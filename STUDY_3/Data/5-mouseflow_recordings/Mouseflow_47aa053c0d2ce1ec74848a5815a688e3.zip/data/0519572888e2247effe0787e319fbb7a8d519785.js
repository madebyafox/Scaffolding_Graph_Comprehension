var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["0519572888e2247effe0787e319fbb7a8d519785"] = {
  "startTime": "2018-05-19T19:55:57.8828934Z",
  "websitePageUrl": "/",
  "visitTime": 55098,
  "engagementTime": 43958,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1266,
  "viewportHeight": 917,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "47aa053c0d2ce1ec74848a5815a688e3",
    "created": "2018-05-19T19:55:57.8555785+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0",
    "browser": "Firefox",
    "browserVersion": "59.0",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "4a50ae5b07abadb70a4b9ff90a3ad3fc",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/47aa053c0d2ce1ec74848a5815a688e3/play"
  },
  "events": [
    {
      "t": 10,
      "e": 10,
      "ty": 14,
      "x": 0,
      "y": 916
    },
    {
      "t": 100,
      "e": 100,
      "ty": 0,
      "x": 1266,
      "y": 917
    },
    {
      "t": 3402,
      "e": 3402,
      "ty": 2,
      "x": 501,
      "y": 328
    },
    {
      "t": 3458,
      "e": 3458,
      "ty": 3,
      "x": 501,
      "y": 411,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 3502,
      "e": 3502,
      "ty": 41,
      "x": 25585,
      "y": 28917,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 3502,
      "e": 3502,
      "ty": 2,
      "x": 501,
      "y": 411
    },
    {
      "t": 3578,
      "e": 3578,
      "ty": 4,
      "x": 25585,
      "y": 28917,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 3580,
      "e": 3580,
      "ty": 5,
      "x": 501,
      "y": 411,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 3752,
      "e": 3752,
      "ty": 41,
      "x": 23674,
      "y": 10321,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 3762,
      "e": 3762,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 3802,
      "e": 3802,
      "ty": 2,
      "x": 440,
      "y": 20
    },
    {
      "t": 4002,
      "e": 4002,
      "ty": 41,
      "x": 22667,
      "y": 873,
      "ta": "html > body"
    },
    {
      "t": 5702,
      "e": 5702,
      "ty": 0,
      "x": 1920,
      "y": 1049
    },
    {
      "t": 6002,
      "e": 6002,
      "ty": 41,
      "x": 44527,
      "y": 698,
      "ta": "html > body"
    },
    {
      "t": 6002,
      "e": 6002,
      "ty": 2,
      "x": 1301,
      "y": 19
    },
    {
      "t": 6102,
      "e": 6102,
      "ty": 2,
      "x": 1519,
      "y": 391
    },
    {
      "t": 6202,
      "e": 6202,
      "ty": 2,
      "x": 1517,
      "y": 700
    },
    {
      "t": 6252,
      "e": 6252,
      "ty": 41,
      "x": 61520,
      "y": 52428,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 6302,
      "e": 6302,
      "ty": 2,
      "x": 1471,
      "y": 782
    },
    {
      "t": 6402,
      "e": 6402,
      "ty": 2,
      "x": 1460,
      "y": 791
    },
    {
      "t": 6410,
      "e": 6410,
      "ty": 3,
      "x": 1460,
      "y": 791,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 6502,
      "e": 6502,
      "ty": 41,
      "x": 60101,
      "y": 54639,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 6522,
      "e": 6522,
      "ty": 4,
      "x": 60101,
      "y": 54639,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 6524,
      "e": 6524,
      "ty": 5,
      "x": 1460,
      "y": 791,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 6602,
      "e": 6602,
      "ty": 2,
      "x": 1442,
      "y": 791
    },
    {
      "t": 6702,
      "e": 6702,
      "ty": 2,
      "x": 1253,
      "y": 792
    },
    {
      "t": 6752,
      "e": 6752,
      "ty": 41,
      "x": 47594,
      "y": 55049,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 6802,
      "e": 6802,
      "ty": 2,
      "x": 1231,
      "y": 796
    },
    {
      "t": 6902,
      "e": 6902,
      "ty": 2,
      "x": 1229,
      "y": 796
    },
    {
      "t": 7002,
      "e": 7002,
      "ty": 41,
      "x": 30828,
      "y": 42515,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 7002,
      "e": 7002,
      "ty": 2,
      "x": 924,
      "y": 643
    },
    {
      "t": 7102,
      "e": 7102,
      "ty": 2,
      "x": 201,
      "y": 58
    },
    {
      "t": 7106,
      "e": 7106,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 7202,
      "e": 7202,
      "ty": 2,
      "x": 153,
      "y": 18
    },
    {
      "t": 7252,
      "e": 7252,
      "ty": 41,
      "x": 4993,
      "y": 635,
      "ta": "html > body"
    },
    {
      "t": 7502,
      "e": 7502,
      "ty": 41,
      "x": 16564,
      "y": 1206,
      "ta": "html > body"
    },
    {
      "t": 7502,
      "e": 7502,
      "ty": 2,
      "x": 489,
      "y": 27
    },
    {
      "t": 10000,
      "e": 10000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 19416,
      "e": 12502,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 19518,
      "e": 12502,
      "ty": 1,
      "x": 0,
      "y": 11
    },
    {
      "t": 19618,
      "e": 12602,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 20556,
      "e": 13540,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 27436,
      "e": 17602,
      "ty": 2,
      "x": 590,
      "y": 132
    },
    {
      "t": 27510,
      "e": 17676,
      "ty": 41,
      "x": 31955,
      "y": 62412,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 27536,
      "e": 17702,
      "ty": 2,
      "x": 1174,
      "y": 889
    },
    {
      "t": 27552,
      "e": 17718,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 27636,
      "e": 17802,
      "ty": 2,
      "x": 1231,
      "y": 1008
    },
    {
      "t": 27760,
      "e": 17926,
      "ty": 41,
      "x": 42117,
      "y": 63502,
      "ta": "> div.masterdiv"
    },
    {
      "t": 27836,
      "e": 18002,
      "ty": 2,
      "x": 1021,
      "y": 870
    },
    {
      "t": 27936,
      "e": 18102,
      "ty": 2,
      "x": 960,
      "y": 844
    },
    {
      "t": 28008,
      "e": 18174,
      "ty": 41,
      "x": 32242,
      "y": 12697,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 28036,
      "e": 18202,
      "ty": 2,
      "x": 932,
      "y": 845
    },
    {
      "t": 28136,
      "e": 18302,
      "ty": 2,
      "x": 908,
      "y": 907
    },
    {
      "t": 28214,
      "e": 18380,
      "ty": 6,
      "x": 931,
      "y": 937,
      "ta": "#start"
    },
    {
      "t": 28236,
      "e": 18402,
      "ty": 2,
      "x": 931,
      "y": 937
    },
    {
      "t": 28258,
      "e": 18424,
      "ty": 41,
      "x": 11741,
      "y": 385,
      "ta": "#start"
    },
    {
      "t": 28332,
      "e": 18498,
      "ty": 7,
      "x": 913,
      "y": 908,
      "ta": "#start"
    },
    {
      "t": 28336,
      "e": 18502,
      "ty": 2,
      "x": 913,
      "y": 908
    },
    {
      "t": 28436,
      "e": 18602,
      "ty": 2,
      "x": 852,
      "y": 835
    },
    {
      "t": 28508,
      "e": 18674,
      "ty": 41,
      "x": 27429,
      "y": 61770,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 28536,
      "e": 18702,
      "ty": 2,
      "x": 851,
      "y": 829
    },
    {
      "t": 28574,
      "e": 18740,
      "ty": 3,
      "x": 851,
      "y": 829,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 28672,
      "e": 18838,
      "ty": 4,
      "x": 27429,
      "y": 61770,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 28672,
      "e": 18838,
      "ty": 5,
      "x": 851,
      "y": 829,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 28758,
      "e": 18924,
      "ty": 41,
      "x": 27429,
      "y": 61972,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 28836,
      "e": 19002,
      "ty": 2,
      "x": 842,
      "y": 850
    },
    {
      "t": 28896,
      "e": 19062,
      "ty": 3,
      "x": 841,
      "y": 851,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 28936,
      "e": 19102,
      "ty": 2,
      "x": 841,
      "y": 851
    },
    {
      "t": 28984,
      "e": 19150,
      "ty": 4,
      "x": 7874,
      "y": 31811,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 28984,
      "e": 19150,
      "ty": 5,
      "x": 841,
      "y": 851,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 28986,
      "e": 19152,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 28990,
      "e": 19156,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 29008,
      "e": 19174,
      "ty": 41,
      "x": 7874,
      "y": 31811,
      "ta": "> div.masterdiv > div:[2] > div > div > label"
    },
    {
      "t": 29136,
      "e": 19302,
      "ty": 2,
      "x": 930,
      "y": 922
    },
    {
      "t": 29148,
      "e": 19314,
      "ty": 6,
      "x": 956,
      "y": 942,
      "ta": "#start"
    },
    {
      "t": 29198,
      "e": 19364,
      "ty": 7,
      "x": 977,
      "y": 971,
      "ta": "#start"
    },
    {
      "t": 29236,
      "e": 19402,
      "ty": 2,
      "x": 981,
      "y": 985
    },
    {
      "t": 29258,
      "e": 19424,
      "ty": 41,
      "x": 46108,
      "y": 37593,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 29336,
      "e": 19502,
      "ty": 2,
      "x": 998,
      "y": 1014
    },
    {
      "t": 29436,
      "e": 19602,
      "ty": 2,
      "x": 998,
      "y": 1007
    },
    {
      "t": 29508,
      "e": 19674,
      "ty": 41,
      "x": 50321,
      "y": 29973,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 29536,
      "e": 19702,
      "ty": 2,
      "x": 996,
      "y": 978
    },
    {
      "t": 29614,
      "e": 19780,
      "ty": 6,
      "x": 996,
      "y": 969,
      "ta": "#start"
    },
    {
      "t": 29636,
      "e": 19802,
      "ty": 2,
      "x": 996,
      "y": 966
    },
    {
      "t": 29728,
      "e": 19894,
      "ty": 3,
      "x": 996,
      "y": 959,
      "ta": "#start"
    },
    {
      "t": 29730,
      "e": 19896,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 29730,
      "e": 19896,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 29736,
      "e": 19902,
      "ty": 2,
      "x": 996,
      "y": 959
    },
    {
      "t": 29758,
      "e": 19924,
      "ty": 41,
      "x": 47239,
      "y": 42790,
      "ta": "#start"
    },
    {
      "t": 29832,
      "e": 19998,
      "ty": 4,
      "x": 47239,
      "y": 42790,
      "ta": "#start"
    },
    {
      "t": 29834,
      "e": 20000,
      "ty": 5,
      "x": 996,
      "y": 959,
      "ta": "#start"
    },
    {
      "t": 29834,
      "e": 20000,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 29936,
      "e": 20102,
      "ty": 2,
      "x": 993,
      "y": 955
    },
    {
      "t": 30000,
      "e": 20166,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30008,
      "e": 20174,
      "ty": 41,
      "x": 33886,
      "y": 60137,
      "ta": "html > body"
    },
    {
      "t": 30036,
      "e": 20202,
      "ty": 2,
      "x": 992,
      "y": 955
    },
    {
      "t": 30136,
      "e": 20302,
      "ty": 2,
      "x": 989,
      "y": 949
    },
    {
      "t": 30236,
      "e": 20402,
      "ty": 2,
      "x": 983,
      "y": 944
    },
    {
      "t": 30258,
      "e": 20424,
      "ty": 41,
      "x": 33576,
      "y": 59438,
      "ta": "html > body"
    },
    {
      "t": 30336,
      "e": 20502,
      "ty": 2,
      "x": 982,
      "y": 944
    },
    {
      "t": 30508,
      "e": 20674,
      "ty": 41,
      "x": 33542,
      "y": 59438,
      "ta": "html > body"
    },
    {
      "t": 30844,
      "e": 21010,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 31446,
      "e": 21612,
      "ty": 2,
      "x": 981,
      "y": 944
    },
    {
      "t": 31508,
      "e": 21674,
      "ty": 41,
      "x": 32715,
      "y": 55755,
      "ta": "html > body"
    },
    {
      "t": 31546,
      "e": 21712,
      "ty": 2,
      "x": 943,
      "y": 801
    },
    {
      "t": 31584,
      "e": 21750,
      "ty": 6,
      "x": 926,
      "y": 638,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 31600,
      "e": 21766,
      "ty": 7,
      "x": 920,
      "y": 599,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 31634,
      "e": 21800,
      "ty": 6,
      "x": 902,
      "y": 524,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 31646,
      "e": 21812,
      "ty": 2,
      "x": 902,
      "y": 524
    },
    {
      "t": 31668,
      "e": 21834,
      "ty": 7,
      "x": 886,
      "y": 480,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 31746,
      "e": 21912,
      "ty": 2,
      "x": 858,
      "y": 417
    },
    {
      "t": 31758,
      "e": 21924,
      "ty": 41,
      "x": 19711,
      "y": 58936,
      "ta": "#jspsych-survey-text-preamble > p"
    },
    {
      "t": 31846,
      "e": 22012,
      "ty": 2,
      "x": 858,
      "y": 407
    },
    {
      "t": 31946,
      "e": 22112,
      "ty": 2,
      "x": 855,
      "y": 444
    },
    {
      "t": 31984,
      "e": 22150,
      "ty": 6,
      "x": 844,
      "y": 500,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 32008,
      "e": 22174,
      "ty": 41,
      "x": 10511,
      "y": 22937,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 32048,
      "e": 22214,
      "ty": 2,
      "x": 843,
      "y": 510
    },
    {
      "t": 32250,
      "e": 22416,
      "ty": 2,
      "x": 840,
      "y": 519
    },
    {
      "t": 32258,
      "e": 22424,
      "ty": 41,
      "x": 9938,
      "y": 38458,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 32282,
      "e": 22448,
      "ty": 3,
      "x": 840,
      "y": 519,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 32282,
      "e": 22448,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 32376,
      "e": 22542,
      "ty": 4,
      "x": 9938,
      "y": 38458,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 32376,
      "e": 22542,
      "ty": 5,
      "x": 840,
      "y": 519,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 32508,
      "e": 22674,
      "ty": 41,
      "x": 9555,
      "y": 40183,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 32548,
      "e": 22714,
      "ty": 2,
      "x": 838,
      "y": 520
    },
    {
      "t": 32648,
      "e": 22814,
      "ty": 2,
      "x": 838,
      "y": 521
    },
    {
      "t": 32758,
      "e": 22924,
      "ty": 41,
      "x": 9555,
      "y": 41907,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 34020,
      "e": 24186,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "77"
    },
    {
      "t": 34020,
      "e": 24186,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 34068,
      "e": 24234,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "m"
    },
    {
      "t": 34390,
      "e": 24556,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 34390,
      "e": 24556,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 34444,
      "e": 24610,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "me"
    },
    {
      "t": 34838,
      "e": 25004,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "78"
    },
    {
      "t": 34840,
      "e": 25006,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 34876,
      "e": 25042,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "men"
    },
    {
      "t": 35024,
      "e": 25190,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "men"
    },
    {
      "t": 35486,
      "e": 25652,
      "ty": 7,
      "x": 850,
      "y": 550,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35508,
      "e": 25674,
      "ty": 41,
      "x": 12803,
      "y": 23665,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 35546,
      "e": 25712,
      "ty": 2,
      "x": 863,
      "y": 592
    },
    {
      "t": 35620,
      "e": 25786,
      "ty": 6,
      "x": 867,
      "y": 609,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 35648,
      "e": 25814,
      "ty": 2,
      "x": 867,
      "y": 614
    },
    {
      "t": 35748,
      "e": 25914,
      "ty": 2,
      "x": 867,
      "y": 618
    },
    {
      "t": 35758,
      "e": 25924,
      "ty": 41,
      "x": 15096,
      "y": 21729,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 35826,
      "e": 25992,
      "ty": 3,
      "x": 867,
      "y": 618,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 35830,
      "e": 25996,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "men"
    },
    {
      "t": 35830,
      "e": 25996,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 35832,
      "e": 25998,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 35936,
      "e": 26102,
      "ty": 4,
      "x": 15096,
      "y": 21729,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 35936,
      "e": 26102,
      "ty": 5,
      "x": 867,
      "y": 618,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 38374,
      "e": 28540,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "97"
    },
    {
      "t": 38374,
      "e": 28540,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 38412,
      "e": 28578,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "1"
    },
    {
      "t": 38508,
      "e": 28674,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "97"
    },
    {
      "t": 38508,
      "e": 28674,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 38556,
      "e": 28722,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11"
    },
    {
      "t": 38726,
      "e": 28892,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "99"
    },
    {
      "t": 38726,
      "e": 28892,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 38764,
      "e": 28930,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 38992,
      "e": 29158,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "191"
    },
    {
      "t": 38992,
      "e": 29158,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 39036,
      "e": 29202,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*\n"
    },
    {
      "t": 40002,
      "e": 30168,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40008,
      "e": 30174,
      "ty": 41,
      "x": 15478,
      "y": 21729,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40048,
      "e": 30214,
      "ty": 2,
      "x": 887,
      "y": 616
    },
    {
      "t": 40148,
      "e": 30314,
      "ty": 2,
      "x": 897,
      "y": 637
    },
    {
      "t": 40156,
      "e": 30322,
      "ty": 7,
      "x": 898,
      "y": 644,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40176,
      "e": 30342,
      "ty": 6,
      "x": 903,
      "y": 658,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 40248,
      "e": 30414,
      "ty": 2,
      "x": 910,
      "y": 675
    },
    {
      "t": 40258,
      "e": 30424,
      "ty": 41,
      "x": 7021,
      "y": 52076,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 40348,
      "e": 30514,
      "ty": 2,
      "x": 913,
      "y": 675
    },
    {
      "t": 40424,
      "e": 30590,
      "ty": 3,
      "x": 923,
      "y": 673,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 40426,
      "e": 30592,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*\n"
    },
    {
      "t": 40428,
      "e": 30594,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40430,
      "e": 30596,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 40448,
      "e": 30614,
      "ty": 2,
      "x": 923,
      "y": 673
    },
    {
      "t": 40508,
      "e": 30674,
      "ty": 41,
      "x": 13783,
      "y": 48176,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 40512,
      "e": 30678,
      "ty": 4,
      "x": 13783,
      "y": 48176,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 40516,
      "e": 30682,
      "ty": 5,
      "x": 923,
      "y": 673,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 40518,
      "e": 30684,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 41616,
      "e": 31782,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 41626,
      "e": 31792,
      "ty": 6,
      "x": 923,
      "y": 673,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 47932,
      "e": 36792,
      "ty": 7,
      "x": 935,
      "y": 648,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 47934,
      "e": 36794,
      "ty": 6,
      "x": 935,
      "y": 648,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 47948,
      "e": 36808,
      "ty": 2,
      "x": 935,
      "y": 648
    },
    {
      "t": 48008,
      "e": 36868,
      "ty": 41,
      "x": 30397,
      "y": 52109,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 48014,
      "e": 36874,
      "ty": 7,
      "x": 921,
      "y": 655,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 48014,
      "e": 36874,
      "ty": 6,
      "x": 921,
      "y": 655,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 48046,
      "e": 36906,
      "ty": 7,
      "x": 885,
      "y": 705,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 48048,
      "e": 36908,
      "ty": 6,
      "x": 885,
      "y": 705,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 48048,
      "e": 36908,
      "ty": 2,
      "x": 885,
      "y": 705
    },
    {
      "t": 48064,
      "e": 36924,
      "ty": 7,
      "x": 866,
      "y": 742,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 48148,
      "e": 37008,
      "ty": 2,
      "x": 845,
      "y": 910
    },
    {
      "t": 48248,
      "e": 37108,
      "ty": 2,
      "x": 877,
      "y": 958
    },
    {
      "t": 48258,
      "e": 37118,
      "ty": 41,
      "x": 29926,
      "y": 60327,
      "ta": "> div.masterdiv"
    },
    {
      "t": 48348,
      "e": 37208,
      "ty": 2,
      "x": 901,
      "y": 946
    },
    {
      "t": 48448,
      "e": 37308,
      "ty": 2,
      "x": 975,
      "y": 912
    },
    {
      "t": 48508,
      "e": 37368,
      "ty": 41,
      "x": 34022,
      "y": 63328,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 48548,
      "e": 37408,
      "ty": 2,
      "x": 987,
      "y": 909
    },
    {
      "t": 48648,
      "e": 37508,
      "ty": 2,
      "x": 1007,
      "y": 917
    },
    {
      "t": 48748,
      "e": 37608,
      "ty": 2,
      "x": 1019,
      "y": 924
    },
    {
      "t": 48760,
      "e": 37620,
      "ty": 41,
      "x": 35694,
      "y": 64518,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 48848,
      "e": 37708,
      "ty": 2,
      "x": 1020,
      "y": 934
    },
    {
      "t": 48864,
      "e": 37724,
      "ty": 6,
      "x": 1020,
      "y": 937,
      "ta": "#start"
    },
    {
      "t": 48948,
      "e": 37808,
      "ty": 2,
      "x": 1017,
      "y": 940
    },
    {
      "t": 49010,
      "e": 37870,
      "ty": 41,
      "x": 57616,
      "y": 10023,
      "ta": "#start"
    },
    {
      "t": 49048,
      "e": 37908,
      "ty": 2,
      "x": 1013,
      "y": 944
    },
    {
      "t": 49148,
      "e": 38008,
      "ty": 2,
      "x": 1009,
      "y": 947
    },
    {
      "t": 49260,
      "e": 38120,
      "ty": 41,
      "x": 54339,
      "y": 19660,
      "ta": "#start"
    },
    {
      "t": 49290,
      "e": 38150,
      "ty": 3,
      "x": 1009,
      "y": 947,
      "ta": "#start"
    },
    {
      "t": 49292,
      "e": 38152,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 49424,
      "e": 38284,
      "ty": 4,
      "x": 54339,
      "y": 19660,
      "ta": "#start"
    },
    {
      "t": 49426,
      "e": 38286,
      "ty": 5,
      "x": 1009,
      "y": 947,
      "ta": "#start"
    },
    {
      "t": 49428,
      "e": 38288,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 49648,
      "e": 38508,
      "ty": 2,
      "x": 1004,
      "y": 949
    },
    {
      "t": 49748,
      "e": 38608,
      "ty": 2,
      "x": 1003,
      "y": 949
    },
    {
      "t": 49760,
      "e": 38620,
      "ty": 41,
      "x": 34265,
      "y": 59756,
      "ta": "html > body"
    },
    {
      "t": 50002,
      "e": 38862,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 50048,
      "e": 38908,
      "ty": 2,
      "x": 1000,
      "y": 945
    },
    {
      "t": 50148,
      "e": 39008,
      "ty": 2,
      "x": 998,
      "y": 941
    },
    {
      "t": 50248,
      "e": 39108,
      "ty": 2,
      "x": 993,
      "y": 934
    },
    {
      "t": 50260,
      "e": 39120,
      "ty": 41,
      "x": 33921,
      "y": 58803,
      "ta": "html > body"
    },
    {
      "t": 50348,
      "e": 39208,
      "ty": 2,
      "x": 992,
      "y": 933
    },
    {
      "t": 50434,
      "e": 39294,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 50508,
      "e": 39368,
      "ty": 41,
      "x": 44270,
      "y": 3185,
      "ta": "> p"
    },
    {
      "t": 50648,
      "e": 39508,
      "ty": 2,
      "x": 989,
      "y": 924
    },
    {
      "t": 50750,
      "e": 39610,
      "ty": 2,
      "x": 988,
      "y": 922
    },
    {
      "t": 50758,
      "e": 39618,
      "ty": 41,
      "x": 33748,
      "y": 58041,
      "ta": "html > body"
    },
    {
      "t": 51050,
      "e": 39910,
      "ty": 2,
      "x": 985,
      "y": 918
    },
    {
      "t": 51150,
      "e": 40010,
      "ty": 2,
      "x": 984,
      "y": 918
    },
    {
      "t": 51260,
      "e": 40120,
      "ty": 41,
      "x": 33611,
      "y": 57787,
      "ta": "html > body"
    },
    {
      "t": 51350,
      "e": 40210,
      "ty": 2,
      "x": 983,
      "y": 917
    },
    {
      "t": 51450,
      "e": 40310,
      "ty": 2,
      "x": 983,
      "y": 923
    },
    {
      "t": 51510,
      "e": 40370,
      "ty": 41,
      "x": 42500,
      "y": 14563,
      "ta": "> p"
    },
    {
      "t": 51550,
      "e": 40410,
      "ty": 2,
      "x": 989,
      "y": 950
    },
    {
      "t": 51650,
      "e": 40510,
      "ty": 2,
      "x": 984,
      "y": 960
    },
    {
      "t": 51750,
      "e": 40610,
      "ty": 2,
      "x": 982,
      "y": 960
    },
    {
      "t": 51760,
      "e": 40620,
      "ty": 41,
      "x": 40730,
      "y": 64624,
      "ta": "> p"
    },
    {
      "t": 51952,
      "e": 40812,
      "ty": 2,
      "x": 979,
      "y": 954
    },
    {
      "t": 52008,
      "e": 40868,
      "ty": 41,
      "x": 33335,
      "y": 58168,
      "ta": "html > body"
    },
    {
      "t": 52052,
      "e": 40912,
      "ty": 2,
      "x": 975,
      "y": 923
    },
    {
      "t": 52260,
      "e": 41120,
      "ty": 41,
      "x": 33301,
      "y": 58105,
      "ta": "html > body"
    },
    {
      "t": 54082,
      "e": 42942,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 55098,
      "e": 43958,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":60,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":61,\"previousSibling\":{\"id\":60},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":62,\"textContent\":\" \",\"previousSibling\":{\"id\":61},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":63,\"textContent\":\" \",\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":64,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":63},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":65,\"textContent\":\" \",\"previousSibling\":{\"id\":64},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":66,\"previousSibling\":{\"id\":65},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":67,\"textContent\":\" \",\"previousSibling\":{\"id\":66},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":68,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":67},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":69,\"previousSibling\":{\"id\":68},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":70,\"textContent\":\" \",\"previousSibling\":{\"id\":69},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":71,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":70},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":72,\"previousSibling\":{\"id\":71},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":73,\"textContent\":\" \",\"previousSibling\":{\"id\":72},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":74,\"textContent\":\" \",\"parentNode\":{\"id\":64}},{\"nodeType\":1,\"id\":75,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":74},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":76,\"textContent\":\" \",\"previousSibling\":{\"id\":75},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":77,\"textContent\":\" \",\"parentNode\":{\"id\":75}},{\"nodeType\":1,\"id\":78,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":77},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":79,\"textContent\":\" \",\"previousSibling\":{\"id\":78},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":80,\"textContent\":\"UNIVERSITY OF CALIFORNIA, SAN DIEGO CONSENT TO ACT AS A RESEARCH SUBJECT\",\"parentNode\":{\"id\":78}},{\"nodeType\":3,\"id\":81,\"textContent\":\" \",\"parentNode\":{\"id\":68}},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":81},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":83,\"textContent\":\" \",\"previousSibling\":{\"id\":82},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":84,\"textContent\":\" \",\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":85,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":84},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":86,\"textContent\":\" \",\"previousSibling\":{\"id\":85},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":87,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":86},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":88,\"textContent\":\" \",\"previousSibling\":{\"id\":87},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":89,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":88},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":90,\"textContent\":\" \",\"previousSibling\":{\"id\":89},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":91,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":90},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":92,\"textContent\":\" \",\"previousSibling\":{\"id\":91},\"parentNode\":{\"id\":82}},{\"nodeType\":8,\"id\":93,\"previousSibling\":{\"id\":92},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":94,\"textContent\":\" \",\"previousSibling\":{\"id\":93},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":95,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control-group centered\"},\"previousSibling\":{\"id\":94},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":96,\"textContent\":\" \",\"previousSibling\":{\"id\":95},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":97,\"textContent\":\" You are being invited to participate in a research study titled Learning Diagrams: Evaluating Learning With External Representations. This study is being done by Amy Fox and Dr. Jim Hollan from the University of California - San Diego (UCSD). You were selected to participate in this study because we think you might use graphs and diagrams in your work and educational activities.\",\"parentNode\":{\"id\":85}},{\"nodeType\":3,\"id\":98,\"textContent\":\" The purpose of this research study is to understand how humans try to make sense of charts, diagrams and graphs that are unconventional and that we may not have seen before. If you agree to take part in this study, you will be asked to read a series of instructions and answer a series of questions. The entire study should take no more than 60 minutes to complete. The researchers expect there will be no direct benefit to you from this research, other than any enjoyment you might have in contributing to research. We hope that you will find the questions interesting, though at times you may feel bored. The investigator(s), however, may learn more about how different types of instructions trigger different levels of understanding when using graphs. There are minimal risks associated with this research study, including a loss of confidentiality of your participation. The researchers are taking all required steps to protect your confidentiality, including storing all of your responses to questions in a secure, encrypted database separate from any information that can personally identify you. The only records containing your name and other personally identifying information are those stored in the system through which you signed up to participate in the study. These records will never be connected with the data we collect from you today. Research records will be kept confidential to the extent allowed by law and may be reviewed by the UCSD Institutional Review Board.\",\"parentNode\":{\"id\":87}},{\"nodeType\":3,\"id\":99,\"textContent\":\" Your participation in this study is completely voluntary and you can withdraw at any time by notifying the researcher that you wish to end your participation. Choosing not to participate or withdrawing will result in no penalty or loss of benefits to which you are entitled. You are free to skip any questions that you choose. If you have questions about this project or if you have a research-related problem, you may contact the researcher(s), Amy Fox: 919 886 4455: a2fox@ucsd.edu, and Jim Hollan: hollan@ucsd.edu. If you have any questions concerning your rights as a research subject, you may contact the UCSD Human Research Protections Program Office at 858-246-HRPP (858-246-4777). \",\"parentNode\":{\"id\":89}},{\"nodeType\":3,\"id\":100,\"textContent\":\" By clicking “I agree” below you are indicating that: you are at least 18 years old, have read this consent form, and agree to participate in this research study. If you do not wish to participate in the study, please notify the researcher now.\",\"parentNode\":{\"id\":91}},{\"nodeType\":3,\"id\":101,\"textContent\":\" \",\"parentNode\":{\"id\":95}},{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"centered control control-checkbox\"},\"previousSibling\":{\"id\":101},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":103,\"textContent\":\" \",\"previousSibling\":{\"id\":102},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":104,\"textContent\":\" I agree to take part in this study. \",\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":105,\"tagName\":\"INPUT\",\"attributes\":{\"id\":\"consent_checkbox\",\"type\":\"checkbox\"},\"previousSibling\":{\"id\":104},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":106,\"textContent\":\" \",\"previousSibling\":{\"id\":105},\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"},\"previousSibling\":{\"id\":106},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":108,\"textContent\":\" \",\"previousSibling\":{\"id\":107},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":109,\"textContent\":\" \",\"parentNode\":{\"id\":71}},{\"nodeType\":1,\"id\":110,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":109},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":111,\"textContent\":\" \",\"previousSibling\":{\"id\":110},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":112,\"textContent\":\"START\",\"parentNode\":{\"id\":110}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"style\":\"display:block;\",\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\",\"width\":\"40\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "<!doctype html>\n<html>\n    <head><!-- MFINJECT -->\n        <title>FOX2YP</title>\n        <!--JAVASCRIPT LIBRARIES -->\n        <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js\"></script>\n        <script src=\"https://cdnjs.cloudflare.com/ajax/libs/underscore.js/1.8.3/underscore-min.js\"></script>\n        <script src=\"https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.17.1/moment.min.js\"></script>\n        <script src=\"https://d3js.org/d3.v4.min.js\"></script>\n        <script src=\"https://use.fontawesome.com/945539d961.js\"></script>\n\n        <!-- JSPYCH LIBRARIES -->\n        <script src=\"../views/jsPsych/jspsych.js\"></script>\n        <script src=\"../views/jsPsych/plugins/jspsych-text.js\"></script>\n        <script src=\"../views/jsPsych/plugins/jspsych-html.js\"></script>\n        <script src=\"../views/jsPsych/plugins/jspsych-button-response.js\"></script>\n        <script src=\"../views/jsPsych/plugins/jspsych-single-stim.js\"></script>\n        <script src=\"../views/jsPsych/plugins/jspsych-survey-text.js\"></script>\n        <script src=\"../views/jsPsych/plugins/jspsych-survey-multi-choice.js\"></script>\n\n        <!-- HELPERS -->\n        <script src=\"../views/src/helpers.js\"></script>\n\n        <!--STYLE SHEETS -->\n        <!-- <link href=\"jsPsych-5.0.3/css/jspsych.css\" rel=\"stylesheet\" type=\"text/css\"></link> -->\n        <link href=\"../views/jsPsych/css/jspsych.css\" rel=\"stylesheet\" type=\"text/css\"></link>\n        <link href=\"../css/styles.css\" rel=\"stylesheet\" type=\"text/css\"></link>\n\n    </head>\n\n  <!-- /*MOUSEFLOW TRACKING SCRIPT*/ -->\n  <script type=\"text/javascript\">\n  window._mfq = window._mfq || [];\n  (function() {\n    var mf = document.createElement(\"script\");\n    mf.type = \"text/javascript\"; mf.async = true;\n    mf.src = \"\";\n    document.getElementsByTagName(\"head\")[0].appendChild(mf);\n  })();\n</script>\n\n    <body> </body>\n\n<script src = \"../views/src/experiment.js\"></script>\n</html>\n",
  "useCssProxy": true,
  "loadTimes": "es: 170, dom: 1108, initialDom: 1121",
  "javascriptErrors": []
}