var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "757d7a9324fce7cb4f99e0025d3a6fd4",
  "created": "2018-06-01T10:06:49.4895844-07:00",
  "lastActivity": "2018-06-01T10:09:14.3796097-07:00",
  "pageViews": [
    {
      "id": "060149710c9f84ece2b3e134fe5e6c350faa363f",
      "startTime": "2018-06-01T10:06:49.6837201-07:00",
      "endTime": "2018-06-01T10:09:14.3796097-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 145115,
      "engagementTime": 108437,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 145115,
  "engagementTime": 108437,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.39",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "67.0.3396.62",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "c8fb45854a12d07c2a1a51746711944c",
  "gdpr": false
}