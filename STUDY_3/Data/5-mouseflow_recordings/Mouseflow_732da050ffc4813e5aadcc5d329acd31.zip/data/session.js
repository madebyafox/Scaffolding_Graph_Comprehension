var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "732da050ffc4813e5aadcc5d329acd31",
  "created": "2018-05-22T16:11:51.6200406-07:00",
  "lastActivity": "2018-05-22T16:12:14.4890406-07:00",
  "pageViews": [
    {
      "id": "052251467e172c86a2ef29692e3d550adcd005a1",
      "startTime": "2018-05-22T16:11:51.6200406-07:00",
      "endTime": "2018-05-22T16:12:14.4890406-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/15",
      "visitTime": 22869,
      "engagementTime": 22721,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 22869,
  "engagementTime": 22721,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.47",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=JVUC6",
    "CONDITION=115",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "e6942045222b3a8c664d532dfa5a1f3c",
  "gdpr": false
}