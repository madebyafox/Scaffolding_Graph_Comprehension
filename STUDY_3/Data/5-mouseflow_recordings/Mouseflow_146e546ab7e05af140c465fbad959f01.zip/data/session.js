var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "146e546ab7e05af140c465fbad959f01",
  "created": "2018-05-22T14:14:54.901411-07:00",
  "lastActivity": "2018-05-22T14:15:10.3322204-07:00",
  "pageViews": [
    {
      "id": "052255651456cdac439fe83e4c8a708df4f3ebb2",
      "startTime": "2018-05-22T14:14:55.0949532-07:00",
      "endTime": "2018-05-22T14:15:10.3322204-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/14",
      "visitTime": 15378,
      "engagementTime": 15377,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 15378,
  "engagementTime": 15377,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.27",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=T5SHZ",
    "CONDITION=121",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "396ca9069b2f025233f9ec0d1f7686b2",
  "gdpr": false
}