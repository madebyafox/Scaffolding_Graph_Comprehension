var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "fe6d28777d2640f96f411621af190bd2",
  "created": "2018-06-04T13:14:05.5785608-07:00",
  "lastActivity": "2018-06-04T13:17:14.1151883-07:00",
  "pageViews": [
    {
      "id": "0604059326a9e10d95489d18ec7a8c127be494b3",
      "startTime": "2018-06-04T13:14:05.5785608-07:00",
      "endTime": "2018-06-04T13:17:14.1151883-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 188907,
      "engagementTime": 47098,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 188907,
  "engagementTime": 47098,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.41",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "248d24c09f7162a42fd95d5cd253a0af",
  "gdpr": false
}