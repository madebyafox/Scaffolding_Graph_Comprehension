var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["0604059326a9e10d95489d18ec7a8c127be494b3"] = {
  "startTime": "2018-06-04T20:14:05.5785608Z",
  "websitePageUrl": "/",
  "visitTime": 188907,
  "engagementTime": 47098,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1094,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "fe6d28777d2640f96f411621af190bd2",
    "created": "2018-06-04T20:14:05.5785608+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "248d24c09f7162a42fd95d5cd253a0af",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/fe6d28777d2640f96f411621af190bd2/play"
  },
  "events": [
    {
      "t": 102,
      "e": 102,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 347,
      "e": 347,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 10006,
      "e": 5102,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 37101,
      "e": 5102,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 37103,
      "e": 5104,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 37201,
      "e": 5202,
      "ty": 2,
      "x": 550,
      "y": 44
    },
    {
      "t": 37252,
      "e": 5253,
      "ty": 41,
      "x": 18665,
      "y": 1994,
      "ta": "html > body"
    },
    {
      "t": 50001,
      "e": 10253,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 122808,
      "e": 10253,
      "ty": 2,
      "x": 549,
      "y": 44
    },
    {
      "t": 122908,
      "e": 10353,
      "ty": 2,
      "x": 615,
      "y": 239
    },
    {
      "t": 123008,
      "e": 10453,
      "ty": 2,
      "x": 697,
      "y": 588
    },
    {
      "t": 123009,
      "e": 10454,
      "ty": 41,
      "x": 18431,
      "y": 31825,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 123109,
      "e": 10554,
      "ty": 2,
      "x": 749,
      "y": 763
    },
    {
      "t": 123209,
      "e": 10654,
      "ty": 2,
      "x": 750,
      "y": 767
    },
    {
      "t": 123259,
      "e": 10704,
      "ty": 41,
      "x": 21326,
      "y": 46488,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 126012,
      "e": 13457,
      "ty": 3,
      "x": 750,
      "y": 767,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 126131,
      "e": 13576,
      "ty": 4,
      "x": 21326,
      "y": 46488,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 126132,
      "e": 13577,
      "ty": 5,
      "x": 750,
      "y": 767,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 126809,
      "e": 14254,
      "ty": 2,
      "x": 753,
      "y": 770
    },
    {
      "t": 126909,
      "e": 14354,
      "ty": 2,
      "x": 800,
      "y": 837
    },
    {
      "t": 127009,
      "e": 14454,
      "ty": 2,
      "x": 804,
      "y": 843
    },
    {
      "t": 127009,
      "e": 14454,
      "ty": 41,
      "x": 24275,
      "y": 52714,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 130009,
      "e": 17454,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 130862,
      "e": 18307,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 130909,
      "e": 18354,
      "ty": 1,
      "x": 0,
      "y": 1
    },
    {
      "t": 131009,
      "e": 18454,
      "ty": 1,
      "x": 0,
      "y": 15
    },
    {
      "t": 131109,
      "e": 18554,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 131408,
      "e": 18853,
      "ty": 2,
      "x": 791,
      "y": 833
    },
    {
      "t": 131509,
      "e": 18954,
      "ty": 2,
      "x": 579,
      "y": 61
    },
    {
      "t": 131509,
      "e": 18954,
      "ty": 41,
      "x": 19663,
      "y": 2936,
      "ta": "html > body"
    },
    {
      "t": 131609,
      "e": 19054,
      "ty": 2,
      "x": 481,
      "y": 16
    },
    {
      "t": 131709,
      "e": 19154,
      "ty": 2,
      "x": 477,
      "y": 16
    },
    {
      "t": 131760,
      "e": 19205,
      "ty": 41,
      "x": 16151,
      "y": 443,
      "ta": "html > body"
    },
    {
      "t": 131809,
      "e": 19254,
      "ty": 2,
      "x": 511,
      "y": 24
    },
    {
      "t": 131908,
      "e": 19353,
      "ty": 2,
      "x": 793,
      "y": 120
    },
    {
      "t": 132009,
      "e": 19454,
      "ty": 2,
      "x": 1001,
      "y": 224
    },
    {
      "t": 132009,
      "e": 19454,
      "ty": 41,
      "x": 34196,
      "y": 11965,
      "ta": "html > body"
    },
    {
      "t": 132109,
      "e": 19554,
      "ty": 2,
      "x": 1178,
      "y": 287
    },
    {
      "t": 132196,
      "e": 19641,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 132215,
      "e": 19660,
      "ty": 2,
      "x": 1211,
      "y": 301
    },
    {
      "t": 132259,
      "e": 19704,
      "ty": 41,
      "x": 45140,
      "y": 12,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 132809,
      "e": 20254,
      "ty": 2,
      "x": 1211,
      "y": 304
    },
    {
      "t": 132909,
      "e": 20354,
      "ty": 2,
      "x": 1090,
      "y": 577
    },
    {
      "t": 132995,
      "e": 20440,
      "ty": 6,
      "x": 917,
      "y": 1103,
      "ta": "#start"
    },
    {
      "t": 133009,
      "e": 20454,
      "ty": 2,
      "x": 917,
      "y": 1103
    },
    {
      "t": 133009,
      "e": 20454,
      "ty": 41,
      "x": 4095,
      "y": 58427,
      "ta": "#start"
    },
    {
      "t": 133011,
      "e": 20456,
      "ty": 7,
      "x": 909,
      "y": 1138,
      "ta": "#start"
    },
    {
      "t": 133108,
      "e": 20553,
      "ty": 2,
      "x": 867,
      "y": 1215
    },
    {
      "t": 133209,
      "e": 20654,
      "ty": 2,
      "x": 860,
      "y": 1200
    },
    {
      "t": 133259,
      "e": 20704,
      "ty": 41,
      "x": 29340,
      "y": 61601,
      "ta": "> div.masterdiv"
    },
    {
      "t": 133309,
      "e": 20754,
      "ty": 2,
      "x": 860,
      "y": 1021
    },
    {
      "t": 133409,
      "e": 20854,
      "ty": 2,
      "x": 846,
      "y": 963
    },
    {
      "t": 133509,
      "e": 20954,
      "ty": 2,
      "x": 833,
      "y": 957
    },
    {
      "t": 133510,
      "e": 20955,
      "ty": 41,
      "x": 26544,
      "y": 57523,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 133609,
      "e": 21054,
      "ty": 2,
      "x": 819,
      "y": 937
    },
    {
      "t": 133709,
      "e": 21154,
      "ty": 2,
      "x": 815,
      "y": 927
    },
    {
      "t": 133760,
      "e": 21205,
      "ty": 41,
      "x": 21503,
      "y": 42648,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 133809,
      "e": 21254,
      "ty": 2,
      "x": 803,
      "y": 915
    },
    {
      "t": 133909,
      "e": 21354,
      "ty": 2,
      "x": 799,
      "y": 901
    },
    {
      "t": 134010,
      "e": 21455,
      "ty": 41,
      "x": 24871,
      "y": 62120,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 134109,
      "e": 21554,
      "ty": 2,
      "x": 806,
      "y": 916
    },
    {
      "t": 134209,
      "e": 21654,
      "ty": 2,
      "x": 811,
      "y": 934
    },
    {
      "t": 134259,
      "e": 21704,
      "ty": 41,
      "x": 25461,
      "y": 55931,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 134307,
      "e": 21752,
      "ty": 3,
      "x": 811,
      "y": 934,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 134386,
      "e": 21831,
      "ty": 4,
      "x": 25461,
      "y": 55931,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 134387,
      "e": 21832,
      "ty": 5,
      "x": 811,
      "y": 934,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 134509,
      "e": 21954,
      "ty": 2,
      "x": 812,
      "y": 931
    },
    {
      "t": 134510,
      "e": 21955,
      "ty": 41,
      "x": 25510,
      "y": 58790,
      "ta": "> div.masterdiv > div:[2] > div > div"
    },
    {
      "t": 134609,
      "e": 22054,
      "ty": 2,
      "x": 812,
      "y": 928
    },
    {
      "t": 134658,
      "e": 22103,
      "ty": 3,
      "x": 812,
      "y": 928,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 134722,
      "e": 22167,
      "ty": 4,
      "x": 28057,
      "y": 55755,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 134722,
      "e": 22167,
      "ty": 5,
      "x": 812,
      "y": 928,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 134725,
      "e": 22170,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 134731,
      "e": 22176,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 134759,
      "e": 22204,
      "ty": 41,
      "x": 28057,
      "y": 55755,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 135009,
      "e": 22454,
      "ty": 2,
      "x": 894,
      "y": 974
    },
    {
      "t": 135010,
      "e": 22455,
      "ty": 41,
      "x": 29545,
      "y": 58701,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 135109,
      "e": 22554,
      "ty": 2,
      "x": 937,
      "y": 1034
    },
    {
      "t": 135180,
      "e": 22625,
      "ty": 6,
      "x": 961,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 135209,
      "e": 22654,
      "ty": 2,
      "x": 962,
      "y": 1074
    },
    {
      "t": 135259,
      "e": 22704,
      "ty": 41,
      "x": 29763,
      "y": 16022,
      "ta": "#start"
    },
    {
      "t": 135309,
      "e": 22754,
      "ty": 2,
      "x": 969,
      "y": 1089
    },
    {
      "t": 135409,
      "e": 22854,
      "ty": 2,
      "x": 970,
      "y": 1093
    },
    {
      "t": 135499,
      "e": 22944,
      "ty": 3,
      "x": 970,
      "y": 1093,
      "ta": "#start"
    },
    {
      "t": 135501,
      "e": 22946,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 135501,
      "e": 22946,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 135509,
      "e": 22954,
      "ty": 41,
      "x": 33040,
      "y": 39152,
      "ta": "#start"
    },
    {
      "t": 135554,
      "e": 22999,
      "ty": 4,
      "x": 33040,
      "y": 39152,
      "ta": "#start"
    },
    {
      "t": 135554,
      "e": 22999,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 135554,
      "e": 22999,
      "ty": 5,
      "x": 970,
      "y": 1093,
      "ta": "#start"
    },
    {
      "t": 135555,
      "e": 23000,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 135709,
      "e": 23154,
      "ty": 2,
      "x": 975,
      "y": 1077
    },
    {
      "t": 135759,
      "e": 23204,
      "ty": 41,
      "x": 33990,
      "y": 55895,
      "ta": "html > body"
    },
    {
      "t": 135809,
      "e": 23254,
      "ty": 2,
      "x": 1029,
      "y": 939
    },
    {
      "t": 135909,
      "e": 23354,
      "ty": 2,
      "x": 1093,
      "y": 804
    },
    {
      "t": 136009,
      "e": 23454,
      "ty": 2,
      "x": 1108,
      "y": 760
    },
    {
      "t": 136009,
      "e": 23454,
      "ty": 41,
      "x": 37881,
      "y": 41658,
      "ta": "html > body"
    },
    {
      "t": 136562,
      "e": 24007,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 137482,
      "e": 24927,
      "ty": 6,
      "x": 1065,
      "y": 695,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 137497,
      "e": 24942,
      "ty": 7,
      "x": 1040,
      "y": 670,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 137509,
      "e": 24954,
      "ty": 2,
      "x": 1040,
      "y": 670
    },
    {
      "t": 137509,
      "e": 24954,
      "ty": 41,
      "x": 50178,
      "y": 38757,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 137609,
      "e": 25054,
      "ty": 2,
      "x": 1019,
      "y": 641
    },
    {
      "t": 137647,
      "e": 25092,
      "ty": 6,
      "x": 1000,
      "y": 606,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 137709,
      "e": 25154,
      "ty": 2,
      "x": 991,
      "y": 587
    },
    {
      "t": 137715,
      "e": 25160,
      "ty": 7,
      "x": 989,
      "y": 583,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 137760,
      "e": 25205,
      "ty": 41,
      "x": 39147,
      "y": 40166,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 137808,
      "e": 25253,
      "ty": 2,
      "x": 989,
      "y": 578
    },
    {
      "t": 138008,
      "e": 25453,
      "ty": 41,
      "x": 39147,
      "y": 39461,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 138108,
      "e": 25553,
      "ty": 2,
      "x": 988,
      "y": 578
    },
    {
      "t": 138132,
      "e": 25577,
      "ty": 6,
      "x": 982,
      "y": 587,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 138209,
      "e": 25654,
      "ty": 2,
      "x": 977,
      "y": 599
    },
    {
      "t": 138258,
      "e": 25703,
      "ty": 41,
      "x": 36552,
      "y": 40569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 138276,
      "e": 25721,
      "ty": 3,
      "x": 977,
      "y": 599,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 138277,
      "e": 25722,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 138410,
      "e": 25855,
      "ty": 4,
      "x": 36552,
      "y": 40569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 138410,
      "e": 25855,
      "ty": 5,
      "x": 977,
      "y": 599,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 139383,
      "e": 26828,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "90"
    },
    {
      "t": 139384,
      "e": 26829,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 139502,
      "e": 26947,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "85"
    },
    {
      "t": 139502,
      "e": 26947,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 139526,
      "e": 26971,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "zu"
    },
    {
      "t": 139606,
      "e": 27051,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "zu"
    },
    {
      "t": 139678,
      "e": 27123,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "76"
    },
    {
      "t": 139679,
      "e": 27124,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 139814,
      "e": 27259,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "zul"
    },
    {
      "t": 139822,
      "e": 27267,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "85"
    },
    {
      "t": 139823,
      "e": 27268,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 139870,
      "e": 27269,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "zulu"
    },
    {
      "t": 139933,
      "e": 27332,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 140450,
      "e": 27849,
      "ty": 7,
      "x": 1031,
      "y": 559,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 140508,
      "e": 27907,
      "ty": 2,
      "x": 1203,
      "y": 445
    },
    {
      "t": 140508,
      "e": 27907,
      "ty": 41,
      "x": 41153,
      "y": 24208,
      "ta": "html > body"
    },
    {
      "t": 141108,
      "e": 28507,
      "ty": 2,
      "x": 1188,
      "y": 458
    },
    {
      "t": 141208,
      "e": 28607,
      "ty": 2,
      "x": 1143,
      "y": 531
    },
    {
      "t": 141259,
      "e": 28658,
      "ty": 41,
      "x": 39052,
      "y": 29305,
      "ta": "html > body"
    },
    {
      "t": 141308,
      "e": 28707,
      "ty": 2,
      "x": 1139,
      "y": 544
    },
    {
      "t": 141408,
      "e": 28807,
      "ty": 2,
      "x": 1118,
      "y": 562
    },
    {
      "t": 141435,
      "e": 28834,
      "ty": 6,
      "x": 1087,
      "y": 593,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 141451,
      "e": 28850,
      "ty": 7,
      "x": 1058,
      "y": 610,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 141508,
      "e": 28907,
      "ty": 2,
      "x": 978,
      "y": 665
    },
    {
      "t": 141509,
      "e": 28908,
      "ty": 41,
      "x": 36768,
      "y": 35233,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 141518,
      "e": 28917,
      "ty": 6,
      "x": 958,
      "y": 682,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 141551,
      "e": 28950,
      "ty": 7,
      "x": 929,
      "y": 710,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 141552,
      "e": 28951,
      "ty": 6,
      "x": 929,
      "y": 710,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 141609,
      "e": 29008,
      "ty": 2,
      "x": 925,
      "y": 717
    },
    {
      "t": 141758,
      "e": 29157,
      "ty": 41,
      "x": 15501,
      "y": 3971,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 141768,
      "e": 29167,
      "ty": 7,
      "x": 928,
      "y": 707,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 141785,
      "e": 29184,
      "ty": 6,
      "x": 931,
      "y": 698,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 141808,
      "e": 29207,
      "ty": 2,
      "x": 936,
      "y": 680
    },
    {
      "t": 141818,
      "e": 29217,
      "ty": 7,
      "x": 938,
      "y": 675,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 141908,
      "e": 29307,
      "ty": 2,
      "x": 938,
      "y": 670
    },
    {
      "t": 142008,
      "e": 29407,
      "ty": 41,
      "x": 28117,
      "y": 38757,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 142108,
      "e": 29507,
      "ty": 2,
      "x": 938,
      "y": 671
    },
    {
      "t": 142135,
      "e": 29534,
      "ty": 6,
      "x": 933,
      "y": 680,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 142208,
      "e": 29607,
      "ty": 2,
      "x": 930,
      "y": 684
    },
    {
      "t": 142258,
      "e": 29657,
      "ty": 41,
      "x": 26387,
      "y": 15603,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 142426,
      "e": 29825,
      "ty": 3,
      "x": 930,
      "y": 684,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 142428,
      "e": 29827,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "zulu"
    },
    {
      "t": 142429,
      "e": 29828,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 142429,
      "e": 29828,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 142530,
      "e": 29929,
      "ty": 4,
      "x": 26387,
      "y": 15603,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 142530,
      "e": 29929,
      "ty": 5,
      "x": 930,
      "y": 684,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 143109,
      "e": 30508,
      "ty": 2,
      "x": 930,
      "y": 682
    },
    {
      "t": 143258,
      "e": 30657,
      "ty": 41,
      "x": 26387,
      "y": 9362,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 143294,
      "e": 30693,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "50"
    },
    {
      "t": 143295,
      "e": 30694,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 143390,
      "e": 30789,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "2"
    },
    {
      "t": 143508,
      "e": 30907,
      "ty": 2,
      "x": 930,
      "y": 681
    },
    {
      "t": 143509,
      "e": 30908,
      "ty": 41,
      "x": 26387,
      "y": 6241,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 143598,
      "e": 30997,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 143599,
      "e": 30998,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 143709,
      "e": 31108,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "21"
    },
    {
      "t": 143926,
      "e": 31325,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 143926,
      "e": 31325,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 144078,
      "e": 31477,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "21*"
    },
    {
      "t": 144203,
      "e": 31602,
      "ty": 7,
      "x": 935,
      "y": 702,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 144209,
      "e": 31608,
      "ty": 2,
      "x": 935,
      "y": 702
    },
    {
      "t": 144221,
      "e": 31620,
      "ty": 6,
      "x": 936,
      "y": 710,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 144258,
      "e": 31657,
      "ty": 41,
      "x": 21686,
      "y": 29788,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 144308,
      "e": 31707,
      "ty": 2,
      "x": 939,
      "y": 736
    },
    {
      "t": 144354,
      "e": 31753,
      "ty": 7,
      "x": 940,
      "y": 743,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 144409,
      "e": 31808,
      "ty": 2,
      "x": 940,
      "y": 744
    },
    {
      "t": 144509,
      "e": 31908,
      "ty": 41,
      "x": 32095,
      "y": 40772,
      "ta": "html > body"
    },
    {
      "t": 144588,
      "e": 31987,
      "ty": 6,
      "x": 940,
      "y": 740,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 144609,
      "e": 32008,
      "ty": 2,
      "x": 941,
      "y": 736
    },
    {
      "t": 144708,
      "e": 32107,
      "ty": 2,
      "x": 941,
      "y": 732
    },
    {
      "t": 144759,
      "e": 32158,
      "ty": 41,
      "x": 23232,
      "y": 47661,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 145109,
      "e": 32508,
      "ty": 2,
      "x": 941,
      "y": 723
    },
    {
      "t": 145209,
      "e": 32608,
      "ty": 2,
      "x": 941,
      "y": 722
    },
    {
      "t": 145259,
      "e": 32658,
      "ty": 41,
      "x": 23232,
      "y": 27802,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 145873,
      "e": 33272,
      "ty": 3,
      "x": 941,
      "y": 722,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 145874,
      "e": 33273,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "21*"
    },
    {
      "t": 145874,
      "e": 33273,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 145874,
      "e": 33273,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 145961,
      "e": 33360,
      "ty": 4,
      "x": 23232,
      "y": 27802,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 145962,
      "e": 33361,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 145963,
      "e": 33362,
      "ty": 5,
      "x": 941,
      "y": 722,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 145963,
      "e": 33362,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 146509,
      "e": 33908,
      "ty": 2,
      "x": 970,
      "y": 721
    },
    {
      "t": 146509,
      "e": 33908,
      "ty": 41,
      "x": 33129,
      "y": 39498,
      "ta": "html > body"
    },
    {
      "t": 146608,
      "e": 34007,
      "ty": 2,
      "x": 1152,
      "y": 713
    },
    {
      "t": 146709,
      "e": 34108,
      "ty": 2,
      "x": 1157,
      "y": 710
    },
    {
      "t": 146758,
      "e": 34157,
      "ty": 41,
      "x": 39568,
      "y": 38888,
      "ta": "html > body"
    },
    {
      "t": 147057,
      "e": 34456,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 147086,
      "e": 34485,
      "ty": 6,
      "x": 1157,
      "y": 710,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 150008,
      "e": 37407,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 174146,
      "e": 39485,
      "ty": 7,
      "x": 1171,
      "y": 692,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 174147,
      "e": 39486,
      "ty": 6,
      "x": 1171,
      "y": 692,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 174209,
      "e": 39548,
      "ty": 2,
      "x": 1178,
      "y": 681
    },
    {
      "t": 174259,
      "e": 39598,
      "ty": 41,
      "x": 42860,
      "y": 23441,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 174378,
      "e": 39717,
      "ty": 7,
      "x": 1166,
      "y": 752,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 174379,
      "e": 39718,
      "ty": 6,
      "x": 1166,
      "y": 752,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 174394,
      "e": 39733,
      "ty": 7,
      "x": 1143,
      "y": 843,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 174409,
      "e": 39748,
      "ty": 2,
      "x": 1143,
      "y": 843
    },
    {
      "t": 174509,
      "e": 39848,
      "ty": 2,
      "x": 984,
      "y": 1158
    },
    {
      "t": 174509,
      "e": 39848,
      "ty": 41,
      "x": 44236,
      "y": 47262,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 174608,
      "e": 39947,
      "ty": 2,
      "x": 968,
      "y": 1205
    },
    {
      "t": 174708,
      "e": 40047,
      "ty": 2,
      "x": 964,
      "y": 1185
    },
    {
      "t": 174759,
      "e": 40098,
      "ty": 41,
      "x": 33001,
      "y": 46708,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 174809,
      "e": 40148,
      "ty": 2,
      "x": 959,
      "y": 1145
    },
    {
      "t": 174908,
      "e": 40247,
      "ty": 2,
      "x": 958,
      "y": 1132
    },
    {
      "t": 175008,
      "e": 40347,
      "ty": 2,
      "x": 958,
      "y": 1111
    },
    {
      "t": 175009,
      "e": 40348,
      "ty": 41,
      "x": 32065,
      "y": 21224,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 175013,
      "e": 40352,
      "ty": 6,
      "x": 959,
      "y": 1099,
      "ta": "#start"
    },
    {
      "t": 175108,
      "e": 40447,
      "ty": 2,
      "x": 959,
      "y": 1077
    },
    {
      "t": 175259,
      "e": 40598,
      "ty": 41,
      "x": 27033,
      "y": 8312,
      "ta": "#start"
    },
    {
      "t": 175459,
      "e": 40798,
      "ty": 3,
      "x": 959,
      "y": 1077,
      "ta": "#start"
    },
    {
      "t": 175460,
      "e": 40799,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 175545,
      "e": 40884,
      "ty": 4,
      "x": 27033,
      "y": 8312,
      "ta": "#start"
    },
    {
      "t": 175545,
      "e": 40884,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 175546,
      "e": 40885,
      "ty": 5,
      "x": 959,
      "y": 1077,
      "ta": "#start"
    },
    {
      "t": 175547,
      "e": 40886,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 176109,
      "e": 41448,
      "ty": 2,
      "x": 955,
      "y": 1012
    },
    {
      "t": 176209,
      "e": 41548,
      "ty": 2,
      "x": 919,
      "y": 922
    },
    {
      "t": 176258,
      "e": 41597,
      "ty": 41,
      "x": 30305,
      "y": 45148,
      "ta": "html > body"
    },
    {
      "t": 176309,
      "e": 41648,
      "ty": 2,
      "x": 843,
      "y": 644
    },
    {
      "t": 176409,
      "e": 41748,
      "ty": 2,
      "x": 821,
      "y": 507
    },
    {
      "t": 176509,
      "e": 41848,
      "ty": 41,
      "x": 27997,
      "y": 27643,
      "ta": "html > body"
    },
    {
      "t": 176550,
      "e": 41889,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 176609,
      "e": 41948,
      "ty": 2,
      "x": 791,
      "y": 415
    },
    {
      "t": 176708,
      "e": 42047,
      "ty": 2,
      "x": 785,
      "y": 401
    },
    {
      "t": 176759,
      "e": 42098,
      "ty": 41,
      "x": 24296,
      "y": 19839,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 180013,
      "e": 45352,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 187899,
      "e": 47098,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 188907,
      "e": 47098,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":60,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":61,\"previousSibling\":{\"id\":60},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":62,\"textContent\":\" \",\"previousSibling\":{\"id\":61},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":63,\"textContent\":\" \",\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":64,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":63},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":65,\"textContent\":\" \",\"previousSibling\":{\"id\":64},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":66,\"previousSibling\":{\"id\":65},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":67,\"textContent\":\" \",\"previousSibling\":{\"id\":66},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":68,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":67},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":69,\"previousSibling\":{\"id\":68},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":70,\"textContent\":\" \",\"previousSibling\":{\"id\":69},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":71,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":70},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":72,\"previousSibling\":{\"id\":71},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":73,\"textContent\":\" \",\"previousSibling\":{\"id\":72},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":74,\"textContent\":\" \",\"parentNode\":{\"id\":64}},{\"nodeType\":1,\"id\":75,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":74},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":76,\"textContent\":\" \",\"previousSibling\":{\"id\":75},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":77,\"textContent\":\" \",\"parentNode\":{\"id\":75}},{\"nodeType\":1,\"id\":78,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":77},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":79,\"textContent\":\" \",\"previousSibling\":{\"id\":78},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":80,\"textContent\":\"UNIVERSITY OF CALIFORNIA, SAN DIEGO CONSENT TO ACT AS A RESEARCH SUBJECT\",\"parentNode\":{\"id\":78}},{\"nodeType\":3,\"id\":81,\"textContent\":\" \",\"parentNode\":{\"id\":68}},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":81},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":83,\"textContent\":\" \",\"previousSibling\":{\"id\":82},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":84,\"textContent\":\" \",\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":85,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":84},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":86,\"textContent\":\" \",\"previousSibling\":{\"id\":85},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":87,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":86},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":88,\"textContent\":\" \",\"previousSibling\":{\"id\":87},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":89,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":88},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":90,\"textContent\":\" \",\"previousSibling\":{\"id\":89},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":91,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":90},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":92,\"textContent\":\" \",\"previousSibling\":{\"id\":91},\"parentNode\":{\"id\":82}},{\"nodeType\":8,\"id\":93,\"previousSibling\":{\"id\":92},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":94,\"textContent\":\" \",\"previousSibling\":{\"id\":93},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":95,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control-group centered\"},\"previousSibling\":{\"id\":94},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":96,\"textContent\":\" \",\"previousSibling\":{\"id\":95},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":97,\"textContent\":\" You are being invited to participate in a research study titled Learning Diagrams: Evaluating Learning With External Representations. This study is being done by Amy Fox and Dr. Jim Hollan from the University of California - San Diego (UCSD). You were selected to participate in this study because we think you might use graphs and diagrams in your work and educational activities.\",\"parentNode\":{\"id\":85}},{\"nodeType\":3,\"id\":98,\"textContent\":\" The purpose of this research study is to understand how humans try to make sense of charts, diagrams and graphs that are unconventional and that we may not have seen before. If you agree to take part in this study, you will be asked to read a series of instructions and answer a series of questions. The entire study should take no more than 60 minutes to complete. The researchers expect there will be no direct benefit to you from this research, other than any enjoyment you might have in contributing to research. We hope that you will find the questions interesting, though at times you may feel bored. The investigator(s), however, may learn more about how different types of instructions trigger different levels of understanding when using graphs. There are minimal risks associated with this research study, including a loss of confidentiality of your participation. The researchers are taking all required steps to protect your confidentiality, including storing all of your responses to questions in a secure, encrypted database separate from any information that can personally identify you. The only records containing your name and other personally identifying information are those stored in the system through which you signed up to participate in the study. These records will never be connected with the data we collect from you today. Research records will be kept confidential to the extent allowed by law and may be reviewed by the UCSD Institutional Review Board.\",\"parentNode\":{\"id\":87}},{\"nodeType\":3,\"id\":99,\"textContent\":\" Your participation in this study is completely voluntary and you can withdraw at any time by notifying the researcher that you wish to end your participation. Choosing not to participate or withdrawing will result in no penalty or loss of benefits to which you are entitled. You are free to skip any questions that you choose. If you have questions about this project or if you have a research-related problem, you may contact the researcher(s), Amy Fox: 919 886 4455: a2fox@ucsd.edu, and Jim Hollan: hollan@ucsd.edu. If you have any questions concerning your rights as a research subject, you may contact the UCSD Human Research Protections Program Office at 858-246-HRPP (858-246-4777). \",\"parentNode\":{\"id\":89}},{\"nodeType\":3,\"id\":100,\"textContent\":\" By clicking “I agree” below you are indicating that: you are at least 18 years old, have read this consent form, and agree to participate in this research study. If you do not wish to participate in the study, please notify the researcher now.\",\"parentNode\":{\"id\":91}},{\"nodeType\":3,\"id\":101,\"textContent\":\" \",\"parentNode\":{\"id\":95}},{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"centered control control-checkbox\"},\"previousSibling\":{\"id\":101},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":103,\"textContent\":\" \",\"previousSibling\":{\"id\":102},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":104,\"textContent\":\" I agree to take part in this study. \",\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":105,\"tagName\":\"INPUT\",\"attributes\":{\"id\":\"consent_checkbox\",\"type\":\"checkbox\"},\"previousSibling\":{\"id\":104},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":106,\"textContent\":\" \",\"previousSibling\":{\"id\":105},\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"},\"previousSibling\":{\"id\":106},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":108,\"textContent\":\" \",\"previousSibling\":{\"id\":107},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":109,\"textContent\":\" \",\"parentNode\":{\"id\":71}},{\"nodeType\":1,\"id\":110,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":109},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":111,\"textContent\":\" \",\"previousSibling\":{\"id\":110},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":112,\"textContent\":\"START\",\"parentNode\":{\"id\":110}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 448, dom: 1195, initialDom: 1202",
  "javascriptErrors": []
}