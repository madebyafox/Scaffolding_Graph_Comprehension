var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "e5f18d838d8a409da0931ca6e6675111",
  "created": "2018-05-18T11:19:01.9885557-07:00",
  "lastActivity": "2018-05-18T11:19:37.2725557-07:00",
  "pageViews": [
    {
      "id": "051802253e7c6c18ec94755fc677987ed01ff065",
      "startTime": "2018-05-18T11:19:01.9885557-07:00",
      "endTime": "2018-05-18T11:19:37.2725557-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/14",
      "visitTime": 35284,
      "engagementTime": 35284,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 35284,
  "engagementTime": 35284,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.34",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=4KEEF",
    "CONDITION=113",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "ecc2ca6af74cbcfcc226fc9d974bb79c",
  "gdpr": false
}