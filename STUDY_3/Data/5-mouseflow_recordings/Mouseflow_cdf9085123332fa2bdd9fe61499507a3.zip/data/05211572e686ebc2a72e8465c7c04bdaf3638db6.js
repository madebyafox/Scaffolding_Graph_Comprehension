var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05211572e686ebc2a72e8465c7c04bdaf3638db6"] = {
  "startTime": "2018-05-21T17:16:15.3455394Z",
  "websitePageUrl": "/16",
  "visitTime": 195494,
  "engagementTime": 166817,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "cdf9085123332fa2bdd9fe61499507a3",
    "created": "2018-05-21T17:16:15.3455394+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=DKL3R",
      "CONDITION=121"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "025ad1e5172e799fc286bac8e9bbf9da",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/cdf9085123332fa2bdd9fe61499507a3/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 201,
      "e": 201,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 1101,
      "e": 1101,
      "ty": 2,
      "x": 512,
      "y": 748
    },
    {
      "t": 1193,
      "e": 1193,
      "ty": 6,
      "x": 463,
      "y": 596,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1202,
      "e": 1202,
      "ty": 2,
      "x": 463,
      "y": 596
    },
    {
      "t": 1251,
      "e": 1251,
      "ty": 41,
      "x": 40457,
      "y": 47950,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1301,
      "e": 1301,
      "ty": 2,
      "x": 452,
      "y": 563
    },
    {
      "t": 1401,
      "e": 1401,
      "ty": 2,
      "x": 445,
      "y": 543
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 41,
      "x": 39108,
      "y": 16396,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1601,
      "e": 1601,
      "ty": 2,
      "x": 445,
      "y": 545
    },
    {
      "t": 1701,
      "e": 1701,
      "ty": 2,
      "x": 445,
      "y": 549
    },
    {
      "t": 1752,
      "e": 1752,
      "ty": 41,
      "x": 39108,
      "y": 21250,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1802,
      "e": 1802,
      "ty": 2,
      "x": 445,
      "y": 551
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 41,
      "x": 39108,
      "y": 22868,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9338,
      "e": 7001,
      "ty": 3,
      "x": 445,
      "y": 551,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9340,
      "e": 7003,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9383,
      "e": 7046,
      "ty": 4,
      "x": 39108,
      "y": 22868,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9383,
      "e": 7046,
      "ty": 5,
      "x": 445,
      "y": 551,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9700,
      "e": 7363,
      "ty": 2,
      "x": 475,
      "y": 587
    },
    {
      "t": 9750,
      "e": 7413,
      "ty": 41,
      "x": 43154,
      "y": 60895,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9800,
      "e": 7463,
      "ty": 2,
      "x": 484,
      "y": 600
    },
    {
      "t": 9901,
      "e": 7564,
      "ty": 2,
      "x": 485,
      "y": 602
    },
    {
      "t": 10001,
      "e": 7664,
      "ty": 41,
      "x": 43604,
      "y": 64131,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10001,
      "e": 7664,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 13376,
      "e": 11039,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 13488,
      "e": 11151,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 13584,
      "e": 11247,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 13584,
      "e": 11247,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13687,
      "e": 11350,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 13702,
      "e": 11365,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B"
    },
    {
      "t": 13783,
      "e": 11446,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "B"
    },
    {
      "t": 13855,
      "e": 11518,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 13856,
      "e": 11519,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13966,
      "e": 11629,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By"
    },
    {
      "t": 14080,
      "e": 11743,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14080,
      "e": 11743,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14205,
      "e": 11868,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By "
    },
    {
      "t": 14206,
      "e": 11869,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By "
    },
    {
      "t": 15095,
      "e": 12758,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 15096,
      "e": 12759,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15205,
      "e": 12868,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By l"
    },
    {
      "t": 15215,
      "e": 12878,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By l"
    },
    {
      "t": 15392,
      "e": 13055,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 15392,
      "e": 13055,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15470,
      "e": 13133,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 15575,
      "e": 13238,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 15575,
      "e": 13238,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15654,
      "e": 13317,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 15831,
      "e": 13494,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 15831,
      "e": 13494,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15927,
      "e": 13590,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 16071,
      "e": 13734,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 16072,
      "e": 13735,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16119,
      "e": 13782,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 16535,
      "e": 14198,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 16535,
      "e": 14198,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16638,
      "e": 14301,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 16654,
      "e": 14317,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 16654,
      "e": 14317,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16806,
      "e": 14469,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking"
    },
    {
      "t": 16815,
      "e": 14478,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 16831,
      "e": 14494,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16832,
      "e": 14495,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17006,
      "e": 14669,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking "
    },
    {
      "t": 17007,
      "e": 14670,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 17015,
      "e": 14678,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 17015,
      "e": 14678,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17199,
      "e": 14862,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 17287,
      "e": 14950,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 17288,
      "e": 14951,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17407,
      "e": 15070,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at"
    },
    {
      "t": 17455,
      "e": 15118,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 17503,
      "e": 15166,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17504,
      "e": 15167,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17605,
      "e": 15268,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at "
    },
    {
      "t": 17630,
      "e": 15293,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 17630,
      "e": 15293,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17678,
      "e": 15341,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 17775,
      "e": 15438,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17783,
      "e": 15446,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 17784,
      "e": 15447,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17879,
      "e": 15542,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 17903,
      "e": 15566,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 17904,
      "e": 15567,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18007,
      "e": 15670,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the"
    },
    {
      "t": 18063,
      "e": 15726,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 18064,
      "e": 15727,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18065,
      "e": 15728,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18182,
      "e": 15845,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20005,
      "e": 17668,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 21528,
      "e": 19191,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 21529,
      "e": 19192,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21623,
      "e": 19286,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 21871,
      "e": 19534,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 21871,
      "e": 19534,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21990,
      "e": 19653,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||-"
    },
    {
      "t": 22159,
      "e": 19822,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 22159,
      "e": 19822,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22247,
      "e": 19910,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 22351,
      "e": 20014,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 22352,
      "e": 20015,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22470,
      "e": 20133,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 22503,
      "e": 20166,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 22503,
      "e": 20166,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22607,
      "e": 20270,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the x-axi"
    },
    {
      "t": 22608,
      "e": 20271,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 22623,
      "e": 20286,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 22624,
      "e": 20287,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22718,
      "e": 20381,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 22887,
      "e": 20550,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22888,
      "e": 20551,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23005,
      "e": 20668,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the x-axis "
    },
    {
      "t": 23022,
      "e": 20685,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25615,
      "e": 23278,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 25806,
      "e": 23469,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "By looking at the x-axis"
    },
    {
      "t": 26115,
      "e": 23778,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26147,
      "e": 23810,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26179,
      "e": 23842,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26213,
      "e": 23876,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26246,
      "e": 23909,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26279,
      "e": 23942,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26312,
      "e": 23975,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26345,
      "e": 24008,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26378,
      "e": 24041,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26411,
      "e": 24074,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26444,
      "e": 24107,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26477,
      "e": 24140,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26510,
      "e": 24173,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26543,
      "e": 24206,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26576,
      "e": 24239,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26608,
      "e": 24271,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26642,
      "e": 24305,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26675,
      "e": 24338,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26708,
      "e": 24371,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26741,
      "e": 24404,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26774,
      "e": 24437,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26807,
      "e": 24470,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26839,
      "e": 24502,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26873,
      "e": 24536,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26906,
      "e": 24569,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26939,
      "e": 24602,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 26972,
      "e": 24635,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 27005,
      "e": 24668,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 27038,
      "e": 24701,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 27071,
      "e": 24734,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 27104,
      "e": 24767,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 27133,
      "e": 24796,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 27262,
      "e": 24925,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 27375,
      "e": 25038,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 27487,
      "e": 25150,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 27488,
      "e": 25151,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27582,
      "e": 25245,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 27622,
      "e": 25285,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F"
    },
    {
      "t": 27727,
      "e": 25390,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "F"
    },
    {
      "t": 27735,
      "e": 25398,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 27736,
      "e": 25399,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27846,
      "e": 25509,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 27847,
      "e": 25510,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27863,
      "e": 25526,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Fir"
    },
    {
      "t": 27902,
      "e": 25565,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Fir"
    },
    {
      "t": 28007,
      "e": 25670,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Fir"
    },
    {
      "t": 28111,
      "e": 25774,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 28111,
      "e": 25774,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28247,
      "e": 25910,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Firs"
    },
    {
      "t": 28327,
      "e": 25990,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 28328,
      "e": 25991,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28439,
      "e": 26102,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 28639,
      "e": 26302,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28640,
      "e": 26303,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28790,
      "e": 26453,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 29151,
      "e": 26814,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 29153,
      "e": 26816,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29239,
      "e": 26902,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 29247,
      "e": 26910,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 29247,
      "e": 26910,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29406,
      "e": 27069,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First fi"
    },
    {
      "t": 29414,
      "e": 27077,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 29415,
      "e": 27078,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29430,
      "e": 27093,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 29503,
      "e": 27166,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 29504,
      "e": 27167,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29550,
      "e": 27213,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 29646,
      "e": 27309,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 29767,
      "e": 27430,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29768,
      "e": 27431,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29942,
      "e": 27605,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30004,
      "e": 27667,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 31008,
      "e": 28671,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 31008,
      "e": 28671,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31126,
      "e": 28789,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 31215,
      "e": 28878,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 31215,
      "e": 28878,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31334,
      "e": 28997,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 31503,
      "e": 29166,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 31503,
      "e": 29166,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31526,
      "e": 29189,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 32638,
      "e": 30301,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 32718,
      "e": 30381,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12"
    },
    {
      "t": 32990,
      "e": 30653,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 32991,
      "e": 30654,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33087,
      "e": 30750,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 33223,
      "e": 30886,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 33224,
      "e": 30887,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33318,
      "e": 30981,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 33399,
      "e": 31062,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33399,
      "e": 31062,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33494,
      "e": 31157,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 33494,
      "e": 31157,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33518,
      "e": 31181,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| o"
    },
    {
      "t": 33638,
      "e": 31301,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 33638,
      "e": 31301,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33646,
      "e": 31309,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 33743,
      "e": 31406,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33783,
      "e": 31446,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33783,
      "e": 31446,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33966,
      "e": 31629,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 33974,
      "e": 31637,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 33975,
      "e": 31638,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34071,
      "e": 31734,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 34103,
      "e": 31766,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 34104,
      "e": 31767,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34207,
      "e": 31870,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on th"
    },
    {
      "t": 34223,
      "e": 31886,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 34279,
      "e": 31942,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 34280,
      "e": 31943,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34406,
      "e": 32069,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the"
    },
    {
      "t": 34414,
      "e": 32077,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 34495,
      "e": 32158,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34496,
      "e": 32159,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34606,
      "e": 32269,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the "
    },
    {
      "t": 34638,
      "e": 32301,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 35055,
      "e": 32718,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 35056,
      "e": 32719,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35135,
      "e": 32798,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 35214,
      "e": 32877,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 35215,
      "e": 32878,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35350,
      "e": 33013,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||-"
    },
    {
      "t": 35399,
      "e": 33062,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 35399,
      "e": 33062,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35470,
      "e": 33133,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 35582,
      "e": 33245,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 35583,
      "e": 33246,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35670,
      "e": 33333,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 35678,
      "e": 33341,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 35678,
      "e": 33341,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35775,
      "e": 33438,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 35822,
      "e": 33485,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 35823,
      "e": 33486,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35958,
      "e": 33621,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 36022,
      "e": 33685,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36023,
      "e": 33686,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36191,
      "e": 33854,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 36223,
      "e": 33886,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 36223,
      "e": 33886,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36350,
      "e": 34013,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 36495,
      "e": 34158,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 36496,
      "e": 34159,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36582,
      "e": 34245,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 36606,
      "e": 34269,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 36606,
      "e": 34269,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36710,
      "e": 34373,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 36838,
      "e": 34501,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36838,
      "e": 34501,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36990,
      "e": 34653,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 39407,
      "e": 37070,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 39606,
      "e": 37269,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and"
    },
    {
      "t": 39906,
      "e": 37569,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 39939,
      "e": 37602,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 39971,
      "e": 37634,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 40003,
      "e": 37666,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40005,
      "e": 37668,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 40037,
      "e": 37700,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 40070,
      "e": 37733,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 40103,
      "e": 37766,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 40110,
      "e": 37773,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-a"
    },
    {
      "t": 41846,
      "e": 39509,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 41847,
      "e": 39510,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41934,
      "e": 39597,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 42031,
      "e": 39694,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 42031,
      "e": 39694,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42151,
      "e": 39814,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 42198,
      "e": 39861,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 42199,
      "e": 39862,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42278,
      "e": 39941,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 42440,
      "e": 40103,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 42442,
      "e": 40105,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42549,
      "e": 40212,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 42622,
      "e": 40285,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 42622,
      "e": 40285,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42719,
      "e": 40382,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 42759,
      "e": 40422,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 42760,
      "e": 40423,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42837,
      "e": 40500,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 42846,
      "e": 40509,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 42847,
      "e": 40510,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42966,
      "e": 40629,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 42982,
      "e": 40645,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 42983,
      "e": 40646,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43119,
      "e": 40782,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 43119,
      "e": 40782,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43166,
      "e": 40829,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 43270,
      "e": 40933,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 43270,
      "e": 40933,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 43270,
      "e": 40933,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43366,
      "e": 41029,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 43398,
      "e": 41061,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 43398,
      "e": 41061,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43494,
      "e": 41157,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 43535,
      "e": 41198,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 43535,
      "e": 41198,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43630,
      "e": 41293,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 43678,
      "e": 41341,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 43679,
      "e": 41342,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43806,
      "e": 41469,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then "
    },
    {
      "t": 43838,
      "e": 41501,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 43966,
      "e": 41629,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 43968,
      "e": 41631,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44086,
      "e": 41749,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 44134,
      "e": 41797,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 44134,
      "e": 41797,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44230,
      "e": 41893,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 44439,
      "e": 42102,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 44440,
      "e": 42103,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44566,
      "e": 42229,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 48566,
      "e": 46229,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 48568,
      "e": 46231,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48654,
      "e": 46317,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 48783,
      "e": 46446,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 48783,
      "e": 46446,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48910,
      "e": 46573,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 48967,
      "e": 46630,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 48967,
      "e": 46630,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49103,
      "e": 46766,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 49150,
      "e": 46813,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 49151,
      "e": 46814,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49230,
      "e": 46893,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 49366,
      "e": 47029,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 49367,
      "e": 47030,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49446,
      "e": 47109,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 49446,
      "e": 47109,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49469,
      "e": 47132,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ro"
    },
    {
      "t": 49606,
      "e": 47269,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up fro"
    },
    {
      "t": 49607,
      "e": 47270,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 49609,
      "e": 47272,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49629,
      "e": 47292,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 49766,
      "e": 47429,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 50004,
      "e": 47667,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 50077,
      "e": 47740,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 50078,
      "e": 47741,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50206,
      "e": 47869,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from "
    },
    {
      "t": 50214,
      "e": 47877,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 51950,
      "e": 49613,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 51951,
      "e": 49614,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52038,
      "e": 49701,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 52223,
      "e": 49886,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 52223,
      "e": 49886,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52333,
      "e": 49996,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 52349,
      "e": 50012,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 52350,
      "e": 50013,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52470,
      "e": 50133,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 52630,
      "e": 50293,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 52632,
      "e": 50295,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52773,
      "e": 50436,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 53223,
      "e": 50886,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 53224,
      "e": 50887,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53334,
      "e": 50997,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 53447,
      "e": 51110,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 53447,
      "e": 51110,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53550,
      "e": 51213,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 53782,
      "e": 51445,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 53783,
      "e": 51446,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53878,
      "e": 51541,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 54023,
      "e": 51686,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 54023,
      "e": 51686,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54158,
      "e": 51821,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 54310,
      "e": 51973,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 54311,
      "e": 51974,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54438,
      "e": 52101,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 55070,
      "e": 52733,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 55071,
      "e": 52734,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55174,
      "e": 52837,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 55311,
      "e": 52974,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 55311,
      "e": 52974,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55438,
      "e": 53101,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 55510,
      "e": 53173,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 55511,
      "e": 53174,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55646,
      "e": 53309,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 55694,
      "e": 53357,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 55695,
      "e": 53358,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55805,
      "e": 53468,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm poin"
    },
    {
      "t": 55806,
      "e": 53469,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 55846,
      "e": 53509,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 55846,
      "e": 53509,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55902,
      "e": 53565,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 56007,
      "e": 53670,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point"
    },
    {
      "t": 56158,
      "e": 53821,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 56160,
      "e": 53823,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56294,
      "e": 53957,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 56509,
      "e": 54172,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 56510,
      "e": 54173,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56638,
      "e": 54301,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 56662,
      "e": 54325,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 56663,
      "e": 54326,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56774,
      "e": 54437,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 56775,
      "e": 54438,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56782,
      "e": 54445,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||nd"
    },
    {
      "t": 56902,
      "e": 54565,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 56902,
      "e": 54565,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56909,
      "e": 54572,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 57031,
      "e": 54694,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 57031,
      "e": 54694,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57053,
      "e": 54716,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 57133,
      "e": 54796,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 57134,
      "e": 54797,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57149,
      "e": 54812,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 57270,
      "e": 54933,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 57272,
      "e": 54935,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57293,
      "e": 54956,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 57366,
      "e": 55029,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 57366,
      "e": 55029,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57381,
      "e": 55044,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 57550,
      "e": 55213,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 57551,
      "e": 55214,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57559,
      "e": 55222,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 57701,
      "e": 55364,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 57950,
      "e": 55613,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 57951,
      "e": 55614,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58038,
      "e": 55701,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 58039,
      "e": 55702,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58062,
      "e": 55725,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||an"
    },
    {
      "t": 58119,
      "e": 55782,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 58247,
      "e": 55910,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 58247,
      "e": 55910,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58333,
      "e": 55996,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 58374,
      "e": 56037,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 58374,
      "e": 56037,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58503,
      "e": 56166,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 58566,
      "e": 56229,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 58567,
      "e": 56230,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58695,
      "e": 56358,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 58702,
      "e": 56365,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 58703,
      "e": 56366,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58807,
      "e": 56470,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any do"
    },
    {
      "t": 58814,
      "e": 56477,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 58847,
      "e": 56477,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 58849,
      "e": 56479,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58926,
      "e": 56556,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 59159,
      "e": 56789,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 59159,
      "e": 56789,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59309,
      "e": 56939,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 59967,
      "e": 57597,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 59967,
      "e": 57597,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60029,
      "e": 57659,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 60101,
      "e": 57731,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 60101,
      "e": 57731,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60206,
      "e": 57836,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dot th"
    },
    {
      "t": 60229,
      "e": 57859,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 60238,
      "e": 57868,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 60238,
      "e": 57868,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60374,
      "e": 58004,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 60422,
      "e": 58052,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 60423,
      "e": 58053,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60574,
      "e": 58204,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 60574,
      "e": 58204,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60597,
      "e": 58227,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 60686,
      "e": 58316,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 60694,
      "e": 58324,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 60695,
      "e": 58325,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60807,
      "e": 58437,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dot that i"
    },
    {
      "t": 60838,
      "e": 58468,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 60846,
      "e": 58476,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 60847,
      "e": 58477,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60974,
      "e": 58604,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 61030,
      "e": 58660,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 61031,
      "e": 58661,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61182,
      "e": 58812,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 61408,
      "e": 59038,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 61470,
      "e": 59100,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dot that in"
    },
    {
      "t": 61565,
      "e": 59195,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 61630,
      "e": 59260,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dot that i"
    },
    {
      "t": 61718,
      "e": 59348,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 61798,
      "e": 59428,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dot that "
    },
    {
      "t": 61838,
      "e": 59468,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 61838,
      "e": 59468,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61894,
      "e": 59524,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 62007,
      "e": 59637,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dot that s"
    },
    {
      "t": 62462,
      "e": 60092,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 62566,
      "e": 60196,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dot that "
    },
    {
      "t": 62743,
      "e": 60373,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 62743,
      "e": 60373,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62822,
      "e": 60452,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 62853,
      "e": 60483,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 62854,
      "e": 60484,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62965,
      "e": 60595,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 63071,
      "e": 60701,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 63071,
      "e": 60701,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63206,
      "e": 60702,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dot that is "
    },
    {
      "t": 63229,
      "e": 60725,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 69743,
      "e": 65725,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 70004,
      "e": 65986,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 70241,
      "e": 66223,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 70275,
      "e": 66257,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 70307,
      "e": 66289,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 70340,
      "e": 66322,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 70374,
      "e": 66356,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 70407,
      "e": 66389,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 70439,
      "e": 66421,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 70470,
      "e": 66452,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dot "
    },
    {
      "t": 70606,
      "e": 66588,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dot "
    },
    {
      "t": 70799,
      "e": 66781,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 70885,
      "e": 66867,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dot"
    },
    {
      "t": 70997,
      "e": 66979,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 71070,
      "e": 67052,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any do"
    },
    {
      "t": 71758,
      "e": 67740,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 71759,
      "e": 67741,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71837,
      "e": 67819,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 71902,
      "e": 67884,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 71902,
      "e": 67884,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72006,
      "e": 67988,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dots"
    },
    {
      "t": 72054,
      "e": 68036,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 72055,
      "e": 68037,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72069,
      "e": 68051,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s "
    },
    {
      "t": 72206,
      "e": 68188,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dots "
    },
    {
      "t": 72213,
      "e": 68195,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 72214,
      "e": 68196,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72221,
      "e": 68203,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 72293,
      "e": 68275,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 72407,
      "e": 68389,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dots t"
    },
    {
      "t": 72446,
      "e": 68428,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 72447,
      "e": 68429,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72558,
      "e": 68540,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 72709,
      "e": 68691,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 72709,
      "e": 68691,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72810,
      "e": 68792,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dots tha"
    },
    {
      "t": 72834,
      "e": 68816,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 72834,
      "e": 68816,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72842,
      "e": 68824,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 72922,
      "e": 68904,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 73178,
      "e": 69160,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 73178,
      "e": 69160,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73345,
      "e": 69327,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 74169,
      "e": 70151,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 74169,
      "e": 70151,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74289,
      "e": 70271,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 74346,
      "e": 70328,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 74347,
      "e": 70329,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74466,
      "e": 70330,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 74466,
      "e": 70330,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74537,
      "e": 70401,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||re"
    },
    {
      "t": 74626,
      "e": 70490,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 74627,
      "e": 70491,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74641,
      "e": 70505,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 74745,
      "e": 70609,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 74745,
      "e": 70609,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74785,
      "e": 70649,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 74865,
      "e": 70729,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 74867,
      "e": 70731,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74929,
      "e": 70793,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 75033,
      "e": 70897,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 77818,
      "e": 73682,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 77818,
      "e": 73682,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78002,
      "e": 73866,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 78002,
      "e": 73866,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78025,
      "e": 73889,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 78138,
      "e": 74002,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 78201,
      "e": 74065,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 78202,
      "e": 74066,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78321,
      "e": 74185,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 78322,
      "e": 74186,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78328,
      "e": 74192,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 78513,
      "e": 74377,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 78521,
      "e": 74385,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 78522,
      "e": 74386,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78682,
      "e": 74546,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 78881,
      "e": 74745,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 78882,
      "e": 74746,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78985,
      "e": 74849,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 80008,
      "e": 75872,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 80290,
      "e": 76154,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 80291,
      "e": 76155,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80410,
      "e": 76274,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dots that are on the st"
    },
    {
      "t": 80417,
      "e": 76281,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 80650,
      "e": 76514,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 80650,
      "e": 76514,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80737,
      "e": 76601,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 81522,
      "e": 77386,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 81522,
      "e": 77386,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81649,
      "e": 77513,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 81697,
      "e": 77561,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 81698,
      "e": 77562,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81810,
      "e": 77674,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dots that are on the strai"
    },
    {
      "t": 81825,
      "e": 77689,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 81873,
      "e": 77737,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 81873,
      "e": 77737,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 82010,
      "e": 77874,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dots that are on the straig"
    },
    {
      "t": 82025,
      "e": 77889,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 83578,
      "e": 79442,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 83681,
      "e": 79545,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dots that are on the strai"
    },
    {
      "t": 83826,
      "e": 79690,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 83961,
      "e": 79825,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dots that are on the stra"
    },
    {
      "t": 84202,
      "e": 80066,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 84288,
      "e": 80152,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dots that are on the str"
    },
    {
      "t": 84914,
      "e": 80778,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 84914,
      "e": 80778,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85025,
      "e": 80889,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 85049,
      "e": 80913,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 85049,
      "e": 80913,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85129,
      "e": 80993,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 85162,
      "e": 81026,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 85163,
      "e": 81027,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85248,
      "e": 81112,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 85257,
      "e": 81121,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 85257,
      "e": 81121,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85337,
      "e": 81201,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 85369,
      "e": 81233,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 85370,
      "e": 81234,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85449,
      "e": 81313,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 85649,
      "e": 81513,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 85650,
      "e": 81514,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 85777,
      "e": 81641,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 86913,
      "e": 82777,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 86915,
      "e": 82779,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 87113,
      "e": 82977,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 87114,
      "e": 82978,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 87121,
      "e": 82985,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||li"
    },
    {
      "t": 87249,
      "e": 83113,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 87370,
      "e": 83234,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 87370,
      "e": 83234,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 87530,
      "e": 83394,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 87596,
      "e": 83397,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 87597,
      "e": 83398,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 87673,
      "e": 83474,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 87857,
      "e": 83658,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 87858,
      "e": 83659,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 88000,
      "e": 83801,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 99218,
      "e": 88801,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 99218,
      "e": 88801,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 99361,
      "e": 88944,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 99361,
      "e": 88944,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 99401,
      "e": 88984,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||re"
    },
    {
      "t": 99497,
      "e": 89080,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 99561,
      "e": 89144,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 99562,
      "e": 89145,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 99673,
      "e": 89256,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 99673,
      "e": 89256,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 99688,
      "e": 89271,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||pr"
    },
    {
      "t": 99794,
      "e": 89377,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 99794,
      "e": 89377,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 99848,
      "e": 89431,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 99913,
      "e": 89496,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 100008,
      "e": 89591,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 100065,
      "e": 89648,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 100065,
      "e": 89648,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 100185,
      "e": 89768,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 100233,
      "e": 89816,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 100233,
      "e": 89816,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 100361,
      "e": 89944,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 100425,
      "e": 90008,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 100426,
      "e": 90009,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 100520,
      "e": 90103,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 100544,
      "e": 90127,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 100544,
      "e": 90127,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 100649,
      "e": 90232,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 100664,
      "e": 90247,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 100665,
      "e": 90248,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 100793,
      "e": 90376,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 100793,
      "e": 90376,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 100800,
      "e": 90383,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 100929,
      "e": 90512,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 100945,
      "e": 90528,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 100946,
      "e": 90529,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 101065,
      "e": 90648,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 101273,
      "e": 90856,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 101274,
      "e": 90857,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 101409,
      "e": 90992,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 101832,
      "e": 91415,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 101832,
      "e": 91415,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 101937,
      "e": 91520,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 101993,
      "e": 91576,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 101993,
      "e": 91576,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 102089,
      "e": 91672,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 102121,
      "e": 91704,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 102122,
      "e": 91705,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 102232,
      "e": 91815,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 102248,
      "e": 91831,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 102249,
      "e": 91832,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 102353,
      "e": 91936,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 102369,
      "e": 91952,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 102370,
      "e": 91953,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 102409,
      "e": 91992,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 102601,
      "e": 92184,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 102602,
      "e": 92185,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 102744,
      "e": 92327,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 109418,
      "e": 97327,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 109610,
      "e": 97519,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dots that are on the straight line representing event"
    },
    {
      "t": 109916,
      "e": 97825,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 109948,
      "e": 97857,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 109981,
      "e": 97890,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 110007,
      "e": 97916,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 110014,
      "e": 97923,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 110048,
      "e": 97957,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 110080,
      "e": 97989,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 110114,
      "e": 98023,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 110147,
      "e": 98056,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 110180,
      "e": 98089,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 110212,
      "e": 98121,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 110246,
      "e": 98155,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 110279,
      "e": 98188,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 110312,
      "e": 98221,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 110344,
      "e": 98253,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 110377,
      "e": 98286,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 110410,
      "e": 98319,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 110444,
      "e": 98353,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 110477,
      "e": 98386,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 110510,
      "e": 98419,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 110543,
      "e": 98452,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 110576,
      "e": 98485,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 110609,
      "e": 98518,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 110642,
      "e": 98551,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 110675,
      "e": 98584,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 110707,
      "e": 98616,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 110741,
      "e": 98650,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 110774,
      "e": 98683,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 110807,
      "e": 98716,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 110840,
      "e": 98749,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 110873,
      "e": 98782,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 110906,
      "e": 98815,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 110939,
      "e": 98848,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 110972,
      "e": 98881,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 111005,
      "e": 98914,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 111038,
      "e": 98947,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 111071,
      "e": 98980,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 111104,
      "e": 99013,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 111137,
      "e": 99046,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 111173,
      "e": 99082,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 111203,
      "e": 99112,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 111236,
      "e": 99145,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 111269,
      "e": 99178,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 111301,
      "e": 99210,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 111335,
      "e": 99244,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 111368,
      "e": 99277,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 111400,
      "e": 99309,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 111434,
      "e": 99343,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 111465,
      "e": 99374,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dots t"
    },
    {
      "t": 111611,
      "e": 99520,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dots t"
    },
    {
      "t": 111753,
      "e": 99662,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 111840,
      "e": 99749,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dots "
    },
    {
      "t": 111961,
      "e": 99870,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 112064,
      "e": 99973,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dots"
    },
    {
      "t": 112977,
      "e": 100886,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 112978,
      "e": 100887,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 113120,
      "e": 101029,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 113145,
      "e": 101054,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 113145,
      "e": 101054,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 113377,
      "e": 101286,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 113378,
      "e": 101287,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 113400,
      "e": 101309,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| r"
    },
    {
      "t": 113536,
      "e": 101445,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 113537,
      "e": 101446,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 113569,
      "e": 101478,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 113689,
      "e": 101598,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 113849,
      "e": 101758,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 113850,
      "e": 101759,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 113993,
      "e": 101902,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 114009,
      "e": 101918,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 114009,
      "e": 101918,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 114209,
      "e": 102118,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 114210,
      "e": 102119,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 114264,
      "e": 102173,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||re"
    },
    {
      "t": 114329,
      "e": 102238,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 114481,
      "e": 102390,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 114482,
      "e": 102391,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 114610,
      "e": 102519,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dots, repres"
    },
    {
      "t": 114616,
      "e": 102519,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 114648,
      "e": 102551,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 114648,
      "e": 102551,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 114792,
      "e": 102695,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 114808,
      "e": 102711,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 114808,
      "e": 102711,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 114928,
      "e": 102831,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 114953,
      "e": 102856,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 114953,
      "e": 102856,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 115056,
      "e": 102959,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 115056,
      "e": 102959,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 115064,
      "e": 102967,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ti"
    },
    {
      "t": 115193,
      "e": 103096,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 115193,
      "e": 103096,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 115201,
      "e": 103104,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 115305,
      "e": 103208,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 115305,
      "e": 103208,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 115336,
      "e": 103239,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 115416,
      "e": 103319,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 115417,
      "e": 103320,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 115448,
      "e": 103351,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 115585,
      "e": 103488,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 115586,
      "e": 103489,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 115624,
      "e": 103527,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 115753,
      "e": 103656,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 115929,
      "e": 103832,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 115930,
      "e": 103833,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 116065,
      "e": 103968,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 116153,
      "e": 104056,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 116154,
      "e": 104057,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 116249,
      "e": 104152,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 116593,
      "e": 104496,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 116665,
      "e": 104568,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dots, representing th"
    },
    {
      "t": 116753,
      "e": 104656,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 116825,
      "e": 104728,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dots, representing t"
    },
    {
      "t": 117225,
      "e": 105128,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 117312,
      "e": 105215,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dots, representing "
    },
    {
      "t": 117569,
      "e": 105472,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 117571,
      "e": 105474,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 117632,
      "e": 105535,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 117633,
      "e": 105536,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 117648,
      "e": 105551,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ev"
    },
    {
      "t": 117728,
      "e": 105631,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 117800,
      "e": 105703,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 117801,
      "e": 105704,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 117896,
      "e": 105799,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 117897,
      "e": 105800,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 117897,
      "e": 105800,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 118001,
      "e": 105904,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 118025,
      "e": 105928,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 118025,
      "e": 105928,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 118120,
      "e": 106023,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 118377,
      "e": 106280,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 118377,
      "e": 106280,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 118504,
      "e": 106407,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 119698,
      "e": 107601,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 119698,
      "e": 107601,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 119792,
      "e": 107695,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 120008,
      "e": 107911,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 120545,
      "e": 108448,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 120546,
      "e": 108449,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 120680,
      "e": 108583,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 124530,
      "e": 112433,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 124632,
      "e": 112535,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dots, representing events,"
    },
    {
      "t": 124816,
      "e": 112719,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 124929,
      "e": 112832,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dots, representing events"
    },
    {
      "t": 125689,
      "e": 113592,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 125689,
      "e": 113592,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 125809,
      "e": 113712,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dots, representing events."
    },
    {
      "t": 125816,
      "e": 113719,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 125905,
      "e": 113808,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 125905,
      "e": 113808,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 126010,
      "e": 113913,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dots, representing events. "
    },
    {
      "t": 126033,
      "e": 113936,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 130008,
      "e": 117911,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 134911,
      "e": 118936,
      "ty": 2,
      "x": 160,
      "y": 589
    },
    {
      "t": 134943,
      "e": 118968,
      "ty": 7,
      "x": 64,
      "y": 582,
      "ta": "#strategyAnswer"
    },
    {
      "t": 135011,
      "e": 119036,
      "ty": 2,
      "x": 42,
      "y": 579
    },
    {
      "t": 135011,
      "e": 119036,
      "ty": 41,
      "x": 1170,
      "y": 31631,
      "ta": "> div.stimulus"
    },
    {
      "t": 135111,
      "e": 119136,
      "ty": 2,
      "x": 38,
      "y": 582
    },
    {
      "t": 135195,
      "e": 119220,
      "ty": 6,
      "x": 109,
      "y": 557,
      "ta": "#strategyAnswer"
    },
    {
      "t": 135211,
      "e": 119236,
      "ty": 2,
      "x": 131,
      "y": 550
    },
    {
      "t": 135261,
      "e": 119286,
      "ty": 41,
      "x": 7296,
      "y": 14778,
      "ta": "#strategyAnswer"
    },
    {
      "t": 135311,
      "e": 119336,
      "ty": 2,
      "x": 167,
      "y": 537
    },
    {
      "t": 135410,
      "e": 119435,
      "ty": 2,
      "x": 169,
      "y": 537
    },
    {
      "t": 135511,
      "e": 119536,
      "ty": 2,
      "x": 159,
      "y": 556
    },
    {
      "t": 135511,
      "e": 119536,
      "ty": 41,
      "x": 6958,
      "y": 26914,
      "ta": "#strategyAnswer"
    },
    {
      "t": 135610,
      "e": 119635,
      "ty": 2,
      "x": 154,
      "y": 557
    },
    {
      "t": 135711,
      "e": 119736,
      "ty": 2,
      "x": 147,
      "y": 556
    },
    {
      "t": 135761,
      "e": 119786,
      "ty": 41,
      "x": 5497,
      "y": 26105,
      "ta": "#strategyAnswer"
    },
    {
      "t": 135810,
      "e": 119835,
      "ty": 2,
      "x": 146,
      "y": 555
    },
    {
      "t": 135896,
      "e": 119921,
      "ty": 3,
      "x": 146,
      "y": 555,
      "ta": "#strategyAnswer"
    },
    {
      "t": 135976,
      "e": 120001,
      "ty": 4,
      "x": 5497,
      "y": 26105,
      "ta": "#strategyAnswer"
    },
    {
      "t": 135976,
      "e": 120001,
      "ty": 5,
      "x": 146,
      "y": 555,
      "ta": "#strategyAnswer"
    },
    {
      "t": 136110,
      "e": 120135,
      "ty": 2,
      "x": 150,
      "y": 555
    },
    {
      "t": 136211,
      "e": 120236,
      "ty": 2,
      "x": 569,
      "y": 555
    },
    {
      "t": 136261,
      "e": 120286,
      "ty": 41,
      "x": 54058,
      "y": 25296,
      "ta": "#strategyAnswer"
    },
    {
      "t": 136311,
      "e": 120336,
      "ty": 2,
      "x": 578,
      "y": 554
    },
    {
      "t": 136828,
      "e": 120853,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 136908,
      "e": 120933,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dots,representing events. "
    },
    {
      "t": 137012,
      "e": 121037,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 137108,
      "e": 121133,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dotsrepresenting events. "
    },
    {
      "t": 137444,
      "e": 121469,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 137445,
      "e": 121470,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 137572,
      "e": 121597,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dots representing events. "
    },
    {
      "t": 137716,
      "e": 121741,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 137716,
      "e": 121741,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 137795,
      "e": 121820,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dots trepresenting events. "
    },
    {
      "t": 137924,
      "e": 121949,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 137924,
      "e": 121949,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 137932,
      "e": 121957,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 137932,
      "e": 121957,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 138027,
      "e": 122052,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dots tahrepresenting events. "
    },
    {
      "t": 138059,
      "e": 122084,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 138220,
      "e": 122245,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 138226,
      "e": 122251,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 138300,
      "e": 122325,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dots tahtrepresenting events. "
    },
    {
      "t": 138415,
      "e": 122326,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dots tahtrepresenting events. "
    },
    {
      "t": 138693,
      "e": 122604,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 138771,
      "e": 122682,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dots tahrepresenting events. "
    },
    {
      "t": 138867,
      "e": 122778,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 138940,
      "e": 122851,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dots tarepresenting events. "
    },
    {
      "t": 139028,
      "e": 122939,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 139108,
      "e": 123019,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dots trepresenting events. "
    },
    {
      "t": 139214,
      "e": 123125,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dots trepresenting events. "
    },
    {
      "t": 139333,
      "e": 123244,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 139333,
      "e": 123244,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 139420,
      "e": 123331,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dots threpresenting events. "
    },
    {
      "t": 139452,
      "e": 123363,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 139453,
      "e": 123364,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 139564,
      "e": 123475,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dots tharepresenting events. "
    },
    {
      "t": 139564,
      "e": 123475,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 139564,
      "e": 123475,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 139620,
      "e": 123531,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dots thatrepresenting events. "
    },
    {
      "t": 139700,
      "e": 123611,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 139701,
      "e": 123612,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 139812,
      "e": 123613,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dots that representing events. "
    },
    {
      "t": 140211,
      "e": 124012,
      "ty": 2,
      "x": 484,
      "y": 523
    },
    {
      "t": 140215,
      "e": 124016,
      "ty": 7,
      "x": 324,
      "y": 486,
      "ta": "#strategyAnswer"
    },
    {
      "t": 140261,
      "e": 124062,
      "ty": 41,
      "x": 13253,
      "y": 2154,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 140311,
      "e": 124112,
      "ty": 2,
      "x": 202,
      "y": 492
    },
    {
      "t": 140399,
      "e": 124200,
      "ty": 6,
      "x": 184,
      "y": 534,
      "ta": "#strategyAnswer"
    },
    {
      "t": 140411,
      "e": 124212,
      "ty": 2,
      "x": 184,
      "y": 534
    },
    {
      "t": 140511,
      "e": 124312,
      "ty": 2,
      "x": 205,
      "y": 577
    },
    {
      "t": 140512,
      "e": 124313,
      "ty": 41,
      "x": 12129,
      "y": 43904,
      "ta": "#strategyAnswer"
    },
    {
      "t": 140611,
      "e": 124412,
      "ty": 2,
      "x": 224,
      "y": 573
    },
    {
      "t": 140711,
      "e": 124512,
      "ty": 2,
      "x": 255,
      "y": 561
    },
    {
      "t": 140761,
      "e": 124562,
      "ty": 41,
      "x": 18537,
      "y": 28532,
      "ta": "#strategyAnswer"
    },
    {
      "t": 140810,
      "e": 124611,
      "ty": 2,
      "x": 268,
      "y": 558
    },
    {
      "t": 140910,
      "e": 124711,
      "ty": 2,
      "x": 273,
      "y": 558
    },
    {
      "t": 141011,
      "e": 124812,
      "ty": 2,
      "x": 273,
      "y": 557
    },
    {
      "t": 141011,
      "e": 124812,
      "ty": 41,
      "x": 19773,
      "y": 27723,
      "ta": "#strategyAnswer"
    },
    {
      "t": 141111,
      "e": 124912,
      "ty": 2,
      "x": 265,
      "y": 554
    },
    {
      "t": 141261,
      "e": 125062,
      "ty": 41,
      "x": 18649,
      "y": 25296,
      "ta": "#strategyAnswer"
    },
    {
      "t": 141311,
      "e": 125112,
      "ty": 2,
      "x": 263,
      "y": 554
    },
    {
      "t": 141441,
      "e": 125242,
      "ty": 3,
      "x": 263,
      "y": 554,
      "ta": "#strategyAnswer"
    },
    {
      "t": 141527,
      "e": 125328,
      "ty": 4,
      "x": 18649,
      "y": 25296,
      "ta": "#strategyAnswer"
    },
    {
      "t": 141527,
      "e": 125328,
      "ty": 5,
      "x": 263,
      "y": 554,
      "ta": "#strategyAnswer"
    },
    {
      "t": 142412,
      "e": 126213,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 142491,
      "e": 126292,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dots that representin events. "
    },
    {
      "t": 142611,
      "e": 126412,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 142691,
      "e": 126492,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dots that representi events. "
    },
    {
      "t": 143124,
      "e": 126925,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 143212,
      "e": 127013,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dots that represent events. "
    },
    {
      "t": 144111,
      "e": 127912,
      "ty": 2,
      "x": 266,
      "y": 556
    },
    {
      "t": 144211,
      "e": 128012,
      "ty": 2,
      "x": 306,
      "y": 595
    },
    {
      "t": 144252,
      "e": 128053,
      "ty": 7,
      "x": 316,
      "y": 604,
      "ta": "#strategyAnswer"
    },
    {
      "t": 144262,
      "e": 128063,
      "ty": 41,
      "x": 24607,
      "y": 61202,
      "ta": "#.strategy"
    },
    {
      "t": 144310,
      "e": 128111,
      "ty": 2,
      "x": 330,
      "y": 618
    },
    {
      "t": 144352,
      "e": 128153,
      "ty": 6,
      "x": 361,
      "y": 662,
      "ta": "#strategyButton"
    },
    {
      "t": 144411,
      "e": 128212,
      "ty": 2,
      "x": 394,
      "y": 688
    },
    {
      "t": 144511,
      "e": 128312,
      "ty": 2,
      "x": 395,
      "y": 688
    },
    {
      "t": 144511,
      "e": 128312,
      "ty": 41,
      "x": 30804,
      "y": 64119,
      "ta": "#strategyButton"
    },
    {
      "t": 144612,
      "e": 128413,
      "ty": 2,
      "x": 395,
      "y": 669
    },
    {
      "t": 144711,
      "e": 128512,
      "ty": 2,
      "x": 395,
      "y": 668
    },
    {
      "t": 144761,
      "e": 128562,
      "ty": 41,
      "x": 30804,
      "y": 25569,
      "ta": "#strategyButton"
    },
    {
      "t": 145113,
      "e": 128914,
      "ty": 3,
      "x": 395,
      "y": 668,
      "ta": "#strategyButton"
    },
    {
      "t": 145114,
      "e": 128915,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "First find 12pm on the x-axis and then go up from the 12pm point and find any dots that represent events. "
    },
    {
      "t": 145116,
      "e": 128917,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 145117,
      "e": 128918,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 145207,
      "e": 129008,
      "ty": 4,
      "x": 30804,
      "y": 25569,
      "ta": "#strategyButton"
    },
    {
      "t": 145217,
      "e": 129018,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 145218,
      "e": 129019,
      "ty": 5,
      "x": 395,
      "y": 668,
      "ta": "#strategyButton"
    },
    {
      "t": 145227,
      "e": 129028,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 146227,
      "e": 130028,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 147012,
      "e": 130813,
      "ty": 2,
      "x": 403,
      "y": 668
    },
    {
      "t": 147012,
      "e": 130813,
      "ty": 41,
      "x": 13602,
      "y": 36562,
      "ta": "html > body"
    },
    {
      "t": 147111,
      "e": 130912,
      "ty": 2,
      "x": 881,
      "y": 608
    },
    {
      "t": 147211,
      "e": 131012,
      "ty": 2,
      "x": 904,
      "y": 592
    },
    {
      "t": 147261,
      "e": 131062,
      "ty": 41,
      "x": 23359,
      "y": 59897,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 147272,
      "e": 131063,
      "ty": 6,
      "x": 919,
      "y": 572,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 147311,
      "e": 131102,
      "ty": 2,
      "x": 922,
      "y": 568
    },
    {
      "t": 147416,
      "e": 131207,
      "ty": 3,
      "x": 922,
      "y": 568,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 147416,
      "e": 131207,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 147512,
      "e": 131303,
      "ty": 41,
      "x": 24656,
      "y": 43690,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 147528,
      "e": 131319,
      "ty": 4,
      "x": 24656,
      "y": 43690,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 147528,
      "e": 131319,
      "ty": 5,
      "x": 922,
      "y": 568,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 148380,
      "e": 132171,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 148381,
      "e": 132172,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 148476,
      "e": 132267,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 148508,
      "e": 132299,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "57"
    },
    {
      "t": 148508,
      "e": 132299,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 148579,
      "e": 132370,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 149261,
      "e": 133052,
      "ty": 41,
      "x": 25521,
      "y": 56172,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 149272,
      "e": 133063,
      "ty": 7,
      "x": 927,
      "y": 582,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 149312,
      "e": 133103,
      "ty": 2,
      "x": 932,
      "y": 600
    },
    {
      "t": 149411,
      "e": 133202,
      "ty": 2,
      "x": 950,
      "y": 625
    },
    {
      "t": 149511,
      "e": 133302,
      "ty": 2,
      "x": 955,
      "y": 634
    },
    {
      "t": 149511,
      "e": 133302,
      "ty": 41,
      "x": 31794,
      "y": 35938,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 149611,
      "e": 133402,
      "ty": 2,
      "x": 962,
      "y": 640
    },
    {
      "t": 149711,
      "e": 133502,
      "ty": 2,
      "x": 965,
      "y": 645
    },
    {
      "t": 149740,
      "e": 133531,
      "ty": 6,
      "x": 966,
      "y": 648,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 149762,
      "e": 133553,
      "ty": 41,
      "x": 34389,
      "y": 6241,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 149812,
      "e": 133603,
      "ty": 2,
      "x": 967,
      "y": 649
    },
    {
      "t": 149985,
      "e": 133776,
      "ty": 3,
      "x": 967,
      "y": 649,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 149986,
      "e": 133777,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 149987,
      "e": 133778,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 149987,
      "e": 133778,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 150080,
      "e": 133871,
      "ty": 4,
      "x": 34389,
      "y": 6241,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 150080,
      "e": 133871,
      "ty": 5,
      "x": 967,
      "y": 649,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 150312,
      "e": 134103,
      "ty": 2,
      "x": 970,
      "y": 651
    },
    {
      "t": 150411,
      "e": 134202,
      "ty": 2,
      "x": 971,
      "y": 652
    },
    {
      "t": 150512,
      "e": 134303,
      "ty": 41,
      "x": 35254,
      "y": 15603,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 150796,
      "e": 134587,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 150931,
      "e": 134722,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 151027,
      "e": 134818,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "67"
    },
    {
      "t": 151027,
      "e": 134818,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 151180,
      "e": 134971,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 151252,
      "e": 135043,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "72"
    },
    {
      "t": 151252,
      "e": 135043,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 151308,
      "e": 135099,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Ch"
    },
    {
      "t": 151323,
      "e": 135114,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 151324,
      "e": 135115,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 151347,
      "e": 135138,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Chi"
    },
    {
      "t": 151347,
      "e": 135138,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Chi"
    },
    {
      "t": 151451,
      "e": 135242,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 151452,
      "e": 135243,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 151491,
      "e": 135282,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Chin"
    },
    {
      "t": 151580,
      "e": 135371,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 151596,
      "e": 135387,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 151596,
      "e": 135387,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 151732,
      "e": 135523,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 152212,
      "e": 136003,
      "ty": 2,
      "x": 972,
      "y": 660
    },
    {
      "t": 152224,
      "e": 136015,
      "ty": 7,
      "x": 975,
      "y": 682,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 152226,
      "e": 136017,
      "ty": 6,
      "x": 975,
      "y": 682,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 152262,
      "e": 136053,
      "ty": 41,
      "x": 41786,
      "y": 39718,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 152311,
      "e": 136102,
      "ty": 2,
      "x": 977,
      "y": 696
    },
    {
      "t": 152448,
      "e": 136239,
      "ty": 3,
      "x": 977,
      "y": 696,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 152449,
      "e": 136240,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "China"
    },
    {
      "t": 152450,
      "e": 136241,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 152450,
      "e": 136241,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 152527,
      "e": 136318,
      "ty": 4,
      "x": 41786,
      "y": 39718,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 152528,
      "e": 136319,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 152528,
      "e": 136319,
      "ty": 5,
      "x": 977,
      "y": 696,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 152528,
      "e": 136319,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 153540,
      "e": 137331,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 154612,
      "e": 138403,
      "ty": 2,
      "x": 789,
      "y": 366
    },
    {
      "t": 154712,
      "e": 138503,
      "ty": 2,
      "x": 779,
      "y": 321
    },
    {
      "t": 154762,
      "e": 138553,
      "ty": 41,
      "x": 26448,
      "y": 16563,
      "ta": "html > body"
    },
    {
      "t": 154811,
      "e": 138602,
      "ty": 2,
      "x": 775,
      "y": 299
    },
    {
      "t": 154911,
      "e": 138702,
      "ty": 2,
      "x": 779,
      "y": 288
    },
    {
      "t": 155012,
      "e": 138803,
      "ty": 2,
      "x": 814,
      "y": 276
    },
    {
      "t": 155012,
      "e": 138803,
      "ty": 41,
      "x": 27756,
      "y": 14846,
      "ta": "html > body"
    },
    {
      "t": 155111,
      "e": 138902,
      "ty": 2,
      "x": 820,
      "y": 272
    },
    {
      "t": 155210,
      "e": 139001,
      "ty": 2,
      "x": 822,
      "y": 247
    },
    {
      "t": 155262,
      "e": 139053,
      "ty": 41,
      "x": 473,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 155312,
      "e": 139103,
      "ty": 2,
      "x": 822,
      "y": 246
    },
    {
      "t": 155411,
      "e": 139202,
      "ty": 2,
      "x": 825,
      "y": 246
    },
    {
      "t": 155512,
      "e": 139303,
      "ty": 2,
      "x": 826,
      "y": 249
    },
    {
      "t": 155512,
      "e": 139303,
      "ty": 41,
      "x": 1086,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 155611,
      "e": 139402,
      "ty": 2,
      "x": 828,
      "y": 250
    },
    {
      "t": 155680,
      "e": 139471,
      "ty": 6,
      "x": 832,
      "y": 244,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 155711,
      "e": 139502,
      "ty": 2,
      "x": 832,
      "y": 244
    },
    {
      "t": 155762,
      "e": 139553,
      "ty": 41,
      "x": 33161,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 155812,
      "e": 139603,
      "ty": 2,
      "x": 833,
      "y": 244
    },
    {
      "t": 155897,
      "e": 139688,
      "ty": 7,
      "x": 833,
      "y": 245,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 155911,
      "e": 139702,
      "ty": 2,
      "x": 833,
      "y": 246
    },
    {
      "t": 156011,
      "e": 139802,
      "ty": 2,
      "x": 833,
      "y": 254
    },
    {
      "t": 156011,
      "e": 139802,
      "ty": 41,
      "x": 2747,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-0-1"
    },
    {
      "t": 156062,
      "e": 139802,
      "ty": 6,
      "x": 832,
      "y": 260,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 156094,
      "e": 139834,
      "ty": 7,
      "x": 828,
      "y": 281,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 156111,
      "e": 139851,
      "ty": 6,
      "x": 827,
      "y": 297,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 156111,
      "e": 139851,
      "ty": 2,
      "x": 827,
      "y": 297
    },
    {
      "t": 156127,
      "e": 139867,
      "ty": 7,
      "x": 827,
      "y": 308,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 156161,
      "e": 139901,
      "ty": 6,
      "x": 827,
      "y": 317,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 156211,
      "e": 139951,
      "ty": 2,
      "x": 827,
      "y": 320
    },
    {
      "t": 156261,
      "e": 140001,
      "ty": 41,
      "x": 7955,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 156312,
      "e": 140052,
      "ty": 2,
      "x": 830,
      "y": 325
    },
    {
      "t": 156411,
      "e": 140151,
      "ty": 2,
      "x": 831,
      "y": 325
    },
    {
      "t": 156511,
      "e": 140251,
      "ty": 2,
      "x": 835,
      "y": 320
    },
    {
      "t": 156511,
      "e": 140251,
      "ty": 41,
      "x": 43243,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 156560,
      "e": 140300,
      "ty": 7,
      "x": 837,
      "y": 314,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 156611,
      "e": 140351,
      "ty": 2,
      "x": 837,
      "y": 309
    },
    {
      "t": 156711,
      "e": 140451,
      "ty": 2,
      "x": 837,
      "y": 302
    },
    {
      "t": 156762,
      "e": 140502,
      "ty": 41,
      "x": 4882,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 156951,
      "e": 140691,
      "ty": 6,
      "x": 837,
      "y": 300,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 157012,
      "e": 140752,
      "ty": 2,
      "x": 837,
      "y": 299
    },
    {
      "t": 157012,
      "e": 140752,
      "ty": 41,
      "x": 53325,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 157112,
      "e": 140852,
      "ty": 2,
      "x": 836,
      "y": 297
    },
    {
      "t": 157211,
      "e": 140951,
      "ty": 2,
      "x": 833,
      "y": 293
    },
    {
      "t": 157262,
      "e": 141002,
      "ty": 41,
      "x": 33161,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 157280,
      "e": 141020,
      "ty": 3,
      "x": 833,
      "y": 293,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 157282,
      "e": 141022,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 157359,
      "e": 141099,
      "ty": 4,
      "x": 33161,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 157360,
      "e": 141100,
      "ty": 5,
      "x": 833,
      "y": 293,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 157360,
      "e": 141100,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf",
      "v": "Mandarin or Cantonese"
    },
    {
      "t": 158080,
      "e": 141820,
      "ty": 7,
      "x": 832,
      "y": 302,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 158111,
      "e": 141851,
      "ty": 2,
      "x": 831,
      "y": 309
    },
    {
      "t": 158112,
      "e": 141852,
      "ty": 6,
      "x": 831,
      "y": 318,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 158129,
      "e": 141869,
      "ty": 7,
      "x": 831,
      "y": 331,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 158212,
      "e": 141952,
      "ty": 2,
      "x": 839,
      "y": 381
    },
    {
      "t": 158262,
      "e": 142002,
      "ty": 41,
      "x": 4883,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 158311,
      "e": 142051,
      "ty": 2,
      "x": 845,
      "y": 438
    },
    {
      "t": 158412,
      "e": 142152,
      "ty": 2,
      "x": 846,
      "y": 460
    },
    {
      "t": 158512,
      "e": 142252,
      "ty": 41,
      "x": 5832,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 158562,
      "e": 142302,
      "ty": 6,
      "x": 838,
      "y": 447,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 158612,
      "e": 142352,
      "ty": 2,
      "x": 838,
      "y": 442
    },
    {
      "t": 158671,
      "e": 142411,
      "ty": 7,
      "x": 837,
      "y": 435,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 158711,
      "e": 142451,
      "ty": 2,
      "x": 837,
      "y": 434
    },
    {
      "t": 158762,
      "e": 142502,
      "ty": 41,
      "x": 3697,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 158811,
      "e": 142551,
      "ty": 2,
      "x": 837,
      "y": 429
    },
    {
      "t": 158911,
      "e": 142651,
      "ty": 2,
      "x": 837,
      "y": 421
    },
    {
      "t": 158929,
      "e": 142669,
      "ty": 6,
      "x": 837,
      "y": 420,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 159012,
      "e": 142752,
      "ty": 2,
      "x": 838,
      "y": 417
    },
    {
      "t": 159012,
      "e": 142752,
      "ty": 41,
      "x": 58367,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 159112,
      "e": 142852,
      "ty": 2,
      "x": 838,
      "y": 415
    },
    {
      "t": 159212,
      "e": 142952,
      "ty": 2,
      "x": 838,
      "y": 413
    },
    {
      "t": 159262,
      "e": 143002,
      "ty": 41,
      "x": 58367,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 159409,
      "e": 143149,
      "ty": 3,
      "x": 838,
      "y": 412,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 159410,
      "e": 143150,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 159411,
      "e": 143151,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 159413,
      "e": 143153,
      "ty": 2,
      "x": 838,
      "y": 412
    },
    {
      "t": 159495,
      "e": 143235,
      "ty": 4,
      "x": 58367,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 159496,
      "e": 143236,
      "ty": 5,
      "x": 838,
      "y": 412,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 159496,
      "e": 143236,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf",
      "v": "First"
    },
    {
      "t": 159512,
      "e": 143236,
      "ty": 41,
      "x": 58367,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 160198,
      "e": 143922,
      "ty": 7,
      "x": 838,
      "y": 422,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 160211,
      "e": 143935,
      "ty": 2,
      "x": 838,
      "y": 422
    },
    {
      "t": 160232,
      "e": 143956,
      "ty": 6,
      "x": 838,
      "y": 436,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 160261,
      "e": 143985,
      "ty": 41,
      "x": 58367,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 160264,
      "e": 143988,
      "ty": 7,
      "x": 838,
      "y": 458,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 160281,
      "e": 144005,
      "ty": 6,
      "x": 838,
      "y": 472,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 160298,
      "e": 144022,
      "ty": 7,
      "x": 840,
      "y": 487,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 160312,
      "e": 144036,
      "ty": 2,
      "x": 840,
      "y": 487
    },
    {
      "t": 160411,
      "e": 144135,
      "ty": 2,
      "x": 862,
      "y": 579
    },
    {
      "t": 160512,
      "e": 144236,
      "ty": 2,
      "x": 883,
      "y": 697
    },
    {
      "t": 160512,
      "e": 144236,
      "ty": 41,
      "x": 15516,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 160610,
      "e": 144334,
      "ty": 2,
      "x": 883,
      "y": 713
    },
    {
      "t": 160711,
      "e": 144435,
      "ty": 2,
      "x": 877,
      "y": 726
    },
    {
      "t": 160761,
      "e": 144485,
      "ty": 41,
      "x": 12443,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 160811,
      "e": 144535,
      "ty": 2,
      "x": 868,
      "y": 729
    },
    {
      "t": 160911,
      "e": 144635,
      "ty": 2,
      "x": 862,
      "y": 729
    },
    {
      "t": 161011,
      "e": 144735,
      "ty": 2,
      "x": 857,
      "y": 723
    },
    {
      "t": 161012,
      "e": 144736,
      "ty": 41,
      "x": 8929,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 161111,
      "e": 144835,
      "ty": 2,
      "x": 853,
      "y": 714
    },
    {
      "t": 161210,
      "e": 144934,
      "ty": 2,
      "x": 850,
      "y": 711
    },
    {
      "t": 161262,
      "e": 144986,
      "ty": 41,
      "x": 7201,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 161410,
      "e": 145134,
      "ty": 2,
      "x": 847,
      "y": 751
    },
    {
      "t": 161511,
      "e": 145235,
      "ty": 2,
      "x": 842,
      "y": 811
    },
    {
      "t": 161511,
      "e": 145235,
      "ty": 41,
      "x": 12146,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 161565,
      "e": 145289,
      "ty": 6,
      "x": 839,
      "y": 837,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 161610,
      "e": 145334,
      "ty": 2,
      "x": 838,
      "y": 840
    },
    {
      "t": 161681,
      "e": 145405,
      "ty": 7,
      "x": 835,
      "y": 851,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 161711,
      "e": 145435,
      "ty": 2,
      "x": 835,
      "y": 851
    },
    {
      "t": 161761,
      "e": 145485,
      "ty": 41,
      "x": 9566,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 161865,
      "e": 145589,
      "ty": 6,
      "x": 835,
      "y": 846,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 161911,
      "e": 145635,
      "ty": 2,
      "x": 835,
      "y": 843
    },
    {
      "t": 162011,
      "e": 145735,
      "ty": 2,
      "x": 835,
      "y": 840
    },
    {
      "t": 162011,
      "e": 145735,
      "ty": 41,
      "x": 43243,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 162111,
      "e": 145835,
      "ty": 2,
      "x": 835,
      "y": 839
    },
    {
      "t": 162210,
      "e": 145934,
      "ty": 2,
      "x": 833,
      "y": 839
    },
    {
      "t": 162261,
      "e": 145985,
      "ty": 41,
      "x": 33161,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 162311,
      "e": 146035,
      "ty": 2,
      "x": 832,
      "y": 838
    },
    {
      "t": 162511,
      "e": 146235,
      "ty": 41,
      "x": 28120,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 164176,
      "e": 147900,
      "ty": 7,
      "x": 832,
      "y": 830,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 164192,
      "e": 147916,
      "ty": 6,
      "x": 832,
      "y": 808,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 164200,
      "e": 147924,
      "ty": 7,
      "x": 832,
      "y": 793,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 164211,
      "e": 147935,
      "ty": 2,
      "x": 832,
      "y": 793
    },
    {
      "t": 164250,
      "e": 147974,
      "ty": 6,
      "x": 832,
      "y": 724,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 164261,
      "e": 147985,
      "ty": 41,
      "x": 28120,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 164267,
      "e": 147991,
      "ty": 7,
      "x": 832,
      "y": 714,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 164311,
      "e": 148035,
      "ty": 2,
      "x": 832,
      "y": 709
    },
    {
      "t": 164317,
      "e": 148035,
      "ty": 6,
      "x": 832,
      "y": 707,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 164411,
      "e": 148129,
      "ty": 2,
      "x": 830,
      "y": 703
    },
    {
      "t": 164511,
      "e": 148229,
      "ty": 41,
      "x": 18037,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 164611,
      "e": 148329,
      "ty": 2,
      "x": 830,
      "y": 701
    },
    {
      "t": 164761,
      "e": 148479,
      "ty": 41,
      "x": 18037,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 164768,
      "e": 148486,
      "ty": 3,
      "x": 830,
      "y": 701,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 164770,
      "e": 148488,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 164771,
      "e": 148489,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 164823,
      "e": 148541,
      "ty": 4,
      "x": 18037,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 164823,
      "e": 148541,
      "ty": 5,
      "x": 830,
      "y": 701,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 164823,
      "e": 148541,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 164984,
      "e": 148702,
      "ty": 7,
      "x": 834,
      "y": 737,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 165011,
      "e": 148729,
      "ty": 2,
      "x": 841,
      "y": 783
    },
    {
      "t": 165011,
      "e": 148729,
      "ty": 41,
      "x": 10960,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 165111,
      "e": 148829,
      "ty": 2,
      "x": 842,
      "y": 885
    },
    {
      "t": 165211,
      "e": 148929,
      "ty": 2,
      "x": 836,
      "y": 905
    },
    {
      "t": 165261,
      "e": 148979,
      "ty": 41,
      "x": 2747,
      "y": 18148,
      "ta": "#jspsych-survey-multi-choice-3"
    },
    {
      "t": 165311,
      "e": 149029,
      "ty": 2,
      "x": 832,
      "y": 923
    },
    {
      "t": 165352,
      "e": 149070,
      "ty": 6,
      "x": 832,
      "y": 928,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 165411,
      "e": 149129,
      "ty": 2,
      "x": 832,
      "y": 929
    },
    {
      "t": 165511,
      "e": 149229,
      "ty": 41,
      "x": 28120,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 165665,
      "e": 149383,
      "ty": 7,
      "x": 832,
      "y": 927,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 165710,
      "e": 149428,
      "ty": 2,
      "x": 832,
      "y": 912
    },
    {
      "t": 165761,
      "e": 149479,
      "ty": 41,
      "x": 2747,
      "y": 25745,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 165811,
      "e": 149529,
      "ty": 2,
      "x": 833,
      "y": 877
    },
    {
      "t": 166011,
      "e": 149729,
      "ty": 2,
      "x": 827,
      "y": 908
    },
    {
      "t": 166011,
      "e": 149729,
      "ty": 41,
      "x": 1323,
      "y": 16635,
      "ta": "#jspsych-survey-multi-choice-3"
    },
    {
      "t": 166110,
      "e": 149828,
      "ty": 2,
      "x": 821,
      "y": 926
    },
    {
      "t": 166211,
      "e": 149929,
      "ty": 2,
      "x": 820,
      "y": 934
    },
    {
      "t": 166261,
      "e": 149979,
      "ty": 41,
      "x": 27963,
      "y": 51297,
      "ta": "html > body"
    },
    {
      "t": 166311,
      "e": 150029,
      "ty": 2,
      "x": 821,
      "y": 931
    },
    {
      "t": 166411,
      "e": 150129,
      "ty": 2,
      "x": 828,
      "y": 927
    },
    {
      "t": 166456,
      "e": 150174,
      "ty": 6,
      "x": 830,
      "y": 928,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 166511,
      "e": 150229,
      "ty": 2,
      "x": 831,
      "y": 931
    },
    {
      "t": 166511,
      "e": 150229,
      "ty": 41,
      "x": 23079,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 166586,
      "e": 150304,
      "ty": 7,
      "x": 835,
      "y": 943,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 166611,
      "e": 150329,
      "ty": 2,
      "x": 836,
      "y": 949
    },
    {
      "t": 166619,
      "e": 150337,
      "ty": 6,
      "x": 838,
      "y": 957,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 166711,
      "e": 150429,
      "ty": 2,
      "x": 838,
      "y": 961
    },
    {
      "t": 166761,
      "e": 150479,
      "ty": 41,
      "x": 58367,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 166812,
      "e": 150530,
      "ty": 2,
      "x": 838,
      "y": 962
    },
    {
      "t": 166911,
      "e": 150629,
      "ty": 2,
      "x": 833,
      "y": 961
    },
    {
      "t": 167008,
      "e": 150726,
      "ty": 3,
      "x": 833,
      "y": 961,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 167009,
      "e": 150727,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 167010,
      "e": 150728,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 167013,
      "e": 150731,
      "ty": 41,
      "x": 33161,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 167087,
      "e": 150805,
      "ty": 4,
      "x": 33161,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 167088,
      "e": 150806,
      "ty": 5,
      "x": 833,
      "y": 961,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 167088,
      "e": 150806,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 167143,
      "e": 150861,
      "ty": 7,
      "x": 840,
      "y": 963,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 167211,
      "e": 150929,
      "ty": 2,
      "x": 910,
      "y": 991
    },
    {
      "t": 167237,
      "e": 150955,
      "ty": 6,
      "x": 928,
      "y": 1007,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 167261,
      "e": 150979,
      "ty": 41,
      "x": 50806,
      "y": 7943,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 167311,
      "e": 151029,
      "ty": 2,
      "x": 928,
      "y": 1012
    },
    {
      "t": 167411,
      "e": 151129,
      "ty": 2,
      "x": 927,
      "y": 1015
    },
    {
      "t": 167457,
      "e": 151175,
      "ty": 3,
      "x": 927,
      "y": 1015,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 167458,
      "e": 151176,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 167458,
      "e": 151176,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 167511,
      "e": 151229,
      "ty": 4,
      "x": 50290,
      "y": 19859,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 167512,
      "e": 151230,
      "ty": 5,
      "x": 927,
      "y": 1015,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 167513,
      "e": 151231,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 167514,
      "e": 151232,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 167515,
      "e": 151233,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 167516,
      "e": 151234,
      "ty": 41,
      "x": 31648,
      "y": 55785,
      "ta": "html > body"
    },
    {
      "t": 167611,
      "e": 151329,
      "ty": 2,
      "x": 927,
      "y": 1016
    },
    {
      "t": 167761,
      "e": 151479,
      "ty": 41,
      "x": 31648,
      "y": 55840,
      "ta": "html > body"
    },
    {
      "t": 167811,
      "e": 151529,
      "ty": 2,
      "x": 926,
      "y": 1016
    },
    {
      "t": 167911,
      "e": 151629,
      "ty": 2,
      "x": 925,
      "y": 1016
    },
    {
      "t": 168012,
      "e": 151730,
      "ty": 2,
      "x": 923,
      "y": 1015
    },
    {
      "t": 168012,
      "e": 151730,
      "ty": 41,
      "x": 31510,
      "y": 55785,
      "ta": "html > body"
    },
    {
      "t": 168611,
      "e": 152329,
      "ty": 2,
      "x": 923,
      "y": 1014
    },
    {
      "t": 168761,
      "e": 152479,
      "ty": 41,
      "x": 31510,
      "y": 55729,
      "ta": "html > body"
    },
    {
      "t": 168894,
      "e": 152612,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 169211,
      "e": 152929,
      "ty": 2,
      "x": 922,
      "y": 1013
    },
    {
      "t": 169263,
      "e": 152931,
      "ty": 41,
      "x": 30922,
      "y": 61401,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 170511,
      "e": 154179,
      "ty": 2,
      "x": 920,
      "y": 1030
    },
    {
      "t": 170511,
      "e": 154179,
      "ty": 41,
      "x": 30824,
      "y": 62579,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 170611,
      "e": 154279,
      "ty": 2,
      "x": 940,
      "y": 1066
    },
    {
      "t": 170623,
      "e": 154291,
      "ty": 6,
      "x": 944,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 170711,
      "e": 154379,
      "ty": 2,
      "x": 951,
      "y": 1083
    },
    {
      "t": 170761,
      "e": 154429,
      "ty": 41,
      "x": 24302,
      "y": 29514,
      "ta": "#start"
    },
    {
      "t": 170811,
      "e": 154479,
      "ty": 2,
      "x": 954,
      "y": 1089
    },
    {
      "t": 171011,
      "e": 154679,
      "ty": 41,
      "x": 24302,
      "y": 31442,
      "ta": "#start"
    },
    {
      "t": 176712,
      "e": 159679,
      "ty": 2,
      "x": 955,
      "y": 1089
    },
    {
      "t": 176761,
      "e": 159728,
      "ty": 41,
      "x": 24848,
      "y": 31442,
      "ta": "#start"
    },
    {
      "t": 180012,
      "e": 162979,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 193405,
      "e": 164728,
      "ty": 3,
      "x": 955,
      "y": 1089,
      "ta": "#start"
    },
    {
      "t": 193406,
      "e": 164729,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 193475,
      "e": 164798,
      "ty": 4,
      "x": 24848,
      "y": 31442,
      "ta": "#start"
    },
    {
      "t": 193476,
      "e": 164799,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 193476,
      "e": 164799,
      "ty": 5,
      "x": 955,
      "y": 1089,
      "ta": "#start"
    },
    {
      "t": 193476,
      "e": 164799,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 194511,
      "e": 165834,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 195494,
      "e": 166817,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 111819, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 111826, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"DKL3R\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 3027, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 116177, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"DKL3R\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 8903, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"bravo\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"121\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 126084, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"DKL3R\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 7088, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 134259, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"DKL3R\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 21553, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 156815, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"DKL3R\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 37247, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 195412, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"DKL3R\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-01 PM-10 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1006,y:1018,t:1526922554772};\\\", \\\"{x:1073,y:1034,t:1526922554784};\\\", \\\"{x:1236,y:1090,t:1526922554801};\\\", \\\"{x:1370,y:1133,t:1526922554817};\\\", \\\"{x:1457,y:1199,t:1526922554834};\\\", \\\"{x:1539,y:1199,t:1526922554850};\\\", \\\"{x:1653,y:1199,t:1526922554868};\\\", \\\"{x:1745,y:1199,t:1526922554885};\\\", \\\"{x:1902,y:1199,t:1526922554901};\\\", \\\"{x:1913,y:5,t:1526922555260};\\\", \\\"{x:1837,y:16,t:1526922555268};\\\", \\\"{x:1684,y:65,t:1526922555284};\\\", \\\"{x:1539,y:150,t:1526922555300};\\\", \\\"{x:1483,y:245,t:1526922555318};\\\", \\\"{x:1470,y:300,t:1526922555335};\\\", \\\"{x:1470,y:329,t:1526922555351};\\\", \\\"{x:1470,y:355,t:1526922555368};\\\", \\\"{x:1470,y:382,t:1526922555384};\\\", \\\"{x:1470,y:414,t:1526922555401};\\\", \\\"{x:1470,y:450,t:1526922555417};\\\", \\\"{x:1470,y:497,t:1526922555435};\\\", \\\"{x:1472,y:520,t:1526922555451};\\\", \\\"{x:1478,y:540,t:1526922555468};\\\", \\\"{x:1487,y:559,t:1526922555485};\\\", \\\"{x:1501,y:583,t:1526922555501};\\\", \\\"{x:1520,y:619,t:1526922555518};\\\", \\\"{x:1546,y:670,t:1526922555535};\\\", \\\"{x:1566,y:721,t:1526922555551};\\\", \\\"{x:1577,y:776,t:1526922555568};\\\", \\\"{x:1583,y:815,t:1526922555585};\\\", \\\"{x:1583,y:845,t:1526922555601};\\\", \\\"{x:1583,y:862,t:1526922555618};\\\", \\\"{x:1579,y:873,t:1526922555635};\\\", \\\"{x:1572,y:881,t:1526922555651};\\\", \\\"{x:1559,y:891,t:1526922555667};\\\", \\\"{x:1529,y:911,t:1526922555685};\\\", \\\"{x:1482,y:944,t:1526922555701};\\\", \\\"{x:1431,y:977,t:1526922555718};\\\", \\\"{x:1376,y:1012,t:1526922555738};\\\", \\\"{x:1331,y:1035,t:1526922555751};\\\", \\\"{x:1289,y:1053,t:1526922555769};\\\", \\\"{x:1254,y:1068,t:1526922555784};\\\", \\\"{x:1230,y:1080,t:1526922555802};\\\", \\\"{x:1209,y:1090,t:1526922555818};\\\", \\\"{x:1204,y:1094,t:1526922555835};\\\", \\\"{x:1202,y:1095,t:1526922555851};\\\", \\\"{x:1201,y:1095,t:1526922555874};\\\", \\\"{x:1200,y:1095,t:1526922555907};\\\", \\\"{x:1199,y:1095,t:1526922555919};\\\", \\\"{x:1197,y:1095,t:1526922555934};\\\", \\\"{x:1194,y:1094,t:1526922555952};\\\", \\\"{x:1191,y:1089,t:1526922555969};\\\", \\\"{x:1186,y:1082,t:1526922555985};\\\", \\\"{x:1181,y:1072,t:1526922556002};\\\", \\\"{x:1174,y:1058,t:1526922556019};\\\", \\\"{x:1172,y:1049,t:1526922556034};\\\", \\\"{x:1168,y:1039,t:1526922556051};\\\", \\\"{x:1167,y:1031,t:1526922556069};\\\", \\\"{x:1167,y:1026,t:1526922556084};\\\", \\\"{x:1167,y:1021,t:1526922556102};\\\", \\\"{x:1167,y:1016,t:1526922556119};\\\", \\\"{x:1167,y:1014,t:1526922556135};\\\", \\\"{x:1167,y:1012,t:1526922556152};\\\", \\\"{x:1169,y:1009,t:1526922556169};\\\", \\\"{x:1170,y:1007,t:1526922556186};\\\", \\\"{x:1173,y:1004,t:1526922556202};\\\", \\\"{x:1177,y:1000,t:1526922556218};\\\", \\\"{x:1185,y:995,t:1526922556235};\\\", \\\"{x:1189,y:992,t:1526922556252};\\\", \\\"{x:1196,y:989,t:1526922556269};\\\", \\\"{x:1201,y:986,t:1526922556285};\\\", \\\"{x:1207,y:984,t:1526922556301};\\\", \\\"{x:1211,y:982,t:1526922556318};\\\", \\\"{x:1216,y:980,t:1526922556335};\\\", \\\"{x:1221,y:977,t:1526922556352};\\\", \\\"{x:1223,y:977,t:1526922556368};\\\", \\\"{x:1227,y:975,t:1526922556385};\\\", \\\"{x:1229,y:974,t:1526922556402};\\\", \\\"{x:1240,y:972,t:1526922556418};\\\", \\\"{x:1248,y:970,t:1526922556435};\\\", \\\"{x:1259,y:968,t:1526922556451};\\\", \\\"{x:1266,y:967,t:1526922556469};\\\", \\\"{x:1274,y:964,t:1526922556486};\\\", \\\"{x:1279,y:962,t:1526922556501};\\\", \\\"{x:1281,y:962,t:1526922556519};\\\", \\\"{x:1282,y:961,t:1526922556535};\\\", \\\"{x:1283,y:961,t:1526922556676};\\\", \\\"{x:1284,y:961,t:1526922557450};\\\", \\\"{x:1284,y:960,t:1526922557474};\\\", \\\"{x:1284,y:959,t:1526922559580};\\\", \\\"{x:1284,y:958,t:1526922561379};\\\", \\\"{x:1284,y:956,t:1526922561390};\\\", \\\"{x:1284,y:952,t:1526922561407};\\\", \\\"{x:1284,y:946,t:1526922561423};\\\", \\\"{x:1284,y:936,t:1526922561440};\\\", \\\"{x:1284,y:922,t:1526922561458};\\\", \\\"{x:1284,y:904,t:1526922561474};\\\", \\\"{x:1281,y:886,t:1526922561491};\\\", \\\"{x:1259,y:845,t:1526922561507};\\\", \\\"{x:1220,y:803,t:1526922561523};\\\", \\\"{x:1159,y:759,t:1526922561541};\\\", \\\"{x:1095,y:718,t:1526922561557};\\\", \\\"{x:1012,y:664,t:1526922561574};\\\", \\\"{x:921,y:608,t:1526922561592};\\\", \\\"{x:816,y:556,t:1526922561607};\\\", \\\"{x:706,y:513,t:1526922561624};\\\", \\\"{x:604,y:485,t:1526922561639};\\\", \\\"{x:516,y:463,t:1526922561655};\\\", \\\"{x:416,y:450,t:1526922561671};\\\", \\\"{x:305,y:433,t:1526922561689};\\\", \\\"{x:189,y:421,t:1526922561705};\\\", \\\"{x:14,y:419,t:1526922561722};\\\", \\\"{x:0,y:419,t:1526922561739};\\\", \\\"{x:0,y:420,t:1526922561755};\\\", \\\"{x:0,y:434,t:1526922561773};\\\", \\\"{x:0,y:439,t:1526922561790};\\\", \\\"{x:0,y:440,t:1526922561805};\\\", \\\"{x:0,y:444,t:1526922561907};\\\", \\\"{x:3,y:452,t:1526922561923};\\\", \\\"{x:7,y:460,t:1526922561940};\\\", \\\"{x:11,y:467,t:1526922561957};\\\", \\\"{x:13,y:472,t:1526922561974};\\\", \\\"{x:19,y:476,t:1526922561990};\\\", \\\"{x:24,y:479,t:1526922562007};\\\", \\\"{x:32,y:483,t:1526922562024};\\\", \\\"{x:40,y:486,t:1526922562040};\\\", \\\"{x:50,y:490,t:1526922562058};\\\", \\\"{x:58,y:494,t:1526922562074};\\\", \\\"{x:66,y:497,t:1526922562091};\\\", \\\"{x:71,y:499,t:1526922562107};\\\", \\\"{x:75,y:500,t:1526922562124};\\\", \\\"{x:79,y:501,t:1526922562141};\\\", \\\"{x:84,y:503,t:1526922562157};\\\", \\\"{x:89,y:503,t:1526922562174};\\\", \\\"{x:94,y:505,t:1526922562191};\\\", \\\"{x:99,y:508,t:1526922562209};\\\", \\\"{x:103,y:508,t:1526922562224};\\\", \\\"{x:107,y:509,t:1526922562238};\\\", \\\"{x:112,y:511,t:1526922562255};\\\", \\\"{x:116,y:512,t:1526922562272};\\\", \\\"{x:118,y:513,t:1526922562288};\\\", \\\"{x:122,y:514,t:1526922562305};\\\", \\\"{x:126,y:515,t:1526922562322};\\\", \\\"{x:131,y:516,t:1526922562338};\\\", \\\"{x:143,y:516,t:1526922562355};\\\", \\\"{x:150,y:516,t:1526922562373};\\\", \\\"{x:157,y:516,t:1526922562387};\\\", \\\"{x:163,y:516,t:1526922562406};\\\", \\\"{x:167,y:516,t:1526922562422};\\\", \\\"{x:169,y:516,t:1526922562440};\\\", \\\"{x:170,y:516,t:1526922562490};\\\", \\\"{x:170,y:517,t:1526922562987};\\\", \\\"{x:169,y:518,t:1526922562994};\\\", \\\"{x:168,y:518,t:1526922563074};\\\", \\\"{x:167,y:518,t:1526922563171};\\\", \\\"{x:176,y:522,t:1526922579423};\\\", \\\"{x:209,y:531,t:1526922579431};\\\", \\\"{x:264,y:541,t:1526922579443};\\\", \\\"{x:401,y:547,t:1526922579458};\\\", \\\"{x:617,y:551,t:1526922579483};\\\", \\\"{x:741,y:551,t:1526922579500};\\\", \\\"{x:869,y:551,t:1526922579524};\\\", \\\"{x:900,y:551,t:1526922579539};\\\", \\\"{x:905,y:551,t:1526922579557};\\\", \\\"{x:903,y:551,t:1526922579621};\\\", \\\"{x:898,y:551,t:1526922579629};\\\", \\\"{x:887,y:551,t:1526922579639};\\\", \\\"{x:866,y:551,t:1526922579657};\\\", \\\"{x:840,y:551,t:1526922579674};\\\", \\\"{x:813,y:551,t:1526922579690};\\\", \\\"{x:790,y:551,t:1526922579707};\\\", \\\"{x:775,y:551,t:1526922579723};\\\", \\\"{x:761,y:551,t:1526922579740};\\\", \\\"{x:750,y:551,t:1526922579757};\\\", \\\"{x:726,y:551,t:1526922579773};\\\", \\\"{x:707,y:551,t:1526922579791};\\\", \\\"{x:678,y:551,t:1526922579807};\\\", \\\"{x:632,y:551,t:1526922579824};\\\", \\\"{x:581,y:551,t:1526922579841};\\\", \\\"{x:528,y:551,t:1526922579857};\\\", \\\"{x:489,y:551,t:1526922579874};\\\", \\\"{x:456,y:551,t:1526922579890};\\\", \\\"{x:431,y:551,t:1526922579907};\\\", \\\"{x:418,y:551,t:1526922579923};\\\", \\\"{x:408,y:552,t:1526922579940};\\\", \\\"{x:403,y:554,t:1526922579956};\\\", \\\"{x:399,y:555,t:1526922579974};\\\", \\\"{x:398,y:556,t:1526922579990};\\\", \\\"{x:394,y:559,t:1526922580006};\\\", \\\"{x:391,y:560,t:1526922580024};\\\", \\\"{x:388,y:562,t:1526922580040};\\\", \\\"{x:393,y:568,t:1526922580429};\\\", \\\"{x:399,y:573,t:1526922580441};\\\", \\\"{x:420,y:591,t:1526922580458};\\\", \\\"{x:453,y:626,t:1526922580475};\\\", \\\"{x:490,y:668,t:1526922580491};\\\", \\\"{x:519,y:695,t:1526922580507};\\\", \\\"{x:540,y:712,t:1526922580525};\\\", \\\"{x:550,y:722,t:1526922580541};\\\", \\\"{x:553,y:727,t:1526922580557};\\\", \\\"{x:554,y:730,t:1526922580574};\\\", \\\"{x:554,y:732,t:1526922580590};\\\", \\\"{x:554,y:733,t:1526922580613};\\\", \\\"{x:554,y:734,t:1526922580838};\\\", \\\"{x:553,y:734,t:1526922580846};\\\", \\\"{x:552,y:734,t:1526922580858};\\\", \\\"{x:551,y:734,t:1526922580874};\\\", \\\"{x:549,y:733,t:1526922580891};\\\", \\\"{x:548,y:731,t:1526922580908};\\\", \\\"{x:545,y:729,t:1526922580924};\\\", \\\"{x:545,y:728,t:1526922580941};\\\", \\\"{x:543,y:727,t:1526922580958};\\\", \\\"{x:541,y:726,t:1526922580974};\\\", \\\"{x:541,y:725,t:1526922580991};\\\", \\\"{x:540,y:724,t:1526922581008};\\\", \\\"{x:539,y:723,t:1526922581046};\\\", \\\"{x:539,y:722,t:1526922581078};\\\", \\\"{x:538,y:721,t:1526922581110};\\\", \\\"{x:538,y:720,t:1526922581126};\\\", \\\"{x:538,y:719,t:1526922581175};\\\", \\\"{x:538,y:718,t:1526922581213};\\\", \\\"{x:538,y:717,t:1526922581262};\\\", \\\"{x:537,y:716,t:1526922581310};\\\", \\\"{x:537,y:715,t:1526922581324};\\\", \\\"{x:537,y:714,t:1526922581431};\\\", \\\"{x:536,y:714,t:1526922581441};\\\", \\\"{x:536,y:713,t:1526922583342};\\\" ] }, { \\\"rt\\\": 7338, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 203999, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"DKL3R\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:537,y:712,t:1526922588902};\\\", \\\"{x:540,y:713,t:1526922588912};\\\", \\\"{x:544,y:714,t:1526922588929};\\\", \\\"{x:549,y:715,t:1526922588946};\\\", \\\"{x:557,y:720,t:1526922588962};\\\", \\\"{x:570,y:727,t:1526922588980};\\\", \\\"{x:593,y:736,t:1526922588995};\\\", \\\"{x:668,y:763,t:1526922589012};\\\", \\\"{x:738,y:787,t:1526922589030};\\\", \\\"{x:829,y:812,t:1526922589047};\\\", \\\"{x:918,y:835,t:1526922589064};\\\", \\\"{x:1002,y:854,t:1526922589081};\\\", \\\"{x:1091,y:867,t:1526922589097};\\\", \\\"{x:1169,y:878,t:1526922589113};\\\", \\\"{x:1257,y:886,t:1526922589131};\\\", \\\"{x:1351,y:886,t:1526922589147};\\\", \\\"{x:1426,y:886,t:1526922589165};\\\", \\\"{x:1545,y:868,t:1526922589180};\\\", \\\"{x:1618,y:840,t:1526922589197};\\\", \\\"{x:1684,y:813,t:1526922589215};\\\", \\\"{x:1743,y:786,t:1526922589231};\\\", \\\"{x:1788,y:755,t:1526922589248};\\\", \\\"{x:1817,y:731,t:1526922589265};\\\", \\\"{x:1833,y:711,t:1526922589281};\\\", \\\"{x:1840,y:692,t:1526922589298};\\\", \\\"{x:1842,y:678,t:1526922589315};\\\", \\\"{x:1842,y:667,t:1526922589331};\\\", \\\"{x:1840,y:660,t:1526922589348};\\\", \\\"{x:1815,y:637,t:1526922589364};\\\", \\\"{x:1792,y:622,t:1526922589381};\\\", \\\"{x:1765,y:607,t:1526922589397};\\\", \\\"{x:1741,y:593,t:1526922589415};\\\", \\\"{x:1724,y:580,t:1526922589431};\\\", \\\"{x:1710,y:570,t:1526922589447};\\\", \\\"{x:1696,y:561,t:1526922589465};\\\", \\\"{x:1687,y:555,t:1526922589481};\\\", \\\"{x:1680,y:552,t:1526922589498};\\\", \\\"{x:1675,y:550,t:1526922589515};\\\", \\\"{x:1669,y:547,t:1526922589532};\\\", \\\"{x:1668,y:546,t:1526922589598};\\\", \\\"{x:1667,y:541,t:1526922589615};\\\", \\\"{x:1666,y:534,t:1526922589631};\\\", \\\"{x:1665,y:526,t:1526922589649};\\\", \\\"{x:1664,y:512,t:1526922589665};\\\", \\\"{x:1660,y:495,t:1526922589681};\\\", \\\"{x:1659,y:482,t:1526922589698};\\\", \\\"{x:1657,y:474,t:1526922589715};\\\", \\\"{x:1656,y:470,t:1526922589732};\\\", \\\"{x:1655,y:466,t:1526922589748};\\\", \\\"{x:1652,y:463,t:1526922589765};\\\", \\\"{x:1652,y:462,t:1526922589782};\\\", \\\"{x:1651,y:459,t:1526922589798};\\\", \\\"{x:1649,y:458,t:1526922589815};\\\", \\\"{x:1648,y:456,t:1526922589832};\\\", \\\"{x:1646,y:456,t:1526922589848};\\\", \\\"{x:1644,y:455,t:1526922589865};\\\", \\\"{x:1643,y:455,t:1526922589882};\\\", \\\"{x:1639,y:453,t:1526922589899};\\\", \\\"{x:1637,y:453,t:1526922589915};\\\", \\\"{x:1636,y:452,t:1526922589932};\\\", \\\"{x:1633,y:452,t:1526922589948};\\\", \\\"{x:1632,y:452,t:1526922589966};\\\", \\\"{x:1629,y:450,t:1526922589982};\\\", \\\"{x:1629,y:449,t:1526922590006};\\\", \\\"{x:1628,y:449,t:1526922590015};\\\", \\\"{x:1627,y:449,t:1526922590033};\\\", \\\"{x:1626,y:448,t:1526922590049};\\\", \\\"{x:1624,y:448,t:1526922590086};\\\", \\\"{x:1622,y:448,t:1526922590646};\\\", \\\"{x:1611,y:449,t:1526922590654};\\\", \\\"{x:1595,y:454,t:1526922590666};\\\", \\\"{x:1493,y:480,t:1526922590682};\\\", \\\"{x:1347,y:512,t:1526922590699};\\\", \\\"{x:1180,y:550,t:1526922590716};\\\", \\\"{x:1011,y:575,t:1526922590732};\\\", \\\"{x:813,y:585,t:1526922590751};\\\", \\\"{x:727,y:585,t:1526922590766};\\\", \\\"{x:671,y:585,t:1526922590782};\\\", \\\"{x:638,y:589,t:1526922590799};\\\", \\\"{x:621,y:591,t:1526922590815};\\\", \\\"{x:613,y:596,t:1526922590832};\\\", \\\"{x:608,y:598,t:1526922590849};\\\", \\\"{x:600,y:600,t:1526922590865};\\\", \\\"{x:592,y:604,t:1526922590882};\\\", \\\"{x:579,y:609,t:1526922590898};\\\", \\\"{x:555,y:617,t:1526922590916};\\\", \\\"{x:498,y:635,t:1526922590933};\\\", \\\"{x:464,y:647,t:1526922590948};\\\", \\\"{x:435,y:655,t:1526922590966};\\\", \\\"{x:424,y:659,t:1526922590983};\\\", \\\"{x:423,y:659,t:1526922590998};\\\", \\\"{x:422,y:658,t:1526922591093};\\\", \\\"{x:426,y:653,t:1526922591101};\\\", \\\"{x:431,y:647,t:1526922591116};\\\", \\\"{x:447,y:628,t:1526922591132};\\\", \\\"{x:451,y:619,t:1526922591150};\\\", \\\"{x:451,y:614,t:1526922591166};\\\", \\\"{x:448,y:604,t:1526922591183};\\\", \\\"{x:431,y:595,t:1526922591198};\\\", \\\"{x:405,y:587,t:1526922591216};\\\", \\\"{x:374,y:582,t:1526922591233};\\\", \\\"{x:346,y:576,t:1526922591249};\\\", \\\"{x:329,y:572,t:1526922591266};\\\", \\\"{x:327,y:571,t:1526922591283};\\\", \\\"{x:326,y:571,t:1526922591299};\\\", \\\"{x:330,y:574,t:1526922591430};\\\", \\\"{x:334,y:577,t:1526922591447};\\\", \\\"{x:339,y:578,t:1526922591466};\\\", \\\"{x:344,y:581,t:1526922591482};\\\", \\\"{x:346,y:582,t:1526922591499};\\\", \\\"{x:347,y:582,t:1526922591515};\\\", \\\"{x:352,y:582,t:1526922591580};\\\", \\\"{x:353,y:582,t:1526922591588};\\\", \\\"{x:355,y:582,t:1526922591600};\\\", \\\"{x:359,y:582,t:1526922591617};\\\", \\\"{x:361,y:582,t:1526922591633};\\\", \\\"{x:362,y:582,t:1526922591650};\\\", \\\"{x:363,y:582,t:1526922591665};\\\", \\\"{x:364,y:582,t:1526922591701};\\\", \\\"{x:365,y:583,t:1526922591717};\\\", \\\"{x:369,y:586,t:1526922591734};\\\", \\\"{x:372,y:589,t:1526922591750};\\\", \\\"{x:374,y:590,t:1526922591768};\\\", \\\"{x:377,y:593,t:1526922591782};\\\", \\\"{x:381,y:597,t:1526922591800};\\\", \\\"{x:382,y:598,t:1526922591817};\\\", \\\"{x:384,y:600,t:1526922591832};\\\", \\\"{x:385,y:600,t:1526922591849};\\\", \\\"{x:385,y:602,t:1526922591877};\\\", \\\"{x:387,y:602,t:1526922592117};\\\", \\\"{x:396,y:603,t:1526922592133};\\\", \\\"{x:411,y:613,t:1526922592151};\\\", \\\"{x:430,y:624,t:1526922592167};\\\", \\\"{x:446,y:635,t:1526922592183};\\\", \\\"{x:455,y:643,t:1526922592199};\\\", \\\"{x:459,y:648,t:1526922592217};\\\", \\\"{x:463,y:655,t:1526922592234};\\\", \\\"{x:470,y:662,t:1526922592250};\\\", \\\"{x:475,y:670,t:1526922592267};\\\", \\\"{x:484,y:682,t:1526922592284};\\\", \\\"{x:504,y:704,t:1526922592302};\\\", \\\"{x:520,y:718,t:1526922592317};\\\", \\\"{x:533,y:727,t:1526922592334};\\\", \\\"{x:542,y:733,t:1526922592350};\\\", \\\"{x:548,y:737,t:1526922592368};\\\", \\\"{x:549,y:738,t:1526922592396};\\\", \\\"{x:549,y:735,t:1526922592518};\\\", \\\"{x:545,y:731,t:1526922592534};\\\", \\\"{x:544,y:727,t:1526922592550};\\\", \\\"{x:541,y:724,t:1526922592566};\\\", \\\"{x:541,y:723,t:1526922592584};\\\", \\\"{x:540,y:722,t:1526922592601};\\\", \\\"{x:539,y:721,t:1526922592646};\\\", \\\"{x:538,y:721,t:1526922592670};\\\", \\\"{x:538,y:720,t:1526922592701};\\\", \\\"{x:537,y:720,t:1526922592717};\\\" ] }, { \\\"rt\\\": 15926, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 221145, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"DKL3R\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"J\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-H -C -C \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:542,y:722,t:1526922596973};\\\", \\\"{x:566,y:743,t:1526922596988};\\\", \\\"{x:650,y:808,t:1526922597004};\\\", \\\"{x:752,y:865,t:1526922597020};\\\", \\\"{x:889,y:913,t:1526922597036};\\\", \\\"{x:973,y:928,t:1526922597054};\\\", \\\"{x:1051,y:939,t:1526922597070};\\\", \\\"{x:1126,y:949,t:1526922597087};\\\", \\\"{x:1193,y:949,t:1526922597104};\\\", \\\"{x:1262,y:949,t:1526922597120};\\\", \\\"{x:1315,y:949,t:1526922597137};\\\", \\\"{x:1368,y:944,t:1526922597154};\\\", \\\"{x:1424,y:926,t:1526922597170};\\\", \\\"{x:1469,y:906,t:1526922597188};\\\", \\\"{x:1505,y:883,t:1526922597204};\\\", \\\"{x:1524,y:867,t:1526922597220};\\\", \\\"{x:1539,y:845,t:1526922597237};\\\", \\\"{x:1541,y:832,t:1526922597254};\\\", \\\"{x:1541,y:816,t:1526922597271};\\\", \\\"{x:1541,y:801,t:1526922597288};\\\", \\\"{x:1541,y:784,t:1526922597305};\\\", \\\"{x:1538,y:766,t:1526922597320};\\\", \\\"{x:1531,y:746,t:1526922597338};\\\", \\\"{x:1521,y:726,t:1526922597354};\\\", \\\"{x:1509,y:706,t:1526922597371};\\\", \\\"{x:1498,y:687,t:1526922597388};\\\", \\\"{x:1487,y:668,t:1526922597404};\\\", \\\"{x:1475,y:643,t:1526922597421};\\\", \\\"{x:1466,y:626,t:1526922597437};\\\", \\\"{x:1459,y:609,t:1526922597454};\\\", \\\"{x:1449,y:594,t:1526922597471};\\\", \\\"{x:1441,y:580,t:1526922597487};\\\", \\\"{x:1434,y:569,t:1526922597504};\\\", \\\"{x:1425,y:558,t:1526922597521};\\\", \\\"{x:1412,y:548,t:1526922597537};\\\", \\\"{x:1401,y:542,t:1526922597555};\\\", \\\"{x:1394,y:536,t:1526922597571};\\\", \\\"{x:1391,y:533,t:1526922597588};\\\", \\\"{x:1390,y:531,t:1526922597604};\\\", \\\"{x:1387,y:528,t:1526922597621};\\\", \\\"{x:1387,y:527,t:1526922597637};\\\", \\\"{x:1386,y:525,t:1526922597654};\\\", \\\"{x:1384,y:524,t:1526922597671};\\\", \\\"{x:1380,y:523,t:1526922597687};\\\", \\\"{x:1376,y:520,t:1526922597704};\\\", \\\"{x:1374,y:520,t:1526922597722};\\\", \\\"{x:1374,y:519,t:1526922597806};\\\", \\\"{x:1369,y:517,t:1526922597822};\\\", \\\"{x:1367,y:516,t:1526922597838};\\\", \\\"{x:1366,y:516,t:1526922597855};\\\", \\\"{x:1364,y:516,t:1526922597871};\\\", \\\"{x:1363,y:516,t:1526922597888};\\\", \\\"{x:1360,y:516,t:1526922597905};\\\", \\\"{x:1356,y:517,t:1526922597922};\\\", \\\"{x:1351,y:521,t:1526922597939};\\\", \\\"{x:1347,y:525,t:1526922597954};\\\", \\\"{x:1340,y:530,t:1526922597972};\\\", \\\"{x:1332,y:536,t:1526922597989};\\\", \\\"{x:1326,y:542,t:1526922598005};\\\", \\\"{x:1317,y:552,t:1526922598021};\\\", \\\"{x:1311,y:560,t:1526922598038};\\\", \\\"{x:1308,y:566,t:1526922598054};\\\", \\\"{x:1305,y:570,t:1526922598071};\\\", \\\"{x:1302,y:575,t:1526922598088};\\\", \\\"{x:1301,y:579,t:1526922598104};\\\", \\\"{x:1301,y:581,t:1526922598122};\\\", \\\"{x:1300,y:583,t:1526922598139};\\\", \\\"{x:1298,y:587,t:1526922598155};\\\", \\\"{x:1297,y:590,t:1526922598172};\\\", \\\"{x:1297,y:591,t:1526922598189};\\\", \\\"{x:1294,y:594,t:1526922598205};\\\", \\\"{x:1293,y:596,t:1526922598221};\\\", \\\"{x:1291,y:600,t:1526922598238};\\\", \\\"{x:1290,y:603,t:1526922598255};\\\", \\\"{x:1288,y:607,t:1526922598272};\\\", \\\"{x:1286,y:612,t:1526922598289};\\\", \\\"{x:1283,y:616,t:1526922598304};\\\", \\\"{x:1275,y:626,t:1526922598322};\\\", \\\"{x:1266,y:638,t:1526922598338};\\\", \\\"{x:1257,y:653,t:1526922598354};\\\", \\\"{x:1248,y:670,t:1526922598372};\\\", \\\"{x:1240,y:686,t:1526922598388};\\\", \\\"{x:1235,y:703,t:1526922598405};\\\", \\\"{x:1229,y:726,t:1526922598422};\\\", \\\"{x:1229,y:739,t:1526922598439};\\\", \\\"{x:1229,y:751,t:1526922598456};\\\", \\\"{x:1229,y:763,t:1526922598472};\\\", \\\"{x:1229,y:777,t:1526922598489};\\\", \\\"{x:1229,y:786,t:1526922598506};\\\", \\\"{x:1229,y:792,t:1526922598521};\\\", \\\"{x:1233,y:801,t:1526922598539};\\\", \\\"{x:1233,y:808,t:1526922598555};\\\", \\\"{x:1234,y:813,t:1526922598572};\\\", \\\"{x:1234,y:816,t:1526922598589};\\\", \\\"{x:1234,y:819,t:1526922598605};\\\", \\\"{x:1234,y:820,t:1526922598646};\\\", \\\"{x:1234,y:821,t:1526922598661};\\\", \\\"{x:1234,y:822,t:1526922598677};\\\", \\\"{x:1232,y:822,t:1526922598689};\\\", \\\"{x:1230,y:823,t:1526922598705};\\\", \\\"{x:1227,y:824,t:1526922598722};\\\", \\\"{x:1225,y:825,t:1526922598738};\\\", \\\"{x:1222,y:826,t:1526922598756};\\\", \\\"{x:1221,y:826,t:1526922598774};\\\", \\\"{x:1220,y:826,t:1526922598797};\\\", \\\"{x:1219,y:827,t:1526922598808};\\\", \\\"{x:1219,y:828,t:1526922598838};\\\", \\\"{x:1218,y:828,t:1526922598884};\\\", \\\"{x:1218,y:829,t:1526922598909};\\\", \\\"{x:1217,y:829,t:1526922598948};\\\", \\\"{x:1216,y:829,t:1526922599013};\\\", \\\"{x:1216,y:828,t:1526922601886};\\\", \\\"{x:1213,y:823,t:1526922601894};\\\", \\\"{x:1187,y:817,t:1526922601910};\\\", \\\"{x:1168,y:810,t:1526922601924};\\\", \\\"{x:1074,y:795,t:1526922601941};\\\", \\\"{x:996,y:782,t:1526922601957};\\\", \\\"{x:920,y:768,t:1526922601974};\\\", \\\"{x:848,y:750,t:1526922601991};\\\", \\\"{x:782,y:732,t:1526922602008};\\\", \\\"{x:737,y:719,t:1526922602023};\\\", \\\"{x:709,y:711,t:1526922602041};\\\", \\\"{x:690,y:705,t:1526922602057};\\\", \\\"{x:681,y:701,t:1526922602075};\\\", \\\"{x:676,y:698,t:1526922602091};\\\", \\\"{x:674,y:697,t:1526922602109};\\\", \\\"{x:673,y:696,t:1526922602125};\\\", \\\"{x:672,y:695,t:1526922602141};\\\", \\\"{x:669,y:692,t:1526922602157};\\\", \\\"{x:667,y:688,t:1526922602175};\\\", \\\"{x:667,y:685,t:1526922602190};\\\", \\\"{x:667,y:682,t:1526922602207};\\\", \\\"{x:667,y:674,t:1526922602225};\\\", \\\"{x:672,y:665,t:1526922602241};\\\", \\\"{x:683,y:653,t:1526922602257};\\\", \\\"{x:698,y:643,t:1526922602277};\\\", \\\"{x:717,y:630,t:1526922602290};\\\", \\\"{x:733,y:621,t:1526922602307};\\\", \\\"{x:746,y:612,t:1526922602326};\\\", \\\"{x:758,y:604,t:1526922602341};\\\", \\\"{x:764,y:600,t:1526922602358};\\\", \\\"{x:768,y:597,t:1526922602375};\\\", \\\"{x:770,y:594,t:1526922602391};\\\", \\\"{x:772,y:592,t:1526922602407};\\\", \\\"{x:774,y:590,t:1526922602425};\\\", \\\"{x:776,y:588,t:1526922602441};\\\", \\\"{x:779,y:586,t:1526922602458};\\\", \\\"{x:781,y:585,t:1526922602475};\\\", \\\"{x:785,y:583,t:1526922602491};\\\", \\\"{x:787,y:581,t:1526922602509};\\\", \\\"{x:793,y:577,t:1526922602525};\\\", \\\"{x:797,y:575,t:1526922602541};\\\", \\\"{x:798,y:574,t:1526922602559};\\\", \\\"{x:799,y:573,t:1526922602575};\\\", \\\"{x:800,y:573,t:1526922602592};\\\", \\\"{x:800,y:572,t:1526922602637};\\\", \\\"{x:801,y:572,t:1526922602645};\\\", \\\"{x:803,y:571,t:1526922602658};\\\", \\\"{x:805,y:570,t:1526922602677};\\\", \\\"{x:808,y:570,t:1526922602693};\\\", \\\"{x:810,y:570,t:1526922602709};\\\", \\\"{x:812,y:570,t:1526922602725};\\\", \\\"{x:814,y:569,t:1526922602743};\\\", \\\"{x:815,y:569,t:1526922602759};\\\", \\\"{x:816,y:568,t:1526922602775};\\\", \\\"{x:817,y:568,t:1526922602792};\\\", \\\"{x:818,y:567,t:1526922602809};\\\", \\\"{x:819,y:567,t:1526922602826};\\\", \\\"{x:820,y:567,t:1526922602842};\\\", \\\"{x:822,y:566,t:1526922602858};\\\", \\\"{x:824,y:566,t:1526922602877};\\\", \\\"{x:825,y:565,t:1526922602893};\\\", \\\"{x:827,y:565,t:1526922602926};\\\", \\\"{x:827,y:564,t:1526922602942};\\\", \\\"{x:828,y:564,t:1526922602958};\\\", \\\"{x:826,y:565,t:1526922609493};\\\", \\\"{x:813,y:575,t:1526922609514};\\\", \\\"{x:803,y:581,t:1526922609529};\\\", \\\"{x:795,y:585,t:1526922609546};\\\", \\\"{x:788,y:589,t:1526922609562};\\\", \\\"{x:770,y:601,t:1526922609581};\\\", \\\"{x:761,y:607,t:1526922609597};\\\", \\\"{x:746,y:618,t:1526922609614};\\\", \\\"{x:724,y:633,t:1526922609631};\\\", \\\"{x:695,y:649,t:1526922609647};\\\", \\\"{x:649,y:668,t:1526922609665};\\\", \\\"{x:616,y:681,t:1526922609680};\\\", \\\"{x:585,y:692,t:1526922609697};\\\", \\\"{x:564,y:701,t:1526922609714};\\\", \\\"{x:550,y:707,t:1526922609731};\\\", \\\"{x:538,y:712,t:1526922609747};\\\", \\\"{x:520,y:721,t:1526922609765};\\\", \\\"{x:509,y:728,t:1526922609780};\\\", \\\"{x:496,y:733,t:1526922609797};\\\", \\\"{x:483,y:738,t:1526922609815};\\\", \\\"{x:479,y:740,t:1526922609831};\\\", \\\"{x:478,y:740,t:1526922609909};\\\", \\\"{x:478,y:738,t:1526922609925};\\\", \\\"{x:478,y:737,t:1526922609933};\\\", \\\"{x:478,y:735,t:1526922609948};\\\", \\\"{x:478,y:730,t:1526922609964};\\\", \\\"{x:480,y:728,t:1526922609981};\\\", \\\"{x:482,y:725,t:1526922609997};\\\", \\\"{x:482,y:724,t:1526922610015};\\\", \\\"{x:485,y:722,t:1526922610031};\\\", \\\"{x:487,y:721,t:1526922610048};\\\", \\\"{x:488,y:721,t:1526922610065};\\\", \\\"{x:489,y:721,t:1526922610081};\\\", \\\"{x:490,y:721,t:1526922610101};\\\", \\\"{x:491,y:720,t:1526922610115};\\\" ] }, { \\\"rt\\\": 12975, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 235415, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"DKL3R\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:506,y:729,t:1526922613949};\\\", \\\"{x:538,y:745,t:1526922613963};\\\", \\\"{x:583,y:761,t:1526922613971};\\\", \\\"{x:678,y:795,t:1526922613987};\\\", \\\"{x:797,y:824,t:1526922614000};\\\", \\\"{x:918,y:857,t:1526922614017};\\\", \\\"{x:1027,y:875,t:1526922614033};\\\", \\\"{x:1126,y:885,t:1526922614050};\\\", \\\"{x:1204,y:885,t:1526922614067};\\\", \\\"{x:1265,y:885,t:1526922614082};\\\", \\\"{x:1318,y:885,t:1526922614100};\\\", \\\"{x:1391,y:885,t:1526922614116};\\\", \\\"{x:1438,y:885,t:1526922614133};\\\", \\\"{x:1486,y:885,t:1526922614149};\\\", \\\"{x:1525,y:885,t:1526922614167};\\\", \\\"{x:1567,y:885,t:1526922614182};\\\", \\\"{x:1606,y:885,t:1526922614200};\\\", \\\"{x:1646,y:885,t:1526922614217};\\\", \\\"{x:1674,y:885,t:1526922614232};\\\", \\\"{x:1696,y:885,t:1526922614249};\\\", \\\"{x:1715,y:885,t:1526922614266};\\\", \\\"{x:1730,y:885,t:1526922614283};\\\", \\\"{x:1737,y:885,t:1526922614299};\\\", \\\"{x:1742,y:885,t:1526922614317};\\\", \\\"{x:1741,y:885,t:1526922614486};\\\", \\\"{x:1737,y:889,t:1526922614500};\\\", \\\"{x:1730,y:894,t:1526922614517};\\\", \\\"{x:1726,y:895,t:1526922614533};\\\", \\\"{x:1722,y:898,t:1526922614550};\\\", \\\"{x:1719,y:898,t:1526922614567};\\\", \\\"{x:1718,y:898,t:1526922614584};\\\", \\\"{x:1716,y:899,t:1526922614601};\\\", \\\"{x:1715,y:900,t:1526922614618};\\\", \\\"{x:1712,y:901,t:1526922614633};\\\", \\\"{x:1708,y:903,t:1526922614650};\\\", \\\"{x:1705,y:905,t:1526922614667};\\\", \\\"{x:1698,y:907,t:1526922614683};\\\", \\\"{x:1693,y:909,t:1526922614700};\\\", \\\"{x:1688,y:912,t:1526922614717};\\\", \\\"{x:1686,y:912,t:1526922614734};\\\", \\\"{x:1681,y:915,t:1526922614750};\\\", \\\"{x:1679,y:915,t:1526922614767};\\\", \\\"{x:1677,y:916,t:1526922614784};\\\", \\\"{x:1675,y:917,t:1526922614800};\\\", \\\"{x:1670,y:918,t:1526922614818};\\\", \\\"{x:1667,y:919,t:1526922614833};\\\", \\\"{x:1660,y:920,t:1526922614850};\\\", \\\"{x:1652,y:923,t:1526922614867};\\\", \\\"{x:1646,y:924,t:1526922614884};\\\", \\\"{x:1642,y:924,t:1526922614900};\\\", \\\"{x:1638,y:925,t:1526922614917};\\\", \\\"{x:1637,y:925,t:1526922615494};\\\", \\\"{x:1634,y:923,t:1526922615501};\\\", \\\"{x:1625,y:911,t:1526922615517};\\\", \\\"{x:1603,y:886,t:1526922615535};\\\", \\\"{x:1564,y:854,t:1526922615550};\\\", \\\"{x:1508,y:814,t:1526922615568};\\\", \\\"{x:1445,y:778,t:1526922615584};\\\", \\\"{x:1357,y:739,t:1526922615600};\\\", \\\"{x:1255,y:698,t:1526922615617};\\\", \\\"{x:1154,y:655,t:1526922615634};\\\", \\\"{x:1053,y:623,t:1526922615650};\\\", \\\"{x:973,y:599,t:1526922615667};\\\", \\\"{x:903,y:579,t:1526922615685};\\\", \\\"{x:849,y:570,t:1526922615702};\\\", \\\"{x:806,y:565,t:1526922615716};\\\", \\\"{x:789,y:565,t:1526922615734};\\\", \\\"{x:778,y:565,t:1526922615753};\\\", \\\"{x:770,y:565,t:1526922615769};\\\", \\\"{x:763,y:566,t:1526922615786};\\\", \\\"{x:752,y:571,t:1526922615803};\\\", \\\"{x:735,y:579,t:1526922615819};\\\", \\\"{x:707,y:587,t:1526922615836};\\\", \\\"{x:669,y:605,t:1526922615852};\\\", \\\"{x:645,y:612,t:1526922615868};\\\", \\\"{x:623,y:617,t:1526922615886};\\\", \\\"{x:603,y:619,t:1526922615903};\\\", \\\"{x:586,y:625,t:1526922615920};\\\", \\\"{x:567,y:628,t:1526922615936};\\\", \\\"{x:548,y:630,t:1526922615953};\\\", \\\"{x:525,y:633,t:1526922615969};\\\", \\\"{x:499,y:636,t:1526922615985};\\\", \\\"{x:471,y:636,t:1526922616004};\\\", \\\"{x:446,y:636,t:1526922616018};\\\", \\\"{x:424,y:638,t:1526922616036};\\\", \\\"{x:405,y:638,t:1526922616053};\\\", \\\"{x:402,y:638,t:1526922616069};\\\", \\\"{x:400,y:638,t:1526922616086};\\\", \\\"{x:399,y:638,t:1526922616149};\\\", \\\"{x:397,y:638,t:1526922616181};\\\", \\\"{x:397,y:637,t:1526922616188};\\\", \\\"{x:395,y:637,t:1526922616205};\\\", \\\"{x:395,y:636,t:1526922616237};\\\", \\\"{x:394,y:635,t:1526922616269};\\\", \\\"{x:390,y:631,t:1526922622350};\\\", \\\"{x:378,y:624,t:1526922622359};\\\", \\\"{x:356,y:604,t:1526922622377};\\\", \\\"{x:334,y:588,t:1526922622391};\\\", \\\"{x:318,y:576,t:1526922622408};\\\", \\\"{x:303,y:565,t:1526922622425};\\\", \\\"{x:298,y:561,t:1526922622441};\\\", \\\"{x:297,y:561,t:1526922622458};\\\", \\\"{x:294,y:560,t:1526922622474};\\\", \\\"{x:291,y:557,t:1526922622491};\\\", \\\"{x:288,y:557,t:1526922622508};\\\", \\\"{x:286,y:557,t:1526922622524};\\\", \\\"{x:286,y:556,t:1526922622541};\\\", \\\"{x:283,y:556,t:1526922622558};\\\", \\\"{x:281,y:556,t:1526922622574};\\\", \\\"{x:277,y:556,t:1526922622591};\\\", \\\"{x:274,y:558,t:1526922622608};\\\", \\\"{x:270,y:561,t:1526922622625};\\\", \\\"{x:262,y:568,t:1526922622641};\\\", \\\"{x:254,y:577,t:1526922622659};\\\", \\\"{x:248,y:587,t:1526922622674};\\\", \\\"{x:245,y:594,t:1526922622691};\\\", \\\"{x:248,y:602,t:1526922622708};\\\", \\\"{x:258,y:606,t:1526922622724};\\\", \\\"{x:270,y:611,t:1526922622741};\\\", \\\"{x:283,y:613,t:1526922622759};\\\", \\\"{x:294,y:613,t:1526922622775};\\\", \\\"{x:305,y:613,t:1526922622791};\\\", \\\"{x:316,y:613,t:1526922622808};\\\", \\\"{x:330,y:613,t:1526922622825};\\\", \\\"{x:339,y:613,t:1526922622841};\\\", \\\"{x:353,y:613,t:1526922622858};\\\", \\\"{x:375,y:612,t:1526922622876};\\\", \\\"{x:392,y:609,t:1526922622891};\\\", \\\"{x:412,y:606,t:1526922622909};\\\", \\\"{x:424,y:605,t:1526922622926};\\\", \\\"{x:436,y:603,t:1526922622941};\\\", \\\"{x:449,y:601,t:1526922622957};\\\", \\\"{x:467,y:600,t:1526922622975};\\\", \\\"{x:490,y:599,t:1526922622991};\\\", \\\"{x:522,y:595,t:1526922623009};\\\", \\\"{x:554,y:594,t:1526922623025};\\\", \\\"{x:592,y:590,t:1526922623041};\\\", \\\"{x:623,y:588,t:1526922623059};\\\", \\\"{x:651,y:586,t:1526922623075};\\\", \\\"{x:678,y:586,t:1526922623091};\\\", \\\"{x:706,y:586,t:1526922623108};\\\", \\\"{x:721,y:586,t:1526922623125};\\\", \\\"{x:729,y:586,t:1526922623143};\\\", \\\"{x:734,y:586,t:1526922623158};\\\", \\\"{x:736,y:586,t:1526922623174};\\\", \\\"{x:736,y:587,t:1526922623220};\\\", \\\"{x:736,y:590,t:1526922623228};\\\", \\\"{x:735,y:593,t:1526922623242};\\\", \\\"{x:727,y:602,t:1526922623258};\\\", \\\"{x:721,y:607,t:1526922623276};\\\", \\\"{x:707,y:615,t:1526922623293};\\\", \\\"{x:699,y:619,t:1526922623308};\\\", \\\"{x:693,y:620,t:1526922623325};\\\", \\\"{x:691,y:621,t:1526922623342};\\\", \\\"{x:685,y:623,t:1526922623358};\\\", \\\"{x:679,y:624,t:1526922623375};\\\", \\\"{x:673,y:624,t:1526922623392};\\\", \\\"{x:669,y:626,t:1526922623410};\\\", \\\"{x:664,y:626,t:1526922623425};\\\", \\\"{x:659,y:626,t:1526922623442};\\\", \\\"{x:656,y:626,t:1526922623459};\\\", \\\"{x:650,y:626,t:1526922623476};\\\", \\\"{x:643,y:626,t:1526922623492};\\\", \\\"{x:639,y:626,t:1526922623510};\\\", \\\"{x:636,y:626,t:1526922623526};\\\", \\\"{x:634,y:626,t:1526922623542};\\\", \\\"{x:632,y:626,t:1526922623565};\\\", \\\"{x:630,y:626,t:1526922623597};\\\", \\\"{x:630,y:627,t:1526922623613};\\\", \\\"{x:629,y:627,t:1526922623626};\\\", \\\"{x:627,y:628,t:1526922623642};\\\", \\\"{x:626,y:629,t:1526922623659};\\\", \\\"{x:625,y:629,t:1526922623693};\\\", \\\"{x:624,y:629,t:1526922623709};\\\", \\\"{x:623,y:629,t:1526922623726};\\\", \\\"{x:622,y:629,t:1526922623742};\\\", \\\"{x:621,y:629,t:1526922623760};\\\", \\\"{x:620,y:630,t:1526922623981};\\\", \\\"{x:616,y:633,t:1526922623992};\\\", \\\"{x:610,y:642,t:1526922624009};\\\", \\\"{x:602,y:649,t:1526922624027};\\\", \\\"{x:596,y:654,t:1526922624042};\\\", \\\"{x:589,y:663,t:1526922624059};\\\", \\\"{x:566,y:679,t:1526922624076};\\\", \\\"{x:551,y:687,t:1526922624092};\\\", \\\"{x:543,y:694,t:1526922624109};\\\", \\\"{x:532,y:699,t:1526922624126};\\\", \\\"{x:524,y:704,t:1526922624142};\\\", \\\"{x:513,y:709,t:1526922624159};\\\", \\\"{x:506,y:713,t:1526922624176};\\\", \\\"{x:505,y:713,t:1526922624192};\\\", \\\"{x:503,y:713,t:1526922624209};\\\", \\\"{x:501,y:714,t:1526922624292};\\\", \\\"{x:501,y:715,t:1526922624310};\\\", \\\"{x:501,y:716,t:1526922624327};\\\", \\\"{x:500,y:717,t:1526922624342};\\\" ] }, { \\\"rt\\\": 28346, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 265017, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"DKL3R\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-7-I \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:509,y:717,t:1526922639849};\\\", \\\"{x:654,y:717,t:1526922639872};\\\", \\\"{x:691,y:714,t:1526922639886};\\\", \\\"{x:857,y:630,t:1526922639904};\\\", \\\"{x:1015,y:508,t:1526922639926};\\\", \\\"{x:1199,y:365,t:1526922639942};\\\", \\\"{x:1405,y:234,t:1526922639959};\\\", \\\"{x:1661,y:41,t:1526922639975};\\\", \\\"{x:1760,y:0,t:1526922639992};\\\", \\\"{x:1794,y:0,t:1526922640009};\\\", \\\"{x:1797,y:0,t:1526922640025};\\\", \\\"{x:1782,y:0,t:1526922640042};\\\", \\\"{x:1721,y:0,t:1526922640059};\\\", \\\"{x:1611,y:0,t:1526922640076};\\\", \\\"{x:1484,y:0,t:1526922640092};\\\", \\\"{x:1379,y:0,t:1526922640109};\\\", \\\"{x:1299,y:0,t:1526922640125};\\\", \\\"{x:1243,y:0,t:1526922640143};\\\", \\\"{x:1195,y:0,t:1526922640159};\\\", \\\"{x:1138,y:14,t:1526922640175};\\\", \\\"{x:1059,y:48,t:1526922640192};\\\", \\\"{x:1022,y:75,t:1526922640209};\\\", \\\"{x:973,y:132,t:1526922640226};\\\", \\\"{x:937,y:198,t:1526922640243};\\\", \\\"{x:916,y:250,t:1526922640258};\\\", \\\"{x:909,y:277,t:1526922640276};\\\", \\\"{x:908,y:298,t:1526922640293};\\\", \\\"{x:908,y:317,t:1526922640309};\\\", \\\"{x:912,y:339,t:1526922640326};\\\", \\\"{x:921,y:362,t:1526922640342};\\\", \\\"{x:932,y:383,t:1526922640358};\\\", \\\"{x:959,y:420,t:1526922640376};\\\", \\\"{x:985,y:447,t:1526922640393};\\\", \\\"{x:1015,y:471,t:1526922640409};\\\", \\\"{x:1040,y:485,t:1526922640426};\\\", \\\"{x:1060,y:498,t:1526922640443};\\\", \\\"{x:1075,y:507,t:1526922640460};\\\", \\\"{x:1092,y:518,t:1526922640476};\\\", \\\"{x:1113,y:530,t:1526922640493};\\\", \\\"{x:1137,y:547,t:1526922640509};\\\", \\\"{x:1178,y:563,t:1526922640526};\\\", \\\"{x:1234,y:579,t:1526922640543};\\\", \\\"{x:1331,y:603,t:1526922640560};\\\", \\\"{x:1400,y:612,t:1526922640576};\\\", \\\"{x:1461,y:619,t:1526922640593};\\\", \\\"{x:1537,y:624,t:1526922640610};\\\", \\\"{x:1596,y:624,t:1526922640626};\\\", \\\"{x:1636,y:624,t:1526922640643};\\\", \\\"{x:1658,y:613,t:1526922640660};\\\", \\\"{x:1664,y:606,t:1526922640676};\\\", \\\"{x:1665,y:600,t:1526922640693};\\\", \\\"{x:1665,y:588,t:1526922640710};\\\", \\\"{x:1650,y:567,t:1526922640726};\\\", \\\"{x:1625,y:549,t:1526922640743};\\\", \\\"{x:1563,y:520,t:1526922640760};\\\", \\\"{x:1516,y:500,t:1526922640777};\\\", \\\"{x:1467,y:489,t:1526922640793};\\\", \\\"{x:1428,y:484,t:1526922640810};\\\", \\\"{x:1404,y:481,t:1526922640826};\\\", \\\"{x:1390,y:479,t:1526922640843};\\\", \\\"{x:1382,y:479,t:1526922640860};\\\", \\\"{x:1375,y:479,t:1526922640876};\\\", \\\"{x:1368,y:479,t:1526922640893};\\\", \\\"{x:1360,y:479,t:1526922640910};\\\", \\\"{x:1352,y:479,t:1526922640926};\\\", \\\"{x:1341,y:479,t:1526922640943};\\\", \\\"{x:1331,y:479,t:1526922640960};\\\", \\\"{x:1314,y:479,t:1526922640977};\\\", \\\"{x:1304,y:481,t:1526922640993};\\\", \\\"{x:1294,y:485,t:1526922641010};\\\", \\\"{x:1287,y:488,t:1526922641028};\\\", \\\"{x:1285,y:489,t:1526922641044};\\\", \\\"{x:1284,y:490,t:1526922641065};\\\", \\\"{x:1283,y:490,t:1526922641081};\\\", \\\"{x:1283,y:491,t:1526922641093};\\\", \\\"{x:1281,y:493,t:1526922641110};\\\", \\\"{x:1280,y:494,t:1526922641128};\\\", \\\"{x:1280,y:495,t:1526922641143};\\\", \\\"{x:1279,y:496,t:1526922641160};\\\", \\\"{x:1279,y:498,t:1526922641250};\\\", \\\"{x:1282,y:498,t:1526922641261};\\\", \\\"{x:1287,y:499,t:1526922641277};\\\", \\\"{x:1292,y:499,t:1526922641293};\\\", \\\"{x:1297,y:500,t:1526922641310};\\\", \\\"{x:1300,y:500,t:1526922641327};\\\", \\\"{x:1301,y:500,t:1526922641343};\\\", \\\"{x:1302,y:500,t:1526922641433};\\\", \\\"{x:1303,y:500,t:1526922641443};\\\", \\\"{x:1304,y:500,t:1526922641460};\\\", \\\"{x:1305,y:500,t:1526922641477};\\\", \\\"{x:1307,y:500,t:1526922641494};\\\", \\\"{x:1309,y:500,t:1526922641511};\\\", \\\"{x:1310,y:500,t:1526922641529};\\\", \\\"{x:1311,y:500,t:1526922641544};\\\", \\\"{x:1312,y:500,t:1526922641559};\\\", \\\"{x:1313,y:500,t:1526922641672};\\\", \\\"{x:1307,y:500,t:1526922651122};\\\", \\\"{x:1296,y:503,t:1526922651135};\\\", \\\"{x:1273,y:509,t:1526922651150};\\\", \\\"{x:1244,y:513,t:1526922651168};\\\", \\\"{x:1141,y:513,t:1526922651185};\\\", \\\"{x:1061,y:513,t:1526922651201};\\\", \\\"{x:966,y:513,t:1526922651217};\\\", \\\"{x:864,y:513,t:1526922651234};\\\", \\\"{x:758,y:513,t:1526922651251};\\\", \\\"{x:650,y:515,t:1526922651268};\\\", \\\"{x:542,y:515,t:1526922651285};\\\", \\\"{x:448,y:515,t:1526922651300};\\\", \\\"{x:373,y:515,t:1526922651317};\\\", \\\"{x:306,y:515,t:1526922651334};\\\", \\\"{x:247,y:515,t:1526922651350};\\\", \\\"{x:188,y:523,t:1526922651369};\\\", \\\"{x:113,y:531,t:1526922651385};\\\", \\\"{x:65,y:539,t:1526922651401};\\\", \\\"{x:58,y:540,t:1526922651418};\\\", \\\"{x:57,y:540,t:1526922651487};\\\", \\\"{x:56,y:541,t:1526922651501};\\\", \\\"{x:55,y:543,t:1526922651518};\\\", \\\"{x:53,y:546,t:1526922651535};\\\", \\\"{x:51,y:551,t:1526922651552};\\\", \\\"{x:51,y:552,t:1526922651568};\\\", \\\"{x:52,y:554,t:1526922651608};\\\", \\\"{x:56,y:556,t:1526922651619};\\\", \\\"{x:69,y:558,t:1526922651635};\\\", \\\"{x:87,y:560,t:1526922651651};\\\", \\\"{x:114,y:560,t:1526922651667};\\\", \\\"{x:150,y:560,t:1526922651685};\\\", \\\"{x:204,y:559,t:1526922651702};\\\", \\\"{x:252,y:552,t:1526922651719};\\\", \\\"{x:294,y:546,t:1526922651736};\\\", \\\"{x:320,y:543,t:1526922651751};\\\", \\\"{x:323,y:542,t:1526922651768};\\\", \\\"{x:326,y:542,t:1526922651831};\\\", \\\"{x:329,y:541,t:1526922651840};\\\", \\\"{x:334,y:540,t:1526922651852};\\\", \\\"{x:349,y:536,t:1526922651868};\\\", \\\"{x:359,y:534,t:1526922651885};\\\", \\\"{x:362,y:533,t:1526922651902};\\\", \\\"{x:362,y:532,t:1526922651919};\\\", \\\"{x:364,y:531,t:1526922652049};\\\", \\\"{x:366,y:531,t:1526922652056};\\\", \\\"{x:367,y:531,t:1526922652069};\\\", \\\"{x:373,y:529,t:1526922652086};\\\", \\\"{x:376,y:528,t:1526922652103};\\\", \\\"{x:380,y:528,t:1526922652119};\\\", \\\"{x:383,y:528,t:1526922652135};\\\", \\\"{x:384,y:529,t:1526922652352};\\\", \\\"{x:384,y:535,t:1526922652369};\\\", \\\"{x:386,y:542,t:1526922652386};\\\", \\\"{x:399,y:557,t:1526922652402};\\\", \\\"{x:422,y:584,t:1526922652419};\\\", \\\"{x:443,y:607,t:1526922652437};\\\", \\\"{x:468,y:633,t:1526922652452};\\\", \\\"{x:479,y:647,t:1526922652469};\\\", \\\"{x:485,y:656,t:1526922652485};\\\", \\\"{x:486,y:661,t:1526922652502};\\\", \\\"{x:488,y:666,t:1526922652520};\\\", \\\"{x:489,y:673,t:1526922652536};\\\", \\\"{x:493,y:680,t:1526922652552};\\\", \\\"{x:494,y:684,t:1526922652569};\\\", \\\"{x:499,y:694,t:1526922652586};\\\", \\\"{x:502,y:702,t:1526922652602};\\\", \\\"{x:508,y:710,t:1526922652619};\\\", \\\"{x:512,y:715,t:1526922652637};\\\", \\\"{x:514,y:717,t:1526922652652};\\\", \\\"{x:515,y:718,t:1526922652669};\\\", \\\"{x:515,y:719,t:1526922652688};\\\", \\\"{x:515,y:721,t:1526922652711};\\\", \\\"{x:515,y:722,t:1526922652728};\\\", \\\"{x:515,y:724,t:1526922652744};\\\", \\\"{x:515,y:725,t:1526922652776};\\\" ] }, { \\\"rt\\\": 13451, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 279701, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"DKL3R\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -I -E -A \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:518,y:725,t:1526922657768};\\\", \\\"{x:538,y:725,t:1526922657776};\\\", \\\"{x:569,y:725,t:1526922657791};\\\", \\\"{x:694,y:725,t:1526922657807};\\\", \\\"{x:791,y:725,t:1526922657824};\\\", \\\"{x:919,y:726,t:1526922657840};\\\", \\\"{x:1066,y:730,t:1526922657856};\\\", \\\"{x:1205,y:735,t:1526922657873};\\\", \\\"{x:1335,y:735,t:1526922657890};\\\", \\\"{x:1448,y:735,t:1526922657908};\\\", \\\"{x:1543,y:735,t:1526922657923};\\\", \\\"{x:1611,y:732,t:1526922657940};\\\", \\\"{x:1662,y:723,t:1526922657957};\\\", \\\"{x:1697,y:714,t:1526922657973};\\\", \\\"{x:1715,y:707,t:1526922657990};\\\", \\\"{x:1720,y:706,t:1526922658008};\\\", \\\"{x:1721,y:705,t:1526922658056};\\\", \\\"{x:1721,y:704,t:1526922658064};\\\", \\\"{x:1720,y:702,t:1526922658074};\\\", \\\"{x:1710,y:695,t:1526922658091};\\\", \\\"{x:1697,y:688,t:1526922658108};\\\", \\\"{x:1678,y:680,t:1526922658125};\\\", \\\"{x:1654,y:672,t:1526922658141};\\\", \\\"{x:1633,y:666,t:1526922658157};\\\", \\\"{x:1620,y:661,t:1526922658175};\\\", \\\"{x:1609,y:658,t:1526922658191};\\\", \\\"{x:1606,y:657,t:1526922658208};\\\", \\\"{x:1604,y:656,t:1526922658224};\\\", \\\"{x:1603,y:656,t:1526922658241};\\\", \\\"{x:1601,y:655,t:1526922658258};\\\", \\\"{x:1599,y:654,t:1526922658275};\\\", \\\"{x:1593,y:651,t:1526922658291};\\\", \\\"{x:1589,y:650,t:1526922658308};\\\", \\\"{x:1579,y:649,t:1526922658325};\\\", \\\"{x:1569,y:649,t:1526922658342};\\\", \\\"{x:1555,y:647,t:1526922658358};\\\", \\\"{x:1537,y:647,t:1526922658374};\\\", \\\"{x:1501,y:647,t:1526922658392};\\\", \\\"{x:1474,y:647,t:1526922658408};\\\", \\\"{x:1452,y:648,t:1526922658424};\\\", \\\"{x:1437,y:651,t:1526922658442};\\\", \\\"{x:1425,y:652,t:1526922658459};\\\", \\\"{x:1416,y:654,t:1526922658475};\\\", \\\"{x:1408,y:657,t:1526922658492};\\\", \\\"{x:1399,y:661,t:1526922658508};\\\", \\\"{x:1385,y:668,t:1526922658525};\\\", \\\"{x:1371,y:673,t:1526922658542};\\\", \\\"{x:1358,y:679,t:1526922658559};\\\", \\\"{x:1350,y:683,t:1526922658575};\\\", \\\"{x:1341,y:690,t:1526922658592};\\\", \\\"{x:1337,y:694,t:1526922658609};\\\", \\\"{x:1332,y:697,t:1526922658625};\\\", \\\"{x:1331,y:700,t:1526922658642};\\\", \\\"{x:1327,y:705,t:1526922658659};\\\", \\\"{x:1320,y:712,t:1526922658674};\\\", \\\"{x:1315,y:718,t:1526922658692};\\\", \\\"{x:1310,y:721,t:1526922658709};\\\", \\\"{x:1306,y:725,t:1526922658725};\\\", \\\"{x:1303,y:728,t:1526922658742};\\\", \\\"{x:1300,y:731,t:1526922658759};\\\", \\\"{x:1294,y:740,t:1526922658776};\\\", \\\"{x:1290,y:744,t:1526922658793};\\\", \\\"{x:1286,y:750,t:1526922658808};\\\", \\\"{x:1282,y:756,t:1526922658826};\\\", \\\"{x:1278,y:761,t:1526922658842};\\\", \\\"{x:1273,y:767,t:1526922658859};\\\", \\\"{x:1269,y:771,t:1526922658876};\\\", \\\"{x:1266,y:774,t:1526922658892};\\\", \\\"{x:1263,y:779,t:1526922658909};\\\", \\\"{x:1259,y:783,t:1526922658926};\\\", \\\"{x:1255,y:788,t:1526922658942};\\\", \\\"{x:1252,y:791,t:1526922658958};\\\", \\\"{x:1248,y:795,t:1526922658977};\\\", \\\"{x:1247,y:797,t:1526922658992};\\\", \\\"{x:1244,y:799,t:1526922659009};\\\", \\\"{x:1241,y:800,t:1526922659026};\\\", \\\"{x:1238,y:801,t:1526922659042};\\\", \\\"{x:1235,y:804,t:1526922659059};\\\", \\\"{x:1233,y:807,t:1526922659076};\\\", \\\"{x:1228,y:809,t:1526922659093};\\\", \\\"{x:1223,y:811,t:1526922659109};\\\", \\\"{x:1218,y:812,t:1526922659126};\\\", \\\"{x:1213,y:812,t:1526922659144};\\\", \\\"{x:1208,y:814,t:1526922659160};\\\", \\\"{x:1203,y:814,t:1526922659176};\\\", \\\"{x:1201,y:814,t:1526922659193};\\\", \\\"{x:1199,y:814,t:1526922659209};\\\", \\\"{x:1198,y:814,t:1526922659256};\\\", \\\"{x:1197,y:813,t:1526922659272};\\\", \\\"{x:1196,y:812,t:1526922659296};\\\", \\\"{x:1195,y:811,t:1526922659310};\\\", \\\"{x:1195,y:810,t:1526922659328};\\\", \\\"{x:1194,y:808,t:1526922659343};\\\", \\\"{x:1194,y:807,t:1526922659360};\\\", \\\"{x:1194,y:805,t:1526922659376};\\\", \\\"{x:1193,y:804,t:1526922659393};\\\", \\\"{x:1192,y:802,t:1526922659410};\\\", \\\"{x:1191,y:800,t:1526922659426};\\\", \\\"{x:1189,y:797,t:1526922659443};\\\", \\\"{x:1189,y:795,t:1526922659459};\\\", \\\"{x:1188,y:793,t:1526922659477};\\\", \\\"{x:1187,y:791,t:1526922659493};\\\", \\\"{x:1186,y:787,t:1526922659509};\\\", \\\"{x:1185,y:784,t:1526922659527};\\\", \\\"{x:1185,y:780,t:1526922659543};\\\", \\\"{x:1184,y:776,t:1526922659560};\\\", \\\"{x:1184,y:774,t:1526922659577};\\\", \\\"{x:1183,y:771,t:1526922659593};\\\", \\\"{x:1183,y:770,t:1526922659610};\\\", \\\"{x:1183,y:769,t:1526922659640};\\\", \\\"{x:1183,y:768,t:1526922659667};\\\", \\\"{x:1182,y:767,t:1526922659694};\\\", \\\"{x:1182,y:766,t:1526922659713};\\\", \\\"{x:1182,y:765,t:1526922660393};\\\", \\\"{x:1182,y:764,t:1526922660912};\\\", \\\"{x:1183,y:763,t:1526922660928};\\\", \\\"{x:1186,y:760,t:1526922660945};\\\", \\\"{x:1190,y:756,t:1526922660963};\\\", \\\"{x:1193,y:753,t:1526922660979};\\\", \\\"{x:1197,y:750,t:1526922660995};\\\", \\\"{x:1200,y:747,t:1526922661012};\\\", \\\"{x:1203,y:744,t:1526922661029};\\\", \\\"{x:1206,y:742,t:1526922661046};\\\", \\\"{x:1209,y:739,t:1526922661062};\\\", \\\"{x:1212,y:736,t:1526922661079};\\\", \\\"{x:1220,y:729,t:1526922661095};\\\", \\\"{x:1223,y:726,t:1526922661112};\\\", \\\"{x:1230,y:722,t:1526922661129};\\\", \\\"{x:1236,y:718,t:1526922661146};\\\", \\\"{x:1246,y:711,t:1526922661161};\\\", \\\"{x:1252,y:707,t:1526922661178};\\\", \\\"{x:1260,y:702,t:1526922661196};\\\", \\\"{x:1264,y:697,t:1526922661212};\\\", \\\"{x:1272,y:691,t:1526922661229};\\\", \\\"{x:1274,y:689,t:1526922661246};\\\", \\\"{x:1278,y:685,t:1526922661263};\\\", \\\"{x:1282,y:681,t:1526922661278};\\\", \\\"{x:1287,y:675,t:1526922661296};\\\", \\\"{x:1292,y:670,t:1526922661312};\\\", \\\"{x:1295,y:667,t:1526922661328};\\\", \\\"{x:1297,y:664,t:1526922661346};\\\", \\\"{x:1298,y:663,t:1526922661363};\\\", \\\"{x:1299,y:663,t:1526922661379};\\\", \\\"{x:1300,y:662,t:1526922661395};\\\", \\\"{x:1301,y:661,t:1526922661412};\\\", \\\"{x:1301,y:660,t:1526922661429};\\\", \\\"{x:1303,y:658,t:1526922661446};\\\", \\\"{x:1305,y:657,t:1526922661463};\\\", \\\"{x:1307,y:656,t:1526922661481};\\\", \\\"{x:1309,y:654,t:1526922661496};\\\", \\\"{x:1310,y:654,t:1526922661513};\\\", \\\"{x:1311,y:653,t:1526922661530};\\\", \\\"{x:1313,y:653,t:1526922661546};\\\", \\\"{x:1313,y:652,t:1526922661576};\\\", \\\"{x:1314,y:651,t:1526922661608};\\\", \\\"{x:1314,y:650,t:1526922663217};\\\", \\\"{x:1311,y:646,t:1526922663232};\\\", \\\"{x:1308,y:643,t:1526922663248};\\\", \\\"{x:1302,y:635,t:1526922663265};\\\", \\\"{x:1297,y:630,t:1526922663282};\\\", \\\"{x:1295,y:627,t:1526922663299};\\\", \\\"{x:1292,y:624,t:1526922663315};\\\", \\\"{x:1292,y:621,t:1526922663331};\\\", \\\"{x:1289,y:618,t:1526922663349};\\\", \\\"{x:1289,y:616,t:1526922663365};\\\", \\\"{x:1289,y:613,t:1526922663382};\\\", \\\"{x:1288,y:610,t:1526922663399};\\\", \\\"{x:1287,y:608,t:1526922663416};\\\", \\\"{x:1286,y:606,t:1526922663433};\\\", \\\"{x:1285,y:603,t:1526922663449};\\\", \\\"{x:1285,y:600,t:1526922663466};\\\", \\\"{x:1283,y:596,t:1526922663483};\\\", \\\"{x:1282,y:593,t:1526922663499};\\\", \\\"{x:1282,y:589,t:1526922663516};\\\", \\\"{x:1279,y:586,t:1526922663534};\\\", \\\"{x:1279,y:585,t:1526922663549};\\\", \\\"{x:1279,y:583,t:1526922663566};\\\", \\\"{x:1279,y:582,t:1526922663593};\\\", \\\"{x:1279,y:581,t:1526922663600};\\\", \\\"{x:1279,y:580,t:1526922663615};\\\", \\\"{x:1279,y:578,t:1526922663633};\\\", \\\"{x:1279,y:576,t:1526922663649};\\\", \\\"{x:1278,y:575,t:1526922663666};\\\", \\\"{x:1278,y:573,t:1526922663683};\\\", \\\"{x:1278,y:572,t:1526922663699};\\\", \\\"{x:1278,y:570,t:1526922663716};\\\", \\\"{x:1278,y:569,t:1526922663735};\\\", \\\"{x:1278,y:567,t:1526922663751};\\\", \\\"{x:1278,y:566,t:1526922663783};\\\", \\\"{x:1278,y:565,t:1526922663800};\\\", \\\"{x:1278,y:564,t:1526922663816};\\\", \\\"{x:1281,y:584,t:1526922664817};\\\", \\\"{x:1294,y:683,t:1526922664834};\\\", \\\"{x:1319,y:796,t:1526922664851};\\\", \\\"{x:1356,y:905,t:1526922664868};\\\", \\\"{x:1416,y:1006,t:1526922664885};\\\", \\\"{x:1518,y:1090,t:1526922664901};\\\", \\\"{x:1653,y:1149,t:1526922664918};\\\", \\\"{x:1858,y:1181,t:1526922664935};\\\", \\\"{x:1883,y:0,t:1526922665177};\\\", \\\"{x:1741,y:11,t:1526922665185};\\\", \\\"{x:1506,y:49,t:1526922665202};\\\", \\\"{x:1334,y:112,t:1526922665217};\\\", \\\"{x:1236,y:163,t:1526922665235};\\\", \\\"{x:1205,y:201,t:1526922665253};\\\", \\\"{x:1202,y:223,t:1526922665268};\\\", \\\"{x:1211,y:250,t:1526922665286};\\\", \\\"{x:1233,y:288,t:1526922665302};\\\", \\\"{x:1269,y:327,t:1526922665319};\\\", \\\"{x:1312,y:360,t:1526922665335};\\\", \\\"{x:1372,y:397,t:1526922665352};\\\", \\\"{x:1404,y:412,t:1526922665368};\\\", \\\"{x:1423,y:421,t:1526922665385};\\\", \\\"{x:1428,y:425,t:1526922665402};\\\", \\\"{x:1427,y:429,t:1526922665449};\\\", \\\"{x:1419,y:432,t:1526922665457};\\\", \\\"{x:1405,y:437,t:1526922665470};\\\", \\\"{x:1353,y:447,t:1526922665485};\\\", \\\"{x:1259,y:463,t:1526922665502};\\\", \\\"{x:1147,y:481,t:1526922665519};\\\", \\\"{x:959,y:519,t:1526922665536};\\\", \\\"{x:840,y:550,t:1526922665554};\\\", \\\"{x:721,y:581,t:1526922665569};\\\", \\\"{x:630,y:609,t:1526922665586};\\\", \\\"{x:556,y:632,t:1526922665613};\\\", \\\"{x:543,y:640,t:1526922665630};\\\", \\\"{x:541,y:641,t:1526922665645};\\\", \\\"{x:542,y:641,t:1526922665728};\\\", \\\"{x:547,y:639,t:1526922665735};\\\", \\\"{x:554,y:634,t:1526922665747};\\\", \\\"{x:576,y:621,t:1526922665763};\\\", \\\"{x:613,y:602,t:1526922665779};\\\", \\\"{x:665,y:579,t:1526922665797};\\\", \\\"{x:732,y:550,t:1526922665814};\\\", \\\"{x:792,y:524,t:1526922665830};\\\", \\\"{x:823,y:511,t:1526922665847};\\\", \\\"{x:840,y:504,t:1526922665863};\\\", \\\"{x:841,y:504,t:1526922665944};\\\", \\\"{x:842,y:504,t:1526922665951};\\\", \\\"{x:843,y:504,t:1526922665964};\\\", \\\"{x:845,y:504,t:1526922665979};\\\", \\\"{x:846,y:504,t:1526922665996};\\\", \\\"{x:846,y:505,t:1526922666088};\\\", \\\"{x:846,y:506,t:1526922666096};\\\", \\\"{x:845,y:507,t:1526922666114};\\\", \\\"{x:842,y:510,t:1526922666130};\\\", \\\"{x:837,y:512,t:1526922666147};\\\", \\\"{x:834,y:514,t:1526922666164};\\\", \\\"{x:831,y:515,t:1526922666179};\\\", \\\"{x:829,y:516,t:1526922666196};\\\", \\\"{x:827,y:516,t:1526922666213};\\\", \\\"{x:824,y:516,t:1526922666230};\\\", \\\"{x:818,y:516,t:1526922666246};\\\", \\\"{x:809,y:516,t:1526922666263};\\\", \\\"{x:802,y:516,t:1526922666280};\\\", \\\"{x:792,y:516,t:1526922666296};\\\", \\\"{x:776,y:516,t:1526922666313};\\\", \\\"{x:750,y:516,t:1526922666331};\\\", \\\"{x:727,y:516,t:1526922666347};\\\", \\\"{x:705,y:516,t:1526922666365};\\\", \\\"{x:689,y:516,t:1526922666381};\\\", \\\"{x:683,y:516,t:1526922666397};\\\", \\\"{x:682,y:513,t:1526922666585};\\\", \\\"{x:681,y:513,t:1526922666597};\\\", \\\"{x:673,y:512,t:1526922666614};\\\", \\\"{x:667,y:511,t:1526922666630};\\\", \\\"{x:662,y:510,t:1526922666647};\\\", \\\"{x:661,y:510,t:1526922666664};\\\", \\\"{x:660,y:510,t:1526922666681};\\\", \\\"{x:659,y:509,t:1526922666698};\\\", \\\"{x:657,y:508,t:1526922666713};\\\", \\\"{x:653,y:508,t:1526922666731};\\\", \\\"{x:644,y:505,t:1526922666748};\\\", \\\"{x:634,y:504,t:1526922666765};\\\", \\\"{x:626,y:503,t:1526922666780};\\\", \\\"{x:620,y:502,t:1526922666798};\\\", \\\"{x:617,y:502,t:1526922666814};\\\", \\\"{x:616,y:502,t:1526922666830};\\\", \\\"{x:614,y:501,t:1526922666847};\\\", \\\"{x:613,y:501,t:1526922667152};\\\", \\\"{x:612,y:500,t:1526922667192};\\\", \\\"{x:612,y:501,t:1526922667407};\\\", \\\"{x:622,y:504,t:1526922667415};\\\", \\\"{x:640,y:509,t:1526922667431};\\\", \\\"{x:721,y:523,t:1526922667448};\\\", \\\"{x:760,y:528,t:1526922667465};\\\", \\\"{x:784,y:531,t:1526922667480};\\\", \\\"{x:792,y:534,t:1526922667497};\\\", \\\"{x:793,y:534,t:1526922667543};\\\", \\\"{x:794,y:534,t:1526922667559};\\\", \\\"{x:796,y:535,t:1526922667568};\\\", \\\"{x:799,y:536,t:1526922667581};\\\", \\\"{x:805,y:537,t:1526922667598};\\\", \\\"{x:810,y:537,t:1526922667614};\\\", \\\"{x:812,y:537,t:1526922667630};\\\", \\\"{x:813,y:537,t:1526922667647};\\\", \\\"{x:814,y:538,t:1526922667665};\\\", \\\"{x:815,y:538,t:1526922667681};\\\", \\\"{x:816,y:538,t:1526922667698};\\\", \\\"{x:820,y:538,t:1526922667715};\\\", \\\"{x:823,y:539,t:1526922667731};\\\", \\\"{x:825,y:539,t:1526922667748};\\\", \\\"{x:826,y:540,t:1526922667765};\\\", \\\"{x:827,y:540,t:1526922667882};\\\", \\\"{x:827,y:540,t:1526922667947};\\\", \\\"{x:825,y:541,t:1526922668000};\\\", \\\"{x:818,y:545,t:1526922668015};\\\", \\\"{x:798,y:562,t:1526922668031};\\\", \\\"{x:777,y:577,t:1526922668049};\\\", \\\"{x:750,y:594,t:1526922668065};\\\", \\\"{x:708,y:624,t:1526922668082};\\\", \\\"{x:668,y:653,t:1526922668099};\\\", \\\"{x:644,y:671,t:1526922668114};\\\", \\\"{x:630,y:683,t:1526922668132};\\\", \\\"{x:623,y:688,t:1526922668149};\\\", \\\"{x:620,y:692,t:1526922668164};\\\", \\\"{x:619,y:694,t:1526922668181};\\\", \\\"{x:617,y:697,t:1526922668198};\\\", \\\"{x:613,y:704,t:1526922668214};\\\", \\\"{x:599,y:721,t:1526922668231};\\\", \\\"{x:579,y:735,t:1526922668249};\\\", \\\"{x:556,y:750,t:1526922668266};\\\", \\\"{x:533,y:762,t:1526922668283};\\\", \\\"{x:517,y:769,t:1526922668298};\\\", \\\"{x:510,y:773,t:1526922668315};\\\", \\\"{x:506,y:773,t:1526922668331};\\\", \\\"{x:505,y:774,t:1526922668348};\\\", \\\"{x:504,y:775,t:1526922668365};\\\", \\\"{x:502,y:776,t:1526922668382};\\\", \\\"{x:501,y:776,t:1526922668399};\\\", \\\"{x:500,y:776,t:1526922668415};\\\", \\\"{x:499,y:775,t:1526922668488};\\\", \\\"{x:500,y:772,t:1526922668499};\\\", \\\"{x:504,y:765,t:1526922668516};\\\", \\\"{x:509,y:758,t:1526922668532};\\\", \\\"{x:511,y:756,t:1526922668549};\\\", \\\"{x:513,y:754,t:1526922668567};\\\", \\\"{x:514,y:750,t:1526922668582};\\\", \\\"{x:516,y:745,t:1526922668599};\\\", \\\"{x:517,y:740,t:1526922668616};\\\", \\\"{x:518,y:732,t:1526922668634};\\\", \\\"{x:519,y:727,t:1526922668649};\\\", \\\"{x:520,y:725,t:1526922668666};\\\" ] }, { \\\"rt\\\": 49247, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 330174, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"DKL3R\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -Z -Z -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:520,y:716,t:1526922670704};\\\", \\\"{x:518,y:695,t:1526922670717};\\\", \\\"{x:502,y:644,t:1526922670734};\\\", \\\"{x:481,y:602,t:1526922670750};\\\", \\\"{x:469,y:575,t:1526922670768};\\\", \\\"{x:451,y:553,t:1526922670784};\\\", \\\"{x:446,y:544,t:1526922670800};\\\", \\\"{x:439,y:535,t:1526922670817};\\\", \\\"{x:436,y:528,t:1526922670833};\\\", \\\"{x:433,y:525,t:1526922670850};\\\", \\\"{x:429,y:521,t:1526922670867};\\\", \\\"{x:426,y:519,t:1526922670884};\\\", \\\"{x:423,y:515,t:1526922670901};\\\", \\\"{x:418,y:511,t:1526922670916};\\\", \\\"{x:409,y:504,t:1526922670934};\\\", \\\"{x:403,y:500,t:1526922670951};\\\", \\\"{x:388,y:491,t:1526922670967};\\\", \\\"{x:376,y:486,t:1526922670984};\\\", \\\"{x:367,y:484,t:1526922671001};\\\", \\\"{x:354,y:480,t:1526922671017};\\\", \\\"{x:337,y:475,t:1526922671034};\\\", \\\"{x:323,y:473,t:1526922671051};\\\", \\\"{x:318,y:470,t:1526922671068};\\\", \\\"{x:318,y:469,t:1526922671249};\\\", \\\"{x:321,y:467,t:1526922671256};\\\", \\\"{x:324,y:466,t:1526922671268};\\\", \\\"{x:327,y:466,t:1526922671284};\\\", \\\"{x:334,y:466,t:1526922671301};\\\", \\\"{x:341,y:465,t:1526922671318};\\\", \\\"{x:344,y:465,t:1526922671334};\\\", \\\"{x:348,y:465,t:1526922671352};\\\", \\\"{x:354,y:463,t:1526922671368};\\\", \\\"{x:361,y:462,t:1526922671384};\\\", \\\"{x:371,y:462,t:1526922671401};\\\", \\\"{x:378,y:462,t:1526922671420};\\\", \\\"{x:388,y:462,t:1526922671434};\\\", \\\"{x:399,y:462,t:1526922671451};\\\", \\\"{x:404,y:461,t:1526922671468};\\\", \\\"{x:411,y:459,t:1526922671484};\\\", \\\"{x:415,y:459,t:1526922671501};\\\", \\\"{x:419,y:459,t:1526922671518};\\\", \\\"{x:423,y:459,t:1526922671534};\\\", \\\"{x:427,y:459,t:1526922671551};\\\", \\\"{x:432,y:459,t:1526922671568};\\\", \\\"{x:434,y:459,t:1526922671584};\\\", \\\"{x:437,y:458,t:1526922671601};\\\", \\\"{x:439,y:458,t:1526922671619};\\\", \\\"{x:442,y:458,t:1526922671635};\\\", \\\"{x:444,y:458,t:1526922671651};\\\", \\\"{x:447,y:458,t:1526922671668};\\\", \\\"{x:450,y:458,t:1526922671684};\\\", \\\"{x:452,y:458,t:1526922671701};\\\", \\\"{x:453,y:458,t:1526922671718};\\\", \\\"{x:455,y:458,t:1526922671734};\\\", \\\"{x:456,y:458,t:1526922671760};\\\", \\\"{x:458,y:458,t:1526922671800};\\\", \\\"{x:459,y:458,t:1526922671849};\\\", \\\"{x:461,y:458,t:1526922671912};\\\", \\\"{x:468,y:458,t:1526922681520};\\\", \\\"{x:479,y:461,t:1526922681527};\\\", \\\"{x:494,y:468,t:1526922681539};\\\", \\\"{x:517,y:484,t:1526922681556};\\\", \\\"{x:547,y:501,t:1526922681574};\\\", \\\"{x:591,y:528,t:1526922681590};\\\", \\\"{x:659,y:566,t:1526922681605};\\\", \\\"{x:737,y:604,t:1526922681621};\\\", \\\"{x:826,y:641,t:1526922681637};\\\", \\\"{x:998,y:693,t:1526922681660};\\\", \\\"{x:1128,y:716,t:1526922681676};\\\", \\\"{x:1248,y:733,t:1526922681692};\\\", \\\"{x:1364,y:733,t:1526922681709};\\\", \\\"{x:1462,y:726,t:1526922681726};\\\", \\\"{x:1591,y:698,t:1526922681743};\\\", \\\"{x:1641,y:677,t:1526922681759};\\\", \\\"{x:1684,y:654,t:1526922681776};\\\", \\\"{x:1719,y:624,t:1526922681793};\\\", \\\"{x:1748,y:597,t:1526922681809};\\\", \\\"{x:1764,y:574,t:1526922681826};\\\", \\\"{x:1776,y:547,t:1526922681843};\\\", \\\"{x:1778,y:525,t:1526922681859};\\\", \\\"{x:1778,y:512,t:1526922681876};\\\", \\\"{x:1769,y:496,t:1526922681894};\\\", \\\"{x:1754,y:479,t:1526922681910};\\\", \\\"{x:1729,y:464,t:1526922681926};\\\", \\\"{x:1685,y:448,t:1526922681944};\\\", \\\"{x:1654,y:443,t:1526922681960};\\\", \\\"{x:1616,y:442,t:1526922681977};\\\", \\\"{x:1572,y:442,t:1526922681994};\\\", \\\"{x:1516,y:447,t:1526922682011};\\\", \\\"{x:1475,y:457,t:1526922682026};\\\", \\\"{x:1442,y:467,t:1526922682043};\\\", \\\"{x:1412,y:480,t:1526922682061};\\\", \\\"{x:1384,y:497,t:1526922682076};\\\", \\\"{x:1360,y:513,t:1526922682094};\\\", \\\"{x:1339,y:531,t:1526922682110};\\\", \\\"{x:1316,y:552,t:1526922682126};\\\", \\\"{x:1292,y:574,t:1526922682144};\\\", \\\"{x:1283,y:587,t:1526922682160};\\\", \\\"{x:1274,y:598,t:1526922682178};\\\", \\\"{x:1268,y:606,t:1526922682193};\\\", \\\"{x:1265,y:614,t:1526922682211};\\\", \\\"{x:1264,y:622,t:1526922682228};\\\", \\\"{x:1263,y:634,t:1526922682243};\\\", \\\"{x:1263,y:643,t:1526922682261};\\\", \\\"{x:1261,y:655,t:1526922682278};\\\", \\\"{x:1259,y:666,t:1526922682294};\\\", \\\"{x:1258,y:676,t:1526922682311};\\\", \\\"{x:1258,y:681,t:1526922682328};\\\", \\\"{x:1258,y:685,t:1526922682344};\\\", \\\"{x:1258,y:687,t:1526922682360};\\\", \\\"{x:1258,y:688,t:1526922682378};\\\", \\\"{x:1257,y:688,t:1526922682416};\\\", \\\"{x:1257,y:690,t:1526922683272};\\\", \\\"{x:1257,y:696,t:1526922683280};\\\", \\\"{x:1255,y:702,t:1526922683296};\\\", \\\"{x:1254,y:706,t:1526922683312};\\\", \\\"{x:1252,y:709,t:1526922683329};\\\", \\\"{x:1251,y:711,t:1526922683345};\\\", \\\"{x:1251,y:713,t:1526922683363};\\\", \\\"{x:1251,y:716,t:1526922683379};\\\", \\\"{x:1251,y:718,t:1526922683396};\\\", \\\"{x:1251,y:722,t:1526922683413};\\\", \\\"{x:1249,y:724,t:1526922683429};\\\", \\\"{x:1249,y:726,t:1526922683446};\\\", \\\"{x:1249,y:727,t:1526922683463};\\\", \\\"{x:1249,y:728,t:1526922683479};\\\", \\\"{x:1249,y:729,t:1526922683496};\\\", \\\"{x:1249,y:730,t:1526922683528};\\\", \\\"{x:1249,y:731,t:1526922683544};\\\", \\\"{x:1249,y:732,t:1526922683560};\\\", \\\"{x:1249,y:733,t:1526922683576};\\\", \\\"{x:1249,y:734,t:1526922683584};\\\", \\\"{x:1249,y:735,t:1526922683624};\\\", \\\"{x:1249,y:736,t:1526922683696};\\\", \\\"{x:1250,y:737,t:1526922683719};\\\", \\\"{x:1251,y:738,t:1526922683736};\\\", \\\"{x:1252,y:738,t:1526922683759};\\\", \\\"{x:1254,y:739,t:1526922683776};\\\", \\\"{x:1255,y:739,t:1526922683784};\\\", \\\"{x:1256,y:740,t:1526922683797};\\\", \\\"{x:1258,y:740,t:1526922683813};\\\", \\\"{x:1261,y:741,t:1526922683829};\\\", \\\"{x:1264,y:742,t:1526922683847};\\\", \\\"{x:1268,y:743,t:1526922683864};\\\", \\\"{x:1273,y:745,t:1526922683879};\\\", \\\"{x:1275,y:745,t:1526922683897};\\\", \\\"{x:1275,y:746,t:1526922683914};\\\", \\\"{x:1278,y:746,t:1526922683929};\\\", \\\"{x:1279,y:747,t:1526922683947};\\\", \\\"{x:1281,y:747,t:1526922683964};\\\", \\\"{x:1282,y:748,t:1526922683980};\\\", \\\"{x:1285,y:749,t:1526922683997};\\\", \\\"{x:1289,y:749,t:1526922684013};\\\", \\\"{x:1290,y:750,t:1526922684030};\\\", \\\"{x:1292,y:750,t:1526922684046};\\\", \\\"{x:1292,y:751,t:1526922684080};\\\", \\\"{x:1293,y:751,t:1526922684097};\\\", \\\"{x:1295,y:752,t:1526922684120};\\\", \\\"{x:1296,y:753,t:1526922684185};\\\", \\\"{x:1296,y:754,t:1526922684240};\\\", \\\"{x:1297,y:755,t:1526922684264};\\\", \\\"{x:1298,y:758,t:1526922684281};\\\", \\\"{x:1299,y:758,t:1526922684298};\\\", \\\"{x:1299,y:759,t:1526922684314};\\\", \\\"{x:1300,y:761,t:1526922684331};\\\", \\\"{x:1301,y:763,t:1526922684368};\\\", \\\"{x:1301,y:764,t:1526922684416};\\\", \\\"{x:1302,y:765,t:1526922684448};\\\", \\\"{x:1303,y:766,t:1526922684464};\\\", \\\"{x:1304,y:768,t:1526922684481};\\\", \\\"{x:1305,y:768,t:1526922684498};\\\", \\\"{x:1307,y:769,t:1526922684515};\\\", \\\"{x:1308,y:770,t:1526922684536};\\\", \\\"{x:1309,y:770,t:1526922684548};\\\", \\\"{x:1310,y:771,t:1526922684565};\\\", \\\"{x:1313,y:771,t:1526922684581};\\\", \\\"{x:1316,y:772,t:1526922684598};\\\", \\\"{x:1319,y:772,t:1526922684615};\\\", \\\"{x:1323,y:772,t:1526922684632};\\\", \\\"{x:1327,y:772,t:1526922684648};\\\", \\\"{x:1328,y:772,t:1526922684712};\\\", \\\"{x:1329,y:772,t:1526922684720};\\\", \\\"{x:1330,y:772,t:1526922684732};\\\", \\\"{x:1335,y:772,t:1526922684748};\\\", \\\"{x:1340,y:772,t:1526922684765};\\\", \\\"{x:1345,y:770,t:1526922684782};\\\", \\\"{x:1348,y:769,t:1526922684798};\\\", \\\"{x:1350,y:767,t:1526922684817};\\\", \\\"{x:1351,y:767,t:1526922684952};\\\", \\\"{x:1352,y:767,t:1526922684984};\\\", \\\"{x:1353,y:766,t:1526922685009};\\\", \\\"{x:1354,y:766,t:1526922685016};\\\", \\\"{x:1354,y:765,t:1526922685032};\\\", \\\"{x:1354,y:763,t:1526922689651};\\\", \\\"{x:1354,y:761,t:1526922689659};\\\", \\\"{x:1351,y:755,t:1526922689676};\\\", \\\"{x:1347,y:750,t:1526922689694};\\\", \\\"{x:1341,y:744,t:1526922689710};\\\", \\\"{x:1335,y:739,t:1526922689726};\\\", \\\"{x:1328,y:735,t:1526922689743};\\\", \\\"{x:1322,y:730,t:1526922689759};\\\", \\\"{x:1316,y:724,t:1526922689776};\\\", \\\"{x:1309,y:720,t:1526922689793};\\\", \\\"{x:1304,y:716,t:1526922689809};\\\", \\\"{x:1299,y:712,t:1526922689826};\\\", \\\"{x:1291,y:705,t:1526922689843};\\\", \\\"{x:1286,y:700,t:1526922689860};\\\", \\\"{x:1281,y:694,t:1526922689877};\\\", \\\"{x:1277,y:689,t:1526922689893};\\\", \\\"{x:1270,y:684,t:1526922689911};\\\", \\\"{x:1267,y:680,t:1526922689926};\\\", \\\"{x:1264,y:677,t:1526922689943};\\\", \\\"{x:1263,y:676,t:1526922689960};\\\", \\\"{x:1262,y:675,t:1526922689976};\\\", \\\"{x:1262,y:674,t:1526922689993};\\\", \\\"{x:1262,y:670,t:1526922690010};\\\", \\\"{x:1264,y:666,t:1526922690026};\\\", \\\"{x:1267,y:660,t:1526922690043};\\\", \\\"{x:1269,y:657,t:1526922690060};\\\", \\\"{x:1269,y:656,t:1526922690076};\\\", \\\"{x:1271,y:655,t:1526922690093};\\\", \\\"{x:1273,y:653,t:1526922690110};\\\", \\\"{x:1274,y:652,t:1526922690131};\\\", \\\"{x:1275,y:652,t:1526922690144};\\\", \\\"{x:1276,y:651,t:1526922690160};\\\", \\\"{x:1277,y:650,t:1526922690178};\\\", \\\"{x:1278,y:650,t:1526922690267};\\\", \\\"{x:1279,y:650,t:1526922690516};\\\", \\\"{x:1280,y:649,t:1526922690528};\\\", \\\"{x:1281,y:649,t:1526922692203};\\\", \\\"{x:1284,y:647,t:1526922692214};\\\", \\\"{x:1291,y:647,t:1526922692231};\\\", \\\"{x:1296,y:646,t:1526922692247};\\\", \\\"{x:1303,y:646,t:1526922692264};\\\", \\\"{x:1309,y:646,t:1526922692280};\\\", \\\"{x:1314,y:645,t:1526922692298};\\\", \\\"{x:1318,y:645,t:1526922692314};\\\", \\\"{x:1323,y:645,t:1526922692331};\\\", \\\"{x:1339,y:645,t:1526922692347};\\\", \\\"{x:1357,y:645,t:1526922692364};\\\", \\\"{x:1380,y:645,t:1526922692380};\\\", \\\"{x:1406,y:645,t:1526922692398};\\\", \\\"{x:1429,y:642,t:1526922692415};\\\", \\\"{x:1450,y:642,t:1526922692431};\\\", \\\"{x:1463,y:642,t:1526922692448};\\\", \\\"{x:1472,y:642,t:1526922692465};\\\", \\\"{x:1476,y:642,t:1526922692481};\\\", \\\"{x:1477,y:642,t:1526922692571};\\\", \\\"{x:1479,y:642,t:1526922692604};\\\", \\\"{x:1480,y:642,t:1526922692644};\\\", \\\"{x:1481,y:642,t:1526922692668};\\\", \\\"{x:1482,y:642,t:1526922692682};\\\", \\\"{x:1486,y:642,t:1526922692698};\\\", \\\"{x:1490,y:641,t:1526922692715};\\\", \\\"{x:1494,y:640,t:1526922692732};\\\", \\\"{x:1499,y:640,t:1526922692748};\\\", \\\"{x:1504,y:639,t:1526922692765};\\\", \\\"{x:1509,y:639,t:1526922692782};\\\", \\\"{x:1515,y:639,t:1526922692798};\\\", \\\"{x:1519,y:638,t:1526922692815};\\\", \\\"{x:1523,y:638,t:1526922692832};\\\", \\\"{x:1525,y:638,t:1526922692849};\\\", \\\"{x:1527,y:638,t:1526922692865};\\\", \\\"{x:1529,y:638,t:1526922692881};\\\", \\\"{x:1530,y:638,t:1526922692906};\\\", \\\"{x:1531,y:638,t:1526922692923};\\\", \\\"{x:1532,y:638,t:1526922692931};\\\", \\\"{x:1533,y:638,t:1526922692954};\\\", \\\"{x:1534,y:637,t:1526922692979};\\\", \\\"{x:1540,y:639,t:1526922696220};\\\", \\\"{x:1549,y:644,t:1526922696237};\\\", \\\"{x:1560,y:649,t:1526922696254};\\\", \\\"{x:1568,y:651,t:1526922696271};\\\", \\\"{x:1572,y:653,t:1526922696287};\\\", \\\"{x:1576,y:654,t:1526922696304};\\\", \\\"{x:1579,y:654,t:1526922696322};\\\", \\\"{x:1581,y:656,t:1526922696337};\\\", \\\"{x:1583,y:658,t:1526922696354};\\\", \\\"{x:1590,y:661,t:1526922696372};\\\", \\\"{x:1594,y:665,t:1526922696387};\\\", \\\"{x:1599,y:668,t:1526922696404};\\\", \\\"{x:1602,y:671,t:1526922696421};\\\", \\\"{x:1604,y:672,t:1526922696438};\\\", \\\"{x:1605,y:672,t:1526922696454};\\\", \\\"{x:1609,y:674,t:1526922696471};\\\", \\\"{x:1610,y:675,t:1526922696488};\\\", \\\"{x:1612,y:676,t:1526922696504};\\\", \\\"{x:1613,y:678,t:1526922696521};\\\", \\\"{x:1614,y:679,t:1526922696538};\\\", \\\"{x:1616,y:680,t:1526922696554};\\\", \\\"{x:1618,y:682,t:1526922696572};\\\", \\\"{x:1619,y:683,t:1526922696588};\\\", \\\"{x:1620,y:684,t:1526922696605};\\\", \\\"{x:1621,y:685,t:1526922696621};\\\", \\\"{x:1623,y:687,t:1526922696637};\\\", \\\"{x:1624,y:687,t:1526922696654};\\\", \\\"{x:1626,y:689,t:1526922696670};\\\", \\\"{x:1626,y:690,t:1526922696687};\\\", \\\"{x:1627,y:691,t:1526922696704};\\\", \\\"{x:1628,y:691,t:1526922696721};\\\", \\\"{x:1628,y:692,t:1526922696738};\\\", \\\"{x:1629,y:692,t:1526922696778};\\\", \\\"{x:1629,y:693,t:1526922696795};\\\", \\\"{x:1630,y:693,t:1526922696859};\\\", \\\"{x:1631,y:694,t:1526922697035};\\\", \\\"{x:1631,y:695,t:1526922697076};\\\", \\\"{x:1631,y:696,t:1526922697100};\\\", \\\"{x:1631,y:697,t:1526922697115};\\\", \\\"{x:1630,y:697,t:1526922697139};\\\", \\\"{x:1630,y:698,t:1526922697155};\\\", \\\"{x:1629,y:698,t:1526922697187};\\\", \\\"{x:1628,y:698,t:1526922697195};\\\", \\\"{x:1627,y:698,t:1526922697206};\\\", \\\"{x:1625,y:698,t:1526922697223};\\\", \\\"{x:1624,y:698,t:1526922697239};\\\", \\\"{x:1623,y:698,t:1526922697256};\\\", \\\"{x:1622,y:698,t:1526922697272};\\\", \\\"{x:1621,y:698,t:1526922697340};\\\", \\\"{x:1620,y:697,t:1526922697372};\\\", \\\"{x:1619,y:696,t:1526922697435};\\\", \\\"{x:1618,y:696,t:1526922697460};\\\", \\\"{x:1617,y:696,t:1526922697628};\\\", \\\"{x:1616,y:695,t:1526922697640};\\\", \\\"{x:1615,y:695,t:1526922697731};\\\", \\\"{x:1615,y:694,t:1526922698244};\\\", \\\"{x:1614,y:693,t:1526922703404};\\\", \\\"{x:1606,y:693,t:1526922703417};\\\", \\\"{x:1585,y:695,t:1526922703432};\\\", \\\"{x:1565,y:697,t:1526922703449};\\\", \\\"{x:1543,y:701,t:1526922703466};\\\", \\\"{x:1498,y:708,t:1526922703482};\\\", \\\"{x:1407,y:720,t:1526922703499};\\\", \\\"{x:1365,y:725,t:1526922703515};\\\", \\\"{x:1342,y:731,t:1526922703532};\\\", \\\"{x:1321,y:734,t:1526922703549};\\\", \\\"{x:1308,y:736,t:1526922703566};\\\", \\\"{x:1303,y:737,t:1526922703582};\\\", \\\"{x:1298,y:740,t:1526922703599};\\\", \\\"{x:1295,y:741,t:1526922703616};\\\", \\\"{x:1294,y:742,t:1526922703632};\\\", \\\"{x:1293,y:743,t:1526922703649};\\\", \\\"{x:1292,y:744,t:1526922703666};\\\", \\\"{x:1291,y:745,t:1526922703682};\\\", \\\"{x:1290,y:747,t:1526922703698};\\\", \\\"{x:1289,y:748,t:1526922703716};\\\", \\\"{x:1289,y:749,t:1526922703803};\\\", \\\"{x:1289,y:751,t:1526922703826};\\\", \\\"{x:1290,y:752,t:1526922703842};\\\", \\\"{x:1290,y:753,t:1526922703850};\\\", \\\"{x:1291,y:753,t:1526922703866};\\\", \\\"{x:1296,y:755,t:1526922703883};\\\", \\\"{x:1301,y:756,t:1526922703900};\\\", \\\"{x:1305,y:757,t:1526922703915};\\\", \\\"{x:1309,y:759,t:1526922703932};\\\", \\\"{x:1311,y:759,t:1526922703949};\\\", \\\"{x:1314,y:759,t:1526922703966};\\\", \\\"{x:1316,y:759,t:1526922704044};\\\", \\\"{x:1317,y:759,t:1526922704132};\\\", \\\"{x:1319,y:759,t:1526922704150};\\\", \\\"{x:1320,y:759,t:1526922704167};\\\", \\\"{x:1323,y:759,t:1526922704182};\\\", \\\"{x:1326,y:759,t:1526922704200};\\\", \\\"{x:1328,y:759,t:1526922704217};\\\", \\\"{x:1329,y:759,t:1526922704233};\\\", \\\"{x:1331,y:759,t:1526922704250};\\\", \\\"{x:1332,y:759,t:1526922704267};\\\", \\\"{x:1333,y:759,t:1526922704340};\\\", \\\"{x:1334,y:759,t:1526922704571};\\\", \\\"{x:1335,y:759,t:1526922704650};\\\", \\\"{x:1335,y:760,t:1526922705803};\\\", \\\"{x:1336,y:760,t:1526922705923};\\\", \\\"{x:1337,y:760,t:1526922705987};\\\", \\\"{x:1338,y:760,t:1526922706044};\\\", \\\"{x:1338,y:761,t:1526922706053};\\\", \\\"{x:1339,y:762,t:1526922713227};\\\", \\\"{x:1340,y:762,t:1526922713243};\\\", \\\"{x:1342,y:762,t:1526922713259};\\\", \\\"{x:1343,y:763,t:1526922713667};\\\", \\\"{x:1343,y:764,t:1526922713931};\\\", \\\"{x:1343,y:774,t:1526922713940};\\\", \\\"{x:1343,y:783,t:1526922713950};\\\", \\\"{x:1350,y:817,t:1526922713967};\\\", \\\"{x:1386,y:882,t:1526922713982};\\\", \\\"{x:1450,y:961,t:1526922714000};\\\", \\\"{x:1533,y:1041,t:1526922714017};\\\", \\\"{x:1644,y:1117,t:1526922714032};\\\", \\\"{x:1788,y:1188,t:1526922714050};\\\", \\\"{x:1872,y:1199,t:1526922714059};\\\", \\\"{x:1816,y:0,t:1526922714356};\\\", \\\"{x:1523,y:0,t:1526922714374};\\\", \\\"{x:1212,y:0,t:1526922714389};\\\", \\\"{x:935,y:6,t:1526922714406};\\\", \\\"{x:682,y:37,t:1526922714424};\\\", \\\"{x:489,y:60,t:1526922714440};\\\", \\\"{x:327,y:93,t:1526922714456};\\\", \\\"{x:191,y:134,t:1526922714473};\\\", \\\"{x:110,y:172,t:1526922714490};\\\", \\\"{x:60,y:217,t:1526922714507};\\\", \\\"{x:45,y:241,t:1526922714523};\\\", \\\"{x:36,y:261,t:1526922714539};\\\", \\\"{x:27,y:288,t:1526922714557};\\\", \\\"{x:19,y:315,t:1526922714573};\\\", \\\"{x:14,y:337,t:1526922714589};\\\", \\\"{x:13,y:350,t:1526922714607};\\\", \\\"{x:13,y:358,t:1526922714623};\\\", \\\"{x:13,y:366,t:1526922714640};\\\", \\\"{x:13,y:371,t:1526922714657};\\\", \\\"{x:13,y:379,t:1526922714673};\\\", \\\"{x:13,y:391,t:1526922714691};\\\", \\\"{x:16,y:400,t:1526922714707};\\\", \\\"{x:18,y:410,t:1526922714723};\\\", \\\"{x:22,y:422,t:1526922714741};\\\", \\\"{x:26,y:431,t:1526922714756};\\\", \\\"{x:27,y:437,t:1526922714773};\\\", \\\"{x:32,y:444,t:1526922714791};\\\", \\\"{x:38,y:453,t:1526922714807};\\\", \\\"{x:48,y:464,t:1526922714823};\\\", \\\"{x:60,y:478,t:1526922714840};\\\", \\\"{x:78,y:490,t:1526922714858};\\\", \\\"{x:93,y:500,t:1526922714872};\\\", \\\"{x:115,y:509,t:1526922714889};\\\", \\\"{x:130,y:510,t:1526922714906};\\\", \\\"{x:146,y:514,t:1526922714923};\\\", \\\"{x:161,y:519,t:1526922714940};\\\", \\\"{x:177,y:524,t:1526922714956};\\\", \\\"{x:184,y:525,t:1526922714973};\\\", \\\"{x:186,y:525,t:1526922714989};\\\", \\\"{x:188,y:526,t:1526922715006};\\\", \\\"{x:190,y:526,t:1526922715023};\\\", \\\"{x:195,y:527,t:1526922715040};\\\", \\\"{x:198,y:529,t:1526922715056};\\\", \\\"{x:206,y:530,t:1526922715073};\\\", \\\"{x:220,y:532,t:1526922715090};\\\", \\\"{x:227,y:533,t:1526922715107};\\\", \\\"{x:236,y:534,t:1526922715123};\\\", \\\"{x:245,y:536,t:1526922715140};\\\", \\\"{x:250,y:537,t:1526922715156};\\\", \\\"{x:254,y:537,t:1526922715173};\\\", \\\"{x:261,y:540,t:1526922715190};\\\", \\\"{x:263,y:540,t:1526922715206};\\\", \\\"{x:268,y:540,t:1526922715223};\\\", \\\"{x:270,y:540,t:1526922715242};\\\", \\\"{x:271,y:541,t:1526922715257};\\\", \\\"{x:272,y:541,t:1526922715273};\\\", \\\"{x:274,y:541,t:1526922715292};\\\", \\\"{x:275,y:542,t:1526922715307};\\\", \\\"{x:277,y:542,t:1526922715322};\\\", \\\"{x:278,y:542,t:1526922715340};\\\", \\\"{x:280,y:542,t:1526922715356};\\\", \\\"{x:281,y:542,t:1526922715373};\\\", \\\"{x:282,y:543,t:1526922715390};\\\", \\\"{x:283,y:543,t:1526922715409};\\\", \\\"{x:284,y:544,t:1526922715482};\\\", \\\"{x:285,y:545,t:1526922715707};\\\", \\\"{x:286,y:546,t:1526922715963};\\\", \\\"{x:287,y:546,t:1526922715994};\\\", \\\"{x:288,y:546,t:1526922716043};\\\", \\\"{x:288,y:547,t:1526922716059};\\\", \\\"{x:289,y:547,t:1526922716074};\\\", \\\"{x:291,y:548,t:1526922716098};\\\", \\\"{x:292,y:549,t:1526922716115};\\\", \\\"{x:294,y:551,t:1526922716124};\\\", \\\"{x:297,y:553,t:1526922716141};\\\", \\\"{x:301,y:555,t:1526922716158};\\\", \\\"{x:303,y:558,t:1526922716176};\\\", \\\"{x:308,y:562,t:1526922716190};\\\", \\\"{x:313,y:565,t:1526922716207};\\\", \\\"{x:318,y:570,t:1526922716224};\\\", \\\"{x:322,y:573,t:1526922716240};\\\", \\\"{x:327,y:577,t:1526922716257};\\\", \\\"{x:334,y:580,t:1526922716274};\\\", \\\"{x:336,y:580,t:1526922716291};\\\", \\\"{x:338,y:581,t:1526922716307};\\\", \\\"{x:339,y:581,t:1526922716378};\\\", \\\"{x:342,y:581,t:1526922716390};\\\", \\\"{x:350,y:581,t:1526922716407};\\\", \\\"{x:365,y:581,t:1526922716424};\\\", \\\"{x:382,y:580,t:1526922716442};\\\", \\\"{x:398,y:574,t:1526922716457};\\\", \\\"{x:414,y:563,t:1526922716475};\\\", \\\"{x:416,y:559,t:1526922716492};\\\", \\\"{x:416,y:554,t:1526922716507};\\\", \\\"{x:416,y:542,t:1526922716524};\\\", \\\"{x:401,y:530,t:1526922716541};\\\", \\\"{x:370,y:519,t:1526922716557};\\\", \\\"{x:328,y:513,t:1526922716574};\\\", \\\"{x:286,y:513,t:1526922716591};\\\", \\\"{x:257,y:513,t:1526922716607};\\\", \\\"{x:236,y:517,t:1526922716624};\\\", \\\"{x:227,y:520,t:1526922716641};\\\", \\\"{x:224,y:521,t:1526922716657};\\\", \\\"{x:223,y:524,t:1526922716674};\\\", \\\"{x:222,y:528,t:1526922716691};\\\", \\\"{x:216,y:534,t:1526922716707};\\\", \\\"{x:209,y:539,t:1526922716724};\\\", \\\"{x:195,y:542,t:1526922716740};\\\", \\\"{x:189,y:544,t:1526922716758};\\\", \\\"{x:187,y:545,t:1526922716774};\\\", \\\"{x:186,y:545,t:1526922716802};\\\", \\\"{x:185,y:545,t:1526922716810};\\\", \\\"{x:184,y:545,t:1526922716825};\\\", \\\"{x:182,y:545,t:1526922716842};\\\", \\\"{x:181,y:545,t:1526922716858};\\\", \\\"{x:179,y:545,t:1526922716874};\\\", \\\"{x:177,y:544,t:1526922716898};\\\", \\\"{x:176,y:544,t:1526922716915};\\\", \\\"{x:175,y:544,t:1526922716930};\\\", \\\"{x:174,y:543,t:1526922716946};\\\", \\\"{x:173,y:543,t:1526922716959};\\\", \\\"{x:171,y:543,t:1526922716974};\\\", \\\"{x:169,y:543,t:1526922716992};\\\", \\\"{x:168,y:542,t:1526922717018};\\\", \\\"{x:166,y:542,t:1526922717066};\\\", \\\"{x:165,y:541,t:1526922717106};\\\", \\\"{x:168,y:541,t:1526922717242};\\\", \\\"{x:196,y:541,t:1526922717258};\\\", \\\"{x:293,y:541,t:1526922717276};\\\", \\\"{x:391,y:535,t:1526922717292};\\\", \\\"{x:505,y:519,t:1526922717309};\\\", \\\"{x:616,y:505,t:1526922717326};\\\", \\\"{x:697,y:492,t:1526922717341};\\\", \\\"{x:725,y:489,t:1526922717359};\\\", \\\"{x:732,y:485,t:1526922717376};\\\", \\\"{x:732,y:482,t:1526922717434};\\\", \\\"{x:731,y:481,t:1526922717442};\\\", \\\"{x:727,y:479,t:1526922717458};\\\", \\\"{x:724,y:477,t:1526922717475};\\\", \\\"{x:715,y:474,t:1526922717491};\\\", \\\"{x:708,y:474,t:1526922717508};\\\", \\\"{x:703,y:474,t:1526922717525};\\\", \\\"{x:703,y:483,t:1526922717541};\\\", \\\"{x:706,y:493,t:1526922717558};\\\", \\\"{x:726,y:507,t:1526922717576};\\\", \\\"{x:765,y:519,t:1526922717591};\\\", \\\"{x:815,y:519,t:1526922717608};\\\", \\\"{x:863,y:519,t:1526922717625};\\\", \\\"{x:908,y:512,t:1526922717642};\\\", \\\"{x:918,y:509,t:1526922717658};\\\", \\\"{x:920,y:507,t:1526922717675};\\\", \\\"{x:920,y:506,t:1526922717714};\\\", \\\"{x:919,y:505,t:1526922717725};\\\", \\\"{x:918,y:504,t:1526922717742};\\\", \\\"{x:917,y:504,t:1526922717759};\\\", \\\"{x:915,y:503,t:1526922717776};\\\", \\\"{x:911,y:502,t:1526922717792};\\\", \\\"{x:906,y:502,t:1526922717808};\\\", \\\"{x:900,y:502,t:1526922717825};\\\", \\\"{x:891,y:502,t:1526922717842};\\\", \\\"{x:887,y:502,t:1526922717858};\\\", \\\"{x:880,y:503,t:1526922717875};\\\", \\\"{x:876,y:504,t:1526922717892};\\\", \\\"{x:875,y:504,t:1526922717908};\\\", \\\"{x:873,y:504,t:1526922717925};\\\", \\\"{x:872,y:504,t:1526922717942};\\\", \\\"{x:871,y:504,t:1526922717959};\\\", \\\"{x:870,y:504,t:1526922717977};\\\", \\\"{x:868,y:503,t:1526922717992};\\\", \\\"{x:864,y:501,t:1526922718008};\\\", \\\"{x:855,y:500,t:1526922718024};\\\", \\\"{x:840,y:500,t:1526922718041};\\\", \\\"{x:835,y:500,t:1526922718059};\\\", \\\"{x:831,y:500,t:1526922718075};\\\", \\\"{x:829,y:500,t:1526922718506};\\\", \\\"{x:825,y:500,t:1526922718514};\\\", \\\"{x:821,y:500,t:1526922718525};\\\", \\\"{x:803,y:500,t:1526922718542};\\\", \\\"{x:773,y:506,t:1526922718560};\\\", \\\"{x:721,y:524,t:1526922718577};\\\", \\\"{x:676,y:547,t:1526922718593};\\\", \\\"{x:646,y:573,t:1526922718610};\\\", \\\"{x:611,y:614,t:1526922718627};\\\", \\\"{x:586,y:650,t:1526922718643};\\\", \\\"{x:558,y:695,t:1526922718659};\\\", \\\"{x:529,y:735,t:1526922718677};\\\", \\\"{x:505,y:766,t:1526922718693};\\\", \\\"{x:491,y:788,t:1526922718709};\\\", \\\"{x:480,y:803,t:1526922718727};\\\", \\\"{x:476,y:809,t:1526922718742};\\\", \\\"{x:473,y:813,t:1526922718759};\\\", \\\"{x:471,y:815,t:1526922718777};\\\", \\\"{x:470,y:815,t:1526922718793};\\\", \\\"{x:470,y:812,t:1526922718859};\\\", \\\"{x:477,y:798,t:1526922718877};\\\", \\\"{x:488,y:781,t:1526922718893};\\\", \\\"{x:501,y:767,t:1526922718909};\\\", \\\"{x:513,y:754,t:1526922718928};\\\", \\\"{x:520,y:746,t:1526922718942};\\\", \\\"{x:520,y:745,t:1526922718958};\\\", \\\"{x:521,y:743,t:1526922719042};\\\", \\\"{x:522,y:742,t:1526922719139};\\\", \\\"{x:523,y:742,t:1526922719338};\\\", \\\"{x:520,y:739,t:1526922719346};\\\", \\\"{x:507,y:739,t:1526922719359};\\\" ] }, { \\\"rt\\\": 45632, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 377016, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"DKL3R\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-G -10 AM-11 AM-11 AM-12 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:506,y:739,t:1526922721387};\\\", \\\"{x:503,y:739,t:1526922721396};\\\", \\\"{x:499,y:734,t:1526922721414};\\\", \\\"{x:497,y:729,t:1526922721430};\\\", \\\"{x:496,y:724,t:1526922721447};\\\", \\\"{x:495,y:722,t:1526922721463};\\\", \\\"{x:495,y:719,t:1526922721483};\\\", \\\"{x:495,y:718,t:1526922721496};\\\", \\\"{x:495,y:717,t:1526922721511};\\\", \\\"{x:495,y:716,t:1526922721531};\\\", \\\"{x:495,y:715,t:1526922721544};\\\", \\\"{x:495,y:714,t:1526922721561};\\\", \\\"{x:493,y:711,t:1526922721578};\\\", \\\"{x:493,y:709,t:1526922721595};\\\", \\\"{x:493,y:708,t:1526922721618};\\\", \\\"{x:493,y:707,t:1526922721643};\\\", \\\"{x:493,y:706,t:1526922721650};\\\", \\\"{x:492,y:705,t:1526922721674};\\\", \\\"{x:491,y:703,t:1526922721682};\\\", \\\"{x:491,y:702,t:1526922721698};\\\", \\\"{x:490,y:700,t:1526922721711};\\\", \\\"{x:489,y:699,t:1526922721729};\\\", \\\"{x:488,y:698,t:1526922721745};\\\", \\\"{x:487,y:698,t:1526922721761};\\\", \\\"{x:486,y:697,t:1526922721778};\\\", \\\"{x:486,y:696,t:1526922722195};\\\", \\\"{x:486,y:695,t:1526922722213};\\\", \\\"{x:497,y:707,t:1526922724483};\\\", \\\"{x:520,y:745,t:1526922724498};\\\", \\\"{x:624,y:825,t:1526922724513};\\\", \\\"{x:938,y:949,t:1526922724530};\\\", \\\"{x:1254,y:1008,t:1526922724547};\\\", \\\"{x:1657,y:1019,t:1526922724564};\\\", \\\"{x:1858,y:1019,t:1526922724578};\\\", \\\"{x:1869,y:64,t:1526922727891};\\\", \\\"{x:1715,y:22,t:1526922727900};\\\", \\\"{x:1404,y:0,t:1526922727916};\\\", \\\"{x:1129,y:0,t:1526922727933};\\\", \\\"{x:922,y:0,t:1526922727950};\\\", \\\"{x:782,y:27,t:1526922727967};\\\", \\\"{x:706,y:71,t:1526922727984};\\\", \\\"{x:658,y:113,t:1526922728000};\\\", \\\"{x:635,y:153,t:1526922728016};\\\", \\\"{x:628,y:224,t:1526922728033};\\\", \\\"{x:637,y:280,t:1526922728049};\\\", \\\"{x:677,y:344,t:1526922728067};\\\", \\\"{x:741,y:390,t:1526922728083};\\\", \\\"{x:823,y:406,t:1526922728101};\\\", \\\"{x:934,y:405,t:1526922728116};\\\", \\\"{x:1055,y:380,t:1526922728134};\\\", \\\"{x:1159,y:354,t:1526922728150};\\\", \\\"{x:1240,y:332,t:1526922728167};\\\", \\\"{x:1265,y:327,t:1526922728183};\\\", \\\"{x:1272,y:327,t:1526922728201};\\\", \\\"{x:1275,y:327,t:1526922728217};\\\", \\\"{x:1285,y:334,t:1526922728234};\\\", \\\"{x:1311,y:360,t:1526922728250};\\\", \\\"{x:1361,y:405,t:1526922728267};\\\", \\\"{x:1440,y:471,t:1526922728284};\\\", \\\"{x:1534,y:532,t:1526922728301};\\\", \\\"{x:1622,y:586,t:1526922728316};\\\", \\\"{x:1684,y:629,t:1526922728334};\\\", \\\"{x:1719,y:657,t:1526922728350};\\\", \\\"{x:1728,y:668,t:1526922728367};\\\", \\\"{x:1730,y:673,t:1526922728384};\\\", \\\"{x:1727,y:678,t:1526922728401};\\\", \\\"{x:1708,y:687,t:1526922728417};\\\", \\\"{x:1669,y:697,t:1526922728434};\\\", \\\"{x:1592,y:716,t:1526922728451};\\\", \\\"{x:1536,y:724,t:1526922728467};\\\", \\\"{x:1494,y:729,t:1526922728484};\\\", \\\"{x:1469,y:730,t:1526922728501};\\\", \\\"{x:1451,y:730,t:1526922728517};\\\", \\\"{x:1445,y:730,t:1526922728535};\\\", \\\"{x:1438,y:730,t:1526922728551};\\\", \\\"{x:1430,y:730,t:1526922728568};\\\", \\\"{x:1419,y:728,t:1526922728584};\\\", \\\"{x:1401,y:723,t:1526922728602};\\\", \\\"{x:1375,y:714,t:1526922728618};\\\", \\\"{x:1340,y:702,t:1526922728635};\\\", \\\"{x:1323,y:694,t:1526922728651};\\\", \\\"{x:1311,y:685,t:1526922728668};\\\", \\\"{x:1303,y:675,t:1526922728683};\\\", \\\"{x:1293,y:665,t:1526922728700};\\\", \\\"{x:1279,y:653,t:1526922728718};\\\", \\\"{x:1261,y:638,t:1526922728733};\\\", \\\"{x:1238,y:621,t:1526922728750};\\\", \\\"{x:1217,y:606,t:1526922728768};\\\", \\\"{x:1199,y:593,t:1526922728784};\\\", \\\"{x:1184,y:582,t:1526922728800};\\\", \\\"{x:1177,y:575,t:1526922728817};\\\", \\\"{x:1177,y:574,t:1526922728833};\\\", \\\"{x:1177,y:572,t:1526922728850};\\\", \\\"{x:1177,y:569,t:1526922728868};\\\", \\\"{x:1185,y:563,t:1526922728883};\\\", \\\"{x:1198,y:556,t:1526922728901};\\\", \\\"{x:1214,y:546,t:1526922728918};\\\", \\\"{x:1230,y:536,t:1526922728933};\\\", \\\"{x:1243,y:529,t:1526922728950};\\\", \\\"{x:1251,y:525,t:1526922728968};\\\", \\\"{x:1259,y:520,t:1526922728985};\\\", \\\"{x:1267,y:516,t:1526922729000};\\\", \\\"{x:1284,y:508,t:1526922729018};\\\", \\\"{x:1299,y:501,t:1526922729034};\\\", \\\"{x:1310,y:496,t:1526922729051};\\\", \\\"{x:1318,y:495,t:1526922729068};\\\", \\\"{x:1327,y:491,t:1526922729084};\\\", \\\"{x:1333,y:490,t:1526922729100};\\\", \\\"{x:1335,y:489,t:1526922729118};\\\", \\\"{x:1338,y:488,t:1526922729134};\\\", \\\"{x:1340,y:488,t:1526922729150};\\\", \\\"{x:1346,y:488,t:1526922729168};\\\", \\\"{x:1354,y:488,t:1526922729184};\\\", \\\"{x:1370,y:488,t:1526922729200};\\\", \\\"{x:1391,y:486,t:1526922729217};\\\", \\\"{x:1398,y:486,t:1526922729234};\\\", \\\"{x:1400,y:486,t:1526922729251};\\\", \\\"{x:1401,y:486,t:1526922729268};\\\", \\\"{x:1402,y:486,t:1526922729284};\\\", \\\"{x:1403,y:486,t:1526922729313};\\\", \\\"{x:1406,y:486,t:1526922729330};\\\", \\\"{x:1407,y:487,t:1526922729345};\\\", \\\"{x:1408,y:488,t:1526922729354};\\\", \\\"{x:1409,y:488,t:1526922729369};\\\", \\\"{x:1410,y:488,t:1526922729385};\\\", \\\"{x:1411,y:489,t:1526922729401};\\\", \\\"{x:1413,y:490,t:1526922729418};\\\", \\\"{x:1415,y:491,t:1526922729435};\\\", \\\"{x:1417,y:491,t:1526922729451};\\\", \\\"{x:1418,y:493,t:1526922732994};\\\", \\\"{x:1418,y:499,t:1526922733003};\\\", \\\"{x:1417,y:527,t:1526922733020};\\\", \\\"{x:1413,y:557,t:1526922733038};\\\", \\\"{x:1408,y:590,t:1526922733054};\\\", \\\"{x:1400,y:627,t:1526922733070};\\\", \\\"{x:1398,y:652,t:1526922733087};\\\", \\\"{x:1398,y:672,t:1526922733103};\\\", \\\"{x:1399,y:694,t:1526922733120};\\\", \\\"{x:1403,y:723,t:1526922733137};\\\", \\\"{x:1404,y:744,t:1526922733153};\\\", \\\"{x:1404,y:759,t:1526922733171};\\\", \\\"{x:1404,y:771,t:1526922733187};\\\", \\\"{x:1404,y:780,t:1526922733203};\\\", \\\"{x:1404,y:785,t:1526922733221};\\\", \\\"{x:1402,y:792,t:1526922733238};\\\", \\\"{x:1400,y:795,t:1526922733254};\\\", \\\"{x:1397,y:799,t:1526922733271};\\\", \\\"{x:1395,y:801,t:1526922733288};\\\", \\\"{x:1393,y:802,t:1526922733305};\\\", \\\"{x:1392,y:803,t:1526922733321};\\\", \\\"{x:1390,y:803,t:1526922733347};\\\", \\\"{x:1388,y:802,t:1526922733363};\\\", \\\"{x:1386,y:801,t:1526922733371};\\\", \\\"{x:1384,y:798,t:1526922733388};\\\", \\\"{x:1382,y:797,t:1526922733406};\\\", \\\"{x:1381,y:793,t:1526922733421};\\\", \\\"{x:1379,y:790,t:1526922733439};\\\", \\\"{x:1378,y:785,t:1526922733455};\\\", \\\"{x:1375,y:780,t:1526922733471};\\\", \\\"{x:1371,y:773,t:1526922733488};\\\", \\\"{x:1367,y:766,t:1526922733505};\\\", \\\"{x:1365,y:762,t:1526922733521};\\\", \\\"{x:1362,y:758,t:1526922733538};\\\", \\\"{x:1361,y:756,t:1526922733555};\\\", \\\"{x:1361,y:755,t:1526922733571};\\\", \\\"{x:1361,y:752,t:1526922733588};\\\", \\\"{x:1359,y:750,t:1526922733606};\\\", \\\"{x:1358,y:746,t:1526922733621};\\\", \\\"{x:1357,y:744,t:1526922733638};\\\", \\\"{x:1356,y:741,t:1526922733655};\\\", \\\"{x:1355,y:739,t:1526922733671};\\\", \\\"{x:1353,y:737,t:1526922733689};\\\", \\\"{x:1351,y:736,t:1526922733705};\\\", \\\"{x:1350,y:735,t:1526922733721};\\\", \\\"{x:1349,y:734,t:1526922733746};\\\", \\\"{x:1348,y:733,t:1526922733755};\\\", \\\"{x:1346,y:731,t:1526922733772};\\\", \\\"{x:1343,y:728,t:1526922733788};\\\", \\\"{x:1342,y:727,t:1526922733805};\\\", \\\"{x:1340,y:723,t:1526922733822};\\\", \\\"{x:1338,y:720,t:1526922733838};\\\", \\\"{x:1335,y:714,t:1526922733856};\\\", \\\"{x:1330,y:703,t:1526922733873};\\\", \\\"{x:1325,y:691,t:1526922733889};\\\", \\\"{x:1319,y:676,t:1526922733906};\\\", \\\"{x:1312,y:662,t:1526922733922};\\\", \\\"{x:1305,y:648,t:1526922733939};\\\", \\\"{x:1299,y:637,t:1526922733955};\\\", \\\"{x:1296,y:629,t:1526922733972};\\\", \\\"{x:1294,y:623,t:1526922733988};\\\", \\\"{x:1290,y:615,t:1526922734005};\\\", \\\"{x:1289,y:609,t:1526922734022};\\\", \\\"{x:1288,y:604,t:1526922734038};\\\", \\\"{x:1287,y:601,t:1526922734055};\\\", \\\"{x:1287,y:599,t:1526922734072};\\\", \\\"{x:1287,y:598,t:1526922734089};\\\", \\\"{x:1287,y:597,t:1526922734105};\\\", \\\"{x:1285,y:595,t:1526922734122};\\\", \\\"{x:1285,y:594,t:1526922734138};\\\", \\\"{x:1285,y:593,t:1526922734155};\\\", \\\"{x:1285,y:592,t:1526922734172};\\\", \\\"{x:1285,y:591,t:1526922734194};\\\", \\\"{x:1285,y:590,t:1526922734210};\\\", \\\"{x:1285,y:589,t:1526922734222};\\\", \\\"{x:1285,y:588,t:1526922734240};\\\", \\\"{x:1284,y:585,t:1526922734255};\\\", \\\"{x:1283,y:583,t:1526922734272};\\\", \\\"{x:1283,y:582,t:1526922734289};\\\", \\\"{x:1282,y:580,t:1526922734306};\\\", \\\"{x:1281,y:578,t:1526922734323};\\\", \\\"{x:1281,y:577,t:1526922734339};\\\", \\\"{x:1281,y:575,t:1526922734355};\\\", \\\"{x:1281,y:574,t:1526922734373};\\\", \\\"{x:1281,y:573,t:1526922734390};\\\", \\\"{x:1280,y:572,t:1526922734427};\\\", \\\"{x:1266,y:615,t:1526922757335};\\\", \\\"{x:1240,y:693,t:1526922757345};\\\", \\\"{x:1204,y:810,t:1526922757361};\\\", \\\"{x:1194,y:879,t:1526922757378};\\\", \\\"{x:1189,y:915,t:1526922757395};\\\", \\\"{x:1192,y:921,t:1526922757411};\\\", \\\"{x:1200,y:926,t:1526922757428};\\\", \\\"{x:1205,y:929,t:1526922757444};\\\", \\\"{x:1210,y:935,t:1526922757461};\\\", \\\"{x:1223,y:956,t:1526922757478};\\\", \\\"{x:1233,y:971,t:1526922757495};\\\", \\\"{x:1244,y:989,t:1526922757512};\\\", \\\"{x:1252,y:1001,t:1526922757528};\\\", \\\"{x:1260,y:1010,t:1526922757545};\\\", \\\"{x:1264,y:1015,t:1526922757561};\\\", \\\"{x:1265,y:1017,t:1526922757577};\\\", \\\"{x:1266,y:1017,t:1526922757597};\\\", \\\"{x:1267,y:1017,t:1526922757645};\\\", \\\"{x:1268,y:1017,t:1526922757661};\\\", \\\"{x:1269,y:1017,t:1526922757678};\\\", \\\"{x:1272,y:1017,t:1526922757695};\\\", \\\"{x:1273,y:1016,t:1526922757711};\\\", \\\"{x:1273,y:1013,t:1526922757727};\\\", \\\"{x:1273,y:1010,t:1526922757745};\\\", \\\"{x:1272,y:1004,t:1526922757761};\\\", \\\"{x:1270,y:997,t:1526922757777};\\\", \\\"{x:1268,y:989,t:1526922757796};\\\", \\\"{x:1267,y:981,t:1526922757811};\\\", \\\"{x:1266,y:976,t:1526922757827};\\\", \\\"{x:1265,y:973,t:1526922757845};\\\", \\\"{x:1264,y:969,t:1526922757861};\\\", \\\"{x:1264,y:968,t:1526922757878};\\\", \\\"{x:1264,y:966,t:1526922757894};\\\", \\\"{x:1264,y:964,t:1526922757926};\\\", \\\"{x:1263,y:963,t:1526922757989};\\\", \\\"{x:1262,y:963,t:1526922758284};\\\", \\\"{x:1261,y:963,t:1526922758349};\\\", \\\"{x:1259,y:963,t:1526922758396};\\\", \\\"{x:1258,y:963,t:1526922758437};\\\", \\\"{x:1258,y:962,t:1526922758445};\\\", \\\"{x:1259,y:962,t:1526922758590};\\\", \\\"{x:1260,y:962,t:1526922758598};\\\", \\\"{x:1262,y:962,t:1526922758612};\\\", \\\"{x:1264,y:962,t:1526922758629};\\\", \\\"{x:1269,y:964,t:1526922758645};\\\", \\\"{x:1273,y:965,t:1526922758662};\\\", \\\"{x:1275,y:966,t:1526922758679};\\\", \\\"{x:1278,y:967,t:1526922758695};\\\", \\\"{x:1281,y:968,t:1526922758712};\\\", \\\"{x:1282,y:968,t:1526922758728};\\\", \\\"{x:1284,y:968,t:1526922758750};\\\", \\\"{x:1285,y:968,t:1526922758974};\\\", \\\"{x:1287,y:968,t:1526922759014};\\\", \\\"{x:1287,y:969,t:1526922759029};\\\", \\\"{x:1288,y:969,t:1526922759046};\\\", \\\"{x:1290,y:969,t:1526922759062};\\\", \\\"{x:1291,y:969,t:1526922759079};\\\", \\\"{x:1294,y:969,t:1526922759096};\\\", \\\"{x:1298,y:969,t:1526922759112};\\\", \\\"{x:1304,y:969,t:1526922759129};\\\", \\\"{x:1308,y:969,t:1526922759146};\\\", \\\"{x:1311,y:969,t:1526922759163};\\\", \\\"{x:1316,y:969,t:1526922759178};\\\", \\\"{x:1319,y:969,t:1526922759196};\\\", \\\"{x:1322,y:969,t:1526922759213};\\\", \\\"{x:1326,y:969,t:1526922759229};\\\", \\\"{x:1330,y:969,t:1526922759246};\\\", \\\"{x:1335,y:969,t:1526922759263};\\\", \\\"{x:1339,y:969,t:1526922759278};\\\", \\\"{x:1343,y:969,t:1526922759296};\\\", \\\"{x:1345,y:969,t:1526922759313};\\\", \\\"{x:1346,y:969,t:1526922759328};\\\", \\\"{x:1347,y:969,t:1526922759346};\\\", \\\"{x:1349,y:969,t:1526922759582};\\\", \\\"{x:1350,y:969,t:1526922759596};\\\", \\\"{x:1356,y:969,t:1526922759613};\\\", \\\"{x:1361,y:969,t:1526922759630};\\\", \\\"{x:1367,y:969,t:1526922759646};\\\", \\\"{x:1372,y:969,t:1526922759662};\\\", \\\"{x:1374,y:969,t:1526922759680};\\\", \\\"{x:1377,y:968,t:1526922759695};\\\", \\\"{x:1379,y:968,t:1526922759712};\\\", \\\"{x:1382,y:967,t:1526922759729};\\\", \\\"{x:1383,y:967,t:1526922759757};\\\", \\\"{x:1384,y:967,t:1526922759765};\\\", \\\"{x:1385,y:967,t:1526922759779};\\\", \\\"{x:1391,y:967,t:1526922759795};\\\", \\\"{x:1396,y:966,t:1526922759813};\\\", \\\"{x:1403,y:965,t:1526922759829};\\\", \\\"{x:1405,y:965,t:1526922759846};\\\", \\\"{x:1409,y:965,t:1526922759862};\\\", \\\"{x:1412,y:963,t:1526922759880};\\\", \\\"{x:1414,y:963,t:1526922759896};\\\", \\\"{x:1416,y:963,t:1526922759913};\\\", \\\"{x:1417,y:963,t:1526922760174};\\\", \\\"{x:1420,y:963,t:1526922760181};\\\", \\\"{x:1423,y:963,t:1526922760197};\\\", \\\"{x:1429,y:963,t:1526922760214};\\\", \\\"{x:1440,y:963,t:1526922760230};\\\", \\\"{x:1446,y:963,t:1526922760247};\\\", \\\"{x:1451,y:963,t:1526922760263};\\\", \\\"{x:1452,y:963,t:1526922760280};\\\", \\\"{x:1453,y:963,t:1526922760301};\\\", \\\"{x:1454,y:963,t:1526922760313};\\\", \\\"{x:1456,y:963,t:1526922760330};\\\", \\\"{x:1460,y:963,t:1526922760346};\\\", \\\"{x:1470,y:962,t:1526922760363};\\\", \\\"{x:1480,y:961,t:1526922760380};\\\", \\\"{x:1492,y:959,t:1526922760398};\\\", \\\"{x:1494,y:959,t:1526922760414};\\\", \\\"{x:1495,y:959,t:1526922760430};\\\", \\\"{x:1496,y:959,t:1526922760775};\\\", \\\"{x:1498,y:959,t:1526922760790};\\\", \\\"{x:1499,y:959,t:1526922760798};\\\", \\\"{x:1505,y:959,t:1526922760813};\\\", \\\"{x:1511,y:959,t:1526922760830};\\\", \\\"{x:1517,y:959,t:1526922760847};\\\", \\\"{x:1522,y:959,t:1526922760864};\\\", \\\"{x:1526,y:959,t:1526922760881};\\\", \\\"{x:1531,y:959,t:1526922760898};\\\", \\\"{x:1533,y:959,t:1526922760914};\\\", \\\"{x:1535,y:959,t:1526922760930};\\\", \\\"{x:1536,y:959,t:1526922760958};\\\", \\\"{x:1537,y:958,t:1526922760966};\\\", \\\"{x:1538,y:958,t:1526922760981};\\\", \\\"{x:1540,y:958,t:1526922760997};\\\", \\\"{x:1544,y:957,t:1526922761014};\\\", \\\"{x:1546,y:955,t:1526922761031};\\\", \\\"{x:1547,y:955,t:1526922761047};\\\", \\\"{x:1549,y:955,t:1526922761064};\\\", \\\"{x:1552,y:954,t:1526922761081};\\\", \\\"{x:1555,y:954,t:1526922761097};\\\", \\\"{x:1558,y:953,t:1526922761114};\\\", \\\"{x:1560,y:953,t:1526922761131};\\\", \\\"{x:1563,y:952,t:1526922761147};\\\", \\\"{x:1564,y:952,t:1526922761164};\\\", \\\"{x:1566,y:951,t:1526922761181};\\\", \\\"{x:1567,y:951,t:1526922761197};\\\", \\\"{x:1562,y:948,t:1526922761526};\\\", \\\"{x:1553,y:944,t:1526922761533};\\\", \\\"{x:1536,y:938,t:1526922761548};\\\", \\\"{x:1496,y:918,t:1526922761564};\\\", \\\"{x:1422,y:870,t:1526922761581};\\\", \\\"{x:1258,y:734,t:1526922761598};\\\", \\\"{x:1138,y:640,t:1526922761614};\\\", \\\"{x:1016,y:558,t:1526922761631};\\\", \\\"{x:909,y:493,t:1526922761649};\\\", \\\"{x:797,y:429,t:1526922761664};\\\", \\\"{x:706,y:390,t:1526922761680};\\\", \\\"{x:648,y:373,t:1526922761697};\\\", \\\"{x:616,y:367,t:1526922761714};\\\", \\\"{x:606,y:364,t:1526922761730};\\\", \\\"{x:605,y:364,t:1526922761861};\\\", \\\"{x:603,y:364,t:1526922761869};\\\", \\\"{x:597,y:367,t:1526922761882};\\\", \\\"{x:580,y:376,t:1526922761898};\\\", \\\"{x:563,y:391,t:1526922761914};\\\", \\\"{x:550,y:412,t:1526922761931};\\\", \\\"{x:540,y:434,t:1526922761947};\\\", \\\"{x:527,y:460,t:1526922761965};\\\", \\\"{x:521,y:469,t:1526922761981};\\\", \\\"{x:503,y:491,t:1526922761999};\\\", \\\"{x:484,y:505,t:1526922762015};\\\", \\\"{x:470,y:518,t:1526922762031};\\\", \\\"{x:461,y:528,t:1526922762047};\\\", \\\"{x:455,y:534,t:1526922762064};\\\", \\\"{x:453,y:536,t:1526922762080};\\\", \\\"{x:451,y:538,t:1526922762097};\\\", \\\"{x:450,y:539,t:1526922762114};\\\", \\\"{x:449,y:539,t:1526922762189};\\\", \\\"{x:448,y:539,t:1526922762204};\\\", \\\"{x:447,y:539,t:1526922762215};\\\", \\\"{x:446,y:539,t:1526922762231};\\\", \\\"{x:444,y:539,t:1526922762248};\\\", \\\"{x:441,y:538,t:1526922762264};\\\", \\\"{x:438,y:537,t:1526922762281};\\\", \\\"{x:431,y:535,t:1526922762297};\\\", \\\"{x:428,y:534,t:1526922762313};\\\", \\\"{x:424,y:533,t:1526922762330};\\\", \\\"{x:419,y:533,t:1526922762348};\\\", \\\"{x:414,y:531,t:1526922762365};\\\", \\\"{x:408,y:531,t:1526922762381};\\\", \\\"{x:400,y:531,t:1526922762396};\\\", \\\"{x:396,y:531,t:1526922762414};\\\", \\\"{x:393,y:531,t:1526922762431};\\\", \\\"{x:391,y:532,t:1526922762446};\\\", \\\"{x:388,y:535,t:1526922762464};\\\", \\\"{x:386,y:537,t:1526922762481};\\\", \\\"{x:385,y:540,t:1526922762497};\\\", \\\"{x:383,y:543,t:1526922762513};\\\", \\\"{x:382,y:547,t:1526922762529};\\\", \\\"{x:378,y:556,t:1526922762548};\\\", \\\"{x:375,y:567,t:1526922762565};\\\", \\\"{x:374,y:577,t:1526922762581};\\\", \\\"{x:373,y:579,t:1526922762600};\\\", \\\"{x:373,y:580,t:1526922762615};\\\", \\\"{x:372,y:580,t:1526922762637};\\\", \\\"{x:370,y:580,t:1526922762648};\\\", \\\"{x:361,y:581,t:1526922762664};\\\", \\\"{x:346,y:581,t:1526922762682};\\\", \\\"{x:326,y:581,t:1526922762699};\\\", \\\"{x:299,y:581,t:1526922762716};\\\", \\\"{x:270,y:581,t:1526922762732};\\\", \\\"{x:242,y:581,t:1526922762748};\\\", \\\"{x:211,y:581,t:1526922762765};\\\", \\\"{x:204,y:579,t:1526922762781};\\\", \\\"{x:204,y:577,t:1526922762813};\\\", \\\"{x:206,y:576,t:1526922762821};\\\", \\\"{x:217,y:575,t:1526922762831};\\\", \\\"{x:261,y:573,t:1526922762849};\\\", \\\"{x:336,y:573,t:1526922762866};\\\", \\\"{x:428,y:572,t:1526922762882};\\\", \\\"{x:543,y:563,t:1526922762898};\\\", \\\"{x:634,y:554,t:1526922762915};\\\", \\\"{x:688,y:544,t:1526922762932};\\\", \\\"{x:725,y:535,t:1526922762949};\\\", \\\"{x:731,y:534,t:1526922762965};\\\", \\\"{x:732,y:533,t:1526922762981};\\\", \\\"{x:732,y:532,t:1526922762998};\\\", \\\"{x:732,y:530,t:1526922763015};\\\", \\\"{x:732,y:527,t:1526922763032};\\\", \\\"{x:734,y:522,t:1526922763049};\\\", \\\"{x:737,y:517,t:1526922763066};\\\", \\\"{x:740,y:511,t:1526922763081};\\\", \\\"{x:742,y:507,t:1526922763098};\\\", \\\"{x:742,y:506,t:1526922763115};\\\", \\\"{x:742,y:505,t:1526922763131};\\\", \\\"{x:738,y:502,t:1526922763149};\\\", \\\"{x:715,y:501,t:1526922763165};\\\", \\\"{x:685,y:498,t:1526922763181};\\\", \\\"{x:662,y:498,t:1526922763198};\\\", \\\"{x:643,y:497,t:1526922763216};\\\", \\\"{x:637,y:496,t:1526922763231};\\\", \\\"{x:636,y:496,t:1526922763413};\\\", \\\"{x:634,y:497,t:1526922763421};\\\", \\\"{x:634,y:498,t:1526922763437};\\\", \\\"{x:633,y:500,t:1526922763449};\\\", \\\"{x:632,y:501,t:1526922763465};\\\", \\\"{x:630,y:501,t:1526922763493};\\\", \\\"{x:629,y:501,t:1526922763509};\\\", \\\"{x:628,y:501,t:1526922763516};\\\", \\\"{x:624,y:501,t:1526922763532};\\\", \\\"{x:621,y:500,t:1526922763548};\\\", \\\"{x:613,y:498,t:1526922763566};\\\", \\\"{x:612,y:498,t:1526922763582};\\\", \\\"{x:611,y:498,t:1526922763715};\\\", \\\"{x:609,y:498,t:1526922763958};\\\", \\\"{x:608,y:498,t:1526922763973};\\\", \\\"{x:607,y:498,t:1526922763983};\\\", \\\"{x:606,y:499,t:1526922764000};\\\", \\\"{x:605,y:500,t:1526922764638};\\\", \\\"{x:605,y:501,t:1526922764650};\\\", \\\"{x:603,y:503,t:1526922764667};\\\", \\\"{x:602,y:507,t:1526922764683};\\\", \\\"{x:599,y:511,t:1526922764701};\\\", \\\"{x:594,y:519,t:1526922764717};\\\", \\\"{x:590,y:525,t:1526922764733};\\\", \\\"{x:585,y:532,t:1526922764750};\\\", \\\"{x:577,y:543,t:1526922764766};\\\", \\\"{x:570,y:554,t:1526922764783};\\\", \\\"{x:562,y:564,t:1526922764799};\\\", \\\"{x:557,y:575,t:1526922764817};\\\", \\\"{x:551,y:587,t:1526922764833};\\\", \\\"{x:547,y:596,t:1526922764851};\\\", \\\"{x:543,y:605,t:1526922764867};\\\", \\\"{x:541,y:617,t:1526922764884};\\\", \\\"{x:538,y:630,t:1526922764899};\\\", \\\"{x:536,y:655,t:1526922764917};\\\", \\\"{x:531,y:672,t:1526922764934};\\\", \\\"{x:525,y:688,t:1526922764950};\\\", \\\"{x:519,y:705,t:1526922764966};\\\", \\\"{x:515,y:718,t:1526922764983};\\\", \\\"{x:510,y:730,t:1526922765000};\\\", \\\"{x:508,y:735,t:1526922765016};\\\", \\\"{x:506,y:738,t:1526922765033};\\\", \\\"{x:505,y:740,t:1526922765050};\\\", \\\"{x:505,y:742,t:1526922765066};\\\", \\\"{x:505,y:743,t:1526922765084};\\\", \\\"{x:504,y:746,t:1526922765100};\\\", \\\"{x:504,y:752,t:1526922765117};\\\", \\\"{x:504,y:753,t:1526922765133};\\\", \\\"{x:503,y:753,t:1526922765151};\\\", \\\"{x:503,y:754,t:1526922765237};\\\", \\\"{x:503,y:753,t:1526922765262};\\\", \\\"{x:503,y:751,t:1526922765270};\\\", \\\"{x:503,y:750,t:1526922765284};\\\", \\\"{x:503,y:746,t:1526922765302};\\\", \\\"{x:503,y:744,t:1526922765317};\\\", \\\"{x:503,y:742,t:1526922765334};\\\", \\\"{x:503,y:741,t:1526922765350};\\\" ] }, { \\\"rt\\\": 18850, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 397073, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"DKL3R\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -I -10 AM-11 AM-12 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:503,y:740,t:1526922767328};\\\", \\\"{x:507,y:744,t:1526922771725};\\\", \\\"{x:516,y:753,t:1526922771738};\\\", \\\"{x:527,y:766,t:1526922771755};\\\", \\\"{x:534,y:777,t:1526922771772};\\\", \\\"{x:543,y:788,t:1526922771788};\\\", \\\"{x:557,y:806,t:1526922771806};\\\", \\\"{x:563,y:817,t:1526922771821};\\\", \\\"{x:569,y:832,t:1526922771838};\\\", \\\"{x:577,y:849,t:1526922771856};\\\", \\\"{x:582,y:873,t:1526922771872};\\\", \\\"{x:590,y:894,t:1526922771888};\\\", \\\"{x:596,y:915,t:1526922771905};\\\", \\\"{x:602,y:937,t:1526922771922};\\\", \\\"{x:611,y:968,t:1526922771939};\\\", \\\"{x:615,y:1014,t:1526922771956};\\\", \\\"{x:615,y:1076,t:1526922771971};\\\", \\\"{x:619,y:1155,t:1526922771988};\\\", \\\"{x:619,y:1189,t:1526922772006};\\\", \\\"{x:618,y:1199,t:1526922772022};\\\", \\\"{x:620,y:1199,t:1526922772076};\\\", \\\"{x:621,y:1199,t:1526922772088};\\\", \\\"{x:622,y:1199,t:1526922772106};\\\", \\\"{x:627,y:1199,t:1526922772122};\\\", \\\"{x:630,y:1199,t:1526922772139};\\\", \\\"{x:632,y:1199,t:1526922772156};\\\", \\\"{x:638,y:1199,t:1526922772172};\\\", \\\"{x:644,y:1199,t:1526922772189};\\\", \\\"{x:656,y:1195,t:1526922772205};\\\", \\\"{x:688,y:1168,t:1526922772223};\\\", \\\"{x:734,y:1122,t:1526922772238};\\\", \\\"{x:804,y:1042,t:1526922772255};\\\", \\\"{x:888,y:946,t:1526922772273};\\\", \\\"{x:962,y:838,t:1526922772289};\\\", \\\"{x:1036,y:709,t:1526922772306};\\\", \\\"{x:1104,y:573,t:1526922772323};\\\", \\\"{x:1165,y:435,t:1526922772339};\\\", \\\"{x:1221,y:316,t:1526922772355};\\\", \\\"{x:1275,y:185,t:1526922772372};\\\", \\\"{x:1295,y:116,t:1526922772388};\\\", \\\"{x:1306,y:67,t:1526922772406};\\\", \\\"{x:1308,y:41,t:1526922772423};\\\", \\\"{x:1308,y:19,t:1526922772439};\\\", \\\"{x:1308,y:7,t:1526922772456};\\\", \\\"{x:1308,y:4,t:1526922772473};\\\", \\\"{x:1309,y:7,t:1526922772572};\\\", \\\"{x:1340,y:50,t:1526922772590};\\\", \\\"{x:1387,y:112,t:1526922772605};\\\", \\\"{x:1444,y:179,t:1526922772623};\\\", \\\"{x:1498,y:242,t:1526922772640};\\\", \\\"{x:1547,y:295,t:1526922772656};\\\", \\\"{x:1605,y:341,t:1526922772673};\\\", \\\"{x:1664,y:386,t:1526922772690};\\\", \\\"{x:1719,y:421,t:1526922772706};\\\", \\\"{x:1761,y:440,t:1526922772723};\\\", \\\"{x:1784,y:447,t:1526922772740};\\\", \\\"{x:1793,y:450,t:1526922772756};\\\", \\\"{x:1794,y:450,t:1526922772773};\\\", \\\"{x:1795,y:450,t:1526922772869};\\\", \\\"{x:1793,y:456,t:1526922772876};\\\", \\\"{x:1775,y:470,t:1526922772890};\\\", \\\"{x:1709,y:510,t:1526922772905};\\\", \\\"{x:1627,y:552,t:1526922772923};\\\", \\\"{x:1545,y:599,t:1526922772940};\\\", \\\"{x:1442,y:655,t:1526922772956};\\\", \\\"{x:1302,y:723,t:1526922772972};\\\", \\\"{x:1222,y:757,t:1526922772990};\\\", \\\"{x:1153,y:786,t:1526922773006};\\\", \\\"{x:1123,y:800,t:1526922773023};\\\", \\\"{x:1109,y:810,t:1526922773039};\\\", \\\"{x:1108,y:812,t:1526922773060};\\\", \\\"{x:1108,y:813,t:1526922773172};\\\", \\\"{x:1112,y:817,t:1526922773190};\\\", \\\"{x:1118,y:818,t:1526922773207};\\\", \\\"{x:1132,y:821,t:1526922773222};\\\", \\\"{x:1150,y:822,t:1526922773240};\\\", \\\"{x:1168,y:822,t:1526922773256};\\\", \\\"{x:1184,y:822,t:1526922773272};\\\", \\\"{x:1193,y:822,t:1526922773290};\\\", \\\"{x:1197,y:822,t:1526922773306};\\\", \\\"{x:1199,y:822,t:1526922773323};\\\", \\\"{x:1199,y:823,t:1526922773437};\\\", \\\"{x:1200,y:824,t:1526922773476};\\\", \\\"{x:1201,y:825,t:1526922773489};\\\", \\\"{x:1204,y:827,t:1526922773507};\\\", \\\"{x:1208,y:829,t:1526922773522};\\\", \\\"{x:1210,y:830,t:1526922773540};\\\", \\\"{x:1211,y:830,t:1526922773557};\\\", \\\"{x:1212,y:831,t:1526922773573};\\\", \\\"{x:1213,y:831,t:1526922773628};\\\", \\\"{x:1214,y:831,t:1526922774388};\\\", \\\"{x:1213,y:830,t:1526922774404};\\\", \\\"{x:1212,y:829,t:1526922774420};\\\", \\\"{x:1210,y:828,t:1526922774437};\\\", \\\"{x:1207,y:824,t:1526922774453};\\\", \\\"{x:1205,y:823,t:1526922774460};\\\", \\\"{x:1204,y:821,t:1526922774473};\\\", \\\"{x:1201,y:816,t:1526922774491};\\\", \\\"{x:1199,y:812,t:1526922774506};\\\", \\\"{x:1198,y:807,t:1526922774524};\\\", \\\"{x:1196,y:805,t:1526922774541};\\\", \\\"{x:1196,y:803,t:1526922774557};\\\", \\\"{x:1195,y:802,t:1526922774574};\\\", \\\"{x:1195,y:801,t:1526922774596};\\\", \\\"{x:1195,y:800,t:1526922774612};\\\", \\\"{x:1195,y:799,t:1526922774644};\\\", \\\"{x:1195,y:798,t:1526922774661};\\\", \\\"{x:1195,y:796,t:1526922774684};\\\", \\\"{x:1195,y:795,t:1526922774693};\\\", \\\"{x:1195,y:794,t:1526922774707};\\\", \\\"{x:1193,y:791,t:1526922774723};\\\", \\\"{x:1189,y:784,t:1526922774741};\\\", \\\"{x:1188,y:779,t:1526922774757};\\\", \\\"{x:1184,y:774,t:1526922774774};\\\", \\\"{x:1181,y:769,t:1526922774791};\\\", \\\"{x:1181,y:768,t:1526922774808};\\\", \\\"{x:1181,y:767,t:1526922774996};\\\", \\\"{x:1181,y:768,t:1526922780940};\\\", \\\"{x:1181,y:779,t:1526922780949};\\\", \\\"{x:1181,y:787,t:1526922780962};\\\", \\\"{x:1181,y:804,t:1526922780978};\\\", \\\"{x:1181,y:823,t:1526922780995};\\\", \\\"{x:1181,y:848,t:1526922781011};\\\", \\\"{x:1181,y:858,t:1526922781028};\\\", \\\"{x:1181,y:864,t:1526922781045};\\\", \\\"{x:1181,y:869,t:1526922781062};\\\", \\\"{x:1181,y:875,t:1526922781078};\\\", \\\"{x:1181,y:887,t:1526922781095};\\\", \\\"{x:1181,y:898,t:1526922781112};\\\", \\\"{x:1181,y:913,t:1526922781128};\\\", \\\"{x:1181,y:926,t:1526922781145};\\\", \\\"{x:1181,y:934,t:1526922781162};\\\", \\\"{x:1181,y:939,t:1526922781179};\\\", \\\"{x:1181,y:944,t:1526922781195};\\\", \\\"{x:1181,y:949,t:1526922781213};\\\", \\\"{x:1181,y:954,t:1526922781228};\\\", \\\"{x:1181,y:963,t:1526922781245};\\\", \\\"{x:1177,y:975,t:1526922781262};\\\", \\\"{x:1175,y:982,t:1526922781278};\\\", \\\"{x:1174,y:988,t:1526922781295};\\\", \\\"{x:1172,y:991,t:1526922781312};\\\", \\\"{x:1172,y:994,t:1526922781328};\\\", \\\"{x:1171,y:995,t:1526922781345};\\\", \\\"{x:1173,y:994,t:1526922781444};\\\", \\\"{x:1176,y:989,t:1526922781451};\\\", \\\"{x:1177,y:986,t:1526922781461};\\\", \\\"{x:1182,y:978,t:1526922781479};\\\", \\\"{x:1184,y:971,t:1526922781494};\\\", \\\"{x:1186,y:967,t:1526922781512};\\\", \\\"{x:1187,y:965,t:1526922781529};\\\", \\\"{x:1187,y:963,t:1526922781545};\\\", \\\"{x:1187,y:962,t:1526922781613};\\\", \\\"{x:1187,y:960,t:1526922781636};\\\", \\\"{x:1187,y:959,t:1526922781669};\\\", \\\"{x:1187,y:958,t:1526922781868};\\\", \\\"{x:1188,y:958,t:1526922781879};\\\", \\\"{x:1189,y:958,t:1526922781896};\\\", \\\"{x:1190,y:958,t:1526922781912};\\\", \\\"{x:1192,y:958,t:1526922781929};\\\", \\\"{x:1192,y:959,t:1526922781972};\\\", \\\"{x:1193,y:959,t:1526922781981};\\\", \\\"{x:1195,y:961,t:1526922781996};\\\", \\\"{x:1196,y:963,t:1526922782012};\\\", \\\"{x:1199,y:966,t:1526922782029};\\\", \\\"{x:1201,y:967,t:1526922782046};\\\", \\\"{x:1203,y:968,t:1526922782062};\\\", \\\"{x:1205,y:970,t:1526922782079};\\\", \\\"{x:1207,y:970,t:1526922782097};\\\", \\\"{x:1210,y:972,t:1526922782112};\\\", \\\"{x:1215,y:973,t:1526922782129};\\\", \\\"{x:1222,y:973,t:1526922782146};\\\", \\\"{x:1230,y:973,t:1526922782162};\\\", \\\"{x:1239,y:973,t:1526922782180};\\\", \\\"{x:1244,y:973,t:1526922782196};\\\", \\\"{x:1246,y:973,t:1526922782212};\\\", \\\"{x:1247,y:973,t:1526922782229};\\\", \\\"{x:1248,y:973,t:1526922782246};\\\", \\\"{x:1249,y:972,t:1526922782262};\\\", \\\"{x:1250,y:971,t:1526922782279};\\\", \\\"{x:1252,y:970,t:1526922782296};\\\", \\\"{x:1254,y:969,t:1526922782312};\\\", \\\"{x:1255,y:969,t:1526922782329};\\\", \\\"{x:1257,y:969,t:1526922782346};\\\", \\\"{x:1258,y:969,t:1526922782365};\\\", \\\"{x:1259,y:969,t:1526922782565};\\\", \\\"{x:1260,y:969,t:1526922782588};\\\", \\\"{x:1261,y:969,t:1526922782596};\\\", \\\"{x:1263,y:969,t:1526922782613};\\\", \\\"{x:1265,y:969,t:1526922782629};\\\", \\\"{x:1267,y:969,t:1526922782646};\\\", \\\"{x:1268,y:969,t:1526922782663};\\\", \\\"{x:1270,y:969,t:1526922782679};\\\", \\\"{x:1271,y:969,t:1526922782696};\\\", \\\"{x:1274,y:969,t:1526922782713};\\\", \\\"{x:1277,y:969,t:1526922782729};\\\", \\\"{x:1280,y:970,t:1526922782746};\\\", \\\"{x:1284,y:971,t:1526922782763};\\\", \\\"{x:1288,y:971,t:1526922782779};\\\", \\\"{x:1293,y:971,t:1526922782797};\\\", \\\"{x:1296,y:971,t:1526922782813};\\\", \\\"{x:1298,y:971,t:1526922782829};\\\", \\\"{x:1301,y:971,t:1526922782846};\\\", \\\"{x:1302,y:971,t:1526922782901};\\\", \\\"{x:1303,y:971,t:1526922782913};\\\", \\\"{x:1304,y:971,t:1526922782930};\\\", \\\"{x:1306,y:970,t:1526922782946};\\\", \\\"{x:1307,y:970,t:1526922782963};\\\", \\\"{x:1309,y:970,t:1526922782980};\\\", \\\"{x:1310,y:969,t:1526922783005};\\\", \\\"{x:1311,y:969,t:1526922783252};\\\", \\\"{x:1312,y:969,t:1526922783268};\\\", \\\"{x:1313,y:969,t:1526922783476};\\\", \\\"{x:1314,y:969,t:1526922783508};\\\", \\\"{x:1315,y:969,t:1526922783524};\\\", \\\"{x:1315,y:970,t:1526922783532};\\\", \\\"{x:1316,y:970,t:1526922783547};\\\", \\\"{x:1318,y:971,t:1526922783563};\\\", \\\"{x:1322,y:972,t:1526922783580};\\\", \\\"{x:1324,y:973,t:1526922783596};\\\", \\\"{x:1327,y:974,t:1526922783613};\\\", \\\"{x:1331,y:976,t:1526922783630};\\\", \\\"{x:1335,y:978,t:1526922783647};\\\", \\\"{x:1342,y:978,t:1526922783663};\\\", \\\"{x:1348,y:979,t:1526922783680};\\\", \\\"{x:1353,y:980,t:1526922783698};\\\", \\\"{x:1356,y:980,t:1526922783713};\\\", \\\"{x:1359,y:980,t:1526922783730};\\\", \\\"{x:1362,y:980,t:1526922783747};\\\", \\\"{x:1364,y:979,t:1526922783763};\\\", \\\"{x:1369,y:976,t:1526922783781};\\\", \\\"{x:1374,y:973,t:1526922783797};\\\", \\\"{x:1380,y:970,t:1526922783813};\\\", \\\"{x:1384,y:968,t:1526922783830};\\\", \\\"{x:1387,y:965,t:1526922783847};\\\", \\\"{x:1390,y:964,t:1526922783863};\\\", \\\"{x:1392,y:963,t:1526922783880};\\\", \\\"{x:1393,y:962,t:1526922783897};\\\", \\\"{x:1387,y:959,t:1526922784044};\\\", \\\"{x:1380,y:956,t:1526922784052};\\\", \\\"{x:1370,y:948,t:1526922784064};\\\", \\\"{x:1323,y:909,t:1526922784080};\\\", \\\"{x:1230,y:840,t:1526922784097};\\\", \\\"{x:1103,y:752,t:1526922784114};\\\", \\\"{x:976,y:666,t:1526922784130};\\\", \\\"{x:845,y:571,t:1526922784148};\\\", \\\"{x:625,y:429,t:1526922784165};\\\", \\\"{x:504,y:358,t:1526922784181};\\\", \\\"{x:413,y:316,t:1526922784198};\\\", \\\"{x:381,y:306,t:1526922784215};\\\", \\\"{x:359,y:303,t:1526922784232};\\\", \\\"{x:348,y:303,t:1526922784248};\\\", \\\"{x:345,y:303,t:1526922784265};\\\", \\\"{x:343,y:304,t:1526922784282};\\\", \\\"{x:339,y:309,t:1526922784298};\\\", \\\"{x:328,y:324,t:1526922784315};\\\", \\\"{x:305,y:359,t:1526922784333};\\\", \\\"{x:287,y:393,t:1526922784349};\\\", \\\"{x:269,y:434,t:1526922784365};\\\", \\\"{x:259,y:468,t:1526922784383};\\\", \\\"{x:258,y:489,t:1526922784399};\\\", \\\"{x:258,y:500,t:1526922784415};\\\", \\\"{x:258,y:510,t:1526922784431};\\\", \\\"{x:259,y:521,t:1526922784449};\\\", \\\"{x:259,y:527,t:1526922784466};\\\", \\\"{x:259,y:536,t:1526922784482};\\\", \\\"{x:259,y:543,t:1526922784499};\\\", \\\"{x:259,y:549,t:1526922784515};\\\", \\\"{x:257,y:558,t:1526922784533};\\\", \\\"{x:257,y:559,t:1526922784549};\\\", \\\"{x:256,y:560,t:1526922784645};\\\", \\\"{x:255,y:560,t:1526922784652};\\\", \\\"{x:252,y:560,t:1526922784666};\\\", \\\"{x:247,y:560,t:1526922784682};\\\", \\\"{x:241,y:560,t:1526922784699};\\\", \\\"{x:237,y:560,t:1526922784715};\\\", \\\"{x:232,y:558,t:1526922784732};\\\", \\\"{x:228,y:557,t:1526922784749};\\\", \\\"{x:222,y:555,t:1526922784766};\\\", \\\"{x:217,y:554,t:1526922784782};\\\", \\\"{x:213,y:552,t:1526922784800};\\\", \\\"{x:207,y:551,t:1526922784816};\\\", \\\"{x:203,y:550,t:1526922784832};\\\", \\\"{x:202,y:549,t:1526922784849};\\\", \\\"{x:201,y:549,t:1526922784866};\\\", \\\"{x:199,y:549,t:1526922784882};\\\", \\\"{x:197,y:549,t:1526922784899};\\\", \\\"{x:189,y:549,t:1526922784916};\\\", \\\"{x:181,y:549,t:1526922784933};\\\", \\\"{x:175,y:549,t:1526922784949};\\\", \\\"{x:166,y:549,t:1526922784966};\\\", \\\"{x:155,y:549,t:1526922784982};\\\", \\\"{x:144,y:549,t:1526922785000};\\\", \\\"{x:137,y:549,t:1526922785016};\\\", \\\"{x:133,y:549,t:1526922785032};\\\", \\\"{x:131,y:547,t:1526922785049};\\\", \\\"{x:130,y:546,t:1526922785066};\\\", \\\"{x:129,y:544,t:1526922785083};\\\", \\\"{x:129,y:543,t:1526922785099};\\\", \\\"{x:129,y:539,t:1526922785116};\\\", \\\"{x:129,y:532,t:1526922785133};\\\", \\\"{x:129,y:527,t:1526922785149};\\\", \\\"{x:134,y:519,t:1526922785167};\\\", \\\"{x:139,y:512,t:1526922785184};\\\", \\\"{x:144,y:504,t:1526922785199};\\\", \\\"{x:148,y:501,t:1526922785216};\\\", \\\"{x:150,y:500,t:1526922785233};\\\", \\\"{x:151,y:499,t:1526922785249};\\\", \\\"{x:153,y:499,t:1526922785333};\\\", \\\"{x:154,y:499,t:1526922785349};\\\", \\\"{x:155,y:499,t:1526922785372};\\\", \\\"{x:156,y:499,t:1526922785387};\\\", \\\"{x:160,y:502,t:1526922785564};\\\", \\\"{x:165,y:506,t:1526922785572};\\\", \\\"{x:174,y:511,t:1526922785583};\\\", \\\"{x:200,y:525,t:1526922785602};\\\", \\\"{x:249,y:547,t:1526922785616};\\\", \\\"{x:323,y:574,t:1526922785634};\\\", \\\"{x:395,y:598,t:1526922785651};\\\", \\\"{x:454,y:626,t:1526922785666};\\\", \\\"{x:490,y:641,t:1526922785684};\\\", \\\"{x:518,y:653,t:1526922785700};\\\", \\\"{x:521,y:657,t:1526922785716};\\\", \\\"{x:524,y:658,t:1526922785733};\\\", \\\"{x:524,y:659,t:1526922785750};\\\", \\\"{x:524,y:661,t:1526922785772};\\\", \\\"{x:525,y:665,t:1526922785783};\\\", \\\"{x:530,y:678,t:1526922785800};\\\", \\\"{x:535,y:688,t:1526922785818};\\\", \\\"{x:537,y:696,t:1526922785833};\\\", \\\"{x:539,y:703,t:1526922785850};\\\", \\\"{x:539,y:704,t:1526922785867};\\\", \\\"{x:539,y:707,t:1526922785884};\\\", \\\"{x:538,y:715,t:1526922785901};\\\", \\\"{x:533,y:724,t:1526922785918};\\\", \\\"{x:529,y:734,t:1526922785934};\\\", \\\"{x:527,y:738,t:1526922785951};\\\", \\\"{x:527,y:740,t:1526922785967};\\\", \\\"{x:527,y:739,t:1526922786628};\\\", \\\"{x:527,y:738,t:1526922786644};\\\", \\\"{x:527,y:737,t:1526922786676};\\\", \\\"{x:527,y:736,t:1526922786692};\\\", \\\"{x:527,y:735,t:1526922786700};\\\", \\\"{x:527,y:734,t:1526922786724};\\\", \\\"{x:527,y:733,t:1526922786740};\\\", \\\"{x:527,y:732,t:1526922786764};\\\", \\\"{x:527,y:731,t:1526922786844};\\\", \\\"{x:527,y:730,t:1526922786868};\\\", \\\"{x:527,y:729,t:1526922786892};\\\" ] }, { \\\"rt\\\": 41076, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 439419, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"DKL3R\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -F -B -B -12 PM-01 PM-02 PM-05 PM-F -H -B -B -B -F -E -E -E -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:528,y:728,t:1526922788692};\\\", \\\"{x:528,y:727,t:1526922788956};\\\", \\\"{x:528,y:726,t:1526922788968};\\\", \\\"{x:528,y:725,t:1526922788996};\\\", \\\"{x:528,y:724,t:1526922789012};\\\", \\\"{x:528,y:723,t:1526922789052};\\\", \\\"{x:528,y:722,t:1526922789268};\\\", \\\"{x:528,y:720,t:1526922789284};\\\", \\\"{x:528,y:717,t:1526922789302};\\\", \\\"{x:528,y:716,t:1526922789317};\\\", \\\"{x:528,y:712,t:1526922789337};\\\", \\\"{x:528,y:710,t:1526922789353};\\\", \\\"{x:528,y:709,t:1526922789369};\\\", \\\"{x:527,y:709,t:1526922789386};\\\", \\\"{x:527,y:708,t:1526922790060};\\\", \\\"{x:527,y:707,t:1526922790076};\\\", \\\"{x:527,y:704,t:1526922790086};\\\", \\\"{x:524,y:698,t:1526922790103};\\\", \\\"{x:521,y:690,t:1526922790120};\\\", \\\"{x:516,y:678,t:1526922790137};\\\", \\\"{x:511,y:666,t:1526922790154};\\\", \\\"{x:509,y:658,t:1526922790170};\\\", \\\"{x:506,y:653,t:1526922790187};\\\", \\\"{x:506,y:650,t:1526922790203};\\\", \\\"{x:506,y:668,t:1526922790796};\\\", \\\"{x:512,y:711,t:1526922790804};\\\", \\\"{x:550,y:787,t:1526922790821};\\\", \\\"{x:587,y:838,t:1526922790838};\\\", \\\"{x:644,y:882,t:1526922790855};\\\", \\\"{x:721,y:930,t:1526922790870};\\\", \\\"{x:828,y:967,t:1526922790887};\\\", \\\"{x:954,y:994,t:1526922790905};\\\", \\\"{x:1104,y:1003,t:1526922790921};\\\", \\\"{x:1266,y:991,t:1526922790937};\\\", \\\"{x:1424,y:944,t:1526922790955};\\\", \\\"{x:1560,y:872,t:1526922790972};\\\", \\\"{x:1669,y:791,t:1526922790988};\\\", \\\"{x:1762,y:663,t:1526922791004};\\\", \\\"{x:1785,y:615,t:1526922791021};\\\", \\\"{x:1787,y:589,t:1526922791037};\\\", \\\"{x:1784,y:572,t:1526922791054};\\\", \\\"{x:1766,y:558,t:1526922791071};\\\", \\\"{x:1744,y:548,t:1526922791088};\\\", \\\"{x:1716,y:540,t:1526922791104};\\\", \\\"{x:1686,y:537,t:1526922791122};\\\", \\\"{x:1659,y:536,t:1526922791138};\\\", \\\"{x:1636,y:536,t:1526922791154};\\\", \\\"{x:1618,y:536,t:1526922791172};\\\", \\\"{x:1604,y:536,t:1526922791188};\\\", \\\"{x:1584,y:543,t:1526922791204};\\\", \\\"{x:1562,y:550,t:1526922791222};\\\", \\\"{x:1531,y:564,t:1526922791237};\\\", \\\"{x:1495,y:587,t:1526922791255};\\\", \\\"{x:1463,y:610,t:1526922791271};\\\", \\\"{x:1438,y:631,t:1526922791287};\\\", \\\"{x:1416,y:660,t:1526922791305};\\\", \\\"{x:1393,y:689,t:1526922791321};\\\", \\\"{x:1371,y:721,t:1526922791338};\\\", \\\"{x:1358,y:744,t:1526922791355};\\\", \\\"{x:1345,y:766,t:1526922791372};\\\", \\\"{x:1336,y:787,t:1526922791388};\\\", \\\"{x:1335,y:788,t:1526922791405};\\\", \\\"{x:1335,y:787,t:1526922791524};\\\", \\\"{x:1335,y:782,t:1526922791538};\\\", \\\"{x:1340,y:767,t:1526922791555};\\\", \\\"{x:1346,y:753,t:1526922791572};\\\", \\\"{x:1353,y:735,t:1526922791589};\\\", \\\"{x:1356,y:728,t:1526922791605};\\\", \\\"{x:1356,y:725,t:1526922791621};\\\", \\\"{x:1357,y:722,t:1526922791638};\\\", \\\"{x:1358,y:720,t:1526922791655};\\\", \\\"{x:1359,y:716,t:1526922791672};\\\", \\\"{x:1360,y:715,t:1526922791688};\\\", \\\"{x:1360,y:712,t:1526922791704};\\\", \\\"{x:1360,y:709,t:1526922791722};\\\", \\\"{x:1360,y:707,t:1526922791739};\\\", \\\"{x:1360,y:705,t:1526922791756};\\\", \\\"{x:1360,y:703,t:1526922791772};\\\", \\\"{x:1360,y:701,t:1526922791788};\\\", \\\"{x:1359,y:700,t:1526922791812};\\\", \\\"{x:1358,y:700,t:1526922791900};\\\", \\\"{x:1357,y:700,t:1526922791924};\\\", \\\"{x:1356,y:700,t:1526922791948};\\\", \\\"{x:1355,y:700,t:1526922791956};\\\", \\\"{x:1354,y:700,t:1526922791972};\\\", \\\"{x:1353,y:700,t:1526922791988};\\\", \\\"{x:1351,y:700,t:1526922792006};\\\", \\\"{x:1350,y:700,t:1526922792084};\\\", \\\"{x:1349,y:700,t:1526922792125};\\\", \\\"{x:1348,y:700,t:1526922792164};\\\", \\\"{x:1347,y:699,t:1526922792228};\\\", \\\"{x:1346,y:698,t:1526922792348};\\\", \\\"{x:1347,y:698,t:1526922792996};\\\", \\\"{x:1347,y:700,t:1526922793012};\\\", \\\"{x:1347,y:702,t:1526922793028};\\\", \\\"{x:1347,y:704,t:1526922793040};\\\", \\\"{x:1348,y:707,t:1526922793057};\\\", \\\"{x:1348,y:710,t:1526922793073};\\\", \\\"{x:1350,y:712,t:1526922793090};\\\", \\\"{x:1350,y:713,t:1526922793140};\\\", \\\"{x:1350,y:714,t:1526922793188};\\\", \\\"{x:1350,y:715,t:1526922793212};\\\", \\\"{x:1350,y:716,t:1526922793228};\\\", \\\"{x:1350,y:718,t:1526922793239};\\\", \\\"{x:1350,y:720,t:1526922793256};\\\", \\\"{x:1350,y:723,t:1526922793273};\\\", \\\"{x:1350,y:729,t:1526922793290};\\\", \\\"{x:1350,y:735,t:1526922793306};\\\", \\\"{x:1350,y:741,t:1526922793323};\\\", \\\"{x:1350,y:745,t:1526922793339};\\\", \\\"{x:1350,y:749,t:1526922793355};\\\", \\\"{x:1350,y:752,t:1526922793373};\\\", \\\"{x:1350,y:756,t:1526922793390};\\\", \\\"{x:1351,y:761,t:1526922793406};\\\", \\\"{x:1351,y:767,t:1526922793423};\\\", \\\"{x:1352,y:774,t:1526922793440};\\\", \\\"{x:1354,y:781,t:1526922793456};\\\", \\\"{x:1354,y:790,t:1526922793474};\\\", \\\"{x:1356,y:796,t:1526922793490};\\\", \\\"{x:1356,y:808,t:1526922793506};\\\", \\\"{x:1356,y:818,t:1526922793524};\\\", \\\"{x:1356,y:830,t:1526922793540};\\\", \\\"{x:1356,y:850,t:1526922793556};\\\", \\\"{x:1356,y:860,t:1526922793573};\\\", \\\"{x:1356,y:867,t:1526922793589};\\\", \\\"{x:1356,y:875,t:1526922793607};\\\", \\\"{x:1356,y:885,t:1526922793623};\\\", \\\"{x:1356,y:896,t:1526922793640};\\\", \\\"{x:1356,y:908,t:1526922793657};\\\", \\\"{x:1356,y:918,t:1526922793674};\\\", \\\"{x:1356,y:927,t:1526922793689};\\\", \\\"{x:1358,y:936,t:1526922793707};\\\", \\\"{x:1358,y:944,t:1526922793723};\\\", \\\"{x:1358,y:950,t:1526922793740};\\\", \\\"{x:1358,y:955,t:1526922793756};\\\", \\\"{x:1359,y:958,t:1526922793773};\\\", \\\"{x:1359,y:960,t:1526922793789};\\\", \\\"{x:1359,y:964,t:1526922793807};\\\", \\\"{x:1359,y:965,t:1526922793824};\\\", \\\"{x:1359,y:968,t:1526922793841};\\\", \\\"{x:1359,y:969,t:1526922793856};\\\", \\\"{x:1359,y:970,t:1526922793874};\\\", \\\"{x:1359,y:971,t:1526922793891};\\\", \\\"{x:1359,y:972,t:1526922793948};\\\", \\\"{x:1358,y:972,t:1526922794076};\\\", \\\"{x:1358,y:971,t:1526922794091};\\\", \\\"{x:1359,y:970,t:1526922794106};\\\", \\\"{x:1364,y:970,t:1526922794123};\\\", \\\"{x:1372,y:970,t:1526922794141};\\\", \\\"{x:1379,y:970,t:1526922794157};\\\", \\\"{x:1388,y:970,t:1526922794174};\\\", \\\"{x:1401,y:970,t:1526922794191};\\\", \\\"{x:1415,y:970,t:1526922794208};\\\", \\\"{x:1430,y:970,t:1526922794223};\\\", \\\"{x:1445,y:970,t:1526922794241};\\\", \\\"{x:1459,y:970,t:1526922794258};\\\", \\\"{x:1471,y:970,t:1526922794274};\\\", \\\"{x:1490,y:970,t:1526922794291};\\\", \\\"{x:1504,y:968,t:1526922794307};\\\", \\\"{x:1517,y:968,t:1526922794324};\\\", \\\"{x:1536,y:966,t:1526922794340};\\\", \\\"{x:1549,y:963,t:1526922794357};\\\", \\\"{x:1559,y:962,t:1526922794374};\\\", \\\"{x:1567,y:960,t:1526922794391};\\\", \\\"{x:1572,y:960,t:1526922794408};\\\", \\\"{x:1578,y:958,t:1526922794423};\\\", \\\"{x:1582,y:958,t:1526922794441};\\\", \\\"{x:1586,y:958,t:1526922794457};\\\", \\\"{x:1589,y:957,t:1526922794474};\\\", \\\"{x:1593,y:957,t:1526922794491};\\\", \\\"{x:1597,y:956,t:1526922794508};\\\", \\\"{x:1601,y:956,t:1526922794524};\\\", \\\"{x:1608,y:954,t:1526922794540};\\\", \\\"{x:1611,y:954,t:1526922794558};\\\", \\\"{x:1615,y:954,t:1526922794573};\\\", \\\"{x:1617,y:954,t:1526922794591};\\\", \\\"{x:1621,y:954,t:1526922794608};\\\", \\\"{x:1622,y:954,t:1526922794624};\\\", \\\"{x:1623,y:954,t:1526922794708};\\\", \\\"{x:1623,y:955,t:1526922794740};\\\", \\\"{x:1623,y:956,t:1526922794748};\\\", \\\"{x:1623,y:957,t:1526922794758};\\\", \\\"{x:1623,y:958,t:1526922794775};\\\", \\\"{x:1623,y:960,t:1526922794790};\\\", \\\"{x:1623,y:961,t:1526922794808};\\\", \\\"{x:1622,y:961,t:1526922794825};\\\", \\\"{x:1622,y:962,t:1526922794924};\\\", \\\"{x:1622,y:963,t:1526922794948};\\\", \\\"{x:1621,y:964,t:1526922794957};\\\", \\\"{x:1620,y:965,t:1526922794981};\\\", \\\"{x:1620,y:966,t:1526922795012};\\\", \\\"{x:1619,y:966,t:1526922796500};\\\", \\\"{x:1617,y:965,t:1526922796940};\\\", \\\"{x:1616,y:965,t:1526922796956};\\\", \\\"{x:1615,y:962,t:1526922796963};\\\", \\\"{x:1613,y:955,t:1526922796976};\\\", \\\"{x:1608,y:935,t:1526922796992};\\\", \\\"{x:1586,y:881,t:1526922797011};\\\", \\\"{x:1555,y:765,t:1526922797027};\\\", \\\"{x:1506,y:559,t:1526922797042};\\\", \\\"{x:1439,y:359,t:1526922797060};\\\", \\\"{x:1295,y:109,t:1526922797076};\\\", \\\"{x:1190,y:0,t:1526922797093};\\\", \\\"{x:1073,y:0,t:1526922797110};\\\", \\\"{x:950,y:0,t:1526922797127};\\\", \\\"{x:831,y:0,t:1526922797143};\\\", \\\"{x:717,y:0,t:1526922797160};\\\", \\\"{x:636,y:0,t:1526922797176};\\\", \\\"{x:577,y:0,t:1526922797193};\\\", \\\"{x:512,y:0,t:1526922797210};\\\", \\\"{x:434,y:0,t:1526922797226};\\\", \\\"{x:339,y:0,t:1526922797242};\\\", \\\"{x:186,y:7,t:1526922797260};\\\", \\\"{x:84,y:33,t:1526922797276};\\\", \\\"{x:0,y:67,t:1526922797292};\\\", \\\"{x:0,y:108,t:1526922797310};\\\", \\\"{x:0,y:149,t:1526922797327};\\\", \\\"{x:0,y:189,t:1526922797342};\\\", \\\"{x:0,y:235,t:1526922797360};\\\", \\\"{x:0,y:274,t:1526922797377};\\\", \\\"{x:0,y:326,t:1526922797393};\\\", \\\"{x:0,y:377,t:1526922797411};\\\", \\\"{x:0,y:431,t:1526922797427};\\\", \\\"{x:0,y:472,t:1526922797443};\\\", \\\"{x:0,y:510,t:1526922797460};\\\", \\\"{x:0,y:546,t:1526922797476};\\\", \\\"{x:0,y:561,t:1526922797493};\\\", \\\"{x:0,y:578,t:1526922797509};\\\", \\\"{x:0,y:593,t:1526922797526};\\\", \\\"{x:0,y:607,t:1526922797543};\\\", \\\"{x:0,y:621,t:1526922797560};\\\", \\\"{x:0,y:631,t:1526922797577};\\\", \\\"{x:1,y:641,t:1526922797593};\\\", \\\"{x:4,y:648,t:1526922797610};\\\", \\\"{x:7,y:653,t:1526922797627};\\\", \\\"{x:11,y:660,t:1526922797644};\\\", \\\"{x:16,y:666,t:1526922797660};\\\", \\\"{x:20,y:670,t:1526922797677};\\\", \\\"{x:23,y:673,t:1526922797694};\\\", \\\"{x:30,y:677,t:1526922797709};\\\", \\\"{x:38,y:681,t:1526922797726};\\\", \\\"{x:54,y:683,t:1526922797744};\\\", \\\"{x:76,y:687,t:1526922797760};\\\", \\\"{x:103,y:692,t:1526922797777};\\\", \\\"{x:135,y:693,t:1526922797793};\\\", \\\"{x:171,y:693,t:1526922797810};\\\", \\\"{x:213,y:693,t:1526922797826};\\\", \\\"{x:253,y:693,t:1526922797844};\\\", \\\"{x:294,y:692,t:1526922797860};\\\", \\\"{x:310,y:684,t:1526922797876};\\\", \\\"{x:316,y:677,t:1526922797894};\\\", \\\"{x:318,y:664,t:1526922797911};\\\", \\\"{x:318,y:652,t:1526922797926};\\\", \\\"{x:318,y:638,t:1526922797944};\\\", \\\"{x:311,y:621,t:1526922797960};\\\", \\\"{x:307,y:610,t:1526922797976};\\\", \\\"{x:304,y:602,t:1526922797992};\\\", \\\"{x:302,y:599,t:1526922798010};\\\", \\\"{x:301,y:599,t:1526922798172};\\\", \\\"{x:296,y:599,t:1526922798180};\\\", \\\"{x:284,y:599,t:1526922798194};\\\", \\\"{x:254,y:598,t:1526922798210};\\\", \\\"{x:210,y:592,t:1526922798227};\\\", \\\"{x:117,y:582,t:1526922798244};\\\", \\\"{x:66,y:580,t:1526922798259};\\\", \\\"{x:38,y:577,t:1526922798277};\\\", \\\"{x:23,y:572,t:1526922798293};\\\", \\\"{x:20,y:572,t:1526922798309};\\\", \\\"{x:19,y:571,t:1526922798340};\\\", \\\"{x:19,y:570,t:1526922798348};\\\", \\\"{x:20,y:570,t:1526922798360};\\\", \\\"{x:24,y:568,t:1526922798376};\\\", \\\"{x:32,y:565,t:1526922798394};\\\", \\\"{x:50,y:560,t:1526922798410};\\\", \\\"{x:83,y:555,t:1526922798427};\\\", \\\"{x:182,y:541,t:1526922798444};\\\", \\\"{x:270,y:532,t:1526922798460};\\\", \\\"{x:369,y:524,t:1526922798478};\\\", \\\"{x:461,y:522,t:1526922798494};\\\", \\\"{x:539,y:522,t:1526922798510};\\\", \\\"{x:594,y:516,t:1526922798528};\\\", \\\"{x:638,y:511,t:1526922798544};\\\", \\\"{x:677,y:511,t:1526922798560};\\\", \\\"{x:707,y:511,t:1526922798576};\\\", \\\"{x:741,y:511,t:1526922798594};\\\", \\\"{x:766,y:511,t:1526922798611};\\\", \\\"{x:787,y:511,t:1526922798627};\\\", \\\"{x:813,y:515,t:1526922798644};\\\", \\\"{x:833,y:517,t:1526922798659};\\\", \\\"{x:856,y:523,t:1526922798677};\\\", \\\"{x:891,y:534,t:1526922798695};\\\", \\\"{x:939,y:547,t:1526922798711};\\\", \\\"{x:1006,y:567,t:1526922798727};\\\", \\\"{x:1089,y:589,t:1526922798744};\\\", \\\"{x:1188,y:617,t:1526922798761};\\\", \\\"{x:1302,y:650,t:1526922798776};\\\", \\\"{x:1420,y:682,t:1526922798794};\\\", \\\"{x:1542,y:713,t:1526922798810};\\\", \\\"{x:1632,y:732,t:1526922798827};\\\", \\\"{x:1731,y:747,t:1526922798844};\\\", \\\"{x:1768,y:753,t:1526922798861};\\\", \\\"{x:1786,y:754,t:1526922798878};\\\", \\\"{x:1790,y:754,t:1526922798894};\\\", \\\"{x:1791,y:755,t:1526922798956};\\\", \\\"{x:1791,y:758,t:1526922798964};\\\", \\\"{x:1791,y:767,t:1526922798978};\\\", \\\"{x:1785,y:791,t:1526922798994};\\\", \\\"{x:1774,y:824,t:1526922799011};\\\", \\\"{x:1752,y:875,t:1526922799028};\\\", \\\"{x:1740,y:905,t:1526922799044};\\\", \\\"{x:1726,y:931,t:1526922799060};\\\", \\\"{x:1715,y:949,t:1526922799078};\\\", \\\"{x:1706,y:966,t:1526922799095};\\\", \\\"{x:1697,y:976,t:1526922799111};\\\", \\\"{x:1693,y:982,t:1526922799128};\\\", \\\"{x:1687,y:990,t:1526922799145};\\\", \\\"{x:1686,y:991,t:1526922799160};\\\", \\\"{x:1684,y:992,t:1526922799177};\\\", \\\"{x:1682,y:993,t:1526922799194};\\\", \\\"{x:1679,y:993,t:1526922799211};\\\", \\\"{x:1674,y:993,t:1526922799228};\\\", \\\"{x:1671,y:993,t:1526922799244};\\\", \\\"{x:1667,y:989,t:1526922799261};\\\", \\\"{x:1661,y:985,t:1526922799278};\\\", \\\"{x:1655,y:979,t:1526922799295};\\\", \\\"{x:1647,y:969,t:1526922799310};\\\", \\\"{x:1640,y:960,t:1526922799327};\\\", \\\"{x:1634,y:955,t:1526922799345};\\\", \\\"{x:1631,y:952,t:1526922799361};\\\", \\\"{x:1630,y:952,t:1526922799378};\\\", \\\"{x:1629,y:951,t:1526922799589};\\\", \\\"{x:1629,y:950,t:1526922799604};\\\", \\\"{x:1628,y:950,t:1526922799612};\\\", \\\"{x:1623,y:945,t:1526922800740};\\\", \\\"{x:1606,y:936,t:1526922800748};\\\", \\\"{x:1540,y:877,t:1526922800764};\\\", \\\"{x:1460,y:809,t:1526922800780};\\\", \\\"{x:1360,y:738,t:1526922800797};\\\", \\\"{x:1224,y:643,t:1526922800814};\\\", \\\"{x:1084,y:553,t:1526922800830};\\\", \\\"{x:934,y:475,t:1526922800847};\\\", \\\"{x:801,y:419,t:1526922800864};\\\", \\\"{x:675,y:365,t:1526922800880};\\\", \\\"{x:572,y:335,t:1526922800897};\\\", \\\"{x:473,y:307,t:1526922800914};\\\", \\\"{x:379,y:283,t:1526922800930};\\\", \\\"{x:310,y:266,t:1526922800946};\\\", \\\"{x:229,y:250,t:1526922800964};\\\", \\\"{x:173,y:242,t:1526922800980};\\\", \\\"{x:125,y:240,t:1526922800996};\\\", \\\"{x:104,y:240,t:1526922801013};\\\", \\\"{x:92,y:244,t:1526922801030};\\\", \\\"{x:85,y:250,t:1526922801047};\\\", \\\"{x:79,y:257,t:1526922801064};\\\", \\\"{x:76,y:266,t:1526922801081};\\\", \\\"{x:74,y:274,t:1526922801097};\\\", \\\"{x:74,y:280,t:1526922801114};\\\", \\\"{x:74,y:289,t:1526922801131};\\\", \\\"{x:79,y:320,t:1526922801148};\\\", \\\"{x:89,y:344,t:1526922801164};\\\", \\\"{x:99,y:371,t:1526922801180};\\\", \\\"{x:112,y:394,t:1526922801198};\\\", \\\"{x:125,y:414,t:1526922801214};\\\", \\\"{x:136,y:430,t:1526922801231};\\\", \\\"{x:144,y:441,t:1526922801248};\\\", \\\"{x:152,y:449,t:1526922801264};\\\", \\\"{x:155,y:452,t:1526922801281};\\\", \\\"{x:157,y:453,t:1526922801298};\\\", \\\"{x:158,y:454,t:1526922801314};\\\", \\\"{x:159,y:455,t:1526922801331};\\\", \\\"{x:162,y:456,t:1526922801348};\\\", \\\"{x:163,y:457,t:1526922801372};\\\", \\\"{x:163,y:458,t:1526922801388};\\\", \\\"{x:164,y:458,t:1526922801404};\\\", \\\"{x:165,y:458,t:1526922801436};\\\", \\\"{x:166,y:459,t:1526922801448};\\\", \\\"{x:167,y:459,t:1526922801476};\\\", \\\"{x:167,y:460,t:1526922801484};\\\", \\\"{x:168,y:461,t:1526922801516};\\\", \\\"{x:169,y:461,t:1526922801540};\\\", \\\"{x:170,y:461,t:1526922801548};\\\", \\\"{x:170,y:462,t:1526922801572};\\\", \\\"{x:171,y:462,t:1526922802028};\\\", \\\"{x:173,y:463,t:1526922802043};\\\", \\\"{x:174,y:463,t:1526922802051};\\\", \\\"{x:175,y:463,t:1526922802067};\\\", \\\"{x:177,y:463,t:1526922802082};\\\", \\\"{x:179,y:464,t:1526922802099};\\\", \\\"{x:182,y:464,t:1526922802115};\\\", \\\"{x:183,y:464,t:1526922802132};\\\", \\\"{x:187,y:464,t:1526922802148};\\\", \\\"{x:190,y:464,t:1526922802166};\\\", \\\"{x:197,y:464,t:1526922802182};\\\", \\\"{x:201,y:464,t:1526922802199};\\\", \\\"{x:206,y:466,t:1526922802215};\\\", \\\"{x:211,y:466,t:1526922802232};\\\", \\\"{x:215,y:467,t:1526922802249};\\\", \\\"{x:216,y:467,t:1526922802266};\\\", \\\"{x:217,y:468,t:1526922802283};\\\", \\\"{x:218,y:468,t:1526922802299};\\\", \\\"{x:219,y:468,t:1526922802331};\\\", \\\"{x:219,y:469,t:1526922802348};\\\", \\\"{x:220,y:469,t:1526922802356};\\\", \\\"{x:221,y:470,t:1526922802380};\\\", \\\"{x:222,y:471,t:1526922802388};\\\", \\\"{x:226,y:472,t:1526922802404};\\\", \\\"{x:227,y:474,t:1526922802415};\\\", \\\"{x:229,y:474,t:1526922802433};\\\", \\\"{x:233,y:477,t:1526922802449};\\\", \\\"{x:242,y:482,t:1526922802466};\\\", \\\"{x:257,y:489,t:1526922802483};\\\", \\\"{x:277,y:497,t:1526922802502};\\\", \\\"{x:294,y:502,t:1526922802515};\\\", \\\"{x:306,y:505,t:1526922802530};\\\", \\\"{x:320,y:507,t:1526922802547};\\\", \\\"{x:328,y:508,t:1526922802564};\\\", \\\"{x:331,y:508,t:1526922802579};\\\", \\\"{x:333,y:508,t:1526922802612};\\\", \\\"{x:335,y:508,t:1526922802627};\\\", \\\"{x:337,y:507,t:1526922802635};\\\", \\\"{x:338,y:505,t:1526922802647};\\\", \\\"{x:344,y:502,t:1526922802664};\\\", \\\"{x:351,y:498,t:1526922802680};\\\", \\\"{x:357,y:493,t:1526922802697};\\\", \\\"{x:360,y:489,t:1526922802714};\\\", \\\"{x:364,y:484,t:1526922802731};\\\", \\\"{x:365,y:482,t:1526922802747};\\\", \\\"{x:368,y:478,t:1526922802764};\\\", \\\"{x:370,y:475,t:1526922802781};\\\", \\\"{x:373,y:472,t:1526922802797};\\\", \\\"{x:379,y:468,t:1526922802814};\\\", \\\"{x:383,y:467,t:1526922802830};\\\", \\\"{x:388,y:464,t:1526922802846};\\\", \\\"{x:393,y:464,t:1526922802864};\\\", \\\"{x:397,y:463,t:1526922802881};\\\", \\\"{x:400,y:463,t:1526922802897};\\\", \\\"{x:406,y:462,t:1526922802913};\\\", \\\"{x:409,y:462,t:1526922802931};\\\", \\\"{x:414,y:460,t:1526922802947};\\\", \\\"{x:423,y:460,t:1526922802964};\\\", \\\"{x:433,y:460,t:1526922802980};\\\", \\\"{x:443,y:459,t:1526922802997};\\\", \\\"{x:448,y:458,t:1526922803014};\\\", \\\"{x:455,y:457,t:1526922803031};\\\", \\\"{x:460,y:456,t:1526922803048};\\\", \\\"{x:466,y:456,t:1526922803064};\\\", \\\"{x:472,y:456,t:1526922803081};\\\", \\\"{x:480,y:456,t:1526922803097};\\\", \\\"{x:488,y:455,t:1526922803114};\\\", \\\"{x:497,y:455,t:1526922803130};\\\", \\\"{x:506,y:452,t:1526922803148};\\\", \\\"{x:510,y:452,t:1526922803164};\\\", \\\"{x:512,y:452,t:1526922803181};\\\", \\\"{x:515,y:451,t:1526922803198};\\\", \\\"{x:516,y:451,t:1526922803219};\\\", \\\"{x:517,y:451,t:1526922803292};\\\", \\\"{x:518,y:451,t:1526922803308};\\\", \\\"{x:519,y:451,t:1526922803332};\\\", \\\"{x:521,y:450,t:1526922803348};\\\", \\\"{x:522,y:450,t:1526922803364};\\\", \\\"{x:524,y:450,t:1526922803381};\\\", \\\"{x:525,y:450,t:1526922803398};\\\", \\\"{x:528,y:450,t:1526922803415};\\\", \\\"{x:529,y:450,t:1526922803431};\\\", \\\"{x:531,y:450,t:1526922803448};\\\", \\\"{x:533,y:450,t:1526922803465};\\\", \\\"{x:534,y:450,t:1526922803482};\\\", \\\"{x:536,y:450,t:1526922803498};\\\", \\\"{x:537,y:450,t:1526922803515};\\\", \\\"{x:538,y:450,t:1526922803532};\\\", \\\"{x:539,y:450,t:1526922803548};\\\", \\\"{x:540,y:450,t:1526922803565};\\\", \\\"{x:542,y:451,t:1526922803582};\\\", \\\"{x:545,y:452,t:1526922803598};\\\", \\\"{x:549,y:453,t:1526922803615};\\\", \\\"{x:556,y:455,t:1526922803632};\\\", \\\"{x:562,y:457,t:1526922803648};\\\", \\\"{x:569,y:457,t:1526922803665};\\\", \\\"{x:575,y:459,t:1526922803681};\\\", \\\"{x:581,y:460,t:1526922803699};\\\", \\\"{x:584,y:460,t:1526922803714};\\\", \\\"{x:587,y:461,t:1526922803732};\\\", \\\"{x:588,y:461,t:1526922803749};\\\", \\\"{x:589,y:461,t:1526922803780};\\\", \\\"{x:590,y:461,t:1526922803844};\\\", \\\"{x:591,y:463,t:1526922803860};\\\", \\\"{x:592,y:463,t:1526922803876};\\\", \\\"{x:594,y:463,t:1526922803892};\\\", \\\"{x:596,y:463,t:1526922803899};\\\", \\\"{x:599,y:463,t:1526922803915};\\\", \\\"{x:602,y:463,t:1526922803932};\\\", \\\"{x:606,y:464,t:1526922803949};\\\", \\\"{x:609,y:464,t:1526922803966};\\\", \\\"{x:612,y:465,t:1526922803982};\\\", \\\"{x:617,y:466,t:1526922803999};\\\", \\\"{x:620,y:466,t:1526922804015};\\\", \\\"{x:623,y:466,t:1526922804032};\\\", \\\"{x:627,y:466,t:1526922804049};\\\", \\\"{x:629,y:466,t:1526922804065};\\\", \\\"{x:632,y:466,t:1526922804082};\\\", \\\"{x:635,y:466,t:1526922804099};\\\", \\\"{x:638,y:466,t:1526922804116};\\\", \\\"{x:640,y:466,t:1526922804132};\\\", \\\"{x:643,y:466,t:1526922804148};\\\", \\\"{x:646,y:466,t:1526922804166};\\\", \\\"{x:649,y:466,t:1526922804183};\\\", \\\"{x:652,y:466,t:1526922804199};\\\", \\\"{x:655,y:467,t:1526922804216};\\\", \\\"{x:659,y:468,t:1526922804233};\\\", \\\"{x:661,y:468,t:1526922804249};\\\", \\\"{x:663,y:468,t:1526922804265};\\\", \\\"{x:664,y:468,t:1526922804283};\\\", \\\"{x:665,y:468,t:1526922804299};\\\", \\\"{x:666,y:468,t:1526922804316};\\\", \\\"{x:667,y:470,t:1526922804333};\\\", \\\"{x:671,y:470,t:1526922804350};\\\", \\\"{x:672,y:470,t:1526922804366};\\\", \\\"{x:681,y:471,t:1526922804383};\\\", \\\"{x:699,y:474,t:1526922804399};\\\", \\\"{x:732,y:480,t:1526922804416};\\\", \\\"{x:820,y:486,t:1526922804433};\\\", \\\"{x:952,y:501,t:1526922804450};\\\", \\\"{x:1116,y:505,t:1526922804465};\\\", \\\"{x:1312,y:507,t:1526922804483};\\\", \\\"{x:1628,y:514,t:1526922804499};\\\", \\\"{x:1805,y:514,t:1526922804517};\\\", \\\"{x:1893,y:513,t:1526922804532};\\\", \\\"{x:1910,y:634,t:1526922804764};\\\", \\\"{x:1871,y:645,t:1526922804772};\\\", \\\"{x:1838,y:654,t:1526922804782};\\\", \\\"{x:1790,y:661,t:1526922804799};\\\", \\\"{x:1759,y:666,t:1526922804815};\\\", \\\"{x:1738,y:667,t:1526922804831};\\\", \\\"{x:1721,y:667,t:1526922804849};\\\", \\\"{x:1710,y:667,t:1526922804865};\\\", \\\"{x:1696,y:667,t:1526922804882};\\\", \\\"{x:1677,y:667,t:1526922804899};\\\", \\\"{x:1650,y:667,t:1526922804915};\\\", \\\"{x:1613,y:667,t:1526922804932};\\\", \\\"{x:1590,y:667,t:1526922804949};\\\", \\\"{x:1575,y:667,t:1526922804965};\\\", \\\"{x:1565,y:667,t:1526922804982};\\\", \\\"{x:1555,y:670,t:1526922804998};\\\", \\\"{x:1547,y:675,t:1526922805015};\\\", \\\"{x:1539,y:682,t:1526922805032};\\\", \\\"{x:1525,y:691,t:1526922805049};\\\", \\\"{x:1505,y:705,t:1526922805065};\\\", \\\"{x:1479,y:716,t:1526922805082};\\\", \\\"{x:1447,y:726,t:1526922805099};\\\", \\\"{x:1416,y:734,t:1526922805115};\\\", \\\"{x:1376,y:737,t:1526922805132};\\\", \\\"{x:1358,y:737,t:1526922805149};\\\", \\\"{x:1343,y:737,t:1526922805166};\\\", \\\"{x:1334,y:736,t:1526922805182};\\\", \\\"{x:1329,y:732,t:1526922805199};\\\", \\\"{x:1325,y:730,t:1526922805215};\\\", \\\"{x:1322,y:728,t:1526922805232};\\\", \\\"{x:1321,y:725,t:1526922805249};\\\", \\\"{x:1320,y:722,t:1526922805266};\\\", \\\"{x:1319,y:719,t:1526922805282};\\\", \\\"{x:1319,y:717,t:1526922805299};\\\", \\\"{x:1319,y:714,t:1526922805316};\\\", \\\"{x:1321,y:710,t:1526922805332};\\\", \\\"{x:1326,y:708,t:1526922805349};\\\", \\\"{x:1331,y:705,t:1526922805366};\\\", \\\"{x:1334,y:704,t:1526922805382};\\\", \\\"{x:1337,y:703,t:1526922805399};\\\", \\\"{x:1340,y:703,t:1526922805416};\\\", \\\"{x:1340,y:702,t:1526922805432};\\\", \\\"{x:1341,y:701,t:1526922805459};\\\", \\\"{x:1342,y:701,t:1526922805723};\\\", \\\"{x:1342,y:700,t:1526922805748};\\\", \\\"{x:1343,y:700,t:1526922805812};\\\", \\\"{x:1343,y:699,t:1526922805833};\\\", \\\"{x:1345,y:698,t:1526922805892};\\\", \\\"{x:1345,y:703,t:1526922810689};\\\", \\\"{x:1345,y:709,t:1526922810696};\\\", \\\"{x:1345,y:712,t:1526922810708};\\\", \\\"{x:1346,y:720,t:1526922810724};\\\", \\\"{x:1346,y:727,t:1526922810740};\\\", \\\"{x:1346,y:732,t:1526922810758};\\\", \\\"{x:1348,y:738,t:1526922810774};\\\", \\\"{x:1348,y:743,t:1526922810790};\\\", \\\"{x:1352,y:749,t:1526922810807};\\\", \\\"{x:1370,y:771,t:1526922810824};\\\", \\\"{x:1388,y:792,t:1526922810841};\\\", \\\"{x:1416,y:822,t:1526922810857};\\\", \\\"{x:1454,y:856,t:1526922810874};\\\", \\\"{x:1499,y:886,t:1526922810892};\\\", \\\"{x:1536,y:911,t:1526922810907};\\\", \\\"{x:1571,y:931,t:1526922810924};\\\", \\\"{x:1598,y:943,t:1526922810941};\\\", \\\"{x:1618,y:951,t:1526922810957};\\\", \\\"{x:1631,y:955,t:1526922810974};\\\", \\\"{x:1638,y:959,t:1526922810992};\\\", \\\"{x:1641,y:962,t:1526922811007};\\\", \\\"{x:1644,y:963,t:1526922811025};\\\", \\\"{x:1645,y:964,t:1526922811047};\\\", \\\"{x:1645,y:965,t:1526922811071};\\\", \\\"{x:1646,y:965,t:1526922811128};\\\", \\\"{x:1643,y:965,t:1526922811232};\\\", \\\"{x:1640,y:964,t:1526922811241};\\\", \\\"{x:1635,y:964,t:1526922811257};\\\", \\\"{x:1634,y:964,t:1526922811274};\\\", \\\"{x:1633,y:964,t:1526922811291};\\\", \\\"{x:1632,y:964,t:1526922811320};\\\", \\\"{x:1630,y:964,t:1526922811352};\\\", \\\"{x:1629,y:964,t:1526922811360};\\\", \\\"{x:1627,y:965,t:1526922811374};\\\", \\\"{x:1625,y:966,t:1526922811391};\\\", \\\"{x:1624,y:966,t:1526922811408};\\\", \\\"{x:1623,y:966,t:1526922811544};\\\", \\\"{x:1622,y:966,t:1526922811583};\\\", \\\"{x:1620,y:966,t:1526922811591};\\\", \\\"{x:1619,y:965,t:1526922811632};\\\", \\\"{x:1619,y:964,t:1526922811672};\\\", \\\"{x:1619,y:963,t:1526922811679};\\\", \\\"{x:1619,y:962,t:1526922811691};\\\", \\\"{x:1618,y:960,t:1526922811708};\\\", \\\"{x:1618,y:959,t:1526922811725};\\\", \\\"{x:1618,y:955,t:1526922811741};\\\", \\\"{x:1618,y:949,t:1526922811759};\\\", \\\"{x:1618,y:942,t:1526922811775};\\\", \\\"{x:1618,y:933,t:1526922811791};\\\", \\\"{x:1618,y:919,t:1526922811808};\\\", \\\"{x:1618,y:911,t:1526922811825};\\\", \\\"{x:1618,y:903,t:1526922811841};\\\", \\\"{x:1618,y:895,t:1526922811859};\\\", \\\"{x:1618,y:890,t:1526922811876};\\\", \\\"{x:1617,y:881,t:1526922811891};\\\", \\\"{x:1616,y:872,t:1526922811909};\\\", \\\"{x:1611,y:857,t:1526922811926};\\\", \\\"{x:1608,y:839,t:1526922811941};\\\", \\\"{x:1603,y:814,t:1526922811959};\\\", \\\"{x:1598,y:796,t:1526922811975};\\\", \\\"{x:1594,y:780,t:1526922811991};\\\", \\\"{x:1592,y:763,t:1526922812008};\\\", \\\"{x:1590,y:752,t:1526922812026};\\\", \\\"{x:1589,y:745,t:1526922812042};\\\", \\\"{x:1589,y:740,t:1526922812059};\\\", \\\"{x:1589,y:735,t:1526922812075};\\\", \\\"{x:1589,y:730,t:1526922812092};\\\", \\\"{x:1588,y:723,t:1526922812109};\\\", \\\"{x:1588,y:718,t:1526922812125};\\\", \\\"{x:1588,y:713,t:1526922812141};\\\", \\\"{x:1588,y:708,t:1526922812158};\\\", \\\"{x:1588,y:705,t:1526922812175};\\\", \\\"{x:1588,y:701,t:1526922812192};\\\", \\\"{x:1588,y:697,t:1526922812208};\\\", \\\"{x:1588,y:695,t:1526922812225};\\\", \\\"{x:1586,y:693,t:1526922812243};\\\", \\\"{x:1586,y:690,t:1526922812259};\\\", \\\"{x:1586,y:688,t:1526922812275};\\\", \\\"{x:1585,y:685,t:1526922812293};\\\", \\\"{x:1584,y:679,t:1526922812308};\\\", \\\"{x:1584,y:675,t:1526922812326};\\\", \\\"{x:1584,y:673,t:1526922812342};\\\", \\\"{x:1584,y:669,t:1526922812358};\\\", \\\"{x:1583,y:667,t:1526922812375};\\\", \\\"{x:1582,y:662,t:1526922812392};\\\", \\\"{x:1581,y:658,t:1526922812408};\\\", \\\"{x:1581,y:655,t:1526922812425};\\\", \\\"{x:1581,y:651,t:1526922812443};\\\", \\\"{x:1581,y:648,t:1526922812459};\\\", \\\"{x:1581,y:645,t:1526922812476};\\\", \\\"{x:1581,y:642,t:1526922812493};\\\", \\\"{x:1581,y:639,t:1526922812508};\\\", \\\"{x:1581,y:636,t:1526922812525};\\\", \\\"{x:1580,y:634,t:1526922812543};\\\", \\\"{x:1580,y:632,t:1526922812575};\\\", \\\"{x:1580,y:631,t:1526922812592};\\\", \\\"{x:1580,y:629,t:1526922812609};\\\", \\\"{x:1580,y:628,t:1526922812625};\\\", \\\"{x:1580,y:627,t:1526922812664};\\\", \\\"{x:1578,y:633,t:1526922817328};\\\", \\\"{x:1575,y:639,t:1526922817337};\\\", \\\"{x:1572,y:645,t:1526922817346};\\\", \\\"{x:1566,y:657,t:1526922817362};\\\", \\\"{x:1558,y:668,t:1526922817380};\\\", \\\"{x:1553,y:676,t:1526922817396};\\\", \\\"{x:1552,y:680,t:1526922817413};\\\", \\\"{x:1548,y:688,t:1526922817430};\\\", \\\"{x:1545,y:695,t:1526922817447};\\\", \\\"{x:1542,y:704,t:1526922817463};\\\", \\\"{x:1536,y:718,t:1526922817480};\\\", \\\"{x:1530,y:731,t:1526922817496};\\\", \\\"{x:1525,y:743,t:1526922817512};\\\", \\\"{x:1519,y:755,t:1526922817530};\\\", \\\"{x:1510,y:769,t:1526922817547};\\\", \\\"{x:1502,y:782,t:1526922817563};\\\", \\\"{x:1493,y:792,t:1526922817580};\\\", \\\"{x:1485,y:802,t:1526922817596};\\\", \\\"{x:1480,y:808,t:1526922817612};\\\", \\\"{x:1475,y:816,t:1526922817630};\\\", \\\"{x:1470,y:823,t:1526922817646};\\\", \\\"{x:1466,y:830,t:1526922817662};\\\", \\\"{x:1458,y:843,t:1526922817680};\\\", \\\"{x:1457,y:848,t:1526922817696};\\\", \\\"{x:1454,y:852,t:1526922817713};\\\", \\\"{x:1453,y:855,t:1526922817729};\\\", \\\"{x:1453,y:858,t:1526922817747};\\\", \\\"{x:1451,y:861,t:1526922817763};\\\", \\\"{x:1451,y:863,t:1526922817780};\\\", \\\"{x:1451,y:866,t:1526922817797};\\\", \\\"{x:1452,y:869,t:1526922817813};\\\", \\\"{x:1455,y:873,t:1526922817829};\\\", \\\"{x:1461,y:877,t:1526922817847};\\\", \\\"{x:1477,y:884,t:1526922817864};\\\", \\\"{x:1483,y:886,t:1526922817879};\\\", \\\"{x:1508,y:896,t:1526922817897};\\\", \\\"{x:1524,y:902,t:1526922817914};\\\", \\\"{x:1541,y:908,t:1526922817930};\\\", \\\"{x:1554,y:911,t:1526922817946};\\\", \\\"{x:1562,y:916,t:1526922817964};\\\", \\\"{x:1567,y:919,t:1526922817980};\\\", \\\"{x:1573,y:923,t:1526922817996};\\\", \\\"{x:1580,y:928,t:1526922818013};\\\", \\\"{x:1587,y:932,t:1526922818029};\\\", \\\"{x:1595,y:936,t:1526922818047};\\\", \\\"{x:1602,y:940,t:1526922818064};\\\", \\\"{x:1605,y:942,t:1526922818079};\\\", \\\"{x:1606,y:943,t:1526922818112};\\\", \\\"{x:1606,y:944,t:1526922818136};\\\", \\\"{x:1606,y:946,t:1526922818147};\\\", \\\"{x:1607,y:949,t:1526922818164};\\\", \\\"{x:1607,y:950,t:1526922818179};\\\", \\\"{x:1607,y:953,t:1526922818197};\\\", \\\"{x:1607,y:958,t:1526922818213};\\\", \\\"{x:1607,y:959,t:1526922818230};\\\", \\\"{x:1607,y:962,t:1526922818247};\\\", \\\"{x:1607,y:964,t:1526922818264};\\\", \\\"{x:1608,y:966,t:1526922818280};\\\", \\\"{x:1609,y:966,t:1526922818297};\\\", \\\"{x:1609,y:967,t:1526922818320};\\\", \\\"{x:1610,y:967,t:1526922818401};\\\", \\\"{x:1611,y:966,t:1526922818752};\\\", \\\"{x:1612,y:965,t:1526922818764};\\\", \\\"{x:1612,y:963,t:1526922819122};\\\", \\\"{x:1611,y:961,t:1526922819132};\\\", \\\"{x:1605,y:956,t:1526922819149};\\\", \\\"{x:1594,y:947,t:1526922819164};\\\", \\\"{x:1576,y:936,t:1526922819181};\\\", \\\"{x:1540,y:917,t:1526922819198};\\\", \\\"{x:1478,y:890,t:1526922819216};\\\", \\\"{x:1460,y:881,t:1526922819231};\\\", \\\"{x:1382,y:842,t:1526922819249};\\\", \\\"{x:1333,y:803,t:1526922819264};\\\", \\\"{x:1297,y:770,t:1526922819281};\\\", \\\"{x:1271,y:751,t:1526922819299};\\\", \\\"{x:1256,y:739,t:1526922819315};\\\", \\\"{x:1252,y:737,t:1526922819331};\\\", \\\"{x:1250,y:736,t:1526922819348};\\\", \\\"{x:1253,y:736,t:1526922819521};\\\", \\\"{x:1256,y:736,t:1526922819531};\\\", \\\"{x:1263,y:737,t:1526922819549};\\\", \\\"{x:1269,y:737,t:1526922819565};\\\", \\\"{x:1278,y:737,t:1526922819582};\\\", \\\"{x:1286,y:737,t:1526922819599};\\\", \\\"{x:1294,y:739,t:1526922819616};\\\", \\\"{x:1299,y:740,t:1526922819632};\\\", \\\"{x:1302,y:740,t:1526922819649};\\\", \\\"{x:1303,y:740,t:1526922819672};\\\", \\\"{x:1304,y:740,t:1526922819688};\\\", \\\"{x:1306,y:741,t:1526922819698};\\\", \\\"{x:1309,y:742,t:1526922819715};\\\", \\\"{x:1317,y:744,t:1526922819732};\\\", \\\"{x:1332,y:748,t:1526922819747};\\\", \\\"{x:1348,y:752,t:1526922819765};\\\", \\\"{x:1368,y:756,t:1526922819782};\\\", \\\"{x:1379,y:760,t:1526922819798};\\\", \\\"{x:1385,y:760,t:1526922819815};\\\", \\\"{x:1383,y:760,t:1526922820057};\\\", \\\"{x:1382,y:762,t:1526922820065};\\\", \\\"{x:1379,y:762,t:1526922820083};\\\", \\\"{x:1376,y:762,t:1526922820099};\\\", \\\"{x:1374,y:762,t:1526922820116};\\\", \\\"{x:1373,y:762,t:1526922820132};\\\", \\\"{x:1372,y:762,t:1526922820153};\\\", \\\"{x:1371,y:762,t:1526922820166};\\\", \\\"{x:1369,y:762,t:1526922820182};\\\", \\\"{x:1366,y:763,t:1526922820199};\\\", \\\"{x:1358,y:763,t:1526922820217};\\\", \\\"{x:1355,y:763,t:1526922820233};\\\", \\\"{x:1353,y:764,t:1526922820250};\\\", \\\"{x:1352,y:764,t:1526922820320};\\\", \\\"{x:1351,y:764,t:1526922820345};\\\", \\\"{x:1350,y:764,t:1526922820393};\\\", \\\"{x:1349,y:764,t:1526922820721};\\\", \\\"{x:1348,y:763,t:1526922820736};\\\", \\\"{x:1348,y:762,t:1526922820761};\\\", \\\"{x:1348,y:761,t:1526922820769};\\\", \\\"{x:1348,y:760,t:1526922820782};\\\", \\\"{x:1348,y:758,t:1526922820799};\\\", \\\"{x:1348,y:754,t:1526922820818};\\\", \\\"{x:1349,y:749,t:1526922820833};\\\", \\\"{x:1349,y:747,t:1526922820849};\\\", \\\"{x:1349,y:743,t:1526922820867};\\\", \\\"{x:1349,y:739,t:1526922820882};\\\", \\\"{x:1349,y:733,t:1526922820899};\\\", \\\"{x:1349,y:728,t:1526922820916};\\\", \\\"{x:1349,y:724,t:1526922820933};\\\", \\\"{x:1348,y:719,t:1526922820950};\\\", \\\"{x:1346,y:715,t:1526922820966};\\\", \\\"{x:1345,y:709,t:1526922820984};\\\", \\\"{x:1343,y:706,t:1526922821000};\\\", \\\"{x:1342,y:703,t:1526922821016};\\\", \\\"{x:1342,y:701,t:1526922821033};\\\", \\\"{x:1341,y:700,t:1526922821050};\\\", \\\"{x:1341,y:699,t:1526922821066};\\\", \\\"{x:1341,y:698,t:1526922821083};\\\", \\\"{x:1341,y:697,t:1526922821104};\\\", \\\"{x:1341,y:696,t:1526922821121};\\\", \\\"{x:1340,y:695,t:1526922821137};\\\", \\\"{x:1339,y:694,t:1526922821153};\\\", \\\"{x:1339,y:693,t:1526922821217};\\\", \\\"{x:1339,y:692,t:1526922821393};\\\", \\\"{x:1340,y:692,t:1526922821417};\\\", \\\"{x:1341,y:692,t:1526922821433};\\\", \\\"{x:1342,y:693,t:1526922821456};\\\", \\\"{x:1343,y:694,t:1526922821658};\\\", \\\"{x:1343,y:695,t:1526922821705};\\\", \\\"{x:1344,y:695,t:1526922821737};\\\", \\\"{x:1344,y:696,t:1526922821769};\\\", \\\"{x:1343,y:694,t:1526922823360};\\\", \\\"{x:1341,y:691,t:1526922823369};\\\", \\\"{x:1334,y:679,t:1526922823384};\\\", \\\"{x:1321,y:663,t:1526922823401};\\\", \\\"{x:1305,y:645,t:1526922823418};\\\", \\\"{x:1296,y:635,t:1526922823434};\\\", \\\"{x:1288,y:626,t:1526922823451};\\\", \\\"{x:1287,y:623,t:1526922823468};\\\", \\\"{x:1285,y:620,t:1526922823484};\\\", \\\"{x:1284,y:617,t:1526922823501};\\\", \\\"{x:1283,y:612,t:1526922823518};\\\", \\\"{x:1282,y:607,t:1526922823534};\\\", \\\"{x:1281,y:604,t:1526922823552};\\\", \\\"{x:1281,y:600,t:1526922823568};\\\", \\\"{x:1281,y:597,t:1526922823585};\\\", \\\"{x:1281,y:593,t:1526922823601};\\\", \\\"{x:1281,y:586,t:1526922823618};\\\", \\\"{x:1280,y:577,t:1526922823636};\\\", \\\"{x:1279,y:571,t:1526922823651};\\\", \\\"{x:1279,y:566,t:1526922823668};\\\", \\\"{x:1278,y:563,t:1526922823685};\\\", \\\"{x:1277,y:561,t:1526922823701};\\\", \\\"{x:1277,y:560,t:1526922823718};\\\", \\\"{x:1277,y:559,t:1526922823735};\\\", \\\"{x:1277,y:558,t:1526922823752};\\\", \\\"{x:1277,y:557,t:1526922823807};\\\", \\\"{x:1277,y:560,t:1526922824410};\\\", \\\"{x:1277,y:562,t:1526922824418};\\\", \\\"{x:1277,y:566,t:1526922824435};\\\", \\\"{x:1277,y:569,t:1526922824452};\\\", \\\"{x:1277,y:573,t:1526922824469};\\\", \\\"{x:1277,y:575,t:1526922824485};\\\", \\\"{x:1278,y:577,t:1526922824502};\\\", \\\"{x:1279,y:580,t:1526922824519};\\\", \\\"{x:1279,y:582,t:1526922824560};\\\", \\\"{x:1279,y:581,t:1526922824818};\\\", \\\"{x:1278,y:579,t:1526922824825};\\\", \\\"{x:1278,y:577,t:1526922824835};\\\", \\\"{x:1277,y:574,t:1526922824852};\\\", \\\"{x:1277,y:572,t:1526922824869};\\\", \\\"{x:1276,y:570,t:1526922824886};\\\", \\\"{x:1276,y:569,t:1526922824901};\\\", \\\"{x:1276,y:567,t:1526922824919};\\\", \\\"{x:1275,y:565,t:1526922824936};\\\", \\\"{x:1275,y:564,t:1526922824952};\\\", \\\"{x:1275,y:563,t:1526922825025};\\\", \\\"{x:1262,y:562,t:1526922825570};\\\", \\\"{x:1185,y:557,t:1526922825586};\\\", \\\"{x:1099,y:546,t:1526922825604};\\\", \\\"{x:970,y:531,t:1526922825620};\\\", \\\"{x:790,y:508,t:1526922825637};\\\", \\\"{x:594,y:476,t:1526922825654};\\\", \\\"{x:373,y:446,t:1526922825669};\\\", \\\"{x:190,y:419,t:1526922825685};\\\", \\\"{x:30,y:397,t:1526922825703};\\\", \\\"{x:0,y:381,t:1526922825720};\\\", \\\"{x:0,y:377,t:1526922825735};\\\", \\\"{x:4,y:378,t:1526922825808};\\\", \\\"{x:12,y:381,t:1526922825820};\\\", \\\"{x:24,y:386,t:1526922825836};\\\", \\\"{x:34,y:390,t:1526922825853};\\\", \\\"{x:46,y:396,t:1526922825870};\\\", \\\"{x:58,y:401,t:1526922825887};\\\", \\\"{x:72,y:404,t:1526922825903};\\\", \\\"{x:83,y:408,t:1526922825920};\\\", \\\"{x:87,y:411,t:1526922825937};\\\", \\\"{x:90,y:413,t:1526922825954};\\\", \\\"{x:96,y:423,t:1526922825970};\\\", \\\"{x:116,y:442,t:1526922825986};\\\", \\\"{x:170,y:469,t:1526922826003};\\\", \\\"{x:260,y:500,t:1526922826021};\\\", \\\"{x:349,y:513,t:1526922826038};\\\", \\\"{x:424,y:515,t:1526922826053};\\\", \\\"{x:477,y:515,t:1526922826070};\\\", \\\"{x:523,y:515,t:1526922826087};\\\", \\\"{x:551,y:511,t:1526922826103};\\\", \\\"{x:571,y:507,t:1526922826120};\\\", \\\"{x:575,y:506,t:1526922826137};\\\", \\\"{x:576,y:506,t:1526922826216};\\\", \\\"{x:578,y:506,t:1526922826225};\\\", \\\"{x:581,y:506,t:1526922826240};\\\", \\\"{x:586,y:510,t:1526922826254};\\\", \\\"{x:596,y:515,t:1526922826270};\\\", \\\"{x:608,y:516,t:1526922826287};\\\", \\\"{x:615,y:515,t:1526922826303};\\\", \\\"{x:618,y:509,t:1526922826322};\\\", \\\"{x:618,y:507,t:1526922826337};\\\", \\\"{x:618,y:504,t:1526922826353};\\\", \\\"{x:618,y:503,t:1526922826370};\\\", \\\"{x:618,y:502,t:1526922826386};\\\", \\\"{x:618,y:500,t:1526922826403};\\\", \\\"{x:617,y:500,t:1526922826431};\\\", \\\"{x:617,y:499,t:1526922826440};\\\", \\\"{x:616,y:499,t:1526922826453};\\\", \\\"{x:614,y:497,t:1526922826470};\\\", \\\"{x:613,y:496,t:1526922826486};\\\", \\\"{x:610,y:496,t:1526922826985};\\\", \\\"{x:604,y:501,t:1526922826993};\\\", \\\"{x:599,y:511,t:1526922827005};\\\", \\\"{x:579,y:546,t:1526922827022};\\\", \\\"{x:553,y:596,t:1526922827037};\\\", \\\"{x:516,y:664,t:1526922827054};\\\", \\\"{x:489,y:718,t:1526922827072};\\\", \\\"{x:478,y:748,t:1526922827087};\\\", \\\"{x:469,y:785,t:1526922827104};\\\", \\\"{x:468,y:804,t:1526922827120};\\\", \\\"{x:468,y:817,t:1526922827137};\\\", \\\"{x:468,y:821,t:1526922827153};\\\", \\\"{x:468,y:824,t:1526922827170};\\\", \\\"{x:469,y:825,t:1526922827200};\\\", \\\"{x:471,y:821,t:1526922827280};\\\", \\\"{x:472,y:817,t:1526922827288};\\\", \\\"{x:473,y:815,t:1526922827304};\\\", \\\"{x:477,y:796,t:1526922827320};\\\", \\\"{x:482,y:782,t:1526922827337};\\\", \\\"{x:487,y:770,t:1526922827352};\\\", \\\"{x:490,y:761,t:1526922827370};\\\", \\\"{x:494,y:751,t:1526922827387};\\\", \\\"{x:496,y:748,t:1526922827403};\\\", \\\"{x:497,y:745,t:1526922827421};\\\", \\\"{x:500,y:741,t:1526922827438};\\\", \\\"{x:501,y:737,t:1526922827455};\\\", \\\"{x:503,y:734,t:1526922827471};\\\", \\\"{x:508,y:727,t:1526922827488};\\\", \\\"{x:512,y:723,t:1526922827505};\\\", \\\"{x:514,y:720,t:1526922827521};\\\", \\\"{x:514,y:719,t:1526922827539};\\\", \\\"{x:515,y:719,t:1526922827696};\\\", \\\"{x:516,y:720,t:1526922827705};\\\", \\\"{x:516,y:723,t:1526922827721};\\\", \\\"{x:516,y:725,t:1526922827738};\\\", \\\"{x:517,y:726,t:1526922827755};\\\", \\\"{x:517,y:728,t:1526922827776};\\\" ] }, { \\\"rt\\\": 10659, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 451279, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"DKL3R\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-02 PM-01 PM-12 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:518,y:726,t:1526922830873};\\\", \\\"{x:523,y:714,t:1526922830881};\\\", \\\"{x:528,y:703,t:1526922830892};\\\", \\\"{x:533,y:689,t:1526922830907};\\\", \\\"{x:537,y:676,t:1526922830924};\\\", \\\"{x:539,y:665,t:1526922830940};\\\", \\\"{x:540,y:651,t:1526922830957};\\\", \\\"{x:540,y:622,t:1526922830974};\\\", \\\"{x:540,y:594,t:1526922830991};\\\", \\\"{x:540,y:576,t:1526922831008};\\\", \\\"{x:540,y:562,t:1526922831024};\\\", \\\"{x:539,y:556,t:1526922831040};\\\", \\\"{x:537,y:552,t:1526922831058};\\\", \\\"{x:536,y:549,t:1526922831075};\\\", \\\"{x:534,y:546,t:1526922831090};\\\", \\\"{x:533,y:543,t:1526922831107};\\\", \\\"{x:533,y:540,t:1526922831124};\\\", \\\"{x:531,y:539,t:1526922831140};\\\", \\\"{x:531,y:537,t:1526922831157};\\\", \\\"{x:531,y:536,t:1526922831174};\\\", \\\"{x:531,y:534,t:1526922831190};\\\", \\\"{x:531,y:531,t:1526922831207};\\\", \\\"{x:530,y:526,t:1526922831224};\\\", \\\"{x:529,y:523,t:1526922831242};\\\", \\\"{x:529,y:521,t:1526922831257};\\\", \\\"{x:529,y:520,t:1526922831274};\\\", \\\"{x:529,y:519,t:1526922832073};\\\", \\\"{x:530,y:519,t:1526922832088};\\\", \\\"{x:531,y:518,t:1526922832096};\\\", \\\"{x:532,y:518,t:1526922832137};\\\", \\\"{x:533,y:518,t:1526922832145};\\\", \\\"{x:534,y:518,t:1526922832177};\\\", \\\"{x:536,y:518,t:1526922832193};\\\", \\\"{x:537,y:518,t:1526922832208};\\\", \\\"{x:546,y:518,t:1526922832226};\\\", \\\"{x:559,y:518,t:1526922832242};\\\", \\\"{x:579,y:523,t:1526922832259};\\\", \\\"{x:604,y:530,t:1526922832277};\\\", \\\"{x:639,y:547,t:1526922832291};\\\", \\\"{x:692,y:572,t:1526922832308};\\\", \\\"{x:750,y:609,t:1526922832325};\\\", \\\"{x:827,y:655,t:1526922832341};\\\", \\\"{x:923,y:695,t:1526922832358};\\\", \\\"{x:1031,y:730,t:1526922832375};\\\", \\\"{x:1155,y:761,t:1526922832391};\\\", \\\"{x:1328,y:782,t:1526922832408};\\\", \\\"{x:1419,y:782,t:1526922832426};\\\", \\\"{x:1483,y:782,t:1526922832441};\\\", \\\"{x:1514,y:782,t:1526922832458};\\\", \\\"{x:1532,y:782,t:1526922832476};\\\", \\\"{x:1537,y:782,t:1526922832491};\\\", \\\"{x:1538,y:782,t:1526922832508};\\\", \\\"{x:1539,y:785,t:1526922832561};\\\", \\\"{x:1539,y:793,t:1526922832575};\\\", \\\"{x:1538,y:806,t:1526922832592};\\\", \\\"{x:1537,y:830,t:1526922832609};\\\", \\\"{x:1537,y:851,t:1526922832626};\\\", \\\"{x:1537,y:871,t:1526922832642};\\\", \\\"{x:1540,y:890,t:1526922832659};\\\", \\\"{x:1544,y:904,t:1526922832676};\\\", \\\"{x:1547,y:913,t:1526922832693};\\\", \\\"{x:1548,y:919,t:1526922832709};\\\", \\\"{x:1550,y:925,t:1526922832726};\\\", \\\"{x:1552,y:929,t:1526922832743};\\\", \\\"{x:1552,y:933,t:1526922832759};\\\", \\\"{x:1552,y:938,t:1526922832776};\\\", \\\"{x:1552,y:947,t:1526922832792};\\\", \\\"{x:1550,y:950,t:1526922832808};\\\", \\\"{x:1547,y:955,t:1526922832826};\\\", \\\"{x:1545,y:957,t:1526922832843};\\\", \\\"{x:1543,y:958,t:1526922832859};\\\", \\\"{x:1542,y:961,t:1526922832876};\\\", \\\"{x:1539,y:962,t:1526922832893};\\\", \\\"{x:1536,y:965,t:1526922832909};\\\", \\\"{x:1533,y:967,t:1526922832925};\\\", \\\"{x:1528,y:970,t:1526922832943};\\\", \\\"{x:1523,y:973,t:1526922832960};\\\", \\\"{x:1519,y:973,t:1526922832975};\\\", \\\"{x:1512,y:975,t:1526922832992};\\\", \\\"{x:1508,y:976,t:1526922833008};\\\", \\\"{x:1506,y:976,t:1526922833026};\\\", \\\"{x:1504,y:976,t:1526922833042};\\\", \\\"{x:1503,y:976,t:1526922833059};\\\", \\\"{x:1501,y:976,t:1526922833075};\\\", \\\"{x:1501,y:977,t:1526922834528};\\\", \\\"{x:1503,y:977,t:1526922834585};\\\", \\\"{x:1503,y:978,t:1526922834617};\\\", \\\"{x:1503,y:979,t:1526922834632};\\\", \\\"{x:1505,y:981,t:1526922834644};\\\", \\\"{x:1505,y:982,t:1526922834661};\\\", \\\"{x:1505,y:984,t:1526922834677};\\\", \\\"{x:1505,y:985,t:1526922834697};\\\", \\\"{x:1505,y:986,t:1526922834713};\\\", \\\"{x:1505,y:987,t:1526922834729};\\\", \\\"{x:1505,y:988,t:1526922834752};\\\", \\\"{x:1503,y:988,t:1526922834768};\\\", \\\"{x:1502,y:988,t:1526922834777};\\\", \\\"{x:1498,y:988,t:1526922834794};\\\", \\\"{x:1491,y:988,t:1526922834811};\\\", \\\"{x:1482,y:988,t:1526922834827};\\\", \\\"{x:1465,y:986,t:1526922834844};\\\", \\\"{x:1456,y:985,t:1526922834861};\\\", \\\"{x:1445,y:983,t:1526922834878};\\\", \\\"{x:1439,y:981,t:1526922834894};\\\", \\\"{x:1437,y:981,t:1526922834911};\\\", \\\"{x:1435,y:979,t:1526922834928};\\\", \\\"{x:1434,y:979,t:1526922834976};\\\", \\\"{x:1431,y:977,t:1526922834994};\\\", \\\"{x:1425,y:976,t:1526922835011};\\\", \\\"{x:1421,y:975,t:1526922835028};\\\", \\\"{x:1417,y:974,t:1526922835044};\\\", \\\"{x:1415,y:974,t:1526922835061};\\\", \\\"{x:1414,y:974,t:1526922835077};\\\", \\\"{x:1412,y:974,t:1526922835094};\\\", \\\"{x:1410,y:974,t:1526922835111};\\\", \\\"{x:1405,y:974,t:1526922835128};\\\", \\\"{x:1402,y:974,t:1526922835145};\\\", \\\"{x:1398,y:974,t:1526922835161};\\\", \\\"{x:1392,y:974,t:1526922835179};\\\", \\\"{x:1386,y:974,t:1526922835194};\\\", \\\"{x:1378,y:974,t:1526922835211};\\\", \\\"{x:1371,y:974,t:1526922835228};\\\", \\\"{x:1360,y:974,t:1526922835244};\\\", \\\"{x:1353,y:974,t:1526922835261};\\\", \\\"{x:1349,y:974,t:1526922835278};\\\", \\\"{x:1347,y:974,t:1526922835295};\\\", \\\"{x:1346,y:973,t:1526922835537};\\\", \\\"{x:1346,y:972,t:1526922835552};\\\", \\\"{x:1346,y:970,t:1526922835568};\\\", \\\"{x:1345,y:969,t:1526922835592};\\\", \\\"{x:1345,y:968,t:1526922835753};\\\", \\\"{x:1345,y:967,t:1526922835777};\\\", \\\"{x:1345,y:966,t:1526922835840};\\\", \\\"{x:1345,y:965,t:1526922835889};\\\", \\\"{x:1345,y:964,t:1526922836914};\\\", \\\"{x:1351,y:957,t:1526922836929};\\\", \\\"{x:1367,y:944,t:1526922836946};\\\", \\\"{x:1414,y:897,t:1526922836962};\\\", \\\"{x:1523,y:740,t:1526922836979};\\\", \\\"{x:1637,y:566,t:1526922836996};\\\", \\\"{x:1720,y:421,t:1526922837013};\\\", \\\"{x:1769,y:300,t:1526922837029};\\\", \\\"{x:1772,y:246,t:1526922837046};\\\", \\\"{x:1752,y:191,t:1526922837063};\\\", \\\"{x:1691,y:154,t:1526922837079};\\\", \\\"{x:1577,y:105,t:1526922837097};\\\", \\\"{x:1483,y:65,t:1526922837113};\\\", \\\"{x:1350,y:25,t:1526922837129};\\\", \\\"{x:1189,y:0,t:1526922837146};\\\", \\\"{x:1045,y:0,t:1526922837163};\\\", \\\"{x:957,y:0,t:1526922837179};\\\", \\\"{x:908,y:6,t:1526922837196};\\\", \\\"{x:886,y:16,t:1526922837213};\\\", \\\"{x:871,y:27,t:1526922837229};\\\", \\\"{x:859,y:40,t:1526922837245};\\\", \\\"{x:848,y:61,t:1526922837263};\\\", \\\"{x:834,y:93,t:1526922837279};\\\", \\\"{x:811,y:131,t:1526922837296};\\\", \\\"{x:784,y:159,t:1526922837313};\\\", \\\"{x:740,y:188,t:1526922837329};\\\", \\\"{x:696,y:214,t:1526922837345};\\\", \\\"{x:646,y:235,t:1526922837362};\\\", \\\"{x:579,y:266,t:1526922837380};\\\", \\\"{x:510,y:297,t:1526922837395};\\\", \\\"{x:457,y:321,t:1526922837412};\\\", \\\"{x:407,y:353,t:1526922837430};\\\", \\\"{x:371,y:378,t:1526922837446};\\\", \\\"{x:337,y:402,t:1526922837462};\\\", \\\"{x:290,y:447,t:1526922837479};\\\", \\\"{x:270,y:478,t:1526922837496};\\\", \\\"{x:259,y:502,t:1526922837514};\\\", \\\"{x:256,y:528,t:1526922837530};\\\", \\\"{x:251,y:553,t:1526922837545};\\\", \\\"{x:248,y:575,t:1526922837563};\\\", \\\"{x:247,y:595,t:1526922837579};\\\", \\\"{x:241,y:611,t:1526922837597};\\\", \\\"{x:233,y:623,t:1526922837612};\\\", \\\"{x:223,y:627,t:1526922837629};\\\", \\\"{x:213,y:627,t:1526922837645};\\\", \\\"{x:203,y:626,t:1526922837662};\\\", \\\"{x:187,y:615,t:1526922837680};\\\", \\\"{x:181,y:607,t:1526922837695};\\\", \\\"{x:175,y:597,t:1526922837712};\\\", \\\"{x:172,y:593,t:1526922837730};\\\", \\\"{x:168,y:588,t:1526922837747};\\\", \\\"{x:163,y:585,t:1526922837762};\\\", \\\"{x:162,y:583,t:1526922837779};\\\", \\\"{x:159,y:581,t:1526922837796};\\\", \\\"{x:156,y:577,t:1526922837812};\\\", \\\"{x:153,y:573,t:1526922837829};\\\", \\\"{x:149,y:569,t:1526922837846};\\\", \\\"{x:147,y:567,t:1526922837863};\\\", \\\"{x:147,y:564,t:1526922837879};\\\", \\\"{x:147,y:561,t:1526922837897};\\\", \\\"{x:147,y:559,t:1526922837913};\\\", \\\"{x:147,y:557,t:1526922837929};\\\", \\\"{x:149,y:554,t:1526922837948};\\\", \\\"{x:151,y:552,t:1526922837962};\\\", \\\"{x:152,y:550,t:1526922837979};\\\", \\\"{x:153,y:549,t:1526922837996};\\\", \\\"{x:153,y:548,t:1526922838012};\\\", \\\"{x:153,y:547,t:1526922838031};\\\", \\\"{x:154,y:546,t:1526922838056};\\\", \\\"{x:154,y:545,t:1526922838071};\\\", \\\"{x:156,y:544,t:1526922838229};\\\", \\\"{x:161,y:544,t:1526922838246};\\\", \\\"{x:167,y:547,t:1526922838263};\\\", \\\"{x:220,y:553,t:1526922838280};\\\", \\\"{x:321,y:562,t:1526922838296};\\\", \\\"{x:424,y:564,t:1526922838314};\\\", \\\"{x:516,y:564,t:1526922838330};\\\", \\\"{x:578,y:564,t:1526922838346};\\\", \\\"{x:598,y:557,t:1526922838364};\\\", \\\"{x:601,y:555,t:1526922838379};\\\", \\\"{x:601,y:553,t:1526922838399};\\\", \\\"{x:601,y:552,t:1526922838413};\\\", \\\"{x:601,y:549,t:1526922838429};\\\", \\\"{x:601,y:547,t:1526922838446};\\\", \\\"{x:604,y:545,t:1526922838464};\\\", \\\"{x:611,y:541,t:1526922838480};\\\", \\\"{x:614,y:539,t:1526922838496};\\\", \\\"{x:616,y:538,t:1526922838513};\\\", \\\"{x:618,y:536,t:1526922838530};\\\", \\\"{x:627,y:533,t:1526922838546};\\\", \\\"{x:647,y:531,t:1526922838564};\\\", \\\"{x:672,y:531,t:1526922838580};\\\", \\\"{x:690,y:530,t:1526922838597};\\\", \\\"{x:705,y:529,t:1526922838613};\\\", \\\"{x:711,y:528,t:1526922838630};\\\", \\\"{x:713,y:527,t:1526922838646};\\\", \\\"{x:715,y:527,t:1526922838664};\\\", \\\"{x:724,y:527,t:1526922838682};\\\", \\\"{x:747,y:527,t:1526922838696};\\\", \\\"{x:784,y:525,t:1526922838714};\\\", \\\"{x:837,y:519,t:1526922838731};\\\", \\\"{x:870,y:515,t:1526922838747};\\\", \\\"{x:882,y:511,t:1526922838763};\\\", \\\"{x:882,y:509,t:1526922838799};\\\", \\\"{x:881,y:509,t:1526922838815};\\\", \\\"{x:880,y:508,t:1526922838830};\\\", \\\"{x:877,y:508,t:1526922838871};\\\", \\\"{x:875,y:508,t:1526922838880};\\\", \\\"{x:863,y:508,t:1526922838896};\\\", \\\"{x:845,y:508,t:1526922838913};\\\", \\\"{x:824,y:508,t:1526922838930};\\\", \\\"{x:803,y:508,t:1526922838946};\\\", \\\"{x:795,y:508,t:1526922838963};\\\", \\\"{x:799,y:507,t:1526922839055};\\\", \\\"{x:804,y:505,t:1526922839063};\\\", \\\"{x:819,y:503,t:1526922839081};\\\", \\\"{x:836,y:500,t:1526922839096};\\\", \\\"{x:849,y:497,t:1526922839113};\\\", \\\"{x:854,y:495,t:1526922839130};\\\", \\\"{x:853,y:495,t:1526922839305};\\\", \\\"{x:852,y:495,t:1526922839314};\\\", \\\"{x:851,y:495,t:1526922839344};\\\", \\\"{x:850,y:495,t:1526922839351};\\\", \\\"{x:849,y:495,t:1526922839368};\\\", \\\"{x:849,y:496,t:1526922839380};\\\", \\\"{x:848,y:496,t:1526922839456};\\\", \\\"{x:847,y:498,t:1526922839735};\\\", \\\"{x:846,y:498,t:1526922839747};\\\", \\\"{x:843,y:500,t:1526922839764};\\\", \\\"{x:836,y:505,t:1526922839780};\\\", \\\"{x:824,y:512,t:1526922839798};\\\", \\\"{x:813,y:521,t:1526922839815};\\\", \\\"{x:794,y:532,t:1526922839831};\\\", \\\"{x:763,y:549,t:1526922839847};\\\", \\\"{x:727,y:565,t:1526922839866};\\\", \\\"{x:685,y:585,t:1526922839881};\\\", \\\"{x:656,y:600,t:1526922839898};\\\", \\\"{x:630,y:615,t:1526922839915};\\\", \\\"{x:610,y:629,t:1526922839931};\\\", \\\"{x:585,y:652,t:1526922839948};\\\", \\\"{x:562,y:669,t:1526922839964};\\\", \\\"{x:548,y:684,t:1526922839982};\\\", \\\"{x:535,y:697,t:1526922839998};\\\", \\\"{x:524,y:710,t:1526922840014};\\\", \\\"{x:508,y:726,t:1526922840032};\\\", \\\"{x:497,y:737,t:1526922840047};\\\", \\\"{x:493,y:742,t:1526922840065};\\\", \\\"{x:493,y:744,t:1526922840152};\\\", \\\"{x:493,y:746,t:1526922840168};\\\", \\\"{x:494,y:746,t:1526922840181};\\\", \\\"{x:497,y:746,t:1526922840197};\\\", \\\"{x:499,y:746,t:1526922840216};\\\", \\\"{x:500,y:746,t:1526922840232};\\\", \\\"{x:503,y:746,t:1526922840248};\\\" ] }, { \\\"rt\\\": 6808, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 459305, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"DKL3R\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-O \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:503,y:745,t:1526922842585};\\\", \\\"{x:503,y:743,t:1526922842600};\\\", \\\"{x:504,y:738,t:1526922842631};\\\", \\\"{x:504,y:736,t:1526922842634};\\\", \\\"{x:504,y:731,t:1526922842649};\\\", \\\"{x:504,y:723,t:1526922842666};\\\", \\\"{x:504,y:708,t:1526922842684};\\\", \\\"{x:501,y:689,t:1526922842699};\\\", \\\"{x:494,y:651,t:1526922842717};\\\", \\\"{x:486,y:628,t:1526922842735};\\\", \\\"{x:477,y:610,t:1526922842749};\\\", \\\"{x:471,y:592,t:1526922842767};\\\", \\\"{x:461,y:565,t:1526922842783};\\\", \\\"{x:457,y:549,t:1526922842800};\\\", \\\"{x:453,y:540,t:1526922842817};\\\", \\\"{x:451,y:534,t:1526922842833};\\\", \\\"{x:448,y:527,t:1526922842849};\\\", \\\"{x:446,y:520,t:1526922842867};\\\", \\\"{x:445,y:516,t:1526922842884};\\\", \\\"{x:444,y:515,t:1526922842899};\\\", \\\"{x:443,y:514,t:1526922842917};\\\", \\\"{x:443,y:513,t:1526922842933};\\\", \\\"{x:443,y:512,t:1526922842959};\\\", \\\"{x:443,y:511,t:1526922842968};\\\", \\\"{x:442,y:510,t:1526922842983};\\\", \\\"{x:441,y:507,t:1526922843000};\\\", \\\"{x:441,y:506,t:1526922843017};\\\", \\\"{x:440,y:502,t:1526922843034};\\\", \\\"{x:440,y:501,t:1526922843050};\\\", \\\"{x:440,y:500,t:1526922843067};\\\", \\\"{x:440,y:499,t:1526922843084};\\\", \\\"{x:440,y:497,t:1526922843101};\\\", \\\"{x:440,y:496,t:1526922843118};\\\", \\\"{x:440,y:494,t:1526922843134};\\\", \\\"{x:440,y:493,t:1526922843160};\\\", \\\"{x:440,y:491,t:1526922843192};\\\", \\\"{x:441,y:489,t:1526922843329};\\\", \\\"{x:442,y:489,t:1526922843336};\\\", \\\"{x:444,y:487,t:1526922843352};\\\", \\\"{x:447,y:486,t:1526922843369};\\\", \\\"{x:452,y:484,t:1526922843385};\\\", \\\"{x:457,y:483,t:1526922843401};\\\", \\\"{x:462,y:481,t:1526922843417};\\\", \\\"{x:467,y:480,t:1526922843433};\\\", \\\"{x:469,y:479,t:1526922843450};\\\", \\\"{x:471,y:479,t:1526922843467};\\\", \\\"{x:473,y:478,t:1526922843484};\\\", \\\"{x:473,y:477,t:1526922843500};\\\", \\\"{x:474,y:477,t:1526922843517};\\\", \\\"{x:474,y:476,t:1526922843533};\\\", \\\"{x:476,y:476,t:1526922843550};\\\", \\\"{x:477,y:474,t:1526922843567};\\\", \\\"{x:479,y:473,t:1526922843584};\\\", \\\"{x:482,y:473,t:1526922843601};\\\", \\\"{x:485,y:471,t:1526922843617};\\\", \\\"{x:486,y:471,t:1526922843633};\\\", \\\"{x:489,y:470,t:1526922843651};\\\", \\\"{x:492,y:470,t:1526922843668};\\\", \\\"{x:494,y:470,t:1526922843684};\\\", \\\"{x:497,y:469,t:1526922843701};\\\", \\\"{x:501,y:469,t:1526922843717};\\\", \\\"{x:507,y:469,t:1526922843734};\\\", \\\"{x:514,y:467,t:1526922843751};\\\", \\\"{x:522,y:466,t:1526922843768};\\\", \\\"{x:527,y:465,t:1526922843784};\\\", \\\"{x:533,y:465,t:1526922843801};\\\", \\\"{x:539,y:465,t:1526922843818};\\\", \\\"{x:546,y:465,t:1526922843834};\\\", \\\"{x:553,y:465,t:1526922843851};\\\", \\\"{x:557,y:465,t:1526922843868};\\\", \\\"{x:561,y:465,t:1526922843884};\\\", \\\"{x:562,y:465,t:1526922843900};\\\", \\\"{x:563,y:465,t:1526922843918};\\\", \\\"{x:564,y:465,t:1526922843934};\\\", \\\"{x:566,y:465,t:1526922843951};\\\", \\\"{x:570,y:463,t:1526922843968};\\\", \\\"{x:571,y:463,t:1526922843992};\\\", \\\"{x:572,y:463,t:1526922844008};\\\", \\\"{x:573,y:463,t:1526922844032};\\\", \\\"{x:574,y:462,t:1526922844056};\\\", \\\"{x:574,y:461,t:1526922844068};\\\", \\\"{x:576,y:461,t:1526922844084};\\\", \\\"{x:578,y:460,t:1526922844101};\\\", \\\"{x:580,y:460,t:1526922844118};\\\", \\\"{x:583,y:459,t:1526922844135};\\\", \\\"{x:585,y:459,t:1526922844151};\\\", \\\"{x:590,y:459,t:1526922844168};\\\", \\\"{x:594,y:459,t:1526922844184};\\\", \\\"{x:597,y:458,t:1526922844201};\\\", \\\"{x:599,y:458,t:1526922844218};\\\", \\\"{x:602,y:457,t:1526922844235};\\\", \\\"{x:604,y:456,t:1526922844251};\\\", \\\"{x:605,y:455,t:1526922844272};\\\", \\\"{x:606,y:455,t:1526922844284};\\\", \\\"{x:608,y:455,t:1526922844301};\\\", \\\"{x:611,y:453,t:1526922844318};\\\", \\\"{x:612,y:452,t:1526922844392};\\\", \\\"{x:613,y:452,t:1526922844904};\\\", \\\"{x:617,y:452,t:1526922844919};\\\", \\\"{x:629,y:459,t:1526922844935};\\\", \\\"{x:649,y:471,t:1526922844952};\\\", \\\"{x:663,y:476,t:1526922844968};\\\", \\\"{x:674,y:481,t:1526922844985};\\\", \\\"{x:687,y:486,t:1526922845002};\\\", \\\"{x:697,y:490,t:1526922845019};\\\", \\\"{x:708,y:492,t:1526922845035};\\\", \\\"{x:721,y:497,t:1526922845052};\\\", \\\"{x:746,y:509,t:1526922845069};\\\", \\\"{x:774,y:521,t:1526922845085};\\\", \\\"{x:822,y:535,t:1526922845102};\\\", \\\"{x:872,y:549,t:1526922845118};\\\", \\\"{x:930,y:566,t:1526922845136};\\\", \\\"{x:1028,y:586,t:1526922845152};\\\", \\\"{x:1120,y:600,t:1526922845168};\\\", \\\"{x:1217,y:613,t:1526922845185};\\\", \\\"{x:1315,y:629,t:1526922845202};\\\", \\\"{x:1403,y:638,t:1526922845219};\\\", \\\"{x:1500,y:652,t:1526922845235};\\\", \\\"{x:1590,y:667,t:1526922845252};\\\", \\\"{x:1652,y:677,t:1526922845269};\\\", \\\"{x:1691,y:682,t:1526922845286};\\\", \\\"{x:1708,y:684,t:1526922845302};\\\", \\\"{x:1711,y:685,t:1526922845319};\\\", \\\"{x:1711,y:686,t:1526922845360};\\\", \\\"{x:1711,y:687,t:1526922845370};\\\", \\\"{x:1708,y:690,t:1526922845386};\\\", \\\"{x:1695,y:697,t:1526922845402};\\\", \\\"{x:1671,y:706,t:1526922845419};\\\", \\\"{x:1650,y:715,t:1526922845437};\\\", \\\"{x:1621,y:726,t:1526922845453};\\\", \\\"{x:1596,y:733,t:1526922845469};\\\", \\\"{x:1575,y:738,t:1526922845487};\\\", \\\"{x:1558,y:743,t:1526922845502};\\\", \\\"{x:1542,y:748,t:1526922845520};\\\", \\\"{x:1532,y:751,t:1526922845536};\\\", \\\"{x:1527,y:752,t:1526922845552};\\\", \\\"{x:1522,y:753,t:1526922845569};\\\", \\\"{x:1514,y:753,t:1526922845587};\\\", \\\"{x:1501,y:753,t:1526922845603};\\\", \\\"{x:1491,y:755,t:1526922845619};\\\", \\\"{x:1487,y:755,t:1526922845637};\\\", \\\"{x:1484,y:755,t:1526922845652};\\\", \\\"{x:1483,y:756,t:1526922845669};\\\", \\\"{x:1482,y:756,t:1526922845849};\\\", \\\"{x:1481,y:755,t:1526922845864};\\\", \\\"{x:1480,y:755,t:1526922845889};\\\", \\\"{x:1479,y:755,t:1526922845944};\\\", \\\"{x:1478,y:755,t:1526922846073};\\\", \\\"{x:1476,y:755,t:1526922846088};\\\", \\\"{x:1475,y:754,t:1526922846120};\\\", \\\"{x:1472,y:754,t:1526922846136};\\\", \\\"{x:1468,y:753,t:1526922846153};\\\", \\\"{x:1465,y:753,t:1526922846170};\\\", \\\"{x:1461,y:753,t:1526922846185};\\\", \\\"{x:1457,y:751,t:1526922846203};\\\", \\\"{x:1447,y:750,t:1526922846220};\\\", \\\"{x:1434,y:746,t:1526922846236};\\\", \\\"{x:1419,y:742,t:1526922846253};\\\", \\\"{x:1393,y:735,t:1526922846269};\\\", \\\"{x:1360,y:726,t:1526922846286};\\\", \\\"{x:1315,y:713,t:1526922846303};\\\", \\\"{x:1229,y:689,t:1526922846319};\\\", \\\"{x:1184,y:674,t:1526922846336};\\\", \\\"{x:1146,y:662,t:1526922846353};\\\", \\\"{x:1120,y:654,t:1526922846370};\\\", \\\"{x:1095,y:645,t:1526922846387};\\\", \\\"{x:1069,y:633,t:1526922846403};\\\", \\\"{x:1044,y:624,t:1526922846420};\\\", \\\"{x:1015,y:608,t:1526922846437};\\\", \\\"{x:980,y:594,t:1526922846453};\\\", \\\"{x:941,y:577,t:1526922846471};\\\", \\\"{x:895,y:558,t:1526922846488};\\\", \\\"{x:847,y:543,t:1526922846504};\\\", \\\"{x:786,y:521,t:1526922846519};\\\", \\\"{x:746,y:507,t:1526922846537};\\\", \\\"{x:702,y:490,t:1526922846553};\\\", \\\"{x:658,y:477,t:1526922846570};\\\", \\\"{x:619,y:467,t:1526922846587};\\\", \\\"{x:584,y:459,t:1526922846603};\\\", \\\"{x:544,y:452,t:1526922846619};\\\", \\\"{x:484,y:441,t:1526922846637};\\\", \\\"{x:420,y:432,t:1526922846653};\\\", \\\"{x:361,y:424,t:1526922846670};\\\", \\\"{x:295,y:424,t:1526922846687};\\\", \\\"{x:225,y:425,t:1526922846702};\\\", \\\"{x:156,y:440,t:1526922846720};\\\", \\\"{x:138,y:449,t:1526922846737};\\\", \\\"{x:129,y:455,t:1526922846753};\\\", \\\"{x:122,y:462,t:1526922846770};\\\", \\\"{x:117,y:475,t:1526922846787};\\\", \\\"{x:116,y:490,t:1526922846803};\\\", \\\"{x:116,y:512,t:1526922846820};\\\", \\\"{x:115,y:539,t:1526922846837};\\\", \\\"{x:112,y:563,t:1526922846856};\\\", \\\"{x:109,y:583,t:1526922846870};\\\", \\\"{x:106,y:607,t:1526922846887};\\\", \\\"{x:106,y:633,t:1526922846903};\\\", \\\"{x:109,y:646,t:1526922846920};\\\", \\\"{x:117,y:656,t:1526922846937};\\\", \\\"{x:125,y:662,t:1526922846952};\\\", \\\"{x:137,y:665,t:1526922846969};\\\", \\\"{x:148,y:665,t:1526922846987};\\\", \\\"{x:157,y:665,t:1526922847003};\\\", \\\"{x:165,y:664,t:1526922847020};\\\", \\\"{x:170,y:661,t:1526922847037};\\\", \\\"{x:172,y:659,t:1526922847053};\\\", \\\"{x:174,y:656,t:1526922847070};\\\", \\\"{x:176,y:650,t:1526922847087};\\\", \\\"{x:179,y:644,t:1526922847102};\\\", \\\"{x:180,y:633,t:1526922847120};\\\", \\\"{x:180,y:621,t:1526922847137};\\\", \\\"{x:180,y:609,t:1526922847154};\\\", \\\"{x:177,y:598,t:1526922847171};\\\", \\\"{x:176,y:593,t:1526922847188};\\\", \\\"{x:175,y:591,t:1526922847204};\\\", \\\"{x:174,y:590,t:1526922847220};\\\", \\\"{x:174,y:589,t:1526922847239};\\\", \\\"{x:174,y:587,t:1526922847254};\\\", \\\"{x:174,y:585,t:1526922847271};\\\", \\\"{x:174,y:583,t:1526922847287};\\\", \\\"{x:172,y:576,t:1526922847303};\\\", \\\"{x:171,y:572,t:1526922847320};\\\", \\\"{x:170,y:570,t:1526922847337};\\\", \\\"{x:170,y:568,t:1526922847354};\\\", \\\"{x:169,y:565,t:1526922847370};\\\", \\\"{x:169,y:561,t:1526922847387};\\\", \\\"{x:169,y:558,t:1526922847403};\\\", \\\"{x:168,y:555,t:1526922847421};\\\", \\\"{x:168,y:554,t:1526922847436};\\\", \\\"{x:168,y:552,t:1526922847454};\\\", \\\"{x:168,y:551,t:1526922847480};\\\", \\\"{x:168,y:549,t:1526922847488};\\\", \\\"{x:168,y:545,t:1526922847503};\\\", \\\"{x:168,y:541,t:1526922847521};\\\", \\\"{x:166,y:537,t:1526922847537};\\\", \\\"{x:168,y:537,t:1526922847727};\\\", \\\"{x:176,y:541,t:1526922847737};\\\", \\\"{x:202,y:555,t:1526922847754};\\\", \\\"{x:246,y:573,t:1526922847771};\\\", \\\"{x:306,y:596,t:1526922847788};\\\", \\\"{x:373,y:617,t:1526922847804};\\\", \\\"{x:419,y:634,t:1526922847821};\\\", \\\"{x:445,y:644,t:1526922847838};\\\", \\\"{x:460,y:651,t:1526922847854};\\\", \\\"{x:469,y:655,t:1526922847871};\\\", \\\"{x:478,y:660,t:1526922847886};\\\", \\\"{x:482,y:665,t:1526922847904};\\\", \\\"{x:486,y:670,t:1526922847921};\\\", \\\"{x:491,y:676,t:1526922847937};\\\", \\\"{x:495,y:681,t:1526922847954};\\\", \\\"{x:501,y:688,t:1526922847970};\\\", \\\"{x:505,y:693,t:1526922847987};\\\", \\\"{x:510,y:699,t:1526922848004};\\\", \\\"{x:517,y:702,t:1526922848021};\\\", \\\"{x:520,y:702,t:1526922848038};\\\", \\\"{x:522,y:702,t:1526922848054};\\\", \\\"{x:523,y:702,t:1526922848071};\\\", \\\"{x:525,y:702,t:1526922848104};\\\", \\\"{x:526,y:706,t:1526922848121};\\\", \\\"{x:527,y:712,t:1526922848139};\\\", \\\"{x:527,y:715,t:1526922848154};\\\", \\\"{x:527,y:717,t:1526922848171};\\\", \\\"{x:527,y:720,t:1526922848189};\\\", \\\"{x:524,y:727,t:1526922848204};\\\", \\\"{x:521,y:735,t:1526922848221};\\\", \\\"{x:520,y:747,t:1526922848237};\\\", \\\"{x:520,y:749,t:1526922848254};\\\", \\\"{x:520,y:750,t:1526922848270};\\\", \\\"{x:520,y:749,t:1526922849144};\\\", \\\"{x:520,y:748,t:1526922849160};\\\", \\\"{x:520,y:747,t:1526922849217};\\\" ] }, { \\\"rt\\\": 46582, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 507182, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"DKL3R\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-X -Z -04 PM-H -H -B -B -F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:520,y:746,t:1526922849782};\\\", \\\"{x:520,y:745,t:1526922849975};\\\", \\\"{x:520,y:744,t:1526922850048};\\\", \\\"{x:520,y:743,t:1526922850256};\\\", \\\"{x:520,y:742,t:1526922850785};\\\", \\\"{x:520,y:741,t:1526922850864};\\\", \\\"{x:520,y:740,t:1526922851536};\\\", \\\"{x:520,y:739,t:1526922851656};\\\", \\\"{x:520,y:738,t:1526922852288};\\\", \\\"{x:520,y:737,t:1526922852328};\\\", \\\"{x:520,y:736,t:1526922852512};\\\", \\\"{x:520,y:734,t:1526922853081};\\\", \\\"{x:520,y:733,t:1526922853089};\\\", \\\"{x:519,y:732,t:1526922853106};\\\", \\\"{x:519,y:731,t:1526922853123};\\\", \\\"{x:517,y:730,t:1526922853140};\\\", \\\"{x:514,y:725,t:1526922853157};\\\", \\\"{x:510,y:722,t:1526922853172};\\\", \\\"{x:503,y:717,t:1526922853190};\\\", \\\"{x:496,y:713,t:1526922853206};\\\", \\\"{x:488,y:708,t:1526922853222};\\\", \\\"{x:479,y:706,t:1526922853239};\\\", \\\"{x:472,y:704,t:1526922853257};\\\", \\\"{x:463,y:703,t:1526922853275};\\\", \\\"{x:460,y:703,t:1526922853291};\\\", \\\"{x:459,y:703,t:1526922853311};\\\", \\\"{x:458,y:703,t:1526922853335};\\\", \\\"{x:457,y:703,t:1526922853359};\\\", \\\"{x:458,y:714,t:1526922853375};\\\", \\\"{x:469,y:733,t:1526922853392};\\\", \\\"{x:498,y:757,t:1526922853409};\\\", \\\"{x:563,y:795,t:1526922853425};\\\", \\\"{x:666,y:847,t:1526922853442};\\\", \\\"{x:801,y:901,t:1526922853458};\\\", \\\"{x:951,y:957,t:1526922853476};\\\", \\\"{x:1120,y:1006,t:1526922853493};\\\", \\\"{x:1301,y:1045,t:1526922853508};\\\", \\\"{x:1483,y:1062,t:1526922853525};\\\", \\\"{x:1648,y:1062,t:1526922853542};\\\", \\\"{x:1800,y:1046,t:1526922853559};\\\", \\\"{x:1871,y:1031,t:1526922853569};\\\", \\\"{x:1908,y:785,t:1526922854000};\\\", \\\"{x:1895,y:775,t:1526922854010};\\\", \\\"{x:1870,y:759,t:1526922854026};\\\", \\\"{x:1853,y:743,t:1526922854042};\\\", \\\"{x:1838,y:729,t:1526922854059};\\\", \\\"{x:1826,y:711,t:1526922854076};\\\", \\\"{x:1817,y:699,t:1526922854091};\\\", \\\"{x:1809,y:685,t:1526922854109};\\\", \\\"{x:1802,y:676,t:1526922854126};\\\", \\\"{x:1799,y:669,t:1526922854142};\\\", \\\"{x:1791,y:662,t:1526922854158};\\\", \\\"{x:1777,y:654,t:1526922854176};\\\", \\\"{x:1765,y:648,t:1526922854192};\\\", \\\"{x:1758,y:645,t:1526922854210};\\\", \\\"{x:1753,y:643,t:1526922854226};\\\", \\\"{x:1744,y:639,t:1526922854242};\\\", \\\"{x:1728,y:633,t:1526922854260};\\\", \\\"{x:1709,y:625,t:1526922854276};\\\", \\\"{x:1689,y:618,t:1526922854292};\\\", \\\"{x:1671,y:613,t:1526922854309};\\\", \\\"{x:1660,y:608,t:1526922854326};\\\", \\\"{x:1647,y:599,t:1526922854343};\\\", \\\"{x:1631,y:587,t:1526922854359};\\\", \\\"{x:1618,y:574,t:1526922854376};\\\", \\\"{x:1601,y:552,t:1526922854392};\\\", \\\"{x:1577,y:510,t:1526922854409};\\\", \\\"{x:1553,y:453,t:1526922854426};\\\", \\\"{x:1531,y:395,t:1526922854443};\\\", \\\"{x:1522,y:357,t:1526922854459};\\\", \\\"{x:1518,y:327,t:1526922854476};\\\", \\\"{x:1512,y:307,t:1526922854493};\\\", \\\"{x:1511,y:289,t:1526922854509};\\\", \\\"{x:1508,y:272,t:1526922854526};\\\", \\\"{x:1506,y:255,t:1526922854544};\\\", \\\"{x:1506,y:249,t:1526922854560};\\\", \\\"{x:1506,y:247,t:1526922854576};\\\", \\\"{x:1504,y:243,t:1526922854594};\\\", \\\"{x:1504,y:242,t:1526922854609};\\\", \\\"{x:1503,y:241,t:1526922854627};\\\", \\\"{x:1500,y:237,t:1526922854644};\\\", \\\"{x:1498,y:237,t:1526922854660};\\\", \\\"{x:1496,y:237,t:1526922854677};\\\", \\\"{x:1491,y:237,t:1526922854694};\\\", \\\"{x:1485,y:241,t:1526922854710};\\\", \\\"{x:1476,y:245,t:1526922854726};\\\", \\\"{x:1464,y:256,t:1526922854744};\\\", \\\"{x:1451,y:269,t:1526922854760};\\\", \\\"{x:1445,y:279,t:1526922854776};\\\", \\\"{x:1441,y:287,t:1526922854794};\\\", \\\"{x:1440,y:291,t:1526922854810};\\\", \\\"{x:1440,y:295,t:1526922854826};\\\", \\\"{x:1440,y:298,t:1526922854843};\\\", \\\"{x:1440,y:301,t:1526922854860};\\\", \\\"{x:1443,y:309,t:1526922854877};\\\", \\\"{x:1449,y:322,t:1526922854894};\\\", \\\"{x:1456,y:333,t:1526922854911};\\\", \\\"{x:1461,y:341,t:1526922854926};\\\", \\\"{x:1468,y:351,t:1526922854944};\\\", \\\"{x:1471,y:354,t:1526922854961};\\\", \\\"{x:1473,y:357,t:1526922854976};\\\", \\\"{x:1473,y:359,t:1526922854993};\\\", \\\"{x:1474,y:364,t:1526922855011};\\\", \\\"{x:1474,y:372,t:1526922855026};\\\", \\\"{x:1473,y:385,t:1526922855044};\\\", \\\"{x:1468,y:398,t:1526922855060};\\\", \\\"{x:1460,y:409,t:1526922855077};\\\", \\\"{x:1451,y:418,t:1526922855094};\\\", \\\"{x:1439,y:427,t:1526922855111};\\\", \\\"{x:1425,y:436,t:1526922855127};\\\", \\\"{x:1405,y:448,t:1526922855144};\\\", \\\"{x:1399,y:454,t:1526922855161};\\\", \\\"{x:1396,y:459,t:1526922855177};\\\", \\\"{x:1393,y:463,t:1526922855194};\\\", \\\"{x:1393,y:467,t:1526922855211};\\\", \\\"{x:1393,y:474,t:1526922855228};\\\", \\\"{x:1393,y:482,t:1526922855243};\\\", \\\"{x:1396,y:494,t:1526922855260};\\\", \\\"{x:1402,y:509,t:1526922855277};\\\", \\\"{x:1416,y:529,t:1526922855293};\\\", \\\"{x:1430,y:549,t:1526922855310};\\\", \\\"{x:1459,y:590,t:1526922855327};\\\", \\\"{x:1496,y:622,t:1526922855343};\\\", \\\"{x:1544,y:658,t:1526922855360};\\\", \\\"{x:1595,y:694,t:1526922855378};\\\", \\\"{x:1638,y:725,t:1526922855393};\\\", \\\"{x:1679,y:753,t:1526922855411};\\\", \\\"{x:1714,y:773,t:1526922855427};\\\", \\\"{x:1744,y:790,t:1526922855444};\\\", \\\"{x:1764,y:805,t:1526922855460};\\\", \\\"{x:1778,y:816,t:1526922855478};\\\", \\\"{x:1791,y:826,t:1526922855494};\\\", \\\"{x:1802,y:833,t:1526922855510};\\\", \\\"{x:1814,y:843,t:1526922855528};\\\", \\\"{x:1822,y:849,t:1526922855544};\\\", \\\"{x:1826,y:856,t:1526922855561};\\\", \\\"{x:1831,y:864,t:1526922855578};\\\", \\\"{x:1836,y:872,t:1526922855593};\\\", \\\"{x:1839,y:880,t:1526922855610};\\\", \\\"{x:1844,y:889,t:1526922855627};\\\", \\\"{x:1846,y:896,t:1526922855644};\\\", \\\"{x:1849,y:902,t:1526922855661};\\\", \\\"{x:1849,y:906,t:1526922855678};\\\", \\\"{x:1846,y:907,t:1526922855752};\\\", \\\"{x:1837,y:907,t:1526922855761};\\\", \\\"{x:1817,y:907,t:1526922855777};\\\", \\\"{x:1791,y:903,t:1526922855795};\\\", \\\"{x:1763,y:898,t:1526922855811};\\\", \\\"{x:1736,y:889,t:1526922855828};\\\", \\\"{x:1720,y:885,t:1526922855845};\\\", \\\"{x:1711,y:882,t:1526922855861};\\\", \\\"{x:1707,y:881,t:1526922855878};\\\", \\\"{x:1704,y:879,t:1526922855895};\\\", \\\"{x:1702,y:877,t:1526922855911};\\\", \\\"{x:1690,y:875,t:1526922855928};\\\", \\\"{x:1670,y:875,t:1526922855944};\\\", \\\"{x:1644,y:875,t:1526922855961};\\\", \\\"{x:1620,y:875,t:1526922855978};\\\", \\\"{x:1598,y:875,t:1526922855995};\\\", \\\"{x:1578,y:875,t:1526922856011};\\\", \\\"{x:1560,y:875,t:1526922856028};\\\", \\\"{x:1547,y:876,t:1526922856046};\\\", \\\"{x:1538,y:879,t:1526922856061};\\\", \\\"{x:1525,y:882,t:1526922856077};\\\", \\\"{x:1507,y:886,t:1526922856095};\\\", \\\"{x:1490,y:891,t:1526922856111};\\\", \\\"{x:1474,y:895,t:1526922856128};\\\", \\\"{x:1449,y:900,t:1526922856145};\\\", \\\"{x:1437,y:902,t:1526922856161};\\\", \\\"{x:1426,y:903,t:1526922856177};\\\", \\\"{x:1420,y:904,t:1526922856195};\\\", \\\"{x:1418,y:904,t:1526922856211};\\\", \\\"{x:1417,y:904,t:1526922856228};\\\", \\\"{x:1417,y:905,t:1526922856244};\\\", \\\"{x:1417,y:904,t:1526922856432};\\\", \\\"{x:1417,y:903,t:1526922856445};\\\", \\\"{x:1417,y:902,t:1526922856480};\\\", \\\"{x:1417,y:901,t:1526922856585};\\\", \\\"{x:1417,y:900,t:1526922856595};\\\", \\\"{x:1417,y:898,t:1526922856612};\\\", \\\"{x:1417,y:896,t:1526922856629};\\\", \\\"{x:1418,y:895,t:1526922856645};\\\", \\\"{x:1420,y:891,t:1526922856662};\\\", \\\"{x:1422,y:887,t:1526922856679};\\\", \\\"{x:1428,y:879,t:1526922856694};\\\", \\\"{x:1438,y:869,t:1526922856712};\\\", \\\"{x:1443,y:865,t:1526922856728};\\\", \\\"{x:1448,y:861,t:1526922856745};\\\", \\\"{x:1451,y:858,t:1526922856762};\\\", \\\"{x:1456,y:853,t:1526922856779};\\\", \\\"{x:1463,y:845,t:1526922856795};\\\", \\\"{x:1469,y:836,t:1526922856812};\\\", \\\"{x:1474,y:830,t:1526922856829};\\\", \\\"{x:1482,y:821,t:1526922856845};\\\", \\\"{x:1488,y:816,t:1526922856862};\\\", \\\"{x:1495,y:811,t:1526922856879};\\\", \\\"{x:1500,y:806,t:1526922856895};\\\", \\\"{x:1506,y:799,t:1526922856912};\\\", \\\"{x:1510,y:795,t:1526922856928};\\\", \\\"{x:1514,y:788,t:1526922856945};\\\", \\\"{x:1523,y:778,t:1526922856962};\\\", \\\"{x:1540,y:763,t:1526922856979};\\\", \\\"{x:1558,y:744,t:1526922856995};\\\", \\\"{x:1578,y:723,t:1526922857012};\\\", \\\"{x:1592,y:711,t:1526922857029};\\\", \\\"{x:1597,y:705,t:1526922857045};\\\", \\\"{x:1599,y:703,t:1526922857062};\\\", \\\"{x:1599,y:702,t:1526922857184};\\\", \\\"{x:1600,y:701,t:1526922857200};\\\", \\\"{x:1601,y:700,t:1526922857232};\\\", \\\"{x:1603,y:700,t:1526922857248};\\\", \\\"{x:1605,y:700,t:1526922857262};\\\", \\\"{x:1607,y:700,t:1526922857279};\\\", \\\"{x:1611,y:700,t:1526922857298};\\\", \\\"{x:1614,y:701,t:1526922857312};\\\", \\\"{x:1615,y:701,t:1526922857329};\\\", \\\"{x:1616,y:701,t:1526922857346};\\\", \\\"{x:1617,y:701,t:1526922857513};\\\", \\\"{x:1618,y:701,t:1526922858649};\\\", \\\"{x:1617,y:700,t:1526922858696};\\\", \\\"{x:1617,y:699,t:1526922858720};\\\", \\\"{x:1617,y:698,t:1526922858729};\\\", \\\"{x:1617,y:697,t:1526922858792};\\\", \\\"{x:1617,y:696,t:1526922861353};\\\", \\\"{x:1617,y:695,t:1526922878812};\\\", \\\"{x:1617,y:694,t:1526922878819};\\\", \\\"{x:1617,y:697,t:1526922878835};\\\", \\\"{x:1617,y:698,t:1526922878848};\\\", \\\"{x:1617,y:701,t:1526922878866};\\\", \\\"{x:1617,y:704,t:1526922878884};\\\", \\\"{x:1617,y:705,t:1526922878900};\\\", \\\"{x:1617,y:706,t:1526922878916};\\\", \\\"{x:1617,y:707,t:1526922878947};\\\", \\\"{x:1617,y:708,t:1526922878956};\\\", \\\"{x:1617,y:709,t:1526922878966};\\\", \\\"{x:1617,y:711,t:1526922878983};\\\", \\\"{x:1617,y:712,t:1526922879000};\\\", \\\"{x:1617,y:716,t:1526922879016};\\\", \\\"{x:1617,y:718,t:1526922879033};\\\", \\\"{x:1617,y:723,t:1526922879050};\\\", \\\"{x:1617,y:728,t:1526922879066};\\\", \\\"{x:1617,y:735,t:1526922879083};\\\", \\\"{x:1617,y:738,t:1526922879100};\\\", \\\"{x:1617,y:741,t:1526922879116};\\\", \\\"{x:1617,y:743,t:1526922879133};\\\", \\\"{x:1617,y:745,t:1526922879150};\\\", \\\"{x:1617,y:747,t:1526922879166};\\\", \\\"{x:1617,y:750,t:1526922879183};\\\", \\\"{x:1617,y:752,t:1526922879200};\\\", \\\"{x:1617,y:757,t:1526922879216};\\\", \\\"{x:1617,y:762,t:1526922879233};\\\", \\\"{x:1617,y:766,t:1526922879250};\\\", \\\"{x:1617,y:772,t:1526922879266};\\\", \\\"{x:1617,y:779,t:1526922879282};\\\", \\\"{x:1617,y:780,t:1526922879300};\\\", \\\"{x:1617,y:784,t:1526922879317};\\\", \\\"{x:1617,y:786,t:1526922879332};\\\", \\\"{x:1617,y:791,t:1526922879350};\\\", \\\"{x:1617,y:795,t:1526922879367};\\\", \\\"{x:1617,y:800,t:1526922879382};\\\", \\\"{x:1617,y:806,t:1526922879400};\\\", \\\"{x:1617,y:810,t:1526922879417};\\\", \\\"{x:1616,y:817,t:1526922879433};\\\", \\\"{x:1615,y:824,t:1526922879450};\\\", \\\"{x:1615,y:832,t:1526922879467};\\\", \\\"{x:1613,y:838,t:1526922879483};\\\", \\\"{x:1612,y:845,t:1526922879500};\\\", \\\"{x:1612,y:850,t:1526922879517};\\\", \\\"{x:1612,y:852,t:1526922879534};\\\", \\\"{x:1611,y:855,t:1526922879550};\\\", \\\"{x:1611,y:856,t:1526922879567};\\\", \\\"{x:1611,y:859,t:1526922879582};\\\", \\\"{x:1609,y:863,t:1526922879599};\\\", \\\"{x:1609,y:866,t:1526922879617};\\\", \\\"{x:1609,y:871,t:1526922879633};\\\", \\\"{x:1608,y:874,t:1526922879650};\\\", \\\"{x:1607,y:878,t:1526922879667};\\\", \\\"{x:1607,y:880,t:1526922879683};\\\", \\\"{x:1607,y:882,t:1526922879700};\\\", \\\"{x:1607,y:884,t:1526922879717};\\\", \\\"{x:1606,y:885,t:1526922879734};\\\", \\\"{x:1606,y:887,t:1526922879750};\\\", \\\"{x:1606,y:890,t:1526922879768};\\\", \\\"{x:1606,y:895,t:1526922879784};\\\", \\\"{x:1606,y:899,t:1526922879800};\\\", \\\"{x:1606,y:905,t:1526922879817};\\\", \\\"{x:1606,y:912,t:1526922879834};\\\", \\\"{x:1606,y:918,t:1526922879849};\\\", \\\"{x:1606,y:928,t:1526922879867};\\\", \\\"{x:1606,y:935,t:1526922879884};\\\", \\\"{x:1606,y:942,t:1526922879900};\\\", \\\"{x:1606,y:948,t:1526922879918};\\\", \\\"{x:1606,y:951,t:1526922879934};\\\", \\\"{x:1606,y:954,t:1526922879950};\\\", \\\"{x:1606,y:955,t:1526922879971};\\\", \\\"{x:1606,y:956,t:1526922879987};\\\", \\\"{x:1606,y:957,t:1526922880001};\\\", \\\"{x:1606,y:958,t:1526922880017};\\\", \\\"{x:1606,y:960,t:1526922880034};\\\", \\\"{x:1606,y:964,t:1526922880051};\\\", \\\"{x:1606,y:966,t:1526922880067};\\\", \\\"{x:1606,y:967,t:1526922880084};\\\", \\\"{x:1606,y:969,t:1526922880100};\\\", \\\"{x:1606,y:970,t:1526922880219};\\\", \\\"{x:1606,y:965,t:1526922880300};\\\", \\\"{x:1602,y:947,t:1526922880317};\\\", \\\"{x:1592,y:921,t:1526922880334};\\\", \\\"{x:1581,y:888,t:1526922880351};\\\", \\\"{x:1571,y:862,t:1526922880367};\\\", \\\"{x:1567,y:829,t:1526922880384};\\\", \\\"{x:1562,y:794,t:1526922880401};\\\", \\\"{x:1560,y:769,t:1526922880417};\\\", \\\"{x:1555,y:747,t:1526922880434};\\\", \\\"{x:1551,y:718,t:1526922880451};\\\", \\\"{x:1549,y:703,t:1526922880467};\\\", \\\"{x:1548,y:693,t:1526922880484};\\\", \\\"{x:1548,y:684,t:1526922880501};\\\", \\\"{x:1548,y:673,t:1526922880517};\\\", \\\"{x:1548,y:667,t:1526922880534};\\\", \\\"{x:1548,y:661,t:1526922880551};\\\", \\\"{x:1548,y:655,t:1526922880568};\\\", \\\"{x:1548,y:644,t:1526922880584};\\\", \\\"{x:1548,y:639,t:1526922880601};\\\", \\\"{x:1548,y:633,t:1526922880617};\\\", \\\"{x:1548,y:629,t:1526922880633};\\\", \\\"{x:1549,y:625,t:1526922880650};\\\", \\\"{x:1550,y:625,t:1526922880668};\\\", \\\"{x:1550,y:624,t:1526922880683};\\\", \\\"{x:1551,y:622,t:1526922880706};\\\", \\\"{x:1552,y:622,t:1526922880723};\\\", \\\"{x:1552,y:621,t:1526922880734};\\\", \\\"{x:1553,y:620,t:1526922880750};\\\", \\\"{x:1556,y:619,t:1526922880768};\\\", \\\"{x:1559,y:618,t:1526922880783};\\\", \\\"{x:1562,y:618,t:1526922880800};\\\", \\\"{x:1567,y:618,t:1526922880819};\\\", \\\"{x:1568,y:618,t:1526922880842};\\\", \\\"{x:1569,y:618,t:1526922880867};\\\", \\\"{x:1570,y:618,t:1526922880882};\\\", \\\"{x:1571,y:618,t:1526922880915};\\\", \\\"{x:1573,y:619,t:1526922880939};\\\", \\\"{x:1573,y:621,t:1526922880955};\\\", \\\"{x:1574,y:622,t:1526922880971};\\\", \\\"{x:1575,y:623,t:1526922880984};\\\", \\\"{x:1576,y:624,t:1526922881001};\\\", \\\"{x:1577,y:625,t:1526922881036};\\\", \\\"{x:1577,y:627,t:1526922881260};\\\", \\\"{x:1577,y:628,t:1526922881268};\\\", \\\"{x:1577,y:629,t:1526922881285};\\\", \\\"{x:1577,y:631,t:1526922881301};\\\", \\\"{x:1577,y:632,t:1526922881317};\\\", \\\"{x:1577,y:633,t:1526922881335};\\\", \\\"{x:1577,y:634,t:1526922881351};\\\", \\\"{x:1577,y:635,t:1526922881380};\\\", \\\"{x:1577,y:636,t:1526922881387};\\\", \\\"{x:1577,y:637,t:1526922881401};\\\", \\\"{x:1577,y:638,t:1526922881418};\\\", \\\"{x:1577,y:641,t:1526922881436};\\\", \\\"{x:1577,y:643,t:1526922881452};\\\", \\\"{x:1577,y:645,t:1526922881468};\\\", \\\"{x:1577,y:646,t:1526922881485};\\\", \\\"{x:1577,y:649,t:1526922881503};\\\", \\\"{x:1577,y:651,t:1526922881518};\\\", \\\"{x:1577,y:654,t:1526922881535};\\\", \\\"{x:1576,y:659,t:1526922881552};\\\", \\\"{x:1575,y:662,t:1526922881569};\\\", \\\"{x:1575,y:667,t:1526922881585};\\\", \\\"{x:1574,y:669,t:1526922881603};\\\", \\\"{x:1574,y:675,t:1526922881620};\\\", \\\"{x:1572,y:678,t:1526922881635};\\\", \\\"{x:1572,y:682,t:1526922881652};\\\", \\\"{x:1571,y:685,t:1526922881668};\\\", \\\"{x:1571,y:689,t:1526922881685};\\\", \\\"{x:1570,y:692,t:1526922881702};\\\", \\\"{x:1569,y:696,t:1526922881718};\\\", \\\"{x:1569,y:700,t:1526922881735};\\\", \\\"{x:1569,y:706,t:1526922881752};\\\", \\\"{x:1569,y:710,t:1526922881768};\\\", \\\"{x:1569,y:714,t:1526922881786};\\\", \\\"{x:1569,y:718,t:1526922881802};\\\", \\\"{x:1569,y:722,t:1526922881820};\\\", \\\"{x:1569,y:724,t:1526922881835};\\\", \\\"{x:1569,y:726,t:1526922881852};\\\", \\\"{x:1569,y:728,t:1526922881868};\\\", \\\"{x:1569,y:730,t:1526922881885};\\\", \\\"{x:1569,y:731,t:1526922881902};\\\", \\\"{x:1569,y:732,t:1526922881919};\\\", \\\"{x:1569,y:734,t:1526922881936};\\\", \\\"{x:1570,y:736,t:1526922881953};\\\", \\\"{x:1570,y:737,t:1526922881969};\\\", \\\"{x:1571,y:740,t:1526922881985};\\\", \\\"{x:1572,y:741,t:1526922882002};\\\", \\\"{x:1572,y:743,t:1526922882019};\\\", \\\"{x:1572,y:744,t:1526922882035};\\\", \\\"{x:1572,y:745,t:1526922882059};\\\", \\\"{x:1572,y:746,t:1526922882075};\\\", \\\"{x:1573,y:746,t:1526922882085};\\\", \\\"{x:1573,y:747,t:1526922882102};\\\", \\\"{x:1573,y:749,t:1526922882123};\\\", \\\"{x:1573,y:750,t:1526922882136};\\\", \\\"{x:1574,y:753,t:1526922882152};\\\", \\\"{x:1574,y:754,t:1526922882170};\\\", \\\"{x:1575,y:756,t:1526922882185};\\\", \\\"{x:1576,y:759,t:1526922882202};\\\", \\\"{x:1576,y:760,t:1526922882220};\\\", \\\"{x:1576,y:761,t:1526922882235};\\\", \\\"{x:1576,y:763,t:1526922882252};\\\", \\\"{x:1576,y:764,t:1526922882270};\\\", \\\"{x:1576,y:766,t:1526922882286};\\\", \\\"{x:1576,y:768,t:1526922882302};\\\", \\\"{x:1578,y:771,t:1526922882319};\\\", \\\"{x:1578,y:773,t:1526922882335};\\\", \\\"{x:1578,y:775,t:1526922882352};\\\", \\\"{x:1578,y:777,t:1526922882369};\\\", \\\"{x:1579,y:779,t:1526922882386};\\\", \\\"{x:1580,y:782,t:1526922882402};\\\", \\\"{x:1580,y:785,t:1526922882419};\\\", \\\"{x:1581,y:791,t:1526922882436};\\\", \\\"{x:1582,y:795,t:1526922882452};\\\", \\\"{x:1582,y:800,t:1526922882469};\\\", \\\"{x:1583,y:802,t:1526922882486};\\\", \\\"{x:1583,y:808,t:1526922882502};\\\", \\\"{x:1583,y:813,t:1526922882519};\\\", \\\"{x:1585,y:818,t:1526922882536};\\\", \\\"{x:1586,y:823,t:1526922882553};\\\", \\\"{x:1586,y:828,t:1526922882569};\\\", \\\"{x:1586,y:832,t:1526922882586};\\\", \\\"{x:1586,y:834,t:1526922882603};\\\", \\\"{x:1587,y:838,t:1526922882621};\\\", \\\"{x:1587,y:839,t:1526922882637};\\\", \\\"{x:1587,y:842,t:1526922882653};\\\", \\\"{x:1587,y:844,t:1526922882669};\\\", \\\"{x:1589,y:846,t:1526922882686};\\\", \\\"{x:1589,y:849,t:1526922882703};\\\", \\\"{x:1589,y:851,t:1526922882719};\\\", \\\"{x:1589,y:853,t:1526922882736};\\\", \\\"{x:1589,y:856,t:1526922882752};\\\", \\\"{x:1589,y:860,t:1526922882769};\\\", \\\"{x:1589,y:863,t:1526922882786};\\\", \\\"{x:1589,y:866,t:1526922882803};\\\", \\\"{x:1589,y:868,t:1526922882820};\\\", \\\"{x:1589,y:871,t:1526922882836};\\\", \\\"{x:1589,y:874,t:1526922882853};\\\", \\\"{x:1589,y:878,t:1526922882869};\\\", \\\"{x:1589,y:880,t:1526922882886};\\\", \\\"{x:1589,y:882,t:1526922882904};\\\", \\\"{x:1589,y:884,t:1526922882920};\\\", \\\"{x:1589,y:885,t:1526922882936};\\\", \\\"{x:1589,y:888,t:1526922882953};\\\", \\\"{x:1589,y:891,t:1526922882969};\\\", \\\"{x:1589,y:894,t:1526922882987};\\\", \\\"{x:1589,y:897,t:1526922883003};\\\", \\\"{x:1588,y:901,t:1526922883019};\\\", \\\"{x:1588,y:904,t:1526922883036};\\\", \\\"{x:1588,y:908,t:1526922883053};\\\", \\\"{x:1587,y:912,t:1526922883070};\\\", \\\"{x:1586,y:916,t:1526922883086};\\\", \\\"{x:1586,y:919,t:1526922883103};\\\", \\\"{x:1585,y:923,t:1526922883119};\\\", \\\"{x:1585,y:925,t:1526922883136};\\\", \\\"{x:1584,y:927,t:1526922883154};\\\", \\\"{x:1584,y:929,t:1526922883169};\\\", \\\"{x:1584,y:931,t:1526922883186};\\\", \\\"{x:1584,y:933,t:1526922883203};\\\", \\\"{x:1584,y:936,t:1526922883221};\\\", \\\"{x:1584,y:938,t:1526922883236};\\\", \\\"{x:1584,y:939,t:1526922883253};\\\", \\\"{x:1584,y:941,t:1526922883269};\\\", \\\"{x:1584,y:942,t:1526922883286};\\\", \\\"{x:1584,y:945,t:1526922883303};\\\", \\\"{x:1585,y:946,t:1526922883320};\\\", \\\"{x:1586,y:947,t:1526922883337};\\\", \\\"{x:1588,y:949,t:1526922883353};\\\", \\\"{x:1590,y:951,t:1526922883371};\\\", \\\"{x:1593,y:952,t:1526922883387};\\\", \\\"{x:1600,y:955,t:1526922883403};\\\", \\\"{x:1602,y:956,t:1526922883421};\\\", \\\"{x:1607,y:956,t:1526922883437};\\\", \\\"{x:1610,y:958,t:1526922883453};\\\", \\\"{x:1613,y:958,t:1526922883470};\\\", \\\"{x:1616,y:958,t:1526922883486};\\\", \\\"{x:1620,y:958,t:1526922883503};\\\", \\\"{x:1622,y:958,t:1526922883520};\\\", \\\"{x:1623,y:958,t:1526922883536};\\\", \\\"{x:1624,y:958,t:1526922883643};\\\", \\\"{x:1622,y:949,t:1526922886108};\\\", \\\"{x:1575,y:904,t:1526922886123};\\\", \\\"{x:1544,y:883,t:1526922886139};\\\", \\\"{x:1467,y:838,t:1526922886155};\\\", \\\"{x:1388,y:810,t:1526922886172};\\\", \\\"{x:1328,y:784,t:1526922886189};\\\", \\\"{x:1273,y:762,t:1526922886205};\\\", \\\"{x:1244,y:750,t:1526922886222};\\\", \\\"{x:1232,y:745,t:1526922886239};\\\", \\\"{x:1228,y:743,t:1526922886255};\\\", \\\"{x:1227,y:743,t:1526922886283};\\\", \\\"{x:1226,y:742,t:1526922886291};\\\", \\\"{x:1226,y:741,t:1526922886315};\\\", \\\"{x:1227,y:741,t:1526922886403};\\\", \\\"{x:1233,y:741,t:1526922886411};\\\", \\\"{x:1240,y:741,t:1526922886423};\\\", \\\"{x:1257,y:745,t:1526922886440};\\\", \\\"{x:1274,y:751,t:1526922886455};\\\", \\\"{x:1289,y:755,t:1526922886472};\\\", \\\"{x:1293,y:755,t:1526922886490};\\\", \\\"{x:1295,y:755,t:1526922886506};\\\", \\\"{x:1296,y:755,t:1526922886523};\\\", \\\"{x:1298,y:755,t:1526922886547};\\\", \\\"{x:1299,y:755,t:1526922886555};\\\", \\\"{x:1307,y:755,t:1526922886572};\\\", \\\"{x:1316,y:755,t:1526922886589};\\\", \\\"{x:1324,y:755,t:1526922886605};\\\", \\\"{x:1328,y:755,t:1526922886622};\\\", \\\"{x:1331,y:755,t:1526922886640};\\\", \\\"{x:1335,y:755,t:1526922886656};\\\", \\\"{x:1338,y:755,t:1526922886673};\\\", \\\"{x:1341,y:755,t:1526922886689};\\\", \\\"{x:1344,y:755,t:1526922886706};\\\", \\\"{x:1345,y:755,t:1526922886723};\\\", \\\"{x:1347,y:757,t:1526922886739};\\\", \\\"{x:1348,y:757,t:1526922886756};\\\", \\\"{x:1350,y:757,t:1526922886773};\\\", \\\"{x:1352,y:758,t:1526922886790};\\\", \\\"{x:1352,y:757,t:1526922887003};\\\", \\\"{x:1352,y:755,t:1526922887011};\\\", \\\"{x:1351,y:753,t:1526922887027};\\\", \\\"{x:1350,y:750,t:1526922887039};\\\", \\\"{x:1350,y:747,t:1526922887056};\\\", \\\"{x:1350,y:743,t:1526922887073};\\\", \\\"{x:1350,y:737,t:1526922887090};\\\", \\\"{x:1350,y:728,t:1526922887107};\\\", \\\"{x:1350,y:723,t:1526922887122};\\\", \\\"{x:1350,y:720,t:1526922887140};\\\", \\\"{x:1350,y:713,t:1526922887156};\\\", \\\"{x:1350,y:708,t:1526922887173};\\\", \\\"{x:1351,y:703,t:1526922887189};\\\", \\\"{x:1351,y:698,t:1526922887207};\\\", \\\"{x:1352,y:697,t:1526922887223};\\\", \\\"{x:1352,y:694,t:1526922887239};\\\", \\\"{x:1352,y:693,t:1526922887256};\\\", \\\"{x:1352,y:691,t:1526922887445};\\\", \\\"{x:1345,y:690,t:1526922887457};\\\", \\\"{x:1322,y:680,t:1526922887474};\\\", \\\"{x:1261,y:663,t:1526922887489};\\\", \\\"{x:1091,y:639,t:1526922887507};\\\", \\\"{x:988,y:623,t:1526922887523};\\\", \\\"{x:909,y:610,t:1526922887541};\\\", \\\"{x:848,y:602,t:1526922887555};\\\", \\\"{x:782,y:593,t:1526922887573};\\\", \\\"{x:749,y:587,t:1526922887581};\\\", \\\"{x:695,y:585,t:1526922887600};\\\", \\\"{x:649,y:587,t:1526922887616};\\\", \\\"{x:578,y:604,t:1526922887640};\\\", \\\"{x:538,y:611,t:1526922887655};\\\", \\\"{x:509,y:616,t:1526922887672};\\\", \\\"{x:495,y:618,t:1526922887690};\\\", \\\"{x:494,y:618,t:1526922887707};\\\", \\\"{x:492,y:618,t:1526922887769};\\\", \\\"{x:490,y:618,t:1526922887778};\\\", \\\"{x:487,y:618,t:1526922887790};\\\", \\\"{x:473,y:618,t:1526922887805};\\\", \\\"{x:458,y:616,t:1526922887823};\\\", \\\"{x:444,y:614,t:1526922887839};\\\", \\\"{x:427,y:610,t:1526922887856};\\\", \\\"{x:410,y:605,t:1526922887874};\\\", \\\"{x:405,y:604,t:1526922887890};\\\", \\\"{x:409,y:604,t:1526922887971};\\\", \\\"{x:419,y:604,t:1526922887980};\\\", \\\"{x:430,y:601,t:1526922887990};\\\", \\\"{x:458,y:598,t:1526922888007};\\\", \\\"{x:491,y:589,t:1526922888024};\\\", \\\"{x:514,y:581,t:1526922888040};\\\", \\\"{x:531,y:572,t:1526922888056};\\\", \\\"{x:541,y:566,t:1526922888072};\\\", \\\"{x:545,y:560,t:1526922888090};\\\", \\\"{x:545,y:554,t:1526922888107};\\\", \\\"{x:545,y:546,t:1526922888122};\\\", \\\"{x:545,y:540,t:1526922888139};\\\", \\\"{x:545,y:536,t:1526922888156};\\\", \\\"{x:545,y:533,t:1526922888173};\\\", \\\"{x:545,y:530,t:1526922888190};\\\", \\\"{x:545,y:529,t:1526922888206};\\\", \\\"{x:545,y:527,t:1526922888224};\\\", \\\"{x:546,y:525,t:1526922888240};\\\", \\\"{x:546,y:524,t:1526922888257};\\\", \\\"{x:541,y:522,t:1526922888282};\\\", \\\"{x:528,y:522,t:1526922888290};\\\", \\\"{x:486,y:522,t:1526922888306};\\\", \\\"{x:436,y:527,t:1526922888324};\\\", \\\"{x:386,y:535,t:1526922888341};\\\", \\\"{x:336,y:541,t:1526922888358};\\\", \\\"{x:287,y:550,t:1526922888373};\\\", \\\"{x:253,y:555,t:1526922888391};\\\", \\\"{x:224,y:561,t:1526922888407};\\\", \\\"{x:200,y:568,t:1526922888424};\\\", \\\"{x:184,y:573,t:1526922888440};\\\", \\\"{x:175,y:576,t:1526922888457};\\\", \\\"{x:172,y:577,t:1526922888474};\\\", \\\"{x:171,y:577,t:1526922888562};\\\", \\\"{x:170,y:577,t:1526922888574};\\\", \\\"{x:169,y:580,t:1526922888723};\\\", \\\"{x:170,y:584,t:1526922888730};\\\", \\\"{x:171,y:587,t:1526922888742};\\\", \\\"{x:174,y:593,t:1526922888758};\\\", \\\"{x:178,y:598,t:1526922888774};\\\", \\\"{x:185,y:603,t:1526922888790};\\\", \\\"{x:201,y:608,t:1526922888806};\\\", \\\"{x:224,y:613,t:1526922888824};\\\", \\\"{x:255,y:616,t:1526922888841};\\\", \\\"{x:288,y:616,t:1526922888857};\\\", \\\"{x:338,y:616,t:1526922888873};\\\", \\\"{x:362,y:616,t:1526922888889};\\\", \\\"{x:375,y:616,t:1526922888906};\\\", \\\"{x:375,y:614,t:1526922888970};\\\", \\\"{x:375,y:613,t:1526922888986};\\\", \\\"{x:376,y:611,t:1526922888994};\\\", \\\"{x:377,y:610,t:1526922889006};\\\", \\\"{x:378,y:607,t:1526922889023};\\\", \\\"{x:379,y:604,t:1526922889041};\\\", \\\"{x:380,y:600,t:1526922889057};\\\", \\\"{x:383,y:593,t:1526922889074};\\\", \\\"{x:385,y:589,t:1526922889091};\\\", \\\"{x:387,y:584,t:1526922889108};\\\", \\\"{x:389,y:580,t:1526922889123};\\\", \\\"{x:389,y:578,t:1526922889141};\\\", \\\"{x:390,y:576,t:1526922889156};\\\", \\\"{x:390,y:575,t:1526922889174};\\\", \\\"{x:391,y:573,t:1526922889191};\\\", \\\"{x:392,y:571,t:1526922889210};\\\", \\\"{x:393,y:570,t:1526922889224};\\\", \\\"{x:397,y:568,t:1526922889241};\\\", \\\"{x:407,y:562,t:1526922889257};\\\", \\\"{x:424,y:556,t:1526922889274};\\\", \\\"{x:436,y:550,t:1526922889291};\\\", \\\"{x:451,y:545,t:1526922889307};\\\", \\\"{x:461,y:541,t:1526922889324};\\\", \\\"{x:474,y:538,t:1526922889341};\\\", \\\"{x:480,y:537,t:1526922889358};\\\", \\\"{x:488,y:535,t:1526922889374};\\\", \\\"{x:501,y:531,t:1526922889391};\\\", \\\"{x:516,y:530,t:1526922889408};\\\", \\\"{x:539,y:524,t:1526922889425};\\\", \\\"{x:567,y:520,t:1526922889440};\\\", \\\"{x:596,y:515,t:1526922889459};\\\", \\\"{x:609,y:511,t:1526922889475};\\\", \\\"{x:616,y:510,t:1526922889491};\\\", \\\"{x:618,y:509,t:1526922889746};\\\", \\\"{x:619,y:509,t:1526922889758};\\\", \\\"{x:628,y:506,t:1526922889775};\\\", \\\"{x:637,y:503,t:1526922889790};\\\", \\\"{x:651,y:501,t:1526922889808};\\\", \\\"{x:667,y:501,t:1526922889825};\\\", \\\"{x:684,y:501,t:1526922889840};\\\", \\\"{x:703,y:501,t:1526922889858};\\\", \\\"{x:709,y:501,t:1526922889874};\\\", \\\"{x:713,y:501,t:1526922889891};\\\", \\\"{x:714,y:501,t:1526922889907};\\\", \\\"{x:716,y:501,t:1526922889930};\\\", \\\"{x:717,y:501,t:1526922889941};\\\", \\\"{x:723,y:501,t:1526922889958};\\\", \\\"{x:740,y:501,t:1526922889976};\\\", \\\"{x:766,y:501,t:1526922889991};\\\", \\\"{x:795,y:501,t:1526922890007};\\\", \\\"{x:819,y:501,t:1526922890024};\\\", \\\"{x:833,y:501,t:1526922890041};\\\", \\\"{x:836,y:501,t:1526922890057};\\\", \\\"{x:837,y:501,t:1526922890081};\\\", \\\"{x:830,y:502,t:1526922893122};\\\", \\\"{x:822,y:505,t:1526922893130};\\\", \\\"{x:813,y:510,t:1526922893144};\\\", \\\"{x:800,y:515,t:1526922893161};\\\", \\\"{x:784,y:523,t:1526922893177};\\\", \\\"{x:774,y:527,t:1526922893193};\\\", \\\"{x:771,y:528,t:1526922893209};\\\", \\\"{x:769,y:529,t:1526922893227};\\\", \\\"{x:768,y:529,t:1526922893257};\\\", \\\"{x:766,y:528,t:1526922893266};\\\", \\\"{x:764,y:527,t:1526922893277};\\\", \\\"{x:760,y:524,t:1526922893294};\\\", \\\"{x:750,y:520,t:1526922893311};\\\", \\\"{x:738,y:515,t:1526922893327};\\\", \\\"{x:727,y:512,t:1526922893344};\\\", \\\"{x:717,y:510,t:1526922893362};\\\", \\\"{x:705,y:510,t:1526922893378};\\\", \\\"{x:696,y:510,t:1526922893394};\\\", \\\"{x:684,y:510,t:1526922893411};\\\", \\\"{x:678,y:510,t:1526922893427};\\\", \\\"{x:671,y:510,t:1526922893444};\\\", \\\"{x:666,y:510,t:1526922893461};\\\", \\\"{x:663,y:510,t:1526922893477};\\\", \\\"{x:660,y:509,t:1526922893493};\\\", \\\"{x:657,y:509,t:1526922893511};\\\", \\\"{x:653,y:508,t:1526922893527};\\\", \\\"{x:648,y:508,t:1526922893544};\\\", \\\"{x:644,y:508,t:1526922893561};\\\", \\\"{x:635,y:504,t:1526922893579};\\\", \\\"{x:627,y:502,t:1526922893594};\\\", \\\"{x:623,y:501,t:1526922893611};\\\", \\\"{x:619,y:500,t:1526922893628};\\\", \\\"{x:615,y:500,t:1526922893644};\\\", \\\"{x:612,y:500,t:1526922893661};\\\", \\\"{x:609,y:500,t:1526922893678};\\\", \\\"{x:606,y:500,t:1526922893694};\\\", \\\"{x:602,y:500,t:1526922893711};\\\", \\\"{x:601,y:500,t:1526922893728};\\\", \\\"{x:600,y:500,t:1526922893745};\\\", \\\"{x:598,y:499,t:1526922893833};\\\", \\\"{x:598,y:499,t:1526922893874};\\\", \\\"{x:598,y:498,t:1526922893914};\\\", \\\"{x:593,y:502,t:1526922893928};\\\", \\\"{x:579,y:538,t:1526922893945};\\\", \\\"{x:556,y:591,t:1526922893962};\\\", \\\"{x:534,y:647,t:1526922893978};\\\", \\\"{x:525,y:669,t:1526922893994};\\\", \\\"{x:523,y:686,t:1526922894011};\\\", \\\"{x:520,y:699,t:1526922894028};\\\", \\\"{x:520,y:710,t:1526922894045};\\\", \\\"{x:523,y:722,t:1526922894062};\\\", \\\"{x:525,y:729,t:1526922894078};\\\", \\\"{x:527,y:733,t:1526922894095};\\\", \\\"{x:527,y:736,t:1526922894112};\\\", \\\"{x:528,y:736,t:1526922894127};\\\", \\\"{x:528,y:737,t:1526922894144};\\\", \\\"{x:529,y:736,t:1526922894587};\\\", \\\"{x:529,y:731,t:1526922894598};\\\", \\\"{x:532,y:719,t:1526922894615};\\\", \\\"{x:534,y:701,t:1526922894630};\\\", \\\"{x:541,y:676,t:1526922894645};\\\", \\\"{x:547,y:648,t:1526922894660};\\\", \\\"{x:555,y:624,t:1526922894678};\\\", \\\"{x:561,y:604,t:1526922894695};\\\", \\\"{x:565,y:593,t:1526922894712};\\\", \\\"{x:572,y:578,t:1526922894727};\\\", \\\"{x:573,y:572,t:1526922894745};\\\", \\\"{x:577,y:562,t:1526922894762};\\\", \\\"{x:580,y:554,t:1526922894779};\\\", \\\"{x:580,y:550,t:1526922894795};\\\", \\\"{x:580,y:545,t:1526922894812};\\\", \\\"{x:581,y:537,t:1526922894828};\\\", \\\"{x:585,y:528,t:1526922894845};\\\", \\\"{x:588,y:520,t:1526922894863};\\\", \\\"{x:593,y:509,t:1526922894880};\\\", \\\"{x:600,y:493,t:1526922894896};\\\", \\\"{x:603,y:484,t:1526922894913};\\\", \\\"{x:606,y:478,t:1526922894928};\\\", \\\"{x:607,y:475,t:1526922894945};\\\", \\\"{x:608,y:473,t:1526922894962};\\\", \\\"{x:608,y:474,t:1526922895075};\\\", \\\"{x:607,y:478,t:1526922895083};\\\", \\\"{x:606,y:481,t:1526922895095};\\\", \\\"{x:604,y:487,t:1526922895114};\\\", \\\"{x:604,y:488,t:1526922895129};\\\", \\\"{x:604,y:489,t:1526922895146};\\\", \\\"{x:604,y:490,t:1526922895203};\\\", \\\"{x:604,y:492,t:1526922895214};\\\", \\\"{x:604,y:495,t:1526922895229};\\\", \\\"{x:604,y:498,t:1526922895245};\\\", \\\"{x:604,y:499,t:1526922895262};\\\", \\\"{x:604,y:500,t:1526922895490};\\\", \\\"{x:604,y:501,t:1526922895498};\\\", \\\"{x:604,y:504,t:1526922895512};\\\", \\\"{x:604,y:508,t:1526922895529};\\\", \\\"{x:604,y:509,t:1526922895546};\\\", \\\"{x:604,y:510,t:1526922895569};\\\", \\\"{x:604,y:511,t:1526922895579};\\\", \\\"{x:602,y:516,t:1526922895597};\\\", \\\"{x:597,y:535,t:1526922895613};\\\", \\\"{x:581,y:567,t:1526922895630};\\\", \\\"{x:557,y:617,t:1526922895647};\\\", \\\"{x:536,y:667,t:1526922895663};\\\", \\\"{x:519,y:703,t:1526922895679};\\\", \\\"{x:510,y:729,t:1526922895696};\\\", \\\"{x:504,y:751,t:1526922895713};\\\", \\\"{x:501,y:774,t:1526922895730};\\\", \\\"{x:501,y:795,t:1526922895746};\\\", \\\"{x:501,y:805,t:1526922895762};\\\", \\\"{x:501,y:810,t:1526922895779};\\\", \\\"{x:501,y:811,t:1526922895796};\\\", \\\"{x:502,y:811,t:1526922895874};\\\", \\\"{x:504,y:809,t:1526922895882};\\\", \\\"{x:505,y:805,t:1526922895896};\\\", \\\"{x:508,y:795,t:1526922895913};\\\", \\\"{x:513,y:786,t:1526922895929};\\\", \\\"{x:516,y:771,t:1526922895946};\\\", \\\"{x:518,y:767,t:1526922895963};\\\", \\\"{x:519,y:763,t:1526922895980};\\\", \\\"{x:519,y:759,t:1526922895997};\\\", \\\"{x:520,y:753,t:1526922896015};\\\", \\\"{x:522,y:749,t:1526922896029};\\\", \\\"{x:523,y:745,t:1526922896047};\\\", \\\"{x:523,y:744,t:1526922896063};\\\", \\\"{x:524,y:742,t:1526922896079};\\\", \\\"{x:525,y:741,t:1526922896095};\\\", \\\"{x:526,y:739,t:1526922896112};\\\", \\\"{x:528,y:733,t:1526922896129};\\\", \\\"{x:530,y:731,t:1526922896145};\\\", \\\"{x:531,y:730,t:1526922896195};\\\", \\\"{x:533,y:730,t:1526922896217};\\\", \\\"{x:533,y:729,t:1526922896230};\\\", \\\"{x:533,y:729,t:1526922896278};\\\", \\\"{x:533,y:728,t:1526922897243};\\\", \\\"{x:533,y:727,t:1526922897267};\\\", \\\"{x:533,y:726,t:1526922897283};\\\", \\\"{x:533,y:725,t:1526922897305};\\\", \\\"{x:532,y:725,t:1526922897354};\\\" ] }, { \\\"rt\\\": 19908, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 528306, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"DKL3R\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-F -F -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:529,y:725,t:1526922897859};\\\", \\\"{x:435,y:672,t:1526922897948};\\\", \\\"{x:415,y:651,t:1526922897965};\\\", \\\"{x:401,y:630,t:1526922897982};\\\", \\\"{x:395,y:616,t:1526922897998};\\\", \\\"{x:392,y:608,t:1526922898014};\\\", \\\"{x:390,y:602,t:1526922898031};\\\", \\\"{x:386,y:594,t:1526922898047};\\\", \\\"{x:385,y:586,t:1526922898064};\\\", \\\"{x:384,y:580,t:1526922898081};\\\", \\\"{x:382,y:565,t:1526922898098};\\\", \\\"{x:382,y:558,t:1526922898114};\\\", \\\"{x:382,y:552,t:1526922898131};\\\", \\\"{x:382,y:546,t:1526922898148};\\\", \\\"{x:383,y:540,t:1526922898164};\\\", \\\"{x:385,y:536,t:1526922898181};\\\", \\\"{x:388,y:531,t:1526922898198};\\\", \\\"{x:390,y:527,t:1526922898215};\\\", \\\"{x:393,y:523,t:1526922898231};\\\", \\\"{x:394,y:521,t:1526922898248};\\\", \\\"{x:395,y:520,t:1526922898264};\\\", \\\"{x:397,y:518,t:1526922898281};\\\", \\\"{x:399,y:514,t:1526922898299};\\\", \\\"{x:402,y:510,t:1526922898314};\\\", \\\"{x:405,y:508,t:1526922898331};\\\", \\\"{x:407,y:505,t:1526922898348};\\\", \\\"{x:408,y:503,t:1526922898364};\\\", \\\"{x:411,y:500,t:1526922898381};\\\", \\\"{x:412,y:499,t:1526922898398};\\\", \\\"{x:413,y:498,t:1526922898415};\\\", \\\"{x:414,y:497,t:1526922898432};\\\", \\\"{x:417,y:495,t:1526922898449};\\\", \\\"{x:418,y:493,t:1526922898465};\\\", \\\"{x:420,y:493,t:1526922898481};\\\", \\\"{x:420,y:492,t:1526922898498};\\\", \\\"{x:422,y:491,t:1526922898515};\\\", \\\"{x:423,y:491,t:1526922898579};\\\", \\\"{x:424,y:491,t:1526922898593};\\\", \\\"{x:425,y:490,t:1526922898875};\\\", \\\"{x:426,y:490,t:1526922898882};\\\", \\\"{x:429,y:490,t:1526922898898};\\\", \\\"{x:435,y:491,t:1526922898915};\\\", \\\"{x:447,y:492,t:1526922898932};\\\", \\\"{x:453,y:494,t:1526922898948};\\\", \\\"{x:456,y:494,t:1526922898965};\\\", \\\"{x:458,y:494,t:1526922898982};\\\", \\\"{x:459,y:494,t:1526922898998};\\\", \\\"{x:460,y:494,t:1526922899034};\\\", \\\"{x:462,y:494,t:1526922899058};\\\", \\\"{x:463,y:494,t:1526922899066};\\\", \\\"{x:469,y:494,t:1526922899082};\\\", \\\"{x:475,y:494,t:1526922899099};\\\", \\\"{x:481,y:493,t:1526922899115};\\\", \\\"{x:485,y:492,t:1526922899132};\\\", \\\"{x:488,y:492,t:1526922899149};\\\", \\\"{x:495,y:491,t:1526922899165};\\\", \\\"{x:504,y:491,t:1526922899183};\\\", \\\"{x:519,y:491,t:1526922899199};\\\", \\\"{x:537,y:491,t:1526922899216};\\\", \\\"{x:560,y:491,t:1526922899233};\\\", \\\"{x:582,y:491,t:1526922899248};\\\", \\\"{x:601,y:491,t:1526922899266};\\\", \\\"{x:623,y:491,t:1526922899283};\\\", \\\"{x:636,y:491,t:1526922899298};\\\", \\\"{x:649,y:491,t:1526922899316};\\\", \\\"{x:664,y:491,t:1526922899332};\\\", \\\"{x:677,y:492,t:1526922899349};\\\", \\\"{x:695,y:495,t:1526922899365};\\\", \\\"{x:714,y:497,t:1526922899382};\\\", \\\"{x:734,y:500,t:1526922899400};\\\", \\\"{x:749,y:502,t:1526922899415};\\\", \\\"{x:764,y:504,t:1526922899432};\\\", \\\"{x:776,y:506,t:1526922899449};\\\", \\\"{x:791,y:509,t:1526922899465};\\\", \\\"{x:832,y:518,t:1526922899482};\\\", \\\"{x:881,y:529,t:1526922899499};\\\", \\\"{x:942,y:544,t:1526922899514};\\\", \\\"{x:1006,y:563,t:1526922899532};\\\", \\\"{x:1078,y:585,t:1526922899550};\\\", \\\"{x:1150,y:605,t:1526922899565};\\\", \\\"{x:1228,y:617,t:1526922899582};\\\", \\\"{x:1307,y:630,t:1526922899599};\\\", \\\"{x:1402,y:650,t:1526922899615};\\\", \\\"{x:1500,y:665,t:1526922899633};\\\", \\\"{x:1594,y:691,t:1526922899650};\\\", \\\"{x:1679,y:710,t:1526922899666};\\\", \\\"{x:1777,y:732,t:1526922899682};\\\", \\\"{x:1821,y:742,t:1526922899700};\\\", \\\"{x:1843,y:744,t:1526922899715};\\\", \\\"{x:1852,y:746,t:1526922899732};\\\", \\\"{x:1853,y:747,t:1526922899762};\\\", \\\"{x:1850,y:747,t:1526922899843};\\\", \\\"{x:1842,y:747,t:1526922899850};\\\", \\\"{x:1833,y:747,t:1526922899866};\\\", \\\"{x:1790,y:753,t:1526922899882};\\\", \\\"{x:1761,y:758,t:1526922899900};\\\", \\\"{x:1729,y:762,t:1526922899916};\\\", \\\"{x:1702,y:765,t:1526922899933};\\\", \\\"{x:1682,y:766,t:1526922899949};\\\", \\\"{x:1671,y:766,t:1526922899966};\\\", \\\"{x:1664,y:766,t:1526922899982};\\\", \\\"{x:1660,y:766,t:1526922900000};\\\", \\\"{x:1656,y:766,t:1526922900015};\\\", \\\"{x:1650,y:766,t:1526922900033};\\\", \\\"{x:1642,y:766,t:1526922900049};\\\", \\\"{x:1629,y:764,t:1526922900066};\\\", \\\"{x:1605,y:758,t:1526922900082};\\\", \\\"{x:1589,y:752,t:1526922900100};\\\", \\\"{x:1575,y:746,t:1526922900116};\\\", \\\"{x:1561,y:741,t:1526922900133};\\\", \\\"{x:1548,y:736,t:1526922900150};\\\", \\\"{x:1543,y:733,t:1526922900166};\\\", \\\"{x:1542,y:733,t:1526922900183};\\\", \\\"{x:1541,y:733,t:1526922900242};\\\", \\\"{x:1539,y:734,t:1526922900291};\\\", \\\"{x:1535,y:741,t:1526922900300};\\\", \\\"{x:1531,y:752,t:1526922900316};\\\", \\\"{x:1526,y:765,t:1526922900333};\\\", \\\"{x:1521,y:782,t:1526922900349};\\\", \\\"{x:1520,y:796,t:1526922900366};\\\", \\\"{x:1519,y:810,t:1526922900383};\\\", \\\"{x:1519,y:825,t:1526922900399};\\\", \\\"{x:1519,y:841,t:1526922900416};\\\", \\\"{x:1521,y:856,t:1526922900433};\\\", \\\"{x:1526,y:871,t:1526922900450};\\\", \\\"{x:1533,y:889,t:1526922900466};\\\", \\\"{x:1555,y:915,t:1526922900483};\\\", \\\"{x:1569,y:927,t:1526922900500};\\\", \\\"{x:1578,y:933,t:1526922900515};\\\", \\\"{x:1582,y:936,t:1526922900533};\\\", \\\"{x:1583,y:937,t:1526922900550};\\\", \\\"{x:1583,y:938,t:1526922900578};\\\", \\\"{x:1583,y:940,t:1526922900594};\\\", \\\"{x:1583,y:943,t:1526922900610};\\\", \\\"{x:1581,y:945,t:1526922900626};\\\", \\\"{x:1579,y:946,t:1526922900634};\\\", \\\"{x:1577,y:946,t:1526922900649};\\\", \\\"{x:1567,y:950,t:1526922900665};\\\", \\\"{x:1547,y:954,t:1526922900682};\\\", \\\"{x:1536,y:959,t:1526922900699};\\\", \\\"{x:1530,y:962,t:1526922900715};\\\", \\\"{x:1528,y:963,t:1526922900732};\\\", \\\"{x:1527,y:964,t:1526922900749};\\\", \\\"{x:1527,y:966,t:1526922900766};\\\", \\\"{x:1527,y:967,t:1526922900783};\\\", \\\"{x:1527,y:968,t:1526922900799};\\\", \\\"{x:1527,y:969,t:1526922900867};\\\", \\\"{x:1528,y:969,t:1526922900883};\\\", \\\"{x:1529,y:969,t:1526922900900};\\\", \\\"{x:1531,y:969,t:1526922900916};\\\", \\\"{x:1535,y:971,t:1526922900933};\\\", \\\"{x:1536,y:972,t:1526922900949};\\\", \\\"{x:1537,y:973,t:1526922900966};\\\", \\\"{x:1540,y:973,t:1526922900982};\\\", \\\"{x:1541,y:973,t:1526922901000};\\\", \\\"{x:1543,y:973,t:1526922901016};\\\", \\\"{x:1544,y:973,t:1526922901034};\\\", \\\"{x:1545,y:973,t:1526922901299};\\\", \\\"{x:1546,y:971,t:1526922901315};\\\", \\\"{x:1547,y:969,t:1526922901332};\\\", \\\"{x:1548,y:966,t:1526922901351};\\\", \\\"{x:1548,y:963,t:1526922901365};\\\", \\\"{x:1549,y:962,t:1526922901384};\\\", \\\"{x:1549,y:961,t:1526922901400};\\\", \\\"{x:1549,y:960,t:1526922901747};\\\", \\\"{x:1549,y:959,t:1526922901811};\\\", \\\"{x:1549,y:958,t:1526922902571};\\\", \\\"{x:1549,y:957,t:1526922902619};\\\", \\\"{x:1549,y:956,t:1526922902778};\\\", \\\"{x:1549,y:955,t:1526922902835};\\\", \\\"{x:1550,y:954,t:1526922902850};\\\", \\\"{x:1550,y:953,t:1526922903035};\\\", \\\"{x:1550,y:952,t:1526922903145};\\\", \\\"{x:1550,y:951,t:1526922903194};\\\", \\\"{x:1550,y:950,t:1526922903250};\\\", \\\"{x:1550,y:949,t:1526922903284};\\\", \\\"{x:1550,y:948,t:1526922903339};\\\", \\\"{x:1550,y:947,t:1526922903427};\\\", \\\"{x:1550,y:946,t:1526922903515};\\\", \\\"{x:1550,y:945,t:1526922903571};\\\", \\\"{x:1550,y:944,t:1526922904626};\\\", \\\"{x:1550,y:943,t:1526922906602};\\\", \\\"{x:1550,y:942,t:1526922906616};\\\", \\\"{x:1550,y:941,t:1526922906667};\\\", \\\"{x:1550,y:940,t:1526922906746};\\\", \\\"{x:1549,y:939,t:1526922908283};\\\", \\\"{x:1535,y:938,t:1526922908300};\\\", \\\"{x:1514,y:931,t:1526922908316};\\\", \\\"{x:1490,y:920,t:1526922908333};\\\", \\\"{x:1481,y:917,t:1526922908350};\\\", \\\"{x:1476,y:914,t:1526922908366};\\\", \\\"{x:1472,y:910,t:1526922908383};\\\", \\\"{x:1468,y:902,t:1526922908400};\\\", \\\"{x:1466,y:885,t:1526922908416};\\\", \\\"{x:1457,y:856,t:1526922908433};\\\", \\\"{x:1431,y:795,t:1526922908450};\\\", \\\"{x:1413,y:755,t:1526922908466};\\\", \\\"{x:1399,y:727,t:1526922908483};\\\", \\\"{x:1389,y:704,t:1526922908499};\\\", \\\"{x:1376,y:684,t:1526922908516};\\\", \\\"{x:1369,y:671,t:1526922908533};\\\", \\\"{x:1364,y:665,t:1526922908549};\\\", \\\"{x:1361,y:659,t:1526922908566};\\\", \\\"{x:1359,y:656,t:1526922908583};\\\", \\\"{x:1355,y:654,t:1526922908600};\\\", \\\"{x:1352,y:652,t:1526922908615};\\\", \\\"{x:1350,y:650,t:1526922908633};\\\", \\\"{x:1347,y:649,t:1526922908650};\\\", \\\"{x:1346,y:649,t:1526922908666};\\\", \\\"{x:1344,y:649,t:1526922908771};\\\", \\\"{x:1344,y:651,t:1526922908783};\\\", \\\"{x:1344,y:653,t:1526922908800};\\\", \\\"{x:1343,y:656,t:1526922908816};\\\", \\\"{x:1343,y:658,t:1526922908833};\\\", \\\"{x:1343,y:661,t:1526922908849};\\\", \\\"{x:1343,y:665,t:1526922908866};\\\", \\\"{x:1343,y:668,t:1526922908883};\\\", \\\"{x:1343,y:671,t:1526922908900};\\\", \\\"{x:1343,y:673,t:1526922908916};\\\", \\\"{x:1343,y:674,t:1526922908938};\\\", \\\"{x:1343,y:675,t:1526922908970};\\\", \\\"{x:1343,y:676,t:1526922908986};\\\", \\\"{x:1343,y:677,t:1526922908999};\\\", \\\"{x:1343,y:679,t:1526922909017};\\\", \\\"{x:1343,y:681,t:1526922909034};\\\", \\\"{x:1343,y:682,t:1526922909059};\\\", \\\"{x:1343,y:683,t:1526922909178};\\\", \\\"{x:1343,y:684,t:1526922909315};\\\", \\\"{x:1343,y:685,t:1526922909322};\\\", \\\"{x:1343,y:687,t:1526922909333};\\\", \\\"{x:1343,y:690,t:1526922909349};\\\", \\\"{x:1343,y:691,t:1526922909371};\\\", \\\"{x:1344,y:692,t:1526922909757};\\\", \\\"{x:1344,y:693,t:1526922911730};\\\", \\\"{x:1344,y:697,t:1526922911738};\\\", \\\"{x:1344,y:703,t:1526922911750};\\\", \\\"{x:1347,y:718,t:1526922911766};\\\", \\\"{x:1352,y:735,t:1526922911784};\\\", \\\"{x:1358,y:755,t:1526922911799};\\\", \\\"{x:1363,y:772,t:1526922911816};\\\", \\\"{x:1365,y:781,t:1526922911833};\\\", \\\"{x:1366,y:783,t:1526922911849};\\\", \\\"{x:1367,y:784,t:1526922911867};\\\", \\\"{x:1365,y:784,t:1526922912051};\\\", \\\"{x:1364,y:784,t:1526922912066};\\\", \\\"{x:1362,y:784,t:1526922912083};\\\", \\\"{x:1361,y:783,t:1526922912114};\\\", \\\"{x:1361,y:782,t:1526922912122};\\\", \\\"{x:1360,y:782,t:1526922912133};\\\", \\\"{x:1360,y:778,t:1526922912149};\\\", \\\"{x:1360,y:777,t:1526922912167};\\\", \\\"{x:1360,y:776,t:1526922912183};\\\", \\\"{x:1360,y:774,t:1526922912200};\\\", \\\"{x:1360,y:772,t:1526922912216};\\\", \\\"{x:1360,y:771,t:1526922912233};\\\", \\\"{x:1359,y:770,t:1526922912250};\\\", \\\"{x:1359,y:769,t:1526922912284};\\\", \\\"{x:1359,y:768,t:1526922912299};\\\", \\\"{x:1358,y:767,t:1526922912323};\\\", \\\"{x:1358,y:766,t:1526922912355};\\\", \\\"{x:1357,y:765,t:1526922912370};\\\", \\\"{x:1357,y:764,t:1526922912403};\\\", \\\"{x:1357,y:763,t:1526922912416};\\\", \\\"{x:1356,y:762,t:1526922912492};\\\", \\\"{x:1355,y:762,t:1526922912667};\\\", \\\"{x:1354,y:762,t:1526922912691};\\\", \\\"{x:1354,y:761,t:1526922912731};\\\", \\\"{x:1353,y:761,t:1526922912755};\\\", \\\"{x:1352,y:761,t:1526922912784};\\\", \\\"{x:1351,y:761,t:1526922912810};\\\", \\\"{x:1351,y:760,t:1526922912818};\\\", \\\"{x:1350,y:760,t:1526922912874};\\\", \\\"{x:1349,y:760,t:1526922912907};\\\", \\\"{x:1348,y:760,t:1526922912916};\\\", \\\"{x:1347,y:759,t:1526922913002};\\\", \\\"{x:1346,y:759,t:1526922913049};\\\", \\\"{x:1345,y:759,t:1526922913129};\\\", \\\"{x:1345,y:758,t:1526922913137};\\\", \\\"{x:1342,y:758,t:1526922915380};\\\", \\\"{x:1326,y:754,t:1526922915387};\\\", \\\"{x:1286,y:747,t:1526922915400};\\\", \\\"{x:1170,y:732,t:1526922915416};\\\", \\\"{x:1045,y:714,t:1526922915433};\\\", \\\"{x:920,y:695,t:1526922915449};\\\", \\\"{x:739,y:656,t:1526922915467};\\\", \\\"{x:652,y:640,t:1526922915483};\\\", \\\"{x:629,y:636,t:1526922915499};\\\", \\\"{x:626,y:636,t:1526922915516};\\\", \\\"{x:625,y:636,t:1526922915571};\\\", \\\"{x:622,y:635,t:1526922915583};\\\", \\\"{x:606,y:633,t:1526922915599};\\\", \\\"{x:582,y:633,t:1526922915616};\\\", \\\"{x:559,y:632,t:1526922915633};\\\", \\\"{x:530,y:631,t:1526922915651};\\\", \\\"{x:476,y:623,t:1526922915667};\\\", \\\"{x:397,y:605,t:1526922915699};\\\", \\\"{x:386,y:600,t:1526922915713};\\\", \\\"{x:372,y:594,t:1526922915729};\\\", \\\"{x:364,y:588,t:1526922915745};\\\", \\\"{x:361,y:585,t:1526922915761};\\\", \\\"{x:361,y:584,t:1526922915778};\\\", \\\"{x:360,y:582,t:1526922915795};\\\", \\\"{x:358,y:578,t:1526922915811};\\\", \\\"{x:356,y:575,t:1526922915829};\\\", \\\"{x:353,y:573,t:1526922915846};\\\", \\\"{x:352,y:572,t:1526922915861};\\\", \\\"{x:350,y:572,t:1526922916065};\\\", \\\"{x:340,y:572,t:1526922916079};\\\", \\\"{x:307,y:572,t:1526922916096};\\\", \\\"{x:251,y:572,t:1526922916113};\\\", \\\"{x:162,y:572,t:1526922916129};\\\", \\\"{x:111,y:572,t:1526922916145};\\\", \\\"{x:83,y:572,t:1526922916163};\\\", \\\"{x:76,y:571,t:1526922916178};\\\", \\\"{x:78,y:568,t:1526922916290};\\\", \\\"{x:79,y:568,t:1526922916297};\\\", \\\"{x:81,y:567,t:1526922916313};\\\", \\\"{x:88,y:563,t:1526922916329};\\\", \\\"{x:99,y:559,t:1526922916347};\\\", \\\"{x:106,y:557,t:1526922916363};\\\", \\\"{x:115,y:554,t:1526922916380};\\\", \\\"{x:124,y:551,t:1526922916396};\\\", \\\"{x:132,y:548,t:1526922916412};\\\", \\\"{x:138,y:545,t:1526922916428};\\\", \\\"{x:144,y:542,t:1526922916446};\\\", \\\"{x:147,y:539,t:1526922916463};\\\", \\\"{x:151,y:536,t:1526922916479};\\\", \\\"{x:152,y:536,t:1526922916497};\\\", \\\"{x:152,y:535,t:1526922916602};\\\", \\\"{x:153,y:535,t:1526922916634};\\\", \\\"{x:156,y:537,t:1526922916737};\\\", \\\"{x:167,y:549,t:1526922916745};\\\", \\\"{x:225,y:602,t:1526922916764};\\\", \\\"{x:324,y:662,t:1526922916781};\\\", \\\"{x:449,y:706,t:1526922916796};\\\", \\\"{x:569,y:729,t:1526922916813};\\\", \\\"{x:631,y:739,t:1526922916829};\\\", \\\"{x:651,y:743,t:1526922916846};\\\", \\\"{x:652,y:743,t:1526922916881};\\\", \\\"{x:652,y:742,t:1526922916913};\\\", \\\"{x:651,y:739,t:1526922916930};\\\", \\\"{x:650,y:735,t:1526922916945};\\\", \\\"{x:647,y:732,t:1526922916963};\\\", \\\"{x:644,y:727,t:1526922916980};\\\", \\\"{x:642,y:726,t:1526922916997};\\\", \\\"{x:637,y:725,t:1526922917013};\\\", \\\"{x:628,y:725,t:1526922917030};\\\", \\\"{x:620,y:725,t:1526922917047};\\\", \\\"{x:612,y:727,t:1526922917063};\\\", \\\"{x:607,y:727,t:1526922917081};\\\", \\\"{x:600,y:729,t:1526922917097};\\\", \\\"{x:595,y:730,t:1526922917113};\\\", \\\"{x:589,y:732,t:1526922917130};\\\", \\\"{x:585,y:732,t:1526922917146};\\\", \\\"{x:577,y:732,t:1526922917163};\\\", \\\"{x:570,y:732,t:1526922917180};\\\", \\\"{x:559,y:732,t:1526922917201};\\\", \\\"{x:552,y:732,t:1526922917213};\\\", \\\"{x:550,y:732,t:1526922917229};\\\" ] }, { \\\"rt\\\": 55950, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 585472, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"DKL3R\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 2, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-03 PM-02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:551,y:732,t:1526922921138};\\\", \\\"{x:552,y:732,t:1526922921170};\\\", \\\"{x:553,y:732,t:1526922921202};\\\", \\\"{x:554,y:732,t:1526922921234};\\\", \\\"{x:555,y:733,t:1526922921267};\\\", \\\"{x:556,y:733,t:1526922922218};\\\", \\\"{x:557,y:733,t:1526922922242};\\\", \\\"{x:558,y:733,t:1526922922298};\\\", \\\"{x:559,y:733,t:1526922922330};\\\", \\\"{x:560,y:733,t:1526922922691};\\\", \\\"{x:560,y:731,t:1526922922747};\\\", \\\"{x:560,y:730,t:1526922922802};\\\", \\\"{x:559,y:730,t:1526922922818};\\\", \\\"{x:559,y:729,t:1526922923451};\\\", \\\"{x:560,y:729,t:1526922923482};\\\", \\\"{x:567,y:729,t:1526922924595};\\\", \\\"{x:588,y:732,t:1526922924602};\\\", \\\"{x:671,y:753,t:1526922924620};\\\", \\\"{x:731,y:775,t:1526922924636};\\\", \\\"{x:777,y:794,t:1526922924653};\\\", \\\"{x:830,y:810,t:1526922924669};\\\", \\\"{x:930,y:838,t:1526922924686};\\\", \\\"{x:1094,y:871,t:1526922924703};\\\", \\\"{x:1269,y:895,t:1526922924720};\\\", \\\"{x:1448,y:920,t:1526922924735};\\\", \\\"{x:1619,y:938,t:1526922924753};\\\", \\\"{x:1819,y:935,t:1526922924770};\\\", \\\"{x:1894,y:914,t:1526922924786};\\\", \\\"{x:1917,y:901,t:1526922924803};\\\", \\\"{x:1919,y:897,t:1526922924819};\\\", \\\"{x:1919,y:892,t:1526922924835};\\\", \\\"{x:1912,y:874,t:1526922924853};\\\", \\\"{x:1893,y:853,t:1526922924869};\\\", \\\"{x:1868,y:835,t:1526922924885};\\\", \\\"{x:1834,y:822,t:1526922924902};\\\", \\\"{x:1801,y:819,t:1526922924920};\\\", \\\"{x:1759,y:819,t:1526922924936};\\\", \\\"{x:1714,y:831,t:1526922924952};\\\", \\\"{x:1664,y:857,t:1526922924970};\\\", \\\"{x:1651,y:868,t:1526922924985};\\\", \\\"{x:1645,y:879,t:1526922925004};\\\", \\\"{x:1643,y:891,t:1526922925020};\\\", \\\"{x:1643,y:897,t:1526922925036};\\\", \\\"{x:1643,y:904,t:1526922925054};\\\", \\\"{x:1643,y:909,t:1526922925070};\\\", \\\"{x:1642,y:912,t:1526922925087};\\\", \\\"{x:1641,y:918,t:1526922925104};\\\", \\\"{x:1641,y:919,t:1526922925120};\\\", \\\"{x:1641,y:922,t:1526922925137};\\\", \\\"{x:1641,y:923,t:1526922925154};\\\", \\\"{x:1641,y:925,t:1526922925170};\\\", \\\"{x:1641,y:926,t:1526922925186};\\\", \\\"{x:1641,y:930,t:1526922925204};\\\", \\\"{x:1641,y:934,t:1526922925220};\\\", \\\"{x:1641,y:938,t:1526922925236};\\\", \\\"{x:1641,y:940,t:1526922925254};\\\", \\\"{x:1641,y:941,t:1526922925269};\\\", \\\"{x:1641,y:942,t:1526922925287};\\\", \\\"{x:1641,y:943,t:1526922925303};\\\", \\\"{x:1641,y:945,t:1526922925320};\\\", \\\"{x:1642,y:946,t:1526922925336};\\\", \\\"{x:1644,y:948,t:1526922925354};\\\", \\\"{x:1646,y:949,t:1526922925370};\\\", \\\"{x:1651,y:952,t:1526922925387};\\\", \\\"{x:1652,y:953,t:1526922925404};\\\", \\\"{x:1656,y:954,t:1526922925420};\\\", \\\"{x:1660,y:956,t:1526922925437};\\\", \\\"{x:1662,y:957,t:1526922925453};\\\", \\\"{x:1666,y:959,t:1526922925471};\\\", \\\"{x:1668,y:960,t:1526922925486};\\\", \\\"{x:1671,y:960,t:1526922925503};\\\", \\\"{x:1674,y:960,t:1526922925521};\\\", \\\"{x:1674,y:961,t:1526922925537};\\\", \\\"{x:1674,y:962,t:1526922925587};\\\", \\\"{x:1672,y:964,t:1526922925604};\\\", \\\"{x:1668,y:964,t:1526922925620};\\\", \\\"{x:1660,y:966,t:1526922925637};\\\", \\\"{x:1649,y:967,t:1526922925654};\\\", \\\"{x:1632,y:969,t:1526922925671};\\\", \\\"{x:1614,y:972,t:1526922925686};\\\", \\\"{x:1595,y:975,t:1526922925704};\\\", \\\"{x:1575,y:977,t:1526922925722};\\\", \\\"{x:1558,y:977,t:1526922925738};\\\", \\\"{x:1530,y:977,t:1526922925754};\\\", \\\"{x:1518,y:977,t:1526922925771};\\\", \\\"{x:1511,y:977,t:1526922925787};\\\", \\\"{x:1506,y:976,t:1526922925803};\\\", \\\"{x:1504,y:974,t:1526922925820};\\\", \\\"{x:1503,y:974,t:1526922925837};\\\", \\\"{x:1502,y:973,t:1526922925858};\\\", \\\"{x:1501,y:973,t:1526922925871};\\\", \\\"{x:1498,y:973,t:1526922925887};\\\", \\\"{x:1493,y:972,t:1526922925904};\\\", \\\"{x:1488,y:970,t:1526922925921};\\\", \\\"{x:1478,y:965,t:1526922925938};\\\", \\\"{x:1475,y:964,t:1526922925954};\\\", \\\"{x:1473,y:962,t:1526922925971};\\\", \\\"{x:1472,y:961,t:1526922925988};\\\", \\\"{x:1472,y:960,t:1526922926004};\\\", \\\"{x:1472,y:959,t:1526922926043};\\\", \\\"{x:1474,y:959,t:1526922926066};\\\", \\\"{x:1476,y:959,t:1526922926075};\\\", \\\"{x:1477,y:959,t:1526922926088};\\\", \\\"{x:1481,y:959,t:1526922926104};\\\", \\\"{x:1484,y:959,t:1526922926121};\\\", \\\"{x:1486,y:960,t:1526922926138};\\\", \\\"{x:1487,y:960,t:1526922926155};\\\", \\\"{x:1487,y:959,t:1526922926346};\\\", \\\"{x:1486,y:959,t:1526922926355};\\\", \\\"{x:1474,y:946,t:1526922957718};\\\", \\\"{x:1430,y:898,t:1526922957732};\\\", \\\"{x:1304,y:789,t:1526922957749};\\\", \\\"{x:1120,y:656,t:1526922957766};\\\", \\\"{x:1075,y:623,t:1526922957781};\\\", \\\"{x:973,y:553,t:1526922957798};\\\", \\\"{x:891,y:525,t:1526922957817};\\\", \\\"{x:829,y:513,t:1526922957832};\\\", \\\"{x:793,y:508,t:1526922957847};\\\", \\\"{x:776,y:506,t:1526922957866};\\\", \\\"{x:771,y:505,t:1526922957884};\\\", \\\"{x:771,y:504,t:1526922957900};\\\", \\\"{x:779,y:504,t:1526922957917};\\\", \\\"{x:790,y:501,t:1526922957933};\\\", \\\"{x:795,y:500,t:1526922957952};\\\", \\\"{x:797,y:500,t:1526922957966};\\\", \\\"{x:798,y:502,t:1526922957984};\\\", \\\"{x:798,y:505,t:1526922958000};\\\", \\\"{x:798,y:506,t:1526922958021};\\\", \\\"{x:797,y:507,t:1526922958034};\\\", \\\"{x:793,y:507,t:1526922958050};\\\", \\\"{x:778,y:510,t:1526922958067};\\\", \\\"{x:747,y:515,t:1526922958083};\\\", \\\"{x:714,y:519,t:1526922958102};\\\", \\\"{x:673,y:524,t:1526922958117};\\\", \\\"{x:657,y:528,t:1526922958134};\\\", \\\"{x:652,y:528,t:1526922958151};\\\", \\\"{x:650,y:528,t:1526922958173};\\\", \\\"{x:649,y:528,t:1526922958197};\\\", \\\"{x:647,y:528,t:1526922958230};\\\", \\\"{x:646,y:528,t:1526922958237};\\\", \\\"{x:644,y:528,t:1526922958253};\\\", \\\"{x:643,y:528,t:1526922958270};\\\", \\\"{x:642,y:528,t:1526922958284};\\\", \\\"{x:640,y:527,t:1526922958301};\\\", \\\"{x:631,y:523,t:1526922958318};\\\", \\\"{x:626,y:521,t:1526922958333};\\\", \\\"{x:620,y:518,t:1526922958351};\\\", \\\"{x:619,y:518,t:1526922958367};\\\", \\\"{x:617,y:518,t:1526922958384};\\\", \\\"{x:617,y:517,t:1526922958437};\\\", \\\"{x:616,y:517,t:1526922958477};\\\", \\\"{x:614,y:516,t:1526922958485};\\\", \\\"{x:613,y:516,t:1526922958501};\\\", \\\"{x:611,y:515,t:1526922958517};\\\", \\\"{x:607,y:513,t:1526922958534};\\\", \\\"{x:605,y:513,t:1526922958551};\\\", \\\"{x:604,y:512,t:1526922958567};\\\", \\\"{x:603,y:512,t:1526922959903};\\\", \\\"{x:600,y:518,t:1526922959919};\\\", \\\"{x:595,y:529,t:1526922959936};\\\", \\\"{x:592,y:538,t:1526922959952};\\\", \\\"{x:586,y:549,t:1526922959969};\\\", \\\"{x:582,y:557,t:1526922959984};\\\", \\\"{x:578,y:564,t:1526922960001};\\\", \\\"{x:572,y:578,t:1526922960019};\\\", \\\"{x:567,y:590,t:1526922960034};\\\", \\\"{x:564,y:599,t:1526922960051};\\\", \\\"{x:560,y:611,t:1526922960069};\\\", \\\"{x:557,y:620,t:1526922960085};\\\", \\\"{x:555,y:629,t:1526922960102};\\\", \\\"{x:553,y:642,t:1526922960119};\\\", \\\"{x:552,y:651,t:1526922960135};\\\", \\\"{x:552,y:657,t:1526922960151};\\\", \\\"{x:549,y:666,t:1526922960169};\\\", \\\"{x:547,y:673,t:1526922960185};\\\", \\\"{x:547,y:677,t:1526922960201};\\\", \\\"{x:547,y:679,t:1526922960219};\\\", \\\"{x:547,y:680,t:1526922960235};\\\", \\\"{x:545,y:683,t:1526922960251};\\\", \\\"{x:545,y:685,t:1526922960269};\\\", \\\"{x:544,y:686,t:1526922960286};\\\", \\\"{x:544,y:687,t:1526922960301};\\\", \\\"{x:543,y:689,t:1526922960319};\\\", \\\"{x:543,y:690,t:1526922960335};\\\", \\\"{x:543,y:693,t:1526922960351};\\\", \\\"{x:542,y:695,t:1526922960369};\\\", \\\"{x:542,y:696,t:1526922960386};\\\", \\\"{x:541,y:698,t:1526922960402};\\\", \\\"{x:541,y:699,t:1526922960421};\\\", \\\"{x:541,y:700,t:1526922960453};\\\", \\\"{x:540,y:702,t:1526922960469};\\\", \\\"{x:540,y:703,t:1526922960485};\\\", \\\"{x:539,y:705,t:1526922960501};\\\", \\\"{x:538,y:707,t:1526922960518};\\\", \\\"{x:538,y:708,t:1526922960536};\\\", \\\"{x:538,y:711,t:1526922960552};\\\", \\\"{x:537,y:712,t:1526922960570};\\\", \\\"{x:536,y:715,t:1526922960586};\\\", \\\"{x:535,y:717,t:1526922960602};\\\", \\\"{x:535,y:718,t:1526922960619};\\\", \\\"{x:535,y:720,t:1526922960638};\\\", \\\"{x:535,y:721,t:1526922960652};\\\", \\\"{x:534,y:723,t:1526922960669};\\\", \\\"{x:534,y:725,t:1526922960686};\\\", \\\"{x:533,y:727,t:1526922960703};\\\", \\\"{x:532,y:729,t:1526922960719};\\\", \\\"{x:532,y:731,t:1526922960736};\\\", \\\"{x:531,y:733,t:1526922960753};\\\", \\\"{x:531,y:735,t:1526922960770};\\\", \\\"{x:529,y:737,t:1526922960786};\\\", \\\"{x:529,y:739,t:1526922960803};\\\", \\\"{x:529,y:741,t:1526922960818};\\\", \\\"{x:528,y:743,t:1526922960836};\\\", \\\"{x:528,y:744,t:1526922960853};\\\", \\\"{x:528,y:745,t:1526922960869};\\\", \\\"{x:528,y:746,t:1526922960901};\\\", \\\"{x:528,y:747,t:1526922960925};\\\", \\\"{x:527,y:749,t:1526922960936};\\\", \\\"{x:527,y:750,t:1526922961494};\\\", \\\"{x:527,y:751,t:1526922961502};\\\", \\\"{x:526,y:751,t:1526922962430};\\\", \\\"{x:526,y:752,t:1526922962437};\\\", \\\"{x:526,y:753,t:1526922962494};\\\", \\\"{x:520,y:740,t:1526922972742};\\\", \\\"{x:503,y:705,t:1526922972750};\\\", \\\"{x:485,y:670,t:1526922972764};\\\", \\\"{x:460,y:629,t:1526922972781};\\\", \\\"{x:440,y:603,t:1526922972796};\\\", \\\"{x:427,y:584,t:1526922972812};\\\", \\\"{x:415,y:570,t:1526922972828};\\\", \\\"{x:408,y:558,t:1526922972846};\\\", \\\"{x:404,y:552,t:1526922972862};\\\", \\\"{x:401,y:548,t:1526922972879};\\\", \\\"{x:398,y:540,t:1526922972895};\\\", \\\"{x:392,y:530,t:1526922972912};\\\", \\\"{x:382,y:518,t:1526922972929};\\\", \\\"{x:376,y:511,t:1526922972945};\\\", \\\"{x:375,y:510,t:1526922972963};\\\", \\\"{x:381,y:510,t:1526922973022};\\\", \\\"{x:390,y:510,t:1526922973029};\\\", \\\"{x:423,y:515,t:1526922973045};\\\", \\\"{x:469,y:516,t:1526922973062};\\\", \\\"{x:527,y:516,t:1526922973080};\\\", \\\"{x:586,y:516,t:1526922973095};\\\", \\\"{x:636,y:516,t:1526922973113};\\\", \\\"{x:653,y:516,t:1526922973130};\\\", \\\"{x:656,y:515,t:1526922973145};\\\", \\\"{x:657,y:515,t:1526922973173};\\\", \\\"{x:659,y:514,t:1526922973189};\\\", \\\"{x:662,y:513,t:1526922973197};\\\", \\\"{x:664,y:513,t:1526922973213};\\\", \\\"{x:676,y:510,t:1526922973229};\\\", \\\"{x:689,y:509,t:1526922973245};\\\", \\\"{x:707,y:508,t:1526922973263};\\\", \\\"{x:730,y:508,t:1526922973281};\\\", \\\"{x:754,y:508,t:1526922973296};\\\", \\\"{x:772,y:508,t:1526922973312};\\\", \\\"{x:785,y:511,t:1526922973329};\\\", \\\"{x:787,y:512,t:1526922973346};\\\", \\\"{x:789,y:512,t:1526922973362};\\\", \\\"{x:790,y:512,t:1526922973445};\\\", \\\"{x:791,y:512,t:1526922973461};\\\", \\\"{x:793,y:512,t:1526922973468};\\\", \\\"{x:794,y:512,t:1526922973479};\\\", \\\"{x:797,y:512,t:1526922973496};\\\", \\\"{x:800,y:512,t:1526922973512};\\\", \\\"{x:806,y:512,t:1526922973529};\\\", \\\"{x:810,y:510,t:1526922973547};\\\", \\\"{x:816,y:510,t:1526922973563};\\\", \\\"{x:821,y:510,t:1526922973580};\\\", \\\"{x:827,y:510,t:1526922973598};\\\", \\\"{x:829,y:510,t:1526922973612};\\\", \\\"{x:830,y:510,t:1526922973629};\\\", \\\"{x:831,y:510,t:1526922973646};\\\", \\\"{x:832,y:511,t:1526922973693};\\\", \\\"{x:832,y:512,t:1526922973885};\\\", \\\"{x:823,y:513,t:1526922973896};\\\", \\\"{x:793,y:528,t:1526922973913};\\\", \\\"{x:741,y:560,t:1526922973930};\\\", \\\"{x:692,y:588,t:1526922973946};\\\", \\\"{x:664,y:607,t:1526922973963};\\\", \\\"{x:625,y:633,t:1526922973980};\\\", \\\"{x:555,y:689,t:1526922973997};\\\", \\\"{x:532,y:707,t:1526922974013};\\\", \\\"{x:519,y:718,t:1526922974029};\\\", \\\"{x:510,y:731,t:1526922974047};\\\", \\\"{x:507,y:735,t:1526922974064};\\\", \\\"{x:505,y:738,t:1526922974079};\\\", \\\"{x:505,y:740,t:1526922974097};\\\", \\\"{x:505,y:742,t:1526922974113};\\\", \\\"{x:505,y:746,t:1526922974130};\\\", \\\"{x:505,y:753,t:1526922974147};\\\", \\\"{x:505,y:762,t:1526922974163};\\\", \\\"{x:505,y:775,t:1526922974181};\\\", \\\"{x:505,y:783,t:1526922974198};\\\", \\\"{x:505,y:780,t:1526922974294};\\\", \\\"{x:507,y:777,t:1526922974301};\\\", \\\"{x:507,y:774,t:1526922974314};\\\", \\\"{x:508,y:767,t:1526922974332};\\\", \\\"{x:509,y:765,t:1526922974346};\\\", \\\"{x:509,y:764,t:1526922974364};\\\", \\\"{x:510,y:763,t:1526922974380};\\\", \\\"{x:510,y:762,t:1526922974397};\\\", \\\"{x:511,y:761,t:1526922974413};\\\", \\\"{x:512,y:758,t:1526922974431};\\\", \\\"{x:512,y:756,t:1526922974446};\\\" ] }, { \\\"rt\\\": 145011, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 731703, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"DKL3R\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"First find 12pm on the x-axis and then go up from the 12pm point and find any dots that represent events. \\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 6303, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"19\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"China\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 739013, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"DKL3R\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 13975, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Mandarin or Cantonese\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"First\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 753998, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"DKL3R\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\" }, { \\\"rt\\\": 24590, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 779961, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"DKL3R\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"bravo\\\", \\\"condition\\\": \\\"121\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"DKL3R\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 363, dom: 1624, initialDom: 2250",
  "javascriptErrors": []
}