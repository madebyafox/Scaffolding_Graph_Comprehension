var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "6586af53fde4e428ebd45170db1c6029",
  "created": "2018-06-04T12:19:09.9672363-07:00",
  "lastActivity": "2018-06-04T12:19:32.7902363-07:00",
  "pageViews": [
    {
      "id": "06041098649b9a816905d5714ec5ba87ed528a3c",
      "startTime": "2018-06-04T12:19:09.9672363-07:00",
      "endTime": "2018-06-04T12:19:32.7902363-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/13",
      "visitTime": 22823,
      "engagementTime": 22823,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 22823,
  "engagementTime": 22823,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.41",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=02TJQ",
    "CONDITION=311",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "61e59e87f9d9d20c6260e5a19d6ea54c",
  "gdpr": false
}