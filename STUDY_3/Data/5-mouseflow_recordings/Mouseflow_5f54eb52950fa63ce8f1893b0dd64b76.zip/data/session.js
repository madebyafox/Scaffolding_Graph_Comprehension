var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "5f54eb52950fa63ce8f1893b0dd64b76",
  "created": "2018-05-22T10:22:56.9311857-07:00",
  "lastActivity": "2018-05-22T10:23:08.0231857-07:00",
  "pageViews": [
    {
      "id": "052256929bb315598ea87001fe912742aceb6c16",
      "startTime": "2018-05-22T10:22:56.9311857-07:00",
      "endTime": "2018-05-22T10:23:08.0231857-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/11",
      "visitTime": 11092,
      "engagementTime": 12075,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 11092,
  "engagementTime": 12075,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.32",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=MOWH2",
    "CONDITION=121",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "e39889631e4b8aded2a71f2b5e73a65a",
  "gdpr": false
}