var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "438cdb0a100e81c29a90be492b0c8cad",
  "created": "2018-05-19T13:00:02.8698354-07:00",
  "lastActivity": "2018-05-19T13:01:03.5190022-07:00",
  "pageViews": [
    {
      "id": "051905503e555d48cd7e59996ab1d4741cad6bcc",
      "startTime": "2018-05-19T13:00:05.4690022-07:00",
      "endTime": "2018-05-19T13:01:03.5190022-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/7",
      "visitTime": 58050,
      "engagementTime": 44886,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 58050,
  "engagementTime": 44886,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.22",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0",
  "browser": "Firefox",
  "browserVersion": "59.0",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=93YLJ",
    "CONDITION=113",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": true,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "09bbac8419f60e0cee37d475fc7c9934",
  "gdpr": false
}