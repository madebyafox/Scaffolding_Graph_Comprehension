var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "89d9e2d0d0f82af797dae272e8149282",
  "created": "2018-05-24T12:11:02.8303453-07:00",
  "lastActivity": "2018-05-24T12:14:23.3793453-07:00",
  "pageViews": [
    {
      "id": "05240390c1759ed8b286450d310afd500b398865",
      "startTime": "2018-05-24T12:11:02.8303453-07:00",
      "endTime": "2018-05-24T12:14:23.3793453-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 200549,
      "engagementTime": 120030,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 200549,
  "engagementTime": 120030,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.36",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=ZUJQV",
    "CONDITION=113"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "32f37339f9f1ce9b5c2d5fb5a9897e8e",
  "gdpr": false
}