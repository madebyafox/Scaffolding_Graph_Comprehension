var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "30722c6289b6a821e9dc28c09f33d8ab",
  "created": "2018-05-15T10:20:28.4250021-07:00",
  "lastActivity": "2018-05-15T10:22:09.1800021-07:00",
  "pageViews": [
    {
      "id": "0515282758f1c2b3c3738484c728fc5bb0e029e5",
      "startTime": "2018-05-15T10:20:28.4250021-07:00",
      "endTime": "2018-05-15T10:22:09.1800021-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/15",
      "visitTime": 100755,
      "engagementTime": 93818,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 100755,
  "engagementTime": 93818,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.170 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.170",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=ZJPX1",
    "CONDITION=121",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "3a65e19953f2730525a2a59c98087fa6",
  "gdpr": false
}