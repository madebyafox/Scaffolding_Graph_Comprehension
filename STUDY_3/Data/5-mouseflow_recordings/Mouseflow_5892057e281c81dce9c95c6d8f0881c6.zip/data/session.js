var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "5892057e281c81dce9c95c6d8f0881c6",
  "created": "2018-06-04T12:06:05.6432336-07:00",
  "lastActivity": "2018-06-04T12:12:53.7492981-07:00",
  "pageViews": [
    {
      "id": "060405859b356607db9ecd1eb88abf888061e671",
      "startTime": "2018-06-04T12:06:05.9151449-07:00",
      "endTime": "2018-06-04T12:12:53.7492981-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 408296,
      "engagementTime": 41095,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 408296,
  "engagementTime": 41095,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.34",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "67.0.3396.62",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "ef8fc5f5f5541651cca89dcc5011c600",
  "gdpr": false
}