var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["060405859b356607db9ecd1eb88abf888061e671"] = {
  "startTime": "2018-06-04T19:06:05.9151449Z",
  "websitePageUrl": "/",
  "visitTime": 408296,
  "engagementTime": 41095,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1094,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "5892057e281c81dce9c95c6d8f0881c6",
    "created": "2018-06-04T19:06:05.6432336+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "67.0.3396.62",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "ef8fc5f5f5541651cca89dcc5011c600",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/5892057e281c81dce9c95c6d8f0881c6/play"
  },
  "events": [
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 388,
      "e": 388,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 10006,
      "e": 5101,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 347185,
      "e": 5101,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 347192,
      "e": 5108,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 347192,
      "e": 5108,
      "ty": 2,
      "x": 611,
      "y": 47
    },
    {
      "t": 347243,
      "e": 5159,
      "ty": 41,
      "x": 7505,
      "y": 21605,
      "ta": "> div.masterdiv > div"
    },
    {
      "t": 354692,
      "e": 10159,
      "ty": 2,
      "x": 579,
      "y": 561
    },
    {
      "t": 354743,
      "e": 10210,
      "ty": 41,
      "x": 16950,
      "y": 3752,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 354792,
      "e": 10259,
      "ty": 2,
      "x": 670,
      "y": 729
    },
    {
      "t": 354892,
      "e": 10359,
      "ty": 2,
      "x": 779,
      "y": 951
    },
    {
      "t": 354992,
      "e": 10459,
      "ty": 2,
      "x": 810,
      "y": 1027
    },
    {
      "t": 354993,
      "e": 10460,
      "ty": 41,
      "x": 25412,
      "y": 62371,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 355092,
      "e": 10559,
      "ty": 2,
      "x": 809,
      "y": 1000
    },
    {
      "t": 355192,
      "e": 10659,
      "ty": 2,
      "x": 794,
      "y": 977
    },
    {
      "t": 355242,
      "e": 10709,
      "ty": 41,
      "x": 23739,
      "y": 58354,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 355292,
      "e": 10759,
      "ty": 2,
      "x": 773,
      "y": 967
    },
    {
      "t": 355392,
      "e": 10859,
      "ty": 2,
      "x": 786,
      "y": 931
    },
    {
      "t": 355492,
      "e": 10959,
      "ty": 2,
      "x": 793,
      "y": 924
    },
    {
      "t": 355493,
      "e": 10960,
      "ty": 41,
      "x": 24576,
      "y": 42972,
      "ta": "> div.masterdiv > div:[2] > div > div"
    },
    {
      "t": 355692,
      "e": 11159,
      "ty": 2,
      "x": 797,
      "y": 923
    },
    {
      "t": 355743,
      "e": 11210,
      "ty": 41,
      "x": 24772,
      "y": 40712,
      "ta": "> div.masterdiv > div:[2] > div > div"
    },
    {
      "t": 355992,
      "e": 11459,
      "ty": 2,
      "x": 800,
      "y": 923
    },
    {
      "t": 355993,
      "e": 11460,
      "ty": 41,
      "x": 24920,
      "y": 40712,
      "ta": "> div.masterdiv > div:[2] > div > div"
    },
    {
      "t": 356092,
      "e": 11559,
      "ty": 2,
      "x": 803,
      "y": 923
    },
    {
      "t": 356192,
      "e": 11659,
      "ty": 2,
      "x": 806,
      "y": 922
    },
    {
      "t": 356242,
      "e": 11709,
      "ty": 41,
      "x": 8396,
      "y": 36095,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 356304,
      "e": 11771,
      "ty": 3,
      "x": 806,
      "y": 922,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 356425,
      "e": 11892,
      "ty": 4,
      "x": 8396,
      "y": 36095,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 356425,
      "e": 11892,
      "ty": 5,
      "x": 806,
      "y": 922,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 356428,
      "e": 11895,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 356430,
      "e": 11897,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 356592,
      "e": 12059,
      "ty": 2,
      "x": 819,
      "y": 943
    },
    {
      "t": 356692,
      "e": 12159,
      "ty": 2,
      "x": 945,
      "y": 1073
    },
    {
      "t": 356742,
      "e": 12209,
      "ty": 41,
      "x": 31948,
      "y": 37224,
      "ta": "#start"
    },
    {
      "t": 356792,
      "e": 12259,
      "ty": 2,
      "x": 968,
      "y": 1092
    },
    {
      "t": 356984,
      "e": 12451,
      "ty": 3,
      "x": 968,
      "y": 1092,
      "ta": "#start"
    },
    {
      "t": 356985,
      "e": 12452,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 356987,
      "e": 12454,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 357070,
      "e": 12537,
      "ty": 4,
      "x": 31948,
      "y": 37224,
      "ta": "#start"
    },
    {
      "t": 357072,
      "e": 12539,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 357073,
      "e": 12540,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 357073,
      "e": 12540,
      "ty": 5,
      "x": 968,
      "y": 1092,
      "ta": "#start"
    },
    {
      "t": 357393,
      "e": 12860,
      "ty": 2,
      "x": 968,
      "y": 1080
    },
    {
      "t": 357492,
      "e": 12959,
      "ty": 2,
      "x": 933,
      "y": 954
    },
    {
      "t": 357493,
      "e": 12960,
      "ty": 41,
      "x": 31854,
      "y": 52405,
      "ta": "html > body"
    },
    {
      "t": 357593,
      "e": 13060,
      "ty": 2,
      "x": 794,
      "y": 667
    },
    {
      "t": 357692,
      "e": 13159,
      "ty": 2,
      "x": 729,
      "y": 530
    },
    {
      "t": 357743,
      "e": 13210,
      "ty": 41,
      "x": 24829,
      "y": 28917,
      "ta": "html > body"
    },
    {
      "t": 358079,
      "e": 13546,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 358892,
      "e": 14359,
      "ty": 2,
      "x": 729,
      "y": 529
    },
    {
      "t": 358951,
      "e": 14418,
      "ty": 6,
      "x": 875,
      "y": 594,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 358992,
      "e": 14459,
      "ty": 2,
      "x": 894,
      "y": 602
    },
    {
      "t": 358993,
      "e": 14460,
      "ty": 41,
      "x": 18600,
      "y": 49931,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 359092,
      "e": 14559,
      "ty": 2,
      "x": 896,
      "y": 603
    },
    {
      "t": 359243,
      "e": 14710,
      "ty": 41,
      "x": 19033,
      "y": 53052,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 359360,
      "e": 14827,
      "ty": 3,
      "x": 896,
      "y": 603,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 359362,
      "e": 14829,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 359462,
      "e": 14929,
      "ty": 4,
      "x": 19033,
      "y": 53052,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 359463,
      "e": 14930,
      "ty": 5,
      "x": 896,
      "y": 603,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 359993,
      "e": 15460,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 362410,
      "e": 17877,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 362553,
      "e": 18020,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": ""
    },
    {
      "t": 362746,
      "e": 18213,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "89"
    },
    {
      "t": 362746,
      "e": 18213,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 362824,
      "e": 18291,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "Y"
    },
    {
      "t": 363089,
      "e": 18556,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "65"
    },
    {
      "t": 363089,
      "e": 18556,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 363185,
      "e": 18652,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "YA"
    },
    {
      "t": 363753,
      "e": 19220,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "78"
    },
    {
      "t": 363753,
      "e": 19220,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 363856,
      "e": 19323,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "YAN"
    },
    {
      "t": 364105,
      "e": 19572,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "75"
    },
    {
      "t": 364105,
      "e": 19572,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 364209,
      "e": 19676,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "YANK"
    },
    {
      "t": 365073,
      "e": 20540,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 365074,
      "e": 20541,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 365192,
      "e": 20659,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||E"
    },
    {
      "t": 365464,
      "e": 20931,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "69"
    },
    {
      "t": 365465,
      "e": 20932,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 365560,
      "e": 21027,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||E"
    },
    {
      "t": 369991,
      "e": 25458,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 370189,
      "e": 25656,
      "ty": 2,
      "x": 897,
      "y": 603
    },
    {
      "t": 370240,
      "e": 25707,
      "ty": 41,
      "x": 19249,
      "y": 62414,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 370244,
      "e": 25711,
      "ty": 7,
      "x": 897,
      "y": 609,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 370289,
      "e": 25756,
      "ty": 2,
      "x": 896,
      "y": 612
    },
    {
      "t": 370389,
      "e": 25856,
      "ty": 2,
      "x": 884,
      "y": 645
    },
    {
      "t": 370489,
      "e": 25956,
      "ty": 2,
      "x": 880,
      "y": 649
    },
    {
      "t": 370489,
      "e": 25956,
      "ty": 41,
      "x": 15572,
      "y": 37448,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 370590,
      "e": 26057,
      "ty": 2,
      "x": 877,
      "y": 652
    },
    {
      "t": 370690,
      "e": 26157,
      "ty": 2,
      "x": 871,
      "y": 667
    },
    {
      "t": 370692,
      "e": 26159,
      "ty": 6,
      "x": 866,
      "y": 683,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 370739,
      "e": 26206,
      "ty": 41,
      "x": 11030,
      "y": 46810,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 370789,
      "e": 26256,
      "ty": 2,
      "x": 857,
      "y": 699
    },
    {
      "t": 370981,
      "e": 26448,
      "ty": 3,
      "x": 857,
      "y": 699,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 370983,
      "e": 26450,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "YANKEE"
    },
    {
      "t": 370984,
      "e": 26451,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 370984,
      "e": 26451,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 370989,
      "e": 26456,
      "ty": 41,
      "x": 10598,
      "y": 62414,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 371084,
      "e": 26551,
      "ty": 4,
      "x": 10598,
      "y": 62414,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 371084,
      "e": 26551,
      "ty": 5,
      "x": 857,
      "y": 699,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 371888,
      "e": 27355,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "51"
    },
    {
      "t": 371889,
      "e": 27356,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 371995,
      "e": 27462,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "3"
    },
    {
      "t": 372000,
      "e": 27467,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "3"
    },
    {
      "t": 372321,
      "e": 27788,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 372321,
      "e": 27788,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 372440,
      "e": 27907,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "31"
    },
    {
      "t": 372713,
      "e": 28180,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 372713,
      "e": 28180,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 372809,
      "e": 28276,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "31*"
    },
    {
      "t": 373060,
      "e": 28527,
      "ty": 7,
      "x": 869,
      "y": 700,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 373090,
      "e": 28557,
      "ty": 2,
      "x": 899,
      "y": 706
    },
    {
      "t": 373093,
      "e": 28560,
      "ty": 6,
      "x": 924,
      "y": 712,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 373190,
      "e": 28657,
      "ty": 2,
      "x": 975,
      "y": 734
    },
    {
      "t": 373240,
      "e": 28707,
      "ty": 41,
      "x": 40756,
      "y": 51633,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 373374,
      "e": 28841,
      "ty": 3,
      "x": 975,
      "y": 734,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 373374,
      "e": 28841,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "31*"
    },
    {
      "t": 373375,
      "e": 28842,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 373376,
      "e": 28843,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 373469,
      "e": 28936,
      "ty": 4,
      "x": 40756,
      "y": 51633,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 373472,
      "e": 28939,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 373474,
      "e": 28941,
      "ty": 5,
      "x": 975,
      "y": 734,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 373476,
      "e": 28943,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 374580,
      "e": 30047,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 374607,
      "e": 30074,
      "ty": 6,
      "x": 975,
      "y": 734,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 379989,
      "e": 35074,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 392090,
      "e": 35074,
      "ty": 2,
      "x": 967,
      "y": 734
    },
    {
      "t": 392190,
      "e": 35174,
      "ty": 2,
      "x": 953,
      "y": 733
    },
    {
      "t": 392240,
      "e": 35224,
      "ty": 41,
      "x": 31461,
      "y": 14079,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 392324,
      "e": 35308,
      "ty": 7,
      "x": 938,
      "y": 771,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 392325,
      "e": 35309,
      "ty": 6,
      "x": 938,
      "y": 771,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 392337,
      "e": 35321,
      "ty": 7,
      "x": 929,
      "y": 791,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 392390,
      "e": 35374,
      "ty": 2,
      "x": 885,
      "y": 886
    },
    {
      "t": 392490,
      "e": 35474,
      "ty": 2,
      "x": 871,
      "y": 931
    },
    {
      "t": 392491,
      "e": 35475,
      "ty": 41,
      "x": 28413,
      "y": 55723,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 392590,
      "e": 35574,
      "ty": 2,
      "x": 911,
      "y": 1022
    },
    {
      "t": 392690,
      "e": 35674,
      "ty": 2,
      "x": 925,
      "y": 1065
    },
    {
      "t": 392740,
      "e": 35724,
      "ty": 41,
      "x": 31168,
      "y": 65210,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 392754,
      "e": 35738,
      "ty": 6,
      "x": 930,
      "y": 1073,
      "ta": "#start"
    },
    {
      "t": 392790,
      "e": 35774,
      "ty": 2,
      "x": 939,
      "y": 1086
    },
    {
      "t": 392890,
      "e": 35874,
      "ty": 2,
      "x": 948,
      "y": 1090
    },
    {
      "t": 392990,
      "e": 35974,
      "ty": 2,
      "x": 949,
      "y": 1090
    },
    {
      "t": 392990,
      "e": 35974,
      "ty": 41,
      "x": 21571,
      "y": 33369,
      "ta": "#start"
    },
    {
      "t": 393037,
      "e": 36021,
      "ty": 3,
      "x": 949,
      "y": 1090,
      "ta": "#start"
    },
    {
      "t": 393039,
      "e": 36023,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 393108,
      "e": 36092,
      "ty": 4,
      "x": 21571,
      "y": 33369,
      "ta": "#start"
    },
    {
      "t": 393109,
      "e": 36093,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 393111,
      "e": 36095,
      "ty": 5,
      "x": 949,
      "y": 1090,
      "ta": "#start"
    },
    {
      "t": 393116,
      "e": 36100,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 394114,
      "e": 37098,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 399990,
      "e": 41095,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 407290,
      "e": 41095,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 408296,
      "e": 41095,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 359, dom: 870, initialDom: 874",
  "javascriptErrors": []
}