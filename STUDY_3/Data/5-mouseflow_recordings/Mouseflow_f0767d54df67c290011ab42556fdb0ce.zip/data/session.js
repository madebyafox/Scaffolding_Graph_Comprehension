var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "f0767d54df67c290011ab42556fdb0ce",
  "created": "2018-05-15T14:10:54.1571498-07:00",
  "lastActivity": "2018-05-15T14:11:15.2195769-07:00",
  "pageViews": [
    {
      "id": "05155419a06828821ab922eb4f531dfa959d3835",
      "startTime": "2018-05-15T14:10:54.2595769-07:00",
      "endTime": "2018-05-15T14:11:15.2195769-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/12",
      "visitTime": 20960,
      "engagementTime": 20426,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 20960,
  "engagementTime": 20426,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.24",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=OVZHS",
    "CONDITION=111",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "4f6995918fdf1e1635dea4a4f6bf2a1f",
  "gdpr": false
}