var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "9ce2e2ca10c730973249b48aae12ff53",
  "created": "2018-05-21T09:08:27.9126241-07:00",
  "lastActivity": "2018-05-21T09:08:56.3626241-07:00",
  "pageViews": [
    {
      "id": "05212816e8fb02a3b3b3632ce87b8f4a81a05e04",
      "startTime": "2018-05-21T09:08:27.9126241-07:00",
      "endTime": "2018-05-21T09:08:56.3626241-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/2",
      "visitTime": 28450,
      "engagementTime": 24489,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 28450,
  "engagementTime": 24489,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.47",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=UQWX4",
    "CONDITION=111",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "4ee3c2949e0703ea93ef37adb84422ba",
  "gdpr": false
}