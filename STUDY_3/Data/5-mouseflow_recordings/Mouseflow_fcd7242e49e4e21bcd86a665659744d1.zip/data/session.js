var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "fcd7242e49e4e21bcd86a665659744d1",
  "created": "2018-05-24T12:08:24.8287158-07:00",
  "lastActivity": "2018-05-24T12:09:01.5977158-07:00",
  "pageViews": [
    {
      "id": "0524252301b26bae2da1d9a9d96bfbaae5bf171b",
      "startTime": "2018-05-24T12:08:24.8287158-07:00",
      "endTime": "2018-05-24T12:09:01.5977158-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/5",
      "visitTime": 36769,
      "engagementTime": 19120,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 36769,
  "engagementTime": 19120,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.25",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=M3NXB",
    "CONDITION=113"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "76ae83f37459251e68cfd52e0fb27ce7",
  "gdpr": false
}