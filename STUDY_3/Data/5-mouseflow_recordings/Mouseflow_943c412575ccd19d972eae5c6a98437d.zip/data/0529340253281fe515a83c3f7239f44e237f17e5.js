var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["0529340253281fe515a83c3f7239f44e237f17e5"] = {
  "startTime": "2018-05-29T23:12:34.481541Z",
  "websitePageUrl": "/16",
  "visitTime": 161095,
  "engagementTime": 110788,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "943c412575ccd19d972eae5c6a98437d",
    "created": "2018-05-29T23:12:34.481541+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=93XU7",
      "CONDITION=113"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "b4f8351982850e3d9ea37e1e96fa1052",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/943c412575ccd19d972eae5c6a98437d/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 261,
      "e": 261,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 1400,
      "e": 1400,
      "ty": 2,
      "x": 631,
      "y": 715
    },
    {
      "t": 1500,
      "e": 1500,
      "ty": 2,
      "x": 669,
      "y": 706
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 41,
      "x": 64287,
      "y": 38667,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1600,
      "e": 1600,
      "ty": 2,
      "x": 757,
      "y": 695
    },
    {
      "t": 1700,
      "e": 1700,
      "ty": 2,
      "x": 902,
      "y": 679
    },
    {
      "t": 1751,
      "e": 1751,
      "ty": 41,
      "x": 13812,
      "y": 38676,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 1800,
      "e": 1800,
      "ty": 2,
      "x": 1128,
      "y": 730
    },
    {
      "t": 2000,
      "e": 2000,
      "ty": 41,
      "x": 24101,
      "y": 42400,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 2500,
      "e": 2500,
      "ty": 2,
      "x": 1092,
      "y": 699
    },
    {
      "t": 2500,
      "e": 2500,
      "ty": 41,
      "x": 21564,
      "y": 40180,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 2600,
      "e": 2600,
      "ty": 2,
      "x": 945,
      "y": 627
    },
    {
      "t": 2700,
      "e": 2700,
      "ty": 2,
      "x": 814,
      "y": 580
    },
    {
      "t": 2750,
      "e": 2750,
      "ty": 41,
      "x": 705,
      "y": 31084,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 2800,
      "e": 2800,
      "ty": 2,
      "x": 780,
      "y": 565
    },
    {
      "t": 2893,
      "e": 2893,
      "ty": 6,
      "x": 668,
      "y": 563,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2900,
      "e": 2900,
      "ty": 2,
      "x": 668,
      "y": 563
    },
    {
      "t": 3000,
      "e": 3000,
      "ty": 2,
      "x": 461,
      "y": 563
    },
    {
      "t": 3000,
      "e": 3000,
      "ty": 41,
      "x": 40906,
      "y": 32577,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3100,
      "e": 3100,
      "ty": 2,
      "x": 432,
      "y": 563
    },
    {
      "t": 3250,
      "e": 3250,
      "ty": 41,
      "x": 37646,
      "y": 32577,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4645,
      "e": 4645,
      "ty": 7,
      "x": 502,
      "y": 604,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4700,
      "e": 4700,
      "ty": 2,
      "x": 813,
      "y": 696
    },
    {
      "t": 4750,
      "e": 4750,
      "ty": 41,
      "x": 33050,
      "y": 49061,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 4800,
      "e": 4800,
      "ty": 2,
      "x": 1468,
      "y": 885
    },
    {
      "t": 4900,
      "e": 4900,
      "ty": 2,
      "x": 1460,
      "y": 891
    },
    {
      "t": 5000,
      "e": 5000,
      "ty": 2,
      "x": 1378,
      "y": 923
    },
    {
      "t": 5001,
      "e": 5001,
      "ty": 41,
      "x": 41718,
      "y": 56224,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5101,
      "e": 5101,
      "ty": 2,
      "x": 1334,
      "y": 974
    },
    {
      "t": 5200,
      "e": 5200,
      "ty": 2,
      "x": 1335,
      "y": 987
    },
    {
      "t": 5251,
      "e": 5251,
      "ty": 41,
      "x": 38687,
      "y": 60807,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5401,
      "e": 5401,
      "ty": 2,
      "x": 1187,
      "y": 968
    },
    {
      "t": 5501,
      "e": 5501,
      "ty": 2,
      "x": 1050,
      "y": 949
    },
    {
      "t": 5501,
      "e": 5501,
      "ty": 41,
      "x": 18604,
      "y": 58086,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5600,
      "e": 5600,
      "ty": 2,
      "x": 1049,
      "y": 955
    },
    {
      "t": 5700,
      "e": 5700,
      "ty": 2,
      "x": 1082,
      "y": 985
    },
    {
      "t": 5751,
      "e": 5751,
      "ty": 41,
      "x": 23889,
      "y": 61738,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5800,
      "e": 5800,
      "ty": 2,
      "x": 1132,
      "y": 1001
    },
    {
      "t": 5901,
      "e": 5901,
      "ty": 2,
      "x": 1114,
      "y": 1001
    },
    {
      "t": 6000,
      "e": 6000,
      "ty": 2,
      "x": 914,
      "y": 972
    },
    {
      "t": 6001,
      "e": 6001,
      "ty": 41,
      "x": 9020,
      "y": 59733,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6100,
      "e": 6100,
      "ty": 2,
      "x": 894,
      "y": 969
    },
    {
      "t": 6251,
      "e": 6251,
      "ty": 41,
      "x": 51410,
      "y": 255,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g > text"
    },
    {
      "t": 6300,
      "e": 6300,
      "ty": 2,
      "x": 909,
      "y": 969
    },
    {
      "t": 6400,
      "e": 6400,
      "ty": 2,
      "x": 960,
      "y": 974
    },
    {
      "t": 6500,
      "e": 6500,
      "ty": 2,
      "x": 1035,
      "y": 974
    },
    {
      "t": 6501,
      "e": 6501,
      "ty": 41,
      "x": 57350,
      "y": 20735,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[5] > text"
    },
    {
      "t": 6600,
      "e": 6600,
      "ty": 2,
      "x": 1039,
      "y": 974
    },
    {
      "t": 6700,
      "e": 6700,
      "ty": 2,
      "x": 986,
      "y": 964
    },
    {
      "t": 6750,
      "e": 6750,
      "ty": 41,
      "x": 7087,
      "y": 0,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > path"
    },
    {
      "t": 6800,
      "e": 6800,
      "ty": 2,
      "x": 973,
      "y": 963
    },
    {
      "t": 7100,
      "e": 7100,
      "ty": 2,
      "x": 970,
      "y": 963
    },
    {
      "t": 7200,
      "e": 7200,
      "ty": 2,
      "x": 1038,
      "y": 963
    },
    {
      "t": 7251,
      "e": 7251,
      "ty": 41,
      "x": 24453,
      "y": 59876,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7301,
      "e": 7301,
      "ty": 2,
      "x": 1168,
      "y": 977
    },
    {
      "t": 7401,
      "e": 7401,
      "ty": 2,
      "x": 1171,
      "y": 978
    },
    {
      "t": 7500,
      "e": 7500,
      "ty": 2,
      "x": 1244,
      "y": 978
    },
    {
      "t": 7501,
      "e": 7501,
      "ty": 41,
      "x": 32275,
      "y": 60163,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7601,
      "e": 7601,
      "ty": 2,
      "x": 1313,
      "y": 979
    },
    {
      "t": 7701,
      "e": 7701,
      "ty": 2,
      "x": 1331,
      "y": 981
    },
    {
      "t": 7751,
      "e": 7751,
      "ty": 41,
      "x": 4969,
      "y": 49407,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[15] > text"
    },
    {
      "t": 7800,
      "e": 7800,
      "ty": 2,
      "x": 1337,
      "y": 981
    },
    {
      "t": 8001,
      "e": 8001,
      "ty": 41,
      "x": 6589,
      "y": 49407,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[15] > text"
    },
    {
      "t": 8101,
      "e": 8101,
      "ty": 2,
      "x": 1345,
      "y": 981
    },
    {
      "t": 8200,
      "e": 8200,
      "ty": 2,
      "x": 1347,
      "y": 981
    },
    {
      "t": 8250,
      "e": 8250,
      "ty": 41,
      "x": 22790,
      "y": 49407,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[15] > text"
    },
    {
      "t": 8400,
      "e": 8400,
      "ty": 2,
      "x": 1363,
      "y": 981
    },
    {
      "t": 8501,
      "e": 8501,
      "ty": 2,
      "x": 1373,
      "y": 982
    },
    {
      "t": 8501,
      "e": 8501,
      "ty": 41,
      "x": 64910,
      "y": 53503,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[15] > text"
    },
    {
      "t": 8600,
      "e": 8600,
      "ty": 2,
      "x": 1321,
      "y": 916
    },
    {
      "t": 8701,
      "e": 8701,
      "ty": 2,
      "x": 790,
      "y": 586
    },
    {
      "t": 8751,
      "e": 8751,
      "ty": 41,
      "x": 5734,
      "y": 31737,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 8846,
      "e": 8846,
      "ty": 2,
      "x": 764,
      "y": 636
    },
    {
      "t": 8901,
      "e": 8901,
      "ty": 2,
      "x": 764,
      "y": 642
    },
    {
      "t": 8997,
      "e": 8997,
      "ty": 6,
      "x": 668,
      "y": 560,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9000,
      "e": 9000,
      "ty": 2,
      "x": 668,
      "y": 560
    },
    {
      "t": 9001,
      "e": 9001,
      "ty": 41,
      "x": 64175,
      "y": 30150,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9100,
      "e": 9100,
      "ty": 2,
      "x": 555,
      "y": 533
    },
    {
      "t": 9250,
      "e": 9250,
      "ty": 41,
      "x": 51810,
      "y": 13969,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9301,
      "e": 9301,
      "ty": 2,
      "x": 576,
      "y": 552
    },
    {
      "t": 9339,
      "e": 9339,
      "ty": 3,
      "x": 578,
      "y": 553,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9341,
      "e": 9341,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9400,
      "e": 9400,
      "ty": 2,
      "x": 586,
      "y": 552
    },
    {
      "t": 9492,
      "e": 9492,
      "ty": 4,
      "x": 54957,
      "y": 23678,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9492,
      "e": 9492,
      "ty": 5,
      "x": 586,
      "y": 552,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9502,
      "e": 9502,
      "ty": 41,
      "x": 54957,
      "y": 23678,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10000,
      "e": 10000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10293,
      "e": 10293,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 10493,
      "e": 10493,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 10493,
      "e": 10493,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10549,
      "e": 10549,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "E"
    },
    {
      "t": 10621,
      "e": 10621,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "E"
    },
    {
      "t": 10693,
      "e": 10693,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 10694,
      "e": 10694,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10789,
      "e": 10789,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Ea"
    },
    {
      "t": 10902,
      "e": 10902,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 10902,
      "e": 10902,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10958,
      "e": 10958,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 10959,
      "e": 10959,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10997,
      "e": 10997,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Each"
    },
    {
      "t": 11085,
      "e": 11085,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 11093,
      "e": 11093,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11093,
      "e": 11093,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11181,
      "e": 11181,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 11293,
      "e": 11293,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 11293,
      "e": 11293,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11309,
      "e": 11309,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 11309,
      "e": 11309,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11357,
      "e": 11357,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||sd"
    },
    {
      "t": 11373,
      "e": 11373,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 11678,
      "e": 11678,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11781,
      "e": 11781,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Each s"
    },
    {
      "t": 12341,
      "e": 12341,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 12343,
      "e": 12343,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12454,
      "e": 12454,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 12517,
      "e": 12517,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 12518,
      "e": 12518,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12521,
      "e": 12521,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 12521,
      "e": 12521,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12589,
      "e": 12589,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 12589,
      "e": 12589,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12597,
      "e": 12597,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||iof"
    },
    {
      "t": 12605,
      "e": 12605,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12677,
      "e": 12677,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12982,
      "e": 12982,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13117,
      "e": 13117,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Each shio"
    },
    {
      "t": 13213,
      "e": 13213,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13294,
      "e": 13294,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Each shi"
    },
    {
      "t": 13404,
      "e": 13404,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Each shi"
    },
    {
      "t": 13686,
      "e": 13686,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 13686,
      "e": 13686,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13802,
      "e": 13802,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Each shif"
    },
    {
      "t": 13805,
      "e": 13805,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 13926,
      "e": 13926,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 13927,
      "e": 13927,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14020,
      "e": 14020,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 14045,
      "e": 14045,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14046,
      "e": 14046,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14173,
      "e": 14173,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 16134,
      "e": 16134,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 16135,
      "e": 16135,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16270,
      "e": 16270,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 16325,
      "e": 16325,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 16325,
      "e": 16325,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16412,
      "e": 16412,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 16429,
      "e": 16429,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 16429,
      "e": 16429,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16525,
      "e": 16525,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 16525,
      "e": 16525,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 16525,
      "e": 16525,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16597,
      "e": 16597,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 16702,
      "e": 16702,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 16702,
      "e": 16702,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16789,
      "e": 16789,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 16830,
      "e": 16830,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 16830,
      "e": 16830,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16917,
      "e": 16917,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 16997,
      "e": 16997,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16998,
      "e": 16998,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17102,
      "e": 17102,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 17151,
      "e": 17151,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 17151,
      "e": 17151,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17261,
      "e": 17261,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 17261,
      "e": 17261,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 17262,
      "e": 17262,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17397,
      "e": 17397,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17397,
      "e": 17397,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17405,
      "e": 17405,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 17501,
      "e": 17501,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18326,
      "e": 18326,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "56"
    },
    {
      "t": 18326,
      "e": 18326,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18397,
      "e": 18397,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||8"
    },
    {
      "t": 18501,
      "e": 18501,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 18502,
      "e": 18502,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18598,
      "e": 18598,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 18605,
      "e": 18605,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 18607,
      "e": 18607,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18709,
      "e": 18709,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 18797,
      "e": 18797,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18798,
      "e": 18798,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18892,
      "e": 18892,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18973,
      "e": 18973,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 18973,
      "e": 18973,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19085,
      "e": 19085,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 19085,
      "e": 19085,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19125,
      "e": 19125,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||to"
    },
    {
      "t": 19262,
      "e": 19262,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19382,
      "e": 19382,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19383,
      "e": 19383,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19477,
      "e": 19477,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 19541,
      "e": 19541,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "56"
    },
    {
      "t": 19542,
      "e": 19542,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19573,
      "e": 19573,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||8"
    },
    {
      "t": 20001,
      "e": 20001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20007,
      "e": 20007,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "219"
    },
    {
      "t": 20007,
      "e": 20007,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20077,
      "e": 20077,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||["
    },
    {
      "t": 20202,
      "e": 20202,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Each shift starts at 8am to 8["
    },
    {
      "t": 20550,
      "e": 20550,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 20701,
      "e": 20701,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Each shift starts at 8am to 8"
    },
    {
      "t": 21629,
      "e": 21629,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 21629,
      "e": 21629,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21756,
      "e": 21756,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 21757,
      "e": 21757,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21780,
      "e": 21780,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||pm"
    },
    {
      "t": 21877,
      "e": 21877,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26017,
      "e": 26017,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26017,
      "e": 26017,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26177,
      "e": 26177,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 26329,
      "e": 26329,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 26329,
      "e": 26329,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26464,
      "e": 26464,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 26769,
      "e": 26769,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 26770,
      "e": 26770,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26929,
      "e": 26929,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 27034,
      "e": 27034,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 27034,
      "e": 27034,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27185,
      "e": 27185,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 27200,
      "e": 27200,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27201,
      "e": 27201,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27321,
      "e": 27321,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27377,
      "e": 27377,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 27377,
      "e": 27377,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27505,
      "e": 27505,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 27506,
      "e": 27506,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27512,
      "e": 27512,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||we"
    },
    {
      "t": 27657,
      "e": 27657,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27697,
      "e": 27697,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27698,
      "e": 27698,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27777,
      "e": 27777,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27897,
      "e": 27897,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 27898,
      "e": 27898,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27977,
      "e": 27977,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 28105,
      "e": 28105,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 28106,
      "e": 28106,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28177,
      "e": 28177,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 28265,
      "e": 28265,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 28265,
      "e": 28265,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28345,
      "e": 28345,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 28345,
      "e": 28345,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28417,
      "e": 28417,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ok"
    },
    {
      "t": 28457,
      "e": 28457,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28458,
      "e": 28458,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28480,
      "e": 28480,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 28561,
      "e": 28561,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 28713,
      "e": 28713,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 28714,
      "e": 28714,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28824,
      "e": 28824,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 28841,
      "e": 28841,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 28842,
      "e": 28842,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28920,
      "e": 28920,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28920,
      "e": 28920,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28977,
      "e": 28977,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 29033,
      "e": 29033,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 29114,
      "e": 29114,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 29114,
      "e": 29114,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29265,
      "e": 29265,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 29313,
      "e": 29313,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 29314,
      "e": 29314,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29321,
      "e": 29321,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 29321,
      "e": 29321,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29352,
      "e": 29352,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||hg"
    },
    {
      "t": 29449,
      "e": 29449,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30005,
      "e": 30005,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30096,
      "e": 30096,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30201,
      "e": 30201,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Each shift starts at 8am to 8pm and we look at th"
    },
    {
      "t": 30394,
      "e": 30394,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 30394,
      "e": 30394,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30504,
      "e": 30504,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 30521,
      "e": 30521,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30521,
      "e": 30521,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30625,
      "e": 30625,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30793,
      "e": 30793,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 30793,
      "e": 30793,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30889,
      "e": 30889,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 30890,
      "e": 30890,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30905,
      "e": 30905,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||st"
    },
    {
      "t": 31006,
      "e": 31006,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Each shift starts at 8am to 8pm and we look at the st"
    },
    {
      "t": 31057,
      "e": 31057,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 31081,
      "e": 31081,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 31081,
      "e": 31081,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31161,
      "e": 31161,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 31163,
      "e": 31163,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31185,
      "e": 31185,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 31265,
      "e": 31265,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 31345,
      "e": 31345,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 31345,
      "e": 31345,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31473,
      "e": 31473,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 31489,
      "e": 31489,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31489,
      "e": 31489,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31593,
      "e": 31593,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 31665,
      "e": 31665,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 31666,
      "e": 31666,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31762,
      "e": 31762,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 31794,
      "e": 31794,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 31794,
      "e": 31794,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31889,
      "e": 31889,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 32089,
      "e": 32089,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 32090,
      "e": 32090,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32206,
      "e": 32206,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Each shift starts at 8am to 8pm and we look at the start abd"
    },
    {
      "t": 32248,
      "e": 32248,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 32249,
      "e": 32249,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32249,
      "e": 32249,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32313,
      "e": 32313,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 32409,
      "e": 32409,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 32410,
      "e": 32410,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32520,
      "e": 32520,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 32544,
      "e": 32544,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 32545,
      "e": 32545,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32657,
      "e": 32657,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 32873,
      "e": 32873,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 32961,
      "e": 32961,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Each shift starts at 8am to 8pm and we look at the start abd e"
    },
    {
      "t": 33080,
      "e": 33080,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 33128,
      "e": 33128,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Each shift starts at 8am to 8pm and we look at the start abd "
    },
    {
      "t": 33241,
      "e": 33241,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 33305,
      "e": 33305,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Each shift starts at 8am to 8pm and we look at the start abd"
    },
    {
      "t": 33407,
      "e": 33407,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Each shift starts at 8am to 8pm and we look at the start abd"
    },
    {
      "t": 33417,
      "e": 33417,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 33480,
      "e": 33480,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Each shift starts at 8am to 8pm and we look at the start ab"
    },
    {
      "t": 33593,
      "e": 33593,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 33640,
      "e": 33640,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Each shift starts at 8am to 8pm and we look at the start a"
    },
    {
      "t": 34137,
      "e": 34137,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 34139,
      "e": 34139,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34232,
      "e": 34232,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 34297,
      "e": 34297,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 34297,
      "e": 34297,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34408,
      "e": 34298,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Each shift starts at 8am to 8pm and we look at the start and"
    },
    {
      "t": 34432,
      "e": 34322,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 34472,
      "e": 34362,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34473,
      "e": 34363,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34552,
      "e": 34442,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 34640,
      "e": 34530,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 34641,
      "e": 34531,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34705,
      "e": 34595,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 34705,
      "e": 34595,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34728,
      "e": 34618,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||en"
    },
    {
      "t": 34848,
      "e": 34738,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34865,
      "e": 34755,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 34865,
      "e": 34755,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34969,
      "e": 34859,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 34984,
      "e": 34874,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34985,
      "e": 34875,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35073,
      "e": 34963,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 35866,
      "e": 35756,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 35866,
      "e": 35756,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35936,
      "e": 35826,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 35936,
      "e": 35826,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36000,
      "e": 35890,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ti"
    },
    {
      "t": 36072,
      "e": 35962,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36130,
      "e": 36020,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 36130,
      "e": 36020,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36304,
      "e": 36194,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 36337,
      "e": 36227,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 36338,
      "e": 36228,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36465,
      "e": 36355,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 37761,
      "e": 37651,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37762,
      "e": 37652,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37864,
      "e": 37754,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 38169,
      "e": 38059,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 38264,
      "e": 38154,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Each shift starts at 8am to 8pm and we look at the start and end time"
    },
    {
      "t": 38497,
      "e": 38387,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 38498,
      "e": 38388,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38606,
      "e": 38496,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Each shift starts at 8am to 8pm and we look at the start and end time,"
    },
    {
      "t": 38616,
      "e": 38506,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 38729,
      "e": 38619,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 38730,
      "e": 38620,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38809,
      "e": 38699,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 38859,
      "e": 38749,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 38859,
      "e": 38749,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38953,
      "e": 38843,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 38953,
      "e": 38843,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38960,
      "e": 38850,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||sp"
    },
    {
      "t": 39073,
      "e": 38963,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 39074,
      "e": 38964,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39080,
      "e": 38970,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 39177,
      "e": 39067,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 39298,
      "e": 39188,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 39298,
      "e": 39188,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39408,
      "e": 39298,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Each shift starts at 8am to 8pm and we look at the start and end time, spec"
    },
    {
      "t": 39409,
      "e": 39299,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 39426,
      "e": 39316,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 39426,
      "e": 39316,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39520,
      "e": 39410,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 39608,
      "e": 39498,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 39609,
      "e": 39499,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39728,
      "e": 39618,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 39833,
      "e": 39723,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 39834,
      "e": 39724,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39904,
      "e": 39794,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 39993,
      "e": 39883,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 39993,
      "e": 39883,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40004,
      "e": 39894,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40096,
      "e": 39986,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "186"
    },
    {
      "t": 40096,
      "e": 39986,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40128,
      "e": 40018,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a;"
    },
    {
      "t": 40160,
      "e": 40050,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40257,
      "e": 40147,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "186"
    },
    {
      "t": 40257,
      "e": 40147,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40344,
      "e": 40234,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||;"
    },
    {
      "t": 40513,
      "e": 40403,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 40513,
      "e": 40403,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40689,
      "e": 40579,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 41009,
      "e": 40899,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41106,
      "e": 40996,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Each shift starts at 8am to 8pm and we look at the start and end time, specofca;;"
    },
    {
      "t": 41201,
      "e": 41091,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41272,
      "e": 41162,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Each shift starts at 8am to 8pm and we look at the start and end time, specofca;"
    },
    {
      "t": 41377,
      "e": 41267,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 41449,
      "e": 41339,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Each shift starts at 8am to 8pm and we look at the start and end time, specofca"
    },
    {
      "t": 42024,
      "e": 41914,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 42185,
      "e": 42075,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Each shift starts at 8am to 8pm and we look at the start and end time, specofc"
    },
    {
      "t": 42289,
      "e": 42179,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 42392,
      "e": 42282,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Each shift starts at 8am to 8pm and we look at the start and end time, specof"
    },
    {
      "t": 42513,
      "e": 42403,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 42648,
      "e": 42538,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Each shift starts at 8am to 8pm and we look at the start and end time, speco"
    },
    {
      "t": 42777,
      "e": 42667,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 42817,
      "e": 42707,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Each shift starts at 8am to 8pm and we look at the start and end time, spec"
    },
    {
      "t": 43865,
      "e": 43755,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 43866,
      "e": 43756,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43936,
      "e": 43826,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 44008,
      "e": 43898,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 44008,
      "e": 43898,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44105,
      "e": 43995,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 44106,
      "e": 43996,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44120,
      "e": 44010,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||fi"
    },
    {
      "t": 44185,
      "e": 44075,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 44248,
      "e": 44138,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 44248,
      "e": 44138,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44329,
      "e": 44219,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 44433,
      "e": 44323,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 44434,
      "e": 44324,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44520,
      "e": 44410,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 44520,
      "e": 44410,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44537,
      "e": 44427,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||al"
    },
    {
      "t": 44577,
      "e": 44467,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 44672,
      "e": 44562,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 44673,
      "e": 44563,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44712,
      "e": 44602,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 44873,
      "e": 44763,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 44874,
      "e": 44764,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45000,
      "e": 44890,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 45024,
      "e": 44914,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 45025,
      "e": 44915,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45160,
      "e": 45050,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 45185,
      "e": 45075,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 45185,
      "e": 45075,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45281,
      "e": 45171,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 45288,
      "e": 45178,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 45288,
      "e": 45178,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45406,
      "e": 45178,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Each shift starts at 8am to 8pm and we look at the start and end time, specifically at"
    },
    {
      "t": 45416,
      "e": 45188,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 45416,
      "e": 45188,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45424,
      "e": 45196,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 45536,
      "e": 45308,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 45824,
      "e": 45596,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 45825,
      "e": 45597,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45953,
      "e": 45725,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 45953,
      "e": 45725,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45977,
      "e": 45749,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 46080,
      "e": 45852,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 47128,
      "e": 46900,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 47128,
      "e": 46900,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47224,
      "e": 46996,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 47336,
      "e": 47108,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 47368,
      "e": 47140,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 47369,
      "e": 47141,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47488,
      "e": 47260,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 47792,
      "e": 47564,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 47793,
      "e": 47565,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47849,
      "e": 47621,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||W"
    },
    {
      "t": 47929,
      "e": 47701,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 48056,
      "e": 47828,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 48057,
      "e": 47829,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48120,
      "e": 47892,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 48121,
      "e": 47893,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48152,
      "e": 47924,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 48273,
      "e": 48045,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 48288,
      "e": 48060,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 48288,
      "e": 48060,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48377,
      "e": 48149,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 48440,
      "e": 48212,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 48440,
      "e": 48212,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48544,
      "e": 48316,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 48544,
      "e": 48316,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48560,
      "e": 48332,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ot"
    },
    {
      "t": 48672,
      "e": 48444,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 48696,
      "e": 48468,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 48696,
      "e": 48468,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48806,
      "e": 48578,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Each shift starts at 8am to 8pm and we look at the start and end time, specifically at 12. We noti"
    },
    {
      "t": 48808,
      "e": 48580,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 48889,
      "e": 48661,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 48889,
      "e": 48661,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49006,
      "e": 48778,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Each shift starts at 8am to 8pm and we look at the start and end time, specifically at 12. We notic"
    },
    {
      "t": 49016,
      "e": 48788,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 49176,
      "e": 48948,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 49177,
      "e": 48949,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49344,
      "e": 49116,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 49344,
      "e": 49116,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49400,
      "e": 49172,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ed"
    },
    {
      "t": 49464,
      "e": 49236,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49464,
      "e": 49236,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 49464,
      "e": 49236,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49568,
      "e": 49340,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 57304,
      "e": 54340,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 57304,
      "e": 54340,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57384,
      "e": 54420,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 57384,
      "e": 54420,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57408,
      "e": 54444,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 57496,
      "e": 54532,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 57640,
      "e": 54676,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 57641,
      "e": 54677,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57744,
      "e": 54780,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 57745,
      "e": 54781,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57752,
      "e": 54788,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 57848,
      "e": 54884,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 58169,
      "e": 55205,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 58169,
      "e": 55205,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 58312,
      "e": 55348,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 58337,
      "e": 55373,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 58836,
      "e": 55872,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 58870,
      "e": 55906,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 58902,
      "e": 55938,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 58936,
      "e": 55972,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 58968,
      "e": 56004,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 59001,
      "e": 56037,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 59034,
      "e": 56070,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 59068,
      "e": 56104,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 59100,
      "e": 56136,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 59133,
      "e": 56169,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 59166,
      "e": 56202,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 59199,
      "e": 56235,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 59232,
      "e": 56268,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 59266,
      "e": 56302,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 59298,
      "e": 56334,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 59332,
      "e": 56368,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 59364,
      "e": 56400,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 59398,
      "e": 56434,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 59431,
      "e": 56467,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 59463,
      "e": 56499,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 59496,
      "e": 56532,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 59530,
      "e": 56566,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 59562,
      "e": 56598,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 59596,
      "e": 56632,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 59629,
      "e": 56632,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 59660,
      "e": 56663,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 59694,
      "e": 56697,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 59727,
      "e": 56730,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 59760,
      "e": 56763,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 59792,
      "e": 56795,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 59826,
      "e": 56829,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 59859,
      "e": 56862,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 59892,
      "e": 56895,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 59926,
      "e": 56929,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 59958,
      "e": 56961,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 59991,
      "e": 56994,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 60024,
      "e": 57027,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 60057,
      "e": 57060,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 60091,
      "e": 57094,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 60123,
      "e": 57126,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 60157,
      "e": 57160,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 60189,
      "e": 57192,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 60222,
      "e": 57225,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 60256,
      "e": 57259,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 60288,
      "e": 57291,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 60321,
      "e": 57324,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 60353,
      "e": 57356,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 60387,
      "e": 57390,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 60420,
      "e": 57423,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 60453,
      "e": 57456,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 60486,
      "e": 57489,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 60519,
      "e": 57522,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 60552,
      "e": 57555,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 60586,
      "e": 57589,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 60618,
      "e": 57621,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 60652,
      "e": 57655,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 60685,
      "e": 57688,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 60718,
      "e": 57721,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 60751,
      "e": 57754,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 60752,
      "e": 57755,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 60753,
      "e": 57756,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60800,
      "e": 57803,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||B"
    },
    {
      "t": 60856,
      "e": 57859,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 60944,
      "e": 57947,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 60944,
      "e": 57947,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61024,
      "e": 58027,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 61025,
      "e": 58028,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61033,
      "e": 58036,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| a"
    },
    {
      "t": 61152,
      "e": 58155,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 61192,
      "e": 58195,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 61193,
      "e": 58196,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61295,
      "e": 58298,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 61296,
      "e": 58299,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 61297,
      "e": 58300,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61407,
      "e": 58410,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Each shift starts at 8am to 8pm and we look at the start and end time, specifically at 12. We noticed that B and"
    },
    {
      "t": 61432,
      "e": 58435,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 61465,
      "e": 58468,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 61465,
      "e": 58468,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61528,
      "e": 58531,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 61544,
      "e": 58547,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 61737,
      "e": 58740,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 61737,
      "e": 58740,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61809,
      "e": 58812,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||F"
    },
    {
      "t": 61856,
      "e": 58859,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 62033,
      "e": 59036,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 62033,
      "e": 59036,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62143,
      "e": 59146,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 62225,
      "e": 59228,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 62225,
      "e": 59228,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62329,
      "e": 59332,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 62473,
      "e": 59476,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 62473,
      "e": 59476,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62568,
      "e": 59571,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 62568,
      "e": 59571,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62640,
      "e": 59643,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||re"
    },
    {
      "t": 62656,
      "e": 59659,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 62657,
      "e": 59660,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62696,
      "e": 59699,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 62760,
      "e": 59763,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 62768,
      "e": 59771,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 62769,
      "e": 59772,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 62889,
      "e": 59892,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 63000,
      "e": 60003,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 63001,
      "e": 60004,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63128,
      "e": 60131,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 63128,
      "e": 60131,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63176,
      "e": 60179,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 63257,
      "e": 60260,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 63258,
      "e": 60261,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63264,
      "e": 60267,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 63360,
      "e": 60363,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 63912,
      "e": 60915,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 63912,
      "e": 60915,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64032,
      "e": 61035,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 64041,
      "e": 61044,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 64041,
      "e": 61044,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64120,
      "e": 61123,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 64208,
      "e": 61211,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 64209,
      "e": 61212,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64320,
      "e": 61323,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 64433,
      "e": 61436,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 64434,
      "e": 61437,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64528,
      "e": 61531,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 65197,
      "e": 62200,
      "ty": 7,
      "x": 387,
      "y": 611,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65204,
      "e": 62207,
      "ty": 2,
      "x": 387,
      "y": 611
    },
    {
      "t": 65248,
      "e": 62251,
      "ty": 6,
      "x": 408,
      "y": 662,
      "ta": "#strategyButton"
    },
    {
      "t": 65255,
      "e": 62258,
      "ty": 41,
      "x": 37904,
      "y": 14004,
      "ta": "#strategyButton"
    },
    {
      "t": 65281,
      "e": 62284,
      "ty": 7,
      "x": 418,
      "y": 694,
      "ta": "#strategyButton"
    },
    {
      "t": 65305,
      "e": 62308,
      "ty": 2,
      "x": 423,
      "y": 711
    },
    {
      "t": 65398,
      "e": 62401,
      "ty": 6,
      "x": 406,
      "y": 687,
      "ta": "#strategyButton"
    },
    {
      "t": 65404,
      "e": 62407,
      "ty": 2,
      "x": 406,
      "y": 687
    },
    {
      "t": 65504,
      "e": 62507,
      "ty": 2,
      "x": 405,
      "y": 685
    },
    {
      "t": 65505,
      "e": 62508,
      "ty": 41,
      "x": 36266,
      "y": 58336,
      "ta": "#strategyButton"
    },
    {
      "t": 65604,
      "e": 62607,
      "ty": 2,
      "x": 405,
      "y": 678
    },
    {
      "t": 65705,
      "e": 62708,
      "ty": 2,
      "x": 405,
      "y": 677
    },
    {
      "t": 65755,
      "e": 62758,
      "ty": 41,
      "x": 36266,
      "y": 42916,
      "ta": "#strategyButton"
    },
    {
      "t": 66737,
      "e": 63740,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 66738,
      "e": 63741,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66833,
      "e": 63743,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 66944,
      "e": 63854,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 66945,
      "e": 63855,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67040,
      "e": 63950,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 67113,
      "e": 64023,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 67113,
      "e": 64023,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67248,
      "e": 64158,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 67272,
      "e": 64182,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 67273,
      "e": 64183,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67369,
      "e": 64279,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 67377,
      "e": 64287,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 67377,
      "e": 64287,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67432,
      "e": 64342,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 67609,
      "e": 64519,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 67609,
      "e": 64519,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67768,
      "e": 64678,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 67768,
      "e": 64678,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67776,
      "e": 64686,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 67881,
      "e": 64791,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 67881,
      "e": 64791,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67903,
      "e": 64813,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 68006,
      "e": 64916,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Each shift starts at 8am to 8pm and we look at the start and end time, specifically at 12. We noticed that B and F are lined up, making"
    },
    {
      "t": 68040,
      "e": 64950,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 68065,
      "e": 64975,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 68065,
      "e": 64975,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68192,
      "e": 65102,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 68296,
      "e": 65206,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 68297,
      "e": 65207,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68376,
      "e": 65286,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 68376,
      "e": 65286,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68448,
      "e": 65358,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 68504,
      "e": 65414,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 68569,
      "e": 65479,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 68570,
      "e": 65480,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68712,
      "e": 65622,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 68720,
      "e": 65630,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 68721,
      "e": 65631,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68848,
      "e": 65758,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 68936,
      "e": 65846,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 68939,
      "e": 65849,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69032,
      "e": 65942,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 69592,
      "e": 66502,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 69593,
      "e": 66503,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69688,
      "e": 66598,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 69688,
      "e": 66598,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69744,
      "e": 66654,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 69840,
      "e": 66750,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 69856,
      "e": 66766,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 69857,
      "e": 66767,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70001,
      "e": 66911,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 70008,
      "e": 66918,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 70009,
      "e": 66919,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70080,
      "e": 66990,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 70207,
      "e": 67117,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Each shift starts at 8am to 8pm and we look at the start and end time, specifically at 12. We noticed that B and F are lined up, making them the "
    },
    {
      "t": 70224,
      "e": 67134,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 70225,
      "e": 67135,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70353,
      "e": 67263,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 70377,
      "e": 67287,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 70377,
      "e": 67287,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70379,
      "e": 67289,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 70380,
      "e": 67290,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70432,
      "e": 67342,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ty"
    },
    {
      "t": 70529,
      "e": 67439,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 70919,
      "e": 67829,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 71048,
      "e": 67958,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Each shift starts at 8am to 8pm and we look at the start and end time, specifically at 12. We noticed that B and F are lined up, making them the st"
    },
    {
      "t": 71112,
      "e": 68022,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 71113,
      "e": 68023,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71209,
      "e": 68119,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 71385,
      "e": 68295,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 71386,
      "e": 68296,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71495,
      "e": 68405,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 71497,
      "e": 68407,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71520,
      "e": 68430,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||rt"
    },
    {
      "t": 71592,
      "e": 68502,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 72822,
      "e": 69732,
      "ty": 3,
      "x": 405,
      "y": 677,
      "ta": "#strategyButton"
    },
    {
      "t": 72824,
      "e": 69733,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Each shift starts at 8am to 8pm and we look at the start and end time, specifically at 12. We noticed that B and F are lined up, making them the start"
    },
    {
      "t": 72826,
      "e": 69735,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72827,
      "e": 69736,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 73020,
      "e": 69929,
      "ty": 4,
      "x": 36266,
      "y": 42916,
      "ta": "#strategyButton"
    },
    {
      "t": 73031,
      "e": 69940,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 73033,
      "e": 69942,
      "ty": 5,
      "x": 405,
      "y": 677,
      "ta": "#strategyButton"
    },
    {
      "t": 73042,
      "e": 69951,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 73305,
      "e": 70214,
      "ty": 2,
      "x": 388,
      "y": 733
    },
    {
      "t": 73405,
      "e": 70314,
      "ty": 2,
      "x": 371,
      "y": 773
    },
    {
      "t": 73505,
      "e": 70414,
      "ty": 41,
      "x": 12500,
      "y": 42378,
      "ta": "html > body"
    },
    {
      "t": 74004,
      "e": 70913,
      "ty": 2,
      "x": 371,
      "y": 772
    },
    {
      "t": 74005,
      "e": 70914,
      "ty": 41,
      "x": 12500,
      "y": 42323,
      "ta": "html > body"
    },
    {
      "t": 74041,
      "e": 70950,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 74104,
      "e": 71013,
      "ty": 2,
      "x": 379,
      "y": 720
    },
    {
      "t": 74204,
      "e": 71113,
      "ty": 2,
      "x": 385,
      "y": 653
    },
    {
      "t": 74254,
      "e": 71163,
      "ty": 41,
      "x": 12983,
      "y": 35343,
      "ta": "html > body"
    },
    {
      "t": 74304,
      "e": 71213,
      "ty": 2,
      "x": 385,
      "y": 641
    },
    {
      "t": 74405,
      "e": 71314,
      "ty": 2,
      "x": 422,
      "y": 584
    },
    {
      "t": 74505,
      "e": 71414,
      "ty": 2,
      "x": 779,
      "y": 505
    },
    {
      "t": 74505,
      "e": 71414,
      "ty": 41,
      "x": 26551,
      "y": 27532,
      "ta": "html > body"
    },
    {
      "t": 74605,
      "e": 71514,
      "ty": 2,
      "x": 1212,
      "y": 507
    },
    {
      "t": 74705,
      "e": 71614,
      "ty": 2,
      "x": 1210,
      "y": 510
    },
    {
      "t": 74755,
      "e": 71664,
      "ty": 41,
      "x": 39947,
      "y": 28917,
      "ta": "html > body"
    },
    {
      "t": 74788,
      "e": 71697,
      "ty": 6,
      "x": 1056,
      "y": 556,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 74805,
      "e": 71714,
      "ty": 2,
      "x": 1056,
      "y": 556
    },
    {
      "t": 74905,
      "e": 71814,
      "ty": 2,
      "x": 984,
      "y": 561
    },
    {
      "t": 75006,
      "e": 71915,
      "ty": 41,
      "x": 38066,
      "y": 21845,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 75077,
      "e": 71986,
      "ty": 3,
      "x": 984,
      "y": 561,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 75078,
      "e": 71987,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 75148,
      "e": 72057,
      "ty": 4,
      "x": 38066,
      "y": 21845,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 75148,
      "e": 72057,
      "ty": 5,
      "x": 984,
      "y": 561,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 75849,
      "e": 72758,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "98"
    },
    {
      "t": 75849,
      "e": 72758,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 75912,
      "e": 72821,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 76008,
      "e": 72917,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "98"
    },
    {
      "t": 76008,
      "e": 72917,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 76040,
      "e": 72949,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "22"
    },
    {
      "t": 76206,
      "e": 73115,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "22"
    },
    {
      "t": 76456,
      "e": 73365,
      "ty": 7,
      "x": 946,
      "y": 599,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 76505,
      "e": 73414,
      "ty": 2,
      "x": 932,
      "y": 616
    },
    {
      "t": 76505,
      "e": 73414,
      "ty": 41,
      "x": 26819,
      "y": 35108,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 76605,
      "e": 73514,
      "ty": 2,
      "x": 932,
      "y": 643
    },
    {
      "t": 76705,
      "e": 73614,
      "ty": 2,
      "x": 932,
      "y": 646
    },
    {
      "t": 76755,
      "e": 73664,
      "ty": 41,
      "x": 26819,
      "y": 44394,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 76766,
      "e": 73675,
      "ty": 6,
      "x": 932,
      "y": 648,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 76805,
      "e": 73714,
      "ty": 2,
      "x": 932,
      "y": 653
    },
    {
      "t": 76905,
      "e": 73814,
      "ty": 2,
      "x": 932,
      "y": 660
    },
    {
      "t": 76997,
      "e": 73906,
      "ty": 3,
      "x": 932,
      "y": 660,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 76998,
      "e": 73907,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "22"
    },
    {
      "t": 76998,
      "e": 73907,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 76999,
      "e": 73908,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 77004,
      "e": 73913,
      "ty": 41,
      "x": 26819,
      "y": 40569,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 77116,
      "e": 74025,
      "ty": 4,
      "x": 26819,
      "y": 40569,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 77116,
      "e": 74025,
      "ty": 5,
      "x": 932,
      "y": 660,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 78137,
      "e": 75046,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 78636,
      "e": 75545,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 78669,
      "e": 75578,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 78702,
      "e": 75611,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 78735,
      "e": 75644,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 78768,
      "e": 75677,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 78801,
      "e": 75710,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 78834,
      "e": 75743,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 78867,
      "e": 75776,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 78900,
      "e": 75809,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 78933,
      "e": 75842,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 78966,
      "e": 75875,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 78999,
      "e": 75908,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79033,
      "e": 75942,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79065,
      "e": 75974,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79099,
      "e": 76008,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79131,
      "e": 76040,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79165,
      "e": 76074,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79197,
      "e": 76106,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79230,
      "e": 76139,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79264,
      "e": 76173,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79296,
      "e": 76205,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79329,
      "e": 76238,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79362,
      "e": 76271,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79395,
      "e": 76304,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79428,
      "e": 76337,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79461,
      "e": 76370,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79495,
      "e": 76404,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79527,
      "e": 76436,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79560,
      "e": 76469,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79593,
      "e": 76502,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79627,
      "e": 76536,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79660,
      "e": 76569,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79691,
      "e": 76600,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79725,
      "e": 76634,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79757,
      "e": 76666,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79790,
      "e": 76699,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79823,
      "e": 76732,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79857,
      "e": 76766,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79890,
      "e": 76799,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79922,
      "e": 76831,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79956,
      "e": 76865,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 79989,
      "e": 76898,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 80004,
      "e": 76913,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 80021,
      "e": 76930,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 80055,
      "e": 76964,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 80088,
      "e": 76997,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 80122,
      "e": 77031,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 80154,
      "e": 77063,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 80187,
      "e": 77096,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 80220,
      "e": 77129,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 80253,
      "e": 77162,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 80286,
      "e": 77195,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 80319,
      "e": 77228,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 80352,
      "e": 77261,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 80385,
      "e": 77294,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 80418,
      "e": 77327,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 80451,
      "e": 77360,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 80484,
      "e": 77393,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 80517,
      "e": 77426,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 80521,
      "e": 77430,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 80521,
      "e": 77430,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 80665,
      "e": 77574,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "A"
    },
    {
      "t": 80673,
      "e": 77582,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "A"
    },
    {
      "t": 80849,
      "e": 77758,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "77"
    },
    {
      "t": 80849,
      "e": 77758,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 80960,
      "e": 77869,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 80961,
      "e": 77870,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 80983,
      "e": 77892,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Ame"
    },
    {
      "t": 81080,
      "e": 77989,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "82"
    },
    {
      "t": 81083,
      "e": 77992,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 81111,
      "e": 78020,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Amer"
    },
    {
      "t": 81168,
      "e": 78077,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 81168,
      "e": 78077,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 81199,
      "e": 78108,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||i"
    },
    {
      "t": 81271,
      "e": 78180,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 81344,
      "e": 78253,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "67"
    },
    {
      "t": 81345,
      "e": 78254,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 81433,
      "e": 78342,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||c"
    },
    {
      "t": 81568,
      "e": 78477,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 81569,
      "e": 78478,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 81664,
      "e": 78573,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 82233,
      "e": 79142,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 82233,
      "e": 79142,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 82304,
      "e": 79213,
      "ty": 2,
      "x": 933,
      "y": 663
    },
    {
      "t": 82311,
      "e": 79220,
      "ty": 7,
      "x": 933,
      "y": 669,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 82344,
      "e": 79253,
      "ty": 6,
      "x": 936,
      "y": 679,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 82384,
      "e": 79293,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| "
    },
    {
      "t": 82404,
      "e": 79313,
      "ty": 2,
      "x": 936,
      "y": 704
    },
    {
      "t": 82412,
      "e": 79321,
      "ty": 7,
      "x": 936,
      "y": 712,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 82504,
      "e": 79413,
      "ty": 2,
      "x": 936,
      "y": 715
    },
    {
      "t": 82505,
      "e": 79414,
      "ty": 41,
      "x": 31958,
      "y": 39165,
      "ta": "html > body"
    },
    {
      "t": 82604,
      "e": 79513,
      "ty": 2,
      "x": 935,
      "y": 709
    },
    {
      "t": 82612,
      "e": 79521,
      "ty": 6,
      "x": 934,
      "y": 706,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 82704,
      "e": 79613,
      "ty": 2,
      "x": 922,
      "y": 689
    },
    {
      "t": 82754,
      "e": 79663,
      "ty": 41,
      "x": 8286,
      "y": 7943,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 82804,
      "e": 79713,
      "ty": 2,
      "x": 909,
      "y": 677
    },
    {
      "t": 83004,
      "e": 79913,
      "ty": 2,
      "x": 912,
      "y": 677
    },
    {
      "t": 83004,
      "e": 79913,
      "ty": 41,
      "x": 8286,
      "y": 1985,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 83104,
      "e": 80013,
      "ty": 2,
      "x": 918,
      "y": 682
    },
    {
      "t": 83204,
      "e": 80113,
      "ty": 2,
      "x": 918,
      "y": 684
    },
    {
      "t": 83254,
      "e": 80163,
      "ty": 41,
      "x": 11378,
      "y": 15887,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 83404,
      "e": 80313,
      "ty": 2,
      "x": 897,
      "y": 677
    },
    {
      "t": 83413,
      "e": 80322,
      "ty": 7,
      "x": 881,
      "y": 673,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 83429,
      "e": 80338,
      "ty": 6,
      "x": 862,
      "y": 667,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 83504,
      "e": 80413,
      "ty": 2,
      "x": 827,
      "y": 662
    },
    {
      "t": 83505,
      "e": 80414,
      "ty": 41,
      "x": 4109,
      "y": 46810,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 83604,
      "e": 80513,
      "ty": 2,
      "x": 830,
      "y": 662
    },
    {
      "t": 83704,
      "e": 80613,
      "ty": 2,
      "x": 865,
      "y": 662
    },
    {
      "t": 83754,
      "e": 80663,
      "ty": 41,
      "x": 12328,
      "y": 46810,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 83804,
      "e": 80713,
      "ty": 2,
      "x": 870,
      "y": 662
    },
    {
      "t": 83904,
      "e": 80813,
      "ty": 2,
      "x": 874,
      "y": 662
    },
    {
      "t": 84004,
      "e": 80913,
      "ty": 2,
      "x": 883,
      "y": 658
    },
    {
      "t": 84005,
      "e": 80914,
      "ty": 41,
      "x": 16221,
      "y": 34327,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 84104,
      "e": 81013,
      "ty": 2,
      "x": 921,
      "y": 657
    },
    {
      "t": 84197,
      "e": 81106,
      "ty": 7,
      "x": 928,
      "y": 669,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 84204,
      "e": 81113,
      "ty": 2,
      "x": 928,
      "y": 669
    },
    {
      "t": 84247,
      "e": 81156,
      "ty": 6,
      "x": 929,
      "y": 676,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 84254,
      "e": 81163,
      "ty": 41,
      "x": 17048,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 84304,
      "e": 81213,
      "ty": 2,
      "x": 931,
      "y": 680
    },
    {
      "t": 84404,
      "e": 81313,
      "ty": 2,
      "x": 932,
      "y": 682
    },
    {
      "t": 84505,
      "e": 81414,
      "ty": 41,
      "x": 18594,
      "y": 11915,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 84517,
      "e": 81426,
      "ty": 3,
      "x": 932,
      "y": 682,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 84518,
      "e": 81427,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "America "
    },
    {
      "t": 84519,
      "e": 81428,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 84519,
      "e": 81428,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 84636,
      "e": 81545,
      "ty": 4,
      "x": 18594,
      "y": 11915,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 84636,
      "e": 81545,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 84637,
      "e": 81546,
      "ty": 5,
      "x": 932,
      "y": 682,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 84637,
      "e": 81546,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 84804,
      "e": 81713,
      "ty": 2,
      "x": 932,
      "y": 685
    },
    {
      "t": 84904,
      "e": 81813,
      "ty": 2,
      "x": 883,
      "y": 736
    },
    {
      "t": 85004,
      "e": 81913,
      "ty": 41,
      "x": 30133,
      "y": 40329,
      "ta": "html > body"
    },
    {
      "t": 85504,
      "e": 82413,
      "ty": 2,
      "x": 883,
      "y": 729
    },
    {
      "t": 85504,
      "e": 82413,
      "ty": 41,
      "x": 30133,
      "y": 39941,
      "ta": "html > body"
    },
    {
      "t": 85604,
      "e": 82513,
      "ty": 2,
      "x": 875,
      "y": 695
    },
    {
      "t": 85657,
      "e": 82566,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 85704,
      "e": 82613,
      "ty": 2,
      "x": 871,
      "y": 681
    },
    {
      "t": 85755,
      "e": 82664,
      "ty": 41,
      "x": 12774,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 85804,
      "e": 82713,
      "ty": 2,
      "x": 869,
      "y": 680
    },
    {
      "t": 86208,
      "e": 83117,
      "ty": 2,
      "x": 828,
      "y": 489
    },
    {
      "t": 86217,
      "e": 83126,
      "ty": 6,
      "x": 827,
      "y": 471,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 86234,
      "e": 83143,
      "ty": 7,
      "x": 826,
      "y": 452,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 86251,
      "e": 83160,
      "ty": 6,
      "x": 826,
      "y": 441,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 86257,
      "e": 83166,
      "ty": 41,
      "x": 0,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 86268,
      "e": 83177,
      "ty": 7,
      "x": 826,
      "y": 433,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 86308,
      "e": 83217,
      "ty": 2,
      "x": 829,
      "y": 422
    },
    {
      "t": 86319,
      "e": 83218,
      "ty": 6,
      "x": 829,
      "y": 420,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 86407,
      "e": 83306,
      "ty": 2,
      "x": 829,
      "y": 417
    },
    {
      "t": 86468,
      "e": 83367,
      "ty": 7,
      "x": 835,
      "y": 439,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 86468,
      "e": 83367,
      "ty": 6,
      "x": 835,
      "y": 439,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 86508,
      "e": 83407,
      "ty": 2,
      "x": 838,
      "y": 448
    },
    {
      "t": 86508,
      "e": 83407,
      "ty": 41,
      "x": 58367,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 86936,
      "e": 83835,
      "ty": 7,
      "x": 838,
      "y": 427,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 86952,
      "e": 83851,
      "ty": 6,
      "x": 838,
      "y": 408,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 86968,
      "e": 83867,
      "ty": 7,
      "x": 838,
      "y": 388,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 87008,
      "e": 83907,
      "ty": 2,
      "x": 838,
      "y": 363
    },
    {
      "t": 87008,
      "e": 83907,
      "ty": 41,
      "x": 3934,
      "y": 18724,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 87086,
      "e": 83985,
      "ty": 6,
      "x": 838,
      "y": 326,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 87102,
      "e": 84001,
      "ty": 7,
      "x": 838,
      "y": 311,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 87107,
      "e": 84006,
      "ty": 2,
      "x": 838,
      "y": 311
    },
    {
      "t": 87118,
      "e": 84017,
      "ty": 6,
      "x": 838,
      "y": 298,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 87136,
      "e": 84035,
      "ty": 7,
      "x": 839,
      "y": 280,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 87152,
      "e": 84051,
      "ty": 6,
      "x": 839,
      "y": 269,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 87169,
      "e": 84068,
      "ty": 7,
      "x": 839,
      "y": 255,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 87202,
      "e": 84101,
      "ty": 6,
      "x": 839,
      "y": 234,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 87208,
      "e": 84107,
      "ty": 2,
      "x": 839,
      "y": 234
    },
    {
      "t": 87218,
      "e": 84117,
      "ty": 7,
      "x": 839,
      "y": 227,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 87258,
      "e": 84157,
      "ty": 41,
      "x": 4171,
      "y": 17835,
      "ta": "#jspsych-survey-multi-choice-0"
    },
    {
      "t": 87308,
      "e": 84207,
      "ty": 2,
      "x": 839,
      "y": 222
    },
    {
      "t": 87369,
      "e": 84268,
      "ty": 6,
      "x": 835,
      "y": 233,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 87407,
      "e": 84306,
      "ty": 2,
      "x": 834,
      "y": 237
    },
    {
      "t": 87508,
      "e": 84407,
      "ty": 41,
      "x": 38202,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 87608,
      "e": 84507,
      "ty": 3,
      "x": 831,
      "y": 233,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 87610,
      "e": 84509,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 87612,
      "e": 84511,
      "ty": 2,
      "x": 831,
      "y": 233
    },
    {
      "t": 87735,
      "e": 84634,
      "ty": 4,
      "x": 23079,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 87735,
      "e": 84634,
      "ty": 5,
      "x": 831,
      "y": 233,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 87735,
      "e": 84634,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 87757,
      "e": 84656,
      "ty": 41,
      "x": 23079,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 87870,
      "e": 84769,
      "ty": 7,
      "x": 837,
      "y": 255,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 87908,
      "e": 84807,
      "ty": 2,
      "x": 845,
      "y": 266
    },
    {
      "t": 88008,
      "e": 84907,
      "ty": 2,
      "x": 865,
      "y": 299
    },
    {
      "t": 88008,
      "e": 84907,
      "ty": 41,
      "x": 13657,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 88108,
      "e": 85007,
      "ty": 2,
      "x": 885,
      "y": 328
    },
    {
      "t": 88207,
      "e": 85106,
      "ty": 2,
      "x": 866,
      "y": 259
    },
    {
      "t": 88258,
      "e": 85157,
      "ty": 41,
      "x": 32428,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 88308,
      "e": 85207,
      "ty": 2,
      "x": 856,
      "y": 343
    },
    {
      "t": 88408,
      "e": 85307,
      "ty": 2,
      "x": 865,
      "y": 428
    },
    {
      "t": 88508,
      "e": 85407,
      "ty": 2,
      "x": 867,
      "y": 404
    },
    {
      "t": 88508,
      "e": 85407,
      "ty": 41,
      "x": 10816,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 88607,
      "e": 85506,
      "ty": 2,
      "x": 846,
      "y": 422
    },
    {
      "t": 88637,
      "e": 85507,
      "ty": 6,
      "x": 827,
      "y": 446,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 88653,
      "e": 85523,
      "ty": 7,
      "x": 824,
      "y": 451,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 88708,
      "e": 85578,
      "ty": 2,
      "x": 823,
      "y": 456
    },
    {
      "t": 88758,
      "e": 85628,
      "ty": 41,
      "x": 374,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 88808,
      "e": 85678,
      "ty": 2,
      "x": 823,
      "y": 450
    },
    {
      "t": 88908,
      "e": 85778,
      "ty": 2,
      "x": 826,
      "y": 422
    },
    {
      "t": 89008,
      "e": 85878,
      "ty": 2,
      "x": 827,
      "y": 422
    },
    {
      "t": 89008,
      "e": 85878,
      "ty": 41,
      "x": 6529,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 89105,
      "e": 85975,
      "ty": 6,
      "x": 834,
      "y": 436,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 89108,
      "e": 85978,
      "ty": 2,
      "x": 834,
      "y": 436
    },
    {
      "t": 89258,
      "e": 86128,
      "ty": 41,
      "x": 38202,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 89307,
      "e": 86177,
      "ty": 2,
      "x": 835,
      "y": 445
    },
    {
      "t": 89354,
      "e": 86224,
      "ty": 7,
      "x": 835,
      "y": 450,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 89408,
      "e": 86278,
      "ty": 2,
      "x": 835,
      "y": 454
    },
    {
      "t": 89509,
      "e": 86379,
      "ty": 41,
      "x": 3222,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 89655,
      "e": 86525,
      "ty": 6,
      "x": 835,
      "y": 465,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 89688,
      "e": 86558,
      "ty": 7,
      "x": 833,
      "y": 477,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 89708,
      "e": 86578,
      "ty": 2,
      "x": 831,
      "y": 479
    },
    {
      "t": 89758,
      "e": 86628,
      "ty": 41,
      "x": 2273,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 89809,
      "e": 86679,
      "ty": 2,
      "x": 832,
      "y": 489
    },
    {
      "t": 89838,
      "e": 86708,
      "ty": 6,
      "x": 833,
      "y": 493,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 89904,
      "e": 86774,
      "ty": 7,
      "x": 836,
      "y": 506,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 89907,
      "e": 86777,
      "ty": 2,
      "x": 836,
      "y": 506
    },
    {
      "t": 89971,
      "e": 86841,
      "ty": 6,
      "x": 839,
      "y": 521,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 90008,
      "e": 86878,
      "ty": 2,
      "x": 839,
      "y": 524
    },
    {
      "t": 90008,
      "e": 86878,
      "ty": 41,
      "x": 63408,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 90037,
      "e": 86907,
      "ty": 7,
      "x": 841,
      "y": 527,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 90108,
      "e": 86978,
      "ty": 2,
      "x": 841,
      "y": 533
    },
    {
      "t": 90208,
      "e": 87078,
      "ty": 2,
      "x": 841,
      "y": 534
    },
    {
      "t": 90258,
      "e": 87128,
      "ty": 41,
      "x": 22911,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 90584,
      "e": 87454,
      "ty": 6,
      "x": 838,
      "y": 531,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 90608,
      "e": 87478,
      "ty": 2,
      "x": 837,
      "y": 531
    },
    {
      "t": 90708,
      "e": 87578,
      "ty": 2,
      "x": 835,
      "y": 522
    },
    {
      "t": 90722,
      "e": 87592,
      "ty": 7,
      "x": 835,
      "y": 519,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 90759,
      "e": 87629,
      "ty": 41,
      "x": 3222,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-4"
    },
    {
      "t": 90804,
      "e": 87674,
      "ty": 6,
      "x": 835,
      "y": 504,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 90808,
      "e": 87678,
      "ty": 2,
      "x": 835,
      "y": 504
    },
    {
      "t": 90888,
      "e": 87758,
      "ty": 7,
      "x": 835,
      "y": 490,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 90908,
      "e": 87778,
      "ty": 2,
      "x": 835,
      "y": 489
    },
    {
      "t": 91007,
      "e": 87877,
      "ty": 2,
      "x": 834,
      "y": 489
    },
    {
      "t": 91008,
      "e": 87878,
      "ty": 41,
      "x": 11289,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 91208,
      "e": 88078,
      "ty": 2,
      "x": 835,
      "y": 491
    },
    {
      "t": 91223,
      "e": 88093,
      "ty": 6,
      "x": 835,
      "y": 492,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 91258,
      "e": 88128,
      "ty": 41,
      "x": 48284,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 91308,
      "e": 88178,
      "ty": 2,
      "x": 838,
      "y": 504
    },
    {
      "t": 91322,
      "e": 88192,
      "ty": 7,
      "x": 838,
      "y": 505,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 91408,
      "e": 88278,
      "ty": 2,
      "x": 838,
      "y": 506
    },
    {
      "t": 91473,
      "e": 88343,
      "ty": 6,
      "x": 838,
      "y": 504,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 91508,
      "e": 88378,
      "ty": 2,
      "x": 838,
      "y": 502
    },
    {
      "t": 91508,
      "e": 88378,
      "ty": 41,
      "x": 58367,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 91608,
      "e": 88478,
      "ty": 2,
      "x": 838,
      "y": 498
    },
    {
      "t": 91708,
      "e": 88578,
      "ty": 2,
      "x": 837,
      "y": 496
    },
    {
      "t": 91740,
      "e": 88610,
      "ty": 7,
      "x": 835,
      "y": 489,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 91758,
      "e": 88628,
      "ty": 41,
      "x": 3222,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 91808,
      "e": 88678,
      "ty": 2,
      "x": 835,
      "y": 482
    },
    {
      "t": 91983,
      "e": 88678,
      "ty": 3,
      "x": 834,
      "y": 479,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 91984,
      "e": 88679,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 92008,
      "e": 88703,
      "ty": 2,
      "x": 834,
      "y": 479
    },
    {
      "t": 92008,
      "e": 88703,
      "ty": 41,
      "x": 13295,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 92119,
      "e": 88814,
      "ty": 4,
      "x": 13295,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 92119,
      "e": 88814,
      "ty": 5,
      "x": 834,
      "y": 479,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 92120,
      "e": 88815,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 92121,
      "e": 88816,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf",
      "v": "Third"
    },
    {
      "t": 92407,
      "e": 89102,
      "ty": 2,
      "x": 894,
      "y": 615
    },
    {
      "t": 92508,
      "e": 89203,
      "ty": 2,
      "x": 911,
      "y": 675
    },
    {
      "t": 92508,
      "e": 89203,
      "ty": 41,
      "x": 24051,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 93808,
      "e": 90503,
      "ty": 2,
      "x": 914,
      "y": 676
    },
    {
      "t": 93908,
      "e": 90603,
      "ty": 2,
      "x": 917,
      "y": 673
    },
    {
      "t": 94008,
      "e": 90703,
      "ty": 2,
      "x": 922,
      "y": 669
    },
    {
      "t": 94008,
      "e": 90703,
      "ty": 41,
      "x": 27005,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 94108,
      "e": 90803,
      "ty": 2,
      "x": 931,
      "y": 663
    },
    {
      "t": 94208,
      "e": 90903,
      "ty": 2,
      "x": 932,
      "y": 663
    },
    {
      "t": 94258,
      "e": 90953,
      "ty": 41,
      "x": 26242,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 94908,
      "e": 91603,
      "ty": 2,
      "x": 932,
      "y": 657
    },
    {
      "t": 95008,
      "e": 91703,
      "ty": 2,
      "x": 931,
      "y": 655
    },
    {
      "t": 95008,
      "e": 91703,
      "ty": 41,
      "x": 26005,
      "y": 10832,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 95108,
      "e": 91803,
      "ty": 2,
      "x": 919,
      "y": 708
    },
    {
      "t": 95208,
      "e": 91903,
      "ty": 2,
      "x": 915,
      "y": 733
    },
    {
      "t": 95258,
      "e": 91953,
      "ty": 41,
      "x": 21980,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 95308,
      "e": 92003,
      "ty": 2,
      "x": 904,
      "y": 753
    },
    {
      "t": 95408,
      "e": 92103,
      "ty": 2,
      "x": 890,
      "y": 794
    },
    {
      "t": 95508,
      "e": 92203,
      "ty": 2,
      "x": 887,
      "y": 829
    },
    {
      "t": 95508,
      "e": 92203,
      "ty": 41,
      "x": 15563,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 95608,
      "e": 92303,
      "ty": 2,
      "x": 881,
      "y": 819
    },
    {
      "t": 95692,
      "e": 92387,
      "ty": 6,
      "x": 827,
      "y": 733,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 95708,
      "e": 92403,
      "ty": 2,
      "x": 827,
      "y": 733
    },
    {
      "t": 95758,
      "e": 92453,
      "ty": 41,
      "x": 2914,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 95808,
      "e": 92503,
      "ty": 2,
      "x": 827,
      "y": 731
    },
    {
      "t": 96374,
      "e": 93069,
      "ty": 7,
      "x": 825,
      "y": 731,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 96408,
      "e": 93103,
      "ty": 2,
      "x": 825,
      "y": 731
    },
    {
      "t": 96509,
      "e": 93204,
      "ty": 41,
      "x": 898,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 96561,
      "e": 93256,
      "ty": 6,
      "x": 826,
      "y": 730,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 96609,
      "e": 93304,
      "ty": 2,
      "x": 828,
      "y": 730
    },
    {
      "t": 96677,
      "e": 93372,
      "ty": 7,
      "x": 839,
      "y": 737,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 96708,
      "e": 93403,
      "ty": 2,
      "x": 839,
      "y": 743
    },
    {
      "t": 96758,
      "e": 93453,
      "ty": 41,
      "x": 4171,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 96808,
      "e": 93503,
      "ty": 2,
      "x": 839,
      "y": 746
    },
    {
      "t": 97060,
      "e": 93755,
      "ty": 6,
      "x": 837,
      "y": 753,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 97108,
      "e": 93803,
      "ty": 2,
      "x": 836,
      "y": 754
    },
    {
      "t": 97259,
      "e": 93954,
      "ty": 41,
      "x": 48284,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 97308,
      "e": 94003,
      "ty": 2,
      "x": 834,
      "y": 754
    },
    {
      "t": 97408,
      "e": 94103,
      "ty": 2,
      "x": 834,
      "y": 753
    },
    {
      "t": 97508,
      "e": 94203,
      "ty": 41,
      "x": 38202,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 97608,
      "e": 94303,
      "ty": 2,
      "x": 834,
      "y": 755
    },
    {
      "t": 97709,
      "e": 94404,
      "ty": 2,
      "x": 835,
      "y": 756
    },
    {
      "t": 97758,
      "e": 94453,
      "ty": 41,
      "x": 43243,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 97775,
      "e": 94470,
      "ty": 7,
      "x": 835,
      "y": 751,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 97809,
      "e": 94504,
      "ty": 2,
      "x": 835,
      "y": 745
    },
    {
      "t": 97827,
      "e": 94522,
      "ty": 6,
      "x": 835,
      "y": 736,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 97908,
      "e": 94603,
      "ty": 2,
      "x": 835,
      "y": 736
    },
    {
      "t": 98008,
      "e": 94703,
      "ty": 2,
      "x": 835,
      "y": 728
    },
    {
      "t": 98008,
      "e": 94703,
      "ty": 41,
      "x": 43243,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 98072,
      "e": 94767,
      "ty": 3,
      "x": 835,
      "y": 726,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 98073,
      "e": 94768,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 98074,
      "e": 94769,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 98108,
      "e": 94803,
      "ty": 2,
      "x": 835,
      "y": 726
    },
    {
      "t": 98198,
      "e": 94893,
      "ty": 4,
      "x": 43243,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 98199,
      "e": 94894,
      "ty": 5,
      "x": 835,
      "y": 726,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 98199,
      "e": 94894,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf",
      "v": "Biomedical & Health Sciences"
    },
    {
      "t": 98258,
      "e": 94953,
      "ty": 41,
      "x": 43243,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 98408,
      "e": 95103,
      "ty": 2,
      "x": 835,
      "y": 728
    },
    {
      "t": 98445,
      "e": 95140,
      "ty": 7,
      "x": 828,
      "y": 742,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 98508,
      "e": 95203,
      "ty": 2,
      "x": 795,
      "y": 761
    },
    {
      "t": 98509,
      "e": 95204,
      "ty": 41,
      "x": 27102,
      "y": 41714,
      "ta": "html > body"
    },
    {
      "t": 98608,
      "e": 95303,
      "ty": 2,
      "x": 744,
      "y": 773
    },
    {
      "t": 98708,
      "e": 95403,
      "ty": 2,
      "x": 777,
      "y": 779
    },
    {
      "t": 98760,
      "e": 95405,
      "ty": 41,
      "x": 43428,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 98808,
      "e": 95453,
      "ty": 2,
      "x": 944,
      "y": 833
    },
    {
      "t": 98908,
      "e": 95553,
      "ty": 2,
      "x": 916,
      "y": 887
    },
    {
      "t": 99008,
      "e": 95653,
      "ty": 2,
      "x": 874,
      "y": 936
    },
    {
      "t": 99009,
      "e": 95654,
      "ty": 41,
      "x": 57428,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 99108,
      "e": 95753,
      "ty": 2,
      "x": 869,
      "y": 928
    },
    {
      "t": 99208,
      "e": 95853,
      "ty": 2,
      "x": 860,
      "y": 893
    },
    {
      "t": 99258,
      "e": 95903,
      "ty": 41,
      "x": 7968,
      "y": 46810,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 99308,
      "e": 95953,
      "ty": 2,
      "x": 843,
      "y": 918
    },
    {
      "t": 99408,
      "e": 96053,
      "ty": 2,
      "x": 841,
      "y": 946
    },
    {
      "t": 99508,
      "e": 96153,
      "ty": 2,
      "x": 841,
      "y": 957
    },
    {
      "t": 99508,
      "e": 96153,
      "ty": 41,
      "x": 15837,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 99512,
      "e": 96157,
      "ty": 6,
      "x": 839,
      "y": 959,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 99608,
      "e": 96253,
      "ty": 2,
      "x": 829,
      "y": 961
    },
    {
      "t": 99758,
      "e": 96403,
      "ty": 41,
      "x": 12996,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 99824,
      "e": 96469,
      "ty": 3,
      "x": 829,
      "y": 961,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 99825,
      "e": 96470,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 99826,
      "e": 96471,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 99927,
      "e": 96572,
      "ty": 4,
      "x": 12996,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 99928,
      "e": 96573,
      "ty": 5,
      "x": 829,
      "y": 961,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 99928,
      "e": 96573,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 99996,
      "e": 96641,
      "ty": 7,
      "x": 832,
      "y": 970,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 100008,
      "e": 96653,
      "ty": 2,
      "x": 832,
      "y": 970
    },
    {
      "t": 100008,
      "e": 96653,
      "ty": 41,
      "x": 8556,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 100108,
      "e": 96753,
      "ty": 2,
      "x": 861,
      "y": 1000
    },
    {
      "t": 100208,
      "e": 96853,
      "ty": 2,
      "x": 864,
      "y": 1002
    },
    {
      "t": 100230,
      "e": 96875,
      "ty": 6,
      "x": 864,
      "y": 1005,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 100259,
      "e": 96904,
      "ty": 41,
      "x": 18851,
      "y": 5957,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 100303,
      "e": 96948,
      "ty": 3,
      "x": 866,
      "y": 1008,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 100304,
      "e": 96949,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 100304,
      "e": 96949,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 100308,
      "e": 96953,
      "ty": 2,
      "x": 866,
      "y": 1008
    },
    {
      "t": 100472,
      "e": 97117,
      "ty": 4,
      "x": 18851,
      "y": 5957,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 100472,
      "e": 97117,
      "ty": 5,
      "x": 866,
      "y": 1008,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 100477,
      "e": 97122,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 100479,
      "e": 97124,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 100480,
      "e": 97125,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 100608,
      "e": 97253,
      "ty": 2,
      "x": 866,
      "y": 1007
    },
    {
      "t": 100708,
      "e": 97353,
      "ty": 2,
      "x": 809,
      "y": 926
    },
    {
      "t": 100759,
      "e": 97404,
      "ty": 41,
      "x": 24795,
      "y": 43154,
      "ta": "html > body"
    },
    {
      "t": 100810,
      "e": 97455,
      "ty": 2,
      "x": 671,
      "y": 571
    },
    {
      "t": 100908,
      "e": 97553,
      "ty": 2,
      "x": 744,
      "y": 404
    },
    {
      "t": 101008,
      "e": 97653,
      "ty": 2,
      "x": 849,
      "y": 342
    },
    {
      "t": 101009,
      "e": 97654,
      "ty": 41,
      "x": 28962,
      "y": 18502,
      "ta": "html > body"
    },
    {
      "t": 101209,
      "e": 97854,
      "ty": 2,
      "x": 849,
      "y": 352
    },
    {
      "t": 101258,
      "e": 97903,
      "ty": 41,
      "x": 28962,
      "y": 19167,
      "ta": "html > body"
    },
    {
      "t": 101308,
      "e": 97953,
      "ty": 2,
      "x": 849,
      "y": 354
    },
    {
      "t": 101822,
      "e": 98467,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 101908,
      "e": 98553,
      "ty": 2,
      "x": 847,
      "y": 318
    },
    {
      "t": 102009,
      "e": 98654,
      "ty": 2,
      "x": 841,
      "y": 296
    },
    {
      "t": 102009,
      "e": 98654,
      "ty": 41,
      "x": 26937,
      "y": 11751,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 102108,
      "e": 98753,
      "ty": 2,
      "x": 840,
      "y": 287
    },
    {
      "t": 102209,
      "e": 98854,
      "ty": 2,
      "x": 748,
      "y": 310
    },
    {
      "t": 102259,
      "e": 98904,
      "ty": 41,
      "x": 13605,
      "y": 14313,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 102308,
      "e": 98953,
      "ty": 2,
      "x": 552,
      "y": 333
    },
    {
      "t": 102409,
      "e": 99054,
      "ty": 2,
      "x": 593,
      "y": 312
    },
    {
      "t": 102508,
      "e": 99153,
      "ty": 2,
      "x": 701,
      "y": 287
    },
    {
      "t": 102508,
      "e": 99153,
      "ty": 41,
      "x": 20050,
      "y": 11128,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 102608,
      "e": 99253,
      "ty": 2,
      "x": 693,
      "y": 289
    },
    {
      "t": 102709,
      "e": 99354,
      "ty": 2,
      "x": 304,
      "y": 317
    },
    {
      "t": 102758,
      "e": 99403,
      "ty": 41,
      "x": 5647,
      "y": 16674,
      "ta": "> div.masterdiv"
    },
    {
      "t": 102808,
      "e": 99453,
      "ty": 2,
      "x": 166,
      "y": 308
    },
    {
      "t": 102908,
      "e": 99553,
      "ty": 2,
      "x": 216,
      "y": 374
    },
    {
      "t": 103008,
      "e": 99653,
      "ty": 2,
      "x": 368,
      "y": 400
    },
    {
      "t": 103009,
      "e": 99654,
      "ty": 41,
      "x": 25990,
      "y": 50840,
      "ta": "> div.masterdiv > div:[2] > div > p:[2] > b"
    },
    {
      "t": 103108,
      "e": 99753,
      "ty": 2,
      "x": 369,
      "y": 400
    },
    {
      "t": 103209,
      "e": 99854,
      "ty": 2,
      "x": 370,
      "y": 406
    },
    {
      "t": 103260,
      "e": 99856,
      "ty": 41,
      "x": 3765,
      "y": 19906,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 104008,
      "e": 100604,
      "ty": 2,
      "x": 378,
      "y": 409
    },
    {
      "t": 104008,
      "e": 100604,
      "ty": 41,
      "x": 4159,
      "y": 22247,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 104108,
      "e": 100704,
      "ty": 2,
      "x": 392,
      "y": 409
    },
    {
      "t": 104208,
      "e": 100804,
      "ty": 2,
      "x": 434,
      "y": 405
    },
    {
      "t": 104259,
      "e": 100855,
      "ty": 41,
      "x": 60506,
      "y": 60671,
      "ta": "> div.masterdiv > div:[2] > div > p:[2] > b"
    },
    {
      "t": 104308,
      "e": 100904,
      "ty": 2,
      "x": 500,
      "y": 398
    },
    {
      "t": 104407,
      "e": 101003,
      "ty": 2,
      "x": 550,
      "y": 385
    },
    {
      "t": 104507,
      "e": 101103,
      "ty": 2,
      "x": 566,
      "y": 374
    },
    {
      "t": 104507,
      "e": 101103,
      "ty": 41,
      "x": 13408,
      "y": 4575,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 104907,
      "e": 101503,
      "ty": 2,
      "x": 502,
      "y": 374
    },
    {
      "t": 105007,
      "e": 101603,
      "ty": 2,
      "x": 300,
      "y": 400
    },
    {
      "t": 105008,
      "e": 101604,
      "ty": 41,
      "x": 2282,
      "y": 50840,
      "ta": "> div.masterdiv > div:[2] > div > p:[2] > b"
    },
    {
      "t": 105107,
      "e": 101703,
      "ty": 2,
      "x": 215,
      "y": 400
    },
    {
      "t": 105208,
      "e": 101804,
      "ty": 2,
      "x": 165,
      "y": 433
    },
    {
      "t": 105258,
      "e": 101854,
      "ty": 41,
      "x": 5234,
      "y": 25593,
      "ta": "> div.masterdiv"
    },
    {
      "t": 105308,
      "e": 101904,
      "ty": 2,
      "x": 190,
      "y": 497
    },
    {
      "t": 105408,
      "e": 102004,
      "ty": 2,
      "x": 220,
      "y": 501
    },
    {
      "t": 105508,
      "e": 102104,
      "ty": 41,
      "x": 7300,
      "y": 27310,
      "ta": "> div.masterdiv"
    },
    {
      "t": 110008,
      "e": 106604,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 157411,
      "e": 107104,
      "ty": 2,
      "x": 318,
      "y": 431
    },
    {
      "t": 157512,
      "e": 107205,
      "ty": 2,
      "x": 1331,
      "y": 574
    },
    {
      "t": 157513,
      "e": 107206,
      "ty": 41,
      "x": 51044,
      "y": 35699,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 157612,
      "e": 107305,
      "ty": 2,
      "x": 1462,
      "y": 1199
    },
    {
      "t": 157712,
      "e": 107405,
      "ty": 2,
      "x": 1571,
      "y": 1190
    },
    {
      "t": 157763,
      "e": 107456,
      "ty": 41,
      "x": 56960,
      "y": 64260,
      "ta": "> div.masterdiv"
    },
    {
      "t": 157812,
      "e": 107505,
      "ty": 2,
      "x": 1666,
      "y": 1162
    },
    {
      "t": 157911,
      "e": 107604,
      "ty": 2,
      "x": 1108,
      "y": 1145
    },
    {
      "t": 158011,
      "e": 107704,
      "ty": 2,
      "x": 1077,
      "y": 1126
    },
    {
      "t": 158012,
      "e": 107705,
      "ty": 41,
      "x": 36813,
      "y": 61934,
      "ta": "> div.masterdiv"
    },
    {
      "t": 158112,
      "e": 107805,
      "ty": 2,
      "x": 1074,
      "y": 1125
    },
    {
      "t": 158198,
      "e": 107891,
      "ty": 6,
      "x": 948,
      "y": 1106,
      "ta": "#start"
    },
    {
      "t": 158211,
      "e": 107904,
      "ty": 2,
      "x": 948,
      "y": 1106
    },
    {
      "t": 158261,
      "e": 107954,
      "ty": 41,
      "x": 18295,
      "y": 52644,
      "ta": "#start"
    },
    {
      "t": 158312,
      "e": 108005,
      "ty": 2,
      "x": 943,
      "y": 1100
    },
    {
      "t": 158395,
      "e": 108088,
      "ty": 3,
      "x": 943,
      "y": 1100,
      "ta": "#start"
    },
    {
      "t": 158396,
      "e": 108089,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 158507,
      "e": 108200,
      "ty": 4,
      "x": 18295,
      "y": 52644,
      "ta": "#start"
    },
    {
      "t": 158509,
      "e": 108202,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 158510,
      "e": 108203,
      "ty": 5,
      "x": 943,
      "y": 1100,
      "ta": "#start"
    },
    {
      "t": 158512,
      "e": 108205,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 159549,
      "e": 109242,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 161095,
      "e": 110788,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"id\":2593},{\"id\":2594},{\"id\":2595},{\"id\":2596},{\"id\":2597},{\"id\":2598},{\"id\":2599},{\"id\":2600},{\"nodeType\":3,\"id\":2604,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2601},{\"id\":2602},{\"nodeType\":3,\"id\":2605,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2603}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2606,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2607,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2606},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2608,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2607},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2609,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2608},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2607}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2607}},{\"nodeType\":3,\"id\":2612,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2610}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2608}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2608}},{\"nodeType\":3,\"id\":2615,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2616,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2609}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2606},{\"id\":2607},{\"id\":2610},{\"id\":2612},{\"id\":2611},{\"id\":2608},{\"id\":2613},{\"id\":2615},{\"id\":2614},{\"id\":2609},{\"id\":2616}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2617,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2621,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2620},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2622},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2625,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2625},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2626},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2628,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2619}},{\"nodeType\":3,\"id\":2629,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2624}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2629},\"parentNode\":{\"id\":2624}},{\"nodeType\":1,\"id\":2631,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2625}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2631}},{\"nodeType\":3,\"id\":2633,\"textContent\":\"English\",\"previousSibling\":{\"id\":2632},\"parentNode\":{\"id\":2631}},{\"nodeType\":1,\"id\":2634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2635,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2634}},{\"nodeType\":3,\"id\":2636,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2635},\"parentNode\":{\"id\":2634}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2627}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":3,\"id\":2639,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2628}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":3,\"id\":2642,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2640}},{\"nodeType\":3,\"id\":2643,\"textContent\":\"*\",\"parentNode\":{\"id\":2630}},{\"nodeType\":1,\"id\":2644,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2645},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2646},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2648,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2648},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2649},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2651,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2620}},{\"nodeType\":3,\"id\":2652,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2644}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2652},\"parentNode\":{\"id\":2644}},{\"nodeType\":1,\"id\":2654,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2654}},{\"nodeType\":3,\"id\":2656,\"textContent\":\"First\",\"previousSibling\":{\"id\":2655},\"parentNode\":{\"id\":2654}},{\"nodeType\":1,\"id\":2657,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2657}},{\"nodeType\":3,\"id\":2659,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2658},\"parentNode\":{\"id\":2657}},{\"nodeType\":1,\"id\":2660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2647}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2660}},{\"nodeType\":3,\"id\":2662,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2661},\"parentNode\":{\"id\":2660}},{\"nodeType\":1,\"id\":2663,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2648}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2663}},{\"nodeType\":3,\"id\":2665,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2664},\"parentNode\":{\"id\":2663}},{\"nodeType\":1,\"id\":2666,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2667,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2666}},{\"nodeType\":3,\"id\":2668,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2667},\"parentNode\":{\"id\":2666}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2650}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":3,\"id\":2671,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2651}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":3,\"id\":2674,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2672}},{\"nodeType\":3,\"id\":2675,\"textContent\":\"*\",\"parentNode\":{\"id\":2653}},{\"nodeType\":1,\"id\":2676,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2677},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2678},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2680,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2680},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2681},\"parentNode\":{\"id\":2621}},{\"nodeType\":1,\"id\":2683,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2621}},{\"nodeType\":3,\"id\":2684,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2676}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2684},\"parentNode\":{\"id\":2676}},{\"nodeType\":1,\"id\":2686,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2686}},{\"nodeType\":3,\"id\":2688,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2687},\"parentNode\":{\"id\":2686}},{\"nodeType\":1,\"id\":2689,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2689}},{\"nodeType\":3,\"id\":2691,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2690},\"parentNode\":{\"id\":2689}},{\"nodeType\":1,\"id\":2692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2679}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2692}},{\"nodeType\":3,\"id\":2694,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2693},\"parentNode\":{\"id\":2692}},{\"nodeType\":1,\"id\":2695,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2680}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2695}},{\"nodeType\":3,\"id\":2697,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2696},\"parentNode\":{\"id\":2695}},{\"nodeType\":1,\"id\":2698,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2699,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2698}},{\"nodeType\":3,\"id\":2700,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2699},\"parentNode\":{\"id\":2698}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2682}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":3,\"id\":2703,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2704,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2683}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2704}},{\"nodeType\":3,\"id\":2706,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2705},\"parentNode\":{\"id\":2704}},{\"nodeType\":3,\"id\":2707,\"textContent\":\"*\",\"parentNode\":{\"id\":2685}},{\"nodeType\":1,\"id\":2708,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2708},\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2709},\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2711,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2622}},{\"nodeType\":3,\"id\":2712,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2708}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2712},\"parentNode\":{\"id\":2708}},{\"nodeType\":1,\"id\":2714,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2715,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2714}},{\"nodeType\":3,\"id\":2716,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2715},\"parentNode\":{\"id\":2714}},{\"nodeType\":1,\"id\":2717,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2710}},{\"nodeType\":1,\"id\":2718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2717}},{\"nodeType\":3,\"id\":2719,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2717}},{\"nodeType\":1,\"id\":2720,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2711}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2720}},{\"nodeType\":3,\"id\":2722,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2720}},{\"nodeType\":3,\"id\":2723,\"textContent\":\"*\",\"parentNode\":{\"id\":2713}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2617},{\"id\":2618},{\"id\":2619},{\"id\":2624},{\"id\":2629},{\"id\":2630},{\"id\":2643},{\"id\":2625},{\"id\":2631},{\"id\":2632},{\"id\":2633},{\"id\":2626},{\"id\":2634},{\"id\":2635},{\"id\":2636},{\"id\":2627},{\"id\":2637},{\"id\":2638},{\"id\":2639},{\"id\":2628},{\"id\":2640},{\"id\":2641},{\"id\":2642},{\"id\":2620},{\"id\":2644},{\"id\":2652},{\"id\":2653},{\"id\":2675},{\"id\":2645},{\"id\":2654},{\"id\":2655},{\"id\":2656},{\"id\":2646},{\"id\":2657},{\"id\":2658},{\"id\":2659},{\"id\":2647},{\"id\":2660},{\"id\":2661},{\"id\":2662},{\"id\":2648},{\"id\":2663},{\"id\":2664},{\"id\":2665},{\"id\":2649},{\"id\":2666},{\"id\":2667},{\"id\":2668},{\"id\":2650},{\"id\":2669},{\"id\":2670},{\"id\":2671},{\"id\":2651},{\"id\":2672},{\"id\":2673},{\"id\":2674},{\"id\":2621},{\"id\":2676},{\"id\":2684},{\"id\":2685},{\"id\":2707},{\"id\":2677},{\"id\":2686},{\"id\":2687},{\"id\":2688},{\"id\":2678},{\"id\":2689},{\"id\":2690},{\"id\":2691},{\"id\":2679},{\"id\":2692},{\"id\":2693},{\"id\":2694},{\"id\":2680},{\"id\":2695},{\"id\":2696},{\"id\":2697},{\"id\":2681},{\"id\":2698},{\"id\":2699},{\"id\":2700},{\"id\":2682},{\"id\":2701},{\"id\":2702},{\"id\":2703},{\"id\":2683},{\"id\":2704},{\"id\":2705},{\"id\":2706},{\"id\":2622},{\"id\":2708},{\"id\":2712},{\"id\":2713},{\"id\":2723},{\"id\":2709},{\"id\":2714},{\"id\":2715},{\"id\":2716},{\"id\":2710},{\"id\":2717},{\"id\":2718},{\"id\":2719},{\"id\":2711},{\"id\":2720},{\"id\":2721},{\"id\":2722},{\"id\":2623}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2724,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"previousSibling\":{\"id\":2724},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2726,\"textContent\":\" \",\"parentNode\":{\"id\":2724}},{\"nodeType\":1,\"id\":2727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"previousSibling\":{\"id\":2727},\"parentNode\":{\"id\":2724}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2724}},{\"nodeType\":1,\"id\":2731,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2730},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"previousSibling\":{\"id\":2731},\"parentNode\":{\"id\":2724}},{\"nodeType\":3,\"id\":2733,\"textContent\":\" \",\"parentNode\":{\"id\":2727}},{\"nodeType\":1,\"id\":2734,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2727}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"previousSibling\":{\"id\":2734},\"parentNode\":{\"id\":2727}},{\"nodeType\":3,\"id\":2736,\"textContent\":\" \",\"parentNode\":{\"id\":2734}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2734}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2734}},{\"nodeType\":3,\"id\":2739,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"parentNode\":{\"id\":2729}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2743,\"textContent\":\" \",\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2744,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2747,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2746},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"previousSibling\":{\"id\":2747},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" \",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2751,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2750},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"previousSibling\":{\"id\":2751},\"parentNode\":{\"id\":2741}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2744}},{\"nodeType\":3,\"id\":2756,\"textContent\":\" \",\"parentNode\":{\"id\":2745}},{\"nodeType\":1,\"id\":2757,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2758,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2757},\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2757}},{\"nodeType\":3,\"id\":2760,\"textContent\":\" \",\"parentNode\":{\"id\":2747}},{\"nodeType\":1,\"id\":2761,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2760},\"parentNode\":{\"id\":2747}},{\"nodeType\":3,\"id\":2762,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2747}},{\"nodeType\":3,\"id\":2763,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2761}},{\"nodeType\":1,\"id\":2764,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2765,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2764},\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2764}},{\"nodeType\":3,\"id\":2767,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2751}},{\"nodeType\":3,\"id\":2768,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2753}},{\"nodeType\":3,\"id\":2769,\"textContent\":\" \",\"parentNode\":{\"id\":2731}},{\"nodeType\":1,\"id\":2770,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2769},\"parentNode\":{\"id\":2731}},{\"nodeType\":3,\"id\":2771,\"textContent\":\" \",\"previousSibling\":{\"id\":2770},\"parentNode\":{\"id\":2731}},{\"nodeType\":3,\"id\":2772,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2770}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2724},{\"id\":2726},{\"id\":2727},{\"id\":2733},{\"id\":2734},{\"id\":2736},{\"id\":2737},{\"id\":2739},{\"id\":2738},{\"id\":2735},{\"id\":2728},{\"id\":2729},{\"id\":2740},{\"id\":2741},{\"id\":2743},{\"id\":2744},{\"id\":2755},{\"id\":2745},{\"id\":2756},{\"id\":2757},{\"id\":2759},{\"id\":2758},{\"id\":2746},{\"id\":2747},{\"id\":2760},{\"id\":2761},{\"id\":2763},{\"id\":2762},{\"id\":2748},{\"id\":2749},{\"id\":2764},{\"id\":2766},{\"id\":2765},{\"id\":2750},{\"id\":2751},{\"id\":2767},{\"id\":2752},{\"id\":2753},{\"id\":2768},{\"id\":2754},{\"id\":2742},{\"id\":2730},{\"id\":2731},{\"id\":2769},{\"id\":2770},{\"id\":2772},{\"id\":2771},{\"id\":2732},{\"id\":2725}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2773,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2774,\"textContent\":\"[ { \\\"rt\\\": 120740, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 120747, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"93XU7\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 7099, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 129196, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"93XU7\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 28734, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"tango\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"113\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 158939, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"93XU7\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 17270, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 177299, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"93XU7\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 11853, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 190154, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"93XU7\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 51956, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 243469, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"93XU7\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 4, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"C\\\", \\\"A\\\", \\\"U\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-03 PM-10 AM-Z -11 AM-11 AM-11 AM-11 AM-11 AM-A -A -A -1\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1144,y:746,t:1527635172540};\\\", \\\"{x:1131,y:739,t:1527635172547};\\\", \\\"{x:1112,y:727,t:1527635172561};\\\", \\\"{x:1032,y:689,t:1527635172576};\\\", \\\"{x:923,y:632,t:1527635172594};\\\", \\\"{x:798,y:572,t:1527635172611};\\\", \\\"{x:702,y:532,t:1527635172627};\\\", \\\"{x:613,y:498,t:1527635172644};\\\", \\\"{x:602,y:493,t:1527635172660};\\\", \\\"{x:601,y:492,t:1527635172677};\\\", \\\"{x:600,y:492,t:1527635172715};\\\", \\\"{x:599,y:492,t:1527635172740};\\\", \\\"{x:597,y:492,t:1527635172747};\\\", \\\"{x:593,y:495,t:1527635172760};\\\", \\\"{x:325,y:717,t:1527635172863};\\\", \\\"{x:319,y:728,t:1527635172878};\\\", \\\"{x:318,y:735,t:1527635172894};\\\", \\\"{x:318,y:745,t:1527635172911};\\\", \\\"{x:337,y:772,t:1527635172928};\\\", \\\"{x:367,y:824,t:1527635172943};\\\", \\\"{x:380,y:851,t:1527635172960};\\\", \\\"{x:383,y:851,t:1527635172978};\\\", \\\"{x:383,y:850,t:1527635173573};\\\", \\\"{x:383,y:846,t:1527635173580};\\\", \\\"{x:383,y:843,t:1527635173596};\\\", \\\"{x:380,y:838,t:1527635173611};\\\", \\\"{x:379,y:831,t:1527635173628};\\\", \\\"{x:378,y:827,t:1527635173645};\\\", \\\"{x:376,y:822,t:1527635173662};\\\", \\\"{x:375,y:816,t:1527635173678};\\\", \\\"{x:373,y:810,t:1527635173695};\\\", \\\"{x:371,y:801,t:1527635173712};\\\", \\\"{x:367,y:790,t:1527635173728};\\\", \\\"{x:362,y:778,t:1527635173745};\\\", \\\"{x:357,y:764,t:1527635173761};\\\", \\\"{x:353,y:748,t:1527635173778};\\\", \\\"{x:346,y:725,t:1527635173795};\\\", \\\"{x:344,y:716,t:1527635173811};\\\", \\\"{x:343,y:715,t:1527635173828};\\\", \\\"{x:345,y:715,t:1527635173948};\\\", \\\"{x:348,y:721,t:1527635173980};\\\", \\\"{x:353,y:731,t:1527635173996};\\\", \\\"{x:355,y:737,t:1527635174012};\\\", \\\"{x:357,y:738,t:1527635174773};\\\", \\\"{x:362,y:740,t:1527635174780};\\\", \\\"{x:372,y:741,t:1527635174796};\\\", \\\"{x:405,y:749,t:1527635174812};\\\", \\\"{x:433,y:757,t:1527635174829};\\\", \\\"{x:474,y:767,t:1527635174846};\\\", \\\"{x:525,y:781,t:1527635174863};\\\", \\\"{x:597,y:801,t:1527635174878};\\\", \\\"{x:691,y:812,t:1527635174896};\\\", \\\"{x:794,y:832,t:1527635174913};\\\", \\\"{x:915,y:861,t:1527635174929};\\\", \\\"{x:1034,y:890,t:1527635174946};\\\", \\\"{x:1165,y:920,t:1527635174962};\\\", \\\"{x:1285,y:943,t:1527635174979};\\\", \\\"{x:1391,y:961,t:1527635174996};\\\", \\\"{x:1501,y:977,t:1527635175013};\\\", \\\"{x:1535,y:981,t:1527635175031};\\\", \\\"{x:1545,y:984,t:1527635175045};\\\", \\\"{x:1548,y:984,t:1527635175062};\\\", \\\"{x:1548,y:983,t:1527635175188};\\\", \\\"{x:1548,y:981,t:1527635175196};\\\", \\\"{x:1533,y:973,t:1527635175212};\\\", \\\"{x:1502,y:964,t:1527635175230};\\\", \\\"{x:1460,y:956,t:1527635175245};\\\", \\\"{x:1411,y:954,t:1527635175262};\\\", \\\"{x:1350,y:954,t:1527635175279};\\\", \\\"{x:1288,y:954,t:1527635175295};\\\", \\\"{x:1256,y:954,t:1527635175312};\\\", \\\"{x:1236,y:954,t:1527635175329};\\\", \\\"{x:1226,y:954,t:1527635175345};\\\", \\\"{x:1223,y:954,t:1527635175362};\\\", \\\"{x:1221,y:954,t:1527635175379};\\\", \\\"{x:1220,y:954,t:1527635175412};\\\", \\\"{x:1219,y:954,t:1527635175429};\\\", \\\"{x:1219,y:955,t:1527635175446};\\\", \\\"{x:1216,y:956,t:1527635175463};\\\", \\\"{x:1214,y:958,t:1527635175480};\\\", \\\"{x:1213,y:959,t:1527635175495};\\\", \\\"{x:1211,y:960,t:1527635175513};\\\", \\\"{x:1208,y:962,t:1527635175530};\\\", \\\"{x:1205,y:964,t:1527635175546};\\\", \\\"{x:1202,y:967,t:1527635175563};\\\", \\\"{x:1201,y:971,t:1527635175580};\\\", \\\"{x:1199,y:975,t:1527635175596};\\\", \\\"{x:1199,y:977,t:1527635175612};\\\", \\\"{x:1199,y:979,t:1527635175629};\\\", \\\"{x:1199,y:981,t:1527635175646};\\\", \\\"{x:1200,y:983,t:1527635175663};\\\", \\\"{x:1202,y:984,t:1527635175679};\\\", \\\"{x:1205,y:984,t:1527635175696};\\\", \\\"{x:1210,y:984,t:1527635175712};\\\", \\\"{x:1216,y:984,t:1527635175728};\\\", \\\"{x:1221,y:984,t:1527635175746};\\\", \\\"{x:1226,y:984,t:1527635175762};\\\", \\\"{x:1230,y:982,t:1527635175778};\\\", \\\"{x:1235,y:977,t:1527635175795};\\\", \\\"{x:1237,y:975,t:1527635175813};\\\", \\\"{x:1239,y:973,t:1527635175829};\\\", \\\"{x:1242,y:970,t:1527635175846};\\\", \\\"{x:1246,y:968,t:1527635175862};\\\", \\\"{x:1249,y:967,t:1527635175880};\\\", \\\"{x:1253,y:966,t:1527635175896};\\\", \\\"{x:1262,y:966,t:1527635175912};\\\", \\\"{x:1278,y:966,t:1527635175929};\\\", \\\"{x:1297,y:966,t:1527635175947};\\\", \\\"{x:1318,y:966,t:1527635175962};\\\", \\\"{x:1333,y:966,t:1527635175979};\\\", \\\"{x:1344,y:966,t:1527635175997};\\\", \\\"{x:1345,y:966,t:1527635176013};\\\", \\\"{x:1343,y:966,t:1527635176092};\\\", \\\"{x:1336,y:966,t:1527635176100};\\\", \\\"{x:1330,y:966,t:1527635176112};\\\", \\\"{x:1316,y:966,t:1527635176130};\\\", \\\"{x:1302,y:966,t:1527635176146};\\\", \\\"{x:1288,y:966,t:1527635176162};\\\", \\\"{x:1274,y:965,t:1527635176179};\\\", \\\"{x:1269,y:963,t:1527635176195};\\\", \\\"{x:1268,y:963,t:1527635176212};\\\", \\\"{x:1268,y:962,t:1527635176549};\\\", \\\"{x:1268,y:960,t:1527635176563};\\\", \\\"{x:1271,y:955,t:1527635176579};\\\", \\\"{x:1275,y:949,t:1527635176596};\\\", \\\"{x:1278,y:945,t:1527635176614};\\\", \\\"{x:1280,y:939,t:1527635176630};\\\", \\\"{x:1283,y:936,t:1527635176647};\\\", \\\"{x:1283,y:934,t:1527635176664};\\\", \\\"{x:1285,y:932,t:1527635176679};\\\", \\\"{x:1286,y:930,t:1527635176697};\\\", \\\"{x:1287,y:928,t:1527635176713};\\\", \\\"{x:1289,y:926,t:1527635176730};\\\", \\\"{x:1290,y:924,t:1527635176746};\\\", \\\"{x:1292,y:921,t:1527635176763};\\\", \\\"{x:1295,y:915,t:1527635176779};\\\", \\\"{x:1297,y:910,t:1527635176796};\\\", \\\"{x:1301,y:901,t:1527635176813};\\\", \\\"{x:1305,y:892,t:1527635176829};\\\", \\\"{x:1310,y:880,t:1527635176846};\\\", \\\"{x:1315,y:869,t:1527635176863};\\\", \\\"{x:1320,y:859,t:1527635176879};\\\", \\\"{x:1324,y:847,t:1527635176897};\\\", \\\"{x:1328,y:830,t:1527635176914};\\\", \\\"{x:1335,y:813,t:1527635176930};\\\", \\\"{x:1340,y:795,t:1527635176946};\\\", \\\"{x:1346,y:781,t:1527635176964};\\\", \\\"{x:1351,y:772,t:1527635176980};\\\", \\\"{x:1353,y:767,t:1527635176996};\\\", \\\"{x:1355,y:764,t:1527635177013};\\\", \\\"{x:1357,y:761,t:1527635177030};\\\", \\\"{x:1360,y:758,t:1527635177047};\\\", \\\"{x:1361,y:756,t:1527635177064};\\\", \\\"{x:1363,y:754,t:1527635177081};\\\", \\\"{x:1364,y:752,t:1527635177097};\\\", \\\"{x:1365,y:756,t:1527635177157};\\\", \\\"{x:1368,y:763,t:1527635177164};\\\", \\\"{x:1368,y:789,t:1527635177180};\\\", \\\"{x:1367,y:819,t:1527635177196};\\\", \\\"{x:1360,y:846,t:1527635177213};\\\", \\\"{x:1354,y:870,t:1527635177230};\\\", \\\"{x:1346,y:887,t:1527635177246};\\\", \\\"{x:1339,y:903,t:1527635177265};\\\", \\\"{x:1335,y:911,t:1527635177281};\\\", \\\"{x:1331,y:917,t:1527635177296};\\\", \\\"{x:1330,y:919,t:1527635177314};\\\", \\\"{x:1328,y:921,t:1527635177331};\\\", \\\"{x:1327,y:921,t:1527635177346};\\\", \\\"{x:1327,y:922,t:1527635177364};\\\", \\\"{x:1326,y:922,t:1527635177413};\\\", \\\"{x:1321,y:923,t:1527635177431};\\\", \\\"{x:1318,y:923,t:1527635177447};\\\", \\\"{x:1308,y:928,t:1527635177464};\\\", \\\"{x:1296,y:934,t:1527635177481};\\\", \\\"{x:1285,y:943,t:1527635177497};\\\", \\\"{x:1276,y:956,t:1527635177514};\\\", \\\"{x:1267,y:973,t:1527635177531};\\\", \\\"{x:1263,y:985,t:1527635177547};\\\", \\\"{x:1262,y:992,t:1527635177564};\\\", \\\"{x:1262,y:994,t:1527635177581};\\\", \\\"{x:1262,y:992,t:1527635177669};\\\", \\\"{x:1262,y:988,t:1527635177681};\\\", \\\"{x:1265,y:978,t:1527635177697};\\\", \\\"{x:1270,y:968,t:1527635177715};\\\", \\\"{x:1275,y:960,t:1527635177731};\\\", \\\"{x:1278,y:956,t:1527635177747};\\\", \\\"{x:1280,y:951,t:1527635177765};\\\", \\\"{x:1281,y:951,t:1527635177844};\\\", \\\"{x:1282,y:952,t:1527635177852};\\\", \\\"{x:1284,y:958,t:1527635177864};\\\", \\\"{x:1286,y:965,t:1527635177881};\\\", \\\"{x:1286,y:972,t:1527635177899};\\\", \\\"{x:1287,y:974,t:1527635177914};\\\", \\\"{x:1287,y:975,t:1527635177930};\\\", \\\"{x:1288,y:973,t:1527635178043};\\\", \\\"{x:1288,y:970,t:1527635178052};\\\", \\\"{x:1288,y:968,t:1527635178064};\\\", \\\"{x:1288,y:963,t:1527635178080};\\\", \\\"{x:1288,y:961,t:1527635178097};\\\", \\\"{x:1288,y:958,t:1527635178113};\\\", \\\"{x:1288,y:957,t:1527635178293};\\\", \\\"{x:1287,y:957,t:1527635178316};\\\", \\\"{x:1286,y:957,t:1527635178332};\\\", \\\"{x:1285,y:957,t:1527635178347};\\\", \\\"{x:1284,y:957,t:1527635178939};\\\", \\\"{x:1283,y:957,t:1527635178947};\\\", \\\"{x:1282,y:957,t:1527635178964};\\\", \\\"{x:1281,y:957,t:1527635179011};\\\", \\\"{x:1281,y:958,t:1527635179052};\\\", \\\"{x:1281,y:959,t:1527635179126};\\\", \\\"{x:1281,y:960,t:1527635179356};\\\", \\\"{x:1281,y:962,t:1527635179396};\\\", \\\"{x:1281,y:964,t:1527635179436};\\\", \\\"{x:1281,y:965,t:1527635179453};\\\", \\\"{x:1279,y:965,t:1527635179653};\\\", \\\"{x:1279,y:963,t:1527635179665};\\\", \\\"{x:1278,y:961,t:1527635179683};\\\", \\\"{x:1278,y:958,t:1527635179698};\\\", \\\"{x:1275,y:954,t:1527635179715};\\\", \\\"{x:1273,y:947,t:1527635179733};\\\", \\\"{x:1272,y:944,t:1527635179749};\\\", \\\"{x:1271,y:942,t:1527635179765};\\\", \\\"{x:1271,y:940,t:1527635179782};\\\", \\\"{x:1270,y:937,t:1527635179798};\\\", \\\"{x:1269,y:935,t:1527635179815};\\\", \\\"{x:1269,y:934,t:1527635179832};\\\", \\\"{x:1269,y:933,t:1527635179848};\\\", \\\"{x:1269,y:931,t:1527635179865};\\\", \\\"{x:1269,y:930,t:1527635179882};\\\", \\\"{x:1269,y:928,t:1527635179898};\\\", \\\"{x:1269,y:927,t:1527635179915};\\\", \\\"{x:1269,y:924,t:1527635179932};\\\", \\\"{x:1272,y:919,t:1527635179949};\\\", \\\"{x:1273,y:916,t:1527635179965};\\\", \\\"{x:1274,y:911,t:1527635179982};\\\", \\\"{x:1276,y:910,t:1527635179999};\\\", \\\"{x:1276,y:908,t:1527635180015};\\\", \\\"{x:1276,y:907,t:1527635180109};\\\", \\\"{x:1276,y:906,t:1527635180132};\\\", \\\"{x:1276,y:904,t:1527635180261};\\\", \\\"{x:1276,y:903,t:1527635180268};\\\", \\\"{x:1276,y:902,t:1527635180282};\\\", \\\"{x:1276,y:898,t:1527635180299};\\\", \\\"{x:1276,y:896,t:1527635180315};\\\", \\\"{x:1276,y:893,t:1527635180332};\\\", \\\"{x:1276,y:892,t:1527635180356};\\\", \\\"{x:1276,y:891,t:1527635180365};\\\", \\\"{x:1276,y:890,t:1527635180382};\\\", \\\"{x:1276,y:889,t:1527635180398};\\\", \\\"{x:1276,y:887,t:1527635180415};\\\", \\\"{x:1276,y:886,t:1527635180432};\\\", \\\"{x:1276,y:885,t:1527635180449};\\\", \\\"{x:1276,y:883,t:1527635180465};\\\", \\\"{x:1276,y:882,t:1527635180482};\\\", \\\"{x:1276,y:881,t:1527635180498};\\\", \\\"{x:1276,y:879,t:1527635180515};\\\", \\\"{x:1276,y:877,t:1527635180532};\\\", \\\"{x:1276,y:874,t:1527635180548};\\\", \\\"{x:1276,y:872,t:1527635180565};\\\", \\\"{x:1276,y:871,t:1527635180581};\\\", \\\"{x:1276,y:869,t:1527635180598};\\\", \\\"{x:1275,y:867,t:1527635180620};\\\", \\\"{x:1275,y:866,t:1527635180635};\\\", \\\"{x:1275,y:865,t:1527635180675};\\\", \\\"{x:1275,y:863,t:1527635180707};\\\", \\\"{x:1274,y:863,t:1527635180724};\\\", \\\"{x:1274,y:862,t:1527635181259};\\\", \\\"{x:1273,y:860,t:1527635181283};\\\", \\\"{x:1273,y:859,t:1527635181323};\\\", \\\"{x:1273,y:858,t:1527635181339};\\\", \\\"{x:1273,y:857,t:1527635181356};\\\", \\\"{x:1273,y:856,t:1527635181387};\\\", \\\"{x:1273,y:855,t:1527635181419};\\\", \\\"{x:1273,y:854,t:1527635181451};\\\", \\\"{x:1273,y:853,t:1527635181556};\\\", \\\"{x:1273,y:852,t:1527635181589};\\\", \\\"{x:1273,y:854,t:1527635185004};\\\", \\\"{x:1272,y:861,t:1527635185017};\\\", \\\"{x:1272,y:867,t:1527635185034};\\\", \\\"{x:1272,y:873,t:1527635185051};\\\", \\\"{x:1271,y:880,t:1527635185068};\\\", \\\"{x:1271,y:888,t:1527635185084};\\\", \\\"{x:1271,y:896,t:1527635185101};\\\", \\\"{x:1273,y:905,t:1527635185118};\\\", \\\"{x:1273,y:912,t:1527635185134};\\\", \\\"{x:1273,y:917,t:1527635185151};\\\", \\\"{x:1273,y:919,t:1527635185169};\\\", \\\"{x:1273,y:923,t:1527635185184};\\\", \\\"{x:1273,y:928,t:1527635185201};\\\", \\\"{x:1273,y:933,t:1527635185218};\\\", \\\"{x:1273,y:937,t:1527635185234};\\\", \\\"{x:1272,y:941,t:1527635185251};\\\", \\\"{x:1272,y:946,t:1527635185268};\\\", \\\"{x:1272,y:949,t:1527635185284};\\\", \\\"{x:1272,y:951,t:1527635185302};\\\", \\\"{x:1272,y:953,t:1527635185318};\\\", \\\"{x:1272,y:954,t:1527635185340};\\\", \\\"{x:1272,y:955,t:1527635185380};\\\", \\\"{x:1272,y:956,t:1527635185388};\\\", \\\"{x:1273,y:956,t:1527635185588};\\\", \\\"{x:1274,y:955,t:1527635185604};\\\", \\\"{x:1275,y:953,t:1527635185619};\\\", \\\"{x:1277,y:949,t:1527635185635};\\\", \\\"{x:1280,y:945,t:1527635185651};\\\", \\\"{x:1281,y:942,t:1527635185668};\\\", \\\"{x:1282,y:938,t:1527635185684};\\\", \\\"{x:1283,y:935,t:1527635185701};\\\", \\\"{x:1285,y:931,t:1527635185719};\\\", \\\"{x:1287,y:927,t:1527635185734};\\\", \\\"{x:1288,y:923,t:1527635185751};\\\", \\\"{x:1288,y:922,t:1527635185768};\\\", \\\"{x:1288,y:921,t:1527635185786};\\\", \\\"{x:1290,y:919,t:1527635185802};\\\", \\\"{x:1290,y:918,t:1527635185818};\\\", \\\"{x:1290,y:917,t:1527635185836};\\\", \\\"{x:1290,y:916,t:1527635185868};\\\", \\\"{x:1290,y:918,t:1527635185997};\\\", \\\"{x:1290,y:921,t:1527635186004};\\\", \\\"{x:1290,y:924,t:1527635186018};\\\", \\\"{x:1289,y:928,t:1527635186035};\\\", \\\"{x:1287,y:932,t:1527635186051};\\\", \\\"{x:1287,y:933,t:1527635186068};\\\", \\\"{x:1286,y:934,t:1527635186092};\\\", \\\"{x:1286,y:935,t:1527635186117};\\\", \\\"{x:1286,y:936,t:1527635186148};\\\", \\\"{x:1285,y:939,t:1527635186181};\\\", \\\"{x:1284,y:939,t:1527635186188};\\\", \\\"{x:1284,y:940,t:1527635186202};\\\", \\\"{x:1282,y:942,t:1527635186219};\\\", \\\"{x:1280,y:945,t:1527635186235};\\\", \\\"{x:1278,y:949,t:1527635186251};\\\", \\\"{x:1276,y:951,t:1527635186269};\\\", \\\"{x:1276,y:953,t:1527635186285};\\\", \\\"{x:1274,y:956,t:1527635186301};\\\", \\\"{x:1272,y:958,t:1527635186318};\\\", \\\"{x:1272,y:959,t:1527635186335};\\\", \\\"{x:1272,y:961,t:1527635186351};\\\", \\\"{x:1271,y:962,t:1527635186368};\\\", \\\"{x:1270,y:962,t:1527635186701};\\\", \\\"{x:1270,y:960,t:1527635187349};\\\", \\\"{x:1270,y:959,t:1527635187389};\\\", \\\"{x:1270,y:957,t:1527635187668};\\\", \\\"{x:1269,y:955,t:1527635187685};\\\", \\\"{x:1269,y:953,t:1527635187702};\\\", \\\"{x:1267,y:949,t:1527635187720};\\\", \\\"{x:1267,y:947,t:1527635187734};\\\", \\\"{x:1266,y:946,t:1527635187752};\\\", \\\"{x:1265,y:945,t:1527635187768};\\\", \\\"{x:1264,y:942,t:1527635187784};\\\", \\\"{x:1262,y:939,t:1527635187801};\\\", \\\"{x:1260,y:933,t:1527635187819};\\\", \\\"{x:1258,y:928,t:1527635187834};\\\", \\\"{x:1255,y:921,t:1527635187851};\\\", \\\"{x:1252,y:914,t:1527635187868};\\\", \\\"{x:1248,y:909,t:1527635187885};\\\", \\\"{x:1244,y:903,t:1527635187901};\\\", \\\"{x:1239,y:898,t:1527635187919};\\\", \\\"{x:1236,y:895,t:1527635187935};\\\", \\\"{x:1234,y:894,t:1527635187952};\\\", \\\"{x:1231,y:891,t:1527635187969};\\\", \\\"{x:1227,y:889,t:1527635187986};\\\", \\\"{x:1219,y:886,t:1527635188002};\\\", \\\"{x:1205,y:880,t:1527635188019};\\\", \\\"{x:1171,y:871,t:1527635188036};\\\", \\\"{x:1136,y:866,t:1527635188051};\\\", \\\"{x:1096,y:854,t:1527635188069};\\\", \\\"{x:1090,y:848,t:1527635188086};\\\", \\\"{x:1090,y:847,t:1527635189412};\\\", \\\"{x:1090,y:846,t:1527635189436};\\\", \\\"{x:1090,y:845,t:1527635189476};\\\", \\\"{x:1091,y:845,t:1527635189500};\\\", \\\"{x:1093,y:844,t:1527635189588};\\\", \\\"{x:1094,y:844,t:1527635189612};\\\", \\\"{x:1095,y:844,t:1527635189620};\\\", \\\"{x:1096,y:844,t:1527635189700};\\\", \\\"{x:1097,y:844,t:1527635189724};\\\", \\\"{x:1098,y:844,t:1527635189797};\\\", \\\"{x:1100,y:844,t:1527635189804};\\\", \\\"{x:1118,y:846,t:1527635189820};\\\", \\\"{x:1168,y:858,t:1527635189836};\\\", \\\"{x:1247,y:871,t:1527635189853};\\\", \\\"{x:1335,y:882,t:1527635189870};\\\", \\\"{x:1414,y:897,t:1527635189886};\\\", \\\"{x:1481,y:905,t:1527635189903};\\\", \\\"{x:1533,y:917,t:1527635189920};\\\", \\\"{x:1555,y:923,t:1527635189937};\\\", \\\"{x:1561,y:927,t:1527635189953};\\\", \\\"{x:1560,y:928,t:1527635189997};\\\", \\\"{x:1557,y:929,t:1527635190004};\\\", \\\"{x:1550,y:931,t:1527635190020};\\\", \\\"{x:1544,y:933,t:1527635190036};\\\", \\\"{x:1536,y:935,t:1527635190053};\\\", \\\"{x:1524,y:937,t:1527635190070};\\\", \\\"{x:1509,y:939,t:1527635190086};\\\", \\\"{x:1491,y:940,t:1527635190103};\\\", \\\"{x:1472,y:940,t:1527635190121};\\\", \\\"{x:1448,y:940,t:1527635190138};\\\", \\\"{x:1428,y:940,t:1527635190154};\\\", \\\"{x:1408,y:940,t:1527635190171};\\\", \\\"{x:1388,y:940,t:1527635190188};\\\", \\\"{x:1370,y:939,t:1527635190203};\\\", \\\"{x:1347,y:938,t:1527635190220};\\\", \\\"{x:1330,y:938,t:1527635190237};\\\", \\\"{x:1312,y:938,t:1527635190253};\\\", \\\"{x:1303,y:938,t:1527635190271};\\\", \\\"{x:1298,y:937,t:1527635190287};\\\", \\\"{x:1296,y:937,t:1527635190303};\\\", \\\"{x:1295,y:937,t:1527635190320};\\\", \\\"{x:1294,y:937,t:1527635190356};\\\", \\\"{x:1292,y:937,t:1527635190370};\\\", \\\"{x:1289,y:937,t:1527635190387};\\\", \\\"{x:1285,y:937,t:1527635190404};\\\", \\\"{x:1278,y:938,t:1527635190420};\\\", \\\"{x:1275,y:938,t:1527635190437};\\\", \\\"{x:1271,y:938,t:1527635190453};\\\", \\\"{x:1266,y:939,t:1527635190470};\\\", \\\"{x:1263,y:941,t:1527635190487};\\\", \\\"{x:1258,y:942,t:1527635190504};\\\", \\\"{x:1254,y:945,t:1527635190520};\\\", \\\"{x:1252,y:948,t:1527635190538};\\\", \\\"{x:1250,y:952,t:1527635190553};\\\", \\\"{x:1250,y:955,t:1527635190570};\\\", \\\"{x:1250,y:960,t:1527635190588};\\\", \\\"{x:1250,y:967,t:1527635190603};\\\", \\\"{x:1250,y:974,t:1527635190620};\\\", \\\"{x:1252,y:977,t:1527635190637};\\\", \\\"{x:1253,y:977,t:1527635190660};\\\", \\\"{x:1254,y:977,t:1527635190708};\\\", \\\"{x:1255,y:977,t:1527635190720};\\\", \\\"{x:1259,y:977,t:1527635190738};\\\", \\\"{x:1265,y:974,t:1527635190753};\\\", \\\"{x:1271,y:969,t:1527635190770};\\\", \\\"{x:1278,y:965,t:1527635190788};\\\", \\\"{x:1285,y:962,t:1527635190803};\\\", \\\"{x:1290,y:960,t:1527635190820};\\\", \\\"{x:1292,y:960,t:1527635190838};\\\", \\\"{x:1292,y:961,t:1527635190956};\\\", \\\"{x:1292,y:962,t:1527635190971};\\\", \\\"{x:1292,y:965,t:1527635190987};\\\", \\\"{x:1292,y:967,t:1527635191005};\\\", \\\"{x:1292,y:968,t:1527635191021};\\\", \\\"{x:1291,y:969,t:1527635191038};\\\", \\\"{x:1291,y:970,t:1527635191054};\\\", \\\"{x:1290,y:970,t:1527635191205};\\\", \\\"{x:1289,y:970,t:1527635191260};\\\", \\\"{x:1288,y:970,t:1527635191284};\\\", \\\"{x:1288,y:969,t:1527635191341};\\\", \\\"{x:1287,y:968,t:1527635191380};\\\", \\\"{x:1287,y:967,t:1527635191428};\\\", \\\"{x:1287,y:965,t:1527635191452};\\\", \\\"{x:1287,y:964,t:1527635191508};\\\", \\\"{x:1287,y:962,t:1527635191548};\\\", \\\"{x:1287,y:961,t:1527635191589};\\\", \\\"{x:1287,y:960,t:1527635191732};\\\", \\\"{x:1286,y:960,t:1527635191756};\\\", \\\"{x:1285,y:959,t:1527635191772};\\\", \\\"{x:1285,y:958,t:1527635194316};\\\", \\\"{x:1285,y:956,t:1527635194332};\\\", \\\"{x:1285,y:954,t:1527635194340};\\\", \\\"{x:1285,y:953,t:1527635194356};\\\", \\\"{x:1285,y:952,t:1527635194371};\\\", \\\"{x:1285,y:951,t:1527635194388};\\\", \\\"{x:1284,y:949,t:1527635194406};\\\", \\\"{x:1284,y:948,t:1527635194436};\\\", \\\"{x:1284,y:946,t:1527635194444};\\\", \\\"{x:1284,y:945,t:1527635194460};\\\", \\\"{x:1284,y:944,t:1527635194472};\\\", \\\"{x:1284,y:943,t:1527635194490};\\\", \\\"{x:1284,y:941,t:1527635194505};\\\", \\\"{x:1284,y:939,t:1527635194523};\\\", \\\"{x:1282,y:936,t:1527635194540};\\\", \\\"{x:1282,y:934,t:1527635194556};\\\", \\\"{x:1282,y:933,t:1527635194572};\\\", \\\"{x:1282,y:931,t:1527635194589};\\\", \\\"{x:1282,y:930,t:1527635194605};\\\", \\\"{x:1282,y:928,t:1527635194623};\\\", \\\"{x:1282,y:927,t:1527635194640};\\\", \\\"{x:1282,y:925,t:1527635194668};\\\", \\\"{x:1282,y:924,t:1527635194693};\\\", \\\"{x:1282,y:922,t:1527635194716};\\\", \\\"{x:1282,y:921,t:1527635194732};\\\", \\\"{x:1282,y:919,t:1527635194748};\\\", \\\"{x:1282,y:918,t:1527635194756};\\\", \\\"{x:1282,y:915,t:1527635194772};\\\", \\\"{x:1282,y:912,t:1527635194790};\\\", \\\"{x:1282,y:911,t:1527635194806};\\\", \\\"{x:1282,y:909,t:1527635194822};\\\", \\\"{x:1282,y:908,t:1527635194839};\\\", \\\"{x:1282,y:907,t:1527635194860};\\\", \\\"{x:1282,y:906,t:1527635194892};\\\", \\\"{x:1281,y:905,t:1527635194980};\\\", \\\"{x:1281,y:904,t:1527635195012};\\\", \\\"{x:1281,y:903,t:1527635195029};\\\", \\\"{x:1281,y:902,t:1527635195077};\\\", \\\"{x:1281,y:901,t:1527635195100};\\\", \\\"{x:1281,y:900,t:1527635195116};\\\", \\\"{x:1281,y:899,t:1527635195148};\\\", \\\"{x:1281,y:898,t:1527635195155};\\\", \\\"{x:1281,y:897,t:1527635195172};\\\", \\\"{x:1281,y:896,t:1527635195197};\\\", \\\"{x:1281,y:895,t:1527635195212};\\\", \\\"{x:1281,y:894,t:1527635195223};\\\", \\\"{x:1281,y:893,t:1527635195244};\\\", \\\"{x:1281,y:892,t:1527635195255};\\\", \\\"{x:1281,y:891,t:1527635195273};\\\", \\\"{x:1281,y:890,t:1527635195290};\\\", \\\"{x:1281,y:889,t:1527635195306};\\\", \\\"{x:1280,y:888,t:1527635195348};\\\", \\\"{x:1280,y:887,t:1527635195797};\\\", \\\"{x:1280,y:885,t:1527635197292};\\\", \\\"{x:1280,y:884,t:1527635197306};\\\", \\\"{x:1280,y:876,t:1527635197324};\\\", \\\"{x:1280,y:871,t:1527635197340};\\\", \\\"{x:1280,y:866,t:1527635197356};\\\", \\\"{x:1280,y:863,t:1527635197373};\\\", \\\"{x:1280,y:859,t:1527635197391};\\\", \\\"{x:1278,y:855,t:1527635197408};\\\", \\\"{x:1277,y:852,t:1527635197424};\\\", \\\"{x:1277,y:850,t:1527635197441};\\\", \\\"{x:1277,y:848,t:1527635197457};\\\", \\\"{x:1276,y:846,t:1527635197473};\\\", \\\"{x:1275,y:845,t:1527635197490};\\\", \\\"{x:1275,y:843,t:1527635197516};\\\", \\\"{x:1275,y:842,t:1527635197589};\\\", \\\"{x:1275,y:840,t:1527635197653};\\\", \\\"{x:1275,y:839,t:1527635197676};\\\", \\\"{x:1275,y:837,t:1527635197692};\\\", \\\"{x:1275,y:836,t:1527635197707};\\\", \\\"{x:1275,y:834,t:1527635197724};\\\", \\\"{x:1276,y:833,t:1527635197740};\\\", \\\"{x:1276,y:831,t:1527635197760};\\\", \\\"{x:1276,y:830,t:1527635197773};\\\", \\\"{x:1278,y:828,t:1527635197789};\\\", \\\"{x:1278,y:826,t:1527635197807};\\\", \\\"{x:1279,y:825,t:1527635197834};\\\", \\\"{x:1279,y:824,t:1527635197875};\\\", \\\"{x:1280,y:826,t:1527635198173};\\\", \\\"{x:1281,y:832,t:1527635198190};\\\", \\\"{x:1284,y:841,t:1527635198209};\\\", \\\"{x:1288,y:849,t:1527635198225};\\\", \\\"{x:1291,y:858,t:1527635198241};\\\", \\\"{x:1295,y:869,t:1527635198258};\\\", \\\"{x:1298,y:882,t:1527635198275};\\\", \\\"{x:1301,y:896,t:1527635198291};\\\", \\\"{x:1301,y:912,t:1527635198308};\\\", \\\"{x:1299,y:918,t:1527635198324};\\\", \\\"{x:1290,y:926,t:1527635198341};\\\", \\\"{x:1280,y:929,t:1527635198357};\\\", \\\"{x:1262,y:930,t:1527635198375};\\\", \\\"{x:1238,y:924,t:1527635198390};\\\", \\\"{x:1204,y:907,t:1527635198408};\\\", \\\"{x:1152,y:875,t:1527635198424};\\\", \\\"{x:1075,y:829,t:1527635198440};\\\", \\\"{x:985,y:777,t:1527635198458};\\\", \\\"{x:900,y:728,t:1527635198475};\\\", \\\"{x:818,y:677,t:1527635198491};\\\", \\\"{x:690,y:610,t:1527635198509};\\\", \\\"{x:583,y:569,t:1527635198525};\\\", \\\"{x:470,y:536,t:1527635198541};\\\", \\\"{x:288,y:505,t:1527635198566};\\\", \\\"{x:168,y:486,t:1527635198582};\\\", \\\"{x:54,y:484,t:1527635198598};\\\", \\\"{x:0,y:484,t:1527635198615};\\\", \\\"{x:0,y:486,t:1527635198650};\\\", \\\"{x:0,y:488,t:1527635198665};\\\", \\\"{x:0,y:490,t:1527635198682};\\\", \\\"{x:4,y:490,t:1527635198748};\\\", \\\"{x:13,y:487,t:1527635198755};\\\", \\\"{x:24,y:485,t:1527635198765};\\\", \\\"{x:55,y:482,t:1527635198780};\\\", \\\"{x:97,y:482,t:1527635198798};\\\", \\\"{x:159,y:482,t:1527635198815};\\\", \\\"{x:223,y:489,t:1527635198831};\\\", \\\"{x:292,y:509,t:1527635198849};\\\", \\\"{x:346,y:527,t:1527635198865};\\\", \\\"{x:390,y:545,t:1527635198883};\\\", \\\"{x:417,y:557,t:1527635198898};\\\", \\\"{x:438,y:566,t:1527635198915};\\\", \\\"{x:440,y:567,t:1527635198932};\\\", \\\"{x:438,y:567,t:1527635199019};\\\", \\\"{x:434,y:567,t:1527635199032};\\\", \\\"{x:419,y:567,t:1527635199049};\\\", \\\"{x:400,y:561,t:1527635199065};\\\", \\\"{x:379,y:553,t:1527635199082};\\\", \\\"{x:352,y:542,t:1527635199100};\\\", \\\"{x:341,y:536,t:1527635199116};\\\", \\\"{x:336,y:535,t:1527635199132};\\\", \\\"{x:333,y:533,t:1527635199149};\\\", \\\"{x:333,y:530,t:1527635199166};\\\", \\\"{x:333,y:526,t:1527635199182};\\\", \\\"{x:333,y:525,t:1527635199199};\\\", \\\"{x:337,y:522,t:1527635199216};\\\", \\\"{x:345,y:521,t:1527635199232};\\\", \\\"{x:354,y:519,t:1527635199249};\\\", \\\"{x:369,y:519,t:1527635199266};\\\", \\\"{x:380,y:519,t:1527635199282};\\\", \\\"{x:389,y:519,t:1527635199298};\\\", \\\"{x:391,y:519,t:1527635199316};\\\", \\\"{x:392,y:519,t:1527635199339};\\\", \\\"{x:392,y:520,t:1527635199349};\\\", \\\"{x:394,y:520,t:1527635199365};\\\", \\\"{x:395,y:521,t:1527635199382};\\\", \\\"{x:397,y:522,t:1527635199403};\\\", \\\"{x:398,y:522,t:1527635199434};\\\", \\\"{x:398,y:522,t:1527635199552};\\\", \\\"{x:399,y:523,t:1527635199675};\\\", \\\"{x:399,y:526,t:1527635199683};\\\", \\\"{x:407,y:537,t:1527635199700};\\\", \\\"{x:418,y:545,t:1527635199716};\\\", \\\"{x:435,y:555,t:1527635199733};\\\", \\\"{x:454,y:564,t:1527635199749};\\\", \\\"{x:489,y:579,t:1527635199766};\\\", \\\"{x:532,y:592,t:1527635199783};\\\", \\\"{x:574,y:605,t:1527635199799};\\\", \\\"{x:614,y:618,t:1527635199816};\\\", \\\"{x:640,y:625,t:1527635199834};\\\", \\\"{x:665,y:635,t:1527635199849};\\\", \\\"{x:691,y:647,t:1527635199866};\\\", \\\"{x:717,y:659,t:1527635199883};\\\", \\\"{x:736,y:671,t:1527635199899};\\\", \\\"{x:759,y:689,t:1527635199916};\\\", \\\"{x:786,y:711,t:1527635199933};\\\", \\\"{x:802,y:726,t:1527635199950};\\\", \\\"{x:802,y:729,t:1527635199966};\\\", \\\"{x:804,y:729,t:1527635200901};\\\", \\\"{x:805,y:729,t:1527635200926};\\\", \\\"{x:806,y:728,t:1527635200955};\\\", \\\"{x:808,y:728,t:1527635200972};\\\", \\\"{x:808,y:727,t:1527635200986};\\\", \\\"{x:809,y:727,t:1527635200999};\\\", \\\"{x:810,y:725,t:1527635201017};\\\", \\\"{x:812,y:725,t:1527635201067};\\\", \\\"{x:812,y:724,t:1527635201301};\\\", \\\"{x:813,y:722,t:1527635201318};\\\", \\\"{x:814,y:722,t:1527635201335};\\\", \\\"{x:815,y:721,t:1527635201352};\\\", \\\"{x:815,y:720,t:1527635201444};\\\", \\\"{x:816,y:719,t:1527635201460};\\\", \\\"{x:814,y:720,t:1527635203900};\\\", \\\"{x:813,y:720,t:1527635203908};\\\", \\\"{x:811,y:721,t:1527635203920};\\\", \\\"{x:805,y:722,t:1527635203935};\\\", \\\"{x:801,y:724,t:1527635203953};\\\", \\\"{x:800,y:724,t:1527635203969};\\\", \\\"{x:798,y:724,t:1527635203986};\\\", \\\"{x:795,y:726,t:1527635204003};\\\", \\\"{x:794,y:727,t:1527635204019};\\\", \\\"{x:792,y:727,t:1527635204036};\\\", \\\"{x:790,y:728,t:1527635204053};\\\", \\\"{x:788,y:728,t:1527635204070};\\\", \\\"{x:786,y:729,t:1527635204086};\\\", \\\"{x:785,y:729,t:1527635204103};\\\", \\\"{x:784,y:729,t:1527635204121};\\\", \\\"{x:783,y:730,t:1527635204136};\\\", \\\"{x:782,y:730,t:1527635204155};\\\", \\\"{x:781,y:730,t:1527635204171};\\\", \\\"{x:780,y:730,t:1527635204186};\\\", \\\"{x:780,y:731,t:1527635211804};\\\", \\\"{x:788,y:733,t:1527635211811};\\\", \\\"{x:796,y:735,t:1527635211827};\\\", \\\"{x:834,y:745,t:1527635211844};\\\", \\\"{x:873,y:759,t:1527635211860};\\\", \\\"{x:920,y:771,t:1527635211877};\\\", \\\"{x:964,y:783,t:1527635211894};\\\", \\\"{x:1009,y:796,t:1527635211911};\\\", \\\"{x:1039,y:805,t:1527635211928};\\\", \\\"{x:1057,y:810,t:1527635211944};\\\", \\\"{x:1066,y:813,t:1527635211960};\\\", \\\"{x:1068,y:814,t:1527635211976};\\\", \\\"{x:1069,y:814,t:1527635211994};\\\", \\\"{x:1069,y:815,t:1527635212009};\\\", \\\"{x:1069,y:818,t:1527635212026};\\\", \\\"{x:1071,y:827,t:1527635212043};\\\", \\\"{x:1071,y:833,t:1527635212059};\\\", \\\"{x:1071,y:840,t:1527635212077};\\\", \\\"{x:1073,y:849,t:1527635212093};\\\", \\\"{x:1076,y:861,t:1527635212109};\\\", \\\"{x:1080,y:870,t:1527635212127};\\\", \\\"{x:1084,y:880,t:1527635212144};\\\", \\\"{x:1085,y:884,t:1527635212160};\\\", \\\"{x:1087,y:889,t:1527635212177};\\\", \\\"{x:1087,y:891,t:1527635212194};\\\", \\\"{x:1088,y:895,t:1527635212211};\\\", \\\"{x:1088,y:897,t:1527635212226};\\\", \\\"{x:1089,y:902,t:1527635212243};\\\", \\\"{x:1089,y:905,t:1527635212261};\\\", \\\"{x:1090,y:906,t:1527635212277};\\\", \\\"{x:1090,y:908,t:1527635212294};\\\", \\\"{x:1090,y:909,t:1527635212311};\\\", \\\"{x:1090,y:911,t:1527635212327};\\\", \\\"{x:1090,y:912,t:1527635212347};\\\", \\\"{x:1090,y:911,t:1527635212603};\\\", \\\"{x:1090,y:910,t:1527635212620};\\\", \\\"{x:1090,y:909,t:1527635212627};\\\", \\\"{x:1090,y:908,t:1527635212652};\\\", \\\"{x:1090,y:907,t:1527635212661};\\\", \\\"{x:1089,y:906,t:1527635212678};\\\", \\\"{x:1089,y:905,t:1527635212700};\\\", \\\"{x:1089,y:904,t:1527635212724};\\\", \\\"{x:1089,y:903,t:1527635212781};\\\", \\\"{x:1088,y:902,t:1527635212795};\\\", \\\"{x:1088,y:901,t:1527635212835};\\\", \\\"{x:1088,y:900,t:1527635212900};\\\", \\\"{x:1088,y:899,t:1527635212996};\\\", \\\"{x:1088,y:897,t:1527635216252};\\\", \\\"{x:1088,y:896,t:1527635216264};\\\", \\\"{x:1090,y:892,t:1527635216282};\\\", \\\"{x:1094,y:888,t:1527635216298};\\\", \\\"{x:1098,y:881,t:1527635216314};\\\", \\\"{x:1106,y:871,t:1527635216331};\\\", \\\"{x:1115,y:860,t:1527635216348};\\\", \\\"{x:1120,y:852,t:1527635216364};\\\", \\\"{x:1126,y:842,t:1527635216382};\\\", \\\"{x:1130,y:837,t:1527635216398};\\\", \\\"{x:1133,y:833,t:1527635216414};\\\", \\\"{x:1136,y:829,t:1527635216432};\\\", \\\"{x:1138,y:826,t:1527635216447};\\\", \\\"{x:1139,y:824,t:1527635216465};\\\", \\\"{x:1141,y:824,t:1527635218020};\\\", \\\"{x:1142,y:824,t:1527635218032};\\\", \\\"{x:1145,y:824,t:1527635218049};\\\", \\\"{x:1148,y:825,t:1527635218066};\\\", \\\"{x:1150,y:825,t:1527635218083};\\\", \\\"{x:1153,y:825,t:1527635218100};\\\", \\\"{x:1153,y:826,t:1527635218115};\\\", \\\"{x:1154,y:826,t:1527635218148};\\\", \\\"{x:1155,y:826,t:1527635218164};\\\", \\\"{x:1156,y:827,t:1527635218183};\\\", \\\"{x:1158,y:827,t:1527635218200};\\\", \\\"{x:1159,y:827,t:1527635218219};\\\", \\\"{x:1160,y:828,t:1527635218235};\\\", \\\"{x:1161,y:828,t:1527635218252};\\\", \\\"{x:1162,y:828,t:1527635218268};\\\", \\\"{x:1163,y:828,t:1527635218283};\\\", \\\"{x:1165,y:828,t:1527635218300};\\\", \\\"{x:1167,y:828,t:1527635218324};\\\", \\\"{x:1168,y:828,t:1527635218332};\\\", \\\"{x:1169,y:829,t:1527635218350};\\\", \\\"{x:1170,y:829,t:1527635218367};\\\", \\\"{x:1171,y:829,t:1527635218383};\\\", \\\"{x:1172,y:829,t:1527635218400};\\\", \\\"{x:1173,y:829,t:1527635218416};\\\", \\\"{x:1171,y:829,t:1527635218996};\\\", \\\"{x:1167,y:829,t:1527635219004};\\\", \\\"{x:1164,y:829,t:1527635219017};\\\", \\\"{x:1156,y:829,t:1527635219034};\\\", \\\"{x:1147,y:829,t:1527635219050};\\\", \\\"{x:1136,y:827,t:1527635219067};\\\", \\\"{x:1112,y:825,t:1527635219084};\\\", \\\"{x:1089,y:820,t:1527635219100};\\\", \\\"{x:1065,y:815,t:1527635219117};\\\", \\\"{x:1032,y:807,t:1527635219134};\\\", \\\"{x:988,y:794,t:1527635219150};\\\", \\\"{x:932,y:777,t:1527635219166};\\\", \\\"{x:879,y:763,t:1527635219183};\\\", \\\"{x:832,y:751,t:1527635219201};\\\", \\\"{x:793,y:740,t:1527635219217};\\\", \\\"{x:766,y:734,t:1527635219233};\\\", \\\"{x:750,y:733,t:1527635219250};\\\", \\\"{x:740,y:731,t:1527635219266};\\\", \\\"{x:737,y:730,t:1527635219283};\\\", \\\"{x:735,y:730,t:1527635219301};\\\", \\\"{x:734,y:730,t:1527635219316};\\\", \\\"{x:731,y:729,t:1527635219333};\\\", \\\"{x:725,y:727,t:1527635219350};\\\", \\\"{x:722,y:725,t:1527635219366};\\\", \\\"{x:714,y:721,t:1527635219384};\\\", \\\"{x:704,y:714,t:1527635219400};\\\", \\\"{x:689,y:700,t:1527635219417};\\\", \\\"{x:666,y:678,t:1527635219433};\\\", \\\"{x:625,y:636,t:1527635219452};\\\", \\\"{x:547,y:574,t:1527635219467};\\\", \\\"{x:465,y:514,t:1527635219501};\\\", \\\"{x:445,y:500,t:1527635219515};\\\", \\\"{x:432,y:490,t:1527635219531};\\\", \\\"{x:427,y:486,t:1527635219548};\\\", \\\"{x:425,y:485,t:1527635219565};\\\", \\\"{x:425,y:483,t:1527635219581};\\\", \\\"{x:424,y:488,t:1527635219755};\\\", \\\"{x:424,y:497,t:1527635219766};\\\", \\\"{x:424,y:515,t:1527635219783};\\\", \\\"{x:429,y:533,t:1527635219800};\\\", \\\"{x:437,y:555,t:1527635219818};\\\", \\\"{x:448,y:571,t:1527635219833};\\\", \\\"{x:459,y:586,t:1527635219849};\\\", \\\"{x:468,y:595,t:1527635219866};\\\", \\\"{x:473,y:598,t:1527635219882};\\\", \\\"{x:478,y:599,t:1527635219898};\\\", \\\"{x:480,y:599,t:1527635219915};\\\", \\\"{x:482,y:597,t:1527635219932};\\\", \\\"{x:485,y:589,t:1527635219949};\\\", \\\"{x:488,y:584,t:1527635219966};\\\", \\\"{x:489,y:580,t:1527635219983};\\\", \\\"{x:491,y:576,t:1527635219999};\\\", \\\"{x:493,y:570,t:1527635220017};\\\", \\\"{x:495,y:565,t:1527635220033};\\\", \\\"{x:495,y:560,t:1527635220049};\\\", \\\"{x:494,y:555,t:1527635220066};\\\", \\\"{x:489,y:552,t:1527635220080};\\\", \\\"{x:482,y:552,t:1527635220096};\\\", \\\"{x:474,y:552,t:1527635220114};\\\", \\\"{x:461,y:558,t:1527635220130};\\\", \\\"{x:446,y:564,t:1527635220146};\\\", \\\"{x:434,y:569,t:1527635220163};\\\", \\\"{x:422,y:574,t:1527635220180};\\\", \\\"{x:413,y:576,t:1527635220197};\\\", \\\"{x:406,y:579,t:1527635220213};\\\", \\\"{x:395,y:581,t:1527635220230};\\\", \\\"{x:379,y:581,t:1527635220246};\\\", \\\"{x:353,y:581,t:1527635220263};\\\", \\\"{x:302,y:570,t:1527635220282};\\\", \\\"{x:260,y:565,t:1527635220297};\\\", \\\"{x:219,y:561,t:1527635220312};\\\", \\\"{x:185,y:556,t:1527635220330};\\\", \\\"{x:159,y:552,t:1527635220347};\\\", \\\"{x:143,y:550,t:1527635220363};\\\", \\\"{x:141,y:549,t:1527635220380};\\\", \\\"{x:140,y:548,t:1527635220408};\\\", \\\"{x:140,y:547,t:1527635220424};\\\", \\\"{x:140,y:543,t:1527635220432};\\\", \\\"{x:141,y:541,t:1527635220447};\\\", \\\"{x:144,y:535,t:1527635220463};\\\", \\\"{x:147,y:524,t:1527635220479};\\\", \\\"{x:149,y:520,t:1527635220497};\\\", \\\"{x:150,y:520,t:1527635220513};\\\", \\\"{x:151,y:520,t:1527635220530};\\\", \\\"{x:154,y:520,t:1527635220546};\\\", \\\"{x:157,y:520,t:1527635220563};\\\", \\\"{x:159,y:520,t:1527635220580};\\\", \\\"{x:166,y:522,t:1527635220596};\\\", \\\"{x:170,y:524,t:1527635220613};\\\", \\\"{x:172,y:525,t:1527635220630};\\\", \\\"{x:173,y:525,t:1527635220656};\\\", \\\"{x:175,y:525,t:1527635220697};\\\", \\\"{x:175,y:525,t:1527635220813};\\\", \\\"{x:179,y:525,t:1527635220832};\\\", \\\"{x:186,y:525,t:1527635220847};\\\", \\\"{x:213,y:530,t:1527635220864};\\\", \\\"{x:241,y:541,t:1527635220880};\\\", \\\"{x:274,y:549,t:1527635220898};\\\", \\\"{x:314,y:562,t:1527635220913};\\\", \\\"{x:348,y:568,t:1527635220929};\\\", \\\"{x:380,y:574,t:1527635220947};\\\", \\\"{x:427,y:580,t:1527635220964};\\\", \\\"{x:475,y:588,t:1527635220980};\\\", \\\"{x:528,y:596,t:1527635220998};\\\", \\\"{x:582,y:599,t:1527635221014};\\\", \\\"{x:622,y:600,t:1527635221030};\\\", \\\"{x:647,y:600,t:1527635221047};\\\", \\\"{x:669,y:597,t:1527635221063};\\\", \\\"{x:679,y:592,t:1527635221079};\\\", \\\"{x:685,y:586,t:1527635221097};\\\", \\\"{x:687,y:580,t:1527635221114};\\\", \\\"{x:687,y:572,t:1527635221130};\\\", \\\"{x:689,y:567,t:1527635221147};\\\", \\\"{x:692,y:561,t:1527635221163};\\\", \\\"{x:695,y:559,t:1527635221180};\\\", \\\"{x:701,y:558,t:1527635221197};\\\", \\\"{x:714,y:555,t:1527635221213};\\\", \\\"{x:732,y:551,t:1527635221232};\\\", \\\"{x:759,y:546,t:1527635221246};\\\", \\\"{x:785,y:543,t:1527635221264};\\\", \\\"{x:817,y:537,t:1527635221280};\\\", \\\"{x:825,y:530,t:1527635221299};\\\", \\\"{x:825,y:528,t:1527635221314};\\\", \\\"{x:823,y:525,t:1527635221331};\\\", \\\"{x:810,y:521,t:1527635221347};\\\", \\\"{x:778,y:521,t:1527635221364};\\\", \\\"{x:743,y:521,t:1527635221380};\\\", \\\"{x:710,y:521,t:1527635221400};\\\", \\\"{x:686,y:525,t:1527635221414};\\\", \\\"{x:669,y:533,t:1527635221431};\\\", \\\"{x:661,y:539,t:1527635221447};\\\", \\\"{x:660,y:549,t:1527635221464};\\\", \\\"{x:660,y:553,t:1527635221481};\\\", \\\"{x:666,y:559,t:1527635221497};\\\", \\\"{x:670,y:563,t:1527635221514};\\\", \\\"{x:683,y:568,t:1527635221531};\\\", \\\"{x:700,y:571,t:1527635221546};\\\", \\\"{x:719,y:571,t:1527635221564};\\\", \\\"{x:738,y:571,t:1527635221582};\\\", \\\"{x:752,y:571,t:1527635221597};\\\", \\\"{x:758,y:570,t:1527635221614};\\\", \\\"{x:760,y:567,t:1527635221631};\\\", \\\"{x:756,y:556,t:1527635221648};\\\", \\\"{x:738,y:548,t:1527635221663};\\\", \\\"{x:714,y:544,t:1527635221682};\\\", \\\"{x:688,y:542,t:1527635221698};\\\", \\\"{x:656,y:538,t:1527635221714};\\\", \\\"{x:630,y:538,t:1527635221731};\\\", \\\"{x:614,y:538,t:1527635221747};\\\", \\\"{x:607,y:539,t:1527635221764};\\\", \\\"{x:605,y:543,t:1527635221781};\\\", \\\"{x:604,y:551,t:1527635221799};\\\", \\\"{x:604,y:560,t:1527635221814};\\\", \\\"{x:607,y:567,t:1527635221831};\\\", \\\"{x:615,y:573,t:1527635221848};\\\", \\\"{x:629,y:581,t:1527635221865};\\\", \\\"{x:644,y:584,t:1527635221882};\\\", \\\"{x:661,y:588,t:1527635221898};\\\", \\\"{x:677,y:592,t:1527635221914};\\\", \\\"{x:684,y:594,t:1527635221931};\\\", \\\"{x:684,y:595,t:1527635221960};\\\", \\\"{x:684,y:596,t:1527635221968};\\\", \\\"{x:684,y:599,t:1527635221981};\\\", \\\"{x:676,y:606,t:1527635221997};\\\", \\\"{x:664,y:611,t:1527635222014};\\\", \\\"{x:652,y:612,t:1527635222031};\\\", \\\"{x:640,y:612,t:1527635222047};\\\", \\\"{x:634,y:612,t:1527635222064};\\\", \\\"{x:630,y:610,t:1527635222080};\\\", \\\"{x:627,y:609,t:1527635222098};\\\", \\\"{x:626,y:608,t:1527635222113};\\\", \\\"{x:624,y:606,t:1527635222131};\\\", \\\"{x:624,y:604,t:1527635222148};\\\", \\\"{x:623,y:603,t:1527635222165};\\\", \\\"{x:622,y:600,t:1527635222181};\\\", \\\"{x:620,y:599,t:1527635222198};\\\", \\\"{x:618,y:597,t:1527635222215};\\\", \\\"{x:618,y:596,t:1527635222398};\\\", \\\"{x:618,y:599,t:1527635222415};\\\", \\\"{x:618,y:608,t:1527635222430};\\\", \\\"{x:618,y:631,t:1527635222448};\\\", \\\"{x:618,y:645,t:1527635222465};\\\", \\\"{x:618,y:653,t:1527635222481};\\\", \\\"{x:618,y:656,t:1527635222498};\\\", \\\"{x:618,y:659,t:1527635222514};\\\", \\\"{x:618,y:657,t:1527635222600};\\\", \\\"{x:618,y:656,t:1527635222608};\\\", \\\"{x:618,y:654,t:1527635222631};\\\", \\\"{x:618,y:652,t:1527635222648};\\\", \\\"{x:618,y:651,t:1527635222665};\\\", \\\"{x:618,y:650,t:1527635222682};\\\", \\\"{x:618,y:650,t:1527635222697};\\\", \\\"{x:618,y:649,t:1527635222727};\\\", \\\"{x:618,y:648,t:1527635222759};\\\", \\\"{x:618,y:647,t:1527635222776};\\\", \\\"{x:618,y:646,t:1527635222808};\\\", \\\"{x:618,y:645,t:1527635222815};\\\", \\\"{x:618,y:643,t:1527635222832};\\\", \\\"{x:618,y:640,t:1527635222848};\\\", \\\"{x:618,y:639,t:1527635222865};\\\", \\\"{x:618,y:638,t:1527635222882};\\\", \\\"{x:618,y:637,t:1527635223343};\\\", \\\"{x:618,y:640,t:1527635223423};\\\", \\\"{x:617,y:642,t:1527635223432};\\\", \\\"{x:613,y:646,t:1527635223449};\\\", \\\"{x:607,y:650,t:1527635223466};\\\", \\\"{x:600,y:653,t:1527635223483};\\\", \\\"{x:592,y:658,t:1527635223499};\\\", \\\"{x:581,y:662,t:1527635223515};\\\", \\\"{x:570,y:665,t:1527635223532};\\\", \\\"{x:559,y:670,t:1527635223549};\\\", \\\"{x:552,y:673,t:1527635223566};\\\", \\\"{x:545,y:677,t:1527635223582};\\\", \\\"{x:538,y:683,t:1527635223599};\\\", \\\"{x:534,y:687,t:1527635223615};\\\", \\\"{x:529,y:693,t:1527635223632};\\\", \\\"{x:528,y:696,t:1527635223649};\\\", \\\"{x:527,y:698,t:1527635223672};\\\", \\\"{x:526,y:698,t:1527635223683};\\\", \\\"{x:526,y:702,t:1527635223701};\\\", \\\"{x:525,y:706,t:1527635223716};\\\", \\\"{x:522,y:713,t:1527635223732};\\\", \\\"{x:521,y:718,t:1527635223748};\\\", \\\"{x:515,y:726,t:1527635223766};\\\", \\\"{x:512,y:733,t:1527635223783};\\\", \\\"{x:511,y:737,t:1527635223799};\\\", \\\"{x:511,y:739,t:1527635223815};\\\", \\\"{x:510,y:740,t:1527635223832};\\\", \\\"{x:511,y:740,t:1527635223880};\\\", \\\"{x:512,y:740,t:1527635223887};\\\", \\\"{x:514,y:739,t:1527635223899};\\\", \\\"{x:516,y:738,t:1527635223976};\\\", \\\"{x:517,y:736,t:1527635223983};\\\", \\\"{x:517,y:736,t:1527635223985};\\\", \\\"{x:519,y:734,t:1527635224000};\\\", \\\"{x:528,y:727,t:1527635224016};\\\", \\\"{x:529,y:726,t:1527635224032};\\\", \\\"{x:531,y:724,t:1527635224112};\\\", \\\"{x:532,y:724,t:1527635224175};\\\", \\\"{x:532,y:724,t:1527635224237};\\\", \\\"{x:533,y:724,t:1527635224263};\\\", \\\"{x:533,y:723,t:1527635224312};\\\", \\\"{x:533,y:721,t:1527635224336};\\\", \\\"{x:534,y:721,t:1527635224408};\\\", \\\"{x:534,y:720,t:1527635224416};\\\", \\\"{x:539,y:718,t:1527635224434};\\\", \\\"{x:548,y:716,t:1527635224450};\\\", \\\"{x:562,y:715,t:1527635224466};\\\", \\\"{x:588,y:713,t:1527635224484};\\\", \\\"{x:631,y:713,t:1527635224501};\\\", \\\"{x:711,y:713,t:1527635224516};\\\", \\\"{x:803,y:723,t:1527635224534};\\\", \\\"{x:905,y:737,t:1527635224550};\\\", \\\"{x:1008,y:753,t:1527635224566};\\\", \\\"{x:1113,y:767,t:1527635224584};\\\", \\\"{x:1236,y:791,t:1527635224600};\\\", \\\"{x:1279,y:801,t:1527635224617};\\\", \\\"{x:1280,y:801,t:1527635224634};\\\", \\\"{x:1279,y:801,t:1527635225128};\\\", \\\"{x:1278,y:801,t:1527635225145};\\\", \\\"{x:1277,y:801,t:1527635225160};\\\", \\\"{x:1276,y:801,t:1527635225168};\\\", \\\"{x:1275,y:800,t:1527635225184};\\\", \\\"{x:1273,y:800,t:1527635225208};\\\", \\\"{x:1272,y:799,t:1527635225224};\\\", \\\"{x:1267,y:797,t:1527635225291};\\\" ] }, { \\\"rt\\\": 21199, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 265953, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"93XU7\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"J\\\", \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -Z -H -D \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1267,y:789,t:1527635225499};\\\", \\\"{x:1268,y:788,t:1527635225534};\\\", \\\"{x:1271,y:787,t:1527635225550};\\\", \\\"{x:1277,y:786,t:1527635225567};\\\", \\\"{x:1284,y:782,t:1527635225587};\\\", \\\"{x:1285,y:782,t:1527635225600};\\\", \\\"{x:1285,y:781,t:1527635226505};\\\", \\\"{x:1285,y:780,t:1527635226519};\\\", \\\"{x:1284,y:780,t:1527635226535};\\\", \\\"{x:1284,y:779,t:1527635226663};\\\", \\\"{x:1282,y:777,t:1527635226671};\\\", \\\"{x:1277,y:774,t:1527635226685};\\\", \\\"{x:1273,y:762,t:1527635226701};\\\", \\\"{x:1271,y:759,t:1527635226718};\\\", \\\"{x:1271,y:769,t:1527635229392};\\\", \\\"{x:1275,y:783,t:1527635229403};\\\", \\\"{x:1282,y:809,t:1527635229420};\\\", \\\"{x:1288,y:832,t:1527635229437};\\\", \\\"{x:1296,y:845,t:1527635229453};\\\", \\\"{x:1303,y:859,t:1527635229470};\\\", \\\"{x:1310,y:868,t:1527635229487};\\\", \\\"{x:1313,y:874,t:1527635229504};\\\", \\\"{x:1315,y:876,t:1527635229520};\\\", \\\"{x:1315,y:877,t:1527635229568};\\\", \\\"{x:1315,y:876,t:1527635229752};\\\", \\\"{x:1325,y:859,t:1527635229771};\\\", \\\"{x:1333,y:839,t:1527635229788};\\\", \\\"{x:1343,y:815,t:1527635229803};\\\", \\\"{x:1349,y:799,t:1527635229821};\\\", \\\"{x:1352,y:786,t:1527635229837};\\\", \\\"{x:1356,y:776,t:1527635229854};\\\", \\\"{x:1359,y:767,t:1527635229871};\\\", \\\"{x:1363,y:759,t:1527635229887};\\\", \\\"{x:1371,y:743,t:1527635229904};\\\", \\\"{x:1378,y:733,t:1527635229921};\\\", \\\"{x:1384,y:720,t:1527635229938};\\\", \\\"{x:1389,y:712,t:1527635229955};\\\", \\\"{x:1391,y:709,t:1527635229970};\\\", \\\"{x:1392,y:708,t:1527635229987};\\\", \\\"{x:1392,y:706,t:1527635230121};\\\", \\\"{x:1379,y:699,t:1527635230137};\\\", \\\"{x:1361,y:689,t:1527635230155};\\\", \\\"{x:1348,y:679,t:1527635230171};\\\", \\\"{x:1342,y:668,t:1527635230188};\\\", \\\"{x:1337,y:648,t:1527635230204};\\\", \\\"{x:1334,y:633,t:1527635230221};\\\", \\\"{x:1329,y:614,t:1527635230237};\\\", \\\"{x:1323,y:600,t:1527635230255};\\\", \\\"{x:1320,y:591,t:1527635230271};\\\", \\\"{x:1317,y:584,t:1527635230288};\\\", \\\"{x:1317,y:581,t:1527635230305};\\\", \\\"{x:1321,y:581,t:1527635230369};\\\", \\\"{x:1330,y:582,t:1527635230376};\\\", \\\"{x:1338,y:582,t:1527635230388};\\\", \\\"{x:1361,y:582,t:1527635230405};\\\", \\\"{x:1391,y:582,t:1527635230421};\\\", \\\"{x:1422,y:582,t:1527635230438};\\\", \\\"{x:1447,y:578,t:1527635230455};\\\", \\\"{x:1467,y:574,t:1527635230472};\\\", \\\"{x:1486,y:564,t:1527635230488};\\\", \\\"{x:1491,y:556,t:1527635230505};\\\", \\\"{x:1491,y:539,t:1527635230522};\\\", \\\"{x:1489,y:523,t:1527635230538};\\\", \\\"{x:1478,y:506,t:1527635230554};\\\", \\\"{x:1461,y:490,t:1527635230572};\\\", \\\"{x:1441,y:475,t:1527635230588};\\\", \\\"{x:1423,y:461,t:1527635230605};\\\", \\\"{x:1409,y:452,t:1527635230622};\\\", \\\"{x:1406,y:450,t:1527635230638};\\\", \\\"{x:1406,y:449,t:1527635230654};\\\", \\\"{x:1405,y:449,t:1527635230672};\\\", \\\"{x:1405,y:447,t:1527635230713};\\\", \\\"{x:1410,y:445,t:1527635230722};\\\", \\\"{x:1418,y:439,t:1527635230738};\\\", \\\"{x:1429,y:433,t:1527635230755};\\\", \\\"{x:1440,y:425,t:1527635230772};\\\", \\\"{x:1451,y:420,t:1527635230788};\\\", \\\"{x:1455,y:418,t:1527635230805};\\\", \\\"{x:1460,y:415,t:1527635230822};\\\", \\\"{x:1461,y:413,t:1527635230837};\\\", \\\"{x:1461,y:411,t:1527635230855};\\\", \\\"{x:1461,y:409,t:1527635230872};\\\", \\\"{x:1461,y:405,t:1527635230888};\\\", \\\"{x:1462,y:402,t:1527635230905};\\\", \\\"{x:1463,y:402,t:1527635231096};\\\", \\\"{x:1468,y:404,t:1527635231105};\\\", \\\"{x:1479,y:407,t:1527635231122};\\\", \\\"{x:1495,y:412,t:1527635231139};\\\", \\\"{x:1509,y:413,t:1527635231155};\\\", \\\"{x:1525,y:413,t:1527635231172};\\\", \\\"{x:1545,y:411,t:1527635231188};\\\", \\\"{x:1557,y:405,t:1527635231205};\\\", \\\"{x:1562,y:400,t:1527635231222};\\\", \\\"{x:1565,y:395,t:1527635231238};\\\", \\\"{x:1567,y:391,t:1527635231254};\\\", \\\"{x:1569,y:386,t:1527635231271};\\\", \\\"{x:1572,y:380,t:1527635231288};\\\", \\\"{x:1573,y:379,t:1527635231328};\\\", \\\"{x:1575,y:379,t:1527635231339};\\\", \\\"{x:1590,y:383,t:1527635231355};\\\", \\\"{x:1603,y:389,t:1527635231372};\\\", \\\"{x:1615,y:394,t:1527635231389};\\\", \\\"{x:1625,y:403,t:1527635231406};\\\", \\\"{x:1634,y:412,t:1527635231421};\\\", \\\"{x:1639,y:425,t:1527635231439};\\\", \\\"{x:1641,y:442,t:1527635231456};\\\", \\\"{x:1641,y:449,t:1527635231472};\\\", \\\"{x:1641,y:455,t:1527635231488};\\\", \\\"{x:1641,y:462,t:1527635231505};\\\", \\\"{x:1637,y:469,t:1527635231522};\\\", \\\"{x:1630,y:485,t:1527635231539};\\\", \\\"{x:1619,y:505,t:1527635231556};\\\", \\\"{x:1610,y:524,t:1527635231572};\\\", \\\"{x:1602,y:539,t:1527635231589};\\\", \\\"{x:1596,y:548,t:1527635231606};\\\", \\\"{x:1593,y:554,t:1527635231622};\\\", \\\"{x:1593,y:559,t:1527635231639};\\\", \\\"{x:1592,y:570,t:1527635231657};\\\", \\\"{x:1592,y:577,t:1527635231671};\\\", \\\"{x:1592,y:596,t:1527635231688};\\\", \\\"{x:1592,y:607,t:1527635231706};\\\", \\\"{x:1594,y:616,t:1527635231723};\\\", \\\"{x:1597,y:623,t:1527635231739};\\\", \\\"{x:1598,y:627,t:1527635231756};\\\", \\\"{x:1599,y:629,t:1527635231772};\\\", \\\"{x:1600,y:630,t:1527635231789};\\\", \\\"{x:1601,y:631,t:1527635231921};\\\", \\\"{x:1603,y:632,t:1527635231928};\\\", \\\"{x:1606,y:633,t:1527635231939};\\\", \\\"{x:1613,y:638,t:1527635231956};\\\", \\\"{x:1618,y:642,t:1527635231973};\\\", \\\"{x:1624,y:649,t:1527635231989};\\\", \\\"{x:1628,y:656,t:1527635232006};\\\", \\\"{x:1632,y:664,t:1527635232023};\\\", \\\"{x:1634,y:670,t:1527635232039};\\\", \\\"{x:1635,y:680,t:1527635232056};\\\", \\\"{x:1636,y:686,t:1527635232072};\\\", \\\"{x:1638,y:698,t:1527635232089};\\\", \\\"{x:1641,y:710,t:1527635232106};\\\", \\\"{x:1645,y:724,t:1527635232123};\\\", \\\"{x:1649,y:738,t:1527635232139};\\\", \\\"{x:1654,y:754,t:1527635232155};\\\", \\\"{x:1660,y:771,t:1527635232173};\\\", \\\"{x:1668,y:792,t:1527635232189};\\\", \\\"{x:1678,y:812,t:1527635232206};\\\", \\\"{x:1683,y:828,t:1527635232226};\\\", \\\"{x:1688,y:838,t:1527635232239};\\\", \\\"{x:1689,y:840,t:1527635232256};\\\", \\\"{x:1689,y:841,t:1527635232272};\\\", \\\"{x:1689,y:843,t:1527635232303};\\\", \\\"{x:1689,y:844,t:1527635232320};\\\", \\\"{x:1689,y:845,t:1527635232335};\\\", \\\"{x:1689,y:846,t:1527635232343};\\\", \\\"{x:1688,y:847,t:1527635232355};\\\", \\\"{x:1686,y:849,t:1527635232372};\\\", \\\"{x:1683,y:850,t:1527635232389};\\\", \\\"{x:1679,y:851,t:1527635232406};\\\", \\\"{x:1673,y:854,t:1527635232422};\\\", \\\"{x:1657,y:858,t:1527635232440};\\\", \\\"{x:1646,y:858,t:1527635232456};\\\", \\\"{x:1633,y:858,t:1527635232472};\\\", \\\"{x:1621,y:858,t:1527635232489};\\\", \\\"{x:1611,y:858,t:1527635232505};\\\", \\\"{x:1601,y:858,t:1527635232523};\\\", \\\"{x:1591,y:859,t:1527635232540};\\\", \\\"{x:1584,y:859,t:1527635232555};\\\", \\\"{x:1577,y:859,t:1527635232572};\\\", \\\"{x:1569,y:862,t:1527635232590};\\\", \\\"{x:1564,y:864,t:1527635232605};\\\", \\\"{x:1556,y:866,t:1527635232623};\\\", \\\"{x:1545,y:869,t:1527635232639};\\\", \\\"{x:1542,y:870,t:1527635232655};\\\", \\\"{x:1538,y:871,t:1527635232672};\\\", \\\"{x:1533,y:873,t:1527635232689};\\\", \\\"{x:1528,y:873,t:1527635232705};\\\", \\\"{x:1520,y:874,t:1527635232722};\\\", \\\"{x:1516,y:875,t:1527635232739};\\\", \\\"{x:1510,y:875,t:1527635232755};\\\", \\\"{x:1506,y:875,t:1527635232772};\\\", \\\"{x:1500,y:875,t:1527635232789};\\\", \\\"{x:1494,y:875,t:1527635232807};\\\", \\\"{x:1488,y:875,t:1527635232822};\\\", \\\"{x:1480,y:875,t:1527635232839};\\\", \\\"{x:1474,y:875,t:1527635232856};\\\", \\\"{x:1469,y:875,t:1527635232872};\\\", \\\"{x:1466,y:875,t:1527635232889};\\\", \\\"{x:1462,y:876,t:1527635232906};\\\", \\\"{x:1458,y:876,t:1527635232923};\\\", \\\"{x:1450,y:880,t:1527635232940};\\\", \\\"{x:1441,y:883,t:1527635232957};\\\", \\\"{x:1432,y:884,t:1527635232972};\\\", \\\"{x:1423,y:887,t:1527635232990};\\\", \\\"{x:1417,y:888,t:1527635233006};\\\", \\\"{x:1410,y:889,t:1527635233023};\\\", \\\"{x:1399,y:891,t:1527635233040};\\\", \\\"{x:1391,y:891,t:1527635233056};\\\", \\\"{x:1382,y:891,t:1527635233073};\\\", \\\"{x:1376,y:891,t:1527635233090};\\\", \\\"{x:1369,y:891,t:1527635233107};\\\", \\\"{x:1360,y:891,t:1527635233123};\\\", \\\"{x:1351,y:891,t:1527635233140};\\\", \\\"{x:1343,y:890,t:1527635233157};\\\", \\\"{x:1330,y:888,t:1527635233173};\\\", \\\"{x:1320,y:887,t:1527635233190};\\\", \\\"{x:1310,y:883,t:1527635233207};\\\", \\\"{x:1298,y:882,t:1527635233223};\\\", \\\"{x:1294,y:881,t:1527635233239};\\\", \\\"{x:1287,y:880,t:1527635233256};\\\", \\\"{x:1280,y:878,t:1527635233274};\\\", \\\"{x:1275,y:876,t:1527635233289};\\\", \\\"{x:1270,y:874,t:1527635233307};\\\", \\\"{x:1266,y:873,t:1527635233323};\\\", \\\"{x:1262,y:870,t:1527635233340};\\\", \\\"{x:1258,y:865,t:1527635233356};\\\", \\\"{x:1257,y:858,t:1527635233373};\\\", \\\"{x:1255,y:848,t:1527635233389};\\\", \\\"{x:1254,y:836,t:1527635233406};\\\", \\\"{x:1254,y:812,t:1527635233423};\\\", \\\"{x:1254,y:792,t:1527635233439};\\\", \\\"{x:1256,y:767,t:1527635233456};\\\", \\\"{x:1262,y:739,t:1527635233473};\\\", \\\"{x:1278,y:683,t:1527635233489};\\\", \\\"{x:1298,y:608,t:1527635233506};\\\", \\\"{x:1322,y:515,t:1527635233523};\\\", \\\"{x:1333,y:434,t:1527635233539};\\\", \\\"{x:1345,y:366,t:1527635233557};\\\", \\\"{x:1359,y:314,t:1527635233573};\\\", \\\"{x:1374,y:273,t:1527635233590};\\\", \\\"{x:1385,y:241,t:1527635233606};\\\", \\\"{x:1399,y:207,t:1527635233623};\\\", \\\"{x:1403,y:190,t:1527635233639};\\\", \\\"{x:1407,y:176,t:1527635233656};\\\", \\\"{x:1411,y:163,t:1527635233673};\\\", \\\"{x:1414,y:151,t:1527635233690};\\\", \\\"{x:1414,y:140,t:1527635233706};\\\", \\\"{x:1414,y:129,t:1527635233723};\\\", \\\"{x:1414,y:119,t:1527635233740};\\\", \\\"{x:1414,y:111,t:1527635233757};\\\", \\\"{x:1414,y:106,t:1527635233773};\\\", \\\"{x:1418,y:100,t:1527635233790};\\\", \\\"{x:1423,y:95,t:1527635233806};\\\", \\\"{x:1439,y:90,t:1527635233823};\\\", \\\"{x:1463,y:89,t:1527635233840};\\\", \\\"{x:1502,y:89,t:1527635233856};\\\", \\\"{x:1560,y:101,t:1527635233873};\\\", \\\"{x:1615,y:117,t:1527635233890};\\\", \\\"{x:1643,y:130,t:1527635233907};\\\", \\\"{x:1657,y:136,t:1527635233923};\\\", \\\"{x:1660,y:139,t:1527635233941};\\\", \\\"{x:1660,y:141,t:1527635233956};\\\", \\\"{x:1660,y:143,t:1527635233974};\\\", \\\"{x:1656,y:148,t:1527635233991};\\\", \\\"{x:1651,y:151,t:1527635234007};\\\", \\\"{x:1631,y:155,t:1527635234024};\\\", \\\"{x:1613,y:155,t:1527635234040};\\\", \\\"{x:1596,y:155,t:1527635234057};\\\", \\\"{x:1581,y:155,t:1527635234073};\\\", \\\"{x:1566,y:155,t:1527635234091};\\\", \\\"{x:1556,y:154,t:1527635234107};\\\", \\\"{x:1548,y:154,t:1527635234124};\\\", \\\"{x:1540,y:154,t:1527635234141};\\\", \\\"{x:1534,y:160,t:1527635234157};\\\", \\\"{x:1525,y:175,t:1527635234174};\\\", \\\"{x:1513,y:199,t:1527635234191};\\\", \\\"{x:1499,y:241,t:1527635234207};\\\", \\\"{x:1484,y:332,t:1527635234224};\\\", \\\"{x:1476,y:391,t:1527635234240};\\\", \\\"{x:1468,y:441,t:1527635234258};\\\", \\\"{x:1461,y:471,t:1527635234274};\\\", \\\"{x:1459,y:492,t:1527635234291};\\\", \\\"{x:1455,y:507,t:1527635234308};\\\", \\\"{x:1454,y:516,t:1527635234323};\\\", \\\"{x:1453,y:520,t:1527635234341};\\\", \\\"{x:1452,y:521,t:1527635234358};\\\", \\\"{x:1452,y:522,t:1527635234373};\\\", \\\"{x:1451,y:523,t:1527635234391};\\\", \\\"{x:1449,y:525,t:1527635234408};\\\", \\\"{x:1448,y:526,t:1527635234424};\\\", \\\"{x:1446,y:527,t:1527635234441};\\\", \\\"{x:1444,y:528,t:1527635234458};\\\", \\\"{x:1441,y:530,t:1527635234474};\\\", \\\"{x:1438,y:531,t:1527635234491};\\\", \\\"{x:1430,y:538,t:1527635234508};\\\", \\\"{x:1425,y:547,t:1527635234524};\\\", \\\"{x:1414,y:561,t:1527635234542};\\\", \\\"{x:1404,y:577,t:1527635234559};\\\", \\\"{x:1397,y:592,t:1527635234574};\\\", \\\"{x:1393,y:602,t:1527635234591};\\\", \\\"{x:1389,y:613,t:1527635234609};\\\", \\\"{x:1388,y:618,t:1527635234624};\\\", \\\"{x:1386,y:624,t:1527635234641};\\\", \\\"{x:1385,y:630,t:1527635234658};\\\", \\\"{x:1385,y:639,t:1527635234674};\\\", \\\"{x:1381,y:651,t:1527635234690};\\\", \\\"{x:1377,y:660,t:1527635234708};\\\", \\\"{x:1374,y:667,t:1527635234725};\\\", \\\"{x:1371,y:669,t:1527635234741};\\\", \\\"{x:1371,y:672,t:1527635234758};\\\", \\\"{x:1369,y:676,t:1527635234775};\\\", \\\"{x:1367,y:682,t:1527635234792};\\\", \\\"{x:1362,y:698,t:1527635234809};\\\", \\\"{x:1358,y:709,t:1527635234824};\\\", \\\"{x:1354,y:719,t:1527635234841};\\\", \\\"{x:1349,y:730,t:1527635234858};\\\", \\\"{x:1345,y:739,t:1527635234875};\\\", \\\"{x:1343,y:748,t:1527635234891};\\\", \\\"{x:1339,y:758,t:1527635234908};\\\", \\\"{x:1336,y:764,t:1527635234925};\\\", \\\"{x:1334,y:769,t:1527635234941};\\\", \\\"{x:1332,y:773,t:1527635234958};\\\", \\\"{x:1328,y:780,t:1527635234975};\\\", \\\"{x:1327,y:783,t:1527635234990};\\\", \\\"{x:1322,y:791,t:1527635235007};\\\", \\\"{x:1318,y:795,t:1527635235025};\\\", \\\"{x:1315,y:799,t:1527635235041};\\\", \\\"{x:1313,y:801,t:1527635235057};\\\", \\\"{x:1312,y:802,t:1527635235074};\\\", \\\"{x:1311,y:803,t:1527635235095};\\\", \\\"{x:1310,y:803,t:1527635235119};\\\", \\\"{x:1309,y:804,t:1527635235128};\\\", \\\"{x:1308,y:805,t:1527635235141};\\\", \\\"{x:1307,y:807,t:1527635235158};\\\", \\\"{x:1305,y:809,t:1527635235175};\\\", \\\"{x:1304,y:812,t:1527635235192};\\\", \\\"{x:1303,y:814,t:1527635235207};\\\", \\\"{x:1303,y:819,t:1527635235225};\\\", \\\"{x:1303,y:822,t:1527635235242};\\\", \\\"{x:1303,y:826,t:1527635235258};\\\", \\\"{x:1303,y:829,t:1527635235275};\\\", \\\"{x:1303,y:830,t:1527635235294};\\\", \\\"{x:1304,y:832,t:1527635235308};\\\", \\\"{x:1305,y:833,t:1527635235325};\\\", \\\"{x:1305,y:834,t:1527635235368};\\\", \\\"{x:1307,y:834,t:1527635235464};\\\", \\\"{x:1310,y:834,t:1527635235474};\\\", \\\"{x:1320,y:832,t:1527635235492};\\\", \\\"{x:1334,y:828,t:1527635235507};\\\", \\\"{x:1349,y:825,t:1527635235524};\\\", \\\"{x:1363,y:820,t:1527635235541};\\\", \\\"{x:1380,y:813,t:1527635235558};\\\", \\\"{x:1398,y:806,t:1527635235574};\\\", \\\"{x:1412,y:800,t:1527635235592};\\\", \\\"{x:1416,y:796,t:1527635235608};\\\", \\\"{x:1420,y:793,t:1527635235625};\\\", \\\"{x:1421,y:793,t:1527635235736};\\\", \\\"{x:1421,y:795,t:1527635235744};\\\", \\\"{x:1421,y:799,t:1527635235759};\\\", \\\"{x:1418,y:812,t:1527635235774};\\\", \\\"{x:1415,y:835,t:1527635235792};\\\", \\\"{x:1414,y:844,t:1527635235809};\\\", \\\"{x:1412,y:854,t:1527635235825};\\\", \\\"{x:1411,y:862,t:1527635235841};\\\", \\\"{x:1411,y:865,t:1527635235858};\\\", \\\"{x:1411,y:867,t:1527635235874};\\\", \\\"{x:1411,y:870,t:1527635235893};\\\", \\\"{x:1411,y:871,t:1527635235908};\\\", \\\"{x:1411,y:873,t:1527635235925};\\\", \\\"{x:1411,y:874,t:1527635235942};\\\", \\\"{x:1411,y:875,t:1527635235959};\\\", \\\"{x:1411,y:876,t:1527635236000};\\\", \\\"{x:1412,y:878,t:1527635236008};\\\", \\\"{x:1413,y:880,t:1527635236025};\\\", \\\"{x:1416,y:881,t:1527635236042};\\\", \\\"{x:1422,y:883,t:1527635236058};\\\", \\\"{x:1432,y:884,t:1527635236074};\\\", \\\"{x:1446,y:886,t:1527635236092};\\\", \\\"{x:1459,y:886,t:1527635236109};\\\", \\\"{x:1473,y:885,t:1527635236125};\\\", \\\"{x:1488,y:880,t:1527635236141};\\\", \\\"{x:1505,y:871,t:1527635236158};\\\", \\\"{x:1528,y:854,t:1527635236175};\\\", \\\"{x:1536,y:847,t:1527635236192};\\\", \\\"{x:1539,y:839,t:1527635236209};\\\", \\\"{x:1542,y:833,t:1527635236226};\\\", \\\"{x:1543,y:828,t:1527635236242};\\\", \\\"{x:1543,y:821,t:1527635236259};\\\", \\\"{x:1543,y:818,t:1527635236276};\\\", \\\"{x:1543,y:814,t:1527635236292};\\\", \\\"{x:1543,y:808,t:1527635236309};\\\", \\\"{x:1543,y:801,t:1527635236325};\\\", \\\"{x:1539,y:793,t:1527635236341};\\\", \\\"{x:1537,y:785,t:1527635236359};\\\", \\\"{x:1533,y:775,t:1527635236376};\\\", \\\"{x:1528,y:766,t:1527635236392};\\\", \\\"{x:1524,y:755,t:1527635236409};\\\", \\\"{x:1522,y:751,t:1527635236426};\\\", \\\"{x:1521,y:747,t:1527635236442};\\\", \\\"{x:1521,y:741,t:1527635236459};\\\", \\\"{x:1518,y:732,t:1527635236476};\\\", \\\"{x:1516,y:722,t:1527635236492};\\\", \\\"{x:1513,y:715,t:1527635236509};\\\", \\\"{x:1512,y:710,t:1527635236526};\\\", \\\"{x:1508,y:704,t:1527635236541};\\\", \\\"{x:1507,y:700,t:1527635236559};\\\", \\\"{x:1501,y:693,t:1527635236575};\\\", \\\"{x:1497,y:690,t:1527635236592};\\\", \\\"{x:1489,y:686,t:1527635236609};\\\", \\\"{x:1481,y:681,t:1527635236626};\\\", \\\"{x:1476,y:678,t:1527635236642};\\\", \\\"{x:1475,y:678,t:1527635236659};\\\", \\\"{x:1474,y:677,t:1527635236676};\\\", \\\"{x:1472,y:675,t:1527635236693};\\\", \\\"{x:1470,y:673,t:1527635236709};\\\", \\\"{x:1468,y:668,t:1527635236726};\\\", \\\"{x:1464,y:656,t:1527635236743};\\\", \\\"{x:1462,y:638,t:1527635236759};\\\", \\\"{x:1456,y:610,t:1527635236776};\\\", \\\"{x:1453,y:593,t:1527635236792};\\\", \\\"{x:1449,y:574,t:1527635236809};\\\", \\\"{x:1448,y:563,t:1527635236827};\\\", \\\"{x:1447,y:549,t:1527635236844};\\\", \\\"{x:1447,y:540,t:1527635236859};\\\", \\\"{x:1447,y:531,t:1527635236876};\\\", \\\"{x:1447,y:518,t:1527635236894};\\\", \\\"{x:1447,y:510,t:1527635236909};\\\", \\\"{x:1447,y:501,t:1527635236926};\\\", \\\"{x:1448,y:492,t:1527635236943};\\\", \\\"{x:1451,y:481,t:1527635236959};\\\", \\\"{x:1457,y:468,t:1527635236976};\\\", \\\"{x:1462,y:460,t:1527635236992};\\\", \\\"{x:1470,y:450,t:1527635237009};\\\", \\\"{x:1478,y:443,t:1527635237026};\\\", \\\"{x:1490,y:437,t:1527635237043};\\\", \\\"{x:1503,y:434,t:1527635237060};\\\", \\\"{x:1519,y:432,t:1527635237076};\\\", \\\"{x:1535,y:432,t:1527635237093};\\\", \\\"{x:1553,y:432,t:1527635237110};\\\", \\\"{x:1568,y:432,t:1527635237126};\\\", \\\"{x:1582,y:432,t:1527635237143};\\\", \\\"{x:1592,y:432,t:1527635237160};\\\", \\\"{x:1598,y:432,t:1527635237176};\\\", \\\"{x:1604,y:431,t:1527635237193};\\\", \\\"{x:1607,y:430,t:1527635237210};\\\", \\\"{x:1610,y:429,t:1527635237226};\\\", \\\"{x:1613,y:427,t:1527635237242};\\\", \\\"{x:1615,y:426,t:1527635237259};\\\", \\\"{x:1618,y:424,t:1527635237277};\\\", \\\"{x:1620,y:423,t:1527635237293};\\\", \\\"{x:1621,y:422,t:1527635237310};\\\", \\\"{x:1621,y:423,t:1527635237409};\\\", \\\"{x:1621,y:427,t:1527635237426};\\\", \\\"{x:1621,y:430,t:1527635237444};\\\", \\\"{x:1621,y:431,t:1527635237464};\\\", \\\"{x:1621,y:432,t:1527635237481};\\\", \\\"{x:1616,y:436,t:1527635241753};\\\", \\\"{x:1607,y:439,t:1527635241764};\\\", \\\"{x:1583,y:446,t:1527635241779};\\\", \\\"{x:1550,y:454,t:1527635241797};\\\", \\\"{x:1512,y:460,t:1527635241813};\\\", \\\"{x:1460,y:466,t:1527635241829};\\\", \\\"{x:1400,y:468,t:1527635241847};\\\", \\\"{x:1332,y:473,t:1527635241863};\\\", \\\"{x:1192,y:494,t:1527635241880};\\\", \\\"{x:1079,y:506,t:1527635241895};\\\", \\\"{x:960,y:521,t:1527635241914};\\\", \\\"{x:845,y:525,t:1527635241931};\\\", \\\"{x:746,y:525,t:1527635241946};\\\", \\\"{x:660,y:525,t:1527635241963};\\\", \\\"{x:598,y:525,t:1527635241980};\\\", \\\"{x:566,y:520,t:1527635241996};\\\", \\\"{x:545,y:511,t:1527635242013};\\\", \\\"{x:529,y:504,t:1527635242031};\\\", \\\"{x:524,y:502,t:1527635242047};\\\", \\\"{x:523,y:501,t:1527635242064};\\\", \\\"{x:523,y:499,t:1527635242080};\\\", \\\"{x:521,y:498,t:1527635242097};\\\", \\\"{x:520,y:497,t:1527635242113};\\\", \\\"{x:519,y:497,t:1527635242160};\\\", \\\"{x:519,y:499,t:1527635242167};\\\", \\\"{x:521,y:503,t:1527635242180};\\\", \\\"{x:529,y:514,t:1527635242198};\\\", \\\"{x:545,y:532,t:1527635242213};\\\", \\\"{x:561,y:544,t:1527635242231};\\\", \\\"{x:585,y:555,t:1527635242246};\\\", \\\"{x:594,y:558,t:1527635242263};\\\", \\\"{x:598,y:559,t:1527635242281};\\\", \\\"{x:599,y:559,t:1527635242298};\\\", \\\"{x:599,y:556,t:1527635242400};\\\", \\\"{x:598,y:556,t:1527635242415};\\\", \\\"{x:597,y:555,t:1527635242430};\\\", \\\"{x:595,y:552,t:1527635242448};\\\", \\\"{x:595,y:551,t:1527635242464};\\\", \\\"{x:594,y:550,t:1527635242480};\\\", \\\"{x:594,y:551,t:1527635242536};\\\", \\\"{x:594,y:556,t:1527635242547};\\\", \\\"{x:594,y:562,t:1527635242565};\\\", \\\"{x:596,y:572,t:1527635242581};\\\", \\\"{x:598,y:579,t:1527635242599};\\\", \\\"{x:599,y:586,t:1527635242615};\\\", \\\"{x:600,y:588,t:1527635242631};\\\", \\\"{x:599,y:596,t:1527635242647};\\\", \\\"{x:595,y:599,t:1527635242664};\\\", \\\"{x:587,y:603,t:1527635242680};\\\", \\\"{x:584,y:604,t:1527635242697};\\\", \\\"{x:579,y:604,t:1527635242715};\\\", \\\"{x:576,y:605,t:1527635242730};\\\", \\\"{x:570,y:607,t:1527635242748};\\\", \\\"{x:563,y:607,t:1527635242765};\\\", \\\"{x:556,y:607,t:1527635242781};\\\", \\\"{x:549,y:607,t:1527635242797};\\\", \\\"{x:546,y:607,t:1527635242815};\\\", \\\"{x:547,y:607,t:1527635242855};\\\", \\\"{x:555,y:607,t:1527635242865};\\\", \\\"{x:582,y:607,t:1527635242882};\\\", \\\"{x:624,y:607,t:1527635242898};\\\", \\\"{x:672,y:607,t:1527635242915};\\\", \\\"{x:719,y:607,t:1527635242931};\\\", \\\"{x:746,y:607,t:1527635242949};\\\", \\\"{x:761,y:607,t:1527635242964};\\\", \\\"{x:764,y:607,t:1527635242982};\\\", \\\"{x:765,y:607,t:1527635242997};\\\", \\\"{x:766,y:605,t:1527635243023};\\\", \\\"{x:767,y:603,t:1527635243030};\\\", \\\"{x:772,y:598,t:1527635243049};\\\", \\\"{x:780,y:592,t:1527635243065};\\\", \\\"{x:788,y:585,t:1527635243082};\\\", \\\"{x:802,y:581,t:1527635243099};\\\", \\\"{x:826,y:578,t:1527635243114};\\\", \\\"{x:845,y:576,t:1527635243131};\\\", \\\"{x:862,y:574,t:1527635243149};\\\", \\\"{x:869,y:570,t:1527635243164};\\\", \\\"{x:869,y:569,t:1527635243182};\\\", \\\"{x:870,y:568,t:1527635243198};\\\", \\\"{x:870,y:567,t:1527635243336};\\\", \\\"{x:867,y:567,t:1527635243348};\\\", \\\"{x:855,y:567,t:1527635243366};\\\", \\\"{x:836,y:566,t:1527635243382};\\\", \\\"{x:821,y:563,t:1527635243398};\\\", \\\"{x:812,y:561,t:1527635243415};\\\", \\\"{x:810,y:559,t:1527635243431};\\\", \\\"{x:810,y:558,t:1527635243544};\\\", \\\"{x:811,y:558,t:1527635243552};\\\", \\\"{x:813,y:558,t:1527635243565};\\\", \\\"{x:819,y:558,t:1527635243582};\\\", \\\"{x:821,y:558,t:1527635243599};\\\", \\\"{x:823,y:558,t:1527635243615};\\\", \\\"{x:827,y:558,t:1527635243632};\\\", \\\"{x:828,y:558,t:1527635243679};\\\", \\\"{x:829,y:558,t:1527635243695};\\\", \\\"{x:830,y:558,t:1527635243703};\\\", \\\"{x:831,y:558,t:1527635243719};\\\", \\\"{x:832,y:558,t:1527635243735};\\\", \\\"{x:833,y:558,t:1527635243749};\\\", \\\"{x:834,y:558,t:1527635243775};\\\", \\\"{x:835,y:558,t:1527635243807};\\\", \\\"{x:836,y:558,t:1527635243840};\\\", \\\"{x:834,y:558,t:1527635244047};\\\", \\\"{x:830,y:559,t:1527635244055};\\\", \\\"{x:825,y:561,t:1527635244066};\\\", \\\"{x:802,y:573,t:1527635244081};\\\", \\\"{x:762,y:594,t:1527635244100};\\\", \\\"{x:697,y:617,t:1527635244116};\\\", \\\"{x:613,y:630,t:1527635244132};\\\", \\\"{x:530,y:641,t:1527635244149};\\\", \\\"{x:465,y:645,t:1527635244166};\\\", \\\"{x:418,y:645,t:1527635244182};\\\", \\\"{x:378,y:639,t:1527635244199};\\\", \\\"{x:344,y:627,t:1527635244215};\\\", \\\"{x:332,y:625,t:1527635244233};\\\", \\\"{x:327,y:621,t:1527635244249};\\\", \\\"{x:325,y:619,t:1527635244266};\\\", \\\"{x:325,y:616,t:1527635244282};\\\", \\\"{x:324,y:612,t:1527635244300};\\\", \\\"{x:323,y:611,t:1527635244316};\\\", \\\"{x:323,y:609,t:1527635244332};\\\", \\\"{x:326,y:607,t:1527635244349};\\\", \\\"{x:341,y:605,t:1527635244365};\\\", \\\"{x:363,y:605,t:1527635244383};\\\", \\\"{x:388,y:604,t:1527635244398};\\\", \\\"{x:422,y:604,t:1527635244415};\\\", \\\"{x:432,y:604,t:1527635244431};\\\", \\\"{x:429,y:604,t:1527635244520};\\\", \\\"{x:427,y:604,t:1527635244532};\\\", \\\"{x:416,y:604,t:1527635244549};\\\", \\\"{x:405,y:604,t:1527635244565};\\\", \\\"{x:396,y:604,t:1527635244583};\\\", \\\"{x:390,y:604,t:1527635244600};\\\", \\\"{x:389,y:603,t:1527635244616};\\\", \\\"{x:388,y:603,t:1527635244633};\\\", \\\"{x:387,y:602,t:1527635244650};\\\", \\\"{x:386,y:601,t:1527635244667};\\\", \\\"{x:385,y:599,t:1527635244683};\\\", \\\"{x:385,y:597,t:1527635244700};\\\", \\\"{x:383,y:597,t:1527635244943};\\\", \\\"{x:383,y:598,t:1527635244951};\\\", \\\"{x:383,y:602,t:1527635244966};\\\", \\\"{x:389,y:611,t:1527635244983};\\\", \\\"{x:394,y:620,t:1527635245000};\\\", \\\"{x:398,y:628,t:1527635245016};\\\", \\\"{x:402,y:633,t:1527635245033};\\\", \\\"{x:407,y:643,t:1527635245050};\\\", \\\"{x:417,y:654,t:1527635245067};\\\", \\\"{x:422,y:661,t:1527635245083};\\\", \\\"{x:426,y:668,t:1527635245100};\\\", \\\"{x:433,y:675,t:1527635245115};\\\", \\\"{x:436,y:679,t:1527635245133};\\\", \\\"{x:439,y:683,t:1527635245150};\\\", \\\"{x:442,y:686,t:1527635245167};\\\", \\\"{x:444,y:687,t:1527635245183};\\\", \\\"{x:444,y:688,t:1527635245200};\\\", \\\"{x:445,y:688,t:1527635245217};\\\", \\\"{x:445,y:689,t:1527635245264};\\\", \\\"{x:446,y:690,t:1527635245280};\\\", \\\"{x:447,y:690,t:1527635245287};\\\", \\\"{x:448,y:691,t:1527635245303};\\\", \\\"{x:449,y:692,t:1527635245316};\\\", \\\"{x:450,y:693,t:1527635245333};\\\", \\\"{x:453,y:696,t:1527635245350};\\\", \\\"{x:456,y:698,t:1527635245366};\\\", \\\"{x:462,y:703,t:1527635245383};\\\", \\\"{x:464,y:704,t:1527635245400};\\\", \\\"{x:466,y:705,t:1527635245416};\\\", \\\"{x:467,y:705,t:1527635245760};\\\", \\\"{x:468,y:705,t:1527635245767};\\\", \\\"{x:469,y:703,t:1527635245784};\\\", \\\"{x:471,y:701,t:1527635245800};\\\", \\\"{x:471,y:700,t:1527635245818};\\\", \\\"{x:472,y:699,t:1527635245833};\\\", \\\"{x:472,y:697,t:1527635245850};\\\", \\\"{x:473,y:697,t:1527635245866};\\\", \\\"{x:475,y:698,t:1527635246464};\\\", \\\"{x:475,y:700,t:1527635246472};\\\", \\\"{x:475,y:703,t:1527635246485};\\\", \\\"{x:479,y:707,t:1527635246501};\\\", \\\"{x:480,y:709,t:1527635246517};\\\", \\\"{x:481,y:710,t:1527635246534};\\\", \\\"{x:484,y:710,t:1527635246719};\\\", \\\"{x:485,y:710,t:1527635246734};\\\", \\\"{x:486,y:710,t:1527635246751};\\\", \\\"{x:488,y:710,t:1527635246767};\\\", \\\"{x:490,y:710,t:1527635246783};\\\", \\\"{x:495,y:709,t:1527635246831};\\\", \\\"{x:505,y:709,t:1527635246839};\\\", \\\"{x:514,y:709,t:1527635246851};\\\", \\\"{x:530,y:709,t:1527635246867};\\\", \\\"{x:534,y:709,t:1527635246884};\\\", \\\"{x:534,y:708,t:1527635247536};\\\", \\\"{x:534,y:707,t:1527635247552};\\\", \\\"{x:535,y:706,t:1527635247576};\\\", \\\"{x:535,y:705,t:1527635247592};\\\", \\\"{x:535,y:704,t:1527635247602};\\\", \\\"{x:535,y:703,t:1527635247619};\\\", \\\"{x:535,y:701,t:1527635247635};\\\", \\\"{x:535,y:700,t:1527635247652};\\\", \\\"{x:535,y:698,t:1527635247669};\\\", \\\"{x:535,y:696,t:1527635247685};\\\", \\\"{x:535,y:693,t:1527635247702};\\\", \\\"{x:535,y:684,t:1527635247743};\\\", \\\"{x:535,y:681,t:1527635247752};\\\", \\\"{x:535,y:675,t:1527635247769};\\\", \\\"{x:535,y:669,t:1527635247785};\\\", \\\"{x:535,y:657,t:1527635247802};\\\", \\\"{x:535,y:643,t:1527635247818};\\\" ] }, { \\\"rt\\\": 21085, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 288319, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"93XU7\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 5.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"A\\\", \\\"O\\\", \\\"J\\\", \\\"U\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -C -C -C -C \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:570,y:469,t:1527635247980};\\\", \\\"{x:572,y:463,t:1527635247989};\\\", \\\"{x:573,y:455,t:1527635248007};\\\", \\\"{x:573,y:453,t:1527635248019};\\\", \\\"{x:573,y:448,t:1527635248035};\\\", \\\"{x:575,y:444,t:1527635248051};\\\", \\\"{x:576,y:438,t:1527635248078};\\\", \\\"{x:578,y:435,t:1527635248085};\\\", \\\"{x:580,y:431,t:1527635248102};\\\", \\\"{x:584,y:423,t:1527635248119};\\\", \\\"{x:584,y:420,t:1527635248135};\\\", \\\"{x:586,y:416,t:1527635248152};\\\", \\\"{x:587,y:414,t:1527635248169};\\\", \\\"{x:588,y:413,t:1527635248186};\\\", \\\"{x:588,y:411,t:1527635248201};\\\", \\\"{x:588,y:410,t:1527635248219};\\\", \\\"{x:589,y:410,t:1527635248236};\\\", \\\"{x:590,y:409,t:1527635248251};\\\", \\\"{x:593,y:407,t:1527635249160};\\\", \\\"{x:601,y:404,t:1527635249169};\\\", \\\"{x:637,y:395,t:1527635249186};\\\", \\\"{x:685,y:393,t:1527635249203};\\\", \\\"{x:766,y:393,t:1527635249219};\\\", \\\"{x:855,y:393,t:1527635249236};\\\", \\\"{x:939,y:396,t:1527635249254};\\\", \\\"{x:1025,y:409,t:1527635249269};\\\", \\\"{x:1097,y:418,t:1527635249287};\\\", \\\"{x:1172,y:430,t:1527635249304};\\\", \\\"{x:1199,y:435,t:1527635249320};\\\", \\\"{x:1209,y:436,t:1527635249336};\\\", \\\"{x:1211,y:436,t:1527635249354};\\\", \\\"{x:1212,y:436,t:1527635249448};\\\", \\\"{x:1215,y:437,t:1527635249464};\\\", \\\"{x:1221,y:439,t:1527635249472};\\\", \\\"{x:1225,y:439,t:1527635249487};\\\", \\\"{x:1242,y:441,t:1527635249503};\\\", \\\"{x:1274,y:445,t:1527635249520};\\\", \\\"{x:1300,y:450,t:1527635249537};\\\", \\\"{x:1323,y:452,t:1527635249554};\\\", \\\"{x:1351,y:457,t:1527635249571};\\\", \\\"{x:1376,y:461,t:1527635249587};\\\", \\\"{x:1399,y:467,t:1527635249604};\\\", \\\"{x:1418,y:474,t:1527635249620};\\\", \\\"{x:1436,y:485,t:1527635249637};\\\", \\\"{x:1465,y:500,t:1527635249654};\\\", \\\"{x:1498,y:519,t:1527635249670};\\\", \\\"{x:1584,y:566,t:1527635249688};\\\", \\\"{x:1620,y:584,t:1527635249704};\\\", \\\"{x:1683,y:618,t:1527635249721};\\\", \\\"{x:1680,y:618,t:1527635250336};\\\", \\\"{x:1670,y:615,t:1527635250355};\\\", \\\"{x:1662,y:611,t:1527635250370};\\\", \\\"{x:1657,y:608,t:1527635250388};\\\", \\\"{x:1653,y:607,t:1527635250404};\\\", \\\"{x:1647,y:607,t:1527635250421};\\\", \\\"{x:1641,y:602,t:1527635250438};\\\", \\\"{x:1632,y:599,t:1527635250455};\\\", \\\"{x:1628,y:596,t:1527635250471};\\\", \\\"{x:1618,y:594,t:1527635250488};\\\", \\\"{x:1609,y:591,t:1527635250504};\\\", \\\"{x:1596,y:589,t:1527635250521};\\\", \\\"{x:1585,y:586,t:1527635250538};\\\", \\\"{x:1575,y:583,t:1527635250554};\\\", \\\"{x:1570,y:582,t:1527635250571};\\\", \\\"{x:1563,y:580,t:1527635250588};\\\", \\\"{x:1557,y:579,t:1527635250604};\\\", \\\"{x:1552,y:577,t:1527635250621};\\\", \\\"{x:1547,y:576,t:1527635250637};\\\", \\\"{x:1541,y:574,t:1527635250655};\\\", \\\"{x:1532,y:572,t:1527635250672};\\\", \\\"{x:1525,y:570,t:1527635250688};\\\", \\\"{x:1520,y:569,t:1527635250705};\\\", \\\"{x:1516,y:567,t:1527635250721};\\\", \\\"{x:1510,y:565,t:1527635250738};\\\", \\\"{x:1508,y:565,t:1527635250754};\\\", \\\"{x:1507,y:565,t:1527635250772};\\\", \\\"{x:1504,y:563,t:1527635250787};\\\", \\\"{x:1503,y:563,t:1527635250945};\\\", \\\"{x:1500,y:563,t:1527635250960};\\\", \\\"{x:1499,y:563,t:1527635250972};\\\", \\\"{x:1495,y:562,t:1527635250987};\\\", \\\"{x:1494,y:562,t:1527635251004};\\\", \\\"{x:1492,y:561,t:1527635251021};\\\", \\\"{x:1491,y:561,t:1527635251037};\\\", \\\"{x:1490,y:561,t:1527635251055};\\\", \\\"{x:1488,y:560,t:1527635251233};\\\", \\\"{x:1488,y:559,t:1527635251240};\\\", \\\"{x:1487,y:559,t:1527635251256};\\\", \\\"{x:1485,y:559,t:1527635251272};\\\", \\\"{x:1482,y:559,t:1527635251288};\\\", \\\"{x:1480,y:558,t:1527635251305};\\\", \\\"{x:1479,y:558,t:1527635251322};\\\", \\\"{x:1478,y:558,t:1527635251339};\\\", \\\"{x:1477,y:557,t:1527635251355};\\\", \\\"{x:1476,y:557,t:1527635251376};\\\", \\\"{x:1475,y:557,t:1527635251391};\\\", \\\"{x:1475,y:556,t:1527635251405};\\\", \\\"{x:1473,y:556,t:1527635251424};\\\", \\\"{x:1471,y:555,t:1527635251448};\\\", \\\"{x:1471,y:554,t:1527635251464};\\\", \\\"{x:1470,y:554,t:1527635251471};\\\", \\\"{x:1469,y:553,t:1527635251488};\\\", \\\"{x:1466,y:551,t:1527635251520};\\\", \\\"{x:1465,y:551,t:1527635251528};\\\", \\\"{x:1465,y:549,t:1527635251539};\\\", \\\"{x:1461,y:545,t:1527635251556};\\\", \\\"{x:1459,y:541,t:1527635251571};\\\", \\\"{x:1458,y:538,t:1527635251589};\\\", \\\"{x:1456,y:535,t:1527635251605};\\\", \\\"{x:1453,y:531,t:1527635251622};\\\", \\\"{x:1451,y:527,t:1527635251639};\\\", \\\"{x:1448,y:523,t:1527635251656};\\\", \\\"{x:1447,y:521,t:1527635251672};\\\", \\\"{x:1445,y:519,t:1527635251688};\\\", \\\"{x:1443,y:517,t:1527635251706};\\\", \\\"{x:1440,y:513,t:1527635251722};\\\", \\\"{x:1438,y:509,t:1527635251739};\\\", \\\"{x:1434,y:505,t:1527635251755};\\\", \\\"{x:1430,y:498,t:1527635251772};\\\", \\\"{x:1426,y:493,t:1527635251788};\\\", \\\"{x:1425,y:491,t:1527635251806};\\\", \\\"{x:1424,y:489,t:1527635251821};\\\", \\\"{x:1422,y:485,t:1527635251838};\\\", \\\"{x:1419,y:479,t:1527635251856};\\\", \\\"{x:1415,y:475,t:1527635251872};\\\", \\\"{x:1412,y:471,t:1527635251889};\\\", \\\"{x:1410,y:469,t:1527635251905};\\\", \\\"{x:1410,y:468,t:1527635251922};\\\", \\\"{x:1409,y:467,t:1527635251960};\\\", \\\"{x:1408,y:466,t:1527635251984};\\\", \\\"{x:1408,y:465,t:1527635251992};\\\", \\\"{x:1408,y:463,t:1527635252006};\\\", \\\"{x:1407,y:460,t:1527635252022};\\\", \\\"{x:1407,y:458,t:1527635252038};\\\", \\\"{x:1405,y:456,t:1527635252056};\\\", \\\"{x:1404,y:461,t:1527635252152};\\\", \\\"{x:1404,y:472,t:1527635252160};\\\", \\\"{x:1404,y:484,t:1527635252172};\\\", \\\"{x:1404,y:507,t:1527635252189};\\\", \\\"{x:1404,y:533,t:1527635252206};\\\", \\\"{x:1406,y:555,t:1527635252223};\\\", \\\"{x:1408,y:570,t:1527635252239};\\\", \\\"{x:1415,y:592,t:1527635252256};\\\", \\\"{x:1418,y:602,t:1527635252272};\\\", \\\"{x:1421,y:612,t:1527635252289};\\\", \\\"{x:1424,y:619,t:1527635252306};\\\", \\\"{x:1426,y:624,t:1527635252323};\\\", \\\"{x:1429,y:630,t:1527635252340};\\\", \\\"{x:1431,y:637,t:1527635252356};\\\", \\\"{x:1438,y:648,t:1527635252373};\\\", \\\"{x:1443,y:657,t:1527635252388};\\\", \\\"{x:1448,y:663,t:1527635252405};\\\", \\\"{x:1450,y:665,t:1527635252422};\\\", \\\"{x:1452,y:664,t:1527635252519};\\\", \\\"{x:1452,y:663,t:1527635252527};\\\", \\\"{x:1452,y:661,t:1527635252539};\\\", \\\"{x:1452,y:658,t:1527635252555};\\\", \\\"{x:1450,y:655,t:1527635252572};\\\", \\\"{x:1447,y:653,t:1527635252589};\\\", \\\"{x:1439,y:650,t:1527635252605};\\\", \\\"{x:1428,y:649,t:1527635252622};\\\", \\\"{x:1404,y:644,t:1527635252639};\\\", \\\"{x:1389,y:642,t:1527635252655};\\\", \\\"{x:1372,y:639,t:1527635252672};\\\", \\\"{x:1363,y:638,t:1527635252690};\\\", \\\"{x:1354,y:637,t:1527635252705};\\\", \\\"{x:1350,y:637,t:1527635252723};\\\", \\\"{x:1347,y:637,t:1527635252739};\\\", \\\"{x:1345,y:637,t:1527635252756};\\\", \\\"{x:1343,y:638,t:1527635252776};\\\", \\\"{x:1342,y:639,t:1527635252790};\\\", \\\"{x:1339,y:645,t:1527635252805};\\\", \\\"{x:1336,y:650,t:1527635252823};\\\", \\\"{x:1331,y:663,t:1527635252840};\\\", \\\"{x:1330,y:674,t:1527635252856};\\\", \\\"{x:1328,y:687,t:1527635252872};\\\", \\\"{x:1326,y:702,t:1527635252889};\\\", \\\"{x:1326,y:720,t:1527635252906};\\\", \\\"{x:1326,y:740,t:1527635252923};\\\", \\\"{x:1326,y:753,t:1527635252940};\\\", \\\"{x:1329,y:763,t:1527635252955};\\\", \\\"{x:1334,y:774,t:1527635252973};\\\", \\\"{x:1337,y:783,t:1527635252989};\\\", \\\"{x:1338,y:786,t:1527635253005};\\\", \\\"{x:1338,y:787,t:1527635253024};\\\", \\\"{x:1338,y:788,t:1527635253040};\\\", \\\"{x:1339,y:789,t:1527635253057};\\\", \\\"{x:1340,y:789,t:1527635253073};\\\", \\\"{x:1341,y:790,t:1527635253089};\\\", \\\"{x:1346,y:793,t:1527635253107};\\\", \\\"{x:1355,y:794,t:1527635253122};\\\", \\\"{x:1368,y:795,t:1527635253140};\\\", \\\"{x:1385,y:795,t:1527635253157};\\\", \\\"{x:1398,y:795,t:1527635253173};\\\", \\\"{x:1405,y:795,t:1527635253190};\\\", \\\"{x:1409,y:795,t:1527635253207};\\\", \\\"{x:1411,y:795,t:1527635253223};\\\", \\\"{x:1413,y:793,t:1527635253240};\\\", \\\"{x:1413,y:791,t:1527635253256};\\\", \\\"{x:1414,y:789,t:1527635253273};\\\", \\\"{x:1413,y:789,t:1527635253369};\\\", \\\"{x:1411,y:789,t:1527635253376};\\\", \\\"{x:1407,y:792,t:1527635253390};\\\", \\\"{x:1392,y:803,t:1527635253407};\\\", \\\"{x:1378,y:814,t:1527635253423};\\\", \\\"{x:1346,y:839,t:1527635253440};\\\", \\\"{x:1335,y:849,t:1527635253457};\\\", \\\"{x:1332,y:852,t:1527635253474};\\\", \\\"{x:1331,y:856,t:1527635253490};\\\", \\\"{x:1330,y:860,t:1527635253507};\\\", \\\"{x:1329,y:865,t:1527635253524};\\\", \\\"{x:1329,y:868,t:1527635253540};\\\", \\\"{x:1329,y:875,t:1527635253557};\\\", \\\"{x:1329,y:881,t:1527635253574};\\\", \\\"{x:1330,y:886,t:1527635253590};\\\", \\\"{x:1333,y:892,t:1527635253606};\\\", \\\"{x:1335,y:898,t:1527635253623};\\\", \\\"{x:1337,y:900,t:1527635253640};\\\", \\\"{x:1339,y:902,t:1527635253657};\\\", \\\"{x:1340,y:903,t:1527635253674};\\\", \\\"{x:1341,y:903,t:1527635253690};\\\", \\\"{x:1342,y:903,t:1527635253706};\\\", \\\"{x:1343,y:903,t:1527635253723};\\\", \\\"{x:1347,y:902,t:1527635253743};\\\", \\\"{x:1349,y:896,t:1527635253756};\\\", \\\"{x:1350,y:890,t:1527635253774};\\\", \\\"{x:1350,y:881,t:1527635253789};\\\", \\\"{x:1350,y:875,t:1527635253806};\\\", \\\"{x:1347,y:869,t:1527635253822};\\\", \\\"{x:1336,y:864,t:1527635253839};\\\", \\\"{x:1324,y:861,t:1527635253856};\\\", \\\"{x:1309,y:859,t:1527635253874};\\\", \\\"{x:1290,y:858,t:1527635253889};\\\", \\\"{x:1272,y:858,t:1527635253906};\\\", \\\"{x:1253,y:858,t:1527635253923};\\\", \\\"{x:1239,y:858,t:1527635253940};\\\", \\\"{x:1230,y:858,t:1527635253956};\\\", \\\"{x:1226,y:858,t:1527635253973};\\\", \\\"{x:1225,y:858,t:1527635253990};\\\", \\\"{x:1223,y:858,t:1527635254032};\\\", \\\"{x:1222,y:857,t:1527635254039};\\\", \\\"{x:1219,y:851,t:1527635254056};\\\", \\\"{x:1214,y:841,t:1527635254074};\\\", \\\"{x:1211,y:835,t:1527635254090};\\\", \\\"{x:1209,y:833,t:1527635254106};\\\", \\\"{x:1209,y:832,t:1527635254124};\\\", \\\"{x:1208,y:831,t:1527635254141};\\\", \\\"{x:1208,y:832,t:1527635254753};\\\", \\\"{x:1210,y:832,t:1527635254760};\\\", \\\"{x:1212,y:832,t:1527635254773};\\\", \\\"{x:1220,y:832,t:1527635254792};\\\", \\\"{x:1233,y:832,t:1527635254807};\\\", \\\"{x:1238,y:832,t:1527635254824};\\\", \\\"{x:1240,y:832,t:1527635254841};\\\", \\\"{x:1241,y:832,t:1527635254858};\\\", \\\"{x:1241,y:831,t:1527635254960};\\\", \\\"{x:1241,y:830,t:1527635254984};\\\", \\\"{x:1241,y:829,t:1527635255000};\\\", \\\"{x:1242,y:828,t:1527635255031};\\\", \\\"{x:1243,y:828,t:1527635255127};\\\", \\\"{x:1244,y:828,t:1527635255140};\\\", \\\"{x:1246,y:828,t:1527635255157};\\\", \\\"{x:1247,y:828,t:1527635255174};\\\", \\\"{x:1248,y:828,t:1527635255191};\\\", \\\"{x:1249,y:828,t:1527635255208};\\\", \\\"{x:1250,y:827,t:1527635255232};\\\", \\\"{x:1251,y:827,t:1527635255248};\\\", \\\"{x:1252,y:826,t:1527635255257};\\\", \\\"{x:1253,y:825,t:1527635255274};\\\", \\\"{x:1253,y:824,t:1527635255291};\\\", \\\"{x:1254,y:824,t:1527635255311};\\\", \\\"{x:1255,y:824,t:1527635255368};\\\", \\\"{x:1254,y:824,t:1527635255584};\\\", \\\"{x:1252,y:824,t:1527635255591};\\\", \\\"{x:1247,y:824,t:1527635255608};\\\", \\\"{x:1244,y:824,t:1527635255625};\\\", \\\"{x:1242,y:824,t:1527635255642};\\\", \\\"{x:1239,y:825,t:1527635255658};\\\", \\\"{x:1238,y:825,t:1527635255675};\\\", \\\"{x:1236,y:826,t:1527635255692};\\\", \\\"{x:1235,y:828,t:1527635255720};\\\", \\\"{x:1234,y:828,t:1527635255728};\\\", \\\"{x:1233,y:828,t:1527635255742};\\\", \\\"{x:1233,y:829,t:1527635255758};\\\", \\\"{x:1232,y:829,t:1527635255775};\\\", \\\"{x:1230,y:830,t:1527635255792};\\\", \\\"{x:1228,y:831,t:1527635255833};\\\", \\\"{x:1226,y:832,t:1527635255856};\\\", \\\"{x:1225,y:832,t:1527635255871};\\\", \\\"{x:1224,y:832,t:1527635255888};\\\", \\\"{x:1223,y:833,t:1527635255896};\\\", \\\"{x:1222,y:833,t:1527635255919};\\\", \\\"{x:1222,y:834,t:1527635255935};\\\", \\\"{x:1222,y:835,t:1527635255952};\\\", \\\"{x:1222,y:836,t:1527635255975};\\\", \\\"{x:1221,y:836,t:1527635255992};\\\", \\\"{x:1220,y:837,t:1527635256008};\\\", \\\"{x:1220,y:838,t:1527635256025};\\\", \\\"{x:1219,y:838,t:1527635256159};\\\", \\\"{x:1218,y:835,t:1527635256175};\\\", \\\"{x:1217,y:830,t:1527635256192};\\\", \\\"{x:1216,y:830,t:1527635256208};\\\", \\\"{x:1216,y:827,t:1527635256560};\\\", \\\"{x:1217,y:824,t:1527635256577};\\\", \\\"{x:1221,y:818,t:1527635256592};\\\", \\\"{x:1223,y:811,t:1527635256608};\\\", \\\"{x:1226,y:807,t:1527635256626};\\\", \\\"{x:1231,y:797,t:1527635256641};\\\", \\\"{x:1239,y:790,t:1527635256659};\\\", \\\"{x:1250,y:772,t:1527635256676};\\\", \\\"{x:1261,y:753,t:1527635256692};\\\", \\\"{x:1273,y:737,t:1527635256709};\\\", \\\"{x:1284,y:721,t:1527635256725};\\\", \\\"{x:1293,y:706,t:1527635256741};\\\", \\\"{x:1301,y:691,t:1527635256759};\\\", \\\"{x:1310,y:675,t:1527635256775};\\\", \\\"{x:1314,y:667,t:1527635256792};\\\", \\\"{x:1317,y:662,t:1527635256809};\\\", \\\"{x:1319,y:655,t:1527635256826};\\\", \\\"{x:1322,y:647,t:1527635256843};\\\", \\\"{x:1322,y:643,t:1527635256859};\\\", \\\"{x:1323,y:640,t:1527635256876};\\\", \\\"{x:1324,y:637,t:1527635256893};\\\", \\\"{x:1326,y:632,t:1527635256909};\\\", \\\"{x:1327,y:629,t:1527635256926};\\\", \\\"{x:1327,y:627,t:1527635256943};\\\", \\\"{x:1327,y:625,t:1527635256959};\\\", \\\"{x:1327,y:624,t:1527635256976};\\\", \\\"{x:1327,y:623,t:1527635256993};\\\", \\\"{x:1327,y:622,t:1527635257009};\\\", \\\"{x:1327,y:621,t:1527635257026};\\\", \\\"{x:1327,y:620,t:1527635257043};\\\", \\\"{x:1328,y:619,t:1527635257059};\\\", \\\"{x:1329,y:619,t:1527635257087};\\\", \\\"{x:1329,y:618,t:1527635257111};\\\", \\\"{x:1329,y:616,t:1527635257125};\\\", \\\"{x:1330,y:614,t:1527635257142};\\\", \\\"{x:1332,y:612,t:1527635257158};\\\", \\\"{x:1333,y:608,t:1527635257175};\\\", \\\"{x:1336,y:603,t:1527635257192};\\\", \\\"{x:1338,y:598,t:1527635257209};\\\", \\\"{x:1341,y:593,t:1527635257226};\\\", \\\"{x:1343,y:590,t:1527635257242};\\\", \\\"{x:1345,y:585,t:1527635257259};\\\", \\\"{x:1350,y:577,t:1527635257275};\\\", \\\"{x:1353,y:574,t:1527635257292};\\\", \\\"{x:1356,y:569,t:1527635257310};\\\", \\\"{x:1358,y:566,t:1527635257326};\\\", \\\"{x:1359,y:564,t:1527635257343};\\\", \\\"{x:1365,y:557,t:1527635257360};\\\", \\\"{x:1368,y:553,t:1527635257376};\\\", \\\"{x:1371,y:550,t:1527635257393};\\\", \\\"{x:1374,y:548,t:1527635257410};\\\", \\\"{x:1376,y:544,t:1527635257426};\\\", \\\"{x:1380,y:539,t:1527635257443};\\\", \\\"{x:1383,y:534,t:1527635257460};\\\", \\\"{x:1386,y:531,t:1527635257476};\\\", \\\"{x:1387,y:528,t:1527635257493};\\\", \\\"{x:1389,y:525,t:1527635257510};\\\", \\\"{x:1391,y:520,t:1527635257525};\\\", \\\"{x:1392,y:517,t:1527635257543};\\\", \\\"{x:1396,y:507,t:1527635257560};\\\", \\\"{x:1399,y:500,t:1527635257576};\\\", \\\"{x:1401,y:497,t:1527635257593};\\\", \\\"{x:1402,y:492,t:1527635257610};\\\", \\\"{x:1403,y:490,t:1527635257626};\\\", \\\"{x:1404,y:486,t:1527635257643};\\\", \\\"{x:1405,y:483,t:1527635257660};\\\", \\\"{x:1406,y:481,t:1527635257676};\\\", \\\"{x:1406,y:479,t:1527635257693};\\\", \\\"{x:1406,y:477,t:1527635257710};\\\", \\\"{x:1406,y:476,t:1527635257726};\\\", \\\"{x:1408,y:472,t:1527635257746};\\\", \\\"{x:1408,y:471,t:1527635257759};\\\", \\\"{x:1409,y:469,t:1527635257776};\\\", \\\"{x:1409,y:467,t:1527635257792};\\\", \\\"{x:1409,y:466,t:1527635257815};\\\", \\\"{x:1409,y:465,t:1527635257826};\\\", \\\"{x:1411,y:464,t:1527635257842};\\\", \\\"{x:1411,y:462,t:1527635257859};\\\", \\\"{x:1411,y:461,t:1527635257876};\\\", \\\"{x:1411,y:460,t:1527635257892};\\\", \\\"{x:1412,y:458,t:1527635257909};\\\", \\\"{x:1412,y:456,t:1527635257926};\\\", \\\"{x:1412,y:455,t:1527635257943};\\\", \\\"{x:1414,y:454,t:1527635257959};\\\", \\\"{x:1414,y:453,t:1527635257976};\\\", \\\"{x:1414,y:454,t:1527635258392};\\\", \\\"{x:1414,y:458,t:1527635258399};\\\", \\\"{x:1414,y:464,t:1527635258409};\\\", \\\"{x:1410,y:477,t:1527635258427};\\\", \\\"{x:1409,y:489,t:1527635258443};\\\", \\\"{x:1407,y:509,t:1527635258460};\\\", \\\"{x:1401,y:532,t:1527635258477};\\\", \\\"{x:1390,y:575,t:1527635258493};\\\", \\\"{x:1381,y:610,t:1527635258509};\\\", \\\"{x:1368,y:648,t:1527635258526};\\\", \\\"{x:1350,y:686,t:1527635258546};\\\", \\\"{x:1340,y:707,t:1527635258560};\\\", \\\"{x:1329,y:725,t:1527635258577};\\\", \\\"{x:1319,y:741,t:1527635258593};\\\", \\\"{x:1306,y:756,t:1527635258610};\\\", \\\"{x:1293,y:773,t:1527635258626};\\\", \\\"{x:1280,y:787,t:1527635258644};\\\", \\\"{x:1266,y:802,t:1527635258659};\\\", \\\"{x:1254,y:815,t:1527635258676};\\\", \\\"{x:1241,y:828,t:1527635258694};\\\", \\\"{x:1233,y:835,t:1527635258711};\\\", \\\"{x:1226,y:842,t:1527635258727};\\\", \\\"{x:1218,y:847,t:1527635258745};\\\", \\\"{x:1215,y:849,t:1527635258760};\\\", \\\"{x:1213,y:851,t:1527635258777};\\\", \\\"{x:1209,y:854,t:1527635258794};\\\", \\\"{x:1207,y:855,t:1527635258811};\\\", \\\"{x:1207,y:856,t:1527635258827};\\\", \\\"{x:1213,y:853,t:1527635258952};\\\", \\\"{x:1220,y:850,t:1527635258960};\\\", \\\"{x:1237,y:845,t:1527635258977};\\\", \\\"{x:1254,y:841,t:1527635258994};\\\", \\\"{x:1272,y:840,t:1527635259010};\\\", \\\"{x:1289,y:838,t:1527635259026};\\\", \\\"{x:1307,y:835,t:1527635259044};\\\", \\\"{x:1325,y:833,t:1527635259061};\\\", \\\"{x:1336,y:831,t:1527635259076};\\\", \\\"{x:1342,y:829,t:1527635259093};\\\", \\\"{x:1343,y:829,t:1527635259166};\\\", \\\"{x:1340,y:827,t:1527635259191};\\\", \\\"{x:1335,y:827,t:1527635259199};\\\", \\\"{x:1322,y:827,t:1527635259210};\\\", \\\"{x:1293,y:830,t:1527635259227};\\\", \\\"{x:1253,y:837,t:1527635259244};\\\", \\\"{x:1186,y:845,t:1527635259261};\\\", \\\"{x:1108,y:858,t:1527635259277};\\\", \\\"{x:1041,y:866,t:1527635259293};\\\", \\\"{x:995,y:868,t:1527635259311};\\\", \\\"{x:959,y:874,t:1527635259327};\\\", \\\"{x:946,y:875,t:1527635259344};\\\", \\\"{x:941,y:875,t:1527635259360};\\\", \\\"{x:936,y:874,t:1527635259377};\\\", \\\"{x:933,y:870,t:1527635259394};\\\", \\\"{x:930,y:862,t:1527635259410};\\\", \\\"{x:923,y:844,t:1527635259428};\\\", \\\"{x:910,y:816,t:1527635259444};\\\", \\\"{x:882,y:774,t:1527635259461};\\\", \\\"{x:850,y:729,t:1527635259478};\\\", \\\"{x:811,y:687,t:1527635259493};\\\", \\\"{x:769,y:659,t:1527635259511};\\\", \\\"{x:693,y:603,t:1527635259529};\\\", \\\"{x:642,y:568,t:1527635259546};\\\", \\\"{x:557,y:494,t:1527635259577};\\\", \\\"{x:521,y:456,t:1527635259594};\\\", \\\"{x:482,y:437,t:1527635259611};\\\", \\\"{x:461,y:429,t:1527635259627};\\\", \\\"{x:458,y:428,t:1527635259644};\\\", \\\"{x:457,y:427,t:1527635259661};\\\", \\\"{x:456,y:427,t:1527635259695};\\\", \\\"{x:455,y:426,t:1527635259712};\\\", \\\"{x:452,y:426,t:1527635259743};\\\", \\\"{x:443,y:430,t:1527635259751};\\\", \\\"{x:434,y:439,t:1527635259761};\\\", \\\"{x:418,y:458,t:1527635259779};\\\", \\\"{x:398,y:480,t:1527635259794};\\\", \\\"{x:383,y:501,t:1527635259811};\\\", \\\"{x:376,y:517,t:1527635259829};\\\", \\\"{x:373,y:525,t:1527635259845};\\\", \\\"{x:374,y:530,t:1527635259862};\\\", \\\"{x:382,y:536,t:1527635259878};\\\", \\\"{x:403,y:542,t:1527635259896};\\\", \\\"{x:419,y:544,t:1527635259912};\\\", \\\"{x:440,y:544,t:1527635259928};\\\", \\\"{x:463,y:544,t:1527635259945};\\\", \\\"{x:489,y:544,t:1527635259961};\\\", \\\"{x:503,y:544,t:1527635259979};\\\", \\\"{x:507,y:543,t:1527635259995};\\\", \\\"{x:510,y:540,t:1527635260011};\\\", \\\"{x:510,y:538,t:1527635260029};\\\", \\\"{x:510,y:534,t:1527635260045};\\\", \\\"{x:510,y:530,t:1527635260061};\\\", \\\"{x:508,y:528,t:1527635260078};\\\", \\\"{x:496,y:527,t:1527635260095};\\\", \\\"{x:485,y:527,t:1527635260111};\\\", \\\"{x:467,y:527,t:1527635260128};\\\", \\\"{x:445,y:529,t:1527635260145};\\\", \\\"{x:420,y:533,t:1527635260161};\\\", \\\"{x:392,y:537,t:1527635260179};\\\", \\\"{x:371,y:538,t:1527635260195};\\\", \\\"{x:354,y:538,t:1527635260211};\\\", \\\"{x:342,y:538,t:1527635260229};\\\", \\\"{x:330,y:537,t:1527635260246};\\\", \\\"{x:321,y:534,t:1527635260262};\\\", \\\"{x:316,y:533,t:1527635260278};\\\", \\\"{x:305,y:532,t:1527635260295};\\\", \\\"{x:293,y:532,t:1527635260312};\\\", \\\"{x:279,y:532,t:1527635260329};\\\", \\\"{x:260,y:532,t:1527635260347};\\\", \\\"{x:245,y:532,t:1527635260362};\\\", \\\"{x:227,y:535,t:1527635260378};\\\", \\\"{x:208,y:540,t:1527635260395};\\\", \\\"{x:191,y:544,t:1527635260411};\\\", \\\"{x:177,y:549,t:1527635260429};\\\", \\\"{x:165,y:552,t:1527635260445};\\\", \\\"{x:155,y:556,t:1527635260462};\\\", \\\"{x:148,y:560,t:1527635260479};\\\", \\\"{x:143,y:563,t:1527635260494};\\\", \\\"{x:141,y:564,t:1527635260512};\\\", \\\"{x:141,y:566,t:1527635260528};\\\", \\\"{x:140,y:567,t:1527635260545};\\\", \\\"{x:140,y:565,t:1527635260631};\\\", \\\"{x:142,y:563,t:1527635260646};\\\", \\\"{x:145,y:558,t:1527635260662};\\\", \\\"{x:151,y:555,t:1527635260679};\\\", \\\"{x:158,y:552,t:1527635260695};\\\", \\\"{x:169,y:552,t:1527635260712};\\\", \\\"{x:187,y:552,t:1527635260729};\\\", \\\"{x:210,y:552,t:1527635260745};\\\", \\\"{x:246,y:552,t:1527635260762};\\\", \\\"{x:302,y:552,t:1527635260779};\\\", \\\"{x:374,y:552,t:1527635260795};\\\", \\\"{x:466,y:552,t:1527635260813};\\\", \\\"{x:569,y:547,t:1527635260830};\\\", \\\"{x:677,y:533,t:1527635260845};\\\", \\\"{x:777,y:519,t:1527635260864};\\\", \\\"{x:878,y:507,t:1527635260879};\\\", \\\"{x:917,y:501,t:1527635260896};\\\", \\\"{x:935,y:500,t:1527635260913};\\\", \\\"{x:945,y:500,t:1527635260929};\\\", \\\"{x:956,y:500,t:1527635260945};\\\", \\\"{x:961,y:500,t:1527635260963};\\\", \\\"{x:962,y:500,t:1527635260980};\\\", \\\"{x:963,y:500,t:1527635260995};\\\", \\\"{x:965,y:501,t:1527635261031};\\\", \\\"{x:965,y:505,t:1527635261045};\\\", \\\"{x:966,y:513,t:1527635261063};\\\", \\\"{x:966,y:520,t:1527635261079};\\\", \\\"{x:963,y:526,t:1527635261095};\\\", \\\"{x:956,y:531,t:1527635261112};\\\", \\\"{x:946,y:533,t:1527635261130};\\\", \\\"{x:931,y:533,t:1527635261145};\\\", \\\"{x:916,y:533,t:1527635261162};\\\", \\\"{x:899,y:528,t:1527635261179};\\\", \\\"{x:884,y:524,t:1527635261195};\\\", \\\"{x:874,y:521,t:1527635261212};\\\", \\\"{x:870,y:519,t:1527635261230};\\\", \\\"{x:868,y:518,t:1527635261246};\\\", \\\"{x:867,y:517,t:1527635261303};\\\", \\\"{x:865,y:517,t:1527635261312};\\\", \\\"{x:864,y:516,t:1527635261329};\\\", \\\"{x:862,y:516,t:1527635261346};\\\", \\\"{x:858,y:516,t:1527635261362};\\\", \\\"{x:855,y:516,t:1527635261379};\\\", \\\"{x:851,y:516,t:1527635261396};\\\", \\\"{x:850,y:516,t:1527635261412};\\\", \\\"{x:850,y:517,t:1527635261430};\\\", \\\"{x:849,y:517,t:1527635261614};\\\", \\\"{x:848,y:519,t:1527635261629};\\\", \\\"{x:848,y:525,t:1527635261646};\\\", \\\"{x:844,y:535,t:1527635261662};\\\", \\\"{x:843,y:544,t:1527635261680};\\\", \\\"{x:842,y:550,t:1527635261697};\\\", \\\"{x:840,y:554,t:1527635261712};\\\", \\\"{x:840,y:555,t:1527635261729};\\\", \\\"{x:840,y:556,t:1527635261746};\\\", \\\"{x:840,y:557,t:1527635262334};\\\", \\\"{x:840,y:558,t:1527635262346};\\\", \\\"{x:840,y:560,t:1527635262363};\\\", \\\"{x:839,y:561,t:1527635262380};\\\", \\\"{x:838,y:562,t:1527635263224};\\\", \\\"{x:837,y:562,t:1527635263232};\\\", \\\"{x:832,y:562,t:1527635263247};\\\", \\\"{x:828,y:562,t:1527635263264};\\\", \\\"{x:823,y:562,t:1527635263282};\\\", \\\"{x:818,y:562,t:1527635263298};\\\", \\\"{x:809,y:560,t:1527635263314};\\\", \\\"{x:800,y:559,t:1527635263331};\\\", \\\"{x:789,y:558,t:1527635263347};\\\", \\\"{x:776,y:555,t:1527635263365};\\\", \\\"{x:761,y:554,t:1527635263381};\\\", \\\"{x:747,y:551,t:1527635263398};\\\", \\\"{x:731,y:550,t:1527635263415};\\\", \\\"{x:721,y:548,t:1527635263434};\\\", \\\"{x:704,y:545,t:1527635263447};\\\", \\\"{x:698,y:545,t:1527635263464};\\\", \\\"{x:689,y:544,t:1527635263481};\\\", \\\"{x:683,y:542,t:1527635263498};\\\", \\\"{x:677,y:542,t:1527635263515};\\\", \\\"{x:671,y:542,t:1527635263531};\\\", \\\"{x:668,y:542,t:1527635263547};\\\", \\\"{x:665,y:542,t:1527635263564};\\\", \\\"{x:663,y:542,t:1527635263582};\\\", \\\"{x:659,y:543,t:1527635263598};\\\", \\\"{x:656,y:545,t:1527635263615};\\\", \\\"{x:650,y:551,t:1527635263631};\\\", \\\"{x:646,y:554,t:1527635263648};\\\", \\\"{x:642,y:558,t:1527635263664};\\\", \\\"{x:637,y:562,t:1527635263681};\\\", \\\"{x:634,y:565,t:1527635263697};\\\", \\\"{x:630,y:569,t:1527635263714};\\\", \\\"{x:627,y:573,t:1527635263733};\\\", \\\"{x:621,y:577,t:1527635263749};\\\", \\\"{x:612,y:582,t:1527635263765};\\\", \\\"{x:604,y:585,t:1527635263782};\\\", \\\"{x:595,y:589,t:1527635263798};\\\", \\\"{x:571,y:595,t:1527635263815};\\\", \\\"{x:557,y:596,t:1527635263831};\\\", \\\"{x:548,y:597,t:1527635263848};\\\", \\\"{x:544,y:597,t:1527635263864};\\\", \\\"{x:543,y:597,t:1527635263882};\\\", \\\"{x:543,y:596,t:1527635263943};\\\", \\\"{x:543,y:592,t:1527635263950};\\\", \\\"{x:545,y:588,t:1527635263967};\\\", \\\"{x:547,y:585,t:1527635263982};\\\", \\\"{x:549,y:580,t:1527635263999};\\\", \\\"{x:552,y:573,t:1527635264015};\\\", \\\"{x:554,y:571,t:1527635264031};\\\", \\\"{x:558,y:564,t:1527635264047};\\\", \\\"{x:559,y:561,t:1527635264064};\\\", \\\"{x:559,y:559,t:1527635264081};\\\", \\\"{x:559,y:558,t:1527635264098};\\\", \\\"{x:559,y:557,t:1527635264113};\\\", \\\"{x:559,y:555,t:1527635264146};\\\", \\\"{x:558,y:555,t:1527635264152};\\\", \\\"{x:551,y:553,t:1527635264164};\\\", \\\"{x:532,y:553,t:1527635264180};\\\", \\\"{x:503,y:550,t:1527635264196};\\\", \\\"{x:454,y:546,t:1527635264214};\\\", \\\"{x:397,y:543,t:1527635264231};\\\", \\\"{x:324,y:535,t:1527635264249};\\\", \\\"{x:291,y:531,t:1527635264264};\\\", \\\"{x:266,y:527,t:1527635264282};\\\", \\\"{x:247,y:524,t:1527635264298};\\\", \\\"{x:238,y:523,t:1527635264316};\\\", \\\"{x:237,y:522,t:1527635264390};\\\", \\\"{x:237,y:521,t:1527635264399};\\\", \\\"{x:238,y:519,t:1527635264415};\\\", \\\"{x:246,y:516,t:1527635264431};\\\", \\\"{x:256,y:516,t:1527635264449};\\\", \\\"{x:269,y:516,t:1527635264465};\\\", \\\"{x:280,y:516,t:1527635264483};\\\", \\\"{x:292,y:516,t:1527635264499};\\\", \\\"{x:297,y:517,t:1527635264514};\\\", \\\"{x:301,y:518,t:1527635264531};\\\", \\\"{x:303,y:519,t:1527635264548};\\\", \\\"{x:305,y:520,t:1527635264583};\\\", \\\"{x:307,y:520,t:1527635264599};\\\", \\\"{x:310,y:521,t:1527635264615};\\\", \\\"{x:313,y:521,t:1527635264632};\\\", \\\"{x:318,y:523,t:1527635264649};\\\", \\\"{x:321,y:523,t:1527635264664};\\\", \\\"{x:325,y:524,t:1527635264682};\\\", \\\"{x:330,y:524,t:1527635264698};\\\", \\\"{x:334,y:524,t:1527635264715};\\\", \\\"{x:340,y:524,t:1527635264732};\\\", \\\"{x:346,y:524,t:1527635264748};\\\", \\\"{x:351,y:524,t:1527635264765};\\\", \\\"{x:353,y:524,t:1527635264782};\\\", \\\"{x:355,y:524,t:1527635264798};\\\", \\\"{x:357,y:524,t:1527635264815};\\\", \\\"{x:358,y:524,t:1527635264881};\\\", \\\"{x:359,y:524,t:1527635264967};\\\", \\\"{x:359,y:524,t:1527635264967};\\\", \\\"{x:362,y:524,t:1527635264982};\\\", \\\"{x:372,y:524,t:1527635264999};\\\", \\\"{x:391,y:524,t:1527635265016};\\\", \\\"{x:405,y:527,t:1527635265032};\\\", \\\"{x:423,y:536,t:1527635265049};\\\", \\\"{x:443,y:547,t:1527635265066};\\\", \\\"{x:457,y:553,t:1527635265083};\\\", \\\"{x:465,y:556,t:1527635265099};\\\", \\\"{x:472,y:559,t:1527635265115};\\\", \\\"{x:476,y:560,t:1527635265132};\\\", \\\"{x:483,y:560,t:1527635265150};\\\", \\\"{x:493,y:561,t:1527635265165};\\\", \\\"{x:511,y:561,t:1527635265183};\\\", \\\"{x:544,y:563,t:1527635265199};\\\", \\\"{x:567,y:565,t:1527635265216};\\\", \\\"{x:588,y:566,t:1527635265233};\\\", \\\"{x:600,y:567,t:1527635265250};\\\", \\\"{x:606,y:568,t:1527635265266};\\\", \\\"{x:608,y:569,t:1527635265283};\\\", \\\"{x:609,y:570,t:1527635265300};\\\", \\\"{x:610,y:570,t:1527635265320};\\\", \\\"{x:611,y:571,t:1527635265346};\\\", \\\"{x:612,y:573,t:1527635265365};\\\", \\\"{x:614,y:580,t:1527635265383};\\\", \\\"{x:619,y:592,t:1527635265399};\\\", \\\"{x:620,y:597,t:1527635265416};\\\", \\\"{x:620,y:599,t:1527635265433};\\\", \\\"{x:620,y:600,t:1527635265449};\\\", \\\"{x:619,y:598,t:1527635265799};\\\", \\\"{x:611,y:591,t:1527635265816};\\\", \\\"{x:599,y:585,t:1527635265833};\\\", \\\"{x:582,y:575,t:1527635265850};\\\", \\\"{x:554,y:567,t:1527635265867};\\\", \\\"{x:524,y:556,t:1527635265882};\\\", \\\"{x:500,y:549,t:1527635265899};\\\", \\\"{x:481,y:543,t:1527635265917};\\\", \\\"{x:464,y:539,t:1527635265932};\\\", \\\"{x:453,y:535,t:1527635265950};\\\", \\\"{x:449,y:534,t:1527635265967};\\\", \\\"{x:445,y:534,t:1527635265982};\\\", \\\"{x:441,y:534,t:1527635265999};\\\", \\\"{x:431,y:534,t:1527635266017};\\\", \\\"{x:417,y:532,t:1527635266034};\\\", \\\"{x:399,y:529,t:1527635266050};\\\", \\\"{x:381,y:526,t:1527635266067};\\\", \\\"{x:363,y:524,t:1527635266083};\\\", \\\"{x:351,y:520,t:1527635266099};\\\", \\\"{x:343,y:520,t:1527635266117};\\\", \\\"{x:340,y:519,t:1527635266133};\\\", \\\"{x:339,y:517,t:1527635266183};\\\", \\\"{x:339,y:516,t:1527635266232};\\\", \\\"{x:340,y:514,t:1527635266247};\\\", \\\"{x:341,y:514,t:1527635266255};\\\", \\\"{x:343,y:513,t:1527635266270};\\\", \\\"{x:344,y:513,t:1527635266286};\\\", \\\"{x:345,y:513,t:1527635266300};\\\", \\\"{x:347,y:513,t:1527635266316};\\\", \\\"{x:350,y:513,t:1527635266333};\\\", \\\"{x:356,y:513,t:1527635266350};\\\", \\\"{x:360,y:513,t:1527635266366};\\\", \\\"{x:367,y:513,t:1527635266383};\\\", \\\"{x:371,y:514,t:1527635266400};\\\", \\\"{x:374,y:514,t:1527635266416};\\\", \\\"{x:376,y:515,t:1527635266433};\\\", \\\"{x:377,y:515,t:1527635266451};\\\", \\\"{x:377,y:516,t:1527635266466};\\\", \\\"{x:378,y:516,t:1527635266487};\\\", \\\"{x:379,y:516,t:1527635266510};\\\", \\\"{x:381,y:516,t:1527635266663};\\\", \\\"{x:383,y:518,t:1527635266670};\\\", \\\"{x:385,y:519,t:1527635266683};\\\", \\\"{x:390,y:520,t:1527635266701};\\\", \\\"{x:396,y:522,t:1527635266717};\\\", \\\"{x:406,y:528,t:1527635266734};\\\", \\\"{x:436,y:543,t:1527635266751};\\\", \\\"{x:458,y:551,t:1527635266767};\\\", \\\"{x:484,y:559,t:1527635266783};\\\", \\\"{x:510,y:564,t:1527635266801};\\\", \\\"{x:540,y:570,t:1527635266816};\\\", \\\"{x:562,y:573,t:1527635266833};\\\", \\\"{x:577,y:577,t:1527635266851};\\\", \\\"{x:579,y:577,t:1527635266867};\\\", \\\"{x:579,y:578,t:1527635266903};\\\", \\\"{x:579,y:579,t:1527635266918};\\\", \\\"{x:566,y:585,t:1527635266935};\\\", \\\"{x:522,y:593,t:1527635266950};\\\", \\\"{x:469,y:601,t:1527635266968};\\\", \\\"{x:413,y:601,t:1527635266984};\\\", \\\"{x:352,y:601,t:1527635267000};\\\", \\\"{x:304,y:601,t:1527635267017};\\\", \\\"{x:274,y:601,t:1527635267033};\\\", \\\"{x:256,y:599,t:1527635267051};\\\", \\\"{x:250,y:597,t:1527635267067};\\\", \\\"{x:247,y:594,t:1527635267083};\\\", \\\"{x:243,y:594,t:1527635267143};\\\", \\\"{x:242,y:594,t:1527635267150};\\\", \\\"{x:236,y:594,t:1527635267167};\\\", \\\"{x:227,y:594,t:1527635267184};\\\", \\\"{x:217,y:597,t:1527635267201};\\\", \\\"{x:207,y:602,t:1527635267218};\\\", \\\"{x:201,y:606,t:1527635267233};\\\", \\\"{x:199,y:608,t:1527635267250};\\\", \\\"{x:199,y:613,t:1527635267268};\\\", \\\"{x:206,y:621,t:1527635267284};\\\", \\\"{x:221,y:633,t:1527635267301};\\\", \\\"{x:243,y:644,t:1527635267317};\\\", \\\"{x:274,y:654,t:1527635267334};\\\", \\\"{x:319,y:657,t:1527635267351};\\\", \\\"{x:343,y:657,t:1527635267367};\\\", \\\"{x:368,y:657,t:1527635267385};\\\", \\\"{x:384,y:657,t:1527635267401};\\\", \\\"{x:392,y:655,t:1527635267417};\\\", \\\"{x:397,y:652,t:1527635267435};\\\", \\\"{x:401,y:649,t:1527635267452};\\\", \\\"{x:409,y:645,t:1527635267468};\\\", \\\"{x:426,y:642,t:1527635267485};\\\", \\\"{x:449,y:641,t:1527635267500};\\\", \\\"{x:488,y:641,t:1527635267518};\\\", \\\"{x:616,y:641,t:1527635267535};\\\", \\\"{x:674,y:641,t:1527635267550};\\\", \\\"{x:849,y:641,t:1527635267568};\\\", \\\"{x:965,y:641,t:1527635267585};\\\", \\\"{x:1058,y:635,t:1527635267600};\\\", \\\"{x:1126,y:622,t:1527635267618};\\\", \\\"{x:1154,y:612,t:1527635267634};\\\", \\\"{x:1163,y:606,t:1527635267651};\\\", \\\"{x:1163,y:603,t:1527635267668};\\\", \\\"{x:1161,y:596,t:1527635267685};\\\", \\\"{x:1152,y:590,t:1527635267701};\\\", \\\"{x:1140,y:585,t:1527635267718};\\\", \\\"{x:1112,y:580,t:1527635267735};\\\", \\\"{x:1087,y:580,t:1527635267751};\\\", \\\"{x:1060,y:580,t:1527635267768};\\\", \\\"{x:1024,y:583,t:1527635267785};\\\", \\\"{x:977,y:589,t:1527635267802};\\\", \\\"{x:926,y:596,t:1527635267819};\\\", \\\"{x:881,y:604,t:1527635267834};\\\", \\\"{x:844,y:609,t:1527635267851};\\\", \\\"{x:819,y:617,t:1527635267867};\\\", \\\"{x:800,y:626,t:1527635267885};\\\", \\\"{x:786,y:629,t:1527635267901};\\\", \\\"{x:771,y:632,t:1527635267917};\\\", \\\"{x:754,y:634,t:1527635267935};\\\", \\\"{x:744,y:634,t:1527635267950};\\\", \\\"{x:737,y:634,t:1527635267967};\\\", \\\"{x:731,y:634,t:1527635267984};\\\", \\\"{x:722,y:631,t:1527635268002};\\\", \\\"{x:709,y:627,t:1527635268017};\\\", \\\"{x:697,y:624,t:1527635268034};\\\", \\\"{x:685,y:622,t:1527635268052};\\\", \\\"{x:676,y:621,t:1527635268067};\\\", \\\"{x:668,y:621,t:1527635268085};\\\", \\\"{x:660,y:620,t:1527635268102};\\\", \\\"{x:651,y:620,t:1527635268118};\\\", \\\"{x:639,y:620,t:1527635268135};\\\", \\\"{x:632,y:620,t:1527635268152};\\\", \\\"{x:626,y:621,t:1527635268167};\\\", \\\"{x:620,y:622,t:1527635268185};\\\", \\\"{x:617,y:623,t:1527635268202};\\\", \\\"{x:613,y:624,t:1527635268219};\\\", \\\"{x:613,y:625,t:1527635268234};\\\", \\\"{x:611,y:626,t:1527635268455};\\\", \\\"{x:611,y:628,t:1527635268468};\\\", \\\"{x:608,y:635,t:1527635268484};\\\", \\\"{x:602,y:645,t:1527635268501};\\\", \\\"{x:593,y:661,t:1527635268519};\\\", \\\"{x:587,y:669,t:1527635268535};\\\", \\\"{x:582,y:675,t:1527635268552};\\\", \\\"{x:581,y:676,t:1527635268568};\\\", \\\"{x:580,y:677,t:1527635268584};\\\", \\\"{x:579,y:677,t:1527635268602};\\\", \\\"{x:579,y:678,t:1527635268619};\\\", \\\"{x:577,y:680,t:1527635268636};\\\", \\\"{x:571,y:682,t:1527635268652};\\\", \\\"{x:560,y:684,t:1527635268669};\\\", \\\"{x:545,y:686,t:1527635268685};\\\", \\\"{x:532,y:688,t:1527635268702};\\\", \\\"{x:514,y:691,t:1527635268719};\\\", \\\"{x:508,y:693,t:1527635268735};\\\", \\\"{x:504,y:695,t:1527635268751};\\\", \\\"{x:503,y:696,t:1527635268769};\\\", \\\"{x:502,y:697,t:1527635268786};\\\", \\\"{x:502,y:699,t:1527635268802};\\\", \\\"{x:502,y:703,t:1527635268820};\\\", \\\"{x:500,y:707,t:1527635268836};\\\", \\\"{x:499,y:711,t:1527635268851};\\\", \\\"{x:498,y:714,t:1527635268869};\\\", \\\"{x:496,y:717,t:1527635268885};\\\", \\\"{x:495,y:720,t:1527635268901};\\\", \\\"{x:495,y:723,t:1527635268919};\\\", \\\"{x:495,y:724,t:1527635268982};\\\", \\\"{x:495,y:724,t:1527635269084};\\\", \\\"{x:495,y:722,t:1527635269102};\\\", \\\"{x:496,y:721,t:1527635269118};\\\", \\\"{x:499,y:721,t:1527635269135};\\\", \\\"{x:502,y:721,t:1527635269152};\\\", \\\"{x:506,y:721,t:1527635269168};\\\", \\\"{x:509,y:721,t:1527635269185};\\\", \\\"{x:510,y:721,t:1527635269203};\\\", \\\"{x:512,y:719,t:1527635269679};\\\", \\\"{x:515,y:713,t:1527635269687};\\\", \\\"{x:520,y:699,t:1527635269703};\\\", \\\"{x:530,y:684,t:1527635269719};\\\", \\\"{x:542,y:666,t:1527635269736};\\\", \\\"{x:551,y:645,t:1527635269753};\\\", \\\"{x:570,y:611,t:1527635269770};\\\", \\\"{x:596,y:574,t:1527635269786};\\\", \\\"{x:616,y:547,t:1527635269803};\\\", \\\"{x:632,y:529,t:1527635269820};\\\", \\\"{x:646,y:514,t:1527635269836};\\\", \\\"{x:663,y:497,t:1527635269853};\\\", \\\"{x:685,y:485,t:1527635269870};\\\", \\\"{x:698,y:477,t:1527635269886};\\\", \\\"{x:705,y:472,t:1527635269903};\\\", \\\"{x:708,y:471,t:1527635269920};\\\", \\\"{x:708,y:470,t:1527635269983};\\\" ] }, { \\\"rt\\\": 16683, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 306288, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"93XU7\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 4.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"D\\\", \\\"E\\\", \\\"G\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-04 PM-03 PM-04 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:707,y:471,t:1527635270871};\\\", \\\"{x:698,y:475,t:1527635270886};\\\", \\\"{x:688,y:479,t:1527635270903};\\\", \\\"{x:671,y:482,t:1527635270920};\\\", \\\"{x:652,y:483,t:1527635270936};\\\", \\\"{x:628,y:483,t:1527635270954};\\\", \\\"{x:611,y:483,t:1527635270971};\\\", \\\"{x:597,y:483,t:1527635270987};\\\", \\\"{x:588,y:485,t:1527635271003};\\\", \\\"{x:585,y:486,t:1527635271020};\\\", \\\"{x:585,y:488,t:1527635271047};\\\", \\\"{x:585,y:490,t:1527635271055};\\\", \\\"{x:588,y:496,t:1527635271070};\\\", \\\"{x:592,y:502,t:1527635271086};\\\", \\\"{x:596,y:504,t:1527635271104};\\\", \\\"{x:597,y:504,t:1527635271127};\\\", \\\"{x:599,y:504,t:1527635271576};\\\", \\\"{x:604,y:501,t:1527635271588};\\\", \\\"{x:615,y:494,t:1527635271604};\\\", \\\"{x:630,y:487,t:1527635271621};\\\", \\\"{x:648,y:480,t:1527635271638};\\\", \\\"{x:666,y:475,t:1527635271654};\\\", \\\"{x:682,y:469,t:1527635271672};\\\", \\\"{x:685,y:466,t:1527635271687};\\\", \\\"{x:685,y:465,t:1527635271704};\\\", \\\"{x:687,y:464,t:1527635271721};\\\", \\\"{x:687,y:462,t:1527635271738};\\\", \\\"{x:689,y:460,t:1527635271754};\\\", \\\"{x:689,y:457,t:1527635271771};\\\", \\\"{x:690,y:456,t:1527635271788};\\\", \\\"{x:691,y:454,t:1527635271805};\\\", \\\"{x:692,y:453,t:1527635271840};\\\", \\\"{x:692,y:451,t:1527635271855};\\\", \\\"{x:695,y:449,t:1527635271871};\\\", \\\"{x:699,y:446,t:1527635271888};\\\", \\\"{x:707,y:444,t:1527635271905};\\\", \\\"{x:720,y:444,t:1527635271922};\\\", \\\"{x:735,y:444,t:1527635271938};\\\", \\\"{x:758,y:444,t:1527635271955};\\\", \\\"{x:798,y:452,t:1527635271971};\\\", \\\"{x:857,y:484,t:1527635271989};\\\", \\\"{x:935,y:536,t:1527635272007};\\\", \\\"{x:1022,y:606,t:1527635272022};\\\", \\\"{x:1108,y:700,t:1527635272038};\\\", \\\"{x:1249,y:869,t:1527635272055};\\\", \\\"{x:1344,y:981,t:1527635272072};\\\", \\\"{x:1447,y:1082,t:1527635272088};\\\", \\\"{x:1539,y:1145,t:1527635272105};\\\", \\\"{x:1617,y:1184,t:1527635272122};\\\", \\\"{x:1679,y:1199,t:1527635272137};\\\", \\\"{x:1716,y:1199,t:1527635272154};\\\", \\\"{x:1731,y:1199,t:1527635272172};\\\", \\\"{x:1736,y:1199,t:1527635272189};\\\", \\\"{x:1737,y:1198,t:1527635272223};\\\", \\\"{x:1737,y:1195,t:1527635272238};\\\", \\\"{x:1737,y:1191,t:1527635272255};\\\", \\\"{x:1737,y:1184,t:1527635272272};\\\", \\\"{x:1737,y:1178,t:1527635272289};\\\", \\\"{x:1737,y:1168,t:1527635272306};\\\", \\\"{x:1734,y:1155,t:1527635272322};\\\", \\\"{x:1726,y:1137,t:1527635272337};\\\", \\\"{x:1715,y:1118,t:1527635272355};\\\", \\\"{x:1704,y:1097,t:1527635272372};\\\", \\\"{x:1687,y:1072,t:1527635272388};\\\", \\\"{x:1669,y:1038,t:1527635272405};\\\", \\\"{x:1657,y:1014,t:1527635272422};\\\", \\\"{x:1647,y:999,t:1527635272438};\\\", \\\"{x:1635,y:981,t:1527635272455};\\\", \\\"{x:1632,y:976,t:1527635272472};\\\", \\\"{x:1631,y:975,t:1527635272488};\\\", \\\"{x:1630,y:975,t:1527635272520};\\\", \\\"{x:1628,y:975,t:1527635272527};\\\", \\\"{x:1622,y:981,t:1527635272539};\\\", \\\"{x:1607,y:1003,t:1527635272555};\\\", \\\"{x:1587,y:1024,t:1527635272572};\\\", \\\"{x:1564,y:1043,t:1527635272590};\\\", \\\"{x:1545,y:1052,t:1527635272605};\\\", \\\"{x:1533,y:1056,t:1527635272623};\\\", \\\"{x:1530,y:1056,t:1527635272639};\\\", \\\"{x:1529,y:1055,t:1527635272679};\\\", \\\"{x:1529,y:1052,t:1527635272689};\\\", \\\"{x:1529,y:1041,t:1527635272705};\\\", \\\"{x:1534,y:1022,t:1527635272723};\\\", \\\"{x:1543,y:1005,t:1527635272740};\\\", \\\"{x:1552,y:989,t:1527635272756};\\\", \\\"{x:1565,y:971,t:1527635272773};\\\", \\\"{x:1580,y:954,t:1527635272790};\\\", \\\"{x:1592,y:947,t:1527635272805};\\\", \\\"{x:1601,y:944,t:1527635272823};\\\", \\\"{x:1613,y:943,t:1527635272839};\\\", \\\"{x:1619,y:943,t:1527635272855};\\\", \\\"{x:1626,y:949,t:1527635272872};\\\", \\\"{x:1631,y:957,t:1527635272889};\\\", \\\"{x:1635,y:966,t:1527635272906};\\\", \\\"{x:1638,y:972,t:1527635272922};\\\", \\\"{x:1639,y:973,t:1527635272940};\\\", \\\"{x:1638,y:973,t:1527635273048};\\\", \\\"{x:1637,y:973,t:1527635273056};\\\", \\\"{x:1632,y:973,t:1527635273073};\\\", \\\"{x:1627,y:973,t:1527635273089};\\\", \\\"{x:1620,y:973,t:1527635273107};\\\", \\\"{x:1614,y:973,t:1527635273123};\\\", \\\"{x:1610,y:976,t:1527635273139};\\\", \\\"{x:1608,y:977,t:1527635273157};\\\", \\\"{x:1606,y:979,t:1527635273172};\\\", \\\"{x:1605,y:980,t:1527635273189};\\\", \\\"{x:1605,y:978,t:1527635273328};\\\", \\\"{x:1605,y:975,t:1527635273339};\\\", \\\"{x:1605,y:970,t:1527635273356};\\\", \\\"{x:1607,y:964,t:1527635273373};\\\", \\\"{x:1609,y:963,t:1527635273389};\\\", \\\"{x:1609,y:962,t:1527635273407};\\\", \\\"{x:1610,y:962,t:1527635273544};\\\", \\\"{x:1611,y:964,t:1527635273556};\\\", \\\"{x:1612,y:966,t:1527635273574};\\\", \\\"{x:1613,y:967,t:1527635273590};\\\", \\\"{x:1613,y:965,t:1527635273808};\\\", \\\"{x:1613,y:964,t:1527635274768};\\\", \\\"{x:1613,y:963,t:1527635274775};\\\", \\\"{x:1613,y:962,t:1527635274790};\\\", \\\"{x:1613,y:959,t:1527635274808};\\\", \\\"{x:1616,y:955,t:1527635274824};\\\", \\\"{x:1617,y:953,t:1527635274840};\\\", \\\"{x:1620,y:949,t:1527635274858};\\\", \\\"{x:1621,y:944,t:1527635274875};\\\", \\\"{x:1624,y:939,t:1527635274890};\\\", \\\"{x:1629,y:930,t:1527635274907};\\\", \\\"{x:1634,y:920,t:1527635274924};\\\", \\\"{x:1638,y:911,t:1527635274940};\\\", \\\"{x:1642,y:906,t:1527635274958};\\\", \\\"{x:1646,y:898,t:1527635274975};\\\", \\\"{x:1649,y:893,t:1527635274990};\\\", \\\"{x:1655,y:885,t:1527635275008};\\\", \\\"{x:1658,y:878,t:1527635275024};\\\", \\\"{x:1661,y:873,t:1527635275040};\\\", \\\"{x:1663,y:869,t:1527635275058};\\\", \\\"{x:1666,y:865,t:1527635275075};\\\", \\\"{x:1667,y:861,t:1527635275090};\\\", \\\"{x:1668,y:858,t:1527635275108};\\\", \\\"{x:1668,y:856,t:1527635275125};\\\", \\\"{x:1669,y:853,t:1527635275140};\\\", \\\"{x:1669,y:850,t:1527635275157};\\\", \\\"{x:1670,y:847,t:1527635275175};\\\", \\\"{x:1670,y:846,t:1527635275191};\\\", \\\"{x:1670,y:843,t:1527635275207};\\\", \\\"{x:1668,y:839,t:1527635275375};\\\", \\\"{x:1664,y:831,t:1527635275391};\\\", \\\"{x:1659,y:822,t:1527635275406};\\\", \\\"{x:1654,y:813,t:1527635275424};\\\", \\\"{x:1649,y:807,t:1527635275441};\\\", \\\"{x:1647,y:803,t:1527635275456};\\\", \\\"{x:1647,y:801,t:1527635275574};\\\", \\\"{x:1645,y:799,t:1527635275590};\\\", \\\"{x:1645,y:796,t:1527635275608};\\\", \\\"{x:1644,y:793,t:1527635275624};\\\", \\\"{x:1643,y:791,t:1527635275641};\\\", \\\"{x:1640,y:789,t:1527635275658};\\\", \\\"{x:1638,y:783,t:1527635275674};\\\", \\\"{x:1634,y:777,t:1527635275691};\\\", \\\"{x:1628,y:766,t:1527635275708};\\\", \\\"{x:1626,y:761,t:1527635275725};\\\", \\\"{x:1623,y:756,t:1527635275742};\\\", \\\"{x:1622,y:752,t:1527635275759};\\\", \\\"{x:1618,y:743,t:1527635275774};\\\", \\\"{x:1616,y:731,t:1527635275791};\\\", \\\"{x:1614,y:726,t:1527635275808};\\\", \\\"{x:1613,y:718,t:1527635275824};\\\", \\\"{x:1612,y:710,t:1527635275842};\\\", \\\"{x:1611,y:705,t:1527635275858};\\\", \\\"{x:1611,y:702,t:1527635275874};\\\", \\\"{x:1611,y:700,t:1527635275891};\\\", \\\"{x:1611,y:699,t:1527635275909};\\\", \\\"{x:1611,y:698,t:1527635276152};\\\", \\\"{x:1613,y:698,t:1527635276160};\\\", \\\"{x:1624,y:700,t:1527635276175};\\\", \\\"{x:1633,y:706,t:1527635276192};\\\", \\\"{x:1639,y:718,t:1527635276208};\\\", \\\"{x:1639,y:731,t:1527635276226};\\\", \\\"{x:1639,y:753,t:1527635276242};\\\", \\\"{x:1632,y:777,t:1527635276258};\\\", \\\"{x:1608,y:808,t:1527635276275};\\\", \\\"{x:1573,y:845,t:1527635276292};\\\", \\\"{x:1507,y:885,t:1527635276309};\\\", \\\"{x:1403,y:926,t:1527635276326};\\\", \\\"{x:1263,y:958,t:1527635276341};\\\", \\\"{x:1108,y:975,t:1527635276358};\\\", \\\"{x:848,y:978,t:1527635276375};\\\", \\\"{x:685,y:978,t:1527635276392};\\\", \\\"{x:537,y:966,t:1527635276408};\\\", \\\"{x:412,y:945,t:1527635276426};\\\", \\\"{x:307,y:921,t:1527635276442};\\\", \\\"{x:242,y:894,t:1527635276459};\\\", \\\"{x:197,y:866,t:1527635276475};\\\", \\\"{x:183,y:841,t:1527635276492};\\\", \\\"{x:174,y:807,t:1527635276509};\\\", \\\"{x:168,y:760,t:1527635276526};\\\", \\\"{x:168,y:712,t:1527635276543};\\\", \\\"{x:167,y:680,t:1527635276559};\\\", \\\"{x:160,y:650,t:1527635276577};\\\", \\\"{x:156,y:633,t:1527635276592};\\\", \\\"{x:151,y:614,t:1527635276608};\\\", \\\"{x:150,y:600,t:1527635276624};\\\", \\\"{x:150,y:589,t:1527635276641};\\\", \\\"{x:150,y:578,t:1527635276658};\\\", \\\"{x:150,y:570,t:1527635276675};\\\", \\\"{x:156,y:555,t:1527635276692};\\\", \\\"{x:171,y:542,t:1527635276708};\\\", \\\"{x:199,y:531,t:1527635276725};\\\", \\\"{x:246,y:525,t:1527635276741};\\\", \\\"{x:376,y:525,t:1527635276759};\\\", \\\"{x:487,y:525,t:1527635276775};\\\", \\\"{x:601,y:525,t:1527635276792};\\\", \\\"{x:720,y:525,t:1527635276808};\\\", \\\"{x:814,y:525,t:1527635276825};\\\", \\\"{x:849,y:531,t:1527635276842};\\\", \\\"{x:852,y:533,t:1527635276858};\\\", \\\"{x:851,y:537,t:1527635276875};\\\", \\\"{x:840,y:548,t:1527635276893};\\\", \\\"{x:815,y:563,t:1527635276908};\\\", \\\"{x:779,y:580,t:1527635276925};\\\", \\\"{x:732,y:600,t:1527635276942};\\\", \\\"{x:678,y:616,t:1527635276958};\\\", \\\"{x:658,y:622,t:1527635276975};\\\", \\\"{x:654,y:625,t:1527635276992};\\\", \\\"{x:654,y:629,t:1527635277009};\\\", \\\"{x:655,y:629,t:1527635277024};\\\", \\\"{x:654,y:629,t:1527635277440};\\\", \\\"{x:646,y:629,t:1527635277447};\\\", \\\"{x:635,y:629,t:1527635277460};\\\", \\\"{x:611,y:629,t:1527635277475};\\\", \\\"{x:572,y:634,t:1527635277492};\\\", \\\"{x:532,y:636,t:1527635277507};\\\", \\\"{x:498,y:636,t:1527635277526};\\\", \\\"{x:474,y:640,t:1527635277541};\\\", \\\"{x:458,y:642,t:1527635277558};\\\", \\\"{x:449,y:644,t:1527635277576};\\\", \\\"{x:442,y:644,t:1527635277592};\\\", \\\"{x:432,y:644,t:1527635277609};\\\", \\\"{x:420,y:644,t:1527635277626};\\\", \\\"{x:410,y:644,t:1527635277642};\\\", \\\"{x:401,y:643,t:1527635277658};\\\", \\\"{x:393,y:638,t:1527635277676};\\\", \\\"{x:387,y:636,t:1527635277692};\\\", \\\"{x:384,y:635,t:1527635277709};\\\", \\\"{x:383,y:633,t:1527635278063};\\\", \\\"{x:382,y:631,t:1527635278075};\\\", \\\"{x:381,y:630,t:1527635278093};\\\", \\\"{x:379,y:628,t:1527635278109};\\\", \\\"{x:377,y:625,t:1527635278126};\\\", \\\"{x:366,y:616,t:1527635278143};\\\", \\\"{x:359,y:608,t:1527635278161};\\\", \\\"{x:345,y:601,t:1527635278176};\\\", \\\"{x:325,y:591,t:1527635278193};\\\", \\\"{x:301,y:584,t:1527635278210};\\\", \\\"{x:268,y:574,t:1527635278226};\\\", \\\"{x:240,y:571,t:1527635278243};\\\", \\\"{x:215,y:566,t:1527635278260};\\\", \\\"{x:195,y:563,t:1527635278276};\\\", \\\"{x:179,y:561,t:1527635278294};\\\", \\\"{x:169,y:561,t:1527635278311};\\\", \\\"{x:166,y:561,t:1527635278326};\\\", \\\"{x:163,y:561,t:1527635278343};\\\", \\\"{x:168,y:563,t:1527635278568};\\\", \\\"{x:178,y:567,t:1527635278576};\\\", \\\"{x:205,y:574,t:1527635278595};\\\", \\\"{x:262,y:584,t:1527635278612};\\\", \\\"{x:348,y:597,t:1527635278627};\\\", \\\"{x:440,y:608,t:1527635278643};\\\", \\\"{x:545,y:620,t:1527635278660};\\\", \\\"{x:637,y:622,t:1527635278676};\\\", \\\"{x:720,y:622,t:1527635278693};\\\", \\\"{x:800,y:616,t:1527635278711};\\\", \\\"{x:879,y:605,t:1527635278727};\\\", \\\"{x:911,y:600,t:1527635278743};\\\", \\\"{x:933,y:596,t:1527635278759};\\\", \\\"{x:955,y:596,t:1527635278777};\\\", \\\"{x:973,y:596,t:1527635278793};\\\", \\\"{x:979,y:596,t:1527635278810};\\\", \\\"{x:980,y:596,t:1527635278827};\\\", \\\"{x:979,y:596,t:1527635278863};\\\", \\\"{x:975,y:596,t:1527635278877};\\\", \\\"{x:958,y:599,t:1527635278893};\\\", \\\"{x:927,y:604,t:1527635278911};\\\", \\\"{x:833,y:609,t:1527635278927};\\\", \\\"{x:770,y:612,t:1527635278944};\\\", \\\"{x:704,y:620,t:1527635278961};\\\", \\\"{x:653,y:628,t:1527635278977};\\\", \\\"{x:625,y:633,t:1527635278994};\\\", \\\"{x:608,y:635,t:1527635279010};\\\", \\\"{x:601,y:637,t:1527635279026};\\\", \\\"{x:599,y:637,t:1527635279045};\\\", \\\"{x:600,y:637,t:1527635279968};\\\", \\\"{x:602,y:638,t:1527635279978};\\\", \\\"{x:606,y:638,t:1527635279993};\\\", \\\"{x:612,y:638,t:1527635280011};\\\", \\\"{x:615,y:638,t:1527635280028};\\\", \\\"{x:617,y:639,t:1527635280044};\\\", \\\"{x:618,y:639,t:1527635280061};\\\", \\\"{x:619,y:639,t:1527635280173};\\\", \\\"{x:620,y:639,t:1527635280269};\\\", \\\"{x:620,y:638,t:1527635280285};\\\", \\\"{x:620,y:637,t:1527635280293};\\\", \\\"{x:617,y:630,t:1527635280309};\\\", \\\"{x:612,y:626,t:1527635280327};\\\", \\\"{x:605,y:619,t:1527635280345};\\\", \\\"{x:590,y:611,t:1527635280360};\\\", \\\"{x:573,y:604,t:1527635280376};\\\", \\\"{x:554,y:598,t:1527635280393};\\\", \\\"{x:536,y:593,t:1527635280409};\\\", \\\"{x:516,y:588,t:1527635280426};\\\", \\\"{x:504,y:587,t:1527635280443};\\\", \\\"{x:493,y:585,t:1527635280460};\\\", \\\"{x:489,y:584,t:1527635280476};\\\", \\\"{x:488,y:584,t:1527635280493};\\\", \\\"{x:486,y:584,t:1527635280541};\\\", \\\"{x:485,y:584,t:1527635280549};\\\", \\\"{x:484,y:584,t:1527635280559};\\\", \\\"{x:478,y:585,t:1527635280575};\\\", \\\"{x:471,y:587,t:1527635280592};\\\", \\\"{x:462,y:590,t:1527635280609};\\\", \\\"{x:451,y:594,t:1527635280626};\\\", \\\"{x:441,y:595,t:1527635280643};\\\", \\\"{x:432,y:596,t:1527635280658};\\\", \\\"{x:425,y:596,t:1527635280675};\\\", \\\"{x:420,y:596,t:1527635280693};\\\", \\\"{x:418,y:596,t:1527635280709};\\\", \\\"{x:417,y:596,t:1527635280734};\\\", \\\"{x:414,y:595,t:1527635280742};\\\", \\\"{x:406,y:590,t:1527635280760};\\\", \\\"{x:393,y:584,t:1527635280776};\\\", \\\"{x:373,y:576,t:1527635280794};\\\", \\\"{x:352,y:565,t:1527635280811};\\\", \\\"{x:333,y:555,t:1527635280826};\\\", \\\"{x:321,y:548,t:1527635280843};\\\", \\\"{x:308,y:541,t:1527635280861};\\\", \\\"{x:303,y:539,t:1527635280876};\\\", \\\"{x:300,y:537,t:1527635280893};\\\", \\\"{x:298,y:537,t:1527635280941};\\\", \\\"{x:297,y:537,t:1527635280949};\\\", \\\"{x:294,y:537,t:1527635280961};\\\", \\\"{x:288,y:538,t:1527635280976};\\\", \\\"{x:282,y:542,t:1527635280993};\\\", \\\"{x:278,y:545,t:1527635281012};\\\", \\\"{x:278,y:546,t:1527635281027};\\\", \\\"{x:278,y:547,t:1527635281043};\\\", \\\"{x:278,y:548,t:1527635281061};\\\", \\\"{x:278,y:551,t:1527635281077};\\\", \\\"{x:290,y:557,t:1527635281094};\\\", \\\"{x:307,y:560,t:1527635281111};\\\", \\\"{x:338,y:566,t:1527635281127};\\\", \\\"{x:376,y:569,t:1527635281145};\\\", \\\"{x:418,y:576,t:1527635281161};\\\", \\\"{x:466,y:583,t:1527635281178};\\\", \\\"{x:502,y:589,t:1527635281194};\\\", \\\"{x:521,y:591,t:1527635281211};\\\", \\\"{x:530,y:594,t:1527635281227};\\\", \\\"{x:533,y:595,t:1527635281243};\\\", \\\"{x:535,y:596,t:1527635281261};\\\", \\\"{x:540,y:598,t:1527635281277};\\\", \\\"{x:545,y:602,t:1527635281293};\\\", \\\"{x:556,y:605,t:1527635281311};\\\", \\\"{x:570,y:611,t:1527635281328};\\\", \\\"{x:590,y:616,t:1527635281345};\\\", \\\"{x:611,y:622,t:1527635281362};\\\", \\\"{x:633,y:626,t:1527635281377};\\\", \\\"{x:650,y:631,t:1527635281394};\\\", \\\"{x:657,y:633,t:1527635281410};\\\", \\\"{x:659,y:634,t:1527635281427};\\\", \\\"{x:660,y:634,t:1527635281533};\\\", \\\"{x:660,y:636,t:1527635281544};\\\", \\\"{x:654,y:637,t:1527635281561};\\\", \\\"{x:646,y:639,t:1527635281578};\\\", \\\"{x:638,y:639,t:1527635281595};\\\", \\\"{x:630,y:639,t:1527635281611};\\\", \\\"{x:626,y:639,t:1527635281627};\\\", \\\"{x:623,y:639,t:1527635281644};\\\", \\\"{x:622,y:639,t:1527635281661};\\\", \\\"{x:621,y:639,t:1527635281677};\\\", \\\"{x:621,y:638,t:1527635281702};\\\", \\\"{x:620,y:638,t:1527635281711};\\\", \\\"{x:619,y:636,t:1527635281728};\\\", \\\"{x:618,y:635,t:1527635281744};\\\", \\\"{x:618,y:633,t:1527635281977};\\\", \\\"{x:617,y:632,t:1527635281994};\\\", \\\"{x:612,y:629,t:1527635282010};\\\", \\\"{x:605,y:625,t:1527635282028};\\\", \\\"{x:589,y:621,t:1527635282045};\\\", \\\"{x:558,y:610,t:1527635282061};\\\", \\\"{x:529,y:600,t:1527635282077};\\\", \\\"{x:499,y:592,t:1527635282094};\\\", \\\"{x:466,y:583,t:1527635282112};\\\", \\\"{x:442,y:576,t:1527635282128};\\\", \\\"{x:425,y:572,t:1527635282144};\\\", \\\"{x:416,y:568,t:1527635282162};\\\", \\\"{x:412,y:567,t:1527635282178};\\\", \\\"{x:411,y:567,t:1527635282213};\\\", \\\"{x:409,y:567,t:1527635282237};\\\", \\\"{x:408,y:567,t:1527635282245};\\\", \\\"{x:404,y:567,t:1527635282261};\\\", \\\"{x:395,y:567,t:1527635282278};\\\", \\\"{x:383,y:567,t:1527635282294};\\\", \\\"{x:372,y:567,t:1527635282311};\\\", \\\"{x:360,y:567,t:1527635282327};\\\", \\\"{x:354,y:567,t:1527635282345};\\\", \\\"{x:352,y:567,t:1527635282361};\\\", \\\"{x:350,y:565,t:1527635282377};\\\", \\\"{x:346,y:565,t:1527635282394};\\\", \\\"{x:343,y:565,t:1527635282411};\\\", \\\"{x:336,y:565,t:1527635282427};\\\", \\\"{x:325,y:563,t:1527635282445};\\\", \\\"{x:303,y:558,t:1527635282461};\\\", \\\"{x:288,y:552,t:1527635282477};\\\", \\\"{x:271,y:547,t:1527635282495};\\\", \\\"{x:254,y:543,t:1527635282511};\\\", \\\"{x:242,y:539,t:1527635282528};\\\", \\\"{x:236,y:538,t:1527635282544};\\\", \\\"{x:234,y:538,t:1527635282562};\\\", \\\"{x:232,y:540,t:1527635282661};\\\", \\\"{x:229,y:543,t:1527635282678};\\\", \\\"{x:220,y:551,t:1527635282696};\\\", \\\"{x:210,y:559,t:1527635282712};\\\", \\\"{x:198,y:567,t:1527635282729};\\\", \\\"{x:190,y:573,t:1527635282746};\\\", \\\"{x:186,y:577,t:1527635282762};\\\", \\\"{x:185,y:580,t:1527635282779};\\\", \\\"{x:185,y:583,t:1527635282794};\\\", \\\"{x:185,y:584,t:1527635282811};\\\", \\\"{x:185,y:585,t:1527635282829};\\\", \\\"{x:186,y:586,t:1527635282844};\\\", \\\"{x:186,y:587,t:1527635282901};\\\", \\\"{x:186,y:589,t:1527635282911};\\\", \\\"{x:185,y:591,t:1527635282928};\\\", \\\"{x:185,y:596,t:1527635282946};\\\", \\\"{x:179,y:601,t:1527635282962};\\\", \\\"{x:173,y:605,t:1527635282978};\\\", \\\"{x:169,y:607,t:1527635282996};\\\", \\\"{x:167,y:609,t:1527635283012};\\\", \\\"{x:165,y:611,t:1527635283029};\\\", \\\"{x:163,y:612,t:1527635283045};\\\", \\\"{x:162,y:613,t:1527635283062};\\\", \\\"{x:162,y:614,t:1527635283118};\\\", \\\"{x:161,y:614,t:1527635283129};\\\", \\\"{x:161,y:615,t:1527635283146};\\\", \\\"{x:160,y:616,t:1527635283162};\\\", \\\"{x:159,y:617,t:1527635283179};\\\", \\\"{x:158,y:619,t:1527635283196};\\\", \\\"{x:157,y:621,t:1527635283213};\\\", \\\"{x:156,y:623,t:1527635283229};\\\", \\\"{x:156,y:625,t:1527635283245};\\\", \\\"{x:156,y:627,t:1527635283263};\\\", \\\"{x:156,y:628,t:1527635283279};\\\", \\\"{x:156,y:629,t:1527635283296};\\\", \\\"{x:156,y:631,t:1527635283313};\\\", \\\"{x:156,y:634,t:1527635283329};\\\", \\\"{x:156,y:637,t:1527635283346};\\\", \\\"{x:156,y:638,t:1527635283445};\\\", \\\"{x:156,y:638,t:1527635283578};\\\", \\\"{x:157,y:638,t:1527635283645};\\\", \\\"{x:159,y:638,t:1527635283662};\\\", \\\"{x:161,y:638,t:1527635283678};\\\", \\\"{x:165,y:638,t:1527635283695};\\\", \\\"{x:168,y:638,t:1527635283712};\\\", \\\"{x:174,y:638,t:1527635283728};\\\", \\\"{x:180,y:639,t:1527635283746};\\\", \\\"{x:185,y:639,t:1527635283763};\\\", \\\"{x:191,y:641,t:1527635283779};\\\", \\\"{x:193,y:642,t:1527635283796};\\\", \\\"{x:196,y:642,t:1527635283812};\\\", \\\"{x:199,y:644,t:1527635283829};\\\", \\\"{x:203,y:644,t:1527635283846};\\\", \\\"{x:213,y:644,t:1527635283862};\\\", \\\"{x:228,y:644,t:1527635283880};\\\", \\\"{x:250,y:641,t:1527635283896};\\\", \\\"{x:281,y:637,t:1527635283914};\\\", \\\"{x:324,y:629,t:1527635283929};\\\", \\\"{x:381,y:616,t:1527635283947};\\\", \\\"{x:448,y:606,t:1527635283963};\\\", \\\"{x:507,y:598,t:1527635283981};\\\", \\\"{x:571,y:589,t:1527635283995};\\\", \\\"{x:653,y:578,t:1527635284013};\\\", \\\"{x:703,y:572,t:1527635284028};\\\", \\\"{x:733,y:572,t:1527635284045};\\\", \\\"{x:758,y:568,t:1527635284062};\\\", \\\"{x:777,y:565,t:1527635284079};\\\", \\\"{x:789,y:560,t:1527635284096};\\\", \\\"{x:795,y:556,t:1527635284112};\\\", \\\"{x:798,y:553,t:1527635284129};\\\", \\\"{x:800,y:551,t:1527635284147};\\\", \\\"{x:800,y:550,t:1527635284162};\\\", \\\"{x:800,y:547,t:1527635284179};\\\", \\\"{x:789,y:538,t:1527635284197};\\\", \\\"{x:772,y:532,t:1527635284213};\\\", \\\"{x:743,y:528,t:1527635284228};\\\", \\\"{x:713,y:527,t:1527635284246};\\\", \\\"{x:683,y:527,t:1527635284263};\\\", \\\"{x:661,y:528,t:1527635284279};\\\", \\\"{x:653,y:530,t:1527635284296};\\\", \\\"{x:648,y:533,t:1527635284312};\\\", \\\"{x:645,y:536,t:1527635284330};\\\", \\\"{x:642,y:540,t:1527635284346};\\\", \\\"{x:639,y:544,t:1527635284363};\\\", \\\"{x:634,y:549,t:1527635284380};\\\", \\\"{x:621,y:558,t:1527635284396};\\\", \\\"{x:619,y:560,t:1527635284413};\\\", \\\"{x:612,y:565,t:1527635284429};\\\", \\\"{x:612,y:566,t:1527635284447};\\\", \\\"{x:612,y:567,t:1527635284462};\\\", \\\"{x:612,y:568,t:1527635284486};\\\", \\\"{x:612,y:569,t:1527635284510};\\\", \\\"{x:612,y:570,t:1527635284517};\\\", \\\"{x:612,y:571,t:1527635284565};\\\", \\\"{x:610,y:572,t:1527635284579};\\\", \\\"{x:586,y:576,t:1527635284597};\\\", \\\"{x:560,y:580,t:1527635284613};\\\", \\\"{x:527,y:580,t:1527635284629};\\\", \\\"{x:492,y:580,t:1527635284647};\\\", \\\"{x:461,y:580,t:1527635284664};\\\", \\\"{x:435,y:580,t:1527635284680};\\\", \\\"{x:415,y:580,t:1527635284697};\\\", \\\"{x:400,y:580,t:1527635284713};\\\", \\\"{x:389,y:579,t:1527635284730};\\\", \\\"{x:379,y:575,t:1527635284747};\\\", \\\"{x:374,y:573,t:1527635284765};\\\", \\\"{x:370,y:571,t:1527635284780};\\\", \\\"{x:365,y:567,t:1527635284797};\\\", \\\"{x:361,y:566,t:1527635284813};\\\", \\\"{x:359,y:565,t:1527635284830};\\\", \\\"{x:357,y:563,t:1527635284847};\\\", \\\"{x:356,y:563,t:1527635284864};\\\", \\\"{x:354,y:561,t:1527635284880};\\\", \\\"{x:352,y:561,t:1527635284897};\\\", \\\"{x:348,y:561,t:1527635284913};\\\", \\\"{x:339,y:561,t:1527635284929};\\\", \\\"{x:324,y:561,t:1527635284947};\\\", \\\"{x:304,y:561,t:1527635284964};\\\", \\\"{x:281,y:561,t:1527635284979};\\\", \\\"{x:245,y:561,t:1527635284998};\\\", \\\"{x:223,y:561,t:1527635285013};\\\", \\\"{x:205,y:561,t:1527635285029};\\\", \\\"{x:193,y:561,t:1527635285047};\\\", \\\"{x:180,y:560,t:1527635285064};\\\", \\\"{x:169,y:560,t:1527635285081};\\\", \\\"{x:158,y:560,t:1527635285096};\\\", \\\"{x:144,y:559,t:1527635285114};\\\", \\\"{x:130,y:559,t:1527635285130};\\\", \\\"{x:117,y:556,t:1527635285146};\\\", \\\"{x:111,y:555,t:1527635285163};\\\", \\\"{x:110,y:555,t:1527635285181};\\\", \\\"{x:113,y:555,t:1527635285229};\\\", \\\"{x:120,y:555,t:1527635285237};\\\", \\\"{x:132,y:556,t:1527635285246};\\\", \\\"{x:170,y:560,t:1527635285264};\\\", \\\"{x:237,y:570,t:1527635285281};\\\", \\\"{x:324,y:583,t:1527635285297};\\\", \\\"{x:437,y:598,t:1527635285314};\\\", \\\"{x:584,y:619,t:1527635285331};\\\", \\\"{x:725,y:641,t:1527635285346};\\\", \\\"{x:861,y:658,t:1527635285364};\\\", \\\"{x:1019,y:675,t:1527635285381};\\\", \\\"{x:1079,y:679,t:1527635285396};\\\", \\\"{x:1100,y:683,t:1527635285413};\\\", \\\"{x:1102,y:683,t:1527635285430};\\\", \\\"{x:1101,y:683,t:1527635285477};\\\", \\\"{x:1098,y:683,t:1527635285485};\\\", \\\"{x:1093,y:683,t:1527635285497};\\\", \\\"{x:1078,y:677,t:1527635285513};\\\", \\\"{x:1053,y:671,t:1527635285529};\\\", \\\"{x:1020,y:661,t:1527635285547};\\\", \\\"{x:962,y:648,t:1527635285564};\\\", \\\"{x:902,y:632,t:1527635285579};\\\", \\\"{x:826,y:617,t:1527635285596};\\\", \\\"{x:793,y:612,t:1527635285614};\\\", \\\"{x:772,y:605,t:1527635285629};\\\", \\\"{x:766,y:601,t:1527635285647};\\\", \\\"{x:765,y:601,t:1527635285663};\\\", \\\"{x:767,y:601,t:1527635285742};\\\", \\\"{x:774,y:603,t:1527635285749};\\\", \\\"{x:793,y:605,t:1527635285765};\\\", \\\"{x:813,y:608,t:1527635285782};\\\", \\\"{x:834,y:610,t:1527635285798};\\\", \\\"{x:850,y:614,t:1527635285816};\\\", \\\"{x:857,y:617,t:1527635285830};\\\", \\\"{x:859,y:617,t:1527635285847};\\\", \\\"{x:860,y:617,t:1527635285864};\\\", \\\"{x:860,y:616,t:1527635286133};\\\", \\\"{x:859,y:614,t:1527635286148};\\\", \\\"{x:855,y:609,t:1527635286166};\\\", \\\"{x:854,y:609,t:1527635286180};\\\", \\\"{x:853,y:607,t:1527635286212};\\\", \\\"{x:852,y:607,t:1527635286228};\\\", \\\"{x:851,y:606,t:1527635286245};\\\", \\\"{x:851,y:605,t:1527635286269};\\\", \\\"{x:850,y:605,t:1527635286281};\\\", \\\"{x:849,y:604,t:1527635286297};\\\", \\\"{x:846,y:605,t:1527635286517};\\\", \\\"{x:839,y:609,t:1527635286532};\\\", \\\"{x:811,y:621,t:1527635286548};\\\", \\\"{x:696,y:658,t:1527635286564};\\\", \\\"{x:614,y:686,t:1527635286581};\\\", \\\"{x:545,y:706,t:1527635286599};\\\", \\\"{x:494,y:722,t:1527635286615};\\\", \\\"{x:472,y:726,t:1527635286631};\\\", \\\"{x:461,y:728,t:1527635286647};\\\", \\\"{x:459,y:728,t:1527635286664};\\\", \\\"{x:460,y:728,t:1527635286692};\\\", \\\"{x:461,y:728,t:1527635286700};\\\", \\\"{x:463,y:728,t:1527635286716};\\\", \\\"{x:465,y:728,t:1527635286732};\\\", \\\"{x:484,y:722,t:1527635286749};\\\", \\\"{x:505,y:714,t:1527635286765};\\\", \\\"{x:524,y:709,t:1527635286781};\\\", \\\"{x:540,y:707,t:1527635286798};\\\", \\\"{x:551,y:705,t:1527635286815};\\\", \\\"{x:561,y:704,t:1527635286832};\\\", \\\"{x:562,y:703,t:1527635286849};\\\", \\\"{x:563,y:703,t:1527635287084};\\\", \\\"{x:563,y:705,t:1527635287098};\\\", \\\"{x:557,y:708,t:1527635287114};\\\", \\\"{x:550,y:710,t:1527635287131};\\\", \\\"{x:543,y:712,t:1527635287148};\\\", \\\"{x:541,y:712,t:1527635287164};\\\", \\\"{x:540,y:712,t:1527635287301};\\\", \\\"{x:540,y:712,t:1527635287302};\\\", \\\"{x:539,y:713,t:1527635287315};\\\", \\\"{x:540,y:713,t:1527635287398};\\\", \\\"{x:542,y:713,t:1527635287405};\\\", \\\"{x:544,y:713,t:1527635287421};\\\", \\\"{x:546,y:713,t:1527635287431};\\\", \\\"{x:553,y:713,t:1527635287449};\\\", \\\"{x:563,y:712,t:1527635287466};\\\", \\\"{x:588,y:712,t:1527635287481};\\\", \\\"{x:620,y:712,t:1527635287499};\\\", \\\"{x:673,y:712,t:1527635287515};\\\", \\\"{x:743,y:712,t:1527635287532};\\\", \\\"{x:870,y:712,t:1527635287549};\\\", \\\"{x:973,y:712,t:1527635287565};\\\", \\\"{x:1067,y:712,t:1527635287582};\\\", \\\"{x:1151,y:712,t:1527635287599};\\\", \\\"{x:1215,y:712,t:1527635287616};\\\", \\\"{x:1259,y:712,t:1527635287633};\\\", \\\"{x:1284,y:712,t:1527635287649};\\\", \\\"{x:1288,y:712,t:1527635287666};\\\", \\\"{x:1282,y:712,t:1527635287806};\\\", \\\"{x:1266,y:709,t:1527635287816};\\\", \\\"{x:1193,y:695,t:1527635287833};\\\", \\\"{x:1085,y:683,t:1527635287849};\\\", \\\"{x:966,y:683,t:1527635287866};\\\", \\\"{x:854,y:673,t:1527635287883};\\\", \\\"{x:760,y:663,t:1527635287899};\\\", \\\"{x:707,y:656,t:1527635287916};\\\", \\\"{x:674,y:650,t:1527635287933};\\\", \\\"{x:673,y:650,t:1527635287949};\\\" ] }, { \\\"rt\\\": 16028, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 323521, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"93XU7\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -U -I \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:672,y:650,t:1527635288469};\\\", \\\"{x:670,y:650,t:1527635288484};\\\", \\\"{x:669,y:650,t:1527635288499};\\\", \\\"{x:657,y:647,t:1527635288516};\\\", \\\"{x:654,y:646,t:1527635288532};\\\", \\\"{x:653,y:645,t:1527635288589};\\\", \\\"{x:653,y:644,t:1527635288613};\\\", \\\"{x:652,y:643,t:1527635288629};\\\", \\\"{x:631,y:621,t:1527635288745};\\\", \\\"{x:625,y:617,t:1527635288751};\\\", \\\"{x:620,y:612,t:1527635288766};\\\", \\\"{x:616,y:607,t:1527635288783};\\\", \\\"{x:613,y:603,t:1527635288800};\\\", \\\"{x:612,y:600,t:1527635288816};\\\", \\\"{x:609,y:594,t:1527635288833};\\\", \\\"{x:608,y:590,t:1527635288849};\\\", \\\"{x:607,y:589,t:1527635288867};\\\", \\\"{x:606,y:587,t:1527635288883};\\\", \\\"{x:606,y:586,t:1527635288925};\\\", \\\"{x:605,y:583,t:1527635288933};\\\", \\\"{x:604,y:573,t:1527635288949};\\\", \\\"{x:595,y:557,t:1527635288967};\\\", \\\"{x:586,y:537,t:1527635288985};\\\", \\\"{x:576,y:518,t:1527635289000};\\\", \\\"{x:561,y:500,t:1527635289017};\\\", \\\"{x:549,y:485,t:1527635289033};\\\", \\\"{x:539,y:474,t:1527635289049};\\\", \\\"{x:531,y:467,t:1527635289067};\\\", \\\"{x:529,y:465,t:1527635289084};\\\", \\\"{x:528,y:465,t:1527635289099};\\\", \\\"{x:525,y:465,t:1527635289117};\\\", \\\"{x:519,y:465,t:1527635289134};\\\", \\\"{x:505,y:468,t:1527635289151};\\\", \\\"{x:485,y:477,t:1527635289167};\\\", \\\"{x:468,y:483,t:1527635289184};\\\", \\\"{x:455,y:485,t:1527635289201};\\\", \\\"{x:448,y:485,t:1527635289217};\\\", \\\"{x:444,y:485,t:1527635289233};\\\", \\\"{x:443,y:485,t:1527635289250};\\\", \\\"{x:440,y:485,t:1527635289267};\\\", \\\"{x:439,y:485,t:1527635289292};\\\", \\\"{x:438,y:485,t:1527635289309};\\\", \\\"{x:436,y:485,t:1527635289325};\\\", \\\"{x:435,y:485,t:1527635289334};\\\", \\\"{x:432,y:482,t:1527635289351};\\\", \\\"{x:428,y:477,t:1527635289368};\\\", \\\"{x:424,y:472,t:1527635289384};\\\", \\\"{x:421,y:469,t:1527635289401};\\\", \\\"{x:418,y:466,t:1527635289417};\\\", \\\"{x:418,y:464,t:1527635289434};\\\", \\\"{x:415,y:464,t:1527635289451};\\\", \\\"{x:415,y:463,t:1527635289469};\\\", \\\"{x:414,y:463,t:1527635289492};\\\", \\\"{x:413,y:462,t:1527635289509};\\\", \\\"{x:412,y:462,t:1527635289533};\\\", \\\"{x:414,y:463,t:1527635289972};\\\", \\\"{x:417,y:465,t:1527635289986};\\\", \\\"{x:419,y:465,t:1527635290782};\\\", \\\"{x:420,y:465,t:1527635290789};\\\", \\\"{x:421,y:465,t:1527635290804};\\\", \\\"{x:423,y:465,t:1527635290821};\\\", \\\"{x:425,y:465,t:1527635290918};\\\", \\\"{x:425,y:466,t:1527635290926};\\\", \\\"{x:426,y:466,t:1527635290941};\\\", \\\"{x:427,y:466,t:1527635290954};\\\", \\\"{x:429,y:466,t:1527635290971};\\\", \\\"{x:432,y:466,t:1527635290988};\\\", \\\"{x:444,y:468,t:1527635291004};\\\", \\\"{x:460,y:470,t:1527635291020};\\\", \\\"{x:478,y:474,t:1527635291038};\\\", \\\"{x:504,y:476,t:1527635291055};\\\", \\\"{x:529,y:481,t:1527635291071};\\\", \\\"{x:557,y:485,t:1527635291088};\\\", \\\"{x:588,y:489,t:1527635291105};\\\", \\\"{x:615,y:492,t:1527635291121};\\\", \\\"{x:641,y:497,t:1527635291138};\\\", \\\"{x:659,y:499,t:1527635291155};\\\", \\\"{x:675,y:502,t:1527635291172};\\\", \\\"{x:685,y:503,t:1527635291188};\\\", \\\"{x:692,y:504,t:1527635291205};\\\", \\\"{x:695,y:504,t:1527635291222};\\\", \\\"{x:698,y:504,t:1527635291238};\\\", \\\"{x:699,y:504,t:1527635291255};\\\", \\\"{x:700,y:505,t:1527635291271};\\\", \\\"{x:701,y:505,t:1527635291289};\\\", \\\"{x:702,y:505,t:1527635291317};\\\", \\\"{x:703,y:505,t:1527635291342};\\\", \\\"{x:704,y:506,t:1527635291355};\\\", \\\"{x:704,y:507,t:1527635291389};\\\", \\\"{x:707,y:507,t:1527635291405};\\\", \\\"{x:711,y:510,t:1527635291422};\\\", \\\"{x:719,y:511,t:1527635291439};\\\", \\\"{x:728,y:514,t:1527635291456};\\\", \\\"{x:740,y:518,t:1527635291472};\\\", \\\"{x:757,y:523,t:1527635291491};\\\", \\\"{x:776,y:529,t:1527635291506};\\\", \\\"{x:796,y:534,t:1527635291521};\\\", \\\"{x:807,y:536,t:1527635291530};\\\", \\\"{x:832,y:541,t:1527635291548};\\\", \\\"{x:860,y:547,t:1527635291564};\\\", \\\"{x:901,y:554,t:1527635291580};\\\", \\\"{x:926,y:561,t:1527635291602};\\\", \\\"{x:951,y:569,t:1527635291619};\\\", \\\"{x:973,y:576,t:1527635291636};\\\", \\\"{x:994,y:581,t:1527635291651};\\\", \\\"{x:1019,y:589,t:1527635291669};\\\", \\\"{x:1034,y:594,t:1527635291686};\\\", \\\"{x:1042,y:597,t:1527635291703};\\\", \\\"{x:1054,y:603,t:1527635291718};\\\", \\\"{x:1063,y:608,t:1527635291736};\\\", \\\"{x:1071,y:613,t:1527635291753};\\\", \\\"{x:1075,y:616,t:1527635291769};\\\", \\\"{x:1077,y:618,t:1527635291786};\\\", \\\"{x:1079,y:620,t:1527635291803};\\\", \\\"{x:1081,y:622,t:1527635291820};\\\", \\\"{x:1082,y:625,t:1527635291836};\\\", \\\"{x:1083,y:627,t:1527635291853};\\\", \\\"{x:1083,y:628,t:1527635291870};\\\", \\\"{x:1085,y:629,t:1527635291886};\\\", \\\"{x:1085,y:631,t:1527635291910};\\\", \\\"{x:1085,y:632,t:1527635292430};\\\", \\\"{x:1089,y:632,t:1527635292438};\\\", \\\"{x:1112,y:632,t:1527635292455};\\\", \\\"{x:1148,y:641,t:1527635292472};\\\", \\\"{x:1220,y:663,t:1527635292489};\\\", \\\"{x:1313,y:682,t:1527635292505};\\\", \\\"{x:1406,y:718,t:1527635292522};\\\", \\\"{x:1481,y:752,t:1527635292539};\\\", \\\"{x:1521,y:774,t:1527635292556};\\\", \\\"{x:1542,y:788,t:1527635292573};\\\", \\\"{x:1560,y:813,t:1527635292590};\\\", \\\"{x:1561,y:828,t:1527635292606};\\\", \\\"{x:1561,y:837,t:1527635292623};\\\", \\\"{x:1558,y:846,t:1527635292639};\\\", \\\"{x:1554,y:855,t:1527635292656};\\\", \\\"{x:1546,y:863,t:1527635292673};\\\", \\\"{x:1542,y:866,t:1527635292690};\\\", \\\"{x:1535,y:869,t:1527635292706};\\\", \\\"{x:1530,y:870,t:1527635292722};\\\", \\\"{x:1527,y:870,t:1527635292740};\\\", \\\"{x:1524,y:870,t:1527635292757};\\\", \\\"{x:1525,y:869,t:1527635292830};\\\", \\\"{x:1528,y:868,t:1527635292840};\\\", \\\"{x:1538,y:863,t:1527635292857};\\\", \\\"{x:1553,y:859,t:1527635292874};\\\", \\\"{x:1573,y:857,t:1527635292890};\\\", \\\"{x:1596,y:857,t:1527635292907};\\\", \\\"{x:1622,y:857,t:1527635292923};\\\", \\\"{x:1641,y:857,t:1527635292940};\\\", \\\"{x:1658,y:857,t:1527635292957};\\\", \\\"{x:1668,y:857,t:1527635292974};\\\", \\\"{x:1670,y:856,t:1527635292991};\\\", \\\"{x:1670,y:855,t:1527635293021};\\\", \\\"{x:1670,y:852,t:1527635293029};\\\", \\\"{x:1670,y:849,t:1527635293040};\\\", \\\"{x:1670,y:839,t:1527635293057};\\\", \\\"{x:1670,y:824,t:1527635293075};\\\", \\\"{x:1670,y:806,t:1527635293090};\\\", \\\"{x:1670,y:784,t:1527635293107};\\\", \\\"{x:1666,y:762,t:1527635293124};\\\", \\\"{x:1660,y:739,t:1527635293141};\\\", \\\"{x:1648,y:706,t:1527635293158};\\\", \\\"{x:1643,y:691,t:1527635293174};\\\", \\\"{x:1636,y:680,t:1527635293192};\\\", \\\"{x:1630,y:666,t:1527635293207};\\\", \\\"{x:1623,y:653,t:1527635293225};\\\", \\\"{x:1618,y:645,t:1527635293242};\\\", \\\"{x:1616,y:641,t:1527635293257};\\\", \\\"{x:1613,y:639,t:1527635293275};\\\", \\\"{x:1610,y:634,t:1527635293291};\\\", \\\"{x:1606,y:630,t:1527635293308};\\\", \\\"{x:1599,y:625,t:1527635293325};\\\", \\\"{x:1588,y:613,t:1527635293341};\\\", \\\"{x:1579,y:602,t:1527635293359};\\\", \\\"{x:1562,y:590,t:1527635293376};\\\", \\\"{x:1539,y:569,t:1527635293391};\\\", \\\"{x:1511,y:550,t:1527635293409};\\\", \\\"{x:1489,y:535,t:1527635293425};\\\", \\\"{x:1475,y:524,t:1527635293441};\\\", \\\"{x:1464,y:516,t:1527635293458};\\\", \\\"{x:1459,y:513,t:1527635293475};\\\", \\\"{x:1458,y:512,t:1527635293493};\\\", \\\"{x:1458,y:510,t:1527635293637};\\\", \\\"{x:1458,y:508,t:1527635293645};\\\", \\\"{x:1458,y:504,t:1527635293659};\\\", \\\"{x:1458,y:497,t:1527635293675};\\\", \\\"{x:1459,y:488,t:1527635293693};\\\", \\\"{x:1464,y:479,t:1527635293710};\\\", \\\"{x:1465,y:477,t:1527635293726};\\\", \\\"{x:1465,y:476,t:1527635293743};\\\", \\\"{x:1465,y:475,t:1527635293766};\\\", \\\"{x:1465,y:474,t:1527635293777};\\\", \\\"{x:1465,y:473,t:1527635293794};\\\", \\\"{x:1464,y:471,t:1527635293809};\\\", \\\"{x:1463,y:470,t:1527635293826};\\\", \\\"{x:1463,y:468,t:1527635294422};\\\", \\\"{x:1461,y:463,t:1527635294429};\\\", \\\"{x:1460,y:459,t:1527635294445};\\\", \\\"{x:1459,y:456,t:1527635294462};\\\", \\\"{x:1459,y:455,t:1527635294479};\\\", \\\"{x:1457,y:456,t:1527635294758};\\\", \\\"{x:1457,y:458,t:1527635294766};\\\", \\\"{x:1456,y:460,t:1527635294780};\\\", \\\"{x:1455,y:461,t:1527635294796};\\\", \\\"{x:1454,y:464,t:1527635294813};\\\", \\\"{x:1453,y:468,t:1527635294828};\\\", \\\"{x:1452,y:473,t:1527635294846};\\\", \\\"{x:1452,y:477,t:1527635294862};\\\", \\\"{x:1450,y:485,t:1527635294879};\\\", \\\"{x:1448,y:494,t:1527635294896};\\\", \\\"{x:1446,y:500,t:1527635294913};\\\", \\\"{x:1444,y:507,t:1527635294930};\\\", \\\"{x:1443,y:514,t:1527635294946};\\\", \\\"{x:1442,y:519,t:1527635294963};\\\", \\\"{x:1441,y:523,t:1527635294980};\\\", \\\"{x:1441,y:525,t:1527635294997};\\\", \\\"{x:1439,y:532,t:1527635295013};\\\", \\\"{x:1437,y:537,t:1527635295031};\\\", \\\"{x:1435,y:546,t:1527635295048};\\\", \\\"{x:1431,y:560,t:1527635295063};\\\", \\\"{x:1426,y:578,t:1527635295080};\\\", \\\"{x:1420,y:599,t:1527635295097};\\\", \\\"{x:1413,y:626,t:1527635295113};\\\", \\\"{x:1405,y:660,t:1527635295131};\\\", \\\"{x:1393,y:704,t:1527635295148};\\\", \\\"{x:1380,y:744,t:1527635295164};\\\", \\\"{x:1369,y:773,t:1527635295181};\\\", \\\"{x:1356,y:814,t:1527635295197};\\\", \\\"{x:1346,y:835,t:1527635295214};\\\", \\\"{x:1338,y:855,t:1527635295231};\\\", \\\"{x:1331,y:868,t:1527635295247};\\\", \\\"{x:1329,y:874,t:1527635295264};\\\", \\\"{x:1328,y:876,t:1527635295282};\\\", \\\"{x:1327,y:877,t:1527635295517};\\\", \\\"{x:1327,y:878,t:1527635295531};\\\", \\\"{x:1327,y:883,t:1527635295548};\\\", \\\"{x:1327,y:890,t:1527635295565};\\\", \\\"{x:1329,y:894,t:1527635295582};\\\", \\\"{x:1334,y:897,t:1527635295598};\\\", \\\"{x:1342,y:901,t:1527635295616};\\\", \\\"{x:1347,y:904,t:1527635295633};\\\", \\\"{x:1350,y:905,t:1527635295648};\\\", \\\"{x:1355,y:905,t:1527635295666};\\\", \\\"{x:1359,y:905,t:1527635295683};\\\", \\\"{x:1365,y:905,t:1527635295700};\\\", \\\"{x:1373,y:905,t:1527635295715};\\\", \\\"{x:1382,y:905,t:1527635295732};\\\", \\\"{x:1401,y:901,t:1527635295749};\\\", \\\"{x:1414,y:896,t:1527635295766};\\\", \\\"{x:1428,y:888,t:1527635295783};\\\", \\\"{x:1439,y:879,t:1527635295800};\\\", \\\"{x:1452,y:869,t:1527635295817};\\\", \\\"{x:1464,y:861,t:1527635295833};\\\", \\\"{x:1474,y:852,t:1527635295849};\\\", \\\"{x:1478,y:847,t:1527635295867};\\\", \\\"{x:1480,y:842,t:1527635295884};\\\", \\\"{x:1482,y:839,t:1527635295899};\\\", \\\"{x:1483,y:835,t:1527635295919};\\\", \\\"{x:1484,y:832,t:1527635295933};\\\", \\\"{x:1485,y:829,t:1527635295949};\\\", \\\"{x:1486,y:827,t:1527635295967};\\\", \\\"{x:1486,y:824,t:1527635295984};\\\", \\\"{x:1489,y:820,t:1527635296000};\\\", \\\"{x:1490,y:817,t:1527635296017};\\\", \\\"{x:1492,y:813,t:1527635296034};\\\", \\\"{x:1497,y:808,t:1527635296051};\\\", \\\"{x:1501,y:804,t:1527635296067};\\\", \\\"{x:1506,y:798,t:1527635296084};\\\", \\\"{x:1512,y:792,t:1527635296101};\\\", \\\"{x:1520,y:784,t:1527635296118};\\\", \\\"{x:1526,y:780,t:1527635296133};\\\", \\\"{x:1531,y:779,t:1527635296151};\\\", \\\"{x:1533,y:776,t:1527635296167};\\\", \\\"{x:1538,y:773,t:1527635296185};\\\", \\\"{x:1546,y:771,t:1527635296201};\\\", \\\"{x:1556,y:768,t:1527635296218};\\\", \\\"{x:1568,y:764,t:1527635296234};\\\", \\\"{x:1580,y:762,t:1527635296250};\\\", \\\"{x:1592,y:760,t:1527635296268};\\\", \\\"{x:1601,y:760,t:1527635296285};\\\", \\\"{x:1610,y:760,t:1527635296301};\\\", \\\"{x:1613,y:760,t:1527635296318};\\\", \\\"{x:1618,y:760,t:1527635296335};\\\", \\\"{x:1624,y:760,t:1527635296352};\\\", \\\"{x:1628,y:760,t:1527635296368};\\\", \\\"{x:1632,y:760,t:1527635296384};\\\", \\\"{x:1634,y:759,t:1527635296402};\\\", \\\"{x:1635,y:754,t:1527635296419};\\\", \\\"{x:1636,y:741,t:1527635296435};\\\", \\\"{x:1636,y:723,t:1527635296452};\\\", \\\"{x:1634,y:710,t:1527635296468};\\\", \\\"{x:1629,y:697,t:1527635296485};\\\", \\\"{x:1613,y:673,t:1527635296501};\\\", \\\"{x:1597,y:656,t:1527635296519};\\\", \\\"{x:1578,y:639,t:1527635296536};\\\", \\\"{x:1560,y:625,t:1527635296552};\\\", \\\"{x:1548,y:615,t:1527635296569};\\\", \\\"{x:1542,y:608,t:1527635296585};\\\", \\\"{x:1537,y:602,t:1527635296603};\\\", \\\"{x:1531,y:595,t:1527635296619};\\\", \\\"{x:1526,y:588,t:1527635296636};\\\", \\\"{x:1524,y:584,t:1527635296652};\\\", \\\"{x:1524,y:581,t:1527635296668};\\\", \\\"{x:1524,y:578,t:1527635296685};\\\", \\\"{x:1524,y:574,t:1527635296702};\\\", \\\"{x:1527,y:566,t:1527635296720};\\\", \\\"{x:1538,y:550,t:1527635296736};\\\", \\\"{x:1556,y:529,t:1527635296753};\\\", \\\"{x:1577,y:505,t:1527635296769};\\\", \\\"{x:1596,y:490,t:1527635296786};\\\", \\\"{x:1612,y:479,t:1527635296802};\\\", \\\"{x:1618,y:475,t:1527635296819};\\\", \\\"{x:1620,y:474,t:1527635296837};\\\", \\\"{x:1620,y:471,t:1527635297334};\\\", \\\"{x:1619,y:466,t:1527635297341};\\\", \\\"{x:1618,y:460,t:1527635297355};\\\", \\\"{x:1614,y:454,t:1527635297372};\\\", \\\"{x:1613,y:449,t:1527635297388};\\\", \\\"{x:1610,y:444,t:1527635297405};\\\", \\\"{x:1608,y:439,t:1527635297421};\\\", \\\"{x:1606,y:437,t:1527635297439};\\\", \\\"{x:1606,y:435,t:1527635297455};\\\", \\\"{x:1604,y:434,t:1527635297472};\\\", \\\"{x:1603,y:432,t:1527635297489};\\\", \\\"{x:1598,y:427,t:1527635297518};\\\", \\\"{x:1595,y:425,t:1527635297524};\\\", \\\"{x:1590,y:420,t:1527635297538};\\\", \\\"{x:1578,y:409,t:1527635297555};\\\", \\\"{x:1565,y:398,t:1527635297571};\\\", \\\"{x:1551,y:387,t:1527635297588};\\\", \\\"{x:1527,y:371,t:1527635297604};\\\", \\\"{x:1514,y:364,t:1527635297621};\\\", \\\"{x:1508,y:361,t:1527635297638};\\\", \\\"{x:1505,y:360,t:1527635297656};\\\", \\\"{x:1504,y:359,t:1527635297672};\\\", \\\"{x:1503,y:360,t:1527635297734};\\\", \\\"{x:1499,y:365,t:1527635297741};\\\", \\\"{x:1494,y:375,t:1527635297756};\\\", \\\"{x:1480,y:393,t:1527635297773};\\\", \\\"{x:1452,y:432,t:1527635297789};\\\", \\\"{x:1425,y:465,t:1527635297805};\\\", \\\"{x:1399,y:495,t:1527635297823};\\\", \\\"{x:1374,y:523,t:1527635297839};\\\", \\\"{x:1351,y:550,t:1527635297856};\\\", \\\"{x:1339,y:565,t:1527635297872};\\\", \\\"{x:1333,y:572,t:1527635297889};\\\", \\\"{x:1332,y:574,t:1527635297906};\\\", \\\"{x:1332,y:573,t:1527635297966};\\\", \\\"{x:1332,y:569,t:1527635297973};\\\", \\\"{x:1332,y:554,t:1527635297990};\\\", \\\"{x:1332,y:538,t:1527635298007};\\\", \\\"{x:1328,y:522,t:1527635298023};\\\", \\\"{x:1327,y:512,t:1527635298039};\\\", \\\"{x:1327,y:505,t:1527635298056};\\\", \\\"{x:1325,y:500,t:1527635298073};\\\", \\\"{x:1324,y:497,t:1527635298090};\\\", \\\"{x:1324,y:494,t:1527635298106};\\\", \\\"{x:1324,y:492,t:1527635298123};\\\", \\\"{x:1324,y:491,t:1527635298237};\\\", \\\"{x:1323,y:491,t:1527635298244};\\\", \\\"{x:1322,y:491,t:1527635298257};\\\", \\\"{x:1321,y:492,t:1527635298274};\\\", \\\"{x:1319,y:492,t:1527635298290};\\\", \\\"{x:1318,y:494,t:1527635298607};\\\", \\\"{x:1317,y:495,t:1527635298626};\\\", \\\"{x:1316,y:496,t:1527635298662};\\\", \\\"{x:1316,y:497,t:1527635301966};\\\", \\\"{x:1315,y:497,t:1527635301973};\\\", \\\"{x:1314,y:499,t:1527635301986};\\\", \\\"{x:1314,y:500,t:1527635302002};\\\", \\\"{x:1312,y:501,t:1527635302318};\\\", \\\"{x:1312,y:503,t:1527635302335};\\\", \\\"{x:1312,y:504,t:1527635302350};\\\", \\\"{x:1311,y:505,t:1527635302358};\\\", \\\"{x:1311,y:506,t:1527635302373};\\\", \\\"{x:1311,y:507,t:1527635302422};\\\", \\\"{x:1311,y:509,t:1527635302445};\\\", \\\"{x:1311,y:510,t:1527635302478};\\\", \\\"{x:1310,y:511,t:1527635302493};\\\", \\\"{x:1309,y:512,t:1527635302509};\\\", \\\"{x:1309,y:513,t:1527635302525};\\\", \\\"{x:1309,y:514,t:1527635302537};\\\", \\\"{x:1309,y:515,t:1527635302555};\\\", \\\"{x:1305,y:521,t:1527635302572};\\\", \\\"{x:1299,y:532,t:1527635302587};\\\", \\\"{x:1286,y:563,t:1527635302605};\\\", \\\"{x:1256,y:613,t:1527635302622};\\\", \\\"{x:1206,y:685,t:1527635302639};\\\", \\\"{x:1135,y:760,t:1527635302655};\\\", \\\"{x:1024,y:839,t:1527635302672};\\\", \\\"{x:910,y:892,t:1527635302688};\\\", \\\"{x:809,y:914,t:1527635302705};\\\", \\\"{x:711,y:922,t:1527635302721};\\\", \\\"{x:619,y:922,t:1527635302738};\\\", \\\"{x:537,y:917,t:1527635302756};\\\", \\\"{x:492,y:902,t:1527635302772};\\\", \\\"{x:463,y:888,t:1527635302789};\\\", \\\"{x:458,y:882,t:1527635302805};\\\", \\\"{x:458,y:872,t:1527635302822};\\\", \\\"{x:458,y:859,t:1527635302838};\\\", \\\"{x:480,y:818,t:1527635302855};\\\", \\\"{x:511,y:761,t:1527635302873};\\\", \\\"{x:528,y:713,t:1527635302888};\\\", \\\"{x:538,y:683,t:1527635302905};\\\", \\\"{x:551,y:660,t:1527635302924};\\\", \\\"{x:558,y:646,t:1527635302940};\\\", \\\"{x:562,y:640,t:1527635302955};\\\", \\\"{x:561,y:640,t:1527635303012};\\\", \\\"{x:550,y:642,t:1527635303028};\\\", \\\"{x:530,y:650,t:1527635303044};\\\", \\\"{x:498,y:661,t:1527635303062};\\\", \\\"{x:463,y:669,t:1527635303078};\\\", \\\"{x:429,y:675,t:1527635303094};\\\", \\\"{x:401,y:677,t:1527635303111};\\\", \\\"{x:380,y:677,t:1527635303128};\\\", \\\"{x:366,y:677,t:1527635303144};\\\", \\\"{x:359,y:673,t:1527635303161};\\\", \\\"{x:356,y:670,t:1527635303178};\\\", \\\"{x:354,y:666,t:1527635303194};\\\", \\\"{x:351,y:658,t:1527635303212};\\\", \\\"{x:350,y:650,t:1527635303228};\\\", \\\"{x:349,y:642,t:1527635303245};\\\", \\\"{x:346,y:631,t:1527635303263};\\\", \\\"{x:344,y:619,t:1527635303279};\\\", \\\"{x:337,y:606,t:1527635303294};\\\", \\\"{x:328,y:593,t:1527635303312};\\\", \\\"{x:317,y:587,t:1527635303328};\\\", \\\"{x:305,y:583,t:1527635303344};\\\", \\\"{x:294,y:583,t:1527635303361};\\\", \\\"{x:283,y:582,t:1527635303378};\\\", \\\"{x:273,y:582,t:1527635303394};\\\", \\\"{x:264,y:583,t:1527635303412};\\\", \\\"{x:248,y:588,t:1527635303428};\\\", \\\"{x:236,y:594,t:1527635303446};\\\", \\\"{x:223,y:598,t:1527635303461};\\\", \\\"{x:210,y:602,t:1527635303478};\\\", \\\"{x:199,y:603,t:1527635303495};\\\", \\\"{x:189,y:604,t:1527635303512};\\\", \\\"{x:180,y:605,t:1527635303528};\\\", \\\"{x:176,y:605,t:1527635303545};\\\", \\\"{x:175,y:606,t:1527635303804};\\\", \\\"{x:178,y:612,t:1527635303812};\\\", \\\"{x:192,y:625,t:1527635303829};\\\", \\\"{x:214,y:639,t:1527635303846};\\\", \\\"{x:250,y:656,t:1527635303862};\\\", \\\"{x:303,y:670,t:1527635303879};\\\", \\\"{x:372,y:688,t:1527635303895};\\\", \\\"{x:425,y:702,t:1527635303912};\\\", \\\"{x:471,y:714,t:1527635303928};\\\", \\\"{x:502,y:724,t:1527635303946};\\\", \\\"{x:521,y:729,t:1527635303963};\\\", \\\"{x:535,y:730,t:1527635303978};\\\", \\\"{x:543,y:731,t:1527635303995};\\\", \\\"{x:545,y:731,t:1527635304012};\\\", \\\"{x:549,y:729,t:1527635304028};\\\", \\\"{x:550,y:726,t:1527635304045};\\\", \\\"{x:552,y:722,t:1527635304062};\\\", \\\"{x:553,y:720,t:1527635304078};\\\", \\\"{x:556,y:718,t:1527635304469};\\\", \\\"{x:560,y:718,t:1527635304480};\\\", \\\"{x:579,y:717,t:1527635304495};\\\", \\\"{x:609,y:717,t:1527635304512};\\\", \\\"{x:657,y:717,t:1527635304530};\\\", \\\"{x:718,y:717,t:1527635304545};\\\", \\\"{x:785,y:717,t:1527635304562};\\\", \\\"{x:852,y:717,t:1527635304579};\\\", \\\"{x:905,y:717,t:1527635304595};\\\", \\\"{x:980,y:717,t:1527635304612};\\\", \\\"{x:1012,y:717,t:1527635304629};\\\", \\\"{x:1037,y:717,t:1527635304645};\\\", \\\"{x:1052,y:717,t:1527635304662};\\\", \\\"{x:1063,y:717,t:1527635304680};\\\", \\\"{x:1077,y:721,t:1527635304696};\\\", \\\"{x:1099,y:726,t:1527635304712};\\\", \\\"{x:1105,y:728,t:1527635304730};\\\", \\\"{x:1109,y:733,t:1527635304746};\\\", \\\"{x:1108,y:729,t:1527635305337};\\\", \\\"{x:1106,y:728,t:1527635305363};\\\", \\\"{x:1106,y:726,t:1527635305379};\\\", \\\"{x:1105,y:725,t:1527635305396};\\\", \\\"{x:1104,y:724,t:1527635305414};\\\", \\\"{x:1104,y:722,t:1527635305429};\\\", \\\"{x:1103,y:721,t:1527635305446};\\\", \\\"{x:1102,y:718,t:1527635305464};\\\" ] }, { \\\"rt\\\": 28492, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 353385, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"93XU7\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -E -E -F -F -F -F -F -E -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1101,y:658,t:1527635305641};\\\", \\\"{x:1101,y:657,t:1527635305651};\\\", \\\"{x:1101,y:649,t:1527635305669};\\\", \\\"{x:1101,y:645,t:1527635305679};\\\", \\\"{x:1101,y:638,t:1527635305696};\\\", \\\"{x:1101,y:634,t:1527635305713};\\\", \\\"{x:1102,y:627,t:1527635305729};\\\", \\\"{x:1104,y:623,t:1527635305746};\\\", \\\"{x:1104,y:622,t:1527635305763};\\\", \\\"{x:1110,y:610,t:1527635305796};\\\", \\\"{x:1113,y:602,t:1527635305814};\\\", \\\"{x:1115,y:593,t:1527635305830};\\\", \\\"{x:1116,y:584,t:1527635305846};\\\", \\\"{x:1117,y:575,t:1527635305863};\\\", \\\"{x:1120,y:561,t:1527635305880};\\\", \\\"{x:1121,y:548,t:1527635305896};\\\", \\\"{x:1121,y:537,t:1527635305914};\\\", \\\"{x:1121,y:528,t:1527635305930};\\\", \\\"{x:1120,y:516,t:1527635305946};\\\", \\\"{x:1114,y:503,t:1527635305963};\\\", \\\"{x:1102,y:484,t:1527635305980};\\\", \\\"{x:1092,y:475,t:1527635305996};\\\", \\\"{x:1080,y:470,t:1527635306013};\\\", \\\"{x:1064,y:465,t:1527635306030};\\\", \\\"{x:1046,y:462,t:1527635306047};\\\", \\\"{x:1021,y:460,t:1527635306063};\\\", \\\"{x:1002,y:457,t:1527635306080};\\\", \\\"{x:987,y:456,t:1527635306098};\\\", \\\"{x:974,y:455,t:1527635306114};\\\", \\\"{x:969,y:454,t:1527635306130};\\\", \\\"{x:967,y:453,t:1527635306227};\\\", \\\"{x:966,y:453,t:1527635306268};\\\", \\\"{x:966,y:452,t:1527635306284};\\\", \\\"{x:965,y:452,t:1527635306308};\\\", \\\"{x:964,y:450,t:1527635306316};\\\", \\\"{x:963,y:449,t:1527635306349};\\\", \\\"{x:963,y:448,t:1527635306363};\\\", \\\"{x:963,y:445,t:1527635306380};\\\", \\\"{x:963,y:444,t:1527635306397};\\\", \\\"{x:963,y:443,t:1527635306414};\\\", \\\"{x:963,y:441,t:1527635306431};\\\", \\\"{x:963,y:440,t:1527635306447};\\\", \\\"{x:963,y:436,t:1527635306463};\\\", \\\"{x:965,y:431,t:1527635306481};\\\", \\\"{x:968,y:428,t:1527635306497};\\\", \\\"{x:969,y:425,t:1527635306514};\\\", \\\"{x:971,y:423,t:1527635306531};\\\", \\\"{x:972,y:422,t:1527635306547};\\\", \\\"{x:973,y:419,t:1527635306564};\\\", \\\"{x:974,y:418,t:1527635306588};\\\", \\\"{x:975,y:416,t:1527635306612};\\\", \\\"{x:976,y:416,t:1527635306621};\\\", \\\"{x:976,y:415,t:1527635306637};\\\", \\\"{x:977,y:414,t:1527635306647};\\\", \\\"{x:978,y:413,t:1527635306664};\\\", \\\"{x:979,y:412,t:1527635306725};\\\", \\\"{x:980,y:411,t:1527635306741};\\\", \\\"{x:981,y:410,t:1527635306757};\\\", \\\"{x:983,y:410,t:1527635306765};\\\", \\\"{x:984,y:409,t:1527635306781};\\\", \\\"{x:985,y:408,t:1527635306797};\\\", \\\"{x:986,y:408,t:1527635306815};\\\", \\\"{x:988,y:408,t:1527635306831};\\\", \\\"{x:989,y:408,t:1527635306848};\\\", \\\"{x:992,y:408,t:1527635306865};\\\", \\\"{x:995,y:408,t:1527635306881};\\\", \\\"{x:999,y:409,t:1527635306897};\\\", \\\"{x:1002,y:412,t:1527635306915};\\\", \\\"{x:1008,y:417,t:1527635306931};\\\", \\\"{x:1014,y:425,t:1527635306947};\\\", \\\"{x:1024,y:438,t:1527635306964};\\\", \\\"{x:1033,y:451,t:1527635306982};\\\", \\\"{x:1042,y:462,t:1527635306997};\\\", \\\"{x:1054,y:478,t:1527635307014};\\\", \\\"{x:1067,y:494,t:1527635307032};\\\", \\\"{x:1083,y:513,t:1527635307047};\\\", \\\"{x:1097,y:528,t:1527635307065};\\\", \\\"{x:1110,y:543,t:1527635307082};\\\", \\\"{x:1121,y:558,t:1527635307098};\\\", \\\"{x:1132,y:572,t:1527635307115};\\\", \\\"{x:1140,y:586,t:1527635307132};\\\", \\\"{x:1145,y:598,t:1527635307148};\\\", \\\"{x:1154,y:620,t:1527635307165};\\\", \\\"{x:1161,y:635,t:1527635307181};\\\", \\\"{x:1167,y:649,t:1527635307198};\\\", \\\"{x:1171,y:659,t:1527635307214};\\\", \\\"{x:1176,y:667,t:1527635307232};\\\", \\\"{x:1177,y:673,t:1527635307248};\\\", \\\"{x:1178,y:675,t:1527635307265};\\\", \\\"{x:1179,y:675,t:1527635307282};\\\", \\\"{x:1179,y:676,t:1527635307342};\\\", \\\"{x:1179,y:677,t:1527635307373};\\\", \\\"{x:1180,y:678,t:1527635307382};\\\", \\\"{x:1181,y:679,t:1527635307406};\\\", \\\"{x:1183,y:681,t:1527635307415};\\\", \\\"{x:1187,y:682,t:1527635307432};\\\", \\\"{x:1195,y:684,t:1527635307449};\\\", \\\"{x:1210,y:685,t:1527635307465};\\\", \\\"{x:1229,y:685,t:1527635307482};\\\", \\\"{x:1247,y:685,t:1527635307499};\\\", \\\"{x:1268,y:682,t:1527635307515};\\\", \\\"{x:1285,y:674,t:1527635307533};\\\", \\\"{x:1306,y:653,t:1527635307549};\\\", \\\"{x:1312,y:637,t:1527635307565};\\\", \\\"{x:1315,y:623,t:1527635307582};\\\", \\\"{x:1316,y:610,t:1527635307599};\\\", \\\"{x:1316,y:604,t:1527635307614};\\\", \\\"{x:1316,y:598,t:1527635307632};\\\", \\\"{x:1316,y:593,t:1527635307648};\\\", \\\"{x:1316,y:589,t:1527635307664};\\\", \\\"{x:1315,y:586,t:1527635307681};\\\", \\\"{x:1312,y:583,t:1527635307699};\\\", \\\"{x:1311,y:583,t:1527635307714};\\\", \\\"{x:1310,y:582,t:1527635307731};\\\", \\\"{x:1306,y:581,t:1527635307748};\\\", \\\"{x:1303,y:581,t:1527635307765};\\\", \\\"{x:1298,y:581,t:1527635307782};\\\", \\\"{x:1290,y:584,t:1527635307799};\\\", \\\"{x:1283,y:588,t:1527635307815};\\\", \\\"{x:1278,y:591,t:1527635307831};\\\", \\\"{x:1273,y:593,t:1527635307849};\\\", \\\"{x:1272,y:593,t:1527635307864};\\\", \\\"{x:1271,y:593,t:1527635307925};\\\", \\\"{x:1271,y:589,t:1527635307933};\\\", \\\"{x:1271,y:585,t:1527635307950};\\\", \\\"{x:1273,y:579,t:1527635307965};\\\", \\\"{x:1276,y:574,t:1527635307982};\\\", \\\"{x:1276,y:572,t:1527635307999};\\\", \\\"{x:1276,y:570,t:1527635308016};\\\", \\\"{x:1276,y:569,t:1527635308190};\\\", \\\"{x:1276,y:568,t:1527635308199};\\\", \\\"{x:1276,y:566,t:1527635308216};\\\", \\\"{x:1279,y:559,t:1527635308231};\\\", \\\"{x:1279,y:557,t:1527635308249};\\\", \\\"{x:1279,y:556,t:1527635308265};\\\", \\\"{x:1279,y:555,t:1527635308281};\\\", \\\"{x:1280,y:554,t:1527635311038};\\\", \\\"{x:1281,y:554,t:1527635311051};\\\", \\\"{x:1283,y:556,t:1527635311068};\\\", \\\"{x:1285,y:557,t:1527635311085};\\\", \\\"{x:1287,y:560,t:1527635311101};\\\", \\\"{x:1287,y:561,t:1527635311118};\\\", \\\"{x:1288,y:561,t:1527635311134};\\\", \\\"{x:1288,y:562,t:1527635311237};\\\", \\\"{x:1286,y:562,t:1527635311390};\\\", \\\"{x:1285,y:562,t:1527635311401};\\\", \\\"{x:1281,y:562,t:1527635311418};\\\", \\\"{x:1277,y:562,t:1527635311435};\\\", \\\"{x:1276,y:562,t:1527635311451};\\\", \\\"{x:1277,y:563,t:1527635311645};\\\", \\\"{x:1278,y:563,t:1527635311653};\\\", \\\"{x:1279,y:564,t:1527635311668};\\\", \\\"{x:1280,y:564,t:1527635311685};\\\", \\\"{x:1281,y:565,t:1527635311701};\\\", \\\"{x:1282,y:565,t:1527635311733};\\\", \\\"{x:1282,y:564,t:1527635318516};\\\", \\\"{x:1282,y:563,t:1527635318532};\\\", \\\"{x:1282,y:562,t:1527635318548};\\\", \\\"{x:1284,y:560,t:1527635318556};\\\", \\\"{x:1284,y:559,t:1527635318573};\\\", \\\"{x:1285,y:555,t:1527635318590};\\\", \\\"{x:1286,y:551,t:1527635318606};\\\", \\\"{x:1288,y:548,t:1527635318623};\\\", \\\"{x:1288,y:546,t:1527635318640};\\\", \\\"{x:1289,y:541,t:1527635318656};\\\", \\\"{x:1291,y:534,t:1527635318674};\\\", \\\"{x:1293,y:529,t:1527635318690};\\\", \\\"{x:1293,y:525,t:1527635318706};\\\", \\\"{x:1295,y:521,t:1527635318723};\\\", \\\"{x:1296,y:517,t:1527635318740};\\\", \\\"{x:1297,y:513,t:1527635318756};\\\", \\\"{x:1299,y:508,t:1527635318773};\\\", \\\"{x:1299,y:506,t:1527635318790};\\\", \\\"{x:1299,y:505,t:1527635318807};\\\", \\\"{x:1299,y:504,t:1527635318853};\\\", \\\"{x:1299,y:507,t:1527635319140};\\\", \\\"{x:1299,y:521,t:1527635319156};\\\", \\\"{x:1299,y:532,t:1527635319173};\\\", \\\"{x:1299,y:541,t:1527635319190};\\\", \\\"{x:1299,y:545,t:1527635319207};\\\", \\\"{x:1299,y:548,t:1527635319223};\\\", \\\"{x:1299,y:549,t:1527635319240};\\\", \\\"{x:1299,y:548,t:1527635319637};\\\", \\\"{x:1299,y:544,t:1527635319789};\\\", \\\"{x:1303,y:539,t:1527635319797};\\\", \\\"{x:1306,y:536,t:1527635319808};\\\", \\\"{x:1310,y:527,t:1527635319824};\\\", \\\"{x:1315,y:521,t:1527635319841};\\\", \\\"{x:1323,y:506,t:1527635319858};\\\", \\\"{x:1328,y:495,t:1527635319875};\\\", \\\"{x:1334,y:481,t:1527635319892};\\\", \\\"{x:1339,y:463,t:1527635319907};\\\", \\\"{x:1343,y:445,t:1527635319925};\\\", \\\"{x:1354,y:421,t:1527635319941};\\\", \\\"{x:1362,y:406,t:1527635319958};\\\", \\\"{x:1376,y:388,t:1527635319974};\\\", \\\"{x:1389,y:373,t:1527635319991};\\\", \\\"{x:1403,y:360,t:1527635320008};\\\", \\\"{x:1417,y:355,t:1527635320024};\\\", \\\"{x:1423,y:351,t:1527635320042};\\\", \\\"{x:1425,y:350,t:1527635320058};\\\", \\\"{x:1428,y:350,t:1527635320102};\\\", \\\"{x:1431,y:353,t:1527635320109};\\\", \\\"{x:1443,y:363,t:1527635320125};\\\", \\\"{x:1455,y:379,t:1527635320142};\\\", \\\"{x:1466,y:400,t:1527635320158};\\\", \\\"{x:1475,y:418,t:1527635320175};\\\", \\\"{x:1480,y:432,t:1527635320192};\\\", \\\"{x:1481,y:440,t:1527635320208};\\\", \\\"{x:1481,y:446,t:1527635320225};\\\", \\\"{x:1481,y:457,t:1527635320242};\\\", \\\"{x:1478,y:469,t:1527635320258};\\\", \\\"{x:1472,y:481,t:1527635320274};\\\", \\\"{x:1468,y:486,t:1527635320292};\\\", \\\"{x:1466,y:488,t:1527635320309};\\\", \\\"{x:1462,y:491,t:1527635320325};\\\", \\\"{x:1459,y:492,t:1527635320341};\\\", \\\"{x:1454,y:495,t:1527635320359};\\\", \\\"{x:1446,y:495,t:1527635320375};\\\", \\\"{x:1434,y:495,t:1527635320392};\\\", \\\"{x:1423,y:496,t:1527635320409};\\\", \\\"{x:1408,y:501,t:1527635320425};\\\", \\\"{x:1393,y:505,t:1527635320441};\\\", \\\"{x:1379,y:511,t:1527635320458};\\\", \\\"{x:1360,y:522,t:1527635320474};\\\", \\\"{x:1343,y:535,t:1527635320492};\\\", \\\"{x:1323,y:562,t:1527635320509};\\\", \\\"{x:1313,y:582,t:1527635320525};\\\", \\\"{x:1308,y:599,t:1527635320541};\\\", \\\"{x:1303,y:619,t:1527635320558};\\\", \\\"{x:1302,y:635,t:1527635320574};\\\", \\\"{x:1302,y:654,t:1527635320591};\\\", \\\"{x:1304,y:669,t:1527635320609};\\\", \\\"{x:1309,y:678,t:1527635320625};\\\", \\\"{x:1311,y:681,t:1527635320641};\\\", \\\"{x:1314,y:685,t:1527635320659};\\\", \\\"{x:1319,y:689,t:1527635320675};\\\", \\\"{x:1325,y:692,t:1527635320691};\\\", \\\"{x:1330,y:694,t:1527635320708};\\\", \\\"{x:1331,y:694,t:1527635320725};\\\", \\\"{x:1332,y:694,t:1527635320741};\\\", \\\"{x:1333,y:694,t:1527635320836};\\\", \\\"{x:1335,y:693,t:1527635320844};\\\", \\\"{x:1336,y:692,t:1527635320858};\\\", \\\"{x:1337,y:691,t:1527635320875};\\\", \\\"{x:1338,y:690,t:1527635320980};\\\", \\\"{x:1340,y:690,t:1527635320997};\\\", \\\"{x:1340,y:691,t:1527635321008};\\\", \\\"{x:1342,y:694,t:1527635321025};\\\", \\\"{x:1343,y:695,t:1527635321041};\\\", \\\"{x:1344,y:693,t:1527635321612};\\\", \\\"{x:1344,y:692,t:1527635321636};\\\", \\\"{x:1344,y:690,t:1527635321660};\\\", \\\"{x:1345,y:689,t:1527635321675};\\\", \\\"{x:1345,y:688,t:1527635321692};\\\", \\\"{x:1345,y:687,t:1527635321708};\\\", \\\"{x:1345,y:686,t:1527635321733};\\\", \\\"{x:1345,y:685,t:1527635321742};\\\", \\\"{x:1346,y:683,t:1527635321759};\\\", \\\"{x:1347,y:683,t:1527635321909};\\\", \\\"{x:1352,y:683,t:1527635321926};\\\", \\\"{x:1353,y:683,t:1527635321973};\\\", \\\"{x:1354,y:684,t:1527635322125};\\\", \\\"{x:1354,y:685,t:1527635322143};\\\", \\\"{x:1354,y:687,t:1527635322160};\\\", \\\"{x:1354,y:689,t:1527635322177};\\\", \\\"{x:1354,y:693,t:1527635322192};\\\", \\\"{x:1352,y:696,t:1527635322210};\\\", \\\"{x:1352,y:699,t:1527635322227};\\\", \\\"{x:1351,y:701,t:1527635322243};\\\", \\\"{x:1351,y:703,t:1527635322260};\\\", \\\"{x:1350,y:706,t:1527635322277};\\\", \\\"{x:1350,y:707,t:1527635322292};\\\", \\\"{x:1350,y:709,t:1527635322310};\\\", \\\"{x:1350,y:710,t:1527635322327};\\\", \\\"{x:1350,y:711,t:1527635322342};\\\", \\\"{x:1349,y:711,t:1527635322359};\\\", \\\"{x:1349,y:708,t:1527635322758};\\\", \\\"{x:1349,y:707,t:1527635322765};\\\", \\\"{x:1349,y:706,t:1527635322776};\\\", \\\"{x:1349,y:703,t:1527635322793};\\\", \\\"{x:1349,y:701,t:1527635322810};\\\", \\\"{x:1349,y:699,t:1527635322826};\\\", \\\"{x:1349,y:697,t:1527635322843};\\\", \\\"{x:1349,y:696,t:1527635322859};\\\", \\\"{x:1349,y:694,t:1527635322876};\\\", \\\"{x:1349,y:693,t:1527635322901};\\\", \\\"{x:1348,y:693,t:1527635322933};\\\", \\\"{x:1348,y:690,t:1527635323700};\\\", \\\"{x:1348,y:683,t:1527635323710};\\\", \\\"{x:1345,y:662,t:1527635323727};\\\", \\\"{x:1341,y:638,t:1527635323743};\\\", \\\"{x:1333,y:617,t:1527635323760};\\\", \\\"{x:1324,y:596,t:1527635323777};\\\", \\\"{x:1307,y:569,t:1527635323793};\\\", \\\"{x:1294,y:551,t:1527635323810};\\\", \\\"{x:1290,y:541,t:1527635323827};\\\", \\\"{x:1288,y:537,t:1527635323843};\\\", \\\"{x:1287,y:535,t:1527635323860};\\\", \\\"{x:1287,y:539,t:1527635323988};\\\", \\\"{x:1287,y:548,t:1527635323996};\\\", \\\"{x:1287,y:560,t:1527635324010};\\\", \\\"{x:1289,y:587,t:1527635324027};\\\", \\\"{x:1291,y:608,t:1527635324044};\\\", \\\"{x:1292,y:612,t:1527635324059};\\\", \\\"{x:1293,y:613,t:1527635324077};\\\", \\\"{x:1294,y:611,t:1527635324163};\\\", \\\"{x:1294,y:607,t:1527635324177};\\\", \\\"{x:1294,y:596,t:1527635324194};\\\", \\\"{x:1294,y:583,t:1527635324209};\\\", \\\"{x:1294,y:575,t:1527635324227};\\\", \\\"{x:1294,y:569,t:1527635324244};\\\", \\\"{x:1294,y:567,t:1527635324259};\\\", \\\"{x:1294,y:566,t:1527635324277};\\\", \\\"{x:1294,y:565,t:1527635324294};\\\", \\\"{x:1294,y:564,t:1527635324310};\\\", \\\"{x:1293,y:562,t:1527635324676};\\\", \\\"{x:1292,y:562,t:1527635324684};\\\", \\\"{x:1291,y:561,t:1527635324700};\\\", \\\"{x:1290,y:561,t:1527635324716};\\\", \\\"{x:1289,y:561,t:1527635324727};\\\", \\\"{x:1288,y:561,t:1527635324744};\\\", \\\"{x:1286,y:559,t:1527635324761};\\\", \\\"{x:1285,y:558,t:1527635324777};\\\", \\\"{x:1285,y:559,t:1527635325044};\\\", \\\"{x:1285,y:560,t:1527635325078};\\\", \\\"{x:1285,y:562,t:1527635326685};\\\", \\\"{x:1286,y:562,t:1527635326696};\\\", \\\"{x:1287,y:563,t:1527635326713};\\\", \\\"{x:1290,y:564,t:1527635326731};\\\", \\\"{x:1290,y:565,t:1527635326745};\\\", \\\"{x:1292,y:565,t:1527635326762};\\\", \\\"{x:1292,y:566,t:1527635326779};\\\", \\\"{x:1295,y:566,t:1527635326795};\\\", \\\"{x:1300,y:566,t:1527635326812};\\\", \\\"{x:1304,y:566,t:1527635326829};\\\", \\\"{x:1309,y:566,t:1527635326845};\\\", \\\"{x:1312,y:566,t:1527635326862};\\\", \\\"{x:1316,y:566,t:1527635326879};\\\", \\\"{x:1320,y:566,t:1527635326896};\\\", \\\"{x:1325,y:566,t:1527635326912};\\\", \\\"{x:1331,y:566,t:1527635326930};\\\", \\\"{x:1336,y:566,t:1527635326946};\\\", \\\"{x:1343,y:566,t:1527635326963};\\\", \\\"{x:1352,y:566,t:1527635326979};\\\", \\\"{x:1359,y:566,t:1527635326996};\\\", \\\"{x:1363,y:566,t:1527635327012};\\\", \\\"{x:1366,y:566,t:1527635327029};\\\", \\\"{x:1369,y:566,t:1527635327047};\\\", \\\"{x:1370,y:566,t:1527635327062};\\\", \\\"{x:1372,y:566,t:1527635327080};\\\", \\\"{x:1374,y:566,t:1527635327096};\\\", \\\"{x:1376,y:565,t:1527635327113};\\\", \\\"{x:1377,y:565,t:1527635327132};\\\", \\\"{x:1379,y:565,t:1527635327147};\\\", \\\"{x:1381,y:564,t:1527635327163};\\\", \\\"{x:1383,y:563,t:1527635327179};\\\", \\\"{x:1389,y:563,t:1527635327197};\\\", \\\"{x:1390,y:563,t:1527635327212};\\\", \\\"{x:1393,y:563,t:1527635327229};\\\", \\\"{x:1397,y:563,t:1527635327246};\\\", \\\"{x:1402,y:563,t:1527635327263};\\\", \\\"{x:1407,y:562,t:1527635327280};\\\", \\\"{x:1410,y:562,t:1527635327297};\\\", \\\"{x:1414,y:562,t:1527635327312};\\\", \\\"{x:1415,y:562,t:1527635327333};\\\", \\\"{x:1407,y:563,t:1527635331854};\\\", \\\"{x:1393,y:569,t:1527635331867};\\\", \\\"{x:1358,y:580,t:1527635331883};\\\", \\\"{x:1314,y:590,t:1527635331900};\\\", \\\"{x:1256,y:600,t:1527635331917};\\\", \\\"{x:1212,y:604,t:1527635331933};\\\", \\\"{x:1167,y:604,t:1527635331951};\\\", \\\"{x:1103,y:604,t:1527635331967};\\\", \\\"{x:1021,y:599,t:1527635331983};\\\", \\\"{x:916,y:585,t:1527635332002};\\\", \\\"{x:811,y:573,t:1527635332016};\\\", \\\"{x:700,y:557,t:1527635332033};\\\", \\\"{x:603,y:544,t:1527635332052};\\\", \\\"{x:501,y:530,t:1527635332068};\\\", \\\"{x:470,y:525,t:1527635332085};\\\", \\\"{x:456,y:520,t:1527635332102};\\\", \\\"{x:455,y:519,t:1527635332118};\\\", \\\"{x:453,y:516,t:1527635332157};\\\", \\\"{x:453,y:515,t:1527635332168};\\\", \\\"{x:452,y:512,t:1527635332184};\\\", \\\"{x:449,y:508,t:1527635332201};\\\", \\\"{x:441,y:503,t:1527635332219};\\\", \\\"{x:436,y:499,t:1527635332234};\\\", \\\"{x:433,y:498,t:1527635332251};\\\", \\\"{x:432,y:499,t:1527635332300};\\\", \\\"{x:434,y:505,t:1527635332309};\\\", \\\"{x:440,y:511,t:1527635332319};\\\", \\\"{x:463,y:518,t:1527635332335};\\\", \\\"{x:502,y:528,t:1527635332352};\\\", \\\"{x:571,y:533,t:1527635332368};\\\", \\\"{x:666,y:548,t:1527635332384};\\\", \\\"{x:739,y:552,t:1527635332401};\\\", \\\"{x:776,y:552,t:1527635332419};\\\", \\\"{x:787,y:552,t:1527635332435};\\\", \\\"{x:788,y:552,t:1527635332452};\\\", \\\"{x:788,y:551,t:1527635332468};\\\", \\\"{x:783,y:545,t:1527635332485};\\\", \\\"{x:767,y:536,t:1527635332501};\\\", \\\"{x:751,y:531,t:1527635332518};\\\", \\\"{x:726,y:529,t:1527635332535};\\\", \\\"{x:702,y:525,t:1527635332552};\\\", \\\"{x:678,y:521,t:1527635332569};\\\", \\\"{x:659,y:519,t:1527635332584};\\\", \\\"{x:646,y:517,t:1527635332603};\\\", \\\"{x:641,y:515,t:1527635332618};\\\", \\\"{x:638,y:514,t:1527635332635};\\\", \\\"{x:637,y:512,t:1527635332678};\\\", \\\"{x:636,y:512,t:1527635332691};\\\", \\\"{x:636,y:511,t:1527635332702};\\\", \\\"{x:634,y:509,t:1527635332718};\\\", \\\"{x:633,y:507,t:1527635332735};\\\", \\\"{x:631,y:503,t:1527635332751};\\\", \\\"{x:630,y:501,t:1527635332768};\\\", \\\"{x:630,y:500,t:1527635332785};\\\", \\\"{x:630,y:499,t:1527635333003};\\\", \\\"{x:633,y:500,t:1527635333018};\\\", \\\"{x:650,y:506,t:1527635333036};\\\", \\\"{x:696,y:524,t:1527635333052};\\\", \\\"{x:740,y:535,t:1527635333069};\\\", \\\"{x:781,y:544,t:1527635333085};\\\", \\\"{x:811,y:546,t:1527635333102};\\\", \\\"{x:827,y:546,t:1527635333118};\\\", \\\"{x:832,y:546,t:1527635333135};\\\", \\\"{x:833,y:546,t:1527635333153};\\\", \\\"{x:833,y:545,t:1527635333168};\\\", \\\"{x:833,y:542,t:1527635333185};\\\", \\\"{x:834,y:538,t:1527635333202};\\\", \\\"{x:835,y:536,t:1527635333220};\\\", \\\"{x:836,y:535,t:1527635333236};\\\", \\\"{x:836,y:534,t:1527635333252};\\\", \\\"{x:837,y:534,t:1527635333331};\\\", \\\"{x:837,y:534,t:1527635333408};\\\", \\\"{x:837,y:538,t:1527635333452};\\\", \\\"{x:820,y:554,t:1527635333469};\\\", \\\"{x:785,y:573,t:1527635333486};\\\", \\\"{x:731,y:595,t:1527635333503};\\\", \\\"{x:667,y:612,t:1527635333520};\\\", \\\"{x:611,y:629,t:1527635333536};\\\", \\\"{x:535,y:657,t:1527635333553};\\\", \\\"{x:457,y:695,t:1527635333569};\\\", \\\"{x:421,y:718,t:1527635333585};\\\", \\\"{x:403,y:731,t:1527635333602};\\\", \\\"{x:393,y:740,t:1527635333619};\\\", \\\"{x:389,y:745,t:1527635333636};\\\", \\\"{x:389,y:750,t:1527635333652};\\\", \\\"{x:389,y:752,t:1527635333669};\\\", \\\"{x:389,y:753,t:1527635333685};\\\", \\\"{x:389,y:754,t:1527635333702};\\\", \\\"{x:390,y:755,t:1527635333748};\\\", \\\"{x:391,y:755,t:1527635333756};\\\", \\\"{x:392,y:757,t:1527635333769};\\\", \\\"{x:397,y:761,t:1527635333786};\\\", \\\"{x:405,y:763,t:1527635333803};\\\", \\\"{x:421,y:765,t:1527635333819};\\\", \\\"{x:461,y:765,t:1527635333837};\\\", \\\"{x:490,y:765,t:1527635333852};\\\", \\\"{x:514,y:762,t:1527635333870};\\\", \\\"{x:532,y:755,t:1527635333887};\\\", \\\"{x:541,y:751,t:1527635333907};\\\", \\\"{x:542,y:750,t:1527635333919};\\\", \\\"{x:543,y:749,t:1527635334364};\\\", \\\"{x:546,y:745,t:1527635334372};\\\", \\\"{x:551,y:737,t:1527635334386};\\\", \\\"{x:569,y:719,t:1527635334404};\\\", \\\"{x:587,y:699,t:1527635334420};\\\", \\\"{x:644,y:646,t:1527635334436};\\\", \\\"{x:681,y:620,t:1527635334454};\\\", \\\"{x:729,y:585,t:1527635334470};\\\", \\\"{x:776,y:554,t:1527635334486};\\\", \\\"{x:823,y:523,t:1527635334503};\\\", \\\"{x:853,y:510,t:1527635334520};\\\", \\\"{x:875,y:502,t:1527635334537};\\\", \\\"{x:897,y:493,t:1527635334554};\\\", \\\"{x:911,y:487,t:1527635334571};\\\", \\\"{x:925,y:481,t:1527635334586};\\\", \\\"{x:931,y:478,t:1527635334603};\\\", \\\"{x:932,y:482,t:1527635335235};\\\", \\\"{x:935,y:505,t:1527635335243};\\\", \\\"{x:948,y:532,t:1527635335254};\\\", \\\"{x:954,y:539,t:1527635335270};\\\" ] }, { \\\"rt\\\": 44931, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 399564, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"93XU7\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-6-E -E -E -E -E -E -F -F -B -B -B -B -F -F -F -B -B -01 PM-01 PM-02 PM-02 PM-01 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:954,y:540,t:1527635335899};\\\", \\\"{x:954,y:539,t:1527635335955};\\\", \\\"{x:953,y:538,t:1527635335972};\\\", \\\"{x:951,y:536,t:1527635335988};\\\", \\\"{x:951,y:535,t:1527635336004};\\\", \\\"{x:950,y:532,t:1527635336022};\\\", \\\"{x:949,y:531,t:1527635336037};\\\", \\\"{x:946,y:529,t:1527635336054};\\\", \\\"{x:945,y:527,t:1527635336071};\\\", \\\"{x:943,y:523,t:1527635336088};\\\", \\\"{x:940,y:516,t:1527635336105};\\\", \\\"{x:940,y:505,t:1527635336122};\\\", \\\"{x:938,y:491,t:1527635336137};\\\", \\\"{x:934,y:470,t:1527635336155};\\\", \\\"{x:932,y:450,t:1527635336172};\\\", \\\"{x:932,y:434,t:1527635336187};\\\", \\\"{x:932,y:414,t:1527635336205};\\\", \\\"{x:932,y:401,t:1527635336222};\\\", \\\"{x:932,y:392,t:1527635336238};\\\", \\\"{x:936,y:376,t:1527635336254};\\\", \\\"{x:941,y:364,t:1527635336271};\\\", \\\"{x:945,y:356,t:1527635336288};\\\", \\\"{x:947,y:351,t:1527635336305};\\\", \\\"{x:950,y:346,t:1527635336322};\\\", \\\"{x:952,y:344,t:1527635336337};\\\", \\\"{x:953,y:342,t:1527635336355};\\\", \\\"{x:954,y:342,t:1527635336372};\\\", \\\"{x:954,y:341,t:1527635336388};\\\", \\\"{x:954,y:340,t:1527635337301};\\\", \\\"{x:957,y:338,t:1527635337308};\\\", \\\"{x:958,y:338,t:1527635337322};\\\", \\\"{x:961,y:338,t:1527635337338};\\\", \\\"{x:967,y:338,t:1527635337355};\\\", \\\"{x:973,y:338,t:1527635337372};\\\", \\\"{x:979,y:338,t:1527635337388};\\\", \\\"{x:988,y:338,t:1527635337405};\\\", \\\"{x:993,y:338,t:1527635337422};\\\", \\\"{x:998,y:338,t:1527635337438};\\\", \\\"{x:1004,y:338,t:1527635337456};\\\", \\\"{x:1008,y:338,t:1527635337472};\\\", \\\"{x:1014,y:338,t:1527635337488};\\\", \\\"{x:1020,y:338,t:1527635337505};\\\", \\\"{x:1026,y:338,t:1527635337522};\\\", \\\"{x:1030,y:338,t:1527635337539};\\\", \\\"{x:1036,y:338,t:1527635337555};\\\", \\\"{x:1042,y:338,t:1527635337572};\\\", \\\"{x:1046,y:338,t:1527635337588};\\\", \\\"{x:1057,y:342,t:1527635337605};\\\", \\\"{x:1065,y:346,t:1527635337622};\\\", \\\"{x:1073,y:355,t:1527635337638};\\\", \\\"{x:1077,y:376,t:1527635337656};\\\", \\\"{x:1089,y:435,t:1527635337672};\\\", \\\"{x:1093,y:441,t:1527635337688};\\\", \\\"{x:1096,y:441,t:1527635338621};\\\", \\\"{x:1101,y:442,t:1527635338638};\\\", \\\"{x:1106,y:442,t:1527635338655};\\\", \\\"{x:1110,y:442,t:1527635338673};\\\", \\\"{x:1115,y:442,t:1527635338689};\\\", \\\"{x:1122,y:442,t:1527635338705};\\\", \\\"{x:1129,y:442,t:1527635338722};\\\", \\\"{x:1137,y:445,t:1527635338738};\\\", \\\"{x:1149,y:450,t:1527635338755};\\\", \\\"{x:1169,y:457,t:1527635338773};\\\", \\\"{x:1180,y:461,t:1527635338789};\\\", \\\"{x:1193,y:467,t:1527635338805};\\\", \\\"{x:1204,y:476,t:1527635338822};\\\", \\\"{x:1214,y:485,t:1527635338838};\\\", \\\"{x:1223,y:496,t:1527635338856};\\\", \\\"{x:1231,y:508,t:1527635338872};\\\", \\\"{x:1237,y:519,t:1527635338888};\\\", \\\"{x:1241,y:529,t:1527635338905};\\\", \\\"{x:1245,y:538,t:1527635338923};\\\", \\\"{x:1249,y:547,t:1527635338938};\\\", \\\"{x:1251,y:555,t:1527635338955};\\\", \\\"{x:1255,y:564,t:1527635338974};\\\", \\\"{x:1258,y:567,t:1527635338989};\\\", \\\"{x:1260,y:569,t:1527635339005};\\\", \\\"{x:1260,y:571,t:1527635339023};\\\", \\\"{x:1261,y:571,t:1527635339091};\\\", \\\"{x:1262,y:571,t:1527635339277};\\\", \\\"{x:1263,y:571,t:1527635339288};\\\", \\\"{x:1264,y:571,t:1527635339309};\\\", \\\"{x:1266,y:571,t:1527635339322};\\\", \\\"{x:1267,y:571,t:1527635339338};\\\", \\\"{x:1269,y:570,t:1527635339355};\\\", \\\"{x:1270,y:570,t:1527635339372};\\\", \\\"{x:1271,y:570,t:1527635339388};\\\", \\\"{x:1272,y:570,t:1527635339429};\\\", \\\"{x:1273,y:570,t:1527635339469};\\\", \\\"{x:1274,y:570,t:1527635339501};\\\", \\\"{x:1275,y:570,t:1527635339517};\\\", \\\"{x:1276,y:570,t:1527635339599};\\\", \\\"{x:1277,y:570,t:1527635339605};\\\", \\\"{x:1278,y:570,t:1527635339622};\\\", \\\"{x:1279,y:570,t:1527635339639};\\\", \\\"{x:1280,y:569,t:1527635339655};\\\", \\\"{x:1280,y:567,t:1527635339675};\\\", \\\"{x:1280,y:566,t:1527635339688};\\\", \\\"{x:1280,y:565,t:1527635339706};\\\", \\\"{x:1281,y:564,t:1527635339749};\\\", \\\"{x:1281,y:563,t:1527635339756};\\\", \\\"{x:1281,y:562,t:1527635339772};\\\", \\\"{x:1281,y:560,t:1527635339788};\\\", \\\"{x:1282,y:559,t:1527635339805};\\\", \\\"{x:1282,y:558,t:1527635339822};\\\", \\\"{x:1282,y:557,t:1527635340340};\\\", \\\"{x:1283,y:556,t:1527635340352};\\\", \\\"{x:1283,y:555,t:1527635340370};\\\", \\\"{x:1282,y:553,t:1527635340386};\\\", \\\"{x:1281,y:552,t:1527635340402};\\\", \\\"{x:1279,y:549,t:1527635340420};\\\", \\\"{x:1278,y:548,t:1527635340435};\\\", \\\"{x:1278,y:549,t:1527635341562};\\\", \\\"{x:1278,y:551,t:1527635342217};\\\", \\\"{x:1278,y:552,t:1527635342233};\\\", \\\"{x:1278,y:553,t:1527635342914};\\\", \\\"{x:1278,y:554,t:1527635343042};\\\", \\\"{x:1277,y:555,t:1527635343066};\\\", \\\"{x:1277,y:556,t:1527635343378};\\\", \\\"{x:1277,y:557,t:1527635343385};\\\", \\\"{x:1277,y:558,t:1527635343404};\\\", \\\"{x:1277,y:559,t:1527635343420};\\\", \\\"{x:1278,y:562,t:1527635343435};\\\", \\\"{x:1280,y:565,t:1527635343452};\\\", \\\"{x:1283,y:568,t:1527635343469};\\\", \\\"{x:1285,y:572,t:1527635343487};\\\", \\\"{x:1287,y:574,t:1527635343502};\\\", \\\"{x:1290,y:578,t:1527635343521};\\\", \\\"{x:1295,y:585,t:1527635343536};\\\", \\\"{x:1301,y:594,t:1527635343553};\\\", \\\"{x:1307,y:604,t:1527635343570};\\\", \\\"{x:1309,y:609,t:1527635343586};\\\", \\\"{x:1313,y:617,t:1527635343602};\\\", \\\"{x:1313,y:623,t:1527635343620};\\\", \\\"{x:1316,y:627,t:1527635343636};\\\", \\\"{x:1317,y:633,t:1527635343653};\\\", \\\"{x:1319,y:639,t:1527635343669};\\\", \\\"{x:1321,y:647,t:1527635343686};\\\", \\\"{x:1325,y:656,t:1527635343703};\\\", \\\"{x:1325,y:666,t:1527635343720};\\\", \\\"{x:1328,y:676,t:1527635343736};\\\", \\\"{x:1330,y:689,t:1527635343752};\\\", \\\"{x:1335,y:701,t:1527635343770};\\\", \\\"{x:1338,y:709,t:1527635343786};\\\", \\\"{x:1342,y:717,t:1527635343803};\\\", \\\"{x:1344,y:725,t:1527635343820};\\\", \\\"{x:1344,y:728,t:1527635343835};\\\", \\\"{x:1346,y:730,t:1527635343853};\\\", \\\"{x:1346,y:731,t:1527635343890};\\\", \\\"{x:1346,y:732,t:1527635344778};\\\", \\\"{x:1347,y:732,t:1527635344793};\\\", \\\"{x:1349,y:733,t:1527635344802};\\\", \\\"{x:1350,y:733,t:1527635344978};\\\", \\\"{x:1350,y:732,t:1527635344986};\\\", \\\"{x:1350,y:731,t:1527635345003};\\\", \\\"{x:1351,y:731,t:1527635345106};\\\", \\\"{x:1351,y:730,t:1527635345199};\\\", \\\"{x:1351,y:729,t:1527635345209};\\\", \\\"{x:1351,y:728,t:1527635345219};\\\", \\\"{x:1351,y:727,t:1527635345249};\\\", \\\"{x:1351,y:726,t:1527635345281};\\\", \\\"{x:1351,y:725,t:1527635345410};\\\", \\\"{x:1350,y:725,t:1527635346115};\\\", \\\"{x:1349,y:725,t:1527635346121};\\\", \\\"{x:1349,y:724,t:1527635346746};\\\", \\\"{x:1349,y:723,t:1527635346754};\\\", \\\"{x:1349,y:722,t:1527635346802};\\\", \\\"{x:1348,y:721,t:1527635346834};\\\", \\\"{x:1349,y:721,t:1527635347106};\\\", \\\"{x:1350,y:721,t:1527635347119};\\\", \\\"{x:1353,y:721,t:1527635347136};\\\", \\\"{x:1358,y:721,t:1527635347153};\\\", \\\"{x:1365,y:721,t:1527635347169};\\\", \\\"{x:1376,y:721,t:1527635347186};\\\", \\\"{x:1379,y:721,t:1527635347203};\\\", \\\"{x:1380,y:721,t:1527635347234};\\\", \\\"{x:1384,y:719,t:1527635347241};\\\", \\\"{x:1387,y:717,t:1527635347253};\\\", \\\"{x:1393,y:715,t:1527635347269};\\\", \\\"{x:1396,y:713,t:1527635347285};\\\", \\\"{x:1397,y:708,t:1527635347303};\\\", \\\"{x:1401,y:698,t:1527635347319};\\\", \\\"{x:1405,y:686,t:1527635347336};\\\", \\\"{x:1407,y:674,t:1527635347353};\\\", \\\"{x:1411,y:662,t:1527635347369};\\\", \\\"{x:1416,y:644,t:1527635347386};\\\", \\\"{x:1420,y:626,t:1527635347403};\\\", \\\"{x:1421,y:606,t:1527635347419};\\\", \\\"{x:1420,y:594,t:1527635347436};\\\", \\\"{x:1413,y:579,t:1527635347452};\\\", \\\"{x:1402,y:566,t:1527635347469};\\\", \\\"{x:1391,y:555,t:1527635347486};\\\", \\\"{x:1377,y:548,t:1527635347503};\\\", \\\"{x:1363,y:542,t:1527635347519};\\\", \\\"{x:1349,y:540,t:1527635347535};\\\", \\\"{x:1342,y:540,t:1527635347553};\\\", \\\"{x:1341,y:540,t:1527635347569};\\\", \\\"{x:1340,y:540,t:1527635347586};\\\", \\\"{x:1342,y:542,t:1527635348546};\\\", \\\"{x:1344,y:543,t:1527635348554};\\\", \\\"{x:1347,y:545,t:1527635348569};\\\", \\\"{x:1355,y:549,t:1527635348586};\\\", \\\"{x:1359,y:552,t:1527635348603};\\\", \\\"{x:1361,y:554,t:1527635348619};\\\", \\\"{x:1364,y:555,t:1527635348636};\\\", \\\"{x:1366,y:558,t:1527635348653};\\\", \\\"{x:1367,y:559,t:1527635348698};\\\", \\\"{x:1367,y:560,t:1527635348713};\\\", \\\"{x:1368,y:561,t:1527635348737};\\\", \\\"{x:1369,y:561,t:1527635348762};\\\", \\\"{x:1370,y:561,t:1527635349057};\\\", \\\"{x:1371,y:561,t:1527635349068};\\\", \\\"{x:1374,y:561,t:1527635349086};\\\", \\\"{x:1376,y:561,t:1527635349102};\\\", \\\"{x:1380,y:561,t:1527635349118};\\\", \\\"{x:1383,y:561,t:1527635349135};\\\", \\\"{x:1385,y:561,t:1527635349152};\\\", \\\"{x:1386,y:562,t:1527635349217};\\\", \\\"{x:1388,y:562,t:1527635349314};\\\", \\\"{x:1389,y:564,t:1527635349338};\\\", \\\"{x:1390,y:564,t:1527635349369};\\\", \\\"{x:1390,y:566,t:1527635349385};\\\", \\\"{x:1390,y:567,t:1527635349403};\\\", \\\"{x:1390,y:569,t:1527635349419};\\\", \\\"{x:1390,y:570,t:1527635349436};\\\", \\\"{x:1390,y:571,t:1527635349453};\\\", \\\"{x:1390,y:572,t:1527635349473};\\\", \\\"{x:1390,y:573,t:1527635349490};\\\", \\\"{x:1390,y:575,t:1527635349522};\\\", \\\"{x:1390,y:576,t:1527635349545};\\\", \\\"{x:1390,y:578,t:1527635349570};\\\", \\\"{x:1389,y:578,t:1527635349586};\\\", \\\"{x:1389,y:579,t:1527635349603};\\\", \\\"{x:1389,y:580,t:1527635349619};\\\", \\\"{x:1389,y:581,t:1527635349649};\\\", \\\"{x:1389,y:582,t:1527635349690};\\\", \\\"{x:1388,y:583,t:1527635349705};\\\", \\\"{x:1387,y:583,t:1527635349778};\\\", \\\"{x:1387,y:584,t:1527635349793};\\\", \\\"{x:1387,y:586,t:1527635349810};\\\", \\\"{x:1386,y:586,t:1527635349819};\\\", \\\"{x:1386,y:588,t:1527635349850};\\\", \\\"{x:1385,y:588,t:1527635349986};\\\", \\\"{x:1383,y:588,t:1527635350026};\\\", \\\"{x:1382,y:588,t:1527635350042};\\\", \\\"{x:1381,y:588,t:1527635350066};\\\", \\\"{x:1380,y:588,t:1527635350074};\\\", \\\"{x:1379,y:589,t:1527635350122};\\\", \\\"{x:1379,y:591,t:1527635350258};\\\", \\\"{x:1379,y:592,t:1527635350282};\\\", \\\"{x:1378,y:592,t:1527635350298};\\\", \\\"{x:1376,y:594,t:1527635350314};\\\", \\\"{x:1376,y:595,t:1527635350322};\\\", \\\"{x:1375,y:596,t:1527635350336};\\\", \\\"{x:1370,y:600,t:1527635350353};\\\", \\\"{x:1368,y:604,t:1527635350368};\\\", \\\"{x:1364,y:611,t:1527635350386};\\\", \\\"{x:1361,y:612,t:1527635350402};\\\", \\\"{x:1361,y:611,t:1527635350457};\\\", \\\"{x:1361,y:610,t:1527635350561};\\\", \\\"{x:1360,y:608,t:1527635350569};\\\", \\\"{x:1359,y:605,t:1527635350585};\\\", \\\"{x:1357,y:602,t:1527635350603};\\\", \\\"{x:1354,y:599,t:1527635350618};\\\", \\\"{x:1353,y:597,t:1527635350636};\\\", \\\"{x:1349,y:593,t:1527635350653};\\\", \\\"{x:1346,y:591,t:1527635350669};\\\", \\\"{x:1345,y:590,t:1527635350686};\\\", \\\"{x:1342,y:588,t:1527635350703};\\\", \\\"{x:1339,y:587,t:1527635350719};\\\", \\\"{x:1337,y:587,t:1527635350736};\\\", \\\"{x:1333,y:587,t:1527635350753};\\\", \\\"{x:1330,y:587,t:1527635350769};\\\", \\\"{x:1322,y:590,t:1527635350785};\\\", \\\"{x:1314,y:594,t:1527635350803};\\\", \\\"{x:1296,y:602,t:1527635350818};\\\", \\\"{x:1283,y:608,t:1527635350836};\\\", \\\"{x:1282,y:609,t:1527635350853};\\\", \\\"{x:1281,y:609,t:1527635350869};\\\", \\\"{x:1281,y:610,t:1527635350978};\\\", \\\"{x:1282,y:610,t:1527635351009};\\\", \\\"{x:1282,y:611,t:1527635351025};\\\", \\\"{x:1283,y:612,t:1527635351050};\\\", \\\"{x:1284,y:613,t:1527635351081};\\\", \\\"{x:1285,y:614,t:1527635351098};\\\", \\\"{x:1286,y:615,t:1527635351114};\\\", \\\"{x:1286,y:616,t:1527635351145};\\\", \\\"{x:1287,y:616,t:1527635351154};\\\", \\\"{x:1288,y:618,t:1527635351169};\\\", \\\"{x:1289,y:620,t:1527635351185};\\\", \\\"{x:1290,y:622,t:1527635351203};\\\", \\\"{x:1291,y:623,t:1527635351218};\\\", \\\"{x:1292,y:624,t:1527635351281};\\\", \\\"{x:1292,y:625,t:1527635351289};\\\", \\\"{x:1293,y:626,t:1527635351305};\\\", \\\"{x:1294,y:627,t:1527635351321};\\\", \\\"{x:1295,y:629,t:1527635351345};\\\", \\\"{x:1295,y:628,t:1527635351626};\\\", \\\"{x:1295,y:627,t:1527635351649};\\\", \\\"{x:1295,y:626,t:1527635351658};\\\", \\\"{x:1295,y:625,t:1527635351682};\\\", \\\"{x:1295,y:624,t:1527635351698};\\\", \\\"{x:1295,y:622,t:1527635351705};\\\", \\\"{x:1295,y:620,t:1527635351721};\\\", \\\"{x:1295,y:617,t:1527635351736};\\\", \\\"{x:1295,y:611,t:1527635351753};\\\", \\\"{x:1295,y:604,t:1527635351769};\\\", \\\"{x:1295,y:592,t:1527635351786};\\\", \\\"{x:1293,y:581,t:1527635351803};\\\", \\\"{x:1289,y:568,t:1527635351819};\\\", \\\"{x:1287,y:558,t:1527635351836};\\\", \\\"{x:1285,y:553,t:1527635351853};\\\", \\\"{x:1285,y:549,t:1527635351869};\\\", \\\"{x:1285,y:548,t:1527635351886};\\\", \\\"{x:1284,y:548,t:1527635352002};\\\", \\\"{x:1283,y:550,t:1527635352019};\\\", \\\"{x:1282,y:554,t:1527635352036};\\\", \\\"{x:1281,y:558,t:1527635352054};\\\", \\\"{x:1280,y:560,t:1527635352069};\\\", \\\"{x:1280,y:562,t:1527635352085};\\\", \\\"{x:1280,y:563,t:1527635352103};\\\", \\\"{x:1279,y:565,t:1527635352118};\\\", \\\"{x:1279,y:566,t:1527635352136};\\\", \\\"{x:1279,y:567,t:1527635352153};\\\", \\\"{x:1278,y:568,t:1527635352169};\\\", \\\"{x:1278,y:569,t:1527635352186};\\\", \\\"{x:1277,y:570,t:1527635352209};\\\", \\\"{x:1277,y:571,t:1527635359594};\\\", \\\"{x:1277,y:573,t:1527635359603};\\\", \\\"{x:1277,y:578,t:1527635359618};\\\", \\\"{x:1278,y:581,t:1527635359635};\\\", \\\"{x:1278,y:583,t:1527635359652};\\\", \\\"{x:1278,y:584,t:1527635359668};\\\", \\\"{x:1278,y:585,t:1527635359685};\\\", \\\"{x:1278,y:587,t:1527635359702};\\\", \\\"{x:1278,y:590,t:1527635359719};\\\", \\\"{x:1278,y:592,t:1527635359736};\\\", \\\"{x:1278,y:595,t:1527635359752};\\\", \\\"{x:1278,y:596,t:1527635359769};\\\", \\\"{x:1278,y:597,t:1527635359786};\\\", \\\"{x:1278,y:598,t:1527635359803};\\\", \\\"{x:1278,y:599,t:1527635359819};\\\", \\\"{x:1278,y:602,t:1527635359836};\\\", \\\"{x:1278,y:605,t:1527635359853};\\\", \\\"{x:1278,y:608,t:1527635359869};\\\", \\\"{x:1278,y:612,t:1527635359886};\\\", \\\"{x:1279,y:615,t:1527635359903};\\\", \\\"{x:1279,y:617,t:1527635359919};\\\", \\\"{x:1279,y:620,t:1527635359936};\\\", \\\"{x:1279,y:623,t:1527635359953};\\\", \\\"{x:1279,y:626,t:1527635359969};\\\", \\\"{x:1279,y:629,t:1527635359986};\\\", \\\"{x:1279,y:632,t:1527635360003};\\\", \\\"{x:1279,y:635,t:1527635360019};\\\", \\\"{x:1279,y:636,t:1527635360036};\\\", \\\"{x:1278,y:641,t:1527635360053};\\\", \\\"{x:1277,y:647,t:1527635360069};\\\", \\\"{x:1277,y:651,t:1527635360086};\\\", \\\"{x:1277,y:656,t:1527635360103};\\\", \\\"{x:1277,y:659,t:1527635360119};\\\", \\\"{x:1277,y:665,t:1527635360136};\\\", \\\"{x:1277,y:675,t:1527635360153};\\\", \\\"{x:1277,y:682,t:1527635360169};\\\", \\\"{x:1277,y:691,t:1527635360186};\\\", \\\"{x:1278,y:699,t:1527635360203};\\\", \\\"{x:1278,y:706,t:1527635360218};\\\", \\\"{x:1280,y:714,t:1527635360236};\\\", \\\"{x:1281,y:723,t:1527635360253};\\\", \\\"{x:1283,y:732,t:1527635360269};\\\", \\\"{x:1284,y:739,t:1527635360287};\\\", \\\"{x:1287,y:745,t:1527635360302};\\\", \\\"{x:1288,y:752,t:1527635360319};\\\", \\\"{x:1289,y:761,t:1527635360336};\\\", \\\"{x:1296,y:781,t:1527635360353};\\\", \\\"{x:1299,y:793,t:1527635360369};\\\", \\\"{x:1302,y:806,t:1527635360386};\\\", \\\"{x:1304,y:815,t:1527635360403};\\\", \\\"{x:1306,y:820,t:1527635360419};\\\", \\\"{x:1307,y:824,t:1527635360436};\\\", \\\"{x:1307,y:830,t:1527635360454};\\\", \\\"{x:1307,y:836,t:1527635360469};\\\", \\\"{x:1307,y:843,t:1527635360486};\\\", \\\"{x:1307,y:850,t:1527635360503};\\\", \\\"{x:1306,y:860,t:1527635360519};\\\", \\\"{x:1304,y:869,t:1527635360537};\\\", \\\"{x:1300,y:880,t:1527635360554};\\\", \\\"{x:1295,y:888,t:1527635360570};\\\", \\\"{x:1292,y:894,t:1527635360586};\\\", \\\"{x:1292,y:899,t:1527635360603};\\\", \\\"{x:1289,y:907,t:1527635360619};\\\", \\\"{x:1288,y:911,t:1527635360636};\\\", \\\"{x:1287,y:917,t:1527635360653};\\\", \\\"{x:1287,y:922,t:1527635360670};\\\", \\\"{x:1287,y:926,t:1527635360687};\\\", \\\"{x:1287,y:929,t:1527635360703};\\\", \\\"{x:1287,y:932,t:1527635360720};\\\", \\\"{x:1287,y:937,t:1527635360736};\\\", \\\"{x:1287,y:943,t:1527635360753};\\\", \\\"{x:1287,y:946,t:1527635360769};\\\", \\\"{x:1287,y:947,t:1527635360786};\\\", \\\"{x:1287,y:949,t:1527635360810};\\\", \\\"{x:1287,y:950,t:1527635360820};\\\", \\\"{x:1287,y:952,t:1527635360836};\\\", \\\"{x:1287,y:954,t:1527635360853};\\\", \\\"{x:1287,y:955,t:1527635360870};\\\", \\\"{x:1287,y:958,t:1527635360886};\\\", \\\"{x:1287,y:959,t:1527635360903};\\\", \\\"{x:1287,y:961,t:1527635360919};\\\", \\\"{x:1287,y:962,t:1527635360937};\\\", \\\"{x:1287,y:964,t:1527635360953};\\\", \\\"{x:1287,y:965,t:1527635360978};\\\", \\\"{x:1287,y:966,t:1527635360993};\\\", \\\"{x:1287,y:967,t:1527635361009};\\\", \\\"{x:1287,y:968,t:1527635361025};\\\", \\\"{x:1287,y:966,t:1527635361314};\\\", \\\"{x:1287,y:962,t:1527635361322};\\\", \\\"{x:1287,y:957,t:1527635361337};\\\", \\\"{x:1291,y:932,t:1527635361354};\\\", \\\"{x:1291,y:913,t:1527635361369};\\\", \\\"{x:1294,y:891,t:1527635361387};\\\", \\\"{x:1296,y:872,t:1527635361403};\\\", \\\"{x:1300,y:854,t:1527635361419};\\\", \\\"{x:1303,y:833,t:1527635361436};\\\", \\\"{x:1310,y:807,t:1527635361453};\\\", \\\"{x:1325,y:751,t:1527635361469};\\\", \\\"{x:1338,y:691,t:1527635361486};\\\", \\\"{x:1344,y:649,t:1527635361503};\\\", \\\"{x:1346,y:626,t:1527635361519};\\\", \\\"{x:1349,y:605,t:1527635361535};\\\", \\\"{x:1362,y:559,t:1527635361553};\\\", \\\"{x:1364,y:542,t:1527635361568};\\\", \\\"{x:1364,y:537,t:1527635361586};\\\", \\\"{x:1364,y:532,t:1527635361603};\\\", \\\"{x:1364,y:530,t:1527635361619};\\\", \\\"{x:1363,y:525,t:1527635361636};\\\", \\\"{x:1358,y:519,t:1527635361653};\\\", \\\"{x:1350,y:514,t:1527635361669};\\\", \\\"{x:1342,y:511,t:1527635361686};\\\", \\\"{x:1329,y:509,t:1527635361703};\\\", \\\"{x:1314,y:509,t:1527635361719};\\\", \\\"{x:1294,y:509,t:1527635361736};\\\", \\\"{x:1274,y:513,t:1527635361753};\\\", \\\"{x:1258,y:526,t:1527635361769};\\\", \\\"{x:1251,y:537,t:1527635361786};\\\", \\\"{x:1249,y:543,t:1527635361803};\\\", \\\"{x:1249,y:545,t:1527635361819};\\\", \\\"{x:1250,y:547,t:1527635361836};\\\", \\\"{x:1262,y:546,t:1527635361853};\\\", \\\"{x:1318,y:521,t:1527635361869};\\\", \\\"{x:1374,y:504,t:1527635361886};\\\", \\\"{x:1374,y:503,t:1527635362458};\\\", \\\"{x:1374,y:505,t:1527635362514};\\\", \\\"{x:1374,y:507,t:1527635362522};\\\", \\\"{x:1373,y:507,t:1527635362537};\\\", \\\"{x:1371,y:509,t:1527635362554};\\\", \\\"{x:1370,y:509,t:1527635362569};\\\", \\\"{x:1369,y:511,t:1527635362626};\\\", \\\"{x:1368,y:511,t:1527635362636};\\\", \\\"{x:1364,y:514,t:1527635362652};\\\", \\\"{x:1357,y:519,t:1527635362669};\\\", \\\"{x:1348,y:526,t:1527635362686};\\\", \\\"{x:1331,y:539,t:1527635362703};\\\", \\\"{x:1313,y:553,t:1527635362720};\\\", \\\"{x:1296,y:565,t:1527635362736};\\\", \\\"{x:1280,y:578,t:1527635362753};\\\", \\\"{x:1274,y:583,t:1527635362769};\\\", \\\"{x:1271,y:586,t:1527635362787};\\\", \\\"{x:1268,y:589,t:1527635362803};\\\", \\\"{x:1266,y:590,t:1527635362820};\\\", \\\"{x:1267,y:586,t:1527635363066};\\\", \\\"{x:1271,y:582,t:1527635363073};\\\", \\\"{x:1274,y:578,t:1527635363086};\\\", \\\"{x:1278,y:574,t:1527635363103};\\\", \\\"{x:1287,y:566,t:1527635363119};\\\", \\\"{x:1295,y:559,t:1527635363136};\\\", \\\"{x:1303,y:552,t:1527635363153};\\\", \\\"{x:1307,y:548,t:1527635363169};\\\", \\\"{x:1308,y:547,t:1527635363186};\\\", \\\"{x:1308,y:546,t:1527635363226};\\\", \\\"{x:1308,y:549,t:1527635363376};\\\", \\\"{x:1308,y:552,t:1527635363386};\\\", \\\"{x:1307,y:555,t:1527635363402};\\\", \\\"{x:1307,y:557,t:1527635363418};\\\", \\\"{x:1307,y:558,t:1527635363436};\\\", \\\"{x:1306,y:560,t:1527635363453};\\\", \\\"{x:1306,y:561,t:1527635363473};\\\", \\\"{x:1306,y:562,t:1527635364017};\\\", \\\"{x:1304,y:562,t:1527635364025};\\\", \\\"{x:1303,y:562,t:1527635364037};\\\", \\\"{x:1301,y:562,t:1527635364054};\\\", \\\"{x:1299,y:562,t:1527635364069};\\\", \\\"{x:1298,y:562,t:1527635364086};\\\", \\\"{x:1297,y:562,t:1527635364102};\\\", \\\"{x:1296,y:562,t:1527635364322};\\\", \\\"{x:1295,y:562,t:1527635364336};\\\", \\\"{x:1289,y:562,t:1527635364353};\\\", \\\"{x:1282,y:561,t:1527635364370};\\\", \\\"{x:1280,y:559,t:1527635364386};\\\", \\\"{x:1281,y:560,t:1527635364601};\\\", \\\"{x:1282,y:560,t:1527635364617};\\\", \\\"{x:1283,y:560,t:1527635364642};\\\", \\\"{x:1284,y:561,t:1527635364825};\\\", \\\"{x:1284,y:563,t:1527635364849};\\\", \\\"{x:1288,y:556,t:1527635365139};\\\", \\\"{x:1295,y:548,t:1527635365153};\\\", \\\"{x:1313,y:523,t:1527635365169};\\\", \\\"{x:1337,y:507,t:1527635365187};\\\", \\\"{x:1353,y:496,t:1527635365203};\\\", \\\"{x:1363,y:488,t:1527635365219};\\\", \\\"{x:1367,y:482,t:1527635365236};\\\", \\\"{x:1372,y:474,t:1527635365253};\\\", \\\"{x:1376,y:470,t:1527635365269};\\\", \\\"{x:1376,y:469,t:1527635365286};\\\", \\\"{x:1376,y:468,t:1527635365302};\\\", \\\"{x:1376,y:466,t:1527635365319};\\\", \\\"{x:1376,y:465,t:1527635365336};\\\", \\\"{x:1375,y:461,t:1527635365352};\\\", \\\"{x:1368,y:454,t:1527635365368};\\\", \\\"{x:1361,y:448,t:1527635365386};\\\", \\\"{x:1351,y:441,t:1527635365402};\\\", \\\"{x:1347,y:439,t:1527635365419};\\\", \\\"{x:1343,y:437,t:1527635365436};\\\", \\\"{x:1341,y:436,t:1527635365452};\\\", \\\"{x:1340,y:436,t:1527635365553};\\\", \\\"{x:1340,y:443,t:1527635365569};\\\", \\\"{x:1340,y:455,t:1527635365586};\\\", \\\"{x:1340,y:465,t:1527635365602};\\\", \\\"{x:1344,y:474,t:1527635365619};\\\", \\\"{x:1349,y:485,t:1527635365636};\\\", \\\"{x:1351,y:489,t:1527635365652};\\\", \\\"{x:1352,y:490,t:1527635365669};\\\", \\\"{x:1352,y:492,t:1527635365898};\\\", \\\"{x:1352,y:494,t:1527635365905};\\\", \\\"{x:1352,y:498,t:1527635365919};\\\", \\\"{x:1350,y:506,t:1527635365937};\\\", \\\"{x:1348,y:516,t:1527635365953};\\\", \\\"{x:1344,y:539,t:1527635365969};\\\", \\\"{x:1344,y:553,t:1527635365987};\\\", \\\"{x:1343,y:569,t:1527635366003};\\\", \\\"{x:1343,y:589,t:1527635366020};\\\", \\\"{x:1343,y:609,t:1527635366037};\\\", \\\"{x:1343,y:628,t:1527635366053};\\\", \\\"{x:1343,y:647,t:1527635366070};\\\", \\\"{x:1346,y:663,t:1527635366086};\\\", \\\"{x:1347,y:679,t:1527635366103};\\\", \\\"{x:1347,y:696,t:1527635366120};\\\", \\\"{x:1346,y:715,t:1527635366138};\\\", \\\"{x:1344,y:727,t:1527635366152};\\\", \\\"{x:1341,y:740,t:1527635366169};\\\", \\\"{x:1340,y:746,t:1527635366186};\\\", \\\"{x:1339,y:751,t:1527635366202};\\\", \\\"{x:1336,y:757,t:1527635366220};\\\", \\\"{x:1336,y:761,t:1527635366236};\\\", \\\"{x:1336,y:759,t:1527635366322};\\\", \\\"{x:1336,y:754,t:1527635366336};\\\", \\\"{x:1338,y:737,t:1527635366352};\\\", \\\"{x:1344,y:717,t:1527635366370};\\\", \\\"{x:1348,y:709,t:1527635366386};\\\", \\\"{x:1349,y:706,t:1527635366403};\\\", \\\"{x:1349,y:705,t:1527635366419};\\\", \\\"{x:1349,y:710,t:1527635366706};\\\", \\\"{x:1347,y:712,t:1527635366719};\\\", \\\"{x:1347,y:718,t:1527635366736};\\\", \\\"{x:1347,y:724,t:1527635366753};\\\", \\\"{x:1347,y:731,t:1527635366770};\\\", \\\"{x:1347,y:735,t:1527635366786};\\\", \\\"{x:1347,y:738,t:1527635366803};\\\", \\\"{x:1348,y:742,t:1527635366819};\\\", \\\"{x:1348,y:743,t:1527635366837};\\\", \\\"{x:1349,y:745,t:1527635366852};\\\", \\\"{x:1349,y:746,t:1527635366869};\\\", \\\"{x:1350,y:747,t:1527635366887};\\\", \\\"{x:1350,y:748,t:1527635366903};\\\", \\\"{x:1350,y:750,t:1527635366962};\\\", \\\"{x:1350,y:752,t:1527635366969};\\\", \\\"{x:1350,y:755,t:1527635366987};\\\", \\\"{x:1350,y:760,t:1527635367003};\\\", \\\"{x:1350,y:764,t:1527635367019};\\\", \\\"{x:1350,y:770,t:1527635367038};\\\", \\\"{x:1350,y:775,t:1527635367052};\\\", \\\"{x:1351,y:778,t:1527635367069};\\\", \\\"{x:1351,y:779,t:1527635367087};\\\", \\\"{x:1351,y:778,t:1527635367337};\\\", \\\"{x:1351,y:776,t:1527635368042};\\\", \\\"{x:1351,y:774,t:1527635368057};\\\", \\\"{x:1351,y:773,t:1527635368074};\\\", \\\"{x:1350,y:772,t:1527635368086};\\\", \\\"{x:1350,y:770,t:1527635368102};\\\", \\\"{x:1350,y:768,t:1527635368120};\\\", \\\"{x:1350,y:767,t:1527635368137};\\\", \\\"{x:1349,y:765,t:1527635368152};\\\", \\\"{x:1348,y:763,t:1527635368169};\\\", \\\"{x:1348,y:762,t:1527635368186};\\\", \\\"{x:1348,y:761,t:1527635368202};\\\", \\\"{x:1347,y:759,t:1527635368219};\\\", \\\"{x:1347,y:757,t:1527635368241};\\\", \\\"{x:1347,y:755,t:1527635368252};\\\", \\\"{x:1347,y:753,t:1527635368269};\\\", \\\"{x:1347,y:748,t:1527635368285};\\\", \\\"{x:1347,y:743,t:1527635368302};\\\", \\\"{x:1347,y:739,t:1527635368319};\\\", \\\"{x:1347,y:733,t:1527635368336};\\\", \\\"{x:1347,y:730,t:1527635368352};\\\", \\\"{x:1347,y:727,t:1527635368369};\\\", \\\"{x:1347,y:726,t:1527635368386};\\\", \\\"{x:1347,y:724,t:1527635368403};\\\", \\\"{x:1347,y:722,t:1527635368419};\\\", \\\"{x:1347,y:721,t:1527635368546};\\\", \\\"{x:1347,y:719,t:1527635368561};\\\", \\\"{x:1347,y:718,t:1527635368570};\\\", \\\"{x:1346,y:714,t:1527635368586};\\\", \\\"{x:1346,y:709,t:1527635368603};\\\", \\\"{x:1346,y:703,t:1527635368619};\\\", \\\"{x:1346,y:697,t:1527635368637};\\\", \\\"{x:1346,y:693,t:1527635368653};\\\", \\\"{x:1346,y:689,t:1527635368671};\\\", \\\"{x:1346,y:687,t:1527635368686};\\\", \\\"{x:1346,y:686,t:1527635368702};\\\", \\\"{x:1346,y:685,t:1527635368720};\\\", \\\"{x:1346,y:686,t:1527635368841};\\\", \\\"{x:1345,y:687,t:1527635368857};\\\", \\\"{x:1345,y:688,t:1527635368869};\\\", \\\"{x:1345,y:689,t:1527635368887};\\\", \\\"{x:1345,y:692,t:1527635368903};\\\", \\\"{x:1345,y:694,t:1527635368919};\\\", \\\"{x:1345,y:695,t:1527635368936};\\\", \\\"{x:1345,y:697,t:1527635368961};\\\", \\\"{x:1345,y:698,t:1527635368977};\\\", \\\"{x:1345,y:701,t:1527635368986};\\\", \\\"{x:1345,y:702,t:1527635369004};\\\", \\\"{x:1345,y:705,t:1527635369020};\\\", \\\"{x:1345,y:707,t:1527635369037};\\\", \\\"{x:1345,y:709,t:1527635369053};\\\", \\\"{x:1345,y:711,t:1527635369070};\\\", \\\"{x:1345,y:714,t:1527635369085};\\\", \\\"{x:1345,y:717,t:1527635369101};\\\", \\\"{x:1345,y:721,t:1527635369119};\\\", \\\"{x:1345,y:725,t:1527635369136};\\\", \\\"{x:1345,y:729,t:1527635369152};\\\", \\\"{x:1344,y:735,t:1527635369169};\\\", \\\"{x:1343,y:740,t:1527635369186};\\\", \\\"{x:1343,y:746,t:1527635369202};\\\", \\\"{x:1343,y:750,t:1527635369219};\\\", \\\"{x:1341,y:753,t:1527635369236};\\\", \\\"{x:1341,y:756,t:1527635369252};\\\", \\\"{x:1341,y:757,t:1527635369269};\\\", \\\"{x:1341,y:759,t:1527635369286};\\\", \\\"{x:1341,y:760,t:1527635369302};\\\", \\\"{x:1341,y:762,t:1527635369320};\\\", \\\"{x:1341,y:763,t:1527635369345};\\\", \\\"{x:1341,y:764,t:1527635369361};\\\", \\\"{x:1341,y:765,t:1527635369369};\\\", \\\"{x:1341,y:766,t:1527635369387};\\\", \\\"{x:1342,y:764,t:1527635371106};\\\", \\\"{x:1343,y:761,t:1527635371137};\\\", \\\"{x:1344,y:760,t:1527635371152};\\\", \\\"{x:1344,y:759,t:1527635371169};\\\", \\\"{x:1345,y:759,t:1527635371187};\\\", \\\"{x:1345,y:762,t:1527635372066};\\\", \\\"{x:1347,y:763,t:1527635372073};\\\", \\\"{x:1347,y:766,t:1527635372086};\\\", \\\"{x:1348,y:766,t:1527635372102};\\\", \\\"{x:1348,y:767,t:1527635372170};\\\", \\\"{x:1348,y:769,t:1527635372210};\\\", \\\"{x:1348,y:770,t:1527635372241};\\\", \\\"{x:1348,y:772,t:1527635372257};\\\", \\\"{x:1348,y:773,t:1527635372274};\\\", \\\"{x:1348,y:776,t:1527635372287};\\\", \\\"{x:1348,y:780,t:1527635372302};\\\", \\\"{x:1348,y:784,t:1527635372320};\\\", \\\"{x:1348,y:786,t:1527635372336};\\\", \\\"{x:1348,y:790,t:1527635372353};\\\", \\\"{x:1348,y:798,t:1527635372369};\\\", \\\"{x:1349,y:807,t:1527635372387};\\\", \\\"{x:1351,y:817,t:1527635372403};\\\", \\\"{x:1352,y:828,t:1527635372420};\\\", \\\"{x:1353,y:838,t:1527635372436};\\\", \\\"{x:1357,y:848,t:1527635372453};\\\", \\\"{x:1359,y:859,t:1527635372470};\\\", \\\"{x:1364,y:872,t:1527635372487};\\\", \\\"{x:1367,y:881,t:1527635372503};\\\", \\\"{x:1373,y:892,t:1527635372520};\\\", \\\"{x:1375,y:900,t:1527635372536};\\\", \\\"{x:1376,y:904,t:1527635372552};\\\", \\\"{x:1376,y:908,t:1527635372569};\\\", \\\"{x:1376,y:914,t:1527635372586};\\\", \\\"{x:1376,y:919,t:1527635372603};\\\", \\\"{x:1375,y:923,t:1527635372619};\\\", \\\"{x:1375,y:927,t:1527635372636};\\\", \\\"{x:1375,y:928,t:1527635372652};\\\", \\\"{x:1374,y:931,t:1527635372669};\\\", \\\"{x:1374,y:932,t:1527635372686};\\\", \\\"{x:1374,y:933,t:1527635372703};\\\", \\\"{x:1372,y:938,t:1527635372719};\\\", \\\"{x:1372,y:939,t:1527635372736};\\\", \\\"{x:1372,y:941,t:1527635372753};\\\", \\\"{x:1371,y:945,t:1527635372770};\\\", \\\"{x:1370,y:952,t:1527635372787};\\\", \\\"{x:1369,y:954,t:1527635372802};\\\", \\\"{x:1369,y:956,t:1527635372820};\\\", \\\"{x:1369,y:957,t:1527635372836};\\\", \\\"{x:1369,y:959,t:1527635372865};\\\", \\\"{x:1369,y:960,t:1527635372881};\\\", \\\"{x:1369,y:962,t:1527635372897};\\\", \\\"{x:1370,y:962,t:1527635372905};\\\", \\\"{x:1371,y:964,t:1527635372920};\\\", \\\"{x:1372,y:967,t:1527635372937};\\\", \\\"{x:1374,y:971,t:1527635372953};\\\", \\\"{x:1375,y:972,t:1527635372969};\\\", \\\"{x:1376,y:974,t:1527635372987};\\\", \\\"{x:1379,y:979,t:1527635373003};\\\", \\\"{x:1381,y:983,t:1527635373020};\\\", \\\"{x:1382,y:985,t:1527635373036};\\\", \\\"{x:1383,y:986,t:1527635373052};\\\", \\\"{x:1384,y:986,t:1527635373153};\\\", \\\"{x:1385,y:986,t:1527635373177};\\\", \\\"{x:1386,y:986,t:1527635373186};\\\", \\\"{x:1388,y:986,t:1527635373202};\\\", \\\"{x:1391,y:986,t:1527635373219};\\\", \\\"{x:1394,y:986,t:1527635373236};\\\", \\\"{x:1398,y:986,t:1527635373252};\\\", \\\"{x:1402,y:986,t:1527635373269};\\\", \\\"{x:1406,y:985,t:1527635373286};\\\", \\\"{x:1408,y:985,t:1527635373302};\\\", \\\"{x:1409,y:984,t:1527635373319};\\\", \\\"{x:1410,y:983,t:1527635373336};\\\", \\\"{x:1411,y:982,t:1527635373352};\\\", \\\"{x:1413,y:980,t:1527635373369};\\\", \\\"{x:1414,y:978,t:1527635373386};\\\", \\\"{x:1416,y:976,t:1527635373403};\\\", \\\"{x:1418,y:974,t:1527635373419};\\\", \\\"{x:1419,y:972,t:1527635373437};\\\", \\\"{x:1421,y:971,t:1527635373452};\\\", \\\"{x:1422,y:970,t:1527635373470};\\\", \\\"{x:1423,y:967,t:1527635373487};\\\", \\\"{x:1425,y:966,t:1527635373502};\\\", \\\"{x:1425,y:965,t:1527635373529};\\\", \\\"{x:1426,y:964,t:1527635373569};\\\", \\\"{x:1426,y:963,t:1527635373649};\\\", \\\"{x:1426,y:962,t:1527635373770};\\\", \\\"{x:1428,y:962,t:1527635373787};\\\", \\\"{x:1429,y:964,t:1527635373803};\\\", \\\"{x:1430,y:966,t:1527635373819};\\\", \\\"{x:1432,y:969,t:1527635373837};\\\", \\\"{x:1435,y:972,t:1527635373852};\\\", \\\"{x:1439,y:974,t:1527635373870};\\\", \\\"{x:1442,y:976,t:1527635373886};\\\", \\\"{x:1444,y:976,t:1527635373902};\\\", \\\"{x:1445,y:977,t:1527635373919};\\\", \\\"{x:1449,y:978,t:1527635373936};\\\", \\\"{x:1452,y:979,t:1527635373952};\\\", \\\"{x:1458,y:979,t:1527635373969};\\\", \\\"{x:1463,y:980,t:1527635373987};\\\", \\\"{x:1471,y:980,t:1527635374002};\\\", \\\"{x:1477,y:980,t:1527635374019};\\\", \\\"{x:1482,y:980,t:1527635374037};\\\", \\\"{x:1490,y:980,t:1527635374052};\\\", \\\"{x:1497,y:980,t:1527635374070};\\\", \\\"{x:1501,y:980,t:1527635374086};\\\", \\\"{x:1504,y:980,t:1527635374102};\\\", \\\"{x:1506,y:980,t:1527635374120};\\\", \\\"{x:1506,y:978,t:1527635374145};\\\", \\\"{x:1507,y:976,t:1527635374153};\\\", \\\"{x:1508,y:973,t:1527635374169};\\\", \\\"{x:1509,y:970,t:1527635374187};\\\", \\\"{x:1510,y:966,t:1527635374202};\\\", \\\"{x:1510,y:965,t:1527635374219};\\\", \\\"{x:1510,y:963,t:1527635374236};\\\", \\\"{x:1510,y:961,t:1527635374252};\\\", \\\"{x:1510,y:960,t:1527635374269};\\\", \\\"{x:1510,y:959,t:1527635374286};\\\", \\\"{x:1509,y:961,t:1527635374578};\\\", \\\"{x:1508,y:962,t:1527635374594};\\\", \\\"{x:1508,y:964,t:1527635374714};\\\", \\\"{x:1507,y:965,t:1527635374721};\\\", \\\"{x:1507,y:966,t:1527635374745};\\\", \\\"{x:1505,y:967,t:1527635374753};\\\", \\\"{x:1504,y:967,t:1527635374770};\\\", \\\"{x:1500,y:969,t:1527635374787};\\\", \\\"{x:1497,y:969,t:1527635374803};\\\", \\\"{x:1493,y:971,t:1527635374820};\\\", \\\"{x:1490,y:971,t:1527635374837};\\\", \\\"{x:1487,y:971,t:1527635374852};\\\", \\\"{x:1486,y:971,t:1527635374870};\\\", \\\"{x:1486,y:973,t:1527635374978};\\\", \\\"{x:1485,y:973,t:1527635374993};\\\", \\\"{x:1484,y:974,t:1527635375003};\\\", \\\"{x:1483,y:976,t:1527635375020};\\\", \\\"{x:1480,y:976,t:1527635375037};\\\", \\\"{x:1472,y:979,t:1527635375053};\\\", \\\"{x:1465,y:980,t:1527635375069};\\\", \\\"{x:1460,y:981,t:1527635375088};\\\", \\\"{x:1454,y:981,t:1527635375102};\\\", \\\"{x:1448,y:981,t:1527635375120};\\\", \\\"{x:1439,y:981,t:1527635375137};\\\", \\\"{x:1434,y:981,t:1527635375153};\\\", \\\"{x:1427,y:981,t:1527635375170};\\\", \\\"{x:1422,y:981,t:1527635375187};\\\", \\\"{x:1418,y:981,t:1527635375202};\\\", \\\"{x:1415,y:980,t:1527635375219};\\\", \\\"{x:1413,y:980,t:1527635375236};\\\", \\\"{x:1413,y:979,t:1527635375344};\\\", \\\"{x:1413,y:978,t:1527635375368};\\\", \\\"{x:1413,y:977,t:1527635375377};\\\", \\\"{x:1413,y:976,t:1527635375392};\\\", \\\"{x:1414,y:976,t:1527635375403};\\\", \\\"{x:1414,y:975,t:1527635375440};\\\", \\\"{x:1414,y:974,t:1527635375452};\\\", \\\"{x:1414,y:968,t:1527635375469};\\\", \\\"{x:1405,y:956,t:1527635375487};\\\", \\\"{x:1386,y:935,t:1527635375503};\\\", \\\"{x:1341,y:893,t:1527635375520};\\\", \\\"{x:1212,y:799,t:1527635375537};\\\", \\\"{x:1084,y:732,t:1527635375553};\\\", \\\"{x:956,y:664,t:1527635375569};\\\", \\\"{x:826,y:608,t:1527635375588};\\\", \\\"{x:708,y:555,t:1527635375602};\\\", \\\"{x:627,y:529,t:1527635375619};\\\", \\\"{x:592,y:516,t:1527635375634};\\\", \\\"{x:583,y:514,t:1527635375650};\\\", \\\"{x:581,y:514,t:1527635375667};\\\", \\\"{x:581,y:513,t:1527635375752};\\\", \\\"{x:577,y:513,t:1527635375767};\\\", \\\"{x:559,y:514,t:1527635375783};\\\", \\\"{x:517,y:514,t:1527635375800};\\\", \\\"{x:489,y:518,t:1527635375817};\\\", \\\"{x:477,y:520,t:1527635375834};\\\", \\\"{x:473,y:522,t:1527635375850};\\\", \\\"{x:473,y:524,t:1527635375888};\\\", \\\"{x:476,y:527,t:1527635375901};\\\", \\\"{x:485,y:531,t:1527635375917};\\\", \\\"{x:497,y:536,t:1527635375935};\\\", \\\"{x:514,y:542,t:1527635375951};\\\", \\\"{x:531,y:548,t:1527635375967};\\\", \\\"{x:553,y:554,t:1527635375984};\\\", \\\"{x:556,y:556,t:1527635376000};\\\", \\\"{x:557,y:556,t:1527635376017};\\\", \\\"{x:556,y:556,t:1527635376056};\\\", \\\"{x:551,y:556,t:1527635376067};\\\", \\\"{x:533,y:556,t:1527635376085};\\\", \\\"{x:509,y:552,t:1527635376101};\\\", \\\"{x:482,y:549,t:1527635376118};\\\", \\\"{x:453,y:544,t:1527635376134};\\\", \\\"{x:423,y:543,t:1527635376152};\\\", \\\"{x:402,y:542,t:1527635376168};\\\", \\\"{x:380,y:542,t:1527635376184};\\\", \\\"{x:373,y:544,t:1527635376201};\\\", \\\"{x:369,y:546,t:1527635376218};\\\", \\\"{x:369,y:548,t:1527635376234};\\\", \\\"{x:369,y:550,t:1527635376250};\\\", \\\"{x:368,y:554,t:1527635376267};\\\", \\\"{x:367,y:560,t:1527635376285};\\\", \\\"{x:364,y:564,t:1527635376300};\\\", \\\"{x:360,y:570,t:1527635376317};\\\", \\\"{x:354,y:574,t:1527635376334};\\\", \\\"{x:344,y:575,t:1527635376351};\\\", \\\"{x:333,y:578,t:1527635376367};\\\", \\\"{x:313,y:580,t:1527635376384};\\\", \\\"{x:298,y:583,t:1527635376401};\\\", \\\"{x:280,y:584,t:1527635376417};\\\", \\\"{x:261,y:584,t:1527635376435};\\\", \\\"{x:241,y:584,t:1527635376451};\\\", \\\"{x:226,y:584,t:1527635376468};\\\", \\\"{x:217,y:584,t:1527635376485};\\\", \\\"{x:210,y:584,t:1527635376502};\\\", \\\"{x:206,y:584,t:1527635376517};\\\", \\\"{x:203,y:584,t:1527635376535};\\\", \\\"{x:200,y:584,t:1527635376552};\\\", \\\"{x:195,y:584,t:1527635376568};\\\", \\\"{x:190,y:585,t:1527635376586};\\\", \\\"{x:187,y:587,t:1527635376601};\\\", \\\"{x:184,y:587,t:1527635376617};\\\", \\\"{x:183,y:589,t:1527635376635};\\\", \\\"{x:182,y:591,t:1527635376651};\\\", \\\"{x:182,y:596,t:1527635376669};\\\", \\\"{x:182,y:603,t:1527635376684};\\\", \\\"{x:182,y:609,t:1527635376701};\\\", \\\"{x:182,y:615,t:1527635376718};\\\", \\\"{x:182,y:620,t:1527635376734};\\\", \\\"{x:182,y:624,t:1527635376751};\\\", \\\"{x:183,y:628,t:1527635376767};\\\", \\\"{x:185,y:634,t:1527635376784};\\\", \\\"{x:185,y:637,t:1527635376802};\\\", \\\"{x:186,y:639,t:1527635376819};\\\", \\\"{x:188,y:641,t:1527635376834};\\\", \\\"{x:193,y:642,t:1527635376851};\\\", \\\"{x:204,y:642,t:1527635376868};\\\", \\\"{x:223,y:642,t:1527635376884};\\\", \\\"{x:269,y:642,t:1527635376901};\\\", \\\"{x:350,y:642,t:1527635376919};\\\", \\\"{x:447,y:642,t:1527635376934};\\\", \\\"{x:566,y:642,t:1527635376952};\\\", \\\"{x:736,y:635,t:1527635376968};\\\", \\\"{x:826,y:631,t:1527635376985};\\\", \\\"{x:891,y:629,t:1527635377001};\\\", \\\"{x:929,y:626,t:1527635377018};\\\", \\\"{x:937,y:623,t:1527635377034};\\\", \\\"{x:938,y:623,t:1527635377051};\\\", \\\"{x:939,y:622,t:1527635377068};\\\", \\\"{x:939,y:621,t:1527635377085};\\\", \\\"{x:939,y:620,t:1527635377112};\\\", \\\"{x:939,y:618,t:1527635377145};\\\", \\\"{x:939,y:617,t:1527635377153};\\\", \\\"{x:938,y:615,t:1527635377167};\\\", \\\"{x:928,y:603,t:1527635377185};\\\", \\\"{x:914,y:587,t:1527635377204};\\\", \\\"{x:893,y:566,t:1527635377217};\\\", \\\"{x:857,y:532,t:1527635377235};\\\", \\\"{x:832,y:514,t:1527635377253};\\\", \\\"{x:817,y:503,t:1527635377268};\\\", \\\"{x:812,y:500,t:1527635377286};\\\", \\\"{x:813,y:500,t:1527635377360};\\\", \\\"{x:815,y:500,t:1527635377368};\\\", \\\"{x:817,y:501,t:1527635377385};\\\", \\\"{x:820,y:503,t:1527635377401};\\\", \\\"{x:821,y:504,t:1527635377418};\\\", \\\"{x:821,y:505,t:1527635377440};\\\", \\\"{x:822,y:505,t:1527635377451};\\\", \\\"{x:823,y:505,t:1527635377468};\\\", \\\"{x:824,y:506,t:1527635377485};\\\", \\\"{x:825,y:507,t:1527635377501};\\\", \\\"{x:826,y:507,t:1527635377519};\\\", \\\"{x:827,y:507,t:1527635377577};\\\", \\\"{x:828,y:507,t:1527635377601};\\\", \\\"{x:830,y:507,t:1527635377618};\\\", \\\"{x:831,y:507,t:1527635377640};\\\", \\\"{x:832,y:507,t:1527635377680};\\\", \\\"{x:832,y:506,t:1527635377688};\\\", \\\"{x:832,y:505,t:1527635377696};\\\", \\\"{x:832,y:505,t:1527635377702};\\\", \\\"{x:832,y:504,t:1527635377752};\\\", \\\"{x:826,y:504,t:1527635377768};\\\", \\\"{x:813,y:504,t:1527635377785};\\\", \\\"{x:784,y:504,t:1527635377803};\\\", \\\"{x:734,y:501,t:1527635377818};\\\", \\\"{x:671,y:496,t:1527635377835};\\\", \\\"{x:617,y:495,t:1527635377852};\\\", \\\"{x:575,y:489,t:1527635377868};\\\", \\\"{x:548,y:487,t:1527635377885};\\\", \\\"{x:532,y:487,t:1527635377902};\\\", \\\"{x:518,y:487,t:1527635377918};\\\", \\\"{x:506,y:488,t:1527635377935};\\\", \\\"{x:488,y:493,t:1527635377953};\\\", \\\"{x:474,y:495,t:1527635377969};\\\", \\\"{x:455,y:499,t:1527635377985};\\\", \\\"{x:432,y:499,t:1527635378002};\\\", \\\"{x:408,y:499,t:1527635378020};\\\", \\\"{x:390,y:500,t:1527635378035};\\\", \\\"{x:374,y:503,t:1527635378053};\\\", \\\"{x:362,y:504,t:1527635378069};\\\", \\\"{x:356,y:506,t:1527635378085};\\\", \\\"{x:353,y:507,t:1527635378102};\\\", \\\"{x:352,y:508,t:1527635378145};\\\", \\\"{x:350,y:509,t:1527635378161};\\\", \\\"{x:349,y:511,t:1527635378177};\\\", \\\"{x:348,y:511,t:1527635378193};\\\", \\\"{x:348,y:512,t:1527635378203};\\\", \\\"{x:346,y:513,t:1527635378219};\\\", \\\"{x:343,y:515,t:1527635378235};\\\", \\\"{x:339,y:518,t:1527635378252};\\\", \\\"{x:334,y:521,t:1527635378269};\\\", \\\"{x:329,y:525,t:1527635378286};\\\", \\\"{x:326,y:529,t:1527635378302};\\\", \\\"{x:323,y:532,t:1527635378319};\\\", \\\"{x:320,y:535,t:1527635378335};\\\", \\\"{x:313,y:541,t:1527635378352};\\\", \\\"{x:309,y:542,t:1527635378369};\\\", \\\"{x:303,y:545,t:1527635378386};\\\", \\\"{x:293,y:546,t:1527635378402};\\\", \\\"{x:282,y:546,t:1527635378419};\\\", \\\"{x:268,y:546,t:1527635378437};\\\", \\\"{x:246,y:546,t:1527635378452};\\\", \\\"{x:223,y:546,t:1527635378470};\\\", \\\"{x:196,y:544,t:1527635378486};\\\", \\\"{x:174,y:542,t:1527635378504};\\\", \\\"{x:158,y:539,t:1527635378521};\\\", \\\"{x:147,y:539,t:1527635378537};\\\", \\\"{x:146,y:539,t:1527635378553};\\\", \\\"{x:145,y:539,t:1527635378609};\\\", \\\"{x:145,y:538,t:1527635378816};\\\", \\\"{x:145,y:537,t:1527635378824};\\\", \\\"{x:145,y:535,t:1527635378832};\\\", \\\"{x:145,y:535,t:1527635378836};\\\", \\\"{x:145,y:529,t:1527635378853};\\\", \\\"{x:148,y:526,t:1527635378870};\\\", \\\"{x:160,y:526,t:1527635378886};\\\", \\\"{x:178,y:531,t:1527635378904};\\\", \\\"{x:234,y:557,t:1527635378921};\\\", \\\"{x:289,y:579,t:1527635378936};\\\", \\\"{x:362,y:607,t:1527635378954};\\\", \\\"{x:427,y:628,t:1527635378969};\\\", \\\"{x:478,y:643,t:1527635378987};\\\", \\\"{x:526,y:660,t:1527635379003};\\\", \\\"{x:566,y:673,t:1527635379019};\\\", \\\"{x:587,y:688,t:1527635379037};\\\", \\\"{x:597,y:697,t:1527635379053};\\\", \\\"{x:599,y:701,t:1527635379069};\\\", \\\"{x:599,y:702,t:1527635379086};\\\", \\\"{x:599,y:705,t:1527635379103};\\\", \\\"{x:589,y:705,t:1527635379120};\\\", \\\"{x:561,y:705,t:1527635379137};\\\", \\\"{x:536,y:702,t:1527635379153};\\\", \\\"{x:518,y:700,t:1527635379170};\\\", \\\"{x:499,y:700,t:1527635379186};\\\", \\\"{x:486,y:700,t:1527635379204};\\\", \\\"{x:478,y:699,t:1527635379221};\\\", \\\"{x:473,y:695,t:1527635379237};\\\", \\\"{x:462,y:690,t:1527635379254};\\\", \\\"{x:442,y:673,t:1527635379271};\\\", \\\"{x:406,y:642,t:1527635379288};\\\", \\\"{x:364,y:610,t:1527635379303};\\\", \\\"{x:298,y:580,t:1527635379321};\\\", \\\"{x:260,y:564,t:1527635379336};\\\", \\\"{x:228,y:554,t:1527635379354};\\\", \\\"{x:207,y:549,t:1527635379369};\\\", \\\"{x:190,y:543,t:1527635379386};\\\", \\\"{x:184,y:542,t:1527635379403};\\\", \\\"{x:182,y:542,t:1527635379420};\\\", \\\"{x:181,y:542,t:1527635379436};\\\", \\\"{x:180,y:540,t:1527635379453};\\\", \\\"{x:174,y:540,t:1527635379471};\\\", \\\"{x:171,y:539,t:1527635379487};\\\", \\\"{x:167,y:539,t:1527635379503};\\\", \\\"{x:161,y:537,t:1527635379520};\\\", \\\"{x:157,y:536,t:1527635379538};\\\", \\\"{x:156,y:536,t:1527635379553};\\\", \\\"{x:155,y:536,t:1527635379571};\\\", \\\"{x:155,y:535,t:1527635379672};\\\", \\\"{x:155,y:533,t:1527635379704};\\\", \\\"{x:155,y:533,t:1527635379708};\\\", \\\"{x:155,y:532,t:1527635379720};\\\", \\\"{x:160,y:530,t:1527635379737};\\\", \\\"{x:173,y:530,t:1527635379754};\\\", \\\"{x:191,y:538,t:1527635379771};\\\", \\\"{x:219,y:554,t:1527635379787};\\\", \\\"{x:259,y:577,t:1527635379804};\\\", \\\"{x:314,y:609,t:1527635379821};\\\", \\\"{x:354,y:632,t:1527635379837};\\\", \\\"{x:392,y:652,t:1527635379853};\\\", \\\"{x:421,y:667,t:1527635379871};\\\", \\\"{x:444,y:680,t:1527635379888};\\\", \\\"{x:462,y:689,t:1527635379904};\\\", \\\"{x:466,y:694,t:1527635379920};\\\", \\\"{x:467,y:694,t:1527635379937};\\\", \\\"{x:467,y:696,t:1527635379953};\\\", \\\"{x:467,y:700,t:1527635379971};\\\", \\\"{x:470,y:707,t:1527635379987};\\\", \\\"{x:471,y:718,t:1527635380003};\\\", \\\"{x:475,y:724,t:1527635380021};\\\", \\\"{x:481,y:731,t:1527635380037};\\\", \\\"{x:488,y:739,t:1527635380053};\\\", \\\"{x:494,y:744,t:1527635380070};\\\", \\\"{x:496,y:746,t:1527635380086};\\\", \\\"{x:497,y:746,t:1527635380384};\\\", \\\"{x:498,y:746,t:1527635380953};\\\", \\\"{x:500,y:743,t:1527635380960};\\\", \\\"{x:501,y:738,t:1527635380971};\\\", \\\"{x:504,y:727,t:1527635380988};\\\", \\\"{x:508,y:715,t:1527635381004};\\\", \\\"{x:514,y:703,t:1527635381021};\\\", \\\"{x:516,y:690,t:1527635381038};\\\", \\\"{x:521,y:679,t:1527635381054};\\\", \\\"{x:529,y:660,t:1527635381072};\\\", \\\"{x:537,y:644,t:1527635381087};\\\", \\\"{x:548,y:623,t:1527635381104};\\\", \\\"{x:553,y:611,t:1527635381122};\\\", \\\"{x:558,y:594,t:1527635381137};\\\", \\\"{x:567,y:574,t:1527635381154};\\\", \\\"{x:571,y:566,t:1527635381171};\\\", \\\"{x:573,y:561,t:1527635381188};\\\", \\\"{x:575,y:557,t:1527635381205};\\\", \\\"{x:575,y:556,t:1527635381222};\\\", \\\"{x:575,y:555,t:1527635381238};\\\", \\\"{x:576,y:554,t:1527635381255};\\\" ] }, { \\\"rt\\\": 43807, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 444586, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"93XU7\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 5.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"I\\\", \\\"J\\\", \\\"E\\\", \\\"F\\\", \\\"M\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-10 AM-09 AM-10 AM-7-B -X -M \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:581,y:561,t:1527635383627};\\\", \\\"{x:584,y:566,t:1527635383643};\\\", \\\"{x:592,y:566,t:1527635384337};\\\", \\\"{x:602,y:567,t:1527635384348};\\\", \\\"{x:614,y:568,t:1527635384355};\\\", \\\"{x:644,y:573,t:1527635384375};\\\", \\\"{x:672,y:578,t:1527635384390};\\\", \\\"{x:704,y:580,t:1527635384407};\\\", \\\"{x:735,y:584,t:1527635384424};\\\", \\\"{x:784,y:590,t:1527635384441};\\\", \\\"{x:814,y:594,t:1527635384458};\\\", \\\"{x:838,y:597,t:1527635384475};\\\", \\\"{x:861,y:601,t:1527635384491};\\\", \\\"{x:880,y:603,t:1527635384507};\\\", \\\"{x:895,y:607,t:1527635384525};\\\", \\\"{x:903,y:607,t:1527635384540};\\\", \\\"{x:909,y:608,t:1527635384557};\\\", \\\"{x:916,y:610,t:1527635384575};\\\", \\\"{x:925,y:611,t:1527635384590};\\\", \\\"{x:938,y:612,t:1527635384608};\\\", \\\"{x:962,y:616,t:1527635384625};\\\", \\\"{x:980,y:618,t:1527635384640};\\\", \\\"{x:999,y:624,t:1527635384658};\\\", \\\"{x:1020,y:630,t:1527635384675};\\\", \\\"{x:1037,y:635,t:1527635384690};\\\", \\\"{x:1053,y:640,t:1527635384708};\\\", \\\"{x:1065,y:643,t:1527635384725};\\\", \\\"{x:1069,y:643,t:1527635384741};\\\", \\\"{x:1070,y:643,t:1527635384758};\\\", \\\"{x:1070,y:641,t:1527635385265};\\\", \\\"{x:1069,y:641,t:1527635385281};\\\", \\\"{x:1069,y:639,t:1527635385305};\\\", \\\"{x:1068,y:639,t:1527635385369};\\\", \\\"{x:1068,y:637,t:1527635385433};\\\", \\\"{x:1067,y:637,t:1527635385529};\\\", \\\"{x:1066,y:636,t:1527635385545};\\\", \\\"{x:1065,y:635,t:1527635385617};\\\", \\\"{x:1064,y:635,t:1527635385641};\\\", \\\"{x:1063,y:633,t:1527635385658};\\\", \\\"{x:1062,y:633,t:1527635385681};\\\", \\\"{x:1061,y:633,t:1527635386426};\\\", \\\"{x:1063,y:633,t:1527635386962};\\\", \\\"{x:1067,y:633,t:1527635386977};\\\", \\\"{x:1080,y:634,t:1527635386993};\\\", \\\"{x:1091,y:636,t:1527635387009};\\\", \\\"{x:1103,y:643,t:1527635387026};\\\", \\\"{x:1117,y:650,t:1527635387042};\\\", \\\"{x:1138,y:663,t:1527635387060};\\\", \\\"{x:1162,y:686,t:1527635387076};\\\", \\\"{x:1194,y:717,t:1527635387092};\\\", \\\"{x:1235,y:752,t:1527635387110};\\\", \\\"{x:1276,y:787,t:1527635387126};\\\", \\\"{x:1310,y:817,t:1527635387142};\\\", \\\"{x:1329,y:838,t:1527635387159};\\\", \\\"{x:1339,y:854,t:1527635387176};\\\", \\\"{x:1340,y:865,t:1527635387193};\\\", \\\"{x:1336,y:887,t:1527635387209};\\\", \\\"{x:1321,y:907,t:1527635387226};\\\", \\\"{x:1307,y:922,t:1527635387243};\\\", \\\"{x:1292,y:939,t:1527635387260};\\\", \\\"{x:1281,y:949,t:1527635387276};\\\", \\\"{x:1274,y:956,t:1527635387292};\\\", \\\"{x:1266,y:959,t:1527635387309};\\\", \\\"{x:1260,y:962,t:1527635387326};\\\", \\\"{x:1256,y:963,t:1527635387343};\\\", \\\"{x:1251,y:964,t:1527635387359};\\\", \\\"{x:1244,y:964,t:1527635387376};\\\", \\\"{x:1236,y:964,t:1527635387392};\\\", \\\"{x:1227,y:965,t:1527635387409};\\\", \\\"{x:1222,y:967,t:1527635387427};\\\", \\\"{x:1218,y:969,t:1527635387443};\\\", \\\"{x:1216,y:971,t:1527635387459};\\\", \\\"{x:1216,y:972,t:1527635387505};\\\", \\\"{x:1217,y:974,t:1527635387521};\\\", \\\"{x:1219,y:975,t:1527635387536};\\\", \\\"{x:1222,y:976,t:1527635387553};\\\", \\\"{x:1224,y:977,t:1527635387561};\\\", \\\"{x:1226,y:977,t:1527635387576};\\\", \\\"{x:1229,y:978,t:1527635387593};\\\", \\\"{x:1228,y:978,t:1527635387673};\\\", \\\"{x:1225,y:978,t:1527635387681};\\\", \\\"{x:1222,y:978,t:1527635387693};\\\", \\\"{x:1213,y:978,t:1527635387709};\\\", \\\"{x:1202,y:978,t:1527635387726};\\\", \\\"{x:1190,y:978,t:1527635387744};\\\", \\\"{x:1183,y:978,t:1527635387759};\\\", \\\"{x:1177,y:978,t:1527635387776};\\\", \\\"{x:1170,y:978,t:1527635387793};\\\", \\\"{x:1168,y:978,t:1527635387810};\\\", \\\"{x:1166,y:978,t:1527635387826};\\\", \\\"{x:1161,y:978,t:1527635387843};\\\", \\\"{x:1156,y:978,t:1527635387859};\\\", \\\"{x:1151,y:978,t:1527635387875};\\\", \\\"{x:1147,y:978,t:1527635387892};\\\", \\\"{x:1144,y:978,t:1527635387909};\\\", \\\"{x:1139,y:978,t:1527635387926};\\\", \\\"{x:1135,y:978,t:1527635387943};\\\", \\\"{x:1134,y:978,t:1527635387959};\\\", \\\"{x:1132,y:978,t:1527635387975};\\\", \\\"{x:1131,y:978,t:1527635387992};\\\", \\\"{x:1132,y:977,t:1527635388249};\\\", \\\"{x:1135,y:977,t:1527635388260};\\\", \\\"{x:1143,y:976,t:1527635388277};\\\", \\\"{x:1157,y:976,t:1527635388293};\\\", \\\"{x:1171,y:976,t:1527635388311};\\\", \\\"{x:1187,y:976,t:1527635388326};\\\", \\\"{x:1198,y:976,t:1527635388344};\\\", \\\"{x:1207,y:976,t:1527635388360};\\\", \\\"{x:1211,y:976,t:1527635388376};\\\", \\\"{x:1212,y:976,t:1527635388393};\\\", \\\"{x:1213,y:976,t:1527635388697};\\\", \\\"{x:1215,y:976,t:1527635388710};\\\", \\\"{x:1220,y:976,t:1527635388726};\\\", \\\"{x:1227,y:976,t:1527635388743};\\\", \\\"{x:1236,y:976,t:1527635388761};\\\", \\\"{x:1247,y:976,t:1527635388776};\\\", \\\"{x:1251,y:976,t:1527635388793};\\\", \\\"{x:1254,y:976,t:1527635388810};\\\", \\\"{x:1255,y:976,t:1527635388826};\\\", \\\"{x:1256,y:976,t:1527635389969};\\\", \\\"{x:1257,y:974,t:1527635389977};\\\", \\\"{x:1257,y:973,t:1527635390001};\\\", \\\"{x:1257,y:972,t:1527635390011};\\\", \\\"{x:1257,y:968,t:1527635390028};\\\", \\\"{x:1257,y:964,t:1527635390045};\\\", \\\"{x:1260,y:953,t:1527635390061};\\\", \\\"{x:1261,y:933,t:1527635390077};\\\", \\\"{x:1264,y:913,t:1527635390094};\\\", \\\"{x:1264,y:893,t:1527635390110};\\\", \\\"{x:1263,y:873,t:1527635390128};\\\", \\\"{x:1259,y:852,t:1527635390144};\\\", \\\"{x:1254,y:834,t:1527635390161};\\\", \\\"{x:1253,y:808,t:1527635390177};\\\", \\\"{x:1253,y:784,t:1527635390195};\\\", \\\"{x:1255,y:764,t:1527635390210};\\\", \\\"{x:1257,y:743,t:1527635390227};\\\", \\\"{x:1261,y:726,t:1527635390244};\\\", \\\"{x:1266,y:706,t:1527635390261};\\\", \\\"{x:1271,y:691,t:1527635390277};\\\", \\\"{x:1276,y:671,t:1527635390294};\\\", \\\"{x:1283,y:651,t:1527635390310};\\\", \\\"{x:1287,y:632,t:1527635390327};\\\", \\\"{x:1292,y:609,t:1527635390344};\\\", \\\"{x:1293,y:599,t:1527635390360};\\\", \\\"{x:1293,y:592,t:1527635390377};\\\", \\\"{x:1293,y:587,t:1527635390394};\\\", \\\"{x:1293,y:577,t:1527635390411};\\\", \\\"{x:1293,y:569,t:1527635390427};\\\", \\\"{x:1290,y:558,t:1527635390444};\\\", \\\"{x:1286,y:546,t:1527635390461};\\\", \\\"{x:1285,y:538,t:1527635390476};\\\", \\\"{x:1282,y:523,t:1527635390494};\\\", \\\"{x:1280,y:509,t:1527635390510};\\\", \\\"{x:1280,y:495,t:1527635390527};\\\", \\\"{x:1280,y:475,t:1527635390543};\\\", \\\"{x:1280,y:461,t:1527635390561};\\\", \\\"{x:1284,y:449,t:1527635390576};\\\", \\\"{x:1288,y:438,t:1527635390594};\\\", \\\"{x:1292,y:431,t:1527635390611};\\\", \\\"{x:1294,y:428,t:1527635390627};\\\", \\\"{x:1296,y:426,t:1527635390644};\\\", \\\"{x:1296,y:425,t:1527635390661};\\\", \\\"{x:1304,y:426,t:1527635390728};\\\", \\\"{x:1334,y:441,t:1527635390744};\\\", \\\"{x:1369,y:463,t:1527635390760};\\\", \\\"{x:1385,y:486,t:1527635390777};\\\", \\\"{x:1390,y:507,t:1527635390794};\\\", \\\"{x:1393,y:513,t:1527635390811};\\\", \\\"{x:1393,y:514,t:1527635390827};\\\", \\\"{x:1392,y:514,t:1527635390921};\\\", \\\"{x:1389,y:513,t:1527635390929};\\\", \\\"{x:1386,y:512,t:1527635390945};\\\", \\\"{x:1378,y:508,t:1527635390961};\\\", \\\"{x:1370,y:505,t:1527635390977};\\\", \\\"{x:1365,y:503,t:1527635390994};\\\", \\\"{x:1361,y:501,t:1527635391011};\\\", \\\"{x:1356,y:500,t:1527635391027};\\\", \\\"{x:1353,y:499,t:1527635391043};\\\", \\\"{x:1348,y:499,t:1527635391061};\\\", \\\"{x:1345,y:499,t:1527635391078};\\\", \\\"{x:1341,y:500,t:1527635391094};\\\", \\\"{x:1338,y:502,t:1527635391111};\\\", \\\"{x:1335,y:503,t:1527635391128};\\\", \\\"{x:1333,y:503,t:1527635391241};\\\", \\\"{x:1332,y:503,t:1527635391249};\\\", \\\"{x:1331,y:503,t:1527635391262};\\\", \\\"{x:1329,y:503,t:1527635391278};\\\", \\\"{x:1326,y:503,t:1527635391295};\\\", \\\"{x:1324,y:502,t:1527635391311};\\\", \\\"{x:1322,y:501,t:1527635391329};\\\", \\\"{x:1321,y:500,t:1527635391384};\\\", \\\"{x:1320,y:500,t:1527635391561};\\\", \\\"{x:1319,y:500,t:1527635391579};\\\", \\\"{x:1318,y:500,t:1527635391595};\\\", \\\"{x:1317,y:499,t:1527635391612};\\\", \\\"{x:1316,y:498,t:1527635391629};\\\", \\\"{x:1314,y:498,t:1527635391644};\\\", \\\"{x:1314,y:497,t:1527635391661};\\\", \\\"{x:1313,y:497,t:1527635391679};\\\", \\\"{x:1312,y:497,t:1527635391695};\\\", \\\"{x:1311,y:497,t:1527635391711};\\\", \\\"{x:1310,y:496,t:1527635391729};\\\", \\\"{x:1312,y:496,t:1527635398465};\\\", \\\"{x:1314,y:496,t:1527635398482};\\\", \\\"{x:1315,y:497,t:1527635398505};\\\", \\\"{x:1316,y:497,t:1527635398521};\\\", \\\"{x:1317,y:498,t:1527635398532};\\\", \\\"{x:1318,y:499,t:1527635398549};\\\", \\\"{x:1319,y:500,t:1527635398565};\\\", \\\"{x:1321,y:502,t:1527635398581};\\\", \\\"{x:1322,y:504,t:1527635398598};\\\", \\\"{x:1322,y:510,t:1527635398615};\\\", \\\"{x:1322,y:516,t:1527635398631};\\\", \\\"{x:1322,y:529,t:1527635398649};\\\", \\\"{x:1322,y:547,t:1527635398664};\\\", \\\"{x:1317,y:573,t:1527635398682};\\\", \\\"{x:1306,y:611,t:1527635398699};\\\", \\\"{x:1298,y:646,t:1527635398715};\\\", \\\"{x:1293,y:680,t:1527635398732};\\\", \\\"{x:1291,y:706,t:1527635398749};\\\", \\\"{x:1291,y:732,t:1527635398764};\\\", \\\"{x:1291,y:753,t:1527635398781};\\\", \\\"{x:1291,y:775,t:1527635398798};\\\", \\\"{x:1291,y:793,t:1527635398814};\\\", \\\"{x:1291,y:812,t:1527635398831};\\\", \\\"{x:1291,y:833,t:1527635398848};\\\", \\\"{x:1292,y:838,t:1527635398864};\\\", \\\"{x:1292,y:839,t:1527635398882};\\\", \\\"{x:1293,y:841,t:1527635398921};\\\", \\\"{x:1297,y:838,t:1527635398952};\\\", \\\"{x:1303,y:834,t:1527635398965};\\\", \\\"{x:1317,y:820,t:1527635398981};\\\", \\\"{x:1330,y:807,t:1527635398998};\\\", \\\"{x:1346,y:790,t:1527635399015};\\\", \\\"{x:1358,y:779,t:1527635399031};\\\", \\\"{x:1368,y:766,t:1527635399047};\\\", \\\"{x:1371,y:761,t:1527635399065};\\\", \\\"{x:1372,y:758,t:1527635399081};\\\", \\\"{x:1372,y:756,t:1527635399098};\\\", \\\"{x:1372,y:755,t:1527635399115};\\\", \\\"{x:1368,y:755,t:1527635399233};\\\", \\\"{x:1358,y:759,t:1527635399249};\\\", \\\"{x:1351,y:764,t:1527635399268};\\\", \\\"{x:1347,y:765,t:1527635399281};\\\", \\\"{x:1344,y:766,t:1527635399298};\\\", \\\"{x:1343,y:766,t:1527635399489};\\\", \\\"{x:1343,y:765,t:1527635399513};\\\", \\\"{x:1343,y:764,t:1527635399536};\\\", \\\"{x:1347,y:764,t:1527635407406};\\\", \\\"{x:1353,y:764,t:1527635407416};\\\", \\\"{x:1362,y:765,t:1527635407435};\\\", \\\"{x:1372,y:766,t:1527635407450};\\\", \\\"{x:1378,y:767,t:1527635407467};\\\", \\\"{x:1380,y:769,t:1527635407484};\\\", \\\"{x:1382,y:769,t:1527635407501};\\\", \\\"{x:1384,y:771,t:1527635407516};\\\", \\\"{x:1386,y:771,t:1527635407533};\\\", \\\"{x:1394,y:774,t:1527635407550};\\\", \\\"{x:1403,y:777,t:1527635407566};\\\", \\\"{x:1418,y:781,t:1527635407584};\\\", \\\"{x:1430,y:784,t:1527635407601};\\\", \\\"{x:1443,y:788,t:1527635407617};\\\", \\\"{x:1456,y:792,t:1527635407634};\\\", \\\"{x:1465,y:794,t:1527635407651};\\\", \\\"{x:1472,y:797,t:1527635407667};\\\", \\\"{x:1478,y:798,t:1527635407684};\\\", \\\"{x:1484,y:802,t:1527635407701};\\\", \\\"{x:1487,y:802,t:1527635407717};\\\", \\\"{x:1488,y:803,t:1527635407734};\\\", \\\"{x:1489,y:805,t:1527635407750};\\\", \\\"{x:1490,y:806,t:1527635407768};\\\", \\\"{x:1491,y:809,t:1527635407785};\\\", \\\"{x:1491,y:812,t:1527635407801};\\\", \\\"{x:1493,y:815,t:1527635407818};\\\", \\\"{x:1493,y:817,t:1527635407833};\\\", \\\"{x:1493,y:819,t:1527635407851};\\\", \\\"{x:1494,y:821,t:1527635407868};\\\", \\\"{x:1494,y:823,t:1527635407884};\\\", \\\"{x:1494,y:824,t:1527635407910};\\\", \\\"{x:1494,y:825,t:1527635407926};\\\", \\\"{x:1494,y:826,t:1527635407958};\\\", \\\"{x:1494,y:827,t:1527635407990};\\\", \\\"{x:1494,y:828,t:1527635408047};\\\", \\\"{x:1494,y:829,t:1527635408070};\\\", \\\"{x:1494,y:830,t:1527635408084};\\\", \\\"{x:1489,y:831,t:1527635408101};\\\", \\\"{x:1477,y:834,t:1527635408118};\\\", \\\"{x:1471,y:834,t:1527635408135};\\\", \\\"{x:1443,y:841,t:1527635408151};\\\", \\\"{x:1414,y:851,t:1527635408168};\\\", \\\"{x:1394,y:863,t:1527635408184};\\\", \\\"{x:1374,y:878,t:1527635408200};\\\", \\\"{x:1362,y:888,t:1527635408217};\\\", \\\"{x:1360,y:894,t:1527635408234};\\\", \\\"{x:1360,y:896,t:1527635408251};\\\", \\\"{x:1360,y:897,t:1527635408268};\\\", \\\"{x:1360,y:898,t:1527635408294};\\\", \\\"{x:1363,y:899,t:1527635408343};\\\", \\\"{x:1368,y:899,t:1527635408350};\\\", \\\"{x:1382,y:899,t:1527635408367};\\\", \\\"{x:1396,y:899,t:1527635408383};\\\", \\\"{x:1406,y:899,t:1527635408400};\\\", \\\"{x:1409,y:899,t:1527635408417};\\\", \\\"{x:1410,y:899,t:1527635408434};\\\", \\\"{x:1411,y:899,t:1527635408469};\\\", \\\"{x:1411,y:897,t:1527635408486};\\\", \\\"{x:1409,y:895,t:1527635408501};\\\", \\\"{x:1394,y:884,t:1527635408517};\\\", \\\"{x:1373,y:873,t:1527635408534};\\\", \\\"{x:1335,y:855,t:1527635408551};\\\", \\\"{x:1266,y:826,t:1527635408567};\\\", \\\"{x:1184,y:796,t:1527635408584};\\\", \\\"{x:1096,y:758,t:1527635408600};\\\", \\\"{x:991,y:726,t:1527635408618};\\\", \\\"{x:891,y:698,t:1527635408634};\\\", \\\"{x:791,y:670,t:1527635408651};\\\", \\\"{x:686,y:640,t:1527635408667};\\\", \\\"{x:597,y:613,t:1527635408686};\\\", \\\"{x:527,y:590,t:1527635408701};\\\", \\\"{x:448,y:559,t:1527635408717};\\\", \\\"{x:413,y:544,t:1527635408741};\\\", \\\"{x:401,y:537,t:1527635408758};\\\", \\\"{x:391,y:530,t:1527635408774};\\\", \\\"{x:382,y:523,t:1527635408792};\\\", \\\"{x:378,y:520,t:1527635408808};\\\", \\\"{x:375,y:518,t:1527635408824};\\\", \\\"{x:367,y:514,t:1527635408841};\\\", \\\"{x:359,y:510,t:1527635408858};\\\", \\\"{x:343,y:505,t:1527635408875};\\\", \\\"{x:322,y:500,t:1527635408891};\\\", \\\"{x:296,y:496,t:1527635408909};\\\", \\\"{x:243,y:496,t:1527635408926};\\\", \\\"{x:218,y:496,t:1527635408941};\\\", \\\"{x:203,y:498,t:1527635408958};\\\", \\\"{x:194,y:500,t:1527635408974};\\\", \\\"{x:192,y:500,t:1527635408991};\\\", \\\"{x:192,y:501,t:1527635409055};\\\", \\\"{x:192,y:502,t:1527635409078};\\\", \\\"{x:193,y:503,t:1527635409092};\\\", \\\"{x:197,y:504,t:1527635409109};\\\", \\\"{x:200,y:505,t:1527635409125};\\\", \\\"{x:207,y:506,t:1527635409142};\\\", \\\"{x:219,y:506,t:1527635409158};\\\", \\\"{x:237,y:506,t:1527635409175};\\\", \\\"{x:252,y:506,t:1527635409192};\\\", \\\"{x:255,y:506,t:1527635409208};\\\", \\\"{x:256,y:506,t:1527635409494};\\\", \\\"{x:258,y:506,t:1527635409508};\\\", \\\"{x:266,y:509,t:1527635409525};\\\", \\\"{x:268,y:510,t:1527635409541};\\\", \\\"{x:268,y:511,t:1527635409959};\\\", \\\"{x:269,y:512,t:1527635409982};\\\", \\\"{x:270,y:512,t:1527635409998};\\\", \\\"{x:271,y:512,t:1527635410009};\\\", \\\"{x:272,y:512,t:1527635410024};\\\", \\\"{x:273,y:512,t:1527635410055};\\\", \\\"{x:274,y:512,t:1527635410074};\\\", \\\"{x:277,y:512,t:1527635410092};\\\", \\\"{x:287,y:513,t:1527635410109};\\\", \\\"{x:298,y:516,t:1527635410125};\\\", \\\"{x:310,y:517,t:1527635410142};\\\", \\\"{x:321,y:520,t:1527635410160};\\\", \\\"{x:329,y:520,t:1527635410176};\\\", \\\"{x:337,y:521,t:1527635410192};\\\", \\\"{x:340,y:521,t:1527635410209};\\\", \\\"{x:342,y:521,t:1527635410226};\\\", \\\"{x:344,y:523,t:1527635412055};\\\", \\\"{x:345,y:523,t:1527635412062};\\\", \\\"{x:345,y:524,t:1527635412086};\\\", \\\"{x:346,y:524,t:1527635412126};\\\", \\\"{x:347,y:524,t:1527635412134};\\\", \\\"{x:348,y:524,t:1527635412158};\\\", \\\"{x:348,y:525,t:1527635414431};\\\", \\\"{x:348,y:527,t:1527635414445};\\\", \\\"{x:344,y:529,t:1527635414462};\\\", \\\"{x:339,y:531,t:1527635414479};\\\", \\\"{x:335,y:531,t:1527635414496};\\\", \\\"{x:327,y:531,t:1527635414512};\\\", \\\"{x:313,y:531,t:1527635414529};\\\", \\\"{x:299,y:531,t:1527635414546};\\\", \\\"{x:283,y:531,t:1527635414562};\\\", \\\"{x:268,y:531,t:1527635414581};\\\", \\\"{x:254,y:531,t:1527635414596};\\\", \\\"{x:240,y:529,t:1527635414613};\\\", \\\"{x:234,y:528,t:1527635414629};\\\", \\\"{x:232,y:526,t:1527635414646};\\\", \\\"{x:231,y:526,t:1527635414798};\\\", \\\"{x:232,y:526,t:1527635414846};\\\", \\\"{x:235,y:526,t:1527635414863};\\\", \\\"{x:238,y:526,t:1527635414880};\\\", \\\"{x:242,y:526,t:1527635414897};\\\", \\\"{x:245,y:526,t:1527635414913};\\\", \\\"{x:247,y:526,t:1527635414929};\\\", \\\"{x:249,y:527,t:1527635414947};\\\", \\\"{x:252,y:527,t:1527635414963};\\\", \\\"{x:254,y:528,t:1527635414980};\\\", \\\"{x:255,y:529,t:1527635414996};\\\", \\\"{x:256,y:529,t:1527635415022};\\\", \\\"{x:257,y:529,t:1527635415126};\\\", \\\"{x:257,y:530,t:1527635415142};\\\", \\\"{x:258,y:530,t:1527635415391};\\\", \\\"{x:259,y:530,t:1527635415398};\\\", \\\"{x:261,y:530,t:1527635415414};\\\", \\\"{x:265,y:530,t:1527635415430};\\\", \\\"{x:266,y:530,t:1527635415447};\\\", \\\"{x:268,y:530,t:1527635415464};\\\", \\\"{x:268,y:531,t:1527635415480};\\\", \\\"{x:269,y:532,t:1527635415497};\\\", \\\"{x:270,y:532,t:1527635415517};\\\", \\\"{x:272,y:532,t:1527635415531};\\\", \\\"{x:275,y:533,t:1527635415548};\\\", \\\"{x:277,y:534,t:1527635415563};\\\", \\\"{x:281,y:536,t:1527635415580};\\\", \\\"{x:284,y:537,t:1527635415596};\\\", \\\"{x:288,y:539,t:1527635415613};\\\", \\\"{x:291,y:539,t:1527635415630};\\\", \\\"{x:295,y:540,t:1527635415646};\\\", \\\"{x:301,y:541,t:1527635415663};\\\", \\\"{x:310,y:543,t:1527635415680};\\\", \\\"{x:320,y:545,t:1527635415696};\\\", \\\"{x:337,y:548,t:1527635415713};\\\", \\\"{x:359,y:551,t:1527635415730};\\\", \\\"{x:382,y:556,t:1527635415747};\\\", \\\"{x:410,y:559,t:1527635415764};\\\", \\\"{x:440,y:562,t:1527635415780};\\\", \\\"{x:475,y:568,t:1527635415799};\\\", \\\"{x:525,y:575,t:1527635415814};\\\", \\\"{x:553,y:580,t:1527635415830};\\\", \\\"{x:578,y:583,t:1527635415847};\\\", \\\"{x:601,y:586,t:1527635415864};\\\", \\\"{x:618,y:590,t:1527635415881};\\\", \\\"{x:629,y:591,t:1527635415896};\\\", \\\"{x:635,y:591,t:1527635415913};\\\", \\\"{x:639,y:591,t:1527635415931};\\\", \\\"{x:640,y:591,t:1527635415957};\\\", \\\"{x:641,y:591,t:1527635416046};\\\", \\\"{x:641,y:590,t:1527635416070};\\\", \\\"{x:641,y:589,t:1527635416085};\\\", \\\"{x:641,y:587,t:1527635416098};\\\", \\\"{x:640,y:585,t:1527635416114};\\\", \\\"{x:635,y:583,t:1527635416130};\\\", \\\"{x:628,y:582,t:1527635416147};\\\", \\\"{x:619,y:579,t:1527635416164};\\\", \\\"{x:605,y:577,t:1527635416180};\\\", \\\"{x:583,y:573,t:1527635416198};\\\", \\\"{x:563,y:569,t:1527635416214};\\\", \\\"{x:543,y:567,t:1527635416230};\\\", \\\"{x:519,y:563,t:1527635416247};\\\", \\\"{x:494,y:561,t:1527635416265};\\\", \\\"{x:468,y:556,t:1527635416280};\\\", \\\"{x:445,y:553,t:1527635416297};\\\", \\\"{x:424,y:551,t:1527635416314};\\\", \\\"{x:407,y:547,t:1527635416330};\\\", \\\"{x:395,y:545,t:1527635416347};\\\", \\\"{x:384,y:544,t:1527635416365};\\\", \\\"{x:377,y:543,t:1527635416380};\\\", \\\"{x:369,y:542,t:1527635416398};\\\", \\\"{x:364,y:541,t:1527635416414};\\\", \\\"{x:359,y:540,t:1527635416430};\\\", \\\"{x:353,y:539,t:1527635416447};\\\", \\\"{x:346,y:539,t:1527635416464};\\\", \\\"{x:336,y:537,t:1527635416480};\\\", \\\"{x:326,y:536,t:1527635416498};\\\", \\\"{x:313,y:534,t:1527635416514};\\\", \\\"{x:306,y:532,t:1527635416530};\\\", \\\"{x:304,y:532,t:1527635416548};\\\", \\\"{x:305,y:532,t:1527635416598};\\\", \\\"{x:312,y:532,t:1527635416614};\\\", \\\"{x:322,y:532,t:1527635416631};\\\", \\\"{x:335,y:532,t:1527635416647};\\\", \\\"{x:348,y:532,t:1527635416664};\\\", \\\"{x:357,y:532,t:1527635416681};\\\", \\\"{x:363,y:532,t:1527635416697};\\\", \\\"{x:363,y:531,t:1527635416717};\\\", \\\"{x:363,y:530,t:1527635416757};\\\", \\\"{x:363,y:528,t:1527635416765};\\\", \\\"{x:362,y:525,t:1527635416780};\\\", \\\"{x:340,y:516,t:1527635416798};\\\", \\\"{x:309,y:510,t:1527635416814};\\\", \\\"{x:260,y:502,t:1527635416831};\\\", \\\"{x:205,y:496,t:1527635416848};\\\", \\\"{x:150,y:491,t:1527635416865};\\\", \\\"{x:107,y:488,t:1527635416881};\\\", \\\"{x:87,y:488,t:1527635416897};\\\", \\\"{x:79,y:488,t:1527635416914};\\\", \\\"{x:82,y:488,t:1527635416989};\\\", \\\"{x:86,y:488,t:1527635416997};\\\", \\\"{x:97,y:488,t:1527635417015};\\\", \\\"{x:111,y:488,t:1527635417031};\\\", \\\"{x:125,y:488,t:1527635417047};\\\", \\\"{x:135,y:488,t:1527635417064};\\\", \\\"{x:144,y:489,t:1527635417082};\\\", \\\"{x:147,y:490,t:1527635417098};\\\", \\\"{x:149,y:491,t:1527635417115};\\\", \\\"{x:151,y:492,t:1527635417190};\\\", \\\"{x:152,y:492,t:1527635417270};\\\", \\\"{x:153,y:492,t:1527635417351};\\\", \\\"{x:154,y:492,t:1527635417469};\\\", \\\"{x:154,y:492,t:1527635417474};\\\", \\\"{x:155,y:492,t:1527635417482};\\\", \\\"{x:161,y:496,t:1527635417498};\\\", \\\"{x:167,y:497,t:1527635417515};\\\", \\\"{x:180,y:501,t:1527635417532};\\\", \\\"{x:196,y:506,t:1527635417548};\\\", \\\"{x:219,y:511,t:1527635417565};\\\", \\\"{x:234,y:512,t:1527635417582};\\\", \\\"{x:245,y:515,t:1527635417599};\\\", \\\"{x:250,y:515,t:1527635417615};\\\", \\\"{x:252,y:515,t:1527635417631};\\\", \\\"{x:254,y:514,t:1527635417726};\\\", \\\"{x:254,y:512,t:1527635417734};\\\", \\\"{x:254,y:511,t:1527635417748};\\\", \\\"{x:250,y:503,t:1527635417765};\\\", \\\"{x:242,y:500,t:1527635417782};\\\", \\\"{x:229,y:499,t:1527635417798};\\\", \\\"{x:213,y:498,t:1527635417815};\\\", \\\"{x:195,y:497,t:1527635417833};\\\", \\\"{x:172,y:497,t:1527635417849};\\\", \\\"{x:154,y:497,t:1527635417866};\\\", \\\"{x:147,y:497,t:1527635417883};\\\", \\\"{x:142,y:497,t:1527635417898};\\\", \\\"{x:141,y:497,t:1527635417916};\\\", \\\"{x:142,y:497,t:1527635418118};\\\", \\\"{x:146,y:497,t:1527635418132};\\\", \\\"{x:151,y:497,t:1527635418149};\\\", \\\"{x:156,y:497,t:1527635418165};\\\", \\\"{x:157,y:497,t:1527635418182};\\\", \\\"{x:159,y:497,t:1527635418415};\\\", \\\"{x:171,y:497,t:1527635418432};\\\", \\\"{x:187,y:499,t:1527635418450};\\\", \\\"{x:206,y:501,t:1527635418466};\\\", \\\"{x:224,y:504,t:1527635418482};\\\", \\\"{x:238,y:505,t:1527635418500};\\\", \\\"{x:246,y:506,t:1527635418516};\\\", \\\"{x:248,y:507,t:1527635418532};\\\", \\\"{x:250,y:508,t:1527635418718};\\\", \\\"{x:251,y:509,t:1527635418733};\\\", \\\"{x:253,y:510,t:1527635418749};\\\", \\\"{x:257,y:512,t:1527635418766};\\\", \\\"{x:262,y:513,t:1527635418783};\\\", \\\"{x:267,y:514,t:1527635418800};\\\", \\\"{x:271,y:516,t:1527635418816};\\\", \\\"{x:272,y:516,t:1527635418833};\\\", \\\"{x:272,y:517,t:1527635419790};\\\", \\\"{x:274,y:516,t:1527635419959};\\\", \\\"{x:275,y:516,t:1527635419967};\\\", \\\"{x:281,y:514,t:1527635419982};\\\", \\\"{x:286,y:512,t:1527635419999};\\\", \\\"{x:289,y:510,t:1527635420016};\\\", \\\"{x:291,y:510,t:1527635420032};\\\", \\\"{x:292,y:510,t:1527635420049};\\\", \\\"{x:293,y:512,t:1527635420263};\\\", \\\"{x:300,y:512,t:1527635420270};\\\", \\\"{x:307,y:512,t:1527635420283};\\\", \\\"{x:325,y:512,t:1527635420300};\\\", \\\"{x:343,y:511,t:1527635420317};\\\", \\\"{x:354,y:510,t:1527635420333};\\\", \\\"{x:359,y:509,t:1527635420350};\\\", \\\"{x:360,y:509,t:1527635420478};\\\", \\\"{x:361,y:508,t:1527635420486};\\\", \\\"{x:362,y:508,t:1527635420500};\\\", \\\"{x:366,y:506,t:1527635420517};\\\", \\\"{x:367,y:506,t:1527635420534};\\\", \\\"{x:371,y:505,t:1527635420550};\\\", \\\"{x:375,y:504,t:1527635420567};\\\", \\\"{x:378,y:503,t:1527635420584};\\\", \\\"{x:381,y:503,t:1527635420600};\\\", \\\"{x:382,y:503,t:1527635420617};\\\", \\\"{x:386,y:508,t:1527635420818};\\\", \\\"{x:391,y:520,t:1527635420835};\\\", \\\"{x:394,y:529,t:1527635420851};\\\", \\\"{x:394,y:535,t:1527635420867};\\\", \\\"{x:394,y:540,t:1527635420884};\\\", \\\"{x:394,y:544,t:1527635420901};\\\", \\\"{x:393,y:546,t:1527635420918};\\\", \\\"{x:393,y:545,t:1527635421029};\\\", \\\"{x:393,y:542,t:1527635421037};\\\", \\\"{x:393,y:539,t:1527635421051};\\\", \\\"{x:392,y:535,t:1527635421068};\\\", \\\"{x:391,y:533,t:1527635421084};\\\", \\\"{x:390,y:532,t:1527635421102};\\\", \\\"{x:389,y:534,t:1527635421390};\\\", \\\"{x:389,y:535,t:1527635421402};\\\", \\\"{x:389,y:540,t:1527635421417};\\\", \\\"{x:389,y:545,t:1527635421434};\\\", \\\"{x:389,y:549,t:1527635421452};\\\", \\\"{x:389,y:554,t:1527635421468};\\\", \\\"{x:392,y:559,t:1527635421485};\\\", \\\"{x:399,y:569,t:1527635421502};\\\", \\\"{x:406,y:575,t:1527635421519};\\\", \\\"{x:417,y:578,t:1527635421534};\\\", \\\"{x:431,y:580,t:1527635421552};\\\", \\\"{x:446,y:583,t:1527635421568};\\\", \\\"{x:464,y:585,t:1527635421584};\\\", \\\"{x:485,y:585,t:1527635421602};\\\", \\\"{x:501,y:585,t:1527635421619};\\\", \\\"{x:519,y:585,t:1527635421636};\\\", \\\"{x:537,y:583,t:1527635421651};\\\", \\\"{x:552,y:581,t:1527635421669};\\\", \\\"{x:570,y:578,t:1527635421685};\\\", \\\"{x:600,y:574,t:1527635421701};\\\", \\\"{x:617,y:573,t:1527635421718};\\\", \\\"{x:634,y:573,t:1527635421735};\\\", \\\"{x:646,y:573,t:1527635421752};\\\", \\\"{x:655,y:573,t:1527635421769};\\\", \\\"{x:662,y:573,t:1527635421786};\\\", \\\"{x:666,y:573,t:1527635421802};\\\", \\\"{x:668,y:573,t:1527635421819};\\\", \\\"{x:671,y:573,t:1527635421836};\\\", \\\"{x:673,y:573,t:1527635421852};\\\", \\\"{x:674,y:573,t:1527635421869};\\\", \\\"{x:676,y:574,t:1527635421885};\\\", \\\"{x:677,y:574,t:1527635421901};\\\", \\\"{x:678,y:574,t:1527635421919};\\\", \\\"{x:678,y:576,t:1527635421936};\\\", \\\"{x:678,y:577,t:1527635421952};\\\", \\\"{x:678,y:581,t:1527635421969};\\\", \\\"{x:667,y:586,t:1527635421986};\\\", \\\"{x:652,y:589,t:1527635422002};\\\", \\\"{x:630,y:591,t:1527635422019};\\\", \\\"{x:601,y:591,t:1527635422036};\\\", \\\"{x:578,y:591,t:1527635422051};\\\", \\\"{x:559,y:591,t:1527635422069};\\\", \\\"{x:541,y:590,t:1527635422085};\\\", \\\"{x:535,y:588,t:1527635422102};\\\", \\\"{x:534,y:588,t:1527635422142};\\\", \\\"{x:534,y:587,t:1527635422157};\\\", \\\"{x:533,y:586,t:1527635422173};\\\", \\\"{x:532,y:585,t:1527635422186};\\\", \\\"{x:531,y:583,t:1527635422201};\\\", \\\"{x:531,y:582,t:1527635422219};\\\", \\\"{x:528,y:579,t:1527635422236};\\\", \\\"{x:525,y:576,t:1527635422252};\\\", \\\"{x:524,y:575,t:1527635422269};\\\", \\\"{x:522,y:575,t:1527635422286};\\\", \\\"{x:522,y:573,t:1527635422303};\\\", \\\"{x:523,y:568,t:1527635422318};\\\", \\\"{x:531,y:564,t:1527635422335};\\\", \\\"{x:545,y:561,t:1527635422353};\\\", \\\"{x:561,y:556,t:1527635422369};\\\", \\\"{x:575,y:552,t:1527635422385};\\\", \\\"{x:585,y:549,t:1527635422403};\\\", \\\"{x:593,y:547,t:1527635422418};\\\", \\\"{x:598,y:544,t:1527635422436};\\\", \\\"{x:599,y:543,t:1527635422452};\\\", \\\"{x:602,y:541,t:1527635422469};\\\", \\\"{x:605,y:541,t:1527635422485};\\\", \\\"{x:611,y:541,t:1527635422502};\\\", \\\"{x:626,y:541,t:1527635422519};\\\", \\\"{x:645,y:541,t:1527635422536};\\\", \\\"{x:668,y:541,t:1527635422552};\\\", \\\"{x:694,y:541,t:1527635422569};\\\", \\\"{x:717,y:537,t:1527635422585};\\\", \\\"{x:731,y:535,t:1527635422604};\\\", \\\"{x:738,y:531,t:1527635422618};\\\", \\\"{x:741,y:529,t:1527635422635};\\\", \\\"{x:744,y:524,t:1527635422653};\\\", \\\"{x:748,y:515,t:1527635422670};\\\", \\\"{x:752,y:510,t:1527635422686};\\\", \\\"{x:755,y:507,t:1527635422702};\\\", \\\"{x:759,y:504,t:1527635422718};\\\", \\\"{x:765,y:503,t:1527635422736};\\\", \\\"{x:772,y:503,t:1527635422753};\\\", \\\"{x:785,y:501,t:1527635422770};\\\", \\\"{x:801,y:498,t:1527635422785};\\\", \\\"{x:819,y:498,t:1527635422803};\\\", \\\"{x:836,y:498,t:1527635422819};\\\", \\\"{x:848,y:498,t:1527635422835};\\\", \\\"{x:860,y:498,t:1527635422853};\\\", \\\"{x:864,y:498,t:1527635422870};\\\", \\\"{x:862,y:498,t:1527635422958};\\\", \\\"{x:861,y:498,t:1527635422969};\\\", \\\"{x:855,y:498,t:1527635422986};\\\", \\\"{x:850,y:498,t:1527635423003};\\\", \\\"{x:845,y:498,t:1527635423020};\\\", \\\"{x:842,y:498,t:1527635423036};\\\", \\\"{x:840,y:498,t:1527635423197};\\\", \\\"{x:840,y:498,t:1527635423202};\\\", \\\"{x:838,y:499,t:1527635423221};\\\", \\\"{x:836,y:500,t:1527635423236};\\\", \\\"{x:822,y:501,t:1527635423253};\\\", \\\"{x:763,y:507,t:1527635423269};\\\", \\\"{x:715,y:514,t:1527635423287};\\\", \\\"{x:664,y:516,t:1527635423302};\\\", \\\"{x:625,y:516,t:1527635423319};\\\", \\\"{x:601,y:516,t:1527635423336};\\\", \\\"{x:584,y:516,t:1527635423353};\\\", \\\"{x:579,y:517,t:1527635423369};\\\", \\\"{x:578,y:517,t:1527635423413};\\\", \\\"{x:576,y:517,t:1527635423437};\\\", \\\"{x:575,y:517,t:1527635423454};\\\", \\\"{x:574,y:517,t:1527635423494};\\\", \\\"{x:574,y:516,t:1527635423518};\\\", \\\"{x:574,y:515,t:1527635423534};\\\", \\\"{x:574,y:514,t:1527635423541};\\\", \\\"{x:575,y:511,t:1527635423554};\\\", \\\"{x:584,y:509,t:1527635423569};\\\", \\\"{x:590,y:506,t:1527635423586};\\\", \\\"{x:593,y:505,t:1527635423604};\\\", \\\"{x:595,y:504,t:1527635423620};\\\", \\\"{x:596,y:504,t:1527635423701};\\\", \\\"{x:596,y:504,t:1527635423776};\\\", \\\"{x:598,y:504,t:1527635423787};\\\", \\\"{x:601,y:508,t:1527635423804};\\\", \\\"{x:607,y:524,t:1527635423821};\\\", \\\"{x:610,y:538,t:1527635423837};\\\", \\\"{x:609,y:560,t:1527635423854};\\\", \\\"{x:602,y:575,t:1527635423871};\\\", \\\"{x:591,y:593,t:1527635423887};\\\", \\\"{x:580,y:608,t:1527635423904};\\\", \\\"{x:571,y:624,t:1527635423920};\\\", \\\"{x:565,y:637,t:1527635423937};\\\", \\\"{x:559,y:648,t:1527635423954};\\\", \\\"{x:556,y:656,t:1527635423970};\\\", \\\"{x:556,y:660,t:1527635423987};\\\", \\\"{x:556,y:664,t:1527635424004};\\\", \\\"{x:555,y:669,t:1527635424020};\\\", \\\"{x:551,y:676,t:1527635424037};\\\", \\\"{x:547,y:688,t:1527635424054};\\\", \\\"{x:546,y:689,t:1527635424070};\\\", \\\"{x:546,y:686,t:1527635424125};\\\", \\\"{x:545,y:680,t:1527635424136};\\\", \\\"{x:545,y:665,t:1527635424154};\\\", \\\"{x:544,y:650,t:1527635424170};\\\", \\\"{x:544,y:628,t:1527635424187};\\\", \\\"{x:555,y:604,t:1527635424203};\\\", \\\"{x:567,y:576,t:1527635424221};\\\", \\\"{x:581,y:553,t:1527635424237};\\\", \\\"{x:599,y:531,t:1527635424254};\\\", \\\"{x:607,y:520,t:1527635424271};\\\", \\\"{x:612,y:513,t:1527635424287};\\\", \\\"{x:613,y:510,t:1527635424303};\\\", \\\"{x:613,y:509,t:1527635424320};\\\", \\\"{x:613,y:508,t:1527635424365};\\\", \\\"{x:613,y:507,t:1527635424373};\\\", \\\"{x:613,y:506,t:1527635424389};\\\", \\\"{x:613,y:510,t:1527635424605};\\\", \\\"{x:614,y:520,t:1527635424621};\\\", \\\"{x:614,y:551,t:1527635424637};\\\", \\\"{x:605,y:577,t:1527635424654};\\\", \\\"{x:591,y:609,t:1527635424671};\\\", \\\"{x:579,y:636,t:1527635424688};\\\", \\\"{x:570,y:656,t:1527635424704};\\\", \\\"{x:563,y:670,t:1527635424720};\\\", \\\"{x:558,y:676,t:1527635424737};\\\", \\\"{x:557,y:681,t:1527635424753};\\\", \\\"{x:556,y:683,t:1527635424771};\\\", \\\"{x:554,y:687,t:1527635424787};\\\", \\\"{x:553,y:688,t:1527635424804};\\\", \\\"{x:552,y:690,t:1527635424820};\\\", \\\"{x:552,y:691,t:1527635424837};\\\", \\\"{x:550,y:691,t:1527635424854};\\\", \\\"{x:550,y:692,t:1527635424871};\\\", \\\"{x:549,y:693,t:1527635424893};\\\", \\\"{x:548,y:694,t:1527635424909};\\\", \\\"{x:547,y:695,t:1527635424921};\\\", \\\"{x:546,y:699,t:1527635424938};\\\", \\\"{x:544,y:702,t:1527635424955};\\\", \\\"{x:543,y:705,t:1527635424971};\\\", \\\"{x:542,y:706,t:1527635424990};\\\", \\\"{x:541,y:710,t:1527635425005};\\\", \\\"{x:541,y:712,t:1527635425020};\\\", \\\"{x:540,y:715,t:1527635425037};\\\", \\\"{x:539,y:718,t:1527635425055};\\\", \\\"{x:539,y:722,t:1527635425071};\\\", \\\"{x:537,y:725,t:1527635425088};\\\", \\\"{x:537,y:729,t:1527635425105};\\\", \\\"{x:537,y:729,t:1527635425121};\\\", \\\"{x:537,y:730,t:1527635425370};\\\", \\\"{x:535,y:730,t:1527635425387};\\\", \\\"{x:534,y:730,t:1527635425453};\\\", \\\"{x:533,y:730,t:1527635425460};\\\", \\\"{x:530,y:730,t:1527635425472};\\\", \\\"{x:516,y:723,t:1527635425488};\\\", \\\"{x:501,y:717,t:1527635425504};\\\", \\\"{x:480,y:711,t:1527635425522};\\\", \\\"{x:459,y:705,t:1527635425537};\\\", \\\"{x:440,y:700,t:1527635425555};\\\", \\\"{x:427,y:695,t:1527635425572};\\\", \\\"{x:419,y:690,t:1527635425587};\\\", \\\"{x:415,y:687,t:1527635425605};\\\", \\\"{x:414,y:685,t:1527635425622};\\\", \\\"{x:412,y:678,t:1527635425638};\\\", \\\"{x:411,y:664,t:1527635425655};\\\", \\\"{x:407,y:646,t:1527635425672};\\\", \\\"{x:405,y:628,t:1527635425687};\\\", \\\"{x:401,y:607,t:1527635425704};\\\", \\\"{x:397,y:594,t:1527635425721};\\\", \\\"{x:397,y:588,t:1527635425738};\\\", \\\"{x:395,y:579,t:1527635425755};\\\", \\\"{x:395,y:573,t:1527635425772};\\\", \\\"{x:394,y:569,t:1527635425788};\\\", \\\"{x:394,y:566,t:1527635425805};\\\", \\\"{x:393,y:564,t:1527635425822};\\\", \\\"{x:393,y:562,t:1527635425839};\\\", \\\"{x:392,y:561,t:1527635425855};\\\", \\\"{x:392,y:558,t:1527635425871};\\\", \\\"{x:392,y:552,t:1527635425889};\\\", \\\"{x:392,y:536,t:1527635425904};\\\", \\\"{x:392,y:514,t:1527635425921};\\\", \\\"{x:391,y:495,t:1527635425938};\\\", \\\"{x:388,y:481,t:1527635425954};\\\", \\\"{x:387,y:468,t:1527635425972};\\\", \\\"{x:383,y:451,t:1527635425988};\\\", \\\"{x:383,y:448,t:1527635426005};\\\", \\\"{x:381,y:440,t:1527635426022};\\\", \\\"{x:379,y:436,t:1527635426039};\\\", \\\"{x:379,y:434,t:1527635426055};\\\", \\\"{x:378,y:432,t:1527635426071};\\\", \\\"{x:378,y:431,t:1527635426089};\\\", \\\"{x:377,y:430,t:1527635426106};\\\" ] }, { \\\"rt\\\": 15691, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 461545, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"93XU7\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -2-J -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:374,y:431,t:1527635427286};\\\", \\\"{x:372,y:436,t:1527635427310};\\\", \\\"{x:372,y:438,t:1527635427323};\\\", \\\"{x:371,y:438,t:1527635427902};\\\", \\\"{x:372,y:438,t:1527635427917};\\\", \\\"{x:374,y:438,t:1527635427925};\\\", \\\"{x:378,y:437,t:1527635427941};\\\", \\\"{x:400,y:437,t:1527635427958};\\\", \\\"{x:436,y:437,t:1527635427973};\\\", \\\"{x:492,y:444,t:1527635427990};\\\", \\\"{x:570,y:457,t:1527635428008};\\\", \\\"{x:662,y:470,t:1527635428023};\\\", \\\"{x:761,y:482,t:1527635428041};\\\", \\\"{x:859,y:498,t:1527635428059};\\\", \\\"{x:945,y:509,t:1527635428074};\\\", \\\"{x:1009,y:517,t:1527635428090};\\\", \\\"{x:1054,y:525,t:1527635428107};\\\", \\\"{x:1069,y:526,t:1527635428123};\\\", \\\"{x:1072,y:526,t:1527635428139};\\\", \\\"{x:1070,y:526,t:1527635428294};\\\", \\\"{x:1069,y:526,t:1527635428308};\\\", \\\"{x:1065,y:526,t:1527635428324};\\\", \\\"{x:1062,y:526,t:1527635428340};\\\", \\\"{x:1060,y:526,t:1527635428357};\\\", \\\"{x:1059,y:526,t:1527635429862};\\\", \\\"{x:1060,y:528,t:1527635429876};\\\", \\\"{x:1065,y:534,t:1527635429893};\\\", \\\"{x:1071,y:540,t:1527635429909};\\\", \\\"{x:1081,y:547,t:1527635429925};\\\", \\\"{x:1086,y:552,t:1527635429941};\\\", \\\"{x:1090,y:556,t:1527635429959};\\\", \\\"{x:1094,y:561,t:1527635429976};\\\", \\\"{x:1101,y:570,t:1527635429993};\\\", \\\"{x:1104,y:576,t:1527635430009};\\\", \\\"{x:1107,y:585,t:1527635430025};\\\", \\\"{x:1111,y:593,t:1527635430043};\\\", \\\"{x:1115,y:605,t:1527635430058};\\\", \\\"{x:1120,y:614,t:1527635430075};\\\", \\\"{x:1124,y:626,t:1527635430093};\\\", \\\"{x:1130,y:639,t:1527635430108};\\\", \\\"{x:1139,y:655,t:1527635430126};\\\", \\\"{x:1139,y:656,t:1527635430718};\\\", \\\"{x:1137,y:656,t:1527635430846};\\\", \\\"{x:1139,y:656,t:1527635430910};\\\", \\\"{x:1145,y:657,t:1527635430926};\\\", \\\"{x:1158,y:660,t:1527635430943};\\\", \\\"{x:1173,y:664,t:1527635430959};\\\", \\\"{x:1188,y:669,t:1527635430977};\\\", \\\"{x:1208,y:678,t:1527635430993};\\\", \\\"{x:1230,y:689,t:1527635431009};\\\", \\\"{x:1258,y:702,t:1527635431026};\\\", \\\"{x:1281,y:712,t:1527635431043};\\\", \\\"{x:1300,y:721,t:1527635431060};\\\", \\\"{x:1320,y:731,t:1527635431076};\\\", \\\"{x:1332,y:744,t:1527635431093};\\\", \\\"{x:1347,y:761,t:1527635431112};\\\", \\\"{x:1354,y:771,t:1527635431127};\\\", \\\"{x:1362,y:782,t:1527635431142};\\\", \\\"{x:1368,y:791,t:1527635431158};\\\", \\\"{x:1376,y:800,t:1527635431176};\\\", \\\"{x:1382,y:808,t:1527635431192};\\\", \\\"{x:1387,y:817,t:1527635431209};\\\", \\\"{x:1390,y:822,t:1527635431226};\\\", \\\"{x:1391,y:827,t:1527635431242};\\\", \\\"{x:1393,y:833,t:1527635431259};\\\", \\\"{x:1394,y:841,t:1527635431276};\\\", \\\"{x:1394,y:852,t:1527635431293};\\\", \\\"{x:1394,y:859,t:1527635431309};\\\", \\\"{x:1394,y:866,t:1527635431326};\\\", \\\"{x:1394,y:873,t:1527635431344};\\\", \\\"{x:1394,y:880,t:1527635431360};\\\", \\\"{x:1394,y:885,t:1527635431376};\\\", \\\"{x:1394,y:888,t:1527635431394};\\\", \\\"{x:1394,y:890,t:1527635431409};\\\", \\\"{x:1394,y:891,t:1527635431426};\\\", \\\"{x:1393,y:891,t:1527635431518};\\\", \\\"{x:1393,y:890,t:1527635431526};\\\", \\\"{x:1388,y:886,t:1527635431543};\\\", \\\"{x:1379,y:877,t:1527635431558};\\\", \\\"{x:1367,y:867,t:1527635431576};\\\", \\\"{x:1354,y:855,t:1527635431593};\\\", \\\"{x:1338,y:841,t:1527635431609};\\\", \\\"{x:1324,y:828,t:1527635431626};\\\", \\\"{x:1306,y:816,t:1527635431643};\\\", \\\"{x:1292,y:804,t:1527635431659};\\\", \\\"{x:1282,y:796,t:1527635431676};\\\", \\\"{x:1273,y:788,t:1527635431693};\\\", \\\"{x:1266,y:782,t:1527635431710};\\\", \\\"{x:1263,y:780,t:1527635431725};\\\", \\\"{x:1261,y:779,t:1527635431743};\\\", \\\"{x:1260,y:779,t:1527635431759};\\\", \\\"{x:1256,y:779,t:1527635431776};\\\", \\\"{x:1248,y:779,t:1527635431793};\\\", \\\"{x:1240,y:779,t:1527635431811};\\\", \\\"{x:1233,y:779,t:1527635431826};\\\", \\\"{x:1228,y:782,t:1527635431843};\\\", \\\"{x:1223,y:787,t:1527635431860};\\\", \\\"{x:1218,y:792,t:1527635431877};\\\", \\\"{x:1215,y:796,t:1527635431894};\\\", \\\"{x:1213,y:800,t:1527635431910};\\\", \\\"{x:1212,y:803,t:1527635431926};\\\", \\\"{x:1211,y:806,t:1527635431943};\\\", \\\"{x:1209,y:810,t:1527635431961};\\\", \\\"{x:1207,y:815,t:1527635431976};\\\", \\\"{x:1207,y:819,t:1527635431993};\\\", \\\"{x:1207,y:825,t:1527635432011};\\\", \\\"{x:1207,y:827,t:1527635432027};\\\", \\\"{x:1207,y:828,t:1527635432044};\\\", \\\"{x:1205,y:829,t:1527635432549};\\\", \\\"{x:1204,y:829,t:1527635432560};\\\", \\\"{x:1199,y:829,t:1527635432577};\\\", \\\"{x:1197,y:829,t:1527635432593};\\\", \\\"{x:1194,y:829,t:1527635432610};\\\", \\\"{x:1190,y:829,t:1527635432627};\\\", \\\"{x:1188,y:829,t:1527635432643};\\\", \\\"{x:1187,y:829,t:1527635432660};\\\", \\\"{x:1185,y:829,t:1527635432677};\\\", \\\"{x:1184,y:829,t:1527635432693};\\\", \\\"{x:1183,y:829,t:1527635432710};\\\", \\\"{x:1182,y:829,t:1527635432728};\\\", \\\"{x:1181,y:829,t:1527635432745};\\\", \\\"{x:1179,y:829,t:1527635432760};\\\", \\\"{x:1178,y:829,t:1527635432777};\\\", \\\"{x:1176,y:829,t:1527635432798};\\\", \\\"{x:1176,y:828,t:1527635432822};\\\", \\\"{x:1175,y:828,t:1527635432854};\\\", \\\"{x:1174,y:828,t:1527635432878};\\\", \\\"{x:1172,y:828,t:1527635432894};\\\", \\\"{x:1170,y:828,t:1527635432910};\\\", \\\"{x:1166,y:828,t:1527635432928};\\\", \\\"{x:1163,y:828,t:1527635432945};\\\", \\\"{x:1155,y:828,t:1527635432961};\\\", \\\"{x:1137,y:831,t:1527635432977};\\\", \\\"{x:1120,y:836,t:1527635432995};\\\", \\\"{x:1114,y:837,t:1527635433011};\\\", \\\"{x:1113,y:837,t:1527635433030};\\\", \\\"{x:1114,y:837,t:1527635433222};\\\", \\\"{x:1117,y:837,t:1527635433230};\\\", \\\"{x:1122,y:836,t:1527635433245};\\\", \\\"{x:1140,y:833,t:1527635433262};\\\", \\\"{x:1157,y:831,t:1527635433278};\\\", \\\"{x:1170,y:830,t:1527635433295};\\\", \\\"{x:1176,y:829,t:1527635433312};\\\", \\\"{x:1180,y:828,t:1527635433328};\\\", \\\"{x:1181,y:829,t:1527635433974};\\\", \\\"{x:1181,y:831,t:1527635433982};\\\", \\\"{x:1182,y:832,t:1527635433995};\\\", \\\"{x:1184,y:833,t:1527635434012};\\\", \\\"{x:1186,y:835,t:1527635434029};\\\", \\\"{x:1191,y:837,t:1527635434045};\\\", \\\"{x:1192,y:837,t:1527635434062};\\\", \\\"{x:1193,y:837,t:1527635436590};\\\", \\\"{x:1195,y:837,t:1527635436597};\\\", \\\"{x:1201,y:836,t:1527635436613};\\\", \\\"{x:1206,y:836,t:1527635436630};\\\", \\\"{x:1210,y:836,t:1527635436646};\\\", \\\"{x:1211,y:835,t:1527635436664};\\\", \\\"{x:1212,y:835,t:1527635436680};\\\", \\\"{x:1213,y:835,t:1527635436697};\\\", \\\"{x:1214,y:835,t:1527635436714};\\\", \\\"{x:1215,y:835,t:1527635436730};\\\", \\\"{x:1216,y:835,t:1527635436747};\\\", \\\"{x:1217,y:835,t:1527635436764};\\\", \\\"{x:1218,y:835,t:1527635436781};\\\", \\\"{x:1219,y:834,t:1527635436797};\\\", \\\"{x:1223,y:834,t:1527635436813};\\\", \\\"{x:1224,y:834,t:1527635436830};\\\", \\\"{x:1226,y:834,t:1527635436846};\\\", \\\"{x:1227,y:834,t:1527635436864};\\\", \\\"{x:1229,y:834,t:1527635436881};\\\", \\\"{x:1230,y:834,t:1527635436901};\\\", \\\"{x:1231,y:834,t:1527635436914};\\\", \\\"{x:1232,y:834,t:1527635436931};\\\", \\\"{x:1233,y:834,t:1527635436950};\\\", \\\"{x:1234,y:833,t:1527635436966};\\\", \\\"{x:1235,y:833,t:1527635437006};\\\", \\\"{x:1236,y:833,t:1527635437038};\\\", \\\"{x:1238,y:833,t:1527635437048};\\\", \\\"{x:1240,y:833,t:1527635437070};\\\", \\\"{x:1242,y:833,t:1527635437085};\\\", \\\"{x:1243,y:833,t:1527635437100};\\\", \\\"{x:1245,y:833,t:1527635437113};\\\", \\\"{x:1246,y:833,t:1527635437130};\\\", \\\"{x:1248,y:833,t:1527635437147};\\\", \\\"{x:1252,y:833,t:1527635437163};\\\", \\\"{x:1254,y:833,t:1527635437180};\\\", \\\"{x:1257,y:833,t:1527635437197};\\\", \\\"{x:1260,y:833,t:1527635437213};\\\", \\\"{x:1263,y:833,t:1527635437230};\\\", \\\"{x:1269,y:833,t:1527635437247};\\\", \\\"{x:1275,y:833,t:1527635437263};\\\", \\\"{x:1280,y:833,t:1527635437281};\\\", \\\"{x:1287,y:833,t:1527635437297};\\\", \\\"{x:1292,y:833,t:1527635437314};\\\", \\\"{x:1298,y:834,t:1527635437330};\\\", \\\"{x:1303,y:834,t:1527635437347};\\\", \\\"{x:1309,y:834,t:1527635437363};\\\", \\\"{x:1312,y:834,t:1527635437381};\\\", \\\"{x:1314,y:834,t:1527635437397};\\\", \\\"{x:1315,y:834,t:1527635437422};\\\", \\\"{x:1316,y:834,t:1527635437431};\\\", \\\"{x:1317,y:834,t:1527635437447};\\\", \\\"{x:1320,y:834,t:1527635437464};\\\", \\\"{x:1323,y:834,t:1527635437480};\\\", \\\"{x:1328,y:834,t:1527635437498};\\\", \\\"{x:1334,y:834,t:1527635437515};\\\", \\\"{x:1341,y:834,t:1527635437531};\\\", \\\"{x:1346,y:834,t:1527635437547};\\\", \\\"{x:1353,y:834,t:1527635437565};\\\", \\\"{x:1359,y:834,t:1527635437581};\\\", \\\"{x:1368,y:834,t:1527635437598};\\\", \\\"{x:1369,y:834,t:1527635437615};\\\", \\\"{x:1368,y:833,t:1527635437974};\\\", \\\"{x:1368,y:831,t:1527635437982};\\\", \\\"{x:1365,y:821,t:1527635437998};\\\", \\\"{x:1360,y:804,t:1527635438016};\\\", \\\"{x:1354,y:781,t:1527635438033};\\\", \\\"{x:1351,y:755,t:1527635438048};\\\", \\\"{x:1351,y:733,t:1527635438065};\\\", \\\"{x:1351,y:722,t:1527635438081};\\\", \\\"{x:1351,y:718,t:1527635438097};\\\", \\\"{x:1351,y:717,t:1527635438114};\\\", \\\"{x:1351,y:720,t:1527635438294};\\\", \\\"{x:1351,y:724,t:1527635438302};\\\", \\\"{x:1351,y:729,t:1527635438315};\\\", \\\"{x:1353,y:738,t:1527635438332};\\\", \\\"{x:1355,y:750,t:1527635438348};\\\", \\\"{x:1356,y:763,t:1527635438366};\\\", \\\"{x:1359,y:780,t:1527635438382};\\\", \\\"{x:1359,y:785,t:1527635438398};\\\", \\\"{x:1360,y:789,t:1527635438415};\\\", \\\"{x:1360,y:792,t:1527635438432};\\\", \\\"{x:1360,y:795,t:1527635438449};\\\", \\\"{x:1360,y:798,t:1527635438465};\\\", \\\"{x:1360,y:799,t:1527635438486};\\\", \\\"{x:1360,y:789,t:1527635438566};\\\", \\\"{x:1349,y:758,t:1527635438582};\\\", \\\"{x:1332,y:726,t:1527635438600};\\\", \\\"{x:1313,y:698,t:1527635438615};\\\", \\\"{x:1291,y:679,t:1527635438632};\\\", \\\"{x:1263,y:665,t:1527635438649};\\\", \\\"{x:1238,y:658,t:1527635438664};\\\", \\\"{x:1215,y:656,t:1527635438682};\\\", \\\"{x:1183,y:654,t:1527635438698};\\\", \\\"{x:1136,y:654,t:1527635438715};\\\", \\\"{x:1084,y:671,t:1527635438732};\\\", \\\"{x:1039,y:693,t:1527635438749};\\\", \\\"{x:1004,y:712,t:1527635438765};\\\", \\\"{x:975,y:729,t:1527635438781};\\\", \\\"{x:965,y:734,t:1527635438799};\\\", \\\"{x:960,y:738,t:1527635438814};\\\", \\\"{x:958,y:741,t:1527635438831};\\\", \\\"{x:957,y:741,t:1527635438849};\\\", \\\"{x:953,y:745,t:1527635438865};\\\", \\\"{x:945,y:747,t:1527635438882};\\\", \\\"{x:931,y:747,t:1527635438899};\\\", \\\"{x:909,y:747,t:1527635438916};\\\", \\\"{x:876,y:747,t:1527635438931};\\\", \\\"{x:828,y:740,t:1527635438948};\\\", \\\"{x:742,y:717,t:1527635438966};\\\", \\\"{x:681,y:700,t:1527635438982};\\\", \\\"{x:618,y:676,t:1527635438999};\\\", \\\"{x:558,y:654,t:1527635439015};\\\", \\\"{x:504,y:638,t:1527635439032};\\\", \\\"{x:457,y:624,t:1527635439051};\\\", \\\"{x:426,y:615,t:1527635439065};\\\", \\\"{x:409,y:611,t:1527635439082};\\\", \\\"{x:400,y:610,t:1527635439099};\\\", \\\"{x:398,y:609,t:1527635439115};\\\", \\\"{x:397,y:609,t:1527635439132};\\\", \\\"{x:395,y:612,t:1527635439148};\\\", \\\"{x:395,y:622,t:1527635439165};\\\", \\\"{x:395,y:630,t:1527635439183};\\\", \\\"{x:395,y:636,t:1527635439199};\\\", \\\"{x:395,y:638,t:1527635439216};\\\", \\\"{x:395,y:639,t:1527635439261};\\\", \\\"{x:396,y:637,t:1527635439269};\\\", \\\"{x:399,y:631,t:1527635439282};\\\", \\\"{x:405,y:611,t:1527635439300};\\\", \\\"{x:411,y:593,t:1527635439316};\\\", \\\"{x:416,y:573,t:1527635439332};\\\", \\\"{x:419,y:557,t:1527635439350};\\\", \\\"{x:419,y:550,t:1527635439367};\\\", \\\"{x:420,y:545,t:1527635439382};\\\", \\\"{x:423,y:543,t:1527635439399};\\\", \\\"{x:431,y:542,t:1527635439416};\\\", \\\"{x:447,y:541,t:1527635439432};\\\", \\\"{x:470,y:540,t:1527635439449};\\\", \\\"{x:496,y:536,t:1527635439466};\\\", \\\"{x:525,y:531,t:1527635439483};\\\", \\\"{x:552,y:531,t:1527635439499};\\\", \\\"{x:574,y:530,t:1527635439516};\\\", \\\"{x:591,y:530,t:1527635439532};\\\", \\\"{x:605,y:530,t:1527635439550};\\\", \\\"{x:606,y:530,t:1527635439566};\\\", \\\"{x:606,y:529,t:1527635439677};\\\", \\\"{x:606,y:528,t:1527635439717};\\\", \\\"{x:606,y:525,t:1527635439733};\\\", \\\"{x:606,y:520,t:1527635439750};\\\", \\\"{x:606,y:516,t:1527635439766};\\\", \\\"{x:606,y:511,t:1527635439784};\\\", \\\"{x:608,y:505,t:1527635439799};\\\", \\\"{x:610,y:503,t:1527635439817};\\\", \\\"{x:612,y:501,t:1527635439833};\\\", \\\"{x:613,y:501,t:1527635439933};\\\", \\\"{x:615,y:506,t:1527635439949};\\\", \\\"{x:615,y:511,t:1527635439966};\\\", \\\"{x:615,y:514,t:1527635439984};\\\", \\\"{x:615,y:516,t:1527635439999};\\\", \\\"{x:615,y:515,t:1527635440094};\\\", \\\"{x:615,y:512,t:1527635440102};\\\", \\\"{x:615,y:509,t:1527635440116};\\\", \\\"{x:615,y:502,t:1527635440133};\\\", \\\"{x:615,y:498,t:1527635440150};\\\", \\\"{x:615,y:494,t:1527635440166};\\\", \\\"{x:615,y:493,t:1527635440183};\\\", \\\"{x:615,y:494,t:1527635440413};\\\", \\\"{x:615,y:499,t:1527635440420};\\\", \\\"{x:616,y:506,t:1527635440433};\\\", \\\"{x:616,y:528,t:1527635440451};\\\", \\\"{x:616,y:554,t:1527635440467};\\\", \\\"{x:612,y:577,t:1527635440483};\\\", \\\"{x:607,y:598,t:1527635440501};\\\", \\\"{x:601,y:616,t:1527635440517};\\\", \\\"{x:598,y:639,t:1527635440534};\\\", \\\"{x:597,y:649,t:1527635440550};\\\", \\\"{x:597,y:659,t:1527635440567};\\\", \\\"{x:597,y:667,t:1527635440583};\\\", \\\"{x:597,y:675,t:1527635440601};\\\", \\\"{x:597,y:683,t:1527635440616};\\\", \\\"{x:597,y:689,t:1527635440633};\\\", \\\"{x:597,y:693,t:1527635440650};\\\", \\\"{x:596,y:698,t:1527635440668};\\\", \\\"{x:594,y:704,t:1527635440683};\\\", \\\"{x:591,y:716,t:1527635440700};\\\", \\\"{x:585,y:725,t:1527635440717};\\\", \\\"{x:581,y:730,t:1527635440733};\\\", \\\"{x:578,y:733,t:1527635440751};\\\", \\\"{x:577,y:734,t:1527635440767};\\\", \\\"{x:574,y:737,t:1527635440783};\\\", \\\"{x:571,y:739,t:1527635440800};\\\", \\\"{x:566,y:742,t:1527635440818};\\\", \\\"{x:561,y:744,t:1527635440835};\\\", \\\"{x:558,y:745,t:1527635440851};\\\", \\\"{x:557,y:745,t:1527635440866};\\\", \\\"{x:556,y:745,t:1527635440883};\\\", \\\"{x:555,y:746,t:1527635440901};\\\", \\\"{x:555,y:747,t:1527635440933};\\\", \\\"{x:553,y:750,t:1527635440949};\\\", \\\"{x:553,y:751,t:1527635440966};\\\", \\\"{x:553,y:752,t:1527635440984};\\\", \\\"{x:553,y:753,t:1527635441000};\\\", \\\"{x:552,y:754,t:1527635441016};\\\", \\\"{x:552,y:756,t:1527635441034};\\\", \\\"{x:552,y:757,t:1527635441050};\\\", \\\"{x:551,y:758,t:1527635441068};\\\", \\\"{x:551,y:759,t:1527635441086};\\\", \\\"{x:551,y:761,t:1527635441102};\\\", \\\"{x:551,y:763,t:1527635441117};\\\", \\\"{x:550,y:763,t:1527635441135};\\\", \\\"{x:550,y:764,t:1527635441182};\\\", \\\"{x:549,y:764,t:1527635441205};\\\", \\\"{x:548,y:764,t:1527635441217};\\\", \\\"{x:547,y:764,t:1527635441235};\\\", \\\"{x:542,y:763,t:1527635441250};\\\", \\\"{x:539,y:760,t:1527635441268};\\\", \\\"{x:536,y:758,t:1527635441285};\\\", \\\"{x:535,y:758,t:1527635441301};\\\", \\\"{x:534,y:757,t:1527635441317};\\\", \\\"{x:533,y:756,t:1527635441335};\\\", \\\"{x:533,y:752,t:1527635441352};\\\", \\\"{x:532,y:748,t:1527635441367};\\\", \\\"{x:530,y:742,t:1527635441384};\\\", \\\"{x:530,y:736,t:1527635441401};\\\", \\\"{x:530,y:731,t:1527635441417};\\\", \\\"{x:530,y:727,t:1527635441435};\\\", \\\"{x:530,y:722,t:1527635441451};\\\", \\\"{x:530,y:718,t:1527635441468};\\\", \\\"{x:530,y:717,t:1527635441484};\\\", \\\"{x:530,y:716,t:1527635441694};\\\", \\\"{x:532,y:716,t:1527635441701};\\\", \\\"{x:534,y:715,t:1527635441718};\\\", \\\"{x:536,y:714,t:1527635441734};\\\", \\\"{x:540,y:712,t:1527635441752};\\\", \\\"{x:543,y:709,t:1527635441768};\\\", \\\"{x:550,y:703,t:1527635441785};\\\", \\\"{x:560,y:695,t:1527635441802};\\\", \\\"{x:574,y:685,t:1527635441818};\\\", \\\"{x:585,y:677,t:1527635441834};\\\", \\\"{x:599,y:669,t:1527635441852};\\\", \\\"{x:609,y:663,t:1527635441868};\\\", \\\"{x:611,y:663,t:1527635441885};\\\", \\\"{x:612,y:663,t:1527635441933};\\\", \\\"{x:611,y:672,t:1527635441941};\\\", \\\"{x:605,y:686,t:1527635441952};\\\", \\\"{x:591,y:712,t:1527635441968};\\\", \\\"{x:577,y:727,t:1527635441985};\\\", \\\"{x:567,y:735,t:1527635442002};\\\", \\\"{x:563,y:738,t:1527635442020};\\\", \\\"{x:561,y:738,t:1527635442034};\\\", \\\"{x:560,y:738,t:1527635442051};\\\", \\\"{x:559,y:738,t:1527635442149};\\\", \\\"{x:557,y:738,t:1527635442261};\\\", \\\"{x:557,y:737,t:1527635442269};\\\", \\\"{x:555,y:736,t:1527635442285};\\\", \\\"{x:555,y:732,t:1527635442318};\\\", \\\"{x:555,y:731,t:1527635442380};\\\", \\\"{x:555,y:730,t:1527635442421};\\\", \\\"{x:557,y:727,t:1527635442435};\\\", \\\"{x:561,y:722,t:1527635442451};\\\", \\\"{x:569,y:716,t:1527635442468};\\\", \\\"{x:593,y:699,t:1527635442484};\\\", \\\"{x:597,y:693,t:1527635442502};\\\", \\\"{x:597,y:691,t:1527635442518};\\\", \\\"{x:597,y:690,t:1527635442536};\\\", \\\"{x:597,y:689,t:1527635442925};\\\", \\\"{x:595,y:687,t:1527635442936};\\\", \\\"{x:592,y:685,t:1527635442952};\\\", \\\"{x:587,y:681,t:1527635442969};\\\", \\\"{x:582,y:679,t:1527635442986};\\\", \\\"{x:577,y:674,t:1527635443003};\\\", \\\"{x:574,y:672,t:1527635443019};\\\", \\\"{x:573,y:670,t:1527635443036};\\\", \\\"{x:570,y:668,t:1527635443052};\\\", \\\"{x:569,y:667,t:1527635443078};\\\" ] }, { \\\"rt\\\": 12553, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 475423, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"93XU7\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -B -B -F -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:560,y:614,t:1527635443621};\\\", \\\"{x:560,y:599,t:1527635443636};\\\", \\\"{x:560,y:592,t:1527635443651};\\\", \\\"{x:562,y:575,t:1527635443668};\\\", \\\"{x:562,y:566,t:1527635443685};\\\", \\\"{x:562,y:551,t:1527635443716};\\\", \\\"{x:563,y:549,t:1527635443718};\\\", \\\"{x:563,y:543,t:1527635443736};\\\", \\\"{x:564,y:534,t:1527635443752};\\\", \\\"{x:564,y:526,t:1527635443769};\\\", \\\"{x:566,y:514,t:1527635443786};\\\", \\\"{x:568,y:509,t:1527635443802};\\\", \\\"{x:568,y:507,t:1527635443820};\\\", \\\"{x:570,y:506,t:1527635444116};\\\", \\\"{x:809,y:451,t:1527635444208};\\\", \\\"{x:842,y:451,t:1527635444222};\\\", \\\"{x:860,y:451,t:1527635444236};\\\", \\\"{x:863,y:451,t:1527635444252};\\\", \\\"{x:864,y:451,t:1527635444349};\\\", \\\"{x:862,y:451,t:1527635444373};\\\", \\\"{x:857,y:451,t:1527635444387};\\\", \\\"{x:841,y:451,t:1527635444402};\\\", \\\"{x:818,y:451,t:1527635444419};\\\", \\\"{x:780,y:451,t:1527635444437};\\\", \\\"{x:763,y:451,t:1527635444453};\\\", \\\"{x:756,y:451,t:1527635444470};\\\", \\\"{x:757,y:451,t:1527635445205};\\\", \\\"{x:760,y:451,t:1527635445220};\\\", \\\"{x:770,y:452,t:1527635445236};\\\", \\\"{x:776,y:453,t:1527635445252};\\\", \\\"{x:780,y:453,t:1527635445269};\\\", \\\"{x:784,y:455,t:1527635445287};\\\", \\\"{x:788,y:455,t:1527635445302};\\\", \\\"{x:794,y:456,t:1527635445319};\\\", \\\"{x:802,y:459,t:1527635445336};\\\", \\\"{x:812,y:462,t:1527635445353};\\\", \\\"{x:823,y:464,t:1527635445369};\\\", \\\"{x:836,y:468,t:1527635445387};\\\", \\\"{x:852,y:474,t:1527635445402};\\\", \\\"{x:872,y:483,t:1527635445420};\\\", \\\"{x:894,y:493,t:1527635445436};\\\", \\\"{x:933,y:510,t:1527635445453};\\\", \\\"{x:960,y:527,t:1527635445471};\\\", \\\"{x:981,y:540,t:1527635445488};\\\", \\\"{x:1003,y:558,t:1527635445504};\\\", \\\"{x:1023,y:578,t:1527635445520};\\\", \\\"{x:1037,y:599,t:1527635445538};\\\", \\\"{x:1051,y:622,t:1527635445555};\\\", \\\"{x:1062,y:644,t:1527635445571};\\\", \\\"{x:1075,y:674,t:1527635445588};\\\", \\\"{x:1092,y:718,t:1527635445605};\\\", \\\"{x:1100,y:745,t:1527635445620};\\\", \\\"{x:1108,y:763,t:1527635445637};\\\", \\\"{x:1115,y:778,t:1527635445654};\\\", \\\"{x:1124,y:792,t:1527635445671};\\\", \\\"{x:1132,y:803,t:1527635445687};\\\", \\\"{x:1144,y:813,t:1527635445704};\\\", \\\"{x:1158,y:820,t:1527635445721};\\\", \\\"{x:1175,y:827,t:1527635445737};\\\", \\\"{x:1193,y:832,t:1527635445754};\\\", \\\"{x:1209,y:835,t:1527635445771};\\\", \\\"{x:1223,y:836,t:1527635445787};\\\", \\\"{x:1242,y:836,t:1527635445804};\\\", \\\"{x:1249,y:836,t:1527635445821};\\\", \\\"{x:1258,y:834,t:1527635445837};\\\", \\\"{x:1266,y:833,t:1527635445854};\\\", \\\"{x:1274,y:832,t:1527635445871};\\\", \\\"{x:1285,y:831,t:1527635445887};\\\", \\\"{x:1291,y:829,t:1527635445904};\\\", \\\"{x:1300,y:827,t:1527635445921};\\\", \\\"{x:1304,y:825,t:1527635445937};\\\", \\\"{x:1307,y:823,t:1527635445954};\\\", \\\"{x:1309,y:822,t:1527635445971};\\\", \\\"{x:1314,y:818,t:1527635445987};\\\", \\\"{x:1328,y:811,t:1527635446005};\\\", \\\"{x:1338,y:805,t:1527635446021};\\\", \\\"{x:1345,y:799,t:1527635446038};\\\", \\\"{x:1354,y:793,t:1527635446054};\\\", \\\"{x:1362,y:786,t:1527635446072};\\\", \\\"{x:1370,y:780,t:1527635446088};\\\", \\\"{x:1375,y:776,t:1527635446104};\\\", \\\"{x:1382,y:772,t:1527635446122};\\\", \\\"{x:1386,y:768,t:1527635446137};\\\", \\\"{x:1391,y:762,t:1527635446154};\\\", \\\"{x:1394,y:756,t:1527635446171};\\\", \\\"{x:1395,y:750,t:1527635446189};\\\", \\\"{x:1395,y:747,t:1527635446205};\\\", \\\"{x:1394,y:745,t:1527635446222};\\\", \\\"{x:1389,y:742,t:1527635446239};\\\", \\\"{x:1386,y:740,t:1527635446254};\\\", \\\"{x:1383,y:739,t:1527635446271};\\\", \\\"{x:1380,y:739,t:1527635446287};\\\", \\\"{x:1378,y:738,t:1527635446305};\\\", \\\"{x:1377,y:737,t:1527635446322};\\\", \\\"{x:1375,y:736,t:1527635446338};\\\", \\\"{x:1374,y:736,t:1527635446354};\\\", \\\"{x:1371,y:735,t:1527635446372};\\\", \\\"{x:1369,y:735,t:1527635446388};\\\", \\\"{x:1367,y:734,t:1527635446405};\\\", \\\"{x:1365,y:731,t:1527635446421};\\\", \\\"{x:1363,y:729,t:1527635446438};\\\", \\\"{x:1361,y:725,t:1527635446454};\\\", \\\"{x:1357,y:720,t:1527635446471};\\\", \\\"{x:1356,y:717,t:1527635446488};\\\", \\\"{x:1355,y:714,t:1527635446505};\\\", \\\"{x:1353,y:711,t:1527635446521};\\\", \\\"{x:1353,y:710,t:1527635446538};\\\", \\\"{x:1352,y:708,t:1527635446556};\\\", \\\"{x:1352,y:707,t:1527635446572};\\\", \\\"{x:1350,y:706,t:1527635446589};\\\", \\\"{x:1350,y:705,t:1527635446604};\\\", \\\"{x:1350,y:704,t:1527635446622};\\\", \\\"{x:1350,y:703,t:1527635446638};\\\", \\\"{x:1350,y:702,t:1527635446741};\\\", \\\"{x:1350,y:701,t:1527635446757};\\\", \\\"{x:1350,y:700,t:1527635447668};\\\", \\\"{x:1349,y:699,t:1527635447676};\\\", \\\"{x:1348,y:699,t:1527635447853};\\\", \\\"{x:1347,y:704,t:1527635447861};\\\", \\\"{x:1347,y:706,t:1527635447872};\\\", \\\"{x:1347,y:713,t:1527635447890};\\\", \\\"{x:1346,y:723,t:1527635447907};\\\", \\\"{x:1345,y:733,t:1527635447923};\\\", \\\"{x:1343,y:742,t:1527635447940};\\\", \\\"{x:1343,y:750,t:1527635447956};\\\", \\\"{x:1343,y:755,t:1527635447973};\\\", \\\"{x:1342,y:759,t:1527635447990};\\\", \\\"{x:1342,y:763,t:1527635448007};\\\", \\\"{x:1342,y:766,t:1527635448023};\\\", \\\"{x:1342,y:767,t:1527635448039};\\\", \\\"{x:1341,y:767,t:1527635449028};\\\", \\\"{x:1341,y:766,t:1527635449052};\\\", \\\"{x:1341,y:765,t:1527635449068};\\\", \\\"{x:1341,y:764,t:1527635449132};\\\", \\\"{x:1341,y:763,t:1527635449189};\\\", \\\"{x:1341,y:762,t:1527635449213};\\\", \\\"{x:1341,y:761,t:1527635449244};\\\", \\\"{x:1341,y:758,t:1527635449257};\\\", \\\"{x:1341,y:754,t:1527635449274};\\\", \\\"{x:1341,y:746,t:1527635449291};\\\", \\\"{x:1344,y:733,t:1527635449308};\\\", \\\"{x:1345,y:723,t:1527635449324};\\\", \\\"{x:1346,y:715,t:1527635449340};\\\", \\\"{x:1348,y:712,t:1527635449358};\\\", \\\"{x:1348,y:711,t:1527635449373};\\\", \\\"{x:1348,y:710,t:1527635449452};\\\", \\\"{x:1348,y:709,t:1527635449748};\\\", \\\"{x:1348,y:708,t:1527635449765};\\\", \\\"{x:1348,y:706,t:1527635449780};\\\", \\\"{x:1348,y:705,t:1527635449791};\\\", \\\"{x:1349,y:703,t:1527635449807};\\\", \\\"{x:1349,y:701,t:1527635449824};\\\", \\\"{x:1349,y:700,t:1527635449840};\\\", \\\"{x:1349,y:699,t:1527635449858};\\\", \\\"{x:1349,y:698,t:1527635449875};\\\", \\\"{x:1349,y:702,t:1527635450373};\\\", \\\"{x:1349,y:708,t:1527635450381};\\\", \\\"{x:1351,y:715,t:1527635450392};\\\", \\\"{x:1352,y:724,t:1527635450407};\\\", \\\"{x:1353,y:730,t:1527635450425};\\\", \\\"{x:1354,y:735,t:1527635450442};\\\", \\\"{x:1354,y:737,t:1527635450458};\\\", \\\"{x:1354,y:738,t:1527635450474};\\\", \\\"{x:1354,y:740,t:1527635450492};\\\", \\\"{x:1354,y:741,t:1527635450508};\\\", \\\"{x:1354,y:743,t:1527635450524};\\\", \\\"{x:1354,y:744,t:1527635450548};\\\", \\\"{x:1354,y:746,t:1527635450564};\\\", \\\"{x:1354,y:747,t:1527635450574};\\\", \\\"{x:1354,y:749,t:1527635450591};\\\", \\\"{x:1354,y:752,t:1527635450609};\\\", \\\"{x:1354,y:756,t:1527635450624};\\\", \\\"{x:1354,y:759,t:1527635450642};\\\", \\\"{x:1354,y:762,t:1527635450658};\\\", \\\"{x:1354,y:764,t:1527635450674};\\\", \\\"{x:1354,y:765,t:1527635450691};\\\", \\\"{x:1354,y:767,t:1527635450709};\\\", \\\"{x:1353,y:768,t:1527635451268};\\\", \\\"{x:1353,y:767,t:1527635451285};\\\", \\\"{x:1353,y:766,t:1527635451293};\\\", \\\"{x:1352,y:763,t:1527635451309};\\\", \\\"{x:1352,y:761,t:1527635451325};\\\", \\\"{x:1352,y:759,t:1527635451341};\\\", \\\"{x:1352,y:757,t:1527635451359};\\\", \\\"{x:1352,y:754,t:1527635451375};\\\", \\\"{x:1352,y:752,t:1527635451392};\\\", \\\"{x:1352,y:749,t:1527635451409};\\\", \\\"{x:1352,y:746,t:1527635451426};\\\", \\\"{x:1352,y:741,t:1527635451442};\\\", \\\"{x:1352,y:738,t:1527635451459};\\\", \\\"{x:1352,y:734,t:1527635451475};\\\", \\\"{x:1352,y:730,t:1527635451492};\\\", \\\"{x:1352,y:727,t:1527635451509};\\\", \\\"{x:1352,y:722,t:1527635451526};\\\", \\\"{x:1352,y:720,t:1527635451542};\\\", \\\"{x:1352,y:719,t:1527635451559};\\\", \\\"{x:1352,y:716,t:1527635451576};\\\", \\\"{x:1352,y:715,t:1527635451593};\\\", \\\"{x:1352,y:714,t:1527635451609};\\\", \\\"{x:1352,y:717,t:1527635451709};\\\", \\\"{x:1353,y:731,t:1527635451726};\\\", \\\"{x:1355,y:742,t:1527635451742};\\\", \\\"{x:1357,y:756,t:1527635451759};\\\", \\\"{x:1359,y:769,t:1527635451775};\\\", \\\"{x:1359,y:780,t:1527635451792};\\\", \\\"{x:1359,y:787,t:1527635451809};\\\", \\\"{x:1359,y:790,t:1527635451826};\\\", \\\"{x:1359,y:792,t:1527635451843};\\\", \\\"{x:1359,y:793,t:1527635451860};\\\", \\\"{x:1359,y:794,t:1527635452117};\\\", \\\"{x:1358,y:794,t:1527635452132};\\\", \\\"{x:1357,y:792,t:1527635452165};\\\", \\\"{x:1356,y:791,t:1527635452175};\\\", \\\"{x:1354,y:788,t:1527635452193};\\\", \\\"{x:1352,y:786,t:1527635452209};\\\", \\\"{x:1346,y:780,t:1527635452226};\\\", \\\"{x:1338,y:771,t:1527635452242};\\\", \\\"{x:1327,y:762,t:1527635452260};\\\", \\\"{x:1314,y:750,t:1527635452275};\\\", \\\"{x:1297,y:737,t:1527635452292};\\\", \\\"{x:1286,y:728,t:1527635452310};\\\", \\\"{x:1273,y:722,t:1527635452326};\\\", \\\"{x:1260,y:715,t:1527635452342};\\\", \\\"{x:1247,y:708,t:1527635452360};\\\", \\\"{x:1229,y:702,t:1527635452376};\\\", \\\"{x:1212,y:697,t:1527635452393};\\\", \\\"{x:1192,y:687,t:1527635452409};\\\", \\\"{x:1174,y:679,t:1527635452427};\\\", \\\"{x:1151,y:671,t:1527635452442};\\\", \\\"{x:1121,y:662,t:1527635452459};\\\", \\\"{x:1063,y:647,t:1527635452476};\\\", \\\"{x:1026,y:636,t:1527635452492};\\\", \\\"{x:984,y:623,t:1527635452510};\\\", \\\"{x:956,y:616,t:1527635452527};\\\", \\\"{x:937,y:611,t:1527635452543};\\\", \\\"{x:925,y:607,t:1527635452560};\\\", \\\"{x:921,y:606,t:1527635452577};\\\", \\\"{x:920,y:606,t:1527635452592};\\\", \\\"{x:919,y:606,t:1527635452637};\\\", \\\"{x:917,y:605,t:1527635452644};\\\", \\\"{x:915,y:605,t:1527635452660};\\\", \\\"{x:909,y:605,t:1527635452676};\\\", \\\"{x:896,y:605,t:1527635452693};\\\", \\\"{x:878,y:605,t:1527635452709};\\\", \\\"{x:858,y:605,t:1527635452727};\\\", \\\"{x:832,y:605,t:1527635452743};\\\", \\\"{x:808,y:605,t:1527635452760};\\\", \\\"{x:783,y:605,t:1527635452776};\\\", \\\"{x:763,y:605,t:1527635452793};\\\", \\\"{x:740,y:605,t:1527635452809};\\\", \\\"{x:719,y:605,t:1527635452827};\\\", \\\"{x:708,y:605,t:1527635452844};\\\", \\\"{x:699,y:606,t:1527635452860};\\\", \\\"{x:680,y:608,t:1527635452876};\\\", \\\"{x:667,y:610,t:1527635452893};\\\", \\\"{x:655,y:612,t:1527635452909};\\\", \\\"{x:644,y:613,t:1527635452927};\\\", \\\"{x:636,y:616,t:1527635452944};\\\", \\\"{x:629,y:618,t:1527635452960};\\\", \\\"{x:623,y:620,t:1527635452976};\\\", \\\"{x:619,y:621,t:1527635452993};\\\", \\\"{x:613,y:622,t:1527635453011};\\\", \\\"{x:611,y:623,t:1527635453026};\\\", \\\"{x:608,y:624,t:1527635453044};\\\", \\\"{x:601,y:627,t:1527635453060};\\\", \\\"{x:597,y:628,t:1527635453077};\\\", \\\"{x:591,y:631,t:1527635453094};\\\", \\\"{x:587,y:632,t:1527635453111};\\\", \\\"{x:586,y:633,t:1527635453126};\\\", \\\"{x:583,y:634,t:1527635453143};\\\", \\\"{x:582,y:634,t:1527635453161};\\\", \\\"{x:580,y:635,t:1527635453176};\\\", \\\"{x:580,y:636,t:1527635453196};\\\", \\\"{x:579,y:636,t:1527635453236};\\\", \\\"{x:579,y:637,t:1527635453317};\\\", \\\"{x:579,y:638,t:1527635453327};\\\", \\\"{x:579,y:640,t:1527635453344};\\\", \\\"{x:579,y:642,t:1527635453360};\\\", \\\"{x:579,y:643,t:1527635453376};\\\", \\\"{x:579,y:644,t:1527635453397};\\\", \\\"{x:580,y:644,t:1527635453411};\\\", \\\"{x:580,y:645,t:1527635453436};\\\", \\\"{x:580,y:646,t:1527635453452};\\\", \\\"{x:580,y:647,t:1527635453469};\\\", \\\"{x:580,y:648,t:1527635453484};\\\", \\\"{x:580,y:649,t:1527635453494};\\\", \\\"{x:580,y:651,t:1527635453511};\\\", \\\"{x:580,y:652,t:1527635453526};\\\", \\\"{x:580,y:653,t:1527635453543};\\\", \\\"{x:580,y:655,t:1527635453560};\\\", \\\"{x:580,y:656,t:1527635453577};\\\", \\\"{x:581,y:658,t:1527635453593};\\\", \\\"{x:581,y:659,t:1527635453610};\\\", \\\"{x:581,y:660,t:1527635453628};\\\", \\\"{x:583,y:663,t:1527635453644};\\\", \\\"{x:583,y:665,t:1527635453668};\\\", \\\"{x:584,y:666,t:1527635453700};\\\", \\\"{x:584,y:668,t:1527635453732};\\\", \\\"{x:583,y:668,t:1527635453909};\\\", \\\"{x:582,y:668,t:1527635453924};\\\", \\\"{x:578,y:665,t:1527635453932};\\\", \\\"{x:577,y:664,t:1527635453944};\\\", \\\"{x:569,y:656,t:1527635453961};\\\", \\\"{x:561,y:648,t:1527635453978};\\\", \\\"{x:552,y:639,t:1527635453994};\\\", \\\"{x:545,y:631,t:1527635454011};\\\", \\\"{x:538,y:622,t:1527635454027};\\\", \\\"{x:535,y:618,t:1527635454044};\\\", \\\"{x:531,y:609,t:1527635454061};\\\", \\\"{x:530,y:602,t:1527635454077};\\\", \\\"{x:530,y:597,t:1527635454095};\\\", \\\"{x:530,y:594,t:1527635454111};\\\", \\\"{x:530,y:591,t:1527635454128};\\\", \\\"{x:529,y:590,t:1527635454172};\\\", \\\"{x:528,y:589,t:1527635454180};\\\", \\\"{x:527,y:588,t:1527635454196};\\\", \\\"{x:522,y:587,t:1527635454211};\\\", \\\"{x:508,y:582,t:1527635454228};\\\", \\\"{x:480,y:579,t:1527635454245};\\\", \\\"{x:457,y:576,t:1527635454261};\\\", \\\"{x:428,y:576,t:1527635454277};\\\", \\\"{x:399,y:574,t:1527635454295};\\\", \\\"{x:372,y:574,t:1527635454311};\\\", \\\"{x:352,y:574,t:1527635454328};\\\", \\\"{x:337,y:574,t:1527635454344};\\\", \\\"{x:332,y:574,t:1527635454362};\\\", \\\"{x:331,y:574,t:1527635454378};\\\", \\\"{x:329,y:576,t:1527635454395};\\\", \\\"{x:329,y:581,t:1527635454412};\\\", \\\"{x:329,y:584,t:1527635454428};\\\", \\\"{x:329,y:588,t:1527635454444};\\\", \\\"{x:329,y:590,t:1527635454462};\\\", \\\"{x:332,y:591,t:1527635454478};\\\", \\\"{x:343,y:591,t:1527635454495};\\\", \\\"{x:359,y:591,t:1527635454511};\\\", \\\"{x:370,y:588,t:1527635454528};\\\", \\\"{x:378,y:583,t:1527635454545};\\\", \\\"{x:386,y:575,t:1527635454562};\\\", \\\"{x:389,y:571,t:1527635454577};\\\", \\\"{x:389,y:565,t:1527635454596};\\\", \\\"{x:389,y:561,t:1527635454612};\\\", \\\"{x:387,y:557,t:1527635454628};\\\", \\\"{x:375,y:555,t:1527635454645};\\\", \\\"{x:354,y:555,t:1527635454662};\\\", \\\"{x:332,y:555,t:1527635454678};\\\", \\\"{x:308,y:555,t:1527635454694};\\\", \\\"{x:283,y:555,t:1527635454712};\\\", \\\"{x:266,y:555,t:1527635454728};\\\", \\\"{x:255,y:555,t:1527635454744};\\\", \\\"{x:251,y:555,t:1527635454762};\\\", \\\"{x:250,y:553,t:1527635454778};\\\", \\\"{x:249,y:553,t:1527635454852};\\\", \\\"{x:247,y:553,t:1527635454862};\\\", \\\"{x:242,y:553,t:1527635454879};\\\", \\\"{x:234,y:551,t:1527635454896};\\\", \\\"{x:220,y:547,t:1527635454912};\\\", \\\"{x:204,y:542,t:1527635454929};\\\", \\\"{x:190,y:538,t:1527635454946};\\\", \\\"{x:178,y:534,t:1527635454962};\\\", \\\"{x:173,y:533,t:1527635454978};\\\", \\\"{x:171,y:532,t:1527635454995};\\\", \\\"{x:175,y:532,t:1527635455308};\\\", \\\"{x:184,y:535,t:1527635455316};\\\", \\\"{x:194,y:539,t:1527635455329};\\\", \\\"{x:225,y:548,t:1527635455345};\\\", \\\"{x:279,y:570,t:1527635455361};\\\", \\\"{x:350,y:595,t:1527635455379};\\\", \\\"{x:437,y:626,t:1527635455396};\\\", \\\"{x:522,y:659,t:1527635455412};\\\", \\\"{x:639,y:710,t:1527635455428};\\\", \\\"{x:690,y:736,t:1527635455445};\\\", \\\"{x:720,y:755,t:1527635455462};\\\", \\\"{x:739,y:768,t:1527635455479};\\\", \\\"{x:753,y:779,t:1527635455496};\\\", \\\"{x:761,y:784,t:1527635455512};\\\", \\\"{x:763,y:786,t:1527635455528};\\\", \\\"{x:758,y:786,t:1527635455612};\\\", \\\"{x:740,y:783,t:1527635455628};\\\", \\\"{x:713,y:775,t:1527635455646};\\\", \\\"{x:681,y:766,t:1527635455663};\\\", \\\"{x:638,y:758,t:1527635455678};\\\", \\\"{x:604,y:749,t:1527635455696};\\\", \\\"{x:582,y:742,t:1527635455713};\\\", \\\"{x:569,y:738,t:1527635455730};\\\", \\\"{x:565,y:737,t:1527635455745};\\\", \\\"{x:564,y:736,t:1527635455763};\\\", \\\"{x:564,y:735,t:1527635455812};\\\", \\\"{x:563,y:733,t:1527635455829};\\\", \\\"{x:562,y:729,t:1527635455845};\\\", \\\"{x:561,y:727,t:1527635455863};\\\", \\\"{x:560,y:726,t:1527635455880};\\\", \\\"{x:560,y:725,t:1527635456063};\\\", \\\"{x:560,y:725,t:1527635456189};\\\", \\\"{x:560,y:724,t:1527635456244};\\\", \\\"{x:560,y:725,t:1527635456260};\\\", \\\"{x:559,y:727,t:1527635456276};\\\", \\\"{x:559,y:728,t:1527635456317};\\\", \\\"{x:559,y:729,t:1527635456348};\\\", \\\"{x:560,y:730,t:1527635456363};\\\", \\\"{x:561,y:731,t:1527635456380};\\\", \\\"{x:564,y:732,t:1527635456395};\\\", \\\"{x:568,y:733,t:1527635456412};\\\", \\\"{x:570,y:733,t:1527635456430};\\\", \\\"{x:571,y:734,t:1527635456445};\\\", \\\"{x:573,y:734,t:1527635456541};\\\", \\\"{x:574,y:734,t:1527635456548};\\\", \\\"{x:574,y:735,t:1527635456563};\\\", \\\"{x:577,y:735,t:1527635456580};\\\", \\\"{x:579,y:735,t:1527635456596};\\\", \\\"{x:580,y:735,t:1527635456620};\\\", \\\"{x:581,y:736,t:1527635456693};\\\", \\\"{x:581,y:737,t:1527635456708};\\\", \\\"{x:582,y:737,t:1527635456837};\\\", \\\"{x:583,y:737,t:1527635456852};\\\", \\\"{x:584,y:737,t:1527635456862};\\\", \\\"{x:585,y:737,t:1527635456880};\\\", \\\"{x:587,y:737,t:1527635456897};\\\", \\\"{x:591,y:738,t:1527635456913};\\\", \\\"{x:596,y:738,t:1527635456930};\\\", \\\"{x:602,y:739,t:1527635456947};\\\", \\\"{x:611,y:741,t:1527635456963};\\\", \\\"{x:621,y:742,t:1527635456980};\\\", \\\"{x:633,y:744,t:1527635456996};\\\", \\\"{x:641,y:746,t:1527635457013};\\\", \\\"{x:653,y:747,t:1527635457029};\\\", \\\"{x:665,y:752,t:1527635457046};\\\", \\\"{x:678,y:755,t:1527635457062};\\\", \\\"{x:690,y:757,t:1527635457079};\\\", \\\"{x:705,y:760,t:1527635457097};\\\", \\\"{x:720,y:762,t:1527635457113};\\\", \\\"{x:735,y:763,t:1527635457129};\\\", \\\"{x:750,y:766,t:1527635457147};\\\", \\\"{x:760,y:767,t:1527635457163};\\\", \\\"{x:770,y:768,t:1527635457180};\\\", \\\"{x:779,y:768,t:1527635457196};\\\", \\\"{x:783,y:768,t:1527635457213};\\\", \\\"{x:791,y:766,t:1527635457229};\\\", \\\"{x:796,y:765,t:1527635457247};\\\", \\\"{x:802,y:765,t:1527635457263};\\\" ] }, { \\\"rt\\\": 9865, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 486534, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"93XU7\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-B -F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:896,y:781,t:1527635457420};\\\", \\\"{x:907,y:781,t:1527635457430};\\\", \\\"{x:914,y:781,t:1527635457447};\\\", \\\"{x:919,y:781,t:1527635457464};\\\", \\\"{x:922,y:781,t:1527635457481};\\\", \\\"{x:932,y:781,t:1527635457511};\\\", \\\"{x:934,y:781,t:1527635457516};\\\", \\\"{x:937,y:781,t:1527635457531};\\\", \\\"{x:944,y:781,t:1527635457547};\\\", \\\"{x:953,y:781,t:1527635457564};\\\", \\\"{x:965,y:781,t:1527635457580};\\\", \\\"{x:975,y:781,t:1527635457596};\\\", \\\"{x:983,y:781,t:1527635457615};\\\", \\\"{x:989,y:781,t:1527635457631};\\\", \\\"{x:993,y:780,t:1527635457647};\\\", \\\"{x:996,y:780,t:1527635457664};\\\", \\\"{x:998,y:778,t:1527635457681};\\\", \\\"{x:1001,y:776,t:1527635457696};\\\", \\\"{x:1004,y:772,t:1527635457714};\\\", \\\"{x:1005,y:768,t:1527635457731};\\\", \\\"{x:1006,y:763,t:1527635457747};\\\", \\\"{x:1008,y:754,t:1527635457764};\\\", \\\"{x:997,y:666,t:1527635457825};\\\", \\\"{x:988,y:654,t:1527635457833};\\\", \\\"{x:966,y:635,t:1527635457847};\\\", \\\"{x:943,y:621,t:1527635457865};\\\", \\\"{x:919,y:606,t:1527635457880};\\\", \\\"{x:897,y:595,t:1527635457898};\\\", \\\"{x:877,y:587,t:1527635457915};\\\", \\\"{x:867,y:583,t:1527635457931};\\\", \\\"{x:861,y:581,t:1527635457948};\\\", \\\"{x:857,y:580,t:1527635457964};\\\", \\\"{x:856,y:580,t:1527635457981};\\\", \\\"{x:855,y:580,t:1527635458045};\\\", \\\"{x:853,y:580,t:1527635458052};\\\", \\\"{x:850,y:581,t:1527635458064};\\\", \\\"{x:842,y:583,t:1527635458081};\\\", \\\"{x:830,y:585,t:1527635458098};\\\", \\\"{x:820,y:586,t:1527635458114};\\\", \\\"{x:813,y:586,t:1527635458131};\\\", \\\"{x:810,y:586,t:1527635458148};\\\", \\\"{x:809,y:586,t:1527635458165};\\\", \\\"{x:808,y:586,t:1527635458236};\\\", \\\"{x:807,y:586,t:1527635458276};\\\", \\\"{x:812,y:586,t:1527635458788};\\\", \\\"{x:825,y:586,t:1527635458800};\\\", \\\"{x:861,y:588,t:1527635458816};\\\", \\\"{x:936,y:599,t:1527635458833};\\\", \\\"{x:1024,y:618,t:1527635458848};\\\", \\\"{x:1113,y:645,t:1527635458865};\\\", \\\"{x:1212,y:673,t:1527635458882};\\\", \\\"{x:1296,y:699,t:1527635458898};\\\", \\\"{x:1362,y:717,t:1527635458915};\\\", \\\"{x:1401,y:734,t:1527635458932};\\\", \\\"{x:1418,y:745,t:1527635458948};\\\", \\\"{x:1422,y:751,t:1527635458965};\\\", \\\"{x:1422,y:758,t:1527635458982};\\\", \\\"{x:1421,y:770,t:1527635458998};\\\", \\\"{x:1419,y:784,t:1527635459015};\\\", \\\"{x:1419,y:802,t:1527635459032};\\\", \\\"{x:1422,y:823,t:1527635459048};\\\", \\\"{x:1432,y:840,t:1527635459064};\\\", \\\"{x:1443,y:859,t:1527635459081};\\\", \\\"{x:1459,y:876,t:1527635459098};\\\", \\\"{x:1475,y:895,t:1527635459115};\\\", \\\"{x:1493,y:914,t:1527635459132};\\\", \\\"{x:1504,y:926,t:1527635459148};\\\", \\\"{x:1517,y:943,t:1527635459165};\\\", \\\"{x:1519,y:950,t:1527635459182};\\\", \\\"{x:1520,y:953,t:1527635459198};\\\", \\\"{x:1520,y:957,t:1527635459215};\\\", \\\"{x:1520,y:958,t:1527635459232};\\\", \\\"{x:1520,y:960,t:1527635459248};\\\", \\\"{x:1517,y:963,t:1527635459265};\\\", \\\"{x:1509,y:966,t:1527635459282};\\\", \\\"{x:1498,y:967,t:1527635459298};\\\", \\\"{x:1481,y:969,t:1527635459315};\\\", \\\"{x:1458,y:969,t:1527635459333};\\\", \\\"{x:1419,y:967,t:1527635459348};\\\", \\\"{x:1398,y:963,t:1527635459366};\\\", \\\"{x:1383,y:962,t:1527635459383};\\\", \\\"{x:1378,y:962,t:1527635459399};\\\", \\\"{x:1377,y:962,t:1527635459415};\\\", \\\"{x:1376,y:962,t:1527635459452};\\\", \\\"{x:1376,y:964,t:1527635459468};\\\", \\\"{x:1375,y:966,t:1527635459482};\\\", \\\"{x:1375,y:969,t:1527635459499};\\\", \\\"{x:1375,y:973,t:1527635459515};\\\", \\\"{x:1375,y:974,t:1527635459532};\\\", \\\"{x:1376,y:979,t:1527635459548};\\\", \\\"{x:1380,y:985,t:1527635459565};\\\", \\\"{x:1384,y:988,t:1527635459582};\\\", \\\"{x:1387,y:990,t:1527635459599};\\\", \\\"{x:1387,y:992,t:1527635459615};\\\", \\\"{x:1388,y:992,t:1527635459632};\\\", \\\"{x:1388,y:991,t:1527635459717};\\\", \\\"{x:1388,y:989,t:1527635459732};\\\", \\\"{x:1382,y:978,t:1527635459748};\\\", \\\"{x:1374,y:970,t:1527635459766};\\\", \\\"{x:1362,y:962,t:1527635459783};\\\", \\\"{x:1356,y:960,t:1527635459800};\\\", \\\"{x:1354,y:959,t:1527635459817};\\\", \\\"{x:1353,y:959,t:1527635459964};\\\", \\\"{x:1352,y:959,t:1527635459973};\\\", \\\"{x:1351,y:959,t:1527635459982};\\\", \\\"{x:1349,y:960,t:1527635459999};\\\", \\\"{x:1347,y:961,t:1527635460016};\\\", \\\"{x:1346,y:962,t:1527635460032};\\\", \\\"{x:1344,y:962,t:1527635460049};\\\", \\\"{x:1344,y:963,t:1527635460092};\\\", \\\"{x:1343,y:962,t:1527635460754};\\\", \\\"{x:1342,y:960,t:1527635460763};\\\", \\\"{x:1341,y:957,t:1527635460780};\\\", \\\"{x:1340,y:956,t:1527635460798};\\\", \\\"{x:1339,y:953,t:1527635460814};\\\", \\\"{x:1338,y:950,t:1527635460831};\\\", \\\"{x:1337,y:948,t:1527635460847};\\\", \\\"{x:1337,y:947,t:1527635460864};\\\", \\\"{x:1336,y:944,t:1527635460881};\\\", \\\"{x:1336,y:941,t:1527635460897};\\\", \\\"{x:1336,y:939,t:1527635460914};\\\", \\\"{x:1335,y:936,t:1527635460931};\\\", \\\"{x:1335,y:934,t:1527635460948};\\\", \\\"{x:1335,y:933,t:1527635460964};\\\", \\\"{x:1335,y:931,t:1527635460980};\\\", \\\"{x:1335,y:928,t:1527635460998};\\\", \\\"{x:1335,y:925,t:1527635461014};\\\", \\\"{x:1335,y:921,t:1527635461031};\\\", \\\"{x:1335,y:919,t:1527635461048};\\\", \\\"{x:1335,y:917,t:1527635461064};\\\", \\\"{x:1335,y:913,t:1527635461081};\\\", \\\"{x:1336,y:909,t:1527635461098};\\\", \\\"{x:1336,y:907,t:1527635461114};\\\", \\\"{x:1337,y:905,t:1527635461131};\\\", \\\"{x:1337,y:904,t:1527635461148};\\\", \\\"{x:1337,y:903,t:1527635461164};\\\", \\\"{x:1338,y:900,t:1527635461181};\\\", \\\"{x:1338,y:899,t:1527635461202};\\\", \\\"{x:1338,y:898,t:1527635461214};\\\", \\\"{x:1338,y:895,t:1527635461231};\\\", \\\"{x:1338,y:894,t:1527635461248};\\\", \\\"{x:1338,y:891,t:1527635461265};\\\", \\\"{x:1338,y:888,t:1527635461280};\\\", \\\"{x:1338,y:881,t:1527635461298};\\\", \\\"{x:1339,y:877,t:1527635461314};\\\", \\\"{x:1339,y:872,t:1527635461331};\\\", \\\"{x:1339,y:867,t:1527635461347};\\\", \\\"{x:1339,y:863,t:1527635461365};\\\", \\\"{x:1341,y:856,t:1527635461381};\\\", \\\"{x:1342,y:851,t:1527635461398};\\\", \\\"{x:1342,y:846,t:1527635461415};\\\", \\\"{x:1343,y:840,t:1527635461430};\\\", \\\"{x:1345,y:835,t:1527635461448};\\\", \\\"{x:1345,y:831,t:1527635461465};\\\", \\\"{x:1346,y:827,t:1527635461480};\\\", \\\"{x:1347,y:820,t:1527635461498};\\\", \\\"{x:1349,y:816,t:1527635461515};\\\", \\\"{x:1349,y:813,t:1527635461530};\\\", \\\"{x:1349,y:810,t:1527635461548};\\\", \\\"{x:1349,y:808,t:1527635461565};\\\", \\\"{x:1349,y:806,t:1527635461581};\\\", \\\"{x:1349,y:802,t:1527635461597};\\\", \\\"{x:1349,y:799,t:1527635461615};\\\", \\\"{x:1349,y:795,t:1527635461631};\\\", \\\"{x:1348,y:792,t:1527635461648};\\\", \\\"{x:1348,y:788,t:1527635461665};\\\", \\\"{x:1345,y:782,t:1527635461682};\\\", \\\"{x:1345,y:780,t:1527635461706};\\\", \\\"{x:1345,y:778,t:1527635461715};\\\", \\\"{x:1345,y:776,t:1527635461731};\\\", \\\"{x:1344,y:772,t:1527635461748};\\\", \\\"{x:1344,y:769,t:1527635461765};\\\", \\\"{x:1342,y:768,t:1527635461782};\\\", \\\"{x:1342,y:764,t:1527635461799};\\\", \\\"{x:1342,y:762,t:1527635461815};\\\", \\\"{x:1342,y:759,t:1527635461832};\\\", \\\"{x:1342,y:756,t:1527635461848};\\\", \\\"{x:1342,y:754,t:1527635461865};\\\", \\\"{x:1342,y:751,t:1527635461882};\\\", \\\"{x:1342,y:748,t:1527635461898};\\\", \\\"{x:1342,y:745,t:1527635461915};\\\", \\\"{x:1342,y:741,t:1527635461932};\\\", \\\"{x:1341,y:738,t:1527635461948};\\\", \\\"{x:1340,y:733,t:1527635461965};\\\", \\\"{x:1340,y:730,t:1527635461982};\\\", \\\"{x:1340,y:727,t:1527635461998};\\\", \\\"{x:1340,y:724,t:1527635462015};\\\", \\\"{x:1340,y:721,t:1527635462032};\\\", \\\"{x:1340,y:717,t:1527635462048};\\\", \\\"{x:1340,y:713,t:1527635462064};\\\", \\\"{x:1340,y:709,t:1527635462082};\\\", \\\"{x:1340,y:707,t:1527635462097};\\\", \\\"{x:1340,y:704,t:1527635462115};\\\", \\\"{x:1340,y:703,t:1527635462132};\\\", \\\"{x:1340,y:702,t:1527635462148};\\\", \\\"{x:1339,y:700,t:1527635462165};\\\", \\\"{x:1339,y:699,t:1527635462182};\\\", \\\"{x:1339,y:698,t:1527635462199};\\\", \\\"{x:1339,y:697,t:1527635462218};\\\", \\\"{x:1339,y:696,t:1527635462232};\\\", \\\"{x:1339,y:695,t:1527635462249};\\\", \\\"{x:1339,y:692,t:1527635462265};\\\", \\\"{x:1339,y:691,t:1527635462282};\\\", \\\"{x:1339,y:701,t:1527635462372};\\\", \\\"{x:1343,y:714,t:1527635462383};\\\", \\\"{x:1354,y:752,t:1527635462399};\\\", \\\"{x:1360,y:775,t:1527635462415};\\\", \\\"{x:1367,y:791,t:1527635462431};\\\", \\\"{x:1368,y:794,t:1527635462449};\\\", \\\"{x:1368,y:795,t:1527635462465};\\\", \\\"{x:1368,y:796,t:1527635462539};\\\", \\\"{x:1369,y:797,t:1527635462555};\\\", \\\"{x:1370,y:798,t:1527635462565};\\\", \\\"{x:1376,y:802,t:1527635462582};\\\", \\\"{x:1376,y:803,t:1527635462599};\\\", \\\"{x:1376,y:802,t:1527635463051};\\\", \\\"{x:1370,y:796,t:1527635463067};\\\", \\\"{x:1361,y:785,t:1527635463083};\\\", \\\"{x:1360,y:779,t:1527635463100};\\\", \\\"{x:1358,y:772,t:1527635463116};\\\", \\\"{x:1357,y:766,t:1527635463133};\\\", \\\"{x:1357,y:760,t:1527635463149};\\\", \\\"{x:1357,y:754,t:1527635463166};\\\", \\\"{x:1357,y:751,t:1527635463183};\\\", \\\"{x:1356,y:746,t:1527635463200};\\\", \\\"{x:1354,y:742,t:1527635463216};\\\", \\\"{x:1352,y:740,t:1527635463233};\\\", \\\"{x:1352,y:739,t:1527635463250};\\\", \\\"{x:1351,y:737,t:1527635463266};\\\", \\\"{x:1351,y:733,t:1527635463451};\\\", \\\"{x:1350,y:726,t:1527635463467};\\\", \\\"{x:1350,y:717,t:1527635463483};\\\", \\\"{x:1349,y:711,t:1527635463499};\\\", \\\"{x:1349,y:707,t:1527635463516};\\\", \\\"{x:1349,y:703,t:1527635463533};\\\", \\\"{x:1346,y:699,t:1527635463549};\\\", \\\"{x:1346,y:696,t:1527635463566};\\\", \\\"{x:1346,y:695,t:1527635463583};\\\", \\\"{x:1345,y:694,t:1527635463599};\\\", \\\"{x:1345,y:693,t:1527635463616};\\\", \\\"{x:1344,y:691,t:1527635463633};\\\", \\\"{x:1340,y:687,t:1527635463650};\\\", \\\"{x:1333,y:681,t:1527635463666};\\\", \\\"{x:1318,y:677,t:1527635463683};\\\", \\\"{x:1292,y:672,t:1527635463700};\\\", \\\"{x:1236,y:664,t:1527635463716};\\\", \\\"{x:1143,y:649,t:1527635463733};\\\", \\\"{x:1010,y:630,t:1527635463750};\\\", \\\"{x:867,y:613,t:1527635463767};\\\", \\\"{x:723,y:592,t:1527635463784};\\\", \\\"{x:606,y:573,t:1527635463800};\\\", \\\"{x:521,y:564,t:1527635463817};\\\", \\\"{x:470,y:564,t:1527635463835};\\\", \\\"{x:442,y:564,t:1527635463850};\\\", \\\"{x:438,y:564,t:1527635463867};\\\", \\\"{x:437,y:565,t:1527635463883};\\\", \\\"{x:436,y:564,t:1527635464019};\\\", \\\"{x:436,y:558,t:1527635464034};\\\", \\\"{x:423,y:529,t:1527635464051};\\\", \\\"{x:409,y:515,t:1527635464068};\\\", \\\"{x:390,y:504,t:1527635464084};\\\", \\\"{x:374,y:500,t:1527635464100};\\\", \\\"{x:368,y:500,t:1527635464117};\\\", \\\"{x:364,y:500,t:1527635464134};\\\", \\\"{x:360,y:500,t:1527635464149};\\\", \\\"{x:356,y:510,t:1527635464166};\\\", \\\"{x:355,y:525,t:1527635464184};\\\", \\\"{x:353,y:542,t:1527635464199};\\\", \\\"{x:353,y:555,t:1527635464217};\\\", \\\"{x:353,y:564,t:1527635464235};\\\", \\\"{x:353,y:566,t:1527635464250};\\\", \\\"{x:353,y:568,t:1527635464267};\\\", \\\"{x:351,y:568,t:1527635464306};\\\", \\\"{x:348,y:568,t:1527635464317};\\\", \\\"{x:335,y:568,t:1527635464334};\\\", \\\"{x:313,y:568,t:1527635464350};\\\", \\\"{x:293,y:565,t:1527635464367};\\\", \\\"{x:275,y:564,t:1527635464384};\\\", \\\"{x:257,y:560,t:1527635464402};\\\", \\\"{x:248,y:559,t:1527635464416};\\\", \\\"{x:242,y:559,t:1527635464434};\\\", \\\"{x:241,y:559,t:1527635464451};\\\", \\\"{x:240,y:559,t:1527635464467};\\\", \\\"{x:239,y:559,t:1527635464484};\\\", \\\"{x:236,y:559,t:1527635464501};\\\", \\\"{x:232,y:559,t:1527635464517};\\\", \\\"{x:224,y:556,t:1527635464534};\\\", \\\"{x:214,y:552,t:1527635464553};\\\", \\\"{x:206,y:550,t:1527635464567};\\\", \\\"{x:199,y:545,t:1527635464584};\\\", \\\"{x:196,y:542,t:1527635464601};\\\", \\\"{x:195,y:542,t:1527635464617};\\\", \\\"{x:195,y:541,t:1527635464634};\\\", \\\"{x:195,y:540,t:1527635464883};\\\", \\\"{x:200,y:540,t:1527635464891};\\\", \\\"{x:209,y:542,t:1527635464902};\\\", \\\"{x:240,y:549,t:1527635464918};\\\", \\\"{x:304,y:556,t:1527635464936};\\\", \\\"{x:378,y:565,t:1527635464951};\\\", \\\"{x:475,y:574,t:1527635464968};\\\", \\\"{x:574,y:586,t:1527635464985};\\\", \\\"{x:667,y:590,t:1527635465000};\\\", \\\"{x:767,y:590,t:1527635465018};\\\", \\\"{x:800,y:590,t:1527635465034};\\\", \\\"{x:812,y:590,t:1527635465051};\\\", \\\"{x:814,y:590,t:1527635465068};\\\", \\\"{x:815,y:590,t:1527635465083};\\\", \\\"{x:814,y:583,t:1527635465100};\\\", \\\"{x:809,y:575,t:1527635465118};\\\", \\\"{x:806,y:569,t:1527635465134};\\\", \\\"{x:804,y:565,t:1527635465151};\\\", \\\"{x:803,y:562,t:1527635465169};\\\", \\\"{x:801,y:558,t:1527635465184};\\\", \\\"{x:799,y:555,t:1527635465202};\\\", \\\"{x:794,y:548,t:1527635465218};\\\", \\\"{x:789,y:544,t:1527635465234};\\\", \\\"{x:788,y:542,t:1527635465251};\\\", \\\"{x:788,y:541,t:1527635465315};\\\", \\\"{x:788,y:540,t:1527635465322};\\\", \\\"{x:791,y:539,t:1527635465335};\\\", \\\"{x:802,y:536,t:1527635465351};\\\", \\\"{x:819,y:531,t:1527635465369};\\\", \\\"{x:836,y:525,t:1527635465385};\\\", \\\"{x:847,y:523,t:1527635465401};\\\", \\\"{x:858,y:520,t:1527635465418};\\\", \\\"{x:861,y:519,t:1527635465434};\\\", \\\"{x:861,y:518,t:1527635465555};\\\", \\\"{x:862,y:517,t:1527635465572};\\\", \\\"{x:863,y:517,t:1527635465584};\\\", \\\"{x:863,y:515,t:1527635465601};\\\", \\\"{x:863,y:513,t:1527635465619};\\\", \\\"{x:863,y:510,t:1527635465635};\\\", \\\"{x:863,y:506,t:1527635465651};\\\", \\\"{x:863,y:503,t:1527635465668};\\\", \\\"{x:863,y:502,t:1527635465685};\\\", \\\"{x:863,y:501,t:1527635465702};\\\", \\\"{x:862,y:500,t:1527635465870};\\\", \\\"{x:861,y:500,t:1527635465902};\\\", \\\"{x:854,y:504,t:1527635465917};\\\", \\\"{x:840,y:510,t:1527635465936};\\\", \\\"{x:806,y:516,t:1527635465953};\\\", \\\"{x:732,y:525,t:1527635465969};\\\", \\\"{x:636,y:533,t:1527635465986};\\\", \\\"{x:472,y:533,t:1527635466002};\\\", \\\"{x:367,y:533,t:1527635466018};\\\", \\\"{x:263,y:537,t:1527635466036};\\\", \\\"{x:191,y:538,t:1527635466052};\\\", \\\"{x:143,y:546,t:1527635466069};\\\", \\\"{x:116,y:550,t:1527635466085};\\\", \\\"{x:104,y:554,t:1527635466102};\\\", \\\"{x:102,y:554,t:1527635466118};\\\", \\\"{x:100,y:554,t:1527635466135};\\\", \\\"{x:97,y:554,t:1527635466152};\\\", \\\"{x:96,y:554,t:1527635466170};\\\", \\\"{x:95,y:554,t:1527635466202};\\\", \\\"{x:94,y:554,t:1527635466219};\\\", \\\"{x:94,y:550,t:1527635466235};\\\", \\\"{x:94,y:547,t:1527635466253};\\\", \\\"{x:94,y:544,t:1527635466269};\\\", \\\"{x:94,y:543,t:1527635466285};\\\", \\\"{x:94,y:542,t:1527635466302};\\\", \\\"{x:94,y:541,t:1527635466319};\\\", \\\"{x:94,y:539,t:1527635466335};\\\", \\\"{x:102,y:537,t:1527635466352};\\\", \\\"{x:110,y:536,t:1527635466370};\\\", \\\"{x:120,y:536,t:1527635466385};\\\", \\\"{x:139,y:536,t:1527635466402};\\\", \\\"{x:151,y:537,t:1527635466419};\\\", \\\"{x:157,y:537,t:1527635466435};\\\", \\\"{x:159,y:538,t:1527635466452};\\\", \\\"{x:160,y:538,t:1527635466569};\\\", \\\"{x:162,y:538,t:1527635466586};\\\", \\\"{x:163,y:538,t:1527635466670};\\\", \\\"{x:172,y:541,t:1527635466686};\\\", \\\"{x:191,y:547,t:1527635466702};\\\", \\\"{x:216,y:555,t:1527635466719};\\\", \\\"{x:241,y:566,t:1527635466736};\\\", \\\"{x:271,y:579,t:1527635466752};\\\", \\\"{x:300,y:595,t:1527635466769};\\\", \\\"{x:339,y:623,t:1527635466786};\\\", \\\"{x:356,y:639,t:1527635466803};\\\", \\\"{x:371,y:656,t:1527635466818};\\\", \\\"{x:388,y:670,t:1527635466837};\\\", \\\"{x:403,y:683,t:1527635466852};\\\", \\\"{x:411,y:691,t:1527635466869};\\\", \\\"{x:414,y:693,t:1527635466886};\\\", \\\"{x:414,y:696,t:1527635466902};\\\", \\\"{x:414,y:699,t:1527635466919};\\\", \\\"{x:414,y:706,t:1527635466936};\\\", \\\"{x:418,y:716,t:1527635466952};\\\", \\\"{x:423,y:724,t:1527635466969};\\\", \\\"{x:434,y:736,t:1527635466986};\\\", \\\"{x:444,y:743,t:1527635467003};\\\", \\\"{x:451,y:746,t:1527635467019};\\\", \\\"{x:456,y:748,t:1527635467037};\\\", \\\"{x:458,y:749,t:1527635467053};\\\", \\\"{x:458,y:748,t:1527635467410};\\\", \\\"{x:458,y:747,t:1527635467419};\\\", \\\"{x:458,y:744,t:1527635467436};\\\", \\\"{x:458,y:743,t:1527635467453};\\\", \\\"{x:458,y:742,t:1527635467474};\\\", \\\"{x:460,y:740,t:1527635468018};\\\", \\\"{x:463,y:738,t:1527635468035};\\\", \\\"{x:465,y:738,t:1527635468043};\\\", \\\"{x:466,y:737,t:1527635468054};\\\", \\\"{x:467,y:735,t:1527635468070};\\\", \\\"{x:467,y:731,t:1527635468087};\\\", \\\"{x:469,y:723,t:1527635468104};\\\", \\\"{x:470,y:712,t:1527635468120};\\\", \\\"{x:477,y:695,t:1527635468138};\\\", \\\"{x:481,y:675,t:1527635468153};\\\", \\\"{x:493,y:635,t:1527635468171};\\\", \\\"{x:498,y:613,t:1527635468187};\\\", \\\"{x:504,y:596,t:1527635468203};\\\", \\\"{x:508,y:583,t:1527635468221};\\\", \\\"{x:510,y:574,t:1527635468237};\\\", \\\"{x:513,y:568,t:1527635468253};\\\", \\\"{x:515,y:564,t:1527635468270};\\\", \\\"{x:516,y:561,t:1527635468288};\\\", \\\"{x:517,y:559,t:1527635468310};\\\", \\\"{x:517,y:558,t:1527635468320};\\\", \\\"{x:518,y:557,t:1527635468337};\\\", \\\"{x:519,y:556,t:1527635468353};\\\", \\\"{x:520,y:555,t:1527635468370};\\\", \\\"{x:521,y:554,t:1527635468402};\\\" ] }, { \\\"rt\\\": 10204, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 497956, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"93XU7\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -B -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:520,y:552,t:1527635468859};\\\", \\\"{x:518,y:551,t:1527635468871};\\\", \\\"{x:511,y:549,t:1527635468888};\\\", \\\"{x:496,y:546,t:1527635468985};\\\", \\\"{x:495,y:545,t:1527635469074};\\\", \\\"{x:495,y:543,t:1527635469090};\\\", \\\"{x:497,y:542,t:1527635469104};\\\", \\\"{x:511,y:542,t:1527635469122};\\\", \\\"{x:523,y:542,t:1527635469138};\\\", \\\"{x:525,y:542,t:1527635469153};\\\", \\\"{x:525,y:540,t:1527635469835};\\\", \\\"{x:524,y:536,t:1527635469842};\\\", \\\"{x:520,y:532,t:1527635469855};\\\", \\\"{x:515,y:526,t:1527635469872};\\\", \\\"{x:511,y:522,t:1527635469890};\\\", \\\"{x:505,y:515,t:1527635469904};\\\", \\\"{x:499,y:511,t:1527635469921};\\\", \\\"{x:489,y:504,t:1527635469938};\\\", \\\"{x:482,y:500,t:1527635469955};\\\", \\\"{x:474,y:496,t:1527635469970};\\\", \\\"{x:466,y:493,t:1527635469988};\\\", \\\"{x:458,y:489,t:1527635470005};\\\", \\\"{x:450,y:487,t:1527635470021};\\\", \\\"{x:443,y:483,t:1527635470039};\\\", \\\"{x:439,y:481,t:1527635470054};\\\", \\\"{x:434,y:479,t:1527635470072};\\\", \\\"{x:430,y:476,t:1527635470088};\\\", \\\"{x:428,y:474,t:1527635470105};\\\", \\\"{x:424,y:470,t:1527635470122};\\\", \\\"{x:424,y:469,t:1527635470139};\\\", \\\"{x:423,y:467,t:1527635470155};\\\", \\\"{x:423,y:466,t:1527635470172};\\\", \\\"{x:421,y:463,t:1527635470189};\\\", \\\"{x:421,y:462,t:1527635470218};\\\", \\\"{x:421,y:461,t:1527635470242};\\\", \\\"{x:421,y:460,t:1527635470256};\\\", \\\"{x:422,y:460,t:1527635470273};\\\", \\\"{x:423,y:460,t:1527635470289};\\\", \\\"{x:432,y:460,t:1527635470307};\\\", \\\"{x:446,y:461,t:1527635470323};\\\", \\\"{x:464,y:466,t:1527635470340};\\\", \\\"{x:485,y:472,t:1527635470356};\\\", \\\"{x:508,y:479,t:1527635470372};\\\", \\\"{x:519,y:481,t:1527635470390};\\\", \\\"{x:526,y:483,t:1527635470406};\\\", \\\"{x:526,y:481,t:1527635470579};\\\", \\\"{x:525,y:480,t:1527635470590};\\\", \\\"{x:524,y:478,t:1527635470607};\\\", \\\"{x:522,y:475,t:1527635470624};\\\", \\\"{x:521,y:474,t:1527635470641};\\\", \\\"{x:521,y:473,t:1527635470699};\\\", \\\"{x:521,y:472,t:1527635470714};\\\", \\\"{x:522,y:471,t:1527635470771};\\\", \\\"{x:524,y:470,t:1527635470779};\\\", \\\"{x:528,y:470,t:1527635470791};\\\", \\\"{x:538,y:470,t:1527635470808};\\\", \\\"{x:553,y:470,t:1527635470824};\\\", \\\"{x:571,y:470,t:1527635470840};\\\", \\\"{x:590,y:470,t:1527635470858};\\\", \\\"{x:607,y:470,t:1527635470874};\\\", \\\"{x:633,y:470,t:1527635470891};\\\", \\\"{x:649,y:470,t:1527635470908};\\\", \\\"{x:669,y:472,t:1527635470924};\\\", \\\"{x:687,y:475,t:1527635470940};\\\", \\\"{x:709,y:482,t:1527635470957};\\\", \\\"{x:747,y:493,t:1527635470974};\\\", \\\"{x:797,y:507,t:1527635470991};\\\", \\\"{x:861,y:528,t:1527635471006};\\\", \\\"{x:944,y:564,t:1527635471022};\\\", \\\"{x:1033,y:606,t:1527635471040};\\\", \\\"{x:1145,y:669,t:1527635471056};\\\", \\\"{x:1269,y:743,t:1527635471073};\\\", \\\"{x:1387,y:820,t:1527635471089};\\\", \\\"{x:1541,y:929,t:1527635471106};\\\", \\\"{x:1612,y:987,t:1527635471123};\\\", \\\"{x:1659,y:1029,t:1527635471139};\\\", \\\"{x:1683,y:1057,t:1527635471157};\\\", \\\"{x:1693,y:1072,t:1527635471172};\\\", \\\"{x:1693,y:1075,t:1527635471190};\\\", \\\"{x:1693,y:1077,t:1527635471207};\\\", \\\"{x:1692,y:1077,t:1527635471224};\\\", \\\"{x:1688,y:1077,t:1527635471239};\\\", \\\"{x:1682,y:1077,t:1527635471256};\\\", \\\"{x:1675,y:1076,t:1527635471274};\\\", \\\"{x:1659,y:1072,t:1527635471290};\\\", \\\"{x:1624,y:1059,t:1527635471307};\\\", \\\"{x:1584,y:1041,t:1527635471323};\\\", \\\"{x:1536,y:1025,t:1527635471340};\\\", \\\"{x:1503,y:1012,t:1527635471357};\\\", \\\"{x:1473,y:999,t:1527635471373};\\\", \\\"{x:1454,y:988,t:1527635471389};\\\", \\\"{x:1442,y:978,t:1527635471406};\\\", \\\"{x:1437,y:968,t:1527635471423};\\\", \\\"{x:1433,y:957,t:1527635471439};\\\", \\\"{x:1429,y:946,t:1527635471456};\\\", \\\"{x:1424,y:938,t:1527635471473};\\\", \\\"{x:1417,y:927,t:1527635471490};\\\", \\\"{x:1414,y:925,t:1527635471506};\\\", \\\"{x:1410,y:922,t:1527635471523};\\\", \\\"{x:1407,y:920,t:1527635471540};\\\", \\\"{x:1399,y:917,t:1527635471557};\\\", \\\"{x:1392,y:913,t:1527635471574};\\\", \\\"{x:1381,y:904,t:1527635471590};\\\", \\\"{x:1370,y:897,t:1527635471607};\\\", \\\"{x:1365,y:890,t:1527635471624};\\\", \\\"{x:1359,y:880,t:1527635471641};\\\", \\\"{x:1355,y:871,t:1527635471657};\\\", \\\"{x:1355,y:862,t:1527635471674};\\\", \\\"{x:1355,y:844,t:1527635471691};\\\", \\\"{x:1355,y:823,t:1527635471708};\\\", \\\"{x:1355,y:805,t:1527635471724};\\\", \\\"{x:1355,y:786,t:1527635471741};\\\", \\\"{x:1356,y:769,t:1527635471758};\\\", \\\"{x:1358,y:756,t:1527635471774};\\\", \\\"{x:1363,y:747,t:1527635471791};\\\", \\\"{x:1367,y:740,t:1527635471807};\\\", \\\"{x:1368,y:736,t:1527635471824};\\\", \\\"{x:1368,y:735,t:1527635471843};\\\", \\\"{x:1368,y:733,t:1527635472003};\\\", \\\"{x:1368,y:731,t:1527635472011};\\\", \\\"{x:1368,y:730,t:1527635472025};\\\", \\\"{x:1366,y:724,t:1527635472040};\\\", \\\"{x:1364,y:722,t:1527635472058};\\\", \\\"{x:1360,y:714,t:1527635472075};\\\", \\\"{x:1357,y:708,t:1527635472091};\\\", \\\"{x:1357,y:707,t:1527635472108};\\\", \\\"{x:1354,y:704,t:1527635472125};\\\", \\\"{x:1354,y:703,t:1527635472141};\\\", \\\"{x:1353,y:702,t:1527635472158};\\\", \\\"{x:1352,y:701,t:1527635472179};\\\", \\\"{x:1351,y:701,t:1527635472277};\\\", \\\"{x:1351,y:700,t:1527635472307};\\\", \\\"{x:1350,y:700,t:1527635472563};\\\", \\\"{x:1350,y:703,t:1527635472577};\\\", \\\"{x:1350,y:712,t:1527635472592};\\\", \\\"{x:1350,y:721,t:1527635472609};\\\", \\\"{x:1350,y:733,t:1527635472625};\\\", \\\"{x:1350,y:746,t:1527635472642};\\\", \\\"{x:1350,y:760,t:1527635472659};\\\", \\\"{x:1349,y:767,t:1527635472674};\\\", \\\"{x:1349,y:770,t:1527635472693};\\\", \\\"{x:1349,y:775,t:1527635472709};\\\", \\\"{x:1349,y:778,t:1527635472725};\\\", \\\"{x:1349,y:781,t:1527635472742};\\\", \\\"{x:1349,y:782,t:1527635472763};\\\", \\\"{x:1349,y:780,t:1527635472907};\\\", \\\"{x:1349,y:776,t:1527635472915};\\\", \\\"{x:1348,y:775,t:1527635472926};\\\", \\\"{x:1347,y:771,t:1527635472942};\\\", \\\"{x:1346,y:768,t:1527635472959};\\\", \\\"{x:1346,y:766,t:1527635472975};\\\", \\\"{x:1346,y:765,t:1527635472991};\\\", \\\"{x:1345,y:764,t:1527635473731};\\\", \\\"{x:1340,y:765,t:1527635473744};\\\", \\\"{x:1326,y:769,t:1527635473761};\\\", \\\"{x:1310,y:771,t:1527635473777};\\\", \\\"{x:1283,y:771,t:1527635473794};\\\", \\\"{x:1217,y:765,t:1527635473811};\\\", \\\"{x:1155,y:755,t:1527635473827};\\\", \\\"{x:1070,y:734,t:1527635473844};\\\", \\\"{x:997,y:711,t:1527635473860};\\\", \\\"{x:925,y:689,t:1527635473877};\\\", \\\"{x:854,y:662,t:1527635473894};\\\", \\\"{x:803,y:637,t:1527635473910};\\\", \\\"{x:768,y:616,t:1527635473929};\\\", \\\"{x:745,y:598,t:1527635473944};\\\", \\\"{x:733,y:583,t:1527635473958};\\\", \\\"{x:727,y:567,t:1527635473975};\\\", \\\"{x:724,y:555,t:1527635473992};\\\", \\\"{x:722,y:546,t:1527635474009};\\\", \\\"{x:718,y:535,t:1527635474025};\\\", \\\"{x:715,y:528,t:1527635474041};\\\", \\\"{x:712,y:523,t:1527635474058};\\\", \\\"{x:711,y:522,t:1527635474074};\\\", \\\"{x:712,y:520,t:1527635474179};\\\", \\\"{x:714,y:520,t:1527635474192};\\\", \\\"{x:718,y:520,t:1527635474208};\\\", \\\"{x:726,y:520,t:1527635474226};\\\", \\\"{x:737,y:520,t:1527635474242};\\\", \\\"{x:756,y:520,t:1527635474258};\\\", \\\"{x:769,y:520,t:1527635474276};\\\", \\\"{x:777,y:520,t:1527635474292};\\\", \\\"{x:782,y:520,t:1527635474308};\\\", \\\"{x:783,y:520,t:1527635474326};\\\", \\\"{x:784,y:520,t:1527635474341};\\\", \\\"{x:785,y:521,t:1527635474358};\\\", \\\"{x:786,y:521,t:1527635474378};\\\", \\\"{x:787,y:521,t:1527635474391};\\\", \\\"{x:785,y:521,t:1527635474474};\\\", \\\"{x:781,y:521,t:1527635474482};\\\", \\\"{x:774,y:521,t:1527635474491};\\\", \\\"{x:757,y:521,t:1527635474508};\\\", \\\"{x:733,y:521,t:1527635474525};\\\", \\\"{x:710,y:521,t:1527635474541};\\\", \\\"{x:689,y:521,t:1527635474558};\\\", \\\"{x:672,y:521,t:1527635474576};\\\", \\\"{x:660,y:521,t:1527635474591};\\\", \\\"{x:655,y:521,t:1527635474609};\\\", \\\"{x:653,y:521,t:1527635474625};\\\", \\\"{x:652,y:521,t:1527635474642};\\\", \\\"{x:651,y:521,t:1527635474658};\\\", \\\"{x:648,y:521,t:1527635474676};\\\", \\\"{x:642,y:521,t:1527635474692};\\\", \\\"{x:631,y:523,t:1527635474708};\\\", \\\"{x:614,y:523,t:1527635474725};\\\", \\\"{x:592,y:523,t:1527635474742};\\\", \\\"{x:572,y:523,t:1527635474758};\\\", \\\"{x:550,y:523,t:1527635474775};\\\", \\\"{x:527,y:523,t:1527635474792};\\\", \\\"{x:505,y:523,t:1527635474808};\\\", \\\"{x:482,y:523,t:1527635474825};\\\", \\\"{x:458,y:523,t:1527635474842};\\\", \\\"{x:444,y:523,t:1527635474858};\\\", \\\"{x:434,y:523,t:1527635474877};\\\", \\\"{x:426,y:523,t:1527635474893};\\\", \\\"{x:417,y:523,t:1527635474909};\\\", \\\"{x:406,y:523,t:1527635474925};\\\", \\\"{x:395,y:523,t:1527635474943};\\\", \\\"{x:385,y:523,t:1527635474959};\\\", \\\"{x:374,y:523,t:1527635474976};\\\", \\\"{x:364,y:524,t:1527635474992};\\\", \\\"{x:357,y:526,t:1527635475009};\\\", \\\"{x:347,y:529,t:1527635475025};\\\", \\\"{x:341,y:532,t:1527635475041};\\\", \\\"{x:339,y:532,t:1527635475060};\\\", \\\"{x:339,y:533,t:1527635475076};\\\", \\\"{x:338,y:534,t:1527635475092};\\\", \\\"{x:338,y:537,t:1527635475109};\\\", \\\"{x:338,y:539,t:1527635475126};\\\", \\\"{x:338,y:543,t:1527635475142};\\\", \\\"{x:338,y:545,t:1527635475160};\\\", \\\"{x:335,y:548,t:1527635475176};\\\", \\\"{x:332,y:550,t:1527635475192};\\\", \\\"{x:325,y:550,t:1527635475210};\\\", \\\"{x:299,y:550,t:1527635475227};\\\", \\\"{x:270,y:550,t:1527635475243};\\\", \\\"{x:230,y:546,t:1527635475260};\\\", \\\"{x:191,y:541,t:1527635475276};\\\", \\\"{x:155,y:537,t:1527635475293};\\\", \\\"{x:121,y:532,t:1527635475310};\\\", \\\"{x:97,y:528,t:1527635475326};\\\", \\\"{x:80,y:525,t:1527635475342};\\\", \\\"{x:73,y:523,t:1527635475360};\\\", \\\"{x:72,y:523,t:1527635475377};\\\", \\\"{x:71,y:523,t:1527635475392};\\\", \\\"{x:74,y:523,t:1527635475499};\\\", \\\"{x:77,y:524,t:1527635475510};\\\", \\\"{x:88,y:527,t:1527635475527};\\\", \\\"{x:103,y:531,t:1527635475542};\\\", \\\"{x:117,y:535,t:1527635475560};\\\", \\\"{x:126,y:537,t:1527635475577};\\\", \\\"{x:131,y:538,t:1527635475592};\\\", \\\"{x:132,y:538,t:1527635475609};\\\", \\\"{x:133,y:538,t:1527635475626};\\\", \\\"{x:134,y:538,t:1527635475667};\\\", \\\"{x:136,y:538,t:1527635475682};\\\", \\\"{x:138,y:538,t:1527635475715};\\\", \\\"{x:139,y:537,t:1527635475843};\\\", \\\"{x:140,y:536,t:1527635475883};\\\", \\\"{x:141,y:536,t:1527635476027};\\\", \\\"{x:142,y:536,t:1527635476419};\\\", \\\"{x:145,y:536,t:1527635476434};\\\", \\\"{x:149,y:538,t:1527635476445};\\\", \\\"{x:155,y:541,t:1527635476461};\\\", \\\"{x:167,y:548,t:1527635476477};\\\", \\\"{x:183,y:553,t:1527635476494};\\\", \\\"{x:205,y:560,t:1527635476511};\\\", \\\"{x:233,y:568,t:1527635476528};\\\", \\\"{x:265,y:574,t:1527635476543};\\\", \\\"{x:297,y:584,t:1527635476561};\\\", \\\"{x:321,y:595,t:1527635476578};\\\", \\\"{x:339,y:602,t:1527635476593};\\\", \\\"{x:359,y:610,t:1527635476610};\\\", \\\"{x:368,y:616,t:1527635476627};\\\", \\\"{x:375,y:622,t:1527635476643};\\\", \\\"{x:380,y:628,t:1527635476660};\\\", \\\"{x:385,y:635,t:1527635476678};\\\", \\\"{x:389,y:643,t:1527635476694};\\\", \\\"{x:396,y:657,t:1527635476710};\\\", \\\"{x:401,y:669,t:1527635476728};\\\", \\\"{x:404,y:676,t:1527635476744};\\\", \\\"{x:405,y:683,t:1527635476760};\\\", \\\"{x:406,y:689,t:1527635476777};\\\", \\\"{x:406,y:696,t:1527635476793};\\\", \\\"{x:406,y:703,t:1527635476810};\\\", \\\"{x:407,y:707,t:1527635476827};\\\", \\\"{x:410,y:713,t:1527635476843};\\\", \\\"{x:415,y:719,t:1527635476860};\\\", \\\"{x:422,y:725,t:1527635476877};\\\", \\\"{x:430,y:731,t:1527635476894};\\\", \\\"{x:440,y:735,t:1527635476911};\\\", \\\"{x:443,y:735,t:1527635476927};\\\", \\\"{x:444,y:734,t:1527635476944};\\\", \\\"{x:444,y:725,t:1527635476961};\\\", \\\"{x:436,y:708,t:1527635476977};\\\", \\\"{x:397,y:667,t:1527635476994};\\\", \\\"{x:345,y:626,t:1527635477011};\\\", \\\"{x:290,y:591,t:1527635477028};\\\", \\\"{x:228,y:561,t:1527635477044};\\\", \\\"{x:189,y:544,t:1527635477062};\\\", \\\"{x:167,y:535,t:1527635477077};\\\", \\\"{x:158,y:530,t:1527635477094};\\\", \\\"{x:157,y:529,t:1527635477130};\\\", \\\"{x:156,y:529,t:1527635477258};\\\", \\\"{x:156,y:531,t:1527635477275};\\\", \\\"{x:156,y:533,t:1527635477290};\\\", \\\"{x:157,y:534,t:1527635477299};\\\", \\\"{x:157,y:535,t:1527635477312};\\\", \\\"{x:158,y:535,t:1527635477618};\\\", \\\"{x:159,y:536,t:1527635477627};\\\", \\\"{x:165,y:540,t:1527635477644};\\\", \\\"{x:177,y:546,t:1527635477662};\\\", \\\"{x:200,y:558,t:1527635477678};\\\", \\\"{x:234,y:575,t:1527635477695};\\\", \\\"{x:284,y:597,t:1527635477712};\\\", \\\"{x:336,y:618,t:1527635477728};\\\", \\\"{x:399,y:645,t:1527635477745};\\\", \\\"{x:490,y:689,t:1527635477762};\\\", \\\"{x:520,y:706,t:1527635477778};\\\", \\\"{x:577,y:748,t:1527635477795};\\\", \\\"{x:595,y:762,t:1527635477812};\\\", \\\"{x:604,y:770,t:1527635477827};\\\", \\\"{x:609,y:778,t:1527635477845};\\\", \\\"{x:610,y:780,t:1527635477862};\\\", \\\"{x:611,y:784,t:1527635477878};\\\", \\\"{x:611,y:785,t:1527635477895};\\\", \\\"{x:612,y:787,t:1527635477911};\\\", \\\"{x:612,y:789,t:1527635477928};\\\", \\\"{x:612,y:791,t:1527635477944};\\\", \\\"{x:612,y:792,t:1527635477962};\\\", \\\"{x:607,y:794,t:1527635477978};\\\", \\\"{x:596,y:794,t:1527635477994};\\\", \\\"{x:581,y:794,t:1527635478012};\\\", \\\"{x:563,y:793,t:1527635478029};\\\", \\\"{x:543,y:787,t:1527635478045};\\\", \\\"{x:526,y:782,t:1527635478062};\\\", \\\"{x:513,y:777,t:1527635478078};\\\", \\\"{x:509,y:775,t:1527635478095};\\\", \\\"{x:508,y:774,t:1527635478111};\\\", \\\"{x:507,y:773,t:1527635478139};\\\", \\\"{x:507,y:772,t:1527635478145};\\\", \\\"{x:507,y:771,t:1527635478194};\\\", \\\"{x:508,y:770,t:1527635478219};\\\", \\\"{x:509,y:770,t:1527635478307};\\\", \\\"{x:511,y:770,t:1527635478411};\\\", \\\"{x:511,y:767,t:1527635478429};\\\", \\\"{x:511,y:762,t:1527635478446};\\\", \\\"{x:511,y:755,t:1527635478461};\\\", \\\"{x:511,y:747,t:1527635478480};\\\", \\\"{x:511,y:739,t:1527635478495};\\\", \\\"{x:511,y:735,t:1527635478512};\\\", \\\"{x:511,y:734,t:1527635478527};\\\", \\\"{x:518,y:731,t:1527635478866};\\\", \\\"{x:528,y:728,t:1527635478879};\\\", \\\"{x:536,y:725,t:1527635478895};\\\", \\\"{x:538,y:725,t:1527635478912};\\\", \\\"{x:539,y:724,t:1527635479611};\\\", \\\"{x:540,y:722,t:1527635479618};\\\", \\\"{x:541,y:720,t:1527635479630};\\\", \\\"{x:542,y:715,t:1527635479647};\\\", \\\"{x:545,y:708,t:1527635479664};\\\", \\\"{x:547,y:699,t:1527635479680};\\\", \\\"{x:551,y:689,t:1527635479697};\\\", \\\"{x:557,y:669,t:1527635479714};\\\", \\\"{x:559,y:661,t:1527635479730};\\\", \\\"{x:561,y:651,t:1527635479746};\\\", \\\"{x:564,y:641,t:1527635479763};\\\", \\\"{x:565,y:632,t:1527635479779};\\\", \\\"{x:566,y:628,t:1527635479796};\\\", \\\"{x:567,y:623,t:1527635479813};\\\" ] }, { \\\"rt\\\": 26233, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 525465, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"93XU7\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"P\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-02 PM-M -Z -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:569,y:612,t:1527635479979};\\\", \\\"{x:524,y:555,t:1527635480386};\\\", \\\"{x:516,y:546,t:1527635480397};\\\", \\\"{x:503,y:536,t:1527635480413};\\\", \\\"{x:496,y:528,t:1527635480430};\\\", \\\"{x:488,y:518,t:1527635480447};\\\", \\\"{x:481,y:511,t:1527635480464};\\\", \\\"{x:480,y:507,t:1527635480479};\\\", \\\"{x:479,y:504,t:1527635480504};\\\", \\\"{x:479,y:502,t:1527635480513};\\\", \\\"{x:478,y:501,t:1527635480530};\\\", \\\"{x:478,y:499,t:1527635480547};\\\", \\\"{x:478,y:497,t:1527635480564};\\\", \\\"{x:478,y:495,t:1527635480581};\\\", \\\"{x:478,y:494,t:1527635480597};\\\", \\\"{x:478,y:492,t:1527635480613};\\\", \\\"{x:478,y:491,t:1527635480631};\\\", \\\"{x:478,y:489,t:1527635480647};\\\", \\\"{x:478,y:486,t:1527635480664};\\\", \\\"{x:478,y:485,t:1527635480680};\\\", \\\"{x:478,y:482,t:1527635480696};\\\", \\\"{x:478,y:480,t:1527635480713};\\\", \\\"{x:478,y:477,t:1527635480730};\\\", \\\"{x:478,y:476,t:1527635480762};\\\", \\\"{x:478,y:474,t:1527635480786};\\\", \\\"{x:478,y:472,t:1527635480797};\\\", \\\"{x:474,y:468,t:1527635480813};\\\", \\\"{x:472,y:466,t:1527635480830};\\\", \\\"{x:471,y:466,t:1527635480846};\\\", \\\"{x:470,y:466,t:1527635480890};\\\", \\\"{x:467,y:466,t:1527635480899};\\\", \\\"{x:466,y:467,t:1527635480913};\\\", \\\"{x:466,y:480,t:1527635480930};\\\", \\\"{x:469,y:480,t:1527635481515};\\\", \\\"{x:472,y:480,t:1527635481528};\\\", \\\"{x:492,y:482,t:1527635481546};\\\", \\\"{x:530,y:487,t:1527635481564};\\\", \\\"{x:564,y:493,t:1527635481578};\\\", \\\"{x:599,y:500,t:1527635481598};\\\", \\\"{x:635,y:511,t:1527635481615};\\\", \\\"{x:673,y:523,t:1527635481633};\\\", \\\"{x:702,y:533,t:1527635481649};\\\", \\\"{x:738,y:546,t:1527635481665};\\\", \\\"{x:764,y:554,t:1527635481681};\\\", \\\"{x:795,y:562,t:1527635481698};\\\", \\\"{x:806,y:564,t:1527635481715};\\\", \\\"{x:808,y:565,t:1527635481731};\\\", \\\"{x:806,y:565,t:1527635481810};\\\", \\\"{x:805,y:565,t:1527635481818};\\\", \\\"{x:799,y:565,t:1527635481831};\\\", \\\"{x:788,y:563,t:1527635481847};\\\", \\\"{x:766,y:560,t:1527635481865};\\\", \\\"{x:742,y:555,t:1527635481881};\\\", \\\"{x:693,y:542,t:1527635481899};\\\", \\\"{x:659,y:535,t:1527635481915};\\\", \\\"{x:622,y:528,t:1527635481932};\\\", \\\"{x:595,y:519,t:1527635481948};\\\", \\\"{x:579,y:515,t:1527635481965};\\\", \\\"{x:566,y:511,t:1527635481982};\\\", \\\"{x:557,y:509,t:1527635481997};\\\", \\\"{x:551,y:506,t:1527635482014};\\\", \\\"{x:545,y:504,t:1527635482031};\\\", \\\"{x:542,y:503,t:1527635482047};\\\", \\\"{x:539,y:502,t:1527635482064};\\\", \\\"{x:536,y:502,t:1527635482081};\\\", \\\"{x:537,y:498,t:1527635482314};\\\", \\\"{x:537,y:489,t:1527635482332};\\\", \\\"{x:537,y:481,t:1527635482350};\\\", \\\"{x:537,y:472,t:1527635482366};\\\", \\\"{x:537,y:466,t:1527635482381};\\\", \\\"{x:535,y:460,t:1527635482398};\\\", \\\"{x:532,y:456,t:1527635482415};\\\", \\\"{x:531,y:453,t:1527635482431};\\\", \\\"{x:529,y:452,t:1527635482448};\\\", \\\"{x:529,y:451,t:1527635482474};\\\", \\\"{x:529,y:452,t:1527635482587};\\\", \\\"{x:529,y:454,t:1527635482600};\\\", \\\"{x:530,y:456,t:1527635482616};\\\", \\\"{x:530,y:458,t:1527635482632};\\\", \\\"{x:531,y:461,t:1527635482649};\\\", \\\"{x:533,y:464,t:1527635482665};\\\", \\\"{x:537,y:468,t:1527635482682};\\\", \\\"{x:540,y:471,t:1527635482699};\\\", \\\"{x:543,y:474,t:1527635482716};\\\", \\\"{x:545,y:476,t:1527635482732};\\\", \\\"{x:550,y:477,t:1527635482749};\\\", \\\"{x:556,y:480,t:1527635482766};\\\", \\\"{x:571,y:483,t:1527635482782};\\\", \\\"{x:592,y:489,t:1527635482799};\\\", \\\"{x:619,y:497,t:1527635482816};\\\", \\\"{x:672,y:512,t:1527635482832};\\\", \\\"{x:730,y:530,t:1527635482849};\\\", \\\"{x:844,y:563,t:1527635482866};\\\", \\\"{x:931,y:594,t:1527635482882};\\\", \\\"{x:1031,y:637,t:1527635482898};\\\", \\\"{x:1136,y:684,t:1527635482915};\\\", \\\"{x:1244,y:741,t:1527635482931};\\\", \\\"{x:1354,y:804,t:1527635482949};\\\", \\\"{x:1446,y:854,t:1527635482966};\\\", \\\"{x:1519,y:903,t:1527635482982};\\\", \\\"{x:1581,y:949,t:1527635482998};\\\", \\\"{x:1611,y:974,t:1527635483015};\\\", \\\"{x:1628,y:993,t:1527635483033};\\\", \\\"{x:1637,y:1008,t:1527635483048};\\\", \\\"{x:1641,y:1025,t:1527635483065};\\\", \\\"{x:1644,y:1042,t:1527635483082};\\\", \\\"{x:1645,y:1048,t:1527635483099};\\\", \\\"{x:1645,y:1054,t:1527635483115};\\\", \\\"{x:1645,y:1057,t:1527635483132};\\\", \\\"{x:1645,y:1059,t:1527635483149};\\\", \\\"{x:1645,y:1060,t:1527635483165};\\\", \\\"{x:1644,y:1062,t:1527635483182};\\\", \\\"{x:1643,y:1063,t:1527635483199};\\\", \\\"{x:1641,y:1064,t:1527635483215};\\\", \\\"{x:1638,y:1064,t:1527635483232};\\\", \\\"{x:1634,y:1065,t:1527635483248};\\\", \\\"{x:1627,y:1065,t:1527635483265};\\\", \\\"{x:1613,y:1065,t:1527635483282};\\\", \\\"{x:1597,y:1056,t:1527635483299};\\\", \\\"{x:1580,y:1045,t:1527635483316};\\\", \\\"{x:1554,y:1027,t:1527635483332};\\\", \\\"{x:1525,y:1005,t:1527635483349};\\\", \\\"{x:1497,y:980,t:1527635483366};\\\", \\\"{x:1456,y:945,t:1527635483383};\\\", \\\"{x:1430,y:923,t:1527635483399};\\\", \\\"{x:1418,y:902,t:1527635483416};\\\", \\\"{x:1411,y:889,t:1527635483433};\\\", \\\"{x:1408,y:877,t:1527635483448};\\\", \\\"{x:1405,y:866,t:1527635483466};\\\", \\\"{x:1405,y:854,t:1527635483482};\\\", \\\"{x:1405,y:852,t:1527635483498};\\\", \\\"{x:1405,y:851,t:1527635483515};\\\", \\\"{x:1408,y:852,t:1527635483595};\\\", \\\"{x:1411,y:857,t:1527635483603};\\\", \\\"{x:1414,y:863,t:1527635483616};\\\", \\\"{x:1420,y:876,t:1527635483632};\\\", \\\"{x:1424,y:889,t:1527635483648};\\\", \\\"{x:1428,y:902,t:1527635483665};\\\", \\\"{x:1429,y:915,t:1527635483682};\\\", \\\"{x:1431,y:928,t:1527635483698};\\\", \\\"{x:1429,y:935,t:1527635483714};\\\", \\\"{x:1427,y:938,t:1527635483731};\\\", \\\"{x:1425,y:941,t:1527635483748};\\\", \\\"{x:1423,y:943,t:1527635483766};\\\", \\\"{x:1422,y:943,t:1527635483781};\\\", \\\"{x:1420,y:943,t:1527635483819};\\\", \\\"{x:1418,y:942,t:1527635483831};\\\", \\\"{x:1414,y:934,t:1527635483848};\\\", \\\"{x:1408,y:924,t:1527635483864};\\\", \\\"{x:1401,y:915,t:1527635483882};\\\", \\\"{x:1395,y:908,t:1527635483899};\\\", \\\"{x:1394,y:907,t:1527635483915};\\\", \\\"{x:1392,y:908,t:1527635483987};\\\", \\\"{x:1392,y:910,t:1527635483998};\\\", \\\"{x:1392,y:920,t:1527635484014};\\\", \\\"{x:1392,y:930,t:1527635484031};\\\", \\\"{x:1392,y:940,t:1527635484048};\\\", \\\"{x:1393,y:948,t:1527635484065};\\\", \\\"{x:1394,y:953,t:1527635484081};\\\", \\\"{x:1395,y:958,t:1527635484097};\\\", \\\"{x:1395,y:961,t:1527635484114};\\\", \\\"{x:1395,y:962,t:1527635484131};\\\", \\\"{x:1395,y:963,t:1527635484147};\\\", \\\"{x:1395,y:962,t:1527635484234};\\\", \\\"{x:1395,y:959,t:1527635484246};\\\", \\\"{x:1393,y:956,t:1527635484264};\\\", \\\"{x:1391,y:953,t:1527635484280};\\\", \\\"{x:1388,y:949,t:1527635484297};\\\", \\\"{x:1384,y:947,t:1527635484314};\\\", \\\"{x:1383,y:946,t:1527635484331};\\\", \\\"{x:1381,y:945,t:1527635484347};\\\", \\\"{x:1380,y:944,t:1527635484364};\\\", \\\"{x:1378,y:944,t:1527635484380};\\\", \\\"{x:1377,y:944,t:1527635484398};\\\", \\\"{x:1373,y:943,t:1527635484414};\\\", \\\"{x:1371,y:943,t:1527635484430};\\\", \\\"{x:1370,y:943,t:1527635484447};\\\", \\\"{x:1370,y:944,t:1527635484531};\\\", \\\"{x:1371,y:946,t:1527635484548};\\\", \\\"{x:1373,y:948,t:1527635484564};\\\", \\\"{x:1375,y:950,t:1527635484580};\\\", \\\"{x:1376,y:950,t:1527635484597};\\\", \\\"{x:1377,y:951,t:1527635484618};\\\", \\\"{x:1379,y:951,t:1527635484722};\\\", \\\"{x:1380,y:951,t:1527635484745};\\\", \\\"{x:1381,y:951,t:1527635484761};\\\", \\\"{x:1383,y:951,t:1527635484794};\\\", \\\"{x:1383,y:950,t:1527635484826};\\\", \\\"{x:1384,y:949,t:1527635484858};\\\", \\\"{x:1384,y:950,t:1527635485219};\\\", \\\"{x:1384,y:951,t:1527635485235};\\\", \\\"{x:1385,y:951,t:1527635485247};\\\", \\\"{x:1386,y:951,t:1527635485264};\\\", \\\"{x:1387,y:952,t:1527635485434};\\\", \\\"{x:1388,y:952,t:1527635485446};\\\", \\\"{x:1389,y:952,t:1527635485462};\\\", \\\"{x:1390,y:953,t:1527635485479};\\\", \\\"{x:1388,y:952,t:1527635486691};\\\", \\\"{x:1386,y:952,t:1527635486706};\\\", \\\"{x:1385,y:951,t:1527635486731};\\\", \\\"{x:1385,y:950,t:1527635487435};\\\", \\\"{x:1387,y:950,t:1527635487475};\\\", \\\"{x:1388,y:949,t:1527635487538};\\\", \\\"{x:1389,y:949,t:1527635487779};\\\", \\\"{x:1390,y:949,t:1527635487811};\\\", \\\"{x:1391,y:949,t:1527635487843};\\\", \\\"{x:1392,y:950,t:1527635487860};\\\", \\\"{x:1393,y:950,t:1527635487883};\\\", \\\"{x:1394,y:950,t:1527635487894};\\\", \\\"{x:1395,y:950,t:1527635488107};\\\", \\\"{x:1396,y:946,t:1527635488115};\\\", \\\"{x:1396,y:944,t:1527635488126};\\\", \\\"{x:1396,y:939,t:1527635488143};\\\", \\\"{x:1396,y:935,t:1527635488159};\\\", \\\"{x:1396,y:931,t:1527635488176};\\\", \\\"{x:1396,y:928,t:1527635488192};\\\", \\\"{x:1396,y:925,t:1527635488209};\\\", \\\"{x:1396,y:924,t:1527635488226};\\\", \\\"{x:1396,y:923,t:1527635488331};\\\", \\\"{x:1396,y:922,t:1527635488347};\\\", \\\"{x:1396,y:921,t:1527635488363};\\\", \\\"{x:1396,y:920,t:1527635488394};\\\", \\\"{x:1396,y:917,t:1527635488410};\\\", \\\"{x:1395,y:915,t:1527635488427};\\\", \\\"{x:1394,y:911,t:1527635488443};\\\", \\\"{x:1393,y:907,t:1527635488460};\\\", \\\"{x:1391,y:903,t:1527635488475};\\\", \\\"{x:1389,y:897,t:1527635488493};\\\", \\\"{x:1388,y:894,t:1527635488510};\\\", \\\"{x:1386,y:892,t:1527635488525};\\\", \\\"{x:1386,y:890,t:1527635488542};\\\", \\\"{x:1385,y:888,t:1527635488559};\\\", \\\"{x:1384,y:887,t:1527635488575};\\\", \\\"{x:1383,y:886,t:1527635488594};\\\", \\\"{x:1381,y:886,t:1527635488690};\\\", \\\"{x:1379,y:886,t:1527635488706};\\\", \\\"{x:1377,y:889,t:1527635488713};\\\", \\\"{x:1376,y:892,t:1527635488726};\\\", \\\"{x:1373,y:899,t:1527635488742};\\\", \\\"{x:1372,y:903,t:1527635488759};\\\", \\\"{x:1372,y:906,t:1527635488776};\\\", \\\"{x:1372,y:904,t:1527635488939};\\\", \\\"{x:1372,y:903,t:1527635488971};\\\", \\\"{x:1372,y:904,t:1527635489714};\\\", \\\"{x:1374,y:906,t:1527635489725};\\\", \\\"{x:1377,y:912,t:1527635489742};\\\", \\\"{x:1380,y:915,t:1527635489757};\\\", \\\"{x:1383,y:919,t:1527635489774};\\\", \\\"{x:1384,y:920,t:1527635489792};\\\", \\\"{x:1385,y:921,t:1527635489807};\\\", \\\"{x:1386,y:923,t:1527635489825};\\\", \\\"{x:1388,y:925,t:1527635489841};\\\", \\\"{x:1388,y:927,t:1527635489857};\\\", \\\"{x:1390,y:930,t:1527635489874};\\\", \\\"{x:1390,y:932,t:1527635489890};\\\", \\\"{x:1390,y:933,t:1527635489908};\\\", \\\"{x:1390,y:936,t:1527635489925};\\\", \\\"{x:1386,y:938,t:1527635489940};\\\", \\\"{x:1377,y:938,t:1527635489957};\\\", \\\"{x:1368,y:940,t:1527635489974};\\\", \\\"{x:1362,y:940,t:1527635489991};\\\", \\\"{x:1357,y:942,t:1527635490008};\\\", \\\"{x:1355,y:943,t:1527635490024};\\\", \\\"{x:1354,y:943,t:1527635490040};\\\", \\\"{x:1353,y:944,t:1527635490057};\\\", \\\"{x:1350,y:946,t:1527635490073};\\\", \\\"{x:1348,y:947,t:1527635490090};\\\", \\\"{x:1345,y:948,t:1527635490107};\\\", \\\"{x:1344,y:949,t:1527635490123};\\\", \\\"{x:1342,y:951,t:1527635490140};\\\", \\\"{x:1341,y:953,t:1527635490162};\\\", \\\"{x:1341,y:954,t:1527635490173};\\\", \\\"{x:1341,y:955,t:1527635490190};\\\", \\\"{x:1341,y:956,t:1527635490210};\\\", \\\"{x:1341,y:957,t:1527635490227};\\\", \\\"{x:1341,y:958,t:1527635490240};\\\", \\\"{x:1343,y:959,t:1527635490257};\\\", \\\"{x:1347,y:960,t:1527635490274};\\\", \\\"{x:1361,y:960,t:1527635490289};\\\", \\\"{x:1371,y:960,t:1527635490307};\\\", \\\"{x:1384,y:960,t:1527635490323};\\\", \\\"{x:1399,y:960,t:1527635490341};\\\", \\\"{x:1409,y:960,t:1527635490358};\\\", \\\"{x:1420,y:956,t:1527635490374};\\\", \\\"{x:1435,y:944,t:1527635490390};\\\", \\\"{x:1451,y:927,t:1527635490406};\\\", \\\"{x:1465,y:908,t:1527635490424};\\\", \\\"{x:1474,y:895,t:1527635490440};\\\", \\\"{x:1478,y:883,t:1527635490457};\\\", \\\"{x:1482,y:873,t:1527635490474};\\\", \\\"{x:1484,y:866,t:1527635490491};\\\", \\\"{x:1484,y:861,t:1527635490506};\\\", \\\"{x:1486,y:859,t:1527635490524};\\\", \\\"{x:1487,y:854,t:1527635490541};\\\", \\\"{x:1487,y:851,t:1527635490557};\\\", \\\"{x:1487,y:849,t:1527635490574};\\\", \\\"{x:1487,y:844,t:1527635490590};\\\", \\\"{x:1488,y:841,t:1527635490607};\\\", \\\"{x:1489,y:837,t:1527635490623};\\\", \\\"{x:1489,y:836,t:1527635490699};\\\", \\\"{x:1496,y:834,t:1527635491131};\\\", \\\"{x:1509,y:826,t:1527635491139};\\\", \\\"{x:1547,y:805,t:1527635491157};\\\", \\\"{x:1584,y:784,t:1527635491173};\\\", \\\"{x:1620,y:763,t:1527635491190};\\\", \\\"{x:1644,y:749,t:1527635491207};\\\", \\\"{x:1659,y:738,t:1527635491223};\\\", \\\"{x:1665,y:733,t:1527635491239};\\\", \\\"{x:1667,y:729,t:1527635491256};\\\", \\\"{x:1667,y:727,t:1527635491272};\\\", \\\"{x:1667,y:724,t:1527635491290};\\\", \\\"{x:1667,y:722,t:1527635491306};\\\", \\\"{x:1666,y:718,t:1527635491322};\\\", \\\"{x:1665,y:715,t:1527635491340};\\\", \\\"{x:1665,y:711,t:1527635491355};\\\", \\\"{x:1662,y:707,t:1527635491372};\\\", \\\"{x:1659,y:703,t:1527635491390};\\\", \\\"{x:1654,y:700,t:1527635491405};\\\", \\\"{x:1648,y:698,t:1527635491423};\\\", \\\"{x:1642,y:696,t:1527635491440};\\\", \\\"{x:1635,y:695,t:1527635491456};\\\", \\\"{x:1625,y:694,t:1527635491473};\\\", \\\"{x:1619,y:694,t:1527635491491};\\\", \\\"{x:1616,y:694,t:1527635491505};\\\", \\\"{x:1614,y:694,t:1527635491521};\\\", \\\"{x:1613,y:694,t:1527635491538};\\\", \\\"{x:1613,y:693,t:1527635491586};\\\", \\\"{x:1611,y:692,t:1527635494811};\\\", \\\"{x:1608,y:689,t:1527635494820};\\\", \\\"{x:1606,y:684,t:1527635494834};\\\", \\\"{x:1604,y:679,t:1527635494852};\\\", \\\"{x:1602,y:676,t:1527635494869};\\\", \\\"{x:1601,y:673,t:1527635494884};\\\", \\\"{x:1601,y:670,t:1527635494902};\\\", \\\"{x:1600,y:666,t:1527635494919};\\\", \\\"{x:1598,y:662,t:1527635494935};\\\", \\\"{x:1597,y:659,t:1527635494952};\\\", \\\"{x:1596,y:657,t:1527635494969};\\\", \\\"{x:1596,y:654,t:1527635494985};\\\", \\\"{x:1594,y:649,t:1527635495002};\\\", \\\"{x:1593,y:641,t:1527635495019};\\\", \\\"{x:1593,y:634,t:1527635495035};\\\", \\\"{x:1591,y:627,t:1527635495052};\\\", \\\"{x:1591,y:618,t:1527635495068};\\\", \\\"{x:1590,y:611,t:1527635495085};\\\", \\\"{x:1590,y:604,t:1527635495103};\\\", \\\"{x:1590,y:596,t:1527635495118};\\\", \\\"{x:1590,y:590,t:1527635495135};\\\", \\\"{x:1590,y:583,t:1527635495152};\\\", \\\"{x:1590,y:574,t:1527635495168};\\\", \\\"{x:1590,y:565,t:1527635495185};\\\", \\\"{x:1590,y:558,t:1527635495201};\\\", \\\"{x:1590,y:554,t:1527635495217};\\\", \\\"{x:1590,y:546,t:1527635495234};\\\", \\\"{x:1590,y:540,t:1527635495252};\\\", \\\"{x:1590,y:534,t:1527635495268};\\\", \\\"{x:1589,y:531,t:1527635495285};\\\", \\\"{x:1589,y:528,t:1527635495300};\\\", \\\"{x:1589,y:527,t:1527635495419};\\\", \\\"{x:1589,y:525,t:1527635495434};\\\", \\\"{x:1589,y:523,t:1527635495451};\\\", \\\"{x:1589,y:519,t:1527635495468};\\\", \\\"{x:1589,y:515,t:1527635495485};\\\", \\\"{x:1589,y:512,t:1527635495501};\\\", \\\"{x:1589,y:511,t:1527635495518};\\\", \\\"{x:1589,y:509,t:1527635495535};\\\", \\\"{x:1589,y:508,t:1527635495554};\\\", \\\"{x:1589,y:506,t:1527635495578};\\\", \\\"{x:1589,y:505,t:1527635495611};\\\", \\\"{x:1589,y:503,t:1527635495634};\\\", \\\"{x:1589,y:502,t:1527635495683};\\\", \\\"{x:1589,y:506,t:1527635496251};\\\", \\\"{x:1589,y:521,t:1527635496266};\\\", \\\"{x:1591,y:536,t:1527635496284};\\\", \\\"{x:1593,y:547,t:1527635496299};\\\", \\\"{x:1594,y:555,t:1527635496317};\\\", \\\"{x:1596,y:565,t:1527635496334};\\\", \\\"{x:1596,y:572,t:1527635496350};\\\", \\\"{x:1597,y:576,t:1527635496367};\\\", \\\"{x:1598,y:580,t:1527635496383};\\\", \\\"{x:1600,y:586,t:1527635496399};\\\", \\\"{x:1600,y:590,t:1527635496416};\\\", \\\"{x:1601,y:595,t:1527635496432};\\\", \\\"{x:1602,y:601,t:1527635496449};\\\", \\\"{x:1602,y:605,t:1527635496466};\\\", \\\"{x:1603,y:609,t:1527635496482};\\\", \\\"{x:1603,y:613,t:1527635496499};\\\", \\\"{x:1603,y:617,t:1527635496516};\\\", \\\"{x:1603,y:622,t:1527635496533};\\\", \\\"{x:1603,y:627,t:1527635496550};\\\", \\\"{x:1603,y:634,t:1527635496567};\\\", \\\"{x:1603,y:640,t:1527635496582};\\\", \\\"{x:1602,y:651,t:1527635496599};\\\", \\\"{x:1602,y:657,t:1527635496616};\\\", \\\"{x:1602,y:663,t:1527635496632};\\\", \\\"{x:1600,y:667,t:1527635496649};\\\", \\\"{x:1599,y:674,t:1527635496666};\\\", \\\"{x:1599,y:675,t:1527635496683};\\\", \\\"{x:1599,y:678,t:1527635496700};\\\", \\\"{x:1599,y:681,t:1527635496715};\\\", \\\"{x:1599,y:682,t:1527635496733};\\\", \\\"{x:1599,y:683,t:1527635496749};\\\", \\\"{x:1599,y:684,t:1527635496766};\\\", \\\"{x:1599,y:685,t:1527635497066};\\\", \\\"{x:1599,y:690,t:1527635497082};\\\", \\\"{x:1599,y:693,t:1527635497099};\\\", \\\"{x:1600,y:695,t:1527635497116};\\\", \\\"{x:1601,y:696,t:1527635497133};\\\", \\\"{x:1603,y:696,t:1527635500923};\\\", \\\"{x:1603,y:695,t:1527635500931};\\\", \\\"{x:1603,y:694,t:1527635500955};\\\", \\\"{x:1603,y:693,t:1527635500971};\\\", \\\"{x:1603,y:692,t:1527635500979};\\\", \\\"{x:1603,y:691,t:1527635500994};\\\", \\\"{x:1603,y:690,t:1527635501026};\\\", \\\"{x:1604,y:689,t:1527635501034};\\\", \\\"{x:1604,y:688,t:1527635501058};\\\", \\\"{x:1604,y:687,t:1527635501099};\\\", \\\"{x:1604,y:686,t:1527635501123};\\\", \\\"{x:1605,y:685,t:1527635501146};\\\", \\\"{x:1605,y:683,t:1527635501211};\\\", \\\"{x:1606,y:682,t:1527635501235};\\\", \\\"{x:1606,y:680,t:1527635501258};\\\", \\\"{x:1606,y:679,t:1527635501282};\\\", \\\"{x:1607,y:677,t:1527635501307};\\\", \\\"{x:1607,y:676,t:1527635501330};\\\", \\\"{x:1608,y:675,t:1527635501355};\\\", \\\"{x:1608,y:674,t:1527635501362};\\\", \\\"{x:1608,y:673,t:1527635501394};\\\", \\\"{x:1609,y:672,t:1527635501418};\\\", \\\"{x:1609,y:671,t:1527635501434};\\\", \\\"{x:1609,y:670,t:1527635501451};\\\", \\\"{x:1609,y:669,t:1527635501482};\\\", \\\"{x:1609,y:668,t:1527635501498};\\\", \\\"{x:1610,y:667,t:1527635501523};\\\", \\\"{x:1610,y:665,t:1527635501546};\\\", \\\"{x:1611,y:664,t:1527635501611};\\\", \\\"{x:1605,y:664,t:1527635502275};\\\", \\\"{x:1583,y:673,t:1527635502294};\\\", \\\"{x:1532,y:687,t:1527635502310};\\\", \\\"{x:1450,y:694,t:1527635502326};\\\", \\\"{x:1344,y:694,t:1527635502343};\\\", \\\"{x:1217,y:679,t:1527635502361};\\\", \\\"{x:1073,y:657,t:1527635502376};\\\", \\\"{x:929,y:638,t:1527635502394};\\\", \\\"{x:781,y:605,t:1527635502410};\\\", \\\"{x:582,y:550,t:1527635502426};\\\", \\\"{x:477,y:517,t:1527635502442};\\\", \\\"{x:380,y:477,t:1527635502465};\\\", \\\"{x:273,y:423,t:1527635502481};\\\", \\\"{x:230,y:394,t:1527635502497};\\\", \\\"{x:211,y:375,t:1527635502514};\\\", \\\"{x:196,y:355,t:1527635502532};\\\", \\\"{x:190,y:336,t:1527635502547};\\\", \\\"{x:186,y:320,t:1527635502565};\\\", \\\"{x:186,y:304,t:1527635502581};\\\", \\\"{x:186,y:291,t:1527635502597};\\\", \\\"{x:186,y:284,t:1527635502614};\\\", \\\"{x:186,y:293,t:1527635502691};\\\", \\\"{x:194,y:306,t:1527635502698};\\\", \\\"{x:236,y:353,t:1527635502714};\\\", \\\"{x:309,y:405,t:1527635502732};\\\", \\\"{x:399,y:438,t:1527635502748};\\\", \\\"{x:498,y:466,t:1527635502764};\\\", \\\"{x:595,y:492,t:1527635502782};\\\", \\\"{x:684,y:505,t:1527635502799};\\\", \\\"{x:735,y:512,t:1527635502815};\\\", \\\"{x:753,y:514,t:1527635502831};\\\", \\\"{x:756,y:514,t:1527635502848};\\\", \\\"{x:756,y:513,t:1527635502881};\\\", \\\"{x:753,y:511,t:1527635502898};\\\", \\\"{x:747,y:506,t:1527635502915};\\\", \\\"{x:746,y:505,t:1527635502932};\\\", \\\"{x:746,y:504,t:1527635502994};\\\", \\\"{x:746,y:503,t:1527635503002};\\\", \\\"{x:746,y:502,t:1527635503018};\\\", \\\"{x:747,y:501,t:1527635503042};\\\", \\\"{x:750,y:501,t:1527635503138};\\\", \\\"{x:756,y:502,t:1527635503149};\\\", \\\"{x:770,y:509,t:1527635503166};\\\", \\\"{x:791,y:520,t:1527635503183};\\\", \\\"{x:810,y:529,t:1527635503199};\\\", \\\"{x:828,y:537,t:1527635503215};\\\", \\\"{x:846,y:545,t:1527635503232};\\\", \\\"{x:859,y:551,t:1527635503249};\\\", \\\"{x:862,y:553,t:1527635503266};\\\", \\\"{x:862,y:554,t:1527635503289};\\\", \\\"{x:862,y:557,t:1527635503299};\\\", \\\"{x:861,y:562,t:1527635503315};\\\", \\\"{x:851,y:569,t:1527635503332};\\\", \\\"{x:834,y:580,t:1527635503348};\\\", \\\"{x:812,y:590,t:1527635503366};\\\", \\\"{x:771,y:603,t:1527635503381};\\\", \\\"{x:727,y:613,t:1527635503398};\\\", \\\"{x:690,y:616,t:1527635503415};\\\", \\\"{x:659,y:616,t:1527635503431};\\\", \\\"{x:626,y:614,t:1527635503448};\\\", \\\"{x:581,y:607,t:1527635503465};\\\", \\\"{x:561,y:603,t:1527635503482};\\\", \\\"{x:550,y:600,t:1527635503499};\\\", \\\"{x:547,y:599,t:1527635503515};\\\", \\\"{x:547,y:597,t:1527635503593};\\\", \\\"{x:547,y:596,t:1527635503601};\\\", \\\"{x:547,y:593,t:1527635503616};\\\", \\\"{x:547,y:591,t:1527635503633};\\\", \\\"{x:547,y:589,t:1527635503649};\\\", \\\"{x:547,y:588,t:1527635503666};\\\", \\\"{x:546,y:587,t:1527635503714};\\\", \\\"{x:543,y:587,t:1527635503722};\\\", \\\"{x:537,y:587,t:1527635503732};\\\", \\\"{x:518,y:587,t:1527635503748};\\\", \\\"{x:495,y:588,t:1527635503766};\\\", \\\"{x:473,y:588,t:1527635503781};\\\", \\\"{x:455,y:588,t:1527635503798};\\\", \\\"{x:440,y:588,t:1527635503815};\\\", \\\"{x:431,y:589,t:1527635503832};\\\", \\\"{x:421,y:590,t:1527635503849};\\\", \\\"{x:414,y:591,t:1527635503865};\\\", \\\"{x:406,y:592,t:1527635503883};\\\", \\\"{x:396,y:593,t:1527635503899};\\\", \\\"{x:387,y:593,t:1527635503916};\\\", \\\"{x:376,y:593,t:1527635503933};\\\", \\\"{x:365,y:593,t:1527635503949};\\\", \\\"{x:354,y:593,t:1527635503966};\\\", \\\"{x:342,y:593,t:1527635503983};\\\", \\\"{x:328,y:593,t:1527635504000};\\\", \\\"{x:315,y:593,t:1527635504015};\\\", \\\"{x:302,y:593,t:1527635504032};\\\", \\\"{x:280,y:598,t:1527635504050};\\\", \\\"{x:258,y:607,t:1527635504067};\\\", \\\"{x:236,y:621,t:1527635504082};\\\", \\\"{x:218,y:637,t:1527635504100};\\\", \\\"{x:212,y:645,t:1527635504116};\\\", \\\"{x:212,y:648,t:1527635504132};\\\", \\\"{x:212,y:651,t:1527635504150};\\\", \\\"{x:219,y:656,t:1527635504165};\\\", \\\"{x:233,y:658,t:1527635504183};\\\", \\\"{x:259,y:661,t:1527635504200};\\\", \\\"{x:290,y:661,t:1527635504216};\\\", \\\"{x:327,y:661,t:1527635504232};\\\", \\\"{x:372,y:661,t:1527635504250};\\\", \\\"{x:389,y:660,t:1527635504269};\\\", \\\"{x:398,y:656,t:1527635504282};\\\", \\\"{x:401,y:653,t:1527635504299};\\\", \\\"{x:402,y:650,t:1527635504315};\\\", \\\"{x:402,y:644,t:1527635504333};\\\", \\\"{x:400,y:637,t:1527635504350};\\\", \\\"{x:391,y:627,t:1527635504366};\\\", \\\"{x:378,y:622,t:1527635504382};\\\", \\\"{x:357,y:619,t:1527635504400};\\\", \\\"{x:331,y:615,t:1527635504416};\\\", \\\"{x:302,y:610,t:1527635504432};\\\", \\\"{x:258,y:605,t:1527635504449};\\\", \\\"{x:237,y:602,t:1527635504467};\\\", \\\"{x:226,y:602,t:1527635504482};\\\", \\\"{x:222,y:602,t:1527635504499};\\\", \\\"{x:221,y:602,t:1527635504517};\\\", \\\"{x:219,y:602,t:1527635504532};\\\", \\\"{x:217,y:602,t:1527635504553};\\\", \\\"{x:212,y:604,t:1527635504566};\\\", \\\"{x:207,y:605,t:1527635504583};\\\", \\\"{x:195,y:606,t:1527635504600};\\\", \\\"{x:184,y:606,t:1527635504618};\\\", \\\"{x:176,y:606,t:1527635504633};\\\", \\\"{x:166,y:605,t:1527635504649};\\\", \\\"{x:165,y:605,t:1527635504667};\\\", \\\"{x:164,y:604,t:1527635504769};\\\", \\\"{x:164,y:604,t:1527635504873};\\\", \\\"{x:168,y:601,t:1527635504884};\\\", \\\"{x:183,y:600,t:1527635504900};\\\", \\\"{x:211,y:600,t:1527635504916};\\\", \\\"{x:253,y:604,t:1527635504934};\\\", \\\"{x:298,y:611,t:1527635504950};\\\", \\\"{x:352,y:620,t:1527635504966};\\\", \\\"{x:385,y:628,t:1527635504984};\\\", \\\"{x:406,y:632,t:1527635505000};\\\", \\\"{x:413,y:635,t:1527635505016};\\\", \\\"{x:414,y:635,t:1527635505034};\\\", \\\"{x:412,y:635,t:1527635505339};\\\", \\\"{x:411,y:635,t:1527635505362};\\\", \\\"{x:408,y:635,t:1527635505370};\\\", \\\"{x:407,y:633,t:1527635505384};\\\", \\\"{x:403,y:627,t:1527635505404};\\\", \\\"{x:399,y:620,t:1527635505416};\\\", \\\"{x:398,y:618,t:1527635505434};\\\", \\\"{x:398,y:617,t:1527635505497};\\\", \\\"{x:398,y:618,t:1527635505681};\\\", \\\"{x:398,y:622,t:1527635505689};\\\", \\\"{x:399,y:625,t:1527635505701};\\\", \\\"{x:399,y:636,t:1527635505718};\\\", \\\"{x:408,y:651,t:1527635505734};\\\", \\\"{x:424,y:664,t:1527635505751};\\\", \\\"{x:444,y:681,t:1527635505768};\\\", \\\"{x:465,y:698,t:1527635505784};\\\", \\\"{x:487,y:713,t:1527635505801};\\\", \\\"{x:516,y:734,t:1527635505818};\\\", \\\"{x:529,y:746,t:1527635505833};\\\", \\\"{x:536,y:752,t:1527635505850};\\\", \\\"{x:538,y:754,t:1527635505867};\\\", \\\"{x:540,y:754,t:1527635505930};\\\", \\\"{x:540,y:753,t:1527635505938};\\\", \\\"{x:541,y:750,t:1527635505951};\\\", \\\"{x:542,y:744,t:1527635505968};\\\", \\\"{x:542,y:741,t:1527635505984};\\\", \\\"{x:542,y:738,t:1527635506000};\\\", \\\"{x:542,y:737,t:1527635506018};\\\", \\\"{x:542,y:735,t:1527635506281};\\\", \\\"{x:544,y:735,t:1527635506394};\\\", \\\"{x:545,y:735,t:1527635506409};\\\", \\\"{x:547,y:735,t:1527635506442};\\\", \\\"{x:548,y:735,t:1527635506458};\\\", \\\"{x:551,y:735,t:1527635506468};\\\", \\\"{x:556,y:735,t:1527635506485};\\\", \\\"{x:566,y:735,t:1527635506501};\\\", \\\"{x:578,y:736,t:1527635506518};\\\", \\\"{x:586,y:736,t:1527635506535};\\\", \\\"{x:588,y:736,t:1527635506550};\\\", \\\"{x:589,y:731,t:1527635507245};\\\", \\\"{x:590,y:729,t:1527635507251};\\\", \\\"{x:590,y:725,t:1527635507267};\\\", \\\"{x:591,y:721,t:1527635507284};\\\", \\\"{x:591,y:716,t:1527635507301};\\\", \\\"{x:591,y:712,t:1527635507318};\\\", \\\"{x:591,y:705,t:1527635507335};\\\" ] }, { \\\"rt\\\": 27598, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 554351, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"93XU7\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\", \\\"N\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-11 AM-12 PM-01 PM-02 PM-02 PM-03 PM-I -B -O -O \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:581,y:661,t:1527635507499};\\\", \\\"{x:581,y:660,t:1527635507518};\\\", \\\"{x:581,y:658,t:1527635507535};\\\", \\\"{x:581,y:657,t:1527635507552};\\\", \\\"{x:581,y:656,t:1527635507604};\\\", \\\"{x:581,y:655,t:1527635507618};\\\", \\\"{x:581,y:654,t:1527635507636};\\\", \\\"{x:580,y:654,t:1527635507665};\\\", \\\"{x:579,y:653,t:1527635508017};\\\", \\\"{x:578,y:651,t:1527635508033};\\\", \\\"{x:576,y:649,t:1527635508041};\\\", \\\"{x:574,y:647,t:1527635508053};\\\", \\\"{x:572,y:647,t:1527635508069};\\\", \\\"{x:571,y:646,t:1527635508085};\\\", \\\"{x:570,y:645,t:1527635508105};\\\", \\\"{x:567,y:644,t:1527635508129};\\\", \\\"{x:566,y:644,t:1527635508137};\\\", \\\"{x:565,y:643,t:1527635508152};\\\", \\\"{x:557,y:643,t:1527635508169};\\\", \\\"{x:528,y:653,t:1527635508185};\\\", \\\"{x:528,y:654,t:1527635508203};\\\", \\\"{x:533,y:654,t:1527635508866};\\\", \\\"{x:539,y:654,t:1527635508874};\\\", \\\"{x:548,y:654,t:1527635508887};\\\", \\\"{x:565,y:654,t:1527635508903};\\\", \\\"{x:587,y:656,t:1527635508920};\\\", \\\"{x:611,y:660,t:1527635508937};\\\", \\\"{x:640,y:662,t:1527635508953};\\\", \\\"{x:706,y:674,t:1527635508970};\\\", \\\"{x:747,y:680,t:1527635508987};\\\", \\\"{x:795,y:687,t:1527635509003};\\\", \\\"{x:848,y:692,t:1527635509020};\\\", \\\"{x:890,y:705,t:1527635509038};\\\", \\\"{x:937,y:719,t:1527635509053};\\\", \\\"{x:985,y:733,t:1527635509070};\\\", \\\"{x:1015,y:741,t:1527635509087};\\\", \\\"{x:1040,y:748,t:1527635509103};\\\", \\\"{x:1065,y:757,t:1527635509120};\\\", \\\"{x:1090,y:768,t:1527635509137};\\\", \\\"{x:1110,y:781,t:1527635509153};\\\", \\\"{x:1141,y:800,t:1527635509170};\\\", \\\"{x:1160,y:813,t:1527635509187};\\\", \\\"{x:1174,y:825,t:1527635509203};\\\", \\\"{x:1189,y:836,t:1527635509220};\\\", \\\"{x:1205,y:848,t:1527635509237};\\\", \\\"{x:1222,y:859,t:1527635509252};\\\", \\\"{x:1235,y:868,t:1527635509269};\\\", \\\"{x:1249,y:877,t:1527635509286};\\\", \\\"{x:1261,y:883,t:1527635509302};\\\", \\\"{x:1270,y:887,t:1527635509320};\\\", \\\"{x:1276,y:891,t:1527635509337};\\\", \\\"{x:1293,y:896,t:1527635509353};\\\", \\\"{x:1304,y:898,t:1527635509369};\\\", \\\"{x:1313,y:901,t:1527635509386};\\\", \\\"{x:1328,y:903,t:1527635509404};\\\", \\\"{x:1345,y:906,t:1527635509420};\\\", \\\"{x:1364,y:907,t:1527635509437};\\\", \\\"{x:1385,y:911,t:1527635509454};\\\", \\\"{x:1410,y:912,t:1527635509470};\\\", \\\"{x:1431,y:912,t:1527635509487};\\\", \\\"{x:1450,y:912,t:1527635509504};\\\", \\\"{x:1468,y:912,t:1527635509520};\\\", \\\"{x:1475,y:912,t:1527635509537};\\\", \\\"{x:1477,y:913,t:1527635509555};\\\", \\\"{x:1477,y:914,t:1527635509578};\\\", \\\"{x:1479,y:915,t:1527635509587};\\\", \\\"{x:1480,y:920,t:1527635509604};\\\", \\\"{x:1483,y:928,t:1527635509620};\\\", \\\"{x:1485,y:941,t:1527635509638};\\\", \\\"{x:1489,y:956,t:1527635509654};\\\", \\\"{x:1492,y:967,t:1527635509670};\\\", \\\"{x:1493,y:970,t:1527635509687};\\\", \\\"{x:1493,y:971,t:1527635509722};\\\", \\\"{x:1493,y:972,t:1527635509738};\\\", \\\"{x:1493,y:973,t:1527635509754};\\\", \\\"{x:1491,y:973,t:1527635509811};\\\", \\\"{x:1490,y:973,t:1527635509834};\\\", \\\"{x:1489,y:971,t:1527635509842};\\\", \\\"{x:1487,y:969,t:1527635509854};\\\", \\\"{x:1482,y:963,t:1527635509873};\\\", \\\"{x:1477,y:960,t:1527635509888};\\\", \\\"{x:1471,y:957,t:1527635509904};\\\", \\\"{x:1466,y:957,t:1527635509922};\\\", \\\"{x:1456,y:956,t:1527635509937};\\\", \\\"{x:1439,y:953,t:1527635509954};\\\", \\\"{x:1429,y:953,t:1527635509971};\\\", \\\"{x:1422,y:953,t:1527635509986};\\\", \\\"{x:1418,y:953,t:1527635510004};\\\", \\\"{x:1413,y:953,t:1527635510021};\\\", \\\"{x:1411,y:953,t:1527635510037};\\\", \\\"{x:1410,y:953,t:1527635510090};\\\", \\\"{x:1408,y:953,t:1527635510103};\\\", \\\"{x:1403,y:954,t:1527635510121};\\\", \\\"{x:1391,y:957,t:1527635510137};\\\", \\\"{x:1367,y:961,t:1527635510154};\\\", \\\"{x:1345,y:964,t:1527635510171};\\\", \\\"{x:1323,y:965,t:1527635510188};\\\", \\\"{x:1305,y:967,t:1527635510204};\\\", \\\"{x:1295,y:969,t:1527635510221};\\\", \\\"{x:1291,y:969,t:1527635510237};\\\", \\\"{x:1290,y:969,t:1527635510258};\\\", \\\"{x:1290,y:970,t:1527635510270};\\\", \\\"{x:1289,y:971,t:1527635510288};\\\", \\\"{x:1288,y:972,t:1527635510304};\\\", \\\"{x:1291,y:972,t:1527635510386};\\\", \\\"{x:1295,y:972,t:1527635510394};\\\", \\\"{x:1299,y:972,t:1527635510405};\\\", \\\"{x:1314,y:972,t:1527635510421};\\\", \\\"{x:1335,y:972,t:1527635510438};\\\", \\\"{x:1359,y:972,t:1527635510455};\\\", \\\"{x:1386,y:972,t:1527635510472};\\\", \\\"{x:1416,y:972,t:1527635510488};\\\", \\\"{x:1431,y:972,t:1527635510505};\\\", \\\"{x:1439,y:972,t:1527635510521};\\\", \\\"{x:1441,y:972,t:1527635510538};\\\", \\\"{x:1442,y:972,t:1527635510555};\\\", \\\"{x:1443,y:972,t:1527635510610};\\\", \\\"{x:1445,y:972,t:1527635510622};\\\", \\\"{x:1449,y:972,t:1527635510638};\\\", \\\"{x:1453,y:972,t:1527635510654};\\\", \\\"{x:1457,y:972,t:1527635510671};\\\", \\\"{x:1459,y:972,t:1527635510688};\\\", \\\"{x:1461,y:972,t:1527635510705};\\\", \\\"{x:1464,y:972,t:1527635510722};\\\", \\\"{x:1469,y:971,t:1527635510738};\\\", \\\"{x:1473,y:971,t:1527635510755};\\\", \\\"{x:1477,y:970,t:1527635510770};\\\", \\\"{x:1480,y:970,t:1527635510787};\\\", \\\"{x:1485,y:970,t:1527635510805};\\\", \\\"{x:1489,y:970,t:1527635510821};\\\", \\\"{x:1494,y:970,t:1527635510838};\\\", \\\"{x:1499,y:970,t:1527635510854};\\\", \\\"{x:1505,y:970,t:1527635510871};\\\", \\\"{x:1509,y:970,t:1527635510887};\\\", \\\"{x:1513,y:970,t:1527635510905};\\\", \\\"{x:1517,y:970,t:1527635510921};\\\", \\\"{x:1519,y:970,t:1527635510937};\\\", \\\"{x:1520,y:970,t:1527635511002};\\\", \\\"{x:1520,y:969,t:1527635511018};\\\", \\\"{x:1520,y:968,t:1527635511034};\\\", \\\"{x:1521,y:967,t:1527635511041};\\\", \\\"{x:1523,y:965,t:1527635511057};\\\", \\\"{x:1525,y:964,t:1527635511074};\\\", \\\"{x:1525,y:963,t:1527635511088};\\\", \\\"{x:1528,y:963,t:1527635511105};\\\", \\\"{x:1531,y:961,t:1527635511121};\\\", \\\"{x:1537,y:959,t:1527635511138};\\\", \\\"{x:1538,y:958,t:1527635511155};\\\", \\\"{x:1541,y:956,t:1527635511171};\\\", \\\"{x:1541,y:954,t:1527635511188};\\\", \\\"{x:1541,y:953,t:1527635511234};\\\", \\\"{x:1541,y:952,t:1527635511315};\\\", \\\"{x:1541,y:951,t:1527635511322};\\\", \\\"{x:1541,y:950,t:1527635511339};\\\", \\\"{x:1541,y:949,t:1527635511355};\\\", \\\"{x:1541,y:948,t:1527635511373};\\\", \\\"{x:1541,y:945,t:1527635511388};\\\", \\\"{x:1541,y:940,t:1527635511406};\\\", \\\"{x:1541,y:935,t:1527635511422};\\\", \\\"{x:1541,y:930,t:1527635511439};\\\", \\\"{x:1541,y:923,t:1527635511455};\\\", \\\"{x:1541,y:918,t:1527635511472};\\\", \\\"{x:1541,y:914,t:1527635511489};\\\", \\\"{x:1541,y:908,t:1527635511506};\\\", \\\"{x:1540,y:904,t:1527635511522};\\\", \\\"{x:1540,y:901,t:1527635511539};\\\", \\\"{x:1540,y:900,t:1527635511555};\\\", \\\"{x:1540,y:898,t:1527635511586};\\\", \\\"{x:1540,y:897,t:1527635511610};\\\", \\\"{x:1540,y:894,t:1527635511634};\\\", \\\"{x:1540,y:892,t:1527635511659};\\\", \\\"{x:1540,y:891,t:1527635511672};\\\", \\\"{x:1540,y:888,t:1527635511688};\\\", \\\"{x:1540,y:884,t:1527635511706};\\\", \\\"{x:1539,y:878,t:1527635511723};\\\", \\\"{x:1537,y:873,t:1527635511739};\\\", \\\"{x:1537,y:872,t:1527635511756};\\\", \\\"{x:1537,y:870,t:1527635511773};\\\", \\\"{x:1537,y:869,t:1527635511789};\\\", \\\"{x:1537,y:866,t:1527635511805};\\\", \\\"{x:1537,y:865,t:1527635511822};\\\", \\\"{x:1536,y:863,t:1527635511839};\\\", \\\"{x:1536,y:860,t:1527635511855};\\\", \\\"{x:1536,y:859,t:1527635511872};\\\", \\\"{x:1536,y:857,t:1527635511889};\\\", \\\"{x:1536,y:856,t:1527635511906};\\\", \\\"{x:1536,y:854,t:1527635511922};\\\", \\\"{x:1536,y:855,t:1527635512107};\\\", \\\"{x:1537,y:860,t:1527635512122};\\\", \\\"{x:1539,y:866,t:1527635512139};\\\", \\\"{x:1541,y:878,t:1527635512155};\\\", \\\"{x:1541,y:889,t:1527635512172};\\\", \\\"{x:1536,y:906,t:1527635512190};\\\", \\\"{x:1527,y:927,t:1527635512206};\\\", \\\"{x:1516,y:949,t:1527635512222};\\\", \\\"{x:1506,y:966,t:1527635512239};\\\", \\\"{x:1501,y:977,t:1527635512257};\\\", \\\"{x:1500,y:983,t:1527635512273};\\\", \\\"{x:1500,y:984,t:1527635512289};\\\", \\\"{x:1500,y:985,t:1527635512355};\\\", \\\"{x:1505,y:982,t:1527635512372};\\\", \\\"{x:1512,y:974,t:1527635512390};\\\", \\\"{x:1518,y:964,t:1527635512407};\\\", \\\"{x:1525,y:952,t:1527635512423};\\\", \\\"{x:1528,y:943,t:1527635512440};\\\", \\\"{x:1536,y:925,t:1527635512457};\\\", \\\"{x:1538,y:913,t:1527635512472};\\\", \\\"{x:1540,y:904,t:1527635512490};\\\", \\\"{x:1541,y:892,t:1527635512507};\\\", \\\"{x:1541,y:884,t:1527635512522};\\\", \\\"{x:1541,y:875,t:1527635512540};\\\", \\\"{x:1541,y:867,t:1527635512557};\\\", \\\"{x:1541,y:862,t:1527635512572};\\\", \\\"{x:1541,y:851,t:1527635512590};\\\", \\\"{x:1541,y:845,t:1527635512607};\\\", \\\"{x:1541,y:839,t:1527635512622};\\\", \\\"{x:1541,y:833,t:1527635512639};\\\", \\\"{x:1540,y:826,t:1527635512657};\\\", \\\"{x:1539,y:820,t:1527635512673};\\\", \\\"{x:1539,y:816,t:1527635512690};\\\", \\\"{x:1539,y:812,t:1527635512706};\\\", \\\"{x:1539,y:810,t:1527635512723};\\\", \\\"{x:1539,y:808,t:1527635512739};\\\", \\\"{x:1539,y:805,t:1527635512757};\\\", \\\"{x:1539,y:801,t:1527635512773};\\\", \\\"{x:1542,y:798,t:1527635512789};\\\", \\\"{x:1543,y:794,t:1527635512806};\\\", \\\"{x:1544,y:789,t:1527635512823};\\\", \\\"{x:1545,y:787,t:1527635512840};\\\", \\\"{x:1545,y:784,t:1527635512857};\\\", \\\"{x:1545,y:783,t:1527635512874};\\\", \\\"{x:1545,y:779,t:1527635512890};\\\", \\\"{x:1545,y:775,t:1527635512906};\\\", \\\"{x:1545,y:772,t:1527635512923};\\\", \\\"{x:1545,y:768,t:1527635512940};\\\", \\\"{x:1545,y:764,t:1527635512956};\\\", \\\"{x:1545,y:758,t:1527635512974};\\\", \\\"{x:1545,y:751,t:1527635512990};\\\", \\\"{x:1545,y:746,t:1527635513007};\\\", \\\"{x:1546,y:742,t:1527635513023};\\\", \\\"{x:1546,y:734,t:1527635513040};\\\", \\\"{x:1546,y:730,t:1527635513057};\\\", \\\"{x:1546,y:727,t:1527635513074};\\\", \\\"{x:1547,y:725,t:1527635513090};\\\", \\\"{x:1547,y:724,t:1527635513106};\\\", \\\"{x:1547,y:721,t:1527635513124};\\\", \\\"{x:1548,y:719,t:1527635513141};\\\", \\\"{x:1548,y:717,t:1527635513157};\\\", \\\"{x:1548,y:713,t:1527635513173};\\\", \\\"{x:1548,y:710,t:1527635513191};\\\", \\\"{x:1548,y:706,t:1527635513206};\\\", \\\"{x:1548,y:702,t:1527635513223};\\\", \\\"{x:1548,y:700,t:1527635513240};\\\", \\\"{x:1548,y:696,t:1527635513257};\\\", \\\"{x:1548,y:692,t:1527635513273};\\\", \\\"{x:1548,y:684,t:1527635513290};\\\", \\\"{x:1548,y:679,t:1527635513307};\\\", \\\"{x:1547,y:676,t:1527635513323};\\\", \\\"{x:1547,y:671,t:1527635513341};\\\", \\\"{x:1547,y:668,t:1527635513356};\\\", \\\"{x:1546,y:667,t:1527635513374};\\\", \\\"{x:1546,y:666,t:1527635513390};\\\", \\\"{x:1546,y:665,t:1527635513410};\\\", \\\"{x:1546,y:664,t:1527635513475};\\\", \\\"{x:1546,y:662,t:1527635513490};\\\", \\\"{x:1546,y:660,t:1527635513506};\\\", \\\"{x:1546,y:659,t:1527635513524};\\\", \\\"{x:1546,y:658,t:1527635513541};\\\", \\\"{x:1546,y:657,t:1527635513557};\\\", \\\"{x:1546,y:655,t:1527635513574};\\\", \\\"{x:1546,y:654,t:1527635513590};\\\", \\\"{x:1546,y:653,t:1527635513607};\\\", \\\"{x:1545,y:650,t:1527635513623};\\\", \\\"{x:1544,y:645,t:1527635513640};\\\", \\\"{x:1541,y:639,t:1527635513658};\\\", \\\"{x:1538,y:632,t:1527635513673};\\\", \\\"{x:1535,y:627,t:1527635513691};\\\", \\\"{x:1531,y:622,t:1527635513707};\\\", \\\"{x:1530,y:622,t:1527635513723};\\\", \\\"{x:1529,y:622,t:1527635513931};\\\", \\\"{x:1529,y:625,t:1527635513940};\\\", \\\"{x:1529,y:637,t:1527635513958};\\\", \\\"{x:1530,y:658,t:1527635513973};\\\", \\\"{x:1530,y:681,t:1527635513990};\\\", \\\"{x:1530,y:697,t:1527635514008};\\\", \\\"{x:1531,y:706,t:1527635514024};\\\", \\\"{x:1533,y:709,t:1527635514041};\\\", \\\"{x:1533,y:707,t:1527635514185};\\\", \\\"{x:1533,y:705,t:1527635514201};\\\", \\\"{x:1534,y:702,t:1527635514209};\\\", \\\"{x:1535,y:698,t:1527635514224};\\\", \\\"{x:1537,y:691,t:1527635514240};\\\", \\\"{x:1538,y:686,t:1527635514256};\\\", \\\"{x:1539,y:682,t:1527635514273};\\\", \\\"{x:1541,y:678,t:1527635514290};\\\", \\\"{x:1541,y:675,t:1527635514307};\\\", \\\"{x:1542,y:667,t:1527635514324};\\\", \\\"{x:1543,y:661,t:1527635514340};\\\", \\\"{x:1543,y:657,t:1527635514357};\\\", \\\"{x:1543,y:656,t:1527635514374};\\\", \\\"{x:1543,y:653,t:1527635514389};\\\", \\\"{x:1543,y:651,t:1527635514407};\\\", \\\"{x:1543,y:650,t:1527635514424};\\\", \\\"{x:1543,y:648,t:1527635514439};\\\", \\\"{x:1543,y:646,t:1527635514457};\\\", \\\"{x:1543,y:645,t:1527635514474};\\\", \\\"{x:1543,y:644,t:1527635514490};\\\", \\\"{x:1543,y:643,t:1527635514507};\\\", \\\"{x:1543,y:641,t:1527635514523};\\\", \\\"{x:1542,y:640,t:1527635514540};\\\", \\\"{x:1541,y:637,t:1527635514557};\\\", \\\"{x:1540,y:636,t:1527635514574};\\\", \\\"{x:1540,y:635,t:1527635514590};\\\", \\\"{x:1540,y:634,t:1527635514608};\\\", \\\"{x:1540,y:632,t:1527635514626};\\\", \\\"{x:1539,y:630,t:1527635514642};\\\", \\\"{x:1538,y:630,t:1527635514658};\\\", \\\"{x:1537,y:628,t:1527635514674};\\\", \\\"{x:1537,y:627,t:1527635514692};\\\", \\\"{x:1537,y:625,t:1527635514708};\\\", \\\"{x:1536,y:623,t:1527635514724};\\\", \\\"{x:1535,y:622,t:1527635514742};\\\", \\\"{x:1534,y:621,t:1527635514758};\\\", \\\"{x:1534,y:619,t:1527635514834};\\\", \\\"{x:1534,y:618,t:1527635514850};\\\", \\\"{x:1534,y:616,t:1527635514866};\\\", \\\"{x:1534,y:615,t:1527635514875};\\\", \\\"{x:1534,y:614,t:1527635514892};\\\", \\\"{x:1534,y:613,t:1527635514908};\\\", \\\"{x:1534,y:612,t:1527635514924};\\\", \\\"{x:1534,y:614,t:1527635515203};\\\", \\\"{x:1534,y:616,t:1527635515210};\\\", \\\"{x:1535,y:620,t:1527635515224};\\\", \\\"{x:1537,y:640,t:1527635515242};\\\", \\\"{x:1538,y:655,t:1527635515258};\\\", \\\"{x:1538,y:678,t:1527635515275};\\\", \\\"{x:1538,y:699,t:1527635515292};\\\", \\\"{x:1538,y:723,t:1527635515309};\\\", \\\"{x:1538,y:746,t:1527635515325};\\\", \\\"{x:1540,y:760,t:1527635515341};\\\", \\\"{x:1541,y:766,t:1527635515359};\\\", \\\"{x:1541,y:770,t:1527635515374};\\\", \\\"{x:1542,y:773,t:1527635515391};\\\", \\\"{x:1542,y:775,t:1527635515408};\\\", \\\"{x:1544,y:777,t:1527635515425};\\\", \\\"{x:1544,y:783,t:1527635515442};\\\", \\\"{x:1544,y:791,t:1527635515459};\\\", \\\"{x:1545,y:801,t:1527635515475};\\\", \\\"{x:1545,y:814,t:1527635515492};\\\", \\\"{x:1545,y:828,t:1527635515508};\\\", \\\"{x:1545,y:841,t:1527635515526};\\\", \\\"{x:1545,y:854,t:1527635515542};\\\", \\\"{x:1546,y:868,t:1527635515558};\\\", \\\"{x:1549,y:881,t:1527635515576};\\\", \\\"{x:1551,y:899,t:1527635515591};\\\", \\\"{x:1552,y:911,t:1527635515608};\\\", \\\"{x:1556,y:923,t:1527635515626};\\\", \\\"{x:1559,y:938,t:1527635515642};\\\", \\\"{x:1562,y:947,t:1527635515658};\\\", \\\"{x:1564,y:951,t:1527635515675};\\\", \\\"{x:1566,y:952,t:1527635515692};\\\", \\\"{x:1566,y:953,t:1527635515730};\\\", \\\"{x:1566,y:954,t:1527635515741};\\\", \\\"{x:1567,y:955,t:1527635515762};\\\", \\\"{x:1567,y:954,t:1527635515875};\\\", \\\"{x:1566,y:939,t:1527635515892};\\\", \\\"{x:1565,y:924,t:1527635515909};\\\", \\\"{x:1562,y:908,t:1527635515926};\\\", \\\"{x:1560,y:894,t:1527635515942};\\\", \\\"{x:1560,y:886,t:1527635515959};\\\", \\\"{x:1560,y:872,t:1527635515976};\\\", \\\"{x:1559,y:862,t:1527635515993};\\\", \\\"{x:1559,y:844,t:1527635516009};\\\", \\\"{x:1557,y:818,t:1527635516026};\\\", \\\"{x:1555,y:804,t:1527635516042};\\\", \\\"{x:1554,y:790,t:1527635516058};\\\", \\\"{x:1551,y:780,t:1527635516076};\\\", \\\"{x:1550,y:766,t:1527635516092};\\\", \\\"{x:1549,y:750,t:1527635516109};\\\", \\\"{x:1547,y:739,t:1527635516126};\\\", \\\"{x:1547,y:730,t:1527635516143};\\\", \\\"{x:1547,y:722,t:1527635516159};\\\", \\\"{x:1547,y:715,t:1527635516176};\\\", \\\"{x:1546,y:707,t:1527635516192};\\\", \\\"{x:1545,y:700,t:1527635516209};\\\", \\\"{x:1545,y:692,t:1527635516226};\\\", \\\"{x:1543,y:687,t:1527635516242};\\\", \\\"{x:1543,y:683,t:1527635516259};\\\", \\\"{x:1543,y:677,t:1527635516275};\\\", \\\"{x:1543,y:674,t:1527635516291};\\\", \\\"{x:1543,y:670,t:1527635516308};\\\", \\\"{x:1543,y:664,t:1527635516324};\\\", \\\"{x:1543,y:659,t:1527635516341};\\\", \\\"{x:1543,y:654,t:1527635516358};\\\", \\\"{x:1543,y:650,t:1527635516375};\\\", \\\"{x:1544,y:647,t:1527635516392};\\\", \\\"{x:1544,y:645,t:1527635516408};\\\", \\\"{x:1544,y:641,t:1527635516425};\\\", \\\"{x:1544,y:637,t:1527635516442};\\\", \\\"{x:1544,y:634,t:1527635516459};\\\", \\\"{x:1544,y:628,t:1527635516475};\\\", \\\"{x:1544,y:620,t:1527635516492};\\\", \\\"{x:1544,y:612,t:1527635516509};\\\", \\\"{x:1544,y:606,t:1527635516525};\\\", \\\"{x:1544,y:602,t:1527635516542};\\\", \\\"{x:1544,y:595,t:1527635516559};\\\", \\\"{x:1544,y:588,t:1527635516575};\\\", \\\"{x:1544,y:581,t:1527635516592};\\\", \\\"{x:1544,y:573,t:1527635516609};\\\", \\\"{x:1544,y:569,t:1527635516625};\\\", \\\"{x:1544,y:568,t:1527635516642};\\\", \\\"{x:1544,y:567,t:1527635516659};\\\", \\\"{x:1544,y:564,t:1527635516675};\\\", \\\"{x:1544,y:563,t:1527635516697};\\\", \\\"{x:1544,y:562,t:1527635516709};\\\", \\\"{x:1544,y:560,t:1527635516725};\\\", \\\"{x:1546,y:557,t:1527635516742};\\\", \\\"{x:1546,y:555,t:1527635516759};\\\", \\\"{x:1547,y:553,t:1527635516775};\\\", \\\"{x:1547,y:550,t:1527635516792};\\\", \\\"{x:1547,y:544,t:1527635516809};\\\", \\\"{x:1547,y:539,t:1527635516825};\\\", \\\"{x:1547,y:534,t:1527635516842};\\\", \\\"{x:1547,y:529,t:1527635516859};\\\", \\\"{x:1547,y:522,t:1527635516875};\\\", \\\"{x:1547,y:518,t:1527635516892};\\\", \\\"{x:1547,y:515,t:1527635516909};\\\", \\\"{x:1547,y:511,t:1527635516925};\\\", \\\"{x:1547,y:507,t:1527635516943};\\\", \\\"{x:1547,y:502,t:1527635516959};\\\", \\\"{x:1547,y:494,t:1527635516976};\\\", \\\"{x:1549,y:486,t:1527635516992};\\\", \\\"{x:1550,y:476,t:1527635517010};\\\", \\\"{x:1550,y:471,t:1527635517026};\\\", \\\"{x:1550,y:467,t:1527635517043};\\\", \\\"{x:1550,y:464,t:1527635517060};\\\", \\\"{x:1550,y:460,t:1527635517076};\\\", \\\"{x:1550,y:457,t:1527635517093};\\\", \\\"{x:1550,y:455,t:1527635517110};\\\", \\\"{x:1550,y:454,t:1527635517126};\\\", \\\"{x:1550,y:453,t:1527635517142};\\\", \\\"{x:1550,y:452,t:1527635517160};\\\", \\\"{x:1550,y:451,t:1527635517177};\\\", \\\"{x:1550,y:450,t:1527635517291};\\\", \\\"{x:1550,y:449,t:1527635517298};\\\", \\\"{x:1550,y:448,t:1527635517310};\\\", \\\"{x:1550,y:445,t:1527635517326};\\\", \\\"{x:1550,y:443,t:1527635517343};\\\", \\\"{x:1550,y:440,t:1527635517360};\\\", \\\"{x:1550,y:438,t:1527635517376};\\\", \\\"{x:1550,y:436,t:1527635517393};\\\", \\\"{x:1550,y:433,t:1527635517409};\\\", \\\"{x:1550,y:430,t:1527635517426};\\\", \\\"{x:1550,y:427,t:1527635517443};\\\", \\\"{x:1550,y:422,t:1527635517459};\\\", \\\"{x:1550,y:421,t:1527635517476};\\\", \\\"{x:1550,y:418,t:1527635517493};\\\", \\\"{x:1550,y:416,t:1527635517509};\\\", \\\"{x:1550,y:415,t:1527635517526};\\\", \\\"{x:1550,y:414,t:1527635517543};\\\", \\\"{x:1550,y:413,t:1527635517559};\\\", \\\"{x:1550,y:412,t:1527635517576};\\\", \\\"{x:1550,y:410,t:1527635517593};\\\", \\\"{x:1550,y:409,t:1527635517618};\\\", \\\"{x:1550,y:408,t:1527635517626};\\\", \\\"{x:1551,y:407,t:1527635517644};\\\", \\\"{x:1551,y:404,t:1527635517659};\\\", \\\"{x:1551,y:401,t:1527635517676};\\\", \\\"{x:1551,y:397,t:1527635517693};\\\", \\\"{x:1551,y:396,t:1527635517709};\\\", \\\"{x:1551,y:394,t:1527635517727};\\\", \\\"{x:1551,y:392,t:1527635517744};\\\", \\\"{x:1551,y:391,t:1527635517760};\\\", \\\"{x:1551,y:390,t:1527635517777};\\\", \\\"{x:1551,y:387,t:1527635517794};\\\", \\\"{x:1551,y:385,t:1527635517810};\\\", \\\"{x:1551,y:384,t:1527635517826};\\\", \\\"{x:1551,y:383,t:1527635517844};\\\", \\\"{x:1551,y:381,t:1527635517860};\\\", \\\"{x:1551,y:379,t:1527635517876};\\\", \\\"{x:1551,y:378,t:1527635517893};\\\", \\\"{x:1551,y:375,t:1527635517911};\\\", \\\"{x:1551,y:374,t:1527635517926};\\\", \\\"{x:1551,y:372,t:1527635517943};\\\", \\\"{x:1551,y:371,t:1527635517961};\\\", \\\"{x:1551,y:370,t:1527635517976};\\\", \\\"{x:1551,y:368,t:1527635517993};\\\", \\\"{x:1551,y:367,t:1527635518017};\\\", \\\"{x:1551,y:366,t:1527635518026};\\\", \\\"{x:1551,y:365,t:1527635518043};\\\", \\\"{x:1551,y:364,t:1527635518060};\\\", \\\"{x:1551,y:363,t:1527635518076};\\\", \\\"{x:1551,y:362,t:1527635518093};\\\", \\\"{x:1551,y:360,t:1527635518110};\\\", \\\"{x:1551,y:358,t:1527635518127};\\\", \\\"{x:1551,y:356,t:1527635518143};\\\", \\\"{x:1551,y:354,t:1527635518160};\\\", \\\"{x:1551,y:353,t:1527635518176};\\\", \\\"{x:1551,y:349,t:1527635518194};\\\", \\\"{x:1551,y:348,t:1527635518211};\\\", \\\"{x:1551,y:345,t:1527635518226};\\\", \\\"{x:1551,y:344,t:1527635518243};\\\", \\\"{x:1551,y:342,t:1527635518261};\\\", \\\"{x:1551,y:341,t:1527635518290};\\\", \\\"{x:1551,y:340,t:1527635518298};\\\", \\\"{x:1551,y:339,t:1527635518311};\\\", \\\"{x:1551,y:338,t:1527635518326};\\\", \\\"{x:1551,y:337,t:1527635518344};\\\", \\\"{x:1551,y:336,t:1527635518360};\\\", \\\"{x:1551,y:340,t:1527635518682};\\\", \\\"{x:1552,y:347,t:1527635518694};\\\", \\\"{x:1554,y:364,t:1527635518711};\\\", \\\"{x:1558,y:396,t:1527635518727};\\\", \\\"{x:1569,y:453,t:1527635518744};\\\", \\\"{x:1577,y:517,t:1527635518761};\\\", \\\"{x:1582,y:605,t:1527635518779};\\\", \\\"{x:1587,y:671,t:1527635518794};\\\", \\\"{x:1596,y:732,t:1527635518811};\\\", \\\"{x:1604,y:796,t:1527635518828};\\\", \\\"{x:1611,y:873,t:1527635518845};\\\", \\\"{x:1613,y:943,t:1527635518861};\\\", \\\"{x:1613,y:1016,t:1527635518878};\\\", \\\"{x:1613,y:1077,t:1527635518894};\\\", \\\"{x:1611,y:1126,t:1527635518910};\\\", \\\"{x:1605,y:1163,t:1527635518927};\\\", \\\"{x:1592,y:1199,t:1527635518944};\\\", \\\"{x:1582,y:1199,t:1527635518961};\\\", \\\"{x:1575,y:1199,t:1527635518977};\\\", \\\"{x:1576,y:1199,t:1527635519018};\\\", \\\"{x:1576,y:1197,t:1527635519642};\\\", \\\"{x:1575,y:1191,t:1527635519650};\\\", \\\"{x:1575,y:1186,t:1527635519663};\\\", \\\"{x:1571,y:1171,t:1527635519680};\\\", \\\"{x:1569,y:1157,t:1527635519696};\\\", \\\"{x:1565,y:1141,t:1527635519712};\\\", \\\"{x:1562,y:1121,t:1527635519728};\\\", \\\"{x:1553,y:1088,t:1527635519746};\\\", \\\"{x:1548,y:1070,t:1527635519761};\\\", \\\"{x:1542,y:1053,t:1527635519778};\\\", \\\"{x:1538,y:1041,t:1527635519796};\\\", \\\"{x:1535,y:1036,t:1527635519812};\\\", \\\"{x:1534,y:1032,t:1527635519829};\\\", \\\"{x:1532,y:1028,t:1527635519846};\\\", \\\"{x:1532,y:1026,t:1527635519866};\\\", \\\"{x:1532,y:1025,t:1527635519879};\\\", \\\"{x:1531,y:1022,t:1527635519895};\\\", \\\"{x:1531,y:1020,t:1527635519913};\\\", \\\"{x:1531,y:1016,t:1527635519929};\\\", \\\"{x:1531,y:1006,t:1527635519945};\\\", \\\"{x:1534,y:997,t:1527635519963};\\\", \\\"{x:1543,y:983,t:1527635519979};\\\", \\\"{x:1550,y:973,t:1527635519995};\\\", \\\"{x:1556,y:965,t:1527635520013};\\\", \\\"{x:1557,y:963,t:1527635520029};\\\", \\\"{x:1558,y:961,t:1527635520046};\\\", \\\"{x:1559,y:959,t:1527635520062};\\\", \\\"{x:1556,y:957,t:1527635521742};\\\", \\\"{x:1551,y:956,t:1527635521750};\\\", \\\"{x:1545,y:955,t:1527635521768};\\\", \\\"{x:1537,y:952,t:1527635521785};\\\", \\\"{x:1531,y:950,t:1527635521800};\\\", \\\"{x:1526,y:950,t:1527635521818};\\\", \\\"{x:1525,y:950,t:1527635521835};\\\", \\\"{x:1524,y:950,t:1527635521854};\\\", \\\"{x:1523,y:949,t:1527635521998};\\\", \\\"{x:1516,y:947,t:1527635522006};\\\", \\\"{x:1508,y:944,t:1527635522017};\\\", \\\"{x:1489,y:938,t:1527635522034};\\\", \\\"{x:1459,y:927,t:1527635522051};\\\", \\\"{x:1428,y:918,t:1527635522067};\\\", \\\"{x:1394,y:908,t:1527635522084};\\\", \\\"{x:1348,y:896,t:1527635522101};\\\", \\\"{x:1324,y:888,t:1527635522117};\\\", \\\"{x:1304,y:878,t:1527635522134};\\\", \\\"{x:1287,y:863,t:1527635522151};\\\", \\\"{x:1274,y:843,t:1527635522167};\\\", \\\"{x:1266,y:822,t:1527635522184};\\\", \\\"{x:1254,y:790,t:1527635522201};\\\", \\\"{x:1239,y:744,t:1527635522217};\\\", \\\"{x:1232,y:704,t:1527635522234};\\\", \\\"{x:1230,y:679,t:1527635522251};\\\", \\\"{x:1225,y:651,t:1527635522267};\\\", \\\"{x:1221,y:622,t:1527635522284};\\\", \\\"{x:1215,y:593,t:1527635522301};\\\", \\\"{x:1215,y:584,t:1527635522317};\\\", \\\"{x:1214,y:578,t:1527635522334};\\\", \\\"{x:1211,y:573,t:1527635522352};\\\", \\\"{x:1211,y:572,t:1527635522367};\\\", \\\"{x:1211,y:571,t:1527635522384};\\\", \\\"{x:1211,y:572,t:1527635522484};\\\", \\\"{x:1211,y:586,t:1527635522501};\\\", \\\"{x:1211,y:610,t:1527635522518};\\\", \\\"{x:1211,y:640,t:1527635522534};\\\", \\\"{x:1211,y:666,t:1527635522551};\\\", \\\"{x:1211,y:693,t:1527635522568};\\\", \\\"{x:1207,y:721,t:1527635522584};\\\", \\\"{x:1204,y:746,t:1527635522602};\\\", \\\"{x:1198,y:764,t:1527635522618};\\\", \\\"{x:1193,y:775,t:1527635522634};\\\", \\\"{x:1185,y:786,t:1527635522651};\\\", \\\"{x:1180,y:793,t:1527635522668};\\\", \\\"{x:1177,y:797,t:1527635522684};\\\", \\\"{x:1176,y:798,t:1527635522701};\\\", \\\"{x:1175,y:799,t:1527635522790};\\\", \\\"{x:1173,y:798,t:1527635522805};\\\", \\\"{x:1171,y:792,t:1527635522818};\\\", \\\"{x:1167,y:782,t:1527635522835};\\\", \\\"{x:1163,y:771,t:1527635522852};\\\", \\\"{x:1159,y:762,t:1527635522869};\\\", \\\"{x:1158,y:758,t:1527635522885};\\\", \\\"{x:1158,y:754,t:1527635522901};\\\", \\\"{x:1159,y:754,t:1527635523126};\\\", \\\"{x:1160,y:754,t:1527635523190};\\\", \\\"{x:1161,y:754,t:1527635523206};\\\", \\\"{x:1162,y:754,t:1527635523219};\\\", \\\"{x:1164,y:755,t:1527635523235};\\\", \\\"{x:1167,y:758,t:1527635523252};\\\", \\\"{x:1170,y:759,t:1527635523269};\\\", \\\"{x:1171,y:760,t:1527635523285};\\\", \\\"{x:1174,y:760,t:1527635524206};\\\", \\\"{x:1179,y:760,t:1527635524222};\\\", \\\"{x:1193,y:760,t:1527635524236};\\\", \\\"{x:1212,y:758,t:1527635524252};\\\", \\\"{x:1244,y:754,t:1527635524269};\\\", \\\"{x:1261,y:751,t:1527635524285};\\\", \\\"{x:1273,y:749,t:1527635524302};\\\", \\\"{x:1285,y:749,t:1527635524319};\\\", \\\"{x:1293,y:749,t:1527635524336};\\\", \\\"{x:1301,y:749,t:1527635524352};\\\", \\\"{x:1309,y:749,t:1527635524369};\\\", \\\"{x:1325,y:749,t:1527635524386};\\\", \\\"{x:1347,y:749,t:1527635524402};\\\", \\\"{x:1372,y:749,t:1527635524419};\\\", \\\"{x:1400,y:749,t:1527635524436};\\\", \\\"{x:1427,y:749,t:1527635524452};\\\", \\\"{x:1468,y:749,t:1527635524469};\\\", \\\"{x:1491,y:749,t:1527635524486};\\\", \\\"{x:1511,y:749,t:1527635524502};\\\", \\\"{x:1527,y:748,t:1527635524520};\\\", \\\"{x:1539,y:748,t:1527635524536};\\\", \\\"{x:1548,y:745,t:1527635524552};\\\", \\\"{x:1556,y:744,t:1527635524569};\\\", \\\"{x:1560,y:743,t:1527635524586};\\\", \\\"{x:1564,y:742,t:1527635524602};\\\", \\\"{x:1567,y:741,t:1527635524619};\\\", \\\"{x:1568,y:741,t:1527635524637};\\\", \\\"{x:1570,y:741,t:1527635524719};\\\", \\\"{x:1572,y:745,t:1527635524737};\\\", \\\"{x:1575,y:750,t:1527635524752};\\\", \\\"{x:1575,y:757,t:1527635524769};\\\", \\\"{x:1575,y:759,t:1527635524786};\\\", \\\"{x:1575,y:760,t:1527635524802};\\\", \\\"{x:1575,y:761,t:1527635524820};\\\", \\\"{x:1574,y:762,t:1527635524837};\\\", \\\"{x:1570,y:762,t:1527635524854};\\\", \\\"{x:1568,y:762,t:1527635524869};\\\", \\\"{x:1565,y:762,t:1527635524886};\\\", \\\"{x:1561,y:760,t:1527635524904};\\\", \\\"{x:1556,y:759,t:1527635524919};\\\", \\\"{x:1550,y:756,t:1527635524937};\\\", \\\"{x:1547,y:755,t:1527635524954};\\\", \\\"{x:1546,y:755,t:1527635524969};\\\", \\\"{x:1544,y:755,t:1527635524986};\\\", \\\"{x:1543,y:755,t:1527635525006};\\\", \\\"{x:1542,y:755,t:1527635525021};\\\", \\\"{x:1541,y:755,t:1527635525036};\\\", \\\"{x:1540,y:755,t:1527635525061};\\\", \\\"{x:1539,y:755,t:1527635525086};\\\", \\\"{x:1538,y:755,t:1527635525104};\\\", \\\"{x:1537,y:755,t:1527635525120};\\\", \\\"{x:1534,y:755,t:1527635525136};\\\", \\\"{x:1532,y:756,t:1527635525154};\\\", \\\"{x:1531,y:756,t:1527635525170};\\\", \\\"{x:1530,y:756,t:1527635525582};\\\", \\\"{x:1529,y:756,t:1527635525598};\\\", \\\"{x:1528,y:756,t:1527635525606};\\\", \\\"{x:1528,y:757,t:1527635525621};\\\", \\\"{x:1527,y:757,t:1527635525638};\\\", \\\"{x:1526,y:757,t:1527635525734};\\\", \\\"{x:1525,y:757,t:1527635525758};\\\", \\\"{x:1524,y:757,t:1527635525798};\\\", \\\"{x:1523,y:757,t:1527635525806};\\\", \\\"{x:1522,y:757,t:1527635525821};\\\", \\\"{x:1521,y:758,t:1527635526022};\\\", \\\"{x:1519,y:759,t:1527635526661};\\\", \\\"{x:1515,y:759,t:1527635526671};\\\", \\\"{x:1506,y:764,t:1527635526687};\\\", \\\"{x:1495,y:768,t:1527635526704};\\\", \\\"{x:1488,y:771,t:1527635526722};\\\", \\\"{x:1488,y:770,t:1527635526918};\\\", \\\"{x:1488,y:769,t:1527635526926};\\\", \\\"{x:1488,y:768,t:1527635526938};\\\", \\\"{x:1489,y:767,t:1527635526955};\\\", \\\"{x:1491,y:765,t:1527635526972};\\\", \\\"{x:1492,y:765,t:1527635526990};\\\", \\\"{x:1493,y:765,t:1527635527005};\\\", \\\"{x:1494,y:765,t:1527635527029};\\\", \\\"{x:1495,y:765,t:1527635527038};\\\", \\\"{x:1496,y:765,t:1527635527055};\\\", \\\"{x:1497,y:765,t:1527635527077};\\\", \\\"{x:1498,y:765,t:1527635527102};\\\", \\\"{x:1499,y:765,t:1527635527109};\\\", \\\"{x:1500,y:765,t:1527635527158};\\\", \\\"{x:1501,y:765,t:1527635527190};\\\", \\\"{x:1502,y:765,t:1527635527222};\\\", \\\"{x:1503,y:765,t:1527635527373};\\\", \\\"{x:1504,y:765,t:1527635527389};\\\", \\\"{x:1505,y:765,t:1527635527405};\\\", \\\"{x:1507,y:766,t:1527635527421};\\\", \\\"{x:1506,y:767,t:1527635527726};\\\", \\\"{x:1504,y:768,t:1527635527739};\\\", \\\"{x:1494,y:771,t:1527635527756};\\\", \\\"{x:1481,y:775,t:1527635527772};\\\", \\\"{x:1464,y:779,t:1527635527789};\\\", \\\"{x:1443,y:782,t:1527635527806};\\\", \\\"{x:1428,y:783,t:1527635527822};\\\", \\\"{x:1416,y:785,t:1527635527839};\\\", \\\"{x:1404,y:785,t:1527635527856};\\\", \\\"{x:1393,y:785,t:1527635527872};\\\", \\\"{x:1372,y:785,t:1527635527889};\\\", \\\"{x:1349,y:785,t:1527635527905};\\\", \\\"{x:1323,y:785,t:1527635527922};\\\", \\\"{x:1291,y:785,t:1527635527939};\\\", \\\"{x:1246,y:785,t:1527635527956};\\\", \\\"{x:1188,y:785,t:1527635527972};\\\", \\\"{x:1126,y:785,t:1527635527989};\\\", \\\"{x:1043,y:785,t:1527635528005};\\\", \\\"{x:995,y:785,t:1527635528022};\\\", \\\"{x:956,y:785,t:1527635528039};\\\", \\\"{x:929,y:785,t:1527635528055};\\\", \\\"{x:907,y:785,t:1527635528071};\\\", \\\"{x:888,y:785,t:1527635528088};\\\", \\\"{x:869,y:785,t:1527635528105};\\\", \\\"{x:851,y:785,t:1527635528122};\\\", \\\"{x:832,y:785,t:1527635528139};\\\", \\\"{x:818,y:784,t:1527635528155};\\\", \\\"{x:798,y:780,t:1527635528173};\\\", \\\"{x:777,y:773,t:1527635528188};\\\", \\\"{x:758,y:767,t:1527635528205};\\\", \\\"{x:748,y:762,t:1527635528222};\\\", \\\"{x:738,y:759,t:1527635528239};\\\", \\\"{x:734,y:758,t:1527635528256};\\\", \\\"{x:733,y:759,t:1527635528398};\\\", \\\"{x:733,y:772,t:1527635528405};\\\", \\\"{x:742,y:791,t:1527635528423};\\\", \\\"{x:743,y:791,t:1527635528439};\\\", \\\"{x:744,y:792,t:1527635529438};\\\", \\\"{x:744,y:791,t:1527635529502};\\\", \\\"{x:744,y:788,t:1527635529510};\\\", \\\"{x:744,y:784,t:1527635529522};\\\", \\\"{x:744,y:775,t:1527635529540};\\\", \\\"{x:744,y:763,t:1527635529557};\\\", \\\"{x:747,y:734,t:1527635529573};\\\", \\\"{x:747,y:710,t:1527635529589};\\\", \\\"{x:745,y:677,t:1527635529607};\\\", \\\"{x:732,y:651,t:1527635529624};\\\", \\\"{x:717,y:628,t:1527635529645};\\\", \\\"{x:703,y:613,t:1527635529656};\\\", \\\"{x:683,y:600,t:1527635529674};\\\", \\\"{x:658,y:590,t:1527635529689};\\\", \\\"{x:631,y:582,t:1527635529707};\\\", \\\"{x:605,y:576,t:1527635529723};\\\", \\\"{x:584,y:572,t:1527635529740};\\\", \\\"{x:563,y:569,t:1527635529756};\\\", \\\"{x:556,y:568,t:1527635529773};\\\", \\\"{x:553,y:567,t:1527635529790};\\\", \\\"{x:553,y:566,t:1527635529918};\\\", \\\"{x:553,y:565,t:1527635529933};\\\", \\\"{x:553,y:564,t:1527635529941};\\\", \\\"{x:554,y:561,t:1527635529958};\\\", \\\"{x:555,y:556,t:1527635529973};\\\", \\\"{x:560,y:549,t:1527635529991};\\\", \\\"{x:564,y:542,t:1527635530008};\\\", \\\"{x:568,y:534,t:1527635530024};\\\", \\\"{x:573,y:527,t:1527635530040};\\\", \\\"{x:575,y:523,t:1527635530057};\\\", \\\"{x:576,y:521,t:1527635530073};\\\", \\\"{x:576,y:520,t:1527635530090};\\\", \\\"{x:576,y:519,t:1527635530125};\\\", \\\"{x:575,y:518,t:1527635530165};\\\", \\\"{x:572,y:518,t:1527635530174};\\\", \\\"{x:565,y:522,t:1527635530190};\\\", \\\"{x:561,y:527,t:1527635530209};\\\", \\\"{x:560,y:527,t:1527635530224};\\\", \\\"{x:560,y:528,t:1527635530240};\\\", \\\"{x:565,y:531,t:1527635530257};\\\", \\\"{x:592,y:532,t:1527635530275};\\\", \\\"{x:646,y:536,t:1527635530292};\\\", \\\"{x:719,y:538,t:1527635530308};\\\", \\\"{x:783,y:540,t:1527635530325};\\\", \\\"{x:850,y:545,t:1527635530341};\\\", \\\"{x:865,y:545,t:1527635530358};\\\", \\\"{x:866,y:546,t:1527635530445};\\\", \\\"{x:866,y:547,t:1527635530457};\\\", \\\"{x:866,y:548,t:1527635530474};\\\", \\\"{x:866,y:552,t:1527635530491};\\\", \\\"{x:862,y:555,t:1527635530508};\\\", \\\"{x:851,y:560,t:1527635530525};\\\", \\\"{x:829,y:569,t:1527635530542};\\\", \\\"{x:824,y:572,t:1527635530557};\\\", \\\"{x:821,y:573,t:1527635530575};\\\", \\\"{x:821,y:572,t:1527635530718};\\\", \\\"{x:822,y:570,t:1527635530725};\\\", \\\"{x:824,y:568,t:1527635530741};\\\", \\\"{x:825,y:567,t:1527635530759};\\\", \\\"{x:825,y:570,t:1527635531029};\\\", \\\"{x:825,y:575,t:1527635531041};\\\", \\\"{x:819,y:587,t:1527635531059};\\\", \\\"{x:809,y:603,t:1527635531075};\\\", \\\"{x:795,y:620,t:1527635531091};\\\", \\\"{x:775,y:634,t:1527635531108};\\\", \\\"{x:756,y:648,t:1527635531125};\\\", \\\"{x:720,y:665,t:1527635531141};\\\", \\\"{x:691,y:675,t:1527635531158};\\\", \\\"{x:665,y:680,t:1527635531174};\\\", \\\"{x:639,y:680,t:1527635531191};\\\", \\\"{x:616,y:680,t:1527635531208};\\\", \\\"{x:593,y:680,t:1527635531224};\\\", \\\"{x:574,y:680,t:1527635531241};\\\", \\\"{x:552,y:680,t:1527635531258};\\\", \\\"{x:532,y:680,t:1527635531276};\\\", \\\"{x:509,y:680,t:1527635531292};\\\", \\\"{x:487,y:680,t:1527635531308};\\\", \\\"{x:467,y:680,t:1527635531325};\\\", \\\"{x:460,y:682,t:1527635531341};\\\", \\\"{x:457,y:683,t:1527635531359};\\\", \\\"{x:456,y:685,t:1527635531375};\\\", \\\"{x:456,y:686,t:1527635531392};\\\", \\\"{x:456,y:688,t:1527635531409};\\\", \\\"{x:455,y:691,t:1527635531425};\\\", \\\"{x:455,y:694,t:1527635531441};\\\", \\\"{x:455,y:699,t:1527635531459};\\\", \\\"{x:454,y:704,t:1527635531475};\\\", \\\"{x:454,y:709,t:1527635531491};\\\", \\\"{x:454,y:715,t:1527635531509};\\\", \\\"{x:454,y:719,t:1527635531525};\\\", \\\"{x:455,y:721,t:1527635531542};\\\", \\\"{x:456,y:722,t:1527635531558};\\\", \\\"{x:456,y:723,t:1527635531576};\\\", \\\"{x:458,y:723,t:1527635531591};\\\", \\\"{x:461,y:723,t:1527635531608};\\\", \\\"{x:464,y:723,t:1527635531625};\\\", \\\"{x:473,y:723,t:1527635531643};\\\", \\\"{x:485,y:718,t:1527635531660};\\\", \\\"{x:499,y:710,t:1527635531675};\\\", \\\"{x:528,y:695,t:1527635531693};\\\", \\\"{x:534,y:693,t:1527635531709};\\\", \\\"{x:551,y:686,t:1527635531726};\\\", \\\"{x:552,y:684,t:1527635531742};\\\", \\\"{x:555,y:682,t:1527635531759};\\\", \\\"{x:555,y:680,t:1527635531776};\\\", \\\"{x:553,y:683,t:1527635531869};\\\", \\\"{x:548,y:688,t:1527635531878};\\\", \\\"{x:537,y:702,t:1527635531892};\\\", \\\"{x:531,y:708,t:1527635531909};\\\", \\\"{x:522,y:721,t:1527635531927};\\\", \\\"{x:520,y:723,t:1527635531943};\\\", \\\"{x:522,y:723,t:1527635531981};\\\", \\\"{x:526,y:723,t:1527635531992};\\\", \\\"{x:536,y:722,t:1527635532010};\\\", \\\"{x:553,y:715,t:1527635532026};\\\", \\\"{x:574,y:707,t:1527635532043};\\\", \\\"{x:597,y:698,t:1527635532058};\\\", \\\"{x:613,y:687,t:1527635532075};\\\", \\\"{x:623,y:675,t:1527635532092};\\\", \\\"{x:623,y:674,t:1527635532150};\\\", \\\"{x:619,y:674,t:1527635532159};\\\", \\\"{x:609,y:674,t:1527635532176};\\\", \\\"{x:593,y:682,t:1527635532193};\\\", \\\"{x:585,y:688,t:1527635532210};\\\", \\\"{x:582,y:691,t:1527635532226};\\\", \\\"{x:579,y:691,t:1527635532286};\\\", \\\"{x:576,y:691,t:1527635532293};\\\", \\\"{x:564,y:691,t:1527635532309};\\\", \\\"{x:545,y:689,t:1527635532325};\\\", \\\"{x:515,y:682,t:1527635532344};\\\", \\\"{x:467,y:666,t:1527635532362};\\\", \\\"{x:398,y:649,t:1527635532375};\\\", \\\"{x:318,y:628,t:1527635532393};\\\", \\\"{x:237,y:606,t:1527635532410};\\\", \\\"{x:165,y:586,t:1527635532427};\\\", \\\"{x:104,y:569,t:1527635532443};\\\", \\\"{x:64,y:556,t:1527635532459};\\\", \\\"{x:45,y:551,t:1527635532475};\\\", \\\"{x:33,y:548,t:1527635532493};\\\", \\\"{x:32,y:546,t:1527635532509};\\\", \\\"{x:30,y:546,t:1527635532525};\\\", \\\"{x:29,y:546,t:1527635532542};\\\", \\\"{x:26,y:547,t:1527635532560};\\\", \\\"{x:26,y:552,t:1527635532576};\\\", \\\"{x:25,y:561,t:1527635532592};\\\", \\\"{x:25,y:569,t:1527635532610};\\\", \\\"{x:28,y:577,t:1527635532627};\\\", \\\"{x:38,y:585,t:1527635532643};\\\", \\\"{x:50,y:590,t:1527635532660};\\\", \\\"{x:73,y:598,t:1527635532677};\\\", \\\"{x:91,y:603,t:1527635532694};\\\", \\\"{x:104,y:607,t:1527635532708};\\\", \\\"{x:115,y:610,t:1527635532726};\\\", \\\"{x:121,y:611,t:1527635532742};\\\", \\\"{x:123,y:612,t:1527635532760};\\\", \\\"{x:123,y:613,t:1527635532782};\\\", \\\"{x:124,y:614,t:1527635532792};\\\", \\\"{x:125,y:617,t:1527635532810};\\\", \\\"{x:126,y:622,t:1527635532826};\\\", \\\"{x:129,y:631,t:1527635532842};\\\", \\\"{x:130,y:638,t:1527635532861};\\\", \\\"{x:134,y:647,t:1527635532877};\\\", \\\"{x:134,y:650,t:1527635532892};\\\", \\\"{x:135,y:652,t:1527635532910};\\\", \\\"{x:136,y:652,t:1527635532933};\\\", \\\"{x:136,y:653,t:1527635532965};\\\", \\\"{x:137,y:653,t:1527635533021};\\\", \\\"{x:138,y:653,t:1527635533045};\\\", \\\"{x:139,y:654,t:1527635533061};\\\", \\\"{x:140,y:655,t:1527635533077};\\\", \\\"{x:142,y:656,t:1527635533093};\\\", \\\"{x:143,y:656,t:1527635533110};\\\", \\\"{x:146,y:656,t:1527635533309};\\\", \\\"{x:149,y:657,t:1527635533317};\\\", \\\"{x:154,y:658,t:1527635533327};\\\", \\\"{x:173,y:663,t:1527635533344};\\\", \\\"{x:201,y:671,t:1527635533360};\\\", \\\"{x:241,y:682,t:1527635533377};\\\", \\\"{x:288,y:694,t:1527635533393};\\\", \\\"{x:346,y:711,t:1527635533411};\\\", \\\"{x:415,y:729,t:1527635533426};\\\", \\\"{x:473,y:745,t:1527635533445};\\\", \\\"{x:568,y:773,t:1527635533461};\\\", \\\"{x:621,y:796,t:1527635533477};\\\", \\\"{x:675,y:815,t:1527635533493};\\\", \\\"{x:713,y:831,t:1527635533510};\\\", \\\"{x:735,y:840,t:1527635533527};\\\", \\\"{x:747,y:845,t:1527635533544};\\\", \\\"{x:748,y:846,t:1527635533561};\\\", \\\"{x:747,y:846,t:1527635533629};\\\", \\\"{x:741,y:843,t:1527635533644};\\\", \\\"{x:708,y:827,t:1527635533661};\\\", \\\"{x:688,y:820,t:1527635533676};\\\", \\\"{x:628,y:794,t:1527635533694};\\\", \\\"{x:595,y:779,t:1527635533711};\\\", \\\"{x:570,y:765,t:1527635533727};\\\", \\\"{x:550,y:755,t:1527635533744};\\\", \\\"{x:536,y:752,t:1527635533761};\\\", \\\"{x:519,y:749,t:1527635533777};\\\", \\\"{x:496,y:746,t:1527635533793};\\\", \\\"{x:462,y:740,t:1527635533810};\\\", \\\"{x:414,y:733,t:1527635533828};\\\", \\\"{x:356,y:719,t:1527635533844};\\\", \\\"{x:303,y:711,t:1527635533860};\\\", \\\"{x:217,y:686,t:1527635533877};\\\", \\\"{x:172,y:673,t:1527635533894};\\\", \\\"{x:152,y:667,t:1527635533913};\\\", \\\"{x:142,y:665,t:1527635533927};\\\", \\\"{x:138,y:663,t:1527635533944};\\\", \\\"{x:135,y:663,t:1527635533961};\\\", \\\"{x:132,y:661,t:1527635533976};\\\", \\\"{x:128,y:659,t:1527635533993};\\\", \\\"{x:125,y:657,t:1527635534010};\\\", \\\"{x:123,y:656,t:1527635534026};\\\", \\\"{x:122,y:655,t:1527635534043};\\\", \\\"{x:122,y:654,t:1527635534125};\\\", \\\"{x:123,y:654,t:1527635534133};\\\", \\\"{x:125,y:654,t:1527635534144};\\\", \\\"{x:134,y:654,t:1527635534161};\\\", \\\"{x:147,y:656,t:1527635534177};\\\", \\\"{x:154,y:658,t:1527635534195};\\\", \\\"{x:160,y:660,t:1527635534210};\\\", \\\"{x:161,y:660,t:1527635534227};\\\", \\\"{x:162,y:660,t:1527635534268};\\\", \\\"{x:163,y:660,t:1527635534292};\\\", \\\"{x:164,y:660,t:1527635534427};\\\", \\\"{x:176,y:660,t:1527635534445};\\\", \\\"{x:190,y:660,t:1527635534460};\\\", \\\"{x:216,y:664,t:1527635534478};\\\", \\\"{x:253,y:675,t:1527635534495};\\\", \\\"{x:301,y:689,t:1527635534510};\\\", \\\"{x:347,y:698,t:1527635534527};\\\", \\\"{x:406,y:708,t:1527635534545};\\\", \\\"{x:467,y:718,t:1527635534560};\\\", \\\"{x:515,y:731,t:1527635534578};\\\", \\\"{x:557,y:745,t:1527635534595};\\\", \\\"{x:578,y:750,t:1527635534611};\\\", \\\"{x:583,y:752,t:1527635534628};\\\", \\\"{x:583,y:753,t:1527635534645};\\\", \\\"{x:583,y:755,t:1527635534661};\\\", \\\"{x:581,y:757,t:1527635534677};\\\", \\\"{x:579,y:758,t:1527635534694};\\\", \\\"{x:579,y:759,t:1527635534710};\\\", \\\"{x:578,y:760,t:1527635534728};\\\", \\\"{x:578,y:762,t:1527635534744};\\\", \\\"{x:578,y:763,t:1527635534762};\\\", \\\"{x:577,y:764,t:1527635534777};\\\", \\\"{x:577,y:765,t:1527635534797};\\\", \\\"{x:576,y:765,t:1527635534837};\\\", \\\"{x:573,y:762,t:1527635534845};\\\", \\\"{x:567,y:755,t:1527635534861};\\\", \\\"{x:556,y:747,t:1527635534878};\\\", \\\"{x:542,y:735,t:1527635534895};\\\", \\\"{x:528,y:726,t:1527635534912};\\\", \\\"{x:522,y:722,t:1527635534928};\\\", \\\"{x:521,y:721,t:1527635534945};\\\", \\\"{x:522,y:723,t:1527635535132};\\\", \\\"{x:522,y:724,t:1527635535144};\\\", \\\"{x:522,y:727,t:1527635535162};\\\", \\\"{x:523,y:731,t:1527635535177};\\\", \\\"{x:524,y:734,t:1527635535194};\\\", \\\"{x:525,y:734,t:1527635535211};\\\", \\\"{x:526,y:735,t:1527635535477};\\\", \\\"{x:534,y:733,t:1527635535495};\\\", \\\"{x:550,y:725,t:1527635535512};\\\", \\\"{x:568,y:719,t:1527635535529};\\\", \\\"{x:591,y:714,t:1527635535546};\\\", \\\"{x:616,y:709,t:1527635535562};\\\", \\\"{x:636,y:707,t:1527635535579};\\\", \\\"{x:653,y:706,t:1527635535595};\\\", \\\"{x:667,y:706,t:1527635535612};\\\", \\\"{x:682,y:706,t:1527635535629};\\\", \\\"{x:696,y:709,t:1527635535645};\\\", \\\"{x:708,y:711,t:1527635535661};\\\", \\\"{x:709,y:711,t:1527635535679};\\\" ] }, { \\\"rt\\\": 17253, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 572824, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"93XU7\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Triangular-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-01 PM-02 PM-X -X -C -C -C -02 PM-02 PM-X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:708,y:711,t:1527635536412};\\\", \\\"{x:704,y:711,t:1527635536433};\\\", \\\"{x:699,y:706,t:1527635536446};\\\", \\\"{x:693,y:701,t:1527635536462};\\\", \\\"{x:688,y:697,t:1527635536480};\\\", \\\"{x:678,y:691,t:1527635536495};\\\", \\\"{x:670,y:685,t:1527635536512};\\\", \\\"{x:660,y:678,t:1527635536530};\\\", \\\"{x:647,y:668,t:1527635536545};\\\", \\\"{x:633,y:659,t:1527635536562};\\\", \\\"{x:615,y:645,t:1527635536580};\\\", \\\"{x:596,y:633,t:1527635536595};\\\", \\\"{x:572,y:617,t:1527635536612};\\\", \\\"{x:556,y:606,t:1527635536630};\\\", \\\"{x:542,y:596,t:1527635536645};\\\", \\\"{x:527,y:587,t:1527635536662};\\\", \\\"{x:512,y:578,t:1527635536680};\\\", \\\"{x:499,y:571,t:1527635536696};\\\", \\\"{x:489,y:566,t:1527635536713};\\\", \\\"{x:486,y:564,t:1527635536729};\\\", \\\"{x:484,y:563,t:1527635536746};\\\", \\\"{x:483,y:562,t:1527635536773};\\\", \\\"{x:481,y:557,t:1527635536905};\\\", \\\"{x:481,y:556,t:1527635536912};\\\", \\\"{x:480,y:555,t:1527635537021};\\\", \\\"{x:479,y:554,t:1527635537030};\\\", \\\"{x:469,y:554,t:1527635537046};\\\", \\\"{x:458,y:555,t:1527635537062};\\\", \\\"{x:454,y:562,t:1527635537079};\\\", \\\"{x:454,y:563,t:1527635537097};\\\", \\\"{x:454,y:561,t:1527635537734};\\\", \\\"{x:455,y:557,t:1527635537747};\\\", \\\"{x:456,y:553,t:1527635537765};\\\", \\\"{x:459,y:548,t:1527635537782};\\\", \\\"{x:460,y:544,t:1527635537797};\\\", \\\"{x:462,y:541,t:1527635537814};\\\", \\\"{x:463,y:540,t:1527635537831};\\\", \\\"{x:463,y:539,t:1527635537847};\\\", \\\"{x:464,y:537,t:1527635537865};\\\", \\\"{x:464,y:536,t:1527635537884};\\\", \\\"{x:464,y:534,t:1527635537900};\\\", \\\"{x:467,y:531,t:1527635537914};\\\", \\\"{x:471,y:526,t:1527635537931};\\\", \\\"{x:482,y:514,t:1527635537947};\\\", \\\"{x:498,y:502,t:1527635537963};\\\", \\\"{x:542,y:480,t:1527635537980};\\\", \\\"{x:565,y:471,t:1527635537996};\\\", \\\"{x:596,y:461,t:1527635538014};\\\", \\\"{x:617,y:455,t:1527635538030};\\\", \\\"{x:634,y:450,t:1527635538046};\\\", \\\"{x:649,y:447,t:1527635538063};\\\", \\\"{x:653,y:445,t:1527635538081};\\\", \\\"{x:655,y:445,t:1527635538389};\\\", \\\"{x:660,y:447,t:1527635538398};\\\", \\\"{x:672,y:454,t:1527635538414};\\\", \\\"{x:689,y:463,t:1527635538431};\\\", \\\"{x:708,y:472,t:1527635538447};\\\", \\\"{x:732,y:478,t:1527635538464};\\\", \\\"{x:751,y:485,t:1527635538481};\\\", \\\"{x:764,y:489,t:1527635538498};\\\", \\\"{x:776,y:490,t:1527635538514};\\\", \\\"{x:782,y:491,t:1527635538531};\\\", \\\"{x:785,y:492,t:1527635538548};\\\", \\\"{x:786,y:494,t:1527635538877};\\\", \\\"{x:786,y:496,t:1527635538886};\\\", \\\"{x:786,y:499,t:1527635538898};\\\", \\\"{x:787,y:510,t:1527635538917};\\\", \\\"{x:791,y:520,t:1527635538930};\\\", \\\"{x:796,y:534,t:1527635538948};\\\", \\\"{x:800,y:546,t:1527635538964};\\\", \\\"{x:803,y:552,t:1527635538981};\\\", \\\"{x:804,y:555,t:1527635538997};\\\", \\\"{x:804,y:559,t:1527635539015};\\\", \\\"{x:804,y:561,t:1527635539031};\\\", \\\"{x:804,y:564,t:1527635539047};\\\", \\\"{x:805,y:568,t:1527635539065};\\\", \\\"{x:806,y:570,t:1527635539081};\\\", \\\"{x:806,y:575,t:1527635539098};\\\", \\\"{x:807,y:577,t:1527635539116};\\\", \\\"{x:807,y:580,t:1527635539132};\\\", \\\"{x:809,y:584,t:1527635539148};\\\", \\\"{x:811,y:593,t:1527635539165};\\\", \\\"{x:812,y:597,t:1527635539181};\\\", \\\"{x:817,y:607,t:1527635539197};\\\", \\\"{x:821,y:616,t:1527635539216};\\\", \\\"{x:825,y:626,t:1527635539232};\\\", \\\"{x:830,y:636,t:1527635539248};\\\", \\\"{x:839,y:652,t:1527635539265};\\\", \\\"{x:844,y:666,t:1527635539282};\\\", \\\"{x:850,y:682,t:1527635539297};\\\", \\\"{x:856,y:694,t:1527635539315};\\\", \\\"{x:861,y:707,t:1527635539331};\\\", \\\"{x:866,y:719,t:1527635539348};\\\", \\\"{x:871,y:732,t:1527635539364};\\\", \\\"{x:875,y:743,t:1527635539382};\\\", \\\"{x:881,y:754,t:1527635539397};\\\", \\\"{x:887,y:766,t:1527635539415};\\\", \\\"{x:894,y:777,t:1527635539431};\\\", \\\"{x:904,y:788,t:1527635539448};\\\", \\\"{x:914,y:796,t:1527635539464};\\\", \\\"{x:929,y:807,t:1527635539482};\\\", \\\"{x:945,y:818,t:1527635539498};\\\", \\\"{x:964,y:825,t:1527635539515};\\\", \\\"{x:984,y:834,t:1527635539532};\\\", \\\"{x:1001,y:839,t:1527635539548};\\\", \\\"{x:1029,y:847,t:1527635539565};\\\", \\\"{x:1040,y:852,t:1527635539582};\\\", \\\"{x:1048,y:855,t:1527635539598};\\\", \\\"{x:1051,y:855,t:1527635539615};\\\", \\\"{x:1052,y:855,t:1527635539632};\\\", \\\"{x:1053,y:856,t:1527635539701};\\\", \\\"{x:1054,y:856,t:1527635539732};\\\", \\\"{x:1056,y:857,t:1527635539748};\\\", \\\"{x:1058,y:858,t:1527635539765};\\\", \\\"{x:1061,y:859,t:1527635539781};\\\", \\\"{x:1066,y:860,t:1527635539799};\\\", \\\"{x:1072,y:862,t:1527635539815};\\\", \\\"{x:1077,y:864,t:1527635539831};\\\", \\\"{x:1086,y:867,t:1527635539849};\\\", \\\"{x:1099,y:869,t:1527635539865};\\\", \\\"{x:1111,y:873,t:1527635539882};\\\", \\\"{x:1125,y:878,t:1527635539899};\\\", \\\"{x:1141,y:882,t:1527635539914};\\\", \\\"{x:1161,y:888,t:1527635539932};\\\", \\\"{x:1195,y:895,t:1527635539949};\\\", \\\"{x:1226,y:901,t:1527635539964};\\\", \\\"{x:1263,y:911,t:1527635539981};\\\", \\\"{x:1289,y:918,t:1527635539999};\\\", \\\"{x:1312,y:925,t:1527635540015};\\\", \\\"{x:1329,y:930,t:1527635540032};\\\", \\\"{x:1343,y:936,t:1527635540049};\\\", \\\"{x:1353,y:939,t:1527635540065};\\\", \\\"{x:1357,y:941,t:1527635540082};\\\", \\\"{x:1364,y:943,t:1527635540099};\\\", \\\"{x:1368,y:946,t:1527635540116};\\\", \\\"{x:1370,y:946,t:1527635540132};\\\", \\\"{x:1372,y:948,t:1527635540149};\\\", \\\"{x:1374,y:948,t:1527635540166};\\\", \\\"{x:1375,y:948,t:1527635540182};\\\", \\\"{x:1376,y:949,t:1527635540199};\\\", \\\"{x:1377,y:949,t:1527635540790};\\\", \\\"{x:1379,y:951,t:1527635540799};\\\", \\\"{x:1389,y:959,t:1527635540817};\\\", \\\"{x:1401,y:966,t:1527635540833};\\\", \\\"{x:1415,y:975,t:1527635540849};\\\", \\\"{x:1427,y:981,t:1527635540866};\\\", \\\"{x:1430,y:983,t:1527635540883};\\\", \\\"{x:1431,y:984,t:1527635540899};\\\", \\\"{x:1432,y:984,t:1527635540997};\\\", \\\"{x:1433,y:984,t:1527635541006};\\\", \\\"{x:1433,y:985,t:1527635541018};\\\", \\\"{x:1435,y:986,t:1527635541033};\\\", \\\"{x:1437,y:988,t:1527635541049};\\\", \\\"{x:1440,y:988,t:1527635541067};\\\", \\\"{x:1442,y:989,t:1527635541084};\\\", \\\"{x:1443,y:989,t:1527635541101};\\\", \\\"{x:1444,y:989,t:1527635541293};\\\", \\\"{x:1447,y:989,t:1527635541302};\\\", \\\"{x:1451,y:989,t:1527635541317};\\\", \\\"{x:1464,y:989,t:1527635541334};\\\", \\\"{x:1474,y:989,t:1527635541350};\\\", \\\"{x:1482,y:989,t:1527635541366};\\\", \\\"{x:1489,y:988,t:1527635541383};\\\", \\\"{x:1494,y:985,t:1527635541400};\\\", \\\"{x:1501,y:981,t:1527635541416};\\\", \\\"{x:1505,y:977,t:1527635541434};\\\", \\\"{x:1511,y:973,t:1527635541450};\\\", \\\"{x:1512,y:973,t:1527635541467};\\\", \\\"{x:1512,y:972,t:1527635541483};\\\", \\\"{x:1513,y:972,t:1527635541501};\\\", \\\"{x:1513,y:970,t:1527635541718};\\\", \\\"{x:1512,y:966,t:1527635541733};\\\", \\\"{x:1508,y:958,t:1527635541751};\\\", \\\"{x:1505,y:954,t:1527635541768};\\\", \\\"{x:1503,y:951,t:1527635541784};\\\", \\\"{x:1501,y:947,t:1527635541800};\\\", \\\"{x:1500,y:944,t:1527635541818};\\\", \\\"{x:1500,y:941,t:1527635541834};\\\", \\\"{x:1500,y:939,t:1527635541851};\\\", \\\"{x:1500,y:936,t:1527635541868};\\\", \\\"{x:1498,y:932,t:1527635541884};\\\", \\\"{x:1497,y:928,t:1527635541900};\\\", \\\"{x:1497,y:926,t:1527635541917};\\\", \\\"{x:1497,y:923,t:1527635541934};\\\", \\\"{x:1497,y:921,t:1527635541951};\\\", \\\"{x:1496,y:917,t:1527635541967};\\\", \\\"{x:1496,y:916,t:1527635541982};\\\", \\\"{x:1495,y:912,t:1527635542000};\\\", \\\"{x:1494,y:910,t:1527635542017};\\\", \\\"{x:1493,y:906,t:1527635542033};\\\", \\\"{x:1491,y:901,t:1527635542050};\\\", \\\"{x:1490,y:898,t:1527635542067};\\\", \\\"{x:1490,y:893,t:1527635542083};\\\", \\\"{x:1490,y:889,t:1527635542099};\\\", \\\"{x:1487,y:882,t:1527635542117};\\\", \\\"{x:1486,y:877,t:1527635542133};\\\", \\\"{x:1486,y:869,t:1527635542150};\\\", \\\"{x:1485,y:865,t:1527635542167};\\\", \\\"{x:1483,y:858,t:1527635542183};\\\", \\\"{x:1483,y:855,t:1527635542200};\\\", \\\"{x:1483,y:851,t:1527635542217};\\\", \\\"{x:1482,y:846,t:1527635542234};\\\", \\\"{x:1482,y:844,t:1527635542251};\\\", \\\"{x:1482,y:839,t:1527635542267};\\\", \\\"{x:1482,y:837,t:1527635542284};\\\", \\\"{x:1482,y:835,t:1527635542302};\\\", \\\"{x:1482,y:834,t:1527635542317};\\\", \\\"{x:1482,y:832,t:1527635542334};\\\", \\\"{x:1482,y:831,t:1527635542350};\\\", \\\"{x:1481,y:828,t:1527635542367};\\\", \\\"{x:1481,y:827,t:1527635542384};\\\", \\\"{x:1481,y:824,t:1527635542401};\\\", \\\"{x:1480,y:822,t:1527635542417};\\\", \\\"{x:1480,y:816,t:1527635542434};\\\", \\\"{x:1480,y:813,t:1527635542450};\\\", \\\"{x:1479,y:806,t:1527635542468};\\\", \\\"{x:1477,y:798,t:1527635542485};\\\", \\\"{x:1475,y:787,t:1527635542500};\\\", \\\"{x:1469,y:770,t:1527635542517};\\\", \\\"{x:1466,y:761,t:1527635542534};\\\", \\\"{x:1463,y:752,t:1527635542551};\\\", \\\"{x:1460,y:740,t:1527635542567};\\\", \\\"{x:1458,y:730,t:1527635542584};\\\", \\\"{x:1457,y:725,t:1527635542600};\\\", \\\"{x:1456,y:722,t:1527635542617};\\\", \\\"{x:1455,y:718,t:1527635542634};\\\", \\\"{x:1455,y:717,t:1527635542650};\\\", \\\"{x:1455,y:713,t:1527635542667};\\\", \\\"{x:1453,y:709,t:1527635542684};\\\", \\\"{x:1452,y:702,t:1527635542700};\\\", \\\"{x:1449,y:688,t:1527635542718};\\\", \\\"{x:1448,y:683,t:1527635542734};\\\", \\\"{x:1448,y:679,t:1527635542751};\\\", \\\"{x:1447,y:673,t:1527635542767};\\\", \\\"{x:1447,y:668,t:1527635542784};\\\", \\\"{x:1446,y:664,t:1527635542801};\\\", \\\"{x:1446,y:657,t:1527635542817};\\\", \\\"{x:1446,y:655,t:1527635542835};\\\", \\\"{x:1445,y:653,t:1527635542852};\\\", \\\"{x:1445,y:651,t:1527635542868};\\\", \\\"{x:1445,y:650,t:1527635542885};\\\", \\\"{x:1445,y:644,t:1527635542901};\\\", \\\"{x:1445,y:642,t:1527635542917};\\\", \\\"{x:1445,y:640,t:1527635542934};\\\", \\\"{x:1445,y:638,t:1527635542951};\\\", \\\"{x:1445,y:637,t:1527635542968};\\\", \\\"{x:1445,y:636,t:1527635542985};\\\", \\\"{x:1444,y:634,t:1527635543002};\\\", \\\"{x:1444,y:633,t:1527635543045};\\\", \\\"{x:1444,y:632,t:1527635543070};\\\", \\\"{x:1444,y:631,t:1527635543085};\\\", \\\"{x:1444,y:630,t:1527635543582};\\\", \\\"{x:1444,y:622,t:1527635543591};\\\", \\\"{x:1446,y:612,t:1527635543602};\\\", \\\"{x:1450,y:597,t:1527635543619};\\\", \\\"{x:1452,y:581,t:1527635543635};\\\", \\\"{x:1453,y:565,t:1527635543652};\\\", \\\"{x:1456,y:550,t:1527635543669};\\\", \\\"{x:1456,y:541,t:1527635543685};\\\", \\\"{x:1456,y:531,t:1527635543702};\\\", \\\"{x:1456,y:526,t:1527635543718};\\\", \\\"{x:1456,y:522,t:1527635543734};\\\", \\\"{x:1456,y:518,t:1527635543752};\\\", \\\"{x:1456,y:513,t:1527635543769};\\\", \\\"{x:1455,y:509,t:1527635543785};\\\", \\\"{x:1454,y:505,t:1527635543801};\\\", \\\"{x:1451,y:500,t:1527635543818};\\\", \\\"{x:1448,y:496,t:1527635543836};\\\", \\\"{x:1448,y:495,t:1527635543852};\\\", \\\"{x:1446,y:493,t:1527635543869};\\\", \\\"{x:1445,y:492,t:1527635543886};\\\", \\\"{x:1444,y:492,t:1527635543934};\\\", \\\"{x:1443,y:491,t:1527635543941};\\\", \\\"{x:1442,y:491,t:1527635543998};\\\", \\\"{x:1440,y:490,t:1527635544045};\\\", \\\"{x:1439,y:489,t:1527635544062};\\\", \\\"{x:1439,y:487,t:1527635544077};\\\", \\\"{x:1438,y:484,t:1527635544094};\\\", \\\"{x:1437,y:483,t:1527635544101};\\\", \\\"{x:1436,y:481,t:1527635544119};\\\", \\\"{x:1434,y:478,t:1527635544135};\\\", \\\"{x:1433,y:477,t:1527635544152};\\\", \\\"{x:1433,y:476,t:1527635544169};\\\", \\\"{x:1432,y:475,t:1527635544185};\\\", \\\"{x:1432,y:474,t:1527635544202};\\\", \\\"{x:1430,y:471,t:1527635544218};\\\", \\\"{x:1429,y:471,t:1527635544234};\\\", \\\"{x:1429,y:469,t:1527635544253};\\\", \\\"{x:1429,y:468,t:1527635544284};\\\", \\\"{x:1428,y:468,t:1527635544301};\\\", \\\"{x:1428,y:466,t:1527635544325};\\\", \\\"{x:1427,y:465,t:1527635544381};\\\", \\\"{x:1427,y:463,t:1527635544421};\\\", \\\"{x:1427,y:467,t:1527635544510};\\\", \\\"{x:1427,y:479,t:1527635544519};\\\", \\\"{x:1426,y:507,t:1527635544536};\\\", \\\"{x:1425,y:539,t:1527635544553};\\\", \\\"{x:1421,y:568,t:1527635544568};\\\", \\\"{x:1421,y:593,t:1527635544586};\\\", \\\"{x:1421,y:608,t:1527635544602};\\\", \\\"{x:1425,y:617,t:1527635544619};\\\", \\\"{x:1425,y:618,t:1527635544636};\\\", \\\"{x:1426,y:618,t:1527635544652};\\\", \\\"{x:1428,y:618,t:1527635544709};\\\", \\\"{x:1429,y:618,t:1527635544725};\\\", \\\"{x:1431,y:618,t:1527635544736};\\\", \\\"{x:1432,y:618,t:1527635544752};\\\", \\\"{x:1435,y:618,t:1527635544768};\\\", \\\"{x:1440,y:620,t:1527635544786};\\\", \\\"{x:1445,y:621,t:1527635544803};\\\", \\\"{x:1449,y:622,t:1527635544820};\\\", \\\"{x:1450,y:622,t:1527635544835};\\\", \\\"{x:1453,y:622,t:1527635544853};\\\", \\\"{x:1461,y:629,t:1527635544869};\\\", \\\"{x:1463,y:645,t:1527635544885};\\\", \\\"{x:1466,y:671,t:1527635544902};\\\", \\\"{x:1466,y:704,t:1527635544920};\\\", \\\"{x:1464,y:756,t:1527635544935};\\\", \\\"{x:1453,y:805,t:1527635544952};\\\", \\\"{x:1442,y:844,t:1527635544969};\\\", \\\"{x:1440,y:863,t:1527635544986};\\\", \\\"{x:1440,y:869,t:1527635545003};\\\", \\\"{x:1440,y:871,t:1527635545020};\\\", \\\"{x:1442,y:874,t:1527635545035};\\\", \\\"{x:1442,y:875,t:1527635545052};\\\", \\\"{x:1443,y:876,t:1527635545069};\\\", \\\"{x:1445,y:879,t:1527635545085};\\\", \\\"{x:1448,y:885,t:1527635545103};\\\", \\\"{x:1452,y:896,t:1527635545120};\\\", \\\"{x:1459,y:911,t:1527635545136};\\\", \\\"{x:1466,y:927,t:1527635545152};\\\", \\\"{x:1471,y:938,t:1527635545170};\\\", \\\"{x:1473,y:944,t:1527635545185};\\\", \\\"{x:1474,y:948,t:1527635545203};\\\", \\\"{x:1474,y:952,t:1527635545220};\\\", \\\"{x:1474,y:959,t:1527635545235};\\\", \\\"{x:1469,y:972,t:1527635545253};\\\", \\\"{x:1468,y:976,t:1527635545269};\\\", \\\"{x:1467,y:977,t:1527635545285};\\\", \\\"{x:1466,y:978,t:1527635545303};\\\", \\\"{x:1465,y:978,t:1527635545333};\\\", \\\"{x:1464,y:980,t:1527635545357};\\\", \\\"{x:1463,y:980,t:1527635545382};\\\", \\\"{x:1462,y:980,t:1527635545430};\\\", \\\"{x:1460,y:979,t:1527635545446};\\\", \\\"{x:1459,y:978,t:1527635545453};\\\", \\\"{x:1458,y:973,t:1527635545469};\\\", \\\"{x:1458,y:970,t:1527635545486};\\\", \\\"{x:1457,y:969,t:1527635545503};\\\", \\\"{x:1457,y:967,t:1527635545519};\\\", \\\"{x:1456,y:966,t:1527635545537};\\\", \\\"{x:1455,y:965,t:1527635545701};\\\", \\\"{x:1451,y:967,t:1527635545720};\\\", \\\"{x:1448,y:968,t:1527635545737};\\\", \\\"{x:1446,y:970,t:1527635545753};\\\", \\\"{x:1445,y:970,t:1527635545770};\\\", \\\"{x:1445,y:967,t:1527635545854};\\\", \\\"{x:1445,y:960,t:1527635545870};\\\", \\\"{x:1446,y:950,t:1527635545886};\\\", \\\"{x:1446,y:933,t:1527635545903};\\\", \\\"{x:1446,y:919,t:1527635545920};\\\", \\\"{x:1446,y:913,t:1527635545937};\\\", \\\"{x:1446,y:908,t:1527635545953};\\\", \\\"{x:1446,y:903,t:1527635545969};\\\", \\\"{x:1446,y:898,t:1527635545986};\\\", \\\"{x:1445,y:896,t:1527635546004};\\\", \\\"{x:1444,y:890,t:1527635546019};\\\", \\\"{x:1443,y:888,t:1527635546037};\\\", \\\"{x:1442,y:885,t:1527635546054};\\\", \\\"{x:1442,y:884,t:1527635546069};\\\", \\\"{x:1442,y:882,t:1527635546087};\\\", \\\"{x:1442,y:880,t:1527635546104};\\\", \\\"{x:1441,y:877,t:1527635546119};\\\", \\\"{x:1441,y:874,t:1527635546137};\\\", \\\"{x:1441,y:872,t:1527635546153};\\\", \\\"{x:1441,y:867,t:1527635546169};\\\", \\\"{x:1441,y:861,t:1527635546186};\\\", \\\"{x:1441,y:857,t:1527635546203};\\\", \\\"{x:1441,y:855,t:1527635546219};\\\", \\\"{x:1441,y:851,t:1527635546236};\\\", \\\"{x:1441,y:844,t:1527635546252};\\\", \\\"{x:1441,y:841,t:1527635546270};\\\", \\\"{x:1441,y:837,t:1527635546286};\\\", \\\"{x:1440,y:836,t:1527635546304};\\\", \\\"{x:1439,y:835,t:1527635546319};\\\", \\\"{x:1439,y:834,t:1527635546349};\\\", \\\"{x:1439,y:833,t:1527635546398};\\\", \\\"{x:1439,y:831,t:1527635546414};\\\", \\\"{x:1438,y:833,t:1527635546493};\\\", \\\"{x:1437,y:840,t:1527635546503};\\\", \\\"{x:1434,y:864,t:1527635546520};\\\", \\\"{x:1431,y:891,t:1527635546537};\\\", \\\"{x:1428,y:917,t:1527635546554};\\\", \\\"{x:1427,y:934,t:1527635546570};\\\", \\\"{x:1427,y:943,t:1527635546587};\\\", \\\"{x:1427,y:947,t:1527635546603};\\\", \\\"{x:1427,y:949,t:1527635546620};\\\", \\\"{x:1427,y:950,t:1527635546636};\\\", \\\"{x:1430,y:951,t:1527635546981};\\\", \\\"{x:1437,y:954,t:1527635546990};\\\", \\\"{x:1443,y:955,t:1527635547003};\\\", \\\"{x:1459,y:961,t:1527635547020};\\\", \\\"{x:1479,y:966,t:1527635547037};\\\", \\\"{x:1489,y:968,t:1527635547053};\\\", \\\"{x:1492,y:968,t:1527635547070};\\\", \\\"{x:1492,y:969,t:1527635547087};\\\", \\\"{x:1492,y:967,t:1527635547958};\\\", \\\"{x:1492,y:966,t:1527635547971};\\\", \\\"{x:1492,y:963,t:1527635547988};\\\", \\\"{x:1492,y:960,t:1527635548005};\\\", \\\"{x:1492,y:958,t:1527635548021};\\\", \\\"{x:1492,y:957,t:1527635548038};\\\", \\\"{x:1492,y:954,t:1527635548055};\\\", \\\"{x:1492,y:953,t:1527635548072};\\\", \\\"{x:1492,y:951,t:1527635548087};\\\", \\\"{x:1492,y:950,t:1527635548104};\\\", \\\"{x:1492,y:949,t:1527635548122};\\\", \\\"{x:1492,y:948,t:1527635548138};\\\", \\\"{x:1492,y:947,t:1527635548155};\\\", \\\"{x:1492,y:945,t:1527635548172};\\\", \\\"{x:1492,y:944,t:1527635548188};\\\", \\\"{x:1492,y:941,t:1527635548205};\\\", \\\"{x:1491,y:938,t:1527635548222};\\\", \\\"{x:1491,y:937,t:1527635548238};\\\", \\\"{x:1491,y:940,t:1527635548333};\\\", \\\"{x:1491,y:946,t:1527635548341};\\\", \\\"{x:1491,y:951,t:1527635548355};\\\", \\\"{x:1492,y:957,t:1527635548371};\\\", \\\"{x:1493,y:959,t:1527635548388};\\\", \\\"{x:1493,y:961,t:1527635548405};\\\", \\\"{x:1493,y:962,t:1527635548462};\\\", \\\"{x:1492,y:962,t:1527635548485};\\\", \\\"{x:1491,y:962,t:1527635548509};\\\", \\\"{x:1489,y:962,t:1527635548590};\\\", \\\"{x:1487,y:961,t:1527635548605};\\\", \\\"{x:1485,y:955,t:1527635548621};\\\", \\\"{x:1484,y:946,t:1527635548639};\\\", \\\"{x:1483,y:938,t:1527635548654};\\\", \\\"{x:1481,y:928,t:1527635548672};\\\", \\\"{x:1480,y:918,t:1527635548689};\\\", \\\"{x:1478,y:904,t:1527635548705};\\\", \\\"{x:1476,y:887,t:1527635548722};\\\", \\\"{x:1475,y:874,t:1527635548739};\\\", \\\"{x:1474,y:865,t:1527635548754};\\\", \\\"{x:1473,y:860,t:1527635548772};\\\", \\\"{x:1472,y:853,t:1527635548789};\\\", \\\"{x:1471,y:849,t:1527635548805};\\\", \\\"{x:1471,y:844,t:1527635548822};\\\", \\\"{x:1470,y:843,t:1527635548839};\\\", \\\"{x:1470,y:841,t:1527635548855};\\\", \\\"{x:1470,y:839,t:1527635548872};\\\", \\\"{x:1470,y:837,t:1527635548889};\\\", \\\"{x:1471,y:836,t:1527635548905};\\\", \\\"{x:1472,y:834,t:1527635548921};\\\", \\\"{x:1472,y:832,t:1527635548939};\\\", \\\"{x:1472,y:829,t:1527635548954};\\\", \\\"{x:1474,y:827,t:1527635548972};\\\", \\\"{x:1474,y:823,t:1527635548989};\\\", \\\"{x:1475,y:819,t:1527635549006};\\\", \\\"{x:1476,y:815,t:1527635549022};\\\", \\\"{x:1478,y:811,t:1527635549039};\\\", \\\"{x:1478,y:808,t:1527635549056};\\\", \\\"{x:1478,y:806,t:1527635549072};\\\", \\\"{x:1479,y:805,t:1527635549089};\\\", \\\"{x:1479,y:804,t:1527635549106};\\\", \\\"{x:1479,y:801,t:1527635549122};\\\", \\\"{x:1479,y:799,t:1527635549139};\\\", \\\"{x:1479,y:795,t:1527635549156};\\\", \\\"{x:1479,y:792,t:1527635549172};\\\", \\\"{x:1479,y:787,t:1527635549189};\\\", \\\"{x:1479,y:776,t:1527635549206};\\\", \\\"{x:1479,y:769,t:1527635549222};\\\", \\\"{x:1479,y:763,t:1527635549239};\\\", \\\"{x:1479,y:756,t:1527635549256};\\\", \\\"{x:1478,y:753,t:1527635549272};\\\", \\\"{x:1478,y:749,t:1527635549289};\\\", \\\"{x:1476,y:746,t:1527635549306};\\\", \\\"{x:1475,y:742,t:1527635549322};\\\", \\\"{x:1475,y:741,t:1527635549342};\\\", \\\"{x:1475,y:740,t:1527635549365};\\\", \\\"{x:1474,y:739,t:1527635549381};\\\", \\\"{x:1474,y:738,t:1527635549413};\\\", \\\"{x:1474,y:737,t:1527635549429};\\\", \\\"{x:1474,y:735,t:1527635549439};\\\", \\\"{x:1474,y:733,t:1527635549462};\\\", \\\"{x:1474,y:732,t:1527635549473};\\\", \\\"{x:1474,y:730,t:1527635549489};\\\", \\\"{x:1474,y:726,t:1527635549506};\\\", \\\"{x:1473,y:723,t:1527635549523};\\\", \\\"{x:1472,y:719,t:1527635549539};\\\", \\\"{x:1472,y:716,t:1527635549555};\\\", \\\"{x:1471,y:712,t:1527635549573};\\\", \\\"{x:1470,y:710,t:1527635549589};\\\", \\\"{x:1470,y:705,t:1527635549606};\\\", \\\"{x:1470,y:702,t:1527635549623};\\\", \\\"{x:1470,y:698,t:1527635549639};\\\", \\\"{x:1470,y:694,t:1527635549656};\\\", \\\"{x:1470,y:689,t:1527635549673};\\\", \\\"{x:1470,y:682,t:1527635549689};\\\", \\\"{x:1470,y:675,t:1527635549706};\\\", \\\"{x:1472,y:667,t:1527635549723};\\\", \\\"{x:1473,y:662,t:1527635549738};\\\", \\\"{x:1474,y:658,t:1527635549756};\\\", \\\"{x:1475,y:653,t:1527635549773};\\\", \\\"{x:1476,y:650,t:1527635549789};\\\", \\\"{x:1479,y:641,t:1527635549805};\\\", \\\"{x:1479,y:636,t:1527635549823};\\\", \\\"{x:1481,y:630,t:1527635549839};\\\", \\\"{x:1482,y:627,t:1527635549855};\\\", \\\"{x:1483,y:625,t:1527635549872};\\\", \\\"{x:1484,y:621,t:1527635549888};\\\", \\\"{x:1485,y:618,t:1527635549905};\\\", \\\"{x:1486,y:615,t:1527635549922};\\\", \\\"{x:1487,y:612,t:1527635549938};\\\", \\\"{x:1487,y:608,t:1527635549956};\\\", \\\"{x:1487,y:604,t:1527635549972};\\\", \\\"{x:1487,y:602,t:1527635549988};\\\", \\\"{x:1488,y:598,t:1527635550005};\\\", \\\"{x:1488,y:595,t:1527635550022};\\\", \\\"{x:1488,y:592,t:1527635550040};\\\", \\\"{x:1488,y:589,t:1527635550055};\\\", \\\"{x:1488,y:587,t:1527635550073};\\\", \\\"{x:1488,y:584,t:1527635550089};\\\", \\\"{x:1488,y:580,t:1527635550106};\\\", \\\"{x:1488,y:577,t:1527635550121};\\\", \\\"{x:1488,y:574,t:1527635550139};\\\", \\\"{x:1488,y:570,t:1527635550155};\\\", \\\"{x:1488,y:562,t:1527635550173};\\\", \\\"{x:1488,y:555,t:1527635550188};\\\", \\\"{x:1488,y:548,t:1527635550205};\\\", \\\"{x:1488,y:541,t:1527635550223};\\\", \\\"{x:1488,y:530,t:1527635550239};\\\", \\\"{x:1488,y:522,t:1527635550255};\\\", \\\"{x:1490,y:513,t:1527635550272};\\\", \\\"{x:1490,y:500,t:1527635550289};\\\", \\\"{x:1490,y:490,t:1527635550306};\\\", \\\"{x:1491,y:481,t:1527635550322};\\\", \\\"{x:1492,y:474,t:1527635550339};\\\", \\\"{x:1492,y:471,t:1527635550355};\\\", \\\"{x:1492,y:466,t:1527635550373};\\\", \\\"{x:1491,y:460,t:1527635550389};\\\", \\\"{x:1490,y:458,t:1527635550405};\\\", \\\"{x:1490,y:456,t:1527635550422};\\\", \\\"{x:1490,y:452,t:1527635550440};\\\", \\\"{x:1490,y:449,t:1527635550456};\\\", \\\"{x:1489,y:445,t:1527635550472};\\\", \\\"{x:1489,y:443,t:1527635550490};\\\", \\\"{x:1489,y:441,t:1527635550506};\\\", \\\"{x:1489,y:440,t:1527635550522};\\\", \\\"{x:1489,y:439,t:1527635550540};\\\", \\\"{x:1489,y:438,t:1527635550557};\\\", \\\"{x:1489,y:437,t:1527635550573};\\\", \\\"{x:1488,y:437,t:1527635550630};\\\", \\\"{x:1486,y:446,t:1527635550640};\\\", \\\"{x:1479,y:474,t:1527635550657};\\\", \\\"{x:1457,y:532,t:1527635550673};\\\", \\\"{x:1415,y:631,t:1527635550689};\\\", \\\"{x:1374,y:727,t:1527635550707};\\\", \\\"{x:1323,y:810,t:1527635550723};\\\", \\\"{x:1283,y:859,t:1527635550740};\\\", \\\"{x:1249,y:883,t:1527635550757};\\\", \\\"{x:1233,y:888,t:1527635550773};\\\", \\\"{x:1215,y:890,t:1527635550789};\\\", \\\"{x:1190,y:890,t:1527635550807};\\\", \\\"{x:1147,y:890,t:1527635550823};\\\", \\\"{x:1064,y:871,t:1527635550839};\\\", \\\"{x:965,y:843,t:1527635550857};\\\", \\\"{x:847,y:814,t:1527635550872};\\\", \\\"{x:733,y:781,t:1527635550890};\\\", \\\"{x:633,y:753,t:1527635550906};\\\", \\\"{x:550,y:727,t:1527635550923};\\\", \\\"{x:488,y:708,t:1527635550939};\\\", \\\"{x:454,y:696,t:1527635550957};\\\", \\\"{x:454,y:695,t:1527635550997};\\\", \\\"{x:453,y:694,t:1527635551007};\\\", \\\"{x:453,y:689,t:1527635551024};\\\", \\\"{x:453,y:678,t:1527635551041};\\\", \\\"{x:453,y:663,t:1527635551056};\\\", \\\"{x:453,y:649,t:1527635551074};\\\", \\\"{x:453,y:630,t:1527635551091};\\\", \\\"{x:452,y:618,t:1527635551107};\\\", \\\"{x:451,y:602,t:1527635551124};\\\", \\\"{x:451,y:596,t:1527635551141};\\\", \\\"{x:451,y:592,t:1527635551157};\\\", \\\"{x:451,y:591,t:1527635551174};\\\", \\\"{x:451,y:590,t:1527635551192};\\\", \\\"{x:452,y:590,t:1527635551208};\\\", \\\"{x:458,y:590,t:1527635551225};\\\", \\\"{x:473,y:591,t:1527635551241};\\\", \\\"{x:501,y:598,t:1527635551260};\\\", \\\"{x:532,y:607,t:1527635551274};\\\", \\\"{x:556,y:613,t:1527635551292};\\\", \\\"{x:585,y:617,t:1527635551309};\\\", \\\"{x:591,y:619,t:1527635551324};\\\", \\\"{x:594,y:619,t:1527635551397};\\\", \\\"{x:595,y:618,t:1527635551412};\\\", \\\"{x:596,y:616,t:1527635551425};\\\", \\\"{x:600,y:611,t:1527635551442};\\\", \\\"{x:603,y:605,t:1527635551459};\\\", \\\"{x:607,y:600,t:1527635551474};\\\", \\\"{x:608,y:596,t:1527635551491};\\\", \\\"{x:610,y:591,t:1527635551508};\\\", \\\"{x:611,y:588,t:1527635551524};\\\", \\\"{x:609,y:587,t:1527635551804};\\\", \\\"{x:595,y:587,t:1527635551812};\\\", \\\"{x:580,y:587,t:1527635551825};\\\", \\\"{x:535,y:587,t:1527635551841};\\\", \\\"{x:488,y:587,t:1527635551858};\\\", \\\"{x:435,y:587,t:1527635551875};\\\", \\\"{x:390,y:587,t:1527635551891};\\\", \\\"{x:351,y:587,t:1527635551908};\\\", \\\"{x:337,y:587,t:1527635551925};\\\", \\\"{x:331,y:587,t:1527635551941};\\\", \\\"{x:329,y:587,t:1527635551964};\\\", \\\"{x:335,y:587,t:1527635552109};\\\", \\\"{x:345,y:587,t:1527635552125};\\\", \\\"{x:354,y:585,t:1527635552142};\\\", \\\"{x:358,y:585,t:1527635552159};\\\", \\\"{x:361,y:585,t:1527635552176};\\\", \\\"{x:362,y:585,t:1527635552389};\\\", \\\"{x:363,y:585,t:1527635552397};\\\", \\\"{x:364,y:585,t:1527635552409};\\\", \\\"{x:368,y:589,t:1527635552426};\\\", \\\"{x:376,y:600,t:1527635552444};\\\", \\\"{x:382,y:613,t:1527635552460};\\\", \\\"{x:392,y:630,t:1527635552476};\\\", \\\"{x:408,y:650,t:1527635552493};\\\", \\\"{x:417,y:658,t:1527635552508};\\\", \\\"{x:421,y:660,t:1527635552525};\\\", \\\"{x:422,y:660,t:1527635552542};\\\", \\\"{x:424,y:663,t:1527635552559};\\\", \\\"{x:428,y:669,t:1527635552575};\\\", \\\"{x:432,y:676,t:1527635552592};\\\", \\\"{x:434,y:680,t:1527635552609};\\\", \\\"{x:435,y:680,t:1527635552625};\\\", \\\"{x:436,y:680,t:1527635552677};\\\", \\\"{x:434,y:670,t:1527635552692};\\\", \\\"{x:428,y:649,t:1527635552710};\\\", \\\"{x:425,y:628,t:1527635552727};\\\", \\\"{x:420,y:607,t:1527635552743};\\\", \\\"{x:417,y:598,t:1527635552759};\\\", \\\"{x:415,y:594,t:1527635552775};\\\", \\\"{x:415,y:593,t:1527635552793};\\\", \\\"{x:415,y:592,t:1527635552894};\\\", \\\"{x:415,y:596,t:1527635553076};\\\", \\\"{x:417,y:614,t:1527635553093};\\\", \\\"{x:420,y:636,t:1527635553109};\\\", \\\"{x:427,y:661,t:1527635553127};\\\", \\\"{x:442,y:700,t:1527635553143};\\\", \\\"{x:468,y:748,t:1527635553160};\\\", \\\"{x:501,y:789,t:1527635553177};\\\", \\\"{x:526,y:810,t:1527635553193};\\\", \\\"{x:544,y:823,t:1527635553209};\\\", \\\"{x:551,y:828,t:1527635553226};\\\", \\\"{x:552,y:828,t:1527635553242};\\\", \\\"{x:554,y:828,t:1527635553293};\\\", \\\"{x:556,y:819,t:1527635553310};\\\", \\\"{x:557,y:809,t:1527635553327};\\\", \\\"{x:557,y:796,t:1527635553343};\\\", \\\"{x:557,y:782,t:1527635553360};\\\", \\\"{x:556,y:772,t:1527635553377};\\\", \\\"{x:552,y:761,t:1527635553394};\\\", \\\"{x:551,y:758,t:1527635553409};\\\", \\\"{x:550,y:758,t:1527635553628};\\\", \\\"{x:549,y:760,t:1527635553643};\\\", \\\"{x:548,y:761,t:1527635553659};\\\", \\\"{x:549,y:761,t:1527635554245};\\\", \\\"{x:554,y:758,t:1527635554260};\\\", \\\"{x:572,y:752,t:1527635554277};\\\", \\\"{x:582,y:748,t:1527635554294};\\\", \\\"{x:586,y:747,t:1527635554310};\\\", \\\"{x:589,y:745,t:1527635554327};\\\", \\\"{x:593,y:743,t:1527635554343};\\\", \\\"{x:597,y:740,t:1527635554361};\\\", \\\"{x:599,y:738,t:1527635554378};\\\", \\\"{x:601,y:736,t:1527635554395};\\\", \\\"{x:604,y:732,t:1527635554410};\\\", \\\"{x:606,y:730,t:1527635554428};\\\", \\\"{x:607,y:728,t:1527635554445};\\\", \\\"{x:607,y:727,t:1527635554461};\\\" ] }, { \\\"rt\\\": 72762, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 646877, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"93XU7\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"Each shift starts at 8am to 8pm and we look at the start and end time, specifically at 12. We noticed that B and F are lined up, making them the start\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 10597, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"22\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"America \\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 658481, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"93XU7\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 14820, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Third\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Biomedical & Health Sciences\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 674322, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"93XU7\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 56696, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 732354, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"93XU7\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"tango\\\", \\\"condition\\\": \\\"113\\\" } ]\",\"parentNode\":{\"id\":2773}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"93XU7\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"line\",\"attributes\":{\"x1\":\"400\",\"x2\":\"0\",\"y1\":\"0\",\"y2\":\"800\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-65) translate(-200,280)\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2412,\"textContent\":\"DURATION (in hours)\"}]}]},{\"nodeType\":1,\"id\":2413,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2414,\"tagName\":\"text\",\"attributes\":{\"x\":\"-1.6666666666666714\",\"y\":\"738.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2415,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2416,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2417,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"33.33333333333333\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"text\",\"attributes\":{\"x\":\"31.666666666666657\",\"y\":\"671.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2420,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2421,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2422,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"66.66666666666666\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2423,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"x\":\"65\",\"y\":\"605\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"100\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2428,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2429,\"tagName\":\"text\",\"attributes\":{\"x\":\"98.33333333333331\",\"y\":\"538.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2430,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2431,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2432,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"133.33333333333331\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2433,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2434,\"tagName\":\"text\",\"attributes\":{\"x\":\"131.66666666666669\",\"y\":\"471.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2435,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2436,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2437,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"166.66666666666669\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"text\",\"attributes\":{\"x\":\"165\",\"y\":\"405\"},\"childNodes\":[{\"nodeType\":3,\"id\":2440,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2441,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2442,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"200\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2443,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"x\":\"198.33333333333334\",\"y\":\"338.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"233.33333333333334\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2448,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2449,\"tagName\":\"text\",\"attributes\":{\"x\":\"231.66666666666663\",\"y\":\"271.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2450,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2451,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2452,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"266.66666666666663\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2453,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2454,\"tagName\":\"text\",\"attributes\":{\"x\":\"265\",\"y\":\"205\"},\"childNodes\":[{\"nodeType\":3,\"id\":2455,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2456,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2457,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"300\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"text\",\"attributes\":{\"x\":\"298.33333333333337\",\"y\":\"138.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2460,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2461,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2462,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"333.33333333333337\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2463,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2464,\"tagName\":\"text\",\"attributes\":{\"x\":\"331.66666666666663\",\"y\":\"71.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2465,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"366.66666666666663\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"text\",\"attributes\":{\"x\":\"365\",\"y\":\"5\"},\"childNodes\":[{\"nodeType\":3,\"id\":2470,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2471,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2472,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2473,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"766.6666666666667\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"733.3333333333333\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"700\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"666.6666666666667\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"633.3333333333333\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"600\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"566.6666666666667\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"533.3333333333333\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"500\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2492,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"466.6666666666667\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2494,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"433.3333333333333\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2496,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2498,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2515,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2516,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2517,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2519,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2520,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2521,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2523,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2588,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2589,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2590,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2591,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2592,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2593,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2594,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2595,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2596,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2597,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2598},{\"nodeType\":3,\"id\":2599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2600,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2601,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2602,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2603,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 253, dom: 729, initialDom: 786",
  "javascriptErrors": []
}