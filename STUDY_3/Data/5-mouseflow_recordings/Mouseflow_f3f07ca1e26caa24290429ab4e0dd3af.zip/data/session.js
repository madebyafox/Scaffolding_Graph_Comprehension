var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "f3f07ca1e26caa24290429ab4e0dd3af",
  "created": "2018-05-24T12:05:44.4541348-07:00",
  "lastActivity": "2018-05-24T12:06:02.5405545-07:00",
  "pageViews": [
    {
      "id": "05244448035573534a9b3b98d6960ecf713957d5",
      "startTime": "2018-05-24T12:05:44.6295545-07:00",
      "endTime": "2018-05-24T12:06:02.5405545-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/3",
      "visitTime": 17911,
      "engagementTime": 17822,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 17911,
  "engagementTime": 17822,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.33",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=X66XB",
    "CONDITION=113",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "a157ee5d376bebe4280383ed6c04bafc",
  "gdpr": false
}