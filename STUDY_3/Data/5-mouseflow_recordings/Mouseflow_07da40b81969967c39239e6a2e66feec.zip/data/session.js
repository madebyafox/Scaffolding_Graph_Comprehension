var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "07da40b81969967c39239e6a2e66feec",
  "created": "2018-05-31T12:20:06.7984546-07:00",
  "lastActivity": "2018-05-31T12:21:06.1434546-07:00",
  "pageViews": [
    {
      "id": "0531067262bedaf98541c0b9d5d3aacc86fb788d",
      "startTime": "2018-05-31T12:20:06.7984546-07:00",
      "endTime": "2018-05-31T12:21:06.1434546-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/14",
      "visitTime": 59345,
      "engagementTime": 19640,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 59345,
  "engagementTime": 19640,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.30",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "67.0.3396.62",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=03QKB",
    "CONDITION=115",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "8acba3d341bdec4beb359548acdd0b2d",
  "gdpr": false
}