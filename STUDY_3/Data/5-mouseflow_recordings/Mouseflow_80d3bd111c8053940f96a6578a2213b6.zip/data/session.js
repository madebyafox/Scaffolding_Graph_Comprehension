var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "80d3bd111c8053940f96a6578a2213b6",
  "created": "2018-05-21T12:54:03.5444966-07:00",
  "lastActivity": "2018-05-21T12:54:23.3795967-07:00",
  "pageViews": [
    {
      "id": "052103832b12962b98a93aa03793534142598723",
      "startTime": "2018-05-21T12:54:03.5444966-07:00",
      "endTime": "2018-05-21T12:54:23.3795967-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/2",
      "visitTime": 19966,
      "engagementTime": 19950,
      "scroll": 99.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 19966,
  "engagementTime": 19950,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.9.248",
  "lang": "en-us",
  "userAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/604.5.6 (KHTML, like Gecko) Version/11.0.3 Safari/604.5.6",
  "browser": "Safari",
  "browserVersion": "11.0.3",
  "os": "OS X",
  "osVersion": "10.11 El Capitan",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1440x900",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=WQKT9",
    "CONDITION=121"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "dd400285924bd95f9cff7f8820eef0b3",
  "gdpr": false
}