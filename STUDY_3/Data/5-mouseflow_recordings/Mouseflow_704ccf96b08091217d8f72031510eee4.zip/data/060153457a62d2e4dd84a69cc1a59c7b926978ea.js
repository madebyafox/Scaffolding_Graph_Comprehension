var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["060153457a62d2e4dd84a69cc1a59c7b926978ea"] = {
  "startTime": "2018-06-01T18:13:53.3803407Z",
  "websitePageUrl": "/16",
  "visitTime": 117880,
  "engagementTime": 117629,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "704ccf96b08091217d8f72031510eee4",
    "created": "2018-06-01T18:13:53.2864871+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=DJRH1",
      "CONDITION=311"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "0d03f59fd11b1035e760957b68909b61",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/704ccf96b08091217d8f72031510eee4/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 209,
      "e": 209,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 209,
      "e": 209,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 900,
      "e": 900,
      "ty": 2,
      "x": 455,
      "y": 692
    },
    {
      "t": 903,
      "e": 903,
      "ty": 6,
      "x": 442,
      "y": 668,
      "ta": "#strategyButton"
    },
    {
      "t": 920,
      "e": 920,
      "ty": 7,
      "x": 430,
      "y": 630,
      "ta": "#strategyButton"
    },
    {
      "t": 936,
      "e": 936,
      "ty": 6,
      "x": 420,
      "y": 596,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 2,
      "x": 414,
      "y": 568
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 41,
      "x": 35623,
      "y": 36623,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1100,
      "e": 1100,
      "ty": 2,
      "x": 414,
      "y": 557
    },
    {
      "t": 1250,
      "e": 1250,
      "ty": 41,
      "x": 35623,
      "y": 27723,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2189,
      "e": 2189,
      "ty": 3,
      "x": 414,
      "y": 557,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2190,
      "e": 2190,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2309,
      "e": 2309,
      "ty": 4,
      "x": 35623,
      "y": 27723,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2309,
      "e": 2309,
      "ty": 5,
      "x": 414,
      "y": 557,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3100,
      "e": 3100,
      "ty": 2,
      "x": 418,
      "y": 552
    },
    {
      "t": 3201,
      "e": 3201,
      "ty": 2,
      "x": 431,
      "y": 532
    },
    {
      "t": 3251,
      "e": 3251,
      "ty": 41,
      "x": 37534,
      "y": 6687,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3301,
      "e": 3301,
      "ty": 2,
      "x": 432,
      "y": 528
    },
    {
      "t": 3371,
      "e": 3371,
      "ty": 7,
      "x": 442,
      "y": 521,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3401,
      "e": 3401,
      "ty": 2,
      "x": 447,
      "y": 520
    },
    {
      "t": 3500,
      "e": 3500,
      "ty": 2,
      "x": 458,
      "y": 515
    },
    {
      "t": 3500,
      "e": 3500,
      "ty": 41,
      "x": 40569,
      "y": 47432,
      "ta": "#.strategy > p"
    },
    {
      "t": 3600,
      "e": 3600,
      "ty": 2,
      "x": 460,
      "y": 514
    },
    {
      "t": 3700,
      "e": 3700,
      "ty": 2,
      "x": 479,
      "y": 514
    },
    {
      "t": 3750,
      "e": 3750,
      "ty": 41,
      "x": 45290,
      "y": 45091,
      "ta": "#.strategy > p"
    },
    {
      "t": 3801,
      "e": 3801,
      "ty": 2,
      "x": 527,
      "y": 516
    },
    {
      "t": 3901,
      "e": 3901,
      "ty": 2,
      "x": 552,
      "y": 520
    },
    {
      "t": 4000,
      "e": 4000,
      "ty": 41,
      "x": 51135,
      "y": 59135,
      "ta": "#.strategy > p"
    },
    {
      "t": 6841,
      "e": 6841,
      "ty": 6,
      "x": 550,
      "y": 523,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6900,
      "e": 6900,
      "ty": 2,
      "x": 546,
      "y": 568
    },
    {
      "t": 7001,
      "e": 7001,
      "ty": 2,
      "x": 552,
      "y": 584
    },
    {
      "t": 7001,
      "e": 7001,
      "ty": 41,
      "x": 51135,
      "y": 49568,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8194,
      "e": 8194,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 8194,
      "e": 8194,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8249,
      "e": 8249,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 8249,
      "e": 8249,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8297,
      "e": 8297,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 8297,
      "e": 8297,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8321,
      "e": 8321,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "FIN"
    },
    {
      "t": 8370,
      "e": 8370,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "FIN"
    },
    {
      "t": 8409,
      "e": 8409,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "FIN"
    },
    {
      "t": 8594,
      "e": 8594,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 8594,
      "e": 8594,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8689,
      "e": 8689,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "FIND"
    },
    {
      "t": 8705,
      "e": 8705,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 8705,
      "e": 8705,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8862,
      "e": 8862,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 9593,
      "e": 9593,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 9594,
      "e": 9594,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9641,
      "e": 9641,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 9641,
      "e": 9641,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9689,
      "e": 9689,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 9762,
      "e": 9762,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 9777,
      "e": 9777,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 9778,
      "e": 9778,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9906,
      "e": 9906,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10673,
      "e": 10673,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 10737,
      "e": 10737,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "FIND 12"
    },
    {
      "t": 11113,
      "e": 11113,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 11113,
      "e": 11113,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11209,
      "e": 11209,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 11209,
      "e": 11209,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11249,
      "e": 11249,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||PM"
    },
    {
      "t": 11290,
      "e": 11290,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 11402,
      "e": 11402,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "FIND 12PM"
    },
    {
      "t": 11641,
      "e": 11641,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11642,
      "e": 11642,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11753,
      "e": 11753,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 11865,
      "e": 11865,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 11866,
      "e": 11866,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11921,
      "e": 11921,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 11921,
      "e": 11921,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11953,
      "e": 11953,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11953,
      "e": 11953,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11985,
      "e": 11985,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ON "
    },
    {
      "t": 12041,
      "e": 12041,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12089,
      "e": 12089,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12185,
      "e": 12185,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 12185,
      "e": 12185,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12225,
      "e": 12225,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 12225,
      "e": 12225,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12289,
      "e": 12289,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||TH"
    },
    {
      "t": 12313,
      "e": 12313,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 12313,
      "e": 12313,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12340,
      "e": 12340,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||E"
    },
    {
      "t": 12381,
      "e": 12381,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12381,
      "e": 12381,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12445,
      "e": 12445,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 12460,
      "e": 12460,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12565,
      "e": 12565,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 12565,
      "e": 12565,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12660,
      "e": 12660,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||S"
    },
    {
      "t": 12916,
      "e": 12916,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13012,
      "e": 13012,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "FIND 12PM ON THE "
    },
    {
      "t": 13020,
      "e": 13020,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 13020,
      "e": 13020,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13021,
      "e": 13021,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "90"
    },
    {
      "t": 13021,
      "e": 13021,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13077,
      "e": 13077,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||XZ"
    },
    {
      "t": 13093,
      "e": 13093,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13206,
      "e": 13206,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "FIND 12PM ON THE XZ"
    },
    {
      "t": 13580,
      "e": 13580,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13668,
      "e": 13668,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "FIND 12PM ON THE X"
    },
    {
      "t": 13901,
      "e": 13901,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13901,
      "e": 13901,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14006,
      "e": 14006,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "FIND 12PM ON THE X "
    },
    {
      "t": 14013,
      "e": 14013,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 14084,
      "e": 14084,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 14085,
      "e": 14085,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14196,
      "e": 14196,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||A"
    },
    {
      "t": 14196,
      "e": 14196,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 14196,
      "e": 14196,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14284,
      "e": 14284,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||S"
    },
    {
      "t": 14285,
      "e": 14285,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 14285,
      "e": 14285,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14364,
      "e": 14364,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||I"
    },
    {
      "t": 14781,
      "e": 14781,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 14861,
      "e": 14861,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "FIND 12PM ON THE X AS"
    },
    {
      "t": 14916,
      "e": 14916,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 14988,
      "e": 14988,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "FIND 12PM ON THE X A"
    },
    {
      "t": 15053,
      "e": 15053,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15116,
      "e": 15116,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "FIND 12PM ON THE X "
    },
    {
      "t": 15181,
      "e": 15181,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15244,
      "e": 15244,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "FIND 12PM ON THE X"
    },
    {
      "t": 15308,
      "e": 15308,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 15388,
      "e": 15388,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "FIND 12PM ON THE "
    },
    {
      "t": 16068,
      "e": 16068,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 16069,
      "e": 16069,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16132,
      "e": 16132,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 16133,
      "e": 16133,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16188,
      "e": 16188,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||HO"
    },
    {
      "t": 16268,
      "e": 16268,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16276,
      "e": 16276,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 16276,
      "e": 16276,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16405,
      "e": 16405,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "FIND 12PM ON THE HOR"
    },
    {
      "t": 16413,
      "e": 16413,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||R"
    },
    {
      "t": 16692,
      "e": 16692,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 16693,
      "e": 16693,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16788,
      "e": 16788,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||I"
    },
    {
      "t": 16909,
      "e": 16909,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "90"
    },
    {
      "t": 16909,
      "e": 16909,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17029,
      "e": 17029,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||Z"
    },
    {
      "t": 17132,
      "e": 17132,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 17132,
      "e": 17132,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17212,
      "e": 17212,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 17212,
      "e": 17212,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17276,
      "e": 17276,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ON"
    },
    {
      "t": 17325,
      "e": 17325,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17516,
      "e": 17516,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 17516,
      "e": 17516,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17580,
      "e": 17580,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 17580,
      "e": 17580,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17637,
      "e": 17637,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 17637,
      "e": 17637,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17652,
      "e": 17652,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||TAL"
    },
    {
      "t": 17701,
      "e": 17701,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17716,
      "e": 17716,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17884,
      "e": 17884,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17884,
      "e": 17884,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17980,
      "e": 17980,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18037,
      "e": 18037,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 18037,
      "e": 18037,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18132,
      "e": 18132,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||A"
    },
    {
      "t": 18236,
      "e": 18236,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 18237,
      "e": 18237,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18365,
      "e": 18365,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||X"
    },
    {
      "t": 18405,
      "e": 18405,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 18405,
      "e": 18405,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18460,
      "e": 18460,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||I"
    },
    {
      "t": 18500,
      "e": 18500,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 18500,
      "e": 18500,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18556,
      "e": 18556,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||S"
    },
    {
      "t": 18564,
      "e": 18564,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18564,
      "e": 18564,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18668,
      "e": 18668,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18708,
      "e": 18708,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 18708,
      "e": 18708,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18804,
      "e": 18804,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||O"
    },
    {
      "t": 18837,
      "e": 18837,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 18837,
      "e": 18837,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18924,
      "e": 18924,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18924,
      "e": 18924,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18956,
      "e": 18956,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||F "
    },
    {
      "t": 19012,
      "e": 19012,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19140,
      "e": 19140,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 19141,
      "e": 19141,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19220,
      "e": 19220,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 19724,
      "e": 19724,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 19804,
      "e": 19804,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "FIND 12PM ON THE HORIZONTAL AXIS OF "
    },
    {
      "t": 19812,
      "e": 19812,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 19813,
      "e": 19813,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19885,
      "e": 19885,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||G"
    },
    {
      "t": 19972,
      "e": 19972,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 19972,
      "e": 19972,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20044,
      "e": 20044,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 20044,
      "e": 20044,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20093,
      "e": 20093,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 20093,
      "e": 20093,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20100,
      "e": 20100,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||RAP"
    },
    {
      "t": 20156,
      "e": 20156,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20181,
      "e": 20181,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 20181,
      "e": 20181,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20260,
      "e": 20260,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20261,
      "e": 20261,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20284,
      "e": 20284,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||H "
    },
    {
      "t": 20325,
      "e": 20325,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20420,
      "e": 20420,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20660,
      "e": 20660,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 20660,
      "e": 20660,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20740,
      "e": 20740,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 20740,
      "e": 20740,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20772,
      "e": 20772,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||AN"
    },
    {
      "t": 20805,
      "e": 20805,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20812,
      "e": 20812,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 20812,
      "e": 20812,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20908,
      "e": 20908,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20909,
      "e": 20909,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20941,
      "e": 20941,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||D "
    },
    {
      "t": 20997,
      "e": 20997,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21412,
      "e": 21412,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 21413,
      "e": 21413,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21476,
      "e": 21476,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 21476,
      "e": 21476,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21549,
      "e": 21549,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||FO"
    },
    {
      "t": 21557,
      "e": 21557,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21636,
      "e": 21636,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 21636,
      "e": 21636,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21708,
      "e": 21708,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||L"
    },
    {
      "t": 21780,
      "e": 21780,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 21780,
      "e": 21780,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21845,
      "e": 21845,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||L"
    },
    {
      "t": 21908,
      "e": 21908,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 21909,
      "e": 21909,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21996,
      "e": 21996,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||O"
    },
    {
      "t": 22029,
      "e": 22029,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 22029,
      "e": 22029,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22132,
      "e": 22132,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||W"
    },
    {
      "t": 22149,
      "e": 22149,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22149,
      "e": 22149,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22236,
      "e": 22236,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22292,
      "e": 22292,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 22293,
      "e": 22293,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22372,
      "e": 22372,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 22373,
      "e": 22373,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22420,
      "e": 22420,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||DO"
    },
    {
      "t": 22445,
      "e": 22445,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22532,
      "e": 22532,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 22533,
      "e": 22533,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22588,
      "e": 22588,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 22668,
      "e": 22668,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 22668,
      "e": 22668,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22772,
      "e": 22772,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 22797,
      "e": 22797,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 22797,
      "e": 22797,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22900,
      "e": 22900,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||E"
    },
    {
      "t": 23012,
      "e": 23012,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 23012,
      "e": 23012,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23108,
      "e": 23108,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||D"
    },
    {
      "t": 23108,
      "e": 23108,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23108,
      "e": 23108,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23221,
      "e": 23221,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23229,
      "e": 23229,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 23229,
      "e": 23229,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23284,
      "e": 23284,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 23284,
      "e": 23284,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23324,
      "e": 23324,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||LI"
    },
    {
      "t": 23364,
      "e": 23364,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23725,
      "e": 23725,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 23725,
      "e": 23725,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23820,
      "e": 23820,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||N"
    },
    {
      "t": 23844,
      "e": 23844,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 23844,
      "e": 23844,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23916,
      "e": 23916,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||E"
    },
    {
      "t": 24700,
      "e": 24700,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24700,
      "e": 24700,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24805,
      "e": 24805,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "FIND 12PM ON THE HORIZONTAL AXIS OF GRAPH AND FOLLOW DOTTED LINE "
    },
    {
      "t": 24836,
      "e": 24836,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27044,
      "e": 27044,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 27045,
      "e": 27045,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27172,
      "e": 27172,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||U"
    },
    {
      "t": 28172,
      "e": 28172,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 28172,
      "e": 28172,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28245,
      "e": 28245,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||P"
    },
    {
      "t": 28397,
      "e": 28397,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 28398,
      "e": 28398,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28484,
      "e": 28484,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||-"
    },
    {
      "t": 28596,
      "e": 28596,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 28596,
      "e": 28596,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28653,
      "e": 28653,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 28653,
      "e": 28653,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28677,
      "e": 28677,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||RI"
    },
    {
      "t": 28732,
      "e": 28732,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 28780,
      "e": 28780,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 28780,
      "e": 28780,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28845,
      "e": 28845,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 28845,
      "e": 28845,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28852,
      "e": 28852,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||GH"
    },
    {
      "t": 28924,
      "e": 28924,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 28941,
      "e": 28941,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 28941,
      "e": 28941,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29004,
      "e": 29004,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 31204,
      "e": 31204,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 31204,
      "e": 31204,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31284,
      "e": 31284,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 31420,
      "e": 31420,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31421,
      "e": 31421,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31541,
      "e": 31541,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 31556,
      "e": 31556,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 31716,
      "e": 31716,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 31717,
      "e": 31717,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31788,
      "e": 31788,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 31844,
      "e": 31844,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 31852,
      "e": 31852,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 31852,
      "e": 31852,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31940,
      "e": 31940,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||L"
    },
    {
      "t": 32004,
      "e": 32004,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 32004,
      "e": 32004,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32061,
      "e": 32061,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32061,
      "e": 32061,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32108,
      "e": 32108,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||L "
    },
    {
      "t": 32172,
      "e": 32172,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32420,
      "e": 32420,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 32484,
      "e": 32484,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "FIND 12PM ON THE HORIZONTAL AXIS OF GRAPH AND FOLLOW DOTTED LINE UP-RIGHT. aLL"
    },
    {
      "t": 32548,
      "e": 32548,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 32612,
      "e": 32612,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "FIND 12PM ON THE HORIZONTAL AXIS OF GRAPH AND FOLLOW DOTTED LINE UP-RIGHT. aL"
    },
    {
      "t": 32676,
      "e": 32676,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 32741,
      "e": 32741,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "FIND 12PM ON THE HORIZONTAL AXIS OF GRAPH AND FOLLOW DOTTED LINE UP-RIGHT. a"
    },
    {
      "t": 32797,
      "e": 32797,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 32860,
      "e": 32860,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "FIND 12PM ON THE HORIZONTAL AXIS OF GRAPH AND FOLLOW DOTTED LINE UP-RIGHT. "
    },
    {
      "t": 32941,
      "e": 32941,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 32941,
      "e": 32941,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33012,
      "e": 33012,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 33012,
      "e": 33012,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33028,
      "e": 33028,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||AL"
    },
    {
      "t": 33076,
      "e": 33076,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33157,
      "e": 33157,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 33157,
      "e": 33157,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33221,
      "e": 33221,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33221,
      "e": 33221,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33236,
      "e": 33236,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||L "
    },
    {
      "t": 33301,
      "e": 33301,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33406,
      "e": 33406,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "FIND 12PM ON THE HORIZONTAL AXIS OF GRAPH AND FOLLOW DOTTED LINE UP-RIGHT. ALL "
    },
    {
      "t": 33516,
      "e": 33516,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 33516,
      "e": 33516,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33588,
      "e": 33588,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 33588,
      "e": 33588,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33612,
      "e": 33612,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||OB"
    },
    {
      "t": 33660,
      "e": 33660,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33764,
      "e": 33764,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "74"
    },
    {
      "t": 33764,
      "e": 33764,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33844,
      "e": 33844,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||J"
    },
    {
      "t": 33852,
      "e": 33852,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 33853,
      "e": 33853,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33924,
      "e": 33924,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 33924,
      "e": 33924,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33981,
      "e": 33981,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||EC"
    },
    {
      "t": 34012,
      "e": 34012,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34100,
      "e": 34100,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 34100,
      "e": 34100,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34196,
      "e": 34196,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 34197,
      "e": 34197,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34213,
      "e": 34213,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||TS"
    },
    {
      "t": 34260,
      "e": 34260,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34260,
      "e": 34260,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34292,
      "e": 34292,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 34340,
      "e": 34340,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34644,
      "e": 34644,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34708,
      "e": 34644,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "FIND 12PM ON THE HORIZONTAL AXIS OF GRAPH AND FOLLOW DOTTED LINE UP-RIGHT. ALL OBJECTS"
    },
    {
      "t": 34772,
      "e": 34708,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34844,
      "e": 34780,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "FIND 12PM ON THE HORIZONTAL AXIS OF GRAPH AND FOLLOW DOTTED LINE UP-RIGHT. ALL OBJECT"
    },
    {
      "t": 34916,
      "e": 34852,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34965,
      "e": 34901,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "FIND 12PM ON THE HORIZONTAL AXIS OF GRAPH AND FOLLOW DOTTED LINE UP-RIGHT. ALL OBJEC"
    },
    {
      "t": 35044,
      "e": 34980,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35116,
      "e": 35052,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "FIND 12PM ON THE HORIZONTAL AXIS OF GRAPH AND FOLLOW DOTTED LINE UP-RIGHT. ALL OBJE"
    },
    {
      "t": 35188,
      "e": 35124,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35252,
      "e": 35188,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "FIND 12PM ON THE HORIZONTAL AXIS OF GRAPH AND FOLLOW DOTTED LINE UP-RIGHT. ALL OBJ"
    },
    {
      "t": 35324,
      "e": 35260,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 35397,
      "e": 35333,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "FIND 12PM ON THE HORIZONTAL AXIS OF GRAPH AND FOLLOW DOTTED LINE UP-RIGHT. ALL OB"
    },
    {
      "t": 36084,
      "e": 36020,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "74"
    },
    {
      "t": 36085,
      "e": 36021,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36164,
      "e": 36100,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 36165,
      "e": 36101,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36172,
      "e": 36108,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||JE"
    },
    {
      "t": 36236,
      "e": 36172,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 36237,
      "e": 36173,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36309,
      "e": 36245,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||C"
    },
    {
      "t": 36333,
      "e": 36269,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36412,
      "e": 36348,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 36412,
      "e": 36348,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36524,
      "e": 36460,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 36524,
      "e": 36460,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36556,
      "e": 36492,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||TS"
    },
    {
      "t": 36596,
      "e": 36532,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36596,
      "e": 36532,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36628,
      "e": 36564,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 36676,
      "e": 36612,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36740,
      "e": 36676,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 36740,
      "e": 36676,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36812,
      "e": 36748,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 36813,
      "e": 36749,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36844,
      "e": 36780,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36845,
      "e": 36781,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36884,
      "e": 36820,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ON "
    },
    {
      "t": 36933,
      "e": 36869,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36988,
      "e": 36924,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 37052,
      "e": 36988,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 37052,
      "e": 36988,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37117,
      "e": 37053,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 37117,
      "e": 37053,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37140,
      "e": 37076,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||DO"
    },
    {
      "t": 37196,
      "e": 37132,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 37332,
      "e": 37268,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 37333,
      "e": 37269,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37404,
      "e": 37340,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T"
    },
    {
      "t": 37476,
      "e": 37412,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 37476,
      "e": 37412,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37564,
      "e": 37500,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 37564,
      "e": 37500,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37596,
      "e": 37532,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||TE"
    },
    {
      "t": 37644,
      "e": 37580,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 37732,
      "e": 37668,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 37733,
      "e": 37669,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37813,
      "e": 37749,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37813,
      "e": 37749,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37820,
      "e": 37756,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||D "
    },
    {
      "t": 37876,
      "e": 37812,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 37877,
      "e": 37813,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37909,
      "e": 37845,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||L"
    },
    {
      "t": 37988,
      "e": 37924,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 37989,
      "e": 37925,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38012,
      "e": 37948,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||I"
    },
    {
      "t": 38060,
      "e": 37996,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 38060,
      "e": 37996,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38084,
      "e": 38020,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||N"
    },
    {
      "t": 38116,
      "e": 38052,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 38117,
      "e": 38053,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38133,
      "e": 38069,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||E"
    },
    {
      "t": 38196,
      "e": 38132,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 38596,
      "e": 38532,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 38596,
      "e": 38532,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38708,
      "e": 38644,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 38828,
      "e": 38764,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 38828,
      "e": 38764,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38908,
      "e": 38844,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 38909,
      "e": 38845,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38972,
      "e": 38908,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ST"
    },
    {
      "t": 38988,
      "e": 38924,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 39076,
      "e": 39012,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 39076,
      "e": 39012,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39173,
      "e": 39109,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 39173,
      "e": 39109,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39197,
      "e": 39133,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||AR"
    },
    {
      "t": 39244,
      "e": 39180,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 39332,
      "e": 39268,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 39333,
      "e": 39269,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39396,
      "e": 39332,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 39396,
      "e": 39332,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39420,
      "e": 39356,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||T "
    },
    {
      "t": 39508,
      "e": 39444,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 39556,
      "e": 39492,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 39556,
      "e": 39492,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39612,
      "e": 39548,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 39612,
      "e": 39548,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39652,
      "e": 39588,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||AT"
    },
    {
      "t": 39700,
      "e": 39636,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 39700,
      "e": 39636,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39756,
      "e": 39692,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 39764,
      "e": 39700,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40092,
      "e": 40028,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 40093,
      "e": 40029,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40100,
      "e": 40036,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 40101,
      "e": 40037,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40124,
      "e": 40060,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||21"
    },
    {
      "t": 40132,
      "e": 40068,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40612,
      "e": 40548,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 40677,
      "e": 40613,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "FIND 12PM ON THE HORIZONTAL AXIS OF GRAPH AND FOLLOW DOTTED LINE UP-RIGHT. ALL OBJECTS ON DOTTED LINE START AT 2"
    },
    {
      "t": 40748,
      "e": 40684,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 40780,
      "e": 40716,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 40780,
      "e": 40716,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40804,
      "e": 40740,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "FIND 12PM ON THE HORIZONTAL AXIS OF GRAPH AND FOLLOW DOTTED LINE UP-RIGHT. ALL OBJECTS ON DOTTED LINE START AT 1"
    },
    {
      "t": 40836,
      "e": 40772,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 40837,
      "e": 40773,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40892,
      "e": 40828,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 40948,
      "e": 40884,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 41356,
      "e": 41292,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 41356,
      "e": 41292,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41428,
      "e": 41364,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 41429,
      "e": 41365,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41469,
      "e": 41405,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||PM"
    },
    {
      "t": 41500,
      "e": 41436,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 41605,
      "e": 41541,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "FIND 12PM ON THE HORIZONTAL AXIS OF GRAPH AND FOLLOW DOTTED LINE UP-RIGHT. ALL OBJECTS ON DOTTED LINE START AT 12PM"
    },
    {
      "t": 42204,
      "e": 42140,
      "ty": 2,
      "x": 558,
      "y": 583
    },
    {
      "t": 42254,
      "e": 42190,
      "ty": 41,
      "x": 52035,
      "y": 47950,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42303,
      "e": 42239,
      "ty": 2,
      "x": 561,
      "y": 581
    },
    {
      "t": 42404,
      "e": 42340,
      "ty": 2,
      "x": 471,
      "y": 583
    },
    {
      "t": 42504,
      "e": 42440,
      "ty": 2,
      "x": 427,
      "y": 584
    },
    {
      "t": 42504,
      "e": 42440,
      "ty": 41,
      "x": 37084,
      "y": 49568,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42603,
      "e": 42539,
      "ty": 2,
      "x": 328,
      "y": 555
    },
    {
      "t": 42704,
      "e": 42640,
      "ty": 2,
      "x": 150,
      "y": 529
    },
    {
      "t": 42754,
      "e": 42690,
      "ty": 41,
      "x": 4823,
      "y": 5878,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42804,
      "e": 42740,
      "ty": 2,
      "x": 124,
      "y": 540
    },
    {
      "t": 42903,
      "e": 42839,
      "ty": 2,
      "x": 113,
      "y": 557
    },
    {
      "t": 43003,
      "e": 42939,
      "ty": 2,
      "x": 113,
      "y": 558
    },
    {
      "t": 43003,
      "e": 42939,
      "ty": 41,
      "x": 1788,
      "y": 28532,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43104,
      "e": 43040,
      "ty": 2,
      "x": 122,
      "y": 557
    },
    {
      "t": 43203,
      "e": 43139,
      "ty": 2,
      "x": 159,
      "y": 548
    },
    {
      "t": 43254,
      "e": 43190,
      "ty": 41,
      "x": 7633,
      "y": 18823,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43304,
      "e": 43240,
      "ty": 2,
      "x": 209,
      "y": 543
    },
    {
      "t": 43404,
      "e": 43340,
      "ty": 2,
      "x": 275,
      "y": 541
    },
    {
      "t": 43504,
      "e": 43440,
      "ty": 2,
      "x": 372,
      "y": 541
    },
    {
      "t": 43504,
      "e": 43440,
      "ty": 41,
      "x": 30902,
      "y": 14778,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43604,
      "e": 43540,
      "ty": 2,
      "x": 425,
      "y": 541
    },
    {
      "t": 43703,
      "e": 43639,
      "ty": 2,
      "x": 445,
      "y": 541
    },
    {
      "t": 43754,
      "e": 43690,
      "ty": 41,
      "x": 39332,
      "y": 14778,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43804,
      "e": 43740,
      "ty": 2,
      "x": 464,
      "y": 541
    },
    {
      "t": 43904,
      "e": 43840,
      "ty": 2,
      "x": 502,
      "y": 541
    },
    {
      "t": 44004,
      "e": 43940,
      "ty": 2,
      "x": 508,
      "y": 541
    },
    {
      "t": 44004,
      "e": 43940,
      "ty": 41,
      "x": 46189,
      "y": 14778,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44104,
      "e": 44040,
      "ty": 2,
      "x": 535,
      "y": 541
    },
    {
      "t": 44254,
      "e": 44190,
      "ty": 41,
      "x": 49562,
      "y": 14778,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44304,
      "e": 44240,
      "ty": 2,
      "x": 562,
      "y": 543
    },
    {
      "t": 44404,
      "e": 44340,
      "ty": 2,
      "x": 576,
      "y": 546
    },
    {
      "t": 44504,
      "e": 44440,
      "ty": 2,
      "x": 584,
      "y": 546
    },
    {
      "t": 44504,
      "e": 44440,
      "ty": 41,
      "x": 54733,
      "y": 18823,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44604,
      "e": 44540,
      "ty": 2,
      "x": 593,
      "y": 545
    },
    {
      "t": 44704,
      "e": 44640,
      "ty": 2,
      "x": 596,
      "y": 545
    },
    {
      "t": 44754,
      "e": 44690,
      "ty": 41,
      "x": 56756,
      "y": 18014,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44804,
      "e": 44740,
      "ty": 2,
      "x": 613,
      "y": 545
    },
    {
      "t": 44904,
      "e": 44840,
      "ty": 2,
      "x": 615,
      "y": 545
    },
    {
      "t": 45004,
      "e": 44940,
      "ty": 41,
      "x": 58217,
      "y": 18014,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45160,
      "e": 45096,
      "ty": 7,
      "x": 722,
      "y": 608,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45204,
      "e": 45140,
      "ty": 2,
      "x": 982,
      "y": 731
    },
    {
      "t": 45254,
      "e": 45140,
      "ty": 41,
      "x": 19661,
      "y": 45767,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 45303,
      "e": 45189,
      "ty": 2,
      "x": 1065,
      "y": 777
    },
    {
      "t": 45404,
      "e": 45290,
      "ty": 2,
      "x": 1070,
      "y": 823
    },
    {
      "t": 45504,
      "e": 45390,
      "ty": 2,
      "x": 1163,
      "y": 917
    },
    {
      "t": 45504,
      "e": 45390,
      "ty": 41,
      "x": 26567,
      "y": 55794,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 45604,
      "e": 45490,
      "ty": 2,
      "x": 1172,
      "y": 924
    },
    {
      "t": 45704,
      "e": 45590,
      "ty": 2,
      "x": 1164,
      "y": 939
    },
    {
      "t": 45754,
      "e": 45640,
      "ty": 41,
      "x": 26285,
      "y": 58014,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 45804,
      "e": 45690,
      "ty": 2,
      "x": 1158,
      "y": 956
    },
    {
      "t": 45904,
      "e": 45790,
      "ty": 2,
      "x": 1156,
      "y": 960
    },
    {
      "t": 46004,
      "e": 45890,
      "ty": 2,
      "x": 1154,
      "y": 964
    },
    {
      "t": 47804,
      "e": 47690,
      "ty": 2,
      "x": 1153,
      "y": 965
    },
    {
      "t": 48254,
      "e": 48140,
      "ty": 41,
      "x": 25651,
      "y": 59232,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 48304,
      "e": 48190,
      "ty": 2,
      "x": 1133,
      "y": 954
    },
    {
      "t": 48404,
      "e": 48290,
      "ty": 2,
      "x": 1088,
      "y": 864
    },
    {
      "t": 48504,
      "e": 48390,
      "ty": 2,
      "x": 965,
      "y": 738
    },
    {
      "t": 48505,
      "e": 48391,
      "ty": 41,
      "x": 12614,
      "y": 42973,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 48604,
      "e": 48490,
      "ty": 2,
      "x": 779,
      "y": 668
    },
    {
      "t": 48704,
      "e": 48590,
      "ty": 2,
      "x": 568,
      "y": 620
    },
    {
      "t": 48754,
      "e": 48640,
      "ty": 41,
      "x": 43941,
      "y": 61119,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 48804,
      "e": 48690,
      "ty": 2,
      "x": 433,
      "y": 605
    },
    {
      "t": 48828,
      "e": 48714,
      "ty": 6,
      "x": 369,
      "y": 598,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48904,
      "e": 48790,
      "ty": 2,
      "x": 218,
      "y": 564
    },
    {
      "t": 49004,
      "e": 48890,
      "ty": 2,
      "x": 198,
      "y": 557
    },
    {
      "t": 49005,
      "e": 48891,
      "ty": 41,
      "x": 11342,
      "y": 27723,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49104,
      "e": 48990,
      "ty": 2,
      "x": 197,
      "y": 557
    },
    {
      "t": 49204,
      "e": 49090,
      "ty": 2,
      "x": 188,
      "y": 555
    },
    {
      "t": 49254,
      "e": 49140,
      "ty": 41,
      "x": 9656,
      "y": 25296,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49304,
      "e": 49190,
      "ty": 2,
      "x": 179,
      "y": 554
    },
    {
      "t": 49404,
      "e": 49290,
      "ty": 2,
      "x": 177,
      "y": 553
    },
    {
      "t": 49504,
      "e": 49390,
      "ty": 2,
      "x": 157,
      "y": 556
    },
    {
      "t": 49504,
      "e": 49390,
      "ty": 41,
      "x": 6734,
      "y": 26914,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49952,
      "e": 49838,
      "ty": 3,
      "x": 157,
      "y": 556,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50072,
      "e": 49958,
      "ty": 4,
      "x": 6734,
      "y": 26914,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50072,
      "e": 49958,
      "ty": 5,
      "x": 157,
      "y": 556,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50716,
      "e": 50602,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 50716,
      "e": 50602,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50788,
      "e": 50674,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 50788,
      "e": 50674,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50828,
      "e": 50714,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "FIND 12PM ON THE HORIZONTAL AXIS OF GRAPH AND FOLLOW DOTTED LINE UP-RIGHT. ALL OBJECTS THON DOTTED LINE START AT 12PM"
    },
    {
      "t": 50844,
      "e": 50730,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 50844,
      "e": 50730,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50876,
      "e": 50762,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "FIND 12PM ON THE HORIZONTAL AXIS OF GRAPH AND FOLLOW DOTTED LINE UP-RIGHT. ALL OBJECTS THAON DOTTED LINE START AT 12PM"
    },
    {
      "t": 50916,
      "e": 50802,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 50917,
      "e": 50803,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50956,
      "e": 50842,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "FIND 12PM ON THE HORIZONTAL AXIS OF GRAPH AND FOLLOW DOTTED LINE UP-RIGHT. ALL OBJECTS THATON DOTTED LINE START AT 12PM"
    },
    {
      "t": 50964,
      "e": 50850,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 50964,
      "e": 50850,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51052,
      "e": 50938,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 51053,
      "e": 50939,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51060,
      "e": 50946,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "FIND 12PM ON THE HORIZONTAL AXIS OF GRAPH AND FOLLOW DOTTED LINE UP-RIGHT. ALL OBJECTS THAT LON DOTTED LINE START AT 12PM"
    },
    {
      "t": 51076,
      "e": 50962,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 51084,
      "e": 50970,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 51084,
      "e": 50970,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51124,
      "e": 51010,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 51124,
      "e": 51010,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51132,
      "e": 51010,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "FIND 12PM ON THE HORIZONTAL AXIS OF GRAPH AND FOLLOW DOTTED LINE UP-RIGHT. ALL OBJECTS THAT LIEON DOTTED LINE START AT 12PM"
    },
    {
      "t": 51156,
      "e": 51034,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 51196,
      "e": 51074,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 51484,
      "e": 51362,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 51484,
      "e": 51362,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51548,
      "e": 51426,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "FIND 12PM ON THE HORIZONTAL AXIS OF GRAPH AND FOLLOW DOTTED LINE UP-RIGHT. ALL OBJECTS THAT LIE ON DOTTED LINE START AT 12PM"
    },
    {
      "t": 53324,
      "e": 53202,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "39"
    },
    {
      "t": 53412,
      "e": 53290,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 53485,
      "e": 53363,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "39"
    },
    {
      "t": 53556,
      "e": 53434,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 53612,
      "e": 53490,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "39"
    },
    {
      "t": 53676,
      "e": 53554,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 54124,
      "e": 54002,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 54124,
      "e": 54002,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54180,
      "e": 54058,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 54180,
      "e": 54058,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54236,
      "e": 54114,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "FIND 12PM ON THE HORIZONTAL AXIS OF GRAPH AND FOLLOW DOTTED LINE UP-RIGHT. ALL OBJECTS THAT LIE ON THDOTTED LINE START AT 12PM"
    },
    {
      "t": 54236,
      "e": 54114,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 54236,
      "e": 54114,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54252,
      "e": 54130,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "FIND 12PM ON THE HORIZONTAL AXIS OF GRAPH AND FOLLOW DOTTED LINE UP-RIGHT. ALL OBJECTS THAT LIE ON THEDOTTED LINE START AT 12PM"
    },
    {
      "t": 54292,
      "e": 54170,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 54292,
      "e": 54170,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54316,
      "e": 54194,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "FIND 12PM ON THE HORIZONTAL AXIS OF GRAPH AND FOLLOW DOTTED LINE UP-RIGHT. ALL OBJECTS THAT LIE ON THE DOTTED LINE START AT 12PM"
    },
    {
      "t": 54348,
      "e": 54226,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 54754,
      "e": 54632,
      "ty": 41,
      "x": 7183,
      "y": 28532,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54804,
      "e": 54682,
      "ty": 2,
      "x": 165,
      "y": 559
    },
    {
      "t": 55005,
      "e": 54883,
      "ty": 2,
      "x": 176,
      "y": 571
    },
    {
      "t": 55005,
      "e": 54883,
      "ty": 41,
      "x": 8869,
      "y": 39050,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55051,
      "e": 54929,
      "ty": 7,
      "x": 238,
      "y": 612,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55104,
      "e": 54982,
      "ty": 2,
      "x": 282,
      "y": 643
    },
    {
      "t": 55204,
      "e": 55082,
      "ty": 2,
      "x": 336,
      "y": 668
    },
    {
      "t": 55217,
      "e": 55095,
      "ty": 6,
      "x": 342,
      "y": 668,
      "ta": "#strategyButton"
    },
    {
      "t": 55254,
      "e": 55132,
      "ty": 41,
      "x": 3498,
      "y": 27496,
      "ta": "#strategyButton"
    },
    {
      "t": 55304,
      "e": 55182,
      "ty": 2,
      "x": 351,
      "y": 672
    },
    {
      "t": 55404,
      "e": 55282,
      "ty": 2,
      "x": 371,
      "y": 673
    },
    {
      "t": 55505,
      "e": 55383,
      "ty": 41,
      "x": 17697,
      "y": 35206,
      "ta": "#strategyButton"
    },
    {
      "t": 56752,
      "e": 56630,
      "ty": 3,
      "x": 371,
      "y": 673,
      "ta": "#strategyButton"
    },
    {
      "t": 56753,
      "e": 56630,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "FIND 12PM ON THE HORIZONTAL AXIS OF GRAPH AND FOLLOW DOTTED LINE UP-RIGHT. ALL OBJECTS THAT LIE ON THE DOTTED LINE START AT 12PM"
    },
    {
      "t": 56754,
      "e": 56631,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 56754,
      "e": 56631,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 56857,
      "e": 56734,
      "ty": 4,
      "x": 17697,
      "y": 35206,
      "ta": "#strategyButton"
    },
    {
      "t": 56865,
      "e": 56742,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 56866,
      "e": 56743,
      "ty": 5,
      "x": 371,
      "y": 673,
      "ta": "#strategyButton"
    },
    {
      "t": 56875,
      "e": 56752,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 57869,
      "e": 57746,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 58504,
      "e": 58381,
      "ty": 2,
      "x": 477,
      "y": 642
    },
    {
      "t": 58504,
      "e": 58381,
      "ty": 41,
      "x": 16151,
      "y": 35121,
      "ta": "html > body"
    },
    {
      "t": 58605,
      "e": 58482,
      "ty": 2,
      "x": 572,
      "y": 628
    },
    {
      "t": 58703,
      "e": 58580,
      "ty": 2,
      "x": 795,
      "y": 596
    },
    {
      "t": 58753,
      "e": 58630,
      "ty": 6,
      "x": 894,
      "y": 567,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 58754,
      "e": 58631,
      "ty": 41,
      "x": 18600,
      "y": 40569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 58805,
      "e": 58682,
      "ty": 2,
      "x": 901,
      "y": 562
    },
    {
      "t": 58921,
      "e": 58798,
      "ty": 3,
      "x": 901,
      "y": 562,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 58921,
      "e": 58798,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 59005,
      "e": 58882,
      "ty": 41,
      "x": 20114,
      "y": 24965,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 59008,
      "e": 58885,
      "ty": 4,
      "x": 20114,
      "y": 24965,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 59008,
      "e": 58885,
      "ty": 5,
      "x": 901,
      "y": 562,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 59604,
      "e": 59481,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "98"
    },
    {
      "t": 59604,
      "e": 59481,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 59700,
      "e": 59577,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "100"
    },
    {
      "t": 59700,
      "e": 59577,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 59748,
      "e": 59625,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "24"
    },
    {
      "t": 59787,
      "e": 59664,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "24"
    },
    {
      "t": 60053,
      "e": 59930,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 60053,
      "e": 59930,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "24"
    },
    {
      "t": 60053,
      "e": 59930,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 60053,
      "e": 59930,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 60236,
      "e": 60113,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 61684,
      "e": 61561,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 61900,
      "e": 61777,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 61900,
      "e": 61777,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61908,
      "e": 61785,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "67"
    },
    {
      "t": 61908,
      "e": 61785,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61909,
      "e": 61786,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "74"
    },
    {
      "t": 61909,
      "e": 61786,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 61964,
      "e": 61841,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "ucj"
    },
    {
      "t": 61972,
      "e": 61849,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "ucj"
    },
    {
      "t": 62036,
      "e": 61913,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "ucj"
    },
    {
      "t": 62076,
      "e": 61953,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 62077,
      "e": 61954,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 62172,
      "e": 62049,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "ucja"
    },
    {
      "t": 62340,
      "e": 62217,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 62396,
      "e": 62273,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "ucj"
    },
    {
      "t": 62460,
      "e": 62337,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 62516,
      "e": 62393,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "uc"
    },
    {
      "t": 62556,
      "e": 62433,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "uc"
    },
    {
      "t": 62596,
      "e": 62473,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 62644,
      "e": 62521,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "u"
    },
    {
      "t": 62716,
      "e": 62593,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 62796,
      "e": 62673,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 62988,
      "e": 62865,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 62988,
      "e": 62865,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 63052,
      "e": 62929,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "67"
    },
    {
      "t": 63052,
      "e": 62929,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 63068,
      "e": 62945,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "UC"
    },
    {
      "t": 63205,
      "e": 63082,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "UC"
    },
    {
      "t": 63220,
      "e": 63097,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "UC"
    },
    {
      "t": 63436,
      "e": 63313,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 63500,
      "e": 63377,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 63605,
      "e": 63482,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 63660,
      "e": 63537,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 63660,
      "e": 63537,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 63764,
      "e": 63641,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 63820,
      "e": 63697,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 63820,
      "e": 63697,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 63908,
      "e": 63785,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 64756,
      "e": 64633,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "13"
    },
    {
      "t": 64757,
      "e": 64634,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 64892,
      "e": 64769,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA\n"
    },
    {
      "t": 66188,
      "e": 66065,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 66252,
      "e": 66129,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 66754,
      "e": 66631,
      "ty": 41,
      "x": 24656,
      "y": 21845,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 66804,
      "e": 66681,
      "ty": 2,
      "x": 926,
      "y": 561
    },
    {
      "t": 66876,
      "e": 66753,
      "ty": 7,
      "x": 926,
      "y": 590,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 66904,
      "e": 66781,
      "ty": 2,
      "x": 939,
      "y": 638
    },
    {
      "t": 66910,
      "e": 66787,
      "ty": 6,
      "x": 941,
      "y": 665,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 66927,
      "e": 66804,
      "ty": 7,
      "x": 939,
      "y": 677,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 66927,
      "e": 66804,
      "ty": 6,
      "x": 939,
      "y": 677,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 66976,
      "e": 66853,
      "ty": 7,
      "x": 931,
      "y": 711,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67004,
      "e": 66881,
      "ty": 2,
      "x": 931,
      "y": 713
    },
    {
      "t": 67004,
      "e": 66881,
      "ty": 41,
      "x": 31786,
      "y": 39055,
      "ta": "html > body"
    },
    {
      "t": 67104,
      "e": 66981,
      "ty": 2,
      "x": 933,
      "y": 723
    },
    {
      "t": 67160,
      "e": 67037,
      "ty": 6,
      "x": 938,
      "y": 701,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67204,
      "e": 67081,
      "ty": 2,
      "x": 944,
      "y": 681
    },
    {
      "t": 67210,
      "e": 67087,
      "ty": 7,
      "x": 945,
      "y": 675,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67254,
      "e": 67131,
      "ty": 41,
      "x": 29631,
      "y": 64125,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 67303,
      "e": 67180,
      "ty": 2,
      "x": 945,
      "y": 673
    },
    {
      "t": 67328,
      "e": 67205,
      "ty": 3,
      "x": 945,
      "y": 673,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 67328,
      "e": 67205,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 67328,
      "e": 67205,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 67408,
      "e": 67285,
      "ty": 4,
      "x": 29631,
      "y": 63420,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 67408,
      "e": 67285,
      "ty": 5,
      "x": 945,
      "y": 673,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 67504,
      "e": 67381,
      "ty": 41,
      "x": 29631,
      "y": 63420,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 67728,
      "e": 67605,
      "ty": 6,
      "x": 947,
      "y": 678,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67754,
      "e": 67631,
      "ty": 41,
      "x": 27871,
      "y": 21845,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67804,
      "e": 67681,
      "ty": 2,
      "x": 953,
      "y": 698
    },
    {
      "t": 67929,
      "e": 67806,
      "ty": 3,
      "x": 953,
      "y": 698,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 67929,
      "e": 67806,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 68004,
      "e": 67881,
      "ty": 41,
      "x": 29417,
      "y": 43690,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 68016,
      "e": 67893,
      "ty": 4,
      "x": 29417,
      "y": 43690,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 68016,
      "e": 67893,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 68017,
      "e": 67894,
      "ty": 5,
      "x": 953,
      "y": 698,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 68017,
      "e": 67894,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 68304,
      "e": 68181,
      "ty": 2,
      "x": 947,
      "y": 679
    },
    {
      "t": 68504,
      "e": 68381,
      "ty": 41,
      "x": 32337,
      "y": 37171,
      "ta": "html > body"
    },
    {
      "t": 68904,
      "e": 68781,
      "ty": 2,
      "x": 953,
      "y": 674
    },
    {
      "t": 69004,
      "e": 68881,
      "ty": 41,
      "x": 32543,
      "y": 36894,
      "ta": "html > body"
    },
    {
      "t": 69028,
      "e": 68905,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 69503,
      "e": 69380,
      "ty": 2,
      "x": 923,
      "y": 404
    },
    {
      "t": 69504,
      "e": 69380,
      "ty": 41,
      "x": 24107,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 69604,
      "e": 69480,
      "ty": 2,
      "x": 902,
      "y": 219
    },
    {
      "t": 69704,
      "e": 69580,
      "ty": 2,
      "x": 896,
      "y": 210
    },
    {
      "t": 69754,
      "e": 69630,
      "ty": 41,
      "x": 17699,
      "y": 12858,
      "ta": "#jspsych-survey-multi-choice-0"
    },
    {
      "t": 69903,
      "e": 69779,
      "ty": 2,
      "x": 888,
      "y": 215
    },
    {
      "t": 70003,
      "e": 69879,
      "ty": 2,
      "x": 879,
      "y": 223
    },
    {
      "t": 70004,
      "e": 69880,
      "ty": 41,
      "x": 13664,
      "y": 18250,
      "ta": "#jspsych-survey-multi-choice-0"
    },
    {
      "t": 70104,
      "e": 69980,
      "ty": 2,
      "x": 876,
      "y": 228
    },
    {
      "t": 70204,
      "e": 70080,
      "ty": 2,
      "x": 874,
      "y": 235
    },
    {
      "t": 70254,
      "e": 70130,
      "ty": 41,
      "x": 43054,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 70264,
      "e": 70140,
      "ty": 3,
      "x": 874,
      "y": 235,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 70352,
      "e": 70228,
      "ty": 4,
      "x": 43054,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 70353,
      "e": 70229,
      "ty": 5,
      "x": 874,
      "y": 235,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 70353,
      "e": 70229,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 70353,
      "e": 70229,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 70604,
      "e": 70480,
      "ty": 2,
      "x": 874,
      "y": 257
    },
    {
      "t": 70704,
      "e": 70580,
      "ty": 2,
      "x": 874,
      "y": 295
    },
    {
      "t": 70754,
      "e": 70630,
      "ty": 41,
      "x": 53188,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 70804,
      "e": 70680,
      "ty": 2,
      "x": 878,
      "y": 329
    },
    {
      "t": 70904,
      "e": 70780,
      "ty": 2,
      "x": 877,
      "y": 345
    },
    {
      "t": 71004,
      "e": 70880,
      "ty": 2,
      "x": 873,
      "y": 354
    },
    {
      "t": 71004,
      "e": 70880,
      "ty": 41,
      "x": 12240,
      "y": 14422,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 71104,
      "e": 70980,
      "ty": 2,
      "x": 871,
      "y": 369
    },
    {
      "t": 71204,
      "e": 71080,
      "ty": 2,
      "x": 869,
      "y": 382
    },
    {
      "t": 71254,
      "e": 71130,
      "ty": 41,
      "x": 11054,
      "y": 8665,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 71304,
      "e": 71180,
      "ty": 2,
      "x": 867,
      "y": 391
    },
    {
      "t": 71404,
      "e": 71280,
      "ty": 2,
      "x": 865,
      "y": 400
    },
    {
      "t": 71504,
      "e": 71380,
      "ty": 2,
      "x": 862,
      "y": 413
    },
    {
      "t": 71504,
      "e": 71380,
      "ty": 41,
      "x": 47500,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 71604,
      "e": 71480,
      "ty": 2,
      "x": 858,
      "y": 445
    },
    {
      "t": 71703,
      "e": 71579,
      "ty": 2,
      "x": 854,
      "y": 466
    },
    {
      "t": 71754,
      "e": 71630,
      "ty": 41,
      "x": 34435,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 71804,
      "e": 71680,
      "ty": 2,
      "x": 854,
      "y": 480
    },
    {
      "t": 71904,
      "e": 71780,
      "ty": 2,
      "x": 854,
      "y": 492
    },
    {
      "t": 72004,
      "e": 71880,
      "ty": 2,
      "x": 854,
      "y": 509
    },
    {
      "t": 72004,
      "e": 71880,
      "ty": 41,
      "x": 7731,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 72104,
      "e": 71980,
      "ty": 2,
      "x": 856,
      "y": 520
    },
    {
      "t": 72204,
      "e": 72080,
      "ty": 2,
      "x": 856,
      "y": 527
    },
    {
      "t": 72254,
      "e": 72130,
      "ty": 41,
      "x": 40465,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 72407,
      "e": 72283,
      "ty": 2,
      "x": 856,
      "y": 539
    },
    {
      "t": 72507,
      "e": 72383,
      "ty": 2,
      "x": 859,
      "y": 558
    },
    {
      "t": 72507,
      "e": 72383,
      "ty": 41,
      "x": 25640,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-1-5 > label"
    },
    {
      "t": 72607,
      "e": 72483,
      "ty": 2,
      "x": 854,
      "y": 542
    },
    {
      "t": 72707,
      "e": 72583,
      "ty": 2,
      "x": 847,
      "y": 518
    },
    {
      "t": 72757,
      "e": 72633,
      "ty": 41,
      "x": 29933,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 72787,
      "e": 72663,
      "ty": 3,
      "x": 847,
      "y": 518,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 72787,
      "e": 72663,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 72808,
      "e": 72684,
      "ty": 2,
      "x": 847,
      "y": 517
    },
    {
      "t": 72883,
      "e": 72759,
      "ty": 4,
      "x": 29933,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 72883,
      "e": 72759,
      "ty": 5,
      "x": 847,
      "y": 517,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 72884,
      "e": 72760,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 72884,
      "e": 72760,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf",
      "v": "Fifth"
    },
    {
      "t": 73008,
      "e": 72884,
      "ty": 41,
      "x": 29933,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 73107,
      "e": 72983,
      "ty": 2,
      "x": 853,
      "y": 523
    },
    {
      "t": 73207,
      "e": 73083,
      "ty": 2,
      "x": 855,
      "y": 526
    },
    {
      "t": 73258,
      "e": 73134,
      "ty": 41,
      "x": 43976,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 73307,
      "e": 73183,
      "ty": 2,
      "x": 885,
      "y": 530
    },
    {
      "t": 73407,
      "e": 73283,
      "ty": 2,
      "x": 898,
      "y": 529
    },
    {
      "t": 73507,
      "e": 73383,
      "ty": 2,
      "x": 924,
      "y": 508
    },
    {
      "t": 73507,
      "e": 73383,
      "ty": 41,
      "x": 24344,
      "y": 53832,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 73607,
      "e": 73483,
      "ty": 2,
      "x": 929,
      "y": 492
    },
    {
      "t": 73757,
      "e": 73633,
      "ty": 41,
      "x": 25530,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 74108,
      "e": 73984,
      "ty": 2,
      "x": 925,
      "y": 481
    },
    {
      "t": 74207,
      "e": 74083,
      "ty": 2,
      "x": 917,
      "y": 444
    },
    {
      "t": 74257,
      "e": 74133,
      "ty": 41,
      "x": 21496,
      "y": 51491,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 74307,
      "e": 74183,
      "ty": 2,
      "x": 912,
      "y": 423
    },
    {
      "t": 74408,
      "e": 74284,
      "ty": 2,
      "x": 913,
      "y": 415
    },
    {
      "t": 74507,
      "e": 74383,
      "ty": 2,
      "x": 945,
      "y": 390
    },
    {
      "t": 74507,
      "e": 74383,
      "ty": 41,
      "x": 29328,
      "y": 9478,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 74607,
      "e": 74483,
      "ty": 2,
      "x": 979,
      "y": 379
    },
    {
      "t": 74707,
      "e": 74583,
      "ty": 2,
      "x": 994,
      "y": 373
    },
    {
      "t": 74757,
      "e": 74633,
      "ty": 41,
      "x": 41669,
      "y": 39789,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 74808,
      "e": 74684,
      "ty": 2,
      "x": 997,
      "y": 372
    },
    {
      "t": 74907,
      "e": 74783,
      "ty": 2,
      "x": 1000,
      "y": 372
    },
    {
      "t": 75007,
      "e": 74883,
      "ty": 41,
      "x": 44991,
      "y": 10561,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 75007,
      "e": 74883,
      "ty": 2,
      "x": 1011,
      "y": 394
    },
    {
      "t": 75107,
      "e": 74983,
      "ty": 2,
      "x": 998,
      "y": 435
    },
    {
      "t": 75207,
      "e": 75083,
      "ty": 2,
      "x": 981,
      "y": 453
    },
    {
      "t": 75257,
      "e": 75133,
      "ty": 41,
      "x": 35735,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 75307,
      "e": 75183,
      "ty": 2,
      "x": 967,
      "y": 462
    },
    {
      "t": 75408,
      "e": 75284,
      "ty": 2,
      "x": 946,
      "y": 473
    },
    {
      "t": 75508,
      "e": 75384,
      "ty": 2,
      "x": 937,
      "y": 479
    },
    {
      "t": 75508,
      "e": 75384,
      "ty": 41,
      "x": 27429,
      "y": 51491,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 75608,
      "e": 75484,
      "ty": 2,
      "x": 934,
      "y": 480
    },
    {
      "t": 75757,
      "e": 75633,
      "ty": 41,
      "x": 26717,
      "y": 53832,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 76107,
      "e": 75983,
      "ty": 2,
      "x": 933,
      "y": 483
    },
    {
      "t": 76208,
      "e": 76084,
      "ty": 2,
      "x": 909,
      "y": 498
    },
    {
      "t": 76258,
      "e": 76134,
      "ty": 41,
      "x": 20784,
      "y": 30426,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 76307,
      "e": 76183,
      "ty": 2,
      "x": 905,
      "y": 499
    },
    {
      "t": 76407,
      "e": 76283,
      "ty": 2,
      "x": 887,
      "y": 520
    },
    {
      "t": 76507,
      "e": 76383,
      "ty": 41,
      "x": 63871,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 76507,
      "e": 76383,
      "ty": 2,
      "x": 876,
      "y": 528
    },
    {
      "t": 76707,
      "e": 76583,
      "ty": 2,
      "x": 876,
      "y": 529
    },
    {
      "t": 76757,
      "e": 76633,
      "ty": 41,
      "x": 63871,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 77107,
      "e": 76983,
      "ty": 2,
      "x": 874,
      "y": 520
    },
    {
      "t": 77207,
      "e": 77083,
      "ty": 2,
      "x": 873,
      "y": 517
    },
    {
      "t": 77257,
      "e": 77133,
      "ty": 41,
      "x": 60360,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 77608,
      "e": 77484,
      "ty": 2,
      "x": 875,
      "y": 512
    },
    {
      "t": 77707,
      "e": 77583,
      "ty": 2,
      "x": 877,
      "y": 509
    },
    {
      "t": 77758,
      "e": 77634,
      "ty": 41,
      "x": 52576,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 77807,
      "e": 77683,
      "ty": 2,
      "x": 889,
      "y": 497
    },
    {
      "t": 77907,
      "e": 77783,
      "ty": 2,
      "x": 903,
      "y": 486
    },
    {
      "t": 78008,
      "e": 77884,
      "ty": 41,
      "x": 19360,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 79906,
      "e": 79782,
      "ty": 2,
      "x": 897,
      "y": 504
    },
    {
      "t": 80006,
      "e": 79882,
      "ty": 2,
      "x": 888,
      "y": 552
    },
    {
      "t": 80007,
      "e": 79883,
      "ty": 41,
      "x": 45427,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-1-5 > label"
    },
    {
      "t": 80007,
      "e": 79883,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 80107,
      "e": 79983,
      "ty": 2,
      "x": 889,
      "y": 565
    },
    {
      "t": 80207,
      "e": 80083,
      "ty": 2,
      "x": 889,
      "y": 583
    },
    {
      "t": 80256,
      "e": 80132,
      "ty": 41,
      "x": 16512,
      "y": 44470,
      "ta": "#jspsych-survey-multi-choice-option-1-6"
    },
    {
      "t": 80307,
      "e": 80183,
      "ty": 2,
      "x": 892,
      "y": 591
    },
    {
      "t": 80407,
      "e": 80283,
      "ty": 2,
      "x": 896,
      "y": 597
    },
    {
      "t": 80508,
      "e": 80384,
      "ty": 2,
      "x": 902,
      "y": 604
    },
    {
      "t": 80508,
      "e": 80384,
      "ty": 41,
      "x": 19123,
      "y": 33103,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 80607,
      "e": 80483,
      "ty": 2,
      "x": 902,
      "y": 615
    },
    {
      "t": 80706,
      "e": 80582,
      "ty": 2,
      "x": 890,
      "y": 627
    },
    {
      "t": 80757,
      "e": 80633,
      "ty": 41,
      "x": 15800,
      "y": 30426,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 80806,
      "e": 80682,
      "ty": 2,
      "x": 888,
      "y": 628
    },
    {
      "t": 80908,
      "e": 80784,
      "ty": 2,
      "x": 886,
      "y": 629
    },
    {
      "t": 81007,
      "e": 80883,
      "ty": 2,
      "x": 878,
      "y": 634
    },
    {
      "t": 81007,
      "e": 80883,
      "ty": 41,
      "x": 13427,
      "y": 44470,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 81107,
      "e": 80983,
      "ty": 2,
      "x": 875,
      "y": 636
    },
    {
      "t": 81206,
      "e": 81082,
      "ty": 2,
      "x": 886,
      "y": 636
    },
    {
      "t": 81258,
      "e": 81134,
      "ty": 41,
      "x": 16987,
      "y": 51491,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 81308,
      "e": 81184,
      "ty": 2,
      "x": 896,
      "y": 637
    },
    {
      "t": 81407,
      "e": 81283,
      "ty": 2,
      "x": 908,
      "y": 637
    },
    {
      "t": 81507,
      "e": 81383,
      "ty": 2,
      "x": 935,
      "y": 637
    },
    {
      "t": 81507,
      "e": 81383,
      "ty": 41,
      "x": 26954,
      "y": 51491,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 81607,
      "e": 81483,
      "ty": 2,
      "x": 936,
      "y": 637
    },
    {
      "t": 81707,
      "e": 81583,
      "ty": 2,
      "x": 939,
      "y": 637
    },
    {
      "t": 81756,
      "e": 81632,
      "ty": 41,
      "x": 29090,
      "y": 51491,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 81806,
      "e": 81682,
      "ty": 2,
      "x": 945,
      "y": 636
    },
    {
      "t": 81907,
      "e": 81783,
      "ty": 2,
      "x": 957,
      "y": 635
    },
    {
      "t": 82006,
      "e": 81882,
      "ty": 41,
      "x": 37634,
      "y": 39789,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 82007,
      "e": 81883,
      "ty": 2,
      "x": 980,
      "y": 632
    },
    {
      "t": 82106,
      "e": 81982,
      "ty": 2,
      "x": 1047,
      "y": 632
    },
    {
      "t": 82207,
      "e": 82083,
      "ty": 2,
      "x": 1051,
      "y": 632
    },
    {
      "t": 82257,
      "e": 82133,
      "ty": 41,
      "x": 54484,
      "y": 42129,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 82306,
      "e": 82182,
      "ty": 2,
      "x": 1045,
      "y": 640
    },
    {
      "t": 82407,
      "e": 82283,
      "ty": 2,
      "x": 1017,
      "y": 655
    },
    {
      "t": 82507,
      "e": 82383,
      "ty": 2,
      "x": 987,
      "y": 667
    },
    {
      "t": 82507,
      "e": 82383,
      "ty": 41,
      "x": 44457,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 82606,
      "e": 82482,
      "ty": 2,
      "x": 968,
      "y": 672
    },
    {
      "t": 82706,
      "e": 82582,
      "ty": 2,
      "x": 962,
      "y": 674
    },
    {
      "t": 82757,
      "e": 82633,
      "ty": 41,
      "x": 37208,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 82806,
      "e": 82682,
      "ty": 2,
      "x": 959,
      "y": 675
    },
    {
      "t": 83007,
      "e": 82883,
      "ty": 41,
      "x": 36939,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 83507,
      "e": 83383,
      "ty": 2,
      "x": 956,
      "y": 675
    },
    {
      "t": 83507,
      "e": 83383,
      "ty": 41,
      "x": 36134,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 83606,
      "e": 83482,
      "ty": 2,
      "x": 950,
      "y": 675
    },
    {
      "t": 83707,
      "e": 83583,
      "ty": 2,
      "x": 947,
      "y": 677
    },
    {
      "t": 83757,
      "e": 83633,
      "ty": 41,
      "x": 32643,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 83807,
      "e": 83683,
      "ty": 2,
      "x": 939,
      "y": 684
    },
    {
      "t": 83907,
      "e": 83783,
      "ty": 2,
      "x": 930,
      "y": 694
    },
    {
      "t": 84007,
      "e": 83883,
      "ty": 2,
      "x": 924,
      "y": 699
    },
    {
      "t": 84007,
      "e": 83883,
      "ty": 41,
      "x": 25847,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 84106,
      "e": 83982,
      "ty": 2,
      "x": 916,
      "y": 712
    },
    {
      "t": 84207,
      "e": 84083,
      "ty": 2,
      "x": 900,
      "y": 742
    },
    {
      "t": 84257,
      "e": 84133,
      "ty": 41,
      "x": 30283,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 84307,
      "e": 84183,
      "ty": 2,
      "x": 893,
      "y": 760
    },
    {
      "t": 84407,
      "e": 84283,
      "ty": 2,
      "x": 893,
      "y": 777
    },
    {
      "t": 84507,
      "e": 84383,
      "ty": 2,
      "x": 894,
      "y": 781
    },
    {
      "t": 84507,
      "e": 84383,
      "ty": 41,
      "x": 40631,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 84572,
      "e": 84448,
      "ty": 3,
      "x": 894,
      "y": 781,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 84572,
      "e": 84448,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 84659,
      "e": 84535,
      "ty": 4,
      "x": 40631,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 84659,
      "e": 84535,
      "ty": 5,
      "x": 894,
      "y": 781,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 84659,
      "e": 84535,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 84659,
      "e": 84535,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf",
      "v": "Engineering"
    },
    {
      "t": 85007,
      "e": 84883,
      "ty": 2,
      "x": 889,
      "y": 786
    },
    {
      "t": 85007,
      "e": 84883,
      "ty": 41,
      "x": 37832,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 85107,
      "e": 84983,
      "ty": 2,
      "x": 879,
      "y": 800
    },
    {
      "t": 85207,
      "e": 85083,
      "ty": 2,
      "x": 872,
      "y": 823
    },
    {
      "t": 85257,
      "e": 85133,
      "ty": 41,
      "x": 9867,
      "y": 53130,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 85307,
      "e": 85183,
      "ty": 2,
      "x": 855,
      "y": 909
    },
    {
      "t": 85407,
      "e": 85283,
      "ty": 2,
      "x": 852,
      "y": 916
    },
    {
      "t": 85507,
      "e": 85383,
      "ty": 41,
      "x": 7256,
      "y": 20668,
      "ta": "#jspsych-survey-multi-choice-3"
    },
    {
      "t": 85607,
      "e": 85483,
      "ty": 2,
      "x": 855,
      "y": 930
    },
    {
      "t": 85684,
      "e": 85484,
      "ty": 3,
      "x": 855,
      "y": 930,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 85684,
      "e": 85484,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 85757,
      "e": 85557,
      "ty": 41,
      "x": 36675,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 85771,
      "e": 85571,
      "ty": 4,
      "x": 36675,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 85771,
      "e": 85571,
      "ty": 5,
      "x": 855,
      "y": 930,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 85771,
      "e": 85571,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 85772,
      "e": 85572,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 85906,
      "e": 85706,
      "ty": 2,
      "x": 854,
      "y": 948
    },
    {
      "t": 86007,
      "e": 85807,
      "ty": 2,
      "x": 869,
      "y": 1000
    },
    {
      "t": 86007,
      "e": 85807,
      "ty": 41,
      "x": 47231,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-3-2 > label"
    },
    {
      "t": 86013,
      "e": 85813,
      "ty": 6,
      "x": 872,
      "y": 1011,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 86107,
      "e": 85907,
      "ty": 2,
      "x": 876,
      "y": 1018
    },
    {
      "t": 86207,
      "e": 86007,
      "ty": 2,
      "x": 880,
      "y": 1031
    },
    {
      "t": 86257,
      "e": 86057,
      "ty": 41,
      "x": 26067,
      "y": 51633,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 86407,
      "e": 86207,
      "ty": 2,
      "x": 881,
      "y": 1030
    },
    {
      "t": 86427,
      "e": 86227,
      "ty": 3,
      "x": 881,
      "y": 1030,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 86427,
      "e": 86227,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 86427,
      "e": 86227,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 86506,
      "e": 86306,
      "ty": 2,
      "x": 883,
      "y": 1028
    },
    {
      "t": 86507,
      "e": 86307,
      "ty": 41,
      "x": 27613,
      "y": 45675,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 86515,
      "e": 86315,
      "ty": 4,
      "x": 27613,
      "y": 45675,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 86516,
      "e": 86316,
      "ty": 5,
      "x": 883,
      "y": 1028,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 86519,
      "e": 86319,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 86519,
      "e": 86319,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 86520,
      "e": 86320,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 86757,
      "e": 86557,
      "ty": 41,
      "x": 30098,
      "y": 56505,
      "ta": "html > body"
    },
    {
      "t": 86807,
      "e": 86607,
      "ty": 2,
      "x": 881,
      "y": 1027
    },
    {
      "t": 86907,
      "e": 86707,
      "ty": 2,
      "x": 878,
      "y": 1024
    },
    {
      "t": 87007,
      "e": 86807,
      "ty": 2,
      "x": 877,
      "y": 1010
    },
    {
      "t": 87008,
      "e": 86808,
      "ty": 41,
      "x": 29926,
      "y": 55508,
      "ta": "html > body"
    },
    {
      "t": 87107,
      "e": 86907,
      "ty": 2,
      "x": 871,
      "y": 954
    },
    {
      "t": 87207,
      "e": 87007,
      "ty": 2,
      "x": 850,
      "y": 860
    },
    {
      "t": 87257,
      "e": 87057,
      "ty": 41,
      "x": 28652,
      "y": 45591,
      "ta": "html > body"
    },
    {
      "t": 87307,
      "e": 87107,
      "ty": 2,
      "x": 820,
      "y": 781
    },
    {
      "t": 87407,
      "e": 87207,
      "ty": 2,
      "x": 810,
      "y": 757
    },
    {
      "t": 87506,
      "e": 87306,
      "ty": 41,
      "x": 27584,
      "y": 41492,
      "ta": "html > body"
    },
    {
      "t": 87507,
      "e": 87307,
      "ty": 2,
      "x": 809,
      "y": 757
    },
    {
      "t": 87607,
      "e": 87407,
      "ty": 2,
      "x": 802,
      "y": 757
    },
    {
      "t": 87757,
      "e": 87557,
      "ty": 41,
      "x": 27343,
      "y": 41492,
      "ta": "html > body"
    },
    {
      "t": 87840,
      "e": 87640,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 88207,
      "e": 88007,
      "ty": 2,
      "x": 779,
      "y": 758
    },
    {
      "t": 88257,
      "e": 88057,
      "ty": 41,
      "x": 15868,
      "y": 48282,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 88307,
      "e": 88107,
      "ty": 2,
      "x": 478,
      "y": 675
    },
    {
      "t": 88407,
      "e": 88207,
      "ty": 2,
      "x": 334,
      "y": 444
    },
    {
      "t": 88507,
      "e": 88307,
      "ty": 2,
      "x": 322,
      "y": 296
    },
    {
      "t": 88507,
      "e": 88307,
      "ty": 41,
      "x": 1404,
      "y": 11751,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 88707,
      "e": 88507,
      "ty": 2,
      "x": 315,
      "y": 296
    },
    {
      "t": 88757,
      "e": 88557,
      "ty": 41,
      "x": 863,
      "y": 13067,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 88807,
      "e": 88607,
      "ty": 2,
      "x": 316,
      "y": 332
    },
    {
      "t": 88907,
      "e": 88707,
      "ty": 2,
      "x": 317,
      "y": 335
    },
    {
      "t": 89007,
      "e": 88807,
      "ty": 2,
      "x": 317,
      "y": 336
    },
    {
      "t": 89007,
      "e": 88807,
      "ty": 41,
      "x": 1158,
      "y": 3547,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 89107,
      "e": 88907,
      "ty": 2,
      "x": 317,
      "y": 337
    },
    {
      "t": 89257,
      "e": 89057,
      "ty": 41,
      "x": 1158,
      "y": 5887,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 89707,
      "e": 89507,
      "ty": 2,
      "x": 327,
      "y": 334
    },
    {
      "t": 89757,
      "e": 89557,
      "ty": 41,
      "x": 2339,
      "y": 13690,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 89807,
      "e": 89607,
      "ty": 2,
      "x": 350,
      "y": 306
    },
    {
      "t": 89906,
      "e": 89706,
      "ty": 2,
      "x": 353,
      "y": 302
    },
    {
      "t": 90007,
      "e": 89807,
      "ty": 2,
      "x": 390,
      "y": 337
    },
    {
      "t": 90008,
      "e": 89808,
      "ty": 41,
      "x": 4749,
      "y": 5887,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 90108,
      "e": 89908,
      "ty": 2,
      "x": 391,
      "y": 338
    },
    {
      "t": 90179,
      "e": 89979,
      "ty": 3,
      "x": 404,
      "y": 343,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 90207,
      "e": 90007,
      "ty": 2,
      "x": 416,
      "y": 347
    },
    {
      "t": 90257,
      "e": 90057,
      "ty": 41,
      "x": 7554,
      "y": 48017,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 90307,
      "e": 90107,
      "ty": 2,
      "x": 472,
      "y": 358
    },
    {
      "t": 90407,
      "e": 90207,
      "ty": 2,
      "x": 598,
      "y": 358
    },
    {
      "t": 90507,
      "e": 90307,
      "ty": 2,
      "x": 658,
      "y": 341
    },
    {
      "t": 90507,
      "e": 90307,
      "ty": 41,
      "x": 17934,
      "y": 15250,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 90607,
      "e": 90407,
      "ty": 2,
      "x": 740,
      "y": 326
    },
    {
      "t": 90707,
      "e": 90507,
      "ty": 2,
      "x": 878,
      "y": 320
    },
    {
      "t": 90757,
      "e": 90557,
      "ty": 41,
      "x": 31414,
      "y": 13136,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 90807,
      "e": 90607,
      "ty": 2,
      "x": 988,
      "y": 309
    },
    {
      "t": 90906,
      "e": 90706,
      "ty": 2,
      "x": 1164,
      "y": 303
    },
    {
      "t": 91007,
      "e": 90807,
      "ty": 2,
      "x": 1273,
      "y": 313
    },
    {
      "t": 91007,
      "e": 90807,
      "ty": 41,
      "x": 48190,
      "y": 12928,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 91051,
      "e": 90851,
      "ty": 4,
      "x": 48190,
      "y": 12928,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 91051,
      "e": 90851,
      "ty": 5,
      "x": 1273,
      "y": 313,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 91107,
      "e": 90907,
      "ty": 2,
      "x": 1273,
      "y": 316
    },
    {
      "t": 91207,
      "e": 91007,
      "ty": 2,
      "x": 1158,
      "y": 376
    },
    {
      "t": 91257,
      "e": 91057,
      "ty": 41,
      "x": 32300,
      "y": 34730,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 91306,
      "e": 91106,
      "ty": 2,
      "x": 694,
      "y": 443
    },
    {
      "t": 91407,
      "e": 91207,
      "ty": 2,
      "x": 581,
      "y": 447
    },
    {
      "t": 91419,
      "e": 91219,
      "ty": 3,
      "x": 581,
      "y": 447,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 91483,
      "e": 91283,
      "ty": 4,
      "x": 14146,
      "y": 51894,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 91483,
      "e": 91283,
      "ty": 5,
      "x": 581,
      "y": 447,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 91507,
      "e": 91307,
      "ty": 41,
      "x": 14146,
      "y": 51894,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 91607,
      "e": 91407,
      "ty": 2,
      "x": 558,
      "y": 448
    },
    {
      "t": 91706,
      "e": 91506,
      "ty": 2,
      "x": 475,
      "y": 429
    },
    {
      "t": 91757,
      "e": 91506,
      "ty": 41,
      "x": 8242,
      "y": 32389,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 91807,
      "e": 91556,
      "ty": 2,
      "x": 445,
      "y": 416
    },
    {
      "t": 91907,
      "e": 91656,
      "ty": 2,
      "x": 426,
      "y": 407
    },
    {
      "t": 92007,
      "e": 91756,
      "ty": 41,
      "x": 6520,
      "y": 20686,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 92207,
      "e": 91956,
      "ty": 2,
      "x": 429,
      "y": 406
    },
    {
      "t": 92257,
      "e": 92006,
      "ty": 41,
      "x": 52139,
      "y": 60671,
      "ta": "> div.masterdiv > div:[2] > div > p:[2] > b"
    },
    {
      "t": 92307,
      "e": 92056,
      "ty": 2,
      "x": 443,
      "y": 403
    },
    {
      "t": 92407,
      "e": 92156,
      "ty": 2,
      "x": 444,
      "y": 403
    },
    {
      "t": 92507,
      "e": 92256,
      "ty": 2,
      "x": 445,
      "y": 403
    },
    {
      "t": 92507,
      "e": 92256,
      "ty": 41,
      "x": 52836,
      "y": 60671,
      "ta": "> div.masterdiv > div:[2] > div > p:[2] > b"
    },
    {
      "t": 92607,
      "e": 92356,
      "ty": 2,
      "x": 446,
      "y": 403
    },
    {
      "t": 92706,
      "e": 92455,
      "ty": 2,
      "x": 457,
      "y": 403
    },
    {
      "t": 92757,
      "e": 92506,
      "ty": 41,
      "x": 60506,
      "y": 57394,
      "ta": "> div.masterdiv > div:[2] > div > p:[2] > b"
    },
    {
      "t": 92807,
      "e": 92556,
      "ty": 2,
      "x": 471,
      "y": 401
    },
    {
      "t": 92907,
      "e": 92656,
      "ty": 2,
      "x": 500,
      "y": 398
    },
    {
      "t": 93007,
      "e": 92756,
      "ty": 2,
      "x": 585,
      "y": 393
    },
    {
      "t": 93007,
      "e": 92756,
      "ty": 41,
      "x": 14343,
      "y": 9764,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 93107,
      "e": 92856,
      "ty": 2,
      "x": 592,
      "y": 393
    },
    {
      "t": 93130,
      "e": 92879,
      "ty": 3,
      "x": 592,
      "y": 393,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 93207,
      "e": 92956,
      "ty": 2,
      "x": 610,
      "y": 393
    },
    {
      "t": 93258,
      "e": 93007,
      "ty": 41,
      "x": 16999,
      "y": 9764,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 93308,
      "e": 93057,
      "ty": 2,
      "x": 694,
      "y": 393
    },
    {
      "t": 93407,
      "e": 93156,
      "ty": 2,
      "x": 769,
      "y": 400
    },
    {
      "t": 93507,
      "e": 93256,
      "ty": 41,
      "x": 23395,
      "y": 15225,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 93779,
      "e": 93528,
      "ty": 4,
      "x": 23444,
      "y": 15225,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 93779,
      "e": 93528,
      "ty": 5,
      "x": 770,
      "y": 400,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 93807,
      "e": 93556,
      "ty": 2,
      "x": 770,
      "y": 400
    },
    {
      "t": 94007,
      "e": 93756,
      "ty": 41,
      "x": 23444,
      "y": 15225,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 94011,
      "e": 93760,
      "ty": 3,
      "x": 770,
      "y": 400,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 94130,
      "e": 93879,
      "ty": 4,
      "x": 23444,
      "y": 15225,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 94130,
      "e": 93879,
      "ty": 5,
      "x": 770,
      "y": 400,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 97408,
      "e": 97157,
      "ty": 2,
      "x": 714,
      "y": 424
    },
    {
      "t": 97507,
      "e": 97256,
      "ty": 2,
      "x": 698,
      "y": 428
    },
    {
      "t": 97507,
      "e": 97256,
      "ty": 41,
      "x": 19902,
      "y": 37070,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 97607,
      "e": 97356,
      "ty": 2,
      "x": 670,
      "y": 439
    },
    {
      "t": 97707,
      "e": 97456,
      "ty": 2,
      "x": 660,
      "y": 444
    },
    {
      "t": 97758,
      "e": 97507,
      "ty": 41,
      "x": 17688,
      "y": 51894,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 97808,
      "e": 97557,
      "ty": 2,
      "x": 640,
      "y": 453
    },
    {
      "t": 97908,
      "e": 97657,
      "ty": 2,
      "x": 621,
      "y": 464
    },
    {
      "t": 98007,
      "e": 97756,
      "ty": 2,
      "x": 599,
      "y": 475
    },
    {
      "t": 98007,
      "e": 97756,
      "ty": 41,
      "x": 15031,
      "y": 16269,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 98107,
      "e": 97856,
      "ty": 2,
      "x": 582,
      "y": 483
    },
    {
      "t": 98208,
      "e": 97957,
      "ty": 2,
      "x": 576,
      "y": 484
    },
    {
      "t": 98258,
      "e": 98007,
      "ty": 41,
      "x": 13752,
      "y": 1371,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 98307,
      "e": 98056,
      "ty": 2,
      "x": 569,
      "y": 487
    },
    {
      "t": 98407,
      "e": 98156,
      "ty": 2,
      "x": 552,
      "y": 493
    },
    {
      "t": 98507,
      "e": 98256,
      "ty": 2,
      "x": 513,
      "y": 502
    },
    {
      "t": 98507,
      "e": 98256,
      "ty": 41,
      "x": 60966,
      "y": 50840,
      "ta": "> div.masterdiv > div:[2] > div > p:[3] > b"
    },
    {
      "t": 98607,
      "e": 98356,
      "ty": 2,
      "x": 424,
      "y": 508
    },
    {
      "t": 98707,
      "e": 98456,
      "ty": 2,
      "x": 372,
      "y": 514
    },
    {
      "t": 98758,
      "e": 98507,
      "ty": 41,
      "x": 3815,
      "y": 12293,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 98808,
      "e": 98557,
      "ty": 2,
      "x": 371,
      "y": 514
    },
    {
      "t": 99008,
      "e": 98757,
      "ty": 2,
      "x": 384,
      "y": 509
    },
    {
      "t": 99008,
      "e": 98757,
      "ty": 41,
      "x": 4454,
      "y": 10343,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 99107,
      "e": 98856,
      "ty": 2,
      "x": 415,
      "y": 496
    },
    {
      "t": 99208,
      "e": 98957,
      "ty": 2,
      "x": 425,
      "y": 493
    },
    {
      "t": 99257,
      "e": 99006,
      "ty": 41,
      "x": 37917,
      "y": 21350,
      "ta": "> div.masterdiv > div:[2] > div > p:[3] > b"
    },
    {
      "t": 99307,
      "e": 99056,
      "ty": 2,
      "x": 431,
      "y": 493
    },
    {
      "t": 99407,
      "e": 99156,
      "ty": 2,
      "x": 435,
      "y": 493
    },
    {
      "t": 99508,
      "e": 99257,
      "ty": 2,
      "x": 443,
      "y": 494
    },
    {
      "t": 99508,
      "e": 99257,
      "ty": 41,
      "x": 41527,
      "y": 24626,
      "ta": "> div.masterdiv > div:[2] > div > p:[3] > b"
    },
    {
      "t": 99607,
      "e": 99356,
      "ty": 2,
      "x": 447,
      "y": 495
    },
    {
      "t": 99707,
      "e": 99456,
      "ty": 2,
      "x": 472,
      "y": 499
    },
    {
      "t": 99758,
      "e": 99507,
      "ty": 41,
      "x": 54856,
      "y": 41010,
      "ta": "> div.masterdiv > div:[2] > div > p:[3] > b"
    },
    {
      "t": 99808,
      "e": 99557,
      "ty": 2,
      "x": 508,
      "y": 499
    },
    {
      "t": 99907,
      "e": 99656,
      "ty": 2,
      "x": 516,
      "y": 499
    },
    {
      "t": 100008,
      "e": 99757,
      "ty": 41,
      "x": 61799,
      "y": 41010,
      "ta": "> div.masterdiv > div:[2] > div > p:[3] > b"
    },
    {
      "t": 100008,
      "e": 99757,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 100257,
      "e": 100006,
      "ty": 41,
      "x": 62076,
      "y": 41010,
      "ta": "> div.masterdiv > div:[2] > div > p:[3] > b"
    },
    {
      "t": 100307,
      "e": 100056,
      "ty": 2,
      "x": 517,
      "y": 499
    },
    {
      "t": 100408,
      "e": 100157,
      "ty": 2,
      "x": 518,
      "y": 499
    },
    {
      "t": 100507,
      "e": 100256,
      "ty": 2,
      "x": 527,
      "y": 499
    },
    {
      "t": 100507,
      "e": 100256,
      "ty": 41,
      "x": 64853,
      "y": 41010,
      "ta": "> div.masterdiv > div:[2] > div > p:[3] > b"
    },
    {
      "t": 100587,
      "e": 100336,
      "ty": 3,
      "x": 533,
      "y": 498,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 100607,
      "e": 100356,
      "ty": 2,
      "x": 534,
      "y": 498
    },
    {
      "t": 100706,
      "e": 100455,
      "ty": 2,
      "x": 546,
      "y": 498
    },
    {
      "t": 100758,
      "e": 100507,
      "ty": 41,
      "x": 14589,
      "y": 9563,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 100807,
      "e": 100556,
      "ty": 2,
      "x": 652,
      "y": 529
    },
    {
      "t": 100907,
      "e": 100656,
      "ty": 2,
      "x": 706,
      "y": 551
    },
    {
      "t": 101007,
      "e": 100756,
      "ty": 2,
      "x": 708,
      "y": 552
    },
    {
      "t": 101008,
      "e": 100757,
      "ty": 41,
      "x": 20394,
      "y": 27117,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 101107,
      "e": 100856,
      "ty": 2,
      "x": 718,
      "y": 555
    },
    {
      "t": 101162,
      "e": 100911,
      "ty": 4,
      "x": 20886,
      "y": 28287,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 101162,
      "e": 100911,
      "ty": 5,
      "x": 718,
      "y": 555,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 101257,
      "e": 101006,
      "ty": 41,
      "x": 20984,
      "y": 28287,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 101299,
      "e": 101048,
      "ty": 3,
      "x": 720,
      "y": 555,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 101307,
      "e": 101056,
      "ty": 2,
      "x": 720,
      "y": 555
    },
    {
      "t": 101370,
      "e": 101119,
      "ty": 4,
      "x": 20984,
      "y": 28287,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 101371,
      "e": 101120,
      "ty": 5,
      "x": 720,
      "y": 555,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 101757,
      "e": 101506,
      "ty": 41,
      "x": 20148,
      "y": 31408,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 101808,
      "e": 101557,
      "ty": 2,
      "x": 670,
      "y": 584
    },
    {
      "t": 101908,
      "e": 101657,
      "ty": 2,
      "x": 624,
      "y": 664
    },
    {
      "t": 102007,
      "e": 101756,
      "ty": 2,
      "x": 608,
      "y": 691
    },
    {
      "t": 102007,
      "e": 101756,
      "ty": 41,
      "x": 15474,
      "y": 13174,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 102507,
      "e": 102256,
      "ty": 2,
      "x": 608,
      "y": 692
    },
    {
      "t": 102507,
      "e": 102256,
      "ty": 41,
      "x": 15474,
      "y": 13759,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 102707,
      "e": 102456,
      "ty": 2,
      "x": 608,
      "y": 690
    },
    {
      "t": 102756,
      "e": 102505,
      "ty": 41,
      "x": 15474,
      "y": 12589,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 102883,
      "e": 102632,
      "ty": 3,
      "x": 646,
      "y": 687,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 102907,
      "e": 102656,
      "ty": 2,
      "x": 651,
      "y": 688
    },
    {
      "t": 103007,
      "e": 102756,
      "ty": 2,
      "x": 701,
      "y": 709
    },
    {
      "t": 103007,
      "e": 102756,
      "ty": 41,
      "x": 20050,
      "y": 23707,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 103107,
      "e": 102856,
      "ty": 2,
      "x": 745,
      "y": 739
    },
    {
      "t": 103171,
      "e": 102920,
      "ty": 4,
      "x": 23297,
      "y": 47697,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 103171,
      "e": 102920,
      "ty": 5,
      "x": 767,
      "y": 750,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 103207,
      "e": 102956,
      "ty": 2,
      "x": 772,
      "y": 751
    },
    {
      "t": 103257,
      "e": 103006,
      "ty": 41,
      "x": 24330,
      "y": 50623,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 103306,
      "e": 103055,
      "ty": 2,
      "x": 792,
      "y": 756
    },
    {
      "t": 103406,
      "e": 103155,
      "ty": 2,
      "x": 795,
      "y": 756
    },
    {
      "t": 103507,
      "e": 103256,
      "ty": 2,
      "x": 799,
      "y": 755
    },
    {
      "t": 103507,
      "e": 103256,
      "ty": 41,
      "x": 24871,
      "y": 50623,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 103606,
      "e": 103355,
      "ty": 2,
      "x": 804,
      "y": 753
    },
    {
      "t": 103757,
      "e": 103506,
      "ty": 41,
      "x": 25117,
      "y": 49452,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 107757,
      "e": 107506,
      "ty": 41,
      "x": 25068,
      "y": 49452,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 107807,
      "e": 107556,
      "ty": 2,
      "x": 792,
      "y": 752
    },
    {
      "t": 108008,
      "e": 107757,
      "ty": 41,
      "x": 24527,
      "y": 48867,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 108507,
      "e": 108256,
      "ty": 2,
      "x": 791,
      "y": 751
    },
    {
      "t": 108507,
      "e": 108256,
      "ty": 41,
      "x": 24477,
      "y": 48282,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 110007,
      "e": 109756,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 111757,
      "e": 111506,
      "ty": 3,
      "x": 791,
      "y": 751,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 111868,
      "e": 111617,
      "ty": 4,
      "x": 24477,
      "y": 48282,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 111868,
      "e": 111617,
      "ty": 5,
      "x": 791,
      "y": 751,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 112107,
      "e": 111856,
      "ty": 2,
      "x": 798,
      "y": 733
    },
    {
      "t": 112207,
      "e": 111956,
      "ty": 2,
      "x": 798,
      "y": 731
    },
    {
      "t": 112257,
      "e": 112006,
      "ty": 41,
      "x": 24822,
      "y": 36580,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 112757,
      "e": 112506,
      "ty": 41,
      "x": 24674,
      "y": 45942,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 112807,
      "e": 112556,
      "ty": 2,
      "x": 793,
      "y": 790
    },
    {
      "t": 112907,
      "e": 112656,
      "ty": 2,
      "x": 789,
      "y": 796
    },
    {
      "t": 113007,
      "e": 112756,
      "ty": 41,
      "x": 24379,
      "y": 53437,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 113407,
      "e": 113156,
      "ty": 2,
      "x": 789,
      "y": 800
    },
    {
      "t": 113507,
      "e": 113256,
      "ty": 2,
      "x": 789,
      "y": 810
    },
    {
      "t": 113508,
      "e": 113257,
      "ty": 41,
      "x": 24379,
      "y": 13476,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 113607,
      "e": 113356,
      "ty": 2,
      "x": 795,
      "y": 836
    },
    {
      "t": 113757,
      "e": 113506,
      "ty": 41,
      "x": 24674,
      "y": 43903,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 113807,
      "e": 113556,
      "ty": 2,
      "x": 796,
      "y": 837
    },
    {
      "t": 113907,
      "e": 113656,
      "ty": 2,
      "x": 814,
      "y": 806
    },
    {
      "t": 114007,
      "e": 113756,
      "ty": 2,
      "x": 814,
      "y": 805
    },
    {
      "t": 114008,
      "e": 113757,
      "ty": 41,
      "x": 25609,
      "y": 7625,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 114196,
      "e": 113945,
      "ty": 3,
      "x": 814,
      "y": 805,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 114207,
      "e": 113956,
      "ty": 2,
      "x": 818,
      "y": 807
    },
    {
      "t": 114258,
      "e": 114007,
      "ty": 41,
      "x": 26986,
      "y": 41562,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 114307,
      "e": 114056,
      "ty": 2,
      "x": 849,
      "y": 847
    },
    {
      "t": 114371,
      "e": 114120,
      "ty": 4,
      "x": 27331,
      "y": 57946,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 114371,
      "e": 114120,
      "ty": 5,
      "x": 849,
      "y": 848,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 114407,
      "e": 114156,
      "ty": 2,
      "x": 849,
      "y": 848
    },
    {
      "t": 114499,
      "e": 114248,
      "ty": 3,
      "x": 851,
      "y": 847,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 114507,
      "e": 114256,
      "ty": 2,
      "x": 851,
      "y": 847
    },
    {
      "t": 114508,
      "e": 114257,
      "ty": 41,
      "x": 27429,
      "y": 56776,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 114595,
      "e": 114344,
      "ty": 4,
      "x": 27429,
      "y": 56776,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 114596,
      "e": 114345,
      "ty": 5,
      "x": 851,
      "y": 847,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 114707,
      "e": 114456,
      "ty": 2,
      "x": 861,
      "y": 868
    },
    {
      "t": 114758,
      "e": 114507,
      "ty": 41,
      "x": 29791,
      "y": 55031,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 114807,
      "e": 114556,
      "ty": 2,
      "x": 924,
      "y": 945
    },
    {
      "t": 114907,
      "e": 114656,
      "ty": 2,
      "x": 901,
      "y": 969
    },
    {
      "t": 115007,
      "e": 114756,
      "ty": 2,
      "x": 867,
      "y": 994
    },
    {
      "t": 115008,
      "e": 114757,
      "ty": 41,
      "x": 28216,
      "y": 60086,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 115107,
      "e": 114856,
      "ty": 2,
      "x": 882,
      "y": 1035
    },
    {
      "t": 115207,
      "e": 114956,
      "ty": 2,
      "x": 885,
      "y": 1042
    },
    {
      "t": 115258,
      "e": 115007,
      "ty": 41,
      "x": 29102,
      "y": 63409,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 115408,
      "e": 115157,
      "ty": 2,
      "x": 906,
      "y": 1065
    },
    {
      "t": 115437,
      "e": 115186,
      "ty": 6,
      "x": 923,
      "y": 1078,
      "ta": "#start"
    },
    {
      "t": 115507,
      "e": 115256,
      "ty": 2,
      "x": 952,
      "y": 1094
    },
    {
      "t": 115507,
      "e": 115256,
      "ty": 41,
      "x": 23210,
      "y": 41079,
      "ta": "#start"
    },
    {
      "t": 115607,
      "e": 115356,
      "ty": 2,
      "x": 954,
      "y": 1095
    },
    {
      "t": 115755,
      "e": 115504,
      "ty": 3,
      "x": 954,
      "y": 1095,
      "ta": "#start"
    },
    {
      "t": 115757,
      "e": 115506,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 115758,
      "e": 115507,
      "ty": 41,
      "x": 24302,
      "y": 43007,
      "ta": "#start"
    },
    {
      "t": 115827,
      "e": 115576,
      "ty": 4,
      "x": 24302,
      "y": 43007,
      "ta": "#start"
    },
    {
      "t": 115827,
      "e": 115576,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 115827,
      "e": 115576,
      "ty": 5,
      "x": 954,
      "y": 1095,
      "ta": "#start"
    },
    {
      "t": 115829,
      "e": 115578,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 116858,
      "e": 116607,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 117508,
      "e": 117257,
      "ty": 2,
      "x": 940,
      "y": 1081
    },
    {
      "t": 117508,
      "e": 117257,
      "ty": 41,
      "x": 31864,
      "y": 32917,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 117607,
      "e": 117356,
      "ty": 2,
      "x": 846,
      "y": 1028
    },
    {
      "t": 117707,
      "e": 117456,
      "ty": 2,
      "x": 851,
      "y": 988
    },
    {
      "t": 117757,
      "e": 117506,
      "ty": 41,
      "x": 26817,
      "y": 32875,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 117807,
      "e": 117556,
      "ty": 2,
      "x": 782,
      "y": 855
    },
    {
      "t": 117880,
      "e": 117629,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 14698, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 32, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 14703, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"DJRH1\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 72074, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 87874, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"DJRH1\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 8917, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"XRAY\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"311\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 97795, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"DJRH1\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 22006, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 121148, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"DJRH1\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 9090, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 131241, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"DJRH1\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 23576, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 156192, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"DJRH1\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -O -O -O -O -H -H -H -C -A -A -F \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1879,y:516,t:1527876560817};\\\", \\\"{x:1876,y:518,t:1527876560833};\\\", \\\"{x:1870,y:520,t:1527876560846};\\\", \\\"{x:1854,y:527,t:1527876560863};\\\", \\\"{x:1834,y:535,t:1527876560880};\\\", \\\"{x:1822,y:542,t:1527876560896};\\\", \\\"{x:1821,y:542,t:1527876560913};\\\", \\\"{x:1820,y:544,t:1527876560930};\\\", \\\"{x:1814,y:547,t:1527876560946};\\\", \\\"{x:1805,y:551,t:1527876560963};\\\", \\\"{x:1798,y:555,t:1527876560980};\\\", \\\"{x:1788,y:558,t:1527876560996};\\\", \\\"{x:1785,y:562,t:1527876561013};\\\", \\\"{x:1782,y:565,t:1527876561030};\\\", \\\"{x:1778,y:570,t:1527876561046};\\\", \\\"{x:1774,y:574,t:1527876561063};\\\", \\\"{x:1766,y:574,t:1527876561080};\\\", \\\"{x:1758,y:574,t:1527876561096};\\\", \\\"{x:1757,y:574,t:1527876561113};\\\", \\\"{x:1755,y:574,t:1527876563169};\\\", \\\"{x:1752,y:573,t:1527876563182};\\\", \\\"{x:1744,y:570,t:1527876563199};\\\", \\\"{x:1721,y:560,t:1527876563215};\\\", \\\"{x:1679,y:542,t:1527876563232};\\\", \\\"{x:1589,y:509,t:1527876563249};\\\", \\\"{x:1539,y:497,t:1527876563265};\\\", \\\"{x:1497,y:484,t:1527876563282};\\\", \\\"{x:1467,y:477,t:1527876563298};\\\", \\\"{x:1450,y:474,t:1527876563315};\\\", \\\"{x:1442,y:474,t:1527876563332};\\\", \\\"{x:1437,y:474,t:1527876563349};\\\", \\\"{x:1431,y:475,t:1527876563366};\\\", \\\"{x:1421,y:476,t:1527876563382};\\\", \\\"{x:1407,y:479,t:1527876563398};\\\", \\\"{x:1394,y:484,t:1527876563416};\\\", \\\"{x:1388,y:485,t:1527876563432};\\\", \\\"{x:1380,y:490,t:1527876563449};\\\", \\\"{x:1375,y:492,t:1527876563465};\\\", \\\"{x:1370,y:493,t:1527876563482};\\\", \\\"{x:1364,y:495,t:1527876563499};\\\", \\\"{x:1362,y:495,t:1527876563516};\\\", \\\"{x:1359,y:495,t:1527876563532};\\\", \\\"{x:1358,y:495,t:1527876563548};\\\", \\\"{x:1356,y:495,t:1527876563569};\\\", \\\"{x:1354,y:495,t:1527876563582};\\\", \\\"{x:1352,y:495,t:1527876563598};\\\", \\\"{x:1349,y:495,t:1527876563616};\\\", \\\"{x:1345,y:495,t:1527876563632};\\\", \\\"{x:1333,y:495,t:1527876563650};\\\", \\\"{x:1328,y:495,t:1527876563665};\\\", \\\"{x:1324,y:495,t:1527876563682};\\\", \\\"{x:1322,y:495,t:1527876563705};\\\", \\\"{x:1321,y:495,t:1527876563729};\\\", \\\"{x:1319,y:495,t:1527876563745};\\\", \\\"{x:1318,y:495,t:1527876563781};\\\", \\\"{x:1317,y:495,t:1527876563840};\\\", \\\"{x:1316,y:495,t:1527876563849};\\\", \\\"{x:1314,y:495,t:1527876563865};\\\", \\\"{x:1312,y:495,t:1527876563882};\\\", \\\"{x:1311,y:495,t:1527876569345};\\\", \\\"{x:1310,y:496,t:1527876569354};\\\", \\\"{x:1307,y:500,t:1527876569371};\\\", \\\"{x:1305,y:508,t:1527876569387};\\\", \\\"{x:1305,y:518,t:1527876569403};\\\", \\\"{x:1305,y:529,t:1527876569419};\\\", \\\"{x:1305,y:541,t:1527876569436};\\\", \\\"{x:1305,y:553,t:1527876569453};\\\", \\\"{x:1306,y:561,t:1527876569470};\\\", \\\"{x:1307,y:567,t:1527876569486};\\\", \\\"{x:1308,y:571,t:1527876569504};\\\", \\\"{x:1310,y:581,t:1527876569520};\\\", \\\"{x:1311,y:585,t:1527876569536};\\\", \\\"{x:1312,y:588,t:1527876569553};\\\", \\\"{x:1313,y:591,t:1527876569571};\\\", \\\"{x:1313,y:592,t:1527876569587};\\\", \\\"{x:1314,y:593,t:1527876569632};\\\", \\\"{x:1314,y:595,t:1527876569641};\\\", \\\"{x:1314,y:597,t:1527876569654};\\\", \\\"{x:1314,y:603,t:1527876569671};\\\", \\\"{x:1314,y:608,t:1527876569687};\\\", \\\"{x:1314,y:612,t:1527876569704};\\\", \\\"{x:1314,y:613,t:1527876569720};\\\", \\\"{x:1314,y:614,t:1527876569737};\\\", \\\"{x:1314,y:617,t:1527876569754};\\\", \\\"{x:1314,y:621,t:1527876569771};\\\", \\\"{x:1314,y:627,t:1527876569788};\\\", \\\"{x:1314,y:633,t:1527876569803};\\\", \\\"{x:1314,y:637,t:1527876569821};\\\", \\\"{x:1314,y:638,t:1527876569836};\\\", \\\"{x:1313,y:639,t:1527876569864};\\\", \\\"{x:1312,y:637,t:1527876570090};\\\", \\\"{x:1312,y:633,t:1527876570108};\\\", \\\"{x:1314,y:622,t:1527876570121};\\\", \\\"{x:1321,y:611,t:1527876570138};\\\", \\\"{x:1329,y:602,t:1527876570153};\\\", \\\"{x:1334,y:598,t:1527876570170};\\\", \\\"{x:1339,y:594,t:1527876570188};\\\", \\\"{x:1342,y:592,t:1527876570203};\\\", \\\"{x:1345,y:590,t:1527876570220};\\\", \\\"{x:1348,y:587,t:1527876570237};\\\", \\\"{x:1354,y:583,t:1527876570253};\\\", \\\"{x:1362,y:578,t:1527876570270};\\\", \\\"{x:1374,y:569,t:1527876570287};\\\", \\\"{x:1384,y:565,t:1527876570303};\\\", \\\"{x:1395,y:560,t:1527876570320};\\\", \\\"{x:1403,y:557,t:1527876570337};\\\", \\\"{x:1408,y:556,t:1527876570354};\\\", \\\"{x:1409,y:556,t:1527876570393};\\\", \\\"{x:1410,y:556,t:1527876570538};\\\", \\\"{x:1409,y:559,t:1527876570556};\\\", \\\"{x:1409,y:561,t:1527876570574};\\\", \\\"{x:1408,y:563,t:1527876570588};\\\", \\\"{x:1408,y:565,t:1527876570604};\\\", \\\"{x:1408,y:567,t:1527876570620};\\\", \\\"{x:1408,y:569,t:1527876570637};\\\", \\\"{x:1409,y:569,t:1527876570864};\\\", \\\"{x:1411,y:569,t:1527876570880};\\\", \\\"{x:1412,y:568,t:1527876570889};\\\", \\\"{x:1415,y:565,t:1527876570904};\\\", \\\"{x:1416,y:564,t:1527876570921};\\\", \\\"{x:1417,y:564,t:1527876570937};\\\", \\\"{x:1416,y:564,t:1527876571889};\\\", \\\"{x:1410,y:567,t:1527876571905};\\\", \\\"{x:1396,y:576,t:1527876571923};\\\", \\\"{x:1386,y:584,t:1527876571937};\\\", \\\"{x:1370,y:595,t:1527876571955};\\\", \\\"{x:1356,y:602,t:1527876571971};\\\", \\\"{x:1349,y:607,t:1527876571989};\\\", \\\"{x:1345,y:608,t:1527876572005};\\\", \\\"{x:1340,y:611,t:1527876572022};\\\", \\\"{x:1336,y:615,t:1527876572038};\\\", \\\"{x:1332,y:620,t:1527876572056};\\\", \\\"{x:1329,y:625,t:1527876572072};\\\", \\\"{x:1326,y:630,t:1527876572088};\\\", \\\"{x:1325,y:631,t:1527876572106};\\\", \\\"{x:1325,y:633,t:1527876572137};\\\", \\\"{x:1323,y:636,t:1527876572144};\\\", \\\"{x:1322,y:637,t:1527876572155};\\\", \\\"{x:1322,y:640,t:1527876572172};\\\", \\\"{x:1319,y:642,t:1527876572189};\\\", \\\"{x:1318,y:643,t:1527876572206};\\\", \\\"{x:1318,y:644,t:1527876572222};\\\", \\\"{x:1316,y:644,t:1527876572239};\\\", \\\"{x:1315,y:645,t:1527876572256};\\\", \\\"{x:1314,y:645,t:1527876572272};\\\", \\\"{x:1308,y:648,t:1527876572289};\\\", \\\"{x:1302,y:653,t:1527876572306};\\\", \\\"{x:1289,y:670,t:1527876572322};\\\", \\\"{x:1273,y:688,t:1527876572339};\\\", \\\"{x:1261,y:704,t:1527876572356};\\\", \\\"{x:1254,y:716,t:1527876572372};\\\", \\\"{x:1244,y:730,t:1527876572389};\\\", \\\"{x:1234,y:746,t:1527876572405};\\\", \\\"{x:1229,y:756,t:1527876572423};\\\", \\\"{x:1224,y:769,t:1527876572439};\\\", \\\"{x:1220,y:783,t:1527876572455};\\\", \\\"{x:1216,y:792,t:1527876572472};\\\", \\\"{x:1216,y:794,t:1527876572489};\\\", \\\"{x:1216,y:795,t:1527876572505};\\\", \\\"{x:1216,y:798,t:1527876572523};\\\", \\\"{x:1216,y:800,t:1527876572539};\\\", \\\"{x:1216,y:804,t:1527876572555};\\\", \\\"{x:1217,y:806,t:1527876572572};\\\", \\\"{x:1217,y:807,t:1527876572589};\\\", \\\"{x:1219,y:808,t:1527876572605};\\\", \\\"{x:1219,y:811,t:1527876572623};\\\", \\\"{x:1219,y:815,t:1527876572638};\\\", \\\"{x:1219,y:822,t:1527876572656};\\\", \\\"{x:1219,y:825,t:1527876572672};\\\", \\\"{x:1219,y:826,t:1527876572692};\\\", \\\"{x:1218,y:828,t:1527876572706};\\\", \\\"{x:1218,y:829,t:1527876572722};\\\", \\\"{x:1219,y:829,t:1527876572970};\\\", \\\"{x:1223,y:829,t:1527876572979};\\\", \\\"{x:1225,y:829,t:1527876572990};\\\", \\\"{x:1233,y:827,t:1527876573007};\\\", \\\"{x:1244,y:823,t:1527876573022};\\\", \\\"{x:1254,y:822,t:1527876573040};\\\", \\\"{x:1263,y:821,t:1527876573056};\\\", \\\"{x:1269,y:821,t:1527876573072};\\\", \\\"{x:1275,y:821,t:1527876573090};\\\", \\\"{x:1281,y:821,t:1527876573106};\\\", \\\"{x:1284,y:821,t:1527876573122};\\\", \\\"{x:1285,y:821,t:1527876573139};\\\", \\\"{x:1287,y:821,t:1527876573156};\\\", \\\"{x:1288,y:821,t:1527876573225};\\\", \\\"{x:1290,y:821,t:1527876573241};\\\", \\\"{x:1292,y:821,t:1527876573257};\\\", \\\"{x:1293,y:822,t:1527876573274};\\\", \\\"{x:1294,y:822,t:1527876573369};\\\", \\\"{x:1294,y:823,t:1527876573393};\\\", \\\"{x:1294,y:824,t:1527876573408};\\\", \\\"{x:1292,y:828,t:1527876573424};\\\", \\\"{x:1289,y:830,t:1527876573440};\\\", \\\"{x:1287,y:831,t:1527876573458};\\\", \\\"{x:1285,y:831,t:1527876573485};\\\", \\\"{x:1285,y:832,t:1527876573507};\\\", \\\"{x:1284,y:832,t:1527876573528};\\\", \\\"{x:1282,y:832,t:1527876574320};\\\", \\\"{x:1281,y:832,t:1527876575201};\\\", \\\"{x:1278,y:832,t:1527876575209};\\\", \\\"{x:1277,y:832,t:1527876575224};\\\", \\\"{x:1275,y:832,t:1527876575244};\\\", \\\"{x:1273,y:831,t:1527876575258};\\\", \\\"{x:1275,y:834,t:1527876575416};\\\", \\\"{x:1277,y:838,t:1527876575425};\\\", \\\"{x:1281,y:846,t:1527876575442};\\\", \\\"{x:1283,y:855,t:1527876575459};\\\", \\\"{x:1283,y:864,t:1527876575474};\\\", \\\"{x:1285,y:870,t:1527876575491};\\\", \\\"{x:1286,y:878,t:1527876575509};\\\", \\\"{x:1288,y:886,t:1527876575525};\\\", \\\"{x:1289,y:895,t:1527876575542};\\\", \\\"{x:1293,y:903,t:1527876575559};\\\", \\\"{x:1296,y:910,t:1527876575574};\\\", \\\"{x:1298,y:914,t:1527876575592};\\\", \\\"{x:1299,y:914,t:1527876575665};\\\", \\\"{x:1300,y:914,t:1527876575675};\\\", \\\"{x:1304,y:910,t:1527876575692};\\\", \\\"{x:1308,y:905,t:1527876575709};\\\", \\\"{x:1313,y:899,t:1527876575725};\\\", \\\"{x:1317,y:892,t:1527876575742};\\\", \\\"{x:1319,y:881,t:1527876575760};\\\", \\\"{x:1323,y:868,t:1527876575776};\\\", \\\"{x:1327,y:853,t:1527876575791};\\\", \\\"{x:1330,y:841,t:1527876575808};\\\", \\\"{x:1332,y:835,t:1527876575826};\\\", \\\"{x:1335,y:824,t:1527876575842};\\\", \\\"{x:1337,y:815,t:1527876575858};\\\", \\\"{x:1342,y:807,t:1527876575876};\\\", \\\"{x:1344,y:802,t:1527876575891};\\\", \\\"{x:1346,y:797,t:1527876575909};\\\", \\\"{x:1349,y:792,t:1527876575926};\\\", \\\"{x:1350,y:787,t:1527876575942};\\\", \\\"{x:1353,y:781,t:1527876575959};\\\", \\\"{x:1358,y:774,t:1527876575977};\\\", \\\"{x:1359,y:773,t:1527876575992};\\\", \\\"{x:1362,y:769,t:1527876576009};\\\", \\\"{x:1363,y:768,t:1527876576026};\\\", \\\"{x:1363,y:767,t:1527876576073};\\\", \\\"{x:1364,y:767,t:1527876576081};\\\", \\\"{x:1367,y:767,t:1527876576092};\\\", \\\"{x:1370,y:765,t:1527876576109};\\\", \\\"{x:1371,y:764,t:1527876576126};\\\", \\\"{x:1372,y:763,t:1527876576178};\\\", \\\"{x:1373,y:763,t:1527876576201};\\\", \\\"{x:1374,y:762,t:1527876576217};\\\", \\\"{x:1375,y:762,t:1527876576248};\\\", \\\"{x:1377,y:762,t:1527876576470};\\\", \\\"{x:1378,y:762,t:1527876576492};\\\", \\\"{x:1379,y:762,t:1527876576509};\\\", \\\"{x:1380,y:762,t:1527876576526};\\\", \\\"{x:1381,y:762,t:1527876576713};\\\", \\\"{x:1378,y:762,t:1527876579465};\\\", \\\"{x:1374,y:763,t:1527876579481};\\\", \\\"{x:1355,y:770,t:1527876579496};\\\", \\\"{x:1319,y:779,t:1527876579511};\\\", \\\"{x:1270,y:783,t:1527876579528};\\\", \\\"{x:1222,y:783,t:1527876579545};\\\", \\\"{x:1150,y:783,t:1527876579562};\\\", \\\"{x:1060,y:778,t:1527876579577};\\\", \\\"{x:959,y:762,t:1527876579595};\\\", \\\"{x:868,y:749,t:1527876579611};\\\", \\\"{x:795,y:740,t:1527876579627};\\\", \\\"{x:715,y:729,t:1527876579644};\\\", \\\"{x:640,y:718,t:1527876579662};\\\", \\\"{x:573,y:708,t:1527876579678};\\\", \\\"{x:525,y:702,t:1527876579695};\\\", \\\"{x:482,y:696,t:1527876579712};\\\", \\\"{x:458,y:689,t:1527876579728};\\\", \\\"{x:443,y:685,t:1527876579746};\\\", \\\"{x:429,y:681,t:1527876579762};\\\", \\\"{x:421,y:677,t:1527876579778};\\\", \\\"{x:416,y:675,t:1527876579795};\\\", \\\"{x:413,y:672,t:1527876579812};\\\", \\\"{x:412,y:671,t:1527876579827};\\\", \\\"{x:411,y:670,t:1527876579848};\\\", \\\"{x:410,y:669,t:1527876579862};\\\", \\\"{x:408,y:665,t:1527876579878};\\\", \\\"{x:407,y:660,t:1527876579894};\\\", \\\"{x:407,y:652,t:1527876579912};\\\", \\\"{x:407,y:645,t:1527876579930};\\\", \\\"{x:407,y:638,t:1527876579945};\\\", \\\"{x:410,y:631,t:1527876579962};\\\", \\\"{x:413,y:626,t:1527876579978};\\\", \\\"{x:417,y:620,t:1527876579995};\\\", \\\"{x:426,y:614,t:1527876580012};\\\", \\\"{x:439,y:605,t:1527876580028};\\\", \\\"{x:454,y:597,t:1527876580045};\\\", \\\"{x:477,y:585,t:1527876580062};\\\", \\\"{x:507,y:573,t:1527876580080};\\\", \\\"{x:531,y:567,t:1527876580095};\\\", \\\"{x:566,y:564,t:1527876580112};\\\", \\\"{x:590,y:561,t:1527876580129};\\\", \\\"{x:609,y:561,t:1527876580145};\\\", \\\"{x:624,y:561,t:1527876580161};\\\", \\\"{x:631,y:561,t:1527876580179};\\\", \\\"{x:638,y:561,t:1527876580195};\\\", \\\"{x:645,y:563,t:1527876580213};\\\", \\\"{x:649,y:564,t:1527876580228};\\\", \\\"{x:654,y:567,t:1527876580245};\\\", \\\"{x:659,y:571,t:1527876580262};\\\", \\\"{x:662,y:574,t:1527876580280};\\\", \\\"{x:670,y:585,t:1527876580297};\\\", \\\"{x:676,y:592,t:1527876580312};\\\", \\\"{x:679,y:599,t:1527876580329};\\\", \\\"{x:680,y:604,t:1527876580345};\\\", \\\"{x:680,y:611,t:1527876580362};\\\", \\\"{x:680,y:617,t:1527876580379};\\\", \\\"{x:672,y:631,t:1527876580396};\\\", \\\"{x:664,y:638,t:1527876580411};\\\", \\\"{x:653,y:643,t:1527876580429};\\\", \\\"{x:639,y:647,t:1527876580446};\\\", \\\"{x:629,y:648,t:1527876580462};\\\", \\\"{x:615,y:650,t:1527876580480};\\\", \\\"{x:577,y:653,t:1527876580495};\\\", \\\"{x:544,y:657,t:1527876580512};\\\", \\\"{x:504,y:659,t:1527876580529};\\\", \\\"{x:448,y:659,t:1527876580547};\\\", \\\"{x:386,y:660,t:1527876580562};\\\", \\\"{x:344,y:660,t:1527876580579};\\\", \\\"{x:313,y:660,t:1527876580596};\\\", \\\"{x:287,y:660,t:1527876580612};\\\", \\\"{x:258,y:660,t:1527876580631};\\\", \\\"{x:233,y:660,t:1527876580646};\\\", \\\"{x:210,y:660,t:1527876580662};\\\", \\\"{x:188,y:660,t:1527876580679};\\\", \\\"{x:166,y:660,t:1527876580695};\\\", \\\"{x:158,y:660,t:1527876580712};\\\", \\\"{x:152,y:660,t:1527876580728};\\\", \\\"{x:149,y:660,t:1527876580746};\\\", \\\"{x:148,y:660,t:1527876580763};\\\", \\\"{x:146,y:660,t:1527876580816};\\\", \\\"{x:145,y:655,t:1527876580830};\\\", \\\"{x:144,y:645,t:1527876580847};\\\", \\\"{x:144,y:634,t:1527876580863};\\\", \\\"{x:145,y:612,t:1527876580879};\\\", \\\"{x:150,y:586,t:1527876580896};\\\", \\\"{x:151,y:574,t:1527876580913};\\\", \\\"{x:151,y:573,t:1527876580929};\\\", \\\"{x:152,y:571,t:1527876580947};\\\", \\\"{x:153,y:570,t:1527876580976};\\\", \\\"{x:153,y:569,t:1527876581001};\\\", \\\"{x:156,y:567,t:1527876581013};\\\", \\\"{x:167,y:561,t:1527876581029};\\\", \\\"{x:181,y:559,t:1527876581047};\\\", \\\"{x:197,y:554,t:1527876581064};\\\", \\\"{x:214,y:551,t:1527876581079};\\\", \\\"{x:247,y:549,t:1527876581097};\\\", \\\"{x:275,y:549,t:1527876581115};\\\", \\\"{x:303,y:549,t:1527876581129};\\\", \\\"{x:328,y:552,t:1527876581146};\\\", \\\"{x:349,y:560,t:1527876581163};\\\", \\\"{x:368,y:570,t:1527876581179};\\\", \\\"{x:378,y:576,t:1527876581197};\\\", \\\"{x:384,y:579,t:1527876581213};\\\", \\\"{x:386,y:581,t:1527876581230};\\\", \\\"{x:388,y:582,t:1527876581246};\\\", \\\"{x:388,y:584,t:1527876581282};\\\", \\\"{x:389,y:589,t:1527876581296};\\\", \\\"{x:389,y:593,t:1527876581314};\\\", \\\"{x:389,y:596,t:1527876581330};\\\", \\\"{x:389,y:601,t:1527876581882};\\\", \\\"{x:408,y:618,t:1527876581899};\\\", \\\"{x:435,y:641,t:1527876581914};\\\", \\\"{x:462,y:663,t:1527876581930};\\\", \\\"{x:490,y:687,t:1527876581947};\\\", \\\"{x:511,y:706,t:1527876581963};\\\", \\\"{x:521,y:718,t:1527876581979};\\\", \\\"{x:523,y:720,t:1527876581998};\\\", \\\"{x:525,y:722,t:1527876582013};\\\", \\\"{x:526,y:726,t:1527876582030};\\\", \\\"{x:529,y:736,t:1527876582047};\\\", \\\"{x:530,y:745,t:1527876582064};\\\", \\\"{x:530,y:761,t:1527876582080};\\\", \\\"{x:530,y:763,t:1527876582097};\\\", \\\"{x:529,y:765,t:1527876582113};\\\", \\\"{x:527,y:766,t:1527876582130};\\\", \\\"{x:526,y:766,t:1527876582147};\\\", \\\"{x:524,y:766,t:1527876582313};\\\", \\\"{x:524,y:765,t:1527876582393};\\\", \\\"{x:523,y:763,t:1527876582401};\\\", \\\"{x:522,y:762,t:1527876582414};\\\", \\\"{x:520,y:756,t:1527876582431};\\\", \\\"{x:520,y:755,t:1527876582448};\\\", \\\"{x:520,y:753,t:1527876582464};\\\", \\\"{x:519,y:751,t:1527876583377};\\\", \\\"{x:519,y:748,t:1527876583385};\\\", \\\"{x:518,y:747,t:1527876583400};\\\", \\\"{x:517,y:745,t:1527876583417};\\\", \\\"{x:516,y:744,t:1527876583432};\\\", \\\"{x:516,y:743,t:1527876583448};\\\", \\\"{x:515,y:742,t:1527876583465};\\\", \\\"{x:511,y:738,t:1527876583481};\\\", \\\"{x:510,y:737,t:1527876583498};\\\" ] }, { \\\"rt\\\": 9455, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 166910, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"DJRH1\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-D -H \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:509,y:735,t:1527876584771};\\\", \\\"{x:507,y:727,t:1527876584783};\\\", \\\"{x:502,y:704,t:1527876584800};\\\", \\\"{x:494,y:673,t:1527876584816};\\\", \\\"{x:492,y:655,t:1527876584832};\\\", \\\"{x:492,y:646,t:1527876584850};\\\", \\\"{x:492,y:636,t:1527876584866};\\\", \\\"{x:492,y:623,t:1527876584882};\\\", \\\"{x:492,y:616,t:1527876584899};\\\", \\\"{x:492,y:608,t:1527876584916};\\\", \\\"{x:492,y:599,t:1527876584932};\\\", \\\"{x:492,y:591,t:1527876584949};\\\", \\\"{x:492,y:587,t:1527876584966};\\\", \\\"{x:492,y:583,t:1527876584983};\\\", \\\"{x:491,y:580,t:1527876584999};\\\", \\\"{x:490,y:574,t:1527876585016};\\\", \\\"{x:490,y:567,t:1527876585034};\\\", \\\"{x:490,y:560,t:1527876585049};\\\", \\\"{x:490,y:555,t:1527876585066};\\\", \\\"{x:490,y:551,t:1527876585082};\\\", \\\"{x:490,y:548,t:1527876585099};\\\", \\\"{x:490,y:547,t:1527876585161};\\\", \\\"{x:490,y:545,t:1527876585168};\\\", \\\"{x:490,y:543,t:1527876585184};\\\", \\\"{x:490,y:542,t:1527876585199};\\\", \\\"{x:491,y:538,t:1527876585218};\\\", \\\"{x:492,y:536,t:1527876585233};\\\", \\\"{x:492,y:535,t:1527876585249};\\\", \\\"{x:493,y:535,t:1527876585265};\\\", \\\"{x:493,y:533,t:1527876585320};\\\", \\\"{x:494,y:532,t:1527876585336};\\\", \\\"{x:495,y:531,t:1527876585349};\\\", \\\"{x:495,y:530,t:1527876585368};\\\", \\\"{x:496,y:529,t:1527876585417};\\\", \\\"{x:496,y:528,t:1527876585433};\\\", \\\"{x:498,y:528,t:1527876585449};\\\", \\\"{x:499,y:526,t:1527876585467};\\\", \\\"{x:503,y:524,t:1527876585484};\\\", \\\"{x:505,y:523,t:1527876585501};\\\", \\\"{x:507,y:522,t:1527876585517};\\\", \\\"{x:508,y:522,t:1527876585553};\\\", \\\"{x:509,y:522,t:1527876585567};\\\", \\\"{x:513,y:522,t:1527876585584};\\\", \\\"{x:524,y:522,t:1527876585600};\\\", \\\"{x:534,y:522,t:1527876585616};\\\", \\\"{x:548,y:523,t:1527876585634};\\\", \\\"{x:567,y:529,t:1527876585651};\\\", \\\"{x:586,y:536,t:1527876585667};\\\", \\\"{x:606,y:545,t:1527876585685};\\\", \\\"{x:626,y:554,t:1527876585700};\\\", \\\"{x:641,y:560,t:1527876585716};\\\", \\\"{x:654,y:564,t:1527876585733};\\\", \\\"{x:666,y:570,t:1527876585750};\\\", \\\"{x:678,y:576,t:1527876585766};\\\", \\\"{x:690,y:579,t:1527876585783};\\\", \\\"{x:700,y:584,t:1527876585800};\\\", \\\"{x:708,y:587,t:1527876585816};\\\", \\\"{x:717,y:590,t:1527876585833};\\\", \\\"{x:724,y:591,t:1527876585851};\\\", \\\"{x:729,y:592,t:1527876585866};\\\", \\\"{x:733,y:594,t:1527876585883};\\\", \\\"{x:740,y:595,t:1527876585900};\\\", \\\"{x:747,y:598,t:1527876585916};\\\", \\\"{x:753,y:599,t:1527876585933};\\\", \\\"{x:757,y:600,t:1527876585950};\\\", \\\"{x:758,y:601,t:1527876585966};\\\", \\\"{x:763,y:602,t:1527876586185};\\\", \\\"{x:797,y:605,t:1527876586200};\\\", \\\"{x:860,y:608,t:1527876586218};\\\", \\\"{x:931,y:615,t:1527876586236};\\\", \\\"{x:1012,y:626,t:1527876586250};\\\", \\\"{x:1074,y:636,t:1527876586268};\\\", \\\"{x:1124,y:642,t:1527876586283};\\\", \\\"{x:1144,y:644,t:1527876586300};\\\", \\\"{x:1149,y:645,t:1527876586317};\\\", \\\"{x:1150,y:645,t:1527876586333};\\\", \\\"{x:1151,y:646,t:1527876586937};\\\", \\\"{x:1151,y:647,t:1527876586951};\\\", \\\"{x:1151,y:649,t:1527876586967};\\\", \\\"{x:1151,y:650,t:1527876587001};\\\", \\\"{x:1151,y:652,t:1527876587018};\\\", \\\"{x:1151,y:653,t:1527876587048};\\\", \\\"{x:1151,y:655,t:1527876587072};\\\", \\\"{x:1151,y:656,t:1527876587096};\\\", \\\"{x:1151,y:658,t:1527876587112};\\\", \\\"{x:1151,y:659,t:1527876587137};\\\", \\\"{x:1152,y:659,t:1527876587151};\\\", \\\"{x:1153,y:661,t:1527876587168};\\\", \\\"{x:1154,y:663,t:1527876587184};\\\", \\\"{x:1156,y:665,t:1527876587201};\\\", \\\"{x:1156,y:666,t:1527876587218};\\\", \\\"{x:1158,y:668,t:1527876587235};\\\", \\\"{x:1161,y:672,t:1527876587252};\\\", \\\"{x:1168,y:678,t:1527876587268};\\\", \\\"{x:1174,y:684,t:1527876587285};\\\", \\\"{x:1181,y:692,t:1527876587302};\\\", \\\"{x:1191,y:700,t:1527876587318};\\\", \\\"{x:1205,y:709,t:1527876587335};\\\", \\\"{x:1219,y:717,t:1527876587352};\\\", \\\"{x:1236,y:727,t:1527876587368};\\\", \\\"{x:1259,y:742,t:1527876587385};\\\", \\\"{x:1274,y:750,t:1527876587402};\\\", \\\"{x:1288,y:758,t:1527876587419};\\\", \\\"{x:1295,y:761,t:1527876587435};\\\", \\\"{x:1297,y:763,t:1527876587452};\\\", \\\"{x:1298,y:763,t:1527876587625};\\\", \\\"{x:1298,y:764,t:1527876587635};\\\", \\\"{x:1298,y:766,t:1527876587652};\\\", \\\"{x:1300,y:768,t:1527876587668};\\\", \\\"{x:1303,y:770,t:1527876587685};\\\", \\\"{x:1307,y:773,t:1527876587702};\\\", \\\"{x:1309,y:775,t:1527876587718};\\\", \\\"{x:1312,y:777,t:1527876587735};\\\", \\\"{x:1318,y:780,t:1527876587752};\\\", \\\"{x:1331,y:785,t:1527876587769};\\\", \\\"{x:1342,y:788,t:1527876587785};\\\", \\\"{x:1357,y:793,t:1527876587801};\\\", \\\"{x:1366,y:795,t:1527876587819};\\\", \\\"{x:1375,y:798,t:1527876587835};\\\", \\\"{x:1381,y:799,t:1527876587851};\\\", \\\"{x:1385,y:800,t:1527876587869};\\\", \\\"{x:1386,y:800,t:1527876587885};\\\", \\\"{x:1388,y:800,t:1527876587923};\\\", \\\"{x:1391,y:800,t:1527876587936};\\\", \\\"{x:1395,y:800,t:1527876587952};\\\", \\\"{x:1411,y:803,t:1527876587969};\\\", \\\"{x:1420,y:804,t:1527876587985};\\\", \\\"{x:1426,y:805,t:1527876588002};\\\", \\\"{x:1429,y:805,t:1527876588019};\\\", \\\"{x:1434,y:805,t:1527876588036};\\\", \\\"{x:1438,y:806,t:1527876588052};\\\", \\\"{x:1441,y:807,t:1527876588069};\\\", \\\"{x:1442,y:807,t:1527876588086};\\\", \\\"{x:1444,y:807,t:1527876588102};\\\", \\\"{x:1445,y:807,t:1527876588145};\\\", \\\"{x:1447,y:807,t:1527876588169};\\\", \\\"{x:1446,y:807,t:1527876589017};\\\", \\\"{x:1446,y:806,t:1527876589025};\\\", \\\"{x:1445,y:804,t:1527876589036};\\\", \\\"{x:1443,y:800,t:1527876589053};\\\", \\\"{x:1443,y:786,t:1527876589070};\\\", \\\"{x:1443,y:764,t:1527876589086};\\\", \\\"{x:1443,y:742,t:1527876589102};\\\", \\\"{x:1443,y:711,t:1527876589120};\\\", \\\"{x:1445,y:673,t:1527876589136};\\\", \\\"{x:1451,y:635,t:1527876589152};\\\", \\\"{x:1454,y:616,t:1527876589170};\\\", \\\"{x:1457,y:593,t:1527876589186};\\\", \\\"{x:1460,y:573,t:1527876589203};\\\", \\\"{x:1463,y:562,t:1527876589219};\\\", \\\"{x:1467,y:554,t:1527876589236};\\\", \\\"{x:1468,y:548,t:1527876589253};\\\", \\\"{x:1472,y:539,t:1527876589270};\\\", \\\"{x:1476,y:532,t:1527876589286};\\\", \\\"{x:1479,y:528,t:1527876589303};\\\", \\\"{x:1482,y:525,t:1527876589320};\\\", \\\"{x:1486,y:524,t:1527876589336};\\\", \\\"{x:1499,y:517,t:1527876589352};\\\", \\\"{x:1504,y:516,t:1527876589370};\\\", \\\"{x:1513,y:513,t:1527876589387};\\\", \\\"{x:1517,y:512,t:1527876589403};\\\", \\\"{x:1530,y:508,t:1527876589420};\\\", \\\"{x:1550,y:503,t:1527876589437};\\\", \\\"{x:1572,y:496,t:1527876589454};\\\", \\\"{x:1593,y:490,t:1527876589470};\\\", \\\"{x:1607,y:486,t:1527876589487};\\\", \\\"{x:1609,y:486,t:1527876589503};\\\", \\\"{x:1609,y:484,t:1527876589649};\\\", \\\"{x:1609,y:482,t:1527876589657};\\\", \\\"{x:1609,y:480,t:1527876589673};\\\", \\\"{x:1609,y:478,t:1527876589687};\\\", \\\"{x:1609,y:477,t:1527876589703};\\\", \\\"{x:1609,y:474,t:1527876589720};\\\", \\\"{x:1609,y:471,t:1527876589737};\\\", \\\"{x:1609,y:469,t:1527876589753};\\\", \\\"{x:1609,y:466,t:1527876589770};\\\", \\\"{x:1609,y:464,t:1527876589787};\\\", \\\"{x:1608,y:462,t:1527876589803};\\\", \\\"{x:1608,y:461,t:1527876589820};\\\", \\\"{x:1607,y:459,t:1527876589837};\\\", \\\"{x:1607,y:457,t:1527876589853};\\\", \\\"{x:1607,y:456,t:1527876589888};\\\", \\\"{x:1607,y:455,t:1527876590009};\\\", \\\"{x:1607,y:454,t:1527876590020};\\\", \\\"{x:1607,y:453,t:1527876590041};\\\", \\\"{x:1607,y:452,t:1527876590081};\\\", \\\"{x:1607,y:451,t:1527876590129};\\\", \\\"{x:1607,y:449,t:1527876590145};\\\", \\\"{x:1608,y:448,t:1527876590160};\\\", \\\"{x:1608,y:447,t:1527876590176};\\\", \\\"{x:1609,y:446,t:1527876590192};\\\", \\\"{x:1609,y:444,t:1527876590249};\\\", \\\"{x:1609,y:442,t:1527876590265};\\\", \\\"{x:1609,y:440,t:1527876590273};\\\", \\\"{x:1609,y:439,t:1527876590287};\\\", \\\"{x:1611,y:437,t:1527876590304};\\\", \\\"{x:1611,y:436,t:1527876590361};\\\", \\\"{x:1611,y:435,t:1527876590371};\\\", \\\"{x:1611,y:433,t:1527876590400};\\\", \\\"{x:1611,y:429,t:1527876590420};\\\", \\\"{x:1610,y:429,t:1527876591200};\\\", \\\"{x:1607,y:432,t:1527876591280};\\\", \\\"{x:1605,y:432,t:1527876591311};\\\", \\\"{x:1603,y:432,t:1527876591335};\\\", \\\"{x:1602,y:433,t:1527876591344};\\\", \\\"{x:1602,y:434,t:1527876591354};\\\", \\\"{x:1599,y:436,t:1527876591372};\\\", \\\"{x:1595,y:440,t:1527876591387};\\\", \\\"{x:1588,y:447,t:1527876591405};\\\", \\\"{x:1578,y:456,t:1527876591421};\\\", \\\"{x:1568,y:464,t:1527876591438};\\\", \\\"{x:1555,y:475,t:1527876591455};\\\", \\\"{x:1539,y:488,t:1527876591472};\\\", \\\"{x:1520,y:501,t:1527876591488};\\\", \\\"{x:1484,y:522,t:1527876591505};\\\", \\\"{x:1451,y:543,t:1527876591522};\\\", \\\"{x:1411,y:564,t:1527876591540};\\\", \\\"{x:1367,y:588,t:1527876591555};\\\", \\\"{x:1306,y:616,t:1527876591571};\\\", \\\"{x:1240,y:645,t:1527876591587};\\\", \\\"{x:1169,y:670,t:1527876591604};\\\", \\\"{x:1108,y:687,t:1527876591621};\\\", \\\"{x:1054,y:697,t:1527876591638};\\\", \\\"{x:1003,y:706,t:1527876591655};\\\", \\\"{x:963,y:713,t:1527876591672};\\\", \\\"{x:900,y:723,t:1527876591687};\\\", \\\"{x:866,y:727,t:1527876591704};\\\", \\\"{x:837,y:731,t:1527876591722};\\\", \\\"{x:808,y:733,t:1527876591737};\\\", \\\"{x:784,y:733,t:1527876591754};\\\", \\\"{x:762,y:733,t:1527876591771};\\\", \\\"{x:744,y:733,t:1527876591788};\\\", \\\"{x:722,y:733,t:1527876591804};\\\", \\\"{x:698,y:733,t:1527876591821};\\\", \\\"{x:664,y:733,t:1527876591839};\\\", \\\"{x:627,y:727,t:1527876591854};\\\", \\\"{x:584,y:720,t:1527876591871};\\\", \\\"{x:534,y:706,t:1527876591888};\\\", \\\"{x:497,y:690,t:1527876591916};\\\", \\\"{x:485,y:684,t:1527876591921};\\\", \\\"{x:467,y:673,t:1527876591938};\\\", \\\"{x:447,y:664,t:1527876591954};\\\", \\\"{x:437,y:659,t:1527876591971};\\\", \\\"{x:432,y:657,t:1527876591988};\\\", \\\"{x:432,y:656,t:1527876592005};\\\", \\\"{x:431,y:654,t:1527876592021};\\\", \\\"{x:430,y:650,t:1527876592039};\\\", \\\"{x:428,y:646,t:1527876592055};\\\", \\\"{x:427,y:643,t:1527876592072};\\\", \\\"{x:423,y:641,t:1527876592169};\\\", \\\"{x:421,y:641,t:1527876592177};\\\", \\\"{x:419,y:641,t:1527876592189};\\\", \\\"{x:415,y:641,t:1527876592207};\\\", \\\"{x:413,y:640,t:1527876592222};\\\", \\\"{x:411,y:639,t:1527876592239};\\\", \\\"{x:410,y:639,t:1527876592255};\\\", \\\"{x:408,y:638,t:1527876592271};\\\", \\\"{x:407,y:638,t:1527876592288};\\\", \\\"{x:406,y:638,t:1527876592305};\\\", \\\"{x:405,y:638,t:1527876592321};\\\", \\\"{x:404,y:637,t:1527876592376};\\\", \\\"{x:403,y:637,t:1527876592388};\\\", \\\"{x:400,y:636,t:1527876592406};\\\", \\\"{x:398,y:635,t:1527876592422};\\\", \\\"{x:398,y:636,t:1527876592736};\\\", \\\"{x:401,y:640,t:1527876592743};\\\", \\\"{x:405,y:644,t:1527876592756};\\\", \\\"{x:413,y:653,t:1527876592774};\\\", \\\"{x:423,y:662,t:1527876592789};\\\", \\\"{x:437,y:672,t:1527876592805};\\\", \\\"{x:452,y:685,t:1527876592823};\\\", \\\"{x:473,y:700,t:1527876592839};\\\", \\\"{x:499,y:720,t:1527876592856};\\\", \\\"{x:515,y:734,t:1527876592871};\\\", \\\"{x:529,y:745,t:1527876592889};\\\", \\\"{x:535,y:752,t:1527876592905};\\\", \\\"{x:539,y:756,t:1527876592922};\\\", \\\"{x:541,y:760,t:1527876592938};\\\", \\\"{x:542,y:760,t:1527876592956};\\\", \\\"{x:542,y:761,t:1527876593016};\\\" ] }, { \\\"rt\\\": 15124, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 183296, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"DJRH1\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-X -C -C -C \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:548,y:761,t:1527876595561};\\\", \\\"{x:581,y:744,t:1527876595578};\\\", \\\"{x:662,y:689,t:1527876595592};\\\", \\\"{x:774,y:598,t:1527876595608};\\\", \\\"{x:887,y:498,t:1527876595624};\\\", \\\"{x:1003,y:400,t:1527876595641};\\\", \\\"{x:1128,y:301,t:1527876595658};\\\", \\\"{x:1212,y:226,t:1527876595675};\\\", \\\"{x:1242,y:191,t:1527876595691};\\\", \\\"{x:1258,y:165,t:1527876595708};\\\", \\\"{x:1264,y:149,t:1527876595724};\\\", \\\"{x:1265,y:139,t:1527876595741};\\\", \\\"{x:1267,y:130,t:1527876595757};\\\", \\\"{x:1268,y:127,t:1527876595774};\\\", \\\"{x:1278,y:112,t:1527876595791};\\\", \\\"{x:1294,y:95,t:1527876595808};\\\", \\\"{x:1308,y:83,t:1527876595825};\\\", \\\"{x:1318,y:75,t:1527876595842};\\\", \\\"{x:1322,y:75,t:1527876595858};\\\", \\\"{x:1336,y:79,t:1527876595874};\\\", \\\"{x:1359,y:94,t:1527876595891};\\\", \\\"{x:1391,y:118,t:1527876595907};\\\", \\\"{x:1420,y:139,t:1527876595925};\\\", \\\"{x:1440,y:150,t:1527876595942};\\\", \\\"{x:1448,y:154,t:1527876595958};\\\", \\\"{x:1449,y:154,t:1527876595975};\\\", \\\"{x:1450,y:155,t:1527876596081};\\\", \\\"{x:1451,y:155,t:1527876596093};\\\", \\\"{x:1452,y:155,t:1527876596128};\\\", \\\"{x:1455,y:155,t:1527876596142};\\\", \\\"{x:1462,y:155,t:1527876596159};\\\", \\\"{x:1465,y:156,t:1527876596175};\\\", \\\"{x:1469,y:157,t:1527876596193};\\\", \\\"{x:1471,y:158,t:1527876596209};\\\", \\\"{x:1471,y:159,t:1527876596232};\\\", \\\"{x:1471,y:160,t:1527876596248};\\\", \\\"{x:1473,y:162,t:1527876596417};\\\", \\\"{x:1474,y:162,t:1527876596432};\\\", \\\"{x:1476,y:164,t:1527876596448};\\\", \\\"{x:1477,y:165,t:1527876596458};\\\", \\\"{x:1479,y:167,t:1527876596476};\\\", \\\"{x:1480,y:168,t:1527876596491};\\\", \\\"{x:1480,y:171,t:1527876597740};\\\", \\\"{x:1480,y:185,t:1527876597761};\\\", \\\"{x:1481,y:193,t:1527876597778};\\\", \\\"{x:1481,y:201,t:1527876597792};\\\", \\\"{x:1483,y:205,t:1527876597810};\\\", \\\"{x:1483,y:209,t:1527876597826};\\\", \\\"{x:1484,y:213,t:1527876597843};\\\", \\\"{x:1484,y:218,t:1527876597860};\\\", \\\"{x:1485,y:228,t:1527876597877};\\\", \\\"{x:1488,y:237,t:1527876597892};\\\", \\\"{x:1488,y:246,t:1527876597909};\\\", \\\"{x:1490,y:255,t:1527876597927};\\\", \\\"{x:1492,y:265,t:1527876597943};\\\", \\\"{x:1495,y:286,t:1527876597960};\\\", \\\"{x:1497,y:301,t:1527876597977};\\\", \\\"{x:1499,y:318,t:1527876597992};\\\", \\\"{x:1502,y:331,t:1527876598010};\\\", \\\"{x:1504,y:346,t:1527876598027};\\\", \\\"{x:1506,y:364,t:1527876598043};\\\", \\\"{x:1508,y:377,t:1527876598060};\\\", \\\"{x:1508,y:392,t:1527876598077};\\\", \\\"{x:1508,y:410,t:1527876598092};\\\", \\\"{x:1508,y:429,t:1527876598110};\\\", \\\"{x:1503,y:449,t:1527876598127};\\\", \\\"{x:1496,y:471,t:1527876598143};\\\", \\\"{x:1482,y:504,t:1527876598160};\\\", \\\"{x:1472,y:523,t:1527876598177};\\\", \\\"{x:1460,y:542,t:1527876598193};\\\", \\\"{x:1444,y:559,t:1527876598210};\\\", \\\"{x:1425,y:575,t:1527876598227};\\\", \\\"{x:1401,y:594,t:1527876598243};\\\", \\\"{x:1378,y:610,t:1527876598260};\\\", \\\"{x:1355,y:622,t:1527876598277};\\\", \\\"{x:1339,y:632,t:1527876598294};\\\", \\\"{x:1331,y:636,t:1527876598310};\\\", \\\"{x:1323,y:638,t:1527876598327};\\\", \\\"{x:1303,y:646,t:1527876598344};\\\", \\\"{x:1295,y:651,t:1527876598360};\\\", \\\"{x:1265,y:659,t:1527876598377};\\\", \\\"{x:1252,y:665,t:1527876598394};\\\", \\\"{x:1243,y:668,t:1527876598410};\\\", \\\"{x:1237,y:669,t:1527876598428};\\\", \\\"{x:1235,y:671,t:1527876598444};\\\", \\\"{x:1233,y:671,t:1527876598460};\\\", \\\"{x:1229,y:672,t:1527876598476};\\\", \\\"{x:1222,y:675,t:1527876598494};\\\", \\\"{x:1213,y:677,t:1527876598510};\\\", \\\"{x:1204,y:680,t:1527876598527};\\\", \\\"{x:1184,y:684,t:1527876598544};\\\", \\\"{x:1169,y:686,t:1527876598560};\\\", \\\"{x:1149,y:689,t:1527876598576};\\\", \\\"{x:1127,y:691,t:1527876598594};\\\", \\\"{x:1101,y:695,t:1527876598610};\\\", \\\"{x:1075,y:698,t:1527876598627};\\\", \\\"{x:1045,y:703,t:1527876598643};\\\", \\\"{x:1011,y:708,t:1527876598661};\\\", \\\"{x:971,y:715,t:1527876598677};\\\", \\\"{x:925,y:718,t:1527876598694};\\\", \\\"{x:875,y:718,t:1527876598710};\\\", \\\"{x:830,y:718,t:1527876598727};\\\", \\\"{x:776,y:718,t:1527876598744};\\\", \\\"{x:747,y:718,t:1527876598760};\\\", \\\"{x:723,y:718,t:1527876598776};\\\", \\\"{x:698,y:718,t:1527876598794};\\\", \\\"{x:683,y:718,t:1527876598811};\\\", \\\"{x:665,y:718,t:1527876598827};\\\", \\\"{x:653,y:716,t:1527876598844};\\\", \\\"{x:640,y:715,t:1527876598861};\\\", \\\"{x:629,y:711,t:1527876598877};\\\", \\\"{x:622,y:708,t:1527876598894};\\\", \\\"{x:612,y:704,t:1527876598912};\\\", \\\"{x:602,y:695,t:1527876598927};\\\", \\\"{x:587,y:683,t:1527876598946};\\\", \\\"{x:580,y:675,t:1527876598960};\\\", \\\"{x:570,y:659,t:1527876598977};\\\", \\\"{x:564,y:646,t:1527876598995};\\\", \\\"{x:559,y:635,t:1527876599010};\\\", \\\"{x:550,y:622,t:1527876599026};\\\", \\\"{x:546,y:616,t:1527876599044};\\\", \\\"{x:544,y:612,t:1527876599060};\\\", \\\"{x:542,y:600,t:1527876599077};\\\", \\\"{x:535,y:581,t:1527876599093};\\\", \\\"{x:530,y:560,t:1527876599112};\\\", \\\"{x:521,y:532,t:1527876599127};\\\", \\\"{x:517,y:519,t:1527876599144};\\\", \\\"{x:515,y:513,t:1527876599161};\\\", \\\"{x:515,y:510,t:1527876599178};\\\", \\\"{x:514,y:510,t:1527876599193};\\\", \\\"{x:513,y:510,t:1527876599216};\\\", \\\"{x:512,y:510,t:1527876599231};\\\", \\\"{x:512,y:511,t:1527876599666};\\\", \\\"{x:510,y:517,t:1527876599679};\\\", \\\"{x:508,y:528,t:1527876599696};\\\", \\\"{x:505,y:544,t:1527876599713};\\\", \\\"{x:504,y:551,t:1527876599728};\\\", \\\"{x:504,y:552,t:1527876599745};\\\", \\\"{x:504,y:553,t:1527876599761};\\\", \\\"{x:504,y:551,t:1527876600008};\\\", \\\"{x:504,y:548,t:1527876600017};\\\", \\\"{x:505,y:545,t:1527876600029};\\\", \\\"{x:507,y:541,t:1527876600046};\\\", \\\"{x:511,y:537,t:1527876600062};\\\", \\\"{x:516,y:534,t:1527876600077};\\\", \\\"{x:520,y:532,t:1527876600094};\\\", \\\"{x:524,y:530,t:1527876600111};\\\", \\\"{x:527,y:530,t:1527876600127};\\\", \\\"{x:528,y:530,t:1527876600145};\\\", \\\"{x:529,y:530,t:1527876600176};\\\", \\\"{x:530,y:530,t:1527876600192};\\\", \\\"{x:531,y:530,t:1527876600199};\\\", \\\"{x:533,y:530,t:1527876600212};\\\", \\\"{x:541,y:530,t:1527876600228};\\\", \\\"{x:552,y:533,t:1527876600245};\\\", \\\"{x:570,y:537,t:1527876600261};\\\", \\\"{x:596,y:544,t:1527876600279};\\\", \\\"{x:623,y:550,t:1527876600296};\\\", \\\"{x:664,y:564,t:1527876600312};\\\", \\\"{x:697,y:570,t:1527876600328};\\\", \\\"{x:732,y:577,t:1527876600346};\\\", \\\"{x:764,y:582,t:1527876600363};\\\", \\\"{x:783,y:583,t:1527876600379};\\\", \\\"{x:794,y:586,t:1527876600395};\\\", \\\"{x:800,y:587,t:1527876600412};\\\", \\\"{x:801,y:588,t:1527876600480};\\\", \\\"{x:803,y:590,t:1527876600496};\\\", \\\"{x:813,y:597,t:1527876600513};\\\", \\\"{x:825,y:605,t:1527876600529};\\\", \\\"{x:838,y:612,t:1527876600548};\\\", \\\"{x:850,y:617,t:1527876600563};\\\", \\\"{x:862,y:623,t:1527876600579};\\\", \\\"{x:873,y:627,t:1527876600596};\\\", \\\"{x:888,y:633,t:1527876600612};\\\", \\\"{x:901,y:639,t:1527876600628};\\\", \\\"{x:911,y:643,t:1527876600644};\\\", \\\"{x:917,y:645,t:1527876600661};\\\", \\\"{x:928,y:650,t:1527876600680};\\\", \\\"{x:941,y:655,t:1527876600694};\\\", \\\"{x:964,y:663,t:1527876600712};\\\", \\\"{x:977,y:669,t:1527876600729};\\\", \\\"{x:984,y:673,t:1527876600745};\\\", \\\"{x:989,y:675,t:1527876600762};\\\", \\\"{x:990,y:675,t:1527876600779};\\\", \\\"{x:991,y:675,t:1527876600873};\\\", \\\"{x:992,y:677,t:1527876600880};\\\", \\\"{x:997,y:678,t:1527876600896};\\\", \\\"{x:1003,y:680,t:1527876600913};\\\", \\\"{x:1012,y:682,t:1527876600930};\\\", \\\"{x:1026,y:685,t:1527876600947};\\\", \\\"{x:1040,y:687,t:1527876600962};\\\", \\\"{x:1054,y:689,t:1527876600979};\\\", \\\"{x:1065,y:691,t:1527876600996};\\\", \\\"{x:1076,y:692,t:1527876601012};\\\", \\\"{x:1087,y:694,t:1527876601029};\\\", \\\"{x:1094,y:696,t:1527876601047};\\\", \\\"{x:1101,y:697,t:1527876601063};\\\", \\\"{x:1108,y:697,t:1527876601079};\\\", \\\"{x:1121,y:698,t:1527876601097};\\\", \\\"{x:1130,y:698,t:1527876601113};\\\", \\\"{x:1140,y:698,t:1527876601130};\\\", \\\"{x:1154,y:700,t:1527876601146};\\\", \\\"{x:1170,y:700,t:1527876601163};\\\", \\\"{x:1191,y:700,t:1527876601179};\\\", \\\"{x:1207,y:699,t:1527876601196};\\\", \\\"{x:1225,y:693,t:1527876601212};\\\", \\\"{x:1242,y:686,t:1527876601229};\\\", \\\"{x:1256,y:682,t:1527876601246};\\\", \\\"{x:1268,y:678,t:1527876601262};\\\", \\\"{x:1275,y:676,t:1527876601279};\\\", \\\"{x:1283,y:672,t:1527876601296};\\\", \\\"{x:1286,y:670,t:1527876601313};\\\", \\\"{x:1287,y:673,t:1527876601457};\\\", \\\"{x:1287,y:676,t:1527876601466};\\\", \\\"{x:1287,y:678,t:1527876601479};\\\", \\\"{x:1287,y:684,t:1527876601496};\\\", \\\"{x:1289,y:688,t:1527876601512};\\\", \\\"{x:1290,y:693,t:1527876601529};\\\", \\\"{x:1290,y:697,t:1527876601545};\\\", \\\"{x:1290,y:699,t:1527876601562};\\\", \\\"{x:1291,y:702,t:1527876601578};\\\", \\\"{x:1293,y:709,t:1527876601596};\\\", \\\"{x:1294,y:716,t:1527876601612};\\\", \\\"{x:1298,y:722,t:1527876601629};\\\", \\\"{x:1299,y:727,t:1527876601646};\\\", \\\"{x:1301,y:730,t:1527876601663};\\\", \\\"{x:1302,y:731,t:1527876601679};\\\", \\\"{x:1302,y:733,t:1527876601696};\\\", \\\"{x:1302,y:736,t:1527876601713};\\\", \\\"{x:1302,y:740,t:1527876601729};\\\", \\\"{x:1302,y:748,t:1527876601746};\\\", \\\"{x:1300,y:757,t:1527876601763};\\\", \\\"{x:1293,y:769,t:1527876601779};\\\", \\\"{x:1279,y:783,t:1527876601796};\\\", \\\"{x:1258,y:800,t:1527876601813};\\\", \\\"{x:1231,y:816,t:1527876601830};\\\", \\\"{x:1213,y:829,t:1527876601847};\\\", \\\"{x:1203,y:837,t:1527876601864};\\\", \\\"{x:1193,y:846,t:1527876601880};\\\", \\\"{x:1190,y:847,t:1527876601895};\\\", \\\"{x:1191,y:848,t:1527876602008};\\\", \\\"{x:1193,y:847,t:1527876602016};\\\", \\\"{x:1195,y:847,t:1527876602029};\\\", \\\"{x:1206,y:840,t:1527876602046};\\\", \\\"{x:1215,y:836,t:1527876602062};\\\", \\\"{x:1221,y:831,t:1527876602079};\\\", \\\"{x:1225,y:830,t:1527876602096};\\\", \\\"{x:1225,y:829,t:1527876602143};\\\", \\\"{x:1226,y:829,t:1527876602152};\\\", \\\"{x:1225,y:829,t:1527876602296};\\\", \\\"{x:1218,y:829,t:1527876602315};\\\", \\\"{x:1213,y:829,t:1527876602329};\\\", \\\"{x:1201,y:831,t:1527876602363};\\\", \\\"{x:1199,y:831,t:1527876602380};\\\", \\\"{x:1201,y:831,t:1527876602600};\\\", \\\"{x:1202,y:831,t:1527876602614};\\\", \\\"{x:1207,y:831,t:1527876602630};\\\", \\\"{x:1209,y:830,t:1527876602649};\\\", \\\"{x:1211,y:830,t:1527876602664};\\\", \\\"{x:1177,y:825,t:1527876605707};\\\", \\\"{x:1143,y:819,t:1527876605723};\\\", \\\"{x:1122,y:814,t:1527876605736};\\\", \\\"{x:1069,y:806,t:1527876605751};\\\", \\\"{x:1013,y:798,t:1527876605769};\\\", \\\"{x:961,y:789,t:1527876605786};\\\", \\\"{x:917,y:783,t:1527876605802};\\\", \\\"{x:871,y:776,t:1527876605818};\\\", \\\"{x:852,y:775,t:1527876605836};\\\", \\\"{x:836,y:774,t:1527876605852};\\\", \\\"{x:826,y:772,t:1527876605869};\\\", \\\"{x:821,y:771,t:1527876605886};\\\", \\\"{x:810,y:770,t:1527876605902};\\\", \\\"{x:793,y:766,t:1527876605919};\\\", \\\"{x:776,y:762,t:1527876605935};\\\", \\\"{x:755,y:755,t:1527876605952};\\\", \\\"{x:734,y:750,t:1527876605969};\\\", \\\"{x:714,y:743,t:1527876605986};\\\", \\\"{x:687,y:736,t:1527876606002};\\\", \\\"{x:634,y:720,t:1527876606019};\\\", \\\"{x:605,y:711,t:1527876606036};\\\", \\\"{x:580,y:703,t:1527876606053};\\\", \\\"{x:556,y:696,t:1527876606069};\\\", \\\"{x:528,y:689,t:1527876606087};\\\", \\\"{x:498,y:682,t:1527876606104};\\\", \\\"{x:462,y:677,t:1527876606119};\\\", \\\"{x:431,y:673,t:1527876606135};\\\", \\\"{x:401,y:669,t:1527876606153};\\\", \\\"{x:370,y:664,t:1527876606169};\\\", \\\"{x:340,y:659,t:1527876606185};\\\", \\\"{x:303,y:654,t:1527876606203};\\\", \\\"{x:284,y:652,t:1527876606219};\\\", \\\"{x:268,y:649,t:1527876606235};\\\", \\\"{x:261,y:648,t:1527876606253};\\\", \\\"{x:252,y:647,t:1527876606269};\\\", \\\"{x:244,y:645,t:1527876606286};\\\", \\\"{x:241,y:644,t:1527876606303};\\\", \\\"{x:241,y:643,t:1527876606363};\\\", \\\"{x:243,y:641,t:1527876606371};\\\", \\\"{x:250,y:639,t:1527876606385};\\\", \\\"{x:312,y:626,t:1527876606404};\\\", \\\"{x:392,y:615,t:1527876606420};\\\", \\\"{x:473,y:606,t:1527876606437};\\\", \\\"{x:551,y:603,t:1527876606454};\\\", \\\"{x:596,y:603,t:1527876606470};\\\", \\\"{x:626,y:603,t:1527876606487};\\\", \\\"{x:652,y:602,t:1527876606503};\\\", \\\"{x:679,y:599,t:1527876606519};\\\", \\\"{x:700,y:595,t:1527876606535};\\\", \\\"{x:715,y:594,t:1527876606553};\\\", \\\"{x:723,y:592,t:1527876606570};\\\", \\\"{x:726,y:591,t:1527876606588};\\\", \\\"{x:727,y:591,t:1527876606603};\\\", \\\"{x:728,y:591,t:1527876606779};\\\", \\\"{x:729,y:590,t:1527876606787};\\\", \\\"{x:742,y:586,t:1527876606804};\\\", \\\"{x:761,y:585,t:1527876606822};\\\", \\\"{x:782,y:582,t:1527876606838};\\\", \\\"{x:806,y:577,t:1527876606855};\\\", \\\"{x:830,y:577,t:1527876606871};\\\", \\\"{x:847,y:576,t:1527876606886};\\\", \\\"{x:856,y:576,t:1527876606903};\\\", \\\"{x:858,y:576,t:1527876606919};\\\", \\\"{x:856,y:576,t:1527876606978};\\\", \\\"{x:851,y:577,t:1527876606986};\\\", \\\"{x:830,y:582,t:1527876607003};\\\", \\\"{x:797,y:585,t:1527876607020};\\\", \\\"{x:751,y:588,t:1527876607036};\\\", \\\"{x:695,y:588,t:1527876607053};\\\", \\\"{x:642,y:588,t:1527876607070};\\\", \\\"{x:598,y:588,t:1527876607087};\\\", \\\"{x:560,y:588,t:1527876607103};\\\", \\\"{x:530,y:588,t:1527876607120};\\\", \\\"{x:506,y:588,t:1527876607137};\\\", \\\"{x:501,y:589,t:1527876607153};\\\", \\\"{x:500,y:589,t:1527876607251};\\\", \\\"{x:499,y:589,t:1527876607274};\\\", \\\"{x:498,y:590,t:1527876607287};\\\", \\\"{x:494,y:592,t:1527876607304};\\\", \\\"{x:487,y:592,t:1527876607320};\\\", \\\"{x:473,y:592,t:1527876607336};\\\", \\\"{x:461,y:592,t:1527876607353};\\\", \\\"{x:448,y:592,t:1527876607369};\\\", \\\"{x:435,y:591,t:1527876607386};\\\", \\\"{x:433,y:591,t:1527876607404};\\\", \\\"{x:432,y:591,t:1527876607420};\\\", \\\"{x:430,y:591,t:1527876608035};\\\", \\\"{x:427,y:592,t:1527876608043};\\\", \\\"{x:417,y:593,t:1527876608054};\\\", \\\"{x:406,y:594,t:1527876608072};\\\", \\\"{x:391,y:596,t:1527876608088};\\\", \\\"{x:383,y:597,t:1527876608104};\\\", \\\"{x:380,y:597,t:1527876608120};\\\", \\\"{x:379,y:597,t:1527876608136};\\\", \\\"{x:379,y:598,t:1527876608459};\\\", \\\"{x:381,y:601,t:1527876608471};\\\", \\\"{x:389,y:607,t:1527876608488};\\\", \\\"{x:396,y:613,t:1527876608505};\\\", \\\"{x:406,y:620,t:1527876608521};\\\", \\\"{x:414,y:625,t:1527876608538};\\\", \\\"{x:422,y:632,t:1527876608555};\\\", \\\"{x:424,y:633,t:1527876608571};\\\", \\\"{x:428,y:637,t:1527876608588};\\\", \\\"{x:435,y:644,t:1527876608604};\\\", \\\"{x:444,y:652,t:1527876608622};\\\", \\\"{x:454,y:661,t:1527876608638};\\\", \\\"{x:464,y:669,t:1527876608655};\\\", \\\"{x:470,y:674,t:1527876608671};\\\", \\\"{x:474,y:679,t:1527876608688};\\\", \\\"{x:478,y:686,t:1527876608705};\\\", \\\"{x:481,y:692,t:1527876608723};\\\", \\\"{x:485,y:699,t:1527876608738};\\\", \\\"{x:490,y:706,t:1527876608755};\\\", \\\"{x:493,y:709,t:1527876608772};\\\", \\\"{x:497,y:715,t:1527876608788};\\\", \\\"{x:499,y:718,t:1527876608805};\\\", \\\"{x:502,y:723,t:1527876608822};\\\", \\\"{x:504,y:726,t:1527876608839};\\\", \\\"{x:507,y:731,t:1527876608856};\\\", \\\"{x:507,y:734,t:1527876608873};\\\", \\\"{x:508,y:736,t:1527876608889};\\\", \\\"{x:510,y:740,t:1527876608906};\\\", \\\"{x:511,y:744,t:1527876608922};\\\", \\\"{x:511,y:747,t:1527876608937};\\\", \\\"{x:512,y:748,t:1527876608955};\\\", \\\"{x:513,y:750,t:1527876608970};\\\", \\\"{x:513,y:752,t:1527876608988};\\\", \\\"{x:514,y:755,t:1527876609005};\\\", \\\"{x:514,y:757,t:1527876609021};\\\", \\\"{x:514,y:760,t:1527876609038};\\\", \\\"{x:514,y:763,t:1527876609055};\\\", \\\"{x:514,y:764,t:1527876609071};\\\", \\\"{x:514,y:765,t:1527876609091};\\\", \\\"{x:514,y:766,t:1527876609139};\\\", \\\"{x:513,y:765,t:1527876609315};\\\", \\\"{x:510,y:764,t:1527876609331};\\\", \\\"{x:509,y:763,t:1527876609339};\\\", \\\"{x:506,y:761,t:1527876609355};\\\", \\\"{x:505,y:759,t:1527876609371};\\\", \\\"{x:505,y:755,t:1527876609388};\\\", \\\"{x:505,y:754,t:1527876609405};\\\", \\\"{x:505,y:752,t:1527876609421};\\\", \\\"{x:505,y:751,t:1527876609438};\\\", \\\"{x:505,y:750,t:1527876609455};\\\", \\\"{x:505,y:749,t:1527876610483};\\\", \\\"{x:505,y:748,t:1527876610490};\\\", \\\"{x:505,y:746,t:1527876610506};\\\", \\\"{x:505,y:745,t:1527876610531};\\\", \\\"{x:505,y:743,t:1527876610546};\\\", \\\"{x:505,y:742,t:1527876610579};\\\", \\\"{x:505,y:740,t:1527876610619};\\\", \\\"{x:506,y:739,t:1527876610642};\\\", \\\"{x:507,y:737,t:1527876610746};\\\", \\\"{x:508,y:736,t:1527876610770};\\\", \\\"{x:508,y:735,t:1527876610778};\\\", \\\"{x:509,y:735,t:1527876610824};\\\", \\\"{x:509,y:734,t:1527876610906};\\\" ] }, { \\\"rt\\\": 6836, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 191416, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"DJRH1\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-H -H \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:510,y:734,t:1527876611064};\\\", \\\"{x:511,y:732,t:1527876611091};\\\", \\\"{x:511,y:731,t:1527876611114};\\\", \\\"{x:512,y:730,t:1527876611259};\\\", \\\"{x:513,y:729,t:1527876611282};\\\", \\\"{x:513,y:728,t:1527876611290};\\\", \\\"{x:514,y:726,t:1527876611314};\\\", \\\"{x:515,y:726,t:1527876611323};\\\", \\\"{x:516,y:724,t:1527876611340};\\\", \\\"{x:517,y:721,t:1527876611357};\\\", \\\"{x:518,y:718,t:1527876611373};\\\", \\\"{x:520,y:712,t:1527876611390};\\\", \\\"{x:526,y:620,t:1527876611476};\\\", \\\"{x:520,y:604,t:1527876611491};\\\", \\\"{x:511,y:586,t:1527876611507};\\\", \\\"{x:499,y:570,t:1527876611523};\\\", \\\"{x:488,y:558,t:1527876611540};\\\", \\\"{x:475,y:548,t:1527876611556};\\\", \\\"{x:461,y:539,t:1527876611573};\\\", \\\"{x:449,y:533,t:1527876611589};\\\", \\\"{x:439,y:530,t:1527876611607};\\\", \\\"{x:426,y:527,t:1527876611624};\\\", \\\"{x:410,y:522,t:1527876611640};\\\", \\\"{x:393,y:514,t:1527876611657};\\\", \\\"{x:377,y:507,t:1527876611674};\\\", \\\"{x:357,y:495,t:1527876611690};\\\", \\\"{x:351,y:489,t:1527876611707};\\\", \\\"{x:346,y:481,t:1527876611724};\\\", \\\"{x:345,y:472,t:1527876611741};\\\", \\\"{x:342,y:459,t:1527876611758};\\\", \\\"{x:342,y:447,t:1527876611774};\\\", \\\"{x:342,y:441,t:1527876611791};\\\", \\\"{x:342,y:438,t:1527876611809};\\\", \\\"{x:342,y:434,t:1527876611827};\\\", \\\"{x:342,y:433,t:1527876611867};\\\", \\\"{x:342,y:432,t:1527876611891};\\\", \\\"{x:344,y:432,t:1527876611907};\\\", \\\"{x:344,y:431,t:1527876611915};\\\", \\\"{x:345,y:431,t:1527876611926};\\\", \\\"{x:347,y:431,t:1527876611943};\\\", \\\"{x:349,y:429,t:1527876611960};\\\", \\\"{x:350,y:429,t:1527876611975};\\\", \\\"{x:351,y:429,t:1527876611992};\\\", \\\"{x:353,y:429,t:1527876612010};\\\", \\\"{x:359,y:429,t:1527876612027};\\\", \\\"{x:361,y:429,t:1527876612042};\\\", \\\"{x:367,y:431,t:1527876612060};\\\", \\\"{x:373,y:434,t:1527876612077};\\\", \\\"{x:378,y:436,t:1527876612093};\\\", \\\"{x:382,y:438,t:1527876612109};\\\", \\\"{x:385,y:440,t:1527876612126};\\\", \\\"{x:386,y:440,t:1527876612143};\\\", \\\"{x:388,y:442,t:1527876612161};\\\", \\\"{x:389,y:443,t:1527876612177};\\\", \\\"{x:390,y:444,t:1527876612193};\\\", \\\"{x:391,y:445,t:1527876612211};\\\", \\\"{x:395,y:447,t:1527876612227};\\\", \\\"{x:396,y:448,t:1527876612243};\\\", \\\"{x:399,y:450,t:1527876612261};\\\", \\\"{x:402,y:453,t:1527876612278};\\\", \\\"{x:408,y:458,t:1527876612294};\\\", \\\"{x:417,y:464,t:1527876612311};\\\", \\\"{x:425,y:473,t:1527876612328};\\\", \\\"{x:435,y:488,t:1527876612344};\\\", \\\"{x:442,y:503,t:1527876612362};\\\", \\\"{x:452,y:519,t:1527876612378};\\\", \\\"{x:463,y:538,t:1527876612395};\\\", \\\"{x:477,y:560,t:1527876612412};\\\", \\\"{x:482,y:572,t:1527876612428};\\\", \\\"{x:484,y:578,t:1527876612442};\\\", \\\"{x:487,y:586,t:1527876612458};\\\", \\\"{x:487,y:593,t:1527876612474};\\\", \\\"{x:487,y:595,t:1527876612491};\\\", \\\"{x:487,y:594,t:1527876612602};\\\", \\\"{x:487,y:590,t:1527876612610};\\\", \\\"{x:486,y:586,t:1527876612624};\\\", \\\"{x:486,y:583,t:1527876612641};\\\", \\\"{x:486,y:578,t:1527876612660};\\\", \\\"{x:486,y:576,t:1527876612674};\\\", \\\"{x:486,y:575,t:1527876612692};\\\", \\\"{x:486,y:573,t:1527876612708};\\\", \\\"{x:487,y:571,t:1527876612725};\\\", \\\"{x:488,y:568,t:1527876612741};\\\", \\\"{x:489,y:565,t:1527876612758};\\\", \\\"{x:490,y:561,t:1527876612774};\\\", \\\"{x:493,y:555,t:1527876612791};\\\", \\\"{x:494,y:554,t:1527876612808};\\\", \\\"{x:494,y:553,t:1527876612824};\\\", \\\"{x:494,y:552,t:1527876612890};\\\", \\\"{x:495,y:550,t:1527876612898};\\\", \\\"{x:497,y:548,t:1527876612908};\\\", \\\"{x:501,y:543,t:1527876612924};\\\", \\\"{x:502,y:539,t:1527876612942};\\\", \\\"{x:505,y:536,t:1527876612958};\\\", \\\"{x:508,y:531,t:1527876612974};\\\", \\\"{x:510,y:527,t:1527876612991};\\\", \\\"{x:514,y:521,t:1527876613008};\\\", \\\"{x:516,y:518,t:1527876613023};\\\", \\\"{x:519,y:516,t:1527876613041};\\\", \\\"{x:520,y:516,t:1527876613058};\\\", \\\"{x:523,y:515,t:1527876613074};\\\", \\\"{x:526,y:514,t:1527876613091};\\\", \\\"{x:527,y:513,t:1527876613108};\\\", \\\"{x:539,y:514,t:1527876613124};\\\", \\\"{x:563,y:522,t:1527876613141};\\\", \\\"{x:592,y:533,t:1527876613159};\\\", \\\"{x:628,y:548,t:1527876613175};\\\", \\\"{x:658,y:561,t:1527876613192};\\\", \\\"{x:688,y:572,t:1527876613208};\\\", \\\"{x:714,y:584,t:1527876613226};\\\", \\\"{x:741,y:595,t:1527876613242};\\\", \\\"{x:778,y:613,t:1527876613258};\\\", \\\"{x:807,y:625,t:1527876613276};\\\", \\\"{x:830,y:635,t:1527876613291};\\\", \\\"{x:854,y:645,t:1527876613308};\\\", \\\"{x:878,y:654,t:1527876613326};\\\", \\\"{x:899,y:664,t:1527876613341};\\\", \\\"{x:922,y:675,t:1527876613359};\\\", \\\"{x:946,y:685,t:1527876613375};\\\", \\\"{x:968,y:694,t:1527876613391};\\\", \\\"{x:988,y:703,t:1527876613408};\\\", \\\"{x:1008,y:711,t:1527876613426};\\\", \\\"{x:1028,y:721,t:1527876613442};\\\", \\\"{x:1062,y:735,t:1527876613459};\\\", \\\"{x:1079,y:743,t:1527876613476};\\\", \\\"{x:1099,y:750,t:1527876613491};\\\", \\\"{x:1115,y:755,t:1527876613508};\\\", \\\"{x:1127,y:760,t:1527876613526};\\\", \\\"{x:1142,y:766,t:1527876613543};\\\", \\\"{x:1158,y:774,t:1527876613559};\\\", \\\"{x:1177,y:780,t:1527876613575};\\\", \\\"{x:1196,y:786,t:1527876613592};\\\", \\\"{x:1217,y:791,t:1527876613609};\\\", \\\"{x:1258,y:803,t:1527876613627};\\\", \\\"{x:1292,y:813,t:1527876613643};\\\", \\\"{x:1308,y:817,t:1527876613659};\\\", \\\"{x:1348,y:829,t:1527876613676};\\\", \\\"{x:1369,y:835,t:1527876613693};\\\", \\\"{x:1389,y:840,t:1527876613709};\\\", \\\"{x:1402,y:844,t:1527876613726};\\\", \\\"{x:1413,y:848,t:1527876613742};\\\", \\\"{x:1418,y:849,t:1527876613758};\\\", \\\"{x:1422,y:850,t:1527876613776};\\\", \\\"{x:1426,y:852,t:1527876613793};\\\", \\\"{x:1428,y:852,t:1527876613809};\\\", \\\"{x:1439,y:857,t:1527876613827};\\\", \\\"{x:1448,y:859,t:1527876613843};\\\", \\\"{x:1456,y:861,t:1527876613858};\\\", \\\"{x:1459,y:862,t:1527876613875};\\\", \\\"{x:1462,y:865,t:1527876613892};\\\", \\\"{x:1468,y:868,t:1527876613909};\\\", \\\"{x:1482,y:876,t:1527876613925};\\\", \\\"{x:1500,y:887,t:1527876613942};\\\", \\\"{x:1522,y:895,t:1527876613960};\\\", \\\"{x:1550,y:905,t:1527876613976};\\\", \\\"{x:1574,y:914,t:1527876613993};\\\", \\\"{x:1592,y:918,t:1527876614009};\\\", \\\"{x:1606,y:923,t:1527876614027};\\\", \\\"{x:1613,y:926,t:1527876614043};\\\", \\\"{x:1616,y:928,t:1527876614058};\\\", \\\"{x:1613,y:925,t:1527876614204};\\\", \\\"{x:1607,y:920,t:1527876614211};\\\", \\\"{x:1598,y:914,t:1527876614227};\\\", \\\"{x:1594,y:910,t:1527876614243};\\\", \\\"{x:1578,y:896,t:1527876614260};\\\", \\\"{x:1564,y:880,t:1527876614276};\\\", \\\"{x:1546,y:865,t:1527876614292};\\\", \\\"{x:1530,y:851,t:1527876614310};\\\", \\\"{x:1517,y:836,t:1527876614326};\\\", \\\"{x:1507,y:823,t:1527876614343};\\\", \\\"{x:1498,y:811,t:1527876614359};\\\", \\\"{x:1488,y:796,t:1527876614376};\\\", \\\"{x:1480,y:782,t:1527876614393};\\\", \\\"{x:1472,y:770,t:1527876614410};\\\", \\\"{x:1463,y:753,t:1527876614427};\\\", \\\"{x:1462,y:749,t:1527876614442};\\\", \\\"{x:1459,y:735,t:1527876614459};\\\", \\\"{x:1458,y:721,t:1527876614476};\\\", \\\"{x:1458,y:709,t:1527876614492};\\\", \\\"{x:1458,y:695,t:1527876614510};\\\", \\\"{x:1458,y:683,t:1527876614526};\\\", \\\"{x:1457,y:673,t:1527876614542};\\\", \\\"{x:1455,y:665,t:1527876614560};\\\", \\\"{x:1454,y:660,t:1527876614577};\\\", \\\"{x:1453,y:653,t:1527876614593};\\\", \\\"{x:1451,y:645,t:1527876614610};\\\", \\\"{x:1450,y:632,t:1527876614627};\\\", \\\"{x:1449,y:626,t:1527876614643};\\\", \\\"{x:1446,y:614,t:1527876614660};\\\", \\\"{x:1445,y:602,t:1527876614677};\\\", \\\"{x:1441,y:586,t:1527876614693};\\\", \\\"{x:1438,y:576,t:1527876614710};\\\", \\\"{x:1435,y:570,t:1527876614727};\\\", \\\"{x:1432,y:566,t:1527876614743};\\\", \\\"{x:1431,y:565,t:1527876614759};\\\", \\\"{x:1429,y:562,t:1527876614777};\\\", \\\"{x:1428,y:561,t:1527876614793};\\\", \\\"{x:1426,y:558,t:1527876614810};\\\", \\\"{x:1423,y:555,t:1527876614827};\\\", \\\"{x:1422,y:555,t:1527876614890};\\\", \\\"{x:1421,y:555,t:1527876614898};\\\", \\\"{x:1420,y:555,t:1527876614909};\\\", \\\"{x:1416,y:556,t:1527876614926};\\\", \\\"{x:1410,y:561,t:1527876614946};\\\", \\\"{x:1407,y:563,t:1527876614960};\\\", \\\"{x:1406,y:564,t:1527876614986};\\\", \\\"{x:1405,y:564,t:1527876615042};\\\", \\\"{x:1406,y:563,t:1527876615531};\\\", \\\"{x:1407,y:563,t:1527876615543};\\\", \\\"{x:1406,y:563,t:1527876615714};\\\", \\\"{x:1405,y:563,t:1527876615726};\\\", \\\"{x:1402,y:564,t:1527876615743};\\\", \\\"{x:1397,y:566,t:1527876615760};\\\", \\\"{x:1367,y:578,t:1527876615776};\\\", \\\"{x:1339,y:587,t:1527876615793};\\\", \\\"{x:1316,y:594,t:1527876615810};\\\", \\\"{x:1278,y:604,t:1527876615826};\\\", \\\"{x:1242,y:613,t:1527876615843};\\\", \\\"{x:1195,y:627,t:1527876615860};\\\", \\\"{x:1139,y:643,t:1527876615876};\\\", \\\"{x:1065,y:662,t:1527876615893};\\\", \\\"{x:995,y:681,t:1527876615910};\\\", \\\"{x:923,y:703,t:1527876615927};\\\", \\\"{x:858,y:717,t:1527876615943};\\\", \\\"{x:799,y:725,t:1527876615961};\\\", \\\"{x:743,y:733,t:1527876615976};\\\", \\\"{x:686,y:738,t:1527876615994};\\\", \\\"{x:622,y:738,t:1527876616011};\\\", \\\"{x:556,y:739,t:1527876616029};\\\", \\\"{x:529,y:739,t:1527876616043};\\\", \\\"{x:513,y:738,t:1527876616060};\\\", \\\"{x:500,y:735,t:1527876616078};\\\", \\\"{x:484,y:727,t:1527876616094};\\\", \\\"{x:461,y:715,t:1527876616110};\\\", \\\"{x:446,y:705,t:1527876616127};\\\", \\\"{x:432,y:695,t:1527876616144};\\\", \\\"{x:424,y:690,t:1527876616161};\\\", \\\"{x:422,y:688,t:1527876616177};\\\", \\\"{x:420,y:686,t:1527876616196};\\\", \\\"{x:420,y:680,t:1527876616210};\\\", \\\"{x:420,y:670,t:1527876616227};\\\", \\\"{x:420,y:656,t:1527876616245};\\\", \\\"{x:422,y:646,t:1527876616263};\\\", \\\"{x:424,y:639,t:1527876616277};\\\", \\\"{x:425,y:634,t:1527876616294};\\\", \\\"{x:427,y:627,t:1527876616310};\\\", \\\"{x:427,y:621,t:1527876616327};\\\", \\\"{x:429,y:614,t:1527876616347};\\\", \\\"{x:429,y:607,t:1527876616360};\\\", \\\"{x:429,y:604,t:1527876616377};\\\", \\\"{x:429,y:602,t:1527876616394};\\\", \\\"{x:430,y:600,t:1527876616594};\\\", \\\"{x:434,y:599,t:1527876616611};\\\", \\\"{x:442,y:596,t:1527876616627};\\\", \\\"{x:452,y:595,t:1527876616644};\\\", \\\"{x:469,y:596,t:1527876616661};\\\", \\\"{x:489,y:598,t:1527876616677};\\\", \\\"{x:508,y:602,t:1527876616694};\\\", \\\"{x:523,y:603,t:1527876616711};\\\", \\\"{x:535,y:606,t:1527876616727};\\\", \\\"{x:542,y:606,t:1527876616744};\\\", \\\"{x:546,y:606,t:1527876616761};\\\", \\\"{x:552,y:607,t:1527876616777};\\\", \\\"{x:556,y:607,t:1527876616794};\\\", \\\"{x:560,y:608,t:1527876616811};\\\", \\\"{x:561,y:609,t:1527876616834};\\\", \\\"{x:562,y:609,t:1527876616845};\\\", \\\"{x:566,y:609,t:1527876616861};\\\", \\\"{x:573,y:609,t:1527876616878};\\\", \\\"{x:583,y:609,t:1527876616894};\\\", \\\"{x:590,y:605,t:1527876616912};\\\", \\\"{x:593,y:604,t:1527876616928};\\\", \\\"{x:596,y:602,t:1527876616945};\\\", \\\"{x:600,y:601,t:1527876616962};\\\", \\\"{x:602,y:600,t:1527876616978};\\\", \\\"{x:607,y:598,t:1527876616995};\\\", \\\"{x:609,y:598,t:1527876617011};\\\", \\\"{x:613,y:598,t:1527876617027};\\\", \\\"{x:614,y:596,t:1527876617044};\\\", \\\"{x:616,y:596,t:1527876617061};\\\", \\\"{x:616,y:597,t:1527876617290};\\\", \\\"{x:616,y:602,t:1527876617298};\\\", \\\"{x:613,y:608,t:1527876617312};\\\", \\\"{x:604,y:626,t:1527876617329};\\\", \\\"{x:593,y:646,t:1527876617344};\\\", \\\"{x:581,y:667,t:1527876617362};\\\", \\\"{x:566,y:695,t:1527876617378};\\\", \\\"{x:558,y:708,t:1527876617395};\\\", \\\"{x:553,y:717,t:1527876617411};\\\", \\\"{x:551,y:723,t:1527876617428};\\\", \\\"{x:546,y:729,t:1527876617445};\\\", \\\"{x:543,y:735,t:1527876617461};\\\", \\\"{x:541,y:739,t:1527876617479};\\\", \\\"{x:537,y:743,t:1527876617496};\\\", \\\"{x:535,y:748,t:1527876617511};\\\", \\\"{x:533,y:750,t:1527876617529};\\\" ] }, { \\\"rt\\\": 19849, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 212512, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"DJRH1\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -O -O -O -I \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:534,y:747,t:1527876621139};\\\", \\\"{x:535,y:743,t:1527876621148};\\\", \\\"{x:536,y:741,t:1527876621165};\\\", \\\"{x:537,y:733,t:1527876621181};\\\", \\\"{x:537,y:728,t:1527876621198};\\\", \\\"{x:537,y:720,t:1527876621214};\\\", \\\"{x:537,y:705,t:1527876621231};\\\", \\\"{x:534,y:686,t:1527876621248};\\\", \\\"{x:525,y:666,t:1527876621265};\\\", \\\"{x:517,y:641,t:1527876621281};\\\", \\\"{x:508,y:622,t:1527876621298};\\\", \\\"{x:496,y:598,t:1527876621315};\\\", \\\"{x:485,y:579,t:1527876621332};\\\", \\\"{x:471,y:554,t:1527876621349};\\\", \\\"{x:458,y:537,t:1527876621364};\\\", \\\"{x:449,y:528,t:1527876621381};\\\", \\\"{x:442,y:522,t:1527876621398};\\\", \\\"{x:436,y:519,t:1527876621414};\\\", \\\"{x:430,y:516,t:1527876621432};\\\", \\\"{x:425,y:514,t:1527876621447};\\\", \\\"{x:420,y:512,t:1527876621464};\\\", \\\"{x:413,y:510,t:1527876621481};\\\", \\\"{x:407,y:509,t:1527876621497};\\\", \\\"{x:399,y:507,t:1527876621515};\\\", \\\"{x:392,y:506,t:1527876621532};\\\", \\\"{x:387,y:505,t:1527876621548};\\\", \\\"{x:382,y:505,t:1527876621565};\\\", \\\"{x:380,y:505,t:1527876621581};\\\", \\\"{x:379,y:504,t:1527876621996};\\\", \\\"{x:385,y:504,t:1527876622092};\\\", \\\"{x:394,y:503,t:1527876622099};\\\", \\\"{x:403,y:502,t:1527876622114};\\\", \\\"{x:423,y:502,t:1527876622130};\\\", \\\"{x:457,y:502,t:1527876622147};\\\", \\\"{x:475,y:502,t:1527876622164};\\\", \\\"{x:480,y:502,t:1527876622180};\\\", \\\"{x:482,y:501,t:1527876622197};\\\", \\\"{x:483,y:501,t:1527876622283};\\\", \\\"{x:484,y:501,t:1527876622603};\\\", \\\"{x:486,y:501,t:1527876622613};\\\", \\\"{x:491,y:501,t:1527876622630};\\\", \\\"{x:497,y:501,t:1527876622646};\\\", \\\"{x:505,y:501,t:1527876622663};\\\", \\\"{x:514,y:501,t:1527876622679};\\\", \\\"{x:520,y:501,t:1527876622695};\\\", \\\"{x:529,y:502,t:1527876622713};\\\", \\\"{x:536,y:504,t:1527876622729};\\\", \\\"{x:539,y:504,t:1527876622746};\\\", \\\"{x:540,y:504,t:1527876622764};\\\", \\\"{x:542,y:504,t:1527876622828};\\\", \\\"{x:543,y:504,t:1527876622947};\\\", \\\"{x:545,y:504,t:1527876622987};\\\", \\\"{x:546,y:503,t:1527876623044};\\\", \\\"{x:548,y:503,t:1527876623059};\\\", \\\"{x:549,y:503,t:1527876623075};\\\", \\\"{x:551,y:502,t:1527876623091};\\\", \\\"{x:551,y:501,t:1527876623099};\\\", \\\"{x:552,y:501,t:1527876623115};\\\", \\\"{x:554,y:501,t:1527876623131};\\\", \\\"{x:555,y:501,t:1527876623145};\\\", \\\"{x:559,y:499,t:1527876623162};\\\", \\\"{x:572,y:496,t:1527876623179};\\\", \\\"{x:577,y:495,t:1527876623195};\\\", \\\"{x:584,y:493,t:1527876623212};\\\", \\\"{x:592,y:492,t:1527876623228};\\\", \\\"{x:596,y:492,t:1527876623245};\\\", \\\"{x:601,y:492,t:1527876623262};\\\", \\\"{x:607,y:492,t:1527876623278};\\\", \\\"{x:610,y:492,t:1527876623295};\\\", \\\"{x:612,y:492,t:1527876623312};\\\", \\\"{x:613,y:492,t:1527876623328};\\\", \\\"{x:615,y:492,t:1527876623345};\\\", \\\"{x:617,y:493,t:1527876623362};\\\", \\\"{x:622,y:494,t:1527876623378};\\\", \\\"{x:627,y:497,t:1527876623395};\\\", \\\"{x:628,y:497,t:1527876623411};\\\", \\\"{x:629,y:498,t:1527876623428};\\\", \\\"{x:630,y:498,t:1527876623445};\\\", \\\"{x:632,y:499,t:1527876623461};\\\", \\\"{x:632,y:500,t:1527876623478};\\\", \\\"{x:632,y:503,t:1527876623495};\\\", \\\"{x:632,y:507,t:1527876623511};\\\", \\\"{x:628,y:514,t:1527876623528};\\\", \\\"{x:620,y:523,t:1527876623545};\\\", \\\"{x:608,y:532,t:1527876623561};\\\", \\\"{x:587,y:542,t:1527876623578};\\\", \\\"{x:564,y:549,t:1527876623594};\\\", \\\"{x:531,y:553,t:1527876623611};\\\", \\\"{x:509,y:553,t:1527876623628};\\\", \\\"{x:495,y:554,t:1527876623644};\\\", \\\"{x:488,y:556,t:1527876623662};\\\", \\\"{x:481,y:556,t:1527876623677};\\\", \\\"{x:472,y:556,t:1527876623696};\\\", \\\"{x:467,y:557,t:1527876623713};\\\", \\\"{x:465,y:557,t:1527876623729};\\\", \\\"{x:464,y:557,t:1527876623745};\\\", \\\"{x:463,y:557,t:1527876623827};\\\", \\\"{x:464,y:555,t:1527876623835};\\\", \\\"{x:465,y:553,t:1527876623845};\\\", \\\"{x:470,y:547,t:1527876623867};\\\", \\\"{x:475,y:542,t:1527876623883};\\\", \\\"{x:479,y:539,t:1527876623900};\\\", \\\"{x:483,y:536,t:1527876623917};\\\", \\\"{x:487,y:533,t:1527876623933};\\\", \\\"{x:489,y:533,t:1527876623950};\\\", \\\"{x:490,y:532,t:1527876623966};\\\", \\\"{x:491,y:532,t:1527876624124};\\\", \\\"{x:493,y:531,t:1527876624134};\\\", \\\"{x:499,y:530,t:1527876624151};\\\", \\\"{x:505,y:529,t:1527876624167};\\\", \\\"{x:512,y:529,t:1527876624184};\\\", \\\"{x:518,y:529,t:1527876624201};\\\", \\\"{x:530,y:529,t:1527876624217};\\\", \\\"{x:539,y:529,t:1527876624234};\\\", \\\"{x:552,y:530,t:1527876624251};\\\", \\\"{x:562,y:531,t:1527876624267};\\\", \\\"{x:576,y:533,t:1527876624284};\\\", \\\"{x:588,y:535,t:1527876624301};\\\", \\\"{x:599,y:536,t:1527876624317};\\\", \\\"{x:609,y:538,t:1527876624334};\\\", \\\"{x:620,y:540,t:1527876624352};\\\", \\\"{x:630,y:541,t:1527876624367};\\\", \\\"{x:635,y:542,t:1527876624384};\\\", \\\"{x:636,y:544,t:1527876624401};\\\", \\\"{x:637,y:549,t:1527876625003};\\\", \\\"{x:638,y:555,t:1527876625018};\\\", \\\"{x:645,y:571,t:1527876625037};\\\", \\\"{x:649,y:578,t:1527876625051};\\\", \\\"{x:653,y:585,t:1527876625067};\\\", \\\"{x:656,y:587,t:1527876625084};\\\", \\\"{x:659,y:589,t:1527876625100};\\\", \\\"{x:660,y:589,t:1527876625118};\\\", \\\"{x:661,y:590,t:1527876625146};\\\", \\\"{x:661,y:591,t:1527876625187};\\\", \\\"{x:662,y:592,t:1527876625201};\\\", \\\"{x:663,y:594,t:1527876625218};\\\", \\\"{x:665,y:596,t:1527876625234};\\\", \\\"{x:667,y:598,t:1527876625251};\\\", \\\"{x:669,y:599,t:1527876625268};\\\", \\\"{x:671,y:599,t:1527876625284};\\\", \\\"{x:681,y:604,t:1527876625302};\\\", \\\"{x:695,y:607,t:1527876625318};\\\", \\\"{x:713,y:612,t:1527876625335};\\\", \\\"{x:734,y:619,t:1527876625353};\\\", \\\"{x:755,y:624,t:1527876625367};\\\", \\\"{x:768,y:628,t:1527876625385};\\\", \\\"{x:779,y:631,t:1527876625402};\\\", \\\"{x:790,y:634,t:1527876625418};\\\", \\\"{x:814,y:638,t:1527876625434};\\\", \\\"{x:831,y:638,t:1527876625452};\\\", \\\"{x:853,y:640,t:1527876625468};\\\", \\\"{x:873,y:640,t:1527876625485};\\\", \\\"{x:895,y:643,t:1527876625501};\\\", \\\"{x:927,y:646,t:1527876625518};\\\", \\\"{x:969,y:646,t:1527876625535};\\\", \\\"{x:1014,y:646,t:1527876625552};\\\", \\\"{x:1044,y:642,t:1527876625568};\\\", \\\"{x:1078,y:625,t:1527876625585};\\\", \\\"{x:1105,y:610,t:1527876625602};\\\", \\\"{x:1145,y:590,t:1527876625618};\\\", \\\"{x:1168,y:575,t:1527876625635};\\\", \\\"{x:1187,y:565,t:1527876625652};\\\", \\\"{x:1196,y:557,t:1527876625668};\\\", \\\"{x:1202,y:553,t:1527876625685};\\\", \\\"{x:1207,y:549,t:1527876625702};\\\", \\\"{x:1211,y:546,t:1527876625719};\\\", \\\"{x:1217,y:542,t:1527876625735};\\\", \\\"{x:1224,y:537,t:1527876625752};\\\", \\\"{x:1230,y:534,t:1527876625769};\\\", \\\"{x:1236,y:532,t:1527876625785};\\\", \\\"{x:1244,y:530,t:1527876625802};\\\", \\\"{x:1251,y:529,t:1527876625818};\\\", \\\"{x:1257,y:529,t:1527876625835};\\\", \\\"{x:1258,y:529,t:1527876625852};\\\", \\\"{x:1263,y:529,t:1527876625869};\\\", \\\"{x:1272,y:524,t:1527876625885};\\\", \\\"{x:1284,y:521,t:1527876625902};\\\", \\\"{x:1302,y:519,t:1527876625919};\\\", \\\"{x:1316,y:517,t:1527876625936};\\\", \\\"{x:1326,y:516,t:1527876625952};\\\", \\\"{x:1329,y:515,t:1527876625969};\\\", \\\"{x:1330,y:515,t:1527876626027};\\\", \\\"{x:1330,y:514,t:1527876626051};\\\", \\\"{x:1330,y:513,t:1527876626069};\\\", \\\"{x:1330,y:512,t:1527876626086};\\\", \\\"{x:1327,y:509,t:1527876626220};\\\", \\\"{x:1322,y:507,t:1527876626236};\\\", \\\"{x:1318,y:505,t:1527876626253};\\\", \\\"{x:1315,y:504,t:1527876626270};\\\", \\\"{x:1312,y:503,t:1527876626286};\\\", \\\"{x:1311,y:502,t:1527876626302};\\\", \\\"{x:1311,y:501,t:1527876626677};\\\", \\\"{x:1311,y:500,t:1527876626702};\\\", \\\"{x:1312,y:499,t:1527876626718};\\\", \\\"{x:1311,y:500,t:1527876627499};\\\", \\\"{x:1309,y:500,t:1527876627510};\\\", \\\"{x:1307,y:502,t:1527876627520};\\\", \\\"{x:1304,y:504,t:1527876627536};\\\", \\\"{x:1301,y:512,t:1527876627553};\\\", \\\"{x:1301,y:514,t:1527876627570};\\\", \\\"{x:1301,y:515,t:1527876627587};\\\", \\\"{x:1301,y:516,t:1527876627602};\\\", \\\"{x:1300,y:517,t:1527876627620};\\\", \\\"{x:1300,y:518,t:1527876627637};\\\", \\\"{x:1300,y:520,t:1527876627653};\\\", \\\"{x:1300,y:522,t:1527876627670};\\\", \\\"{x:1300,y:523,t:1527876627687};\\\", \\\"{x:1300,y:524,t:1527876627732};\\\", \\\"{x:1300,y:525,t:1527876627747};\\\", \\\"{x:1300,y:526,t:1527876627764};\\\", \\\"{x:1300,y:527,t:1527876627804};\\\", \\\"{x:1300,y:529,t:1527876627821};\\\", \\\"{x:1300,y:533,t:1527876627838};\\\", \\\"{x:1300,y:537,t:1527876627854};\\\", \\\"{x:1301,y:543,t:1527876627870};\\\", \\\"{x:1302,y:546,t:1527876627888};\\\", \\\"{x:1303,y:550,t:1527876627904};\\\", \\\"{x:1305,y:555,t:1527876627920};\\\", \\\"{x:1306,y:563,t:1527876627937};\\\", \\\"{x:1308,y:568,t:1527876627955};\\\", \\\"{x:1309,y:572,t:1527876627971};\\\", \\\"{x:1311,y:579,t:1527876627987};\\\", \\\"{x:1312,y:582,t:1527876628004};\\\", \\\"{x:1313,y:584,t:1527876628020};\\\", \\\"{x:1313,y:586,t:1527876628037};\\\", \\\"{x:1313,y:588,t:1527876628054};\\\", \\\"{x:1314,y:590,t:1527876628071};\\\", \\\"{x:1316,y:593,t:1527876628088};\\\", \\\"{x:1316,y:595,t:1527876628104};\\\", \\\"{x:1316,y:598,t:1527876628120};\\\", \\\"{x:1316,y:600,t:1527876628137};\\\", \\\"{x:1316,y:601,t:1527876628154};\\\", \\\"{x:1316,y:603,t:1527876628171};\\\", \\\"{x:1317,y:608,t:1527876628188};\\\", \\\"{x:1317,y:611,t:1527876628203};\\\", \\\"{x:1317,y:613,t:1527876628219};\\\", \\\"{x:1318,y:616,t:1527876628237};\\\", \\\"{x:1318,y:620,t:1527876628253};\\\", \\\"{x:1318,y:622,t:1527876628270};\\\", \\\"{x:1318,y:623,t:1527876628287};\\\", \\\"{x:1318,y:624,t:1527876628304};\\\", \\\"{x:1318,y:625,t:1527876628323};\\\", \\\"{x:1318,y:626,t:1527876628336};\\\", \\\"{x:1318,y:627,t:1527876628354};\\\", \\\"{x:1318,y:628,t:1527876628475};\\\", \\\"{x:1318,y:626,t:1527876630443};\\\", \\\"{x:1318,y:625,t:1527876630455};\\\", \\\"{x:1318,y:623,t:1527876630474};\\\", \\\"{x:1318,y:621,t:1527876630489};\\\", \\\"{x:1318,y:616,t:1527876630506};\\\", \\\"{x:1316,y:612,t:1527876630522};\\\", \\\"{x:1316,y:606,t:1527876630539};\\\", \\\"{x:1315,y:600,t:1527876630556};\\\", \\\"{x:1314,y:596,t:1527876630571};\\\", \\\"{x:1314,y:590,t:1527876630589};\\\", \\\"{x:1313,y:587,t:1527876630606};\\\", \\\"{x:1312,y:584,t:1527876630622};\\\", \\\"{x:1311,y:581,t:1527876630639};\\\", \\\"{x:1311,y:578,t:1527876630656};\\\", \\\"{x:1309,y:574,t:1527876630672};\\\", \\\"{x:1308,y:571,t:1527876630689};\\\", \\\"{x:1305,y:565,t:1527876630706};\\\", \\\"{x:1304,y:562,t:1527876630723};\\\", \\\"{x:1303,y:557,t:1527876630739};\\\", \\\"{x:1301,y:552,t:1527876630756};\\\", \\\"{x:1300,y:548,t:1527876630772};\\\", \\\"{x:1298,y:542,t:1527876630789};\\\", \\\"{x:1297,y:538,t:1527876630806};\\\", \\\"{x:1297,y:534,t:1527876630823};\\\", \\\"{x:1297,y:530,t:1527876630839};\\\", \\\"{x:1297,y:527,t:1527876630857};\\\", \\\"{x:1297,y:524,t:1527876630872};\\\", \\\"{x:1297,y:520,t:1527876630889};\\\", \\\"{x:1297,y:518,t:1527876630907};\\\", \\\"{x:1297,y:517,t:1527876630923};\\\", \\\"{x:1297,y:515,t:1527876630939};\\\", \\\"{x:1297,y:514,t:1527876630957};\\\", \\\"{x:1297,y:513,t:1527876630973};\\\", \\\"{x:1298,y:510,t:1527876630990};\\\", \\\"{x:1301,y:506,t:1527876631006};\\\", \\\"{x:1302,y:504,t:1527876631023};\\\", \\\"{x:1304,y:503,t:1527876631039};\\\", \\\"{x:1305,y:502,t:1527876631056};\\\", \\\"{x:1305,y:501,t:1527876631074};\\\", \\\"{x:1306,y:501,t:1527876631090};\\\", \\\"{x:1306,y:500,t:1527876631107};\\\", \\\"{x:1307,y:500,t:1527876631124};\\\", \\\"{x:1309,y:500,t:1527876631171};\\\", \\\"{x:1310,y:500,t:1527876631183};\\\", \\\"{x:1311,y:500,t:1527876631205};\\\", \\\"{x:1313,y:498,t:1527876631223};\\\", \\\"{x:1314,y:498,t:1527876633371};\\\", \\\"{x:1315,y:500,t:1527876633482};\\\", \\\"{x:1318,y:517,t:1527876633508};\\\", \\\"{x:1321,y:524,t:1527876633524};\\\", \\\"{x:1322,y:529,t:1527876633541};\\\", \\\"{x:1322,y:533,t:1527876633558};\\\", \\\"{x:1322,y:535,t:1527876633575};\\\", \\\"{x:1322,y:536,t:1527876633591};\\\", \\\"{x:1322,y:538,t:1527876633608};\\\", \\\"{x:1322,y:539,t:1527876633625};\\\", \\\"{x:1322,y:542,t:1527876633641};\\\", \\\"{x:1323,y:546,t:1527876633658};\\\", \\\"{x:1325,y:549,t:1527876633675};\\\", \\\"{x:1325,y:551,t:1527876633691};\\\", \\\"{x:1325,y:553,t:1527876633708};\\\", \\\"{x:1325,y:555,t:1527876633726};\\\", \\\"{x:1325,y:558,t:1527876633741};\\\", \\\"{x:1325,y:564,t:1527876633758};\\\", \\\"{x:1325,y:569,t:1527876633775};\\\", \\\"{x:1326,y:574,t:1527876633792};\\\", \\\"{x:1326,y:578,t:1527876633808};\\\", \\\"{x:1326,y:581,t:1527876633826};\\\", \\\"{x:1326,y:582,t:1527876633915};\\\", \\\"{x:1326,y:583,t:1527876633931};\\\", \\\"{x:1326,y:584,t:1527876633955};\\\", \\\"{x:1326,y:585,t:1527876634019};\\\", \\\"{x:1326,y:586,t:1527876634027};\\\", \\\"{x:1325,y:590,t:1527876634043};\\\", \\\"{x:1322,y:596,t:1527876634059};\\\", \\\"{x:1317,y:601,t:1527876634075};\\\", \\\"{x:1312,y:610,t:1527876634093};\\\", \\\"{x:1297,y:622,t:1527876634108};\\\", \\\"{x:1283,y:633,t:1527876634125};\\\", \\\"{x:1261,y:649,t:1527876634142};\\\", \\\"{x:1230,y:666,t:1527876634159};\\\", \\\"{x:1197,y:680,t:1527876634176};\\\", \\\"{x:1154,y:697,t:1527876634192};\\\", \\\"{x:1111,y:710,t:1527876634208};\\\", \\\"{x:1064,y:722,t:1527876634225};\\\", \\\"{x:1018,y:725,t:1527876634242};\\\", \\\"{x:992,y:725,t:1527876634258};\\\", \\\"{x:968,y:725,t:1527876634275};\\\", \\\"{x:949,y:725,t:1527876634292};\\\", \\\"{x:932,y:722,t:1527876634308};\\\", \\\"{x:916,y:718,t:1527876634326};\\\", \\\"{x:905,y:715,t:1527876634342};\\\", \\\"{x:893,y:712,t:1527876634358};\\\", \\\"{x:879,y:711,t:1527876634376};\\\", \\\"{x:875,y:710,t:1527876634393};\\\", \\\"{x:872,y:710,t:1527876634409};\\\", \\\"{x:870,y:710,t:1527876634425};\\\", \\\"{x:866,y:710,t:1527876634443};\\\", \\\"{x:865,y:709,t:1527876634459};\\\", \\\"{x:863,y:709,t:1527876634476};\\\", \\\"{x:857,y:708,t:1527876634492};\\\", \\\"{x:845,y:703,t:1527876634509};\\\", \\\"{x:830,y:696,t:1527876634526};\\\", \\\"{x:818,y:691,t:1527876634542};\\\", \\\"{x:817,y:691,t:1527876634560};\\\", \\\"{x:817,y:688,t:1527876634575};\\\", \\\"{x:817,y:675,t:1527876634592};\\\", \\\"{x:822,y:660,t:1527876634610};\\\", \\\"{x:834,y:645,t:1527876634626};\\\", \\\"{x:846,y:633,t:1527876634642};\\\", \\\"{x:854,y:628,t:1527876634660};\\\", \\\"{x:860,y:624,t:1527876634676};\\\", \\\"{x:864,y:622,t:1527876634692};\\\", \\\"{x:866,y:620,t:1527876634709};\\\", \\\"{x:867,y:619,t:1527876634725};\\\", \\\"{x:867,y:616,t:1527876634770};\\\", \\\"{x:867,y:613,t:1527876634778};\\\", \\\"{x:867,y:609,t:1527876634792};\\\", \\\"{x:867,y:603,t:1527876634809};\\\", \\\"{x:867,y:597,t:1527876634825};\\\", \\\"{x:865,y:590,t:1527876634843};\\\", \\\"{x:863,y:586,t:1527876634860};\\\", \\\"{x:861,y:584,t:1527876634876};\\\", \\\"{x:859,y:582,t:1527876634892};\\\", \\\"{x:858,y:582,t:1527876634913};\\\", \\\"{x:857,y:582,t:1527876634954};\\\", \\\"{x:856,y:581,t:1527876634970};\\\", \\\"{x:855,y:581,t:1527876634978};\\\", \\\"{x:854,y:580,t:1527876634992};\\\", \\\"{x:851,y:579,t:1527876635009};\\\", \\\"{x:848,y:578,t:1527876635026};\\\", \\\"{x:846,y:577,t:1527876635106};\\\", \\\"{x:844,y:575,t:1527876635123};\\\", \\\"{x:842,y:575,t:1527876635137};\\\", \\\"{x:841,y:575,t:1527876635154};\\\", \\\"{x:841,y:574,t:1527876635162};\\\", \\\"{x:839,y:574,t:1527876635707};\\\", \\\"{x:837,y:578,t:1527876635715};\\\", \\\"{x:834,y:581,t:1527876635727};\\\", \\\"{x:828,y:590,t:1527876635745};\\\", \\\"{x:818,y:602,t:1527876635762};\\\", \\\"{x:814,y:609,t:1527876635777};\\\", \\\"{x:807,y:616,t:1527876635793};\\\", \\\"{x:799,y:624,t:1527876635810};\\\", \\\"{x:792,y:631,t:1527876635828};\\\", \\\"{x:783,y:638,t:1527876635843};\\\", \\\"{x:773,y:647,t:1527876635860};\\\", \\\"{x:761,y:657,t:1527876635876};\\\", \\\"{x:752,y:664,t:1527876635894};\\\", \\\"{x:741,y:672,t:1527876635910};\\\", \\\"{x:729,y:680,t:1527876635927};\\\", \\\"{x:719,y:685,t:1527876635943};\\\", \\\"{x:711,y:692,t:1527876635960};\\\", \\\"{x:702,y:696,t:1527876635976};\\\", \\\"{x:696,y:700,t:1527876635993};\\\", \\\"{x:687,y:707,t:1527876636010};\\\", \\\"{x:678,y:712,t:1527876636026};\\\", \\\"{x:672,y:715,t:1527876636043};\\\", \\\"{x:666,y:719,t:1527876636060};\\\", \\\"{x:662,y:721,t:1527876636077};\\\", \\\"{x:658,y:723,t:1527876636094};\\\", \\\"{x:652,y:727,t:1527876636111};\\\", \\\"{x:651,y:727,t:1527876636127};\\\", \\\"{x:650,y:728,t:1527876636143};\\\", \\\"{x:648,y:729,t:1527876636160};\\\", \\\"{x:647,y:730,t:1527876636177};\\\", \\\"{x:644,y:731,t:1527876636193};\\\", \\\"{x:639,y:734,t:1527876636211};\\\", \\\"{x:634,y:737,t:1527876636227};\\\", \\\"{x:628,y:739,t:1527876636243};\\\", \\\"{x:623,y:740,t:1527876636261};\\\", \\\"{x:616,y:743,t:1527876636278};\\\", \\\"{x:610,y:746,t:1527876636294};\\\", \\\"{x:607,y:747,t:1527876636311};\\\", \\\"{x:605,y:747,t:1527876636327};\\\", \\\"{x:600,y:749,t:1527876636344};\\\", \\\"{x:598,y:750,t:1527876636360};\\\", \\\"{x:597,y:750,t:1527876636378};\\\", \\\"{x:594,y:750,t:1527876636394};\\\", \\\"{x:591,y:751,t:1527876636411};\\\", \\\"{x:588,y:753,t:1527876636427};\\\", \\\"{x:583,y:754,t:1527876636444};\\\", \\\"{x:580,y:755,t:1527876636460};\\\", \\\"{x:578,y:755,t:1527876636478};\\\", \\\"{x:576,y:756,t:1527876636493};\\\", \\\"{x:574,y:757,t:1527876636979};\\\", \\\"{x:573,y:758,t:1527876636994};\\\", \\\"{x:571,y:759,t:1527876637011};\\\", \\\"{x:568,y:760,t:1527876637027};\\\", \\\"{x:567,y:760,t:1527876637044};\\\", \\\"{x:565,y:761,t:1527876637062};\\\", \\\"{x:563,y:763,t:1527876637079};\\\", \\\"{x:561,y:763,t:1527876637106};\\\", \\\"{x:561,y:764,t:1527876637114};\\\", \\\"{x:560,y:764,t:1527876637130};\\\", \\\"{x:559,y:764,t:1527876637145};\\\", \\\"{x:557,y:766,t:1527876637161};\\\", \\\"{x:556,y:767,t:1527876637177};\\\", \\\"{x:551,y:770,t:1527876637194};\\\", \\\"{x:550,y:770,t:1527876637211};\\\", \\\"{x:546,y:773,t:1527876637227};\\\", \\\"{x:544,y:774,t:1527876637244};\\\", \\\"{x:539,y:775,t:1527876637261};\\\", \\\"{x:535,y:777,t:1527876637278};\\\", \\\"{x:532,y:778,t:1527876637295};\\\", \\\"{x:529,y:779,t:1527876637311};\\\", \\\"{x:527,y:779,t:1527876637327};\\\", \\\"{x:525,y:780,t:1527876637344};\\\", \\\"{x:524,y:780,t:1527876637361};\\\", \\\"{x:523,y:780,t:1527876637378};\\\", \\\"{x:522,y:780,t:1527876637402};\\\", \\\"{x:521,y:780,t:1527876637411};\\\", \\\"{x:519,y:780,t:1527876637427};\\\", \\\"{x:517,y:780,t:1527876637444};\\\", \\\"{x:516,y:779,t:1527876637461};\\\", \\\"{x:512,y:776,t:1527876637478};\\\", \\\"{x:509,y:774,t:1527876637494};\\\", \\\"{x:507,y:773,t:1527876637511};\\\", \\\"{x:506,y:773,t:1527876637528};\\\", \\\"{x:505,y:772,t:1527876637544};\\\", \\\"{x:504,y:772,t:1527876637578};\\\" ] }, { \\\"rt\\\": 10423, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 224186, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"DJRH1\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -E -E -E -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:505,y:771,t:1527876642899};\\\", \\\"{x:510,y:769,t:1527876642923};\\\", \\\"{x:512,y:767,t:1527876642932};\\\", \\\"{x:518,y:763,t:1527876642948};\\\", \\\"{x:526,y:760,t:1527876642965};\\\", \\\"{x:532,y:757,t:1527876642982};\\\", \\\"{x:541,y:753,t:1527876642999};\\\", \\\"{x:563,y:740,t:1527876643015};\\\", \\\"{x:588,y:729,t:1527876643033};\\\", \\\"{x:618,y:710,t:1527876643048};\\\", \\\"{x:663,y:680,t:1527876643065};\\\", \\\"{x:755,y:617,t:1527876643083};\\\", \\\"{x:837,y:566,t:1527876643099};\\\", \\\"{x:925,y:516,t:1527876643116};\\\", \\\"{x:1003,y:472,t:1527876643133};\\\", \\\"{x:1071,y:439,t:1527876643149};\\\", \\\"{x:1111,y:417,t:1527876643165};\\\", \\\"{x:1133,y:406,t:1527876643182};\\\", \\\"{x:1145,y:401,t:1527876643199};\\\", \\\"{x:1148,y:399,t:1527876643216};\\\", \\\"{x:1150,y:398,t:1527876643233};\\\", \\\"{x:1151,y:398,t:1527876643249};\\\", \\\"{x:1154,y:397,t:1527876643266};\\\", \\\"{x:1159,y:399,t:1527876643282};\\\", \\\"{x:1171,y:407,t:1527876643299};\\\", \\\"{x:1188,y:421,t:1527876643316};\\\", \\\"{x:1200,y:438,t:1527876643333};\\\", \\\"{x:1208,y:453,t:1527876643349};\\\", \\\"{x:1215,y:466,t:1527876643366};\\\", \\\"{x:1220,y:478,t:1527876643383};\\\", \\\"{x:1224,y:491,t:1527876643400};\\\", \\\"{x:1226,y:500,t:1527876643416};\\\", \\\"{x:1230,y:511,t:1527876643432};\\\", \\\"{x:1231,y:513,t:1527876643450};\\\", \\\"{x:1231,y:514,t:1527876643466};\\\", \\\"{x:1231,y:522,t:1527876643483};\\\", \\\"{x:1233,y:531,t:1527876643500};\\\", \\\"{x:1233,y:538,t:1527876643516};\\\", \\\"{x:1234,y:541,t:1527876643533};\\\", \\\"{x:1234,y:542,t:1527876643550};\\\", \\\"{x:1235,y:543,t:1527876643611};\\\", \\\"{x:1235,y:544,t:1527876643635};\\\", \\\"{x:1236,y:545,t:1527876643651};\\\", \\\"{x:1246,y:548,t:1527876643667};\\\", \\\"{x:1262,y:554,t:1527876643683};\\\", \\\"{x:1280,y:559,t:1527876643702};\\\", \\\"{x:1297,y:563,t:1527876643717};\\\", \\\"{x:1308,y:566,t:1527876643732};\\\", \\\"{x:1315,y:569,t:1527876643750};\\\", \\\"{x:1316,y:569,t:1527876643766};\\\", \\\"{x:1315,y:569,t:1527876644028};\\\", \\\"{x:1310,y:569,t:1527876644035};\\\", \\\"{x:1308,y:569,t:1527876644050};\\\", \\\"{x:1303,y:569,t:1527876644066};\\\", \\\"{x:1302,y:569,t:1527876644084};\\\", \\\"{x:1300,y:569,t:1527876644164};\\\", \\\"{x:1298,y:569,t:1527876644171};\\\", \\\"{x:1295,y:569,t:1527876644184};\\\", \\\"{x:1293,y:569,t:1527876644200};\\\", \\\"{x:1288,y:569,t:1527876644217};\\\", \\\"{x:1282,y:569,t:1527876644235};\\\", \\\"{x:1272,y:569,t:1527876644251};\\\", \\\"{x:1254,y:569,t:1527876644267};\\\", \\\"{x:1234,y:569,t:1527876644284};\\\", \\\"{x:1205,y:569,t:1527876644301};\\\", \\\"{x:1178,y:569,t:1527876644317};\\\", \\\"{x:1153,y:573,t:1527876644334};\\\", \\\"{x:1124,y:577,t:1527876644350};\\\", \\\"{x:1100,y:581,t:1527876644367};\\\", \\\"{x:1080,y:584,t:1527876644384};\\\", \\\"{x:1065,y:587,t:1527876644401};\\\", \\\"{x:1045,y:591,t:1527876644417};\\\", \\\"{x:1030,y:592,t:1527876644434};\\\", \\\"{x:1003,y:596,t:1527876644450};\\\", \\\"{x:988,y:598,t:1527876644467};\\\", \\\"{x:978,y:601,t:1527876644484};\\\", \\\"{x:974,y:601,t:1527876644501};\\\", \\\"{x:971,y:602,t:1527876644517};\\\", \\\"{x:971,y:603,t:1527876644534};\\\", \\\"{x:970,y:603,t:1527876644551};\\\", \\\"{x:966,y:604,t:1527876644566};\\\", \\\"{x:959,y:606,t:1527876644584};\\\", \\\"{x:949,y:607,t:1527876644602};\\\", \\\"{x:940,y:608,t:1527876644616};\\\", \\\"{x:926,y:609,t:1527876644633};\\\", \\\"{x:898,y:614,t:1527876644650};\\\", \\\"{x:876,y:617,t:1527876644668};\\\", \\\"{x:851,y:620,t:1527876644684};\\\", \\\"{x:825,y:625,t:1527876644700};\\\", \\\"{x:803,y:626,t:1527876644716};\\\", \\\"{x:784,y:626,t:1527876644733};\\\", \\\"{x:767,y:626,t:1527876644750};\\\", \\\"{x:749,y:626,t:1527876644767};\\\", \\\"{x:732,y:626,t:1527876644784};\\\", \\\"{x:713,y:626,t:1527876644802};\\\", \\\"{x:693,y:626,t:1527876644817};\\\", \\\"{x:664,y:626,t:1527876644833};\\\", \\\"{x:646,y:626,t:1527876644851};\\\", \\\"{x:627,y:626,t:1527876644867};\\\", \\\"{x:606,y:626,t:1527876644884};\\\", \\\"{x:587,y:626,t:1527876644901};\\\", \\\"{x:567,y:626,t:1527876644917};\\\", \\\"{x:544,y:623,t:1527876644933};\\\", \\\"{x:515,y:618,t:1527876644951};\\\", \\\"{x:484,y:614,t:1527876644968};\\\", \\\"{x:454,y:611,t:1527876644984};\\\", \\\"{x:421,y:606,t:1527876645001};\\\", \\\"{x:394,y:603,t:1527876645018};\\\", \\\"{x:361,y:598,t:1527876645035};\\\", \\\"{x:344,y:595,t:1527876645051};\\\", \\\"{x:332,y:592,t:1527876645069};\\\", \\\"{x:329,y:591,t:1527876645083};\\\", \\\"{x:325,y:590,t:1527876645101};\\\", \\\"{x:322,y:590,t:1527876645117};\\\", \\\"{x:319,y:590,t:1527876645133};\\\", \\\"{x:312,y:589,t:1527876645150};\\\", \\\"{x:307,y:589,t:1527876645167};\\\", \\\"{x:304,y:589,t:1527876645184};\\\", \\\"{x:301,y:588,t:1527876645200};\\\", \\\"{x:295,y:587,t:1527876645218};\\\", \\\"{x:284,y:587,t:1527876645234};\\\", \\\"{x:275,y:588,t:1527876645251};\\\", \\\"{x:269,y:589,t:1527876645269};\\\", \\\"{x:264,y:590,t:1527876645285};\\\", \\\"{x:256,y:594,t:1527876645301};\\\", \\\"{x:249,y:597,t:1527876645318};\\\", \\\"{x:242,y:600,t:1527876645334};\\\", \\\"{x:233,y:606,t:1527876645351};\\\", \\\"{x:223,y:612,t:1527876645368};\\\", \\\"{x:210,y:617,t:1527876645384};\\\", \\\"{x:203,y:622,t:1527876645400};\\\", \\\"{x:199,y:622,t:1527876645418};\\\", \\\"{x:198,y:622,t:1527876645434};\\\", \\\"{x:197,y:623,t:1527876645451};\\\", \\\"{x:197,y:624,t:1527876645468};\\\", \\\"{x:196,y:625,t:1527876645484};\\\", \\\"{x:194,y:625,t:1527876645501};\\\", \\\"{x:195,y:625,t:1527876645563};\\\", \\\"{x:201,y:623,t:1527876645571};\\\", \\\"{x:207,y:621,t:1527876645584};\\\", \\\"{x:222,y:615,t:1527876645601};\\\", \\\"{x:250,y:610,t:1527876645618};\\\", \\\"{x:270,y:600,t:1527876645635};\\\", \\\"{x:297,y:593,t:1527876645651};\\\", \\\"{x:324,y:584,t:1527876645668};\\\", \\\"{x:358,y:572,t:1527876645684};\\\", \\\"{x:390,y:558,t:1527876645702};\\\", \\\"{x:413,y:552,t:1527876645718};\\\", \\\"{x:433,y:546,t:1527876645734};\\\", \\\"{x:446,y:542,t:1527876645752};\\\", \\\"{x:454,y:540,t:1527876645767};\\\", \\\"{x:461,y:538,t:1527876645785};\\\", \\\"{x:463,y:538,t:1527876645802};\\\", \\\"{x:467,y:536,t:1527876645818};\\\", \\\"{x:476,y:533,t:1527876645835};\\\", \\\"{x:492,y:529,t:1527876645851};\\\", \\\"{x:509,y:524,t:1527876645868};\\\", \\\"{x:525,y:519,t:1527876645885};\\\", \\\"{x:546,y:514,t:1527876645902};\\\", \\\"{x:566,y:508,t:1527876645918};\\\", \\\"{x:585,y:502,t:1527876645934};\\\", \\\"{x:608,y:496,t:1527876645952};\\\", \\\"{x:629,y:492,t:1527876645968};\\\", \\\"{x:645,y:490,t:1527876645985};\\\", \\\"{x:650,y:490,t:1527876646003};\\\", \\\"{x:649,y:490,t:1527876646163};\\\", \\\"{x:645,y:490,t:1527876646171};\\\", \\\"{x:643,y:492,t:1527876646185};\\\", \\\"{x:636,y:495,t:1527876646202};\\\", \\\"{x:633,y:496,t:1527876646218};\\\", \\\"{x:630,y:497,t:1527876646234};\\\", \\\"{x:629,y:497,t:1527876646252};\\\", \\\"{x:628,y:497,t:1527876646274};\\\", \\\"{x:627,y:497,t:1527876646338};\\\", \\\"{x:626,y:497,t:1527876646354};\\\", \\\"{x:624,y:497,t:1527876646368};\\\", \\\"{x:619,y:498,t:1527876646386};\\\", \\\"{x:613,y:499,t:1527876646402};\\\", \\\"{x:607,y:499,t:1527876646419};\\\", \\\"{x:607,y:500,t:1527876646436};\\\", \\\"{x:606,y:500,t:1527876646698};\\\", \\\"{x:606,y:503,t:1527876646705};\\\", \\\"{x:610,y:509,t:1527876646718};\\\", \\\"{x:618,y:512,t:1527876646736};\\\", \\\"{x:626,y:516,t:1527876646752};\\\", \\\"{x:637,y:521,t:1527876646769};\\\", \\\"{x:658,y:527,t:1527876646786};\\\", \\\"{x:680,y:530,t:1527876646802};\\\", \\\"{x:713,y:534,t:1527876646819};\\\", \\\"{x:733,y:536,t:1527876646836};\\\", \\\"{x:745,y:536,t:1527876646853};\\\", \\\"{x:759,y:536,t:1527876646869};\\\", \\\"{x:775,y:536,t:1527876646885};\\\", \\\"{x:794,y:536,t:1527876646902};\\\", \\\"{x:808,y:538,t:1527876646918};\\\", \\\"{x:820,y:539,t:1527876646936};\\\", \\\"{x:825,y:541,t:1527876646952};\\\", \\\"{x:828,y:542,t:1527876646969};\\\", \\\"{x:829,y:542,t:1527876646986};\\\", \\\"{x:830,y:542,t:1527876647163};\\\", \\\"{x:831,y:544,t:1527876647185};\\\", \\\"{x:833,y:544,t:1527876647202};\\\", \\\"{x:833,y:544,t:1527876647295};\\\", \\\"{x:833,y:545,t:1527876647755};\\\", \\\"{x:835,y:547,t:1527876648051};\\\", \\\"{x:837,y:548,t:1527876648059};\\\", \\\"{x:841,y:550,t:1527876648070};\\\", \\\"{x:846,y:552,t:1527876648088};\\\", \\\"{x:855,y:555,t:1527876648103};\\\", \\\"{x:864,y:558,t:1527876648121};\\\", \\\"{x:873,y:562,t:1527876648137};\\\", \\\"{x:887,y:565,t:1527876648155};\\\", \\\"{x:905,y:570,t:1527876648169};\\\", \\\"{x:915,y:572,t:1527876648186};\\\", \\\"{x:927,y:574,t:1527876648202};\\\", \\\"{x:936,y:575,t:1527876648220};\\\", \\\"{x:942,y:576,t:1527876648236};\\\", \\\"{x:946,y:576,t:1527876648253};\\\", \\\"{x:950,y:577,t:1527876648270};\\\", \\\"{x:954,y:578,t:1527876648288};\\\", \\\"{x:961,y:579,t:1527876648303};\\\", \\\"{x:970,y:581,t:1527876648319};\\\", \\\"{x:982,y:585,t:1527876648337};\\\", \\\"{x:994,y:588,t:1527876648353};\\\", \\\"{x:1011,y:591,t:1527876648370};\\\", \\\"{x:1025,y:595,t:1527876648387};\\\", \\\"{x:1040,y:598,t:1527876648403};\\\", \\\"{x:1051,y:600,t:1527876648420};\\\", \\\"{x:1065,y:604,t:1527876648437};\\\", \\\"{x:1076,y:606,t:1527876648453};\\\", \\\"{x:1083,y:608,t:1527876648470};\\\", \\\"{x:1090,y:609,t:1527876648487};\\\", \\\"{x:1094,y:610,t:1527876648503};\\\", \\\"{x:1095,y:610,t:1527876648520};\\\", \\\"{x:1097,y:610,t:1527876648537};\\\", \\\"{x:1098,y:610,t:1527876648563};\\\", \\\"{x:1100,y:610,t:1527876648571};\\\", \\\"{x:1103,y:610,t:1527876648587};\\\", \\\"{x:1109,y:608,t:1527876648603};\\\", \\\"{x:1121,y:608,t:1527876648620};\\\", \\\"{x:1134,y:606,t:1527876648636};\\\", \\\"{x:1150,y:606,t:1527876648653};\\\", \\\"{x:1170,y:603,t:1527876648670};\\\", \\\"{x:1187,y:601,t:1527876648687};\\\", \\\"{x:1201,y:595,t:1527876648703};\\\", \\\"{x:1215,y:588,t:1527876648720};\\\", \\\"{x:1227,y:585,t:1527876648737};\\\", \\\"{x:1239,y:582,t:1527876648753};\\\", \\\"{x:1242,y:581,t:1527876648783};\\\", \\\"{x:1243,y:581,t:1527876648858};\\\", \\\"{x:1244,y:581,t:1527876648870};\\\", \\\"{x:1246,y:581,t:1527876648886};\\\", \\\"{x:1247,y:581,t:1527876648902};\\\", \\\"{x:1249,y:581,t:1527876648922};\\\", \\\"{x:1253,y:581,t:1527876648936};\\\", \\\"{x:1258,y:581,t:1527876648953};\\\", \\\"{x:1265,y:579,t:1527876648970};\\\", \\\"{x:1267,y:578,t:1527876648986};\\\", \\\"{x:1272,y:576,t:1527876649003};\\\", \\\"{x:1273,y:575,t:1527876649020};\\\", \\\"{x:1274,y:574,t:1527876649036};\\\", \\\"{x:1275,y:574,t:1527876649054};\\\", \\\"{x:1275,y:573,t:1527876649106};\\\", \\\"{x:1275,y:571,t:1527876649120};\\\", \\\"{x:1277,y:563,t:1527876649136};\\\", \\\"{x:1280,y:556,t:1527876649153};\\\", \\\"{x:1280,y:555,t:1527876649170};\\\", \\\"{x:1281,y:554,t:1527876649186};\\\", \\\"{x:1283,y:553,t:1527876649203};\\\", \\\"{x:1284,y:552,t:1527876649220};\\\", \\\"{x:1285,y:552,t:1527876649236};\\\", \\\"{x:1286,y:552,t:1527876649253};\\\", \\\"{x:1286,y:551,t:1527876649270};\\\", \\\"{x:1287,y:552,t:1527876649413};\\\", \\\"{x:1283,y:554,t:1527876649440};\\\", \\\"{x:1280,y:557,t:1527876649453};\\\", \\\"{x:1278,y:560,t:1527876649470};\\\", \\\"{x:1277,y:562,t:1527876649486};\\\", \\\"{x:1276,y:563,t:1527876649828};\\\", \\\"{x:1274,y:563,t:1527876649837};\\\", \\\"{x:1260,y:568,t:1527876649854};\\\", \\\"{x:1244,y:577,t:1527876649870};\\\", \\\"{x:1229,y:584,t:1527876649886};\\\", \\\"{x:1219,y:589,t:1527876649903};\\\", \\\"{x:1207,y:592,t:1527876649919};\\\", \\\"{x:1199,y:594,t:1527876649936};\\\", \\\"{x:1191,y:596,t:1527876649953};\\\", \\\"{x:1182,y:599,t:1527876649969};\\\", \\\"{x:1157,y:603,t:1527876649987};\\\", \\\"{x:1141,y:605,t:1527876650003};\\\", \\\"{x:1117,y:610,t:1527876650019};\\\", \\\"{x:1091,y:612,t:1527876650036};\\\", \\\"{x:1058,y:617,t:1527876650054};\\\", \\\"{x:1020,y:624,t:1527876650070};\\\", \\\"{x:984,y:628,t:1527876650087};\\\", \\\"{x:940,y:628,t:1527876650105};\\\", \\\"{x:894,y:629,t:1527876650119};\\\", \\\"{x:827,y:629,t:1527876650137};\\\", \\\"{x:790,y:629,t:1527876650155};\\\", \\\"{x:756,y:635,t:1527876650173};\\\", \\\"{x:715,y:641,t:1527876650189};\\\", \\\"{x:686,y:646,t:1527876650205};\\\", \\\"{x:665,y:653,t:1527876650222};\\\", \\\"{x:650,y:659,t:1527876650238};\\\", \\\"{x:638,y:665,t:1527876650255};\\\", \\\"{x:625,y:670,t:1527876650272};\\\", \\\"{x:607,y:680,t:1527876650288};\\\", \\\"{x:586,y:689,t:1527876650305};\\\", \\\"{x:556,y:696,t:1527876650322};\\\", \\\"{x:542,y:698,t:1527876650338};\\\", \\\"{x:538,y:698,t:1527876650355};\\\", \\\"{x:537,y:699,t:1527876650372};\\\", \\\"{x:535,y:700,t:1527876650388};\\\", \\\"{x:533,y:705,t:1527876650405};\\\", \\\"{x:530,y:714,t:1527876650422};\\\", \\\"{x:526,y:724,t:1527876650439};\\\", \\\"{x:522,y:731,t:1527876650454};\\\", \\\"{x:522,y:734,t:1527876650472};\\\", \\\"{x:521,y:734,t:1527876650538};\\\", \\\"{x:521,y:741,t:1527876650689};\\\", \\\"{x:521,y:743,t:1527876650705};\\\", \\\"{x:521,y:744,t:1527876650721};\\\", \\\"{x:521,y:743,t:1527876651427};\\\" ] }, { \\\"rt\\\": 22071, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 247554, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"DJRH1\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-6-F -X -X -O -O -O \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:521,y:742,t:1527876652006};\\\", \\\"{x:521,y:741,t:1527876652385};\\\", \\\"{x:521,y:739,t:1527876652404};\\\", \\\"{x:521,y:738,t:1527876652506};\\\", \\\"{x:521,y:736,t:1527876652675};\\\", \\\"{x:521,y:735,t:1527876652963};\\\", \\\"{x:521,y:733,t:1527876653499};\\\", \\\"{x:521,y:726,t:1527876654163};\\\", \\\"{x:514,y:708,t:1527876654177};\\\", \\\"{x:500,y:660,t:1527876654192};\\\", \\\"{x:487,y:605,t:1527876654209};\\\", \\\"{x:480,y:560,t:1527876654225};\\\", \\\"{x:477,y:524,t:1527876654242};\\\", \\\"{x:474,y:509,t:1527876654259};\\\", \\\"{x:473,y:497,t:1527876654275};\\\", \\\"{x:472,y:487,t:1527876654291};\\\", \\\"{x:470,y:481,t:1527876654308};\\\", \\\"{x:469,y:477,t:1527876654325};\\\", \\\"{x:468,y:475,t:1527876654341};\\\", \\\"{x:467,y:472,t:1527876654358};\\\", \\\"{x:466,y:471,t:1527876654375};\\\", \\\"{x:466,y:470,t:1527876654675};\\\", \\\"{x:466,y:469,t:1527876654693};\\\", \\\"{x:466,y:467,t:1527876654709};\\\", \\\"{x:469,y:467,t:1527876654727};\\\", \\\"{x:470,y:466,t:1527876654743};\\\", \\\"{x:471,y:466,t:1527876654762};\\\", \\\"{x:472,y:465,t:1527876654776};\\\", \\\"{x:473,y:465,t:1527876654794};\\\", \\\"{x:474,y:464,t:1527876654809};\\\", \\\"{x:478,y:463,t:1527876654827};\\\", \\\"{x:479,y:462,t:1527876654843};\\\", \\\"{x:493,y:459,t:1527876654860};\\\", \\\"{x:502,y:458,t:1527876654877};\\\", \\\"{x:510,y:455,t:1527876654894};\\\", \\\"{x:518,y:454,t:1527876654910};\\\", \\\"{x:526,y:453,t:1527876654928};\\\", \\\"{x:527,y:453,t:1527876654944};\\\", \\\"{x:528,y:453,t:1527876654961};\\\", \\\"{x:529,y:453,t:1527876655211};\\\", \\\"{x:530,y:453,t:1527876655228};\\\", \\\"{x:531,y:453,t:1527876655244};\\\", \\\"{x:534,y:452,t:1527876655262};\\\", \\\"{x:540,y:452,t:1527876655278};\\\", \\\"{x:546,y:453,t:1527876655294};\\\", \\\"{x:554,y:455,t:1527876655312};\\\", \\\"{x:564,y:457,t:1527876655328};\\\", \\\"{x:578,y:460,t:1527876655345};\\\", \\\"{x:588,y:461,t:1527876655362};\\\", \\\"{x:590,y:462,t:1527876655378};\\\", \\\"{x:591,y:463,t:1527876655707};\\\", \\\"{x:591,y:464,t:1527876655715};\\\", \\\"{x:589,y:465,t:1527876655728};\\\", \\\"{x:585,y:466,t:1527876655746};\\\", \\\"{x:579,y:468,t:1527876655762};\\\", \\\"{x:578,y:469,t:1527876655779};\\\", \\\"{x:577,y:470,t:1527876655796};\\\", \\\"{x:576,y:470,t:1527876656155};\\\", \\\"{x:576,y:469,t:1527876656170};\\\", \\\"{x:577,y:469,t:1527876656181};\\\", \\\"{x:577,y:468,t:1527876656210};\\\", \\\"{x:578,y:468,t:1527876656251};\\\", \\\"{x:579,y:468,t:1527876656274};\\\", \\\"{x:581,y:467,t:1527876656331};\\\", \\\"{x:582,y:466,t:1527876656379};\\\", \\\"{x:583,y:466,t:1527876656387};\\\", \\\"{x:583,y:465,t:1527876656427};\\\", \\\"{x:584,y:465,t:1527876656459};\\\", \\\"{x:583,y:465,t:1527876657594};\\\", \\\"{x:582,y:465,t:1527876657603};\\\", \\\"{x:580,y:466,t:1527876657617};\\\", \\\"{x:579,y:466,t:1527876657633};\\\", \\\"{x:575,y:467,t:1527876657651};\\\", \\\"{x:572,y:468,t:1527876657668};\\\", \\\"{x:556,y:468,t:1527876657683};\\\", \\\"{x:537,y:468,t:1527876657701};\\\", \\\"{x:515,y:468,t:1527876657717};\\\", \\\"{x:492,y:468,t:1527876657735};\\\", \\\"{x:470,y:468,t:1527876657750};\\\", \\\"{x:455,y:468,t:1527876657767};\\\", \\\"{x:447,y:468,t:1527876657784};\\\", \\\"{x:442,y:468,t:1527876657801};\\\", \\\"{x:439,y:468,t:1527876657818};\\\", \\\"{x:428,y:468,t:1527876657834};\\\", \\\"{x:423,y:468,t:1527876657851};\\\", \\\"{x:420,y:468,t:1527876657867};\\\", \\\"{x:416,y:468,t:1527876657884};\\\", \\\"{x:414,y:468,t:1527876657907};\\\", \\\"{x:413,y:468,t:1527876657947};\\\", \\\"{x:411,y:469,t:1527876657963};\\\", \\\"{x:408,y:469,t:1527876657971};\\\", \\\"{x:402,y:469,t:1527876657985};\\\", \\\"{x:393,y:469,t:1527876658001};\\\", \\\"{x:372,y:469,t:1527876658019};\\\", \\\"{x:357,y:469,t:1527876658034};\\\", \\\"{x:343,y:469,t:1527876658051};\\\", \\\"{x:333,y:469,t:1527876658068};\\\", \\\"{x:327,y:469,t:1527876658084};\\\", \\\"{x:322,y:469,t:1527876658102};\\\", \\\"{x:318,y:469,t:1527876658118};\\\", \\\"{x:317,y:469,t:1527876658135};\\\", \\\"{x:316,y:469,t:1527876658151};\\\", \\\"{x:318,y:469,t:1527876658667};\\\", \\\"{x:321,y:469,t:1527876658675};\\\", \\\"{x:326,y:468,t:1527876658687};\\\", \\\"{x:331,y:467,t:1527876658703};\\\", \\\"{x:339,y:464,t:1527876658720};\\\", \\\"{x:347,y:464,t:1527876658737};\\\", \\\"{x:356,y:463,t:1527876658754};\\\", \\\"{x:357,y:463,t:1527876658770};\\\", \\\"{x:359,y:463,t:1527876658787};\\\", \\\"{x:362,y:463,t:1527876658955};\\\", \\\"{x:367,y:465,t:1527876658971};\\\", \\\"{x:375,y:467,t:1527876658987};\\\", \\\"{x:381,y:468,t:1527876659004};\\\", \\\"{x:389,y:468,t:1527876659020};\\\", \\\"{x:396,y:468,t:1527876659038};\\\", \\\"{x:402,y:468,t:1527876659055};\\\", \\\"{x:408,y:467,t:1527876659071};\\\", \\\"{x:420,y:464,t:1527876659088};\\\", \\\"{x:433,y:463,t:1527876659104};\\\", \\\"{x:445,y:463,t:1527876659120};\\\", \\\"{x:454,y:463,t:1527876659138};\\\", \\\"{x:466,y:463,t:1527876659154};\\\", \\\"{x:467,y:463,t:1527876659171};\\\", \\\"{x:469,y:463,t:1527876659443};\\\", \\\"{x:471,y:463,t:1527876659456};\\\", \\\"{x:475,y:463,t:1527876659472};\\\", \\\"{x:479,y:463,t:1527876659489};\\\", \\\"{x:483,y:463,t:1527876659506};\\\", \\\"{x:487,y:463,t:1527876659522};\\\", \\\"{x:492,y:463,t:1527876659538};\\\", \\\"{x:495,y:464,t:1527876659556};\\\", \\\"{x:501,y:464,t:1527876659572};\\\", \\\"{x:509,y:465,t:1527876659589};\\\", \\\"{x:519,y:467,t:1527876659605};\\\", \\\"{x:527,y:468,t:1527876659623};\\\", \\\"{x:536,y:469,t:1527876659639};\\\", \\\"{x:540,y:470,t:1527876659656};\\\", \\\"{x:542,y:470,t:1527876659673};\\\", \\\"{x:543,y:470,t:1527876659690};\\\", \\\"{x:544,y:470,t:1527876659706};\\\", \\\"{x:545,y:470,t:1527876659722};\\\", \\\"{x:546,y:470,t:1527876659739};\\\", \\\"{x:547,y:470,t:1527876659756};\\\", \\\"{x:548,y:470,t:1527876659773};\\\", \\\"{x:549,y:470,t:1527876659790};\\\", \\\"{x:551,y:470,t:1527876659867};\\\", \\\"{x:553,y:470,t:1527876659874};\\\", \\\"{x:555,y:470,t:1527876659890};\\\", \\\"{x:559,y:470,t:1527876659906};\\\", \\\"{x:566,y:470,t:1527876659923};\\\", \\\"{x:570,y:469,t:1527876659940};\\\", \\\"{x:574,y:467,t:1527876659957};\\\", \\\"{x:579,y:465,t:1527876659974};\\\", \\\"{x:586,y:462,t:1527876659990};\\\", \\\"{x:594,y:459,t:1527876660007};\\\", \\\"{x:600,y:455,t:1527876660024};\\\", \\\"{x:604,y:454,t:1527876660040};\\\", \\\"{x:608,y:451,t:1527876660057};\\\", \\\"{x:614,y:449,t:1527876660074};\\\", \\\"{x:619,y:447,t:1527876660091};\\\", \\\"{x:626,y:444,t:1527876660106};\\\", \\\"{x:631,y:443,t:1527876660124};\\\", \\\"{x:642,y:442,t:1527876660140};\\\", \\\"{x:658,y:442,t:1527876660156};\\\", \\\"{x:685,y:442,t:1527876660174};\\\", \\\"{x:720,y:449,t:1527876660191};\\\", \\\"{x:760,y:456,t:1527876660208};\\\", \\\"{x:789,y:459,t:1527876660224};\\\", \\\"{x:812,y:464,t:1527876660241};\\\", \\\"{x:834,y:466,t:1527876660258};\\\", \\\"{x:844,y:467,t:1527876660274};\\\", \\\"{x:851,y:467,t:1527876660291};\\\", \\\"{x:856,y:468,t:1527876660531};\\\", \\\"{x:865,y:473,t:1527876660542};\\\", \\\"{x:891,y:489,t:1527876660560};\\\", \\\"{x:920,y:500,t:1527876660574};\\\", \\\"{x:956,y:515,t:1527876660591};\\\", \\\"{x:1004,y:536,t:1527876660614};\\\", \\\"{x:1028,y:546,t:1527876660629};\\\", \\\"{x:1046,y:555,t:1527876660647};\\\", \\\"{x:1062,y:562,t:1527876660664};\\\", \\\"{x:1083,y:575,t:1527876660680};\\\", \\\"{x:1105,y:588,t:1527876660696};\\\", \\\"{x:1129,y:601,t:1527876660714};\\\", \\\"{x:1146,y:607,t:1527876660729};\\\", \\\"{x:1160,y:612,t:1527876660746};\\\", \\\"{x:1163,y:613,t:1527876660763};\\\", \\\"{x:1164,y:613,t:1527876660779};\\\", \\\"{x:1166,y:615,t:1527876660797};\\\", \\\"{x:1168,y:615,t:1527876660813};\\\", \\\"{x:1169,y:615,t:1527876660830};\\\", \\\"{x:1169,y:616,t:1527876660850};\\\", \\\"{x:1171,y:617,t:1527876660923};\\\", \\\"{x:1175,y:622,t:1527876660931};\\\", \\\"{x:1184,y:633,t:1527876660947};\\\", \\\"{x:1195,y:643,t:1527876660964};\\\", \\\"{x:1210,y:654,t:1527876660979};\\\", \\\"{x:1222,y:658,t:1527876660997};\\\", \\\"{x:1225,y:658,t:1527876661013};\\\", \\\"{x:1226,y:658,t:1527876661041};\\\", \\\"{x:1227,y:658,t:1527876661058};\\\", \\\"{x:1228,y:657,t:1527876661066};\\\", \\\"{x:1229,y:656,t:1527876661082};\\\", \\\"{x:1231,y:657,t:1527876661203};\\\", \\\"{x:1235,y:662,t:1527876661215};\\\", \\\"{x:1244,y:670,t:1527876661231};\\\", \\\"{x:1252,y:675,t:1527876661247};\\\", \\\"{x:1255,y:676,t:1527876661264};\\\", \\\"{x:1256,y:677,t:1527876661281};\\\", \\\"{x:1256,y:678,t:1527876661347};\\\", \\\"{x:1256,y:681,t:1527876661365};\\\", \\\"{x:1258,y:687,t:1527876661381};\\\", \\\"{x:1259,y:688,t:1527876661397};\\\", \\\"{x:1260,y:690,t:1527876661414};\\\", \\\"{x:1260,y:691,t:1527876661431};\\\", \\\"{x:1261,y:692,t:1527876661448};\\\", \\\"{x:1262,y:694,t:1527876661464};\\\", \\\"{x:1264,y:696,t:1527876661481};\\\", \\\"{x:1265,y:698,t:1527876661498};\\\", \\\"{x:1267,y:699,t:1527876661514};\\\", \\\"{x:1267,y:700,t:1527876661531};\\\", \\\"{x:1269,y:700,t:1527876661724};\\\", \\\"{x:1271,y:700,t:1527876661731};\\\", \\\"{x:1283,y:700,t:1527876661747};\\\", \\\"{x:1294,y:700,t:1527876661763};\\\", \\\"{x:1305,y:700,t:1527876661780};\\\", \\\"{x:1309,y:700,t:1527876661798};\\\", \\\"{x:1311,y:700,t:1527876661813};\\\", \\\"{x:1312,y:700,t:1527876661882};\\\", \\\"{x:1313,y:699,t:1527876661898};\\\", \\\"{x:1314,y:698,t:1527876661914};\\\", \\\"{x:1315,y:698,t:1527876662011};\\\", \\\"{x:1316,y:698,t:1527876662019};\\\", \\\"{x:1319,y:698,t:1527876662034};\\\", \\\"{x:1320,y:697,t:1527876662048};\\\", \\\"{x:1324,y:696,t:1527876662066};\\\", \\\"{x:1325,y:696,t:1527876662082};\\\", \\\"{x:1327,y:695,t:1527876662098};\\\", \\\"{x:1328,y:695,t:1527876662171};\\\", \\\"{x:1330,y:694,t:1527876662181};\\\", \\\"{x:1331,y:694,t:1527876662203};\\\", \\\"{x:1332,y:694,t:1527876662215};\\\", \\\"{x:1332,y:693,t:1527876662231};\\\", \\\"{x:1333,y:693,t:1527876662291};\\\", \\\"{x:1334,y:693,t:1527876662307};\\\", \\\"{x:1335,y:693,t:1527876662330};\\\", \\\"{x:1336,y:693,t:1527876662362};\\\", \\\"{x:1338,y:693,t:1527876662386};\\\", \\\"{x:1339,y:693,t:1527876662398};\\\", \\\"{x:1340,y:694,t:1527876662415};\\\", \\\"{x:1341,y:694,t:1527876662491};\\\", \\\"{x:1342,y:694,t:1527876662498};\\\", \\\"{x:1343,y:695,t:1527876662574};\\\", \\\"{x:1344,y:696,t:1527876662913};\\\", \\\"{x:1344,y:697,t:1527876662931};\\\", \\\"{x:1345,y:697,t:1527876662949};\\\", \\\"{x:1345,y:698,t:1527876666462};\\\", \\\"{x:1346,y:702,t:1527876667726};\\\", \\\"{x:1352,y:708,t:1527876667740};\\\", \\\"{x:1371,y:723,t:1527876667755};\\\", \\\"{x:1393,y:735,t:1527876667773};\\\", \\\"{x:1408,y:744,t:1527876667788};\\\", \\\"{x:1426,y:755,t:1527876667806};\\\", \\\"{x:1433,y:760,t:1527876667822};\\\", \\\"{x:1441,y:766,t:1527876667839};\\\", \\\"{x:1450,y:774,t:1527876667856};\\\", \\\"{x:1460,y:779,t:1527876667873};\\\", \\\"{x:1469,y:787,t:1527876667889};\\\", \\\"{x:1473,y:790,t:1527876667906};\\\", \\\"{x:1474,y:791,t:1527876667923};\\\", \\\"{x:1475,y:793,t:1527876667939};\\\", \\\"{x:1478,y:798,t:1527876667956};\\\", \\\"{x:1482,y:805,t:1527876667973};\\\", \\\"{x:1487,y:812,t:1527876667988};\\\", \\\"{x:1490,y:818,t:1527876668006};\\\", \\\"{x:1490,y:819,t:1527876668094};\\\", \\\"{x:1491,y:820,t:1527876668183};\\\", \\\"{x:1491,y:821,t:1527876668190};\\\", \\\"{x:1491,y:822,t:1527876668206};\\\", \\\"{x:1491,y:823,t:1527876668223};\\\", \\\"{x:1491,y:824,t:1527876668240};\\\", \\\"{x:1491,y:825,t:1527876668256};\\\", \\\"{x:1490,y:826,t:1527876668273};\\\", \\\"{x:1489,y:827,t:1527876668290};\\\", \\\"{x:1487,y:827,t:1527876668305};\\\", \\\"{x:1486,y:827,t:1527876668324};\\\", \\\"{x:1484,y:827,t:1527876668358};\\\", \\\"{x:1483,y:827,t:1527876668462};\\\", \\\"{x:1482,y:827,t:1527876668526};\\\", \\\"{x:1482,y:825,t:1527876668614};\\\", \\\"{x:1482,y:822,t:1527876668623};\\\", \\\"{x:1484,y:814,t:1527876668640};\\\", \\\"{x:1486,y:808,t:1527876668656};\\\", \\\"{x:1493,y:798,t:1527876668673};\\\", \\\"{x:1495,y:793,t:1527876668690};\\\", \\\"{x:1497,y:790,t:1527876668707};\\\", \\\"{x:1498,y:789,t:1527876668723};\\\", \\\"{x:1498,y:788,t:1527876668739};\\\", \\\"{x:1500,y:787,t:1527876668756};\\\", \\\"{x:1500,y:786,t:1527876668772};\\\", \\\"{x:1501,y:784,t:1527876668789};\\\", \\\"{x:1502,y:783,t:1527876668813};\\\", \\\"{x:1503,y:783,t:1527876668869};\\\", \\\"{x:1503,y:781,t:1527876668877};\\\", \\\"{x:1504,y:781,t:1527876668889};\\\", \\\"{x:1505,y:778,t:1527876668906};\\\", \\\"{x:1508,y:773,t:1527876668922};\\\", \\\"{x:1512,y:765,t:1527876668939};\\\", \\\"{x:1516,y:759,t:1527876668957};\\\", \\\"{x:1516,y:757,t:1527876668973};\\\", \\\"{x:1515,y:757,t:1527876669278};\\\", \\\"{x:1515,y:758,t:1527876670031};\\\", \\\"{x:1513,y:759,t:1527876670142};\\\", \\\"{x:1513,y:760,t:1527876670157};\\\", \\\"{x:1511,y:764,t:1527876670174};\\\", \\\"{x:1511,y:765,t:1527876670191};\\\", \\\"{x:1511,y:766,t:1527876670207};\\\", \\\"{x:1510,y:767,t:1527876670223};\\\", \\\"{x:1509,y:768,t:1527876670279};\\\", \\\"{x:1509,y:769,t:1527876670318};\\\", \\\"{x:1509,y:768,t:1527876670798};\\\", \\\"{x:1504,y:767,t:1527876671454};\\\", \\\"{x:1492,y:767,t:1527876671462};\\\", \\\"{x:1475,y:767,t:1527876671475};\\\", \\\"{x:1439,y:767,t:1527876671492};\\\", \\\"{x:1385,y:767,t:1527876671508};\\\", \\\"{x:1335,y:767,t:1527876671525};\\\", \\\"{x:1232,y:767,t:1527876671542};\\\", \\\"{x:1176,y:767,t:1527876671559};\\\", \\\"{x:1126,y:767,t:1527876671575};\\\", \\\"{x:1070,y:767,t:1527876671592};\\\", \\\"{x:1006,y:766,t:1527876671609};\\\", \\\"{x:947,y:758,t:1527876671625};\\\", \\\"{x:891,y:750,t:1527876671642};\\\", \\\"{x:835,y:740,t:1527876671659};\\\", \\\"{x:777,y:727,t:1527876671674};\\\", \\\"{x:719,y:710,t:1527876671691};\\\", \\\"{x:662,y:692,t:1527876671708};\\\", \\\"{x:627,y:678,t:1527876671725};\\\", \\\"{x:592,y:662,t:1527876671741};\\\", \\\"{x:576,y:653,t:1527876671758};\\\", \\\"{x:565,y:648,t:1527876671775};\\\", \\\"{x:557,y:645,t:1527876671792};\\\", \\\"{x:554,y:644,t:1527876671809};\\\", \\\"{x:553,y:643,t:1527876671844};\\\", \\\"{x:553,y:640,t:1527876671859};\\\", \\\"{x:563,y:633,t:1527876671874};\\\", \\\"{x:582,y:625,t:1527876671892};\\\", \\\"{x:604,y:620,t:1527876671908};\\\", \\\"{x:645,y:614,t:1527876671922};\\\", \\\"{x:699,y:613,t:1527876671938};\\\", \\\"{x:734,y:613,t:1527876671956};\\\", \\\"{x:758,y:613,t:1527876671972};\\\", \\\"{x:780,y:610,t:1527876671992};\\\", \\\"{x:783,y:609,t:1527876672009};\\\", \\\"{x:784,y:609,t:1527876672025};\\\", \\\"{x:786,y:609,t:1527876672042};\\\", \\\"{x:790,y:608,t:1527876672059};\\\", \\\"{x:801,y:605,t:1527876672075};\\\", \\\"{x:812,y:602,t:1527876672092};\\\", \\\"{x:825,y:599,t:1527876672110};\\\", \\\"{x:827,y:597,t:1527876672125};\\\", \\\"{x:826,y:597,t:1527876672247};\\\", \\\"{x:822,y:597,t:1527876672259};\\\", \\\"{x:804,y:597,t:1527876672277};\\\", \\\"{x:769,y:597,t:1527876672293};\\\", \\\"{x:744,y:595,t:1527876672310};\\\", \\\"{x:724,y:594,t:1527876672327};\\\", \\\"{x:708,y:591,t:1527876672344};\\\", \\\"{x:697,y:589,t:1527876672360};\\\", \\\"{x:691,y:589,t:1527876672376};\\\", \\\"{x:690,y:589,t:1527876672393};\\\", \\\"{x:688,y:589,t:1527876672445};\\\", \\\"{x:684,y:589,t:1527876672459};\\\", \\\"{x:673,y:589,t:1527876672476};\\\", \\\"{x:665,y:589,t:1527876672493};\\\", \\\"{x:663,y:589,t:1527876672509};\\\", \\\"{x:661,y:589,t:1527876672527};\\\", \\\"{x:658,y:589,t:1527876672544};\\\", \\\"{x:652,y:587,t:1527876672560};\\\", \\\"{x:646,y:587,t:1527876672577};\\\", \\\"{x:640,y:586,t:1527876672594};\\\", \\\"{x:637,y:586,t:1527876672611};\\\", \\\"{x:636,y:586,t:1527876672626};\\\", \\\"{x:635,y:585,t:1527876672643};\\\", \\\"{x:634,y:585,t:1527876672659};\\\", \\\"{x:633,y:584,t:1527876672676};\\\", \\\"{x:631,y:583,t:1527876672693};\\\", \\\"{x:630,y:583,t:1527876672710};\\\", \\\"{x:629,y:583,t:1527876672726};\\\", \\\"{x:630,y:582,t:1527876672949};\\\", \\\"{x:632,y:580,t:1527876672960};\\\", \\\"{x:665,y:580,t:1527876672977};\\\", \\\"{x:700,y:578,t:1527876672993};\\\", \\\"{x:720,y:578,t:1527876673010};\\\", \\\"{x:742,y:578,t:1527876673027};\\\", \\\"{x:757,y:578,t:1527876673043};\\\", \\\"{x:764,y:578,t:1527876673060};\\\", \\\"{x:772,y:578,t:1527876673076};\\\", \\\"{x:788,y:578,t:1527876673093};\\\", \\\"{x:796,y:578,t:1527876673110};\\\", \\\"{x:808,y:578,t:1527876673127};\\\", \\\"{x:819,y:578,t:1527876673143};\\\", \\\"{x:824,y:578,t:1527876673161};\\\", \\\"{x:825,y:578,t:1527876673176};\\\", \\\"{x:826,y:578,t:1527876673206};\\\", \\\"{x:827,y:578,t:1527876673229};\\\", \\\"{x:830,y:578,t:1527876673245};\\\", \\\"{x:831,y:578,t:1527876673261};\\\", \\\"{x:833,y:578,t:1527876673278};\\\", \\\"{x:834,y:578,t:1527876673293};\\\", \\\"{x:830,y:578,t:1527876673518};\\\", \\\"{x:811,y:583,t:1527876673528};\\\", \\\"{x:759,y:605,t:1527876673544};\\\", \\\"{x:716,y:621,t:1527876673561};\\\", \\\"{x:682,y:636,t:1527876673578};\\\", \\\"{x:647,y:649,t:1527876673594};\\\", \\\"{x:624,y:660,t:1527876673611};\\\", \\\"{x:610,y:668,t:1527876673627};\\\", \\\"{x:597,y:675,t:1527876673644};\\\", \\\"{x:583,y:683,t:1527876673661};\\\", \\\"{x:561,y:696,t:1527876673678};\\\", \\\"{x:548,y:707,t:1527876673694};\\\", \\\"{x:537,y:716,t:1527876673711};\\\", \\\"{x:531,y:720,t:1527876673728};\\\", \\\"{x:529,y:721,t:1527876673744};\\\", \\\"{x:528,y:721,t:1527876673761};\\\", \\\"{x:526,y:721,t:1527876673777};\\\", \\\"{x:526,y:722,t:1527876673806};\\\", \\\"{x:525,y:723,t:1527876673814};\\\", \\\"{x:524,y:725,t:1527876673838};\\\", \\\"{x:522,y:725,t:1527876673845};\\\", \\\"{x:521,y:727,t:1527876673861};\\\", \\\"{x:521,y:728,t:1527876673878};\\\", \\\"{x:520,y:728,t:1527876673896};\\\" ] }, { \\\"rt\\\": 51967, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 300782, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"DJRH1\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -B -B -F -F -F -B -B -J -J -I -F -F -F -G -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:519,y:726,t:1527876675294};\\\", \\\"{x:519,y:725,t:1527876675333};\\\", \\\"{x:519,y:724,t:1527876675356};\\\", \\\"{x:519,y:723,t:1527876675373};\\\", \\\"{x:519,y:722,t:1527876675487};\\\", \\\"{x:519,y:721,t:1527876675500};\\\", \\\"{x:519,y:720,t:1527876675517};\\\", \\\"{x:519,y:719,t:1527876675565};\\\", \\\"{x:519,y:714,t:1527876675701};\\\", \\\"{x:519,y:713,t:1527876675712};\\\", \\\"{x:519,y:712,t:1527876675729};\\\", \\\"{x:519,y:711,t:1527876675745};\\\", \\\"{x:519,y:710,t:1527876675821};\\\", \\\"{x:519,y:709,t:1527876675926};\\\", \\\"{x:517,y:708,t:1527876675933};\\\", \\\"{x:515,y:705,t:1527876675945};\\\", \\\"{x:510,y:700,t:1527876675962};\\\", \\\"{x:500,y:691,t:1527876675979};\\\", \\\"{x:486,y:676,t:1527876675996};\\\", \\\"{x:473,y:660,t:1527876676014};\\\", \\\"{x:451,y:627,t:1527876676030};\\\", \\\"{x:439,y:605,t:1527876676046};\\\", \\\"{x:428,y:578,t:1527876676063};\\\", \\\"{x:420,y:559,t:1527876676080};\\\", \\\"{x:412,y:542,t:1527876676095};\\\", \\\"{x:407,y:529,t:1527876676112};\\\", \\\"{x:405,y:520,t:1527876676130};\\\", \\\"{x:403,y:510,t:1527876676146};\\\", \\\"{x:401,y:498,t:1527876676162};\\\", \\\"{x:400,y:488,t:1527876676180};\\\", \\\"{x:398,y:479,t:1527876676196};\\\", \\\"{x:397,y:471,t:1527876676213};\\\", \\\"{x:397,y:466,t:1527876676229};\\\", \\\"{x:396,y:465,t:1527876676246};\\\", \\\"{x:396,y:464,t:1527876676630};\\\", \\\"{x:399,y:462,t:1527876676645};\\\", \\\"{x:402,y:461,t:1527876676662};\\\", \\\"{x:405,y:459,t:1527876676680};\\\", \\\"{x:407,y:458,t:1527876676696};\\\", \\\"{x:408,y:458,t:1527876676713};\\\", \\\"{x:409,y:458,t:1527876677198};\\\", \\\"{x:409,y:460,t:1527876677422};\\\", \\\"{x:409,y:468,t:1527876677430};\\\", \\\"{x:402,y:483,t:1527876677446};\\\", \\\"{x:397,y:495,t:1527876677464};\\\", \\\"{x:396,y:498,t:1527876677478};\\\", \\\"{x:396,y:499,t:1527876677497};\\\", \\\"{x:396,y:500,t:1527876677710};\\\", \\\"{x:399,y:502,t:1527876677718};\\\", \\\"{x:401,y:503,t:1527876677731};\\\", \\\"{x:412,y:506,t:1527876677748};\\\", \\\"{x:428,y:511,t:1527876677766};\\\", \\\"{x:455,y:518,t:1527876677781};\\\", \\\"{x:535,y:532,t:1527876677798};\\\", \\\"{x:610,y:541,t:1527876677813};\\\", \\\"{x:694,y:545,t:1527876677831};\\\", \\\"{x:775,y:545,t:1527876677848};\\\", \\\"{x:855,y:545,t:1527876677864};\\\", \\\"{x:933,y:545,t:1527876677881};\\\", \\\"{x:997,y:538,t:1527876677898};\\\", \\\"{x:1048,y:530,t:1527876677913};\\\", \\\"{x:1070,y:526,t:1527876677930};\\\", \\\"{x:1089,y:525,t:1527876677948};\\\", \\\"{x:1095,y:525,t:1527876677965};\\\", \\\"{x:1095,y:531,t:1527876678334};\\\", \\\"{x:1095,y:538,t:1527876678348};\\\", \\\"{x:1095,y:548,t:1527876678365};\\\", \\\"{x:1095,y:552,t:1527876678381};\\\", \\\"{x:1095,y:554,t:1527876678398};\\\", \\\"{x:1095,y:556,t:1527876680374};\\\", \\\"{x:1093,y:556,t:1527876680384};\\\", \\\"{x:1091,y:559,t:1527876680400};\\\", \\\"{x:1088,y:559,t:1527876680417};\\\", \\\"{x:1087,y:560,t:1527876680434};\\\", \\\"{x:1085,y:561,t:1527876680450};\\\", \\\"{x:1084,y:562,t:1527876680466};\\\", \\\"{x:1083,y:562,t:1527876682518};\\\", \\\"{x:1082,y:562,t:1527876682558};\\\", \\\"{x:1081,y:563,t:1527876682574};\\\", \\\"{x:1080,y:564,t:1527876682718};\\\", \\\"{x:1080,y:565,t:1527876682790};\\\", \\\"{x:1080,y:567,t:1527876682802};\\\", \\\"{x:1080,y:568,t:1527876682819};\\\", \\\"{x:1081,y:569,t:1527876682836};\\\", \\\"{x:1081,y:570,t:1527876682851};\\\", \\\"{x:1081,y:571,t:1527876682869};\\\", \\\"{x:1082,y:572,t:1527876682885};\\\", \\\"{x:1085,y:576,t:1527876682902};\\\", \\\"{x:1088,y:579,t:1527876682919};\\\", \\\"{x:1089,y:581,t:1527876682936};\\\", \\\"{x:1091,y:583,t:1527876682952};\\\", \\\"{x:1092,y:585,t:1527876682968};\\\", \\\"{x:1093,y:586,t:1527876682986};\\\", \\\"{x:1094,y:588,t:1527876683001};\\\", \\\"{x:1096,y:591,t:1527876683018};\\\", \\\"{x:1097,y:593,t:1527876683036};\\\", \\\"{x:1099,y:594,t:1527876683052};\\\", \\\"{x:1106,y:601,t:1527876683071};\\\", \\\"{x:1109,y:604,t:1527876683085};\\\", \\\"{x:1116,y:610,t:1527876683102};\\\", \\\"{x:1117,y:610,t:1527876683118};\\\", \\\"{x:1118,y:611,t:1527876683135};\\\", \\\"{x:1120,y:611,t:1527876683198};\\\", \\\"{x:1125,y:615,t:1527876683206};\\\", \\\"{x:1131,y:620,t:1527876683218};\\\", \\\"{x:1142,y:626,t:1527876683235};\\\", \\\"{x:1151,y:633,t:1527876683253};\\\", \\\"{x:1157,y:639,t:1527876683270};\\\", \\\"{x:1169,y:650,t:1527876683286};\\\", \\\"{x:1179,y:657,t:1527876683302};\\\", \\\"{x:1189,y:664,t:1527876683319};\\\", \\\"{x:1194,y:668,t:1527876683336};\\\", \\\"{x:1197,y:670,t:1527876683353};\\\", \\\"{x:1200,y:672,t:1527876683368};\\\", \\\"{x:1200,y:673,t:1527876683385};\\\", \\\"{x:1202,y:673,t:1527876683402};\\\", \\\"{x:1204,y:674,t:1527876683418};\\\", \\\"{x:1211,y:675,t:1527876683435};\\\", \\\"{x:1225,y:677,t:1527876683452};\\\", \\\"{x:1239,y:679,t:1527876683470};\\\", \\\"{x:1242,y:679,t:1527876683486};\\\", \\\"{x:1262,y:683,t:1527876683501};\\\", \\\"{x:1272,y:683,t:1527876683519};\\\", \\\"{x:1280,y:683,t:1527876683535};\\\", \\\"{x:1285,y:684,t:1527876683553};\\\", \\\"{x:1289,y:684,t:1527876683571};\\\", \\\"{x:1293,y:684,t:1527876683585};\\\", \\\"{x:1297,y:684,t:1527876683601};\\\", \\\"{x:1299,y:684,t:1527876683618};\\\", \\\"{x:1301,y:684,t:1527876683635};\\\", \\\"{x:1307,y:684,t:1527876683652};\\\", \\\"{x:1315,y:684,t:1527876683669};\\\", \\\"{x:1319,y:686,t:1527876683685};\\\", \\\"{x:1323,y:687,t:1527876683702};\\\", \\\"{x:1325,y:688,t:1527876683719};\\\", \\\"{x:1327,y:689,t:1527876683735};\\\", \\\"{x:1328,y:690,t:1527876683751};\\\", \\\"{x:1329,y:691,t:1527876683769};\\\", \\\"{x:1331,y:694,t:1527876683785};\\\", \\\"{x:1333,y:697,t:1527876683802};\\\", \\\"{x:1334,y:699,t:1527876683818};\\\", \\\"{x:1336,y:700,t:1527876683835};\\\", \\\"{x:1336,y:701,t:1527876683852};\\\", \\\"{x:1337,y:701,t:1527876683950};\\\", \\\"{x:1338,y:701,t:1527876683957};\\\", \\\"{x:1339,y:701,t:1527876683970};\\\", \\\"{x:1341,y:701,t:1527876683986};\\\", \\\"{x:1343,y:701,t:1527876684002};\\\", \\\"{x:1344,y:701,t:1527876684021};\\\", \\\"{x:1346,y:699,t:1527876684035};\\\", \\\"{x:1349,y:698,t:1527876684052};\\\", \\\"{x:1350,y:697,t:1527876684070};\\\", \\\"{x:1351,y:697,t:1527876684094};\\\", \\\"{x:1352,y:697,t:1527876684118};\\\", \\\"{x:1352,y:696,t:1527876684125};\\\", \\\"{x:1350,y:696,t:1527876684941};\\\", \\\"{x:1349,y:696,t:1527876684952};\\\", \\\"{x:1348,y:696,t:1527876684981};\\\", \\\"{x:1347,y:696,t:1527876685005};\\\", \\\"{x:1346,y:696,t:1527876686110};\\\", \\\"{x:1346,y:697,t:1527876697478};\\\", \\\"{x:1346,y:703,t:1527876697497};\\\", \\\"{x:1350,y:709,t:1527876697512};\\\", \\\"{x:1351,y:713,t:1527876697529};\\\", \\\"{x:1352,y:714,t:1527876697546};\\\", \\\"{x:1353,y:715,t:1527876697562};\\\", \\\"{x:1354,y:716,t:1527876697579};\\\", \\\"{x:1355,y:720,t:1527876697596};\\\", \\\"{x:1358,y:725,t:1527876697612};\\\", \\\"{x:1362,y:731,t:1527876697629};\\\", \\\"{x:1365,y:736,t:1527876697646};\\\", \\\"{x:1366,y:738,t:1527876697663};\\\", \\\"{x:1366,y:739,t:1527876697685};\\\", \\\"{x:1368,y:740,t:1527876697702};\\\", \\\"{x:1368,y:741,t:1527876697717};\\\", \\\"{x:1368,y:742,t:1527876697729};\\\", \\\"{x:1371,y:747,t:1527876697746};\\\", \\\"{x:1374,y:752,t:1527876697763};\\\", \\\"{x:1375,y:756,t:1527876697779};\\\", \\\"{x:1376,y:758,t:1527876697796};\\\", \\\"{x:1377,y:759,t:1527876697812};\\\", \\\"{x:1377,y:762,t:1527876697837};\\\", \\\"{x:1379,y:763,t:1527876697845};\\\", \\\"{x:1379,y:764,t:1527876697863};\\\", \\\"{x:1380,y:766,t:1527876697879};\\\", \\\"{x:1381,y:767,t:1527876697896};\\\", \\\"{x:1380,y:767,t:1527876699038};\\\", \\\"{x:1379,y:767,t:1527876699647};\\\", \\\"{x:1378,y:766,t:1527876699782};\\\", \\\"{x:1377,y:766,t:1527876700054};\\\", \\\"{x:1377,y:765,t:1527876700078};\\\", \\\"{x:1376,y:765,t:1527876700126};\\\", \\\"{x:1375,y:765,t:1527876700158};\\\", \\\"{x:1373,y:764,t:1527876700182};\\\", \\\"{x:1371,y:764,t:1527876700197};\\\", \\\"{x:1370,y:764,t:1527876700214};\\\", \\\"{x:1368,y:763,t:1527876700232};\\\", \\\"{x:1367,y:763,t:1527876700248};\\\", \\\"{x:1365,y:763,t:1527876700270};\\\", \\\"{x:1364,y:763,t:1527876700310};\\\", \\\"{x:1362,y:763,t:1527876700358};\\\", \\\"{x:1361,y:763,t:1527876700406};\\\", \\\"{x:1360,y:763,t:1527876700478};\\\", \\\"{x:1359,y:763,t:1527876700509};\\\", \\\"{x:1358,y:763,t:1527876700534};\\\", \\\"{x:1357,y:763,t:1527876700558};\\\", \\\"{x:1356,y:763,t:1527876700574};\\\", \\\"{x:1355,y:763,t:1527876700598};\\\", \\\"{x:1354,y:763,t:1527876700686};\\\", \\\"{x:1353,y:763,t:1527876700710};\\\", \\\"{x:1352,y:763,t:1527876700750};\\\", \\\"{x:1351,y:763,t:1527876700894};\\\", \\\"{x:1350,y:763,t:1527876700901};\\\", \\\"{x:1349,y:763,t:1527876700917};\\\", \\\"{x:1348,y:762,t:1527876700933};\\\", \\\"{x:1347,y:762,t:1527876700957};\\\", \\\"{x:1346,y:762,t:1527876700982};\\\", \\\"{x:1345,y:762,t:1527876701021};\\\", \\\"{x:1344,y:761,t:1527876701071};\\\", \\\"{x:1345,y:761,t:1527876701742};\\\", \\\"{x:1346,y:761,t:1527876701750};\\\", \\\"{x:1346,y:762,t:1527876701782};\\\", \\\"{x:1346,y:763,t:1527876701894};\\\", \\\"{x:1347,y:764,t:1527876702358};\\\", \\\"{x:1348,y:764,t:1527876702519};\\\", \\\"{x:1350,y:764,t:1527876702766};\\\", \\\"{x:1351,y:765,t:1527876702783};\\\", \\\"{x:1352,y:766,t:1527876702799};\\\", \\\"{x:1352,y:766,t:1527876702957};\\\", \\\"{x:1352,y:765,t:1527876703046};\\\", \\\"{x:1351,y:765,t:1527876703053};\\\", \\\"{x:1350,y:764,t:1527876703066};\\\", \\\"{x:1349,y:762,t:1527876703083};\\\", \\\"{x:1348,y:757,t:1527876703101};\\\", \\\"{x:1346,y:751,t:1527876703116};\\\", \\\"{x:1346,y:741,t:1527876703134};\\\", \\\"{x:1346,y:736,t:1527876703149};\\\", \\\"{x:1346,y:734,t:1527876703166};\\\", \\\"{x:1347,y:728,t:1527876703183};\\\", \\\"{x:1347,y:725,t:1527876703200};\\\", \\\"{x:1347,y:716,t:1527876703216};\\\", \\\"{x:1347,y:710,t:1527876703234};\\\", \\\"{x:1347,y:707,t:1527876703250};\\\", \\\"{x:1347,y:706,t:1527876703266};\\\", \\\"{x:1347,y:704,t:1527876703286};\\\", \\\"{x:1347,y:703,t:1527876703326};\\\", \\\"{x:1347,y:701,t:1527876703406};\\\", \\\"{x:1347,y:700,t:1527876703416};\\\", \\\"{x:1347,y:696,t:1527876703433};\\\", \\\"{x:1347,y:694,t:1527876703450};\\\", \\\"{x:1347,y:693,t:1527876703467};\\\", \\\"{x:1347,y:691,t:1527876703485};\\\", \\\"{x:1347,y:689,t:1527876703501};\\\", \\\"{x:1347,y:686,t:1527876703517};\\\", \\\"{x:1347,y:685,t:1527876703533};\\\", \\\"{x:1347,y:686,t:1527876703621};\\\", \\\"{x:1347,y:691,t:1527876703633};\\\", \\\"{x:1347,y:699,t:1527876703651};\\\", \\\"{x:1347,y:708,t:1527876703668};\\\", \\\"{x:1347,y:716,t:1527876703684};\\\", \\\"{x:1347,y:724,t:1527876703700};\\\", \\\"{x:1347,y:729,t:1527876703718};\\\", \\\"{x:1347,y:732,t:1527876703733};\\\", \\\"{x:1348,y:735,t:1527876703751};\\\", \\\"{x:1348,y:738,t:1527876703767};\\\", \\\"{x:1350,y:740,t:1527876703783};\\\", \\\"{x:1350,y:743,t:1527876703801};\\\", \\\"{x:1350,y:745,t:1527876703817};\\\", \\\"{x:1351,y:747,t:1527876703833};\\\", \\\"{x:1351,y:748,t:1527876703850};\\\", \\\"{x:1351,y:749,t:1527876703877};\\\", \\\"{x:1351,y:750,t:1527876703892};\\\", \\\"{x:1352,y:750,t:1527876703900};\\\", \\\"{x:1352,y:751,t:1527876703917};\\\", \\\"{x:1352,y:752,t:1527876703941};\\\", \\\"{x:1352,y:753,t:1527876703965};\\\", \\\"{x:1352,y:754,t:1527876703981};\\\", \\\"{x:1352,y:755,t:1527876704005};\\\", \\\"{x:1352,y:756,t:1527876704021};\\\", \\\"{x:1352,y:757,t:1527876704034};\\\", \\\"{x:1352,y:758,t:1527876704061};\\\", \\\"{x:1352,y:759,t:1527876704085};\\\", \\\"{x:1352,y:760,t:1527876704099};\\\", \\\"{x:1352,y:761,t:1527876704124};\\\", \\\"{x:1352,y:762,t:1527876704133};\\\", \\\"{x:1351,y:762,t:1527876704646};\\\", \\\"{x:1350,y:762,t:1527876704694};\\\", \\\"{x:1349,y:763,t:1527876704742};\\\", \\\"{x:1348,y:763,t:1527876704765};\\\", \\\"{x:1347,y:763,t:1527876704822};\\\", \\\"{x:1347,y:764,t:1527876711294};\\\", \\\"{x:1344,y:767,t:1527876711306};\\\", \\\"{x:1342,y:769,t:1527876711324};\\\", \\\"{x:1339,y:775,t:1527876711340};\\\", \\\"{x:1336,y:783,t:1527876711356};\\\", \\\"{x:1332,y:793,t:1527876711373};\\\", \\\"{x:1329,y:804,t:1527876711390};\\\", \\\"{x:1325,y:813,t:1527876711406};\\\", \\\"{x:1321,y:828,t:1527876711423};\\\", \\\"{x:1320,y:846,t:1527876711439};\\\", \\\"{x:1316,y:868,t:1527876711456};\\\", \\\"{x:1309,y:890,t:1527876711472};\\\", \\\"{x:1302,y:913,t:1527876711489};\\\", \\\"{x:1293,y:933,t:1527876711505};\\\", \\\"{x:1289,y:941,t:1527876711523};\\\", \\\"{x:1285,y:945,t:1527876711539};\\\", \\\"{x:1284,y:947,t:1527876711556};\\\", \\\"{x:1281,y:948,t:1527876711573};\\\", \\\"{x:1274,y:948,t:1527876711590};\\\", \\\"{x:1270,y:948,t:1527876711606};\\\", \\\"{x:1255,y:951,t:1527876711622};\\\", \\\"{x:1227,y:955,t:1527876711640};\\\", \\\"{x:1214,y:955,t:1527876711657};\\\", \\\"{x:1209,y:955,t:1527876711672};\\\", \\\"{x:1206,y:955,t:1527876711690};\\\", \\\"{x:1203,y:955,t:1527876711707};\\\", \\\"{x:1203,y:954,t:1527876711723};\\\", \\\"{x:1203,y:950,t:1527876711740};\\\", \\\"{x:1203,y:941,t:1527876711757};\\\", \\\"{x:1203,y:928,t:1527876711773};\\\", \\\"{x:1204,y:915,t:1527876711790};\\\", \\\"{x:1213,y:899,t:1527876711807};\\\", \\\"{x:1221,y:885,t:1527876711822};\\\", \\\"{x:1224,y:877,t:1527876711840};\\\", \\\"{x:1224,y:869,t:1527876711856};\\\", \\\"{x:1225,y:861,t:1527876711872};\\\", \\\"{x:1225,y:859,t:1527876711889};\\\", \\\"{x:1225,y:858,t:1527876711907};\\\", \\\"{x:1225,y:857,t:1527876712022};\\\", \\\"{x:1225,y:853,t:1527876712029};\\\", \\\"{x:1223,y:847,t:1527876712040};\\\", \\\"{x:1219,y:842,t:1527876712057};\\\", \\\"{x:1219,y:840,t:1527876712074};\\\", \\\"{x:1216,y:836,t:1527876712089};\\\", \\\"{x:1215,y:833,t:1527876712106};\\\", \\\"{x:1214,y:833,t:1527876712123};\\\", \\\"{x:1214,y:830,t:1527876712139};\\\", \\\"{x:1213,y:829,t:1527876712229};\\\", \\\"{x:1213,y:828,t:1527876712302};\\\", \\\"{x:1213,y:822,t:1527876712310};\\\", \\\"{x:1206,y:815,t:1527876712324};\\\", \\\"{x:1193,y:797,t:1527876712340};\\\", \\\"{x:1177,y:778,t:1527876712357};\\\", \\\"{x:1157,y:760,t:1527876712374};\\\", \\\"{x:1152,y:755,t:1527876712390};\\\", \\\"{x:1152,y:754,t:1527876712558};\\\", \\\"{x:1182,y:762,t:1527876712574};\\\", \\\"{x:1215,y:771,t:1527876712592};\\\", \\\"{x:1253,y:776,t:1527876712607};\\\", \\\"{x:1280,y:779,t:1527876712624};\\\", \\\"{x:1293,y:785,t:1527876712641};\\\", \\\"{x:1297,y:785,t:1527876712657};\\\", \\\"{x:1298,y:786,t:1527876712674};\\\", \\\"{x:1301,y:786,t:1527876712710};\\\", \\\"{x:1310,y:780,t:1527876712724};\\\", \\\"{x:1323,y:763,t:1527876712741};\\\", \\\"{x:1337,y:749,t:1527876712757};\\\", \\\"{x:1359,y:718,t:1527876712773};\\\", \\\"{x:1368,y:699,t:1527876712791};\\\", \\\"{x:1372,y:689,t:1527876712806};\\\", \\\"{x:1372,y:687,t:1527876712824};\\\", \\\"{x:1372,y:686,t:1527876712841};\\\", \\\"{x:1372,y:685,t:1527876712861};\\\", \\\"{x:1371,y:687,t:1527876713078};\\\", \\\"{x:1362,y:692,t:1527876713091};\\\", \\\"{x:1354,y:699,t:1527876713108};\\\", \\\"{x:1345,y:705,t:1527876713124};\\\", \\\"{x:1341,y:710,t:1527876713141};\\\", \\\"{x:1338,y:712,t:1527876713158};\\\", \\\"{x:1339,y:712,t:1527876713286};\\\", \\\"{x:1347,y:705,t:1527876713294};\\\", \\\"{x:1350,y:701,t:1527876713308};\\\", \\\"{x:1354,y:697,t:1527876713324};\\\", \\\"{x:1355,y:696,t:1527876713341};\\\", \\\"{x:1354,y:696,t:1527876713629};\\\", \\\"{x:1352,y:696,t:1527876713641};\\\", \\\"{x:1350,y:696,t:1527876713658};\\\", \\\"{x:1348,y:696,t:1527876713675};\\\", \\\"{x:1347,y:689,t:1527876718439};\\\", \\\"{x:1347,y:677,t:1527876718446};\\\", \\\"{x:1349,y:665,t:1527876718461};\\\", \\\"{x:1358,y:632,t:1527876718477};\\\", \\\"{x:1366,y:607,t:1527876718495};\\\", \\\"{x:1373,y:582,t:1527876718511};\\\", \\\"{x:1377,y:571,t:1527876718528};\\\", \\\"{x:1378,y:568,t:1527876718545};\\\", \\\"{x:1379,y:563,t:1527876718561};\\\", \\\"{x:1380,y:560,t:1527876718578};\\\", \\\"{x:1381,y:560,t:1527876718595};\\\", \\\"{x:1384,y:560,t:1527876718654};\\\", \\\"{x:1389,y:560,t:1527876718662};\\\", \\\"{x:1398,y:563,t:1527876718678};\\\", \\\"{x:1403,y:563,t:1527876718695};\\\", \\\"{x:1405,y:564,t:1527876718711};\\\", \\\"{x:1406,y:565,t:1527876718728};\\\", \\\"{x:1408,y:566,t:1527876718745};\\\", \\\"{x:1410,y:567,t:1527876718762};\\\", \\\"{x:1413,y:567,t:1527876718797};\\\", \\\"{x:1414,y:567,t:1527876718814};\\\", \\\"{x:1416,y:567,t:1527876718828};\\\", \\\"{x:1418,y:566,t:1527876718845};\\\", \\\"{x:1422,y:565,t:1527876718862};\\\", \\\"{x:1424,y:565,t:1527876718878};\\\", \\\"{x:1426,y:563,t:1527876718895};\\\", \\\"{x:1427,y:563,t:1527876718965};\\\", \\\"{x:1425,y:563,t:1527876719438};\\\", \\\"{x:1424,y:563,t:1527876719446};\\\", \\\"{x:1423,y:563,t:1527876719462};\\\", \\\"{x:1422,y:563,t:1527876719485};\\\", \\\"{x:1421,y:564,t:1527876719502};\\\", \\\"{x:1418,y:566,t:1527876719513};\\\", \\\"{x:1417,y:566,t:1527876720229};\\\", \\\"{x:1402,y:574,t:1527876724422};\\\", \\\"{x:1367,y:589,t:1527876724432};\\\", \\\"{x:1261,y:623,t:1527876724449};\\\", \\\"{x:1142,y:663,t:1527876724465};\\\", \\\"{x:1039,y:710,t:1527876724482};\\\", \\\"{x:944,y:744,t:1527876724500};\\\", \\\"{x:852,y:771,t:1527876724515};\\\", \\\"{x:753,y:783,t:1527876724532};\\\", \\\"{x:653,y:792,t:1527876724549};\\\", \\\"{x:614,y:792,t:1527876724565};\\\", \\\"{x:589,y:790,t:1527876724582};\\\", \\\"{x:565,y:782,t:1527876724599};\\\", \\\"{x:546,y:766,t:1527876724615};\\\", \\\"{x:532,y:744,t:1527876724633};\\\", \\\"{x:525,y:722,t:1527876724649};\\\", \\\"{x:518,y:705,t:1527876724666};\\\", \\\"{x:504,y:678,t:1527876724685};\\\", \\\"{x:491,y:661,t:1527876724702};\\\", \\\"{x:488,y:654,t:1527876724718};\\\", \\\"{x:487,y:650,t:1527876724736};\\\", \\\"{x:487,y:647,t:1527876724752};\\\", \\\"{x:490,y:641,t:1527876724769};\\\", \\\"{x:491,y:636,t:1527876724786};\\\", \\\"{x:491,y:634,t:1527876724803};\\\", \\\"{x:491,y:633,t:1527876724819};\\\", \\\"{x:491,y:632,t:1527876724836};\\\", \\\"{x:489,y:632,t:1527876724852};\\\", \\\"{x:472,y:634,t:1527876724868};\\\", \\\"{x:454,y:636,t:1527876724885};\\\", \\\"{x:429,y:636,t:1527876724902};\\\", \\\"{x:400,y:636,t:1527876724919};\\\", \\\"{x:373,y:636,t:1527876724936};\\\", \\\"{x:351,y:636,t:1527876724952};\\\", \\\"{x:328,y:636,t:1527876724969};\\\", \\\"{x:305,y:635,t:1527876724985};\\\", \\\"{x:281,y:629,t:1527876725003};\\\", \\\"{x:260,y:624,t:1527876725020};\\\", \\\"{x:239,y:617,t:1527876725036};\\\", \\\"{x:220,y:608,t:1527876725052};\\\", \\\"{x:208,y:604,t:1527876725068};\\\", \\\"{x:194,y:602,t:1527876725085};\\\", \\\"{x:188,y:602,t:1527876725102};\\\", \\\"{x:185,y:602,t:1527876725118};\\\", \\\"{x:182,y:602,t:1527876725136};\\\", \\\"{x:181,y:602,t:1527876725189};\\\", \\\"{x:180,y:603,t:1527876725202};\\\", \\\"{x:177,y:605,t:1527876725220};\\\", \\\"{x:174,y:607,t:1527876725236};\\\", \\\"{x:172,y:608,t:1527876725252};\\\", \\\"{x:172,y:610,t:1527876725285};\\\", \\\"{x:183,y:617,t:1527876725302};\\\", \\\"{x:192,y:622,t:1527876725320};\\\", \\\"{x:209,y:629,t:1527876725336};\\\", \\\"{x:233,y:638,t:1527876725354};\\\", \\\"{x:282,y:647,t:1527876725369};\\\", \\\"{x:334,y:652,t:1527876725385};\\\", \\\"{x:390,y:652,t:1527876725402};\\\", \\\"{x:449,y:651,t:1527876725418};\\\", \\\"{x:500,y:644,t:1527876725436};\\\", \\\"{x:551,y:636,t:1527876725452};\\\", \\\"{x:583,y:632,t:1527876725469};\\\", \\\"{x:615,y:625,t:1527876725486};\\\", \\\"{x:650,y:619,t:1527876725503};\\\", \\\"{x:686,y:610,t:1527876725519};\\\", \\\"{x:728,y:596,t:1527876725536};\\\", \\\"{x:764,y:587,t:1527876725553};\\\", \\\"{x:797,y:577,t:1527876725570};\\\", \\\"{x:825,y:570,t:1527876725585};\\\", \\\"{x:839,y:565,t:1527876725602};\\\", \\\"{x:845,y:564,t:1527876725620};\\\", \\\"{x:846,y:564,t:1527876725636};\\\", \\\"{x:847,y:563,t:1527876725653};\\\", \\\"{x:849,y:563,t:1527876725670};\\\", \\\"{x:851,y:561,t:1527876725687};\\\", \\\"{x:852,y:561,t:1527876725874};\\\", \\\"{x:852,y:559,t:1527876725897};\\\", \\\"{x:852,y:558,t:1527876725907};\\\", \\\"{x:852,y:556,t:1527876725924};\\\", \\\"{x:852,y:554,t:1527876725941};\\\", \\\"{x:852,y:552,t:1527876725957};\\\", \\\"{x:851,y:549,t:1527876725974};\\\", \\\"{x:850,y:549,t:1527876726000};\\\", \\\"{x:848,y:547,t:1527876726121};\\\", \\\"{x:848,y:546,t:1527876726128};\\\", \\\"{x:845,y:545,t:1527876726140};\\\", \\\"{x:844,y:545,t:1527876726157};\\\", \\\"{x:842,y:545,t:1527876726174};\\\", \\\"{x:841,y:543,t:1527876726190};\\\", \\\"{x:839,y:543,t:1527876726207};\\\", \\\"{x:838,y:543,t:1527876726416};\\\", \\\"{x:832,y:547,t:1527876726424};\\\", \\\"{x:813,y:577,t:1527876726441};\\\", \\\"{x:764,y:628,t:1527876726458};\\\", \\\"{x:701,y:682,t:1527876726474};\\\", \\\"{x:637,y:726,t:1527876726491};\\\", \\\"{x:601,y:747,t:1527876726508};\\\", \\\"{x:589,y:754,t:1527876726524};\\\", \\\"{x:585,y:756,t:1527876726541};\\\", \\\"{x:583,y:757,t:1527876726557};\\\", \\\"{x:582,y:758,t:1527876726573};\\\", \\\"{x:579,y:759,t:1527876726591};\\\", \\\"{x:578,y:760,t:1527876726608};\\\", \\\"{x:576,y:760,t:1527876726624};\\\", \\\"{x:574,y:760,t:1527876726673};\\\", \\\"{x:571,y:758,t:1527876726681};\\\", \\\"{x:567,y:750,t:1527876726691};\\\", \\\"{x:558,y:734,t:1527876726708};\\\", \\\"{x:551,y:722,t:1527876726723};\\\", \\\"{x:548,y:717,t:1527876726741};\\\", \\\"{x:547,y:714,t:1527876726757};\\\", \\\"{x:546,y:714,t:1527876726842};\\\", \\\"{x:544,y:714,t:1527876726858};\\\", \\\"{x:541,y:714,t:1527876726875};\\\", \\\"{x:536,y:718,t:1527876726891};\\\", \\\"{x:532,y:723,t:1527876726909};\\\", \\\"{x:530,y:726,t:1527876726924};\\\" ] }, { \\\"rt\\\": 29390, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 331391, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"DJRH1\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -J -I -J -J -11 AM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:529,y:726,t:1527876728985};\\\", \\\"{x:529,y:716,t:1527876730459};\\\", \\\"{x:529,y:673,t:1527876730477};\\\", \\\"{x:529,y:640,t:1527876730493};\\\", \\\"{x:529,y:612,t:1527876730511};\\\", \\\"{x:528,y:599,t:1527876730528};\\\", \\\"{x:525,y:589,t:1527876730544};\\\", \\\"{x:519,y:575,t:1527876730560};\\\", \\\"{x:516,y:570,t:1527876730576};\\\", \\\"{x:515,y:569,t:1527876730593};\\\", \\\"{x:511,y:566,t:1527876730610};\\\", \\\"{x:506,y:564,t:1527876730627};\\\", \\\"{x:502,y:562,t:1527876730645};\\\", \\\"{x:498,y:562,t:1527876730661};\\\", \\\"{x:496,y:560,t:1527876730678};\\\", \\\"{x:494,y:560,t:1527876731154};\\\", \\\"{x:493,y:560,t:1527876731169};\\\", \\\"{x:492,y:560,t:1527876731193};\\\", \\\"{x:488,y:556,t:1527876731201};\\\", \\\"{x:483,y:551,t:1527876731215};\\\", \\\"{x:474,y:538,t:1527876731229};\\\", \\\"{x:463,y:520,t:1527876731244};\\\", \\\"{x:453,y:500,t:1527876731261};\\\", \\\"{x:442,y:479,t:1527876731278};\\\", \\\"{x:432,y:457,t:1527876731295};\\\", \\\"{x:428,y:447,t:1527876731311};\\\", \\\"{x:421,y:430,t:1527876731328};\\\", \\\"{x:414,y:419,t:1527876731345};\\\", \\\"{x:412,y:417,t:1527876731362};\\\", \\\"{x:411,y:414,t:1527876731377};\\\", \\\"{x:407,y:414,t:1527876731395};\\\", \\\"{x:391,y:422,t:1527876731411};\\\", \\\"{x:366,y:437,t:1527876731428};\\\", \\\"{x:338,y:452,t:1527876731445};\\\", \\\"{x:315,y:466,t:1527876731462};\\\", \\\"{x:304,y:472,t:1527876731479};\\\", \\\"{x:303,y:473,t:1527876731495};\\\", \\\"{x:306,y:473,t:1527876731561};\\\", \\\"{x:308,y:471,t:1527876731579};\\\", \\\"{x:314,y:468,t:1527876731595};\\\", \\\"{x:324,y:464,t:1527876731612};\\\", \\\"{x:336,y:458,t:1527876731629};\\\", \\\"{x:342,y:457,t:1527876731646};\\\", \\\"{x:347,y:454,t:1527876731663};\\\", \\\"{x:351,y:454,t:1527876731679};\\\", \\\"{x:353,y:454,t:1527876731696};\\\", \\\"{x:354,y:454,t:1527876731721};\\\", \\\"{x:356,y:454,t:1527876731761};\\\", \\\"{x:357,y:454,t:1527876731769};\\\", \\\"{x:360,y:454,t:1527876731779};\\\", \\\"{x:365,y:456,t:1527876731796};\\\", \\\"{x:371,y:456,t:1527876731813};\\\", \\\"{x:375,y:456,t:1527876731829};\\\", \\\"{x:378,y:456,t:1527876731846};\\\", \\\"{x:381,y:456,t:1527876731864};\\\", \\\"{x:392,y:456,t:1527876731879};\\\", \\\"{x:409,y:456,t:1527876731897};\\\", \\\"{x:429,y:456,t:1527876731913};\\\", \\\"{x:436,y:458,t:1527876731930};\\\", \\\"{x:438,y:458,t:1527876732409};\\\", \\\"{x:440,y:458,t:1527876732417};\\\", \\\"{x:443,y:458,t:1527876732431};\\\", \\\"{x:445,y:458,t:1527876732449};\\\", \\\"{x:446,y:458,t:1527876732592};\\\", \\\"{x:448,y:458,t:1527876732641};\\\", \\\"{x:452,y:462,t:1527876733122};\\\", \\\"{x:457,y:470,t:1527876733133};\\\", \\\"{x:471,y:486,t:1527876733148};\\\", \\\"{x:491,y:505,t:1527876733166};\\\", \\\"{x:516,y:527,t:1527876733183};\\\", \\\"{x:534,y:539,t:1527876733196};\\\", \\\"{x:539,y:544,t:1527876733213};\\\", \\\"{x:541,y:544,t:1527876733229};\\\", \\\"{x:542,y:545,t:1527876733353};\\\", \\\"{x:544,y:547,t:1527876733363};\\\", \\\"{x:558,y:556,t:1527876733381};\\\", \\\"{x:602,y:579,t:1527876733397};\\\", \\\"{x:663,y:607,t:1527876733414};\\\", \\\"{x:748,y:642,t:1527876733431};\\\", \\\"{x:830,y:676,t:1527876733446};\\\", \\\"{x:936,y:711,t:1527876733463};\\\", \\\"{x:1044,y:741,t:1527876733481};\\\", \\\"{x:1188,y:781,t:1527876733496};\\\", \\\"{x:1241,y:797,t:1527876733513};\\\", \\\"{x:1266,y:804,t:1527876733530};\\\", \\\"{x:1273,y:805,t:1527876733546};\\\", \\\"{x:1273,y:808,t:1527876733722};\\\", \\\"{x:1263,y:811,t:1527876733729};\\\", \\\"{x:1247,y:817,t:1527876733747};\\\", \\\"{x:1236,y:822,t:1527876733763};\\\", \\\"{x:1222,y:827,t:1527876733780};\\\", \\\"{x:1205,y:832,t:1527876733796};\\\", \\\"{x:1197,y:834,t:1527876733813};\\\", \\\"{x:1195,y:834,t:1527876733829};\\\", \\\"{x:1197,y:834,t:1527876733961};\\\", \\\"{x:1202,y:834,t:1527876733969};\\\", \\\"{x:1206,y:833,t:1527876733979};\\\", \\\"{x:1215,y:831,t:1527876733999};\\\", \\\"{x:1221,y:829,t:1527876734013};\\\", \\\"{x:1223,y:828,t:1527876734029};\\\", \\\"{x:1224,y:828,t:1527876734046};\\\", \\\"{x:1223,y:828,t:1527876734169};\\\", \\\"{x:1221,y:828,t:1527876734179};\\\", \\\"{x:1216,y:829,t:1527876734197};\\\", \\\"{x:1213,y:830,t:1527876734212};\\\", \\\"{x:1212,y:830,t:1527876734257};\\\", \\\"{x:1208,y:826,t:1527876738219};\\\", \\\"{x:1207,y:822,t:1527876738226};\\\", \\\"{x:1203,y:813,t:1527876738242};\\\", \\\"{x:1198,y:802,t:1527876738260};\\\", \\\"{x:1189,y:789,t:1527876738276};\\\", \\\"{x:1181,y:776,t:1527876738296};\\\", \\\"{x:1175,y:768,t:1527876738309};\\\", \\\"{x:1171,y:763,t:1527876738325};\\\", \\\"{x:1168,y:759,t:1527876738343};\\\", \\\"{x:1167,y:757,t:1527876738359};\\\", \\\"{x:1168,y:758,t:1527876742986};\\\", \\\"{x:1170,y:759,t:1527876742993};\\\", \\\"{x:1171,y:759,t:1527876743017};\\\", \\\"{x:1172,y:760,t:1527876743025};\\\", \\\"{x:1173,y:760,t:1527876743049};\\\", \\\"{x:1174,y:761,t:1527876743577};\\\", \\\"{x:1175,y:762,t:1527876743593};\\\", \\\"{x:1176,y:762,t:1527876743634};\\\", \\\"{x:1177,y:764,t:1527876750386};\\\", \\\"{x:1180,y:765,t:1527876752233};\\\", \\\"{x:1191,y:781,t:1527876752250};\\\", \\\"{x:1198,y:795,t:1527876752265};\\\", \\\"{x:1205,y:807,t:1527876752281};\\\", \\\"{x:1210,y:816,t:1527876752299};\\\", \\\"{x:1212,y:820,t:1527876752314};\\\", \\\"{x:1215,y:826,t:1527876752331};\\\", \\\"{x:1220,y:834,t:1527876752348};\\\", \\\"{x:1228,y:848,t:1527876752363};\\\", \\\"{x:1241,y:864,t:1527876752380};\\\", \\\"{x:1257,y:885,t:1527876752397};\\\", \\\"{x:1273,y:904,t:1527876752414};\\\", \\\"{x:1280,y:912,t:1527876752431};\\\", \\\"{x:1290,y:925,t:1527876752448};\\\", \\\"{x:1294,y:931,t:1527876752464};\\\", \\\"{x:1297,y:934,t:1527876752481};\\\", \\\"{x:1299,y:936,t:1527876752497};\\\", \\\"{x:1300,y:936,t:1527876752544};\\\", \\\"{x:1301,y:938,t:1527876752560};\\\", \\\"{x:1301,y:939,t:1527876752705};\\\", \\\"{x:1300,y:940,t:1527876752729};\\\", \\\"{x:1297,y:941,t:1527876752761};\\\", \\\"{x:1296,y:943,t:1527876752769};\\\", \\\"{x:1295,y:944,t:1527876752785};\\\", \\\"{x:1293,y:945,t:1527876752798};\\\", \\\"{x:1292,y:946,t:1527876752816};\\\", \\\"{x:1288,y:949,t:1527876752831};\\\", \\\"{x:1286,y:950,t:1527876752850};\\\", \\\"{x:1285,y:951,t:1527876752864};\\\", \\\"{x:1283,y:951,t:1527876752880};\\\", \\\"{x:1281,y:952,t:1527876752898};\\\", \\\"{x:1280,y:952,t:1527876752929};\\\", \\\"{x:1279,y:953,t:1527876752948};\\\", \\\"{x:1278,y:953,t:1527876752969};\\\", \\\"{x:1277,y:953,t:1527876753018};\\\", \\\"{x:1276,y:953,t:1527876753041};\\\", \\\"{x:1276,y:954,t:1527876753057};\\\", \\\"{x:1275,y:954,t:1527876753073};\\\", \\\"{x:1274,y:955,t:1527876753097};\\\", \\\"{x:1273,y:956,t:1527876753161};\\\", \\\"{x:1272,y:956,t:1527876753169};\\\", \\\"{x:1272,y:957,t:1527876753193};\\\", \\\"{x:1271,y:957,t:1527876753209};\\\", \\\"{x:1270,y:957,t:1527876753257};\\\", \\\"{x:1270,y:958,t:1527876753570};\\\", \\\"{x:1271,y:959,t:1527876753580};\\\", \\\"{x:1271,y:961,t:1527876753598};\\\", \\\"{x:1273,y:964,t:1527876753614};\\\", \\\"{x:1273,y:965,t:1527876753631};\\\", \\\"{x:1274,y:967,t:1527876753646};\\\", \\\"{x:1275,y:968,t:1527876753663};\\\", \\\"{x:1276,y:968,t:1527876753697};\\\", \\\"{x:1276,y:969,t:1527876753729};\\\", \\\"{x:1277,y:969,t:1527876753761};\\\", \\\"{x:1278,y:969,t:1527876753769};\\\", \\\"{x:1280,y:970,t:1527876753780};\\\", \\\"{x:1281,y:970,t:1527876753796};\\\", \\\"{x:1283,y:970,t:1527876753814};\\\", \\\"{x:1286,y:970,t:1527876753830};\\\", \\\"{x:1288,y:970,t:1527876753846};\\\", \\\"{x:1289,y:970,t:1527876753864};\\\", \\\"{x:1290,y:970,t:1527876753920};\\\", \\\"{x:1290,y:969,t:1527876754521};\\\", \\\"{x:1291,y:968,t:1527876754562};\\\", \\\"{x:1291,y:967,t:1527876754585};\\\", \\\"{x:1291,y:966,t:1527876754609};\\\", \\\"{x:1291,y:965,t:1527876754617};\\\", \\\"{x:1290,y:964,t:1527876754641};\\\", \\\"{x:1290,y:963,t:1527876754665};\\\", \\\"{x:1290,y:962,t:1527876754680};\\\", \\\"{x:1289,y:962,t:1527876754777};\\\", \\\"{x:1288,y:962,t:1527876754785};\\\", \\\"{x:1286,y:962,t:1527876754796};\\\", \\\"{x:1282,y:962,t:1527876754813};\\\", \\\"{x:1275,y:961,t:1527876754830};\\\", \\\"{x:1263,y:958,t:1527876754845};\\\", \\\"{x:1242,y:951,t:1527876754863};\\\", \\\"{x:1210,y:940,t:1527876754879};\\\", \\\"{x:1132,y:919,t:1527876754896};\\\", \\\"{x:1026,y:878,t:1527876754912};\\\", \\\"{x:885,y:810,t:1527876754929};\\\", \\\"{x:806,y:768,t:1527876754945};\\\", \\\"{x:744,y:732,t:1527876754962};\\\", \\\"{x:698,y:708,t:1527876754979};\\\", \\\"{x:672,y:696,t:1527876754995};\\\", \\\"{x:662,y:691,t:1527876755012};\\\", \\\"{x:659,y:689,t:1527876755030};\\\", \\\"{x:658,y:689,t:1527876755045};\\\", \\\"{x:657,y:689,t:1527876755062};\\\", \\\"{x:656,y:689,t:1527876755145};\\\", \\\"{x:646,y:683,t:1527876755162};\\\", \\\"{x:615,y:666,t:1527876755178};\\\", \\\"{x:574,y:642,t:1527876755195};\\\", \\\"{x:529,y:619,t:1527876755214};\\\", \\\"{x:482,y:600,t:1527876755229};\\\", \\\"{x:444,y:576,t:1527876755245};\\\", \\\"{x:395,y:554,t:1527876755265};\\\", \\\"{x:362,y:541,t:1527876755281};\\\", \\\"{x:341,y:536,t:1527876755296};\\\", \\\"{x:329,y:535,t:1527876755314};\\\", \\\"{x:324,y:535,t:1527876755330};\\\", \\\"{x:322,y:535,t:1527876755347};\\\", \\\"{x:318,y:536,t:1527876755364};\\\", \\\"{x:309,y:540,t:1527876755380};\\\", \\\"{x:296,y:545,t:1527876755397};\\\", \\\"{x:279,y:550,t:1527876755414};\\\", \\\"{x:267,y:552,t:1527876755431};\\\", \\\"{x:258,y:554,t:1527876755447};\\\", \\\"{x:248,y:554,t:1527876755464};\\\", \\\"{x:239,y:554,t:1527876755481};\\\", \\\"{x:232,y:554,t:1527876755497};\\\", \\\"{x:220,y:550,t:1527876755513};\\\", \\\"{x:207,y:545,t:1527876755531};\\\", \\\"{x:195,y:539,t:1527876755549};\\\", \\\"{x:185,y:533,t:1527876755565};\\\", \\\"{x:178,y:528,t:1527876755581};\\\", \\\"{x:169,y:522,t:1527876755598};\\\", \\\"{x:162,y:519,t:1527876755614};\\\", \\\"{x:158,y:517,t:1527876755632};\\\", \\\"{x:156,y:516,t:1527876755648};\\\", \\\"{x:154,y:514,t:1527876755752};\\\", \\\"{x:153,y:513,t:1527876755765};\\\", \\\"{x:151,y:510,t:1527876755781};\\\", \\\"{x:151,y:508,t:1527876755797};\\\", \\\"{x:155,y:512,t:1527876755986};\\\", \\\"{x:166,y:524,t:1527876755997};\\\", \\\"{x:191,y:552,t:1527876756016};\\\", \\\"{x:215,y:576,t:1527876756032};\\\", \\\"{x:260,y:611,t:1527876756048};\\\", \\\"{x:285,y:629,t:1527876756066};\\\", \\\"{x:304,y:640,t:1527876756082};\\\", \\\"{x:319,y:648,t:1527876756098};\\\", \\\"{x:330,y:654,t:1527876756115};\\\", \\\"{x:339,y:660,t:1527876756131};\\\", \\\"{x:348,y:664,t:1527876756148};\\\", \\\"{x:352,y:668,t:1527876756164};\\\", \\\"{x:355,y:671,t:1527876756182};\\\", \\\"{x:361,y:675,t:1527876756198};\\\", \\\"{x:367,y:681,t:1527876756215};\\\", \\\"{x:381,y:694,t:1527876756232};\\\", \\\"{x:406,y:713,t:1527876756248};\\\", \\\"{x:418,y:720,t:1527876756265};\\\", \\\"{x:423,y:722,t:1527876756281};\\\", \\\"{x:424,y:722,t:1527876756304};\\\", \\\"{x:420,y:719,t:1527876756315};\\\", \\\"{x:404,y:698,t:1527876756331};\\\", \\\"{x:370,y:650,t:1527876756348};\\\", \\\"{x:302,y:584,t:1527876756366};\\\", \\\"{x:235,y:538,t:1527876756383};\\\", \\\"{x:181,y:507,t:1527876756399};\\\", \\\"{x:134,y:487,t:1527876756415};\\\", \\\"{x:105,y:477,t:1527876756433};\\\", \\\"{x:104,y:477,t:1527876756448};\\\", \\\"{x:103,y:477,t:1527876756560};\\\", \\\"{x:103,y:480,t:1527876756568};\\\", \\\"{x:103,y:485,t:1527876756581};\\\", \\\"{x:109,y:495,t:1527876756599};\\\", \\\"{x:113,y:500,t:1527876756615};\\\", \\\"{x:119,y:505,t:1527876756632};\\\", \\\"{x:122,y:506,t:1527876756649};\\\", \\\"{x:124,y:507,t:1527876756665};\\\", \\\"{x:127,y:507,t:1527876756682};\\\", \\\"{x:131,y:509,t:1527876756698};\\\", \\\"{x:139,y:510,t:1527876756715};\\\", \\\"{x:149,y:511,t:1527876756732};\\\", \\\"{x:156,y:513,t:1527876756749};\\\", \\\"{x:158,y:513,t:1527876756765};\\\", \\\"{x:159,y:513,t:1527876756808};\\\", \\\"{x:162,y:513,t:1527876756816};\\\", \\\"{x:167,y:509,t:1527876756832};\\\", \\\"{x:170,y:506,t:1527876756849};\\\", \\\"{x:171,y:510,t:1527876757112};\\\", \\\"{x:175,y:515,t:1527876757121};\\\", \\\"{x:179,y:520,t:1527876757132};\\\", \\\"{x:189,y:532,t:1527876757149};\\\", \\\"{x:191,y:535,t:1527876757165};\\\", \\\"{x:193,y:537,t:1527876757182};\\\", \\\"{x:197,y:542,t:1527876757199};\\\", \\\"{x:214,y:557,t:1527876757217};\\\", \\\"{x:246,y:576,t:1527876757232};\\\", \\\"{x:300,y:605,t:1527876757250};\\\", \\\"{x:364,y:635,t:1527876757266};\\\", \\\"{x:414,y:658,t:1527876757282};\\\", \\\"{x:459,y:679,t:1527876757299};\\\", \\\"{x:489,y:697,t:1527876757316};\\\", \\\"{x:509,y:712,t:1527876757332};\\\", \\\"{x:524,y:724,t:1527876757349};\\\", \\\"{x:530,y:730,t:1527876757366};\\\", \\\"{x:536,y:740,t:1527876757382};\\\", \\\"{x:540,y:745,t:1527876757399};\\\", \\\"{x:544,y:749,t:1527876757416};\\\", \\\"{x:545,y:750,t:1527876757441};\\\", \\\"{x:546,y:751,t:1527876757450};\\\", \\\"{x:547,y:754,t:1527876757466};\\\", \\\"{x:554,y:760,t:1527876757484};\\\", \\\"{x:556,y:767,t:1527876757499};\\\", \\\"{x:559,y:769,t:1527876757516};\\\", \\\"{x:558,y:770,t:1527876757569};\\\", \\\"{x:557,y:769,t:1527876757583};\\\", \\\"{x:550,y:766,t:1527876757599};\\\", \\\"{x:544,y:751,t:1527876757618};\\\", \\\"{x:538,y:742,t:1527876757633};\\\", \\\"{x:533,y:734,t:1527876757649};\\\", \\\"{x:531,y:731,t:1527876757665};\\\", \\\"{x:531,y:729,t:1527876757682};\\\", \\\"{x:530,y:729,t:1527876757712};\\\", \\\"{x:530,y:728,t:1527876758225};\\\", \\\"{x:530,y:726,t:1527876758241};\\\", \\\"{x:530,y:725,t:1527876758250};\\\", \\\"{x:530,y:724,t:1527876758266};\\\", \\\"{x:530,y:721,t:1527876758283};\\\", \\\"{x:530,y:720,t:1527876758300};\\\", \\\"{x:530,y:718,t:1527876758317};\\\", \\\"{x:530,y:717,t:1527876758377};\\\", \\\"{x:530,y:715,t:1527876758384};\\\", \\\"{x:530,y:714,t:1527876758440};\\\", \\\"{x:530,y:713,t:1527876758472};\\\", \\\"{x:530,y:712,t:1527876758482};\\\", \\\"{x:529,y:710,t:1527876758499};\\\", \\\"{x:527,y:710,t:1527876758656};\\\", \\\"{x:526,y:712,t:1527876758672};\\\", \\\"{x:525,y:712,t:1527876758683};\\\", \\\"{x:524,y:714,t:1527876758700};\\\", \\\"{x:524,y:715,t:1527876758717};\\\", \\\"{x:523,y:716,t:1527876758745};\\\", \\\"{x:522,y:716,t:1527876758753};\\\" ] }, { \\\"rt\\\": 14072, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 346700, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"DJRH1\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:522,y:711,t:1527876759115};\\\", \\\"{x:523,y:709,t:1527876759400};\\\", \\\"{x:525,y:705,t:1527876759417};\\\", \\\"{x:526,y:703,t:1527876759434};\\\", \\\"{x:529,y:699,t:1527876759450};\\\", \\\"{x:530,y:695,t:1527876759467};\\\", \\\"{x:531,y:691,t:1527876759540};\\\", \\\"{x:531,y:690,t:1527876759616};\\\", \\\"{x:531,y:687,t:1527876759623};\\\", \\\"{x:531,y:684,t:1527876759634};\\\", \\\"{x:531,y:683,t:1527876759651};\\\", \\\"{x:531,y:679,t:1527876759667};\\\", \\\"{x:531,y:677,t:1527876759684};\\\", \\\"{x:530,y:675,t:1527876759768};\\\", \\\"{x:527,y:669,t:1527876759784};\\\", \\\"{x:523,y:665,t:1527876759801};\\\", \\\"{x:519,y:656,t:1527876759818};\\\", \\\"{x:515,y:646,t:1527876759835};\\\", \\\"{x:510,y:637,t:1527876759851};\\\", \\\"{x:505,y:625,t:1527876759869};\\\", \\\"{x:501,y:613,t:1527876759883};\\\", \\\"{x:496,y:602,t:1527876759902};\\\", \\\"{x:490,y:590,t:1527876759919};\\\", \\\"{x:483,y:581,t:1527876759934};\\\", \\\"{x:476,y:570,t:1527876759951};\\\", \\\"{x:465,y:555,t:1527876759969};\\\", \\\"{x:461,y:550,t:1527876759984};\\\", \\\"{x:453,y:541,t:1527876760001};\\\", \\\"{x:448,y:535,t:1527876760018};\\\", \\\"{x:442,y:528,t:1527876760033};\\\", \\\"{x:437,y:522,t:1527876760051};\\\", \\\"{x:431,y:515,t:1527876760068};\\\", \\\"{x:421,y:505,t:1527876760084};\\\", \\\"{x:411,y:495,t:1527876760101};\\\", \\\"{x:404,y:485,t:1527876760118};\\\", \\\"{x:395,y:474,t:1527876760135};\\\", \\\"{x:385,y:458,t:1527876760151};\\\", \\\"{x:376,y:441,t:1527876760168};\\\", \\\"{x:373,y:436,t:1527876760185};\\\", \\\"{x:374,y:434,t:1527876760513};\\\", \\\"{x:378,y:434,t:1527876760529};\\\", \\\"{x:381,y:434,t:1527876760537};\\\", \\\"{x:384,y:434,t:1527876760551};\\\", \\\"{x:388,y:434,t:1527876760568};\\\", \\\"{x:390,y:434,t:1527876760673};\\\", \\\"{x:392,y:433,t:1527876760686};\\\", \\\"{x:396,y:431,t:1527876760701};\\\", \\\"{x:403,y:428,t:1527876760719};\\\", \\\"{x:406,y:427,t:1527876760736};\\\", \\\"{x:410,y:424,t:1527876760752};\\\", \\\"{x:411,y:424,t:1527876761008};\\\", \\\"{x:418,y:427,t:1527876761018};\\\", \\\"{x:424,y:436,t:1527876761035};\\\", \\\"{x:429,y:443,t:1527876761052};\\\", \\\"{x:434,y:449,t:1527876761068};\\\", \\\"{x:440,y:458,t:1527876761085};\\\", \\\"{x:452,y:478,t:1527876761102};\\\", \\\"{x:477,y:497,t:1527876761119};\\\", \\\"{x:526,y:523,t:1527876761135};\\\", \\\"{x:557,y:544,t:1527876761153};\\\", \\\"{x:562,y:553,t:1527876761761};\\\", \\\"{x:570,y:559,t:1527876761771};\\\", \\\"{x:584,y:570,t:1527876761786};\\\", \\\"{x:599,y:583,t:1527876761803};\\\", \\\"{x:619,y:596,t:1527876761819};\\\", \\\"{x:637,y:610,t:1527876761836};\\\", \\\"{x:656,y:620,t:1527876761853};\\\", \\\"{x:679,y:630,t:1527876761869};\\\", \\\"{x:708,y:643,t:1527876761887};\\\", \\\"{x:737,y:657,t:1527876761902};\\\", \\\"{x:783,y:672,t:1527876761919};\\\", \\\"{x:828,y:690,t:1527876761936};\\\", \\\"{x:851,y:696,t:1527876761953};\\\", \\\"{x:865,y:701,t:1527876761969};\\\", \\\"{x:874,y:702,t:1527876761986};\\\", \\\"{x:888,y:706,t:1527876762004};\\\", \\\"{x:903,y:711,t:1527876762019};\\\", \\\"{x:919,y:717,t:1527876762036};\\\", \\\"{x:938,y:722,t:1527876762052};\\\", \\\"{x:962,y:728,t:1527876762070};\\\", \\\"{x:980,y:733,t:1527876762087};\\\", \\\"{x:1002,y:739,t:1527876762103};\\\", \\\"{x:1026,y:746,t:1527876762119};\\\", \\\"{x:1054,y:754,t:1527876762137};\\\", \\\"{x:1069,y:758,t:1527876762154};\\\", \\\"{x:1079,y:760,t:1527876762169};\\\", \\\"{x:1088,y:764,t:1527876762186};\\\", \\\"{x:1095,y:766,t:1527876762203};\\\", \\\"{x:1105,y:770,t:1527876762219};\\\", \\\"{x:1118,y:773,t:1527876762237};\\\", \\\"{x:1131,y:776,t:1527876762254};\\\", \\\"{x:1146,y:780,t:1527876762270};\\\", \\\"{x:1156,y:784,t:1527876762286};\\\", \\\"{x:1167,y:786,t:1527876762304};\\\", \\\"{x:1179,y:790,t:1527876762320};\\\", \\\"{x:1194,y:794,t:1527876762336};\\\", \\\"{x:1207,y:797,t:1527876762354};\\\", \\\"{x:1225,y:800,t:1527876762369};\\\", \\\"{x:1246,y:804,t:1527876762387};\\\", \\\"{x:1268,y:806,t:1527876762404};\\\", \\\"{x:1284,y:809,t:1527876762420};\\\", \\\"{x:1298,y:810,t:1527876762437};\\\", \\\"{x:1303,y:811,t:1527876762453};\\\", \\\"{x:1311,y:813,t:1527876762471};\\\", \\\"{x:1315,y:814,t:1527876762487};\\\", \\\"{x:1320,y:814,t:1527876762504};\\\", \\\"{x:1328,y:814,t:1527876762520};\\\", \\\"{x:1334,y:815,t:1527876762537};\\\", \\\"{x:1343,y:817,t:1527876762553};\\\", \\\"{x:1356,y:818,t:1527876762571};\\\", \\\"{x:1367,y:820,t:1527876762587};\\\", \\\"{x:1379,y:823,t:1527876762604};\\\", \\\"{x:1390,y:824,t:1527876762621};\\\", \\\"{x:1399,y:825,t:1527876762637};\\\", \\\"{x:1401,y:825,t:1527876762654};\\\", \\\"{x:1404,y:825,t:1527876762720};\\\", \\\"{x:1409,y:825,t:1527876762736};\\\", \\\"{x:1411,y:825,t:1527876762753};\\\", \\\"{x:1414,y:823,t:1527876762770};\\\", \\\"{x:1415,y:823,t:1527876762787};\\\", \\\"{x:1417,y:822,t:1527876762803};\\\", \\\"{x:1421,y:820,t:1527876762820};\\\", \\\"{x:1423,y:819,t:1527876762837};\\\", \\\"{x:1427,y:818,t:1527876762854};\\\", \\\"{x:1430,y:816,t:1527876762870};\\\", \\\"{x:1435,y:814,t:1527876762886};\\\", \\\"{x:1439,y:811,t:1527876762903};\\\", \\\"{x:1448,y:805,t:1527876762921};\\\", \\\"{x:1453,y:801,t:1527876762937};\\\", \\\"{x:1459,y:795,t:1527876762953};\\\", \\\"{x:1471,y:783,t:1527876762971};\\\", \\\"{x:1483,y:769,t:1527876762988};\\\", \\\"{x:1492,y:755,t:1527876763004};\\\", \\\"{x:1501,y:744,t:1527876763020};\\\", \\\"{x:1507,y:737,t:1527876763037};\\\", \\\"{x:1514,y:727,t:1527876763054};\\\", \\\"{x:1520,y:716,t:1527876763071};\\\", \\\"{x:1526,y:709,t:1527876763087};\\\", \\\"{x:1532,y:700,t:1527876763104};\\\", \\\"{x:1539,y:689,t:1527876763121};\\\", \\\"{x:1543,y:681,t:1527876763137};\\\", \\\"{x:1546,y:675,t:1527876763154};\\\", \\\"{x:1547,y:671,t:1527876763171};\\\", \\\"{x:1550,y:667,t:1527876763188};\\\", \\\"{x:1550,y:664,t:1527876763204};\\\", \\\"{x:1551,y:659,t:1527876763221};\\\", \\\"{x:1552,y:655,t:1527876763238};\\\", \\\"{x:1553,y:650,t:1527876763254};\\\", \\\"{x:1553,y:645,t:1527876763271};\\\", \\\"{x:1554,y:641,t:1527876763288};\\\", \\\"{x:1555,y:633,t:1527876763304};\\\", \\\"{x:1556,y:626,t:1527876763321};\\\", \\\"{x:1556,y:620,t:1527876763338};\\\", \\\"{x:1556,y:616,t:1527876763355};\\\", \\\"{x:1557,y:612,t:1527876763371};\\\", \\\"{x:1557,y:611,t:1527876763388};\\\", \\\"{x:1557,y:605,t:1527876763405};\\\", \\\"{x:1557,y:602,t:1527876763421};\\\", \\\"{x:1557,y:597,t:1527876763438};\\\", \\\"{x:1557,y:592,t:1527876763455};\\\", \\\"{x:1557,y:587,t:1527876763471};\\\", \\\"{x:1557,y:585,t:1527876763488};\\\", \\\"{x:1557,y:583,t:1527876763504};\\\", \\\"{x:1557,y:582,t:1527876763521};\\\", \\\"{x:1557,y:580,t:1527876763538};\\\", \\\"{x:1557,y:579,t:1527876763577};\\\", \\\"{x:1557,y:577,t:1527876763588};\\\", \\\"{x:1559,y:573,t:1527876763605};\\\", \\\"{x:1567,y:566,t:1527876763621};\\\", \\\"{x:1579,y:557,t:1527876763638};\\\", \\\"{x:1592,y:547,t:1527876763655};\\\", \\\"{x:1604,y:538,t:1527876763671};\\\", \\\"{x:1621,y:526,t:1527876763688};\\\", \\\"{x:1633,y:518,t:1527876763705};\\\", \\\"{x:1637,y:514,t:1527876763721};\\\", \\\"{x:1640,y:511,t:1527876763738};\\\", \\\"{x:1641,y:509,t:1527876763755};\\\", \\\"{x:1642,y:507,t:1527876763771};\\\", \\\"{x:1642,y:506,t:1527876763826};\\\", \\\"{x:1642,y:503,t:1527876763838};\\\", \\\"{x:1642,y:497,t:1527876763855};\\\", \\\"{x:1641,y:489,t:1527876763871};\\\", \\\"{x:1636,y:480,t:1527876763888};\\\", \\\"{x:1624,y:461,t:1527876763906};\\\", \\\"{x:1614,y:450,t:1527876763921};\\\", \\\"{x:1604,y:442,t:1527876763938};\\\", \\\"{x:1598,y:437,t:1527876763955};\\\", \\\"{x:1590,y:430,t:1527876763972};\\\", \\\"{x:1579,y:418,t:1527876763988};\\\", \\\"{x:1567,y:408,t:1527876764005};\\\", \\\"{x:1557,y:401,t:1527876764022};\\\", \\\"{x:1547,y:393,t:1527876764038};\\\", \\\"{x:1541,y:389,t:1527876764054};\\\", \\\"{x:1532,y:384,t:1527876764072};\\\", \\\"{x:1524,y:380,t:1527876764088};\\\", \\\"{x:1520,y:378,t:1527876764105};\\\", \\\"{x:1519,y:378,t:1527876764169};\\\", \\\"{x:1519,y:377,t:1527876764185};\\\", \\\"{x:1520,y:375,t:1527876764201};\\\", \\\"{x:1521,y:374,t:1527876764209};\\\", \\\"{x:1523,y:373,t:1527876764222};\\\", \\\"{x:1530,y:369,t:1527876764238};\\\", \\\"{x:1536,y:367,t:1527876764255};\\\", \\\"{x:1544,y:362,t:1527876764272};\\\", \\\"{x:1548,y:359,t:1527876764288};\\\", \\\"{x:1551,y:359,t:1527876764305};\\\", \\\"{x:1551,y:358,t:1527876764337};\\\", \\\"{x:1552,y:358,t:1527876764345};\\\", \\\"{x:1553,y:357,t:1527876764425};\\\", \\\"{x:1553,y:356,t:1527876764490};\\\", \\\"{x:1550,y:351,t:1527876764505};\\\", \\\"{x:1536,y:344,t:1527876764522};\\\", \\\"{x:1522,y:340,t:1527876764539};\\\", \\\"{x:1504,y:337,t:1527876764556};\\\", \\\"{x:1478,y:334,t:1527876764572};\\\", \\\"{x:1456,y:334,t:1527876764589};\\\", \\\"{x:1439,y:338,t:1527876764605};\\\", \\\"{x:1422,y:345,t:1527876764622};\\\", \\\"{x:1410,y:350,t:1527876764639};\\\", \\\"{x:1399,y:357,t:1527876764656};\\\", \\\"{x:1391,y:366,t:1527876764672};\\\", \\\"{x:1378,y:385,t:1527876764689};\\\", \\\"{x:1371,y:394,t:1527876764705};\\\", \\\"{x:1367,y:404,t:1527876764722};\\\", \\\"{x:1364,y:413,t:1527876764738};\\\", \\\"{x:1362,y:422,t:1527876764755};\\\", \\\"{x:1360,y:431,t:1527876764772};\\\", \\\"{x:1358,y:441,t:1527876764789};\\\", \\\"{x:1357,y:450,t:1527876764805};\\\", \\\"{x:1355,y:457,t:1527876764822};\\\", \\\"{x:1355,y:467,t:1527876764839};\\\", \\\"{x:1354,y:478,t:1527876764856};\\\", \\\"{x:1354,y:487,t:1527876764872};\\\", \\\"{x:1354,y:496,t:1527876764889};\\\", \\\"{x:1354,y:501,t:1527876764906};\\\", \\\"{x:1354,y:509,t:1527876764921};\\\", \\\"{x:1354,y:520,t:1527876764938};\\\", \\\"{x:1354,y:531,t:1527876764956};\\\", \\\"{x:1354,y:545,t:1527876764971};\\\", \\\"{x:1354,y:550,t:1527876764988};\\\", \\\"{x:1354,y:555,t:1527876765005};\\\", \\\"{x:1354,y:559,t:1527876765021};\\\", \\\"{x:1355,y:564,t:1527876765038};\\\", \\\"{x:1356,y:571,t:1527876765055};\\\", \\\"{x:1358,y:579,t:1527876765071};\\\", \\\"{x:1359,y:589,t:1527876765088};\\\", \\\"{x:1359,y:591,t:1527876765105};\\\", \\\"{x:1360,y:595,t:1527876765121};\\\", \\\"{x:1360,y:598,t:1527876765138};\\\", \\\"{x:1360,y:602,t:1527876765155};\\\", \\\"{x:1360,y:606,t:1527876765171};\\\", \\\"{x:1362,y:609,t:1527876765188};\\\", \\\"{x:1362,y:614,t:1527876765205};\\\", \\\"{x:1362,y:620,t:1527876765221};\\\", \\\"{x:1362,y:624,t:1527876765239};\\\", \\\"{x:1362,y:629,t:1527876765255};\\\", \\\"{x:1362,y:637,t:1527876765271};\\\", \\\"{x:1362,y:643,t:1527876765288};\\\", \\\"{x:1362,y:647,t:1527876765306};\\\", \\\"{x:1362,y:652,t:1527876765323};\\\", \\\"{x:1361,y:659,t:1527876765338};\\\", \\\"{x:1361,y:672,t:1527876765355};\\\", \\\"{x:1357,y:682,t:1527876765372};\\\", \\\"{x:1352,y:692,t:1527876765389};\\\", \\\"{x:1349,y:697,t:1527876765406};\\\", \\\"{x:1344,y:705,t:1527876765423};\\\", \\\"{x:1340,y:714,t:1527876765439};\\\", \\\"{x:1335,y:719,t:1527876765456};\\\", \\\"{x:1328,y:727,t:1527876765472};\\\", \\\"{x:1324,y:730,t:1527876765488};\\\", \\\"{x:1315,y:735,t:1527876765506};\\\", \\\"{x:1306,y:740,t:1527876765522};\\\", \\\"{x:1298,y:743,t:1527876765538};\\\", \\\"{x:1293,y:746,t:1527876765555};\\\", \\\"{x:1289,y:748,t:1527876765572};\\\", \\\"{x:1284,y:749,t:1527876765588};\\\", \\\"{x:1278,y:752,t:1527876765605};\\\", \\\"{x:1272,y:753,t:1527876765622};\\\", \\\"{x:1265,y:757,t:1527876765638};\\\", \\\"{x:1258,y:760,t:1527876765656};\\\", \\\"{x:1248,y:766,t:1527876765672};\\\", \\\"{x:1241,y:771,t:1527876765689};\\\", \\\"{x:1239,y:772,t:1527876765706};\\\", \\\"{x:1239,y:774,t:1527876765728};\\\", \\\"{x:1239,y:776,t:1527876765739};\\\", \\\"{x:1241,y:781,t:1527876765756};\\\", \\\"{x:1250,y:791,t:1527876765772};\\\", \\\"{x:1269,y:806,t:1527876765788};\\\", \\\"{x:1290,y:819,t:1527876765805};\\\", \\\"{x:1311,y:833,t:1527876765822};\\\", \\\"{x:1323,y:840,t:1527876765839};\\\", \\\"{x:1330,y:844,t:1527876765856};\\\", \\\"{x:1332,y:846,t:1527876765872};\\\", \\\"{x:1333,y:847,t:1527876765890};\\\", \\\"{x:1334,y:850,t:1527876765912};\\\", \\\"{x:1335,y:851,t:1527876765922};\\\", \\\"{x:1338,y:853,t:1527876765939};\\\", \\\"{x:1344,y:858,t:1527876765956};\\\", \\\"{x:1355,y:864,t:1527876765973};\\\", \\\"{x:1370,y:868,t:1527876765989};\\\", \\\"{x:1387,y:869,t:1527876766005};\\\", \\\"{x:1403,y:870,t:1527876766022};\\\", \\\"{x:1423,y:873,t:1527876766040};\\\", \\\"{x:1443,y:873,t:1527876766056};\\\", \\\"{x:1469,y:873,t:1527876766072};\\\", \\\"{x:1480,y:873,t:1527876766090};\\\", \\\"{x:1485,y:873,t:1527876766107};\\\", \\\"{x:1486,y:873,t:1527876766122};\\\", \\\"{x:1487,y:873,t:1527876766184};\\\", \\\"{x:1487,y:872,t:1527876766200};\\\", \\\"{x:1488,y:871,t:1527876766209};\\\", \\\"{x:1490,y:870,t:1527876766222};\\\", \\\"{x:1494,y:866,t:1527876766239};\\\", \\\"{x:1498,y:862,t:1527876766256};\\\", \\\"{x:1504,y:855,t:1527876766273};\\\", \\\"{x:1509,y:849,t:1527876766290};\\\", \\\"{x:1511,y:847,t:1527876766308};\\\", \\\"{x:1512,y:845,t:1527876766324};\\\", \\\"{x:1514,y:844,t:1527876766340};\\\", \\\"{x:1517,y:842,t:1527876766357};\\\", \\\"{x:1521,y:838,t:1527876766373};\\\", \\\"{x:1524,y:835,t:1527876766389};\\\", \\\"{x:1529,y:833,t:1527876766406};\\\", \\\"{x:1532,y:831,t:1527876766423};\\\", \\\"{x:1535,y:830,t:1527876766439};\\\", \\\"{x:1538,y:829,t:1527876766456};\\\", \\\"{x:1539,y:829,t:1527876766473};\\\", \\\"{x:1544,y:829,t:1527876766489};\\\", \\\"{x:1553,y:829,t:1527876766507};\\\", \\\"{x:1570,y:829,t:1527876766522};\\\", \\\"{x:1592,y:830,t:1527876766540};\\\", \\\"{x:1615,y:835,t:1527876766557};\\\", \\\"{x:1637,y:837,t:1527876766573};\\\", \\\"{x:1650,y:839,t:1527876766589};\\\", \\\"{x:1659,y:841,t:1527876766607};\\\", \\\"{x:1663,y:842,t:1527876766622};\\\", \\\"{x:1664,y:842,t:1527876766639};\\\", \\\"{x:1665,y:842,t:1527876766664};\\\", \\\"{x:1666,y:842,t:1527876766673};\\\", \\\"{x:1669,y:842,t:1527876766690};\\\", \\\"{x:1674,y:842,t:1527876766706};\\\", \\\"{x:1682,y:838,t:1527876766722};\\\", \\\"{x:1693,y:830,t:1527876766739};\\\", \\\"{x:1701,y:819,t:1527876766756};\\\", \\\"{x:1708,y:805,t:1527876766773};\\\", \\\"{x:1714,y:790,t:1527876766789};\\\", \\\"{x:1718,y:774,t:1527876766806};\\\", \\\"{x:1720,y:762,t:1527876766824};\\\", \\\"{x:1722,y:747,t:1527876766839};\\\", \\\"{x:1722,y:727,t:1527876766856};\\\", \\\"{x:1715,y:712,t:1527876766873};\\\", \\\"{x:1704,y:699,t:1527876766890};\\\", \\\"{x:1692,y:691,t:1527876766905};\\\", \\\"{x:1680,y:685,t:1527876766923};\\\", \\\"{x:1668,y:680,t:1527876766939};\\\", \\\"{x:1655,y:674,t:1527876766957};\\\", \\\"{x:1636,y:665,t:1527876766973};\\\", \\\"{x:1613,y:659,t:1527876766989};\\\", \\\"{x:1602,y:654,t:1527876767006};\\\", \\\"{x:1594,y:653,t:1527876767023};\\\", \\\"{x:1590,y:653,t:1527876767039};\\\", \\\"{x:1586,y:653,t:1527876767056};\\\", \\\"{x:1585,y:653,t:1527876767073};\\\", \\\"{x:1583,y:653,t:1527876767090};\\\", \\\"{x:1581,y:653,t:1527876767169};\\\", \\\"{x:1580,y:653,t:1527876767176};\\\", \\\"{x:1578,y:653,t:1527876767190};\\\", \\\"{x:1571,y:653,t:1527876767207};\\\", \\\"{x:1557,y:653,t:1527876767224};\\\", \\\"{x:1545,y:652,t:1527876767240};\\\", \\\"{x:1524,y:647,t:1527876767257};\\\", \\\"{x:1508,y:640,t:1527876767274};\\\", \\\"{x:1491,y:632,t:1527876767291};\\\", \\\"{x:1477,y:624,t:1527876767307};\\\", \\\"{x:1466,y:619,t:1527876767324};\\\", \\\"{x:1456,y:613,t:1527876767340};\\\", \\\"{x:1453,y:612,t:1527876767357};\\\", \\\"{x:1452,y:611,t:1527876767373};\\\", \\\"{x:1451,y:610,t:1527876767392};\\\", \\\"{x:1449,y:608,t:1527876767406};\\\", \\\"{x:1448,y:606,t:1527876767423};\\\", \\\"{x:1446,y:605,t:1527876767441};\\\", \\\"{x:1445,y:604,t:1527876767456};\\\", \\\"{x:1443,y:604,t:1527876767473};\\\", \\\"{x:1439,y:606,t:1527876767490};\\\", \\\"{x:1433,y:609,t:1527876767506};\\\", \\\"{x:1431,y:610,t:1527876767524};\\\", \\\"{x:1428,y:615,t:1527876767540};\\\", \\\"{x:1422,y:624,t:1527876767557};\\\", \\\"{x:1418,y:634,t:1527876767573};\\\", \\\"{x:1415,y:643,t:1527876767590};\\\", \\\"{x:1414,y:653,t:1527876767607};\\\", \\\"{x:1410,y:662,t:1527876767623};\\\", \\\"{x:1409,y:669,t:1527876767640};\\\", \\\"{x:1409,y:670,t:1527876767663};\\\", \\\"{x:1406,y:675,t:1527876767704};\\\", \\\"{x:1406,y:676,t:1527876767712};\\\", \\\"{x:1405,y:679,t:1527876767723};\\\", \\\"{x:1402,y:683,t:1527876767741};\\\", \\\"{x:1399,y:686,t:1527876767757};\\\", \\\"{x:1395,y:689,t:1527876767774};\\\", \\\"{x:1393,y:692,t:1527876767791};\\\", \\\"{x:1390,y:694,t:1527876767807};\\\", \\\"{x:1389,y:694,t:1527876767824};\\\", \\\"{x:1389,y:695,t:1527876767840};\\\", \\\"{x:1388,y:695,t:1527876767858};\\\", \\\"{x:1387,y:696,t:1527876767873};\\\", \\\"{x:1384,y:697,t:1527876767890};\\\", \\\"{x:1382,y:698,t:1527876767907};\\\", \\\"{x:1379,y:698,t:1527876767923};\\\", \\\"{x:1375,y:700,t:1527876767941};\\\", \\\"{x:1371,y:701,t:1527876767957};\\\", \\\"{x:1362,y:701,t:1527876767973};\\\", \\\"{x:1356,y:701,t:1527876767990};\\\", \\\"{x:1350,y:699,t:1527876768007};\\\", \\\"{x:1348,y:698,t:1527876768023};\\\", \\\"{x:1347,y:698,t:1527876768040};\\\", \\\"{x:1348,y:699,t:1527876768224};\\\", \\\"{x:1351,y:706,t:1527876768241};\\\", \\\"{x:1355,y:712,t:1527876768257};\\\", \\\"{x:1359,y:719,t:1527876768274};\\\", \\\"{x:1362,y:724,t:1527876768290};\\\", \\\"{x:1367,y:732,t:1527876768333};\\\", \\\"{x:1368,y:733,t:1527876768344};\\\", \\\"{x:1369,y:735,t:1527876768357};\\\", \\\"{x:1372,y:739,t:1527876768375};\\\", \\\"{x:1376,y:743,t:1527876768391};\\\", \\\"{x:1383,y:754,t:1527876768407};\\\", \\\"{x:1395,y:771,t:1527876768424};\\\", \\\"{x:1401,y:782,t:1527876768441};\\\", \\\"{x:1404,y:786,t:1527876768457};\\\", \\\"{x:1405,y:787,t:1527876768474};\\\", \\\"{x:1407,y:790,t:1527876768490};\\\", \\\"{x:1407,y:793,t:1527876768507};\\\", \\\"{x:1409,y:797,t:1527876768524};\\\", \\\"{x:1413,y:807,t:1527876768540};\\\", \\\"{x:1418,y:814,t:1527876768558};\\\", \\\"{x:1422,y:820,t:1527876768574};\\\", \\\"{x:1425,y:824,t:1527876768590};\\\", \\\"{x:1427,y:830,t:1527876768607};\\\", \\\"{x:1429,y:836,t:1527876768624};\\\", \\\"{x:1431,y:843,t:1527876768641};\\\", \\\"{x:1437,y:855,t:1527876768657};\\\", \\\"{x:1441,y:866,t:1527876768674};\\\", \\\"{x:1447,y:876,t:1527876768691};\\\", \\\"{x:1453,y:887,t:1527876768708};\\\", \\\"{x:1457,y:895,t:1527876768724};\\\", \\\"{x:1461,y:904,t:1527876768742};\\\", \\\"{x:1463,y:910,t:1527876768757};\\\", \\\"{x:1465,y:916,t:1527876768774};\\\", \\\"{x:1465,y:921,t:1527876768791};\\\", \\\"{x:1468,y:928,t:1527876768808};\\\", \\\"{x:1470,y:935,t:1527876768824};\\\", \\\"{x:1472,y:939,t:1527876768841};\\\", \\\"{x:1474,y:943,t:1527876768857};\\\", \\\"{x:1475,y:944,t:1527876768874};\\\", \\\"{x:1475,y:945,t:1527876768891};\\\", \\\"{x:1475,y:946,t:1527876768907};\\\", \\\"{x:1476,y:948,t:1527876768924};\\\", \\\"{x:1477,y:949,t:1527876768942};\\\", \\\"{x:1478,y:951,t:1527876768957};\\\", \\\"{x:1480,y:954,t:1527876768974};\\\", \\\"{x:1480,y:957,t:1527876768992};\\\", \\\"{x:1483,y:961,t:1527876769007};\\\", \\\"{x:1483,y:963,t:1527876769025};\\\", \\\"{x:1483,y:964,t:1527876769104};\\\", \\\"{x:1483,y:965,t:1527876769208};\\\", \\\"{x:1481,y:965,t:1527876769400};\\\", \\\"{x:1480,y:965,t:1527876770240};\\\", \\\"{x:1478,y:965,t:1527876770264};\\\", \\\"{x:1477,y:965,t:1527876770280};\\\", \\\"{x:1477,y:964,t:1527876770292};\\\", \\\"{x:1476,y:964,t:1527876770309};\\\", \\\"{x:1475,y:963,t:1527876770327};\\\", \\\"{x:1474,y:963,t:1527876770359};\\\", \\\"{x:1473,y:963,t:1527876770384};\\\", \\\"{x:1472,y:963,t:1527876770424};\\\", \\\"{x:1471,y:961,t:1527876770464};\\\", \\\"{x:1470,y:961,t:1527876770480};\\\", \\\"{x:1469,y:961,t:1527876770492};\\\", \\\"{x:1468,y:960,t:1527876770520};\\\", \\\"{x:1467,y:959,t:1527876770616};\\\", \\\"{x:1466,y:959,t:1527876770626};\\\", \\\"{x:1465,y:959,t:1527876770656};\\\", \\\"{x:1464,y:958,t:1527876770671};\\\", \\\"{x:1463,y:958,t:1527876770704};\\\", \\\"{x:1462,y:957,t:1527876770736};\\\", \\\"{x:1461,y:957,t:1527876770751};\\\", \\\"{x:1461,y:956,t:1527876770760};\\\", \\\"{x:1459,y:954,t:1527876770775};\\\", \\\"{x:1458,y:954,t:1527876770792};\\\", \\\"{x:1457,y:953,t:1527876770810};\\\", \\\"{x:1456,y:953,t:1527876770826};\\\", \\\"{x:1455,y:952,t:1527876770843};\\\", \\\"{x:1454,y:951,t:1527876770863};\\\", \\\"{x:1453,y:951,t:1527876770904};\\\", \\\"{x:1452,y:951,t:1527876770984};\\\", \\\"{x:1450,y:950,t:1527876771000};\\\", \\\"{x:1449,y:949,t:1527876771040};\\\", \\\"{x:1447,y:948,t:1527876771064};\\\", \\\"{x:1446,y:948,t:1527876771077};\\\", \\\"{x:1443,y:946,t:1527876771093};\\\", \\\"{x:1441,y:945,t:1527876771110};\\\", \\\"{x:1439,y:943,t:1527876771126};\\\", \\\"{x:1437,y:943,t:1527876771143};\\\", \\\"{x:1436,y:942,t:1527876771160};\\\", \\\"{x:1435,y:942,t:1527876771184};\\\", \\\"{x:1434,y:942,t:1527876771193};\\\", \\\"{x:1432,y:940,t:1527876771209};\\\", \\\"{x:1431,y:940,t:1527876771226};\\\", \\\"{x:1429,y:939,t:1527876771243};\\\", \\\"{x:1428,y:939,t:1527876771259};\\\", \\\"{x:1427,y:938,t:1527876771277};\\\", \\\"{x:1425,y:937,t:1527876771293};\\\", \\\"{x:1424,y:937,t:1527876771310};\\\", \\\"{x:1421,y:935,t:1527876771326};\\\", \\\"{x:1418,y:935,t:1527876771342};\\\", \\\"{x:1414,y:932,t:1527876771359};\\\", \\\"{x:1411,y:931,t:1527876771376};\\\", \\\"{x:1407,y:928,t:1527876771393};\\\", \\\"{x:1404,y:927,t:1527876771409};\\\", \\\"{x:1398,y:925,t:1527876771427};\\\", \\\"{x:1394,y:923,t:1527876771443};\\\", \\\"{x:1389,y:921,t:1527876771459};\\\", \\\"{x:1383,y:919,t:1527876771476};\\\", \\\"{x:1378,y:916,t:1527876771493};\\\", \\\"{x:1369,y:912,t:1527876771510};\\\", \\\"{x:1356,y:906,t:1527876771527};\\\", \\\"{x:1339,y:900,t:1527876771543};\\\", \\\"{x:1310,y:885,t:1527876771560};\\\", \\\"{x:1248,y:860,t:1527876771577};\\\", \\\"{x:1204,y:840,t:1527876771593};\\\", \\\"{x:1154,y:819,t:1527876771610};\\\", \\\"{x:1107,y:799,t:1527876771627};\\\", \\\"{x:1062,y:777,t:1527876771644};\\\", \\\"{x:1016,y:758,t:1527876771660};\\\", \\\"{x:972,y:738,t:1527876771676};\\\", \\\"{x:944,y:726,t:1527876771693};\\\", \\\"{x:912,y:712,t:1527876771710};\\\", \\\"{x:880,y:690,t:1527876771727};\\\", \\\"{x:844,y:664,t:1527876771744};\\\", \\\"{x:830,y:652,t:1527876771760};\\\", \\\"{x:821,y:640,t:1527876771776};\\\", \\\"{x:814,y:626,t:1527876771794};\\\", \\\"{x:807,y:615,t:1527876771809};\\\", \\\"{x:797,y:599,t:1527876771827};\\\", \\\"{x:787,y:588,t:1527876771844};\\\", \\\"{x:778,y:580,t:1527876771861};\\\", \\\"{x:771,y:576,t:1527876771878};\\\", \\\"{x:764,y:571,t:1527876771894};\\\", \\\"{x:759,y:567,t:1527876771911};\\\", \\\"{x:739,y:557,t:1527876771928};\\\", \\\"{x:715,y:551,t:1527876771944};\\\", \\\"{x:684,y:538,t:1527876771960};\\\", \\\"{x:659,y:528,t:1527876771978};\\\", \\\"{x:641,y:517,t:1527876771994};\\\", \\\"{x:631,y:510,t:1527876772011};\\\", \\\"{x:629,y:507,t:1527876772028};\\\", \\\"{x:627,y:505,t:1527876772045};\\\", \\\"{x:624,y:502,t:1527876772061};\\\", \\\"{x:623,y:500,t:1527876772078};\\\", \\\"{x:623,y:500,t:1527876772304};\\\", \\\"{x:623,y:503,t:1527876772512};\\\", \\\"{x:613,y:517,t:1527876772528};\\\", \\\"{x:600,y:537,t:1527876772545};\\\", \\\"{x:589,y:552,t:1527876772562};\\\", \\\"{x:580,y:563,t:1527876772578};\\\", \\\"{x:572,y:575,t:1527876772594};\\\", \\\"{x:567,y:585,t:1527876772612};\\\", \\\"{x:562,y:597,t:1527876772628};\\\", \\\"{x:557,y:609,t:1527876772645};\\\", \\\"{x:551,y:626,t:1527876772662};\\\", \\\"{x:545,y:641,t:1527876772678};\\\", \\\"{x:536,y:656,t:1527876772695};\\\", \\\"{x:530,y:667,t:1527876772712};\\\", \\\"{x:530,y:668,t:1527876772728};\\\", \\\"{x:529,y:673,t:1527876772744};\\\", \\\"{x:529,y:677,t:1527876772761};\\\", \\\"{x:529,y:685,t:1527876772778};\\\", \\\"{x:529,y:694,t:1527876772794};\\\", \\\"{x:527,y:705,t:1527876772811};\\\", \\\"{x:527,y:711,t:1527876772829};\\\", \\\"{x:527,y:713,t:1527876772844};\\\", \\\"{x:527,y:715,t:1527876772904};\\\", \\\"{x:527,y:717,t:1527876772911};\\\", \\\"{x:527,y:720,t:1527876772929};\\\", \\\"{x:527,y:726,t:1527876772944};\\\", \\\"{x:527,y:734,t:1527876772962};\\\", \\\"{x:527,y:740,t:1527876772978};\\\", \\\"{x:527,y:743,t:1527876772995};\\\", \\\"{x:527,y:744,t:1527876773024};\\\" ] }, { \\\"rt\\\": 8837, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 356803, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"DJRH1\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-12 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:528,y:744,t:1527876775376};\\\", \\\"{x:529,y:743,t:1527876776384};\\\", \\\"{x:530,y:743,t:1527876776397};\\\", \\\"{x:534,y:747,t:1527876776413};\\\", \\\"{x:541,y:756,t:1527876776431};\\\", \\\"{x:557,y:769,t:1527876776447};\\\", \\\"{x:585,y:783,t:1527876776463};\\\", \\\"{x:604,y:793,t:1527876776480};\\\", \\\"{x:623,y:802,t:1527876776498};\\\", \\\"{x:643,y:808,t:1527876776514};\\\", \\\"{x:654,y:812,t:1527876776531};\\\", \\\"{x:662,y:815,t:1527876776548};\\\", \\\"{x:672,y:820,t:1527876776565};\\\", \\\"{x:676,y:822,t:1527876776581};\\\", \\\"{x:678,y:823,t:1527876776598};\\\", \\\"{x:681,y:823,t:1527876776615};\\\", \\\"{x:686,y:826,t:1527876776630};\\\", \\\"{x:705,y:831,t:1527876776647};\\\", \\\"{x:725,y:837,t:1527876776665};\\\", \\\"{x:743,y:842,t:1527876776681};\\\", \\\"{x:763,y:848,t:1527876776697};\\\", \\\"{x:781,y:852,t:1527876776714};\\\", \\\"{x:796,y:853,t:1527876776730};\\\", \\\"{x:811,y:856,t:1527876776748};\\\", \\\"{x:822,y:857,t:1527876776764};\\\", \\\"{x:828,y:857,t:1527876776781};\\\", \\\"{x:829,y:857,t:1527876776798};\\\", \\\"{x:831,y:857,t:1527876776815};\\\", \\\"{x:833,y:857,t:1527876776832};\\\", \\\"{x:837,y:857,t:1527876776848};\\\", \\\"{x:849,y:857,t:1527876776864};\\\", \\\"{x:870,y:862,t:1527876776882};\\\", \\\"{x:898,y:869,t:1527876776898};\\\", \\\"{x:924,y:875,t:1527876776915};\\\", \\\"{x:946,y:882,t:1527876776932};\\\", \\\"{x:971,y:889,t:1527876776947};\\\", \\\"{x:994,y:897,t:1527876776964};\\\", \\\"{x:1016,y:902,t:1527876776982};\\\", \\\"{x:1036,y:908,t:1527876776997};\\\", \\\"{x:1050,y:912,t:1527876777015};\\\", \\\"{x:1059,y:914,t:1527876777032};\\\", \\\"{x:1062,y:915,t:1527876777047};\\\", \\\"{x:1064,y:915,t:1527876777064};\\\", \\\"{x:1069,y:917,t:1527876777082};\\\", \\\"{x:1078,y:919,t:1527876777098};\\\", \\\"{x:1095,y:924,t:1527876777114};\\\", \\\"{x:1111,y:929,t:1527876777131};\\\", \\\"{x:1128,y:933,t:1527876777147};\\\", \\\"{x:1145,y:939,t:1527876777164};\\\", \\\"{x:1163,y:943,t:1527876777181};\\\", \\\"{x:1180,y:948,t:1527876777199};\\\", \\\"{x:1197,y:953,t:1527876777215};\\\", \\\"{x:1216,y:959,t:1527876777231};\\\", \\\"{x:1225,y:960,t:1527876777248};\\\", \\\"{x:1234,y:961,t:1527876777265};\\\", \\\"{x:1239,y:963,t:1527876777281};\\\", \\\"{x:1246,y:964,t:1527876777298};\\\", \\\"{x:1251,y:964,t:1527876777314};\\\", \\\"{x:1263,y:968,t:1527876777332};\\\", \\\"{x:1283,y:974,t:1527876777349};\\\", \\\"{x:1301,y:978,t:1527876777365};\\\", \\\"{x:1314,y:980,t:1527876777382};\\\", \\\"{x:1317,y:980,t:1527876777398};\\\", \\\"{x:1319,y:980,t:1527876777472};\\\", \\\"{x:1320,y:979,t:1527876777482};\\\", \\\"{x:1324,y:975,t:1527876777498};\\\", \\\"{x:1328,y:971,t:1527876777514};\\\", \\\"{x:1335,y:967,t:1527876777532};\\\", \\\"{x:1343,y:962,t:1527876777549};\\\", \\\"{x:1351,y:957,t:1527876777565};\\\", \\\"{x:1355,y:954,t:1527876777582};\\\", \\\"{x:1353,y:955,t:1527876779464};\\\", \\\"{x:1352,y:957,t:1527876779471};\\\", \\\"{x:1351,y:958,t:1527876779484};\\\", \\\"{x:1348,y:962,t:1527876779500};\\\", \\\"{x:1346,y:965,t:1527876779517};\\\", \\\"{x:1344,y:965,t:1527876780936};\\\", \\\"{x:1341,y:965,t:1527876780951};\\\", \\\"{x:1323,y:960,t:1527876780968};\\\", \\\"{x:1308,y:955,t:1527876780985};\\\", \\\"{x:1291,y:952,t:1527876781001};\\\", \\\"{x:1276,y:949,t:1527876781018};\\\", \\\"{x:1262,y:947,t:1527876781035};\\\", \\\"{x:1244,y:944,t:1527876781051};\\\", \\\"{x:1222,y:939,t:1527876781069};\\\", \\\"{x:1193,y:931,t:1527876781085};\\\", \\\"{x:1162,y:921,t:1527876781101};\\\", \\\"{x:1132,y:913,t:1527876781117};\\\", \\\"{x:1096,y:904,t:1527876781135};\\\", \\\"{x:1057,y:886,t:1527876781150};\\\", \\\"{x:997,y:858,t:1527876781168};\\\", \\\"{x:958,y:841,t:1527876781185};\\\", \\\"{x:916,y:820,t:1527876781201};\\\", \\\"{x:882,y:803,t:1527876781218};\\\", \\\"{x:849,y:784,t:1527876781235};\\\", \\\"{x:825,y:771,t:1527876781252};\\\", \\\"{x:788,y:750,t:1527876781268};\\\", \\\"{x:753,y:737,t:1527876781285};\\\", \\\"{x:721,y:720,t:1527876781302};\\\", \\\"{x:692,y:709,t:1527876781318};\\\", \\\"{x:658,y:700,t:1527876781335};\\\", \\\"{x:595,y:684,t:1527876781351};\\\", \\\"{x:550,y:670,t:1527876781368};\\\", \\\"{x:508,y:659,t:1527876781385};\\\", \\\"{x:478,y:652,t:1527876781403};\\\", \\\"{x:456,y:650,t:1527876781417};\\\", \\\"{x:436,y:645,t:1527876781435};\\\", \\\"{x:421,y:642,t:1527876781452};\\\", \\\"{x:412,y:640,t:1527876781468};\\\", \\\"{x:405,y:638,t:1527876781485};\\\", \\\"{x:404,y:637,t:1527876781502};\\\", \\\"{x:402,y:636,t:1527876781518};\\\", \\\"{x:401,y:631,t:1527876781536};\\\", \\\"{x:401,y:623,t:1527876781552};\\\", \\\"{x:401,y:616,t:1527876781569};\\\", \\\"{x:401,y:610,t:1527876781585};\\\", \\\"{x:400,y:601,t:1527876781602};\\\", \\\"{x:399,y:594,t:1527876781619};\\\", \\\"{x:398,y:587,t:1527876781635};\\\", \\\"{x:398,y:586,t:1527876781652};\\\", \\\"{x:398,y:585,t:1527876781668};\\\", \\\"{x:398,y:584,t:1527876781688};\\\", \\\"{x:398,y:583,t:1527876781704};\\\", \\\"{x:398,y:581,t:1527876781718};\\\", \\\"{x:397,y:578,t:1527876781735};\\\", \\\"{x:396,y:573,t:1527876781751};\\\", \\\"{x:396,y:572,t:1527876781769};\\\", \\\"{x:396,y:571,t:1527876781784};\\\", \\\"{x:396,y:568,t:1527876781802};\\\", \\\"{x:394,y:563,t:1527876781819};\\\", \\\"{x:394,y:559,t:1527876781835};\\\", \\\"{x:394,y:557,t:1527876781852};\\\", \\\"{x:394,y:556,t:1527876781868};\\\", \\\"{x:394,y:555,t:1527876781886};\\\", \\\"{x:394,y:553,t:1527876781902};\\\", \\\"{x:393,y:552,t:1527876781919};\\\", \\\"{x:393,y:549,t:1527876781935};\\\", \\\"{x:392,y:546,t:1527876781952};\\\", \\\"{x:392,y:543,t:1527876781969};\\\", \\\"{x:391,y:542,t:1527876781986};\\\", \\\"{x:390,y:542,t:1527876782039};\\\", \\\"{x:388,y:544,t:1527876782216};\\\", \\\"{x:386,y:552,t:1527876782224};\\\", \\\"{x:386,y:556,t:1527876782236};\\\", \\\"{x:385,y:566,t:1527876782252};\\\", \\\"{x:383,y:574,t:1527876782269};\\\", \\\"{x:382,y:582,t:1527876782285};\\\", \\\"{x:381,y:588,t:1527876782302};\\\", \\\"{x:380,y:591,t:1527876782319};\\\", \\\"{x:380,y:595,t:1527876782336};\\\", \\\"{x:380,y:598,t:1527876782352};\\\", \\\"{x:380,y:599,t:1527876782369};\\\", \\\"{x:380,y:600,t:1527876782386};\\\", \\\"{x:380,y:603,t:1527876782404};\\\", \\\"{x:380,y:604,t:1527876782420};\\\", \\\"{x:380,y:606,t:1527876782436};\\\", \\\"{x:380,y:607,t:1527876782463};\\\", \\\"{x:380,y:609,t:1527876782536};\\\", \\\"{x:380,y:610,t:1527876782647};\\\", \\\"{x:380,y:610,t:1527876782698};\\\", \\\"{x:380,y:612,t:1527876782767};\\\", \\\"{x:381,y:618,t:1527876782776};\\\", \\\"{x:387,y:626,t:1527876782786};\\\", \\\"{x:399,y:643,t:1527876782803};\\\", \\\"{x:413,y:662,t:1527876782819};\\\", \\\"{x:426,y:679,t:1527876782836};\\\", \\\"{x:440,y:694,t:1527876782853};\\\", \\\"{x:449,y:702,t:1527876782869};\\\", \\\"{x:457,y:709,t:1527876782886};\\\", \\\"{x:460,y:710,t:1527876782903};\\\", \\\"{x:464,y:711,t:1527876782920};\\\", \\\"{x:464,y:712,t:1527876782936};\\\", \\\"{x:465,y:712,t:1527876782959};\\\", \\\"{x:468,y:714,t:1527876782970};\\\", \\\"{x:474,y:718,t:1527876782986};\\\", \\\"{x:483,y:726,t:1527876783004};\\\", \\\"{x:489,y:731,t:1527876783020};\\\", \\\"{x:495,y:736,t:1527876783035};\\\", \\\"{x:501,y:742,t:1527876783053};\\\", \\\"{x:505,y:744,t:1527876783070};\\\", \\\"{x:508,y:747,t:1527876783086};\\\", \\\"{x:511,y:749,t:1527876783103};\\\", \\\"{x:514,y:751,t:1527876783119};\\\", \\\"{x:513,y:751,t:1527876783584};\\\", \\\"{x:512,y:751,t:1527876783703};\\\", \\\"{x:512,y:750,t:1527876783992};\\\", \\\"{x:513,y:750,t:1527876784008};\\\", \\\"{x:515,y:749,t:1527876784020};\\\", \\\"{x:517,y:749,t:1527876784037};\\\", \\\"{x:520,y:747,t:1527876784054};\\\", \\\"{x:521,y:746,t:1527876784071};\\\", \\\"{x:523,y:746,t:1527876784112};\\\", \\\"{x:523,y:745,t:1527876784135};\\\", \\\"{x:525,y:745,t:1527876784152};\\\", \\\"{x:525,y:744,t:1527876784192};\\\" ] }, { \\\"rt\\\": 15124, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 373144, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"DJRH1\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-N -F -F -G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:524,y:711,t:1527876784956};\\\", \\\"{x:520,y:694,t:1527876784971};\\\", \\\"{x:513,y:671,t:1527876784988};\\\", \\\"{x:503,y:651,t:1527876785004};\\\", \\\"{x:492,y:627,t:1527876785022};\\\", \\\"{x:483,y:605,t:1527876785038};\\\", \\\"{x:474,y:582,t:1527876785055};\\\", \\\"{x:464,y:562,t:1527876785072};\\\", \\\"{x:454,y:541,t:1527876785089};\\\", \\\"{x:447,y:531,t:1527876785105};\\\", \\\"{x:439,y:522,t:1527876785121};\\\", \\\"{x:434,y:518,t:1527876785137};\\\", \\\"{x:429,y:514,t:1527876785155};\\\", \\\"{x:424,y:510,t:1527876785171};\\\", \\\"{x:419,y:506,t:1527876785188};\\\", \\\"{x:410,y:497,t:1527876785205};\\\", \\\"{x:402,y:489,t:1527876785222};\\\", \\\"{x:393,y:482,t:1527876785239};\\\", \\\"{x:387,y:477,t:1527876785256};\\\", \\\"{x:384,y:474,t:1527876785270};\\\", \\\"{x:381,y:471,t:1527876785287};\\\", \\\"{x:380,y:469,t:1527876785306};\\\", \\\"{x:379,y:468,t:1527876785322};\\\", \\\"{x:379,y:467,t:1527876785407};\\\", \\\"{x:379,y:466,t:1527876785422};\\\", \\\"{x:382,y:465,t:1527876785438};\\\", \\\"{x:387,y:463,t:1527876785455};\\\", \\\"{x:402,y:463,t:1527876785471};\\\", \\\"{x:416,y:463,t:1527876785488};\\\", \\\"{x:431,y:463,t:1527876785506};\\\", \\\"{x:450,y:463,t:1527876785522};\\\", \\\"{x:466,y:463,t:1527876785539};\\\", \\\"{x:480,y:463,t:1527876785555};\\\", \\\"{x:488,y:463,t:1527876785572};\\\", \\\"{x:492,y:463,t:1527876785589};\\\", \\\"{x:494,y:463,t:1527876785605};\\\", \\\"{x:496,y:463,t:1527876785622};\\\", \\\"{x:501,y:463,t:1527876785639};\\\", \\\"{x:508,y:463,t:1527876785655};\\\", \\\"{x:520,y:463,t:1527876785672};\\\", \\\"{x:525,y:463,t:1527876785689};\\\", \\\"{x:530,y:463,t:1527876785706};\\\", \\\"{x:532,y:463,t:1527876785722};\\\", \\\"{x:533,y:463,t:1527876785759};\\\", \\\"{x:534,y:463,t:1527876785775};\\\", \\\"{x:535,y:463,t:1527876785867};\\\", \\\"{x:537,y:463,t:1527876785877};\\\", \\\"{x:540,y:463,t:1527876785892};\\\", \\\"{x:544,y:463,t:1527876785910};\\\", \\\"{x:546,y:463,t:1527876785926};\\\", \\\"{x:548,y:463,t:1527876785943};\\\", \\\"{x:549,y:463,t:1527876785959};\\\", \\\"{x:550,y:463,t:1527876785976};\\\", \\\"{x:551,y:463,t:1527876786099};\\\", \\\"{x:551,y:464,t:1527876786787};\\\", \\\"{x:550,y:465,t:1527876786819};\\\", \\\"{x:549,y:465,t:1527876786883};\\\", \\\"{x:546,y:465,t:1527876786922};\\\", \\\"{x:539,y:465,t:1527876786930};\\\", \\\"{x:525,y:465,t:1527876786944};\\\", \\\"{x:504,y:469,t:1527876786961};\\\", \\\"{x:484,y:470,t:1527876786977};\\\", \\\"{x:455,y:470,t:1527876786994};\\\", \\\"{x:420,y:470,t:1527876787011};\\\", \\\"{x:410,y:470,t:1527876787028};\\\", \\\"{x:404,y:470,t:1527876787044};\\\", \\\"{x:399,y:470,t:1527876787061};\\\", \\\"{x:403,y:470,t:1527876787347};\\\", \\\"{x:406,y:470,t:1527876787361};\\\", \\\"{x:407,y:470,t:1527876787378};\\\", \\\"{x:409,y:470,t:1527876787395};\\\", \\\"{x:414,y:470,t:1527876787412};\\\", \\\"{x:416,y:470,t:1527876787428};\\\", \\\"{x:417,y:470,t:1527876787446};\\\", \\\"{x:420,y:470,t:1527876787963};\\\", \\\"{x:430,y:469,t:1527876787980};\\\", \\\"{x:444,y:468,t:1527876787996};\\\", \\\"{x:459,y:465,t:1527876788013};\\\", \\\"{x:463,y:464,t:1527876788030};\\\", \\\"{x:464,y:464,t:1527876788047};\\\", \\\"{x:465,y:464,t:1527876788131};\\\", \\\"{x:465,y:465,t:1527876788347};\\\", \\\"{x:458,y:468,t:1527876788363};\\\", \\\"{x:455,y:469,t:1527876788380};\\\", \\\"{x:453,y:470,t:1527876788397};\\\", \\\"{x:438,y:470,t:1527876788414};\\\", \\\"{x:421,y:470,t:1527876788430};\\\", \\\"{x:412,y:469,t:1527876788447};\\\", \\\"{x:408,y:469,t:1527876788463};\\\", \\\"{x:406,y:468,t:1527876788480};\\\", \\\"{x:405,y:468,t:1527876788555};\\\", \\\"{x:406,y:467,t:1527876788722};\\\", \\\"{x:411,y:467,t:1527876788731};\\\", \\\"{x:416,y:466,t:1527876788747};\\\", \\\"{x:421,y:466,t:1527876788764};\\\", \\\"{x:426,y:466,t:1527876788782};\\\", \\\"{x:429,y:466,t:1527876788798};\\\", \\\"{x:431,y:465,t:1527876788814};\\\", \\\"{x:433,y:465,t:1527876788831};\\\", \\\"{x:436,y:465,t:1527876788847};\\\", \\\"{x:437,y:465,t:1527876788865};\\\", \\\"{x:441,y:465,t:1527876788881};\\\", \\\"{x:458,y:465,t:1527876788898};\\\", \\\"{x:469,y:465,t:1527876788914};\\\", \\\"{x:484,y:465,t:1527876788932};\\\", \\\"{x:500,y:465,t:1527876788949};\\\", \\\"{x:510,y:465,t:1527876788964};\\\", \\\"{x:514,y:465,t:1527876788981};\\\", \\\"{x:517,y:464,t:1527876788998};\\\", \\\"{x:518,y:464,t:1527876789018};\\\", \\\"{x:519,y:464,t:1527876789034};\\\", \\\"{x:520,y:464,t:1527876789048};\\\", \\\"{x:521,y:463,t:1527876789065};\\\", \\\"{x:522,y:463,t:1527876789081};\\\", \\\"{x:524,y:462,t:1527876789099};\\\", \\\"{x:526,y:462,t:1527876789122};\\\", \\\"{x:528,y:461,t:1527876789131};\\\", \\\"{x:534,y:461,t:1527876789148};\\\", \\\"{x:540,y:461,t:1527876789165};\\\", \\\"{x:548,y:461,t:1527876789182};\\\", \\\"{x:561,y:461,t:1527876789198};\\\", \\\"{x:569,y:461,t:1527876789215};\\\", \\\"{x:577,y:461,t:1527876789231};\\\", \\\"{x:581,y:461,t:1527876789248};\\\", \\\"{x:584,y:461,t:1527876789266};\\\", \\\"{x:585,y:461,t:1527876789282};\\\", \\\"{x:590,y:461,t:1527876789299};\\\", \\\"{x:596,y:462,t:1527876789315};\\\", \\\"{x:606,y:463,t:1527876789333};\\\", \\\"{x:613,y:464,t:1527876789349};\\\", \\\"{x:615,y:464,t:1527876789366};\\\", \\\"{x:616,y:464,t:1527876789458};\\\", \\\"{x:617,y:464,t:1527876789490};\\\", \\\"{x:618,y:464,t:1527876789507};\\\", \\\"{x:619,y:465,t:1527876789515};\\\", \\\"{x:626,y:475,t:1527876789532};\\\", \\\"{x:636,y:490,t:1527876789550};\\\", \\\"{x:651,y:508,t:1527876789566};\\\", \\\"{x:675,y:526,t:1527876789584};\\\", \\\"{x:711,y:546,t:1527876789606};\\\", \\\"{x:736,y:562,t:1527876789624};\\\", \\\"{x:755,y:573,t:1527876789640};\\\", \\\"{x:769,y:585,t:1527876789662};\\\", \\\"{x:776,y:595,t:1527876789679};\\\", \\\"{x:783,y:609,t:1527876789695};\\\", \\\"{x:792,y:621,t:1527876789711};\\\", \\\"{x:803,y:634,t:1527876789728};\\\", \\\"{x:812,y:645,t:1527876789745};\\\", \\\"{x:817,y:653,t:1527876789762};\\\", \\\"{x:828,y:666,t:1527876789779};\\\", \\\"{x:839,y:680,t:1527876789795};\\\", \\\"{x:855,y:693,t:1527876789812};\\\", \\\"{x:871,y:704,t:1527876789828};\\\", \\\"{x:891,y:713,t:1527876789845};\\\", \\\"{x:913,y:722,t:1527876789862};\\\", \\\"{x:931,y:730,t:1527876789878};\\\", \\\"{x:946,y:736,t:1527876789895};\\\", \\\"{x:955,y:740,t:1527876789912};\\\", \\\"{x:959,y:742,t:1527876789929};\\\", \\\"{x:962,y:744,t:1527876789944};\\\", \\\"{x:964,y:744,t:1527876789961};\\\", \\\"{x:971,y:747,t:1527876789979};\\\", \\\"{x:978,y:750,t:1527876789994};\\\", \\\"{x:989,y:756,t:1527876790012};\\\", \\\"{x:1009,y:765,t:1527876790029};\\\", \\\"{x:1029,y:773,t:1527876790045};\\\", \\\"{x:1049,y:786,t:1527876790061};\\\", \\\"{x:1065,y:793,t:1527876790079};\\\", \\\"{x:1081,y:800,t:1527876790095};\\\", \\\"{x:1097,y:806,t:1527876790112};\\\", \\\"{x:1110,y:812,t:1527876790128};\\\", \\\"{x:1123,y:818,t:1527876790144};\\\", \\\"{x:1133,y:822,t:1527876790162};\\\", \\\"{x:1147,y:828,t:1527876790179};\\\", \\\"{x:1156,y:830,t:1527876790195};\\\", \\\"{x:1165,y:833,t:1527876790211};\\\", \\\"{x:1174,y:835,t:1527876790229};\\\", \\\"{x:1183,y:837,t:1527876790244};\\\", \\\"{x:1192,y:837,t:1527876790262};\\\", \\\"{x:1201,y:838,t:1527876790278};\\\", \\\"{x:1214,y:839,t:1527876790295};\\\", \\\"{x:1224,y:841,t:1527876790311};\\\", \\\"{x:1234,y:842,t:1527876790328};\\\", \\\"{x:1247,y:844,t:1527876790344};\\\", \\\"{x:1256,y:846,t:1527876790362};\\\", \\\"{x:1269,y:848,t:1527876790378};\\\", \\\"{x:1274,y:848,t:1527876790395};\\\", \\\"{x:1280,y:849,t:1527876790412};\\\", \\\"{x:1288,y:851,t:1527876790429};\\\", \\\"{x:1300,y:854,t:1527876790446};\\\", \\\"{x:1317,y:857,t:1527876790461};\\\", \\\"{x:1331,y:858,t:1527876790479};\\\", \\\"{x:1339,y:859,t:1527876790496};\\\", \\\"{x:1344,y:861,t:1527876790512};\\\", \\\"{x:1347,y:861,t:1527876790528};\\\", \\\"{x:1348,y:861,t:1527876790546};\\\", \\\"{x:1350,y:861,t:1527876790562};\\\", \\\"{x:1358,y:861,t:1527876790579};\\\", \\\"{x:1369,y:861,t:1527876790595};\\\", \\\"{x:1386,y:861,t:1527876790612};\\\", \\\"{x:1405,y:861,t:1527876790628};\\\", \\\"{x:1425,y:861,t:1527876790645};\\\", \\\"{x:1442,y:861,t:1527876790662};\\\", \\\"{x:1461,y:861,t:1527876790678};\\\", \\\"{x:1474,y:861,t:1527876790695};\\\", \\\"{x:1484,y:861,t:1527876790712};\\\", \\\"{x:1494,y:861,t:1527876790729};\\\", \\\"{x:1504,y:861,t:1527876790746};\\\", \\\"{x:1516,y:861,t:1527876790761};\\\", \\\"{x:1537,y:861,t:1527876790779};\\\", \\\"{x:1551,y:861,t:1527876790796};\\\", \\\"{x:1562,y:861,t:1527876790812};\\\", \\\"{x:1569,y:860,t:1527876790829};\\\", \\\"{x:1577,y:859,t:1527876790845};\\\", \\\"{x:1587,y:855,t:1527876790862};\\\", \\\"{x:1604,y:852,t:1527876790878};\\\", \\\"{x:1626,y:850,t:1527876790895};\\\", \\\"{x:1648,y:843,t:1527876790911};\\\", \\\"{x:1666,y:841,t:1527876790928};\\\", \\\"{x:1677,y:839,t:1527876790946};\\\", \\\"{x:1678,y:838,t:1527876790962};\\\", \\\"{x:1681,y:836,t:1527876791002};\\\", \\\"{x:1685,y:831,t:1527876791012};\\\", \\\"{x:1691,y:820,t:1527876791029};\\\", \\\"{x:1696,y:807,t:1527876791045};\\\", \\\"{x:1698,y:795,t:1527876791062};\\\", \\\"{x:1700,y:786,t:1527876791079};\\\", \\\"{x:1701,y:778,t:1527876791096};\\\", \\\"{x:1701,y:770,t:1527876791112};\\\", \\\"{x:1701,y:761,t:1527876791129};\\\", \\\"{x:1701,y:750,t:1527876791145};\\\", \\\"{x:1698,y:738,t:1527876791161};\\\", \\\"{x:1686,y:721,t:1527876791178};\\\", \\\"{x:1683,y:715,t:1527876791195};\\\", \\\"{x:1680,y:713,t:1527876791211};\\\", \\\"{x:1675,y:709,t:1527876791229};\\\", \\\"{x:1669,y:704,t:1527876791245};\\\", \\\"{x:1664,y:700,t:1527876791261};\\\", \\\"{x:1654,y:691,t:1527876791279};\\\", \\\"{x:1648,y:682,t:1527876791295};\\\", \\\"{x:1642,y:674,t:1527876791311};\\\", \\\"{x:1636,y:668,t:1527876791328};\\\", \\\"{x:1628,y:663,t:1527876791346};\\\", \\\"{x:1623,y:660,t:1527876791361};\\\", \\\"{x:1619,y:655,t:1527876791379};\\\", \\\"{x:1616,y:651,t:1527876791395};\\\", \\\"{x:1613,y:642,t:1527876791412};\\\", \\\"{x:1608,y:628,t:1527876791428};\\\", \\\"{x:1601,y:610,t:1527876791445};\\\", \\\"{x:1591,y:594,t:1527876791461};\\\", \\\"{x:1586,y:586,t:1527876791479};\\\", \\\"{x:1584,y:583,t:1527876791496};\\\", \\\"{x:1583,y:579,t:1527876791511};\\\", \\\"{x:1582,y:571,t:1527876791529};\\\", \\\"{x:1579,y:559,t:1527876791546};\\\", \\\"{x:1577,y:549,t:1527876791561};\\\", \\\"{x:1574,y:536,t:1527876791579};\\\", \\\"{x:1574,y:533,t:1527876791596};\\\", \\\"{x:1574,y:530,t:1527876791612};\\\", \\\"{x:1574,y:526,t:1527876791628};\\\", \\\"{x:1574,y:524,t:1527876791645};\\\", \\\"{x:1574,y:522,t:1527876791662};\\\", \\\"{x:1574,y:519,t:1527876791679};\\\", \\\"{x:1573,y:515,t:1527876791696};\\\", \\\"{x:1572,y:513,t:1527876791712};\\\", \\\"{x:1572,y:511,t:1527876791729};\\\", \\\"{x:1570,y:506,t:1527876791746};\\\", \\\"{x:1569,y:504,t:1527876791761};\\\", \\\"{x:1567,y:500,t:1527876791778};\\\", \\\"{x:1566,y:498,t:1527876791796};\\\", \\\"{x:1564,y:495,t:1527876791812};\\\", \\\"{x:1563,y:493,t:1527876791829};\\\", \\\"{x:1563,y:492,t:1527876791846};\\\", \\\"{x:1561,y:489,t:1527876791862};\\\", \\\"{x:1558,y:486,t:1527876791879};\\\", \\\"{x:1553,y:484,t:1527876791895};\\\", \\\"{x:1548,y:481,t:1527876791912};\\\", \\\"{x:1544,y:479,t:1527876791928};\\\", \\\"{x:1541,y:477,t:1527876791945};\\\", \\\"{x:1537,y:475,t:1527876791961};\\\", \\\"{x:1523,y:469,t:1527876791978};\\\", \\\"{x:1512,y:467,t:1527876791995};\\\", \\\"{x:1501,y:464,t:1527876792012};\\\", \\\"{x:1492,y:462,t:1527876792028};\\\", \\\"{x:1484,y:461,t:1527876792045};\\\", \\\"{x:1474,y:460,t:1527876792062};\\\", \\\"{x:1470,y:460,t:1527876792079};\\\", \\\"{x:1467,y:460,t:1527876792096};\\\", \\\"{x:1464,y:460,t:1527876792112};\\\", \\\"{x:1462,y:460,t:1527876792128};\\\", \\\"{x:1458,y:461,t:1527876792145};\\\", \\\"{x:1452,y:463,t:1527876792161};\\\", \\\"{x:1448,y:465,t:1527876792178};\\\", \\\"{x:1443,y:467,t:1527876792195};\\\", \\\"{x:1437,y:469,t:1527876792211};\\\", \\\"{x:1433,y:472,t:1527876792229};\\\", \\\"{x:1424,y:475,t:1527876792245};\\\", \\\"{x:1420,y:477,t:1527876792261};\\\", \\\"{x:1416,y:479,t:1527876792279};\\\", \\\"{x:1414,y:480,t:1527876792295};\\\", \\\"{x:1410,y:483,t:1527876792312};\\\", \\\"{x:1407,y:488,t:1527876792328};\\\", \\\"{x:1399,y:497,t:1527876792345};\\\", \\\"{x:1391,y:505,t:1527876792361};\\\", \\\"{x:1381,y:515,t:1527876792378};\\\", \\\"{x:1378,y:521,t:1527876792396};\\\", \\\"{x:1376,y:528,t:1527876792411};\\\", \\\"{x:1372,y:543,t:1527876792428};\\\", \\\"{x:1368,y:562,t:1527876792445};\\\", \\\"{x:1365,y:586,t:1527876792462};\\\", \\\"{x:1363,y:621,t:1527876792479};\\\", \\\"{x:1363,y:654,t:1527876792496};\\\", \\\"{x:1364,y:675,t:1527876792511};\\\", \\\"{x:1367,y:684,t:1527876792529};\\\", \\\"{x:1368,y:693,t:1527876792546};\\\", \\\"{x:1370,y:704,t:1527876792561};\\\", \\\"{x:1371,y:715,t:1527876792578};\\\", \\\"{x:1371,y:718,t:1527876792596};\\\", \\\"{x:1371,y:719,t:1527876792612};\\\", \\\"{x:1371,y:720,t:1527876792628};\\\", \\\"{x:1369,y:720,t:1527876792707};\\\", \\\"{x:1366,y:720,t:1527876792715};\\\", \\\"{x:1361,y:719,t:1527876792729};\\\", \\\"{x:1355,y:714,t:1527876792745};\\\", \\\"{x:1351,y:710,t:1527876792762};\\\", \\\"{x:1345,y:705,t:1527876792779};\\\", \\\"{x:1343,y:704,t:1527876792795};\\\", \\\"{x:1343,y:703,t:1527876792812};\\\", \\\"{x:1343,y:701,t:1527876794467};\\\", \\\"{x:1343,y:698,t:1527876794479};\\\", \\\"{x:1345,y:693,t:1527876794496};\\\", \\\"{x:1347,y:689,t:1527876794513};\\\", \\\"{x:1347,y:688,t:1527876794528};\\\", \\\"{x:1347,y:687,t:1527876794546};\\\", \\\"{x:1348,y:686,t:1527876794595};\\\", \\\"{x:1348,y:685,t:1527876794619};\\\", \\\"{x:1348,y:683,t:1527876794629};\\\", \\\"{x:1349,y:681,t:1527876794646};\\\", \\\"{x:1349,y:680,t:1527876794663};\\\", \\\"{x:1350,y:678,t:1527876794679};\\\", \\\"{x:1350,y:677,t:1527876794696};\\\", \\\"{x:1351,y:674,t:1527876794713};\\\", \\\"{x:1352,y:671,t:1527876794729};\\\", \\\"{x:1353,y:667,t:1527876794746};\\\", \\\"{x:1356,y:661,t:1527876794762};\\\", \\\"{x:1356,y:659,t:1527876794778};\\\", \\\"{x:1357,y:658,t:1527876794795};\\\", \\\"{x:1358,y:657,t:1527876794874};\\\", \\\"{x:1358,y:656,t:1527876794890};\\\", \\\"{x:1359,y:656,t:1527876794899};\\\", \\\"{x:1359,y:655,t:1527876794914};\\\", \\\"{x:1359,y:654,t:1527876794929};\\\", \\\"{x:1359,y:653,t:1527876794946};\\\", \\\"{x:1360,y:652,t:1527876794987};\\\", \\\"{x:1360,y:651,t:1527876795035};\\\", \\\"{x:1361,y:650,t:1527876795050};\\\", \\\"{x:1361,y:649,t:1527876795063};\\\", \\\"{x:1362,y:646,t:1527876795078};\\\", \\\"{x:1362,y:643,t:1527876795096};\\\", \\\"{x:1363,y:640,t:1527876795112};\\\", \\\"{x:1363,y:638,t:1527876795129};\\\", \\\"{x:1363,y:636,t:1527876795145};\\\", \\\"{x:1365,y:632,t:1527876795163};\\\", \\\"{x:1365,y:628,t:1527876795178};\\\", \\\"{x:1365,y:622,t:1527876795195};\\\", \\\"{x:1366,y:613,t:1527876795213};\\\", \\\"{x:1369,y:603,t:1527876795229};\\\", \\\"{x:1370,y:595,t:1527876795246};\\\", \\\"{x:1372,y:589,t:1527876795262};\\\", \\\"{x:1373,y:586,t:1527876795278};\\\", \\\"{x:1374,y:582,t:1527876795296};\\\", \\\"{x:1375,y:579,t:1527876795312};\\\", \\\"{x:1377,y:575,t:1527876795329};\\\", \\\"{x:1377,y:572,t:1527876795346};\\\", \\\"{x:1379,y:568,t:1527876795363};\\\", \\\"{x:1380,y:567,t:1527876795379};\\\", \\\"{x:1381,y:566,t:1527876795396};\\\", \\\"{x:1382,y:566,t:1527876795414};\\\", \\\"{x:1384,y:564,t:1527876795429};\\\", \\\"{x:1386,y:562,t:1527876795446};\\\", \\\"{x:1387,y:562,t:1527876795462};\\\", \\\"{x:1390,y:561,t:1527876795479};\\\", \\\"{x:1392,y:560,t:1527876795496};\\\", \\\"{x:1396,y:558,t:1527876795513};\\\", \\\"{x:1399,y:558,t:1527876795529};\\\", \\\"{x:1404,y:558,t:1527876795546};\\\", \\\"{x:1414,y:558,t:1527876795563};\\\", \\\"{x:1416,y:558,t:1527876795579};\\\", \\\"{x:1414,y:560,t:1527876796266};\\\", \\\"{x:1407,y:563,t:1527876796279};\\\", \\\"{x:1386,y:571,t:1527876796296};\\\", \\\"{x:1354,y:588,t:1527876796313};\\\", \\\"{x:1272,y:618,t:1527876796329};\\\", \\\"{x:1214,y:633,t:1527876796346};\\\", \\\"{x:1140,y:642,t:1527876796362};\\\", \\\"{x:1093,y:648,t:1527876796379};\\\", \\\"{x:1024,y:648,t:1527876796396};\\\", \\\"{x:951,y:648,t:1527876796413};\\\", \\\"{x:893,y:648,t:1527876796429};\\\", \\\"{x:842,y:648,t:1527876796445};\\\", \\\"{x:795,y:648,t:1527876796463};\\\", \\\"{x:755,y:648,t:1527876796479};\\\", \\\"{x:719,y:648,t:1527876796496};\\\", \\\"{x:680,y:648,t:1527876796513};\\\", \\\"{x:646,y:648,t:1527876796529};\\\", \\\"{x:614,y:645,t:1527876796546};\\\", \\\"{x:591,y:637,t:1527876796562};\\\", \\\"{x:579,y:634,t:1527876796579};\\\", \\\"{x:562,y:630,t:1527876796596};\\\", \\\"{x:540,y:623,t:1527876796613};\\\", \\\"{x:521,y:620,t:1527876796634};\\\", \\\"{x:493,y:614,t:1527876796651};\\\", \\\"{x:482,y:613,t:1527876796666};\\\", \\\"{x:471,y:611,t:1527876796683};\\\", \\\"{x:464,y:611,t:1527876796701};\\\", \\\"{x:459,y:611,t:1527876796718};\\\", \\\"{x:451,y:609,t:1527876796734};\\\", \\\"{x:444,y:608,t:1527876796751};\\\", \\\"{x:439,y:606,t:1527876796768};\\\", \\\"{x:435,y:602,t:1527876796784};\\\", \\\"{x:427,y:596,t:1527876796801};\\\", \\\"{x:414,y:584,t:1527876796818};\\\", \\\"{x:400,y:572,t:1527876796834};\\\", \\\"{x:383,y:564,t:1527876796851};\\\", \\\"{x:377,y:562,t:1527876796868};\\\", \\\"{x:370,y:562,t:1527876796884};\\\", \\\"{x:364,y:561,t:1527876796901};\\\", \\\"{x:351,y:561,t:1527876796917};\\\", \\\"{x:334,y:561,t:1527876796933};\\\", \\\"{x:307,y:561,t:1527876796950};\\\", \\\"{x:279,y:561,t:1527876796968};\\\", \\\"{x:256,y:561,t:1527876796984};\\\", \\\"{x:236,y:561,t:1527876797001};\\\", \\\"{x:217,y:561,t:1527876797018};\\\", \\\"{x:199,y:561,t:1527876797034};\\\", \\\"{x:185,y:561,t:1527876797050};\\\", \\\"{x:175,y:561,t:1527876797068};\\\", \\\"{x:169,y:561,t:1527876797084};\\\", \\\"{x:165,y:561,t:1527876797101};\\\", \\\"{x:162,y:561,t:1527876797118};\\\", \\\"{x:159,y:561,t:1527876797134};\\\", \\\"{x:158,y:561,t:1527876797210};\\\", \\\"{x:157,y:561,t:1527876797219};\\\", \\\"{x:156,y:561,t:1527876797234};\\\", \\\"{x:154,y:561,t:1527876797250};\\\", \\\"{x:153,y:562,t:1527876797268};\\\", \\\"{x:152,y:569,t:1527876797285};\\\", \\\"{x:158,y:580,t:1527876797300};\\\", \\\"{x:165,y:590,t:1527876797318};\\\", \\\"{x:174,y:603,t:1527876797336};\\\", \\\"{x:184,y:618,t:1527876797351};\\\", \\\"{x:197,y:632,t:1527876797368};\\\", \\\"{x:209,y:644,t:1527876797385};\\\", \\\"{x:223,y:651,t:1527876797400};\\\", \\\"{x:241,y:655,t:1527876797418};\\\", \\\"{x:267,y:655,t:1527876797435};\\\", \\\"{x:274,y:655,t:1527876797452};\\\", \\\"{x:283,y:653,t:1527876797467};\\\", \\\"{x:289,y:652,t:1527876797485};\\\", \\\"{x:297,y:649,t:1527876797501};\\\", \\\"{x:302,y:647,t:1527876797518};\\\", \\\"{x:312,y:642,t:1527876797535};\\\", \\\"{x:328,y:634,t:1527876797551};\\\", \\\"{x:343,y:625,t:1527876797568};\\\", \\\"{x:361,y:617,t:1527876797584};\\\", \\\"{x:378,y:610,t:1527876797601};\\\", \\\"{x:395,y:603,t:1527876797618};\\\", \\\"{x:419,y:594,t:1527876797635};\\\", \\\"{x:437,y:589,t:1527876797652};\\\", \\\"{x:450,y:584,t:1527876797668};\\\", \\\"{x:463,y:579,t:1527876797685};\\\", \\\"{x:474,y:575,t:1527876797702};\\\", \\\"{x:483,y:571,t:1527876797718};\\\", \\\"{x:493,y:569,t:1527876797735};\\\", \\\"{x:509,y:566,t:1527876797752};\\\", \\\"{x:529,y:565,t:1527876797768};\\\", \\\"{x:550,y:565,t:1527876797785};\\\", \\\"{x:573,y:565,t:1527876797802};\\\", \\\"{x:596,y:565,t:1527876797818};\\\", \\\"{x:626,y:565,t:1527876797834};\\\", \\\"{x:640,y:564,t:1527876797852};\\\", \\\"{x:648,y:564,t:1527876797868};\\\", \\\"{x:658,y:564,t:1527876797884};\\\", \\\"{x:666,y:564,t:1527876797902};\\\", \\\"{x:676,y:564,t:1527876797918};\\\", \\\"{x:686,y:564,t:1527876797935};\\\", \\\"{x:701,y:564,t:1527876797951};\\\", \\\"{x:715,y:567,t:1527876797968};\\\", \\\"{x:723,y:569,t:1527876797984};\\\", \\\"{x:734,y:573,t:1527876798003};\\\", \\\"{x:747,y:579,t:1527876798017};\\\", \\\"{x:759,y:583,t:1527876798035};\\\", \\\"{x:764,y:585,t:1527876798051};\\\", \\\"{x:766,y:584,t:1527876798091};\\\", \\\"{x:769,y:581,t:1527876798101};\\\", \\\"{x:774,y:574,t:1527876798118};\\\", \\\"{x:782,y:562,t:1527876798135};\\\", \\\"{x:791,y:548,t:1527876798153};\\\", \\\"{x:797,y:540,t:1527876798169};\\\", \\\"{x:799,y:535,t:1527876798184};\\\", \\\"{x:801,y:535,t:1527876798275};\\\", \\\"{x:802,y:535,t:1527876798285};\\\", \\\"{x:806,y:536,t:1527876798302};\\\", \\\"{x:809,y:537,t:1527876798319};\\\", \\\"{x:810,y:538,t:1527876798335};\\\", \\\"{x:811,y:538,t:1527876798352};\\\", \\\"{x:812,y:538,t:1527876798369};\\\", \\\"{x:815,y:538,t:1527876798385};\\\", \\\"{x:816,y:538,t:1527876798402};\\\", \\\"{x:822,y:537,t:1527876798418};\\\", \\\"{x:828,y:535,t:1527876798435};\\\", \\\"{x:835,y:531,t:1527876798452};\\\", \\\"{x:838,y:531,t:1527876798469};\\\", \\\"{x:840,y:529,t:1527876798485};\\\", \\\"{x:841,y:529,t:1527876798502};\\\", \\\"{x:838,y:530,t:1527876798755};\\\", \\\"{x:837,y:530,t:1527876798769};\\\", \\\"{x:832,y:533,t:1527876798786};\\\", \\\"{x:823,y:544,t:1527876798802};\\\", \\\"{x:800,y:565,t:1527876798819};\\\", \\\"{x:781,y:580,t:1527876798836};\\\", \\\"{x:766,y:592,t:1527876798852};\\\", \\\"{x:752,y:601,t:1527876798869};\\\", \\\"{x:739,y:608,t:1527876798886};\\\", \\\"{x:728,y:614,t:1527876798902};\\\", \\\"{x:716,y:619,t:1527876798920};\\\", \\\"{x:701,y:625,t:1527876798936};\\\", \\\"{x:687,y:633,t:1527876798952};\\\", \\\"{x:668,y:644,t:1527876798969};\\\", \\\"{x:650,y:654,t:1527876798986};\\\", \\\"{x:623,y:666,t:1527876799002};\\\", \\\"{x:599,y:676,t:1527876799019};\\\", \\\"{x:577,y:683,t:1527876799036};\\\", \\\"{x:556,y:688,t:1527876799053};\\\", \\\"{x:543,y:690,t:1527876799069};\\\", \\\"{x:537,y:693,t:1527876799086};\\\", \\\"{x:535,y:693,t:1527876799103};\\\", \\\"{x:530,y:697,t:1527876799119};\\\", \\\"{x:527,y:701,t:1527876799136};\\\", \\\"{x:524,y:705,t:1527876799153};\\\", \\\"{x:521,y:712,t:1527876799169};\\\", \\\"{x:517,y:717,t:1527876799186};\\\", \\\"{x:516,y:722,t:1527876799203};\\\", \\\"{x:515,y:723,t:1527876799219};\\\", \\\"{x:515,y:725,t:1527876799236};\\\", \\\"{x:514,y:729,t:1527876799252};\\\", \\\"{x:514,y:734,t:1527876799268};\\\", \\\"{x:514,y:737,t:1527876799286};\\\", \\\"{x:514,y:738,t:1527876799303};\\\" ] }, { \\\"rt\\\": 10294, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 384655, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"DJRH1\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-09 AM-02 PM-Z -02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:514,y:750,t:1527876802027};\\\", \\\"{x:512,y:754,t:1527876802037};\\\", \\\"{x:514,y:754,t:1527876803026};\\\", \\\"{x:518,y:755,t:1527876803036};\\\", \\\"{x:533,y:764,t:1527876803053};\\\", \\\"{x:558,y:778,t:1527876803072};\\\", \\\"{x:603,y:802,t:1527876803089};\\\", \\\"{x:650,y:822,t:1527876803106};\\\", \\\"{x:697,y:841,t:1527876803122};\\\", \\\"{x:766,y:865,t:1527876803139};\\\", \\\"{x:800,y:881,t:1527876803156};\\\", \\\"{x:834,y:892,t:1527876803172};\\\", \\\"{x:867,y:902,t:1527876803189};\\\", \\\"{x:893,y:908,t:1527876803206};\\\", \\\"{x:922,y:915,t:1527876803223};\\\", \\\"{x:959,y:926,t:1527876803239};\\\", \\\"{x:1009,y:942,t:1527876803256};\\\", \\\"{x:1070,y:959,t:1527876803273};\\\", \\\"{x:1145,y:979,t:1527876803290};\\\", \\\"{x:1214,y:998,t:1527876803306};\\\", \\\"{x:1298,y:1021,t:1527876803322};\\\", \\\"{x:1327,y:1032,t:1527876803339};\\\", \\\"{x:1346,y:1040,t:1527876803356};\\\", \\\"{x:1347,y:1042,t:1527876803373};\\\", \\\"{x:1347,y:1043,t:1527876803389};\\\", \\\"{x:1348,y:1043,t:1527876803883};\\\", \\\"{x:1349,y:1043,t:1527876803891};\\\", \\\"{x:1355,y:1042,t:1527876803907};\\\", \\\"{x:1372,y:1038,t:1527876803923};\\\", \\\"{x:1393,y:1034,t:1527876803941};\\\", \\\"{x:1410,y:1026,t:1527876803957};\\\", \\\"{x:1429,y:1015,t:1527876803973};\\\", \\\"{x:1449,y:1002,t:1527876803990};\\\", \\\"{x:1470,y:983,t:1527876804008};\\\", \\\"{x:1499,y:953,t:1527876804024};\\\", \\\"{x:1535,y:907,t:1527876804041};\\\", \\\"{x:1563,y:862,t:1527876804057};\\\", \\\"{x:1576,y:832,t:1527876804073};\\\", \\\"{x:1580,y:810,t:1527876804090};\\\", \\\"{x:1581,y:782,t:1527876804107};\\\", \\\"{x:1576,y:765,t:1527876804123};\\\", \\\"{x:1567,y:752,t:1527876804140};\\\", \\\"{x:1562,y:744,t:1527876804157};\\\", \\\"{x:1561,y:740,t:1527876804175};\\\", \\\"{x:1561,y:732,t:1527876804190};\\\", \\\"{x:1558,y:719,t:1527876804208};\\\", \\\"{x:1558,y:701,t:1527876804225};\\\", \\\"{x:1558,y:691,t:1527876804240};\\\", \\\"{x:1558,y:690,t:1527876804257};\\\", \\\"{x:1558,y:689,t:1527876804299};\\\", \\\"{x:1563,y:689,t:1527876804307};\\\", \\\"{x:1578,y:689,t:1527876804324};\\\", \\\"{x:1592,y:689,t:1527876804340};\\\", \\\"{x:1608,y:689,t:1527876804357};\\\", \\\"{x:1619,y:689,t:1527876804375};\\\", \\\"{x:1624,y:688,t:1527876804390};\\\", \\\"{x:1621,y:688,t:1527876804531};\\\", \\\"{x:1620,y:689,t:1527876804541};\\\", \\\"{x:1615,y:696,t:1527876804558};\\\", \\\"{x:1611,y:706,t:1527876804575};\\\", \\\"{x:1603,y:717,t:1527876804591};\\\", \\\"{x:1598,y:727,t:1527876804608};\\\", \\\"{x:1593,y:735,t:1527876804624};\\\", \\\"{x:1588,y:743,t:1527876804641};\\\", \\\"{x:1584,y:750,t:1527876804657};\\\", \\\"{x:1580,y:759,t:1527876804674};\\\", \\\"{x:1574,y:774,t:1527876804691};\\\", \\\"{x:1569,y:784,t:1527876804707};\\\", \\\"{x:1565,y:790,t:1527876804724};\\\", \\\"{x:1562,y:796,t:1527876804741};\\\", \\\"{x:1560,y:802,t:1527876804757};\\\", \\\"{x:1556,y:813,t:1527876804774};\\\", \\\"{x:1551,y:824,t:1527876804791};\\\", \\\"{x:1546,y:833,t:1527876804808};\\\", \\\"{x:1541,y:845,t:1527876804824};\\\", \\\"{x:1535,y:860,t:1527876804841};\\\", \\\"{x:1528,y:877,t:1527876804858};\\\", \\\"{x:1524,y:893,t:1527876804874};\\\", \\\"{x:1514,y:913,t:1527876804891};\\\", \\\"{x:1506,y:928,t:1527876804908};\\\", \\\"{x:1495,y:943,t:1527876804924};\\\", \\\"{x:1488,y:954,t:1527876804941};\\\", \\\"{x:1480,y:967,t:1527876804959};\\\", \\\"{x:1477,y:972,t:1527876804974};\\\", \\\"{x:1476,y:974,t:1527876804991};\\\", \\\"{x:1475,y:975,t:1527876805008};\\\", \\\"{x:1475,y:974,t:1527876805186};\\\", \\\"{x:1476,y:968,t:1527876805194};\\\", \\\"{x:1478,y:962,t:1527876805208};\\\", \\\"{x:1482,y:955,t:1527876805225};\\\", \\\"{x:1483,y:951,t:1527876805241};\\\", \\\"{x:1485,y:948,t:1527876805258};\\\", \\\"{x:1485,y:947,t:1527876805275};\\\", \\\"{x:1485,y:946,t:1527876805330};\\\", \\\"{x:1485,y:945,t:1527876805386};\\\", \\\"{x:1485,y:944,t:1527876805394};\\\", \\\"{x:1485,y:943,t:1527876805408};\\\", \\\"{x:1483,y:941,t:1527876805425};\\\", \\\"{x:1479,y:939,t:1527876805443};\\\", \\\"{x:1471,y:928,t:1527876805458};\\\", \\\"{x:1458,y:914,t:1527876805475};\\\", \\\"{x:1445,y:900,t:1527876805493};\\\", \\\"{x:1428,y:887,t:1527876805508};\\\", \\\"{x:1412,y:873,t:1527876805525};\\\", \\\"{x:1395,y:855,t:1527876805542};\\\", \\\"{x:1379,y:838,t:1527876805559};\\\", \\\"{x:1365,y:818,t:1527876805576};\\\", \\\"{x:1352,y:797,t:1527876805592};\\\", \\\"{x:1347,y:778,t:1527876805608};\\\", \\\"{x:1342,y:759,t:1527876805625};\\\", \\\"{x:1340,y:738,t:1527876805643};\\\", \\\"{x:1339,y:733,t:1527876805659};\\\", \\\"{x:1336,y:715,t:1527876805675};\\\", \\\"{x:1335,y:705,t:1527876805692};\\\", \\\"{x:1333,y:700,t:1527876805708};\\\", \\\"{x:1332,y:694,t:1527876805725};\\\", \\\"{x:1331,y:688,t:1527876805742};\\\", \\\"{x:1328,y:681,t:1527876805760};\\\", \\\"{x:1324,y:673,t:1527876805775};\\\", \\\"{x:1318,y:662,t:1527876805792};\\\", \\\"{x:1310,y:651,t:1527876805810};\\\", \\\"{x:1304,y:641,t:1527876805826};\\\", \\\"{x:1298,y:620,t:1527876805842};\\\", \\\"{x:1295,y:604,t:1527876805859};\\\", \\\"{x:1293,y:597,t:1527876805876};\\\", \\\"{x:1288,y:587,t:1527876805892};\\\", \\\"{x:1285,y:583,t:1527876805909};\\\", \\\"{x:1283,y:583,t:1527876806026};\\\", \\\"{x:1280,y:583,t:1527876806042};\\\", \\\"{x:1272,y:584,t:1527876806059};\\\", \\\"{x:1251,y:590,t:1527876806075};\\\", \\\"{x:1212,y:600,t:1527876806092};\\\", \\\"{x:1171,y:611,t:1527876806109};\\\", \\\"{x:1109,y:620,t:1527876806127};\\\", \\\"{x:1031,y:631,t:1527876806142};\\\", \\\"{x:972,y:640,t:1527876806159};\\\", \\\"{x:915,y:644,t:1527876806176};\\\", \\\"{x:878,y:645,t:1527876806192};\\\", \\\"{x:858,y:646,t:1527876806209};\\\", \\\"{x:843,y:649,t:1527876806226};\\\", \\\"{x:839,y:650,t:1527876806243};\\\", \\\"{x:835,y:651,t:1527876806260};\\\", \\\"{x:828,y:653,t:1527876806276};\\\", \\\"{x:818,y:655,t:1527876806292};\\\", \\\"{x:801,y:655,t:1527876806309};\\\", \\\"{x:777,y:655,t:1527876806326};\\\", \\\"{x:750,y:655,t:1527876806342};\\\", \\\"{x:714,y:651,t:1527876806359};\\\", \\\"{x:680,y:646,t:1527876806376};\\\", \\\"{x:651,y:641,t:1527876806394};\\\", \\\"{x:628,y:638,t:1527876806409};\\\", \\\"{x:594,y:633,t:1527876806427};\\\", \\\"{x:571,y:629,t:1527876806444};\\\", \\\"{x:558,y:628,t:1527876806459};\\\", \\\"{x:551,y:624,t:1527876806476};\\\", \\\"{x:545,y:622,t:1527876806491};\\\", \\\"{x:540,y:621,t:1527876806509};\\\", \\\"{x:535,y:619,t:1527876806526};\\\", \\\"{x:529,y:618,t:1527876806541};\\\", \\\"{x:520,y:616,t:1527876806558};\\\", \\\"{x:509,y:614,t:1527876806575};\\\", \\\"{x:497,y:611,t:1527876806593};\\\", \\\"{x:488,y:610,t:1527876806608};\\\", \\\"{x:479,y:609,t:1527876806625};\\\", \\\"{x:465,y:607,t:1527876806643};\\\", \\\"{x:455,y:607,t:1527876806658};\\\", \\\"{x:443,y:607,t:1527876806675};\\\", \\\"{x:434,y:607,t:1527876806692};\\\", \\\"{x:424,y:607,t:1527876806708};\\\", \\\"{x:417,y:607,t:1527876806726};\\\", \\\"{x:409,y:606,t:1527876806742};\\\", \\\"{x:400,y:606,t:1527876806759};\\\", \\\"{x:390,y:605,t:1527876806775};\\\", \\\"{x:382,y:602,t:1527876806792};\\\", \\\"{x:374,y:601,t:1527876806808};\\\", \\\"{x:365,y:600,t:1527876806826};\\\", \\\"{x:351,y:597,t:1527876806842};\\\", \\\"{x:339,y:593,t:1527876806859};\\\", \\\"{x:324,y:589,t:1527876806875};\\\", \\\"{x:311,y:588,t:1527876806892};\\\", \\\"{x:296,y:586,t:1527876806909};\\\", \\\"{x:287,y:583,t:1527876806925};\\\", \\\"{x:281,y:582,t:1527876806942};\\\", \\\"{x:271,y:581,t:1527876806960};\\\", \\\"{x:258,y:579,t:1527876806976};\\\", \\\"{x:247,y:577,t:1527876806992};\\\", \\\"{x:237,y:576,t:1527876807009};\\\", \\\"{x:228,y:574,t:1527876807025};\\\", \\\"{x:219,y:574,t:1527876807043};\\\", \\\"{x:213,y:573,t:1527876807060};\\\", \\\"{x:209,y:572,t:1527876807075};\\\", \\\"{x:207,y:572,t:1527876807092};\\\", \\\"{x:205,y:572,t:1527876807109};\\\", \\\"{x:202,y:572,t:1527876807125};\\\", \\\"{x:198,y:572,t:1527876807142};\\\", \\\"{x:196,y:572,t:1527876807160};\\\", \\\"{x:194,y:572,t:1527876807175};\\\", \\\"{x:193,y:572,t:1527876807192};\\\", \\\"{x:192,y:572,t:1527876807209};\\\", \\\"{x:190,y:572,t:1527876807225};\\\", \\\"{x:185,y:574,t:1527876807243};\\\", \\\"{x:180,y:578,t:1527876807259};\\\", \\\"{x:177,y:581,t:1527876807276};\\\", \\\"{x:174,y:586,t:1527876807292};\\\", \\\"{x:170,y:593,t:1527876807310};\\\", \\\"{x:168,y:598,t:1527876807327};\\\", \\\"{x:165,y:609,t:1527876807343};\\\", \\\"{x:165,y:614,t:1527876807359};\\\", \\\"{x:164,y:617,t:1527876807376};\\\", \\\"{x:164,y:621,t:1527876807392};\\\", \\\"{x:164,y:625,t:1527876807409};\\\", \\\"{x:164,y:628,t:1527876807427};\\\", \\\"{x:166,y:632,t:1527876807443};\\\", \\\"{x:169,y:636,t:1527876807459};\\\", \\\"{x:173,y:642,t:1527876807476};\\\", \\\"{x:177,y:651,t:1527876807492};\\\", \\\"{x:180,y:658,t:1527876807510};\\\", \\\"{x:183,y:665,t:1527876807526};\\\", \\\"{x:184,y:666,t:1527876807543};\\\", \\\"{x:185,y:666,t:1527876807560};\\\", \\\"{x:187,y:666,t:1527876807586};\\\", \\\"{x:191,y:666,t:1527876807594};\\\", \\\"{x:197,y:666,t:1527876807609};\\\", \\\"{x:230,y:666,t:1527876807626};\\\", \\\"{x:254,y:666,t:1527876807643};\\\", \\\"{x:279,y:669,t:1527876807659};\\\", \\\"{x:295,y:670,t:1527876807676};\\\", \\\"{x:308,y:670,t:1527876807693};\\\", \\\"{x:315,y:670,t:1527876807709};\\\", \\\"{x:322,y:670,t:1527876807726};\\\", \\\"{x:328,y:670,t:1527876807744};\\\", \\\"{x:333,y:669,t:1527876807759};\\\", \\\"{x:336,y:668,t:1527876807777};\\\", \\\"{x:338,y:666,t:1527876807793};\\\", \\\"{x:340,y:664,t:1527876807810};\\\", \\\"{x:343,y:657,t:1527876807827};\\\", \\\"{x:346,y:649,t:1527876807843};\\\", \\\"{x:349,y:640,t:1527876807859};\\\", \\\"{x:353,y:624,t:1527876807877};\\\", \\\"{x:353,y:608,t:1527876807892};\\\", \\\"{x:353,y:589,t:1527876807910};\\\", \\\"{x:353,y:567,t:1527876807926};\\\", \\\"{x:352,y:550,t:1527876807944};\\\", \\\"{x:352,y:534,t:1527876807959};\\\", \\\"{x:354,y:517,t:1527876807977};\\\", \\\"{x:356,y:502,t:1527876807993};\\\", \\\"{x:356,y:488,t:1527876808010};\\\", \\\"{x:356,y:477,t:1527876808027};\\\", \\\"{x:356,y:474,t:1527876808044};\\\", \\\"{x:357,y:472,t:1527876808059};\\\", \\\"{x:358,y:471,t:1527876808077};\\\", \\\"{x:364,y:468,t:1527876808093};\\\", \\\"{x:376,y:463,t:1527876808110};\\\", \\\"{x:392,y:461,t:1527876808126};\\\", \\\"{x:416,y:458,t:1527876808144};\\\", \\\"{x:441,y:458,t:1527876808160};\\\", \\\"{x:470,y:458,t:1527876808176};\\\", \\\"{x:497,y:459,t:1527876808193};\\\", \\\"{x:530,y:466,t:1527876808210};\\\", \\\"{x:554,y:470,t:1527876808227};\\\", \\\"{x:570,y:472,t:1527876808244};\\\", \\\"{x:577,y:473,t:1527876808260};\\\", \\\"{x:581,y:474,t:1527876808276};\\\", \\\"{x:582,y:475,t:1527876808293};\\\", \\\"{x:583,y:475,t:1527876808310};\\\", \\\"{x:585,y:477,t:1527876808327};\\\", \\\"{x:594,y:486,t:1527876808344};\\\", \\\"{x:603,y:497,t:1527876808361};\\\", \\\"{x:614,y:507,t:1527876808376};\\\", \\\"{x:621,y:515,t:1527876808394};\\\", \\\"{x:624,y:520,t:1527876808410};\\\", \\\"{x:625,y:523,t:1527876808427};\\\", \\\"{x:625,y:527,t:1527876808444};\\\", \\\"{x:625,y:531,t:1527876808461};\\\", \\\"{x:625,y:534,t:1527876808477};\\\", \\\"{x:625,y:537,t:1527876808493};\\\", \\\"{x:625,y:540,t:1527876808511};\\\", \\\"{x:625,y:543,t:1527876808526};\\\", \\\"{x:623,y:549,t:1527876808544};\\\", \\\"{x:623,y:554,t:1527876808562};\\\", \\\"{x:622,y:561,t:1527876808578};\\\", \\\"{x:622,y:572,t:1527876808594};\\\", \\\"{x:622,y:584,t:1527876808610};\\\", \\\"{x:622,y:589,t:1527876808628};\\\", \\\"{x:622,y:593,t:1527876808643};\\\", \\\"{x:622,y:598,t:1527876808661};\\\", \\\"{x:622,y:603,t:1527876808677};\\\", \\\"{x:623,y:605,t:1527876808694};\\\", \\\"{x:624,y:608,t:1527876808710};\\\", \\\"{x:624,y:610,t:1527876808727};\\\", \\\"{x:626,y:613,t:1527876808743};\\\", \\\"{x:627,y:615,t:1527876808760};\\\", \\\"{x:630,y:619,t:1527876808777};\\\", \\\"{x:634,y:622,t:1527876808793};\\\", \\\"{x:645,y:627,t:1527876808810};\\\", \\\"{x:652,y:631,t:1527876808827};\\\", \\\"{x:658,y:631,t:1527876808843};\\\", \\\"{x:661,y:631,t:1527876808860};\\\", \\\"{x:665,y:631,t:1527876808877};\\\", \\\"{x:666,y:631,t:1527876808893};\\\", \\\"{x:667,y:631,t:1527876808911};\\\", \\\"{x:668,y:631,t:1527876808928};\\\", \\\"{x:668,y:630,t:1527876808946};\\\", \\\"{x:668,y:628,t:1527876808960};\\\", \\\"{x:666,y:625,t:1527876808977};\\\", \\\"{x:658,y:615,t:1527876808993};\\\", \\\"{x:636,y:589,t:1527876809011};\\\", \\\"{x:622,y:563,t:1527876809028};\\\", \\\"{x:611,y:544,t:1527876809045};\\\", \\\"{x:602,y:529,t:1527876809060};\\\", \\\"{x:597,y:519,t:1527876809078};\\\", \\\"{x:596,y:515,t:1527876809095};\\\", \\\"{x:596,y:511,t:1527876809111};\\\", \\\"{x:596,y:509,t:1527876809127};\\\", \\\"{x:596,y:508,t:1527876809144};\\\", \\\"{x:597,y:504,t:1527876809161};\\\", \\\"{x:598,y:503,t:1527876809178};\\\", \\\"{x:604,y:499,t:1527876809195};\\\", \\\"{x:605,y:498,t:1527876809211};\\\", \\\"{x:607,y:497,t:1527876809228};\\\", \\\"{x:610,y:497,t:1527876809244};\\\", \\\"{x:612,y:497,t:1527876809262};\\\", \\\"{x:613,y:497,t:1527876809277};\\\", \\\"{x:614,y:497,t:1527876809294};\\\", \\\"{x:615,y:497,t:1527876809731};\\\", \\\"{x:617,y:497,t:1527876809744};\\\", \\\"{x:640,y:503,t:1527876809761};\\\", \\\"{x:687,y:507,t:1527876809777};\\\", \\\"{x:790,y:519,t:1527876809794};\\\", \\\"{x:844,y:527,t:1527876809812};\\\", \\\"{x:873,y:531,t:1527876809827};\\\", \\\"{x:887,y:532,t:1527876809844};\\\", \\\"{x:888,y:533,t:1527876809861};\\\", \\\"{x:889,y:533,t:1527876809939};\\\", \\\"{x:889,y:530,t:1527876810050};\\\", \\\"{x:887,y:524,t:1527876810061};\\\", \\\"{x:881,y:522,t:1527876810079};\\\", \\\"{x:871,y:516,t:1527876810095};\\\", \\\"{x:858,y:511,t:1527876810111};\\\", \\\"{x:847,y:506,t:1527876810129};\\\", \\\"{x:841,y:504,t:1527876810145};\\\", \\\"{x:839,y:503,t:1527876810162};\\\", \\\"{x:836,y:504,t:1527876810506};\\\", \\\"{x:827,y:513,t:1527876810514};\\\", \\\"{x:819,y:519,t:1527876810529};\\\", \\\"{x:804,y:532,t:1527876810546};\\\", \\\"{x:786,y:548,t:1527876810562};\\\", \\\"{x:760,y:570,t:1527876810579};\\\", \\\"{x:741,y:585,t:1527876810596};\\\", \\\"{x:725,y:597,t:1527876810612};\\\", \\\"{x:704,y:612,t:1527876810629};\\\", \\\"{x:687,y:625,t:1527876810645};\\\", \\\"{x:674,y:637,t:1527876810662};\\\", \\\"{x:664,y:645,t:1527876810678};\\\", \\\"{x:654,y:651,t:1527876810696};\\\", \\\"{x:640,y:661,t:1527876810711};\\\", \\\"{x:627,y:669,t:1527876810728};\\\", \\\"{x:607,y:682,t:1527876810745};\\\", \\\"{x:571,y:698,t:1527876810762};\\\", \\\"{x:555,y:703,t:1527876810779};\\\", \\\"{x:542,y:707,t:1527876810795};\\\", \\\"{x:537,y:709,t:1527876810813};\\\", \\\"{x:532,y:713,t:1527876810828};\\\", \\\"{x:529,y:714,t:1527876810845};\\\", \\\"{x:527,y:716,t:1527876810862};\\\", \\\"{x:524,y:717,t:1527876810879};\\\", \\\"{x:522,y:720,t:1527876810896};\\\", \\\"{x:521,y:721,t:1527876810912};\\\", \\\"{x:520,y:723,t:1527876810928};\\\", \\\"{x:519,y:723,t:1527876810962};\\\", \\\"{x:519,y:725,t:1527876810979};\\\", \\\"{x:519,y:728,t:1527876810996};\\\", \\\"{x:519,y:729,t:1527876811012};\\\" ] }, { \\\"rt\\\": 6175, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 392038, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"DJRH1\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-03 PM-03 PM-X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:519,y:730,t:1527876813738};\\\", \\\"{x:523,y:730,t:1527876813748};\\\", \\\"{x:531,y:728,t:1527876813765};\\\", \\\"{x:535,y:726,t:1527876813782};\\\", \\\"{x:539,y:725,t:1527876813797};\\\", \\\"{x:540,y:724,t:1527876813814};\\\", \\\"{x:541,y:724,t:1527876813832};\\\", \\\"{x:542,y:724,t:1527876813848};\\\", \\\"{x:543,y:724,t:1527876813866};\\\", \\\"{x:543,y:723,t:1527876813882};\\\", \\\"{x:544,y:723,t:1527876813898};\\\", \\\"{x:545,y:723,t:1527876813952};\\\", \\\"{x:546,y:722,t:1527876813965};\\\", \\\"{x:549,y:721,t:1527876813981};\\\", \\\"{x:550,y:721,t:1527876814002};\\\", \\\"{x:551,y:720,t:1527876814014};\\\", \\\"{x:552,y:720,t:1527876814042};\\\", \\\"{x:554,y:720,t:1527876814082};\\\", \\\"{x:556,y:718,t:1527876814098};\\\", \\\"{x:567,y:718,t:1527876814115};\\\", \\\"{x:592,y:725,t:1527876814132};\\\", \\\"{x:623,y:734,t:1527876814148};\\\", \\\"{x:659,y:744,t:1527876814164};\\\", \\\"{x:711,y:759,t:1527876814182};\\\", \\\"{x:794,y:780,t:1527876814198};\\\", \\\"{x:869,y:800,t:1527876814214};\\\", \\\"{x:938,y:817,t:1527876814232};\\\", \\\"{x:996,y:834,t:1527876814248};\\\", \\\"{x:1036,y:847,t:1527876814264};\\\", \\\"{x:1067,y:855,t:1527876814282};\\\", \\\"{x:1110,y:867,t:1527876814298};\\\", \\\"{x:1138,y:876,t:1527876814315};\\\", \\\"{x:1162,y:884,t:1527876814332};\\\", \\\"{x:1185,y:890,t:1527876814349};\\\", \\\"{x:1208,y:899,t:1527876814365};\\\", \\\"{x:1238,y:912,t:1527876814382};\\\", \\\"{x:1276,y:926,t:1527876814398};\\\", \\\"{x:1318,y:939,t:1527876814414};\\\", \\\"{x:1352,y:948,t:1527876814431};\\\", \\\"{x:1377,y:955,t:1527876814449};\\\", \\\"{x:1400,y:959,t:1527876814465};\\\", \\\"{x:1421,y:965,t:1527876814481};\\\", \\\"{x:1452,y:969,t:1527876814498};\\\", \\\"{x:1467,y:970,t:1527876814514};\\\", \\\"{x:1473,y:971,t:1527876814532};\\\", \\\"{x:1475,y:971,t:1527876814549};\\\", \\\"{x:1477,y:971,t:1527876814565};\\\", \\\"{x:1481,y:971,t:1527876814581};\\\", \\\"{x:1490,y:971,t:1527876814598};\\\", \\\"{x:1504,y:971,t:1527876814614};\\\", \\\"{x:1517,y:971,t:1527876814631};\\\", \\\"{x:1525,y:971,t:1527876814648};\\\", \\\"{x:1531,y:971,t:1527876814665};\\\", \\\"{x:1537,y:971,t:1527876814682};\\\", \\\"{x:1545,y:971,t:1527876814698};\\\", \\\"{x:1549,y:971,t:1527876814715};\\\", \\\"{x:1552,y:971,t:1527876814731};\\\", \\\"{x:1553,y:971,t:1527876814749};\\\", \\\"{x:1555,y:971,t:1527876814765};\\\", \\\"{x:1557,y:971,t:1527876814782};\\\", \\\"{x:1558,y:971,t:1527876814798};\\\", \\\"{x:1559,y:971,t:1527876815139};\\\", \\\"{x:1558,y:969,t:1527876815148};\\\", \\\"{x:1548,y:963,t:1527876815166};\\\", \\\"{x:1540,y:959,t:1527876815182};\\\", \\\"{x:1528,y:951,t:1527876815199};\\\", \\\"{x:1522,y:947,t:1527876815215};\\\", \\\"{x:1516,y:943,t:1527876815233};\\\", \\\"{x:1514,y:940,t:1527876815249};\\\", \\\"{x:1513,y:938,t:1527876815266};\\\", \\\"{x:1512,y:936,t:1527876815282};\\\", \\\"{x:1510,y:933,t:1527876815299};\\\", \\\"{x:1510,y:932,t:1527876815315};\\\", \\\"{x:1510,y:930,t:1527876815333};\\\", \\\"{x:1509,y:929,t:1527876815349};\\\", \\\"{x:1509,y:928,t:1527876815366};\\\", \\\"{x:1509,y:927,t:1527876815383};\\\", \\\"{x:1509,y:929,t:1527876815499};\\\", \\\"{x:1515,y:937,t:1527876815516};\\\", \\\"{x:1522,y:946,t:1527876815532};\\\", \\\"{x:1526,y:950,t:1527876815548};\\\", \\\"{x:1531,y:957,t:1527876815566};\\\", \\\"{x:1535,y:962,t:1527876815582};\\\", \\\"{x:1538,y:965,t:1527876815599};\\\", \\\"{x:1540,y:968,t:1527876815616};\\\", \\\"{x:1541,y:969,t:1527876815633};\\\", \\\"{x:1541,y:968,t:1527876815787};\\\", \\\"{x:1541,y:966,t:1527876815799};\\\", \\\"{x:1540,y:960,t:1527876815815};\\\", \\\"{x:1539,y:957,t:1527876815832};\\\", \\\"{x:1538,y:950,t:1527876815850};\\\", \\\"{x:1536,y:944,t:1527876815866};\\\", \\\"{x:1534,y:934,t:1527876815883};\\\", \\\"{x:1531,y:926,t:1527876815900};\\\", \\\"{x:1527,y:919,t:1527876815916};\\\", \\\"{x:1523,y:912,t:1527876815932};\\\", \\\"{x:1519,y:903,t:1527876815950};\\\", \\\"{x:1512,y:894,t:1527876815966};\\\", \\\"{x:1508,y:885,t:1527876815983};\\\", \\\"{x:1503,y:876,t:1527876816000};\\\", \\\"{x:1498,y:864,t:1527876816015};\\\", \\\"{x:1494,y:855,t:1527876816033};\\\", \\\"{x:1492,y:850,t:1527876816050};\\\", \\\"{x:1490,y:843,t:1527876816066};\\\", \\\"{x:1485,y:835,t:1527876816082};\\\", \\\"{x:1483,y:831,t:1527876816101};\\\", \\\"{x:1482,y:829,t:1527876816133};\\\", \\\"{x:1481,y:828,t:1527876816150};\\\", \\\"{x:1481,y:827,t:1527876816170};\\\", \\\"{x:1480,y:827,t:1527876816183};\\\", \\\"{x:1480,y:826,t:1527876816587};\\\", \\\"{x:1479,y:826,t:1527876816602};\\\", \\\"{x:1476,y:825,t:1527876816617};\\\", \\\"{x:1462,y:819,t:1527876816633};\\\", \\\"{x:1436,y:803,t:1527876816649};\\\", \\\"{x:1371,y:768,t:1527876816666};\\\", \\\"{x:1305,y:739,t:1527876816683};\\\", \\\"{x:1222,y:705,t:1527876816700};\\\", \\\"{x:1138,y:674,t:1527876816717};\\\", \\\"{x:1050,y:641,t:1527876816734};\\\", \\\"{x:991,y:619,t:1527876816750};\\\", \\\"{x:938,y:604,t:1527876816767};\\\", \\\"{x:890,y:589,t:1527876816785};\\\", \\\"{x:843,y:576,t:1527876816800};\\\", \\\"{x:800,y:569,t:1527876816817};\\\", \\\"{x:775,y:566,t:1527876816833};\\\", \\\"{x:752,y:566,t:1527876816850};\\\", \\\"{x:747,y:566,t:1527876816866};\\\", \\\"{x:745,y:566,t:1527876816884};\\\", \\\"{x:740,y:567,t:1527876816901};\\\", \\\"{x:733,y:570,t:1527876816917};\\\", \\\"{x:728,y:572,t:1527876816934};\\\", \\\"{x:722,y:574,t:1527876816951};\\\", \\\"{x:718,y:575,t:1527876816967};\\\", \\\"{x:714,y:576,t:1527876816984};\\\", \\\"{x:711,y:577,t:1527876817000};\\\", \\\"{x:707,y:577,t:1527876817017};\\\", \\\"{x:700,y:579,t:1527876817034};\\\", \\\"{x:682,y:579,t:1527876817050};\\\", \\\"{x:665,y:579,t:1527876817066};\\\", \\\"{x:646,y:579,t:1527876817083};\\\", \\\"{x:628,y:579,t:1527876817101};\\\", \\\"{x:614,y:579,t:1527876817116};\\\", \\\"{x:602,y:578,t:1527876817134};\\\", \\\"{x:594,y:577,t:1527876817151};\\\", \\\"{x:591,y:577,t:1527876817167};\\\", \\\"{x:590,y:576,t:1527876817183};\\\", \\\"{x:591,y:576,t:1527876817546};\\\", \\\"{x:592,y:576,t:1527876817554};\\\", \\\"{x:593,y:576,t:1527876817578};\\\", \\\"{x:594,y:577,t:1527876817594};\\\", \\\"{x:594,y:578,t:1527876817626};\\\", \\\"{x:595,y:579,t:1527876817690};\\\", \\\"{x:597,y:579,t:1527876817706};\\\", \\\"{x:598,y:581,t:1527876817718};\\\", \\\"{x:599,y:581,t:1527876817738};\\\", \\\"{x:600,y:581,t:1527876817762};\\\", \\\"{x:600,y:582,t:1527876818019};\\\", \\\"{x:596,y:585,t:1527876818035};\\\", \\\"{x:588,y:592,t:1527876818051};\\\", \\\"{x:581,y:602,t:1527876818068};\\\", \\\"{x:572,y:614,t:1527876818085};\\\", \\\"{x:560,y:631,t:1527876818101};\\\", \\\"{x:548,y:643,t:1527876818119};\\\", \\\"{x:537,y:660,t:1527876818135};\\\", \\\"{x:528,y:673,t:1527876818152};\\\", \\\"{x:519,y:688,t:1527876818168};\\\", \\\"{x:514,y:699,t:1527876818184};\\\", \\\"{x:509,y:710,t:1527876818202};\\\", \\\"{x:508,y:718,t:1527876818217};\\\", \\\"{x:507,y:726,t:1527876818235};\\\", \\\"{x:507,y:729,t:1527876818252};\\\", \\\"{x:507,y:730,t:1527876818338};\\\", \\\"{x:508,y:730,t:1527876818354};\\\", \\\"{x:508,y:731,t:1527876818368};\\\", \\\"{x:508,y:732,t:1527876818384};\\\", \\\"{x:509,y:732,t:1527876818443};\\\", \\\"{x:508,y:732,t:1527876818931};\\\", \\\"{x:507,y:732,t:1527876818946};\\\", \\\"{x:506,y:731,t:1527876818994};\\\", \\\"{x:505,y:731,t:1527876819459};\\\", \\\"{x:504,y:730,t:1527876819469};\\\", \\\"{x:504,y:727,t:1527876819486};\\\", \\\"{x:502,y:726,t:1527876819503};\\\", \\\"{x:502,y:723,t:1527876819519};\\\", \\\"{x:502,y:721,t:1527876819539};\\\", \\\"{x:502,y:719,t:1527876819554};\\\" ] }, { \\\"rt\\\": 12688, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 405944, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"DJRH1\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:503,y:719,t:1527876819954};\\\", \\\"{x:503,y:717,t:1527876819970};\\\", \\\"{x:503,y:716,t:1527876819985};\\\", \\\"{x:503,y:714,t:1527876820003};\\\", \\\"{x:503,y:713,t:1527876820020};\\\", \\\"{x:503,y:711,t:1527876820036};\\\", \\\"{x:503,y:709,t:1527876820403};\\\", \\\"{x:503,y:703,t:1527876820410};\\\", \\\"{x:501,y:696,t:1527876820420};\\\", \\\"{x:494,y:680,t:1527876820437};\\\", \\\"{x:487,y:664,t:1527876820453};\\\", \\\"{x:478,y:644,t:1527876820470};\\\", \\\"{x:469,y:629,t:1527876820487};\\\", \\\"{x:463,y:617,t:1527876820502};\\\", \\\"{x:459,y:607,t:1527876820521};\\\", \\\"{x:456,y:597,t:1527876820537};\\\", \\\"{x:452,y:577,t:1527876820553};\\\", \\\"{x:446,y:553,t:1527876820571};\\\", \\\"{x:438,y:525,t:1527876820587};\\\", \\\"{x:434,y:506,t:1527876820603};\\\", \\\"{x:430,y:494,t:1527876820620};\\\", \\\"{x:426,y:481,t:1527876820637};\\\", \\\"{x:425,y:472,t:1527876820653};\\\", \\\"{x:422,y:467,t:1527876820670};\\\", \\\"{x:420,y:461,t:1527876820687};\\\", \\\"{x:417,y:457,t:1527876820703};\\\", \\\"{x:415,y:454,t:1527876820719};\\\", \\\"{x:414,y:453,t:1527876820737};\\\", \\\"{x:412,y:452,t:1527876820754};\\\", \\\"{x:411,y:452,t:1527876820770};\\\", \\\"{x:405,y:452,t:1527876820787};\\\", \\\"{x:400,y:452,t:1527876820804};\\\", \\\"{x:395,y:449,t:1527876820820};\\\", \\\"{x:390,y:449,t:1527876820837};\\\", \\\"{x:388,y:449,t:1527876820854};\\\", \\\"{x:383,y:448,t:1527876820870};\\\", \\\"{x:382,y:448,t:1527876820887};\\\", \\\"{x:379,y:448,t:1527876820904};\\\", \\\"{x:377,y:448,t:1527876820920};\\\", \\\"{x:376,y:447,t:1527876820937};\\\", \\\"{x:375,y:447,t:1527876820954};\\\", \\\"{x:374,y:447,t:1527876821130};\\\", \\\"{x:374,y:446,t:1527876821138};\\\", \\\"{x:374,y:445,t:1527876821154};\\\", \\\"{x:376,y:445,t:1527876821179};\\\", \\\"{x:377,y:445,t:1527876821187};\\\", \\\"{x:386,y:445,t:1527876821204};\\\", \\\"{x:401,y:445,t:1527876821220};\\\", \\\"{x:422,y:447,t:1527876821237};\\\", \\\"{x:445,y:449,t:1527876821254};\\\", \\\"{x:476,y:453,t:1527876821271};\\\", \\\"{x:502,y:454,t:1527876821287};\\\", \\\"{x:525,y:455,t:1527876821304};\\\", \\\"{x:544,y:455,t:1527876821320};\\\", \\\"{x:555,y:455,t:1527876821336};\\\", \\\"{x:562,y:455,t:1527876821354};\\\", \\\"{x:563,y:455,t:1527876821371};\\\", \\\"{x:565,y:455,t:1527876821387};\\\", \\\"{x:567,y:455,t:1527876821403};\\\", \\\"{x:569,y:454,t:1527876821421};\\\", \\\"{x:577,y:453,t:1527876821437};\\\", \\\"{x:588,y:450,t:1527876821454};\\\", \\\"{x:596,y:448,t:1527876821471};\\\", \\\"{x:605,y:445,t:1527876821487};\\\", \\\"{x:611,y:444,t:1527876821504};\\\", \\\"{x:616,y:441,t:1527876821521};\\\", \\\"{x:617,y:441,t:1527876821536};\\\", \\\"{x:618,y:441,t:1527876821554};\\\", \\\"{x:614,y:442,t:1527876821642};\\\", \\\"{x:608,y:445,t:1527876821654};\\\", \\\"{x:596,y:450,t:1527876821671};\\\", \\\"{x:577,y:460,t:1527876821687};\\\", \\\"{x:555,y:469,t:1527876821704};\\\", \\\"{x:531,y:479,t:1527876821721};\\\", \\\"{x:510,y:485,t:1527876821738};\\\", \\\"{x:485,y:491,t:1527876821754};\\\", \\\"{x:450,y:494,t:1527876821771};\\\", \\\"{x:435,y:496,t:1527876821788};\\\", \\\"{x:420,y:497,t:1527876821804};\\\", \\\"{x:410,y:497,t:1527876821821};\\\", \\\"{x:406,y:497,t:1527876821838};\\\", \\\"{x:403,y:498,t:1527876821854};\\\", \\\"{x:401,y:499,t:1527876821871};\\\", \\\"{x:399,y:499,t:1527876821888};\\\", \\\"{x:396,y:500,t:1527876821904};\\\", \\\"{x:397,y:500,t:1527876822002};\\\", \\\"{x:405,y:498,t:1527876822010};\\\", \\\"{x:413,y:494,t:1527876822021};\\\", \\\"{x:422,y:490,t:1527876822038};\\\", \\\"{x:437,y:485,t:1527876822054};\\\", \\\"{x:451,y:482,t:1527876822071};\\\", \\\"{x:462,y:479,t:1527876822088};\\\", \\\"{x:469,y:479,t:1527876822104};\\\", \\\"{x:472,y:479,t:1527876822120};\\\", \\\"{x:473,y:479,t:1527876822138};\\\", \\\"{x:474,y:479,t:1527876822186};\\\", \\\"{x:475,y:479,t:1527876822194};\\\", \\\"{x:476,y:479,t:1527876822205};\\\", \\\"{x:479,y:479,t:1527876822220};\\\", \\\"{x:481,y:478,t:1527876822238};\\\", \\\"{x:483,y:478,t:1527876822255};\\\", \\\"{x:486,y:478,t:1527876822271};\\\", \\\"{x:489,y:478,t:1527876822288};\\\", \\\"{x:493,y:478,t:1527876822305};\\\", \\\"{x:499,y:478,t:1527876822321};\\\", \\\"{x:503,y:478,t:1527876822338};\\\", \\\"{x:507,y:477,t:1527876822354};\\\", \\\"{x:512,y:477,t:1527876822371};\\\", \\\"{x:518,y:476,t:1527876822388};\\\", \\\"{x:523,y:475,t:1527876822405};\\\", \\\"{x:526,y:474,t:1527876822421};\\\", \\\"{x:528,y:474,t:1527876822438};\\\", \\\"{x:529,y:474,t:1527876822498};\\\", \\\"{x:531,y:474,t:1527876822650};\\\", \\\"{x:533,y:474,t:1527876822658};\\\", \\\"{x:535,y:474,t:1527876822671};\\\", \\\"{x:542,y:474,t:1527876822688};\\\", \\\"{x:551,y:474,t:1527876822705};\\\", \\\"{x:557,y:475,t:1527876822722};\\\", \\\"{x:565,y:476,t:1527876822738};\\\", \\\"{x:568,y:476,t:1527876822755};\\\", \\\"{x:571,y:476,t:1527876822778};\\\", \\\"{x:573,y:476,t:1527876822794};\\\", \\\"{x:575,y:475,t:1527876822805};\\\", \\\"{x:580,y:473,t:1527876822822};\\\", \\\"{x:585,y:471,t:1527876822838};\\\", \\\"{x:592,y:468,t:1527876822855};\\\", \\\"{x:598,y:467,t:1527876822872};\\\", \\\"{x:607,y:463,t:1527876822888};\\\", \\\"{x:621,y:463,t:1527876822905};\\\", \\\"{x:646,y:471,t:1527876822922};\\\", \\\"{x:689,y:486,t:1527876822938};\\\", \\\"{x:776,y:523,t:1527876822956};\\\", \\\"{x:829,y:546,t:1527876822972};\\\", \\\"{x:878,y:567,t:1527876822989};\\\", \\\"{x:925,y:585,t:1527876823006};\\\", \\\"{x:966,y:602,t:1527876823022};\\\", \\\"{x:1014,y:627,t:1527876823039};\\\", \\\"{x:1055,y:652,t:1527876823056};\\\", \\\"{x:1084,y:667,t:1527876823072};\\\", \\\"{x:1107,y:677,t:1527876823089};\\\", \\\"{x:1124,y:685,t:1527876823105};\\\", \\\"{x:1139,y:692,t:1527876823122};\\\", \\\"{x:1153,y:698,t:1527876823138};\\\", \\\"{x:1162,y:703,t:1527876823155};\\\", \\\"{x:1167,y:705,t:1527876823172};\\\", \\\"{x:1171,y:706,t:1527876823190};\\\", \\\"{x:1175,y:708,t:1527876823205};\\\", \\\"{x:1178,y:711,t:1527876823222};\\\", \\\"{x:1185,y:718,t:1527876823239};\\\", \\\"{x:1198,y:733,t:1527876823255};\\\", \\\"{x:1218,y:750,t:1527876823272};\\\", \\\"{x:1254,y:784,t:1527876823289};\\\", \\\"{x:1288,y:808,t:1527876823305};\\\", \\\"{x:1315,y:824,t:1527876823323};\\\", \\\"{x:1358,y:848,t:1527876823339};\\\", \\\"{x:1396,y:863,t:1527876823355};\\\", \\\"{x:1420,y:874,t:1527876823373};\\\", \\\"{x:1435,y:881,t:1527876823388};\\\", \\\"{x:1446,y:887,t:1527876823405};\\\", \\\"{x:1453,y:891,t:1527876823423};\\\", \\\"{x:1460,y:898,t:1527876823438};\\\", \\\"{x:1467,y:904,t:1527876823455};\\\", \\\"{x:1476,y:911,t:1527876823472};\\\", \\\"{x:1477,y:912,t:1527876823489};\\\", \\\"{x:1479,y:914,t:1527876823506};\\\", \\\"{x:1480,y:915,t:1527876823523};\\\", \\\"{x:1482,y:918,t:1527876823539};\\\", \\\"{x:1482,y:920,t:1527876823562};\\\", \\\"{x:1482,y:921,t:1527876823572};\\\", \\\"{x:1482,y:926,t:1527876823588};\\\", \\\"{x:1482,y:931,t:1527876823606};\\\", \\\"{x:1482,y:937,t:1527876823623};\\\", \\\"{x:1481,y:943,t:1527876823638};\\\", \\\"{x:1479,y:949,t:1527876823655};\\\", \\\"{x:1478,y:952,t:1527876823673};\\\", \\\"{x:1477,y:954,t:1527876823688};\\\", \\\"{x:1477,y:955,t:1527876823705};\\\", \\\"{x:1477,y:957,t:1527876823722};\\\", \\\"{x:1477,y:959,t:1527876823738};\\\", \\\"{x:1477,y:962,t:1527876823755};\\\", \\\"{x:1478,y:964,t:1527876823772};\\\", \\\"{x:1479,y:964,t:1527876823795};\\\", \\\"{x:1479,y:965,t:1527876823810};\\\", \\\"{x:1480,y:965,t:1527876823851};\\\", \\\"{x:1481,y:965,t:1527876823859};\\\", \\\"{x:1482,y:965,t:1527876823872};\\\", \\\"{x:1481,y:965,t:1527876824194};\\\", \\\"{x:1480,y:962,t:1527876824218};\\\", \\\"{x:1480,y:960,t:1527876824226};\\\", \\\"{x:1479,y:957,t:1527876824238};\\\", \\\"{x:1479,y:953,t:1527876824255};\\\", \\\"{x:1479,y:946,t:1527876824272};\\\", \\\"{x:1478,y:942,t:1527876824288};\\\", \\\"{x:1478,y:939,t:1527876824306};\\\", \\\"{x:1476,y:934,t:1527876824323};\\\", \\\"{x:1476,y:932,t:1527876824339};\\\", \\\"{x:1475,y:930,t:1527876824356};\\\", \\\"{x:1474,y:928,t:1527876824372};\\\", \\\"{x:1474,y:926,t:1527876824388};\\\", \\\"{x:1474,y:923,t:1527876824405};\\\", \\\"{x:1474,y:920,t:1527876824422};\\\", \\\"{x:1474,y:917,t:1527876824438};\\\", \\\"{x:1473,y:913,t:1527876824455};\\\", \\\"{x:1473,y:910,t:1527876824473};\\\", \\\"{x:1473,y:908,t:1527876824488};\\\", \\\"{x:1473,y:904,t:1527876824505};\\\", \\\"{x:1473,y:899,t:1527876824522};\\\", \\\"{x:1473,y:894,t:1527876824539};\\\", \\\"{x:1473,y:888,t:1527876824555};\\\", \\\"{x:1473,y:883,t:1527876824572};\\\", \\\"{x:1473,y:879,t:1527876824588};\\\", \\\"{x:1473,y:876,t:1527876824606};\\\", \\\"{x:1473,y:874,t:1527876824622};\\\", \\\"{x:1473,y:873,t:1527876824638};\\\", \\\"{x:1473,y:871,t:1527876824655};\\\", \\\"{x:1473,y:867,t:1527876824672};\\\", \\\"{x:1473,y:863,t:1527876824688};\\\", \\\"{x:1473,y:861,t:1527876824705};\\\", \\\"{x:1473,y:859,t:1527876824722};\\\", \\\"{x:1473,y:856,t:1527876824739};\\\", \\\"{x:1472,y:854,t:1527876824755};\\\", \\\"{x:1472,y:853,t:1527876824779};\\\", \\\"{x:1472,y:851,t:1527876824788};\\\", \\\"{x:1472,y:850,t:1527876824805};\\\", \\\"{x:1472,y:849,t:1527876824821};\\\", \\\"{x:1472,y:846,t:1527876824838};\\\", \\\"{x:1472,y:845,t:1527876824855};\\\", \\\"{x:1472,y:843,t:1527876824871};\\\", \\\"{x:1472,y:841,t:1527876824907};\\\", \\\"{x:1472,y:840,t:1527876824931};\\\", \\\"{x:1472,y:838,t:1527876824947};\\\", \\\"{x:1472,y:837,t:1527876824963};\\\", \\\"{x:1473,y:833,t:1527876824978};\\\", \\\"{x:1474,y:833,t:1527876824994};\\\", \\\"{x:1474,y:832,t:1527876825005};\\\", \\\"{x:1475,y:832,t:1527876825090};\\\", \\\"{x:1475,y:831,t:1527876825107};\\\", \\\"{x:1476,y:831,t:1527876825122};\\\", \\\"{x:1477,y:831,t:1527876825138};\\\", \\\"{x:1477,y:830,t:1527876825410};\\\", \\\"{x:1478,y:829,t:1527876825426};\\\", \\\"{x:1474,y:829,t:1527876826843};\\\", \\\"{x:1467,y:830,t:1527876826854};\\\", \\\"{x:1441,y:832,t:1527876826871};\\\", \\\"{x:1404,y:832,t:1527876826888};\\\", \\\"{x:1365,y:832,t:1527876826904};\\\", \\\"{x:1309,y:832,t:1527876826921};\\\", \\\"{x:1208,y:821,t:1527876826938};\\\", \\\"{x:1141,y:813,t:1527876826954};\\\", \\\"{x:1063,y:802,t:1527876826972};\\\", \\\"{x:991,y:791,t:1527876826988};\\\", \\\"{x:934,y:780,t:1527876827005};\\\", \\\"{x:897,y:773,t:1527876827021};\\\", \\\"{x:867,y:767,t:1527876827039};\\\", \\\"{x:839,y:764,t:1527876827055};\\\", \\\"{x:814,y:756,t:1527876827072};\\\", \\\"{x:789,y:749,t:1527876827087};\\\", \\\"{x:764,y:742,t:1527876827104};\\\", \\\"{x:736,y:734,t:1527876827121};\\\", \\\"{x:683,y:718,t:1527876827138};\\\", \\\"{x:658,y:711,t:1527876827154};\\\", \\\"{x:642,y:707,t:1527876827171};\\\", \\\"{x:629,y:700,t:1527876827188};\\\", \\\"{x:614,y:693,t:1527876827204};\\\", \\\"{x:599,y:685,t:1527876827222};\\\", \\\"{x:587,y:676,t:1527876827237};\\\", \\\"{x:574,y:666,t:1527876827255};\\\", \\\"{x:562,y:655,t:1527876827271};\\\", \\\"{x:550,y:644,t:1527876827288};\\\", \\\"{x:539,y:634,t:1527876827304};\\\", \\\"{x:515,y:620,t:1527876827325};\\\", \\\"{x:495,y:612,t:1527876827343};\\\", \\\"{x:477,y:607,t:1527876827359};\\\", \\\"{x:467,y:603,t:1527876827376};\\\", \\\"{x:458,y:599,t:1527876827392};\\\", \\\"{x:453,y:597,t:1527876827409};\\\", \\\"{x:448,y:595,t:1527876827426};\\\", \\\"{x:439,y:591,t:1527876827443};\\\", \\\"{x:433,y:587,t:1527876827459};\\\", \\\"{x:425,y:585,t:1527876827476};\\\", \\\"{x:418,y:581,t:1527876827492};\\\", \\\"{x:413,y:579,t:1527876827509};\\\", \\\"{x:412,y:578,t:1527876827526};\\\", \\\"{x:410,y:577,t:1527876827542};\\\", \\\"{x:409,y:576,t:1527876827559};\\\", \\\"{x:407,y:575,t:1527876827575};\\\", \\\"{x:404,y:575,t:1527876827592};\\\", \\\"{x:400,y:573,t:1527876827609};\\\", \\\"{x:399,y:572,t:1527876827626};\\\", \\\"{x:398,y:572,t:1527876827674};\\\", \\\"{x:397,y:572,t:1527876827683};\\\", \\\"{x:394,y:573,t:1527876827692};\\\", \\\"{x:388,y:576,t:1527876827710};\\\", \\\"{x:382,y:580,t:1527876827726};\\\", \\\"{x:381,y:582,t:1527876827742};\\\", \\\"{x:377,y:584,t:1527876827760};\\\", \\\"{x:377,y:585,t:1527876827776};\\\", \\\"{x:374,y:587,t:1527876827792};\\\", \\\"{x:373,y:588,t:1527876827810};\\\", \\\"{x:371,y:593,t:1527876827826};\\\", \\\"{x:370,y:594,t:1527876827843};\\\", \\\"{x:370,y:596,t:1527876827971};\\\", \\\"{x:371,y:596,t:1527876827978};\\\", \\\"{x:375,y:596,t:1527876828027};\\\", \\\"{x:379,y:596,t:1527876828042};\\\", \\\"{x:381,y:596,t:1527876828060};\\\", \\\"{x:382,y:596,t:1527876828076};\\\", \\\"{x:384,y:596,t:1527876828402};\\\", \\\"{x:392,y:596,t:1527876828410};\\\", \\\"{x:411,y:596,t:1527876828426};\\\", \\\"{x:432,y:596,t:1527876828443};\\\", \\\"{x:458,y:596,t:1527876828459};\\\", \\\"{x:485,y:596,t:1527876828476};\\\", \\\"{x:511,y:596,t:1527876828493};\\\", \\\"{x:528,y:596,t:1527876828509};\\\", \\\"{x:542,y:596,t:1527876828527};\\\", \\\"{x:553,y:596,t:1527876828544};\\\", \\\"{x:559,y:596,t:1527876828560};\\\", \\\"{x:560,y:596,t:1527876828578};\\\", \\\"{x:562,y:596,t:1527876828593};\\\", \\\"{x:564,y:596,t:1527876828738};\\\", \\\"{x:567,y:596,t:1527876828746};\\\", \\\"{x:570,y:595,t:1527876828760};\\\", \\\"{x:576,y:595,t:1527876828777};\\\", \\\"{x:582,y:595,t:1527876828794};\\\", \\\"{x:591,y:595,t:1527876828810};\\\", \\\"{x:593,y:595,t:1527876828827};\\\", \\\"{x:596,y:595,t:1527876828843};\\\", \\\"{x:598,y:595,t:1527876828882};\\\", \\\"{x:599,y:595,t:1527876828906};\\\", \\\"{x:601,y:595,t:1527876828955};\\\", \\\"{x:601,y:595,t:1527876829020};\\\", \\\"{x:602,y:595,t:1527876829043};\\\", \\\"{x:603,y:595,t:1527876829058};\\\", \\\"{x:603,y:596,t:1527876829067};\\\", \\\"{x:603,y:600,t:1527876829083};\\\", \\\"{x:603,y:601,t:1527876829094};\\\", \\\"{x:601,y:608,t:1527876829111};\\\", \\\"{x:596,y:621,t:1527876829128};\\\", \\\"{x:590,y:633,t:1527876829143};\\\", \\\"{x:583,y:645,t:1527876829161};\\\", \\\"{x:574,y:658,t:1527876829178};\\\", \\\"{x:566,y:678,t:1527876829195};\\\", \\\"{x:563,y:687,t:1527876829211};\\\", \\\"{x:559,y:698,t:1527876829227};\\\", \\\"{x:554,y:706,t:1527876829245};\\\", \\\"{x:551,y:712,t:1527876829260};\\\", \\\"{x:551,y:713,t:1527876829278};\\\", \\\"{x:551,y:714,t:1527876829294};\\\", \\\"{x:551,y:717,t:1527876829311};\\\", \\\"{x:550,y:718,t:1527876829327};\\\", \\\"{x:549,y:723,t:1527876829344};\\\", \\\"{x:548,y:727,t:1527876829362};\\\", \\\"{x:547,y:730,t:1527876829377};\\\", \\\"{x:544,y:738,t:1527876829395};\\\", \\\"{x:544,y:739,t:1527876829412};\\\", \\\"{x:543,y:743,t:1527876829428};\\\", \\\"{x:543,y:747,t:1527876829444};\\\", \\\"{x:541,y:750,t:1527876829460};\\\", \\\"{x:540,y:753,t:1527876829477};\\\", \\\"{x:539,y:755,t:1527876829495};\\\", \\\"{x:539,y:756,t:1527876829510};\\\", \\\"{x:538,y:756,t:1527876830187};\\\", \\\"{x:539,y:747,t:1527876830939};\\\", \\\"{x:542,y:737,t:1527876830946};\\\", \\\"{x:552,y:710,t:1527876830962};\\\", \\\"{x:561,y:689,t:1527876830979};\\\", \\\"{x:571,y:667,t:1527876830995};\\\", \\\"{x:577,y:658,t:1527876831012};\\\", \\\"{x:582,y:651,t:1527876831029};\\\", \\\"{x:586,y:645,t:1527876831045};\\\", \\\"{x:592,y:637,t:1527876831061};\\\", \\\"{x:598,y:630,t:1527876831079};\\\", \\\"{x:603,y:623,t:1527876831096};\\\", \\\"{x:608,y:618,t:1527876831112};\\\", \\\"{x:610,y:616,t:1527876831129};\\\", \\\"{x:610,y:615,t:1527876831267};\\\", \\\"{x:610,y:613,t:1527876831315};\\\", \\\"{x:610,y:611,t:1527876831329};\\\", \\\"{x:610,y:606,t:1527876831346};\\\", \\\"{x:610,y:597,t:1527876831362};\\\", \\\"{x:610,y:594,t:1527876831378};\\\", \\\"{x:610,y:590,t:1527876831396};\\\", \\\"{x:610,y:587,t:1527876831413};\\\", \\\"{x:610,y:586,t:1527876831429};\\\", \\\"{x:610,y:584,t:1527876831446};\\\", \\\"{x:609,y:584,t:1527876831650};\\\", \\\"{x:607,y:584,t:1527876831663};\\\", \\\"{x:605,y:586,t:1527876831679};\\\", \\\"{x:600,y:594,t:1527876831696};\\\", \\\"{x:596,y:607,t:1527876831712};\\\", \\\"{x:594,y:617,t:1527876831729};\\\", \\\"{x:593,y:624,t:1527876831745};\\\", \\\"{x:591,y:633,t:1527876831763};\\\", \\\"{x:591,y:636,t:1527876831780};\\\", \\\"{x:591,y:642,t:1527876831796};\\\", \\\"{x:590,y:647,t:1527876831813};\\\", \\\"{x:590,y:657,t:1527876831830};\\\", \\\"{x:590,y:673,t:1527876831845};\\\", \\\"{x:597,y:689,t:1527876831863};\\\", \\\"{x:607,y:706,t:1527876831880};\\\", \\\"{x:622,y:721,t:1527876831896};\\\", \\\"{x:636,y:733,t:1527876831912};\\\", \\\"{x:647,y:741,t:1527876831930};\\\", \\\"{x:653,y:746,t:1527876831945};\\\", \\\"{x:655,y:749,t:1527876831962};\\\", \\\"{x:656,y:752,t:1527876831980};\\\", \\\"{x:656,y:755,t:1527876831996};\\\", \\\"{x:654,y:759,t:1527876832013};\\\", \\\"{x:645,y:763,t:1527876832030};\\\", \\\"{x:631,y:765,t:1527876832046};\\\", \\\"{x:608,y:765,t:1527876832063};\\\", \\\"{x:591,y:765,t:1527876832079};\\\", \\\"{x:576,y:765,t:1527876832095};\\\", \\\"{x:566,y:765,t:1527876832113};\\\", \\\"{x:557,y:762,t:1527876832131};\\\", \\\"{x:541,y:758,t:1527876832146};\\\", \\\"{x:531,y:756,t:1527876832163};\\\", \\\"{x:526,y:756,t:1527876832180};\\\", \\\"{x:524,y:756,t:1527876832196};\\\", \\\"{x:523,y:756,t:1527876832213};\\\", \\\"{x:522,y:756,t:1527876832229};\\\", \\\"{x:521,y:756,t:1527876832245};\\\", \\\"{x:518,y:757,t:1527876832262};\\\", \\\"{x:515,y:758,t:1527876832280};\\\", \\\"{x:513,y:759,t:1527876832295};\\\", \\\"{x:512,y:761,t:1527876832312};\\\" ] }, { \\\"rt\\\": 56649, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 463818, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"DJRH1\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"FIND 12PM ON THE HORIZONTAL AXIS OF GRAPH AND FOLLOW DOTTED LINE UP-RIGHT. ALL OBJECTS THAT LIE ON THE DOTTED LINE START AT 12PM\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 10148, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"24\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"USA\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 474969, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"DJRH1\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 17491, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Fifth\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Engineering\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 493471, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"DJRH1\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 27991, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 522779, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"DJRH1\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"DJRH1\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 1014, dom: 1395, initialDom: 1469",
  "javascriptErrors": []
}