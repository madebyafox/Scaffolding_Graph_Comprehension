var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05290965707b56439093a489acbca10fec6341e5"] = {
  "startTime": "2018-05-29T17:07:09.5392645Z",
  "websitePageUrl": "/",
  "visitTime": 22884,
  "engagementTime": 22884,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 929,
  "viewportHeight": 1003,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "7c539dbecd765cdb433c964703f4dbaf",
    "created": "2018-05-29T17:07:09.5352003+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "e2cbc7557f5850fd1e5d963f06dfc34f",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/7c539dbecd765cdb433c964703f4dbaf/play"
  },
  "events": [
    {
      "t": 66,
      "e": 66,
      "ty": 14,
      "x": 0,
      "y": 1002
    },
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 929,
      "y": 1003
    },
    {
      "t": 601,
      "e": 601,
      "ty": 2,
      "x": 213,
      "y": 41
    },
    {
      "t": 701,
      "e": 701,
      "ty": 2,
      "x": 295,
      "y": 198
    },
    {
      "t": 752,
      "e": 752,
      "ty": 41,
      "x": 27797,
      "y": 18923,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 801,
      "e": 801,
      "ty": 2,
      "x": 395,
      "y": 386
    },
    {
      "t": 901,
      "e": 901,
      "ty": 2,
      "x": 456,
      "y": 459
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 2,
      "x": 476,
      "y": 458
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 41,
      "x": 33422,
      "y": 29244,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 1101,
      "e": 1101,
      "ty": 2,
      "x": 485,
      "y": 455
    },
    {
      "t": 1257,
      "e": 1257,
      "ty": 41,
      "x": 33914,
      "y": 28999,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 1800,
      "e": 1800,
      "ty": 0,
      "x": 1920,
      "y": 1156
    },
    {
      "t": 1801,
      "e": 1801,
      "ty": 2,
      "x": 503,
      "y": 550
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 41,
      "x": 7836,
      "y": 30514,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 2200,
      "e": 2200,
      "ty": 2,
      "x": 568,
      "y": 574
    },
    {
      "t": 2251,
      "e": 2251,
      "ty": 41,
      "x": 14827,
      "y": 34037,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 2301,
      "e": 2301,
      "ty": 2,
      "x": 676,
      "y": 599
    },
    {
      "t": 2400,
      "e": 2400,
      "ty": 2,
      "x": 707,
      "y": 604
    },
    {
      "t": 2501,
      "e": 2501,
      "ty": 2,
      "x": 835,
      "y": 641
    },
    {
      "t": 2501,
      "e": 2501,
      "ty": 41,
      "x": 25968,
      "y": 37969,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 2600,
      "e": 2600,
      "ty": 2,
      "x": 1088,
      "y": 742
    },
    {
      "t": 2701,
      "e": 2701,
      "ty": 2,
      "x": 1091,
      "y": 745
    },
    {
      "t": 2751,
      "e": 2751,
      "ty": 41,
      "x": 39949,
      "y": 46570,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 2801,
      "e": 2801,
      "ty": 2,
      "x": 1091,
      "y": 756
    },
    {
      "t": 2874,
      "e": 2874,
      "ty": 3,
      "x": 1091,
      "y": 758,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 2908,
      "e": 2908,
      "ty": 2,
      "x": 1091,
      "y": 758
    },
    {
      "t": 2970,
      "e": 2970,
      "ty": 4,
      "x": 39949,
      "y": 47553,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 3001,
      "e": 3001,
      "ty": 41,
      "x": 39949,
      "y": 47553,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 3355,
      "e": 3355,
      "ty": 3,
      "x": 1091,
      "y": 758,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 3448,
      "e": 3448,
      "ty": 4,
      "x": 39949,
      "y": 47553,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 3450,
      "e": 3450,
      "ty": 5,
      "x": 1091,
      "y": 758,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 3701,
      "e": 3701,
      "ty": 2,
      "x": 1059,
      "y": 764
    },
    {
      "t": 3756,
      "e": 3756,
      "ty": 41,
      "x": 38201,
      "y": 48045,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 3888,
      "e": 3888,
      "ty": 3,
      "x": 1058,
      "y": 764,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 3901,
      "e": 3901,
      "ty": 2,
      "x": 1058,
      "y": 764
    },
    {
      "t": 3984,
      "e": 3984,
      "ty": 4,
      "x": 38146,
      "y": 48045,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 3985,
      "e": 3985,
      "ty": 5,
      "x": 1058,
      "y": 764,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 3985,
      "e": 3985,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 4003,
      "e": 4003,
      "ty": 41,
      "x": 38146,
      "y": 48045,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 4495,
      "e": 4495,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 5587,
      "e": 5587,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 6101,
      "e": 6101,
      "ty": 2,
      "x": 946,
      "y": 949
    },
    {
      "t": 6200,
      "e": 6200,
      "ty": 2,
      "x": 912,
      "y": 1001
    },
    {
      "t": 6252,
      "e": 6252,
      "ty": 41,
      "x": 30332,
      "y": 63370,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 6301,
      "e": 6301,
      "ty": 2,
      "x": 877,
      "y": 969
    },
    {
      "t": 6401,
      "e": 6401,
      "ty": 2,
      "x": 831,
      "y": 925
    },
    {
      "t": 6501,
      "e": 6501,
      "ty": 2,
      "x": 822,
      "y": 915
    },
    {
      "t": 6502,
      "e": 6502,
      "ty": 41,
      "x": 26002,
      "y": 57041,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 6600,
      "e": 6600,
      "ty": 2,
      "x": 806,
      "y": 906
    },
    {
      "t": 6701,
      "e": 6701,
      "ty": 2,
      "x": 806,
      "y": 905
    },
    {
      "t": 6744,
      "e": 6744,
      "ty": 3,
      "x": 806,
      "y": 905,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 6751,
      "e": 6751,
      "ty": 41,
      "x": 8396,
      "y": 52428,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 6817,
      "e": 6817,
      "ty": 4,
      "x": 8396,
      "y": 52428,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 6817,
      "e": 6817,
      "ty": 5,
      "x": 806,
      "y": 905,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 6819,
      "e": 6819,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 6824,
      "e": 6824,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 6900,
      "e": 6900,
      "ty": 2,
      "x": 826,
      "y": 918
    },
    {
      "t": 7000,
      "e": 7000,
      "ty": 2,
      "x": 943,
      "y": 1011
    },
    {
      "t": 7001,
      "e": 7001,
      "ty": 41,
      "x": 31955,
      "y": 63945,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 7101,
      "e": 7101,
      "ty": 2,
      "x": 953,
      "y": 1022
    },
    {
      "t": 7201,
      "e": 7201,
      "ty": 2,
      "x": 961,
      "y": 1032
    },
    {
      "t": 7217,
      "e": 7217,
      "ty": 6,
      "x": 962,
      "y": 1036,
      "ta": "#start"
    },
    {
      "t": 7251,
      "e": 7251,
      "ty": 41,
      "x": 30309,
      "y": 13311,
      "ta": "#start"
    },
    {
      "t": 7301,
      "e": 7301,
      "ty": 2,
      "x": 967,
      "y": 1048
    },
    {
      "t": 7508,
      "e": 7508,
      "ty": 41,
      "x": 31402,
      "y": 28731,
      "ta": "#start"
    },
    {
      "t": 7554,
      "e": 7554,
      "ty": 3,
      "x": 967,
      "y": 1048,
      "ta": "#start"
    },
    {
      "t": 7555,
      "e": 7555,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 7556,
      "e": 7556,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 7648,
      "e": 7648,
      "ty": 4,
      "x": 31402,
      "y": 28731,
      "ta": "#start"
    },
    {
      "t": 7649,
      "e": 7649,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 7650,
      "e": 7650,
      "ty": 5,
      "x": 967,
      "y": 1048,
      "ta": "#start"
    },
    {
      "t": 7650,
      "e": 7650,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 7701,
      "e": 7701,
      "ty": 2,
      "x": 967,
      "y": 1049
    },
    {
      "t": 7759,
      "e": 7759,
      "ty": 41,
      "x": 33025,
      "y": 59896,
      "ta": "html > body"
    },
    {
      "t": 8652,
      "e": 8652,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 8701,
      "e": 8701,
      "ty": 2,
      "x": 968,
      "y": 1049
    },
    {
      "t": 8752,
      "e": 8752,
      "ty": 41,
      "x": 33060,
      "y": 59896,
      "ta": "html > body"
    },
    {
      "t": 9001,
      "e": 9001,
      "ty": 2,
      "x": 970,
      "y": 1037
    },
    {
      "t": 9002,
      "e": 9002,
      "ty": 41,
      "x": 33129,
      "y": 59205,
      "ta": "html > body"
    },
    {
      "t": 9101,
      "e": 9101,
      "ty": 2,
      "x": 953,
      "y": 905
    },
    {
      "t": 9168,
      "e": 9168,
      "ty": 6,
      "x": 918,
      "y": 716,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 9201,
      "e": 9201,
      "ty": 2,
      "x": 913,
      "y": 693
    },
    {
      "t": 9202,
      "e": 9202,
      "ty": 7,
      "x": 910,
      "y": 680,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 9218,
      "e": 9218,
      "ty": 6,
      "x": 907,
      "y": 660,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 9236,
      "e": 9236,
      "ty": 7,
      "x": 897,
      "y": 633,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 9252,
      "e": 9252,
      "ty": 41,
      "x": 19249,
      "y": 51491,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 9269,
      "e": 9269,
      "ty": 6,
      "x": 887,
      "y": 577,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 9285,
      "e": 9285,
      "ty": 7,
      "x": 883,
      "y": 554,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 9300,
      "e": 9300,
      "ty": 2,
      "x": 883,
      "y": 554
    },
    {
      "t": 9407,
      "e": 9407,
      "ty": 2,
      "x": 879,
      "y": 522
    },
    {
      "t": 9501,
      "e": 9501,
      "ty": 2,
      "x": 879,
      "y": 530
    },
    {
      "t": 9501,
      "e": 9501,
      "ty": 41,
      "x": 15356,
      "y": 28086,
      "ta": "#jspsych-survey-text-0 > p"
    },
    {
      "t": 9568,
      "e": 9568,
      "ty": 6,
      "x": 879,
      "y": 569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 9601,
      "e": 9601,
      "ty": 2,
      "x": 879,
      "y": 576
    },
    {
      "t": 9651,
      "e": 9651,
      "ty": 7,
      "x": 879,
      "y": 585,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 9707,
      "e": 9707,
      "ty": 2,
      "x": 879,
      "y": 585
    },
    {
      "t": 9757,
      "e": 9757,
      "ty": 41,
      "x": 15356,
      "y": 60602,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 9797,
      "e": 9797,
      "ty": 6,
      "x": 879,
      "y": 583,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 9800,
      "e": 9800,
      "ty": 2,
      "x": 879,
      "y": 583
    },
    {
      "t": 9901,
      "e": 9901,
      "ty": 2,
      "x": 880,
      "y": 570
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10003,
      "e": 10003,
      "ty": 41,
      "x": 15572,
      "y": 18724,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 10016,
      "e": 10016,
      "ty": 3,
      "x": 880,
      "y": 570,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 10017,
      "e": 10017,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 10112,
      "e": 10112,
      "ty": 4,
      "x": 15572,
      "y": 18724,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 10112,
      "e": 10112,
      "ty": 5,
      "x": 880,
      "y": 570,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 10741,
      "e": 10741,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "79"
    },
    {
      "t": 10742,
      "e": 10742,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 10820,
      "e": 10820,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "o"
    },
    {
      "t": 10909,
      "e": 10909,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "83"
    },
    {
      "t": 10909,
      "e": 10909,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 10973,
      "e": 10973,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "os"
    },
    {
      "t": 11093,
      "e": 11093,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "67"
    },
    {
      "t": 11094,
      "e": 11094,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 11155,
      "e": 11155,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "osc"
    },
    {
      "t": 11276,
      "e": 11276,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "65"
    },
    {
      "t": 11277,
      "e": 11277,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 11373,
      "e": 11373,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "osca"
    },
    {
      "t": 11477,
      "e": 11477,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "82"
    },
    {
      "t": 11477,
      "e": 11477,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 11548,
      "e": 11548,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||r"
    },
    {
      "t": 11716,
      "e": 11716,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 11717,
      "e": 11717,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "oscar"
    },
    {
      "t": 11718,
      "e": 11718,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 11720,
      "e": 11720,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 11796,
      "e": 11796,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 12389,
      "e": 12389,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 12389,
      "e": 12389,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 12436,
      "e": 12436,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "1"
    },
    {
      "t": 12524,
      "e": 12524,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 12525,
      "e": 12525,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 12605,
      "e": 12605,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11"
    },
    {
      "t": 12781,
      "e": 12781,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "52"
    },
    {
      "t": 12781,
      "e": 12781,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 12844,
      "e": 12844,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 13268,
      "e": 13268,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "191"
    },
    {
      "t": 13268,
      "e": 13268,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 13332,
      "e": 13332,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*\n"
    },
    {
      "t": 14590,
      "e": 14590,
      "ty": 7,
      "x": 884,
      "y": 599,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 14601,
      "e": 14601,
      "ty": 2,
      "x": 884,
      "y": 599
    },
    {
      "t": 14701,
      "e": 14701,
      "ty": 2,
      "x": 885,
      "y": 632
    },
    {
      "t": 14751,
      "e": 14751,
      "ty": 41,
      "x": 16654,
      "y": 49151,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 15132,
      "e": 15132,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "191"
    },
    {
      "t": 15220,
      "e": 15220,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 16001,
      "e": 16001,
      "ty": 2,
      "x": 888,
      "y": 638
    },
    {
      "t": 16001,
      "e": 16001,
      "ty": 41,
      "x": 17302,
      "y": 63194,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 16024,
      "e": 16024,
      "ty": 6,
      "x": 918,
      "y": 661,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 16057,
      "e": 16057,
      "ty": 7,
      "x": 939,
      "y": 684,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 16076,
      "e": 16076,
      "ty": 6,
      "x": 939,
      "y": 686,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 16101,
      "e": 16101,
      "ty": 2,
      "x": 939,
      "y": 686
    },
    {
      "t": 16251,
      "e": 16251,
      "ty": 41,
      "x": 22202,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 16301,
      "e": 16301,
      "ty": 2,
      "x": 943,
      "y": 695
    },
    {
      "t": 16503,
      "e": 16503,
      "ty": 41,
      "x": 24263,
      "y": 17873,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 16600,
      "e": 16600,
      "ty": 2,
      "x": 947,
      "y": 706
    },
    {
      "t": 16709,
      "e": 16709,
      "ty": 2,
      "x": 947,
      "y": 708
    },
    {
      "t": 16745,
      "e": 16745,
      "ty": 3,
      "x": 947,
      "y": 708,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 16746,
      "e": 16746,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 16746,
      "e": 16746,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 16746,
      "e": 16746,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 16751,
      "e": 16751,
      "ty": 41,
      "x": 26325,
      "y": 43690,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 16848,
      "e": 16848,
      "ty": 4,
      "x": 26325,
      "y": 43690,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 16849,
      "e": 16849,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 16850,
      "e": 16850,
      "ty": 5,
      "x": 947,
      "y": 708,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 16850,
      "e": 16850,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 17101,
      "e": 17101,
      "ty": 2,
      "x": 956,
      "y": 842
    },
    {
      "t": 17201,
      "e": 17201,
      "ty": 2,
      "x": 990,
      "y": 912
    },
    {
      "t": 17251,
      "e": 17251,
      "ty": 41,
      "x": 33955,
      "y": 52991,
      "ta": "html > body"
    },
    {
      "t": 17304,
      "e": 17304,
      "ty": 2,
      "x": 995,
      "y": 932
    },
    {
      "t": 17506,
      "e": 17506,
      "ty": 41,
      "x": 33990,
      "y": 53164,
      "ta": "html > body"
    },
    {
      "t": 17943,
      "e": 17943,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 18601,
      "e": 18601,
      "ty": 2,
      "x": 985,
      "y": 940
    },
    {
      "t": 18701,
      "e": 18701,
      "ty": 2,
      "x": 954,
      "y": 986
    },
    {
      "t": 18751,
      "e": 18751,
      "ty": 41,
      "x": 31906,
      "y": 64952,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 18793,
      "e": 18793,
      "ty": 6,
      "x": 942,
      "y": 1033,
      "ta": "#start"
    },
    {
      "t": 18801,
      "e": 18801,
      "ty": 2,
      "x": 942,
      "y": 1033
    },
    {
      "t": 18901,
      "e": 18901,
      "ty": 2,
      "x": 942,
      "y": 1058
    },
    {
      "t": 19009,
      "e": 19009,
      "ty": 41,
      "x": 17749,
      "y": 48006,
      "ta": "#start"
    },
    {
      "t": 19018,
      "e": 19018,
      "ty": 3,
      "x": 942,
      "y": 1058,
      "ta": "#start"
    },
    {
      "t": 19018,
      "e": 19018,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 19112,
      "e": 19112,
      "ty": 4,
      "x": 17749,
      "y": 48006,
      "ta": "#start"
    },
    {
      "t": 19113,
      "e": 19113,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 19113,
      "e": 19113,
      "ty": 5,
      "x": 942,
      "y": 1058,
      "ta": "#start"
    },
    {
      "t": 19114,
      "e": 19114,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 20004,
      "e": 20004,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20116,
      "e": 20116,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 20901,
      "e": 20901,
      "ty": 2,
      "x": 939,
      "y": 1054
    },
    {
      "t": 21005,
      "e": 21005,
      "ty": 2,
      "x": 938,
      "y": 1054
    },
    {
      "t": 21006,
      "e": 21006,
      "ty": 41,
      "x": 32027,
      "y": 60184,
      "ta": "html > body"
    },
    {
      "t": 21101,
      "e": 21101,
      "ty": 2,
      "x": 935,
      "y": 1048
    },
    {
      "t": 21201,
      "e": 21201,
      "ty": 2,
      "x": 937,
      "y": 1044
    },
    {
      "t": 21252,
      "e": 21252,
      "ty": 41,
      "x": 31992,
      "y": 59608,
      "ta": "html > body"
    },
    {
      "t": 21302,
      "e": 21302,
      "ty": 2,
      "x": 938,
      "y": 1042
    },
    {
      "t": 21401,
      "e": 21401,
      "ty": 2,
      "x": 941,
      "y": 1033
    },
    {
      "t": 21509,
      "e": 21509,
      "ty": 2,
      "x": 942,
      "y": 1033
    },
    {
      "t": 21509,
      "e": 21509,
      "ty": 41,
      "x": 32164,
      "y": 58975,
      "ta": "html > body"
    },
    {
      "t": 21869,
      "e": 21869,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 21901,
      "e": 21901,
      "ty": 1,
      "x": 0,
      "y": 1
    },
    {
      "t": 22001,
      "e": 22001,
      "ty": 1,
      "x": 0,
      "y": 15
    },
    {
      "t": 22101,
      "e": 22101,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 22884,
      "e": 22884,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":60,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":61,\"previousSibling\":{\"id\":60},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":62,\"textContent\":\" \",\"previousSibling\":{\"id\":61},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":63,\"textContent\":\" \",\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":64,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":63},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":65,\"textContent\":\" \",\"previousSibling\":{\"id\":64},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":66,\"previousSibling\":{\"id\":65},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":67,\"textContent\":\" \",\"previousSibling\":{\"id\":66},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":68,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":67},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":69,\"previousSibling\":{\"id\":68},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":70,\"textContent\":\" \",\"previousSibling\":{\"id\":69},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":71,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":70},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":72,\"previousSibling\":{\"id\":71},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":73,\"textContent\":\" \",\"previousSibling\":{\"id\":72},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":74,\"textContent\":\" \",\"parentNode\":{\"id\":64}},{\"nodeType\":1,\"id\":75,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":74},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":76,\"textContent\":\" \",\"previousSibling\":{\"id\":75},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":77,\"textContent\":\" \",\"parentNode\":{\"id\":75}},{\"nodeType\":1,\"id\":78,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":77},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":79,\"textContent\":\" \",\"previousSibling\":{\"id\":78},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":80,\"textContent\":\"UNIVERSITY OF CALIFORNIA, SAN DIEGO CONSENT TO ACT AS A RESEARCH SUBJECT\",\"parentNode\":{\"id\":78}},{\"nodeType\":3,\"id\":81,\"textContent\":\" \",\"parentNode\":{\"id\":68}},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":81},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":83,\"textContent\":\" \",\"previousSibling\":{\"id\":82},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":84,\"textContent\":\" \",\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":85,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":84},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":86,\"textContent\":\" \",\"previousSibling\":{\"id\":85},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":87,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":86},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":88,\"textContent\":\" \",\"previousSibling\":{\"id\":87},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":89,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":88},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":90,\"textContent\":\" \",\"previousSibling\":{\"id\":89},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":91,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":90},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":92,\"textContent\":\" \",\"previousSibling\":{\"id\":91},\"parentNode\":{\"id\":82}},{\"nodeType\":8,\"id\":93,\"previousSibling\":{\"id\":92},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":94,\"textContent\":\" \",\"previousSibling\":{\"id\":93},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":95,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control-group centered\"},\"previousSibling\":{\"id\":94},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":96,\"textContent\":\" \",\"previousSibling\":{\"id\":95},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":97,\"textContent\":\" You are being invited to participate in a research study titled Learning Diagrams: Evaluating Learning With External Representations. This study is being done by Amy Fox and Dr. Jim Hollan from the University of California - San Diego (UCSD). You were selected to participate in this study because we think you might use graphs and diagrams in your work and educational activities.\",\"parentNode\":{\"id\":85}},{\"nodeType\":3,\"id\":98,\"textContent\":\" The purpose of this research study is to understand how humans try to make sense of charts, diagrams and graphs that are unconventional and that we may not have seen before. If you agree to take part in this study, you will be asked to read a series of instructions and answer a series of questions. The entire study should take no more than 60 minutes to complete. The researchers expect there will be no direct benefit to you from this research, other than any enjoyment you might have in contributing to research. We hope that you will find the questions interesting, though at times you may feel bored. The investigator(s), however, may learn more about how different types of instructions trigger different levels of understanding when using graphs. There are minimal risks associated with this research study, including a loss of confidentiality of your participation. The researchers are taking all required steps to protect your confidentiality, including storing all of your responses to questions in a secure, encrypted database separate from any information that can personally identify you. The only records containing your name and other personally identifying information are those stored in the system through which you signed up to participate in the study. These records will never be connected with the data we collect from you today. Research records will be kept confidential to the extent allowed by law and may be reviewed by the UCSD Institutional Review Board.\",\"parentNode\":{\"id\":87}},{\"nodeType\":3,\"id\":99,\"textContent\":\" Your participation in this study is completely voluntary and you can withdraw at any time by notifying the researcher that you wish to end your participation. Choosing not to participate or withdrawing will result in no penalty or loss of benefits to which you are entitled. You are free to skip any questions that you choose. If you have questions about this project or if you have a research-related problem, you may contact the researcher(s), Amy Fox: 919 886 4455: a2fox@ucsd.edu, and Jim Hollan: hollan@ucsd.edu. If you have any questions concerning your rights as a research subject, you may contact the UCSD Human Research Protections Program Office at 858-246-HRPP (858-246-4777). \",\"parentNode\":{\"id\":89}},{\"nodeType\":3,\"id\":100,\"textContent\":\" By clicking “I agree” below you are indicating that: you are at least 18 years old, have read this consent form, and agree to participate in this research study. If you do not wish to participate in the study, please notify the researcher now.\",\"parentNode\":{\"id\":91}},{\"nodeType\":3,\"id\":101,\"textContent\":\" \",\"parentNode\":{\"id\":95}},{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"centered control control-checkbox\"},\"previousSibling\":{\"id\":101},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":103,\"textContent\":\" \",\"previousSibling\":{\"id\":102},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":104,\"textContent\":\" I agree to take part in this study. \",\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":105,\"tagName\":\"INPUT\",\"attributes\":{\"id\":\"consent_checkbox\",\"type\":\"checkbox\"},\"previousSibling\":{\"id\":104},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":106,\"textContent\":\" \",\"previousSibling\":{\"id\":105},\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"},\"previousSibling\":{\"id\":106},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":108,\"textContent\":\" \",\"previousSibling\":{\"id\":107},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":109,\"textContent\":\" \",\"parentNode\":{\"id\":71}},{\"nodeType\":1,\"id\":110,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":109},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":111,\"textContent\":\" \",\"previousSibling\":{\"id\":110},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":112,\"textContent\":\"START\",\"parentNode\":{\"id\":110}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 111, dom: 649, initialDom: 656",
  "javascriptErrors": []
}