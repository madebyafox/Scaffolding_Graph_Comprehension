var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "a82abfac61e152218ba5f4f592941686",
  "created": "2018-05-22T10:14:36.3767447-07:00",
  "lastActivity": "2018-05-22T10:16:15.9387447-07:00",
  "pageViews": [
    {
      "id": "0522367952ba8dcfc9a5782338dfe52edbb5783b",
      "startTime": "2018-05-22T10:14:36.3767447-07:00",
      "endTime": "2018-05-22T10:16:15.9387447-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/4",
      "visitTime": 99562,
      "engagementTime": 86212,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 99562,
  "engagementTime": 86212,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=FSWW4",
    "CONDITION=121"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "570e2f3c1466971c657c377c1b23b5e4",
  "gdpr": false
}