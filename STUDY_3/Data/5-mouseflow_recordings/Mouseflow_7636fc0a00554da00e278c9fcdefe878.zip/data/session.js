var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "7636fc0a00554da00e278c9fcdefe878",
  "created": "2018-06-04T12:32:31.8356985-07:00",
  "lastActivity": "2018-06-04T12:35:47.5011724-07:00",
  "pageViews": [
    {
      "id": "06043263adff7b98ee057e48630d20df050b04db",
      "startTime": "2018-06-04T12:32:31.8356985-07:00",
      "endTime": "2018-06-04T12:35:47.5011724-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 195810,
      "engagementTime": 175229,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 195810,
  "engagementTime": 175229,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.28",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=74OF5",
    "CONDITION=311\n311"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "13d2e8d127c76760b65d502c02d691b6",
  "gdpr": false
}