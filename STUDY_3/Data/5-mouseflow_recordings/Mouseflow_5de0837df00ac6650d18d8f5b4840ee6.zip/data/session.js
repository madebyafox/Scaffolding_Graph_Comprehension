var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "5de0837df00ac6650d18d8f5b4840ee6",
  "created": "2018-05-21T09:15:29.7285398-07:00",
  "lastActivity": "2018-05-21T09:15:47.9551048-07:00",
  "pageViews": [
    {
      "id": "052129353a1249320cd192a8ca5e67f0689f1199",
      "startTime": "2018-05-21T09:15:29.8142404-07:00",
      "endTime": "2018-05-21T09:15:47.9551048-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/9",
      "visitTime": 18214,
      "engagementTime": 18213,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 18214,
  "engagementTime": 18213,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=781AU",
    "CONDITION=111",
    "TRI_CORRECT=1",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "7cf4dcd6a5999abfd4d2bf73716ab77d",
  "gdpr": false
}