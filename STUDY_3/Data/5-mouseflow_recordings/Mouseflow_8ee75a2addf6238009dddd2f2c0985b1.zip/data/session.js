var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "8ee75a2addf6238009dddd2f2c0985b1",
  "created": "2018-06-01T11:12:09.9608488-07:00",
  "lastActivity": "2018-06-01T11:12:40.1251462-07:00",
  "pageViews": [
    {
      "id": "060109607e8e717f8c924962d2c4155415c3f322",
      "startTime": "2018-06-01T11:12:09.9608488-07:00",
      "endTime": "2018-06-01T11:12:40.1251462-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/5",
      "visitTime": 30435,
      "engagementTime": 30386,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 30435,
  "engagementTime": 30386,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.47",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=EER58",
    "CONDITION=311",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "073285658548ee9d668fed2a29c5d53b",
  "gdpr": false
}