var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "f05920af519c108e326258c6f4de5012",
  "created": "2018-05-22T10:23:31.0020486-07:00",
  "lastActivity": "2018-05-22T10:24:41.5904576-07:00",
  "pageViews": [
    {
      "id": "05223124c70fd317083638f822b0733acce944f6",
      "startTime": "2018-05-22T10:23:31.0020486-07:00",
      "endTime": "2018-05-22T10:24:41.5904576-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/13",
      "visitTime": 70589,
      "engagementTime": 70540,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 70589,
  "engagementTime": 70540,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.32",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=MOWH2",
    "CONDITION=121",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "27eaf9c5b63d54721fb3106cfa14b91c",
  "gdpr": false
}