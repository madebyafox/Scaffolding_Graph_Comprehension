var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["060139661bb61b49c6b0b7011013202ed595c2c3"] = {
  "startTime": "2018-06-01T17:20:39.5411732Z",
  "websitePageUrl": "/16",
  "visitTime": 143553,
  "engagementTime": 124317,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "2b18a5ae55ed47876b8ce0434035abde",
    "created": "2018-06-01T17:20:39.5411732+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=9BS72",
      "CONDITION=115"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "9e2eac2992a3a852334242fa8ca75cd3",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/2b18a5ae55ed47876b8ce0434035abde/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 193,
      "e": 193,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 800,
      "e": 800,
      "ty": 2,
      "x": 525,
      "y": 765
    },
    {
      "t": 901,
      "e": 901,
      "ty": 2,
      "x": 523,
      "y": 765
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 41,
      "x": 47876,
      "y": 41935,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1101,
      "e": 1101,
      "ty": 2,
      "x": 520,
      "y": 758
    },
    {
      "t": 1200,
      "e": 1200,
      "ty": 2,
      "x": 519,
      "y": 742
    },
    {
      "t": 1251,
      "e": 1251,
      "ty": 41,
      "x": 47314,
      "y": 40329,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1301,
      "e": 1301,
      "ty": 2,
      "x": 517,
      "y": 729
    },
    {
      "t": 1401,
      "e": 1401,
      "ty": 2,
      "x": 508,
      "y": 690
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 2,
      "x": 502,
      "y": 670
    },
    {
      "t": 1502,
      "e": 1502,
      "ty": 41,
      "x": 45515,
      "y": 36673,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1601,
      "e": 1601,
      "ty": 2,
      "x": 501,
      "y": 664
    },
    {
      "t": 1701,
      "e": 1701,
      "ty": 2,
      "x": 501,
      "y": 642
    },
    {
      "t": 1751,
      "e": 1751,
      "ty": 41,
      "x": 45403,
      "y": 34069,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1783,
      "e": 1783,
      "ty": 6,
      "x": 501,
      "y": 602,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1801,
      "e": 1801,
      "ty": 2,
      "x": 501,
      "y": 591
    },
    {
      "t": 1901,
      "e": 1901,
      "ty": 2,
      "x": 501,
      "y": 580
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 2,
      "x": 501,
      "y": 575
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 41,
      "x": 45403,
      "y": 42286,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2099,
      "e": 2099,
      "ty": 3,
      "x": 501,
      "y": 575,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2101,
      "e": 2101,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2218,
      "e": 2218,
      "ty": 4,
      "x": 45403,
      "y": 42286,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2218,
      "e": 2218,
      "ty": 5,
      "x": 501,
      "y": 575,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5918,
      "e": 5918,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 6047,
      "e": 6047,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 6231,
      "e": 6231,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 6232,
      "e": 6232,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6318,
      "e": 6318,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "t"
    },
    {
      "t": 6335,
      "e": 6335,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 6454,
      "e": 6454,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "t"
    },
    {
      "t": 6455,
      "e": 6455,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 6456,
      "e": 6456,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6534,
      "e": 6534,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "tH"
    },
    {
      "t": 6590,
      "e": 6590,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 6590,
      "e": 6590,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6695,
      "e": 6695,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 6695,
      "e": 6695,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6710,
      "e": 6710,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "tHE "
    },
    {
      "t": 6765,
      "e": 6765,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 6830,
      "e": 6830,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 6830,
      "e": 6830,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6910,
      "e": 6910,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 6910,
      "e": 6910,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6925,
      "e": 6925,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||EV"
    },
    {
      "t": 7014,
      "e": 7014,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 7030,
      "e": 7030,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 7031,
      "e": 7031,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7134,
      "e": 7134,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||E"
    },
    {
      "t": 7215,
      "e": 7215,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 7216,
      "e": 7216,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7367,
      "e": 7367,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||N"
    },
    {
      "t": 7718,
      "e": 7718,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 7791,
      "e": 7791,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "tHE EVE"
    },
    {
      "t": 7874,
      "e": 7874,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 7938,
      "e": 7938,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "tHE EV"
    },
    {
      "t": 8033,
      "e": 8033,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 8081,
      "e": 8081,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "tHE E"
    },
    {
      "t": 8177,
      "e": 8177,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 8217,
      "e": 8217,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "tHE "
    },
    {
      "t": 8321,
      "e": 8321,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 8370,
      "e": 8370,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "tHE"
    },
    {
      "t": 8465,
      "e": 8465,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 8530,
      "e": 8530,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "tH"
    },
    {
      "t": 8626,
      "e": 8626,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 8681,
      "e": 8681,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "t"
    },
    {
      "t": 8793,
      "e": 8793,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 8858,
      "e": 8858,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 9330,
      "e": 9330,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 9331,
      "e": 9331,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9409,
      "e": 9409,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "T"
    },
    {
      "t": 10004,
      "e": 10004,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10250,
      "e": 10250,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 10251,
      "e": 10251,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10313,
      "e": 10313,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "TO"
    },
    {
      "t": 10610,
      "e": 10610,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 10689,
      "e": 10689,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "T"
    },
    {
      "t": 10769,
      "e": 10769,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 10898,
      "e": 10898,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "T"
    },
    {
      "t": 10970,
      "e": 10970,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 10971,
      "e": 10971,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11058,
      "e": 11058,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To"
    },
    {
      "t": 11121,
      "e": 11121,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11121,
      "e": 11121,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11209,
      "e": 11209,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To "
    },
    {
      "t": 11242,
      "e": 11242,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 11242,
      "e": 11242,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11377,
      "e": 11377,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 11377,
      "e": 11377,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11385,
      "e": 11385,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To de"
    },
    {
      "t": 11514,
      "e": 11514,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 11578,
      "e": 11578,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 11579,
      "e": 11579,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11706,
      "e": 11706,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 11794,
      "e": 11794,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 11794,
      "e": 11794,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11929,
      "e": 11929,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 11929,
      "e": 11929,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11969,
      "e": 11969,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 12082,
      "e": 12082,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12170,
      "e": 12170,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 12170,
      "e": 12170,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12178,
      "e": 12178,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 12179,
      "e": 12179,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12209,
      "e": 12209,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m,"
    },
    {
      "t": 12233,
      "e": 12233,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12417,
      "e": 12417,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 12418,
      "e": 12418,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12506,
      "e": 12506,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 12602,
      "e": 12602,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 12603,
      "e": 12603,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12689,
      "e": 12689,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 12697,
      "e": 12697,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 12697,
      "e": 12697,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12785,
      "e": 12785,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 12810,
      "e": 12810,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12810,
      "e": 12810,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12906,
      "e": 12906,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 13007,
      "e": 13007,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determ,ine "
    },
    {
      "t": 13130,
      "e": 13130,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13193,
      "e": 13193,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determ,ine"
    },
    {
      "t": 13297,
      "e": 13297,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13354,
      "e": 13354,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determ,in"
    },
    {
      "t": 13450,
      "e": 13450,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13506,
      "e": 13506,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determ,i"
    },
    {
      "t": 13603,
      "e": 13603,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13649,
      "e": 13649,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determ,"
    },
    {
      "t": 13746,
      "e": 13746,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13810,
      "e": 13810,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determ"
    },
    {
      "t": 14354,
      "e": 14354,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 14355,
      "e": 14355,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14409,
      "e": 14409,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 14554,
      "e": 14554,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 14554,
      "e": 14554,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14633,
      "e": 14633,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 14665,
      "e": 14665,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 14666,
      "e": 14666,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14754,
      "e": 14754,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 14770,
      "e": 14770,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14770,
      "e": 14770,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14857,
      "e": 14857,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 14898,
      "e": 14898,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 14898,
      "e": 14898,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15003,
      "e": 15003,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 15003,
      "e": 15003,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15010,
      "e": 15010,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||wh"
    },
    {
      "t": 15082,
      "e": 15082,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 15161,
      "e": 15161,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 15162,
      "e": 15162,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15210,
      "e": 15210,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 15994,
      "e": 15994,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 15995,
      "e": 15995,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16065,
      "e": 16065,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 16081,
      "e": 16081,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 16082,
      "e": 16082,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16161,
      "e": 16161,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 16259,
      "e": 16259,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16259,
      "e": 16259,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16348,
      "e": 16348,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 16658,
      "e": 16658,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 16659,
      "e": 16659,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16722,
      "e": 16722,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 16818,
      "e": 16818,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 16818,
      "e": 16818,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16881,
      "e": 16881,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 16914,
      "e": 16914,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 16914,
      "e": 16914,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17017,
      "e": 17017,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 17058,
      "e": 17058,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 17058,
      "e": 17058,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17147,
      "e": 17147,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 17202,
      "e": 17202,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 17204,
      "e": 17204,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17266,
      "e": 17266,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 17298,
      "e": 17298,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17299,
      "e": 17299,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17385,
      "e": 17385,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 17482,
      "e": 17482,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 17482,
      "e": 17482,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17606,
      "e": 17606,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine which event s"
    },
    {
      "t": 17610,
      "e": 17610,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 17610,
      "e": 17610,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17617,
      "e": 17617,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||st"
    },
    {
      "t": 17690,
      "e": 17690,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17730,
      "e": 17730,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 17730,
      "e": 17730,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17850,
      "e": 17850,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 17857,
      "e": 17857,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 17858,
      "e": 17858,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17921,
      "e": 17921,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 18010,
      "e": 18010,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 18011,
      "e": 18011,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18081,
      "e": 18081,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 18082,
      "e": 18082,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18089,
      "e": 18089,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ts"
    },
    {
      "t": 18177,
      "e": 18177,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18234,
      "e": 18234,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18234,
      "e": 18234,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18306,
      "e": 18306,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18330,
      "e": 18330,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 18331,
      "e": 18331,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18441,
      "e": 18441,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 18442,
      "e": 18442,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18449,
      "e": 18449,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 18514,
      "e": 18514,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18682,
      "e": 18682,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18683,
      "e": 18683,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18762,
      "e": 18762,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18865,
      "e": 18865,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 18866,
      "e": 18866,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19006,
      "e": 19006,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine which event starts at 1"
    },
    {
      "t": 19018,
      "e": 19018,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 19018,
      "e": 19018,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19041,
      "e": 19041,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 19147,
      "e": 19147,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19385,
      "e": 19385,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 19385,
      "e": 19385,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19441,
      "e": 19441,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 19586,
      "e": 19586,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 19587,
      "e": 19587,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19674,
      "e": 19674,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 20209,
      "e": 20209,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 20290,
      "e": 20290,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine which event starts at 12p"
    },
    {
      "t": 20406,
      "e": 20406,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine which event starts at 12p"
    },
    {
      "t": 20962,
      "e": 20962,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 20963,
      "e": 20963,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21026,
      "e": 21026,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 21868,
      "e": 21868,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 21869,
      "e": 21869,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21921,
      "e": 21921,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 22114,
      "e": 22114,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22115,
      "e": 22115,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22169,
      "e": 22169,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22649,
      "e": 22649,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 22770,
      "e": 22770,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22771,
      "e": 22771,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 22771,
      "e": 22771,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22841,
      "e": 22841,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||Y"
    },
    {
      "t": 22865,
      "e": 22865,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 22978,
      "e": 22978,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22986,
      "e": 22986,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 22986,
      "e": 22986,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23001,
      "e": 23001,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 23001,
      "e": 23001,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23065,
      "e": 23065,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ou"
    },
    {
      "t": 23073,
      "e": 23073,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23138,
      "e": 23138,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23138,
      "e": 23138,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23241,
      "e": 23241,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 23450,
      "e": 23450,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 23450,
      "e": 23450,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23473,
      "e": 23473,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 23606,
      "e": 23606,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine which event starts at 12pm. You l"
    },
    {
      "t": 24913,
      "e": 24913,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 24985,
      "e": 24985,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine which event starts at 12pm. You "
    },
    {
      "t": 25266,
      "e": 25266,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 25267,
      "e": 25267,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25330,
      "e": 25330,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 25442,
      "e": 25442,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 25443,
      "e": 25443,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25498,
      "e": 25498,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 25606,
      "e": 25606,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine which event starts at 12pm. You go"
    },
    {
      "t": 27962,
      "e": 27962,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 28025,
      "e": 28025,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine which event starts at 12pm. You g"
    },
    {
      "t": 28155,
      "e": 28155,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 28209,
      "e": 28209,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine which event starts at 12pm. You "
    },
    {
      "t": 28370,
      "e": 28370,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 28410,
      "e": 28410,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine which event starts at 12pm. You"
    },
    {
      "t": 29066,
      "e": 29066,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29067,
      "e": 29067,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29137,
      "e": 29137,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 29633,
      "e": 29633,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 29634,
      "e": 29634,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29697,
      "e": 29697,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 29801,
      "e": 29801,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 29803,
      "e": 29801,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29865,
      "e": 29863,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 29961,
      "e": 29959,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 29961,
      "e": 29959,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30009,
      "e": 30007,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 30130,
      "e": 30128,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 30130,
      "e": 30128,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30193,
      "e": 30191,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 30241,
      "e": 30239,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30241,
      "e": 30239,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30338,
      "e": 30336,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30394,
      "e": 30392,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 30395,
      "e": 30393,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30465,
      "e": 30463,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 30465,
      "e": 30463,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30505,
      "e": 30503,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 30545,
      "e": 30543,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30602,
      "e": 30600,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30602,
      "e": 30600,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30689,
      "e": 30687,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30714,
      "e": 30712,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 30714,
      "e": 30712,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30785,
      "e": 30783,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 30898,
      "e": 30896,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 30899,
      "e": 30897,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30986,
      "e": 30984,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 31001,
      "e": 30999,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 31003,
      "e": 31001,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31074,
      "e": 31072,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31074,
      "e": 31072,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31081,
      "e": 31079,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 31138,
      "e": 31136,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 31177,
      "e": 31175,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 31177,
      "e": 31175,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31241,
      "e": 31239,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 31386,
      "e": 31384,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 31387,
      "e": 31385,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31465,
      "e": 31463,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 31497,
      "e": 31495,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 31497,
      "e": 31495,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31577,
      "e": 31575,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 31658,
      "e": 31656,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 31659,
      "e": 31657,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31729,
      "e": 31727,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 31753,
      "e": 31751,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 31753,
      "e": 31751,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31817,
      "e": 31815,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 31922,
      "e": 31920,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 31923,
      "e": 31921,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32009,
      "e": 32007,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 32057,
      "e": 32055,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32057,
      "e": 32055,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32169,
      "e": 32167,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 32194,
      "e": 32192,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 32194,
      "e": 32192,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32281,
      "e": 32279,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 32345,
      "e": 32343,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 32345,
      "e": 32343,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32425,
      "e": 32423,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32425,
      "e": 32423,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32433,
      "e": 32431,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f "
    },
    {
      "t": 32522,
      "e": 32520,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32618,
      "e": 32616,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 32619,
      "e": 32617,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32697,
      "e": 32695,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 32729,
      "e": 32727,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 32729,
      "e": 32727,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32802,
      "e": 32800,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 32866,
      "e": 32864,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 32866,
      "e": 32864,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32945,
      "e": 32943,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32945,
      "e": 32943,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32970,
      "e": 32968,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 33033,
      "e": 33031,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33130,
      "e": 33128,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 33131,
      "e": 33129,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33225,
      "e": 33223,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 33225,
      "e": 33223,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33233,
      "e": 33231,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ch"
    },
    {
      "t": 33282,
      "e": 33280,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33345,
      "e": 33343,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 33345,
      "e": 33343,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33474,
      "e": 33472,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 33530,
      "e": 33528,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 33531,
      "e": 33529,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33617,
      "e": 33615,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 33673,
      "e": 33671,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 33673,
      "e": 33671,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33778,
      "e": 33776,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 33865,
      "e": 33863,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33866,
      "e": 33864,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33970,
      "e": 33968,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 34050,
      "e": 34048,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 34050,
      "e": 34048,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34170,
      "e": 34168,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 34209,
      "e": 34207,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 34210,
      "e": 34208,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34297,
      "e": 34295,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 34354,
      "e": 34352,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 34354,
      "e": 34352,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34466,
      "e": 34464,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 34466,
      "e": 34464,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34481,
      "e": 34479,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 34546,
      "e": 34544,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34642,
      "e": 34640,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34642,
      "e": 34640,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34753,
      "e": 34751,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 34754,
      "e": 34752,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34769,
      "e": 34767,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 34890,
      "e": 34888,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34937,
      "e": 34935,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 34939,
      "e": 34937,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35017,
      "e": 35015,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 35097,
      "e": 35095,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 35098,
      "e": 35096,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35207,
      "e": 35205,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine which event starts at 12pm. You look at the bottom of the chart with the"
    },
    {
      "t": 35218,
      "e": 35216,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 35265,
      "e": 35263,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 35267,
      "e": 35265,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35361,
      "e": 35359,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 38049,
      "e": 38047,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 38051,
      "e": 38048,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38137,
      "e": 38134,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 38162,
      "e": 38159,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 38162,
      "e": 38159,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38329,
      "e": 38326,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 38458,
      "e": 38455,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 38459,
      "e": 38456,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38490,
      "e": 38487,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 38606,
      "e": 38603,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine which event starts at 12pm. You look at the bottom of the chart with the lav"
    },
    {
      "t": 38834,
      "e": 38831,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 38913,
      "e": 38910,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine which event starts at 12pm. You look at the bottom of the chart with the la"
    },
    {
      "t": 39314,
      "e": 39311,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 39314,
      "e": 39311,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39378,
      "e": 39375,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 39514,
      "e": 39511,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 39514,
      "e": 39511,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39586,
      "e": 39583,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 39665,
      "e": 39662,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 39665,
      "e": 39662,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39738,
      "e": 39735,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 39818,
      "e": 39815,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 39818,
      "e": 39815,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39905,
      "e": 39902,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 39945,
      "e": 39942,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 39945,
      "e": 39942,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40025,
      "e": 40022,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 40130,
      "e": 40127,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 40130,
      "e": 40127,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40169,
      "e": 40166,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 40282,
      "e": 40279,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 40282,
      "e": 40279,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40354,
      "e": 40351,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 40402,
      "e": 40399,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 40403,
      "e": 40400,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40465,
      "e": 40462,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 40914,
      "e": 40911,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 40914,
      "e": 40911,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41001,
      "e": 40998,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 41057,
      "e": 41054,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 41057,
      "e": 41054,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41129,
      "e": 41126,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 41250,
      "e": 41247,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 41250,
      "e": 41247,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41329,
      "e": 41326,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 41353,
      "e": 41350,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 41354,
      "e": 41351,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41474,
      "e": 41471,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 41538,
      "e": 41535,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 41540,
      "e": 41537,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41641,
      "e": 41638,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 41890,
      "e": 41887,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 41891,
      "e": 41888,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41994,
      "e": 41991,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 42138,
      "e": 42135,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 42274,
      "e": 42271,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 42314,
      "e": 42311,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 42315,
      "e": 42312,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42385,
      "e": 42382,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||Y"
    },
    {
      "t": 42417,
      "e": 42414,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "20"
    },
    {
      "t": 42513,
      "e": 42510,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 42530,
      "e": 42527,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 42531,
      "e": 42528,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42601,
      "e": 42598,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 42601,
      "e": 42598,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42657,
      "e": 42654,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ou"
    },
    {
      "t": 42682,
      "e": 42679,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 42722,
      "e": 42719,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 42722,
      "e": 42719,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42833,
      "e": 42830,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 42873,
      "e": 42870,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 42873,
      "e": 42870,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42946,
      "e": 42943,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 43042,
      "e": 43039,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 43043,
      "e": 43040,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43114,
      "e": 43111,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 43194,
      "e": 43191,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 43195,
      "e": 43192,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43289,
      "e": 43286,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 43361,
      "e": 43358,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 43362,
      "e": 43359,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43450,
      "e": 43447,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 43466,
      "e": 43463,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 43466,
      "e": 43463,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43546,
      "e": 43543,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 43778,
      "e": 43775,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 43833,
      "e": 43830,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine which event starts at 12pm. You look at the bottom of the chart with the labels of time. You go t"
    },
    {
      "t": 43945,
      "e": 43942,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 44002,
      "e": 43943,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine which event starts at 12pm. You look at the bottom of the chart with the labels of time. You go "
    },
    {
      "t": 44089,
      "e": 44030,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 44145,
      "e": 44086,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine which event starts at 12pm. You look at the bottom of the chart with the labels of time. You go"
    },
    {
      "t": 44233,
      "e": 44174,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 44305,
      "e": 44246,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine which event starts at 12pm. You look at the bottom of the chart with the labels of time. You g"
    },
    {
      "t": 44385,
      "e": 44326,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 44449,
      "e": 44390,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine which event starts at 12pm. You look at the bottom of the chart with the labels of time. You "
    },
    {
      "t": 45042,
      "e": 44983,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 45043,
      "e": 44984,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45114,
      "e": 45055,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 45146,
      "e": 45087,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 45147,
      "e": 45088,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45202,
      "e": 45143,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 45337,
      "e": 45278,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 45338,
      "e": 45279,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45417,
      "e": 45358,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 45474,
      "e": 45415,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 45474,
      "e": 45415,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45562,
      "e": 45503,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 45578,
      "e": 45519,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 45579,
      "e": 45520,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45682,
      "e": 45623,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 46706,
      "e": 46647,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 46706,
      "e": 46647,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46881,
      "e": 46822,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 46882,
      "e": 46823,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46913,
      "e": 46854,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 47010,
      "e": 46951,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 48938,
      "e": 48879,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 48939,
      "e": 48880,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49001,
      "e": 48942,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 49242,
      "e": 49183,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 49242,
      "e": 49183,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49321,
      "e": 49262,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 49386,
      "e": 49327,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 49387,
      "e": 49328,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49481,
      "e": 49422,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 49650,
      "e": 49591,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 49651,
      "e": 49592,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49729,
      "e": 49670,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 50004,
      "e": 49945,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 50233,
      "e": 50174,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 50233,
      "e": 50174,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50313,
      "e": 50254,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 50442,
      "e": 50383,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 50442,
      "e": 50383,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50554,
      "e": 50495,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 50730,
      "e": 50671,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 50731,
      "e": 50672,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 50817,
      "e": 50758,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 51106,
      "e": 51047,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 51106,
      "e": 51047,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51257,
      "e": 51198,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 51322,
      "e": 51263,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 51322,
      "e": 51263,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51401,
      "e": 51342,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 51498,
      "e": 51439,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 51498,
      "e": 51439,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51569,
      "e": 51510,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 51609,
      "e": 51550,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 51609,
      "e": 51550,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51698,
      "e": 51639,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 51698,
      "e": 51639,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51705,
      "e": 51646,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 51777,
      "e": 51718,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 51833,
      "e": 51774,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 51833,
      "e": 51774,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51922,
      "e": 51863,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 52026,
      "e": 51967,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 52027,
      "e": 51968,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52113,
      "e": 52054,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 52121,
      "e": 52062,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 52121,
      "e": 52062,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52218,
      "e": 52159,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 52242,
      "e": 52183,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 52242,
      "e": 52183,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52321,
      "e": 52262,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 52346,
      "e": 52287,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 52346,
      "e": 52287,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52435,
      "e": 52376,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 52441,
      "e": 52382,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 52441,
      "e": 52382,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52554,
      "e": 52495,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 52651,
      "e": 52592,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 52651,
      "e": 52592,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52737,
      "e": 52678,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 52738,
      "e": 52679,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52785,
      "e": 52726,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 52809,
      "e": 52750,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 52857,
      "e": 52798,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 52857,
      "e": 52798,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52930,
      "e": 52871,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 53121,
      "e": 53062,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 53123,
      "e": 53064,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53209,
      "e": 53150,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 53898,
      "e": 53839,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 53898,
      "e": 53839,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 53985,
      "e": 53926,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 54114,
      "e": 54055,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 54114,
      "e": 54055,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54201,
      "e": 54142,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 54337,
      "e": 54278,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 54338,
      "e": 54279,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54458,
      "e": 54399,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 54473,
      "e": 54414,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 54474,
      "e": 54415,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 54585,
      "e": 54526,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 55682,
      "e": 55623,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 55682,
      "e": 55623,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 55761,
      "e": 55702,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 56265,
      "e": 56206,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 56337,
      "e": 56278,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine which event starts at 12pm. You look at the bottom of the chart with the labels of time. You find 12pm and anything that lies "
    },
    {
      "t": 56433,
      "e": 56374,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 56489,
      "e": 56430,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine which event starts at 12pm. You look at the bottom of the chart with the labels of time. You find 12pm and anything that lies"
    },
    {
      "t": 56593,
      "e": 56534,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 56657,
      "e": 56598,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine which event starts at 12pm. You look at the bottom of the chart with the labels of time. You find 12pm and anything that lie"
    },
    {
      "t": 56753,
      "e": 56694,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 56818,
      "e": 56695,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine which event starts at 12pm. You look at the bottom of the chart with the labels of time. You find 12pm and anything that li"
    },
    {
      "t": 57090,
      "e": 56967,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 57152,
      "e": 57029,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine which event starts at 12pm. You look at the bottom of the chart with the labels of time. You find 12pm and anything that l"
    },
    {
      "t": 57249,
      "e": 57126,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 57249,
      "e": 57126,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57337,
      "e": 57214,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 57513,
      "e": 57390,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 57514,
      "e": 57391,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57577,
      "e": 57454,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 57609,
      "e": 57486,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 57609,
      "e": 57486,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57697,
      "e": 57574,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 57698,
      "e": 57575,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 57698,
      "e": 57575,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 57801,
      "e": 57678,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 59242,
      "e": 59119,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 59243,
      "e": 59120,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59304,
      "e": 59181,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||b"
    },
    {
      "t": 59369,
      "e": 59246,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 59369,
      "e": 59246,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59449,
      "e": 59326,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 59553,
      "e": 59430,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 59554,
      "e": 59431,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59625,
      "e": 59502,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 59673,
      "e": 59550,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 59673,
      "e": 59550,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59785,
      "e": 59662,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 59874,
      "e": 59751,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 59874,
      "e": 59751,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 59945,
      "e": 59822,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 60049,
      "e": 59926,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 60050,
      "e": 59927,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60138,
      "e": 60015,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 60154,
      "e": 60031,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 60154,
      "e": 60031,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60241,
      "e": 60118,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 60322,
      "e": 60199,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 60322,
      "e": 60199,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60409,
      "e": 60286,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 60411,
      "e": 60288,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60425,
      "e": 60302,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 60505,
      "e": 60382,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 60545,
      "e": 60422,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 60546,
      "e": 60423,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60618,
      "e": 60495,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 60674,
      "e": 60551,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 60674,
      "e": 60551,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60753,
      "e": 60630,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 60753,
      "e": 60630,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 60769,
      "e": 60646,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 60841,
      "e": 60718,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 61234,
      "e": 61111,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 61234,
      "e": 61111,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61312,
      "e": 61189,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 61482,
      "e": 61359,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 61483,
      "e": 61360,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61546,
      "e": 61423,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 61674,
      "e": 61551,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 61675,
      "e": 61552,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61752,
      "e": 61629,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 61873,
      "e": 61750,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 61874,
      "e": 61751,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 61946,
      "e": 61823,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 63546,
      "e": 63423,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 63546,
      "e": 63423,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63625,
      "e": 63502,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 63713,
      "e": 63590,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 63713,
      "e": 63590,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63801,
      "e": 63678,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 63976,
      "e": 63853,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 63977,
      "e": 63854,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64065,
      "e": 63942,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 64208,
      "e": 64085,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 64209,
      "e": 64086,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64314,
      "e": 64191,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 64433,
      "e": 64310,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 64436,
      "e": 64313,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64560,
      "e": 64437,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 64625,
      "e": 64502,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 64626,
      "e": 64503,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64722,
      "e": 64599,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 64866,
      "e": 64743,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 64866,
      "e": 64743,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64993,
      "e": 64870,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 64993,
      "e": 64870,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65025,
      "e": 64902,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ds"
    },
    {
      "t": 65129,
      "e": 65006,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 65137,
      "e": 65014,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 65137,
      "e": 65014,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65234,
      "e": 65111,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 65466,
      "e": 65343,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 65467,
      "e": 65344,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65553,
      "e": 65430,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 65561,
      "e": 65438,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 65561,
      "e": 65438,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65665,
      "e": 65438,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 65994,
      "e": 65767,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 65995,
      "e": 65768,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66073,
      "e": 65846,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 66073,
      "e": 65846,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66105,
      "e": 65878,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||an"
    },
    {
      "t": 66161,
      "e": 65934,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 66193,
      "e": 65966,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 66193,
      "e": 65966,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66322,
      "e": 66095,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 66441,
      "e": 66214,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 66442,
      "e": 66215,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66569,
      "e": 66342,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 66866,
      "e": 66639,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 66866,
      "e": 66639,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66945,
      "e": 66718,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 66969,
      "e": 66742,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 66969,
      "e": 66742,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67057,
      "e": 66830,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 67146,
      "e": 66919,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 67146,
      "e": 66919,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67233,
      "e": 67006,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 67233,
      "e": 67006,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67297,
      "e": 67070,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 67305,
      "e": 67078,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 67386,
      "e": 67159,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 67387,
      "e": 67160,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67465,
      "e": 67238,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 67553,
      "e": 67326,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 67553,
      "e": 67326,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67618,
      "e": 67391,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 68149,
      "e": 67922,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 68235,
      "e": 68008,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine which event starts at 12pm. You look at the bottom of the chart with the labels of time. You find 12pm and anything that lays between the line upwards means that "
    },
    {
      "t": 68388,
      "e": 68161,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 68389,
      "e": 68162,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68532,
      "e": 68305,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 69220,
      "e": 68993,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 69221,
      "e": 68994,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69307,
      "e": 69080,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 69380,
      "e": 69153,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 69380,
      "e": 69153,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69459,
      "e": 69232,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 69564,
      "e": 69337,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 69565,
      "e": 69338,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69660,
      "e": 69433,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 69660,
      "e": 69433,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 69660,
      "e": 69433,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69732,
      "e": 69505,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 69772,
      "e": 69545,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 69773,
      "e": 69546,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69884,
      "e": 69657,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 69916,
      "e": 69689,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 69917,
      "e": 69690,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70004,
      "e": 69777,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 70060,
      "e": 69833,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 70060,
      "e": 69833,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70155,
      "e": 69928,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 70195,
      "e": 69968,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 70195,
      "e": 69968,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70292,
      "e": 70065,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 70533,
      "e": 70306,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 70533,
      "e": 70306,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70627,
      "e": 70400,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 70628,
      "e": 70401,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70635,
      "e": 70408,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||st"
    },
    {
      "t": 70711,
      "e": 70484,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 70763,
      "e": 70536,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 70763,
      "e": 70536,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70867,
      "e": 70640,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 70868,
      "e": 70641,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70883,
      "e": 70656,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 70932,
      "e": 70705,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 71028,
      "e": 70801,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 71028,
      "e": 70801,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71108,
      "e": 70881,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 71115,
      "e": 70888,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 71116,
      "e": 70889,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71228,
      "e": 71001,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 71252,
      "e": 71025,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 71253,
      "e": 71026,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71340,
      "e": 71113,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 71340,
      "e": 71113,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 71340,
      "e": 71113,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71476,
      "e": 71249,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 71548,
      "e": 71321,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 71550,
      "e": 71323,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71620,
      "e": 71393,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 71708,
      "e": 71481,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 71709,
      "e": 71482,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 71803,
      "e": 71576,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 71924,
      "e": 71697,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 71924,
      "e": 71697,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72084,
      "e": 71857,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 72085,
      "e": 71858,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72099,
      "e": 71872,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 72208,
      "e": 71872,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine which event starts at 12pm. You look at the bottom of the chart with the labels of time. You find 12pm and anything that lays between the line upwards means that an event starts at 12"
    },
    {
      "t": 72211,
      "e": 71875,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 72435,
      "e": 72099,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 72436,
      "e": 72100,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72515,
      "e": 72179,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 72740,
      "e": 72404,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 72740,
      "e": 72404,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 72788,
      "e": 72452,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 73228,
      "e": 72892,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 73229,
      "e": 72893,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73276,
      "e": 72940,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 73408,
      "e": 73072,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine which event starts at 12pm. You look at the bottom of the chart with the labels of time. You find 12pm and anything that lays between the line upwards means that an event starts at 12pm."
    },
    {
      "t": 74206,
      "e": 73870,
      "ty": 2,
      "x": 499,
      "y": 594
    },
    {
      "t": 74212,
      "e": 73876,
      "ty": 7,
      "x": 488,
      "y": 616,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74247,
      "e": 73911,
      "ty": 6,
      "x": 440,
      "y": 672,
      "ta": "#strategyButton"
    },
    {
      "t": 74256,
      "e": 73920,
      "ty": 41,
      "x": 55380,
      "y": 33279,
      "ta": "#strategyButton"
    },
    {
      "t": 74264,
      "e": 73928,
      "ty": 7,
      "x": 386,
      "y": 690,
      "ta": "#strategyButton"
    },
    {
      "t": 74307,
      "e": 73971,
      "ty": 2,
      "x": 370,
      "y": 690
    },
    {
      "t": 74314,
      "e": 73978,
      "ty": 6,
      "x": 368,
      "y": 688,
      "ta": "#strategyButton"
    },
    {
      "t": 74406,
      "e": 74070,
      "ty": 2,
      "x": 365,
      "y": 667
    },
    {
      "t": 74464,
      "e": 74128,
      "ty": 7,
      "x": 365,
      "y": 653,
      "ta": "#strategyButton"
    },
    {
      "t": 74506,
      "e": 74170,
      "ty": 2,
      "x": 367,
      "y": 651
    },
    {
      "t": 74506,
      "e": 74170,
      "ty": 41,
      "x": 22659,
      "y": 19179,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 74706,
      "e": 74370,
      "ty": 2,
      "x": 368,
      "y": 651
    },
    {
      "t": 74757,
      "e": 74421,
      "ty": 41,
      "x": 23127,
      "y": 19179,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 74897,
      "e": 74561,
      "ty": 6,
      "x": 366,
      "y": 658,
      "ta": "#strategyButton"
    },
    {
      "t": 74906,
      "e": 74570,
      "ty": 2,
      "x": 366,
      "y": 658
    },
    {
      "t": 75006,
      "e": 74670,
      "ty": 2,
      "x": 359,
      "y": 661
    },
    {
      "t": 75006,
      "e": 74670,
      "ty": 41,
      "x": 11144,
      "y": 12076,
      "ta": "#strategyButton"
    },
    {
      "t": 75107,
      "e": 74771,
      "ty": 2,
      "x": 360,
      "y": 666
    },
    {
      "t": 75207,
      "e": 74871,
      "ty": 2,
      "x": 361,
      "y": 675
    },
    {
      "t": 75225,
      "e": 74889,
      "ty": 3,
      "x": 361,
      "y": 675,
      "ta": "#strategyButton"
    },
    {
      "t": 75226,
      "e": 74890,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To determine which event starts at 12pm. You look at the bottom of the chart with the labels of time. You find 12pm and anything that lays between the line upwards means that an event starts at 12pm."
    },
    {
      "t": 75227,
      "e": 74891,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75227,
      "e": 74891,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 75256,
      "e": 74920,
      "ty": 41,
      "x": 12236,
      "y": 39061,
      "ta": "#strategyButton"
    },
    {
      "t": 75352,
      "e": 75016,
      "ty": 4,
      "x": 12236,
      "y": 39061,
      "ta": "#strategyButton"
    },
    {
      "t": 75363,
      "e": 75027,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 75364,
      "e": 75028,
      "ty": 5,
      "x": 361,
      "y": 675,
      "ta": "#strategyButton"
    },
    {
      "t": 75369,
      "e": 75033,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 75406,
      "e": 75070,
      "ty": 2,
      "x": 360,
      "y": 676
    },
    {
      "t": 75506,
      "e": 75170,
      "ty": 2,
      "x": 357,
      "y": 679
    },
    {
      "t": 75507,
      "e": 75171,
      "ty": 41,
      "x": 12018,
      "y": 37171,
      "ta": "html > body"
    },
    {
      "t": 75606,
      "e": 75270,
      "ty": 2,
      "x": 364,
      "y": 666
    },
    {
      "t": 75757,
      "e": 75421,
      "ty": 41,
      "x": 12259,
      "y": 36451,
      "ta": "html > body"
    },
    {
      "t": 76371,
      "e": 76035,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 76807,
      "e": 76471,
      "ty": 2,
      "x": 374,
      "y": 661
    },
    {
      "t": 76907,
      "e": 76571,
      "ty": 2,
      "x": 973,
      "y": 602
    },
    {
      "t": 77007,
      "e": 76671,
      "ty": 2,
      "x": 1054,
      "y": 588
    },
    {
      "t": 77007,
      "e": 76671,
      "ty": 41,
      "x": 53206,
      "y": 3523,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 77207,
      "e": 76672,
      "ty": 2,
      "x": 1049,
      "y": 587
    },
    {
      "t": 77233,
      "e": 76698,
      "ty": 6,
      "x": 1046,
      "y": 570,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 77257,
      "e": 76722,
      "ty": 41,
      "x": 51043,
      "y": 37448,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 77306,
      "e": 76771,
      "ty": 2,
      "x": 1043,
      "y": 562
    },
    {
      "t": 77406,
      "e": 76871,
      "ty": 2,
      "x": 1042,
      "y": 561
    },
    {
      "t": 77441,
      "e": 76906,
      "ty": 3,
      "x": 1042,
      "y": 561,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 77441,
      "e": 76906,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 77507,
      "e": 76972,
      "ty": 41,
      "x": 50611,
      "y": 21845,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 77559,
      "e": 77024,
      "ty": 4,
      "x": 50611,
      "y": 21845,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 77560,
      "e": 77025,
      "ty": 5,
      "x": 1042,
      "y": 561,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 77757,
      "e": 77222,
      "ty": 41,
      "x": 49529,
      "y": 21845,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 77807,
      "e": 77272,
      "ty": 2,
      "x": 1029,
      "y": 557
    },
    {
      "t": 78006,
      "e": 77471,
      "ty": 41,
      "x": 47799,
      "y": 9362,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 78260,
      "e": 77725,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "98"
    },
    {
      "t": 78261,
      "e": 77726,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 78403,
      "e": 77868,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 78420,
      "e": 77885,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "96"
    },
    {
      "t": 78420,
      "e": 77885,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 78508,
      "e": 77973,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 78968,
      "e": 78433,
      "ty": 7,
      "x": 956,
      "y": 583,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 79007,
      "e": 78472,
      "ty": 2,
      "x": 937,
      "y": 590
    },
    {
      "t": 79007,
      "e": 78472,
      "ty": 41,
      "x": 27901,
      "y": 4932,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 79107,
      "e": 78572,
      "ty": 2,
      "x": 947,
      "y": 639
    },
    {
      "t": 79151,
      "e": 78616,
      "ty": 6,
      "x": 951,
      "y": 650,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 79207,
      "e": 78672,
      "ty": 2,
      "x": 953,
      "y": 651
    },
    {
      "t": 79257,
      "e": 78722,
      "ty": 41,
      "x": 31794,
      "y": 18724,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 79306,
      "e": 78771,
      "ty": 2,
      "x": 955,
      "y": 653
    },
    {
      "t": 79406,
      "e": 78871,
      "ty": 2,
      "x": 955,
      "y": 660
    },
    {
      "t": 79496,
      "e": 78961,
      "ty": 3,
      "x": 955,
      "y": 661,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 79497,
      "e": 78962,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 79497,
      "e": 78962,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 79497,
      "e": 78962,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 79506,
      "e": 78971,
      "ty": 2,
      "x": 955,
      "y": 661
    },
    {
      "t": 79507,
      "e": 78972,
      "ty": 41,
      "x": 31794,
      "y": 43690,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 79600,
      "e": 79065,
      "ty": 4,
      "x": 31794,
      "y": 43690,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 79600,
      "e": 79065,
      "ty": 5,
      "x": 955,
      "y": 661,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 79707,
      "e": 79172,
      "ty": 2,
      "x": 952,
      "y": 663
    },
    {
      "t": 79757,
      "e": 79222,
      "ty": 41,
      "x": 31145,
      "y": 49931,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 80476,
      "e": 79941,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "20"
    },
    {
      "t": 80644,
      "e": 80109,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 80668,
      "e": 80133,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 80668,
      "e": 80133,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 80740,
      "e": 80205,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 80812,
      "e": 80277,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 80812,
      "e": 80277,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 80955,
      "e": 80420,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 80955,
      "e": 80420,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 81020,
      "e": 80485,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 81116,
      "e": 80581,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 81507,
      "e": 80972,
      "ty": 2,
      "x": 951,
      "y": 663
    },
    {
      "t": 81507,
      "e": 80972,
      "ty": 41,
      "x": 30929,
      "y": 49931,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 81575,
      "e": 81040,
      "ty": 7,
      "x": 951,
      "y": 669,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 81606,
      "e": 81071,
      "ty": 2,
      "x": 950,
      "y": 670
    },
    {
      "t": 81636,
      "e": 81101,
      "ty": 6,
      "x": 942,
      "y": 680,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 81703,
      "e": 81168,
      "ty": 7,
      "x": 931,
      "y": 713,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 81707,
      "e": 81172,
      "ty": 2,
      "x": 931,
      "y": 713
    },
    {
      "t": 81757,
      "e": 81222,
      "ty": 41,
      "x": 31751,
      "y": 39165,
      "ta": "html > body"
    },
    {
      "t": 81807,
      "e": 81272,
      "ty": 2,
      "x": 930,
      "y": 715
    },
    {
      "t": 81906,
      "e": 81371,
      "ty": 2,
      "x": 934,
      "y": 713
    },
    {
      "t": 82007,
      "e": 81472,
      "ty": 2,
      "x": 940,
      "y": 709
    },
    {
      "t": 82007,
      "e": 81472,
      "ty": 41,
      "x": 32095,
      "y": 38833,
      "ta": "html > body"
    },
    {
      "t": 82136,
      "e": 81601,
      "ty": 3,
      "x": 940,
      "y": 709,
      "ta": "html > body"
    },
    {
      "t": 82137,
      "e": 81602,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 82138,
      "e": 81603,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 82199,
      "e": 81664,
      "ty": 4,
      "x": 32095,
      "y": 38833,
      "ta": "html > body"
    },
    {
      "t": 82199,
      "e": 81664,
      "ty": 5,
      "x": 940,
      "y": 709,
      "ta": "html > body"
    },
    {
      "t": 82393,
      "e": 81858,
      "ty": 6,
      "x": 940,
      "y": 708,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 82407,
      "e": 81872,
      "ty": 2,
      "x": 942,
      "y": 706
    },
    {
      "t": 82507,
      "e": 81972,
      "ty": 2,
      "x": 945,
      "y": 701
    },
    {
      "t": 82507,
      "e": 81972,
      "ty": 41,
      "x": 25294,
      "y": 49647,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 82545,
      "e": 82010,
      "ty": 3,
      "x": 945,
      "y": 701,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 82545,
      "e": 82010,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 82664,
      "e": 82129,
      "ty": 4,
      "x": 25294,
      "y": 49647,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 82664,
      "e": 82129,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 82664,
      "e": 82129,
      "ty": 5,
      "x": 945,
      "y": 701,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 82664,
      "e": 82129,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 82907,
      "e": 82372,
      "ty": 2,
      "x": 937,
      "y": 698
    },
    {
      "t": 83007,
      "e": 82472,
      "ty": 2,
      "x": 932,
      "y": 697
    },
    {
      "t": 83007,
      "e": 82472,
      "ty": 41,
      "x": 31820,
      "y": 38168,
      "ta": "html > body"
    },
    {
      "t": 83107,
      "e": 82572,
      "ty": 2,
      "x": 914,
      "y": 691
    },
    {
      "t": 83257,
      "e": 82722,
      "ty": 41,
      "x": 31200,
      "y": 37836,
      "ta": "html > body"
    },
    {
      "t": 83691,
      "e": 83156,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 83707,
      "e": 83172,
      "ty": 2,
      "x": 913,
      "y": 689
    },
    {
      "t": 83756,
      "e": 83221,
      "ty": 41,
      "x": 24588,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 83806,
      "e": 83271,
      "ty": 2,
      "x": 913,
      "y": 680
    },
    {
      "t": 84407,
      "e": 83872,
      "ty": 2,
      "x": 912,
      "y": 610
    },
    {
      "t": 84506,
      "e": 83971,
      "ty": 2,
      "x": 904,
      "y": 473
    },
    {
      "t": 84507,
      "e": 83972,
      "ty": 41,
      "x": 19597,
      "y": 37448,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 84606,
      "e": 84071,
      "ty": 2,
      "x": 901,
      "y": 426
    },
    {
      "t": 84706,
      "e": 84171,
      "ty": 2,
      "x": 897,
      "y": 412
    },
    {
      "t": 84757,
      "e": 84222,
      "ty": 41,
      "x": 10816,
      "y": 44470,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 84807,
      "e": 84272,
      "ty": 2,
      "x": 866,
      "y": 366
    },
    {
      "t": 84907,
      "e": 84372,
      "ty": 2,
      "x": 778,
      "y": 151
    },
    {
      "t": 85007,
      "e": 84472,
      "ty": 41,
      "x": 26517,
      "y": 7921,
      "ta": "html > body"
    },
    {
      "t": 85107,
      "e": 84572,
      "ty": 2,
      "x": 806,
      "y": 199
    },
    {
      "t": 85207,
      "e": 84672,
      "ty": 2,
      "x": 825,
      "y": 244
    },
    {
      "t": 85256,
      "e": 84721,
      "ty": 41,
      "x": 5386,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 85306,
      "e": 84771,
      "ty": 2,
      "x": 829,
      "y": 251
    },
    {
      "t": 85406,
      "e": 84871,
      "ty": 2,
      "x": 830,
      "y": 250
    },
    {
      "t": 85507,
      "e": 84972,
      "ty": 2,
      "x": 830,
      "y": 249
    },
    {
      "t": 85508,
      "e": 84973,
      "ty": 41,
      "x": 2035,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 85539,
      "e": 85004,
      "ty": 6,
      "x": 832,
      "y": 241,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 85606,
      "e": 85071,
      "ty": 2,
      "x": 832,
      "y": 240
    },
    {
      "t": 85757,
      "e": 85222,
      "ty": 41,
      "x": 28120,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 85906,
      "e": 85371,
      "ty": 2,
      "x": 832,
      "y": 239
    },
    {
      "t": 86006,
      "e": 85471,
      "ty": 41,
      "x": 28120,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 86040,
      "e": 85505,
      "ty": 7,
      "x": 830,
      "y": 248,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 86106,
      "e": 85571,
      "ty": 2,
      "x": 831,
      "y": 255
    },
    {
      "t": 86159,
      "e": 85624,
      "ty": 6,
      "x": 831,
      "y": 261,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 86206,
      "e": 85671,
      "ty": 2,
      "x": 831,
      "y": 265
    },
    {
      "t": 86256,
      "e": 85721,
      "ty": 41,
      "x": 23079,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 86312,
      "e": 85777,
      "ty": 3,
      "x": 831,
      "y": 265,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 86313,
      "e": 85778,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 86440,
      "e": 85905,
      "ty": 4,
      "x": 23079,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 86441,
      "e": 85906,
      "ty": 5,
      "x": 831,
      "y": 265,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 86442,
      "e": 85907,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf",
      "v": "Spanish"
    },
    {
      "t": 86506,
      "e": 85971,
      "ty": 2,
      "x": 834,
      "y": 267
    },
    {
      "t": 86506,
      "e": 85971,
      "ty": 41,
      "x": 38202,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 86540,
      "e": 86005,
      "ty": 7,
      "x": 835,
      "y": 277,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 86556,
      "e": 86021,
      "ty": 6,
      "x": 837,
      "y": 290,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 86591,
      "e": 86056,
      "ty": 7,
      "x": 840,
      "y": 301,
      "ta": "jspsych-survey-multi-choice-response-0[2]_mf"
    },
    {
      "t": 86607,
      "e": 86072,
      "ty": 2,
      "x": 840,
      "y": 301
    },
    {
      "t": 86706,
      "e": 86171,
      "ty": 2,
      "x": 840,
      "y": 310
    },
    {
      "t": 86757,
      "e": 86222,
      "ty": 41,
      "x": 5358,
      "y": 13450,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 86806,
      "e": 86271,
      "ty": 2,
      "x": 849,
      "y": 369
    },
    {
      "t": 86906,
      "e": 86371,
      "ty": 2,
      "x": 851,
      "y": 390
    },
    {
      "t": 87006,
      "e": 86471,
      "ty": 2,
      "x": 849,
      "y": 400
    },
    {
      "t": 87007,
      "e": 86472,
      "ty": 41,
      "x": 6544,
      "y": 12186,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 87106,
      "e": 86571,
      "ty": 2,
      "x": 847,
      "y": 401
    },
    {
      "t": 87206,
      "e": 86671,
      "ty": 2,
      "x": 843,
      "y": 409
    },
    {
      "t": 87256,
      "e": 86721,
      "ty": 41,
      "x": 25259,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 87306,
      "e": 86771,
      "ty": 2,
      "x": 841,
      "y": 414
    },
    {
      "t": 87406,
      "e": 86871,
      "ty": 2,
      "x": 840,
      "y": 416
    },
    {
      "t": 87506,
      "e": 86971,
      "ty": 41,
      "x": 21747,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 88928,
      "e": 88393,
      "ty": 6,
      "x": 839,
      "y": 418,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 88959,
      "e": 88424,
      "ty": 7,
      "x": 839,
      "y": 424,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 89006,
      "e": 88471,
      "ty": 2,
      "x": 839,
      "y": 431
    },
    {
      "t": 89006,
      "e": 88471,
      "ty": 41,
      "x": 4171,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 89055,
      "e": 88520,
      "ty": 6,
      "x": 839,
      "y": 436,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 89106,
      "e": 88571,
      "ty": 2,
      "x": 839,
      "y": 437
    },
    {
      "t": 89206,
      "e": 88671,
      "ty": 2,
      "x": 835,
      "y": 441
    },
    {
      "t": 89256,
      "e": 88721,
      "ty": 41,
      "x": 18037,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 89306,
      "e": 88771,
      "ty": 2,
      "x": 830,
      "y": 443
    },
    {
      "t": 89495,
      "e": 88960,
      "ty": 3,
      "x": 830,
      "y": 443,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 89497,
      "e": 88962,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 89497,
      "e": 88962,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 89600,
      "e": 89065,
      "ty": 4,
      "x": 18037,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 89600,
      "e": 89065,
      "ty": 5,
      "x": 830,
      "y": 443,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 89600,
      "e": 89065,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf",
      "v": "Second"
    },
    {
      "t": 90006,
      "e": 89471,
      "ty": 2,
      "x": 828,
      "y": 444
    },
    {
      "t": 90007,
      "e": 89472,
      "ty": 41,
      "x": 7955,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 90106,
      "e": 89571,
      "ty": 2,
      "x": 827,
      "y": 445
    },
    {
      "t": 90127,
      "e": 89592,
      "ty": 7,
      "x": 826,
      "y": 450,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 90206,
      "e": 89671,
      "ty": 2,
      "x": 844,
      "y": 532
    },
    {
      "t": 90258,
      "e": 89673,
      "ty": 41,
      "x": 40282,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-1-6 > label"
    },
    {
      "t": 90306,
      "e": 89721,
      "ty": 2,
      "x": 872,
      "y": 620
    },
    {
      "t": 90406,
      "e": 89821,
      "ty": 2,
      "x": 879,
      "y": 649
    },
    {
      "t": 90506,
      "e": 89921,
      "ty": 2,
      "x": 884,
      "y": 670
    },
    {
      "t": 90506,
      "e": 89921,
      "ty": 41,
      "x": 16802,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 90606,
      "e": 90021,
      "ty": 2,
      "x": 885,
      "y": 673
    },
    {
      "t": 90706,
      "e": 90121,
      "ty": 2,
      "x": 885,
      "y": 675
    },
    {
      "t": 90756,
      "e": 90171,
      "ty": 41,
      "x": 16802,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 90807,
      "e": 90222,
      "ty": 2,
      "x": 869,
      "y": 703
    },
    {
      "t": 90906,
      "e": 90321,
      "ty": 2,
      "x": 869,
      "y": 704
    },
    {
      "t": 91007,
      "e": 90422,
      "ty": 41,
      "x": 11988,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 91206,
      "e": 90621,
      "ty": 2,
      "x": 859,
      "y": 706
    },
    {
      "t": 91256,
      "e": 90671,
      "ty": 41,
      "x": 8713,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 91306,
      "e": 90721,
      "ty": 2,
      "x": 852,
      "y": 725
    },
    {
      "t": 91406,
      "e": 90821,
      "ty": 2,
      "x": 840,
      "y": 748
    },
    {
      "t": 91464,
      "e": 90879,
      "ty": 6,
      "x": 838,
      "y": 752,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 91506,
      "e": 90921,
      "ty": 2,
      "x": 837,
      "y": 756
    },
    {
      "t": 91506,
      "e": 90921,
      "ty": 41,
      "x": 53325,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 91560,
      "e": 90975,
      "ty": 7,
      "x": 837,
      "y": 767,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 91606,
      "e": 91021,
      "ty": 2,
      "x": 835,
      "y": 776
    },
    {
      "t": 91703,
      "e": 91118,
      "ty": 6,
      "x": 835,
      "y": 780,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 91706,
      "e": 91121,
      "ty": 2,
      "x": 835,
      "y": 780
    },
    {
      "t": 91756,
      "e": 91171,
      "ty": 41,
      "x": 43243,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 91806,
      "e": 91221,
      "ty": 2,
      "x": 834,
      "y": 790
    },
    {
      "t": 91844,
      "e": 91259,
      "ty": 7,
      "x": 834,
      "y": 795,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 91906,
      "e": 91321,
      "ty": 2,
      "x": 834,
      "y": 799
    },
    {
      "t": 92006,
      "e": 91421,
      "ty": 2,
      "x": 834,
      "y": 802
    },
    {
      "t": 92006,
      "e": 91421,
      "ty": 41,
      "x": 2985,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 92095,
      "e": 91510,
      "ty": 6,
      "x": 834,
      "y": 808,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 92106,
      "e": 91521,
      "ty": 2,
      "x": 834,
      "y": 808
    },
    {
      "t": 92206,
      "e": 91621,
      "ty": 2,
      "x": 834,
      "y": 819
    },
    {
      "t": 92248,
      "e": 91663,
      "ty": 7,
      "x": 834,
      "y": 821,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 92257,
      "e": 91672,
      "ty": 41,
      "x": 7424,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 92306,
      "e": 91721,
      "ty": 2,
      "x": 834,
      "y": 822
    },
    {
      "t": 92406,
      "e": 91821,
      "ty": 2,
      "x": 834,
      "y": 826
    },
    {
      "t": 92506,
      "e": 91921,
      "ty": 2,
      "x": 834,
      "y": 833
    },
    {
      "t": 92506,
      "e": 91921,
      "ty": 41,
      "x": 8862,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 92756,
      "e": 92171,
      "ty": 41,
      "x": 8862,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 92763,
      "e": 92178,
      "ty": 6,
      "x": 834,
      "y": 836,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 92807,
      "e": 92222,
      "ty": 2,
      "x": 834,
      "y": 837
    },
    {
      "t": 92906,
      "e": 92321,
      "ty": 2,
      "x": 836,
      "y": 842
    },
    {
      "t": 93007,
      "e": 92422,
      "ty": 2,
      "x": 836,
      "y": 843
    },
    {
      "t": 93007,
      "e": 92422,
      "ty": 41,
      "x": 48284,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 93107,
      "e": 92522,
      "ty": 2,
      "x": 836,
      "y": 846
    },
    {
      "t": 93256,
      "e": 92671,
      "ty": 41,
      "x": 48284,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 93907,
      "e": 92671,
      "ty": 2,
      "x": 836,
      "y": 848
    },
    {
      "t": 94006,
      "e": 92770,
      "ty": 41,
      "x": 48284,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 94089,
      "e": 92853,
      "ty": 7,
      "x": 836,
      "y": 849,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 94106,
      "e": 92870,
      "ty": 2,
      "x": 836,
      "y": 849
    },
    {
      "t": 94256,
      "e": 93020,
      "ty": 41,
      "x": 10271,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 94746,
      "e": 93510,
      "ty": 6,
      "x": 834,
      "y": 847,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 94757,
      "e": 93521,
      "ty": 41,
      "x": 38202,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 94806,
      "e": 93570,
      "ty": 2,
      "x": 834,
      "y": 846
    },
    {
      "t": 94897,
      "e": 93661,
      "ty": 3,
      "x": 834,
      "y": 846,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 94898,
      "e": 93662,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 94899,
      "e": 93663,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 95007,
      "e": 93771,
      "ty": 41,
      "x": 38202,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 95039,
      "e": 93803,
      "ty": 4,
      "x": 38202,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 95040,
      "e": 93804,
      "ty": 5,
      "x": 834,
      "y": 846,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 95040,
      "e": 93804,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf",
      "v": "Fine Arts"
    },
    {
      "t": 98106,
      "e": 96870,
      "ty": 2,
      "x": 831,
      "y": 845
    },
    {
      "t": 98257,
      "e": 97021,
      "ty": 41,
      "x": 23079,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 98406,
      "e": 97170,
      "ty": 2,
      "x": 829,
      "y": 845
    },
    {
      "t": 98506,
      "e": 97270,
      "ty": 41,
      "x": 12996,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 98606,
      "e": 97370,
      "ty": 2,
      "x": 826,
      "y": 845
    },
    {
      "t": 98688,
      "e": 97452,
      "ty": 7,
      "x": 825,
      "y": 847,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 98706,
      "e": 97470,
      "ty": 2,
      "x": 824,
      "y": 847
    },
    {
      "t": 98757,
      "e": 97521,
      "ty": 41,
      "x": 1111,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 98807,
      "e": 97571,
      "ty": 2,
      "x": 823,
      "y": 852
    },
    {
      "t": 98907,
      "e": 97671,
      "ty": 2,
      "x": 822,
      "y": 873
    },
    {
      "t": 99007,
      "e": 97771,
      "ty": 2,
      "x": 821,
      "y": 889
    },
    {
      "t": 99007,
      "e": 97771,
      "ty": 41,
      "x": 0,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 99107,
      "e": 97871,
      "ty": 2,
      "x": 822,
      "y": 896
    },
    {
      "t": 99206,
      "e": 97970,
      "ty": 2,
      "x": 823,
      "y": 899
    },
    {
      "t": 99257,
      "e": 98021,
      "ty": 41,
      "x": 1086,
      "y": 15123,
      "ta": "#jspsych-survey-multi-choice-3"
    },
    {
      "t": 99306,
      "e": 98070,
      "ty": 2,
      "x": 829,
      "y": 914
    },
    {
      "t": 99406,
      "e": 98170,
      "ty": 2,
      "x": 833,
      "y": 922
    },
    {
      "t": 99507,
      "e": 98271,
      "ty": 41,
      "x": 2747,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 99507,
      "e": 98271,
      "ty": 2,
      "x": 833,
      "y": 924
    },
    {
      "t": 99607,
      "e": 98371,
      "ty": 2,
      "x": 833,
      "y": 927
    },
    {
      "t": 99663,
      "e": 98427,
      "ty": 6,
      "x": 833,
      "y": 929,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 99706,
      "e": 98470,
      "ty": 2,
      "x": 833,
      "y": 929
    },
    {
      "t": 99752,
      "e": 98516,
      "ty": 3,
      "x": 833,
      "y": 929,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 99752,
      "e": 98516,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 99753,
      "e": 98517,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 99756,
      "e": 98520,
      "ty": 41,
      "x": 33161,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 99807,
      "e": 98571,
      "ty": 2,
      "x": 833,
      "y": 930
    },
    {
      "t": 99903,
      "e": 98667,
      "ty": 4,
      "x": 28120,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 99903,
      "e": 98667,
      "ty": 5,
      "x": 832,
      "y": 933,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 99904,
      "e": 98668,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 99906,
      "e": 98670,
      "ty": 2,
      "x": 832,
      "y": 933
    },
    {
      "t": 100006,
      "e": 98770,
      "ty": 2,
      "x": 831,
      "y": 940
    },
    {
      "t": 100007,
      "e": 98771,
      "ty": 41,
      "x": 23079,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 100007,
      "e": 98771,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 100104,
      "e": 98868,
      "ty": 7,
      "x": 831,
      "y": 941,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 100107,
      "e": 98871,
      "ty": 2,
      "x": 831,
      "y": 941
    },
    {
      "t": 100206,
      "e": 98970,
      "ty": 2,
      "x": 831,
      "y": 942
    },
    {
      "t": 100257,
      "e": 99021,
      "ty": 41,
      "x": 10461,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 100384,
      "e": 99148,
      "ty": 6,
      "x": 833,
      "y": 959,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 100406,
      "e": 99170,
      "ty": 2,
      "x": 834,
      "y": 966
    },
    {
      "t": 100418,
      "e": 99182,
      "ty": 7,
      "x": 835,
      "y": 970,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 100506,
      "e": 99270,
      "ty": 2,
      "x": 837,
      "y": 982
    },
    {
      "t": 100506,
      "e": 99270,
      "ty": 41,
      "x": 15464,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-3-2 > label"
    },
    {
      "t": 100569,
      "e": 99333,
      "ty": 6,
      "x": 837,
      "y": 985,
      "ta": "jspsych-survey-multi-choice-response-3[2]_mf"
    },
    {
      "t": 100606,
      "e": 99370,
      "ty": 2,
      "x": 837,
      "y": 988
    },
    {
      "t": 100707,
      "e": 99471,
      "ty": 2,
      "x": 838,
      "y": 992
    },
    {
      "t": 100753,
      "e": 99517,
      "ty": 7,
      "x": 840,
      "y": 993,
      "ta": "jspsych-survey-multi-choice-response-3[2]_mf"
    },
    {
      "t": 100757,
      "e": 99521,
      "ty": 41,
      "x": 18442,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-3-2 > label"
    },
    {
      "t": 100806,
      "e": 99570,
      "ty": 2,
      "x": 842,
      "y": 998
    },
    {
      "t": 100906,
      "e": 99670,
      "ty": 2,
      "x": 845,
      "y": 1004
    },
    {
      "t": 100928,
      "e": 99692,
      "ty": 6,
      "x": 845,
      "y": 1005,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 101006,
      "e": 99770,
      "ty": 41,
      "x": 8544,
      "y": 7943,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 101007,
      "e": 99771,
      "ty": 2,
      "x": 846,
      "y": 1009
    },
    {
      "t": 101106,
      "e": 99870,
      "ty": 2,
      "x": 846,
      "y": 1011
    },
    {
      "t": 101207,
      "e": 99971,
      "ty": 2,
      "x": 847,
      "y": 1012
    },
    {
      "t": 101256,
      "e": 100020,
      "ty": 41,
      "x": 9574,
      "y": 15887,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 101306,
      "e": 100070,
      "ty": 2,
      "x": 848,
      "y": 1013
    },
    {
      "t": 101608,
      "e": 100372,
      "ty": 3,
      "x": 848,
      "y": 1013,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 101610,
      "e": 100374,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 101610,
      "e": 100374,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 102184,
      "e": 100948,
      "ty": 4,
      "x": 9574,
      "y": 15887,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 102185,
      "e": 100949,
      "ty": 5,
      "x": 848,
      "y": 1013,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 102192,
      "e": 100956,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 102195,
      "e": 100959,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 102197,
      "e": 100961,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 103586,
      "e": 102350,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 103907,
      "e": 102671,
      "ty": 2,
      "x": 845,
      "y": 1011
    },
    {
      "t": 104007,
      "e": 102771,
      "ty": 41,
      "x": 27134,
      "y": 61263,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 104106,
      "e": 102870,
      "ty": 2,
      "x": 847,
      "y": 1011
    },
    {
      "t": 104207,
      "e": 102971,
      "ty": 2,
      "x": 856,
      "y": 1012
    },
    {
      "t": 104257,
      "e": 103021,
      "ty": 41,
      "x": 27675,
      "y": 61332,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 104406,
      "e": 103170,
      "ty": 2,
      "x": 877,
      "y": 1012
    },
    {
      "t": 104506,
      "e": 103270,
      "ty": 41,
      "x": 28708,
      "y": 61332,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 110006,
      "e": 108270,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 127506,
      "e": 108270,
      "ty": 2,
      "x": 881,
      "y": 1025
    },
    {
      "t": 127507,
      "e": 108271,
      "ty": 41,
      "x": 28905,
      "y": 62232,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 127606,
      "e": 108370,
      "ty": 2,
      "x": 886,
      "y": 1036
    },
    {
      "t": 127756,
      "e": 108520,
      "ty": 41,
      "x": 29299,
      "y": 63271,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 127806,
      "e": 108570,
      "ty": 2,
      "x": 894,
      "y": 1040
    },
    {
      "t": 127906,
      "e": 108670,
      "ty": 2,
      "x": 893,
      "y": 1035
    },
    {
      "t": 128007,
      "e": 108771,
      "ty": 41,
      "x": 29495,
      "y": 62925,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 128610,
      "e": 109374,
      "ty": 2,
      "x": 893,
      "y": 1036
    },
    {
      "t": 128710,
      "e": 109474,
      "ty": 2,
      "x": 901,
      "y": 1042
    },
    {
      "t": 128760,
      "e": 109524,
      "ty": 41,
      "x": 30086,
      "y": 63756,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 128810,
      "e": 109574,
      "ty": 2,
      "x": 909,
      "y": 1052
    },
    {
      "t": 128909,
      "e": 109673,
      "ty": 2,
      "x": 914,
      "y": 1059
    },
    {
      "t": 129010,
      "e": 109774,
      "ty": 2,
      "x": 920,
      "y": 1067
    },
    {
      "t": 129010,
      "e": 109774,
      "ty": 41,
      "x": 30824,
      "y": 65141,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 129110,
      "e": 109874,
      "ty": 2,
      "x": 920,
      "y": 1068
    },
    {
      "t": 129210,
      "e": 109974,
      "ty": 2,
      "x": 921,
      "y": 1071
    },
    {
      "t": 129260,
      "e": 110024,
      "ty": 41,
      "x": 30873,
      "y": 65418,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 129949,
      "e": 110713,
      "ty": 6,
      "x": 921,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 130009,
      "e": 110773,
      "ty": 2,
      "x": 921,
      "y": 1072
    },
    {
      "t": 130009,
      "e": 110773,
      "ty": 41,
      "x": 6280,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 134260,
      "e": 115024,
      "ty": 41,
      "x": 6280,
      "y": 602,
      "ta": "#start"
    },
    {
      "t": 134310,
      "e": 115074,
      "ty": 2,
      "x": 924,
      "y": 1076
    },
    {
      "t": 134410,
      "e": 115174,
      "ty": 2,
      "x": 925,
      "y": 1076
    },
    {
      "t": 134510,
      "e": 115274,
      "ty": 2,
      "x": 927,
      "y": 1078
    },
    {
      "t": 134510,
      "e": 115274,
      "ty": 41,
      "x": 9557,
      "y": 10239,
      "ta": "#start"
    },
    {
      "t": 134610,
      "e": 115374,
      "ty": 2,
      "x": 928,
      "y": 1080
    },
    {
      "t": 134760,
      "e": 115524,
      "ty": 41,
      "x": 10103,
      "y": 14094,
      "ta": "#start"
    },
    {
      "t": 135110,
      "e": 115874,
      "ty": 2,
      "x": 930,
      "y": 1082
    },
    {
      "t": 135210,
      "e": 115974,
      "ty": 2,
      "x": 931,
      "y": 1082
    },
    {
      "t": 135260,
      "e": 116024,
      "ty": 41,
      "x": 11741,
      "y": 17949,
      "ta": "#start"
    },
    {
      "t": 135910,
      "e": 116674,
      "ty": 2,
      "x": 932,
      "y": 1083
    },
    {
      "t": 136011,
      "e": 116775,
      "ty": 41,
      "x": 12287,
      "y": 19877,
      "ta": "#start"
    },
    {
      "t": 136260,
      "e": 117024,
      "ty": 41,
      "x": 12833,
      "y": 23732,
      "ta": "#start"
    },
    {
      "t": 136310,
      "e": 117074,
      "ty": 2,
      "x": 934,
      "y": 1086
    },
    {
      "t": 136510,
      "e": 117274,
      "ty": 2,
      "x": 936,
      "y": 1088
    },
    {
      "t": 136511,
      "e": 117275,
      "ty": 41,
      "x": 14472,
      "y": 29514,
      "ta": "#start"
    },
    {
      "t": 137010,
      "e": 117774,
      "ty": 2,
      "x": 938,
      "y": 1088
    },
    {
      "t": 137011,
      "e": 117775,
      "ty": 41,
      "x": 15564,
      "y": 29514,
      "ta": "#start"
    },
    {
      "t": 140010,
      "e": 120774,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 140795,
      "e": 121559,
      "ty": 3,
      "x": 938,
      "y": 1088,
      "ta": "#start"
    },
    {
      "t": 140795,
      "e": 121559,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 141218,
      "e": 121982,
      "ty": 4,
      "x": 15564,
      "y": 29514,
      "ta": "#start"
    },
    {
      "t": 141219,
      "e": 121983,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 141220,
      "e": 121984,
      "ty": 5,
      "x": 938,
      "y": 1088,
      "ta": "#start"
    },
    {
      "t": 141220,
      "e": 121984,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 142246,
      "e": 123010,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 143553,
      "e": 124317,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 17225, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 17227, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"9BS72\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 22620, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 40928, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"9BS72\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 42556, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"WHISKEY\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"115\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 84487, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"9BS72\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 12755, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 98567, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"9BS72\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 11857, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 111427, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"9BS72\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 32277, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 145077, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"9BS72\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1847,y:1012,t:1527873160913};\\\", \\\"{x:1834,y:1007,t:1527873160945};\\\", \\\"{x:1828,y:1003,t:1527873160946};\\\", \\\"{x:1398,y:875,t:1527873161139};\\\", \\\"{x:844,y:833,t:1527873161292};\\\", \\\"{x:804,y:837,t:1527873161298};\\\", \\\"{x:721,y:848,t:1527873161316};\\\", \\\"{x:679,y:855,t:1527873161332};\\\", \\\"{x:655,y:853,t:1527873161349};\\\", \\\"{x:631,y:844,t:1527873161366};\\\", \\\"{x:592,y:822,t:1527873161382};\\\", \\\"{x:556,y:799,t:1527873161399};\\\", \\\"{x:518,y:767,t:1527873161416};\\\", \\\"{x:507,y:749,t:1527873161432};\\\", \\\"{x:507,y:743,t:1527873161449};\\\", \\\"{x:507,y:742,t:1527873161466};\\\", \\\"{x:505,y:740,t:1527873161491};\\\", \\\"{x:505,y:737,t:1527873161499};\\\", \\\"{x:505,y:723,t:1527873161516};\\\", \\\"{x:505,y:710,t:1527873161531};\\\", \\\"{x:505,y:708,t:1527873161764};\\\", \\\"{x:510,y:704,t:1527873161773};\\\", \\\"{x:515,y:701,t:1527873161783};\\\", \\\"{x:527,y:688,t:1527873161800};\\\", \\\"{x:532,y:674,t:1527873161816};\\\", \\\"{x:537,y:659,t:1527873161833};\\\", \\\"{x:543,y:655,t:1527873161849};\\\", \\\"{x:548,y:653,t:1527873161866};\\\", \\\"{x:549,y:649,t:1527873161885};\\\", \\\"{x:550,y:648,t:1527873161899};\\\", \\\"{x:550,y:645,t:1527873161923};\\\", \\\"{x:550,y:644,t:1527873161933};\\\", \\\"{x:550,y:642,t:1527873161948};\\\", \\\"{x:550,y:641,t:1527873161966};\\\", \\\"{x:552,y:639,t:1527873161983};\\\", \\\"{x:552,y:637,t:1527873162003};\\\", \\\"{x:553,y:637,t:1527873162016};\\\", \\\"{x:554,y:634,t:1527873162033};\\\", \\\"{x:553,y:633,t:1527873162820};\\\", \\\"{x:552,y:633,t:1527873162835};\\\", \\\"{x:551,y:632,t:1527873162932};\\\", \\\"{x:553,y:630,t:1527873162948};\\\", \\\"{x:555,y:627,t:1527873162956};\\\", \\\"{x:555,y:625,t:1527873162968};\\\", \\\"{x:558,y:622,t:1527873162984};\\\", \\\"{x:558,y:621,t:1527873163027};\\\", \\\"{x:560,y:619,t:1527873163828};\\\", \\\"{x:563,y:617,t:1527873163842};\\\", \\\"{x:575,y:617,t:1527873163850};\\\", \\\"{x:604,y:617,t:1527873163868};\\\", \\\"{x:636,y:619,t:1527873163884};\\\", \\\"{x:660,y:625,t:1527873163902};\\\", \\\"{x:682,y:630,t:1527873163918};\\\", \\\"{x:699,y:632,t:1527873163934};\\\", \\\"{x:713,y:635,t:1527873163951};\\\", \\\"{x:727,y:637,t:1527873163969};\\\", \\\"{x:747,y:641,t:1527873163984};\\\", \\\"{x:763,y:645,t:1527873164001};\\\", \\\"{x:771,y:646,t:1527873164018};\\\", \\\"{x:775,y:649,t:1527873164034};\\\", \\\"{x:782,y:650,t:1527873164051};\\\", \\\"{x:794,y:654,t:1527873164069};\\\", \\\"{x:815,y:660,t:1527873164085};\\\", \\\"{x:836,y:665,t:1527873164101};\\\", \\\"{x:848,y:669,t:1527873164118};\\\", \\\"{x:855,y:670,t:1527873164134};\\\", \\\"{x:865,y:672,t:1527873164152};\\\", \\\"{x:872,y:672,t:1527873164168};\\\", \\\"{x:881,y:674,t:1527873164184};\\\", \\\"{x:889,y:675,t:1527873164201};\\\", \\\"{x:898,y:678,t:1527873164219};\\\", \\\"{x:911,y:680,t:1527873164235};\\\", \\\"{x:943,y:684,t:1527873164252};\\\", \\\"{x:973,y:692,t:1527873164268};\\\", \\\"{x:1011,y:700,t:1527873164285};\\\", \\\"{x:1045,y:710,t:1527873164301};\\\", \\\"{x:1071,y:717,t:1527873164319};\\\", \\\"{x:1096,y:724,t:1527873164335};\\\", \\\"{x:1114,y:729,t:1527873164352};\\\", \\\"{x:1129,y:734,t:1527873164368};\\\", \\\"{x:1141,y:739,t:1527873164385};\\\", \\\"{x:1153,y:745,t:1527873164402};\\\", \\\"{x:1162,y:749,t:1527873164419};\\\", \\\"{x:1168,y:752,t:1527873164436};\\\", \\\"{x:1171,y:753,t:1527873164452};\\\", \\\"{x:1176,y:758,t:1527873164469};\\\", \\\"{x:1184,y:771,t:1527873164485};\\\", \\\"{x:1191,y:789,t:1527873164501};\\\", \\\"{x:1199,y:817,t:1527873164519};\\\", \\\"{x:1202,y:832,t:1527873164536};\\\", \\\"{x:1206,y:850,t:1527873164552};\\\", \\\"{x:1210,y:862,t:1527873164568};\\\", \\\"{x:1213,y:874,t:1527873164585};\\\", \\\"{x:1216,y:884,t:1527873164601};\\\", \\\"{x:1216,y:890,t:1527873164618};\\\", \\\"{x:1216,y:893,t:1527873164635};\\\", \\\"{x:1216,y:895,t:1527873164652};\\\", \\\"{x:1216,y:898,t:1527873164668};\\\", \\\"{x:1216,y:904,t:1527873164685};\\\", \\\"{x:1216,y:910,t:1527873164701};\\\", \\\"{x:1216,y:912,t:1527873164718};\\\", \\\"{x:1216,y:914,t:1527873164735};\\\", \\\"{x:1216,y:917,t:1527873164752};\\\", \\\"{x:1216,y:920,t:1527873164768};\\\", \\\"{x:1216,y:921,t:1527873164785};\\\", \\\"{x:1216,y:923,t:1527873164802};\\\", \\\"{x:1216,y:924,t:1527873164836};\\\", \\\"{x:1216,y:926,t:1527873164859};\\\", \\\"{x:1216,y:927,t:1527873164875};\\\", \\\"{x:1216,y:929,t:1527873164891};\\\", \\\"{x:1217,y:929,t:1527873164903};\\\", \\\"{x:1217,y:930,t:1527873164919};\\\", \\\"{x:1219,y:933,t:1527873164936};\\\", \\\"{x:1219,y:934,t:1527873164952};\\\", \\\"{x:1220,y:936,t:1527873164968};\\\", \\\"{x:1221,y:936,t:1527873164986};\\\", \\\"{x:1222,y:937,t:1527873165003};\\\", \\\"{x:1222,y:938,t:1527873165018};\\\", \\\"{x:1223,y:939,t:1527873165035};\\\", \\\"{x:1224,y:939,t:1527873165052};\\\", \\\"{x:1225,y:940,t:1527873165100};\\\", \\\"{x:1225,y:941,t:1527873165116};\\\", \\\"{x:1227,y:941,t:1527873165124};\\\", \\\"{x:1230,y:942,t:1527873165136};\\\", \\\"{x:1236,y:947,t:1527873165153};\\\", \\\"{x:1245,y:949,t:1527873165169};\\\", \\\"{x:1250,y:952,t:1527873165186};\\\", \\\"{x:1251,y:952,t:1527873165203};\\\", \\\"{x:1254,y:954,t:1527873165220};\\\", \\\"{x:1254,y:955,t:1527873165269};\\\", \\\"{x:1255,y:955,t:1527873165276};\\\", \\\"{x:1255,y:956,t:1527873165285};\\\", \\\"{x:1256,y:956,t:1527873165316};\\\", \\\"{x:1256,y:957,t:1527873165324};\\\", \\\"{x:1257,y:957,t:1527873165340};\\\", \\\"{x:1258,y:958,t:1527873165356};\\\", \\\"{x:1259,y:958,t:1527873165371};\\\", \\\"{x:1260,y:959,t:1527873165385};\\\", \\\"{x:1266,y:961,t:1527873165402};\\\", \\\"{x:1269,y:962,t:1527873165419};\\\", \\\"{x:1270,y:962,t:1527873165451};\\\", \\\"{x:1271,y:963,t:1527873165597};\\\", \\\"{x:1271,y:964,t:1527873165612};\\\", \\\"{x:1271,y:965,t:1527873165620};\\\", \\\"{x:1273,y:966,t:1527873165989};\\\", \\\"{x:1275,y:966,t:1527873166020};\\\", \\\"{x:1277,y:966,t:1527873166036};\\\", \\\"{x:1278,y:966,t:1527873166054};\\\", \\\"{x:1279,y:966,t:1527873166100};\\\", \\\"{x:1279,y:967,t:1527873166237};\\\", \\\"{x:1281,y:967,t:1527873166637};\\\", \\\"{x:1282,y:967,t:1527873167422};\\\", \\\"{x:1282,y:965,t:1527873170998};\\\", \\\"{x:1282,y:964,t:1527873173526};\\\", \\\"{x:1282,y:963,t:1527873173549};\\\", \\\"{x:1282,y:962,t:1527873173565};\\\", \\\"{x:1282,y:961,t:1527873173573};\\\", \\\"{x:1282,y:960,t:1527873173605};\\\", \\\"{x:1282,y:959,t:1527873173629};\\\", \\\"{x:1282,y:958,t:1527873173725};\\\", \\\"{x:1282,y:957,t:1527873173790};\\\", \\\"{x:1282,y:956,t:1527873173802};\\\", \\\"{x:1282,y:955,t:1527873173828};\\\", \\\"{x:1282,y:954,t:1527873173886};\\\", \\\"{x:1282,y:953,t:1527873173917};\\\", \\\"{x:1282,y:952,t:1527873174029};\\\", \\\"{x:1281,y:951,t:1527873174053};\\\", \\\"{x:1281,y:950,t:1527873174317};\\\", \\\"{x:1281,y:949,t:1527873174325};\\\", \\\"{x:1281,y:948,t:1527873174389};\\\", \\\"{x:1281,y:947,t:1527873174404};\\\", \\\"{x:1281,y:946,t:1527873174419};\\\", \\\"{x:1281,y:944,t:1527873174437};\\\", \\\"{x:1279,y:942,t:1527873174453};\\\", \\\"{x:1279,y:941,t:1527873174469};\\\", \\\"{x:1279,y:940,t:1527873174501};\\\", \\\"{x:1279,y:939,t:1527873174566};\\\", \\\"{x:1279,y:938,t:1527873174628};\\\", \\\"{x:1279,y:937,t:1527873174644};\\\", \\\"{x:1279,y:936,t:1527873174660};\\\", \\\"{x:1279,y:935,t:1527873174669};\\\", \\\"{x:1279,y:934,t:1527873174700};\\\", \\\"{x:1279,y:933,t:1527873174716};\\\", \\\"{x:1279,y:932,t:1527873174724};\\\", \\\"{x:1279,y:931,t:1527873174740};\\\", \\\"{x:1279,y:930,t:1527873174753};\\\", \\\"{x:1279,y:929,t:1527873174771};\\\", \\\"{x:1279,y:928,t:1527873174786};\\\", \\\"{x:1279,y:927,t:1527873174805};\\\", \\\"{x:1279,y:926,t:1527873174829};\\\", \\\"{x:1279,y:925,t:1527873174910};\\\", \\\"{x:1279,y:923,t:1527873174981};\\\", \\\"{x:1279,y:921,t:1527873175006};\\\", \\\"{x:1279,y:920,t:1527873175020};\\\", \\\"{x:1279,y:917,t:1527873175037};\\\", \\\"{x:1279,y:914,t:1527873175053};\\\", \\\"{x:1279,y:910,t:1527873175070};\\\", \\\"{x:1279,y:909,t:1527873175088};\\\", \\\"{x:1279,y:908,t:1527873175173};\\\", \\\"{x:1279,y:907,t:1527873175309};\\\", \\\"{x:1279,y:906,t:1527873175341};\\\", \\\"{x:1279,y:905,t:1527873175373};\\\", \\\"{x:1279,y:904,t:1527873175405};\\\", \\\"{x:1279,y:903,t:1527873175525};\\\", \\\"{x:1279,y:902,t:1527873175565};\\\", \\\"{x:1279,y:901,t:1527873175573};\\\", \\\"{x:1279,y:900,t:1527873175586};\\\", \\\"{x:1280,y:898,t:1527873175628};\\\", \\\"{x:1280,y:897,t:1527873175651};\\\", \\\"{x:1280,y:895,t:1527873175675};\\\", \\\"{x:1280,y:894,t:1527873175692};\\\", \\\"{x:1280,y:893,t:1527873175708};\\\", \\\"{x:1280,y:890,t:1527873175725};\\\", \\\"{x:1280,y:887,t:1527873175737};\\\", \\\"{x:1283,y:883,t:1527873175754};\\\", \\\"{x:1283,y:876,t:1527873175770};\\\", \\\"{x:1283,y:874,t:1527873175787};\\\", \\\"{x:1283,y:873,t:1527873175804};\\\", \\\"{x:1283,y:871,t:1527873175820};\\\", \\\"{x:1283,y:870,t:1527873175838};\\\", \\\"{x:1283,y:869,t:1527873175861};\\\", \\\"{x:1283,y:868,t:1527873175942};\\\", \\\"{x:1283,y:867,t:1527873175954};\\\", \\\"{x:1283,y:866,t:1527873175981};\\\", \\\"{x:1283,y:864,t:1527873175988};\\\", \\\"{x:1283,y:862,t:1527873176005};\\\", \\\"{x:1283,y:859,t:1527873176021};\\\", \\\"{x:1283,y:857,t:1527873176037};\\\", \\\"{x:1283,y:856,t:1527873176157};\\\", \\\"{x:1283,y:854,t:1527873176261};\\\", \\\"{x:1283,y:853,t:1527873176271};\\\", \\\"{x:1283,y:847,t:1527873176289};\\\", \\\"{x:1283,y:842,t:1527873176305};\\\", \\\"{x:1283,y:840,t:1527873176322};\\\", \\\"{x:1284,y:839,t:1527873176338};\\\", \\\"{x:1284,y:838,t:1527873176413};\\\", \\\"{x:1284,y:837,t:1527873176477};\\\", \\\"{x:1284,y:836,t:1527873176668};\\\", \\\"{x:1284,y:835,t:1527873176692};\\\", \\\"{x:1284,y:834,t:1527873176768};\\\", \\\"{x:1286,y:831,t:1527873176788};\\\", \\\"{x:1286,y:830,t:1527873176805};\\\", \\\"{x:1286,y:829,t:1527873176851};\\\", \\\"{x:1287,y:829,t:1527873180693};\\\", \\\"{x:1287,y:830,t:1527873180917};\\\", \\\"{x:1287,y:832,t:1527873180933};\\\", \\\"{x:1287,y:833,t:1527873180949};\\\", \\\"{x:1287,y:835,t:1527873180965};\\\", \\\"{x:1287,y:836,t:1527873180981};\\\", \\\"{x:1288,y:837,t:1527873180991};\\\", \\\"{x:1289,y:839,t:1527873181008};\\\", \\\"{x:1289,y:841,t:1527873181026};\\\", \\\"{x:1291,y:843,t:1527873181041};\\\", \\\"{x:1291,y:844,t:1527873181059};\\\", \\\"{x:1291,y:845,t:1527873181075};\\\", \\\"{x:1291,y:846,t:1527873181091};\\\", \\\"{x:1292,y:848,t:1527873181108};\\\", \\\"{x:1292,y:849,t:1527873181133};\\\", \\\"{x:1292,y:850,t:1527873181142};\\\", \\\"{x:1292,y:852,t:1527873181159};\\\", \\\"{x:1292,y:854,t:1527873181176};\\\", \\\"{x:1292,y:855,t:1527873181197};\\\", \\\"{x:1292,y:856,t:1527873181213};\\\", \\\"{x:1292,y:857,t:1527873181226};\\\", \\\"{x:1293,y:858,t:1527873181243};\\\", \\\"{x:1293,y:861,t:1527873181259};\\\", \\\"{x:1294,y:864,t:1527873181276};\\\", \\\"{x:1297,y:869,t:1527873181292};\\\", \\\"{x:1298,y:871,t:1527873181309};\\\", \\\"{x:1299,y:873,t:1527873181325};\\\", \\\"{x:1302,y:878,t:1527873181342};\\\", \\\"{x:1304,y:883,t:1527873181358};\\\", \\\"{x:1305,y:885,t:1527873181375};\\\", \\\"{x:1306,y:886,t:1527873181392};\\\", \\\"{x:1307,y:888,t:1527873181409};\\\", \\\"{x:1309,y:890,t:1527873181426};\\\", \\\"{x:1311,y:892,t:1527873181443};\\\", \\\"{x:1313,y:893,t:1527873181458};\\\", \\\"{x:1316,y:894,t:1527873181476};\\\", \\\"{x:1319,y:896,t:1527873181493};\\\", \\\"{x:1322,y:897,t:1527873181509};\\\", \\\"{x:1325,y:899,t:1527873181526};\\\", \\\"{x:1329,y:901,t:1527873181543};\\\", \\\"{x:1334,y:903,t:1527873181558};\\\", \\\"{x:1335,y:905,t:1527873181575};\\\", \\\"{x:1336,y:907,t:1527873181592};\\\", \\\"{x:1337,y:908,t:1527873181609};\\\", \\\"{x:1337,y:909,t:1527873181624};\\\", \\\"{x:1337,y:910,t:1527873181642};\\\", \\\"{x:1337,y:911,t:1527873181659};\\\", \\\"{x:1337,y:913,t:1527873181675};\\\", \\\"{x:1339,y:915,t:1527873181692};\\\", \\\"{x:1339,y:916,t:1527873181716};\\\", \\\"{x:1339,y:917,t:1527873181749};\\\", \\\"{x:1339,y:918,t:1527873181759};\\\", \\\"{x:1339,y:919,t:1527873181775};\\\", \\\"{x:1339,y:921,t:1527873181792};\\\", \\\"{x:1339,y:924,t:1527873181809};\\\", \\\"{x:1340,y:926,t:1527873181826};\\\", \\\"{x:1341,y:928,t:1527873181842};\\\", \\\"{x:1342,y:931,t:1527873181859};\\\", \\\"{x:1343,y:932,t:1527873181875};\\\", \\\"{x:1347,y:937,t:1527873181892};\\\", \\\"{x:1354,y:940,t:1527873181909};\\\", \\\"{x:1357,y:942,t:1527873181925};\\\", \\\"{x:1357,y:945,t:1527873181943};\\\", \\\"{x:1357,y:947,t:1527873181960};\\\", \\\"{x:1358,y:948,t:1527873181975};\\\", \\\"{x:1358,y:949,t:1527873182013};\\\", \\\"{x:1358,y:950,t:1527873182028};\\\", \\\"{x:1358,y:951,t:1527873182042};\\\", \\\"{x:1358,y:952,t:1527873182357};\\\", \\\"{x:1358,y:951,t:1527873182589};\\\", \\\"{x:1358,y:949,t:1527873182596};\\\", \\\"{x:1361,y:945,t:1527873182610};\\\", \\\"{x:1362,y:937,t:1527873182626};\\\", \\\"{x:1363,y:933,t:1527873182644};\\\", \\\"{x:1365,y:929,t:1527873182660};\\\", \\\"{x:1365,y:927,t:1527873182676};\\\", \\\"{x:1365,y:926,t:1527873182693};\\\", \\\"{x:1365,y:924,t:1527873182749};\\\", \\\"{x:1365,y:923,t:1527873182765};\\\", \\\"{x:1365,y:921,t:1527873182777};\\\", \\\"{x:1365,y:920,t:1527873182794};\\\", \\\"{x:1365,y:918,t:1527873182810};\\\", \\\"{x:1365,y:917,t:1527873182826};\\\", \\\"{x:1364,y:915,t:1527873182844};\\\", \\\"{x:1362,y:911,t:1527873182861};\\\", \\\"{x:1362,y:910,t:1527873182877};\\\", \\\"{x:1362,y:908,t:1527873182901};\\\", \\\"{x:1362,y:906,t:1527873182911};\\\", \\\"{x:1361,y:903,t:1527873182927};\\\", \\\"{x:1360,y:900,t:1527873182944};\\\", \\\"{x:1360,y:899,t:1527873182965};\\\", \\\"{x:1360,y:898,t:1527873183029};\\\", \\\"{x:1360,y:897,t:1527873183045};\\\", \\\"{x:1359,y:896,t:1527873183620};\\\", \\\"{x:1358,y:896,t:1527873183636};\\\", \\\"{x:1355,y:896,t:1527873183644};\\\", \\\"{x:1339,y:886,t:1527873183660};\\\", \\\"{x:1326,y:878,t:1527873183677};\\\", \\\"{x:1312,y:872,t:1527873183694};\\\", \\\"{x:1308,y:870,t:1527873183710};\\\", \\\"{x:1306,y:869,t:1527873183727};\\\", \\\"{x:1305,y:868,t:1527873183756};\\\", \\\"{x:1304,y:868,t:1527873183821};\\\", \\\"{x:1303,y:866,t:1527873183829};\\\", \\\"{x:1295,y:857,t:1527873183845};\\\", \\\"{x:1286,y:847,t:1527873183861};\\\", \\\"{x:1283,y:843,t:1527873183878};\\\", \\\"{x:1278,y:837,t:1527873183894};\\\", \\\"{x:1272,y:828,t:1527873183910};\\\", \\\"{x:1265,y:817,t:1527873183927};\\\", \\\"{x:1264,y:815,t:1527873183944};\\\", \\\"{x:1264,y:816,t:1527873184165};\\\", \\\"{x:1264,y:820,t:1527873184178};\\\", \\\"{x:1265,y:826,t:1527873184195};\\\", \\\"{x:1265,y:831,t:1527873184212};\\\", \\\"{x:1265,y:835,t:1527873184228};\\\", \\\"{x:1265,y:837,t:1527873184244};\\\", \\\"{x:1265,y:838,t:1527873184262};\\\", \\\"{x:1264,y:839,t:1527873184285};\\\", \\\"{x:1262,y:840,t:1527873184295};\\\", \\\"{x:1252,y:841,t:1527873184312};\\\", \\\"{x:1233,y:842,t:1527873184328};\\\", \\\"{x:1186,y:842,t:1527873184344};\\\", \\\"{x:1117,y:838,t:1527873184362};\\\", \\\"{x:1066,y:835,t:1527873184378};\\\", \\\"{x:999,y:835,t:1527873184395};\\\", \\\"{x:907,y:835,t:1527873184411};\\\", \\\"{x:793,y:817,t:1527873184427};\\\", \\\"{x:629,y:778,t:1527873184444};\\\", \\\"{x:541,y:757,t:1527873184462};\\\", \\\"{x:459,y:729,t:1527873184478};\\\", \\\"{x:395,y:701,t:1527873184494};\\\", \\\"{x:340,y:676,t:1527873184510};\\\", \\\"{x:312,y:662,t:1527873184526};\\\", \\\"{x:303,y:655,t:1527873184543};\\\", \\\"{x:293,y:648,t:1527873184561};\\\", \\\"{x:282,y:638,t:1527873184576};\\\", \\\"{x:271,y:629,t:1527873184594};\\\", \\\"{x:263,y:624,t:1527873184610};\\\", \\\"{x:259,y:620,t:1527873184626};\\\", \\\"{x:259,y:615,t:1527873184643};\\\", \\\"{x:253,y:592,t:1527873184660};\\\", \\\"{x:247,y:578,t:1527873184677};\\\", \\\"{x:240,y:567,t:1527873184693};\\\", \\\"{x:239,y:562,t:1527873184710};\\\", \\\"{x:239,y:561,t:1527873184726};\\\", \\\"{x:239,y:560,t:1527873184743};\\\", \\\"{x:239,y:559,t:1527873184760};\\\", \\\"{x:239,y:557,t:1527873184777};\\\", \\\"{x:239,y:556,t:1527873184793};\\\", \\\"{x:235,y:553,t:1527873184810};\\\", \\\"{x:228,y:550,t:1527873184828};\\\", \\\"{x:221,y:545,t:1527873184844};\\\", \\\"{x:221,y:541,t:1527873184869};\\\", \\\"{x:224,y:535,t:1527873184878};\\\", \\\"{x:235,y:523,t:1527873184893};\\\", \\\"{x:243,y:518,t:1527873184910};\\\", \\\"{x:250,y:516,t:1527873184927};\\\", \\\"{x:265,y:511,t:1527873184943};\\\", \\\"{x:284,y:507,t:1527873184961};\\\", \\\"{x:291,y:506,t:1527873184977};\\\", \\\"{x:292,y:506,t:1527873184993};\\\", \\\"{x:294,y:506,t:1527873185010};\\\", \\\"{x:300,y:504,t:1527873185027};\\\", \\\"{x:311,y:504,t:1527873185043};\\\", \\\"{x:334,y:505,t:1527873185060};\\\", \\\"{x:345,y:509,t:1527873185077};\\\", \\\"{x:357,y:513,t:1527873185094};\\\", \\\"{x:371,y:516,t:1527873185110};\\\", \\\"{x:375,y:518,t:1527873185128};\\\", \\\"{x:377,y:518,t:1527873185143};\\\", \\\"{x:378,y:519,t:1527873185212};\\\", \\\"{x:378,y:522,t:1527873185692};\\\", \\\"{x:378,y:526,t:1527873185700};\\\", \\\"{x:378,y:530,t:1527873185711};\\\", \\\"{x:380,y:541,t:1527873185728};\\\", \\\"{x:390,y:560,t:1527873185745};\\\", \\\"{x:408,y:585,t:1527873185764};\\\", \\\"{x:426,y:609,t:1527873185777};\\\", \\\"{x:442,y:630,t:1527873185794};\\\", \\\"{x:454,y:646,t:1527873185811};\\\", \\\"{x:459,y:653,t:1527873185827};\\\", \\\"{x:464,y:662,t:1527873185844};\\\", \\\"{x:466,y:668,t:1527873185861};\\\", \\\"{x:469,y:674,t:1527873185877};\\\", \\\"{x:470,y:678,t:1527873185894};\\\", \\\"{x:472,y:684,t:1527873185911};\\\", \\\"{x:474,y:690,t:1527873185927};\\\", \\\"{x:475,y:696,t:1527873185945};\\\", \\\"{x:475,y:699,t:1527873185962};\\\", \\\"{x:475,y:701,t:1527873185978};\\\", \\\"{x:475,y:702,t:1527873185994};\\\", \\\"{x:475,y:704,t:1527873186011};\\\", \\\"{x:475,y:705,t:1527873186027};\\\", \\\"{x:475,y:706,t:1527873186044};\\\", \\\"{x:476,y:707,t:1527873186062};\\\", \\\"{x:477,y:708,t:1527873186125};\\\", \\\"{x:477,y:709,t:1527873186141};\\\", \\\"{x:477,y:710,t:1527873186147};\\\", \\\"{x:477,y:712,t:1527873186161};\\\", \\\"{x:477,y:713,t:1527873186178};\\\", \\\"{x:477,y:714,t:1527873186194};\\\" ] }, { \\\"rt\\\": 12232, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 158559, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"9BS72\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:479,y:712,t:1527873202341};\\\", \\\"{x:481,y:703,t:1527873202356};\\\", \\\"{x:481,y:688,t:1527873202375};\\\", \\\"{x:481,y:676,t:1527873202390};\\\", \\\"{x:481,y:662,t:1527873202406};\\\", \\\"{x:481,y:653,t:1527873202424};\\\", \\\"{x:481,y:647,t:1527873202441};\\\", \\\"{x:481,y:642,t:1527873202458};\\\", \\\"{x:481,y:631,t:1527873202474};\\\", \\\"{x:481,y:616,t:1527873202491};\\\", \\\"{x:481,y:597,t:1527873202507};\\\", \\\"{x:482,y:584,t:1527873202524};\\\", \\\"{x:484,y:578,t:1527873202541};\\\", \\\"{x:486,y:574,t:1527873202558};\\\", \\\"{x:485,y:574,t:1527873202685};\\\", \\\"{x:481,y:574,t:1527873202692};\\\", \\\"{x:464,y:574,t:1527873202708};\\\", \\\"{x:435,y:575,t:1527873202727};\\\", \\\"{x:399,y:580,t:1527873202742};\\\", \\\"{x:382,y:583,t:1527873202758};\\\", \\\"{x:379,y:585,t:1527873202775};\\\", \\\"{x:378,y:585,t:1527873202836};\\\", \\\"{x:377,y:586,t:1527873202843};\\\", \\\"{x:375,y:587,t:1527873202858};\\\", \\\"{x:373,y:588,t:1527873202875};\\\", \\\"{x:368,y:590,t:1527873202890};\\\", \\\"{x:351,y:595,t:1527873202907};\\\", \\\"{x:341,y:598,t:1527873202923};\\\", \\\"{x:336,y:599,t:1527873202941};\\\", \\\"{x:326,y:602,t:1527873202958};\\\", \\\"{x:302,y:607,t:1527873202974};\\\", \\\"{x:277,y:609,t:1527873202991};\\\", \\\"{x:255,y:610,t:1527873203010};\\\", \\\"{x:245,y:612,t:1527873203024};\\\", \\\"{x:238,y:612,t:1527873203041};\\\", \\\"{x:229,y:612,t:1527873203058};\\\", \\\"{x:227,y:612,t:1527873203075};\\\", \\\"{x:218,y:612,t:1527873203091};\\\", \\\"{x:181,y:612,t:1527873203107};\\\", \\\"{x:164,y:612,t:1527873203124};\\\", \\\"{x:156,y:611,t:1527873203140};\\\", \\\"{x:155,y:611,t:1527873203158};\\\", \\\"{x:155,y:615,t:1527873203350};\\\", \\\"{x:155,y:616,t:1527873203358};\\\", \\\"{x:155,y:617,t:1527873203375};\\\", \\\"{x:156,y:620,t:1527873203393};\\\", \\\"{x:156,y:621,t:1527873203524};\\\", \\\"{x:157,y:622,t:1527873203724};\\\", \\\"{x:159,y:623,t:1527873203740};\\\", \\\"{x:165,y:627,t:1527873203758};\\\", \\\"{x:176,y:630,t:1527873203776};\\\", \\\"{x:194,y:638,t:1527873203793};\\\", \\\"{x:222,y:649,t:1527873203809};\\\", \\\"{x:249,y:663,t:1527873203825};\\\", \\\"{x:273,y:667,t:1527873203841};\\\", \\\"{x:300,y:672,t:1527873203859};\\\", \\\"{x:340,y:682,t:1527873203875};\\\", \\\"{x:389,y:699,t:1527873203891};\\\", \\\"{x:408,y:705,t:1527873203909};\\\", \\\"{x:418,y:709,t:1527873203925};\\\", \\\"{x:423,y:711,t:1527873203942};\\\", \\\"{x:427,y:713,t:1527873203959};\\\", \\\"{x:429,y:713,t:1527873203975};\\\", \\\"{x:432,y:714,t:1527873203992};\\\", \\\"{x:429,y:714,t:1527873204180};\\\", \\\"{x:420,y:714,t:1527873204192};\\\", \\\"{x:394,y:711,t:1527873204210};\\\", \\\"{x:360,y:705,t:1527873204225};\\\", \\\"{x:323,y:698,t:1527873204242};\\\", \\\"{x:280,y:689,t:1527873204259};\\\", \\\"{x:229,y:683,t:1527873204276};\\\", \\\"{x:221,y:679,t:1527873204292};\\\", \\\"{x:220,y:678,t:1527873204436};\\\", \\\"{x:220,y:676,t:1527873204444};\\\", \\\"{x:220,y:673,t:1527873204459};\\\", \\\"{x:212,y:662,t:1527873204476};\\\", \\\"{x:198,y:652,t:1527873204492};\\\", \\\"{x:184,y:645,t:1527873204510};\\\", \\\"{x:179,y:641,t:1527873204526};\\\", \\\"{x:176,y:639,t:1527873204541};\\\", \\\"{x:175,y:639,t:1527873204588};\\\", \\\"{x:176,y:638,t:1527873204603};\\\", \\\"{x:176,y:637,t:1527873204797};\\\", \\\"{x:175,y:637,t:1527873205468};\\\", \\\"{x:181,y:637,t:1527873205612};\\\", \\\"{x:192,y:641,t:1527873205627};\\\", \\\"{x:254,y:649,t:1527873205643};\\\", \\\"{x:446,y:672,t:1527873205660};\\\", \\\"{x:577,y:712,t:1527873205677};\\\", \\\"{x:673,y:738,t:1527873205692};\\\", \\\"{x:710,y:746,t:1527873205710};\\\", \\\"{x:718,y:748,t:1527873205726};\\\", \\\"{x:716,y:748,t:1527873205827};\\\", \\\"{x:713,y:748,t:1527873205843};\\\", \\\"{x:707,y:748,t:1527873205860};\\\", \\\"{x:700,y:747,t:1527873205876};\\\", \\\"{x:695,y:747,t:1527873205893};\\\", \\\"{x:692,y:746,t:1527873205910};\\\", \\\"{x:686,y:746,t:1527873205927};\\\", \\\"{x:680,y:743,t:1527873205944};\\\", \\\"{x:668,y:738,t:1527873205960};\\\", \\\"{x:652,y:734,t:1527873205977};\\\", \\\"{x:629,y:729,t:1527873205993};\\\", \\\"{x:607,y:726,t:1527873206010};\\\", \\\"{x:592,y:723,t:1527873206027};\\\", \\\"{x:587,y:722,t:1527873206043};\\\", \\\"{x:581,y:722,t:1527873206060};\\\", \\\"{x:580,y:722,t:1527873206092};\\\", \\\"{x:578,y:722,t:1527873206133};\\\", \\\"{x:577,y:722,t:1527873206148};\\\", \\\"{x:575,y:722,t:1527873206205};\\\", \\\"{x:573,y:722,t:1527873206212};\\\", \\\"{x:570,y:722,t:1527873206227};\\\", \\\"{x:564,y:723,t:1527873206246};\\\" ] }, { \\\"rt\\\": 12707, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 172506, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"9BS72\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-A -A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:572,y:722,t:1527873212318};\\\", \\\"{x:631,y:721,t:1527873212339};\\\", \\\"{x:682,y:721,t:1527873212356};\\\", \\\"{x:723,y:721,t:1527873212380};\\\", \\\"{x:725,y:721,t:1527873212397};\\\", \\\"{x:726,y:721,t:1527873212508};\\\", \\\"{x:727,y:721,t:1527873212515};\\\", \\\"{x:730,y:720,t:1527873212531};\\\", \\\"{x:741,y:718,t:1527873212547};\\\", \\\"{x:751,y:717,t:1527873212564};\\\", \\\"{x:767,y:716,t:1527873212581};\\\", \\\"{x:786,y:716,t:1527873212597};\\\", \\\"{x:810,y:716,t:1527873212614};\\\", \\\"{x:839,y:713,t:1527873212631};\\\", \\\"{x:866,y:713,t:1527873212648};\\\", \\\"{x:891,y:713,t:1527873212665};\\\", \\\"{x:913,y:713,t:1527873212681};\\\", \\\"{x:931,y:716,t:1527873212698};\\\", \\\"{x:946,y:718,t:1527873212715};\\\", \\\"{x:961,y:719,t:1527873212731};\\\", \\\"{x:978,y:721,t:1527873212748};\\\", \\\"{x:989,y:721,t:1527873212765};\\\", \\\"{x:1000,y:721,t:1527873212781};\\\", \\\"{x:1016,y:721,t:1527873212798};\\\", \\\"{x:1032,y:721,t:1527873212815};\\\", \\\"{x:1051,y:721,t:1527873212832};\\\", \\\"{x:1069,y:721,t:1527873212848};\\\", \\\"{x:1087,y:723,t:1527873212865};\\\", \\\"{x:1102,y:724,t:1527873212882};\\\", \\\"{x:1111,y:728,t:1527873212898};\\\", \\\"{x:1118,y:728,t:1527873212915};\\\", \\\"{x:1131,y:732,t:1527873212931};\\\", \\\"{x:1145,y:734,t:1527873212947};\\\", \\\"{x:1161,y:735,t:1527873212964};\\\", \\\"{x:1175,y:738,t:1527873212981};\\\", \\\"{x:1189,y:740,t:1527873212997};\\\", \\\"{x:1198,y:742,t:1527873213014};\\\", \\\"{x:1207,y:744,t:1527873213031};\\\", \\\"{x:1212,y:747,t:1527873213047};\\\", \\\"{x:1217,y:749,t:1527873213065};\\\", \\\"{x:1224,y:754,t:1527873213081};\\\", \\\"{x:1227,y:756,t:1527873213097};\\\", \\\"{x:1229,y:758,t:1527873213114};\\\", \\\"{x:1231,y:760,t:1527873213131};\\\", \\\"{x:1232,y:762,t:1527873213147};\\\", \\\"{x:1234,y:765,t:1527873213165};\\\", \\\"{x:1236,y:766,t:1527873213181};\\\", \\\"{x:1238,y:769,t:1527873213197};\\\", \\\"{x:1241,y:773,t:1527873213215};\\\", \\\"{x:1241,y:774,t:1527873213231};\\\", \\\"{x:1243,y:775,t:1527873213247};\\\", \\\"{x:1244,y:777,t:1527873213264};\\\", \\\"{x:1245,y:778,t:1527873213282};\\\", \\\"{x:1246,y:780,t:1527873213297};\\\", \\\"{x:1249,y:782,t:1527873213315};\\\", \\\"{x:1252,y:786,t:1527873213332};\\\", \\\"{x:1253,y:788,t:1527873213347};\\\", \\\"{x:1255,y:790,t:1527873213364};\\\", \\\"{x:1257,y:792,t:1527873213381};\\\", \\\"{x:1258,y:795,t:1527873213398};\\\", \\\"{x:1259,y:795,t:1527873213414};\\\", \\\"{x:1260,y:795,t:1527873213431};\\\", \\\"{x:1261,y:796,t:1527873213448};\\\", \\\"{x:1261,y:797,t:1527873213467};\\\", \\\"{x:1262,y:797,t:1527873213484};\\\", \\\"{x:1263,y:798,t:1527873213500};\\\", \\\"{x:1263,y:801,t:1527873213515};\\\", \\\"{x:1263,y:802,t:1527873213532};\\\", \\\"{x:1263,y:804,t:1527873213549};\\\", \\\"{x:1263,y:806,t:1527873213565};\\\", \\\"{x:1263,y:807,t:1527873213582};\\\", \\\"{x:1263,y:810,t:1527873213598};\\\", \\\"{x:1262,y:811,t:1527873213615};\\\", \\\"{x:1260,y:814,t:1527873213631};\\\", \\\"{x:1259,y:816,t:1527873213649};\\\", \\\"{x:1256,y:820,t:1527873213664};\\\", \\\"{x:1254,y:824,t:1527873213682};\\\", \\\"{x:1252,y:825,t:1527873213698};\\\", \\\"{x:1252,y:826,t:1527873213714};\\\", \\\"{x:1252,y:827,t:1527873213787};\\\", \\\"{x:1252,y:828,t:1527873213811};\\\", \\\"{x:1251,y:828,t:1527873213835};\\\", \\\"{x:1251,y:829,t:1527873213899};\\\", \\\"{x:1250,y:829,t:1527873213914};\\\", \\\"{x:1249,y:830,t:1527873213931};\\\", \\\"{x:1246,y:832,t:1527873213948};\\\", \\\"{x:1240,y:835,t:1527873213964};\\\", \\\"{x:1234,y:838,t:1527873213981};\\\", \\\"{x:1232,y:840,t:1527873213998};\\\", \\\"{x:1230,y:842,t:1527873214014};\\\", \\\"{x:1228,y:843,t:1527873214031};\\\", \\\"{x:1227,y:843,t:1527873214048};\\\", \\\"{x:1227,y:844,t:1527873214064};\\\", \\\"{x:1226,y:845,t:1527873214083};\\\", \\\"{x:1226,y:842,t:1527873214515};\\\", \\\"{x:1226,y:841,t:1527873214539};\\\", \\\"{x:1226,y:840,t:1527873214549};\\\", \\\"{x:1226,y:839,t:1527873214566};\\\", \\\"{x:1226,y:838,t:1527873214581};\\\", \\\"{x:1226,y:837,t:1527873214599};\\\", \\\"{x:1226,y:836,t:1527873214620};\\\", \\\"{x:1226,y:835,t:1527873214805};\\\", \\\"{x:1227,y:834,t:1527873214828};\\\", \\\"{x:1228,y:834,t:1527873214885};\\\", \\\"{x:1231,y:832,t:1527873214899};\\\", \\\"{x:1264,y:830,t:1527873214916};\\\", \\\"{x:1283,y:827,t:1527873214936};\\\", \\\"{x:1291,y:825,t:1527873214949};\\\", \\\"{x:1296,y:823,t:1527873214965};\\\", \\\"{x:1297,y:822,t:1527873214982};\\\", \\\"{x:1298,y:822,t:1527873214999};\\\", \\\"{x:1299,y:821,t:1527873215109};\\\", \\\"{x:1298,y:821,t:1527873215132};\\\", \\\"{x:1296,y:821,t:1527873215156};\\\", \\\"{x:1295,y:821,t:1527873215165};\\\", \\\"{x:1294,y:821,t:1527873215204};\\\", \\\"{x:1292,y:821,t:1527873215216};\\\", \\\"{x:1291,y:821,t:1527873215233};\\\", \\\"{x:1288,y:821,t:1527873215249};\\\", \\\"{x:1282,y:819,t:1527873215266};\\\", \\\"{x:1281,y:818,t:1527873215283};\\\", \\\"{x:1279,y:818,t:1527873215299};\\\", \\\"{x:1277,y:818,t:1527873215332};\\\", \\\"{x:1275,y:818,t:1527873215349};\\\", \\\"{x:1272,y:818,t:1527873215366};\\\", \\\"{x:1271,y:818,t:1527873215383};\\\", \\\"{x:1269,y:818,t:1527873215399};\\\", \\\"{x:1261,y:818,t:1527873215416};\\\", \\\"{x:1248,y:818,t:1527873215433};\\\", \\\"{x:1228,y:815,t:1527873215449};\\\", \\\"{x:1209,y:809,t:1527873215466};\\\", \\\"{x:1187,y:804,t:1527873215484};\\\", \\\"{x:1167,y:797,t:1527873215499};\\\", \\\"{x:1136,y:790,t:1527873215516};\\\", \\\"{x:1101,y:780,t:1527873215533};\\\", \\\"{x:1055,y:769,t:1527873215549};\\\", \\\"{x:1014,y:761,t:1527873215566};\\\", \\\"{x:984,y:755,t:1527873215583};\\\", \\\"{x:954,y:749,t:1527873215599};\\\", \\\"{x:925,y:741,t:1527873215615};\\\", \\\"{x:900,y:737,t:1527873215633};\\\", \\\"{x:870,y:727,t:1527873215649};\\\", \\\"{x:839,y:714,t:1527873215666};\\\", \\\"{x:811,y:704,t:1527873215683};\\\", \\\"{x:797,y:695,t:1527873215698};\\\", \\\"{x:769,y:684,t:1527873215716};\\\", \\\"{x:751,y:676,t:1527873215732};\\\", \\\"{x:730,y:669,t:1527873215748};\\\", \\\"{x:706,y:664,t:1527873215766};\\\", \\\"{x:672,y:656,t:1527873215783};\\\", \\\"{x:648,y:646,t:1527873215801};\\\", \\\"{x:625,y:641,t:1527873215815};\\\", \\\"{x:607,y:639,t:1527873215832};\\\", \\\"{x:590,y:636,t:1527873215852};\\\", \\\"{x:578,y:635,t:1527873215868};\\\", \\\"{x:566,y:635,t:1527873215884};\\\", \\\"{x:555,y:643,t:1527873215902};\\\", \\\"{x:549,y:647,t:1527873215918};\\\", \\\"{x:542,y:647,t:1527873215934};\\\", \\\"{x:531,y:647,t:1527873215952};\\\", \\\"{x:508,y:648,t:1527873215969};\\\", \\\"{x:485,y:654,t:1527873215985};\\\", \\\"{x:465,y:657,t:1527873216001};\\\", \\\"{x:443,y:657,t:1527873216019};\\\", \\\"{x:396,y:627,t:1527873216036};\\\", \\\"{x:372,y:609,t:1527873216052};\\\", \\\"{x:354,y:592,t:1527873216069};\\\", \\\"{x:342,y:582,t:1527873216085};\\\", \\\"{x:336,y:573,t:1527873216103};\\\", \\\"{x:336,y:568,t:1527873216119};\\\", \\\"{x:336,y:564,t:1527873216134};\\\", \\\"{x:335,y:560,t:1527873216151};\\\", \\\"{x:335,y:559,t:1527873216169};\\\", \\\"{x:336,y:555,t:1527873216185};\\\", \\\"{x:338,y:553,t:1527873216201};\\\", \\\"{x:339,y:551,t:1527873216219};\\\", \\\"{x:339,y:550,t:1527873216235};\\\", \\\"{x:341,y:548,t:1527873216251};\\\", \\\"{x:344,y:545,t:1527873216269};\\\", \\\"{x:348,y:542,t:1527873216286};\\\", \\\"{x:351,y:539,t:1527873216302};\\\", \\\"{x:352,y:538,t:1527873216318};\\\", \\\"{x:353,y:536,t:1527873216336};\\\", \\\"{x:356,y:535,t:1527873216351};\\\", \\\"{x:362,y:533,t:1527873216368};\\\", \\\"{x:369,y:530,t:1527873216385};\\\", \\\"{x:371,y:528,t:1527873216402};\\\", \\\"{x:372,y:527,t:1527873216419};\\\", \\\"{x:375,y:525,t:1527873216436};\\\", \\\"{x:380,y:523,t:1527873216451};\\\", \\\"{x:381,y:523,t:1527873216476};\\\", \\\"{x:382,y:524,t:1527873216747};\\\", \\\"{x:386,y:533,t:1527873216756};\\\", \\\"{x:396,y:545,t:1527873216769};\\\", \\\"{x:416,y:571,t:1527873216786};\\\", \\\"{x:435,y:596,t:1527873216803};\\\", \\\"{x:453,y:616,t:1527873216819};\\\", \\\"{x:481,y:662,t:1527873216835};\\\", \\\"{x:494,y:683,t:1527873216851};\\\", \\\"{x:507,y:705,t:1527873216869};\\\", \\\"{x:519,y:726,t:1527873216886};\\\", \\\"{x:528,y:742,t:1527873216902};\\\", \\\"{x:529,y:744,t:1527873216918};\\\", \\\"{x:530,y:745,t:1527873216988};\\\", \\\"{x:532,y:746,t:1527873217004};\\\", \\\"{x:532,y:747,t:1527873217018};\\\", \\\"{x:532,y:746,t:1527873217189};\\\", \\\"{x:532,y:745,t:1527873217203};\\\", \\\"{x:532,y:744,t:1527873217220};\\\", \\\"{x:532,y:743,t:1527873217236};\\\", \\\"{x:532,y:742,t:1527873217260};\\\", \\\"{x:532,y:741,t:1527873217316};\\\", \\\"{x:532,y:740,t:1527873217340};\\\", \\\"{x:532,y:739,t:1527873217353};\\\", \\\"{x:532,y:738,t:1527873217370};\\\", \\\"{x:532,y:737,t:1527873217412};\\\", \\\"{x:532,y:736,t:1527873217428};\\\", \\\"{x:532,y:735,t:1527873217437};\\\", \\\"{x:532,y:734,t:1527873217459};\\\", \\\"{x:532,y:733,t:1527873217470};\\\", \\\"{x:532,y:732,t:1527873217487};\\\", \\\"{x:532,y:731,t:1527873217547};\\\", \\\"{x:533,y:729,t:1527873217555};\\\", \\\"{x:534,y:728,t:1527873217569};\\\", \\\"{x:534,y:726,t:1527873217587};\\\", \\\"{x:534,y:725,t:1527873217677};\\\" ] }, { \\\"rt\\\": 58908, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 232619, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"9BS72\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-K -U -F -F -O -Z -Z -F -F -12 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:537,y:725,t:1527873224837};\\\", \\\"{x:586,y:729,t:1527873224860};\\\", \\\"{x:621,y:738,t:1527873224875};\\\", \\\"{x:756,y:759,t:1527873224892};\\\", \\\"{x:854,y:775,t:1527873224909};\\\", \\\"{x:951,y:786,t:1527873224925};\\\", \\\"{x:1054,y:802,t:1527873224942};\\\", \\\"{x:1154,y:818,t:1527873224959};\\\", \\\"{x:1241,y:835,t:1527873224975};\\\", \\\"{x:1302,y:854,t:1527873224992};\\\", \\\"{x:1370,y:866,t:1527873225009};\\\", \\\"{x:1421,y:874,t:1527873225026};\\\", \\\"{x:1461,y:881,t:1527873225043};\\\", \\\"{x:1495,y:891,t:1527873225059};\\\", \\\"{x:1534,y:905,t:1527873225076};\\\", \\\"{x:1560,y:913,t:1527873225092};\\\", \\\"{x:1586,y:918,t:1527873225110};\\\", \\\"{x:1613,y:923,t:1527873225126};\\\", \\\"{x:1625,y:924,t:1527873225142};\\\", \\\"{x:1629,y:924,t:1527873225159};\\\", \\\"{x:1630,y:924,t:1527873225196};\\\", \\\"{x:1631,y:924,t:1527873225210};\\\", \\\"{x:1633,y:925,t:1527873225227};\\\", \\\"{x:1637,y:926,t:1527873225243};\\\", \\\"{x:1638,y:927,t:1527873225268};\\\", \\\"{x:1639,y:927,t:1527873225284};\\\", \\\"{x:1640,y:928,t:1527873225292};\\\", \\\"{x:1640,y:930,t:1527873225309};\\\", \\\"{x:1641,y:933,t:1527873225327};\\\", \\\"{x:1642,y:935,t:1527873225343};\\\", \\\"{x:1642,y:936,t:1527873225360};\\\", \\\"{x:1642,y:937,t:1527873225381};\\\", \\\"{x:1642,y:938,t:1527873225396};\\\", \\\"{x:1642,y:939,t:1527873225409};\\\", \\\"{x:1642,y:940,t:1527873225436};\\\", \\\"{x:1642,y:941,t:1527873225444};\\\", \\\"{x:1642,y:942,t:1527873225459};\\\", \\\"{x:1642,y:943,t:1527873225476};\\\", \\\"{x:1642,y:944,t:1527873225500};\\\", \\\"{x:1642,y:945,t:1527873225532};\\\", \\\"{x:1642,y:946,t:1527873225555};\\\", \\\"{x:1642,y:947,t:1527873225571};\\\", \\\"{x:1642,y:949,t:1527873225595};\\\", \\\"{x:1642,y:950,t:1527873225708};\\\", \\\"{x:1642,y:951,t:1527873225716};\\\", \\\"{x:1642,y:952,t:1527873225740};\\\", \\\"{x:1641,y:953,t:1527873225764};\\\", \\\"{x:1641,y:954,t:1527873225780};\\\", \\\"{x:1641,y:955,t:1527873225794};\\\", \\\"{x:1640,y:955,t:1527873225810};\\\", \\\"{x:1638,y:957,t:1527873225826};\\\", \\\"{x:1637,y:958,t:1527873225843};\\\", \\\"{x:1636,y:958,t:1527873225861};\\\", \\\"{x:1635,y:959,t:1527873225876};\\\", \\\"{x:1635,y:960,t:1527873225894};\\\", \\\"{x:1634,y:961,t:1527873225910};\\\", \\\"{x:1633,y:962,t:1527873225997};\\\", \\\"{x:1632,y:962,t:1527873226093};\\\", \\\"{x:1630,y:963,t:1527873226293};\\\", \\\"{x:1629,y:963,t:1527873226469};\\\", \\\"{x:1628,y:963,t:1527873226500};\\\", \\\"{x:1627,y:964,t:1527873226511};\\\", \\\"{x:1625,y:964,t:1527873226549};\\\", \\\"{x:1624,y:964,t:1527873226561};\\\", \\\"{x:1623,y:964,t:1527873226580};\\\", \\\"{x:1622,y:964,t:1527873226603};\\\", \\\"{x:1621,y:964,t:1527873226652};\\\", \\\"{x:1620,y:965,t:1527873226966};\\\", \\\"{x:1619,y:965,t:1527873226989};\\\", \\\"{x:1618,y:965,t:1527873227020};\\\", \\\"{x:1617,y:965,t:1527873227341};\\\", \\\"{x:1616,y:965,t:1527873227357};\\\", \\\"{x:1615,y:965,t:1527873227734};\\\", \\\"{x:1614,y:964,t:1527873227741};\\\", \\\"{x:1614,y:960,t:1527873227755};\\\", \\\"{x:1613,y:953,t:1527873227771};\\\", \\\"{x:1611,y:946,t:1527873227787};\\\", \\\"{x:1609,y:941,t:1527873227805};\\\", \\\"{x:1608,y:938,t:1527873227820};\\\", \\\"{x:1607,y:932,t:1527873227837};\\\", \\\"{x:1607,y:920,t:1527873227854};\\\", \\\"{x:1607,y:911,t:1527873227871};\\\", \\\"{x:1607,y:909,t:1527873227887};\\\", \\\"{x:1607,y:908,t:1527873227904};\\\", \\\"{x:1607,y:907,t:1527873227932};\\\", \\\"{x:1607,y:905,t:1527873227956};\\\", \\\"{x:1607,y:904,t:1527873227972};\\\", \\\"{x:1607,y:898,t:1527873227988};\\\", \\\"{x:1607,y:892,t:1527873228004};\\\", \\\"{x:1607,y:889,t:1527873228022};\\\", \\\"{x:1607,y:887,t:1527873228086};\\\", \\\"{x:1607,y:886,t:1527873228101};\\\", \\\"{x:1607,y:884,t:1527873228109};\\\", \\\"{x:1607,y:883,t:1527873228342};\\\", \\\"{x:1607,y:881,t:1527873228398};\\\", \\\"{x:1608,y:880,t:1527873228413};\\\", \\\"{x:1608,y:878,t:1527873228429};\\\", \\\"{x:1608,y:877,t:1527873228590};\\\", \\\"{x:1610,y:875,t:1527873228605};\\\", \\\"{x:1610,y:874,t:1527873228630};\\\", \\\"{x:1610,y:873,t:1527873228639};\\\", \\\"{x:1610,y:871,t:1527873228655};\\\", \\\"{x:1611,y:869,t:1527873228671};\\\", \\\"{x:1611,y:868,t:1527873228688};\\\", \\\"{x:1612,y:867,t:1527873228706};\\\", \\\"{x:1613,y:867,t:1527873228722};\\\", \\\"{x:1613,y:865,t:1527873228739};\\\", \\\"{x:1613,y:864,t:1527873228846};\\\", \\\"{x:1613,y:863,t:1527873228886};\\\", \\\"{x:1613,y:862,t:1527873228893};\\\", \\\"{x:1613,y:861,t:1527873228941};\\\", \\\"{x:1614,y:861,t:1527873228956};\\\", \\\"{x:1614,y:859,t:1527873228973};\\\", \\\"{x:1614,y:858,t:1527873229014};\\\", \\\"{x:1614,y:857,t:1527873229070};\\\", \\\"{x:1614,y:856,t:1527873229189};\\\", \\\"{x:1614,y:855,t:1527873229222};\\\", \\\"{x:1614,y:854,t:1527873229245};\\\", \\\"{x:1614,y:852,t:1527873229262};\\\", \\\"{x:1615,y:851,t:1527873229273};\\\", \\\"{x:1615,y:849,t:1527873229290};\\\", \\\"{x:1615,y:848,t:1527873229306};\\\", \\\"{x:1615,y:847,t:1527873229323};\\\", \\\"{x:1616,y:846,t:1527873229582};\\\", \\\"{x:1613,y:846,t:1527873233092};\\\", \\\"{x:1609,y:847,t:1527873233109};\\\", \\\"{x:1606,y:848,t:1527873233126};\\\", \\\"{x:1602,y:850,t:1527873233144};\\\", \\\"{x:1600,y:852,t:1527873233160};\\\", \\\"{x:1596,y:854,t:1527873233176};\\\", \\\"{x:1588,y:860,t:1527873233193};\\\", \\\"{x:1580,y:868,t:1527873233209};\\\", \\\"{x:1575,y:875,t:1527873233226};\\\", \\\"{x:1566,y:884,t:1527873233244};\\\", \\\"{x:1559,y:889,t:1527873233259};\\\", \\\"{x:1550,y:897,t:1527873233277};\\\", \\\"{x:1548,y:899,t:1527873233294};\\\", \\\"{x:1547,y:902,t:1527873233310};\\\", \\\"{x:1545,y:903,t:1527873233327};\\\", \\\"{x:1544,y:906,t:1527873233343};\\\", \\\"{x:1541,y:911,t:1527873233360};\\\", \\\"{x:1540,y:912,t:1527873233377};\\\", \\\"{x:1539,y:913,t:1527873233394};\\\", \\\"{x:1539,y:914,t:1527873233445};\\\", \\\"{x:1538,y:914,t:1527873233460};\\\", \\\"{x:1538,y:916,t:1527873233485};\\\", \\\"{x:1537,y:916,t:1527873233493};\\\", \\\"{x:1537,y:917,t:1527873233511};\\\", \\\"{x:1537,y:919,t:1527873233527};\\\", \\\"{x:1536,y:920,t:1527873233544};\\\", \\\"{x:1536,y:923,t:1527873233561};\\\", \\\"{x:1536,y:926,t:1527873233577};\\\", \\\"{x:1536,y:927,t:1527873233597};\\\", \\\"{x:1536,y:928,t:1527873233622};\\\", \\\"{x:1535,y:929,t:1527873233638};\\\", \\\"{x:1535,y:930,t:1527873233678};\\\", \\\"{x:1535,y:931,t:1527873233694};\\\", \\\"{x:1535,y:932,t:1527873233711};\\\", \\\"{x:1535,y:933,t:1527873233741};\\\", \\\"{x:1535,y:934,t:1527873233749};\\\", \\\"{x:1535,y:935,t:1527873233760};\\\", \\\"{x:1535,y:936,t:1527873233777};\\\", \\\"{x:1535,y:938,t:1527873233795};\\\", \\\"{x:1535,y:939,t:1527873233838};\\\", \\\"{x:1535,y:940,t:1527873233846};\\\", \\\"{x:1535,y:941,t:1527873233862};\\\", \\\"{x:1535,y:942,t:1527873233894};\\\", \\\"{x:1535,y:943,t:1527873233918};\\\", \\\"{x:1535,y:944,t:1527873233942};\\\", \\\"{x:1535,y:946,t:1527873233973};\\\", \\\"{x:1535,y:947,t:1527873233981};\\\", \\\"{x:1535,y:948,t:1527873233998};\\\", \\\"{x:1535,y:949,t:1527873234014};\\\", \\\"{x:1535,y:950,t:1527873234028};\\\", \\\"{x:1535,y:951,t:1527873234045};\\\", \\\"{x:1535,y:953,t:1527873234069};\\\", \\\"{x:1535,y:954,t:1527873234494};\\\", \\\"{x:1535,y:955,t:1527873234512};\\\", \\\"{x:1537,y:957,t:1527873234528};\\\", \\\"{x:1538,y:957,t:1527873234545};\\\", \\\"{x:1538,y:958,t:1527873234563};\\\", \\\"{x:1539,y:958,t:1527873234578};\\\", \\\"{x:1539,y:959,t:1527873234606};\\\", \\\"{x:1540,y:959,t:1527873234637};\\\", \\\"{x:1540,y:960,t:1527873234718};\\\", \\\"{x:1540,y:961,t:1527873234845};\\\", \\\"{x:1540,y:963,t:1527873237398};\\\", \\\"{x:1541,y:964,t:1527873237454};\\\", \\\"{x:1543,y:964,t:1527873237486};\\\", \\\"{x:1544,y:964,t:1527873237509};\\\", \\\"{x:1544,y:965,t:1527873237541};\\\", \\\"{x:1544,y:966,t:1527873237573};\\\", \\\"{x:1545,y:966,t:1527873237581};\\\", \\\"{x:1546,y:965,t:1527873237886};\\\", \\\"{x:1546,y:963,t:1527873237898};\\\", \\\"{x:1549,y:954,t:1527873237916};\\\", \\\"{x:1555,y:937,t:1527873237932};\\\", \\\"{x:1567,y:905,t:1527873237948};\\\", \\\"{x:1578,y:823,t:1527873237966};\\\", \\\"{x:1578,y:774,t:1527873237982};\\\", \\\"{x:1572,y:730,t:1527873237998};\\\", \\\"{x:1567,y:700,t:1527873238015};\\\", \\\"{x:1562,y:685,t:1527873238033};\\\", \\\"{x:1560,y:682,t:1527873238048};\\\", \\\"{x:1556,y:678,t:1527873238065};\\\", \\\"{x:1541,y:668,t:1527873238082};\\\", \\\"{x:1519,y:649,t:1527873238098};\\\", \\\"{x:1504,y:625,t:1527873238115};\\\", \\\"{x:1489,y:590,t:1527873238133};\\\", \\\"{x:1477,y:562,t:1527873238148};\\\", \\\"{x:1473,y:553,t:1527873238165};\\\", \\\"{x:1473,y:557,t:1527873238269};\\\", \\\"{x:1473,y:568,t:1527873238282};\\\", \\\"{x:1473,y:583,t:1527873238300};\\\", \\\"{x:1473,y:590,t:1527873238315};\\\", \\\"{x:1473,y:593,t:1527873238333};\\\", \\\"{x:1475,y:598,t:1527873238349};\\\", \\\"{x:1477,y:601,t:1527873238365};\\\", \\\"{x:1478,y:604,t:1527873238382};\\\", \\\"{x:1478,y:608,t:1527873238399};\\\", \\\"{x:1478,y:610,t:1527873238415};\\\", \\\"{x:1478,y:612,t:1527873238432};\\\", \\\"{x:1478,y:615,t:1527873238450};\\\", \\\"{x:1478,y:617,t:1527873238465};\\\", \\\"{x:1478,y:619,t:1527873238482};\\\", \\\"{x:1479,y:620,t:1527873238614};\\\", \\\"{x:1480,y:620,t:1527873238621};\\\", \\\"{x:1480,y:622,t:1527873238901};\\\", \\\"{x:1480,y:624,t:1527873238916};\\\", \\\"{x:1481,y:627,t:1527873238933};\\\", \\\"{x:1481,y:629,t:1527873238949};\\\", \\\"{x:1481,y:630,t:1527873238966};\\\", \\\"{x:1481,y:631,t:1527873238984};\\\", \\\"{x:1483,y:631,t:1527873239142};\\\", \\\"{x:1484,y:631,t:1527873239222};\\\", \\\"{x:1485,y:631,t:1527873239234};\\\", \\\"{x:1489,y:631,t:1527873239250};\\\", \\\"{x:1495,y:632,t:1527873239266};\\\", \\\"{x:1498,y:633,t:1527873239284};\\\", \\\"{x:1500,y:633,t:1527873239374};\\\", \\\"{x:1501,y:634,t:1527873239389};\\\", \\\"{x:1502,y:634,t:1527873239638};\\\", \\\"{x:1503,y:634,t:1527873239650};\\\", \\\"{x:1503,y:633,t:1527873239709};\\\", \\\"{x:1504,y:632,t:1527873239717};\\\", \\\"{x:1507,y:628,t:1527873239733};\\\", \\\"{x:1508,y:628,t:1527873239750};\\\", \\\"{x:1510,y:628,t:1527873239848};\\\", \\\"{x:1511,y:628,t:1527873239866};\\\", \\\"{x:1512,y:628,t:1527873239957};\\\", \\\"{x:1513,y:628,t:1527873240718};\\\", \\\"{x:1513,y:630,t:1527873240965};\\\", \\\"{x:1513,y:631,t:1527873240973};\\\", \\\"{x:1513,y:633,t:1527873240986};\\\", \\\"{x:1513,y:642,t:1527873241003};\\\", \\\"{x:1509,y:661,t:1527873241019};\\\", \\\"{x:1509,y:690,t:1527873241035};\\\", \\\"{x:1505,y:694,t:1527873241052};\\\", \\\"{x:1505,y:699,t:1527873241069};\\\", \\\"{x:1504,y:707,t:1527873241085};\\\", \\\"{x:1497,y:719,t:1527873241101};\\\", \\\"{x:1494,y:728,t:1527873241119};\\\", \\\"{x:1491,y:736,t:1527873241135};\\\", \\\"{x:1489,y:739,t:1527873241152};\\\", \\\"{x:1488,y:740,t:1527873241168};\\\", \\\"{x:1487,y:740,t:1527873241189};\\\", \\\"{x:1487,y:741,t:1527873241202};\\\", \\\"{x:1487,y:743,t:1527873241218};\\\", \\\"{x:1487,y:745,t:1527873241235};\\\", \\\"{x:1487,y:747,t:1527873241253};\\\", \\\"{x:1487,y:752,t:1527873241268};\\\", \\\"{x:1487,y:761,t:1527873241285};\\\", \\\"{x:1487,y:775,t:1527873241303};\\\", \\\"{x:1487,y:798,t:1527873241319};\\\", \\\"{x:1493,y:823,t:1527873241335};\\\", \\\"{x:1493,y:849,t:1527873241353};\\\", \\\"{x:1493,y:868,t:1527873241369};\\\", \\\"{x:1493,y:882,t:1527873241385};\\\", \\\"{x:1494,y:886,t:1527873241402};\\\", \\\"{x:1494,y:892,t:1527873241418};\\\", \\\"{x:1494,y:897,t:1527873241435};\\\", \\\"{x:1494,y:902,t:1527873241452};\\\", \\\"{x:1494,y:906,t:1527873241469};\\\", \\\"{x:1494,y:907,t:1527873241485};\\\", \\\"{x:1494,y:904,t:1527873241638};\\\", \\\"{x:1494,y:903,t:1527873241653};\\\", \\\"{x:1493,y:898,t:1527873241669};\\\", \\\"{x:1493,y:896,t:1527873241685};\\\", \\\"{x:1492,y:891,t:1527873241702};\\\", \\\"{x:1489,y:884,t:1527873241719};\\\", \\\"{x:1489,y:879,t:1527873241734};\\\", \\\"{x:1489,y:877,t:1527873241752};\\\", \\\"{x:1488,y:875,t:1527873241769};\\\", \\\"{x:1488,y:873,t:1527873241821};\\\", \\\"{x:1487,y:870,t:1527873241835};\\\", \\\"{x:1485,y:862,t:1527873241852};\\\", \\\"{x:1484,y:852,t:1527873241868};\\\", \\\"{x:1484,y:849,t:1527873241886};\\\", \\\"{x:1483,y:847,t:1527873241902};\\\", \\\"{x:1483,y:845,t:1527873241925};\\\", \\\"{x:1483,y:844,t:1527873241941};\\\", \\\"{x:1482,y:844,t:1527873241957};\\\", \\\"{x:1482,y:842,t:1527873242005};\\\", \\\"{x:1482,y:841,t:1527873242037};\\\", \\\"{x:1482,y:839,t:1527873242069};\\\", \\\"{x:1482,y:838,t:1527873242093};\\\", \\\"{x:1482,y:836,t:1527873242102};\\\", \\\"{x:1482,y:834,t:1527873242119};\\\", \\\"{x:1482,y:833,t:1527873242136};\\\", \\\"{x:1481,y:833,t:1527873250724};\\\", \\\"{x:1478,y:833,t:1527873250741};\\\", \\\"{x:1475,y:833,t:1527873250749};\\\", \\\"{x:1472,y:833,t:1527873250762};\\\", \\\"{x:1457,y:833,t:1527873250778};\\\", \\\"{x:1429,y:824,t:1527873250795};\\\", \\\"{x:1374,y:810,t:1527873250811};\\\", \\\"{x:1312,y:789,t:1527873250829};\\\", \\\"{x:1307,y:781,t:1527873250844};\\\", \\\"{x:1292,y:765,t:1527873250861};\\\", \\\"{x:1270,y:750,t:1527873250879};\\\", \\\"{x:1259,y:743,t:1527873250894};\\\", \\\"{x:1254,y:741,t:1527873250912};\\\", \\\"{x:1246,y:737,t:1527873250928};\\\", \\\"{x:1240,y:737,t:1527873250945};\\\", \\\"{x:1229,y:736,t:1527873250962};\\\", \\\"{x:1203,y:731,t:1527873250979};\\\", \\\"{x:1169,y:725,t:1527873250995};\\\", \\\"{x:1134,y:718,t:1527873251011};\\\", \\\"{x:1029,y:699,t:1527873251029};\\\", \\\"{x:918,y:683,t:1527873251045};\\\", \\\"{x:803,y:679,t:1527873251061};\\\", \\\"{x:717,y:668,t:1527873251079};\\\", \\\"{x:673,y:662,t:1527873251095};\\\", \\\"{x:642,y:657,t:1527873251112};\\\", \\\"{x:607,y:657,t:1527873251128};\\\", \\\"{x:579,y:657,t:1527873251146};\\\", \\\"{x:569,y:657,t:1527873251161};\\\", \\\"{x:566,y:657,t:1527873251179};\\\", \\\"{x:566,y:656,t:1527873251261};\\\", \\\"{x:572,y:641,t:1527873251281};\\\", \\\"{x:578,y:631,t:1527873251296};\\\", \\\"{x:579,y:624,t:1527873251312};\\\", \\\"{x:579,y:622,t:1527873251322};\\\", \\\"{x:579,y:620,t:1527873251338};\\\", \\\"{x:581,y:618,t:1527873251355};\\\", \\\"{x:583,y:617,t:1527873251371};\\\", \\\"{x:591,y:609,t:1527873251389};\\\", \\\"{x:600,y:598,t:1527873251406};\\\", \\\"{x:601,y:595,t:1527873251422};\\\", \\\"{x:602,y:594,t:1527873251439};\\\", \\\"{x:603,y:593,t:1527873251477};\\\", \\\"{x:604,y:593,t:1527873251500};\\\", \\\"{x:604,y:592,t:1527873251508};\\\", \\\"{x:606,y:590,t:1527873251524};\\\", \\\"{x:607,y:589,t:1527873251556};\\\", \\\"{x:614,y:589,t:1527873252317};\\\", \\\"{x:628,y:591,t:1527873252325};\\\", \\\"{x:648,y:598,t:1527873252341};\\\", \\\"{x:780,y:614,t:1527873252356};\\\", \\\"{x:895,y:627,t:1527873252373};\\\", \\\"{x:1020,y:645,t:1527873252389};\\\", \\\"{x:1123,y:663,t:1527873252406};\\\", \\\"{x:1199,y:674,t:1527873252423};\\\", \\\"{x:1239,y:683,t:1527873252439};\\\", \\\"{x:1263,y:691,t:1527873252456};\\\", \\\"{x:1267,y:693,t:1527873252473};\\\", \\\"{x:1269,y:695,t:1527873252490};\\\", \\\"{x:1270,y:696,t:1527873252506};\\\", \\\"{x:1271,y:698,t:1527873252524};\\\", \\\"{x:1272,y:698,t:1527873252541};\\\", \\\"{x:1273,y:699,t:1527873252580};\\\", \\\"{x:1274,y:699,t:1527873252589};\\\", \\\"{x:1275,y:699,t:1527873252607};\\\", \\\"{x:1276,y:700,t:1527873252624};\\\", \\\"{x:1278,y:700,t:1527873252640};\\\", \\\"{x:1280,y:702,t:1527873252657};\\\", \\\"{x:1282,y:702,t:1527873252673};\\\", \\\"{x:1286,y:704,t:1527873252691};\\\", \\\"{x:1289,y:706,t:1527873252706};\\\", \\\"{x:1291,y:708,t:1527873252723};\\\", \\\"{x:1295,y:710,t:1527873252741};\\\", \\\"{x:1299,y:711,t:1527873252757};\\\", \\\"{x:1303,y:711,t:1527873252774};\\\", \\\"{x:1311,y:712,t:1527873252791};\\\", \\\"{x:1320,y:714,t:1527873252807};\\\", \\\"{x:1325,y:714,t:1527873252824};\\\", \\\"{x:1327,y:715,t:1527873252841};\\\", \\\"{x:1328,y:716,t:1527873252862};\\\", \\\"{x:1330,y:716,t:1527873252874};\\\", \\\"{x:1337,y:721,t:1527873252891};\\\", \\\"{x:1352,y:729,t:1527873252907};\\\", \\\"{x:1365,y:734,t:1527873252923};\\\", \\\"{x:1371,y:737,t:1527873252941};\\\", \\\"{x:1373,y:738,t:1527873252957};\\\", \\\"{x:1374,y:739,t:1527873252974};\\\", \\\"{x:1374,y:740,t:1527873252997};\\\", \\\"{x:1374,y:741,t:1527873253013};\\\", \\\"{x:1374,y:742,t:1527873253024};\\\", \\\"{x:1374,y:744,t:1527873253041};\\\", \\\"{x:1374,y:747,t:1527873253057};\\\", \\\"{x:1375,y:748,t:1527873253074};\\\", \\\"{x:1375,y:749,t:1527873253091};\\\", \\\"{x:1375,y:750,t:1527873253108};\\\", \\\"{x:1375,y:751,t:1527873253124};\\\", \\\"{x:1375,y:754,t:1527873253142};\\\", \\\"{x:1376,y:757,t:1527873253158};\\\", \\\"{x:1376,y:758,t:1527873253342};\\\", \\\"{x:1377,y:760,t:1527873253766};\\\", \\\"{x:1378,y:760,t:1527873253829};\\\", \\\"{x:1372,y:762,t:1527873257214};\\\", \\\"{x:1362,y:767,t:1527873257227};\\\", \\\"{x:1352,y:772,t:1527873257245};\\\", \\\"{x:1346,y:772,t:1527873257262};\\\", \\\"{x:1342,y:772,t:1527873257277};\\\", \\\"{x:1341,y:772,t:1527873257294};\\\", \\\"{x:1341,y:773,t:1527873257405};\\\", \\\"{x:1341,y:774,t:1527873257438};\\\", \\\"{x:1340,y:777,t:1527873257444};\\\", \\\"{x:1340,y:781,t:1527873257460};\\\", \\\"{x:1339,y:788,t:1527873257477};\\\", \\\"{x:1338,y:790,t:1527873257495};\\\", \\\"{x:1338,y:792,t:1527873257525};\\\", \\\"{x:1337,y:792,t:1527873257533};\\\", \\\"{x:1337,y:793,t:1527873257582};\\\", \\\"{x:1337,y:794,t:1527873257613};\\\", \\\"{x:1337,y:796,t:1527873257627};\\\", \\\"{x:1336,y:799,t:1527873257645};\\\", \\\"{x:1335,y:803,t:1527873257662};\\\", \\\"{x:1333,y:810,t:1527873257677};\\\", \\\"{x:1329,y:823,t:1527873257694};\\\", \\\"{x:1325,y:837,t:1527873257711};\\\", \\\"{x:1324,y:846,t:1527873257727};\\\", \\\"{x:1323,y:850,t:1527873257744};\\\", \\\"{x:1321,y:853,t:1527873257761};\\\", \\\"{x:1320,y:856,t:1527873257777};\\\", \\\"{x:1320,y:862,t:1527873257795};\\\", \\\"{x:1320,y:872,t:1527873257811};\\\", \\\"{x:1320,y:878,t:1527873257828};\\\", \\\"{x:1319,y:881,t:1527873257844};\\\", \\\"{x:1318,y:883,t:1527873257886};\\\", \\\"{x:1318,y:886,t:1527873257901};\\\", \\\"{x:1318,y:890,t:1527873257911};\\\", \\\"{x:1318,y:894,t:1527873257928};\\\", \\\"{x:1318,y:899,t:1527873257944};\\\", \\\"{x:1317,y:899,t:1527873257961};\\\", \\\"{x:1317,y:898,t:1527873258254};\\\", \\\"{x:1317,y:891,t:1527873258262};\\\", \\\"{x:1317,y:880,t:1527873258278};\\\", \\\"{x:1317,y:873,t:1527873258294};\\\", \\\"{x:1317,y:868,t:1527873258311};\\\", \\\"{x:1317,y:866,t:1527873258328};\\\", \\\"{x:1317,y:863,t:1527873258344};\\\", \\\"{x:1317,y:860,t:1527873258362};\\\", \\\"{x:1317,y:850,t:1527873258378};\\\", \\\"{x:1317,y:836,t:1527873258395};\\\", \\\"{x:1316,y:824,t:1527873258411};\\\", \\\"{x:1314,y:815,t:1527873258428};\\\", \\\"{x:1308,y:802,t:1527873258445};\\\", \\\"{x:1306,y:794,t:1527873258462};\\\", \\\"{x:1305,y:786,t:1527873258478};\\\", \\\"{x:1303,y:776,t:1527873258495};\\\", \\\"{x:1301,y:760,t:1527873258511};\\\", \\\"{x:1298,y:744,t:1527873258529};\\\", \\\"{x:1297,y:730,t:1527873258545};\\\", \\\"{x:1297,y:722,t:1527873258561};\\\", \\\"{x:1297,y:715,t:1527873258578};\\\", \\\"{x:1297,y:707,t:1527873258595};\\\", \\\"{x:1297,y:699,t:1527873258612};\\\", \\\"{x:1294,y:688,t:1527873258628};\\\", \\\"{x:1293,y:684,t:1527873258645};\\\", \\\"{x:1293,y:683,t:1527873258662};\\\", \\\"{x:1294,y:680,t:1527873258678};\\\", \\\"{x:1301,y:675,t:1527873258696};\\\", \\\"{x:1304,y:670,t:1527873258712};\\\", \\\"{x:1308,y:663,t:1527873258728};\\\", \\\"{x:1312,y:657,t:1527873258745};\\\", \\\"{x:1315,y:653,t:1527873258761};\\\", \\\"{x:1319,y:648,t:1527873258778};\\\", \\\"{x:1320,y:647,t:1527873258805};\\\", \\\"{x:1322,y:647,t:1527873258829};\\\", \\\"{x:1325,y:644,t:1527873258845};\\\", \\\"{x:1327,y:641,t:1527873258863};\\\", \\\"{x:1328,y:638,t:1527873258878};\\\", \\\"{x:1328,y:637,t:1527873258895};\\\", \\\"{x:1329,y:637,t:1527873258911};\\\", \\\"{x:1328,y:637,t:1527873259053};\\\", \\\"{x:1325,y:636,t:1527873259062};\\\", \\\"{x:1321,y:634,t:1527873259078};\\\", \\\"{x:1320,y:633,t:1527873259102};\\\", \\\"{x:1319,y:633,t:1527873259133};\\\", \\\"{x:1315,y:632,t:1527873259162};\\\", \\\"{x:1312,y:631,t:1527873259178};\\\", \\\"{x:1311,y:631,t:1527873259195};\\\", \\\"{x:1313,y:637,t:1527873262311};\\\", \\\"{x:1313,y:643,t:1527873262318};\\\", \\\"{x:1314,y:651,t:1527873262331};\\\", \\\"{x:1316,y:669,t:1527873262347};\\\", \\\"{x:1318,y:684,t:1527873262363};\\\", \\\"{x:1318,y:706,t:1527873262380};\\\", \\\"{x:1318,y:714,t:1527873262397};\\\", \\\"{x:1318,y:721,t:1527873262414};\\\", \\\"{x:1318,y:724,t:1527873262430};\\\", \\\"{x:1318,y:728,t:1527873262447};\\\", \\\"{x:1318,y:730,t:1527873262464};\\\", \\\"{x:1318,y:734,t:1527873262480};\\\", \\\"{x:1318,y:737,t:1527873262497};\\\", \\\"{x:1318,y:739,t:1527873262514};\\\", \\\"{x:1318,y:740,t:1527873262531};\\\", \\\"{x:1318,y:741,t:1527873262548};\\\", \\\"{x:1318,y:745,t:1527873262564};\\\", \\\"{x:1316,y:757,t:1527873262581};\\\", \\\"{x:1314,y:764,t:1527873262597};\\\", \\\"{x:1311,y:775,t:1527873262615};\\\", \\\"{x:1306,y:785,t:1527873262631};\\\", \\\"{x:1301,y:796,t:1527873262647};\\\", \\\"{x:1299,y:802,t:1527873262664};\\\", \\\"{x:1298,y:807,t:1527873262681};\\\", \\\"{x:1297,y:814,t:1527873262698};\\\", \\\"{x:1295,y:820,t:1527873262714};\\\", \\\"{x:1295,y:824,t:1527873262732};\\\", \\\"{x:1295,y:826,t:1527873262748};\\\", \\\"{x:1295,y:827,t:1527873262764};\\\", \\\"{x:1295,y:828,t:1527873262781};\\\", \\\"{x:1295,y:830,t:1527873262798};\\\", \\\"{x:1295,y:832,t:1527873262814};\\\", \\\"{x:1295,y:835,t:1527873262831};\\\", \\\"{x:1296,y:838,t:1527873262848};\\\", \\\"{x:1299,y:844,t:1527873262864};\\\", \\\"{x:1300,y:847,t:1527873262881};\\\", \\\"{x:1300,y:848,t:1527873262898};\\\", \\\"{x:1302,y:851,t:1527873262915};\\\", \\\"{x:1302,y:852,t:1527873262932};\\\", \\\"{x:1306,y:856,t:1527873262949};\\\", \\\"{x:1307,y:859,t:1527873262965};\\\", \\\"{x:1310,y:866,t:1527873262981};\\\", \\\"{x:1313,y:869,t:1527873262998};\\\", \\\"{x:1314,y:870,t:1527873263015};\\\", \\\"{x:1315,y:873,t:1527873263031};\\\", \\\"{x:1317,y:876,t:1527873263048};\\\", \\\"{x:1319,y:879,t:1527873263064};\\\", \\\"{x:1321,y:881,t:1527873263082};\\\", \\\"{x:1322,y:882,t:1527873263099};\\\", \\\"{x:1323,y:882,t:1527873263115};\\\", \\\"{x:1323,y:883,t:1527873263132};\\\", \\\"{x:1325,y:883,t:1527873263148};\\\", \\\"{x:1326,y:884,t:1527873263165};\\\", \\\"{x:1328,y:885,t:1527873263181};\\\", \\\"{x:1329,y:886,t:1527873263198};\\\", \\\"{x:1330,y:886,t:1527873263215};\\\", \\\"{x:1332,y:887,t:1527873263237};\\\", \\\"{x:1333,y:887,t:1527873263269};\\\", \\\"{x:1334,y:889,t:1527873263285};\\\", \\\"{x:1336,y:889,t:1527873263309};\\\", \\\"{x:1336,y:890,t:1527873263317};\\\", \\\"{x:1337,y:892,t:1527873263332};\\\", \\\"{x:1339,y:894,t:1527873263350};\\\", \\\"{x:1340,y:895,t:1527873263366};\\\", \\\"{x:1341,y:896,t:1527873263430};\\\", \\\"{x:1343,y:896,t:1527873263454};\\\", \\\"{x:1344,y:896,t:1527873263493};\\\", \\\"{x:1345,y:897,t:1527873263534};\\\", \\\"{x:1345,y:898,t:1527873263549};\\\", \\\"{x:1346,y:898,t:1527873263565};\\\", \\\"{x:1346,y:899,t:1527873263637};\\\", \\\"{x:1346,y:901,t:1527873264013};\\\", \\\"{x:1348,y:901,t:1527873265293};\\\", \\\"{x:1349,y:900,t:1527873265333};\\\", \\\"{x:1349,y:899,t:1527873265350};\\\", \\\"{x:1349,y:898,t:1527873265389};\\\", \\\"{x:1349,y:897,t:1527873265420};\\\", \\\"{x:1350,y:896,t:1527873265437};\\\", \\\"{x:1351,y:895,t:1527873265469};\\\", \\\"{x:1352,y:895,t:1527873265483};\\\", \\\"{x:1355,y:895,t:1527873265501};\\\", \\\"{x:1360,y:895,t:1527873265566};\\\", \\\"{x:1369,y:897,t:1527873265584};\\\", \\\"{x:1376,y:898,t:1527873265600};\\\", \\\"{x:1380,y:898,t:1527873265616};\\\", \\\"{x:1381,y:898,t:1527873265635};\\\", \\\"{x:1382,y:898,t:1527873265694};\\\", \\\"{x:1383,y:898,t:1527873265726};\\\", \\\"{x:1384,y:898,t:1527873265733};\\\", \\\"{x:1385,y:898,t:1527873265751};\\\", \\\"{x:1386,y:898,t:1527873265773};\\\", \\\"{x:1387,y:898,t:1527873265789};\\\", \\\"{x:1388,y:898,t:1527873265805};\\\", \\\"{x:1390,y:898,t:1527873265821};\\\", \\\"{x:1391,y:898,t:1527873265833};\\\", \\\"{x:1394,y:898,t:1527873265851};\\\", \\\"{x:1395,y:898,t:1527873265867};\\\", \\\"{x:1396,y:898,t:1527873265884};\\\", \\\"{x:1397,y:897,t:1527873265910};\\\", \\\"{x:1398,y:896,t:1527873265918};\\\", \\\"{x:1399,y:896,t:1527873265949};\\\", \\\"{x:1399,y:895,t:1527873266198};\\\", \\\"{x:1398,y:895,t:1527873266214};\\\", \\\"{x:1395,y:894,t:1527873266229};\\\", \\\"{x:1390,y:893,t:1527873266237};\\\", \\\"{x:1385,y:892,t:1527873266251};\\\", \\\"{x:1369,y:890,t:1527873266268};\\\", \\\"{x:1348,y:888,t:1527873266285};\\\", \\\"{x:1330,y:883,t:1527873266302};\\\", \\\"{x:1325,y:879,t:1527873266317};\\\", \\\"{x:1322,y:879,t:1527873266334};\\\", \\\"{x:1319,y:878,t:1527873266351};\\\", \\\"{x:1315,y:878,t:1527873266368};\\\", \\\"{x:1311,y:878,t:1527873266384};\\\", \\\"{x:1308,y:878,t:1527873266401};\\\", \\\"{x:1306,y:878,t:1527873266418};\\\", \\\"{x:1304,y:878,t:1527873266445};\\\", \\\"{x:1303,y:878,t:1527873266453};\\\", \\\"{x:1302,y:878,t:1527873266468};\\\", \\\"{x:1300,y:878,t:1527873266484};\\\", \\\"{x:1298,y:878,t:1527873266500};\\\", \\\"{x:1297,y:876,t:1527873266877};\\\", \\\"{x:1296,y:876,t:1527873267022};\\\", \\\"{x:1296,y:877,t:1527873267064};\\\", \\\"{x:1296,y:878,t:1527873267069};\\\", \\\"{x:1295,y:881,t:1527873267084};\\\", \\\"{x:1290,y:886,t:1527873267100};\\\", \\\"{x:1286,y:889,t:1527873267117};\\\", \\\"{x:1281,y:893,t:1527873267134};\\\", \\\"{x:1279,y:895,t:1527873267151};\\\", \\\"{x:1278,y:896,t:1527873267168};\\\", \\\"{x:1278,y:897,t:1527873267185};\\\", \\\"{x:1278,y:898,t:1527873267221};\\\", \\\"{x:1278,y:899,t:1527873267285};\\\", \\\"{x:1278,y:900,t:1527873267309};\\\", \\\"{x:1278,y:901,t:1527873267317};\\\", \\\"{x:1278,y:902,t:1527873267335};\\\", \\\"{x:1279,y:902,t:1527873267351};\\\", \\\"{x:1279,y:903,t:1527873267368};\\\", \\\"{x:1280,y:903,t:1527873267397};\\\", \\\"{x:1281,y:903,t:1527873268796};\\\", \\\"{x:1281,y:902,t:1527873268812};\\\", \\\"{x:1282,y:901,t:1527873268844};\\\", \\\"{x:1282,y:900,t:1527873268893};\\\", \\\"{x:1282,y:898,t:1527873269790};\\\", \\\"{x:1282,y:897,t:1527873269862};\\\", \\\"{x:1284,y:896,t:1527873269942};\\\", \\\"{x:1286,y:895,t:1527873269973};\\\", \\\"{x:1286,y:894,t:1527873269997};\\\", \\\"{x:1288,y:893,t:1527873270005};\\\", \\\"{x:1288,y:892,t:1527873270020};\\\", \\\"{x:1289,y:891,t:1527873270037};\\\", \\\"{x:1289,y:890,t:1527873270062};\\\", \\\"{x:1289,y:889,t:1527873270085};\\\", \\\"{x:1290,y:888,t:1527873270125};\\\", \\\"{x:1294,y:886,t:1527873270141};\\\", \\\"{x:1297,y:884,t:1527873270154};\\\", \\\"{x:1304,y:882,t:1527873270170};\\\", \\\"{x:1306,y:882,t:1527873270187};\\\", \\\"{x:1308,y:880,t:1527873270204};\\\", \\\"{x:1310,y:879,t:1527873270237};\\\", \\\"{x:1312,y:878,t:1527873270253};\\\", \\\"{x:1314,y:877,t:1527873270270};\\\", \\\"{x:1317,y:875,t:1527873270287};\\\", \\\"{x:1320,y:874,t:1527873270304};\\\", \\\"{x:1321,y:873,t:1527873270320};\\\", \\\"{x:1322,y:873,t:1527873270336};\\\", \\\"{x:1323,y:873,t:1527873270357};\\\", \\\"{x:1324,y:873,t:1527873270373};\\\", \\\"{x:1326,y:872,t:1527873270387};\\\", \\\"{x:1331,y:869,t:1527873270404};\\\", \\\"{x:1337,y:868,t:1527873270420};\\\", \\\"{x:1340,y:866,t:1527873270437};\\\", \\\"{x:1341,y:866,t:1527873270453};\\\", \\\"{x:1342,y:866,t:1527873270501};\\\", \\\"{x:1343,y:866,t:1527873270558};\\\", \\\"{x:1344,y:866,t:1527873270581};\\\", \\\"{x:1345,y:865,t:1527873270597};\\\", \\\"{x:1346,y:865,t:1527873270613};\\\", \\\"{x:1347,y:865,t:1527873270621};\\\", \\\"{x:1351,y:864,t:1527873270637};\\\", \\\"{x:1356,y:861,t:1527873270654};\\\", \\\"{x:1364,y:858,t:1527873270671};\\\", \\\"{x:1369,y:857,t:1527873270686};\\\", \\\"{x:1374,y:855,t:1527873270704};\\\", \\\"{x:1376,y:854,t:1527873270721};\\\", \\\"{x:1379,y:852,t:1527873270737};\\\", \\\"{x:1382,y:850,t:1527873270754};\\\", \\\"{x:1386,y:848,t:1527873270771};\\\", \\\"{x:1386,y:847,t:1527873270787};\\\", \\\"{x:1389,y:845,t:1527873270804};\\\", \\\"{x:1390,y:845,t:1527873270894};\\\", \\\"{x:1392,y:844,t:1527873270997};\\\", \\\"{x:1394,y:843,t:1527873271014};\\\", \\\"{x:1397,y:841,t:1527873271021};\\\", \\\"{x:1400,y:839,t:1527873271037};\\\", \\\"{x:1404,y:837,t:1527873271054};\\\", \\\"{x:1406,y:836,t:1527873271071};\\\", \\\"{x:1408,y:835,t:1527873271088};\\\", \\\"{x:1408,y:834,t:1527873271214};\\\", \\\"{x:1408,y:833,t:1527873271277};\\\", \\\"{x:1408,y:831,t:1527873271287};\\\", \\\"{x:1409,y:827,t:1527873271304};\\\", \\\"{x:1410,y:823,t:1527873271321};\\\", \\\"{x:1410,y:819,t:1527873271338};\\\", \\\"{x:1410,y:814,t:1527873271354};\\\", \\\"{x:1408,y:810,t:1527873271371};\\\", \\\"{x:1407,y:808,t:1527873271387};\\\", \\\"{x:1407,y:804,t:1527873271404};\\\", \\\"{x:1407,y:797,t:1527873271421};\\\", \\\"{x:1408,y:789,t:1527873271438};\\\", \\\"{x:1409,y:785,t:1527873271455};\\\", \\\"{x:1410,y:784,t:1527873271471};\\\", \\\"{x:1410,y:783,t:1527873271489};\\\", \\\"{x:1410,y:779,t:1527873271505};\\\", \\\"{x:1409,y:771,t:1527873271522};\\\", \\\"{x:1406,y:766,t:1527873271538};\\\", \\\"{x:1406,y:762,t:1527873271556};\\\", \\\"{x:1405,y:759,t:1527873271571};\\\", \\\"{x:1405,y:758,t:1527873271588};\\\", \\\"{x:1404,y:757,t:1527873271606};\\\", \\\"{x:1403,y:756,t:1527873271621};\\\", \\\"{x:1402,y:756,t:1527873271638};\\\", \\\"{x:1398,y:756,t:1527873271656};\\\", \\\"{x:1397,y:755,t:1527873271670};\\\", \\\"{x:1396,y:755,t:1527873271732};\\\", \\\"{x:1394,y:754,t:1527873271740};\\\", \\\"{x:1393,y:754,t:1527873271756};\\\", \\\"{x:1392,y:754,t:1527873271772};\\\", \\\"{x:1391,y:754,t:1527873271820};\\\", \\\"{x:1390,y:754,t:1527873271837};\\\", \\\"{x:1388,y:754,t:1527873271855};\\\", \\\"{x:1387,y:754,t:1527873271871};\\\", \\\"{x:1384,y:755,t:1527873271887};\\\", \\\"{x:1383,y:756,t:1527873271905};\\\", \\\"{x:1383,y:759,t:1527873271920};\\\", \\\"{x:1382,y:769,t:1527873271938};\\\", \\\"{x:1382,y:779,t:1527873271955};\\\", \\\"{x:1382,y:782,t:1527873271970};\\\", \\\"{x:1382,y:787,t:1527873271987};\\\", \\\"{x:1382,y:792,t:1527873272005};\\\", \\\"{x:1382,y:796,t:1527873272022};\\\", \\\"{x:1382,y:802,t:1527873272038};\\\", \\\"{x:1383,y:811,t:1527873272055};\\\", \\\"{x:1384,y:817,t:1527873272072};\\\", \\\"{x:1385,y:823,t:1527873272088};\\\", \\\"{x:1388,y:829,t:1527873272104};\\\", \\\"{x:1389,y:836,t:1527873272121};\\\", \\\"{x:1389,y:845,t:1527873272138};\\\", \\\"{x:1392,y:857,t:1527873272155};\\\", \\\"{x:1394,y:870,t:1527873272172};\\\", \\\"{x:1397,y:879,t:1527873272188};\\\", \\\"{x:1397,y:882,t:1527873272205};\\\", \\\"{x:1398,y:883,t:1527873272221};\\\", \\\"{x:1398,y:885,t:1527873272238};\\\", \\\"{x:1400,y:888,t:1527873272255};\\\", \\\"{x:1401,y:892,t:1527873272272};\\\", \\\"{x:1401,y:894,t:1527873272288};\\\", \\\"{x:1402,y:896,t:1527873272305};\\\", \\\"{x:1402,y:900,t:1527873272350};\\\", \\\"{x:1402,y:902,t:1527873272357};\\\", \\\"{x:1403,y:906,t:1527873272373};\\\", \\\"{x:1403,y:912,t:1527873272388};\\\", \\\"{x:1405,y:915,t:1527873272405};\\\", \\\"{x:1405,y:917,t:1527873272423};\\\", \\\"{x:1407,y:919,t:1527873272445};\\\", \\\"{x:1408,y:919,t:1527873272455};\\\", \\\"{x:1408,y:920,t:1527873272472};\\\", \\\"{x:1408,y:921,t:1527873272490};\\\", \\\"{x:1409,y:924,t:1527873272505};\\\", \\\"{x:1409,y:925,t:1527873272522};\\\", \\\"{x:1409,y:927,t:1527873272549};\\\", \\\"{x:1411,y:929,t:1527873272557};\\\", \\\"{x:1411,y:930,t:1527873272572};\\\", \\\"{x:1414,y:934,t:1527873272589};\\\", \\\"{x:1416,y:936,t:1527873272604};\\\", \\\"{x:1416,y:938,t:1527873272660};\\\", \\\"{x:1416,y:939,t:1527873272671};\\\", \\\"{x:1416,y:942,t:1527873272689};\\\", \\\"{x:1416,y:945,t:1527873272704};\\\", \\\"{x:1416,y:946,t:1527873272724};\\\", \\\"{x:1418,y:947,t:1527873272739};\\\", \\\"{x:1418,y:948,t:1527873272805};\\\", \\\"{x:1418,y:949,t:1527873272917};\\\", \\\"{x:1418,y:950,t:1527873273406};\\\", \\\"{x:1418,y:951,t:1527873273423};\\\", \\\"{x:1417,y:952,t:1527873273445};\\\", \\\"{x:1416,y:952,t:1527873274301};\\\", \\\"{x:1415,y:952,t:1527873274517};\\\", \\\"{x:1413,y:952,t:1527873277381};\\\", \\\"{x:1409,y:955,t:1527873277420};\\\", \\\"{x:1408,y:955,t:1527873277428};\\\", \\\"{x:1406,y:955,t:1527873277509};\\\", \\\"{x:1405,y:956,t:1527873277532};\\\", \\\"{x:1403,y:958,t:1527873277549};\\\", \\\"{x:1400,y:959,t:1527873277559};\\\", \\\"{x:1394,y:962,t:1527873277575};\\\", \\\"{x:1387,y:964,t:1527873277593};\\\", \\\"{x:1386,y:964,t:1527873277609};\\\", \\\"{x:1386,y:965,t:1527873277626};\\\", \\\"{x:1385,y:966,t:1527873277662};\\\", \\\"{x:1384,y:966,t:1527873277675};\\\", \\\"{x:1383,y:966,t:1527873277692};\\\", \\\"{x:1376,y:969,t:1527873277709};\\\", \\\"{x:1374,y:969,t:1527873277727};\\\", \\\"{x:1373,y:969,t:1527873277805};\\\", \\\"{x:1371,y:969,t:1527873277869};\\\", \\\"{x:1370,y:969,t:1527873277877};\\\", \\\"{x:1366,y:969,t:1527873277892};\\\", \\\"{x:1348,y:964,t:1527873277911};\\\", \\\"{x:1338,y:960,t:1527873277927};\\\", \\\"{x:1336,y:959,t:1527873277942};\\\", \\\"{x:1336,y:958,t:1527873277959};\\\", \\\"{x:1335,y:958,t:1527873279430};\\\", \\\"{x:1334,y:958,t:1527873279443};\\\", \\\"{x:1331,y:958,t:1527873279462};\\\", \\\"{x:1327,y:955,t:1527873279477};\\\", \\\"{x:1317,y:953,t:1527873279493};\\\", \\\"{x:1296,y:950,t:1527873279510};\\\", \\\"{x:1274,y:946,t:1527873279528};\\\", \\\"{x:1252,y:939,t:1527873279543};\\\", \\\"{x:1231,y:934,t:1527873279560};\\\", \\\"{x:1196,y:919,t:1527873279576};\\\", \\\"{x:1158,y:897,t:1527873279593};\\\", \\\"{x:1112,y:864,t:1527873279610};\\\", \\\"{x:1070,y:833,t:1527873279627};\\\", \\\"{x:1034,y:810,t:1527873279643};\\\", \\\"{x:951,y:730,t:1527873279660};\\\", \\\"{x:834,y:623,t:1527873279676};\\\", \\\"{x:694,y:508,t:1527873279694};\\\", \\\"{x:569,y:413,t:1527873279710};\\\", \\\"{x:484,y:364,t:1527873279726};\\\", \\\"{x:441,y:347,t:1527873279744};\\\", \\\"{x:419,y:345,t:1527873279759};\\\", \\\"{x:405,y:345,t:1527873279777};\\\", \\\"{x:390,y:352,t:1527873279793};\\\", \\\"{x:373,y:372,t:1527873279810};\\\", \\\"{x:355,y:424,t:1527873279827};\\\", \\\"{x:340,y:484,t:1527873279843};\\\", \\\"{x:335,y:552,t:1527873279861};\\\", \\\"{x:334,y:570,t:1527873279877};\\\", \\\"{x:334,y:595,t:1527873279896};\\\", \\\"{x:344,y:644,t:1527873279913};\\\", \\\"{x:359,y:692,t:1527873279929};\\\", \\\"{x:374,y:722,t:1527873279945};\\\", \\\"{x:388,y:742,t:1527873279961};\\\", \\\"{x:401,y:760,t:1527873279979};\\\", \\\"{x:411,y:772,t:1527873279995};\\\", \\\"{x:416,y:780,t:1527873280012};\\\", \\\"{x:427,y:790,t:1527873280028};\\\", \\\"{x:435,y:796,t:1527873280045};\\\", \\\"{x:437,y:797,t:1527873280062};\\\", \\\"{x:443,y:796,t:1527873280079};\\\", \\\"{x:461,y:794,t:1527873280095};\\\", \\\"{x:465,y:794,t:1527873280112};\\\", \\\"{x:478,y:790,t:1527873280129};\\\", \\\"{x:484,y:785,t:1527873280146};\\\", \\\"{x:485,y:781,t:1527873280162};\\\", \\\"{x:486,y:777,t:1527873280179};\\\", \\\"{x:486,y:769,t:1527873280196};\\\", \\\"{x:488,y:760,t:1527873280212};\\\", \\\"{x:493,y:752,t:1527873280228};\\\", \\\"{x:494,y:751,t:1527873280246};\\\", \\\"{x:494,y:750,t:1527873280262};\\\", \\\"{x:496,y:749,t:1527873280285};\\\", \\\"{x:497,y:747,t:1527873280309};\\\", \\\"{x:500,y:743,t:1527873280316};\\\", \\\"{x:501,y:740,t:1527873280329};\\\", \\\"{x:503,y:736,t:1527873280346};\\\", \\\"{x:507,y:732,t:1527873280363};\\\", \\\"{x:507,y:729,t:1527873280379};\\\", \\\"{x:510,y:726,t:1527873280396};\\\", \\\"{x:511,y:724,t:1527873280412};\\\", \\\"{x:511,y:723,t:1527873280436};\\\", \\\"{x:514,y:721,t:1527873280462};\\\", \\\"{x:521,y:712,t:1527873280479};\\\", \\\"{x:530,y:702,t:1527873280496};\\\", \\\"{x:531,y:701,t:1527873280513};\\\", \\\"{x:532,y:701,t:1527873280529};\\\" ] }, { \\\"rt\\\": 104839, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 338982, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"9BS72\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -01 PM-U -F -O -U -Z \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:532,y:700,t:1527873286229};\\\", \\\"{x:532,y:699,t:1527873286236};\\\", \\\"{x:532,y:698,t:1527873286250};\\\", \\\"{x:539,y:697,t:1527873286267};\\\", \\\"{x:549,y:696,t:1527873286284};\\\", \\\"{x:567,y:694,t:1527873286301};\\\", \\\"{x:582,y:693,t:1527873286317};\\\", \\\"{x:592,y:690,t:1527873286333};\\\", \\\"{x:603,y:689,t:1527873286350};\\\", \\\"{x:616,y:688,t:1527873286368};\\\", \\\"{x:626,y:685,t:1527873286384};\\\", \\\"{x:636,y:684,t:1527873286401};\\\", \\\"{x:649,y:683,t:1527873286417};\\\", \\\"{x:659,y:683,t:1527873286434};\\\", \\\"{x:671,y:683,t:1527873286450};\\\", \\\"{x:680,y:683,t:1527873286468};\\\", \\\"{x:686,y:680,t:1527873286484};\\\", \\\"{x:693,y:679,t:1527873286501};\\\", \\\"{x:695,y:677,t:1527873286517};\\\", \\\"{x:697,y:677,t:1527873286533};\\\", \\\"{x:701,y:675,t:1527873286550};\\\", \\\"{x:706,y:674,t:1527873286567};\\\", \\\"{x:715,y:671,t:1527873286583};\\\", \\\"{x:722,y:668,t:1527873286600};\\\", \\\"{x:731,y:664,t:1527873286616};\\\", \\\"{x:733,y:664,t:1527873286633};\\\", \\\"{x:736,y:664,t:1527873286650};\\\", \\\"{x:738,y:663,t:1527873286667};\\\", \\\"{x:751,y:658,t:1527873286684};\\\", \\\"{x:766,y:654,t:1527873286700};\\\", \\\"{x:781,y:649,t:1527873286718};\\\", \\\"{x:793,y:646,t:1527873286735};\\\", \\\"{x:801,y:643,t:1527873286750};\\\", \\\"{x:810,y:641,t:1527873286767};\\\", \\\"{x:825,y:639,t:1527873286784};\\\", \\\"{x:848,y:634,t:1527873286800};\\\", \\\"{x:870,y:629,t:1527873286817};\\\", \\\"{x:892,y:624,t:1527873286836};\\\", \\\"{x:908,y:621,t:1527873286850};\\\", \\\"{x:921,y:618,t:1527873286867};\\\", \\\"{x:926,y:616,t:1527873286880};\\\", \\\"{x:938,y:611,t:1527873286897};\\\", \\\"{x:950,y:606,t:1527873286913};\\\", \\\"{x:964,y:599,t:1527873286931};\\\", \\\"{x:975,y:594,t:1527873286947};\\\", \\\"{x:986,y:587,t:1527873286967};\\\", \\\"{x:990,y:585,t:1527873286984};\\\", \\\"{x:993,y:582,t:1527873287001};\\\", \\\"{x:996,y:581,t:1527873287017};\\\", \\\"{x:1003,y:577,t:1527873287034};\\\", \\\"{x:1008,y:574,t:1527873287052};\\\", \\\"{x:1016,y:572,t:1527873287067};\\\", \\\"{x:1025,y:569,t:1527873287084};\\\", \\\"{x:1033,y:565,t:1527873287102};\\\", \\\"{x:1044,y:560,t:1527873287118};\\\", \\\"{x:1053,y:555,t:1527873287135};\\\", \\\"{x:1061,y:552,t:1527873287151};\\\", \\\"{x:1072,y:546,t:1527873287169};\\\", \\\"{x:1079,y:544,t:1527873287185};\\\", \\\"{x:1091,y:539,t:1527873287201};\\\", \\\"{x:1104,y:532,t:1527873287218};\\\", \\\"{x:1119,y:527,t:1527873287234};\\\", \\\"{x:1125,y:525,t:1527873287252};\\\", \\\"{x:1136,y:520,t:1527873287279};\\\", \\\"{x:1137,y:519,t:1527873287295};\\\", \\\"{x:1137,y:518,t:1527873287799};\\\", \\\"{x:1137,y:523,t:1527873287919};\\\", \\\"{x:1136,y:528,t:1527873287928};\\\", \\\"{x:1133,y:553,t:1527873287945};\\\", \\\"{x:1133,y:604,t:1527873287961};\\\", \\\"{x:1133,y:655,t:1527873287978};\\\", \\\"{x:1133,y:684,t:1527873287996};\\\", \\\"{x:1133,y:713,t:1527873288011};\\\", \\\"{x:1133,y:736,t:1527873288028};\\\", \\\"{x:1138,y:762,t:1527873288045};\\\", \\\"{x:1141,y:785,t:1527873288062};\\\", \\\"{x:1145,y:801,t:1527873288078};\\\", \\\"{x:1148,y:806,t:1527873288095};\\\", \\\"{x:1149,y:811,t:1527873288112};\\\", \\\"{x:1150,y:816,t:1527873288128};\\\", \\\"{x:1153,y:821,t:1527873288150};\\\", \\\"{x:1158,y:826,t:1527873288163};\\\", \\\"{x:1159,y:828,t:1527873288178};\\\", \\\"{x:1160,y:829,t:1527873288195};\\\", \\\"{x:1162,y:830,t:1527873288247};\\\", \\\"{x:1163,y:830,t:1527873288295};\\\", \\\"{x:1164,y:830,t:1527873288312};\\\", \\\"{x:1166,y:832,t:1527873288328};\\\", \\\"{x:1167,y:832,t:1527873288351};\\\", \\\"{x:1169,y:833,t:1527873288438};\\\", \\\"{x:1170,y:835,t:1527873288462};\\\", \\\"{x:1171,y:835,t:1527873288493};\\\", \\\"{x:1171,y:836,t:1527873288501};\\\", \\\"{x:1171,y:839,t:1527873288512};\\\", \\\"{x:1172,y:843,t:1527873288528};\\\", \\\"{x:1175,y:847,t:1527873288544};\\\", \\\"{x:1176,y:848,t:1527873288561};\\\", \\\"{x:1177,y:848,t:1527873288579};\\\", \\\"{x:1177,y:850,t:1527873288622};\\\", \\\"{x:1181,y:851,t:1527873288766};\\\", \\\"{x:1183,y:852,t:1527873288778};\\\", \\\"{x:1186,y:854,t:1527873288794};\\\", \\\"{x:1187,y:854,t:1527873288814};\\\", \\\"{x:1188,y:854,t:1527873288829};\\\", \\\"{x:1188,y:853,t:1527873288903};\\\", \\\"{x:1190,y:853,t:1527873288926};\\\", \\\"{x:1191,y:853,t:1527873288934};\\\", \\\"{x:1193,y:855,t:1527873288958};\\\", \\\"{x:1194,y:855,t:1527873288966};\\\", \\\"{x:1195,y:855,t:1527873288981};\\\", \\\"{x:1193,y:853,t:1527873289005};\\\", \\\"{x:1196,y:853,t:1527873289823};\\\", \\\"{x:1199,y:854,t:1527873289830};\\\", \\\"{x:1209,y:858,t:1527873289847};\\\", \\\"{x:1225,y:865,t:1527873289863};\\\", \\\"{x:1243,y:875,t:1527873289880};\\\", \\\"{x:1254,y:881,t:1527873289896};\\\", \\\"{x:1257,y:883,t:1527873289913};\\\", \\\"{x:1258,y:883,t:1527873289931};\\\", \\\"{x:1259,y:883,t:1527873289975};\\\", \\\"{x:1261,y:883,t:1527873289983};\\\", \\\"{x:1262,y:883,t:1527873289999};\\\", \\\"{x:1263,y:883,t:1527873290046};\\\", \\\"{x:1264,y:883,t:1527873290094};\\\", \\\"{x:1265,y:883,t:1527873290111};\\\", \\\"{x:1266,y:883,t:1527873290118};\\\", \\\"{x:1267,y:883,t:1527873290130};\\\", \\\"{x:1268,y:883,t:1527873290150};\\\", \\\"{x:1270,y:883,t:1527873290206};\\\", \\\"{x:1272,y:882,t:1527873290222};\\\", \\\"{x:1273,y:881,t:1527873290238};\\\", \\\"{x:1274,y:881,t:1527873290247};\\\", \\\"{x:1275,y:880,t:1527873290263};\\\", \\\"{x:1278,y:880,t:1527873290280};\\\", \\\"{x:1284,y:880,t:1527873290298};\\\", \\\"{x:1289,y:880,t:1527873290313};\\\", \\\"{x:1297,y:880,t:1527873290330};\\\", \\\"{x:1306,y:881,t:1527873290348};\\\", \\\"{x:1316,y:881,t:1527873290366};\\\", \\\"{x:1320,y:881,t:1527873290380};\\\", \\\"{x:1326,y:881,t:1527873290398};\\\", \\\"{x:1334,y:879,t:1527873290414};\\\", \\\"{x:1344,y:874,t:1527873290430};\\\", \\\"{x:1350,y:872,t:1527873290447};\\\", \\\"{x:1360,y:868,t:1527873290464};\\\", \\\"{x:1369,y:866,t:1527873290480};\\\", \\\"{x:1381,y:862,t:1527873290497};\\\", \\\"{x:1388,y:861,t:1527873290514};\\\", \\\"{x:1399,y:861,t:1527873290531};\\\", \\\"{x:1409,y:861,t:1527873290547};\\\", \\\"{x:1427,y:861,t:1527873290565};\\\", \\\"{x:1454,y:865,t:1527873290580};\\\", \\\"{x:1481,y:870,t:1527873290597};\\\", \\\"{x:1498,y:875,t:1527873290613};\\\", \\\"{x:1513,y:875,t:1527873290631};\\\", \\\"{x:1526,y:875,t:1527873290647};\\\", \\\"{x:1539,y:874,t:1527873290663};\\\", \\\"{x:1556,y:872,t:1527873290681};\\\", \\\"{x:1566,y:869,t:1527873290697};\\\", \\\"{x:1583,y:867,t:1527873290713};\\\", \\\"{x:1599,y:864,t:1527873290731};\\\", \\\"{x:1607,y:861,t:1527873290747};\\\", \\\"{x:1612,y:859,t:1527873290765};\\\", \\\"{x:1622,y:855,t:1527873290781};\\\", \\\"{x:1630,y:852,t:1527873290797};\\\", \\\"{x:1639,y:845,t:1527873290814};\\\", \\\"{x:1647,y:839,t:1527873290830};\\\", \\\"{x:1651,y:834,t:1527873290847};\\\", \\\"{x:1661,y:826,t:1527873290864};\\\", \\\"{x:1669,y:815,t:1527873290880};\\\", \\\"{x:1676,y:805,t:1527873290897};\\\", \\\"{x:1682,y:795,t:1527873290915};\\\", \\\"{x:1685,y:790,t:1527873290930};\\\", \\\"{x:1686,y:787,t:1527873290947};\\\", \\\"{x:1687,y:785,t:1527873290982};\\\", \\\"{x:1688,y:784,t:1527873290997};\\\", \\\"{x:1693,y:774,t:1527873291014};\\\", \\\"{x:1697,y:767,t:1527873291030};\\\", \\\"{x:1701,y:758,t:1527873291047};\\\", \\\"{x:1706,y:747,t:1527873291064};\\\", \\\"{x:1712,y:738,t:1527873291081};\\\", \\\"{x:1713,y:733,t:1527873291097};\\\", \\\"{x:1713,y:725,t:1527873291114};\\\", \\\"{x:1713,y:712,t:1527873291130};\\\", \\\"{x:1710,y:696,t:1527873291147};\\\", \\\"{x:1707,y:675,t:1527873291166};\\\", \\\"{x:1703,y:658,t:1527873291181};\\\", \\\"{x:1702,y:644,t:1527873291197};\\\", \\\"{x:1692,y:615,t:1527873291214};\\\", \\\"{x:1679,y:587,t:1527873291231};\\\", \\\"{x:1662,y:555,t:1527873291248};\\\", \\\"{x:1651,y:531,t:1527873291264};\\\", \\\"{x:1643,y:514,t:1527873291281};\\\", \\\"{x:1637,y:504,t:1527873291297};\\\", \\\"{x:1633,y:497,t:1527873291314};\\\", \\\"{x:1625,y:486,t:1527873291331};\\\", \\\"{x:1614,y:469,t:1527873291347};\\\", \\\"{x:1592,y:436,t:1527873291365};\\\", \\\"{x:1564,y:394,t:1527873291381};\\\", \\\"{x:1546,y:361,t:1527873291397};\\\", \\\"{x:1524,y:324,t:1527873291414};\\\", \\\"{x:1505,y:291,t:1527873291430};\\\", \\\"{x:1494,y:273,t:1527873291447};\\\", \\\"{x:1482,y:257,t:1527873291465};\\\", \\\"{x:1470,y:240,t:1527873291481};\\\", \\\"{x:1461,y:233,t:1527873291498};\\\", \\\"{x:1453,y:226,t:1527873291514};\\\", \\\"{x:1450,y:224,t:1527873291532};\\\", \\\"{x:1447,y:223,t:1527873291547};\\\", \\\"{x:1438,y:219,t:1527873291565};\\\", \\\"{x:1427,y:213,t:1527873291581};\\\", \\\"{x:1418,y:208,t:1527873291598};\\\", \\\"{x:1410,y:205,t:1527873291614};\\\", \\\"{x:1408,y:204,t:1527873291631};\\\", \\\"{x:1402,y:204,t:1527873291647};\\\", \\\"{x:1398,y:204,t:1527873291694};\\\", \\\"{x:1387,y:217,t:1527873291702};\\\", \\\"{x:1377,y:236,t:1527873291714};\\\", \\\"{x:1354,y:288,t:1527873291731};\\\", \\\"{x:1328,y:359,t:1527873291749};\\\", \\\"{x:1307,y:449,t:1527873291765};\\\", \\\"{x:1297,y:514,t:1527873291781};\\\", \\\"{x:1294,y:535,t:1527873291797};\\\", \\\"{x:1294,y:539,t:1527873291814};\\\", \\\"{x:1294,y:542,t:1527873291831};\\\", \\\"{x:1294,y:544,t:1527873291847};\\\", \\\"{x:1295,y:544,t:1527873291864};\\\", \\\"{x:1299,y:551,t:1527873291881};\\\", \\\"{x:1306,y:559,t:1527873291898};\\\", \\\"{x:1313,y:571,t:1527873291914};\\\", \\\"{x:1320,y:577,t:1527873291931};\\\", \\\"{x:1323,y:578,t:1527873291947};\\\", \\\"{x:1324,y:578,t:1527873291964};\\\", \\\"{x:1326,y:578,t:1527873291981};\\\", \\\"{x:1329,y:572,t:1527873291997};\\\", \\\"{x:1330,y:570,t:1527873292014};\\\", \\\"{x:1331,y:569,t:1527873292054};\\\", \\\"{x:1331,y:568,t:1527873292071};\\\", \\\"{x:1332,y:568,t:1527873292081};\\\", \\\"{x:1332,y:565,t:1527873292098};\\\", \\\"{x:1332,y:561,t:1527873292115};\\\", \\\"{x:1331,y:558,t:1527873292131};\\\", \\\"{x:1330,y:557,t:1527873292148};\\\", \\\"{x:1329,y:556,t:1527873292175};\\\", \\\"{x:1328,y:556,t:1527873292198};\\\", \\\"{x:1327,y:555,t:1527873292238};\\\", \\\"{x:1325,y:555,t:1527873292248};\\\", \\\"{x:1323,y:552,t:1527873292265};\\\", \\\"{x:1322,y:549,t:1527873292281};\\\", \\\"{x:1321,y:548,t:1527873292298};\\\", \\\"{x:1321,y:543,t:1527873292314};\\\", \\\"{x:1320,y:538,t:1527873292330};\\\", \\\"{x:1319,y:534,t:1527873292347};\\\", \\\"{x:1319,y:529,t:1527873292365};\\\", \\\"{x:1319,y:524,t:1527873292380};\\\", \\\"{x:1319,y:519,t:1527873292397};\\\", \\\"{x:1319,y:515,t:1527873292414};\\\", \\\"{x:1319,y:511,t:1527873292431};\\\", \\\"{x:1319,y:509,t:1527873292447};\\\", \\\"{x:1319,y:508,t:1527873292469};\\\", \\\"{x:1319,y:507,t:1527873292591};\\\", \\\"{x:1319,y:506,t:1527873292606};\\\", \\\"{x:1319,y:504,t:1527873292623};\\\", \\\"{x:1319,y:503,t:1527873292632};\\\", \\\"{x:1318,y:503,t:1527873292735};\\\", \\\"{x:1318,y:501,t:1527873292801};\\\", \\\"{x:1319,y:500,t:1527873292814};\\\", \\\"{x:1319,y:499,t:1527873292846};\\\", \\\"{x:1320,y:499,t:1527873298152};\\\", \\\"{x:1336,y:499,t:1527873298169};\\\", \\\"{x:1343,y:499,t:1527873298187};\\\", \\\"{x:1348,y:498,t:1527873298203};\\\", \\\"{x:1352,y:496,t:1527873298219};\\\", \\\"{x:1356,y:495,t:1527873298237};\\\", \\\"{x:1361,y:494,t:1527873298253};\\\", \\\"{x:1365,y:493,t:1527873298270};\\\", \\\"{x:1366,y:493,t:1527873298302};\\\", \\\"{x:1367,y:493,t:1527873298320};\\\", \\\"{x:1371,y:493,t:1527873298336};\\\", \\\"{x:1380,y:493,t:1527873298354};\\\", \\\"{x:1388,y:493,t:1527873298370};\\\", \\\"{x:1391,y:493,t:1527873298387};\\\", \\\"{x:1392,y:493,t:1527873298403};\\\", \\\"{x:1393,y:493,t:1527873298420};\\\", \\\"{x:1394,y:493,t:1527873298511};\\\", \\\"{x:1395,y:493,t:1527873298639};\\\", \\\"{x:1394,y:494,t:1527873298671};\\\", \\\"{x:1393,y:495,t:1527873298687};\\\", \\\"{x:1392,y:495,t:1527873298704};\\\", \\\"{x:1390,y:496,t:1527873298775};\\\", \\\"{x:1388,y:497,t:1527873298787};\\\", \\\"{x:1388,y:498,t:1527873298822};\\\", \\\"{x:1387,y:499,t:1527873298838};\\\", \\\"{x:1388,y:498,t:1527873299199};\\\", \\\"{x:1393,y:497,t:1527873299207};\\\", \\\"{x:1397,y:497,t:1527873299220};\\\", \\\"{x:1402,y:494,t:1527873299238};\\\", \\\"{x:1404,y:494,t:1527873299253};\\\", \\\"{x:1405,y:494,t:1527873299270};\\\", \\\"{x:1408,y:494,t:1527873299288};\\\", \\\"{x:1411,y:493,t:1527873299304};\\\", \\\"{x:1414,y:492,t:1527873299321};\\\", \\\"{x:1417,y:490,t:1527873299338};\\\", \\\"{x:1418,y:490,t:1527873299367};\\\", \\\"{x:1419,y:490,t:1527873299439};\\\", \\\"{x:1420,y:490,t:1527873299454};\\\", \\\"{x:1423,y:490,t:1527873299470};\\\", \\\"{x:1428,y:490,t:1527873299488};\\\", \\\"{x:1430,y:490,t:1527873299504};\\\", \\\"{x:1431,y:490,t:1527873299520};\\\", \\\"{x:1433,y:490,t:1527873299538};\\\", \\\"{x:1438,y:490,t:1527873299554};\\\", \\\"{x:1440,y:490,t:1527873299571};\\\", \\\"{x:1441,y:490,t:1527873299654};\\\", \\\"{x:1442,y:490,t:1527873299671};\\\", \\\"{x:1444,y:490,t:1527873299815};\\\", \\\"{x:1446,y:491,t:1527873299823};\\\", \\\"{x:1448,y:492,t:1527873299838};\\\", \\\"{x:1450,y:494,t:1527873299887};\\\", \\\"{x:1451,y:494,t:1527873300014};\\\", \\\"{x:1452,y:494,t:1527873300022};\\\", \\\"{x:1456,y:497,t:1527873300038};\\\", \\\"{x:1457,y:497,t:1527873300054};\\\", \\\"{x:1458,y:498,t:1527873300071};\\\", \\\"{x:1459,y:498,t:1527873300166};\\\", \\\"{x:1460,y:500,t:1527873300182};\\\", \\\"{x:1462,y:501,t:1527873300190};\\\", \\\"{x:1463,y:502,t:1527873300205};\\\", \\\"{x:1464,y:502,t:1527873300221};\\\", \\\"{x:1465,y:502,t:1527873300238};\\\", \\\"{x:1467,y:502,t:1527873300303};\\\", \\\"{x:1468,y:503,t:1527873300310};\\\", \\\"{x:1469,y:504,t:1527873300321};\\\", \\\"{x:1471,y:504,t:1527873300338};\\\", \\\"{x:1472,y:504,t:1527873300414};\\\", \\\"{x:1473,y:504,t:1527873300431};\\\", \\\"{x:1474,y:504,t:1527873300438};\\\", \\\"{x:1482,y:504,t:1527873300455};\\\", \\\"{x:1490,y:504,t:1527873300472};\\\", \\\"{x:1497,y:504,t:1527873300487};\\\", \\\"{x:1502,y:504,t:1527873300504};\\\", \\\"{x:1503,y:504,t:1527873300522};\\\", \\\"{x:1504,y:504,t:1527873300542};\\\", \\\"{x:1505,y:504,t:1527873300558};\\\", \\\"{x:1506,y:505,t:1527873300572};\\\", \\\"{x:1514,y:505,t:1527873300588};\\\", \\\"{x:1521,y:505,t:1527873300605};\\\", \\\"{x:1523,y:505,t:1527873300622};\\\", \\\"{x:1524,y:505,t:1527873300638};\\\", \\\"{x:1526,y:506,t:1527873300911};\\\", \\\"{x:1527,y:506,t:1527873300922};\\\", \\\"{x:1535,y:506,t:1527873300939};\\\", \\\"{x:1539,y:506,t:1527873300955};\\\", \\\"{x:1542,y:506,t:1527873300971};\\\", \\\"{x:1543,y:505,t:1527873300988};\\\", \\\"{x:1544,y:505,t:1527873301005};\\\", \\\"{x:1544,y:504,t:1527873301158};\\\", \\\"{x:1544,y:503,t:1527873301174};\\\", \\\"{x:1545,y:503,t:1527873301188};\\\", \\\"{x:1546,y:502,t:1527873301205};\\\", \\\"{x:1546,y:501,t:1527873301454};\\\", \\\"{x:1546,y:499,t:1527873302239};\\\", \\\"{x:1546,y:497,t:1527873302263};\\\", \\\"{x:1547,y:497,t:1527873302278};\\\", \\\"{x:1547,y:496,t:1527873302290};\\\", \\\"{x:1547,y:495,t:1527873302391};\\\", \\\"{x:1549,y:493,t:1527873302406};\\\", \\\"{x:1550,y:493,t:1527873303549};\\\", \\\"{x:1550,y:495,t:1527873303573};\\\", \\\"{x:1550,y:497,t:1527873303590};\\\", \\\"{x:1550,y:499,t:1527873303607};\\\", \\\"{x:1550,y:500,t:1527873303645};\\\", \\\"{x:1550,y:502,t:1527873303757};\\\", \\\"{x:1550,y:501,t:1527873304622};\\\", \\\"{x:1549,y:500,t:1527873304919};\\\", \\\"{x:1546,y:500,t:1527873305919};\\\", \\\"{x:1540,y:504,t:1527873305926};\\\", \\\"{x:1529,y:514,t:1527873305943};\\\", \\\"{x:1518,y:523,t:1527873305959};\\\", \\\"{x:1508,y:530,t:1527873305976};\\\", \\\"{x:1501,y:537,t:1527873305993};\\\", \\\"{x:1499,y:539,t:1527873306009};\\\", \\\"{x:1497,y:540,t:1527873306026};\\\", \\\"{x:1494,y:541,t:1527873306044};\\\", \\\"{x:1484,y:543,t:1527873306059};\\\", \\\"{x:1469,y:547,t:1527873306077};\\\", \\\"{x:1453,y:548,t:1527873306093};\\\", \\\"{x:1441,y:548,t:1527873306109};\\\", \\\"{x:1438,y:548,t:1527873306126};\\\", \\\"{x:1437,y:548,t:1527873306150};\\\", \\\"{x:1436,y:548,t:1527873306166};\\\", \\\"{x:1435,y:547,t:1527873306182};\\\", \\\"{x:1434,y:546,t:1527873306193};\\\", \\\"{x:1432,y:546,t:1527873306209};\\\", \\\"{x:1429,y:544,t:1527873306226};\\\", \\\"{x:1426,y:541,t:1527873306243};\\\", \\\"{x:1419,y:538,t:1527873306259};\\\", \\\"{x:1408,y:533,t:1527873306276};\\\", \\\"{x:1399,y:529,t:1527873306293};\\\", \\\"{x:1394,y:526,t:1527873306310};\\\", \\\"{x:1390,y:524,t:1527873306327};\\\", \\\"{x:1384,y:520,t:1527873306343};\\\", \\\"{x:1373,y:514,t:1527873306360};\\\", \\\"{x:1368,y:512,t:1527873306376};\\\", \\\"{x:1367,y:512,t:1527873306393};\\\", \\\"{x:1369,y:510,t:1527873306551};\\\", \\\"{x:1373,y:509,t:1527873306560};\\\", \\\"{x:1380,y:508,t:1527873306575};\\\", \\\"{x:1392,y:504,t:1527873306592};\\\", \\\"{x:1411,y:500,t:1527873306609};\\\", \\\"{x:1437,y:498,t:1527873306625};\\\", \\\"{x:1460,y:497,t:1527873306642};\\\", \\\"{x:1475,y:497,t:1527873306659};\\\", \\\"{x:1477,y:497,t:1527873306676};\\\", \\\"{x:1478,y:496,t:1527873306692};\\\", \\\"{x:1477,y:496,t:1527873306831};\\\", \\\"{x:1476,y:498,t:1527873306855};\\\", \\\"{x:1475,y:498,t:1527873306862};\\\", \\\"{x:1474,y:499,t:1527873306876};\\\", \\\"{x:1476,y:499,t:1527873307006};\\\", \\\"{x:1479,y:499,t:1527873307021};\\\", \\\"{x:1481,y:497,t:1527873307029};\\\", \\\"{x:1484,y:497,t:1527873307043};\\\", \\\"{x:1499,y:494,t:1527873307060};\\\", \\\"{x:1519,y:493,t:1527873307077};\\\", \\\"{x:1535,y:493,t:1527873307093};\\\", \\\"{x:1539,y:493,t:1527873307110};\\\", \\\"{x:1538,y:493,t:1527873307166};\\\", \\\"{x:1537,y:493,t:1527873307177};\\\", \\\"{x:1536,y:493,t:1527873307230};\\\", \\\"{x:1535,y:493,t:1527873307244};\\\", \\\"{x:1530,y:495,t:1527873307260};\\\", \\\"{x:1526,y:498,t:1527873307277};\\\", \\\"{x:1524,y:498,t:1527873307294};\\\", \\\"{x:1523,y:499,t:1527873307326};\\\", \\\"{x:1521,y:499,t:1527873307390};\\\", \\\"{x:1522,y:499,t:1527873307703};\\\", \\\"{x:1523,y:499,t:1527873307727};\\\", \\\"{x:1524,y:499,t:1527873307751};\\\", \\\"{x:1525,y:499,t:1527873307831};\\\", \\\"{x:1526,y:499,t:1527873307846};\\\", \\\"{x:1527,y:499,t:1527873307861};\\\", \\\"{x:1528,y:499,t:1527873307877};\\\", \\\"{x:1531,y:497,t:1527873307894};\\\", \\\"{x:1532,y:497,t:1527873307918};\\\", \\\"{x:1533,y:497,t:1527873307934};\\\", \\\"{x:1534,y:497,t:1527873307982};\\\", \\\"{x:1535,y:496,t:1527873307999};\\\", \\\"{x:1537,y:495,t:1527873308127};\\\", \\\"{x:1539,y:494,t:1527873308319};\\\", \\\"{x:1540,y:494,t:1527873308407};\\\", \\\"{x:1542,y:494,t:1527873308431};\\\", \\\"{x:1543,y:494,t:1527873308445};\\\", \\\"{x:1545,y:494,t:1527873308461};\\\", \\\"{x:1547,y:494,t:1527873308478};\\\", \\\"{x:1548,y:493,t:1527873308494};\\\", \\\"{x:1548,y:494,t:1527873309015};\\\", \\\"{x:1547,y:494,t:1527873309190};\\\", \\\"{x:1546,y:494,t:1527873309231};\\\", \\\"{x:1545,y:494,t:1527873309527};\\\", \\\"{x:1544,y:494,t:1527873309542};\\\", \\\"{x:1543,y:494,t:1527873310167};\\\", \\\"{x:1543,y:495,t:1527873312815};\\\", \\\"{x:1544,y:495,t:1527873312975};\\\", \\\"{x:1544,y:496,t:1527873312982};\\\", \\\"{x:1544,y:497,t:1527873313007};\\\", \\\"{x:1543,y:498,t:1527873314079};\\\", \\\"{x:1544,y:498,t:1527873315815};\\\", \\\"{x:1545,y:498,t:1527873315862};\\\", \\\"{x:1548,y:500,t:1527873315870};\\\", \\\"{x:1549,y:500,t:1527873315884};\\\", \\\"{x:1553,y:500,t:1527873315901};\\\", \\\"{x:1554,y:500,t:1527873315917};\\\", \\\"{x:1556,y:500,t:1527873315933};\\\", \\\"{x:1555,y:500,t:1527873316559};\\\", \\\"{x:1554,y:500,t:1527873316573};\\\", \\\"{x:1553,y:500,t:1527873316584};\\\", \\\"{x:1552,y:500,t:1527873316701};\\\", \\\"{x:1551,y:500,t:1527873316717};\\\", \\\"{x:1550,y:499,t:1527873320039};\\\", \\\"{x:1549,y:498,t:1527873320086};\\\", \\\"{x:1553,y:502,t:1527873351656};\\\", \\\"{x:1554,y:540,t:1527873351670};\\\", \\\"{x:1544,y:583,t:1527873351687};\\\", \\\"{x:1527,y:619,t:1527873351704};\\\", \\\"{x:1509,y:661,t:1527873351721};\\\", \\\"{x:1482,y:732,t:1527873351738};\\\", \\\"{x:1440,y:881,t:1527873351755};\\\", \\\"{x:1378,y:1027,t:1527873351772};\\\", \\\"{x:1334,y:1124,t:1527873351788};\\\", \\\"{x:1314,y:1193,t:1527873351805};\\\", \\\"{x:1304,y:1199,t:1527873351821};\\\", \\\"{x:1304,y:1198,t:1527873351895};\\\", \\\"{x:1304,y:1195,t:1527873351904};\\\", \\\"{x:1305,y:1193,t:1527873351922};\\\", \\\"{x:1305,y:1192,t:1527873351938};\\\", \\\"{x:1311,y:1183,t:1527873351954};\\\", \\\"{x:1323,y:1162,t:1527873351974};\\\", \\\"{x:1339,y:1124,t:1527873351988};\\\", \\\"{x:1349,y:1088,t:1527873352004};\\\", \\\"{x:1356,y:1068,t:1527873352020};\\\", \\\"{x:1361,y:1052,t:1527873352037};\\\", \\\"{x:1369,y:1029,t:1527873352055};\\\", \\\"{x:1372,y:1021,t:1527873352071};\\\", \\\"{x:1373,y:1017,t:1527873352087};\\\", \\\"{x:1374,y:1013,t:1527873352105};\\\", \\\"{x:1376,y:1010,t:1527873352121};\\\", \\\"{x:1380,y:1003,t:1527873352137};\\\", \\\"{x:1384,y:995,t:1527873352154};\\\", \\\"{x:1387,y:988,t:1527873352172};\\\", \\\"{x:1391,y:980,t:1527873352187};\\\", \\\"{x:1399,y:969,t:1527873352205};\\\", \\\"{x:1408,y:954,t:1527873352222};\\\", \\\"{x:1423,y:930,t:1527873352237};\\\", \\\"{x:1440,y:900,t:1527873352254};\\\", \\\"{x:1451,y:886,t:1527873352271};\\\", \\\"{x:1454,y:880,t:1527873352287};\\\", \\\"{x:1454,y:878,t:1527873352304};\\\", \\\"{x:1454,y:875,t:1527873352322};\\\", \\\"{x:1457,y:867,t:1527873352338};\\\", \\\"{x:1460,y:858,t:1527873352354};\\\", \\\"{x:1466,y:846,t:1527873352373};\\\", \\\"{x:1469,y:835,t:1527873352388};\\\", \\\"{x:1469,y:831,t:1527873352405};\\\", \\\"{x:1470,y:830,t:1527873352422};\\\", \\\"{x:1471,y:830,t:1527873352999};\\\", \\\"{x:1472,y:830,t:1527873353015};\\\", \\\"{x:1474,y:830,t:1527873353031};\\\", \\\"{x:1475,y:831,t:1527873353047};\\\", \\\"{x:1477,y:831,t:1527873353057};\\\", \\\"{x:1478,y:831,t:1527873353071};\\\", \\\"{x:1480,y:831,t:1527873353158};\\\", \\\"{x:1480,y:832,t:1527873353173};\\\", \\\"{x:1481,y:832,t:1527873353188};\\\", \\\"{x:1480,y:834,t:1527873354359};\\\", \\\"{x:1472,y:840,t:1527873354376};\\\", \\\"{x:1470,y:844,t:1527873354390};\\\", \\\"{x:1464,y:847,t:1527873354406};\\\", \\\"{x:1462,y:848,t:1527873354429};\\\", \\\"{x:1461,y:848,t:1527873354446};\\\", \\\"{x:1460,y:849,t:1527873354456};\\\", \\\"{x:1458,y:852,t:1527873354478};\\\", \\\"{x:1458,y:853,t:1527873354489};\\\", \\\"{x:1454,y:857,t:1527873354506};\\\", \\\"{x:1451,y:860,t:1527873354522};\\\", \\\"{x:1449,y:861,t:1527873354540};\\\", \\\"{x:1446,y:864,t:1527873354557};\\\", \\\"{x:1444,y:866,t:1527873354572};\\\", \\\"{x:1443,y:869,t:1527873354590};\\\", \\\"{x:1442,y:869,t:1527873354607};\\\", \\\"{x:1440,y:871,t:1527873354622};\\\", \\\"{x:1439,y:873,t:1527873354640};\\\", \\\"{x:1438,y:874,t:1527873354657};\\\", \\\"{x:1437,y:875,t:1527873354672};\\\", \\\"{x:1435,y:876,t:1527873354689};\\\", \\\"{x:1434,y:877,t:1527873354706};\\\", \\\"{x:1433,y:879,t:1527873354722};\\\", \\\"{x:1432,y:880,t:1527873354758};\\\", \\\"{x:1431,y:881,t:1527873354790};\\\", \\\"{x:1430,y:881,t:1527873354815};\\\", \\\"{x:1430,y:882,t:1527873354830};\\\", \\\"{x:1430,y:884,t:1527873354840};\\\", \\\"{x:1430,y:885,t:1527873354857};\\\", \\\"{x:1429,y:886,t:1527873354874};\\\", \\\"{x:1427,y:886,t:1527873354890};\\\", \\\"{x:1426,y:888,t:1527873354907};\\\", \\\"{x:1423,y:890,t:1527873354924};\\\", \\\"{x:1419,y:894,t:1527873354940};\\\", \\\"{x:1417,y:896,t:1527873354956};\\\", \\\"{x:1413,y:899,t:1527873354974};\\\", \\\"{x:1413,y:900,t:1527873354998};\\\", \\\"{x:1412,y:900,t:1527873355007};\\\", \\\"{x:1411,y:900,t:1527873355024};\\\", \\\"{x:1410,y:901,t:1527873355063};\\\", \\\"{x:1409,y:902,t:1527873355126};\\\", \\\"{x:1408,y:903,t:1527873355140};\\\", \\\"{x:1407,y:904,t:1527873355166};\\\", \\\"{x:1406,y:904,t:1527873355239};\\\", \\\"{x:1405,y:904,t:1527873355262};\\\", \\\"{x:1405,y:905,t:1527873355286};\\\", \\\"{x:1404,y:905,t:1527873355311};\\\", \\\"{x:1404,y:906,t:1527873355324};\\\", \\\"{x:1401,y:907,t:1527873355341};\\\", \\\"{x:1398,y:909,t:1527873355357};\\\", \\\"{x:1394,y:911,t:1527873355374};\\\", \\\"{x:1392,y:912,t:1527873355390};\\\", \\\"{x:1391,y:912,t:1527873355407};\\\", \\\"{x:1390,y:912,t:1527873355424};\\\", \\\"{x:1389,y:913,t:1527873355441};\\\", \\\"{x:1387,y:911,t:1527873355615};\\\", \\\"{x:1384,y:903,t:1527873355624};\\\", \\\"{x:1379,y:883,t:1527873355641};\\\", \\\"{x:1376,y:855,t:1527873355657};\\\", \\\"{x:1372,y:832,t:1527873355674};\\\", \\\"{x:1369,y:812,t:1527873355691};\\\", \\\"{x:1366,y:801,t:1527873355708};\\\", \\\"{x:1365,y:796,t:1527873355724};\\\", \\\"{x:1364,y:794,t:1527873355741};\\\", \\\"{x:1364,y:793,t:1527873355757};\\\", \\\"{x:1364,y:788,t:1527873355774};\\\", \\\"{x:1364,y:786,t:1527873355791};\\\", \\\"{x:1364,y:783,t:1527873355808};\\\", \\\"{x:1364,y:782,t:1527873355823};\\\", \\\"{x:1364,y:781,t:1527873355870};\\\", \\\"{x:1364,y:780,t:1527873355878};\\\", \\\"{x:1364,y:779,t:1527873355911};\\\", \\\"{x:1365,y:777,t:1527873355934};\\\", \\\"{x:1365,y:776,t:1527873355991};\\\", \\\"{x:1365,y:775,t:1527873356015};\\\", \\\"{x:1366,y:775,t:1527873356024};\\\", \\\"{x:1366,y:774,t:1527873356040};\\\", \\\"{x:1368,y:773,t:1527873356062};\\\", \\\"{x:1368,y:772,t:1527873356073};\\\", \\\"{x:1373,y:770,t:1527873356090};\\\", \\\"{x:1377,y:768,t:1527873356107};\\\", \\\"{x:1379,y:767,t:1527873356124};\\\", \\\"{x:1380,y:767,t:1527873356141};\\\", \\\"{x:1382,y:766,t:1527873356158};\\\", \\\"{x:1384,y:766,t:1527873357271};\\\", \\\"{x:1386,y:765,t:1527873357278};\\\", \\\"{x:1387,y:764,t:1527873357293};\\\", \\\"{x:1388,y:763,t:1527873357309};\\\", \\\"{x:1389,y:763,t:1527873357326};\\\", \\\"{x:1391,y:761,t:1527873357342};\\\", \\\"{x:1400,y:761,t:1527873357359};\\\", \\\"{x:1439,y:761,t:1527873357375};\\\", \\\"{x:1484,y:761,t:1527873357392};\\\", \\\"{x:1515,y:760,t:1527873357409};\\\", \\\"{x:1527,y:759,t:1527873357424};\\\", \\\"{x:1528,y:759,t:1527873357441};\\\", \\\"{x:1527,y:761,t:1527873357590};\\\", \\\"{x:1524,y:764,t:1527873357597};\\\", \\\"{x:1522,y:766,t:1527873357608};\\\", \\\"{x:1515,y:771,t:1527873357625};\\\", \\\"{x:1507,y:774,t:1527873357642};\\\", \\\"{x:1501,y:775,t:1527873357658};\\\", \\\"{x:1498,y:775,t:1527873357675};\\\", \\\"{x:1497,y:775,t:1527873357694};\\\", \\\"{x:1496,y:775,t:1527873357717};\\\", \\\"{x:1495,y:775,t:1527873357725};\\\", \\\"{x:1493,y:775,t:1527873357742};\\\", \\\"{x:1488,y:775,t:1527873357758};\\\", \\\"{x:1483,y:773,t:1527873357776};\\\", \\\"{x:1480,y:773,t:1527873357792};\\\", \\\"{x:1476,y:773,t:1527873357809};\\\", \\\"{x:1472,y:771,t:1527873357825};\\\", \\\"{x:1461,y:764,t:1527873357842};\\\", \\\"{x:1453,y:758,t:1527873357859};\\\", \\\"{x:1453,y:756,t:1527873357876};\\\", \\\"{x:1453,y:755,t:1527873357943};\\\", \\\"{x:1452,y:755,t:1527873357960};\\\", \\\"{x:1451,y:755,t:1527873357990};\\\", \\\"{x:1450,y:755,t:1527873358014};\\\", \\\"{x:1449,y:755,t:1527873358030};\\\", \\\"{x:1449,y:756,t:1527873358095};\\\", \\\"{x:1449,y:757,t:1527873358118};\\\", \\\"{x:1449,y:758,t:1527873358127};\\\", \\\"{x:1449,y:760,t:1527873358159};\\\", \\\"{x:1450,y:760,t:1527873358335};\\\", \\\"{x:1452,y:760,t:1527873358350};\\\", \\\"{x:1453,y:760,t:1527873358359};\\\", \\\"{x:1454,y:760,t:1527873358376};\\\", \\\"{x:1455,y:760,t:1527873358393};\\\", \\\"{x:1456,y:760,t:1527873358409};\\\", \\\"{x:1457,y:761,t:1527873358426};\\\", \\\"{x:1458,y:761,t:1527873358446};\\\", \\\"{x:1459,y:761,t:1527873358470};\\\", \\\"{x:1460,y:761,t:1527873358502};\\\", \\\"{x:1462,y:761,t:1527873358527};\\\", \\\"{x:1464,y:761,t:1527873358558};\\\", \\\"{x:1465,y:761,t:1527873358582};\\\", \\\"{x:1466,y:761,t:1527873358593};\\\", \\\"{x:1469,y:760,t:1527873358609};\\\", \\\"{x:1473,y:758,t:1527873358626};\\\", \\\"{x:1475,y:758,t:1527873358643};\\\", \\\"{x:1476,y:757,t:1527873358659};\\\", \\\"{x:1478,y:757,t:1527873358678};\\\", \\\"{x:1479,y:757,t:1527873358702};\\\", \\\"{x:1479,y:756,t:1527873358775};\\\", \\\"{x:1480,y:756,t:1527873358782};\\\", \\\"{x:1481,y:756,t:1527873358799};\\\", \\\"{x:1482,y:756,t:1527873359455};\\\", \\\"{x:1484,y:756,t:1527873359502};\\\", \\\"{x:1485,y:756,t:1527873359623};\\\", \\\"{x:1484,y:755,t:1527873364022};\\\", \\\"{x:1481,y:755,t:1527873364030};\\\", \\\"{x:1477,y:753,t:1527873364047};\\\", \\\"{x:1454,y:743,t:1527873364063};\\\", \\\"{x:1412,y:729,t:1527873364080};\\\", \\\"{x:1371,y:713,t:1527873364097};\\\", \\\"{x:1331,y:692,t:1527873364113};\\\", \\\"{x:1303,y:673,t:1527873364131};\\\", \\\"{x:1284,y:661,t:1527873364147};\\\", \\\"{x:1266,y:648,t:1527873364163};\\\", \\\"{x:1254,y:637,t:1527873364180};\\\", \\\"{x:1249,y:631,t:1527873364197};\\\", \\\"{x:1248,y:629,t:1527873364213};\\\", \\\"{x:1248,y:628,t:1527873364230};\\\", \\\"{x:1247,y:628,t:1527873364247};\\\", \\\"{x:1247,y:627,t:1527873364278};\\\", \\\"{x:1247,y:625,t:1527873364287};\\\", \\\"{x:1247,y:624,t:1527873364302};\\\", \\\"{x:1247,y:623,t:1527873364314};\\\", \\\"{x:1248,y:621,t:1527873364330};\\\", \\\"{x:1251,y:618,t:1527873364347};\\\", \\\"{x:1255,y:615,t:1527873364363};\\\", \\\"{x:1259,y:613,t:1527873364380};\\\", \\\"{x:1263,y:612,t:1527873364397};\\\", \\\"{x:1266,y:611,t:1527873364414};\\\", \\\"{x:1272,y:610,t:1527873364430};\\\", \\\"{x:1276,y:610,t:1527873364447};\\\", \\\"{x:1277,y:610,t:1527873364463};\\\", \\\"{x:1278,y:610,t:1527873364480};\\\", \\\"{x:1280,y:610,t:1527873364498};\\\", \\\"{x:1282,y:610,t:1527873364515};\\\", \\\"{x:1283,y:610,t:1527873364531};\\\", \\\"{x:1285,y:610,t:1527873364719};\\\", \\\"{x:1285,y:611,t:1527873364951};\\\", \\\"{x:1285,y:612,t:1527873365023};\\\", \\\"{x:1286,y:612,t:1527873365031};\\\", \\\"{x:1286,y:614,t:1527873365047};\\\", \\\"{x:1286,y:617,t:1527873365065};\\\", \\\"{x:1286,y:618,t:1527873365086};\\\", \\\"{x:1286,y:619,t:1527873365103};\\\", \\\"{x:1286,y:620,t:1527873365342};\\\", \\\"{x:1286,y:621,t:1527873365351};\\\", \\\"{x:1287,y:621,t:1527873365398};\\\", \\\"{x:1287,y:622,t:1527873365414};\\\", \\\"{x:1288,y:624,t:1527873365432};\\\", \\\"{x:1289,y:625,t:1527873365448};\\\", \\\"{x:1289,y:626,t:1527873365465};\\\", \\\"{x:1290,y:626,t:1527873365590};\\\", \\\"{x:1291,y:626,t:1527873365758};\\\", \\\"{x:1292,y:627,t:1527873365782};\\\", \\\"{x:1293,y:627,t:1527873365814};\\\", \\\"{x:1298,y:627,t:1527873365831};\\\", \\\"{x:1300,y:627,t:1527873365849};\\\", \\\"{x:1301,y:627,t:1527873365865};\\\", \\\"{x:1302,y:627,t:1527873365982};\\\", \\\"{x:1303,y:627,t:1527873365998};\\\", \\\"{x:1304,y:627,t:1527873366014};\\\", \\\"{x:1306,y:627,t:1527873366046};\\\", \\\"{x:1308,y:627,t:1527873366055};\\\", \\\"{x:1310,y:627,t:1527873366065};\\\", \\\"{x:1311,y:627,t:1527873366081};\\\", \\\"{x:1312,y:629,t:1527873366099};\\\", \\\"{x:1313,y:629,t:1527873366118};\\\", \\\"{x:1314,y:629,t:1527873366132};\\\", \\\"{x:1316,y:629,t:1527873366148};\\\", \\\"{x:1317,y:629,t:1527873366165};\\\", \\\"{x:1318,y:629,t:1527873366190};\\\", \\\"{x:1319,y:629,t:1527873366198};\\\", \\\"{x:1320,y:629,t:1527873366215};\\\", \\\"{x:1324,y:629,t:1527873366232};\\\", \\\"{x:1330,y:629,t:1527873366248};\\\", \\\"{x:1333,y:629,t:1527873366266};\\\", \\\"{x:1334,y:629,t:1527873366281};\\\", \\\"{x:1335,y:629,t:1527873366310};\\\", \\\"{x:1336,y:629,t:1527873366326};\\\", \\\"{x:1337,y:629,t:1527873366423};\\\", \\\"{x:1338,y:629,t:1527873366433};\\\", \\\"{x:1340,y:629,t:1527873366495};\\\", \\\"{x:1341,y:629,t:1527873366503};\\\", \\\"{x:1345,y:628,t:1527873366515};\\\", \\\"{x:1351,y:628,t:1527873366533};\\\", \\\"{x:1352,y:628,t:1527873366548};\\\", \\\"{x:1353,y:628,t:1527873366566};\\\", \\\"{x:1354,y:626,t:1527873366582};\\\", \\\"{x:1355,y:626,t:1527873367399};\\\", \\\"{x:1363,y:627,t:1527873367806};\\\", \\\"{x:1374,y:628,t:1527873367817};\\\", \\\"{x:1390,y:631,t:1527873367833};\\\", \\\"{x:1400,y:631,t:1527873367849};\\\", \\\"{x:1412,y:633,t:1527873367866};\\\", \\\"{x:1415,y:633,t:1527873367883};\\\", \\\"{x:1416,y:634,t:1527873367900};\\\", \\\"{x:1417,y:635,t:1527873367975};\\\", \\\"{x:1418,y:635,t:1527873368806};\\\", \\\"{x:1419,y:635,t:1527873368838};\\\", \\\"{x:1420,y:635,t:1527873369295};\\\", \\\"{x:1421,y:635,t:1527873369310};\\\", \\\"{x:1422,y:635,t:1527873369326};\\\", \\\"{x:1422,y:634,t:1527873369335};\\\", \\\"{x:1423,y:634,t:1527873369366};\\\", \\\"{x:1424,y:634,t:1527873369647};\\\", \\\"{x:1425,y:633,t:1527873369678};\\\", \\\"{x:1425,y:632,t:1527873369686};\\\", \\\"{x:1426,y:631,t:1527873369701};\\\", \\\"{x:1427,y:631,t:1527873369718};\\\", \\\"{x:1428,y:631,t:1527873369735};\\\", \\\"{x:1429,y:631,t:1527873369751};\\\", \\\"{x:1430,y:630,t:1527873369768};\\\", \\\"{x:1431,y:630,t:1527873369790};\\\", \\\"{x:1432,y:630,t:1527873369800};\\\", \\\"{x:1434,y:628,t:1527873369818};\\\", \\\"{x:1436,y:628,t:1527873369847};\\\", \\\"{x:1437,y:627,t:1527873369879};\\\", \\\"{x:1438,y:627,t:1527873369895};\\\", \\\"{x:1439,y:626,t:1527873369911};\\\", \\\"{x:1440,y:625,t:1527873369935};\\\", \\\"{x:1441,y:625,t:1527873369952};\\\", \\\"{x:1442,y:625,t:1527873369968};\\\", \\\"{x:1444,y:625,t:1527873369984};\\\", \\\"{x:1446,y:625,t:1527873370191};\\\", \\\"{x:1448,y:626,t:1527873370487};\\\", \\\"{x:1448,y:628,t:1527873370501};\\\", \\\"{x:1450,y:630,t:1527873370519};\\\", \\\"{x:1451,y:631,t:1527873370535};\\\", \\\"{x:1451,y:632,t:1527873370607};\\\", \\\"{x:1451,y:633,t:1527873370639};\\\", \\\"{x:1451,y:635,t:1527873375167};\\\", \\\"{x:1451,y:661,t:1527873375174};\\\", \\\"{x:1451,y:708,t:1527873375189};\\\", \\\"{x:1451,y:805,t:1527873375205};\\\", \\\"{x:1451,y:917,t:1527873375222};\\\", \\\"{x:1454,y:922,t:1527873375238};\\\", \\\"{x:1462,y:939,t:1527873375255};\\\", \\\"{x:1466,y:944,t:1527873375271};\\\", \\\"{x:1469,y:946,t:1527873375289};\\\", \\\"{x:1470,y:946,t:1527873375367};\\\", \\\"{x:1470,y:945,t:1527873375391};\\\", \\\"{x:1476,y:942,t:1527873375404};\\\", \\\"{x:1475,y:920,t:1527873375422};\\\", \\\"{x:1472,y:898,t:1527873375438};\\\", \\\"{x:1472,y:880,t:1527873375455};\\\", \\\"{x:1472,y:875,t:1527873375471};\\\", \\\"{x:1473,y:871,t:1527873375489};\\\", \\\"{x:1473,y:870,t:1527873375542};\\\", \\\"{x:1473,y:869,t:1527873375630};\\\", \\\"{x:1473,y:868,t:1527873375663};\\\", \\\"{x:1473,y:867,t:1527873375672};\\\", \\\"{x:1473,y:864,t:1527873375689};\\\", \\\"{x:1473,y:861,t:1527873375706};\\\", \\\"{x:1473,y:859,t:1527873375722};\\\", \\\"{x:1473,y:857,t:1527873375739};\\\", \\\"{x:1475,y:854,t:1527873375756};\\\", \\\"{x:1476,y:852,t:1527873375773};\\\", \\\"{x:1476,y:851,t:1527873375789};\\\", \\\"{x:1476,y:850,t:1527873375806};\\\", \\\"{x:1476,y:849,t:1527873375919};\\\", \\\"{x:1476,y:848,t:1527873375926};\\\", \\\"{x:1477,y:846,t:1527873375942};\\\", \\\"{x:1478,y:845,t:1527873375956};\\\", \\\"{x:1483,y:840,t:1527873375975};\\\", \\\"{x:1486,y:840,t:1527873375989};\\\", \\\"{x:1499,y:835,t:1527873376006};\\\", \\\"{x:1508,y:834,t:1527873376022};\\\", \\\"{x:1511,y:833,t:1527873376038};\\\", \\\"{x:1512,y:833,t:1527873376056};\\\", \\\"{x:1513,y:833,t:1527873376073};\\\", \\\"{x:1514,y:832,t:1527873376383};\\\", \\\"{x:1516,y:832,t:1527873376398};\\\", \\\"{x:1518,y:832,t:1527873376406};\\\", \\\"{x:1523,y:829,t:1527873376422};\\\", \\\"{x:1527,y:829,t:1527873376439};\\\", \\\"{x:1529,y:828,t:1527873376456};\\\", \\\"{x:1530,y:828,t:1527873376511};\\\", \\\"{x:1532,y:828,t:1527873376523};\\\", \\\"{x:1534,y:828,t:1527873376540};\\\", \\\"{x:1535,y:828,t:1527873376556};\\\", \\\"{x:1536,y:828,t:1527873376573};\\\", \\\"{x:1537,y:828,t:1527873376766};\\\", \\\"{x:1538,y:828,t:1527873376774};\\\", \\\"{x:1542,y:828,t:1527873376790};\\\", \\\"{x:1548,y:826,t:1527873376806};\\\", \\\"{x:1551,y:826,t:1527873376823};\\\", \\\"{x:1552,y:825,t:1527873376846};\\\", \\\"{x:1553,y:825,t:1527873376926};\\\", \\\"{x:1554,y:825,t:1527873376940};\\\", \\\"{x:1554,y:826,t:1527873377039};\\\", \\\"{x:1554,y:827,t:1527873377070};\\\", \\\"{x:1554,y:828,t:1527873377087};\\\", \\\"{x:1554,y:829,t:1527873377127};\\\", \\\"{x:1554,y:830,t:1527873377223};\\\", \\\"{x:1554,y:831,t:1527873377279};\\\", \\\"{x:1553,y:831,t:1527873377358};\\\", \\\"{x:1552,y:831,t:1527873377431};\\\", \\\"{x:1551,y:831,t:1527873377615};\\\", \\\"{x:1550,y:831,t:1527873378599};\\\", \\\"{x:1549,y:831,t:1527873378608};\\\", \\\"{x:1548,y:831,t:1527873378624};\\\", \\\"{x:1548,y:830,t:1527873378943};\\\", \\\"{x:1548,y:829,t:1527873379006};\\\", \\\"{x:1547,y:830,t:1527873379134};\\\", \\\"{x:1547,y:831,t:1527873379150};\\\", \\\"{x:1546,y:831,t:1527873379295};\\\", \\\"{x:1545,y:831,t:1527873379350};\\\", \\\"{x:1544,y:831,t:1527873379358};\\\", \\\"{x:1543,y:831,t:1527873379382};\\\", \\\"{x:1541,y:831,t:1527873379392};\\\", \\\"{x:1539,y:831,t:1527873379408};\\\", \\\"{x:1532,y:831,t:1527873379426};\\\", \\\"{x:1525,y:829,t:1527873379442};\\\", \\\"{x:1520,y:827,t:1527873379458};\\\", \\\"{x:1508,y:819,t:1527873379475};\\\", \\\"{x:1497,y:815,t:1527873379492};\\\", \\\"{x:1492,y:815,t:1527873379509};\\\", \\\"{x:1491,y:815,t:1527873379525};\\\", \\\"{x:1490,y:815,t:1527873379759};\\\", \\\"{x:1487,y:815,t:1527873379871};\\\", \\\"{x:1485,y:815,t:1527873379878};\\\", \\\"{x:1482,y:819,t:1527873379892};\\\", \\\"{x:1479,y:822,t:1527873379908};\\\", \\\"{x:1478,y:823,t:1527873379925};\\\", \\\"{x:1477,y:824,t:1527873379942};\\\", \\\"{x:1476,y:825,t:1527873379983};\\\", \\\"{x:1475,y:827,t:1527873380031};\\\", \\\"{x:1472,y:829,t:1527873380042};\\\", \\\"{x:1470,y:829,t:1527873380059};\\\", \\\"{x:1469,y:829,t:1527873380075};\\\", \\\"{x:1469,y:830,t:1527873380092};\\\", \\\"{x:1467,y:831,t:1527873380111};\\\", \\\"{x:1466,y:832,t:1527873380125};\\\", \\\"{x:1463,y:834,t:1527873380142};\\\", \\\"{x:1459,y:837,t:1527873380158};\\\", \\\"{x:1456,y:839,t:1527873380175};\\\", \\\"{x:1451,y:841,t:1527873380193};\\\", \\\"{x:1447,y:844,t:1527873380210};\\\", \\\"{x:1443,y:848,t:1527873380226};\\\", \\\"{x:1437,y:852,t:1527873380242};\\\", \\\"{x:1428,y:859,t:1527873380260};\\\", \\\"{x:1417,y:866,t:1527873380275};\\\", \\\"{x:1401,y:876,t:1527873380292};\\\", \\\"{x:1388,y:883,t:1527873380310};\\\", \\\"{x:1376,y:888,t:1527873380326};\\\", \\\"{x:1368,y:894,t:1527873380342};\\\", \\\"{x:1366,y:897,t:1527873380359};\\\", \\\"{x:1364,y:899,t:1527873380375};\\\", \\\"{x:1363,y:900,t:1527873380392};\\\", \\\"{x:1362,y:901,t:1527873380423};\\\", \\\"{x:1361,y:901,t:1527873381543};\\\", \\\"{x:1361,y:900,t:1527873381560};\\\", \\\"{x:1361,y:898,t:1527873381576};\\\", \\\"{x:1361,y:897,t:1527873381593};\\\", \\\"{x:1361,y:896,t:1527873382797};\\\", \\\"{x:1360,y:896,t:1527873382810};\\\", \\\"{x:1347,y:898,t:1527873382827};\\\", \\\"{x:1340,y:899,t:1527873382844};\\\", \\\"{x:1324,y:900,t:1527873382861};\\\", \\\"{x:1305,y:901,t:1527873382877};\\\", \\\"{x:1269,y:901,t:1527873382894};\\\", \\\"{x:1252,y:901,t:1527873382911};\\\", \\\"{x:1213,y:895,t:1527873382928};\\\", \\\"{x:1162,y:880,t:1527873382944};\\\", \\\"{x:1112,y:866,t:1527873382961};\\\", \\\"{x:1079,y:856,t:1527873382977};\\\", \\\"{x:1047,y:844,t:1527873382995};\\\", \\\"{x:1024,y:832,t:1527873383011};\\\", \\\"{x:1003,y:821,t:1527873383027};\\\", \\\"{x:989,y:814,t:1527873383044};\\\", \\\"{x:983,y:812,t:1527873383062};\\\", \\\"{x:975,y:808,t:1527873383077};\\\", \\\"{x:951,y:793,t:1527873383094};\\\", \\\"{x:937,y:785,t:1527873383111};\\\", \\\"{x:927,y:781,t:1527873383127};\\\", \\\"{x:922,y:779,t:1527873383144};\\\", \\\"{x:917,y:778,t:1527873383162};\\\", \\\"{x:912,y:777,t:1527873383177};\\\", \\\"{x:907,y:775,t:1527873383194};\\\", \\\"{x:903,y:775,t:1527873383211};\\\", \\\"{x:898,y:774,t:1527873383227};\\\", \\\"{x:891,y:773,t:1527873383244};\\\", \\\"{x:880,y:770,t:1527873383261};\\\", \\\"{x:871,y:769,t:1527873383277};\\\", \\\"{x:858,y:766,t:1527873383293};\\\", \\\"{x:846,y:765,t:1527873383311};\\\", \\\"{x:832,y:765,t:1527873383328};\\\", \\\"{x:815,y:765,t:1527873383344};\\\", \\\"{x:806,y:765,t:1527873383361};\\\", \\\"{x:803,y:765,t:1527873383377};\\\", \\\"{x:801,y:765,t:1527873383394};\\\", \\\"{x:799,y:765,t:1527873383411};\\\", \\\"{x:798,y:765,t:1527873383428};\\\", \\\"{x:797,y:765,t:1527873383446};\\\", \\\"{x:796,y:765,t:1527873383462};\\\", \\\"{x:795,y:765,t:1527873383478};\\\", \\\"{x:794,y:765,t:1527873383494};\\\", \\\"{x:793,y:765,t:1527873383518};\\\", \\\"{x:792,y:765,t:1527873383528};\\\", \\\"{x:790,y:765,t:1527873383544};\\\", \\\"{x:784,y:765,t:1527873383561};\\\", \\\"{x:775,y:765,t:1527873383578};\\\", \\\"{x:762,y:765,t:1527873383594};\\\", \\\"{x:756,y:765,t:1527873383611};\\\", \\\"{x:752,y:765,t:1527873383628};\\\", \\\"{x:751,y:765,t:1527873383645};\\\", \\\"{x:750,y:765,t:1527873383661};\\\", \\\"{x:749,y:765,t:1527873383694};\\\", \\\"{x:749,y:764,t:1527873383806};\\\", \\\"{x:749,y:763,t:1527873383821};\\\", \\\"{x:746,y:760,t:1527873383829};\\\", \\\"{x:742,y:756,t:1527873383844};\\\", \\\"{x:737,y:751,t:1527873383860};\\\", \\\"{x:736,y:749,t:1527873383878};\\\", \\\"{x:735,y:749,t:1527873383894};\\\", \\\"{x:733,y:748,t:1527873383910};\\\", \\\"{x:732,y:747,t:1527873383928};\\\", \\\"{x:731,y:746,t:1527873383945};\\\", \\\"{x:729,y:746,t:1527873383973};\\\", \\\"{x:728,y:746,t:1527873384014};\\\", \\\"{x:728,y:745,t:1527873384029};\\\", \\\"{x:727,y:745,t:1527873384078};\\\", \\\"{x:725,y:745,t:1527873384095};\\\", \\\"{x:721,y:743,t:1527873384111};\\\", \\\"{x:716,y:742,t:1527873384128};\\\", \\\"{x:710,y:738,t:1527873384145};\\\", \\\"{x:703,y:736,t:1527873384161};\\\", \\\"{x:700,y:734,t:1527873384178};\\\", \\\"{x:695,y:733,t:1527873384196};\\\", \\\"{x:690,y:731,t:1527873384211};\\\", \\\"{x:682,y:729,t:1527873384228};\\\", \\\"{x:673,y:726,t:1527873384245};\\\", \\\"{x:665,y:721,t:1527873384261};\\\", \\\"{x:660,y:720,t:1527873384278};\\\", \\\"{x:657,y:718,t:1527873384296};\\\", \\\"{x:654,y:717,t:1527873384312};\\\", \\\"{x:652,y:715,t:1527873384328};\\\", \\\"{x:650,y:715,t:1527873384344};\\\", \\\"{x:649,y:715,t:1527873384362};\\\", \\\"{x:647,y:714,t:1527873384377};\\\", \\\"{x:646,y:713,t:1527873384395};\\\", \\\"{x:644,y:709,t:1527873384411};\\\", \\\"{x:640,y:696,t:1527873384427};\\\", \\\"{x:639,y:688,t:1527873384445};\\\", \\\"{x:639,y:676,t:1527873384462};\\\", \\\"{x:639,y:667,t:1527873384477};\\\", \\\"{x:639,y:662,t:1527873384495};\\\", \\\"{x:639,y:660,t:1527873384511};\\\", \\\"{x:639,y:658,t:1527873384526};\\\", \\\"{x:639,y:657,t:1527873384541};\\\", \\\"{x:639,y:655,t:1527873384556};\\\", \\\"{x:639,y:653,t:1527873384573};\\\", \\\"{x:638,y:649,t:1527873384590};\\\", \\\"{x:631,y:641,t:1527873384607};\\\", \\\"{x:620,y:632,t:1527873384624};\\\", \\\"{x:606,y:625,t:1527873384640};\\\", \\\"{x:582,y:615,t:1527873384663};\\\", \\\"{x:579,y:614,t:1527873384679};\\\", \\\"{x:578,y:613,t:1527873384709};\\\", \\\"{x:577,y:612,t:1527873384717};\\\", \\\"{x:576,y:611,t:1527873384730};\\\", \\\"{x:572,y:607,t:1527873384746};\\\", \\\"{x:565,y:604,t:1527873384763};\\\", \\\"{x:561,y:603,t:1527873384779};\\\", \\\"{x:560,y:602,t:1527873384796};\\\", \\\"{x:558,y:601,t:1527873384813};\\\", \\\"{x:554,y:601,t:1527873384830};\\\", \\\"{x:533,y:601,t:1527873384847};\\\", \\\"{x:466,y:611,t:1527873384863};\\\", \\\"{x:377,y:623,t:1527873384879};\\\", \\\"{x:315,y:624,t:1527873384897};\\\", \\\"{x:291,y:627,t:1527873384914};\\\", \\\"{x:286,y:627,t:1527873384931};\\\", \\\"{x:286,y:626,t:1527873385054};\\\", \\\"{x:286,y:622,t:1527873385063};\\\", \\\"{x:292,y:611,t:1527873385080};\\\", \\\"{x:299,y:603,t:1527873385097};\\\", \\\"{x:303,y:599,t:1527873385114};\\\", \\\"{x:304,y:596,t:1527873385131};\\\", \\\"{x:305,y:595,t:1527873385148};\\\", \\\"{x:311,y:595,t:1527873385164};\\\", \\\"{x:318,y:593,t:1527873385181};\\\", \\\"{x:335,y:593,t:1527873385197};\\\", \\\"{x:344,y:593,t:1527873385214};\\\", \\\"{x:345,y:592,t:1527873385231};\\\", \\\"{x:347,y:593,t:1527873385277};\\\", \\\"{x:350,y:597,t:1527873385286};\\\", \\\"{x:350,y:601,t:1527873385297};\\\", \\\"{x:354,y:607,t:1527873385314};\\\", \\\"{x:362,y:614,t:1527873385331};\\\", \\\"{x:363,y:615,t:1527873385348};\\\", \\\"{x:365,y:615,t:1527873385364};\\\", \\\"{x:367,y:615,t:1527873385455};\\\", \\\"{x:368,y:615,t:1527873385464};\\\", \\\"{x:370,y:615,t:1527873385870};\\\", \\\"{x:374,y:616,t:1527873385882};\\\", \\\"{x:386,y:625,t:1527873385898};\\\", \\\"{x:396,y:627,t:1527873385915};\\\", \\\"{x:402,y:627,t:1527873385932};\\\", \\\"{x:400,y:627,t:1527873386085};\\\", \\\"{x:399,y:626,t:1527873386099};\\\", \\\"{x:398,y:625,t:1527873386115};\\\", \\\"{x:397,y:625,t:1527873386149};\\\", \\\"{x:396,y:625,t:1527873386222};\\\", \\\"{x:395,y:625,t:1527873386254};\\\", \\\"{x:395,y:624,t:1527873386265};\\\", \\\"{x:393,y:624,t:1527873386282};\\\", \\\"{x:392,y:622,t:1527873386298};\\\", \\\"{x:390,y:620,t:1527873386314};\\\", \\\"{x:390,y:619,t:1527873386332};\\\", \\\"{x:389,y:618,t:1527873386397};\\\", \\\"{x:389,y:618,t:1527873386508};\\\", \\\"{x:390,y:618,t:1527873386517};\\\", \\\"{x:391,y:618,t:1527873386533};\\\", \\\"{x:392,y:618,t:1527873386549};\\\", \\\"{x:395,y:621,t:1527873386566};\\\", \\\"{x:403,y:638,t:1527873386582};\\\", \\\"{x:423,y:663,t:1527873386598};\\\", \\\"{x:440,y:682,t:1527873386615};\\\", \\\"{x:456,y:697,t:1527873386632};\\\", \\\"{x:470,y:708,t:1527873386649};\\\", \\\"{x:475,y:712,t:1527873386664};\\\", \\\"{x:476,y:715,t:1527873386683};\\\", \\\"{x:478,y:718,t:1527873386699};\\\", \\\"{x:479,y:720,t:1527873386715};\\\", \\\"{x:479,y:721,t:1527873386732};\\\", \\\"{x:479,y:723,t:1527873386748};\\\", \\\"{x:480,y:723,t:1527873386765};\\\", \\\"{x:480,y:724,t:1527873386781};\\\", \\\"{x:481,y:726,t:1527873386798};\\\", \\\"{x:482,y:730,t:1527873386815};\\\", \\\"{x:482,y:733,t:1527873386831};\\\", \\\"{x:482,y:735,t:1527873386848};\\\", \\\"{x:482,y:736,t:1527873386886};\\\", \\\"{x:483,y:736,t:1527873386899};\\\", \\\"{x:484,y:737,t:1527873386917};\\\", \\\"{x:485,y:737,t:1527873387114};\\\", \\\"{x:484,y:738,t:1527873387598};\\\", \\\"{x:483,y:739,t:1527873387686};\\\", \\\"{x:482,y:739,t:1527873387702};\\\", \\\"{x:481,y:739,t:1527873387716};\\\", \\\"{x:479,y:739,t:1527873387806};\\\", \\\"{x:478,y:739,t:1527873387855};\\\", \\\"{x:476,y:739,t:1527873387902};\\\" ] }, { \\\"rt\\\": 8078, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 348600, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"9BS72\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:475,y:738,t:1527873389390};\\\", \\\"{x:474,y:738,t:1527873389838};\\\", \\\"{x:474,y:737,t:1527873390070};\\\", \\\"{x:484,y:734,t:1527873390089};\\\", \\\"{x:506,y:731,t:1527873390105};\\\", \\\"{x:546,y:730,t:1527873390122};\\\", \\\"{x:619,y:730,t:1527873390140};\\\", \\\"{x:683,y:730,t:1527873390155};\\\", \\\"{x:732,y:727,t:1527873390168};\\\", \\\"{x:762,y:724,t:1527873390184};\\\", \\\"{x:780,y:723,t:1527873390201};\\\", \\\"{x:787,y:723,t:1527873390218};\\\", \\\"{x:787,y:722,t:1527873390237};\\\", \\\"{x:788,y:722,t:1527873390294};\\\", \\\"{x:789,y:722,t:1527873390301};\\\", \\\"{x:791,y:722,t:1527873390318};\\\", \\\"{x:793,y:722,t:1527873390335};\\\", \\\"{x:796,y:722,t:1527873390351};\\\", \\\"{x:801,y:722,t:1527873390368};\\\", \\\"{x:816,y:720,t:1527873390385};\\\", \\\"{x:835,y:718,t:1527873390401};\\\", \\\"{x:851,y:714,t:1527873390418};\\\", \\\"{x:860,y:713,t:1527873390435};\\\", \\\"{x:874,y:709,t:1527873390451};\\\", \\\"{x:886,y:708,t:1527873390468};\\\", \\\"{x:926,y:704,t:1527873390485};\\\", \\\"{x:955,y:701,t:1527873390501};\\\", \\\"{x:980,y:697,t:1527873390518};\\\", \\\"{x:997,y:692,t:1527873390535};\\\", \\\"{x:1008,y:690,t:1527873390551};\\\", \\\"{x:1015,y:687,t:1527873390568};\\\", \\\"{x:1024,y:684,t:1527873390585};\\\", \\\"{x:1032,y:680,t:1527873390602};\\\", \\\"{x:1041,y:674,t:1527873390618};\\\", \\\"{x:1045,y:671,t:1527873390636};\\\", \\\"{x:1052,y:664,t:1527873390652};\\\", \\\"{x:1062,y:657,t:1527873390669};\\\", \\\"{x:1078,y:648,t:1527873390685};\\\", \\\"{x:1085,y:642,t:1527873390702};\\\", \\\"{x:1088,y:637,t:1527873390718};\\\", \\\"{x:1090,y:633,t:1527873390735};\\\", \\\"{x:1091,y:630,t:1527873390751};\\\", \\\"{x:1094,y:625,t:1527873390768};\\\", \\\"{x:1099,y:618,t:1527873390786};\\\", \\\"{x:1104,y:612,t:1527873390803};\\\", \\\"{x:1105,y:610,t:1527873390818};\\\", \\\"{x:1106,y:608,t:1527873390836};\\\", \\\"{x:1106,y:606,t:1527873390853};\\\", \\\"{x:1107,y:603,t:1527873390869};\\\", \\\"{x:1113,y:596,t:1527873390885};\\\", \\\"{x:1119,y:589,t:1527873390901};\\\", \\\"{x:1123,y:586,t:1527873390919};\\\", \\\"{x:1125,y:585,t:1527873390935};\\\", \\\"{x:1130,y:581,t:1527873390953};\\\", \\\"{x:1139,y:578,t:1527873390969};\\\", \\\"{x:1147,y:574,t:1527873390985};\\\", \\\"{x:1152,y:572,t:1527873391003};\\\", \\\"{x:1147,y:572,t:1527873391111};\\\", \\\"{x:1138,y:573,t:1527873391119};\\\", \\\"{x:1102,y:583,t:1527873391136};\\\", \\\"{x:1056,y:592,t:1527873391152};\\\", \\\"{x:1008,y:599,t:1527873391168};\\\", \\\"{x:963,y:609,t:1527873391185};\\\", \\\"{x:926,y:615,t:1527873391203};\\\", \\\"{x:912,y:619,t:1527873391218};\\\", \\\"{x:904,y:619,t:1527873391235};\\\", \\\"{x:889,y:619,t:1527873391252};\\\", \\\"{x:868,y:619,t:1527873391269};\\\", \\\"{x:863,y:619,t:1527873391286};\\\", \\\"{x:856,y:619,t:1527873391302};\\\", \\\"{x:843,y:620,t:1527873391319};\\\", \\\"{x:829,y:620,t:1527873391335};\\\", \\\"{x:813,y:620,t:1527873391353};\\\", \\\"{x:780,y:625,t:1527873391369};\\\", \\\"{x:752,y:630,t:1527873391385};\\\", \\\"{x:731,y:631,t:1527873391402};\\\", \\\"{x:718,y:631,t:1527873391420};\\\", \\\"{x:712,y:631,t:1527873391436};\\\", \\\"{x:709,y:631,t:1527873391451};\\\", \\\"{x:707,y:631,t:1527873391477};\\\", \\\"{x:706,y:631,t:1527873391509};\\\", \\\"{x:704,y:631,t:1527873391519};\\\", \\\"{x:698,y:631,t:1527873391536};\\\", \\\"{x:686,y:631,t:1527873391551};\\\", \\\"{x:674,y:630,t:1527873391569};\\\", \\\"{x:660,y:628,t:1527873391586};\\\", \\\"{x:637,y:625,t:1527873391602};\\\", \\\"{x:600,y:618,t:1527873391619};\\\", \\\"{x:549,y:610,t:1527873391636};\\\", \\\"{x:494,y:605,t:1527873391653};\\\", \\\"{x:457,y:599,t:1527873391670};\\\", \\\"{x:447,y:595,t:1527873391687};\\\", \\\"{x:446,y:594,t:1527873391814};\\\", \\\"{x:446,y:593,t:1527873391823};\\\", \\\"{x:446,y:591,t:1527873391836};\\\", \\\"{x:448,y:588,t:1527873391853};\\\", \\\"{x:450,y:587,t:1527873391869};\\\", \\\"{x:452,y:585,t:1527873391886};\\\", \\\"{x:456,y:583,t:1527873391903};\\\", \\\"{x:463,y:579,t:1527873391920};\\\", \\\"{x:473,y:574,t:1527873391936};\\\", \\\"{x:491,y:567,t:1527873391953};\\\", \\\"{x:533,y:550,t:1527873391971};\\\", \\\"{x:585,y:538,t:1527873391987};\\\", \\\"{x:617,y:531,t:1527873392004};\\\", \\\"{x:628,y:527,t:1527873392020};\\\", \\\"{x:630,y:527,t:1527873392036};\\\", \\\"{x:630,y:526,t:1527873392110};\\\", \\\"{x:630,y:524,t:1527873392151};\\\", \\\"{x:628,y:520,t:1527873392170};\\\", \\\"{x:627,y:517,t:1527873392186};\\\", \\\"{x:627,y:516,t:1527873392203};\\\", \\\"{x:627,y:515,t:1527873392219};\\\", \\\"{x:626,y:514,t:1527873392261};\\\", \\\"{x:625,y:513,t:1527873392269};\\\", \\\"{x:623,y:511,t:1527873392287};\\\", \\\"{x:622,y:510,t:1527873392309};\\\", \\\"{x:622,y:509,t:1527873392325};\\\", \\\"{x:621,y:507,t:1527873392342};\\\", \\\"{x:620,y:506,t:1527873392366};\\\", \\\"{x:628,y:506,t:1527873392871};\\\", \\\"{x:692,y:506,t:1527873392889};\\\", \\\"{x:774,y:498,t:1527873392904};\\\", \\\"{x:869,y:494,t:1527873392920};\\\", \\\"{x:959,y:489,t:1527873392937};\\\", \\\"{x:984,y:488,t:1527873392954};\\\", \\\"{x:986,y:488,t:1527873392970};\\\", \\\"{x:982,y:488,t:1527873392987};\\\", \\\"{x:976,y:488,t:1527873393003};\\\", \\\"{x:973,y:488,t:1527873393020};\\\", \\\"{x:970,y:487,t:1527873393037};\\\", \\\"{x:966,y:487,t:1527873393053};\\\", \\\"{x:958,y:487,t:1527873393070};\\\", \\\"{x:948,y:490,t:1527873393088};\\\", \\\"{x:942,y:492,t:1527873393103};\\\", \\\"{x:938,y:494,t:1527873393120};\\\", \\\"{x:934,y:495,t:1527873393137};\\\", \\\"{x:929,y:499,t:1527873393154};\\\", \\\"{x:914,y:506,t:1527873393171};\\\", \\\"{x:893,y:514,t:1527873393187};\\\", \\\"{x:870,y:523,t:1527873393205};\\\", \\\"{x:851,y:529,t:1527873393221};\\\", \\\"{x:832,y:532,t:1527873393238};\\\", \\\"{x:826,y:532,t:1527873393254};\\\", \\\"{x:823,y:532,t:1527873393270};\\\", \\\"{x:823,y:533,t:1527873393621};\\\", \\\"{x:821,y:536,t:1527873393637};\\\", \\\"{x:818,y:539,t:1527873393653};\\\", \\\"{x:812,y:548,t:1527873393670};\\\", \\\"{x:801,y:563,t:1527873393690};\\\", \\\"{x:781,y:585,t:1527873393704};\\\", \\\"{x:752,y:610,t:1527873393721};\\\", \\\"{x:716,y:633,t:1527873393738};\\\", \\\"{x:681,y:654,t:1527873393754};\\\", \\\"{x:656,y:675,t:1527873393771};\\\", \\\"{x:639,y:691,t:1527873393788};\\\", \\\"{x:634,y:699,t:1527873393804};\\\", \\\"{x:630,y:706,t:1527873393821};\\\", \\\"{x:622,y:713,t:1527873393837};\\\", \\\"{x:606,y:726,t:1527873393854};\\\", \\\"{x:590,y:735,t:1527873393872};\\\", \\\"{x:582,y:740,t:1527873393887};\\\", \\\"{x:581,y:741,t:1527873393904};\\\", \\\"{x:580,y:741,t:1527873393921};\\\", \\\"{x:579,y:741,t:1527873393937};\\\", \\\"{x:579,y:740,t:1527873393965};\\\", \\\"{x:579,y:738,t:1527873393973};\\\", \\\"{x:579,y:734,t:1527873393987};\\\", \\\"{x:583,y:722,t:1527873394004};\\\", \\\"{x:591,y:704,t:1527873394022};\\\", \\\"{x:609,y:688,t:1527873394038};\\\", \\\"{x:636,y:668,t:1527873394055};\\\", \\\"{x:681,y:648,t:1527873394072};\\\", \\\"{x:712,y:638,t:1527873394088};\\\", \\\"{x:728,y:633,t:1527873394105};\\\", \\\"{x:739,y:628,t:1527873394123};\\\", \\\"{x:743,y:626,t:1527873394138};\\\", \\\"{x:747,y:625,t:1527873394155};\\\", \\\"{x:749,y:625,t:1527873394171};\\\", \\\"{x:750,y:624,t:1527873394188};\\\", \\\"{x:760,y:621,t:1527873394205};\\\", \\\"{x:766,y:617,t:1527873394221};\\\", \\\"{x:771,y:612,t:1527873394238};\\\", \\\"{x:775,y:607,t:1527873394256};\\\", \\\"{x:777,y:602,t:1527873394271};\\\", \\\"{x:780,y:593,t:1527873394290};\\\", \\\"{x:786,y:583,t:1527873394306};\\\", \\\"{x:793,y:573,t:1527873394322};\\\", \\\"{x:796,y:567,t:1527873394339};\\\", \\\"{x:797,y:565,t:1527873394355};\\\", \\\"{x:797,y:563,t:1527873394371};\\\", \\\"{x:798,y:563,t:1527873394388};\\\", \\\"{x:798,y:562,t:1527873394415};\\\", \\\"{x:799,y:562,t:1527873394422};\\\", \\\"{x:803,y:559,t:1527873394438};\\\", \\\"{x:808,y:557,t:1527873394455};\\\", \\\"{x:810,y:556,t:1527873394471};\\\", \\\"{x:810,y:555,t:1527873394489};\\\", \\\"{x:811,y:554,t:1527873394549};\\\", \\\"{x:813,y:554,t:1527873394557};\\\", \\\"{x:815,y:553,t:1527873394571};\\\", \\\"{x:821,y:551,t:1527873394588};\\\", \\\"{x:822,y:549,t:1527873394605};\\\", \\\"{x:822,y:548,t:1527873394735};\\\", \\\"{x:819,y:548,t:1527873395030};\\\", \\\"{x:815,y:552,t:1527873395038};\\\", \\\"{x:808,y:557,t:1527873395057};\\\", \\\"{x:808,y:558,t:1527873395142};\\\", \\\"{x:811,y:558,t:1527873395155};\\\", \\\"{x:822,y:555,t:1527873395173};\\\", \\\"{x:825,y:553,t:1527873395189};\\\", \\\"{x:827,y:552,t:1527873395422};\\\", \\\"{x:828,y:548,t:1527873395441};\\\", \\\"{x:829,y:545,t:1527873395455};\\\", \\\"{x:830,y:542,t:1527873395472};\\\", \\\"{x:832,y:540,t:1527873395489};\\\", \\\"{x:831,y:541,t:1527873395709};\\\", \\\"{x:827,y:544,t:1527873395722};\\\", \\\"{x:821,y:547,t:1527873395740};\\\", \\\"{x:814,y:554,t:1527873395755};\\\", \\\"{x:799,y:565,t:1527873395773};\\\", \\\"{x:775,y:581,t:1527873395789};\\\", \\\"{x:769,y:587,t:1527873395807};\\\", \\\"{x:768,y:589,t:1527873395823};\\\", \\\"{x:768,y:591,t:1527873395861};\\\", \\\"{x:765,y:593,t:1527873395873};\\\", \\\"{x:753,y:602,t:1527873395890};\\\", \\\"{x:737,y:612,t:1527873395906};\\\", \\\"{x:726,y:619,t:1527873395922};\\\", \\\"{x:717,y:627,t:1527873395941};\\\", \\\"{x:709,y:637,t:1527873395957};\\\", \\\"{x:702,y:644,t:1527873395973};\\\", \\\"{x:683,y:651,t:1527873395989};\\\", \\\"{x:660,y:658,t:1527873396006};\\\", \\\"{x:632,y:667,t:1527873396023};\\\", \\\"{x:593,y:678,t:1527873396039};\\\", \\\"{x:559,y:689,t:1527873396057};\\\", \\\"{x:541,y:694,t:1527873396073};\\\", \\\"{x:536,y:696,t:1527873396090};\\\", \\\"{x:534,y:697,t:1527873396107};\\\", \\\"{x:533,y:697,t:1527873396150};\\\", \\\"{x:531,y:698,t:1527873396157};\\\", \\\"{x:526,y:703,t:1527873396174};\\\", \\\"{x:519,y:713,t:1527873396190};\\\", \\\"{x:517,y:719,t:1527873396206};\\\", \\\"{x:517,y:720,t:1527873396225};\\\", \\\"{x:517,y:724,t:1527873396239};\\\", \\\"{x:518,y:735,t:1527873396256};\\\", \\\"{x:519,y:745,t:1527873396272};\\\", \\\"{x:519,y:750,t:1527873396289};\\\", \\\"{x:519,y:752,t:1527873396306};\\\", \\\"{x:517,y:752,t:1527873396365};\\\", \\\"{x:517,y:749,t:1527873396373};\\\", \\\"{x:516,y:747,t:1527873396389};\\\" ] }, { \\\"rt\\\": 15421, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 365342, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"9BS72\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 3, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:516,y:746,t:1527873402326};\\\", \\\"{x:536,y:741,t:1527873402341};\\\", \\\"{x:580,y:733,t:1527873402357};\\\", \\\"{x:663,y:722,t:1527873402375};\\\", \\\"{x:749,y:712,t:1527873402392};\\\", \\\"{x:803,y:703,t:1527873402410};\\\", \\\"{x:858,y:688,t:1527873402427};\\\", \\\"{x:898,y:676,t:1527873402443};\\\", \\\"{x:924,y:664,t:1527873402460};\\\", \\\"{x:936,y:659,t:1527873402477};\\\", \\\"{x:943,y:655,t:1527873402493};\\\", \\\"{x:948,y:651,t:1527873402509};\\\", \\\"{x:962,y:644,t:1527873402527};\\\", \\\"{x:983,y:636,t:1527873402543};\\\", \\\"{x:1015,y:626,t:1527873402560};\\\", \\\"{x:1049,y:615,t:1527873402577};\\\", \\\"{x:1100,y:604,t:1527873402593};\\\", \\\"{x:1144,y:596,t:1527873402609};\\\", \\\"{x:1170,y:591,t:1527873402627};\\\", \\\"{x:1194,y:588,t:1527873402643};\\\", \\\"{x:1233,y:581,t:1527873402660};\\\", \\\"{x:1273,y:575,t:1527873402677};\\\", \\\"{x:1302,y:569,t:1527873402693};\\\", \\\"{x:1324,y:566,t:1527873402709};\\\", \\\"{x:1325,y:566,t:1527873402727};\\\", \\\"{x:1326,y:565,t:1527873403189};\\\", \\\"{x:1325,y:565,t:1527873403198};\\\", \\\"{x:1321,y:565,t:1527873403210};\\\", \\\"{x:1313,y:566,t:1527873403227};\\\", \\\"{x:1301,y:574,t:1527873403244};\\\", \\\"{x:1284,y:582,t:1527873403260};\\\", \\\"{x:1274,y:588,t:1527873403277};\\\", \\\"{x:1271,y:591,t:1527873403294};\\\", \\\"{x:1270,y:592,t:1527873403335};\\\", \\\"{x:1270,y:593,t:1527873403344};\\\", \\\"{x:1270,y:596,t:1527873403361};\\\", \\\"{x:1270,y:600,t:1527873403378};\\\", \\\"{x:1270,y:607,t:1527873403395};\\\", \\\"{x:1270,y:612,t:1527873403410};\\\", \\\"{x:1269,y:617,t:1527873403427};\\\", \\\"{x:1266,y:622,t:1527873403444};\\\", \\\"{x:1264,y:627,t:1527873403461};\\\", \\\"{x:1261,y:633,t:1527873403477};\\\", \\\"{x:1260,y:636,t:1527873403494};\\\", \\\"{x:1260,y:638,t:1527873403510};\\\", \\\"{x:1258,y:638,t:1527873403542};\\\", \\\"{x:1258,y:639,t:1527873403574};\\\", \\\"{x:1256,y:639,t:1527873403821};\\\", \\\"{x:1255,y:640,t:1527873404087};\\\", \\\"{x:1254,y:640,t:1527873404110};\\\", \\\"{x:1253,y:640,t:1527873404118};\\\", \\\"{x:1252,y:640,t:1527873404134};\\\", \\\"{x:1251,y:640,t:1527873404144};\\\", \\\"{x:1249,y:640,t:1527873404454};\\\", \\\"{x:1248,y:640,t:1527873404494};\\\", \\\"{x:1247,y:640,t:1527873404574};\\\", \\\"{x:1246,y:640,t:1527873404598};\\\", \\\"{x:1241,y:641,t:1527873408315};\\\", \\\"{x:1230,y:647,t:1527873408323};\\\", \\\"{x:1210,y:654,t:1527873408334};\\\", \\\"{x:1179,y:662,t:1527873408351};\\\", \\\"{x:1155,y:669,t:1527873408367};\\\", \\\"{x:1141,y:673,t:1527873408384};\\\", \\\"{x:1134,y:676,t:1527873408401};\\\", \\\"{x:1130,y:677,t:1527873408417};\\\", \\\"{x:1125,y:679,t:1527873408434};\\\", \\\"{x:1121,y:680,t:1527873408450};\\\", \\\"{x:1114,y:680,t:1527873408467};\\\", \\\"{x:1101,y:681,t:1527873408484};\\\", \\\"{x:1086,y:681,t:1527873408501};\\\", \\\"{x:1064,y:681,t:1527873408517};\\\", \\\"{x:1042,y:679,t:1527873408533};\\\", \\\"{x:1019,y:677,t:1527873408551};\\\", \\\"{x:992,y:672,t:1527873408567};\\\", \\\"{x:966,y:669,t:1527873408584};\\\", \\\"{x:944,y:664,t:1527873408601};\\\", \\\"{x:924,y:656,t:1527873408616};\\\", \\\"{x:905,y:651,t:1527873408634};\\\", \\\"{x:897,y:650,t:1527873408650};\\\", \\\"{x:891,y:646,t:1527873408666};\\\", \\\"{x:884,y:642,t:1527873408683};\\\", \\\"{x:881,y:640,t:1527873408700};\\\", \\\"{x:879,y:638,t:1527873408716};\\\", \\\"{x:877,y:635,t:1527873408733};\\\", \\\"{x:874,y:633,t:1527873408750};\\\", \\\"{x:870,y:630,t:1527873408767};\\\", \\\"{x:867,y:628,t:1527873408783};\\\", \\\"{x:861,y:624,t:1527873408804};\\\", \\\"{x:851,y:618,t:1527873408821};\\\", \\\"{x:839,y:612,t:1527873408838};\\\", \\\"{x:828,y:604,t:1527873408854};\\\", \\\"{x:825,y:598,t:1527873408870};\\\", \\\"{x:822,y:586,t:1527873408888};\\\", \\\"{x:821,y:571,t:1527873408904};\\\", \\\"{x:820,y:559,t:1527873408920};\\\", \\\"{x:817,y:549,t:1527873408938};\\\", \\\"{x:821,y:543,t:1527873408954};\\\", \\\"{x:828,y:535,t:1527873408970};\\\", \\\"{x:834,y:528,t:1527873408987};\\\", \\\"{x:835,y:526,t:1527873409004};\\\", \\\"{x:835,y:525,t:1527873409020};\\\", \\\"{x:835,y:524,t:1527873409038};\\\", \\\"{x:835,y:523,t:1527873409054};\\\", \\\"{x:835,y:522,t:1527873409098};\\\", \\\"{x:835,y:521,t:1527873409105};\\\", \\\"{x:835,y:520,t:1527873409121};\\\", \\\"{x:835,y:519,t:1527873409161};\\\", \\\"{x:835,y:517,t:1527873409171};\\\", \\\"{x:835,y:513,t:1527873409187};\\\", \\\"{x:835,y:509,t:1527873409204};\\\", \\\"{x:835,y:506,t:1527873409221};\\\", \\\"{x:835,y:505,t:1527873409237};\\\", \\\"{x:835,y:504,t:1527873409254};\\\", \\\"{x:835,y:503,t:1527873409297};\\\", \\\"{x:835,y:502,t:1527873409313};\\\", \\\"{x:836,y:501,t:1527873409434};\\\", \\\"{x:836,y:501,t:1527873409485};\\\", \\\"{x:828,y:501,t:1527873409617};\\\", \\\"{x:812,y:502,t:1527873409626};\\\", \\\"{x:795,y:504,t:1527873409639};\\\", \\\"{x:749,y:511,t:1527873409654};\\\", \\\"{x:716,y:516,t:1527873409672};\\\", \\\"{x:703,y:519,t:1527873409687};\\\", \\\"{x:698,y:519,t:1527873409704};\\\", \\\"{x:690,y:520,t:1527873409721};\\\", \\\"{x:681,y:520,t:1527873409738};\\\", \\\"{x:670,y:522,t:1527873409754};\\\", \\\"{x:653,y:525,t:1527873409772};\\\", \\\"{x:629,y:527,t:1527873409789};\\\", \\\"{x:602,y:532,t:1527873409804};\\\", \\\"{x:574,y:537,t:1527873409821};\\\", \\\"{x:550,y:539,t:1527873409838};\\\", \\\"{x:520,y:544,t:1527873409854};\\\", \\\"{x:482,y:549,t:1527873409872};\\\", \\\"{x:436,y:556,t:1527873409888};\\\", \\\"{x:407,y:559,t:1527873409904};\\\", \\\"{x:379,y:563,t:1527873409922};\\\", \\\"{x:366,y:566,t:1527873409939};\\\", \\\"{x:357,y:569,t:1527873409955};\\\", \\\"{x:353,y:571,t:1527873409972};\\\", \\\"{x:348,y:573,t:1527873409988};\\\", \\\"{x:339,y:575,t:1527873410004};\\\", \\\"{x:325,y:577,t:1527873410022};\\\", \\\"{x:310,y:577,t:1527873410039};\\\", \\\"{x:292,y:577,t:1527873410056};\\\", \\\"{x:276,y:577,t:1527873410071};\\\", \\\"{x:265,y:577,t:1527873410090};\\\", \\\"{x:239,y:582,t:1527873410105};\\\", \\\"{x:200,y:588,t:1527873410121};\\\", \\\"{x:136,y:588,t:1527873410138};\\\", \\\"{x:81,y:588,t:1527873410155};\\\", \\\"{x:59,y:588,t:1527873410171};\\\", \\\"{x:58,y:588,t:1527873410188};\\\", \\\"{x:57,y:588,t:1527873410205};\\\", \\\"{x:56,y:587,t:1527873410221};\\\", \\\"{x:56,y:580,t:1527873410239};\\\", \\\"{x:63,y:572,t:1527873410255};\\\", \\\"{x:64,y:567,t:1527873410271};\\\", \\\"{x:64,y:563,t:1527873410288};\\\", \\\"{x:64,y:561,t:1527873410306};\\\", \\\"{x:65,y:560,t:1527873410322};\\\", \\\"{x:68,y:557,t:1527873410339};\\\", \\\"{x:75,y:551,t:1527873410356};\\\", \\\"{x:87,y:541,t:1527873410371};\\\", \\\"{x:93,y:537,t:1527873410388};\\\", \\\"{x:96,y:535,t:1527873410405};\\\", \\\"{x:101,y:533,t:1527873410423};\\\", \\\"{x:107,y:531,t:1527873410438};\\\", \\\"{x:112,y:530,t:1527873410456};\\\", \\\"{x:119,y:529,t:1527873410473};\\\", \\\"{x:122,y:529,t:1527873410489};\\\", \\\"{x:126,y:529,t:1527873410555};\\\", \\\"{x:127,y:530,t:1527873410562};\\\", \\\"{x:129,y:531,t:1527873410573};\\\", \\\"{x:134,y:534,t:1527873410588};\\\", \\\"{x:135,y:534,t:1527873410610};\\\", \\\"{x:136,y:534,t:1527873410650};\\\", \\\"{x:137,y:535,t:1527873410682};\\\", \\\"{x:138,y:536,t:1527873410881};\\\", \\\"{x:138,y:536,t:1527873410882};\\\", \\\"{x:139,y:536,t:1527873410889};\\\", \\\"{x:140,y:536,t:1527873410906};\\\", \\\"{x:141,y:537,t:1527873411027};\\\", \\\"{x:142,y:537,t:1527873411083};\\\", \\\"{x:143,y:537,t:1527873411099};\\\", \\\"{x:144,y:537,t:1527873411106};\\\", \\\"{x:145,y:537,t:1527873411123};\\\", \\\"{x:146,y:537,t:1527873411140};\\\", \\\"{x:147,y:537,t:1527873411331};\\\", \\\"{x:148,y:537,t:1527873411346};\\\", \\\"{x:148,y:537,t:1527873411444};\\\", \\\"{x:149,y:537,t:1527873411459};\\\", \\\"{x:150,y:538,t:1527873412129};\\\", \\\"{x:151,y:538,t:1527873412193};\\\", \\\"{x:152,y:539,t:1527873412206};\\\", \\\"{x:154,y:540,t:1527873412223};\\\", \\\"{x:155,y:541,t:1527873412241};\\\", \\\"{x:157,y:542,t:1527873412256};\\\", \\\"{x:158,y:543,t:1527873412273};\\\", \\\"{x:159,y:544,t:1527873412298};\\\", \\\"{x:163,y:547,t:1527873412307};\\\", \\\"{x:175,y:554,t:1527873412325};\\\", \\\"{x:190,y:563,t:1527873412341};\\\", \\\"{x:203,y:568,t:1527873412356};\\\", \\\"{x:219,y:573,t:1527873412373};\\\", \\\"{x:239,y:580,t:1527873412391};\\\", \\\"{x:262,y:590,t:1527873412406};\\\", \\\"{x:285,y:600,t:1527873412424};\\\", \\\"{x:305,y:609,t:1527873412441};\\\", \\\"{x:315,y:616,t:1527873412456};\\\", \\\"{x:326,y:621,t:1527873412473};\\\", \\\"{x:336,y:627,t:1527873412491};\\\", \\\"{x:351,y:635,t:1527873412507};\\\", \\\"{x:367,y:646,t:1527873412524};\\\", \\\"{x:381,y:657,t:1527873412541};\\\", \\\"{x:386,y:661,t:1527873412556};\\\", \\\"{x:390,y:666,t:1527873412574};\\\", \\\"{x:392,y:671,t:1527873412592};\\\", \\\"{x:395,y:675,t:1527873412607};\\\", \\\"{x:398,y:680,t:1527873412623};\\\", \\\"{x:402,y:687,t:1527873412641};\\\", \\\"{x:407,y:703,t:1527873412657};\\\", \\\"{x:415,y:714,t:1527873412674};\\\", \\\"{x:423,y:721,t:1527873412691};\\\", \\\"{x:426,y:724,t:1527873412708};\\\", \\\"{x:428,y:724,t:1527873412738};\\\", \\\"{x:428,y:725,t:1527873412746};\\\", \\\"{x:429,y:726,t:1527873412757};\\\", \\\"{x:431,y:727,t:1527873412778};\\\", \\\"{x:432,y:727,t:1527873412791};\\\", \\\"{x:440,y:731,t:1527873412808};\\\", \\\"{x:446,y:733,t:1527873412824};\\\", \\\"{x:448,y:734,t:1527873412841};\\\", \\\"{x:450,y:734,t:1527873412899};\\\", \\\"{x:451,y:734,t:1527873412922};\\\", \\\"{x:454,y:734,t:1527873413003};\\\", \\\"{x:462,y:734,t:1527873413010};\\\", \\\"{x:471,y:734,t:1527873413025};\\\", \\\"{x:495,y:741,t:1527873413042};\\\", \\\"{x:504,y:743,t:1527873413059};\\\", \\\"{x:507,y:744,t:1527873413075};\\\", \\\"{x:508,y:744,t:1527873413713};\\\", \\\"{x:509,y:744,t:1527873414314};\\\" ] }, { \\\"rt\\\": 43445, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 410120, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"9BS72\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"N\\\", \\\"D\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:509,y:743,t:1527873416899};\\\", \\\"{x:511,y:740,t:1527873416910};\\\", \\\"{x:517,y:738,t:1527873416916};\\\", \\\"{x:520,y:737,t:1527873416932};\\\", \\\"{x:524,y:734,t:1527873416949};\\\", \\\"{x:532,y:731,t:1527873416967};\\\", \\\"{x:548,y:725,t:1527873416983};\\\", \\\"{x:590,y:717,t:1527873417000};\\\", \\\"{x:639,y:706,t:1527873417016};\\\", \\\"{x:734,y:688,t:1527873417033};\\\", \\\"{x:766,y:684,t:1527873417042};\\\", \\\"{x:819,y:677,t:1527873417058};\\\", \\\"{x:848,y:668,t:1527873417076};\\\", \\\"{x:886,y:664,t:1527873417092};\\\", \\\"{x:951,y:650,t:1527873417108};\\\", \\\"{x:1064,y:626,t:1527873417126};\\\", \\\"{x:1185,y:594,t:1527873417141};\\\", \\\"{x:1272,y:578,t:1527873417158};\\\", \\\"{x:1323,y:568,t:1527873417175};\\\", \\\"{x:1348,y:563,t:1527873417192};\\\", \\\"{x:1369,y:558,t:1527873417209};\\\", \\\"{x:1379,y:554,t:1527873417225};\\\", \\\"{x:1380,y:554,t:1527873417242};\\\", \\\"{x:1381,y:553,t:1527873417259};\\\", \\\"{x:1382,y:552,t:1527873417290};\\\", \\\"{x:1385,y:552,t:1527873417297};\\\", \\\"{x:1390,y:551,t:1527873417309};\\\", \\\"{x:1403,y:546,t:1527873417326};\\\", \\\"{x:1415,y:542,t:1527873417343};\\\", \\\"{x:1418,y:540,t:1527873417359};\\\", \\\"{x:1416,y:540,t:1527873417554};\\\", \\\"{x:1415,y:541,t:1527873417619};\\\", \\\"{x:1413,y:541,t:1527873417811};\\\", \\\"{x:1409,y:543,t:1527873417827};\\\", \\\"{x:1404,y:544,t:1527873417842};\\\", \\\"{x:1404,y:545,t:1527873417892};\\\", \\\"{x:1394,y:548,t:1527873417910};\\\", \\\"{x:1385,y:550,t:1527873417926};\\\", \\\"{x:1382,y:550,t:1527873417942};\\\", \\\"{x:1380,y:552,t:1527873417959};\\\", \\\"{x:1379,y:554,t:1527873417977};\\\", \\\"{x:1379,y:556,t:1527873417992};\\\", \\\"{x:1379,y:555,t:1527873419627};\\\", \\\"{x:1379,y:554,t:1527873419643};\\\", \\\"{x:1379,y:553,t:1527873419659};\\\", \\\"{x:1379,y:552,t:1527873419676};\\\", \\\"{x:1379,y:551,t:1527873419730};\\\", \\\"{x:1379,y:550,t:1527873419811};\\\", \\\"{x:1379,y:549,t:1527873419850};\\\", \\\"{x:1378,y:549,t:1527873420338};\\\", \\\"{x:1378,y:548,t:1527873420475};\\\", \\\"{x:1378,y:547,t:1527873420493};\\\", \\\"{x:1378,y:544,t:1527873420509};\\\", \\\"{x:1380,y:542,t:1527873420525};\\\", \\\"{x:1381,y:540,t:1527873420542};\\\", \\\"{x:1381,y:539,t:1527873420559};\\\", \\\"{x:1383,y:537,t:1527873420892};\\\", \\\"{x:1383,y:536,t:1527873420910};\\\", \\\"{x:1385,y:534,t:1527873420931};\\\", \\\"{x:1385,y:533,t:1527873420943};\\\", \\\"{x:1388,y:531,t:1527873420960};\\\", \\\"{x:1389,y:530,t:1527873420976};\\\", \\\"{x:1390,y:530,t:1527873421010};\\\", \\\"{x:1391,y:529,t:1527873421034};\\\", \\\"{x:1391,y:528,t:1527873421171};\\\", \\\"{x:1392,y:528,t:1527873421250};\\\", \\\"{x:1393,y:527,t:1527873421274};\\\", \\\"{x:1396,y:526,t:1527873421293};\\\", \\\"{x:1397,y:525,t:1527873421310};\\\", \\\"{x:1398,y:524,t:1527873421325};\\\", \\\"{x:1400,y:523,t:1527873421343};\\\", \\\"{x:1401,y:521,t:1527873421360};\\\", \\\"{x:1402,y:520,t:1527873421475};\\\", \\\"{x:1402,y:521,t:1527873421586};\\\", \\\"{x:1400,y:522,t:1527873421602};\\\", \\\"{x:1398,y:523,t:1527873421610};\\\", \\\"{x:1397,y:524,t:1527873421625};\\\", \\\"{x:1388,y:525,t:1527873421642};\\\", \\\"{x:1371,y:525,t:1527873421659};\\\", \\\"{x:1350,y:525,t:1527873421675};\\\", \\\"{x:1335,y:525,t:1527873421692};\\\", \\\"{x:1325,y:525,t:1527873421709};\\\", \\\"{x:1318,y:525,t:1527873421725};\\\", \\\"{x:1316,y:525,t:1527873421742};\\\", \\\"{x:1315,y:525,t:1527873421834};\\\", \\\"{x:1314,y:525,t:1527873421883};\\\", \\\"{x:1312,y:525,t:1527873421931};\\\", \\\"{x:1311,y:525,t:1527873422761};\\\", \\\"{x:1311,y:523,t:1527873422777};\\\", \\\"{x:1311,y:522,t:1527873422792};\\\", \\\"{x:1311,y:517,t:1527873422809};\\\", \\\"{x:1311,y:516,t:1527873422825};\\\", \\\"{x:1311,y:515,t:1527873422898};\\\", \\\"{x:1311,y:514,t:1527873422971};\\\", \\\"{x:1311,y:512,t:1527873422979};\\\", \\\"{x:1311,y:511,t:1527873422995};\\\", \\\"{x:1311,y:509,t:1527873423066};\\\", \\\"{x:1311,y:508,t:1527873423076};\\\", \\\"{x:1312,y:506,t:1527873423139};\\\", \\\"{x:1312,y:505,t:1527873423155};\\\", \\\"{x:1313,y:503,t:1527873423170};\\\", \\\"{x:1313,y:502,t:1527873423177};\\\", \\\"{x:1313,y:501,t:1527873423193};\\\", \\\"{x:1313,y:500,t:1527873423209};\\\", \\\"{x:1314,y:499,t:1527873423225};\\\", \\\"{x:1315,y:496,t:1527873423242};\\\", \\\"{x:1315,y:495,t:1527873423259};\\\", \\\"{x:1316,y:495,t:1527873423276};\\\", \\\"{x:1317,y:495,t:1527873427034};\\\", \\\"{x:1319,y:494,t:1527873427042};\\\", \\\"{x:1324,y:493,t:1527873427058};\\\", \\\"{x:1327,y:492,t:1527873427075};\\\", \\\"{x:1329,y:491,t:1527873427091};\\\", \\\"{x:1331,y:490,t:1527873427108};\\\", \\\"{x:1332,y:489,t:1527873427126};\\\", \\\"{x:1334,y:489,t:1527873427142};\\\", \\\"{x:1338,y:489,t:1527873427159};\\\", \\\"{x:1348,y:489,t:1527873427176};\\\", \\\"{x:1360,y:488,t:1527873427192};\\\", \\\"{x:1368,y:486,t:1527873427209};\\\", \\\"{x:1371,y:485,t:1527873427226};\\\", \\\"{x:1373,y:485,t:1527873427243};\\\", \\\"{x:1375,y:485,t:1527873427274};\\\", \\\"{x:1376,y:485,t:1527873427283};\\\", \\\"{x:1377,y:485,t:1527873427298};\\\", \\\"{x:1378,y:485,t:1527873427692};\\\", \\\"{x:1378,y:487,t:1527873433515};\\\", \\\"{x:1378,y:488,t:1527873433525};\\\", \\\"{x:1380,y:494,t:1527873433542};\\\", \\\"{x:1385,y:501,t:1527873433559};\\\", \\\"{x:1388,y:509,t:1527873433575};\\\", \\\"{x:1390,y:522,t:1527873433592};\\\", \\\"{x:1393,y:533,t:1527873433609};\\\", \\\"{x:1398,y:543,t:1527873433625};\\\", \\\"{x:1420,y:566,t:1527873433642};\\\", \\\"{x:1437,y:591,t:1527873433659};\\\", \\\"{x:1458,y:624,t:1527873433675};\\\", \\\"{x:1468,y:640,t:1527873433692};\\\", \\\"{x:1472,y:647,t:1527873433709};\\\", \\\"{x:1474,y:651,t:1527873433725};\\\", \\\"{x:1478,y:664,t:1527873433742};\\\", \\\"{x:1484,y:689,t:1527873433759};\\\", \\\"{x:1497,y:721,t:1527873433776};\\\", \\\"{x:1519,y:773,t:1527873433793};\\\", \\\"{x:1529,y:814,t:1527873433809};\\\", \\\"{x:1534,y:835,t:1527873433826};\\\", \\\"{x:1535,y:852,t:1527873433843};\\\", \\\"{x:1535,y:863,t:1527873433859};\\\", \\\"{x:1534,y:870,t:1527873433874};\\\", \\\"{x:1531,y:878,t:1527873433892};\\\", \\\"{x:1529,y:894,t:1527873433908};\\\", \\\"{x:1527,y:910,t:1527873433925};\\\", \\\"{x:1524,y:920,t:1527873433942};\\\", \\\"{x:1524,y:921,t:1527873433957};\\\", \\\"{x:1523,y:922,t:1527873433977};\\\", \\\"{x:1522,y:919,t:1527873434034};\\\", \\\"{x:1522,y:917,t:1527873434042};\\\", \\\"{x:1520,y:910,t:1527873434058};\\\", \\\"{x:1519,y:904,t:1527873434075};\\\", \\\"{x:1515,y:896,t:1527873434092};\\\", \\\"{x:1514,y:890,t:1527873434108};\\\", \\\"{x:1512,y:885,t:1527873434125};\\\", \\\"{x:1511,y:873,t:1527873434141};\\\", \\\"{x:1507,y:856,t:1527873434158};\\\", \\\"{x:1505,y:853,t:1527873434174};\\\", \\\"{x:1503,y:851,t:1527873434191};\\\", \\\"{x:1503,y:850,t:1527873434273};\\\", \\\"{x:1502,y:850,t:1527873434475};\\\", \\\"{x:1489,y:855,t:1527873434494};\\\", \\\"{x:1473,y:861,t:1527873434508};\\\", \\\"{x:1467,y:865,t:1527873434525};\\\", \\\"{x:1467,y:864,t:1527873434665};\\\", \\\"{x:1467,y:862,t:1527873434675};\\\", \\\"{x:1470,y:860,t:1527873434691};\\\", \\\"{x:1476,y:854,t:1527873434707};\\\", \\\"{x:1478,y:852,t:1527873434724};\\\", \\\"{x:1478,y:851,t:1527873434742};\\\", \\\"{x:1478,y:850,t:1527873434758};\\\", \\\"{x:1480,y:847,t:1527873434785};\\\", \\\"{x:1481,y:847,t:1527873434794};\\\", \\\"{x:1486,y:844,t:1527873434808};\\\", \\\"{x:1490,y:839,t:1527873434825};\\\", \\\"{x:1495,y:836,t:1527873434842};\\\", \\\"{x:1498,y:834,t:1527873434858};\\\", \\\"{x:1505,y:832,t:1527873434875};\\\", \\\"{x:1520,y:829,t:1527873434892};\\\", \\\"{x:1531,y:825,t:1527873434907};\\\", \\\"{x:1538,y:822,t:1527873434925};\\\", \\\"{x:1547,y:820,t:1527873434942};\\\", \\\"{x:1552,y:818,t:1527873434958};\\\", \\\"{x:1554,y:817,t:1527873434975};\\\", \\\"{x:1556,y:817,t:1527873434992};\\\", \\\"{x:1558,y:817,t:1527873435049};\\\", \\\"{x:1561,y:817,t:1527873435058};\\\", \\\"{x:1567,y:817,t:1527873435075};\\\", \\\"{x:1570,y:817,t:1527873435092};\\\", \\\"{x:1571,y:817,t:1527873435114};\\\", \\\"{x:1570,y:817,t:1527873435186};\\\", \\\"{x:1569,y:818,t:1527873435202};\\\", \\\"{x:1568,y:818,t:1527873435218};\\\", \\\"{x:1568,y:820,t:1527873435234};\\\", \\\"{x:1567,y:821,t:1527873435250};\\\", \\\"{x:1569,y:821,t:1527873435322};\\\", \\\"{x:1571,y:821,t:1527873435330};\\\", \\\"{x:1575,y:821,t:1527873435342};\\\", \\\"{x:1586,y:821,t:1527873435358};\\\", \\\"{x:1605,y:821,t:1527873435375};\\\", \\\"{x:1624,y:821,t:1527873435393};\\\", \\\"{x:1635,y:821,t:1527873435408};\\\", \\\"{x:1638,y:821,t:1527873435425};\\\", \\\"{x:1638,y:822,t:1527873435633};\\\", \\\"{x:1638,y:823,t:1527873435641};\\\", \\\"{x:1636,y:824,t:1527873435658};\\\", \\\"{x:1635,y:825,t:1527873435675};\\\", \\\"{x:1635,y:826,t:1527873435692};\\\", \\\"{x:1635,y:827,t:1527873435708};\\\", \\\"{x:1634,y:827,t:1527873436339};\\\", \\\"{x:1633,y:827,t:1527873436346};\\\", \\\"{x:1632,y:828,t:1527873436362};\\\", \\\"{x:1631,y:829,t:1527873436375};\\\", \\\"{x:1630,y:829,t:1527873436393};\\\", \\\"{x:1629,y:830,t:1527873436409};\\\", \\\"{x:1628,y:830,t:1527873436466};\\\", \\\"{x:1627,y:830,t:1527873436515};\\\", \\\"{x:1626,y:831,t:1527873436526};\\\", \\\"{x:1625,y:832,t:1527873436579};\\\", \\\"{x:1624,y:832,t:1527873450018};\\\", \\\"{x:1623,y:832,t:1527873450346};\\\", \\\"{x:1622,y:832,t:1527873450410};\\\", \\\"{x:1621,y:832,t:1527873450426};\\\", \\\"{x:1620,y:832,t:1527873450442};\\\", \\\"{x:1618,y:833,t:1527873450466};\\\", \\\"{x:1617,y:833,t:1527873450482};\\\", \\\"{x:1616,y:833,t:1527873450539};\\\", \\\"{x:1615,y:833,t:1527873450571};\\\", \\\"{x:1613,y:833,t:1527873451059};\\\", \\\"{x:1613,y:831,t:1527873451451};\\\", \\\"{x:1614,y:831,t:1527873451482};\\\", \\\"{x:1614,y:829,t:1527873451498};\\\", \\\"{x:1614,y:828,t:1527873451666};\\\", \\\"{x:1614,y:827,t:1527873453177};\\\", \\\"{x:1613,y:827,t:1527873453191};\\\", \\\"{x:1602,y:827,t:1527873453208};\\\", \\\"{x:1568,y:821,t:1527873453223};\\\", \\\"{x:1512,y:821,t:1527873453241};\\\", \\\"{x:1398,y:799,t:1527873453258};\\\", \\\"{x:1309,y:797,t:1527873453274};\\\", \\\"{x:1230,y:793,t:1527873453293};\\\", \\\"{x:1185,y:787,t:1527873453309};\\\", \\\"{x:1158,y:779,t:1527873453324};\\\", \\\"{x:1141,y:770,t:1527873453341};\\\", \\\"{x:1127,y:762,t:1527873453358};\\\", \\\"{x:1113,y:750,t:1527873453374};\\\", \\\"{x:1098,y:737,t:1527873453391};\\\", \\\"{x:1082,y:714,t:1527873453409};\\\", \\\"{x:1072,y:702,t:1527873453424};\\\", \\\"{x:1067,y:697,t:1527873453441};\\\", \\\"{x:1049,y:670,t:1527873453459};\\\", \\\"{x:1038,y:652,t:1527873453474};\\\", \\\"{x:1035,y:646,t:1527873453492};\\\", \\\"{x:1034,y:645,t:1527873453508};\\\", \\\"{x:1034,y:644,t:1527873453525};\\\", \\\"{x:1032,y:640,t:1527873453541};\\\", \\\"{x:1025,y:631,t:1527873453558};\\\", \\\"{x:1021,y:622,t:1527873453573};\\\", \\\"{x:1017,y:615,t:1527873453591};\\\", \\\"{x:1015,y:612,t:1527873453607};\\\", \\\"{x:1015,y:611,t:1527873453624};\\\", \\\"{x:1013,y:604,t:1527873453641};\\\", \\\"{x:1013,y:586,t:1527873453657};\\\", \\\"{x:1013,y:585,t:1527873453674};\\\", \\\"{x:1013,y:584,t:1527873453929};\\\", \\\"{x:997,y:580,t:1527873453941};\\\", \\\"{x:975,y:574,t:1527873453958};\\\", \\\"{x:963,y:573,t:1527873453974};\\\", \\\"{x:957,y:571,t:1527873453991};\\\", \\\"{x:954,y:570,t:1527873454008};\\\", \\\"{x:952,y:570,t:1527873454042};\\\", \\\"{x:950,y:570,t:1527873454059};\\\", \\\"{x:938,y:572,t:1527873454073};\\\", \\\"{x:908,y:584,t:1527873454091};\\\", \\\"{x:867,y:592,t:1527873454106};\\\", \\\"{x:808,y:594,t:1527873454124};\\\", \\\"{x:778,y:594,t:1527873454140};\\\", \\\"{x:760,y:594,t:1527873454156};\\\", \\\"{x:746,y:594,t:1527873454173};\\\", \\\"{x:733,y:594,t:1527873454191};\\\", \\\"{x:716,y:590,t:1527873454207};\\\", \\\"{x:697,y:581,t:1527873454224};\\\", \\\"{x:683,y:576,t:1527873454241};\\\", \\\"{x:680,y:575,t:1527873454257};\\\", \\\"{x:673,y:574,t:1527873454274};\\\", \\\"{x:662,y:572,t:1527873454291};\\\", \\\"{x:642,y:571,t:1527873454307};\\\", \\\"{x:621,y:571,t:1527873454323};\\\", \\\"{x:605,y:571,t:1527873454341};\\\", \\\"{x:590,y:571,t:1527873454359};\\\", \\\"{x:571,y:570,t:1527873454374};\\\", \\\"{x:550,y:565,t:1527873454390};\\\", \\\"{x:523,y:559,t:1527873454409};\\\", \\\"{x:505,y:557,t:1527873454424};\\\", \\\"{x:496,y:555,t:1527873454441};\\\", \\\"{x:489,y:555,t:1527873454456};\\\", \\\"{x:454,y:569,t:1527873454474};\\\", \\\"{x:430,y:578,t:1527873454491};\\\", \\\"{x:415,y:580,t:1527873454508};\\\", \\\"{x:410,y:580,t:1527873454523};\\\", \\\"{x:408,y:580,t:1527873454541};\\\", \\\"{x:407,y:580,t:1527873454558};\\\", \\\"{x:407,y:579,t:1527873454681};\\\", \\\"{x:405,y:575,t:1527873454690};\\\", \\\"{x:404,y:569,t:1527873454707};\\\", \\\"{x:403,y:567,t:1527873454724};\\\", \\\"{x:401,y:567,t:1527873454906};\\\", \\\"{x:398,y:567,t:1527873454914};\\\", \\\"{x:396,y:569,t:1527873454924};\\\", \\\"{x:394,y:569,t:1527873454941};\\\", \\\"{x:393,y:570,t:1527873454994};\\\", \\\"{x:393,y:572,t:1527873455008};\\\", \\\"{x:393,y:574,t:1527873455025};\\\", \\\"{x:393,y:575,t:1527873455138};\\\", \\\"{x:392,y:576,t:1527873455146};\\\", \\\"{x:392,y:577,t:1527873455158};\\\", \\\"{x:392,y:578,t:1527873455202};\\\", \\\"{x:392,y:581,t:1527873455210};\\\", \\\"{x:391,y:583,t:1527873455225};\\\", \\\"{x:391,y:591,t:1527873455242};\\\", \\\"{x:391,y:597,t:1527873455258};\\\", \\\"{x:389,y:600,t:1527873455274};\\\", \\\"{x:389,y:601,t:1527873455292};\\\", \\\"{x:389,y:603,t:1527873455308};\\\", \\\"{x:386,y:610,t:1527873455325};\\\", \\\"{x:385,y:624,t:1527873455341};\\\", \\\"{x:384,y:640,t:1527873455358};\\\", \\\"{x:384,y:649,t:1527873455375};\\\", \\\"{x:382,y:654,t:1527873455391};\\\", \\\"{x:382,y:656,t:1527873455449};\\\", \\\"{x:382,y:657,t:1527873455465};\\\", \\\"{x:382,y:659,t:1527873455475};\\\", \\\"{x:381,y:660,t:1527873455545};\\\", \\\"{x:379,y:658,t:1527873455730};\\\", \\\"{x:379,y:657,t:1527873455745};\\\", \\\"{x:379,y:655,t:1527873455953};\\\", \\\"{x:378,y:654,t:1527873455969};\\\", \\\"{x:377,y:654,t:1527873455993};\\\", \\\"{x:376,y:654,t:1527873456008};\\\", \\\"{x:368,y:654,t:1527873456025};\\\", \\\"{x:334,y:654,t:1527873456041};\\\", \\\"{x:319,y:654,t:1527873456059};\\\", \\\"{x:317,y:654,t:1527873456075};\\\", \\\"{x:315,y:654,t:1527873456091};\\\", \\\"{x:313,y:655,t:1527873456109};\\\", \\\"{x:309,y:658,t:1527873456125};\\\", \\\"{x:303,y:661,t:1527873456142};\\\", \\\"{x:298,y:665,t:1527873456159};\\\", \\\"{x:295,y:666,t:1527873456176};\\\", \\\"{x:293,y:667,t:1527873456191};\\\", \\\"{x:289,y:669,t:1527873456209};\\\", \\\"{x:277,y:673,t:1527873456227};\\\", \\\"{x:266,y:679,t:1527873456242};\\\", \\\"{x:262,y:681,t:1527873456259};\\\", \\\"{x:261,y:683,t:1527873456276};\\\", \\\"{x:258,y:683,t:1527873456292};\\\", \\\"{x:254,y:683,t:1527873456308};\\\", \\\"{x:246,y:683,t:1527873456325};\\\", \\\"{x:232,y:683,t:1527873456342};\\\", \\\"{x:221,y:683,t:1527873456359};\\\", \\\"{x:206,y:683,t:1527873456376};\\\", \\\"{x:178,y:683,t:1527873456392};\\\", \\\"{x:152,y:678,t:1527873456409};\\\", \\\"{x:107,y:672,t:1527873456425};\\\", \\\"{x:82,y:661,t:1527873456443};\\\", \\\"{x:54,y:654,t:1527873456459};\\\", \\\"{x:46,y:651,t:1527873456476};\\\", \\\"{x:48,y:650,t:1527873456537};\\\", \\\"{x:49,y:650,t:1527873456561};\\\", \\\"{x:50,y:650,t:1527873456575};\\\", \\\"{x:56,y:650,t:1527873456593};\\\", \\\"{x:71,y:650,t:1527873456608};\\\", \\\"{x:112,y:650,t:1527873456625};\\\", \\\"{x:114,y:650,t:1527873456642};\\\", \\\"{x:114,y:649,t:1527873456659};\\\", \\\"{x:115,y:648,t:1527873456681};\\\", \\\"{x:116,y:648,t:1527873456754};\\\", \\\"{x:120,y:648,t:1527873456761};\\\", \\\"{x:125,y:648,t:1527873456776};\\\", \\\"{x:135,y:646,t:1527873456793};\\\", \\\"{x:137,y:645,t:1527873456809};\\\", \\\"{x:138,y:645,t:1527873456826};\\\", \\\"{x:139,y:645,t:1527873456843};\\\", \\\"{x:145,y:645,t:1527873456859};\\\", \\\"{x:153,y:645,t:1527873456876};\\\", \\\"{x:156,y:645,t:1527873456892};\\\", \\\"{x:155,y:645,t:1527873457049};\\\", \\\"{x:154,y:645,t:1527873457193};\\\", \\\"{x:157,y:647,t:1527873457233};\\\", \\\"{x:163,y:648,t:1527873457242};\\\", \\\"{x:177,y:652,t:1527873457260};\\\", \\\"{x:198,y:659,t:1527873457276};\\\", \\\"{x:214,y:664,t:1527873457292};\\\", \\\"{x:220,y:666,t:1527873457309};\\\", \\\"{x:223,y:668,t:1527873457337};\\\", \\\"{x:225,y:668,t:1527873457345};\\\", \\\"{x:229,y:669,t:1527873457360};\\\", \\\"{x:242,y:672,t:1527873457377};\\\", \\\"{x:251,y:675,t:1527873457393};\\\", \\\"{x:263,y:677,t:1527873457409};\\\", \\\"{x:279,y:679,t:1527873457426};\\\", \\\"{x:310,y:684,t:1527873457443};\\\", \\\"{x:358,y:691,t:1527873457460};\\\", \\\"{x:427,y:707,t:1527873457476};\\\", \\\"{x:480,y:715,t:1527873457492};\\\", \\\"{x:502,y:717,t:1527873457510};\\\", \\\"{x:512,y:718,t:1527873457526};\\\", \\\"{x:523,y:718,t:1527873457543};\\\", \\\"{x:536,y:720,t:1527873457561};\\\", \\\"{x:565,y:721,t:1527873457577};\\\", \\\"{x:572,y:722,t:1527873457593};\\\", \\\"{x:580,y:723,t:1527873457609};\\\", \\\"{x:581,y:723,t:1527873457641};\\\", \\\"{x:581,y:724,t:1527873457681};\\\", \\\"{x:581,y:726,t:1527873457713};\\\", \\\"{x:581,y:727,t:1527873457727};\\\", \\\"{x:580,y:728,t:1527873457744};\\\", \\\"{x:579,y:730,t:1527873457760};\\\", \\\"{x:574,y:732,t:1527873457777};\\\", \\\"{x:566,y:738,t:1527873457793};\\\", \\\"{x:564,y:739,t:1527873457811};\\\", \\\"{x:562,y:740,t:1527873457827};\\\", \\\"{x:561,y:740,t:1527873457843};\\\", \\\"{x:560,y:741,t:1527873457860};\\\", \\\"{x:558,y:741,t:1527873457876};\\\", \\\"{x:556,y:741,t:1527873457893};\\\", \\\"{x:552,y:741,t:1527873457910};\\\", \\\"{x:544,y:741,t:1527873457926};\\\", \\\"{x:536,y:741,t:1527873457943};\\\", \\\"{x:532,y:741,t:1527873457960};\\\", \\\"{x:530,y:741,t:1527873457977};\\\", \\\"{x:527,y:741,t:1527873457993};\\\", \\\"{x:524,y:741,t:1527873458010};\\\", \\\"{x:523,y:741,t:1527873458058};\\\", \\\"{x:522,y:741,t:1527873458082};\\\", \\\"{x:520,y:741,t:1527873458261};\\\", \\\"{x:520,y:740,t:1527873458276};\\\", \\\"{x:519,y:740,t:1527873458353};\\\", \\\"{x:519,y:739,t:1527873458689};\\\", \\\"{x:519,y:738,t:1527873458754};\\\", \\\"{x:518,y:737,t:1527873458786};\\\", \\\"{x:517,y:737,t:1527873458937};\\\", \\\"{x:517,y:736,t:1527873458961};\\\", \\\"{x:517,y:735,t:1527873459009};\\\", \\\"{x:517,y:733,t:1527873459098};\\\" ] }, { \\\"rt\\\": 15656, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 427017, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"9BS72\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:517,y:732,t:1527873459802};\\\", \\\"{x:516,y:732,t:1527873459897};\\\", \\\"{x:516,y:729,t:1527873459912};\\\", \\\"{x:515,y:726,t:1527873459928};\\\", \\\"{x:514,y:725,t:1527873459946};\\\", \\\"{x:514,y:723,t:1527873459961};\\\", \\\"{x:516,y:723,t:1527873460938};\\\", \\\"{x:518,y:722,t:1527873460948};\\\", \\\"{x:520,y:721,t:1527873460965};\\\", \\\"{x:521,y:721,t:1527873460982};\\\", \\\"{x:522,y:720,t:1527873461001};\\\", \\\"{x:523,y:720,t:1527873461015};\\\", \\\"{x:525,y:719,t:1527873461032};\\\", \\\"{x:529,y:717,t:1527873461047};\\\", \\\"{x:531,y:715,t:1527873461062};\\\", \\\"{x:533,y:715,t:1527873461078};\\\", \\\"{x:534,y:713,t:1527873461095};\\\", \\\"{x:536,y:713,t:1527873461112};\\\", \\\"{x:544,y:712,t:1527873461129};\\\", \\\"{x:567,y:708,t:1527873461145};\\\", \\\"{x:598,y:705,t:1527873461161};\\\", \\\"{x:630,y:702,t:1527873461178};\\\", \\\"{x:648,y:702,t:1527873461195};\\\", \\\"{x:669,y:699,t:1527873461212};\\\", \\\"{x:683,y:699,t:1527873461229};\\\", \\\"{x:692,y:699,t:1527873461244};\\\", \\\"{x:704,y:697,t:1527873461262};\\\", \\\"{x:717,y:696,t:1527873461279};\\\", \\\"{x:724,y:696,t:1527873461295};\\\", \\\"{x:728,y:695,t:1527873461312};\\\", \\\"{x:732,y:694,t:1527873461330};\\\", \\\"{x:733,y:694,t:1527873461345};\\\", \\\"{x:737,y:693,t:1527873461362};\\\", \\\"{x:742,y:692,t:1527873461380};\\\", \\\"{x:744,y:692,t:1527873461395};\\\", \\\"{x:745,y:692,t:1527873461412};\\\", \\\"{x:748,y:690,t:1527873461429};\\\", \\\"{x:754,y:689,t:1527873461446};\\\", \\\"{x:767,y:689,t:1527873461462};\\\", \\\"{x:784,y:689,t:1527873461478};\\\", \\\"{x:804,y:689,t:1527873461495};\\\", \\\"{x:817,y:689,t:1527873461512};\\\", \\\"{x:826,y:689,t:1527873461529};\\\", \\\"{x:835,y:689,t:1527873461545};\\\", \\\"{x:852,y:689,t:1527873461562};\\\", \\\"{x:873,y:689,t:1527873461579};\\\", \\\"{x:893,y:689,t:1527873461595};\\\", \\\"{x:906,y:689,t:1527873461612};\\\", \\\"{x:916,y:689,t:1527873461629};\\\", \\\"{x:920,y:689,t:1527873461645};\\\", \\\"{x:924,y:689,t:1527873461662};\\\", \\\"{x:927,y:689,t:1527873461679};\\\", \\\"{x:929,y:689,t:1527873461695};\\\", \\\"{x:930,y:689,t:1527873461712};\\\", \\\"{x:934,y:689,t:1527873461729};\\\", \\\"{x:939,y:688,t:1527873461745};\\\", \\\"{x:948,y:688,t:1527873461762};\\\", \\\"{x:959,y:686,t:1527873461779};\\\", \\\"{x:973,y:686,t:1527873461795};\\\", \\\"{x:984,y:685,t:1527873461813};\\\", \\\"{x:993,y:683,t:1527873461829};\\\", \\\"{x:1001,y:682,t:1527873461846};\\\", \\\"{x:1013,y:682,t:1527873461863};\\\", \\\"{x:1035,y:682,t:1527873461879};\\\", \\\"{x:1075,y:679,t:1527873461896};\\\", \\\"{x:1119,y:667,t:1527873461912};\\\", \\\"{x:1165,y:659,t:1527873461929};\\\", \\\"{x:1191,y:657,t:1527873461945};\\\", \\\"{x:1191,y:656,t:1527873461962};\\\", \\\"{x:1192,y:656,t:1527873462515};\\\", \\\"{x:1193,y:657,t:1527873462530};\\\", \\\"{x:1196,y:657,t:1527873462546};\\\", \\\"{x:1198,y:657,t:1527873462563};\\\", \\\"{x:1200,y:657,t:1527873462580};\\\", \\\"{x:1203,y:657,t:1527873462597};\\\", \\\"{x:1204,y:657,t:1527873462618};\\\", \\\"{x:1205,y:657,t:1527873462650};\\\", \\\"{x:1206,y:657,t:1527873462663};\\\", \\\"{x:1214,y:658,t:1527873462679};\\\", \\\"{x:1223,y:660,t:1527873462696};\\\", \\\"{x:1230,y:661,t:1527873462713};\\\", \\\"{x:1245,y:663,t:1527873462730};\\\", \\\"{x:1252,y:664,t:1527873462746};\\\", \\\"{x:1257,y:664,t:1527873462763};\\\", \\\"{x:1260,y:664,t:1527873462779};\\\", \\\"{x:1261,y:664,t:1527873462810};\\\", \\\"{x:1262,y:664,t:1527873462818};\\\", \\\"{x:1265,y:664,t:1527873462834};\\\", \\\"{x:1267,y:665,t:1527873462847};\\\", \\\"{x:1271,y:665,t:1527873462864};\\\", \\\"{x:1275,y:666,t:1527873462880};\\\", \\\"{x:1276,y:667,t:1527873462897};\\\", \\\"{x:1278,y:671,t:1527873462915};\\\", \\\"{x:1283,y:683,t:1527873462930};\\\", \\\"{x:1288,y:701,t:1527873462946};\\\", \\\"{x:1293,y:706,t:1527873462964};\\\", \\\"{x:1295,y:710,t:1527873462980};\\\", \\\"{x:1298,y:717,t:1527873462997};\\\", \\\"{x:1301,y:734,t:1527873463014};\\\", \\\"{x:1304,y:746,t:1527873463029};\\\", \\\"{x:1306,y:751,t:1527873463046};\\\", \\\"{x:1307,y:756,t:1527873463063};\\\", \\\"{x:1308,y:759,t:1527873463080};\\\", \\\"{x:1309,y:762,t:1527873463096};\\\", \\\"{x:1309,y:763,t:1527873463122};\\\", \\\"{x:1308,y:763,t:1527873463290};\\\", \\\"{x:1305,y:765,t:1527873463298};\\\", \\\"{x:1301,y:765,t:1527873463313};\\\", \\\"{x:1294,y:765,t:1527873463329};\\\", \\\"{x:1290,y:765,t:1527873463346};\\\", \\\"{x:1286,y:765,t:1527873463364};\\\", \\\"{x:1280,y:765,t:1527873463379};\\\", \\\"{x:1275,y:764,t:1527873463397};\\\", \\\"{x:1272,y:764,t:1527873463414};\\\", \\\"{x:1270,y:764,t:1527873463429};\\\", \\\"{x:1269,y:764,t:1527873463446};\\\", \\\"{x:1268,y:764,t:1527873463463};\\\", \\\"{x:1267,y:764,t:1527873463883};\\\", \\\"{x:1267,y:763,t:1527873463906};\\\", \\\"{x:1265,y:762,t:1527873463914};\\\", \\\"{x:1265,y:761,t:1527873464050};\\\", \\\"{x:1265,y:760,t:1527873464083};\\\", \\\"{x:1265,y:759,t:1527873464163};\\\", \\\"{x:1266,y:759,t:1527873464186};\\\", \\\"{x:1266,y:758,t:1527873464243};\\\", \\\"{x:1267,y:756,t:1527873464339};\\\", \\\"{x:1268,y:756,t:1527873464354};\\\", \\\"{x:1269,y:755,t:1527873464370};\\\", \\\"{x:1271,y:754,t:1527873464381};\\\", \\\"{x:1273,y:750,t:1527873464397};\\\", \\\"{x:1277,y:745,t:1527873464414};\\\", \\\"{x:1280,y:742,t:1527873464430};\\\", \\\"{x:1283,y:739,t:1527873464447};\\\", \\\"{x:1286,y:736,t:1527873464464};\\\", \\\"{x:1287,y:735,t:1527873464481};\\\", \\\"{x:1290,y:731,t:1527873464497};\\\", \\\"{x:1294,y:726,t:1527873464514};\\\", \\\"{x:1296,y:724,t:1527873464530};\\\", \\\"{x:1300,y:719,t:1527873464546};\\\", \\\"{x:1301,y:718,t:1527873464564};\\\", \\\"{x:1302,y:717,t:1527873464581};\\\", \\\"{x:1304,y:715,t:1527873464597};\\\", \\\"{x:1304,y:714,t:1527873464614};\\\", \\\"{x:1304,y:713,t:1527873464631};\\\", \\\"{x:1304,y:711,t:1527873464647};\\\", \\\"{x:1304,y:708,t:1527873464664};\\\", \\\"{x:1304,y:706,t:1527873464681};\\\", \\\"{x:1304,y:702,t:1527873464697};\\\", \\\"{x:1298,y:696,t:1527873464714};\\\", \\\"{x:1295,y:693,t:1527873464731};\\\", \\\"{x:1291,y:688,t:1527873464747};\\\", \\\"{x:1289,y:681,t:1527873464764};\\\", \\\"{x:1290,y:672,t:1527873464783};\\\", \\\"{x:1306,y:661,t:1527873464798};\\\", \\\"{x:1316,y:656,t:1527873464814};\\\", \\\"{x:1320,y:652,t:1527873464831};\\\", \\\"{x:1322,y:652,t:1527873464847};\\\", \\\"{x:1326,y:649,t:1527873464864};\\\", \\\"{x:1325,y:648,t:1527873465010};\\\", \\\"{x:1325,y:649,t:1527873465130};\\\", \\\"{x:1341,y:671,t:1527873465148};\\\", \\\"{x:1356,y:685,t:1527873465164};\\\", \\\"{x:1365,y:692,t:1527873465181};\\\", \\\"{x:1378,y:703,t:1527873465198};\\\", \\\"{x:1392,y:715,t:1527873465214};\\\", \\\"{x:1403,y:729,t:1527873465231};\\\", \\\"{x:1407,y:738,t:1527873465247};\\\", \\\"{x:1413,y:745,t:1527873465263};\\\", \\\"{x:1413,y:751,t:1527873465280};\\\", \\\"{x:1410,y:757,t:1527873465297};\\\", \\\"{x:1407,y:763,t:1527873465313};\\\", \\\"{x:1403,y:770,t:1527873465330};\\\", \\\"{x:1399,y:776,t:1527873465347};\\\", \\\"{x:1389,y:782,t:1527873465363};\\\", \\\"{x:1381,y:788,t:1527873465381};\\\", \\\"{x:1372,y:800,t:1527873465397};\\\", \\\"{x:1363,y:806,t:1527873465413};\\\", \\\"{x:1353,y:810,t:1527873465430};\\\", \\\"{x:1343,y:811,t:1527873465448};\\\", \\\"{x:1335,y:811,t:1527873465464};\\\", \\\"{x:1327,y:813,t:1527873465480};\\\", \\\"{x:1310,y:818,t:1527873465498};\\\", \\\"{x:1305,y:819,t:1527873465514};\\\", \\\"{x:1301,y:819,t:1527873465531};\\\", \\\"{x:1300,y:819,t:1527873465547};\\\", \\\"{x:1295,y:819,t:1527873465564};\\\", \\\"{x:1285,y:818,t:1527873465580};\\\", \\\"{x:1267,y:810,t:1527873465598};\\\", \\\"{x:1248,y:799,t:1527873465614};\\\", \\\"{x:1239,y:795,t:1527873465631};\\\", \\\"{x:1232,y:791,t:1527873465647};\\\", \\\"{x:1229,y:790,t:1527873465663};\\\", \\\"{x:1228,y:790,t:1527873465706};\\\", \\\"{x:1227,y:790,t:1527873465722};\\\", \\\"{x:1226,y:790,t:1527873465746};\\\", \\\"{x:1225,y:790,t:1527873465762};\\\", \\\"{x:1224,y:791,t:1527873465770};\\\", \\\"{x:1223,y:792,t:1527873465781};\\\", \\\"{x:1222,y:794,t:1527873465798};\\\", \\\"{x:1222,y:795,t:1527873465826};\\\", \\\"{x:1222,y:796,t:1527873465834};\\\", \\\"{x:1222,y:798,t:1527873465848};\\\", \\\"{x:1221,y:801,t:1527873465864};\\\", \\\"{x:1220,y:804,t:1527873465881};\\\", \\\"{x:1219,y:809,t:1527873465898};\\\", \\\"{x:1219,y:810,t:1527873465914};\\\", \\\"{x:1219,y:811,t:1527873465930};\\\", \\\"{x:1218,y:812,t:1527873465986};\\\", \\\"{x:1217,y:813,t:1527873466001};\\\", \\\"{x:1216,y:814,t:1527873466081};\\\", \\\"{x:1215,y:814,t:1527873466104};\\\", \\\"{x:1214,y:814,t:1527873466114};\\\", \\\"{x:1213,y:812,t:1527873466130};\\\", \\\"{x:1212,y:810,t:1527873466147};\\\", \\\"{x:1209,y:807,t:1527873466164};\\\", \\\"{x:1208,y:804,t:1527873466180};\\\", \\\"{x:1208,y:799,t:1527873466197};\\\", \\\"{x:1208,y:791,t:1527873466214};\\\", \\\"{x:1208,y:781,t:1527873466230};\\\", \\\"{x:1208,y:779,t:1527873466247};\\\", \\\"{x:1206,y:776,t:1527873466264};\\\", \\\"{x:1205,y:775,t:1527873466281};\\\", \\\"{x:1203,y:775,t:1527873466297};\\\", \\\"{x:1202,y:775,t:1527873466314};\\\", \\\"{x:1201,y:775,t:1527873466353};\\\", \\\"{x:1200,y:774,t:1527873466368};\\\", \\\"{x:1199,y:774,t:1527873466380};\\\", \\\"{x:1198,y:774,t:1527873466397};\\\", \\\"{x:1197,y:774,t:1527873466414};\\\", \\\"{x:1196,y:774,t:1527873466430};\\\", \\\"{x:1195,y:774,t:1527873466457};\\\", \\\"{x:1194,y:774,t:1527873466593};\\\", \\\"{x:1192,y:774,t:1527873466601};\\\", \\\"{x:1191,y:774,t:1527873466614};\\\", \\\"{x:1190,y:774,t:1527873466630};\\\", \\\"{x:1190,y:773,t:1527873469332};\\\", \\\"{x:1190,y:772,t:1527873469340};\\\", \\\"{x:1191,y:771,t:1527873469351};\\\", \\\"{x:1194,y:770,t:1527873469368};\\\", \\\"{x:1197,y:769,t:1527873469385};\\\", \\\"{x:1198,y:768,t:1527873469401};\\\", \\\"{x:1200,y:768,t:1527873469418};\\\", \\\"{x:1201,y:767,t:1527873469434};\\\", \\\"{x:1202,y:766,t:1527873469451};\\\", \\\"{x:1203,y:766,t:1527873469468};\\\", \\\"{x:1206,y:765,t:1527873469485};\\\", \\\"{x:1207,y:764,t:1527873469501};\\\", \\\"{x:1214,y:762,t:1527873469519};\\\", \\\"{x:1220,y:762,t:1527873469535};\\\", \\\"{x:1234,y:762,t:1527873469552};\\\", \\\"{x:1249,y:762,t:1527873469568};\\\", \\\"{x:1256,y:762,t:1527873469584};\\\", \\\"{x:1257,y:762,t:1527873469601};\\\", \\\"{x:1258,y:762,t:1527873469805};\\\", \\\"{x:1260,y:761,t:1527873469820};\\\", \\\"{x:1261,y:761,t:1527873469836};\\\", \\\"{x:1263,y:761,t:1527873469851};\\\", \\\"{x:1289,y:761,t:1527873469868};\\\", \\\"{x:1317,y:761,t:1527873469886};\\\", \\\"{x:1340,y:761,t:1527873469901};\\\", \\\"{x:1351,y:763,t:1527873469919};\\\", \\\"{x:1349,y:764,t:1527873469972};\\\", \\\"{x:1350,y:764,t:1527873470196};\\\", \\\"{x:1352,y:764,t:1527873470212};\\\", \\\"{x:1353,y:764,t:1527873470228};\\\", \\\"{x:1355,y:764,t:1527873470244};\\\", \\\"{x:1356,y:764,t:1527873470268};\\\", \\\"{x:1358,y:764,t:1527873470324};\\\", \\\"{x:1359,y:764,t:1527873470336};\\\", \\\"{x:1363,y:764,t:1527873470352};\\\", \\\"{x:1365,y:763,t:1527873470369};\\\", \\\"{x:1367,y:763,t:1527873470386};\\\", \\\"{x:1368,y:763,t:1527873470620};\\\", \\\"{x:1365,y:763,t:1527873470757};\\\", \\\"{x:1361,y:763,t:1527873470768};\\\", \\\"{x:1351,y:763,t:1527873470786};\\\", \\\"{x:1333,y:763,t:1527873470803};\\\", \\\"{x:1308,y:763,t:1527873470819};\\\", \\\"{x:1269,y:762,t:1527873470836};\\\", \\\"{x:1142,y:741,t:1527873470852};\\\", \\\"{x:1023,y:710,t:1527873470868};\\\", \\\"{x:902,y:676,t:1527873470885};\\\", \\\"{x:811,y:653,t:1527873470902};\\\", \\\"{x:759,y:634,t:1527873470918};\\\", \\\"{x:728,y:620,t:1527873470936};\\\", \\\"{x:712,y:614,t:1527873470953};\\\", \\\"{x:708,y:612,t:1527873470968};\\\", \\\"{x:708,y:611,t:1527873471004};\\\", \\\"{x:707,y:610,t:1527873471020};\\\", \\\"{x:706,y:609,t:1527873471044};\\\", \\\"{x:706,y:608,t:1527873471056};\\\", \\\"{x:704,y:608,t:1527873471074};\\\", \\\"{x:702,y:606,t:1527873471091};\\\", \\\"{x:701,y:606,t:1527873471108};\\\", \\\"{x:700,y:606,t:1527873471148};\\\", \\\"{x:699,y:606,t:1527873471158};\\\", \\\"{x:697,y:605,t:1527873471173};\\\", \\\"{x:693,y:605,t:1527873471191};\\\", \\\"{x:684,y:603,t:1527873471207};\\\", \\\"{x:676,y:601,t:1527873471223};\\\", \\\"{x:663,y:597,t:1527873471241};\\\", \\\"{x:639,y:591,t:1527873471258};\\\", \\\"{x:621,y:584,t:1527873471273};\\\", \\\"{x:620,y:584,t:1527873471291};\\\", \\\"{x:618,y:583,t:1527873471307};\\\", \\\"{x:617,y:581,t:1527873471324};\\\", \\\"{x:615,y:580,t:1527873471340};\\\", \\\"{x:614,y:579,t:1527873471357};\\\", \\\"{x:612,y:578,t:1527873471374};\\\", \\\"{x:606,y:576,t:1527873471391};\\\", \\\"{x:604,y:574,t:1527873471407};\\\", \\\"{x:599,y:572,t:1527873471424};\\\", \\\"{x:589,y:567,t:1527873471441};\\\", \\\"{x:574,y:559,t:1527873471457};\\\", \\\"{x:560,y:558,t:1527873471473};\\\", \\\"{x:552,y:558,t:1527873471491};\\\", \\\"{x:550,y:558,t:1527873471507};\\\", \\\"{x:548,y:558,t:1527873471524};\\\", \\\"{x:542,y:558,t:1527873471548};\\\", \\\"{x:534,y:558,t:1527873471557};\\\", \\\"{x:496,y:568,t:1527873471575};\\\", \\\"{x:455,y:571,t:1527873471591};\\\", \\\"{x:438,y:571,t:1527873471607};\\\", \\\"{x:436,y:571,t:1527873471652};\\\", \\\"{x:431,y:570,t:1527873471901};\\\", \\\"{x:422,y:565,t:1527873471908};\\\", \\\"{x:403,y:558,t:1527873471924};\\\", \\\"{x:393,y:553,t:1527873471942};\\\", \\\"{x:385,y:548,t:1527873471958};\\\", \\\"{x:380,y:546,t:1527873471975};\\\", \\\"{x:373,y:543,t:1527873471990};\\\", \\\"{x:356,y:536,t:1527873472008};\\\", \\\"{x:343,y:531,t:1527873472025};\\\", \\\"{x:322,y:525,t:1527873472042};\\\", \\\"{x:299,y:522,t:1527873472058};\\\", \\\"{x:284,y:518,t:1527873472075};\\\", \\\"{x:273,y:514,t:1527873472092};\\\", \\\"{x:257,y:508,t:1527873472108};\\\", \\\"{x:202,y:496,t:1527873472124};\\\", \\\"{x:141,y:488,t:1527873472142};\\\", \\\"{x:117,y:486,t:1527873472157};\\\", \\\"{x:116,y:484,t:1527873472174};\\\", \\\"{x:115,y:484,t:1527873472212};\\\", \\\"{x:113,y:484,t:1527873472224};\\\", \\\"{x:105,y:482,t:1527873472242};\\\", \\\"{x:96,y:482,t:1527873472258};\\\", \\\"{x:94,y:482,t:1527873472275};\\\", \\\"{x:95,y:483,t:1527873472380};\\\", \\\"{x:99,y:484,t:1527873472392};\\\", \\\"{x:110,y:490,t:1527873472409};\\\", \\\"{x:119,y:497,t:1527873472424};\\\", \\\"{x:122,y:499,t:1527873472441};\\\", \\\"{x:123,y:499,t:1527873472476};\\\", \\\"{x:124,y:499,t:1527873472500};\\\", \\\"{x:126,y:499,t:1527873472508};\\\", \\\"{x:127,y:499,t:1527873472525};\\\", \\\"{x:129,y:499,t:1527873472542};\\\", \\\"{x:130,y:499,t:1527873472558};\\\", \\\"{x:132,y:499,t:1527873472574};\\\", \\\"{x:133,y:499,t:1527873472620};\\\", \\\"{x:136,y:499,t:1527873472628};\\\", \\\"{x:140,y:497,t:1527873472642};\\\", \\\"{x:144,y:496,t:1527873472658};\\\", \\\"{x:150,y:496,t:1527873472674};\\\", \\\"{x:152,y:496,t:1527873472692};\\\", \\\"{x:152,y:495,t:1527873472708};\\\", \\\"{x:153,y:494,t:1527873472933};\\\", \\\"{x:155,y:494,t:1527873472940};\\\", \\\"{x:155,y:494,t:1527873472942};\\\", \\\"{x:165,y:503,t:1527873472959};\\\", \\\"{x:174,y:512,t:1527873472975};\\\", \\\"{x:182,y:523,t:1527873472992};\\\", \\\"{x:188,y:529,t:1527873473010};\\\", \\\"{x:191,y:533,t:1527873473025};\\\", \\\"{x:196,y:537,t:1527873473042};\\\", \\\"{x:203,y:544,t:1527873473059};\\\", \\\"{x:206,y:546,t:1527873473076};\\\", \\\"{x:208,y:546,t:1527873473091};\\\", \\\"{x:210,y:547,t:1527873473109};\\\", \\\"{x:222,y:558,t:1527873473126};\\\", \\\"{x:248,y:581,t:1527873473143};\\\", \\\"{x:288,y:610,t:1527873473160};\\\", \\\"{x:333,y:643,t:1527873473176};\\\", \\\"{x:387,y:682,t:1527873473191};\\\", \\\"{x:432,y:713,t:1527873473209};\\\", \\\"{x:468,y:730,t:1527873473226};\\\", \\\"{x:481,y:734,t:1527873473242};\\\", \\\"{x:488,y:734,t:1527873473259};\\\", \\\"{x:484,y:734,t:1527873473380};\\\", \\\"{x:477,y:730,t:1527873473392};\\\", \\\"{x:455,y:717,t:1527873473410};\\\", \\\"{x:408,y:697,t:1527873473425};\\\", \\\"{x:326,y:665,t:1527873473442};\\\", \\\"{x:245,y:640,t:1527873473459};\\\", \\\"{x:213,y:631,t:1527873473477};\\\", \\\"{x:207,y:629,t:1527873473493};\\\", \\\"{x:207,y:626,t:1527873473509};\\\", \\\"{x:207,y:618,t:1527873473525};\\\", \\\"{x:206,y:609,t:1527873473543};\\\", \\\"{x:203,y:600,t:1527873473559};\\\", \\\"{x:201,y:597,t:1527873473576};\\\", \\\"{x:201,y:595,t:1527873473593};\\\", \\\"{x:201,y:590,t:1527873473609};\\\", \\\"{x:202,y:587,t:1527873473625};\\\", \\\"{x:202,y:582,t:1527873473643};\\\", \\\"{x:203,y:575,t:1527873473659};\\\", \\\"{x:201,y:565,t:1527873473675};\\\", \\\"{x:187,y:545,t:1527873473692};\\\", \\\"{x:175,y:535,t:1527873473710};\\\", \\\"{x:170,y:529,t:1527873473726};\\\", \\\"{x:170,y:524,t:1527873473744};\\\", \\\"{x:168,y:520,t:1527873473759};\\\", \\\"{x:168,y:518,t:1527873473776};\\\", \\\"{x:168,y:517,t:1527873473793};\\\", \\\"{x:168,y:516,t:1527873473876};\\\", \\\"{x:168,y:515,t:1527873473893};\\\", \\\"{x:168,y:514,t:1527873473910};\\\", \\\"{x:168,y:513,t:1527873473925};\\\", \\\"{x:169,y:511,t:1527873473975};\\\", \\\"{x:169,y:510,t:1527873473993};\\\", \\\"{x:170,y:510,t:1527873474308};\\\", \\\"{x:171,y:510,t:1527873474364};\\\", \\\"{x:173,y:510,t:1527873474377};\\\", \\\"{x:176,y:510,t:1527873474393};\\\", \\\"{x:183,y:515,t:1527873474409};\\\", \\\"{x:187,y:519,t:1527873474426};\\\", \\\"{x:195,y:530,t:1527873474443};\\\", \\\"{x:221,y:567,t:1527873474460};\\\", \\\"{x:328,y:661,t:1527873474477};\\\", \\\"{x:414,y:717,t:1527873474493};\\\", \\\"{x:478,y:749,t:1527873474511};\\\", \\\"{x:514,y:771,t:1527873474526};\\\", \\\"{x:536,y:784,t:1527873474543};\\\", \\\"{x:548,y:795,t:1527873474560};\\\", \\\"{x:550,y:795,t:1527873474577};\\\", \\\"{x:550,y:794,t:1527873474724};\\\", \\\"{x:550,y:793,t:1527873474732};\\\", \\\"{x:550,y:792,t:1527873474743};\\\", \\\"{x:550,y:788,t:1527873474761};\\\", \\\"{x:549,y:784,t:1527873474776};\\\", \\\"{x:549,y:781,t:1527873474793};\\\", \\\"{x:548,y:772,t:1527873474811};\\\", \\\"{x:543,y:762,t:1527873474827};\\\", \\\"{x:541,y:759,t:1527873474844};\\\", \\\"{x:540,y:752,t:1527873474861};\\\", \\\"{x:540,y:748,t:1527873474877};\\\", \\\"{x:540,y:747,t:1527873474893};\\\", \\\"{x:540,y:746,t:1527873474980};\\\", \\\"{x:540,y:745,t:1527873475828};\\\" ] }, { \\\"rt\\\": 48167, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 476394, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"9BS72\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-O -F -Z \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:540,y:744,t:1527873482372};\\\", \\\"{x:541,y:742,t:1527873482380};\\\", \\\"{x:542,y:741,t:1527873482393};\\\", \\\"{x:544,y:738,t:1527873482409};\\\", \\\"{x:545,y:736,t:1527873482425};\\\", \\\"{x:548,y:732,t:1527873482443};\\\", \\\"{x:553,y:728,t:1527873482459};\\\", \\\"{x:561,y:722,t:1527873482475};\\\", \\\"{x:568,y:715,t:1527873482494};\\\", \\\"{x:571,y:712,t:1527873482510};\\\", \\\"{x:571,y:711,t:1527873482539};\\\", \\\"{x:572,y:711,t:1527873482564};\\\", \\\"{x:573,y:710,t:1527873482578};\\\", \\\"{x:576,y:709,t:1527873482595};\\\", \\\"{x:576,y:708,t:1527873482612};\\\", \\\"{x:577,y:708,t:1527873482628};\\\", \\\"{x:579,y:707,t:1527873482645};\\\", \\\"{x:580,y:707,t:1527873482662};\\\", \\\"{x:584,y:705,t:1527873482678};\\\", \\\"{x:586,y:705,t:1527873482695};\\\", \\\"{x:591,y:702,t:1527873482712};\\\", \\\"{x:598,y:699,t:1527873482728};\\\", \\\"{x:607,y:694,t:1527873482745};\\\", \\\"{x:610,y:692,t:1527873482762};\\\", \\\"{x:617,y:690,t:1527873482778};\\\", \\\"{x:630,y:686,t:1527873482795};\\\", \\\"{x:649,y:680,t:1527873482812};\\\", \\\"{x:665,y:675,t:1527873482829};\\\", \\\"{x:676,y:670,t:1527873482845};\\\", \\\"{x:686,y:666,t:1527873482862};\\\", \\\"{x:693,y:664,t:1527873482878};\\\", \\\"{x:700,y:662,t:1527873482895};\\\", \\\"{x:713,y:658,t:1527873482912};\\\", \\\"{x:727,y:656,t:1527873482928};\\\", \\\"{x:737,y:652,t:1527873482945};\\\", \\\"{x:741,y:652,t:1527873482962};\\\", \\\"{x:744,y:651,t:1527873482978};\\\", \\\"{x:747,y:650,t:1527873482995};\\\", \\\"{x:760,y:648,t:1527873483012};\\\", \\\"{x:779,y:645,t:1527873483028};\\\", \\\"{x:797,y:642,t:1527873483045};\\\", \\\"{x:806,y:642,t:1527873483062};\\\", \\\"{x:809,y:641,t:1527873483078};\\\", \\\"{x:810,y:640,t:1527873483095};\\\", \\\"{x:815,y:641,t:1527873483112};\\\", \\\"{x:827,y:646,t:1527873483128};\\\", \\\"{x:840,y:652,t:1527873483145};\\\", \\\"{x:849,y:655,t:1527873483162};\\\", \\\"{x:855,y:656,t:1527873483179};\\\", \\\"{x:857,y:656,t:1527873483195};\\\", \\\"{x:858,y:656,t:1527873483212};\\\", \\\"{x:862,y:659,t:1527873483229};\\\", \\\"{x:869,y:662,t:1527873483245};\\\", \\\"{x:880,y:662,t:1527873483262};\\\", \\\"{x:888,y:663,t:1527873483278};\\\", \\\"{x:894,y:663,t:1527873483295};\\\", \\\"{x:896,y:663,t:1527873483312};\\\", \\\"{x:906,y:663,t:1527873483329};\\\", \\\"{x:926,y:663,t:1527873483345};\\\", \\\"{x:960,y:663,t:1527873483362};\\\", \\\"{x:999,y:663,t:1527873483378};\\\", \\\"{x:1039,y:663,t:1527873483395};\\\", \\\"{x:1106,y:663,t:1527873483411};\\\", \\\"{x:1194,y:673,t:1527873483428};\\\", \\\"{x:1325,y:681,t:1527873483445};\\\", \\\"{x:1500,y:683,t:1527873483462};\\\", \\\"{x:1638,y:683,t:1527873483479};\\\", \\\"{x:1726,y:679,t:1527873483495};\\\", \\\"{x:1769,y:670,t:1527873483512};\\\", \\\"{x:1782,y:668,t:1527873483528};\\\", \\\"{x:1783,y:668,t:1527873483545};\\\", \\\"{x:1779,y:670,t:1527873483725};\\\", \\\"{x:1770,y:673,t:1527873483732};\\\", \\\"{x:1761,y:675,t:1527873483745};\\\", \\\"{x:1741,y:683,t:1527873483762};\\\", \\\"{x:1732,y:686,t:1527873483779};\\\", \\\"{x:1724,y:689,t:1527873483795};\\\", \\\"{x:1715,y:694,t:1527873483812};\\\", \\\"{x:1712,y:696,t:1527873483829};\\\", \\\"{x:1710,y:698,t:1527873483845};\\\", \\\"{x:1708,y:699,t:1527873483862};\\\", \\\"{x:1708,y:700,t:1527873483880};\\\", \\\"{x:1707,y:700,t:1527873483895};\\\", \\\"{x:1706,y:701,t:1527873483912};\\\", \\\"{x:1704,y:707,t:1527873483929};\\\", \\\"{x:1701,y:710,t:1527873483945};\\\", \\\"{x:1700,y:711,t:1527873483972};\\\", \\\"{x:1699,y:712,t:1527873483987};\\\", \\\"{x:1698,y:713,t:1527873483996};\\\", \\\"{x:1693,y:718,t:1527873484012};\\\", \\\"{x:1690,y:724,t:1527873484029};\\\", \\\"{x:1689,y:730,t:1527873484045};\\\", \\\"{x:1687,y:736,t:1527873484062};\\\", \\\"{x:1685,y:745,t:1527873484080};\\\", \\\"{x:1685,y:752,t:1527873484095};\\\", \\\"{x:1685,y:758,t:1527873484112};\\\", \\\"{x:1682,y:761,t:1527873484129};\\\", \\\"{x:1679,y:768,t:1527873484145};\\\", \\\"{x:1677,y:774,t:1527873484162};\\\", \\\"{x:1675,y:776,t:1527873484179};\\\", \\\"{x:1673,y:778,t:1527873484195};\\\", \\\"{x:1671,y:780,t:1527873484211};\\\", \\\"{x:1667,y:781,t:1527873484230};\\\", \\\"{x:1659,y:782,t:1527873484246};\\\", \\\"{x:1645,y:783,t:1527873484263};\\\", \\\"{x:1627,y:785,t:1527873484279};\\\", \\\"{x:1615,y:785,t:1527873484295};\\\", \\\"{x:1604,y:786,t:1527873484312};\\\", \\\"{x:1589,y:786,t:1527873484329};\\\", \\\"{x:1578,y:786,t:1527873484345};\\\", \\\"{x:1565,y:786,t:1527873484363};\\\", \\\"{x:1558,y:786,t:1527873484378};\\\", \\\"{x:1554,y:786,t:1527873484395};\\\", \\\"{x:1552,y:786,t:1527873484412};\\\", \\\"{x:1552,y:785,t:1527873484429};\\\", \\\"{x:1551,y:785,t:1527873484452};\\\", \\\"{x:1550,y:784,t:1527873484462};\\\", \\\"{x:1548,y:781,t:1527873484479};\\\", \\\"{x:1547,y:780,t:1527873484500};\\\", \\\"{x:1546,y:779,t:1527873484512};\\\", \\\"{x:1545,y:777,t:1527873484529};\\\", \\\"{x:1544,y:776,t:1527873484545};\\\", \\\"{x:1542,y:775,t:1527873484562};\\\", \\\"{x:1536,y:772,t:1527873484578};\\\", \\\"{x:1532,y:769,t:1527873484595};\\\", \\\"{x:1525,y:765,t:1527873484612};\\\", \\\"{x:1521,y:763,t:1527873484629};\\\", \\\"{x:1518,y:761,t:1527873484646};\\\", \\\"{x:1514,y:760,t:1527873484662};\\\", \\\"{x:1509,y:755,t:1527873484679};\\\", \\\"{x:1501,y:748,t:1527873484695};\\\", \\\"{x:1493,y:743,t:1527873484712};\\\", \\\"{x:1488,y:740,t:1527873484729};\\\", \\\"{x:1484,y:736,t:1527873484745};\\\", \\\"{x:1483,y:733,t:1527873484762};\\\", \\\"{x:1480,y:730,t:1527873484779};\\\", \\\"{x:1477,y:725,t:1527873484795};\\\", \\\"{x:1469,y:717,t:1527873484812};\\\", \\\"{x:1461,y:709,t:1527873484829};\\\", \\\"{x:1454,y:704,t:1527873484845};\\\", \\\"{x:1452,y:700,t:1527873484862};\\\", \\\"{x:1450,y:697,t:1527873484879};\\\", \\\"{x:1450,y:694,t:1527873484895};\\\", \\\"{x:1448,y:691,t:1527873484913};\\\", \\\"{x:1445,y:690,t:1527873484953};\\\", \\\"{x:1444,y:690,t:1527873484972};\\\", \\\"{x:1443,y:689,t:1527873484988};\\\", \\\"{x:1441,y:688,t:1527873484995};\\\", \\\"{x:1436,y:683,t:1527873485012};\\\", \\\"{x:1424,y:675,t:1527873485029};\\\", \\\"{x:1411,y:666,t:1527873485045};\\\", \\\"{x:1403,y:663,t:1527873485062};\\\", \\\"{x:1400,y:662,t:1527873485079};\\\", \\\"{x:1399,y:662,t:1527873485095};\\\", \\\"{x:1398,y:662,t:1527873485112};\\\", \\\"{x:1397,y:661,t:1527873485148};\\\", \\\"{x:1397,y:660,t:1527873485164};\\\", \\\"{x:1394,y:659,t:1527873485180};\\\", \\\"{x:1392,y:658,t:1527873485195};\\\", \\\"{x:1390,y:658,t:1527873485211};\\\", \\\"{x:1386,y:658,t:1527873485229};\\\", \\\"{x:1383,y:658,t:1527873485245};\\\", \\\"{x:1378,y:658,t:1527873485262};\\\", \\\"{x:1373,y:658,t:1527873485280};\\\", \\\"{x:1366,y:663,t:1527873485295};\\\", \\\"{x:1361,y:672,t:1527873485312};\\\", \\\"{x:1357,y:676,t:1527873485329};\\\", \\\"{x:1354,y:680,t:1527873485346};\\\", \\\"{x:1353,y:685,t:1527873485363};\\\", \\\"{x:1352,y:691,t:1527873485380};\\\", \\\"{x:1352,y:698,t:1527873485395};\\\", \\\"{x:1353,y:705,t:1527873485413};\\\", \\\"{x:1354,y:706,t:1527873485460};\\\", \\\"{x:1354,y:707,t:1527873485540};\\\", \\\"{x:1354,y:708,t:1527873485548};\\\", \\\"{x:1355,y:708,t:1527873486156};\\\", \\\"{x:1356,y:708,t:1527873486180};\\\", \\\"{x:1357,y:707,t:1527873486195};\\\", \\\"{x:1360,y:705,t:1527873486212};\\\", \\\"{x:1363,y:704,t:1527873486229};\\\", \\\"{x:1370,y:702,t:1527873486245};\\\", \\\"{x:1374,y:699,t:1527873486262};\\\", \\\"{x:1379,y:696,t:1527873486280};\\\", \\\"{x:1380,y:696,t:1527873486295};\\\", \\\"{x:1381,y:696,t:1527873486313};\\\", \\\"{x:1382,y:696,t:1527873486329};\\\", \\\"{x:1385,y:696,t:1527873486345};\\\", \\\"{x:1387,y:694,t:1527873486363};\\\", \\\"{x:1389,y:694,t:1527873486379};\\\", \\\"{x:1390,y:694,t:1527873486412};\\\", \\\"{x:1403,y:694,t:1527873486430};\\\", \\\"{x:1426,y:696,t:1527873486445};\\\", \\\"{x:1451,y:699,t:1527873486462};\\\", \\\"{x:1462,y:700,t:1527873486479};\\\", \\\"{x:1465,y:700,t:1527873486495};\\\", \\\"{x:1465,y:701,t:1527873486588};\\\", \\\"{x:1464,y:701,t:1527873486612};\\\", \\\"{x:1462,y:701,t:1527873486629};\\\", \\\"{x:1456,y:701,t:1527873486645};\\\", \\\"{x:1451,y:701,t:1527873486662};\\\", \\\"{x:1447,y:701,t:1527873486680};\\\", \\\"{x:1444,y:701,t:1527873486695};\\\", \\\"{x:1442,y:701,t:1527873486712};\\\", \\\"{x:1440,y:701,t:1527873486729};\\\", \\\"{x:1437,y:701,t:1527873486745};\\\", \\\"{x:1430,y:701,t:1527873486763};\\\", \\\"{x:1422,y:699,t:1527873486779};\\\", \\\"{x:1415,y:698,t:1527873486795};\\\", \\\"{x:1409,y:698,t:1527873486812};\\\", \\\"{x:1408,y:698,t:1527873486830};\\\", \\\"{x:1407,y:697,t:1527873486885};\\\", \\\"{x:1406,y:696,t:1527873487012};\\\", \\\"{x:1407,y:695,t:1527873487172};\\\", \\\"{x:1408,y:695,t:1527873487180};\\\", \\\"{x:1410,y:694,t:1527873487195};\\\", \\\"{x:1411,y:693,t:1527873487212};\\\", \\\"{x:1413,y:692,t:1527873487276};\\\", \\\"{x:1414,y:692,t:1527873487340};\\\", \\\"{x:1415,y:692,t:1527873487356};\\\", \\\"{x:1417,y:692,t:1527873487364};\\\", \\\"{x:1421,y:692,t:1527873487379};\\\", \\\"{x:1432,y:692,t:1527873487395};\\\", \\\"{x:1451,y:692,t:1527873487411};\\\", \\\"{x:1455,y:692,t:1527873487429};\\\", \\\"{x:1455,y:691,t:1527873487492};\\\", \\\"{x:1456,y:691,t:1527873487564};\\\", \\\"{x:1457,y:691,t:1527873487700};\\\", \\\"{x:1459,y:691,t:1527873487724};\\\", \\\"{x:1461,y:691,t:1527873487732};\\\", \\\"{x:1468,y:690,t:1527873487745};\\\", \\\"{x:1477,y:690,t:1527873487762};\\\", \\\"{x:1482,y:690,t:1527873487779};\\\", \\\"{x:1485,y:688,t:1527873487795};\\\", \\\"{x:1486,y:688,t:1527873487972};\\\", \\\"{x:1486,y:689,t:1527873487996};\\\", \\\"{x:1486,y:690,t:1527873488012};\\\", \\\"{x:1487,y:691,t:1527873488036};\\\", \\\"{x:1488,y:692,t:1527873488046};\\\", \\\"{x:1489,y:693,t:1527873488236};\\\", \\\"{x:1490,y:694,t:1527873488260};\\\", \\\"{x:1491,y:694,t:1527873488276};\\\", \\\"{x:1493,y:694,t:1527873488284};\\\", \\\"{x:1498,y:695,t:1527873488295};\\\", \\\"{x:1508,y:696,t:1527873488312};\\\", \\\"{x:1522,y:699,t:1527873488329};\\\", \\\"{x:1529,y:699,t:1527873488345};\\\", \\\"{x:1531,y:699,t:1527873488362};\\\", \\\"{x:1532,y:699,t:1527873488444};\\\", \\\"{x:1533,y:699,t:1527873488508};\\\", \\\"{x:1534,y:700,t:1527873488524};\\\", \\\"{x:1535,y:700,t:1527873488572};\\\", \\\"{x:1537,y:700,t:1527873488580};\\\", \\\"{x:1540,y:700,t:1527873488596};\\\", \\\"{x:1541,y:700,t:1527873488612};\\\", \\\"{x:1542,y:700,t:1527873488668};\\\", \\\"{x:1543,y:700,t:1527873488680};\\\", \\\"{x:1547,y:700,t:1527873488695};\\\", \\\"{x:1551,y:700,t:1527873488712};\\\", \\\"{x:1552,y:700,t:1527873488729};\\\", \\\"{x:1553,y:700,t:1527873488796};\\\", \\\"{x:1555,y:700,t:1527873488884};\\\", \\\"{x:1556,y:700,t:1527873488900};\\\", \\\"{x:1557,y:700,t:1527873488916};\\\", \\\"{x:1559,y:700,t:1527873488931};\\\", \\\"{x:1563,y:700,t:1527873488948};\\\", \\\"{x:1566,y:700,t:1527873488963};\\\", \\\"{x:1573,y:700,t:1527873488979};\\\", \\\"{x:1577,y:700,t:1527873488995};\\\", \\\"{x:1580,y:700,t:1527873489012};\\\", \\\"{x:1581,y:700,t:1527873489052};\\\", \\\"{x:1584,y:701,t:1527873489068};\\\", \\\"{x:1585,y:701,t:1527873489084};\\\", \\\"{x:1586,y:701,t:1527873489124};\\\", \\\"{x:1587,y:701,t:1527873489172};\\\", \\\"{x:1588,y:701,t:1527873489220};\\\", \\\"{x:1589,y:701,t:1527873489230};\\\", \\\"{x:1591,y:701,t:1527873489245};\\\", \\\"{x:1594,y:701,t:1527873489263};\\\", \\\"{x:1598,y:701,t:1527873489279};\\\", \\\"{x:1599,y:700,t:1527873489296};\\\", \\\"{x:1600,y:700,t:1527873489313};\\\", \\\"{x:1601,y:700,t:1527873489348};\\\", \\\"{x:1602,y:700,t:1527873489362};\\\", \\\"{x:1604,y:700,t:1527873489379};\\\", \\\"{x:1606,y:700,t:1527873489396};\\\", \\\"{x:1608,y:699,t:1527873489412};\\\", \\\"{x:1609,y:699,t:1527873490117};\\\", \\\"{x:1610,y:699,t:1527873490156};\\\", \\\"{x:1611,y:699,t:1527873490436};\\\", \\\"{x:1612,y:699,t:1527873490459};\\\", \\\"{x:1612,y:698,t:1527873490475};\\\", \\\"{x:1613,y:698,t:1527873490756};\\\", \\\"{x:1614,y:698,t:1527873494293};\\\", \\\"{x:1615,y:698,t:1527873494301};\\\", \\\"{x:1616,y:698,t:1527873494325};\\\", \\\"{x:1618,y:699,t:1527873494349};\\\", \\\"{x:1619,y:699,t:1527873494363};\\\", \\\"{x:1620,y:705,t:1527873494382};\\\", \\\"{x:1621,y:711,t:1527873494396};\\\", \\\"{x:1623,y:713,t:1527873494413};\\\", \\\"{x:1623,y:714,t:1527873494430};\\\", \\\"{x:1624,y:718,t:1527873494446};\\\", \\\"{x:1626,y:727,t:1527873494463};\\\", \\\"{x:1627,y:739,t:1527873494480};\\\", \\\"{x:1627,y:753,t:1527873494497};\\\", \\\"{x:1627,y:770,t:1527873494513};\\\", \\\"{x:1622,y:778,t:1527873494531};\\\", \\\"{x:1622,y:782,t:1527873494546};\\\", \\\"{x:1622,y:785,t:1527873494563};\\\", \\\"{x:1622,y:791,t:1527873494580};\\\", \\\"{x:1622,y:800,t:1527873494596};\\\", \\\"{x:1618,y:815,t:1527873494613};\\\", \\\"{x:1617,y:819,t:1527873494630};\\\", \\\"{x:1617,y:820,t:1527873494646};\\\", \\\"{x:1617,y:821,t:1527873494664};\\\", \\\"{x:1617,y:822,t:1527873495005};\\\", \\\"{x:1616,y:824,t:1527873495061};\\\", \\\"{x:1615,y:824,t:1527873495077};\\\", \\\"{x:1614,y:826,t:1527873495101};\\\", \\\"{x:1613,y:827,t:1527873504877};\\\", \\\"{x:1605,y:828,t:1527873520822};\\\", \\\"{x:1553,y:824,t:1527873520832};\\\", \\\"{x:1445,y:780,t:1527873520849};\\\", \\\"{x:1425,y:770,t:1527873520866};\\\", \\\"{x:1423,y:770,t:1527873520883};\\\", \\\"{x:1418,y:765,t:1527873520898};\\\", \\\"{x:1413,y:764,t:1527873520915};\\\", \\\"{x:1341,y:755,t:1527873520933};\\\", \\\"{x:1263,y:755,t:1527873520949};\\\", \\\"{x:1209,y:755,t:1527873520966};\\\", \\\"{x:1189,y:755,t:1527873520982};\\\", \\\"{x:1184,y:755,t:1527873520998};\\\", \\\"{x:1180,y:750,t:1527873521173};\\\", \\\"{x:1157,y:727,t:1527873521182};\\\", \\\"{x:1092,y:682,t:1527873521198};\\\", \\\"{x:1010,y:645,t:1527873521215};\\\", \\\"{x:917,y:626,t:1527873521234};\\\", \\\"{x:847,y:617,t:1527873521248};\\\", \\\"{x:809,y:613,t:1527873521265};\\\", \\\"{x:789,y:609,t:1527873521280};\\\", \\\"{x:772,y:603,t:1527873521297};\\\", \\\"{x:760,y:599,t:1527873521313};\\\", \\\"{x:756,y:599,t:1527873521330};\\\", \\\"{x:741,y:592,t:1527873521347};\\\", \\\"{x:667,y:580,t:1527873521364};\\\", \\\"{x:570,y:568,t:1527873521381};\\\", \\\"{x:503,y:568,t:1527873521396};\\\", \\\"{x:487,y:568,t:1527873521414};\\\", \\\"{x:485,y:568,t:1527873521431};\\\", \\\"{x:486,y:566,t:1527873521548};\\\", \\\"{x:491,y:564,t:1527873521564};\\\", \\\"{x:497,y:560,t:1527873521582};\\\", \\\"{x:499,y:558,t:1527873521598};\\\", \\\"{x:500,y:553,t:1527873521614};\\\", \\\"{x:505,y:545,t:1527873521631};\\\", \\\"{x:517,y:535,t:1527873521647};\\\", \\\"{x:534,y:523,t:1527873521664};\\\", \\\"{x:550,y:513,t:1527873521682};\\\", \\\"{x:561,y:506,t:1527873521698};\\\", \\\"{x:569,y:503,t:1527873521714};\\\", \\\"{x:570,y:501,t:1527873521731};\\\", \\\"{x:570,y:500,t:1527873521748};\\\", \\\"{x:571,y:500,t:1527873521788};\\\", \\\"{x:573,y:500,t:1527873521804};\\\", \\\"{x:575,y:500,t:1527873521820};\\\", \\\"{x:576,y:500,t:1527873521852};\\\", \\\"{x:576,y:499,t:1527873521868};\\\", \\\"{x:578,y:499,t:1527873521884};\\\", \\\"{x:579,y:499,t:1527873521908};\\\", \\\"{x:582,y:499,t:1527873521917};\\\", \\\"{x:583,y:499,t:1527873521932};\\\", \\\"{x:584,y:499,t:1527873521972};\\\", \\\"{x:585,y:498,t:1527873521981};\\\", \\\"{x:586,y:498,t:1527873522004};\\\", \\\"{x:587,y:498,t:1527873522029};\\\", \\\"{x:588,y:498,t:1527873522044};\\\", \\\"{x:589,y:498,t:1527873522085};\\\", \\\"{x:590,y:498,t:1527873522098};\\\", \\\"{x:593,y:497,t:1527873522115};\\\", \\\"{x:598,y:497,t:1527873522131};\\\", \\\"{x:600,y:496,t:1527873522149};\\\", \\\"{x:602,y:495,t:1527873522204};\\\", \\\"{x:603,y:495,t:1527873522220};\\\", \\\"{x:604,y:495,t:1527873522420};\\\", \\\"{x:605,y:495,t:1527873522432};\\\", \\\"{x:605,y:497,t:1527873522449};\\\", \\\"{x:605,y:505,t:1527873522465};\\\", \\\"{x:605,y:514,t:1527873522481};\\\", \\\"{x:605,y:520,t:1527873522498};\\\", \\\"{x:606,y:530,t:1527873522516};\\\", \\\"{x:610,y:538,t:1527873522531};\\\", \\\"{x:618,y:554,t:1527873522548};\\\", \\\"{x:622,y:562,t:1527873522566};\\\", \\\"{x:622,y:565,t:1527873522581};\\\", \\\"{x:624,y:571,t:1527873522598};\\\", \\\"{x:625,y:573,t:1527873522615};\\\", \\\"{x:627,y:574,t:1527873522700};\\\", \\\"{x:627,y:575,t:1527873522715};\\\", \\\"{x:627,y:576,t:1527873522941};\\\", \\\"{x:625,y:576,t:1527873522988};\\\", \\\"{x:624,y:576,t:1527873523004};\\\", \\\"{x:623,y:577,t:1527873523015};\\\", \\\"{x:621,y:577,t:1527873523036};\\\", \\\"{x:620,y:577,t:1527873523052};\\\", \\\"{x:619,y:577,t:1527873523065};\\\", \\\"{x:618,y:577,t:1527873523101};\\\", \\\"{x:617,y:577,t:1527873523115};\\\", \\\"{x:616,y:577,t:1527873523132};\\\", \\\"{x:614,y:577,t:1527873523148};\\\", \\\"{x:614,y:578,t:1527873523388};\\\", \\\"{x:614,y:579,t:1527873523412};\\\", \\\"{x:614,y:580,t:1527873523452};\\\", \\\"{x:614,y:586,t:1527873523629};\\\", \\\"{x:614,y:592,t:1527873523638};\\\", \\\"{x:614,y:601,t:1527873523649};\\\", \\\"{x:614,y:610,t:1527873523666};\\\", \\\"{x:613,y:617,t:1527873523683};\\\", \\\"{x:610,y:624,t:1527873523699};\\\", \\\"{x:608,y:634,t:1527873523716};\\\", \\\"{x:605,y:646,t:1527873523732};\\\", \\\"{x:600,y:658,t:1527873523749};\\\", \\\"{x:592,y:672,t:1527873523766};\\\", \\\"{x:581,y:686,t:1527873523782};\\\", \\\"{x:570,y:692,t:1527873523799};\\\", \\\"{x:565,y:695,t:1527873523816};\\\", \\\"{x:563,y:696,t:1527873523832};\\\", \\\"{x:561,y:698,t:1527873523849};\\\", \\\"{x:558,y:701,t:1527873523866};\\\", \\\"{x:552,y:708,t:1527873523884};\\\", \\\"{x:543,y:714,t:1527873523900};\\\", \\\"{x:535,y:720,t:1527873523917};\\\", \\\"{x:534,y:721,t:1527873523934};\\\", \\\"{x:534,y:723,t:1527873523950};\\\", \\\"{x:534,y:727,t:1527873523967};\\\", \\\"{x:535,y:738,t:1527873523983};\\\", \\\"{x:535,y:744,t:1527873524000};\\\", \\\"{x:537,y:751,t:1527873524016};\\\", \\\"{x:537,y:753,t:1527873524033};\\\", \\\"{x:537,y:754,t:1527873524077};\\\", \\\"{x:536,y:754,t:1527873524173};\\\", \\\"{x:536,y:753,t:1527873524189};\\\", \\\"{x:535,y:753,t:1527873524200};\\\", \\\"{x:535,y:752,t:1527873524217};\\\", \\\"{x:535,y:750,t:1527873524234};\\\", \\\"{x:535,y:749,t:1527873524250};\\\", \\\"{x:535,y:748,t:1527873524269};\\\", \\\"{x:535,y:747,t:1527873524283};\\\", \\\"{x:535,y:743,t:1527873524300};\\\", \\\"{x:535,y:742,t:1527873524333};\\\" ] }, { \\\"rt\\\": 11517, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 489191, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"9BS72\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-2\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:535,y:741,t:1527873526356};\\\", \\\"{x:536,y:737,t:1527873526383};\\\", \\\"{x:538,y:736,t:1527873526389};\\\", \\\"{x:542,y:733,t:1527873526402};\\\", \\\"{x:551,y:730,t:1527873526419};\\\", \\\"{x:563,y:728,t:1527873526434};\\\", \\\"{x:570,y:727,t:1527873526452};\\\", \\\"{x:575,y:727,t:1527873526468};\\\", \\\"{x:575,y:726,t:1527873526484};\\\", \\\"{x:576,y:726,t:1527873526508};\\\", \\\"{x:578,y:726,t:1527873526813};\\\", \\\"{x:579,y:726,t:1527873526829};\\\", \\\"{x:581,y:726,t:1527873526845};\\\", \\\"{x:582,y:725,t:1527873526869};\\\", \\\"{x:585,y:724,t:1527873527799};\\\", \\\"{x:586,y:724,t:1527873527815};\\\", \\\"{x:587,y:724,t:1527873527822};\\\", \\\"{x:588,y:724,t:1527873527839};\\\", \\\"{x:591,y:724,t:1527873527856};\\\", \\\"{x:593,y:724,t:1527873527873};\\\", \\\"{x:595,y:725,t:1527873527889};\\\", \\\"{x:597,y:725,t:1527873527911};\\\", \\\"{x:600,y:727,t:1527873527923};\\\", \\\"{x:607,y:729,t:1527873527938};\\\", \\\"{x:614,y:730,t:1527873527956};\\\", \\\"{x:622,y:734,t:1527873527972};\\\", \\\"{x:635,y:738,t:1527873527989};\\\", \\\"{x:650,y:741,t:1527873528005};\\\", \\\"{x:667,y:746,t:1527873528023};\\\", \\\"{x:688,y:750,t:1527873528038};\\\", \\\"{x:716,y:755,t:1527873528056};\\\", \\\"{x:737,y:761,t:1527873528073};\\\", \\\"{x:760,y:765,t:1527873528089};\\\", \\\"{x:786,y:768,t:1527873528105};\\\", \\\"{x:811,y:773,t:1527873528123};\\\", \\\"{x:834,y:777,t:1527873528139};\\\", \\\"{x:868,y:784,t:1527873528155};\\\", \\\"{x:903,y:790,t:1527873528172};\\\", \\\"{x:932,y:796,t:1527873528190};\\\", \\\"{x:958,y:802,t:1527873528205};\\\", \\\"{x:977,y:806,t:1527873528222};\\\", \\\"{x:1005,y:814,t:1527873528240};\\\", \\\"{x:1026,y:819,t:1527873528256};\\\", \\\"{x:1047,y:824,t:1527873528273};\\\", \\\"{x:1062,y:828,t:1527873528290};\\\", \\\"{x:1073,y:833,t:1527873528307};\\\", \\\"{x:1086,y:836,t:1527873528323};\\\", \\\"{x:1104,y:840,t:1527873528340};\\\", \\\"{x:1127,y:850,t:1527873528355};\\\", \\\"{x:1145,y:857,t:1527873528373};\\\", \\\"{x:1162,y:860,t:1527873528390};\\\", \\\"{x:1174,y:863,t:1527873528406};\\\", \\\"{x:1187,y:867,t:1527873528423};\\\", \\\"{x:1203,y:871,t:1527873528440};\\\", \\\"{x:1212,y:873,t:1527873528456};\\\", \\\"{x:1220,y:876,t:1527873528473};\\\", \\\"{x:1228,y:879,t:1527873528490};\\\", \\\"{x:1232,y:881,t:1527873528506};\\\", \\\"{x:1240,y:884,t:1527873528523};\\\", \\\"{x:1247,y:885,t:1527873528540};\\\", \\\"{x:1254,y:889,t:1527873528556};\\\", \\\"{x:1256,y:889,t:1527873528573};\\\", \\\"{x:1263,y:894,t:1527873528590};\\\", \\\"{x:1270,y:899,t:1527873528607};\\\", \\\"{x:1278,y:904,t:1527873528623};\\\", \\\"{x:1284,y:910,t:1527873528640};\\\", \\\"{x:1286,y:910,t:1527873528656};\\\", \\\"{x:1287,y:911,t:1527873528673};\\\", \\\"{x:1288,y:912,t:1527873528690};\\\", \\\"{x:1292,y:915,t:1527873528707};\\\", \\\"{x:1293,y:916,t:1527873528723};\\\", \\\"{x:1294,y:919,t:1527873528740};\\\", \\\"{x:1295,y:920,t:1527873528757};\\\", \\\"{x:1296,y:922,t:1527873528773};\\\", \\\"{x:1297,y:923,t:1527873528790};\\\", \\\"{x:1298,y:925,t:1527873528807};\\\", \\\"{x:1300,y:929,t:1527873528824};\\\", \\\"{x:1302,y:931,t:1527873528840};\\\", \\\"{x:1303,y:933,t:1527873528857};\\\", \\\"{x:1304,y:933,t:1527873528873};\\\", \\\"{x:1304,y:934,t:1527873528890};\\\", \\\"{x:1305,y:936,t:1527873528928};\\\", \\\"{x:1307,y:936,t:1527873528943};\\\", \\\"{x:1309,y:937,t:1527873528956};\\\", \\\"{x:1314,y:939,t:1527873528972};\\\", \\\"{x:1319,y:939,t:1527873528990};\\\", \\\"{x:1322,y:939,t:1527873529006};\\\", \\\"{x:1324,y:939,t:1527873529047};\\\", \\\"{x:1325,y:939,t:1527873529071};\\\", \\\"{x:1327,y:939,t:1527873529087};\\\", \\\"{x:1328,y:939,t:1527873529185};\\\", \\\"{x:1330,y:939,t:1527873529232};\\\", \\\"{x:1331,y:940,t:1527873529248};\\\", \\\"{x:1331,y:941,t:1527873529272};\\\", \\\"{x:1333,y:941,t:1527873529280};\\\", \\\"{x:1334,y:942,t:1527873529290};\\\", \\\"{x:1335,y:943,t:1527873529307};\\\", \\\"{x:1337,y:944,t:1527873529328};\\\", \\\"{x:1337,y:945,t:1527873529340};\\\", \\\"{x:1338,y:946,t:1527873529360};\\\", \\\"{x:1341,y:950,t:1527873529376};\\\", \\\"{x:1342,y:951,t:1527873529390};\\\", \\\"{x:1342,y:952,t:1527873529407};\\\", \\\"{x:1343,y:954,t:1527873529424};\\\", \\\"{x:1344,y:956,t:1527873529448};\\\", \\\"{x:1345,y:957,t:1527873529504};\\\", \\\"{x:1346,y:957,t:1527873529671};\\\", \\\"{x:1347,y:958,t:1527873529711};\\\", \\\"{x:1348,y:959,t:1527873529724};\\\", \\\"{x:1348,y:960,t:1527873529984};\\\", \\\"{x:1349,y:960,t:1527873530056};\\\", \\\"{x:1350,y:960,t:1527873530401};\\\", \\\"{x:1346,y:959,t:1527873530592};\\\", \\\"{x:1338,y:954,t:1527873530607};\\\", \\\"{x:1323,y:940,t:1527873530625};\\\", \\\"{x:1278,y:923,t:1527873530641};\\\", \\\"{x:1212,y:896,t:1527873530658};\\\", \\\"{x:1145,y:877,t:1527873530676};\\\", \\\"{x:1110,y:867,t:1527873530691};\\\", \\\"{x:1097,y:864,t:1527873530708};\\\", \\\"{x:1091,y:862,t:1527873530725};\\\", \\\"{x:1087,y:861,t:1527873530741};\\\", \\\"{x:1085,y:860,t:1527873530758};\\\", \\\"{x:1084,y:858,t:1527873530775};\\\", \\\"{x:1082,y:858,t:1527873530808};\\\", \\\"{x:1081,y:858,t:1527873530848};\\\", \\\"{x:1081,y:857,t:1527873530858};\\\", \\\"{x:1076,y:857,t:1527873530875};\\\", \\\"{x:1064,y:852,t:1527873530891};\\\", \\\"{x:1047,y:848,t:1527873530909};\\\", \\\"{x:1023,y:840,t:1527873530925};\\\", \\\"{x:1001,y:834,t:1527873530942};\\\", \\\"{x:980,y:826,t:1527873530958};\\\", \\\"{x:961,y:821,t:1527873530975};\\\", \\\"{x:933,y:813,t:1527873530991};\\\", \\\"{x:912,y:808,t:1527873531007};\\\", \\\"{x:884,y:798,t:1527873531025};\\\", \\\"{x:842,y:787,t:1527873531042};\\\", \\\"{x:790,y:774,t:1527873531058};\\\", \\\"{x:754,y:766,t:1527873531075};\\\", \\\"{x:733,y:760,t:1527873531092};\\\", \\\"{x:719,y:756,t:1527873531108};\\\", \\\"{x:707,y:751,t:1527873531125};\\\", \\\"{x:695,y:747,t:1527873531142};\\\", \\\"{x:684,y:744,t:1527873531158};\\\", \\\"{x:669,y:740,t:1527873531175};\\\", \\\"{x:640,y:731,t:1527873531191};\\\", \\\"{x:624,y:725,t:1527873531208};\\\", \\\"{x:604,y:718,t:1527873531225};\\\", \\\"{x:579,y:709,t:1527873531242};\\\", \\\"{x:550,y:701,t:1527873531259};\\\", \\\"{x:523,y:695,t:1527873531275};\\\", \\\"{x:496,y:689,t:1527873531292};\\\", \\\"{x:464,y:683,t:1527873531309};\\\", \\\"{x:430,y:678,t:1527873531324};\\\", \\\"{x:398,y:669,t:1527873531344};\\\", \\\"{x:388,y:664,t:1527873531358};\\\", \\\"{x:386,y:661,t:1527873531391};\\\", \\\"{x:386,y:660,t:1527873531408};\\\", \\\"{x:384,y:658,t:1527873531425};\\\", \\\"{x:382,y:654,t:1527873531442};\\\", \\\"{x:380,y:651,t:1527873531459};\\\", \\\"{x:379,y:648,t:1527873531475};\\\", \\\"{x:379,y:646,t:1527873531491};\\\", \\\"{x:379,y:643,t:1527873531509};\\\", \\\"{x:378,y:638,t:1527873531527};\\\", \\\"{x:376,y:634,t:1527873531541};\\\", \\\"{x:372,y:626,t:1527873531559};\\\", \\\"{x:372,y:623,t:1527873531576};\\\", \\\"{x:370,y:619,t:1527873531591};\\\", \\\"{x:365,y:601,t:1527873531609};\\\", \\\"{x:359,y:581,t:1527873531626};\\\", \\\"{x:354,y:566,t:1527873531641};\\\", \\\"{x:353,y:561,t:1527873531659};\\\", \\\"{x:352,y:558,t:1527873531675};\\\", \\\"{x:352,y:556,t:1527873531692};\\\", \\\"{x:352,y:555,t:1527873531709};\\\", \\\"{x:352,y:554,t:1527873531799};\\\", \\\"{x:352,y:552,t:1527873531809};\\\", \\\"{x:352,y:549,t:1527873531826};\\\", \\\"{x:352,y:548,t:1527873531842};\\\", \\\"{x:352,y:547,t:1527873531859};\\\", \\\"{x:352,y:546,t:1527873531928};\\\", \\\"{x:352,y:545,t:1527873531992};\\\", \\\"{x:353,y:545,t:1527873532009};\\\", \\\"{x:354,y:543,t:1527873532031};\\\", \\\"{x:354,y:542,t:1527873532071};\\\", \\\"{x:354,y:541,t:1527873532207};\\\", \\\"{x:354,y:539,t:1527873532214};\\\", \\\"{x:354,y:537,t:1527873532226};\\\", \\\"{x:356,y:535,t:1527873532242};\\\", \\\"{x:357,y:534,t:1527873532258};\\\", \\\"{x:359,y:534,t:1527873532276};\\\", \\\"{x:360,y:534,t:1527873532292};\\\", \\\"{x:364,y:534,t:1527873532310};\\\", \\\"{x:371,y:537,t:1527873532326};\\\", \\\"{x:381,y:542,t:1527873532344};\\\", \\\"{x:383,y:542,t:1527873532360};\\\", \\\"{x:385,y:542,t:1527873532375};\\\", \\\"{x:386,y:542,t:1527873532527};\\\", \\\"{x:388,y:545,t:1527873532543};\\\", \\\"{x:389,y:547,t:1527873532561};\\\", \\\"{x:390,y:548,t:1527873532576};\\\", \\\"{x:391,y:551,t:1527873532592};\\\", \\\"{x:392,y:552,t:1527873532609};\\\", \\\"{x:393,y:552,t:1527873532625};\\\", \\\"{x:394,y:553,t:1527873532643};\\\", \\\"{x:397,y:556,t:1527873532660};\\\", \\\"{x:402,y:559,t:1527873532676};\\\", \\\"{x:412,y:563,t:1527873532693};\\\", \\\"{x:425,y:566,t:1527873532709};\\\", \\\"{x:440,y:567,t:1527873532726};\\\", \\\"{x:462,y:567,t:1527873532742};\\\", \\\"{x:479,y:567,t:1527873532759};\\\", \\\"{x:500,y:568,t:1527873532776};\\\", \\\"{x:527,y:568,t:1527873532793};\\\", \\\"{x:558,y:568,t:1527873532809};\\\", \\\"{x:586,y:568,t:1527873532827};\\\", \\\"{x:613,y:565,t:1527873532843};\\\", \\\"{x:625,y:563,t:1527873532859};\\\", \\\"{x:627,y:562,t:1527873532879};\\\", \\\"{x:629,y:561,t:1527873533063};\\\", \\\"{x:629,y:558,t:1527873533079};\\\", \\\"{x:629,y:556,t:1527873533095};\\\", \\\"{x:630,y:555,t:1527873533112};\\\", \\\"{x:634,y:548,t:1527873533128};\\\", \\\"{x:636,y:543,t:1527873533143};\\\", \\\"{x:637,y:539,t:1527873533160};\\\", \\\"{x:638,y:535,t:1527873533177};\\\", \\\"{x:638,y:534,t:1527873533192};\\\", \\\"{x:638,y:533,t:1527873533215};\\\", \\\"{x:637,y:532,t:1527873533231};\\\", \\\"{x:636,y:531,t:1527873533243};\\\", \\\"{x:633,y:530,t:1527873533259};\\\", \\\"{x:632,y:530,t:1527873533276};\\\", \\\"{x:631,y:530,t:1527873533303};\\\", \\\"{x:630,y:530,t:1527873533360};\\\", \\\"{x:639,y:530,t:1527873533379};\\\", \\\"{x:697,y:531,t:1527873533395};\\\", \\\"{x:795,y:535,t:1527873533412};\\\", \\\"{x:873,y:535,t:1527873533426};\\\", \\\"{x:920,y:535,t:1527873533444};\\\", \\\"{x:944,y:535,t:1527873533461};\\\", \\\"{x:947,y:535,t:1527873533476};\\\", \\\"{x:946,y:536,t:1527873533495};\\\", \\\"{x:937,y:537,t:1527873533511};\\\", \\\"{x:932,y:538,t:1527873533527};\\\", \\\"{x:930,y:540,t:1527873533544};\\\", \\\"{x:927,y:541,t:1527873533561};\\\", \\\"{x:919,y:544,t:1527873533578};\\\", \\\"{x:901,y:548,t:1527873533594};\\\", \\\"{x:876,y:552,t:1527873533611};\\\", \\\"{x:847,y:556,t:1527873533629};\\\", \\\"{x:827,y:557,t:1527873533643};\\\", \\\"{x:806,y:559,t:1527873533659};\\\", \\\"{x:796,y:559,t:1527873533676};\\\", \\\"{x:780,y:559,t:1527873533693};\\\", \\\"{x:754,y:559,t:1527873533710};\\\", \\\"{x:700,y:559,t:1527873533727};\\\", \\\"{x:658,y:559,t:1527873533743};\\\", \\\"{x:630,y:559,t:1527873533760};\\\", \\\"{x:616,y:559,t:1527873533777};\\\", \\\"{x:610,y:558,t:1527873533793};\\\", \\\"{x:603,y:555,t:1527873533811};\\\", \\\"{x:594,y:554,t:1527873533827};\\\", \\\"{x:591,y:554,t:1527873533844};\\\", \\\"{x:594,y:551,t:1527873533879};\\\", \\\"{x:599,y:549,t:1527873533894};\\\", \\\"{x:615,y:542,t:1527873533912};\\\", \\\"{x:645,y:534,t:1527873533927};\\\", \\\"{x:706,y:526,t:1527873533943};\\\", \\\"{x:769,y:521,t:1527873533961};\\\", \\\"{x:807,y:520,t:1527873533977};\\\", \\\"{x:825,y:518,t:1527873533994};\\\", \\\"{x:830,y:518,t:1527873534011};\\\", \\\"{x:831,y:518,t:1527873534071};\\\", \\\"{x:832,y:518,t:1527873534078};\\\", \\\"{x:833,y:518,t:1527873534093};\\\", \\\"{x:835,y:518,t:1527873534110};\\\", \\\"{x:836,y:517,t:1527873534128};\\\", \\\"{x:836,y:515,t:1527873534240};\\\", \\\"{x:836,y:514,t:1527873534248};\\\", \\\"{x:836,y:513,t:1527873534262};\\\", \\\"{x:837,y:512,t:1527873534278};\\\", \\\"{x:838,y:511,t:1527873534293};\\\", \\\"{x:840,y:509,t:1527873534311};\\\", \\\"{x:840,y:508,t:1527873534327};\\\", \\\"{x:837,y:510,t:1527873534575};\\\", \\\"{x:833,y:512,t:1527873534583};\\\", \\\"{x:828,y:516,t:1527873534594};\\\", \\\"{x:820,y:520,t:1527873534611};\\\", \\\"{x:812,y:525,t:1527873534628};\\\", \\\"{x:802,y:530,t:1527873534644};\\\", \\\"{x:792,y:534,t:1527873534661};\\\", \\\"{x:774,y:541,t:1527873534678};\\\", \\\"{x:738,y:551,t:1527873534694};\\\", \\\"{x:705,y:559,t:1527873534711};\\\", \\\"{x:676,y:565,t:1527873534728};\\\", \\\"{x:659,y:566,t:1527873534745};\\\", \\\"{x:653,y:566,t:1527873534760};\\\", \\\"{x:650,y:566,t:1527873534778};\\\", \\\"{x:644,y:570,t:1527873534795};\\\", \\\"{x:618,y:606,t:1527873534812};\\\", \\\"{x:604,y:628,t:1527873534828};\\\", \\\"{x:598,y:637,t:1527873534846};\\\", \\\"{x:594,y:639,t:1527873534862};\\\", \\\"{x:594,y:640,t:1527873534960};\\\", \\\"{x:593,y:640,t:1527873534967};\\\", \\\"{x:592,y:639,t:1527873535024};\\\", \\\"{x:592,y:635,t:1527873535031};\\\", \\\"{x:592,y:632,t:1527873535045};\\\", \\\"{x:589,y:627,t:1527873535063};\\\", \\\"{x:588,y:625,t:1527873535078};\\\", \\\"{x:584,y:624,t:1527873535095};\\\", \\\"{x:578,y:624,t:1527873535111};\\\", \\\"{x:568,y:624,t:1527873535128};\\\", \\\"{x:548,y:624,t:1527873535145};\\\", \\\"{x:526,y:625,t:1527873535162};\\\", \\\"{x:504,y:625,t:1527873535178};\\\", \\\"{x:478,y:623,t:1527873535196};\\\", \\\"{x:458,y:617,t:1527873535212};\\\", \\\"{x:436,y:615,t:1527873535228};\\\", \\\"{x:420,y:615,t:1527873535245};\\\", \\\"{x:401,y:615,t:1527873535262};\\\", \\\"{x:382,y:615,t:1527873535278};\\\", \\\"{x:372,y:613,t:1527873535296};\\\", \\\"{x:370,y:613,t:1527873535312};\\\", \\\"{x:369,y:613,t:1527873535328};\\\", \\\"{x:366,y:611,t:1527873535345};\\\", \\\"{x:358,y:609,t:1527873535362};\\\", \\\"{x:351,y:606,t:1527873535378};\\\", \\\"{x:348,y:605,t:1527873535395};\\\", \\\"{x:346,y:605,t:1527873535412};\\\", \\\"{x:338,y:604,t:1527873535429};\\\", \\\"{x:328,y:601,t:1527873535445};\\\", \\\"{x:316,y:597,t:1527873535464};\\\", \\\"{x:303,y:596,t:1527873535479};\\\", \\\"{x:289,y:599,t:1527873535496};\\\", \\\"{x:277,y:603,t:1527873535513};\\\", \\\"{x:269,y:608,t:1527873535529};\\\", \\\"{x:267,y:615,t:1527873535545};\\\", \\\"{x:267,y:617,t:1527873535562};\\\", \\\"{x:264,y:620,t:1527873535579};\\\", \\\"{x:261,y:620,t:1527873535595};\\\", \\\"{x:255,y:607,t:1527873535611};\\\", \\\"{x:253,y:606,t:1527873535848};\\\", \\\"{x:251,y:605,t:1527873535863};\\\", \\\"{x:246,y:603,t:1527873535879};\\\", \\\"{x:242,y:602,t:1527873535895};\\\", \\\"{x:242,y:601,t:1527873535912};\\\", \\\"{x:241,y:601,t:1527873535960};\\\", \\\"{x:239,y:600,t:1527873535993};\\\", \\\"{x:233,y:596,t:1527873536012};\\\", \\\"{x:224,y:590,t:1527873536029};\\\", \\\"{x:214,y:583,t:1527873536045};\\\", \\\"{x:210,y:579,t:1527873536062};\\\", \\\"{x:197,y:568,t:1527873536078};\\\", \\\"{x:178,y:559,t:1527873536096};\\\", \\\"{x:163,y:552,t:1527873536112};\\\", \\\"{x:161,y:550,t:1527873536129};\\\", \\\"{x:161,y:548,t:1527873536151};\\\", \\\"{x:161,y:547,t:1527873536264};\\\", \\\"{x:162,y:547,t:1527873536478};\\\", \\\"{x:168,y:548,t:1527873536496};\\\", \\\"{x:177,y:554,t:1527873536513};\\\", \\\"{x:201,y:562,t:1527873536529};\\\", \\\"{x:232,y:576,t:1527873536546};\\\", \\\"{x:269,y:592,t:1527873536563};\\\", \\\"{x:289,y:605,t:1527873536580};\\\", \\\"{x:301,y:612,t:1527873536596};\\\", \\\"{x:315,y:621,t:1527873536613};\\\", \\\"{x:340,y:645,t:1527873536629};\\\", \\\"{x:411,y:703,t:1527873536646};\\\", \\\"{x:542,y:791,t:1527873536663};\\\", \\\"{x:583,y:811,t:1527873536679};\\\", \\\"{x:598,y:816,t:1527873536696};\\\", \\\"{x:600,y:818,t:1527873536713};\\\", \\\"{x:601,y:818,t:1527873536807};\\\", \\\"{x:601,y:817,t:1527873536815};\\\", \\\"{x:601,y:815,t:1527873536830};\\\", \\\"{x:601,y:812,t:1527873536846};\\\", \\\"{x:603,y:798,t:1527873536862};\\\", \\\"{x:603,y:784,t:1527873536879};\\\", \\\"{x:603,y:773,t:1527873536896};\\\", \\\"{x:600,y:767,t:1527873536913};\\\", \\\"{x:596,y:764,t:1527873536930};\\\", \\\"{x:591,y:761,t:1527873536946};\\\", \\\"{x:587,y:759,t:1527873536963};\\\", \\\"{x:579,y:755,t:1527873536980};\\\", \\\"{x:572,y:750,t:1527873536997};\\\", \\\"{x:563,y:743,t:1527873537014};\\\", \\\"{x:559,y:743,t:1527873537030};\\\", \\\"{x:557,y:741,t:1527873537045};\\\", \\\"{x:555,y:739,t:1527873537071};\\\", \\\"{x:553,y:738,t:1527873537078};\\\", \\\"{x:551,y:737,t:1527873537095};\\\", \\\"{x:550,y:737,t:1527873537112};\\\", \\\"{x:548,y:736,t:1527873537129};\\\", \\\"{x:547,y:737,t:1527873537431};\\\", \\\"{x:547,y:739,t:1527873537623};\\\", \\\"{x:547,y:740,t:1527873537631};\\\", \\\"{x:547,y:741,t:1527873537720};\\\", \\\"{x:546,y:741,t:1527873537735};\\\", \\\"{x:545,y:741,t:1527873537747};\\\", \\\"{x:544,y:741,t:1527873537800};\\\", \\\"{x:543,y:741,t:1527873537831};\\\", \\\"{x:543,y:740,t:1527873537879};\\\", \\\"{x:543,y:739,t:1527873538255};\\\" ] }, { \\\"rt\\\": 8189, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 498622, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"9BS72\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:542,y:739,t:1527873538607};\\\", \\\"{x:541,y:739,t:1527873539608};\\\", \\\"{x:540,y:739,t:1527873539648};\\\", \\\"{x:539,y:739,t:1527873539672};\\\", \\\"{x:539,y:740,t:1527873539688};\\\", \\\"{x:538,y:740,t:1527873540864};\\\", \\\"{x:537,y:741,t:1527873540936};\\\", \\\"{x:538,y:741,t:1527873541120};\\\", \\\"{x:539,y:741,t:1527873541151};\\\", \\\"{x:541,y:741,t:1527873541184};\\\", \\\"{x:543,y:741,t:1527873541198};\\\", \\\"{x:546,y:742,t:1527873541215};\\\", \\\"{x:549,y:742,t:1527873541232};\\\", \\\"{x:556,y:742,t:1527873541249};\\\", \\\"{x:568,y:737,t:1527873541267};\\\", \\\"{x:577,y:732,t:1527873541281};\\\", \\\"{x:587,y:726,t:1527873541298};\\\", \\\"{x:593,y:724,t:1527873541316};\\\", \\\"{x:599,y:721,t:1527873541333};\\\", \\\"{x:608,y:719,t:1527873541350};\\\", \\\"{x:621,y:717,t:1527873541366};\\\", \\\"{x:642,y:715,t:1527873541383};\\\", \\\"{x:651,y:712,t:1527873541400};\\\", \\\"{x:660,y:710,t:1527873541416};\\\", \\\"{x:669,y:708,t:1527873541433};\\\", \\\"{x:675,y:708,t:1527873541451};\\\", \\\"{x:681,y:707,t:1527873541466};\\\", \\\"{x:687,y:706,t:1527873541483};\\\", \\\"{x:695,y:705,t:1527873541501};\\\", \\\"{x:703,y:705,t:1527873541517};\\\", \\\"{x:713,y:705,t:1527873541534};\\\", \\\"{x:723,y:705,t:1527873541551};\\\", \\\"{x:737,y:702,t:1527873541567};\\\", \\\"{x:757,y:700,t:1527873541583};\\\", \\\"{x:767,y:700,t:1527873541600};\\\", \\\"{x:778,y:700,t:1527873541617};\\\", \\\"{x:787,y:700,t:1527873541633};\\\", \\\"{x:801,y:700,t:1527873541650};\\\", \\\"{x:811,y:700,t:1527873541667};\\\", \\\"{x:822,y:700,t:1527873541683};\\\", \\\"{x:831,y:700,t:1527873541700};\\\", \\\"{x:839,y:700,t:1527873541718};\\\", \\\"{x:848,y:700,t:1527873541733};\\\", \\\"{x:854,y:700,t:1527873541750};\\\", \\\"{x:859,y:700,t:1527873541767};\\\", \\\"{x:861,y:700,t:1527873541784};\\\", \\\"{x:866,y:700,t:1527873541801};\\\", \\\"{x:882,y:700,t:1527873541818};\\\", \\\"{x:906,y:700,t:1527873541833};\\\", \\\"{x:928,y:700,t:1527873541850};\\\", \\\"{x:951,y:700,t:1527873541867};\\\", \\\"{x:973,y:700,t:1527873541884};\\\", \\\"{x:1001,y:700,t:1527873541901};\\\", \\\"{x:1033,y:700,t:1527873541917};\\\", \\\"{x:1094,y:700,t:1527873541933};\\\", \\\"{x:1177,y:700,t:1527873541951};\\\", \\\"{x:1248,y:700,t:1527873541968};\\\", \\\"{x:1282,y:700,t:1527873541984};\\\", \\\"{x:1306,y:700,t:1527873542001};\\\", \\\"{x:1323,y:698,t:1527873542018};\\\", \\\"{x:1333,y:695,t:1527873542033};\\\", \\\"{x:1334,y:695,t:1527873542051};\\\", \\\"{x:1337,y:693,t:1527873542096};\\\", \\\"{x:1341,y:692,t:1527873542103};\\\", \\\"{x:1348,y:691,t:1527873542117};\\\", \\\"{x:1357,y:689,t:1527873542134};\\\", \\\"{x:1360,y:689,t:1527873542151};\\\", \\\"{x:1360,y:690,t:1527873542456};\\\", \\\"{x:1360,y:692,t:1527873542467};\\\", \\\"{x:1360,y:693,t:1527873543551};\\\", \\\"{x:1359,y:694,t:1527873543568};\\\", \\\"{x:1358,y:695,t:1527873543584};\\\", \\\"{x:1357,y:696,t:1527873543607};\\\", \\\"{x:1355,y:696,t:1527873543639};\\\", \\\"{x:1354,y:698,t:1527873543655};\\\", \\\"{x:1353,y:698,t:1527873543681};\\\", \\\"{x:1353,y:699,t:1527873543710};\\\", \\\"{x:1352,y:701,t:1527873543727};\\\", \\\"{x:1352,y:702,t:1527873543742};\\\", \\\"{x:1351,y:702,t:1527873543759};\\\", \\\"{x:1350,y:703,t:1527873543775};\\\", \\\"{x:1348,y:704,t:1527873543815};\\\", \\\"{x:1348,y:705,t:1527873543823};\\\", \\\"{x:1345,y:705,t:1527873543836};\\\", \\\"{x:1339,y:708,t:1527873543851};\\\", \\\"{x:1328,y:709,t:1527873543868};\\\", \\\"{x:1311,y:711,t:1527873543885};\\\", \\\"{x:1288,y:711,t:1527873543902};\\\", \\\"{x:1257,y:711,t:1527873543919};\\\", \\\"{x:1176,y:711,t:1527873543935};\\\", \\\"{x:1095,y:711,t:1527873543951};\\\", \\\"{x:1031,y:711,t:1527873543969};\\\", \\\"{x:971,y:707,t:1527873543985};\\\", \\\"{x:911,y:704,t:1527873544003};\\\", \\\"{x:868,y:703,t:1527873544018};\\\", \\\"{x:824,y:697,t:1527873544036};\\\", \\\"{x:769,y:684,t:1527873544053};\\\", \\\"{x:709,y:672,t:1527873544069};\\\", \\\"{x:664,y:659,t:1527873544086};\\\", \\\"{x:614,y:646,t:1527873544103};\\\", \\\"{x:603,y:644,t:1527873544118};\\\", \\\"{x:570,y:630,t:1527873544135};\\\", \\\"{x:549,y:622,t:1527873544152};\\\", \\\"{x:526,y:612,t:1527873544168};\\\", \\\"{x:511,y:606,t:1527873544184};\\\", \\\"{x:506,y:603,t:1527873544202};\\\", \\\"{x:505,y:603,t:1527873544218};\\\", \\\"{x:502,y:602,t:1527873544235};\\\", \\\"{x:494,y:599,t:1527873544253};\\\", \\\"{x:485,y:595,t:1527873544268};\\\", \\\"{x:476,y:592,t:1527873544285};\\\", \\\"{x:470,y:590,t:1527873544302};\\\", \\\"{x:466,y:589,t:1527873544318};\\\", \\\"{x:455,y:586,t:1527873544335};\\\", \\\"{x:445,y:585,t:1527873544352};\\\", \\\"{x:436,y:584,t:1527873544369};\\\", \\\"{x:429,y:582,t:1527873544385};\\\", \\\"{x:425,y:581,t:1527873544402};\\\", \\\"{x:424,y:581,t:1527873544420};\\\", \\\"{x:423,y:581,t:1527873544463};\\\", \\\"{x:422,y:581,t:1527873544479};\\\", \\\"{x:421,y:581,t:1527873544487};\\\", \\\"{x:419,y:581,t:1527873544503};\\\", \\\"{x:414,y:581,t:1527873544519};\\\", \\\"{x:412,y:581,t:1527873544535};\\\", \\\"{x:411,y:581,t:1527873544552};\\\", \\\"{x:409,y:581,t:1527873544569};\\\", \\\"{x:408,y:581,t:1527873544586};\\\", \\\"{x:404,y:581,t:1527873544607};\\\", \\\"{x:402,y:581,t:1527873544619};\\\", \\\"{x:399,y:581,t:1527873544636};\\\", \\\"{x:397,y:581,t:1527873544652};\\\", \\\"{x:396,y:581,t:1527873544668};\\\", \\\"{x:395,y:581,t:1527873544928};\\\", \\\"{x:394,y:582,t:1527873544944};\\\", \\\"{x:392,y:583,t:1527873544967};\\\", \\\"{x:391,y:583,t:1527873544975};\\\", \\\"{x:388,y:583,t:1527873544986};\\\", \\\"{x:386,y:584,t:1527873545002};\\\", \\\"{x:383,y:585,t:1527873545019};\\\", \\\"{x:379,y:585,t:1527873545036};\\\", \\\"{x:372,y:586,t:1527873545052};\\\", \\\"{x:353,y:586,t:1527873545070};\\\", \\\"{x:324,y:586,t:1527873545087};\\\", \\\"{x:293,y:586,t:1527873545103};\\\", \\\"{x:249,y:586,t:1527873545121};\\\", \\\"{x:227,y:586,t:1527873545136};\\\", \\\"{x:211,y:586,t:1527873545153};\\\", \\\"{x:203,y:586,t:1527873545169};\\\", \\\"{x:202,y:585,t:1527873545408};\\\", \\\"{x:199,y:581,t:1527873545420};\\\", \\\"{x:197,y:577,t:1527873545437};\\\", \\\"{x:193,y:572,t:1527873545454};\\\", \\\"{x:190,y:569,t:1527873545471};\\\", \\\"{x:188,y:567,t:1527873545486};\\\", \\\"{x:187,y:566,t:1527873545503};\\\", \\\"{x:184,y:564,t:1527873545521};\\\", \\\"{x:180,y:561,t:1527873545537};\\\", \\\"{x:176,y:560,t:1527873545553};\\\", \\\"{x:176,y:559,t:1527873545569};\\\", \\\"{x:175,y:558,t:1527873545591};\\\", \\\"{x:174,y:557,t:1527873545606};\\\", \\\"{x:173,y:557,t:1527873545619};\\\", \\\"{x:173,y:556,t:1527873545637};\\\", \\\"{x:171,y:553,t:1527873545654};\\\", \\\"{x:167,y:547,t:1527873545669};\\\", \\\"{x:165,y:543,t:1527873545686};\\\", \\\"{x:164,y:542,t:1527873545703};\\\", \\\"{x:165,y:543,t:1527873546047};\\\", \\\"{x:167,y:546,t:1527873546055};\\\", \\\"{x:174,y:554,t:1527873546071};\\\", \\\"{x:193,y:572,t:1527873546087};\\\", \\\"{x:232,y:591,t:1527873546103};\\\", \\\"{x:259,y:602,t:1527873546121};\\\", \\\"{x:286,y:616,t:1527873546138};\\\", \\\"{x:326,y:630,t:1527873546153};\\\", \\\"{x:373,y:649,t:1527873546171};\\\", \\\"{x:411,y:663,t:1527873546188};\\\", \\\"{x:432,y:671,t:1527873546204};\\\", \\\"{x:443,y:676,t:1527873546220};\\\", \\\"{x:446,y:678,t:1527873546237};\\\", \\\"{x:447,y:678,t:1527873546270};\\\", \\\"{x:450,y:680,t:1527873546287};\\\", \\\"{x:453,y:685,t:1527873546303};\\\", \\\"{x:455,y:689,t:1527873546320};\\\", \\\"{x:460,y:695,t:1527873546341};\\\", \\\"{x:462,y:698,t:1527873546353};\\\", \\\"{x:464,y:699,t:1527873546370};\\\", \\\"{x:470,y:705,t:1527873546387};\\\", \\\"{x:484,y:717,t:1527873546403};\\\", \\\"{x:503,y:729,t:1527873546421};\\\", \\\"{x:513,y:734,t:1527873546437};\\\", \\\"{x:514,y:735,t:1527873546453};\\\", \\\"{x:514,y:734,t:1527873546976};\\\", \\\"{x:513,y:734,t:1527873547144};\\\", \\\"{x:512,y:734,t:1527873547464};\\\", \\\"{x:512,y:735,t:1527873547503};\\\" ] }, { \\\"rt\\\": 15054, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 514955, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"9BS72\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-4-Z \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:514,y:735,t:1527873549368};\\\", \\\"{x:516,y:734,t:1527873549375};\\\", \\\"{x:522,y:732,t:1527873549391};\\\", \\\"{x:527,y:729,t:1527873549408};\\\", \\\"{x:539,y:727,t:1527873549425};\\\", \\\"{x:547,y:724,t:1527873549442};\\\", \\\"{x:554,y:723,t:1527873549459};\\\", \\\"{x:560,y:723,t:1527873549475};\\\", \\\"{x:566,y:721,t:1527873549493};\\\", \\\"{x:570,y:721,t:1527873549508};\\\", \\\"{x:576,y:721,t:1527873549525};\\\", \\\"{x:579,y:720,t:1527873549542};\\\", \\\"{x:583,y:719,t:1527873549556};\\\", \\\"{x:586,y:719,t:1527873549572};\\\", \\\"{x:590,y:719,t:1527873549589};\\\", \\\"{x:599,y:716,t:1527873549607};\\\", \\\"{x:611,y:715,t:1527873549623};\\\", \\\"{x:620,y:712,t:1527873549640};\\\", \\\"{x:629,y:712,t:1527873549656};\\\", \\\"{x:637,y:712,t:1527873549672};\\\", \\\"{x:646,y:712,t:1527873549690};\\\", \\\"{x:657,y:712,t:1527873549706};\\\", \\\"{x:669,y:712,t:1527873549722};\\\", \\\"{x:684,y:711,t:1527873549740};\\\", \\\"{x:694,y:711,t:1527873549757};\\\", \\\"{x:705,y:711,t:1527873549772};\\\", \\\"{x:716,y:711,t:1527873549789};\\\", \\\"{x:737,y:711,t:1527873549807};\\\", \\\"{x:755,y:711,t:1527873549823};\\\", \\\"{x:769,y:711,t:1527873549840};\\\", \\\"{x:782,y:711,t:1527873549857};\\\", \\\"{x:792,y:711,t:1527873549874};\\\", \\\"{x:799,y:711,t:1527873549890};\\\", \\\"{x:808,y:711,t:1527873549907};\\\", \\\"{x:813,y:710,t:1527873549924};\\\", \\\"{x:817,y:710,t:1527873549940};\\\", \\\"{x:819,y:710,t:1527873549957};\\\", \\\"{x:820,y:710,t:1527873549973};\\\", \\\"{x:821,y:710,t:1527873549990};\\\", \\\"{x:826,y:710,t:1527873550007};\\\", \\\"{x:833,y:710,t:1527873550024};\\\", \\\"{x:838,y:710,t:1527873550040};\\\", \\\"{x:844,y:708,t:1527873550057};\\\", \\\"{x:847,y:708,t:1527873550074};\\\", \\\"{x:849,y:708,t:1527873550090};\\\", \\\"{x:851,y:707,t:1527873550107};\\\", \\\"{x:857,y:706,t:1527873550124};\\\", \\\"{x:866,y:704,t:1527873550140};\\\", \\\"{x:879,y:703,t:1527873550157};\\\", \\\"{x:892,y:702,t:1527873550175};\\\", \\\"{x:902,y:701,t:1527873550190};\\\", \\\"{x:907,y:700,t:1527873550207};\\\", \\\"{x:914,y:699,t:1527873550223};\\\", \\\"{x:918,y:698,t:1527873550240};\\\", \\\"{x:921,y:697,t:1527873550257};\\\", \\\"{x:926,y:697,t:1527873550273};\\\", \\\"{x:928,y:696,t:1527873550291};\\\", \\\"{x:933,y:696,t:1527873551416};\\\", \\\"{x:945,y:696,t:1527873551425};\\\", \\\"{x:977,y:696,t:1527873551441};\\\", \\\"{x:1017,y:698,t:1527873551459};\\\", \\\"{x:1063,y:699,t:1527873551475};\\\", \\\"{x:1099,y:699,t:1527873551492};\\\", \\\"{x:1130,y:701,t:1527873551508};\\\", \\\"{x:1152,y:702,t:1527873551525};\\\", \\\"{x:1174,y:703,t:1527873551541};\\\", \\\"{x:1190,y:703,t:1527873551559};\\\", \\\"{x:1203,y:703,t:1527873551575};\\\", \\\"{x:1207,y:703,t:1527873551590};\\\", \\\"{x:1210,y:703,t:1527873551607};\\\", \\\"{x:1218,y:704,t:1527873551625};\\\", \\\"{x:1232,y:706,t:1527873551641};\\\", \\\"{x:1252,y:706,t:1527873551658};\\\", \\\"{x:1269,y:706,t:1527873551674};\\\", \\\"{x:1277,y:707,t:1527873551691};\\\", \\\"{x:1281,y:707,t:1527873551707};\\\", \\\"{x:1283,y:708,t:1527873551725};\\\", \\\"{x:1290,y:709,t:1527873551741};\\\", \\\"{x:1311,y:715,t:1527873551758};\\\", \\\"{x:1351,y:736,t:1527873551775};\\\", \\\"{x:1363,y:746,t:1527873551791};\\\", \\\"{x:1367,y:752,t:1527873551808};\\\", \\\"{x:1368,y:758,t:1527873551825};\\\", \\\"{x:1368,y:760,t:1527873551842};\\\", \\\"{x:1368,y:762,t:1527873551858};\\\", \\\"{x:1368,y:765,t:1527873551875};\\\", \\\"{x:1368,y:766,t:1527873551903};\\\", \\\"{x:1368,y:769,t:1527873552680};\\\", \\\"{x:1359,y:771,t:1527873552692};\\\", \\\"{x:1349,y:777,t:1527873552709};\\\", \\\"{x:1341,y:784,t:1527873552726};\\\", \\\"{x:1332,y:787,t:1527873552742};\\\", \\\"{x:1317,y:793,t:1527873552760};\\\", \\\"{x:1303,y:797,t:1527873552775};\\\", \\\"{x:1287,y:803,t:1527873552792};\\\", \\\"{x:1272,y:808,t:1527873552810};\\\", \\\"{x:1260,y:814,t:1527873552827};\\\", \\\"{x:1248,y:820,t:1527873552843};\\\", \\\"{x:1241,y:822,t:1527873552859};\\\", \\\"{x:1238,y:822,t:1527873552876};\\\", \\\"{x:1238,y:823,t:1527873553120};\\\", \\\"{x:1238,y:824,t:1527873553135};\\\", \\\"{x:1238,y:825,t:1527873553280};\\\", \\\"{x:1238,y:827,t:1527873553296};\\\", \\\"{x:1240,y:829,t:1527873553376};\\\", \\\"{x:1243,y:830,t:1527873553393};\\\", \\\"{x:1245,y:830,t:1527873553409};\\\", \\\"{x:1246,y:832,t:1527873553426};\\\", \\\"{x:1247,y:832,t:1527873553455};\\\", \\\"{x:1250,y:832,t:1527873553760};\\\", \\\"{x:1259,y:834,t:1527873553776};\\\", \\\"{x:1280,y:836,t:1527873553793};\\\", \\\"{x:1308,y:841,t:1527873553810};\\\", \\\"{x:1332,y:844,t:1527873553827};\\\", \\\"{x:1354,y:849,t:1527873553843};\\\", \\\"{x:1373,y:851,t:1527873553860};\\\", \\\"{x:1385,y:853,t:1527873553877};\\\", \\\"{x:1395,y:854,t:1527873553893};\\\", \\\"{x:1401,y:854,t:1527873553910};\\\", \\\"{x:1405,y:855,t:1527873553927};\\\", \\\"{x:1409,y:855,t:1527873553944};\\\", \\\"{x:1411,y:855,t:1527873553960};\\\", \\\"{x:1416,y:855,t:1527873553975};\\\", \\\"{x:1430,y:855,t:1527873553993};\\\", \\\"{x:1445,y:855,t:1527873554010};\\\", \\\"{x:1456,y:855,t:1527873554026};\\\", \\\"{x:1461,y:855,t:1527873554043};\\\", \\\"{x:1466,y:855,t:1527873554060};\\\", \\\"{x:1470,y:855,t:1527873554076};\\\", \\\"{x:1474,y:855,t:1527873554093};\\\", \\\"{x:1482,y:855,t:1527873554110};\\\", \\\"{x:1490,y:855,t:1527873554126};\\\", \\\"{x:1498,y:855,t:1527873554143};\\\", \\\"{x:1501,y:855,t:1527873554160};\\\", \\\"{x:1504,y:855,t:1527873554176};\\\", \\\"{x:1507,y:855,t:1527873554193};\\\", \\\"{x:1513,y:855,t:1527873554210};\\\", \\\"{x:1521,y:855,t:1527873554227};\\\", \\\"{x:1533,y:855,t:1527873554243};\\\", \\\"{x:1538,y:855,t:1527873554260};\\\", \\\"{x:1541,y:854,t:1527873554277};\\\", \\\"{x:1542,y:854,t:1527873554368};\\\", \\\"{x:1543,y:853,t:1527873554378};\\\", \\\"{x:1549,y:849,t:1527873554393};\\\", \\\"{x:1552,y:846,t:1527873554409};\\\", \\\"{x:1557,y:843,t:1527873554427};\\\", \\\"{x:1569,y:838,t:1527873554442};\\\", \\\"{x:1578,y:831,t:1527873554460};\\\", \\\"{x:1586,y:824,t:1527873554477};\\\", \\\"{x:1591,y:817,t:1527873554493};\\\", \\\"{x:1596,y:809,t:1527873554510};\\\", \\\"{x:1605,y:794,t:1527873554527};\\\", \\\"{x:1613,y:782,t:1527873554543};\\\", \\\"{x:1625,y:769,t:1527873554560};\\\", \\\"{x:1629,y:761,t:1527873554577};\\\", \\\"{x:1631,y:758,t:1527873554593};\\\", \\\"{x:1633,y:757,t:1527873554610};\\\", \\\"{x:1633,y:755,t:1527873554626};\\\", \\\"{x:1633,y:753,t:1527873554643};\\\", \\\"{x:1637,y:748,t:1527873554660};\\\", \\\"{x:1639,y:743,t:1527873554677};\\\", \\\"{x:1639,y:741,t:1527873554695};\\\", \\\"{x:1639,y:739,t:1527873554711};\\\", \\\"{x:1639,y:737,t:1527873554727};\\\", \\\"{x:1639,y:736,t:1527873554744};\\\", \\\"{x:1639,y:734,t:1527873554761};\\\", \\\"{x:1639,y:732,t:1527873554777};\\\", \\\"{x:1639,y:729,t:1527873554794};\\\", \\\"{x:1639,y:725,t:1527873554810};\\\", \\\"{x:1639,y:723,t:1527873554827};\\\", \\\"{x:1639,y:721,t:1527873554844};\\\", \\\"{x:1638,y:719,t:1527873554861};\\\", \\\"{x:1637,y:718,t:1527873554880};\\\", \\\"{x:1636,y:717,t:1527873554895};\\\", \\\"{x:1635,y:713,t:1527873554911};\\\", \\\"{x:1606,y:671,t:1527873554928};\\\", \\\"{x:1585,y:654,t:1527873554943};\\\", \\\"{x:1574,y:647,t:1527873554960};\\\", \\\"{x:1570,y:645,t:1527873554978};\\\", \\\"{x:1569,y:645,t:1527873555248};\\\", \\\"{x:1569,y:647,t:1527873555261};\\\", \\\"{x:1570,y:650,t:1527873555278};\\\", \\\"{x:1572,y:651,t:1527873555294};\\\", \\\"{x:1573,y:653,t:1527873555392};\\\", \\\"{x:1574,y:654,t:1527873555400};\\\", \\\"{x:1575,y:655,t:1527873555411};\\\", \\\"{x:1577,y:656,t:1527873555427};\\\", \\\"{x:1578,y:657,t:1527873555444};\\\", \\\"{x:1578,y:658,t:1527873555472};\\\", \\\"{x:1580,y:659,t:1527873555496};\\\", \\\"{x:1581,y:660,t:1527873555511};\\\", \\\"{x:1582,y:661,t:1527873555528};\\\", \\\"{x:1583,y:662,t:1527873555544};\\\", \\\"{x:1583,y:663,t:1527873555624};\\\", \\\"{x:1585,y:665,t:1527873555632};\\\", \\\"{x:1587,y:668,t:1527873555645};\\\", \\\"{x:1594,y:672,t:1527873555661};\\\", \\\"{x:1597,y:675,t:1527873555679};\\\", \\\"{x:1600,y:677,t:1527873555695};\\\", \\\"{x:1600,y:678,t:1527873555712};\\\", \\\"{x:1601,y:678,t:1527873555728};\\\", \\\"{x:1601,y:679,t:1527873555752};\\\", \\\"{x:1601,y:680,t:1527873555761};\\\", \\\"{x:1604,y:684,t:1527873555778};\\\", \\\"{x:1605,y:687,t:1527873555794};\\\", \\\"{x:1606,y:689,t:1527873555811};\\\", \\\"{x:1608,y:691,t:1527873555828};\\\", \\\"{x:1608,y:692,t:1527873555879};\\\", \\\"{x:1610,y:694,t:1527873555895};\\\", \\\"{x:1610,y:695,t:1527873555910};\\\", \\\"{x:1610,y:697,t:1527873555927};\\\", \\\"{x:1611,y:698,t:1527873555991};\\\", \\\"{x:1611,y:699,t:1527873556192};\\\", \\\"{x:1612,y:699,t:1527873556240};\\\", \\\"{x:1613,y:699,t:1527873556312};\\\", \\\"{x:1613,y:700,t:1527873556359};\\\", \\\"{x:1614,y:700,t:1527873556408};\\\", \\\"{x:1616,y:700,t:1527873557175};\\\", \\\"{x:1617,y:700,t:1527873557184};\\\", \\\"{x:1618,y:702,t:1527873557216};\\\", \\\"{x:1596,y:708,t:1527873560528};\\\", \\\"{x:1544,y:718,t:1527873560536};\\\", \\\"{x:1456,y:720,t:1527873560548};\\\", \\\"{x:1210,y:690,t:1527873560564};\\\", \\\"{x:937,y:654,t:1527873560582};\\\", \\\"{x:697,y:623,t:1527873560599};\\\", \\\"{x:531,y:597,t:1527873560614};\\\", \\\"{x:387,y:557,t:1527873560631};\\\", \\\"{x:341,y:541,t:1527873560649};\\\", \\\"{x:334,y:536,t:1527873560664};\\\", \\\"{x:333,y:535,t:1527873560682};\\\", \\\"{x:333,y:534,t:1527873560699};\\\", \\\"{x:333,y:532,t:1527873560715};\\\", \\\"{x:333,y:531,t:1527873560732};\\\", \\\"{x:335,y:527,t:1527873560748};\\\", \\\"{x:346,y:520,t:1527873560766};\\\", \\\"{x:376,y:513,t:1527873560783};\\\", \\\"{x:462,y:496,t:1527873560799};\\\", \\\"{x:519,y:485,t:1527873560815};\\\", \\\"{x:575,y:477,t:1527873560832};\\\", \\\"{x:617,y:477,t:1527873560849};\\\", \\\"{x:642,y:477,t:1527873560865};\\\", \\\"{x:652,y:477,t:1527873560882};\\\", \\\"{x:654,y:477,t:1527873560899};\\\", \\\"{x:651,y:479,t:1527873561000};\\\", \\\"{x:645,y:486,t:1527873561016};\\\", \\\"{x:637,y:490,t:1527873561035};\\\", \\\"{x:631,y:493,t:1527873561049};\\\", \\\"{x:629,y:495,t:1527873561066};\\\", \\\"{x:627,y:496,t:1527873561082};\\\", \\\"{x:626,y:496,t:1527873561134};\\\", \\\"{x:625,y:497,t:1527873561149};\\\", \\\"{x:624,y:497,t:1527873561167};\\\", \\\"{x:623,y:497,t:1527873561488};\\\", \\\"{x:621,y:497,t:1527873561511};\\\", \\\"{x:620,y:497,t:1527873561519};\\\", \\\"{x:618,y:497,t:1527873561543};\\\", \\\"{x:617,y:497,t:1527873561695};\\\", \\\"{x:617,y:497,t:1527873561747};\\\", \\\"{x:617,y:498,t:1527873561790};\\\", \\\"{x:617,y:503,t:1527873561799};\\\", \\\"{x:617,y:518,t:1527873561817};\\\", \\\"{x:617,y:528,t:1527873561834};\\\", \\\"{x:617,y:535,t:1527873561849};\\\", \\\"{x:617,y:545,t:1527873561867};\\\", \\\"{x:619,y:559,t:1527873561884};\\\", \\\"{x:619,y:566,t:1527873561900};\\\", \\\"{x:619,y:567,t:1527873561916};\\\", \\\"{x:619,y:568,t:1527873561933};\\\", \\\"{x:619,y:569,t:1527873561951};\\\", \\\"{x:619,y:570,t:1527873561966};\\\", \\\"{x:619,y:571,t:1527873561983};\\\", \\\"{x:619,y:573,t:1527873561999};\\\", \\\"{x:618,y:574,t:1527873562017};\\\", \\\"{x:618,y:577,t:1527873562033};\\\", \\\"{x:617,y:578,t:1527873562049};\\\", \\\"{x:616,y:578,t:1527873562104};\\\", \\\"{x:616,y:580,t:1527873562390};\\\", \\\"{x:614,y:581,t:1527873562400};\\\", \\\"{x:611,y:583,t:1527873562416};\\\", \\\"{x:609,y:585,t:1527873562433};\\\", \\\"{x:603,y:590,t:1527873562450};\\\", \\\"{x:592,y:601,t:1527873562466};\\\", \\\"{x:566,y:626,t:1527873562483};\\\", \\\"{x:532,y:659,t:1527873562501};\\\", \\\"{x:522,y:675,t:1527873562516};\\\", \\\"{x:520,y:680,t:1527873562533};\\\", \\\"{x:520,y:682,t:1527873562599};\\\", \\\"{x:520,y:683,t:1527873562607};\\\", \\\"{x:520,y:685,t:1527873562617};\\\", \\\"{x:520,y:690,t:1527873562634};\\\", \\\"{x:520,y:694,t:1527873562651};\\\", \\\"{x:520,y:696,t:1527873562667};\\\", \\\"{x:520,y:697,t:1527873562683};\\\", \\\"{x:520,y:703,t:1527873562701};\\\", \\\"{x:520,y:718,t:1527873562717};\\\", \\\"{x:520,y:731,t:1527873562735};\\\", \\\"{x:522,y:741,t:1527873562751};\\\", \\\"{x:522,y:743,t:1527873562766};\\\", \\\"{x:522,y:744,t:1527873562832};\\\", \\\"{x:522,y:745,t:1527873562839};\\\" ] }, { \\\"rt\\\": 26332, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 542605, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"9BS72\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-L \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:523,y:745,t:1527873564502};\\\", \\\"{x:526,y:741,t:1527873564519};\\\", \\\"{x:527,y:739,t:1527873565344};\\\", \\\"{x:529,y:738,t:1527873565359};\\\", \\\"{x:530,y:737,t:1527873565367};\\\", \\\"{x:533,y:734,t:1527873565385};\\\", \\\"{x:533,y:733,t:1527873565401};\\\", \\\"{x:534,y:731,t:1527873565418};\\\", \\\"{x:536,y:730,t:1527873565434};\\\", \\\"{x:538,y:728,t:1527873565451};\\\", \\\"{x:540,y:725,t:1527873565468};\\\", \\\"{x:541,y:721,t:1527873565484};\\\", \\\"{x:544,y:714,t:1527873565502};\\\", \\\"{x:549,y:708,t:1527873565517};\\\", \\\"{x:563,y:694,t:1527873565536};\\\", \\\"{x:579,y:687,t:1527873565553};\\\", \\\"{x:608,y:675,t:1527873565569};\\\", \\\"{x:658,y:661,t:1527873565586};\\\", \\\"{x:712,y:643,t:1527873565603};\\\", \\\"{x:785,y:620,t:1527873565620};\\\", \\\"{x:857,y:600,t:1527873565637};\\\", \\\"{x:926,y:582,t:1527873565653};\\\", \\\"{x:1005,y:566,t:1527873565669};\\\", \\\"{x:1100,y:550,t:1527873565686};\\\", \\\"{x:1265,y:524,t:1527873565702};\\\", \\\"{x:1368,y:510,t:1527873565719};\\\", \\\"{x:1426,y:502,t:1527873565735};\\\", \\\"{x:1464,y:495,t:1527873565753};\\\", \\\"{x:1492,y:493,t:1527873565770};\\\", \\\"{x:1514,y:492,t:1527873565786};\\\", \\\"{x:1527,y:490,t:1527873565803};\\\", \\\"{x:1536,y:488,t:1527873565819};\\\", \\\"{x:1538,y:488,t:1527873565837};\\\", \\\"{x:1539,y:488,t:1527873565853};\\\", \\\"{x:1543,y:487,t:1527873565870};\\\", \\\"{x:1550,y:487,t:1527873565887};\\\", \\\"{x:1569,y:487,t:1527873565904};\\\", \\\"{x:1578,y:487,t:1527873565920};\\\", \\\"{x:1582,y:487,t:1527873565937};\\\", \\\"{x:1586,y:487,t:1527873565954};\\\", \\\"{x:1590,y:490,t:1527873565970};\\\", \\\"{x:1595,y:498,t:1527873565987};\\\", \\\"{x:1601,y:507,t:1527873566003};\\\", \\\"{x:1607,y:515,t:1527873566020};\\\", \\\"{x:1610,y:519,t:1527873566037};\\\", \\\"{x:1611,y:521,t:1527873566053};\\\", \\\"{x:1612,y:523,t:1527873566070};\\\", \\\"{x:1612,y:525,t:1527873566087};\\\", \\\"{x:1612,y:526,t:1527873566104};\\\", \\\"{x:1612,y:527,t:1527873566152};\\\", \\\"{x:1612,y:528,t:1527873566160};\\\", \\\"{x:1612,y:529,t:1527873566170};\\\", \\\"{x:1611,y:530,t:1527873566187};\\\", \\\"{x:1610,y:530,t:1527873566203};\\\", \\\"{x:1608,y:530,t:1527873566305};\\\", \\\"{x:1604,y:532,t:1527873566320};\\\", \\\"{x:1600,y:533,t:1527873566337};\\\", \\\"{x:1595,y:534,t:1527873566354};\\\", \\\"{x:1592,y:536,t:1527873566370};\\\", \\\"{x:1584,y:539,t:1527873566387};\\\", \\\"{x:1578,y:543,t:1527873566404};\\\", \\\"{x:1572,y:552,t:1527873566420};\\\", \\\"{x:1566,y:565,t:1527873566437};\\\", \\\"{x:1559,y:585,t:1527873566454};\\\", \\\"{x:1552,y:606,t:1527873566470};\\\", \\\"{x:1546,y:624,t:1527873566487};\\\", \\\"{x:1542,y:633,t:1527873566503};\\\", \\\"{x:1537,y:639,t:1527873566520};\\\", \\\"{x:1535,y:643,t:1527873566537};\\\", \\\"{x:1532,y:650,t:1527873566554};\\\", \\\"{x:1530,y:658,t:1527873566570};\\\", \\\"{x:1522,y:669,t:1527873566586};\\\", \\\"{x:1515,y:676,t:1527873566604};\\\", \\\"{x:1511,y:679,t:1527873566620};\\\", \\\"{x:1506,y:681,t:1527873566636};\\\", \\\"{x:1501,y:685,t:1527873566653};\\\", \\\"{x:1491,y:694,t:1527873566670};\\\", \\\"{x:1479,y:701,t:1527873566687};\\\", \\\"{x:1465,y:710,t:1527873566705};\\\", \\\"{x:1462,y:711,t:1527873566721};\\\", \\\"{x:1458,y:717,t:1527873566737};\\\", \\\"{x:1457,y:735,t:1527873566754};\\\", \\\"{x:1455,y:754,t:1527873566771};\\\", \\\"{x:1452,y:775,t:1527873566786};\\\", \\\"{x:1444,y:799,t:1527873566804};\\\", \\\"{x:1433,y:828,t:1527873566821};\\\", \\\"{x:1419,y:855,t:1527873566836};\\\", \\\"{x:1417,y:865,t:1527873566854};\\\", \\\"{x:1416,y:867,t:1527873566871};\\\", \\\"{x:1415,y:868,t:1527873566887};\\\", \\\"{x:1415,y:873,t:1527873566905};\\\", \\\"{x:1414,y:889,t:1527873566920};\\\", \\\"{x:1414,y:905,t:1527873566936};\\\", \\\"{x:1414,y:914,t:1527873566954};\\\", \\\"{x:1413,y:917,t:1527873566970};\\\", \\\"{x:1413,y:919,t:1527873566987};\\\", \\\"{x:1413,y:920,t:1527873567064};\\\", \\\"{x:1413,y:922,t:1527873567071};\\\", \\\"{x:1414,y:929,t:1527873567087};\\\", \\\"{x:1422,y:942,t:1527873567104};\\\", \\\"{x:1422,y:943,t:1527873567121};\\\", \\\"{x:1424,y:943,t:1527873567368};\\\", \\\"{x:1426,y:943,t:1527873567384};\\\", \\\"{x:1429,y:943,t:1527873567391};\\\", \\\"{x:1431,y:943,t:1527873567405};\\\", \\\"{x:1438,y:943,t:1527873567421};\\\", \\\"{x:1446,y:943,t:1527873567438};\\\", \\\"{x:1464,y:943,t:1527873567454};\\\", \\\"{x:1506,y:933,t:1527873567471};\\\", \\\"{x:1537,y:929,t:1527873567488};\\\", \\\"{x:1561,y:925,t:1527873567505};\\\", \\\"{x:1569,y:924,t:1527873567522};\\\", \\\"{x:1570,y:924,t:1527873567538};\\\", \\\"{x:1570,y:926,t:1527873567768};\\\", \\\"{x:1568,y:929,t:1527873567775};\\\", \\\"{x:1566,y:931,t:1527873567788};\\\", \\\"{x:1565,y:933,t:1527873567804};\\\", \\\"{x:1564,y:935,t:1527873567821};\\\", \\\"{x:1563,y:935,t:1527873567838};\\\", \\\"{x:1562,y:936,t:1527873567855};\\\", \\\"{x:1562,y:938,t:1527873567871};\\\", \\\"{x:1561,y:940,t:1527873567887};\\\", \\\"{x:1560,y:940,t:1527873567904};\\\", \\\"{x:1559,y:941,t:1527873567921};\\\", \\\"{x:1558,y:943,t:1527873567937};\\\", \\\"{x:1557,y:945,t:1527873567954};\\\", \\\"{x:1556,y:946,t:1527873567970};\\\", \\\"{x:1556,y:948,t:1527873568360};\\\", \\\"{x:1556,y:949,t:1527873568372};\\\", \\\"{x:1556,y:950,t:1527873568388};\\\", \\\"{x:1556,y:951,t:1527873568405};\\\", \\\"{x:1556,y:952,t:1527873568422};\\\", \\\"{x:1555,y:952,t:1527873568480};\\\", \\\"{x:1555,y:953,t:1527873568560};\\\", \\\"{x:1555,y:954,t:1527873568616};\\\", \\\"{x:1555,y:955,t:1527873568920};\\\", \\\"{x:1555,y:956,t:1527873568944};\\\", \\\"{x:1555,y:957,t:1527873568955};\\\", \\\"{x:1555,y:958,t:1527873568972};\\\", \\\"{x:1554,y:959,t:1527873568990};\\\", \\\"{x:1554,y:958,t:1527873570744};\\\", \\\"{x:1554,y:957,t:1527873570768};\\\", \\\"{x:1554,y:955,t:1527873570776};\\\", \\\"{x:1554,y:954,t:1527873570790};\\\", \\\"{x:1553,y:951,t:1527873570806};\\\", \\\"{x:1552,y:947,t:1527873570823};\\\", \\\"{x:1552,y:946,t:1527873570839};\\\", \\\"{x:1552,y:943,t:1527873570857};\\\", \\\"{x:1552,y:938,t:1527873570874};\\\", \\\"{x:1552,y:933,t:1527873570890};\\\", \\\"{x:1552,y:931,t:1527873570907};\\\", \\\"{x:1549,y:929,t:1527873570923};\\\", \\\"{x:1548,y:922,t:1527873570940};\\\", \\\"{x:1546,y:920,t:1527873570957};\\\", \\\"{x:1545,y:919,t:1527873570974};\\\", \\\"{x:1545,y:918,t:1527873570991};\\\", \\\"{x:1543,y:915,t:1527873571007};\\\", \\\"{x:1542,y:911,t:1527873571024};\\\", \\\"{x:1542,y:910,t:1527873571040};\\\", \\\"{x:1541,y:909,t:1527873571087};\\\", \\\"{x:1541,y:908,t:1527873571105};\\\", \\\"{x:1541,y:907,t:1527873571127};\\\", \\\"{x:1540,y:906,t:1527873571152};\\\", \\\"{x:1540,y:904,t:1527873571248};\\\", \\\"{x:1540,y:903,t:1527873571319};\\\", \\\"{x:1540,y:901,t:1527873571367};\\\", \\\"{x:1540,y:900,t:1527873571408};\\\", \\\"{x:1540,y:899,t:1527873572432};\\\", \\\"{x:1542,y:887,t:1527873572441};\\\", \\\"{x:1548,y:858,t:1527873572457};\\\", \\\"{x:1551,y:841,t:1527873572475};\\\", \\\"{x:1551,y:828,t:1527873572491};\\\", \\\"{x:1551,y:813,t:1527873572507};\\\", \\\"{x:1551,y:812,t:1527873572525};\\\", \\\"{x:1550,y:813,t:1527873572767};\\\", \\\"{x:1550,y:815,t:1527873572775};\\\", \\\"{x:1550,y:819,t:1527873572791};\\\", \\\"{x:1550,y:821,t:1527873572808};\\\", \\\"{x:1549,y:823,t:1527873572824};\\\", \\\"{x:1549,y:824,t:1527873572841};\\\", \\\"{x:1549,y:826,t:1527873572858};\\\", \\\"{x:1549,y:827,t:1527873572879};\\\", \\\"{x:1548,y:829,t:1527873572891};\\\", \\\"{x:1548,y:831,t:1527873572908};\\\", \\\"{x:1548,y:830,t:1527873574311};\\\", \\\"{x:1548,y:829,t:1527873574325};\\\", \\\"{x:1548,y:828,t:1527873574447};\\\", \\\"{x:1548,y:827,t:1527873574472};\\\", \\\"{x:1548,y:826,t:1527873574487};\\\", \\\"{x:1548,y:825,t:1527873574559};\\\", \\\"{x:1548,y:824,t:1527873574575};\\\", \\\"{x:1548,y:823,t:1527873574608};\\\", \\\"{x:1548,y:822,t:1527873574696};\\\", \\\"{x:1548,y:821,t:1527873574718};\\\", \\\"{x:1548,y:820,t:1527873574790};\\\", \\\"{x:1548,y:819,t:1527873574814};\\\", \\\"{x:1548,y:818,t:1527873574839};\\\", \\\"{x:1548,y:817,t:1527873575280};\\\", \\\"{x:1548,y:816,t:1527873575328};\\\", \\\"{x:1548,y:815,t:1527873575351};\\\", \\\"{x:1548,y:814,t:1527873575367};\\\", \\\"{x:1548,y:813,t:1527873575407};\\\", \\\"{x:1548,y:812,t:1527873575464};\\\", \\\"{x:1548,y:811,t:1527873575476};\\\", \\\"{x:1548,y:810,t:1527873575494};\\\", \\\"{x:1548,y:809,t:1527873575512};\\\", \\\"{x:1548,y:808,t:1527873575526};\\\", \\\"{x:1548,y:807,t:1527873575568};\\\", \\\"{x:1548,y:806,t:1527873575583};\\\", \\\"{x:1548,y:805,t:1527873575594};\\\", \\\"{x:1548,y:804,t:1527873575623};\\\", \\\"{x:1548,y:802,t:1527873575631};\\\", \\\"{x:1548,y:799,t:1527873575643};\\\", \\\"{x:1548,y:798,t:1527873575660};\\\", \\\"{x:1548,y:796,t:1527873575677};\\\", \\\"{x:1548,y:794,t:1527873575694};\\\", \\\"{x:1548,y:793,t:1527873575848};\\\", \\\"{x:1547,y:792,t:1527873575861};\\\", \\\"{x:1547,y:789,t:1527873575880};\\\", \\\"{x:1547,y:788,t:1527873575894};\\\", \\\"{x:1546,y:786,t:1527873575911};\\\", \\\"{x:1546,y:785,t:1527873575927};\\\", \\\"{x:1544,y:782,t:1527873575943};\\\", \\\"{x:1544,y:781,t:1527873575968};\\\", \\\"{x:1544,y:780,t:1527873576008};\\\", \\\"{x:1544,y:779,t:1527873576048};\\\", \\\"{x:1544,y:777,t:1527873576105};\\\", \\\"{x:1544,y:775,t:1527873576111};\\\", \\\"{x:1544,y:773,t:1527873576126};\\\", \\\"{x:1544,y:772,t:1527873576142};\\\", \\\"{x:1544,y:770,t:1527873576175};\\\", \\\"{x:1544,y:769,t:1527873576887};\\\", \\\"{x:1544,y:768,t:1527873577223};\\\", \\\"{x:1544,y:767,t:1527873577536};\\\", \\\"{x:1544,y:766,t:1527873577552};\\\", \\\"{x:1544,y:765,t:1527873580400};\\\", \\\"{x:1544,y:764,t:1527873580455};\\\", \\\"{x:1544,y:763,t:1527873580520};\\\", \\\"{x:1544,y:762,t:1527873584352};\\\", \\\"{x:1544,y:760,t:1527873584366};\\\", \\\"{x:1544,y:758,t:1527873584383};\\\", \\\"{x:1544,y:757,t:1527873584399};\\\", \\\"{x:1544,y:752,t:1527873584415};\\\", \\\"{x:1544,y:750,t:1527873584433};\\\", \\\"{x:1544,y:749,t:1527873584449};\\\", \\\"{x:1544,y:747,t:1527873584466};\\\", \\\"{x:1544,y:746,t:1527873584520};\\\", \\\"{x:1544,y:745,t:1527873584551};\\\", \\\"{x:1544,y:744,t:1527873584566};\\\", \\\"{x:1544,y:741,t:1527873584584};\\\", \\\"{x:1544,y:739,t:1527873584614};\\\", \\\"{x:1544,y:738,t:1527873584638};\\\", \\\"{x:1544,y:736,t:1527873584648};\\\", \\\"{x:1544,y:735,t:1527873584665};\\\", \\\"{x:1544,y:732,t:1527873584683};\\\", \\\"{x:1544,y:727,t:1527873584699};\\\", \\\"{x:1544,y:726,t:1527873584716};\\\", \\\"{x:1544,y:725,t:1527873584815};\\\", \\\"{x:1544,y:724,t:1527873584832};\\\", \\\"{x:1544,y:723,t:1527873584850};\\\", \\\"{x:1544,y:721,t:1527873584968};\\\", \\\"{x:1544,y:720,t:1527873584983};\\\", \\\"{x:1544,y:719,t:1527873585048};\\\", \\\"{x:1544,y:718,t:1527873585087};\\\", \\\"{x:1544,y:717,t:1527873585112};\\\", \\\"{x:1544,y:716,t:1527873585159};\\\", \\\"{x:1544,y:714,t:1527873585735};\\\", \\\"{x:1544,y:712,t:1527873585750};\\\", \\\"{x:1544,y:711,t:1527873585767};\\\", \\\"{x:1544,y:709,t:1527873585783};\\\", \\\"{x:1544,y:708,t:1527873585824};\\\", \\\"{x:1544,y:707,t:1527873585834};\\\", \\\"{x:1544,y:706,t:1527873586856};\\\", \\\"{x:1545,y:706,t:1527873586976};\\\", \\\"{x:1543,y:706,t:1527873587105};\\\", \\\"{x:1542,y:706,t:1527873587118};\\\", \\\"{x:1540,y:707,t:1527873587133};\\\", \\\"{x:1525,y:713,t:1527873587150};\\\", \\\"{x:1495,y:727,t:1527873587167};\\\", \\\"{x:1422,y:739,t:1527873587184};\\\", \\\"{x:1282,y:749,t:1527873587200};\\\", \\\"{x:1108,y:752,t:1527873587217};\\\", \\\"{x:917,y:752,t:1527873587233};\\\", \\\"{x:772,y:742,t:1527873587251};\\\", \\\"{x:671,y:726,t:1527873587267};\\\", \\\"{x:596,y:714,t:1527873587284};\\\", \\\"{x:568,y:704,t:1527873587300};\\\", \\\"{x:558,y:698,t:1527873587318};\\\", \\\"{x:558,y:696,t:1527873587333};\\\", \\\"{x:558,y:689,t:1527873587350};\\\", \\\"{x:560,y:681,t:1527873587368};\\\", \\\"{x:560,y:677,t:1527873587384};\\\", \\\"{x:560,y:672,t:1527873587401};\\\", \\\"{x:561,y:663,t:1527873587417};\\\", \\\"{x:562,y:659,t:1527873587435};\\\", \\\"{x:562,y:656,t:1527873587451};\\\", \\\"{x:562,y:651,t:1527873587467};\\\", \\\"{x:562,y:646,t:1527873587484};\\\", \\\"{x:562,y:639,t:1527873587501};\\\", \\\"{x:557,y:630,t:1527873587518};\\\", \\\"{x:550,y:622,t:1527873587535};\\\", \\\"{x:547,y:620,t:1527873587550};\\\", \\\"{x:541,y:617,t:1527873587571};\\\", \\\"{x:527,y:610,t:1527873587590};\\\", \\\"{x:495,y:595,t:1527873587607};\\\", \\\"{x:466,y:585,t:1527873587624};\\\", \\\"{x:444,y:581,t:1527873587639};\\\", \\\"{x:430,y:581,t:1527873587656};\\\", \\\"{x:424,y:580,t:1527873587674};\\\", \\\"{x:413,y:575,t:1527873587690};\\\", \\\"{x:394,y:568,t:1527873587707};\\\", \\\"{x:376,y:563,t:1527873587724};\\\", \\\"{x:359,y:559,t:1527873587741};\\\", \\\"{x:350,y:558,t:1527873587756};\\\", \\\"{x:346,y:557,t:1527873587774};\\\", \\\"{x:344,y:557,t:1527873587810};\\\", \\\"{x:343,y:557,t:1527873587824};\\\", \\\"{x:333,y:557,t:1527873587841};\\\", \\\"{x:321,y:557,t:1527873587856};\\\", \\\"{x:312,y:557,t:1527873587874};\\\", \\\"{x:308,y:557,t:1527873587890};\\\", \\\"{x:303,y:558,t:1527873587907};\\\", \\\"{x:297,y:558,t:1527873587924};\\\", \\\"{x:289,y:558,t:1527873587941};\\\", \\\"{x:276,y:558,t:1527873587957};\\\", \\\"{x:262,y:553,t:1527873587975};\\\", \\\"{x:249,y:546,t:1527873587990};\\\", \\\"{x:239,y:541,t:1527873588007};\\\", \\\"{x:232,y:538,t:1527873588023};\\\", \\\"{x:228,y:537,t:1527873588041};\\\", \\\"{x:224,y:537,t:1527873588056};\\\", \\\"{x:209,y:535,t:1527873588074};\\\", \\\"{x:187,y:523,t:1527873588091};\\\", \\\"{x:167,y:517,t:1527873588108};\\\", \\\"{x:145,y:517,t:1527873588124};\\\", \\\"{x:126,y:517,t:1527873588141};\\\", \\\"{x:111,y:517,t:1527873588157};\\\", \\\"{x:97,y:517,t:1527873588173};\\\", \\\"{x:89,y:518,t:1527873588191};\\\", \\\"{x:78,y:523,t:1527873588206};\\\", \\\"{x:71,y:523,t:1527873588224};\\\", \\\"{x:66,y:526,t:1527873588241};\\\", \\\"{x:64,y:527,t:1527873588258};\\\", \\\"{x:64,y:528,t:1527873588282};\\\", \\\"{x:64,y:529,t:1527873588322};\\\", \\\"{x:64,y:530,t:1527873588346};\\\", \\\"{x:64,y:531,t:1527873588358};\\\", \\\"{x:75,y:535,t:1527873588374};\\\", \\\"{x:90,y:543,t:1527873588390};\\\", \\\"{x:98,y:550,t:1527873588408};\\\", \\\"{x:100,y:552,t:1527873588423};\\\", \\\"{x:101,y:552,t:1527873588441};\\\", \\\"{x:102,y:552,t:1527873588458};\\\", \\\"{x:104,y:552,t:1527873588474};\\\", \\\"{x:109,y:552,t:1527873588491};\\\", \\\"{x:115,y:552,t:1527873588507};\\\", \\\"{x:120,y:552,t:1527873588524};\\\", \\\"{x:121,y:552,t:1527873588594};\\\", \\\"{x:122,y:551,t:1527873588608};\\\", \\\"{x:123,y:547,t:1527873588624};\\\", \\\"{x:123,y:545,t:1527873588641};\\\", \\\"{x:123,y:544,t:1527873588658};\\\", \\\"{x:123,y:543,t:1527873588674};\\\", \\\"{x:123,y:542,t:1527873588827};\\\", \\\"{x:123,y:541,t:1527873588841};\\\", \\\"{x:155,y:541,t:1527873588859};\\\", \\\"{x:169,y:541,t:1527873588875};\\\", \\\"{x:172,y:540,t:1527873588890};\\\", \\\"{x:171,y:540,t:1527873588945};\\\", \\\"{x:170,y:540,t:1527873588961};\\\", \\\"{x:169,y:540,t:1527873589051};\\\", \\\"{x:168,y:540,t:1527873589234};\\\", \\\"{x:167,y:540,t:1527873589241};\\\", \\\"{x:167,y:540,t:1527873589258};\\\", \\\"{x:166,y:540,t:1527873589370};\\\", \\\"{x:166,y:541,t:1527873589378};\\\", \\\"{x:166,y:542,t:1527873589474};\\\", \\\"{x:166,y:543,t:1527873589492};\\\", \\\"{x:167,y:546,t:1527873589508};\\\", \\\"{x:172,y:553,t:1527873589526};\\\", \\\"{x:202,y:572,t:1527873589543};\\\", \\\"{x:277,y:617,t:1527873589558};\\\", \\\"{x:354,y:653,t:1527873589575};\\\", \\\"{x:414,y:685,t:1527873589592};\\\", \\\"{x:455,y:702,t:1527873589608};\\\", \\\"{x:469,y:710,t:1527873589625};\\\", \\\"{x:471,y:711,t:1527873589641};\\\", \\\"{x:472,y:713,t:1527873589746};\\\", \\\"{x:473,y:714,t:1527873589762};\\\", \\\"{x:474,y:714,t:1527873589803};\\\", \\\"{x:474,y:716,t:1527873589819};\\\", \\\"{x:476,y:719,t:1527873589826};\\\", \\\"{x:489,y:734,t:1527873589843};\\\", \\\"{x:500,y:751,t:1527873589859};\\\", \\\"{x:509,y:760,t:1527873589876};\\\", \\\"{x:513,y:763,t:1527873589892};\\\", \\\"{x:513,y:762,t:1527873590108};\\\", \\\"{x:514,y:757,t:1527873590126};\\\", \\\"{x:515,y:753,t:1527873590143};\\\", \\\"{x:515,y:751,t:1527873590159};\\\", \\\"{x:515,y:750,t:1527873590178};\\\", \\\"{x:516,y:749,t:1527873590192};\\\", \\\"{x:516,y:748,t:1527873590379};\\\", \\\"{x:516,y:747,t:1527873590426};\\\", \\\"{x:517,y:746,t:1527873590450};\\\", \\\"{x:517,y:745,t:1527873590491};\\\", \\\"{x:517,y:744,t:1527873590499};\\\" ] }, { \\\"rt\\\": 46772, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 590623, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"9BS72\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:516,y:744,t:1527873593587};\\\", \\\"{x:515,y:744,t:1527873593602};\\\", \\\"{x:515,y:743,t:1527873593614};\\\", \\\"{x:514,y:743,t:1527873593630};\\\", \\\"{x:513,y:743,t:1527873593648};\\\", \\\"{x:512,y:743,t:1527873593842};\\\", \\\"{x:511,y:743,t:1527873593906};\\\", \\\"{x:510,y:743,t:1527873593938};\\\", \\\"{x:509,y:743,t:1527873594186};\\\", \\\"{x:508,y:743,t:1527873594267};\\\", \\\"{x:509,y:743,t:1527873594394};\\\", \\\"{x:511,y:743,t:1527873594402};\\\", \\\"{x:513,y:743,t:1527873594415};\\\", \\\"{x:515,y:743,t:1527873594433};\\\", \\\"{x:520,y:743,t:1527873594448};\\\", \\\"{x:523,y:743,t:1527873594466};\\\", \\\"{x:527,y:743,t:1527873594482};\\\", \\\"{x:528,y:743,t:1527873594522};\\\", \\\"{x:529,y:743,t:1527873594563};\\\", \\\"{x:530,y:743,t:1527873594579};\\\", \\\"{x:531,y:743,t:1527873594601};\\\", \\\"{x:532,y:743,t:1527873594617};\\\", \\\"{x:533,y:743,t:1527873594632};\\\", \\\"{x:538,y:743,t:1527873594649};\\\", \\\"{x:545,y:743,t:1527873594665};\\\", \\\"{x:558,y:744,t:1527873594682};\\\", \\\"{x:567,y:745,t:1527873594699};\\\", \\\"{x:576,y:747,t:1527873594716};\\\", \\\"{x:583,y:749,t:1527873594732};\\\", \\\"{x:591,y:749,t:1527873594746};\\\", \\\"{x:596,y:749,t:1527873594761};\\\", \\\"{x:604,y:749,t:1527873594779};\\\", \\\"{x:618,y:751,t:1527873594796};\\\", \\\"{x:634,y:751,t:1527873594811};\\\", \\\"{x:649,y:752,t:1527873594829};\\\", \\\"{x:660,y:754,t:1527873594846};\\\", \\\"{x:676,y:757,t:1527873594861};\\\", \\\"{x:695,y:760,t:1527873594879};\\\", \\\"{x:717,y:763,t:1527873594896};\\\", \\\"{x:745,y:767,t:1527873594912};\\\", \\\"{x:771,y:770,t:1527873594929};\\\", \\\"{x:804,y:774,t:1527873594946};\\\", \\\"{x:822,y:775,t:1527873594962};\\\", \\\"{x:837,y:778,t:1527873594979};\\\", \\\"{x:855,y:781,t:1527873594997};\\\", \\\"{x:875,y:785,t:1527873595012};\\\", \\\"{x:894,y:786,t:1527873595029};\\\", \\\"{x:916,y:786,t:1527873595046};\\\", \\\"{x:938,y:786,t:1527873595062};\\\", \\\"{x:963,y:786,t:1527873595079};\\\", \\\"{x:994,y:786,t:1527873595097};\\\", \\\"{x:1023,y:786,t:1527873595114};\\\", \\\"{x:1046,y:787,t:1527873595130};\\\", \\\"{x:1069,y:790,t:1527873595146};\\\", \\\"{x:1074,y:790,t:1527873595163};\\\", \\\"{x:1077,y:790,t:1527873595179};\\\", \\\"{x:1078,y:790,t:1527873595210};\\\", \\\"{x:1081,y:790,t:1527873595226};\\\", \\\"{x:1082,y:790,t:1527873595234};\\\", \\\"{x:1084,y:790,t:1527873595246};\\\", \\\"{x:1092,y:790,t:1527873595263};\\\", \\\"{x:1105,y:792,t:1527873595279};\\\", \\\"{x:1119,y:795,t:1527873595296};\\\", \\\"{x:1131,y:797,t:1527873595314};\\\", \\\"{x:1143,y:802,t:1527873595329};\\\", \\\"{x:1166,y:813,t:1527873595346};\\\", \\\"{x:1179,y:822,t:1527873595363};\\\", \\\"{x:1184,y:826,t:1527873595379};\\\", \\\"{x:1185,y:827,t:1527873595396};\\\", \\\"{x:1187,y:829,t:1527873595413};\\\", \\\"{x:1189,y:831,t:1527873595430};\\\", \\\"{x:1191,y:831,t:1527873595446};\\\", \\\"{x:1192,y:833,t:1527873595463};\\\", \\\"{x:1193,y:835,t:1527873595482};\\\", \\\"{x:1193,y:837,t:1527873595497};\\\", \\\"{x:1195,y:840,t:1527873595514};\\\", \\\"{x:1196,y:843,t:1527873595529};\\\", \\\"{x:1198,y:846,t:1527873595547};\\\", \\\"{x:1198,y:847,t:1527873595564};\\\", \\\"{x:1201,y:851,t:1527873595581};\\\", \\\"{x:1204,y:856,t:1527873595597};\\\", \\\"{x:1210,y:862,t:1527873595613};\\\", \\\"{x:1214,y:866,t:1527873595631};\\\", \\\"{x:1216,y:868,t:1527873595647};\\\", \\\"{x:1218,y:870,t:1527873595664};\\\", \\\"{x:1222,y:873,t:1527873595680};\\\", \\\"{x:1228,y:879,t:1527873595696};\\\", \\\"{x:1234,y:885,t:1527873595714};\\\", \\\"{x:1241,y:889,t:1527873595731};\\\", \\\"{x:1243,y:891,t:1527873595746};\\\", \\\"{x:1246,y:893,t:1527873595764};\\\", \\\"{x:1248,y:894,t:1527873595781};\\\", \\\"{x:1252,y:899,t:1527873595797};\\\", \\\"{x:1263,y:906,t:1527873595813};\\\", \\\"{x:1269,y:909,t:1527873595831};\\\", \\\"{x:1271,y:909,t:1527873595846};\\\", \\\"{x:1274,y:910,t:1527873595863};\\\", \\\"{x:1275,y:911,t:1527873595883};\\\", \\\"{x:1276,y:911,t:1527873595939};\\\", \\\"{x:1277,y:911,t:1527873595947};\\\", \\\"{x:1279,y:913,t:1527873595963};\\\", \\\"{x:1280,y:915,t:1527873595981};\\\", \\\"{x:1283,y:917,t:1527873595997};\\\", \\\"{x:1285,y:919,t:1527873596013};\\\", \\\"{x:1290,y:921,t:1527873596030};\\\", \\\"{x:1296,y:923,t:1527873596048};\\\", \\\"{x:1307,y:926,t:1527873596063};\\\", \\\"{x:1316,y:930,t:1527873596081};\\\", \\\"{x:1324,y:932,t:1527873596097};\\\", \\\"{x:1329,y:933,t:1527873596113};\\\", \\\"{x:1330,y:933,t:1527873596131};\\\", \\\"{x:1331,y:933,t:1527873596148};\\\", \\\"{x:1336,y:935,t:1527873596164};\\\", \\\"{x:1342,y:937,t:1527873596181};\\\", \\\"{x:1346,y:939,t:1527873596198};\\\", \\\"{x:1348,y:939,t:1527873596213};\\\", \\\"{x:1350,y:939,t:1527873596231};\\\", \\\"{x:1353,y:940,t:1527873596247};\\\", \\\"{x:1365,y:943,t:1527873596263};\\\", \\\"{x:1387,y:947,t:1527873596281};\\\", \\\"{x:1409,y:949,t:1527873596297};\\\", \\\"{x:1426,y:954,t:1527873596313};\\\", \\\"{x:1438,y:954,t:1527873596330};\\\", \\\"{x:1451,y:954,t:1527873596348};\\\", \\\"{x:1469,y:954,t:1527873596363};\\\", \\\"{x:1494,y:954,t:1527873596380};\\\", \\\"{x:1519,y:954,t:1527873596397};\\\", \\\"{x:1530,y:954,t:1527873596414};\\\", \\\"{x:1531,y:954,t:1527873596431};\\\", \\\"{x:1532,y:954,t:1527873596539};\\\", \\\"{x:1532,y:955,t:1527873596579};\\\", \\\"{x:1532,y:956,t:1527873596635};\\\", \\\"{x:1531,y:957,t:1527873596648};\\\", \\\"{x:1524,y:957,t:1527873596665};\\\", \\\"{x:1518,y:957,t:1527873596681};\\\", \\\"{x:1514,y:957,t:1527873596698};\\\", \\\"{x:1511,y:957,t:1527873596714};\\\", \\\"{x:1509,y:958,t:1527873596755};\\\", \\\"{x:1507,y:958,t:1527873596765};\\\", \\\"{x:1506,y:958,t:1527873596781};\\\", \\\"{x:1502,y:958,t:1527873596798};\\\", \\\"{x:1499,y:961,t:1527873596814};\\\", \\\"{x:1496,y:961,t:1527873596831};\\\", \\\"{x:1495,y:962,t:1527873596848};\\\", \\\"{x:1494,y:963,t:1527873596955};\\\", \\\"{x:1493,y:963,t:1527873596979};\\\", \\\"{x:1492,y:963,t:1527873596986};\\\", \\\"{x:1492,y:964,t:1527873597003};\\\", \\\"{x:1491,y:964,t:1527873597051};\\\", \\\"{x:1490,y:964,t:1527873597065};\\\", \\\"{x:1489,y:964,t:1527873597082};\\\", \\\"{x:1488,y:964,t:1527873597123};\\\", \\\"{x:1487,y:964,t:1527873597132};\\\", \\\"{x:1486,y:964,t:1527873597154};\\\", \\\"{x:1485,y:965,t:1527873597165};\\\", \\\"{x:1484,y:965,t:1527873597267};\\\", \\\"{x:1483,y:965,t:1527873597538};\\\", \\\"{x:1482,y:965,t:1527873597635};\\\", \\\"{x:1481,y:965,t:1527873597650};\\\", \\\"{x:1480,y:965,t:1527873597699};\\\", \\\"{x:1479,y:965,t:1527873598451};\\\", \\\"{x:1478,y:965,t:1527873598475};\\\", \\\"{x:1477,y:965,t:1527873598499};\\\", \\\"{x:1477,y:964,t:1527873598603};\\\", \\\"{x:1477,y:963,t:1527873598627};\\\", \\\"{x:1477,y:962,t:1527873598643};\\\", \\\"{x:1476,y:962,t:1527873598691};\\\", \\\"{x:1476,y:961,t:1527873598715};\\\", \\\"{x:1476,y:960,t:1527873598754};\\\", \\\"{x:1476,y:958,t:1527873598787};\\\", \\\"{x:1477,y:958,t:1527873598834};\\\", \\\"{x:1477,y:957,t:1527873598867};\\\", \\\"{x:1478,y:957,t:1527873598883};\\\", \\\"{x:1478,y:956,t:1527873598898};\\\", \\\"{x:1478,y:955,t:1527873598916};\\\", \\\"{x:1478,y:954,t:1527873598962};\\\", \\\"{x:1479,y:952,t:1527873598987};\\\", \\\"{x:1480,y:952,t:1527873599000};\\\", \\\"{x:1480,y:950,t:1527873599016};\\\", \\\"{x:1481,y:948,t:1527873599032};\\\", \\\"{x:1481,y:946,t:1527873599049};\\\", \\\"{x:1481,y:945,t:1527873599065};\\\", \\\"{x:1481,y:944,t:1527873599082};\\\", \\\"{x:1481,y:942,t:1527873599100};\\\", \\\"{x:1483,y:938,t:1527873599116};\\\", \\\"{x:1483,y:933,t:1527873599132};\\\", \\\"{x:1483,y:929,t:1527873599149};\\\", \\\"{x:1483,y:924,t:1527873599166};\\\", \\\"{x:1482,y:920,t:1527873599182};\\\", \\\"{x:1481,y:916,t:1527873599200};\\\", \\\"{x:1481,y:914,t:1527873599216};\\\", \\\"{x:1481,y:913,t:1527873599232};\\\", \\\"{x:1480,y:911,t:1527873599250};\\\", \\\"{x:1480,y:910,t:1527873599267};\\\", \\\"{x:1480,y:909,t:1527873599282};\\\", \\\"{x:1480,y:908,t:1527873599379};\\\", \\\"{x:1480,y:907,t:1527873599394};\\\", \\\"{x:1479,y:905,t:1527873599402};\\\", \\\"{x:1479,y:904,t:1527873599715};\\\", \\\"{x:1478,y:901,t:1527873600619};\\\", \\\"{x:1478,y:900,t:1527873600634};\\\", \\\"{x:1478,y:898,t:1527873600651};\\\", \\\"{x:1478,y:897,t:1527873602034};\\\", \\\"{x:1478,y:896,t:1527873602052};\\\", \\\"{x:1478,y:895,t:1527873602068};\\\", \\\"{x:1478,y:894,t:1527873602085};\\\", \\\"{x:1478,y:893,t:1527873602131};\\\", \\\"{x:1478,y:891,t:1527873605155};\\\", \\\"{x:1476,y:886,t:1527873605170};\\\", \\\"{x:1471,y:879,t:1527873605187};\\\", \\\"{x:1469,y:874,t:1527873605204};\\\", \\\"{x:1465,y:868,t:1527873605221};\\\", \\\"{x:1463,y:863,t:1527873605237};\\\", \\\"{x:1462,y:861,t:1527873605254};\\\", \\\"{x:1460,y:857,t:1527873605271};\\\", \\\"{x:1459,y:855,t:1527873605287};\\\", \\\"{x:1459,y:854,t:1527873605307};\\\", \\\"{x:1459,y:853,t:1527873605321};\\\", \\\"{x:1459,y:852,t:1527873605338};\\\", \\\"{x:1459,y:851,t:1527873605355};\\\", \\\"{x:1459,y:850,t:1527873605370};\\\", \\\"{x:1459,y:848,t:1527873605387};\\\", \\\"{x:1459,y:847,t:1527873605404};\\\", \\\"{x:1459,y:845,t:1527873605421};\\\", \\\"{x:1459,y:844,t:1527873605437};\\\", \\\"{x:1460,y:842,t:1527873605455};\\\", \\\"{x:1461,y:840,t:1527873605471};\\\", \\\"{x:1462,y:840,t:1527873605487};\\\", \\\"{x:1462,y:839,t:1527873605504};\\\", \\\"{x:1463,y:839,t:1527873605522};\\\", \\\"{x:1464,y:838,t:1527873605539};\\\", \\\"{x:1465,y:837,t:1527873605562};\\\", \\\"{x:1466,y:837,t:1527873605634};\\\", \\\"{x:1467,y:837,t:1527873605659};\\\", \\\"{x:1468,y:837,t:1527873605755};\\\", \\\"{x:1469,y:836,t:1527873605771};\\\", \\\"{x:1470,y:836,t:1527873605794};\\\", \\\"{x:1472,y:835,t:1527873605804};\\\", \\\"{x:1473,y:834,t:1527873605822};\\\", \\\"{x:1475,y:833,t:1527873605838};\\\", \\\"{x:1476,y:831,t:1527873605893};\\\", \\\"{x:1477,y:831,t:1527873607395};\\\", \\\"{x:1477,y:830,t:1527873607418};\\\", \\\"{x:1477,y:828,t:1527873607426};\\\", \\\"{x:1477,y:826,t:1527873607442};\\\", \\\"{x:1478,y:822,t:1527873607457};\\\", \\\"{x:1478,y:821,t:1527873607472};\\\", \\\"{x:1479,y:817,t:1527873607489};\\\", \\\"{x:1479,y:814,t:1527873607506};\\\", \\\"{x:1480,y:812,t:1527873607522};\\\", \\\"{x:1480,y:811,t:1527873607539};\\\", \\\"{x:1480,y:809,t:1527873607556};\\\", \\\"{x:1480,y:808,t:1527873607571};\\\", \\\"{x:1481,y:806,t:1527873607589};\\\", \\\"{x:1481,y:804,t:1527873607605};\\\", \\\"{x:1481,y:802,t:1527873607621};\\\", \\\"{x:1481,y:801,t:1527873607639};\\\", \\\"{x:1481,y:799,t:1527873607655};\\\", \\\"{x:1481,y:798,t:1527873607672};\\\", \\\"{x:1481,y:797,t:1527873607689};\\\", \\\"{x:1481,y:792,t:1527873607705};\\\", \\\"{x:1481,y:788,t:1527873607722};\\\", \\\"{x:1481,y:786,t:1527873607739};\\\", \\\"{x:1481,y:782,t:1527873607756};\\\", \\\"{x:1481,y:780,t:1527873607772};\\\", \\\"{x:1481,y:779,t:1527873607790};\\\", \\\"{x:1481,y:778,t:1527873607806};\\\", \\\"{x:1481,y:777,t:1527873607858};\\\", \\\"{x:1481,y:776,t:1527873607872};\\\", \\\"{x:1481,y:774,t:1527873607889};\\\", \\\"{x:1481,y:770,t:1527873607907};\\\", \\\"{x:1481,y:769,t:1527873607922};\\\", \\\"{x:1481,y:767,t:1527873607940};\\\", \\\"{x:1481,y:766,t:1527873607956};\\\", \\\"{x:1481,y:765,t:1527873607987};\\\", \\\"{x:1481,y:764,t:1527873608011};\\\", \\\"{x:1481,y:763,t:1527873608027};\\\", \\\"{x:1481,y:762,t:1527873608040};\\\", \\\"{x:1481,y:761,t:1527873612699};\\\", \\\"{x:1479,y:760,t:1527873612795};\\\", \\\"{x:1479,y:757,t:1527873612809};\\\", \\\"{x:1479,y:751,t:1527873612827};\\\", \\\"{x:1479,y:750,t:1527873612842};\\\", \\\"{x:1479,y:749,t:1527873612859};\\\", \\\"{x:1479,y:748,t:1527873612877};\\\", \\\"{x:1479,y:747,t:1527873612898};\\\", \\\"{x:1479,y:746,t:1527873612922};\\\", \\\"{x:1479,y:745,t:1527873612955};\\\", \\\"{x:1479,y:744,t:1527873612987};\\\", \\\"{x:1479,y:743,t:1527873613027};\\\", \\\"{x:1479,y:740,t:1527873613044};\\\", \\\"{x:1479,y:739,t:1527873613067};\\\", \\\"{x:1479,y:738,t:1527873613077};\\\", \\\"{x:1479,y:737,t:1527873613094};\\\", \\\"{x:1479,y:736,t:1527873613146};\\\", \\\"{x:1479,y:735,t:1527873613162};\\\", \\\"{x:1479,y:734,t:1527873613227};\\\", \\\"{x:1479,y:731,t:1527873613258};\\\", \\\"{x:1479,y:730,t:1527873613283};\\\", \\\"{x:1479,y:729,t:1527873613306};\\\", \\\"{x:1479,y:727,t:1527873613370};\\\", \\\"{x:1479,y:726,t:1527873613378};\\\", \\\"{x:1479,y:725,t:1527873613393};\\\", \\\"{x:1479,y:724,t:1527873613410};\\\", \\\"{x:1479,y:722,t:1527873613427};\\\", \\\"{x:1479,y:721,t:1527873613443};\\\", \\\"{x:1479,y:719,t:1527873613539};\\\", \\\"{x:1479,y:718,t:1527873613650};\\\", \\\"{x:1479,y:716,t:1527873613690};\\\", \\\"{x:1479,y:715,t:1527873613731};\\\", \\\"{x:1479,y:713,t:1527873613755};\\\", \\\"{x:1479,y:711,t:1527873613762};\\\", \\\"{x:1479,y:710,t:1527873613776};\\\", \\\"{x:1479,y:707,t:1527873613794};\\\", \\\"{x:1479,y:703,t:1527873613810};\\\", \\\"{x:1479,y:702,t:1527873613842};\\\", \\\"{x:1479,y:700,t:1527873614042};\\\", \\\"{x:1479,y:699,t:1527873614097};\\\", \\\"{x:1480,y:698,t:1527873614114};\\\", \\\"{x:1480,y:697,t:1527873614137};\\\", \\\"{x:1480,y:696,t:1527873614259};\\\", \\\"{x:1480,y:694,t:1527873630331};\\\", \\\"{x:1480,y:693,t:1527873630451};\\\", \\\"{x:1480,y:691,t:1527873630482};\\\", \\\"{x:1480,y:690,t:1527873630515};\\\", \\\"{x:1480,y:689,t:1527873630530};\\\", \\\"{x:1480,y:688,t:1527873630555};\\\", \\\"{x:1480,y:687,t:1527873630563};\\\", \\\"{x:1479,y:687,t:1527873630618};\\\", \\\"{x:1479,y:686,t:1527873630674};\\\", \\\"{x:1479,y:685,t:1527873630689};\\\", \\\"{x:1479,y:684,t:1527873630706};\\\", \\\"{x:1479,y:683,t:1527873630722};\\\", \\\"{x:1479,y:681,t:1527873630740};\\\", \\\"{x:1479,y:679,t:1527873630762};\\\", \\\"{x:1479,y:678,t:1527873630772};\\\", \\\"{x:1479,y:676,t:1527873630788};\\\", \\\"{x:1479,y:674,t:1527873630806};\\\", \\\"{x:1479,y:668,t:1527873630823};\\\", \\\"{x:1476,y:663,t:1527873630839};\\\", \\\"{x:1476,y:659,t:1527873630856};\\\", \\\"{x:1475,y:656,t:1527873630873};\\\", \\\"{x:1475,y:654,t:1527873630889};\\\", \\\"{x:1474,y:651,t:1527873630905};\\\", \\\"{x:1474,y:649,t:1527873630922};\\\", \\\"{x:1474,y:647,t:1527873630939};\\\", \\\"{x:1474,y:644,t:1527873630956};\\\", \\\"{x:1474,y:642,t:1527873630973};\\\", \\\"{x:1474,y:641,t:1527873630989};\\\", \\\"{x:1474,y:639,t:1527873631007};\\\", \\\"{x:1474,y:638,t:1527873631023};\\\", \\\"{x:1474,y:636,t:1527873631099};\\\", \\\"{x:1474,y:635,t:1527873631131};\\\", \\\"{x:1475,y:634,t:1527873631154};\\\", \\\"{x:1476,y:632,t:1527873631179};\\\", \\\"{x:1476,y:631,t:1527873631210};\\\", \\\"{x:1476,y:630,t:1527873631224};\\\", \\\"{x:1476,y:629,t:1527873631251};\\\", \\\"{x:1478,y:627,t:1527873631274};\\\", \\\"{x:1478,y:626,t:1527873631315};\\\", \\\"{x:1479,y:624,t:1527873631338};\\\", \\\"{x:1479,y:623,t:1527873631354};\\\", \\\"{x:1480,y:622,t:1527873631371};\\\", \\\"{x:1480,y:621,t:1527873631458};\\\", \\\"{x:1480,y:620,t:1527873631474};\\\", \\\"{x:1480,y:619,t:1527873631490};\\\", \\\"{x:1481,y:618,t:1527873631507};\\\", \\\"{x:1481,y:617,t:1527873631595};\\\", \\\"{x:1482,y:616,t:1527873631607};\\\", \\\"{x:1482,y:615,t:1527873631623};\\\", \\\"{x:1482,y:613,t:1527873631640};\\\", \\\"{x:1482,y:612,t:1527873631666};\\\", \\\"{x:1482,y:610,t:1527873631683};\\\", \\\"{x:1482,y:609,t:1527873631698};\\\", \\\"{x:1483,y:608,t:1527873631707};\\\", \\\"{x:1483,y:606,t:1527873631724};\\\", \\\"{x:1484,y:604,t:1527873631740};\\\", \\\"{x:1484,y:600,t:1527873631755};\\\", \\\"{x:1484,y:599,t:1527873631773};\\\", \\\"{x:1485,y:597,t:1527873631789};\\\", \\\"{x:1486,y:595,t:1527873631806};\\\", \\\"{x:1486,y:594,t:1527873631822};\\\", \\\"{x:1486,y:592,t:1527873631840};\\\", \\\"{x:1486,y:590,t:1527873631857};\\\", \\\"{x:1486,y:588,t:1527873631873};\\\", \\\"{x:1486,y:586,t:1527873631890};\\\", \\\"{x:1486,y:585,t:1527873631907};\\\", \\\"{x:1486,y:584,t:1527873631923};\\\", \\\"{x:1487,y:584,t:1527873631946};\\\", \\\"{x:1487,y:583,t:1527873631994};\\\", \\\"{x:1487,y:582,t:1527873632026};\\\", \\\"{x:1487,y:581,t:1527873632074};\\\", \\\"{x:1487,y:580,t:1527873632113};\\\", \\\"{x:1487,y:579,t:1527873632146};\\\", \\\"{x:1487,y:578,t:1527873632170};\\\", \\\"{x:1487,y:576,t:1527873632186};\\\", \\\"{x:1487,y:574,t:1527873632194};\\\", \\\"{x:1487,y:573,t:1527873632207};\\\", \\\"{x:1487,y:572,t:1527873632224};\\\", \\\"{x:1487,y:571,t:1527873632240};\\\", \\\"{x:1486,y:570,t:1527873632257};\\\", \\\"{x:1486,y:569,t:1527873632290};\\\", \\\"{x:1486,y:568,t:1527873634115};\\\", \\\"{x:1485,y:568,t:1527873634126};\\\", \\\"{x:1484,y:569,t:1527873634162};\\\", \\\"{x:1481,y:571,t:1527873634175};\\\", \\\"{x:1473,y:577,t:1527873634191};\\\", \\\"{x:1464,y:584,t:1527873634208};\\\", \\\"{x:1453,y:594,t:1527873634226};\\\", \\\"{x:1419,y:610,t:1527873634242};\\\", \\\"{x:1374,y:624,t:1527873634258};\\\", \\\"{x:1298,y:639,t:1527873634275};\\\", \\\"{x:1187,y:659,t:1527873634293};\\\", \\\"{x:1060,y:674,t:1527873634308};\\\", \\\"{x:927,y:691,t:1527873634326};\\\", \\\"{x:803,y:703,t:1527873634343};\\\", \\\"{x:698,y:703,t:1527873634358};\\\", \\\"{x:609,y:703,t:1527873634374};\\\", \\\"{x:545,y:703,t:1527873634392};\\\", \\\"{x:500,y:703,t:1527873634408};\\\", \\\"{x:471,y:702,t:1527873634425};\\\", \\\"{x:458,y:700,t:1527873634441};\\\", \\\"{x:455,y:699,t:1527873634498};\\\", \\\"{x:452,y:697,t:1527873634508};\\\", \\\"{x:448,y:693,t:1527873634525};\\\", \\\"{x:439,y:679,t:1527873634543};\\\", \\\"{x:427,y:655,t:1527873634558};\\\", \\\"{x:419,y:633,t:1527873634575};\\\", \\\"{x:417,y:600,t:1527873634594};\\\", \\\"{x:421,y:585,t:1527873634611};\\\", \\\"{x:424,y:581,t:1527873634627};\\\", \\\"{x:432,y:572,t:1527873634644};\\\", \\\"{x:447,y:563,t:1527873634661};\\\", \\\"{x:462,y:554,t:1527873634678};\\\", \\\"{x:477,y:547,t:1527873634695};\\\", \\\"{x:489,y:545,t:1527873634711};\\\", \\\"{x:508,y:540,t:1527873634729};\\\", \\\"{x:532,y:539,t:1527873634745};\\\", \\\"{x:561,y:539,t:1527873634761};\\\", \\\"{x:592,y:536,t:1527873634777};\\\", \\\"{x:596,y:535,t:1527873634795};\\\", \\\"{x:597,y:535,t:1527873635058};\\\", \\\"{x:598,y:534,t:1527873635074};\\\", \\\"{x:602,y:532,t:1527873635082};\\\", \\\"{x:605,y:531,t:1527873635097};\\\", \\\"{x:612,y:527,t:1527873635112};\\\", \\\"{x:614,y:527,t:1527873635127};\\\", \\\"{x:621,y:524,t:1527873635146};\\\", \\\"{x:628,y:524,t:1527873635160};\\\", \\\"{x:649,y:517,t:1527873635178};\\\", \\\"{x:664,y:513,t:1527873635195};\\\", \\\"{x:694,y:508,t:1527873635211};\\\", \\\"{x:732,y:505,t:1527873635229};\\\", \\\"{x:758,y:502,t:1527873635245};\\\", \\\"{x:773,y:500,t:1527873635262};\\\", \\\"{x:775,y:500,t:1527873635278};\\\", \\\"{x:776,y:500,t:1527873635387};\\\", \\\"{x:777,y:500,t:1527873635402};\\\", \\\"{x:778,y:500,t:1527873635426};\\\", \\\"{x:779,y:500,t:1527873635458};\\\", \\\"{x:781,y:500,t:1527873635474};\\\", \\\"{x:782,y:501,t:1527873635483};\\\", \\\"{x:783,y:501,t:1527873635495};\\\", \\\"{x:786,y:503,t:1527873635512};\\\", \\\"{x:790,y:504,t:1527873635529};\\\", \\\"{x:791,y:504,t:1527873635545};\\\", \\\"{x:792,y:504,t:1527873635561};\\\", \\\"{x:797,y:505,t:1527873635579};\\\", \\\"{x:807,y:509,t:1527873635595};\\\", \\\"{x:814,y:511,t:1527873635612};\\\", \\\"{x:818,y:513,t:1527873635629};\\\", \\\"{x:820,y:513,t:1527873635645};\\\", \\\"{x:821,y:513,t:1527873635662};\\\", \\\"{x:825,y:516,t:1527873635679};\\\", \\\"{x:833,y:520,t:1527873635696};\\\", \\\"{x:836,y:521,t:1527873635712};\\\", \\\"{x:837,y:521,t:1527873635728};\\\", \\\"{x:834,y:522,t:1527873636475};\\\", \\\"{x:828,y:523,t:1527873636482};\\\", \\\"{x:821,y:523,t:1527873636498};\\\", \\\"{x:796,y:526,t:1527873636513};\\\", \\\"{x:781,y:526,t:1527873636529};\\\", \\\"{x:772,y:526,t:1527873636546};\\\", \\\"{x:770,y:526,t:1527873636562};\\\", \\\"{x:769,y:526,t:1527873636579};\\\", \\\"{x:768,y:526,t:1527873636596};\\\", \\\"{x:766,y:526,t:1527873636613};\\\", \\\"{x:760,y:526,t:1527873636629};\\\", \\\"{x:749,y:526,t:1527873636646};\\\", \\\"{x:740,y:526,t:1527873636663};\\\", \\\"{x:732,y:526,t:1527873636679};\\\", \\\"{x:720,y:526,t:1527873636697};\\\", \\\"{x:704,y:526,t:1527873636712};\\\", \\\"{x:687,y:526,t:1527873636729};\\\", \\\"{x:667,y:526,t:1527873636746};\\\", \\\"{x:656,y:526,t:1527873636763};\\\", \\\"{x:650,y:526,t:1527873636779};\\\", \\\"{x:648,y:526,t:1527873636795};\\\", \\\"{x:647,y:526,t:1527873636841};\\\", \\\"{x:646,y:526,t:1527873637027};\\\", \\\"{x:644,y:526,t:1527873637050};\\\", \\\"{x:642,y:526,t:1527873637065};\\\", \\\"{x:637,y:526,t:1527873637079};\\\", \\\"{x:621,y:524,t:1527873637096};\\\", \\\"{x:601,y:521,t:1527873637114};\\\", \\\"{x:598,y:520,t:1527873637130};\\\", \\\"{x:596,y:520,t:1527873637146};\\\", \\\"{x:594,y:520,t:1527873637163};\\\", \\\"{x:591,y:520,t:1527873637180};\\\", \\\"{x:591,y:519,t:1527873637298};\\\", \\\"{x:591,y:518,t:1527873637322};\\\", \\\"{x:592,y:518,t:1527873637674};\\\", \\\"{x:593,y:518,t:1527873637690};\\\", \\\"{x:594,y:518,t:1527873637721};\\\", \\\"{x:595,y:518,t:1527873637754};\\\", \\\"{x:596,y:518,t:1527873637770};\\\", \\\"{x:597,y:518,t:1527873637802};\\\", \\\"{x:598,y:518,t:1527873637826};\\\", \\\"{x:600,y:518,t:1527873637835};\\\", \\\"{x:603,y:518,t:1527873637847};\\\", \\\"{x:604,y:518,t:1527873637864};\\\", \\\"{x:605,y:518,t:1527873637880};\\\", \\\"{x:606,y:518,t:1527873638114};\\\", \\\"{x:605,y:520,t:1527873638153};\\\", \\\"{x:603,y:525,t:1527873638164};\\\", \\\"{x:596,y:538,t:1527873638180};\\\", \\\"{x:589,y:558,t:1527873638197};\\\", \\\"{x:579,y:582,t:1527873638215};\\\", \\\"{x:570,y:604,t:1527873638230};\\\", \\\"{x:563,y:623,t:1527873638247};\\\", \\\"{x:558,y:641,t:1527873638263};\\\", \\\"{x:557,y:660,t:1527873638281};\\\", \\\"{x:549,y:690,t:1527873638297};\\\", \\\"{x:546,y:703,t:1527873638314};\\\", \\\"{x:541,y:712,t:1527873638331};\\\", \\\"{x:540,y:718,t:1527873638347};\\\", \\\"{x:539,y:723,t:1527873638364};\\\", \\\"{x:539,y:729,t:1527873638381};\\\", \\\"{x:538,y:738,t:1527873638397};\\\", \\\"{x:535,y:747,t:1527873638414};\\\", \\\"{x:534,y:751,t:1527873638430};\\\", \\\"{x:531,y:754,t:1527873638447};\\\", \\\"{x:530,y:756,t:1527873638464};\\\", \\\"{x:530,y:757,t:1527873638481};\\\", \\\"{x:530,y:758,t:1527873638497};\\\", \\\"{x:530,y:759,t:1527873638537};\\\", \\\"{x:530,y:761,t:1527873638553};\\\", \\\"{x:529,y:762,t:1527873638564};\\\", \\\"{x:529,y:764,t:1527873638581};\\\", \\\"{x:527,y:765,t:1527873638597};\\\" ] }, { \\\"rt\\\": 75162, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 667006, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"9BS72\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"To determine which event starts at 12pm. You look at the bottom of the chart with the labels of time. You find 12pm and anything that lays between the line upwards means that an event starts at 12pm.\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 6294, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"20\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"USA\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 674306, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"9BS72\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 18499, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Spanish\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Second\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Fine Arts\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 693836, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"9BS72\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 37642, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 732862, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"9BS72\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"9BS72\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 250, dom: 599, initialDom: 695",
  "javascriptErrors": []
}