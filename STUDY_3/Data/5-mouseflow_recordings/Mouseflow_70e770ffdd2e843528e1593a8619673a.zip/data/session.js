var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "70e770ffdd2e843528e1593a8619673a",
  "created": "2018-05-29T15:13:21.2263602-07:00",
  "lastActivity": "2018-05-29T15:13:41.9667936-07:00",
  "pageViews": [
    {
      "id": "052921606b76194a3f9a15bb04f3769755b75e95",
      "startTime": "2018-05-29T15:13:21.308412-07:00",
      "endTime": "2018-05-29T15:13:41.9667936-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/7",
      "visitTime": 20746,
      "engagementTime": 20646,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 20746,
  "engagementTime": 20646,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.37",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=FA2ZF",
    "CONDITION=114",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "428bbe94b8c7cc799668f6675aea7e0e",
  "gdpr": false
}