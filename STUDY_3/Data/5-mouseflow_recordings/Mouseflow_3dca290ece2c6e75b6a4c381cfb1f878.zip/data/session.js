var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "3dca290ece2c6e75b6a4c381cfb1f878",
  "created": "2018-05-22T10:12:25.5541394-07:00",
  "lastActivity": "2018-05-22T10:15:16.2921394-07:00",
  "pageViews": [
    {
      "id": "052225489b736f23cf1543f7a7b159feaf084664",
      "startTime": "2018-05-22T10:12:25.5541394-07:00",
      "endTime": "2018-05-22T10:15:16.2921394-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/5",
      "visitTime": 170738,
      "engagementTime": 95118,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 170738,
  "engagementTime": 95118,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.29",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=VSHHA",
    "CONDITION=121",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "6af366d53a8aec52ddc7f2e664030c7b",
  "gdpr": false
}