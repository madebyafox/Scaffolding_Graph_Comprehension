var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "b3dd56ecb9f7d4d0f2b8fc157b800369",
  "created": "2018-05-24T12:05:22.8266001-07:00",
  "lastActivity": "2018-05-24T12:05:56.0826001-07:00",
  "pageViews": [
    {
      "id": "05242346798d3f8bf5790a35318d948dc1ab5e4a",
      "startTime": "2018-05-24T12:05:22.8266001-07:00",
      "endTime": "2018-05-24T12:05:56.0826001-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/1",
      "visitTime": 33256,
      "engagementTime": 29229,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 33256,
  "engagementTime": 29229,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.28",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=FN9LT",
    "CONDITION=113",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "5f27a825111f824f0b89e39468373eaa",
  "gdpr": false
}