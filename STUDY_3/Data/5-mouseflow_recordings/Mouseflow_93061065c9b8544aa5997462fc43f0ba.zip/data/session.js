var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "93061065c9b8544aa5997462fc43f0ba",
  "created": "2018-05-24T12:11:22.5192269-07:00",
  "lastActivity": "2018-05-24T12:12:28.4292269-07:00",
  "pageViews": [
    {
      "id": "0524220265a5d00b758f4668ffd0fd1b062be6dd",
      "startTime": "2018-05-24T12:11:22.5192269-07:00",
      "endTime": "2018-05-24T12:12:28.4292269-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/13",
      "visitTime": 65910,
      "engagementTime": 61660,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 65910,
  "engagementTime": 61660,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.24",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=SWST4",
    "CONDITION=113"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "74b7f5c1fbafb6e739a48e3de2ae433e",
  "gdpr": false
}