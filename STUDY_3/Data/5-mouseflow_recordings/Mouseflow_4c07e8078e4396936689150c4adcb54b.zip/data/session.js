var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "4c07e8078e4396936689150c4adcb54b",
  "created": "2018-05-24T12:10:31.0811406-07:00",
  "lastActivity": "2018-05-24T12:10:43.0611406-07:00",
  "pageViews": [
    {
      "id": "05243145ebe2af4a595fa41294b46218cd10aa36",
      "startTime": "2018-05-24T12:10:31.0811406-07:00",
      "endTime": "2018-05-24T12:10:43.0611406-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/14",
      "visitTime": 11980,
      "engagementTime": 10664,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 11980,
  "engagementTime": 10664,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.36",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=ZUJQV",
    "CONDITION=113",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "d94029d3dba7b758e3c1758000a47f04",
  "gdpr": false
}