var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "08b59333591a92843193e3c2f3eaf962",
  "created": "2018-05-22T14:09:18.7600976-07:00",
  "lastActivity": "2018-05-22T14:09:48.6759658-07:00",
  "pageViews": [
    {
      "id": "05221886ecd6d3a047cf2084e782e02e7f29d691",
      "startTime": "2018-05-22T14:09:18.8217024-07:00",
      "endTime": "2018-05-22T14:09:48.6759658-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/7",
      "visitTime": 29950,
      "engagementTime": 29935,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 29950,
  "engagementTime": 29935,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.28",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=YP2FK",
    "CONDITION=121",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "d9530c75d6e2b3c1192d28a79db7f2b9",
  "gdpr": false
}