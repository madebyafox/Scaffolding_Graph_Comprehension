var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "2ca9a745636c64c14897069f4c5c82e6",
  "created": "2018-05-29T16:17:51.9029707-07:00",
  "lastActivity": "2018-05-29T16:19:24.0279707-07:00",
  "pageViews": [
    {
      "id": "05295227a8a7ccd3643f00d8cc45236aac7e00dc",
      "startTime": "2018-05-29T16:17:51.9029707-07:00",
      "endTime": "2018-05-29T16:19:24.0279707-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 92125,
      "engagementTime": 82727,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 92125,
  "engagementTime": 82727,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.39",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "67.0.3396.62",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=CSU5Z",
    "CONDITION=113"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "da9eca78e791b53b0c79fb662d54f1bf",
  "gdpr": false
}