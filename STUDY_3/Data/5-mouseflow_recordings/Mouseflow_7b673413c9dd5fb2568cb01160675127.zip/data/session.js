var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "7b673413c9dd5fb2568cb01160675127",
  "created": "2018-05-24T12:08:21.2454816-07:00",
  "lastActivity": "2018-05-24T12:08:53.0028701-07:00",
  "pageViews": [
    {
      "id": "0524211293fa1308fff42784a3a79eae2b861688",
      "startTime": "2018-05-24T12:08:21.3309275-07:00",
      "endTime": "2018-05-24T12:08:53.0028701-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/7",
      "visitTime": 31785,
      "engagementTime": 29756,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 31785,
  "engagementTime": 29756,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.23",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=XKNWZ",
    "CONDITION=113",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "075fbae0e16c38e680bd3568ce71597a",
  "gdpr": false
}