var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["052527397af4d32532dd741cd6c553f86cc701ac"] = {
  "startTime": "2018-05-25T17:15:27.8653039Z",
  "websitePageUrl": "/16",
  "visitTime": 88977,
  "engagementTime": 88146,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "d7b5b71450a6ee39a39e955b89bdd18b",
    "created": "2018-05-25T17:15:27.6928309+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=967LR",
      "CONDITION=115"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "3223ff8592acbbee7db295fbabcb0df1",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/d7b5b71450a6ee39a39e955b89bdd18b/play"
  },
  "events": [
    {
      "t": 0,
      "e": 0,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 204,
      "e": 204,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 1600,
      "e": 1600,
      "ty": 2,
      "x": 499,
      "y": 626
    },
    {
      "t": 1629,
      "e": 1629,
      "ty": 6,
      "x": 483,
      "y": 601,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1701,
      "e": 1701,
      "ty": 2,
      "x": 416,
      "y": 542
    },
    {
      "t": 1750,
      "e": 1750,
      "ty": 41,
      "x": 34499,
      "y": 9923,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1800,
      "e": 1800,
      "ty": 2,
      "x": 404,
      "y": 535
    },
    {
      "t": 2114,
      "e": 2114,
      "ty": 3,
      "x": 404,
      "y": 535,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2115,
      "e": 2115,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2192,
      "e": 2192,
      "ty": 4,
      "x": 34499,
      "y": 9923,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2192,
      "e": 2192,
      "ty": 5,
      "x": 404,
      "y": 535,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2751,
      "e": 2751,
      "ty": 41,
      "x": 33824,
      "y": 11541,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2800,
      "e": 2800,
      "ty": 2,
      "x": 389,
      "y": 551
    },
    {
      "t": 2900,
      "e": 2900,
      "ty": 2,
      "x": 380,
      "y": 568
    },
    {
      "t": 3000,
      "e": 3000,
      "ty": 41,
      "x": 31801,
      "y": 36623,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5342,
      "e": 5342,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 5541,
      "e": 5541,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 5542,
      "e": 5542,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5604,
      "e": 5604,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "T"
    },
    {
      "t": 5637,
      "e": 5637,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "T"
    },
    {
      "t": 5693,
      "e": 5693,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 5693,
      "e": 5693,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5773,
      "e": 5773,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To"
    },
    {
      "t": 5837,
      "e": 5837,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 5838,
      "e": 5838,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5924,
      "e": 5924,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To "
    },
    {
      "t": 6052,
      "e": 6052,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 6053,
      "e": 6053,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6100,
      "e": 6100,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 6100,
      "e": 6100,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6140,
      "e": 6140,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To fi"
    },
    {
      "t": 6164,
      "e": 6164,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 6501,
      "e": 6501,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 6501,
      "e": 6501,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6556,
      "e": 6556,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 6556,
      "e": 6556,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6564,
      "e": 6564,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||gu"
    },
    {
      "t": 6612,
      "e": 6612,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 6684,
      "e": 6684,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 6684,
      "e": 6684,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6764,
      "e": 6764,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 6828,
      "e": 6828,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 6828,
      "e": 6828,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6908,
      "e": 6908,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 6924,
      "e": 6924,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 6925,
      "e": 6925,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6996,
      "e": 6996,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 7036,
      "e": 7036,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 7036,
      "e": 7036,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7141,
      "e": 7141,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 7181,
      "e": 7181,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 7182,
      "e": 7182,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7244,
      "e": 7244,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 7244,
      "e": 7244,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7269,
      "e": 7269,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ut"
    },
    {
      "t": 7373,
      "e": 7373,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 7405,
      "e": 7405,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 7406,
      "e": 7406,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7477,
      "e": 7477,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 7602,
      "e": 7602,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To figure out "
    },
    {
      "t": 7893,
      "e": 7893,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 7894,
      "e": 7894,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8001,
      "e": 8001,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To figure out w"
    },
    {
      "t": 8037,
      "e": 8037,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 8109,
      "e": 8109,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 8109,
      "e": 8109,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8124,
      "e": 8124,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 8124,
      "e": 8124,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8172,
      "e": 8172,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ha"
    },
    {
      "t": 8253,
      "e": 8253,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 8277,
      "e": 8277,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 8278,
      "e": 8278,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8332,
      "e": 8332,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 8332,
      "e": 8332,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8365,
      "e": 8365,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 8412,
      "e": 8412,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 8492,
      "e": 8492,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 8494,
      "e": 8494,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8588,
      "e": 8588,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 8693,
      "e": 8693,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 8693,
      "e": 8693,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8716,
      "e": 8716,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 8717,
      "e": 8717,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8757,
      "e": 8757,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||vc"
    },
    {
      "t": 8805,
      "e": 8805,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 9397,
      "e": 9397,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 9493,
      "e": 9493,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To figure out what ev"
    },
    {
      "t": 9540,
      "e": 9540,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 9540,
      "e": 9540,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9644,
      "e": 9644,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 9733,
      "e": 9733,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 9733,
      "e": 9733,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9804,
      "e": 9804,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 9828,
      "e": 9828,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 9828,
      "e": 9828,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9900,
      "e": 9900,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 9981,
      "e": 9981,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 9982,
      "e": 9982,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9999,
      "e": 9999,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10068,
      "e": 10068,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 10068,
      "e": 10068,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10092,
      "e": 10092,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s "
    },
    {
      "t": 10173,
      "e": 10173,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 10388,
      "e": 10388,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 10388,
      "e": 10388,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10565,
      "e": 10565,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 10613,
      "e": 10613,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 10614,
      "e": 10614,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10757,
      "e": 10757,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 10837,
      "e": 10837,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 10838,
      "e": 10838,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10981,
      "e": 10981,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 10981,
      "e": 10981,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11012,
      "e": 11012,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 11069,
      "e": 11069,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 11181,
      "e": 11181,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 11181,
      "e": 11181,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11244,
      "e": 11244,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 11316,
      "e": 11316,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11317,
      "e": 11317,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11413,
      "e": 11413,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 11453,
      "e": 11453,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 11453,
      "e": 11453,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11603,
      "e": 11603,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To figure out what events start a"
    },
    {
      "t": 11604,
      "e": 11604,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 11677,
      "e": 11677,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 11678,
      "e": 11678,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11757,
      "e": 11757,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 11772,
      "e": 11772,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11772,
      "e": 11772,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11852,
      "e": 11852,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 12133,
      "e": 12133,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 12134,
      "e": 12134,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12237,
      "e": 12237,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 12237,
      "e": 12237,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12252,
      "e": 12252,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 12389,
      "e": 12389,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12908,
      "e": 12908,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 12908,
      "e": 12908,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13037,
      "e": 13037,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 13228,
      "e": 13228,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13230,
      "e": 13230,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13300,
      "e": 13300,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 13402,
      "e": 13402,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To figure out what events start at 12, "
    },
    {
      "t": 13517,
      "e": 13517,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13572,
      "e": 13572,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To figure out what events start at 12,"
    },
    {
      "t": 13676,
      "e": 13676,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13733,
      "e": 13733,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To figure out what events start at 12"
    },
    {
      "t": 13869,
      "e": 13869,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13870,
      "e": 13870,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13925,
      "e": 13925,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 13941,
      "e": 13941,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "219"
    },
    {
      "t": 13942,
      "e": 13942,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14036,
      "e": 14036,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||["
    },
    {
      "t": 14405,
      "e": 14405,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 14500,
      "e": 14500,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To figure out what events start at 12 "
    },
    {
      "t": 14601,
      "e": 14601,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To figure out what events start at 12 "
    },
    {
      "t": 14740,
      "e": 14740,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 14740,
      "e": 14740,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14892,
      "e": 14892,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 15037,
      "e": 15037,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 15038,
      "e": 15038,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15141,
      "e": 15141,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 15429,
      "e": 15429,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 15429,
      "e": 15429,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15533,
      "e": 15533,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||,"
    },
    {
      "t": 15637,
      "e": 15637,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15637,
      "e": 15637,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15701,
      "e": 15701,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 15802,
      "e": 15802,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To figure out what events start at 12 pm, "
    },
    {
      "t": 15813,
      "e": 15813,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 15814,
      "e": 15814,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15820,
      "e": 15820,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 15820,
      "e": 15820,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15852,
      "e": 15852,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||yu"
    },
    {
      "t": 15860,
      "e": 15860,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16002,
      "e": 16002,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To figure out what events start at 12 pm, yu"
    },
    {
      "t": 16461,
      "e": 16461,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16548,
      "e": 16548,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To figure out what events start at 12 pm, y"
    },
    {
      "t": 16820,
      "e": 16820,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 16822,
      "e": 16822,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16909,
      "e": 16909,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 16973,
      "e": 16973,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 16974,
      "e": 16974,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17037,
      "e": 17037,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 17543,
      "e": 17038,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 17620,
      "e": 17115,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To figure out what events start at 12 pm, yp"
    },
    {
      "t": 17716,
      "e": 17211,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 17813,
      "e": 17308,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To figure out what events start at 12 pm, y"
    },
    {
      "t": 17989,
      "e": 17484,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 17989,
      "e": 17484,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18124,
      "e": 17619,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 18213,
      "e": 17708,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 18213,
      "e": 17708,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18284,
      "e": 17779,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 18388,
      "e": 17883,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18389,
      "e": 17884,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18453,
      "e": 17948,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18541,
      "e": 18036,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 18542,
      "e": 18037,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18636,
      "e": 18131,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 18740,
      "e": 18235,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 18741,
      "e": 18236,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18853,
      "e": 18348,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 18885,
      "e": 18380,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 18885,
      "e": 18380,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19001,
      "e": 18496,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To figure out what events start at 12 pm, you tra"
    },
    {
      "t": 19004,
      "e": 18499,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 19117,
      "e": 18612,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 19117,
      "e": 18612,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19148,
      "e": 18643,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 19437,
      "e": 18932,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 19437,
      "e": 18932,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19524,
      "e": 19019,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 19605,
      "e": 19100,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19605,
      "e": 19100,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19709,
      "e": 19204,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 19909,
      "e": 19404,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 19910,
      "e": 19405,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19980,
      "e": 19475,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 19980,
      "e": 19475,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20044,
      "e": 19539,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 20052,
      "e": 19547,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20116,
      "e": 19611,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 20117,
      "e": 19612,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20228,
      "e": 19723,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20229,
      "e": 19724,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20260,
      "e": 19755,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 20325,
      "e": 19820,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20565,
      "e": 20060,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 20565,
      "e": 20060,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20684,
      "e": 20179,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 21229,
      "e": 20724,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 21229,
      "e": 20724,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21341,
      "e": 20836,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 21493,
      "e": 20988,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 21493,
      "e": 20988,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21602,
      "e": 21097,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To figure out what events start at 12 pm, you trace the sta"
    },
    {
      "t": 21653,
      "e": 21148,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 21653,
      "e": 21148,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21684,
      "e": 21179,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 21788,
      "e": 21283,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24436,
      "e": 23931,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 24436,
      "e": 23931,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24564,
      "e": 24059,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 24661,
      "e": 24156,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24662,
      "e": 24157,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24740,
      "e": 24235,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25461,
      "e": 24956,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 25462,
      "e": 24957,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25565,
      "e": 25060,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 25566,
      "e": 25061,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25596,
      "e": 25091,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ti"
    },
    {
      "t": 25643,
      "e": 25138,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25756,
      "e": 25251,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 25757,
      "e": 25252,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25844,
      "e": 25339,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 25884,
      "e": 25379,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 25884,
      "e": 25379,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25964,
      "e": 25459,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 26005,
      "e": 25500,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26005,
      "e": 25500,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26076,
      "e": 25571,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 26182,
      "e": 25677,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 26183,
      "e": 25678,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26252,
      "e": 25747,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 26284,
      "e": 25779,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 26285,
      "e": 25780,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26372,
      "e": 25867,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 26396,
      "e": 25891,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26397,
      "e": 25892,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26492,
      "e": 25987,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27253,
      "e": 26748,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 27253,
      "e": 26748,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27401,
      "e": 26896,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To figure out what events start at 12 pm, you trace the start time of 1"
    },
    {
      "t": 27436,
      "e": 26931,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||1"
    },
    {
      "t": 27573,
      "e": 27068,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 27574,
      "e": 27069,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27700,
      "e": 27195,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||2"
    },
    {
      "t": 29300,
      "e": 28795,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 29301,
      "e": 28796,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29396,
      "e": 28891,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 29493,
      "e": 28892,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 29494,
      "e": 28893,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29600,
      "e": 28999,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To figure out what events start at 12 pm, you trace the start time of 12pm"
    },
    {
      "t": 29620,
      "e": 29019,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 29661,
      "e": 29060,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29661,
      "e": 29060,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29755,
      "e": 29154,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 29892,
      "e": 29291,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 29892,
      "e": 29291,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29965,
      "e": 29364,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 29988,
      "e": 29387,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 29988,
      "e": 29387,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30076,
      "e": 29475,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 30156,
      "e": 29555,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30157,
      "e": 29556,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30252,
      "e": 29651,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30293,
      "e": 29692,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 30294,
      "e": 29693,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30364,
      "e": 29763,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 30372,
      "e": 29771,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 30373,
      "e": 29772,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30427,
      "e": 29826,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 30484,
      "e": 29883,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 30484,
      "e": 29883,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30548,
      "e": 29947,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 30556,
      "e": 29955,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30556,
      "e": 29955,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30628,
      "e": 30027,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30677,
      "e": 30076,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 30678,
      "e": 30077,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30771,
      "e": 30170,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 30772,
      "e": 30171,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30812,
      "e": 30211,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||du"
    },
    {
      "t": 30844,
      "e": 30243,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30916,
      "e": 30315,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 30917,
      "e": 30316,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31004,
      "e": 30403,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 31076,
      "e": 30475,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 31077,
      "e": 30476,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31172,
      "e": 30571,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 31173,
      "e": 30572,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 31174,
      "e": 30573,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31220,
      "e": 30619,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 31220,
      "e": 30619,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31243,
      "e": 30642,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ti"
    },
    {
      "t": 31340,
      "e": 30739,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 31341,
      "e": 30740,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31348,
      "e": 30747,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 31388,
      "e": 30787,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 31540,
      "e": 30939,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31541,
      "e": 30940,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31651,
      "e": 31050,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 31906,
      "e": 31305,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31977,
      "e": 31376,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To figure out what events start at 12 pm, you trace the start time of 12pm to the duratio"
    },
    {
      "t": 32154,
      "e": 31553,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 32155,
      "e": 31554,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32234,
      "e": 31633,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 32313,
      "e": 31712,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32314,
      "e": 31713,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32394,
      "e": 31793,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 32434,
      "e": 31833,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 32435,
      "e": 31834,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32498,
      "e": 31897,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 32586,
      "e": 31985,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 32586,
      "e": 31985,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32657,
      "e": 32056,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 32698,
      "e": 32097,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32699,
      "e": 32098,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32753,
      "e": 32152,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 32802,
      "e": 32201,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 32802,
      "e": 32201,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32874,
      "e": 32273,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 32947,
      "e": 32346,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 32947,
      "e": 32346,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33025,
      "e": 32424,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 33074,
      "e": 32473,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 33075,
      "e": 32474,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33130,
      "e": 32529,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 33130,
      "e": 32529,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33145,
      "e": 32544,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ur"
    },
    {
      "t": 33209,
      "e": 32608,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33234,
      "e": 32633,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 33234,
      "e": 32633,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33386,
      "e": 32785,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 34170,
      "e": 33569,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 34171,
      "e": 33570,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34233,
      "e": 33632,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 35137,
      "e": 34536,
      "ty": 7,
      "x": 380,
      "y": 607,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35197,
      "e": 34596,
      "ty": 2,
      "x": 380,
      "y": 628
    },
    {
      "t": 35248,
      "e": 34647,
      "ty": 41,
      "x": 28744,
      "y": 4106,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 35297,
      "e": 34696,
      "ty": 2,
      "x": 380,
      "y": 636
    },
    {
      "t": 35303,
      "e": 34702,
      "ty": 6,
      "x": 380,
      "y": 666,
      "ta": "#strategyButton"
    },
    {
      "t": 35321,
      "e": 34720,
      "ty": 7,
      "x": 380,
      "y": 689,
      "ta": "#strategyButton"
    },
    {
      "t": 35397,
      "e": 34796,
      "ty": 2,
      "x": 380,
      "y": 690
    },
    {
      "t": 35496,
      "e": 34895,
      "ty": 2,
      "x": 382,
      "y": 690
    },
    {
      "t": 35497,
      "e": 34896,
      "ty": 41,
      "x": 29680,
      "y": 44737,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 35521,
      "e": 34920,
      "ty": 6,
      "x": 387,
      "y": 686,
      "ta": "#strategyButton"
    },
    {
      "t": 35597,
      "e": 34996,
      "ty": 2,
      "x": 389,
      "y": 682
    },
    {
      "t": 35747,
      "e": 35146,
      "ty": 41,
      "x": 27528,
      "y": 52554,
      "ta": "#strategyButton"
    },
    {
      "t": 35759,
      "e": 35158,
      "ty": 3,
      "x": 389,
      "y": 682,
      "ta": "#strategyButton"
    },
    {
      "t": 35761,
      "e": 35159,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "To figure out what events start at 12 pm, you trace the start time of 12pm to the duration in hours."
    },
    {
      "t": 35762,
      "e": 35160,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35763,
      "e": 35161,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 35821,
      "e": 35219,
      "ty": 4,
      "x": 27528,
      "y": 52554,
      "ta": "#strategyButton"
    },
    {
      "t": 35830,
      "e": 35228,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 35832,
      "e": 35230,
      "ty": 5,
      "x": 389,
      "y": 682,
      "ta": "#strategyButton"
    },
    {
      "t": 35838,
      "e": 35236,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 36835,
      "e": 36233,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 37397,
      "e": 36795,
      "ty": 2,
      "x": 745,
      "y": 572
    },
    {
      "t": 37497,
      "e": 36895,
      "ty": 2,
      "x": 800,
      "y": 557
    },
    {
      "t": 37497,
      "e": 36895,
      "ty": 41,
      "x": 27274,
      "y": 30413,
      "ta": "html > body"
    },
    {
      "t": 37597,
      "e": 36995,
      "ty": 2,
      "x": 846,
      "y": 539
    },
    {
      "t": 37656,
      "e": 37054,
      "ty": 6,
      "x": 852,
      "y": 554,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 37697,
      "e": 37095,
      "ty": 2,
      "x": 855,
      "y": 557
    },
    {
      "t": 37747,
      "e": 37145,
      "ty": 41,
      "x": 10165,
      "y": 9362,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 38007,
      "e": 37405,
      "ty": 3,
      "x": 855,
      "y": 557,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 38008,
      "e": 37406,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 38077,
      "e": 37475,
      "ty": 4,
      "x": 10165,
      "y": 9362,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 38077,
      "e": 37475,
      "ty": 5,
      "x": 855,
      "y": 557,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 38858,
      "e": 38256,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "97"
    },
    {
      "t": 38859,
      "e": 38257,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 38938,
      "e": 38336,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 39186,
      "e": 38584,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "105"
    },
    {
      "t": 39187,
      "e": 38585,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 39234,
      "e": 38632,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 39747,
      "e": 39145,
      "ty": 41,
      "x": 8651,
      "y": 15603,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 39773,
      "e": 39171,
      "ty": 7,
      "x": 803,
      "y": 578,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 39797,
      "e": 39195,
      "ty": 2,
      "x": 788,
      "y": 584
    },
    {
      "t": 39897,
      "e": 39295,
      "ty": 2,
      "x": 779,
      "y": 597
    },
    {
      "t": 39997,
      "e": 39395,
      "ty": 2,
      "x": 779,
      "y": 649
    },
    {
      "t": 39998,
      "e": 39396,
      "ty": 41,
      "x": 26551,
      "y": 35509,
      "ta": "html > body"
    },
    {
      "t": 40059,
      "e": 39457,
      "ty": 6,
      "x": 820,
      "y": 665,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40074,
      "e": 39472,
      "ty": 7,
      "x": 832,
      "y": 670,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40098,
      "e": 39496,
      "ty": 2,
      "x": 839,
      "y": 673
    },
    {
      "t": 40197,
      "e": 39595,
      "ty": 2,
      "x": 843,
      "y": 675
    },
    {
      "t": 40247,
      "e": 39645,
      "ty": 41,
      "x": 8002,
      "y": 61306,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 40259,
      "e": 39657,
      "ty": 6,
      "x": 840,
      "y": 661,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40297,
      "e": 39695,
      "ty": 2,
      "x": 836,
      "y": 651
    },
    {
      "t": 40397,
      "e": 39795,
      "ty": 2,
      "x": 836,
      "y": 650
    },
    {
      "t": 40438,
      "e": 39836,
      "ty": 3,
      "x": 836,
      "y": 650,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40439,
      "e": 39837,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 40439,
      "e": 39837,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 40439,
      "e": 39837,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40498,
      "e": 39896,
      "ty": 41,
      "x": 6056,
      "y": 9362,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40502,
      "e": 39900,
      "ty": 4,
      "x": 6056,
      "y": 9362,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40502,
      "e": 39900,
      "ty": 5,
      "x": 836,
      "y": 650,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 41234,
      "e": 40632,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 41298,
      "e": 40696,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 41299,
      "e": 40697,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 41369,
      "e": 40767,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 41401,
      "e": 40799,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 41522,
      "e": 40920,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 41522,
      "e": 40920,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 41570,
      "e": 40968,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Un"
    },
    {
      "t": 41666,
      "e": 41064,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 41667,
      "e": 41065,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 41705,
      "e": 41103,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Uni"
    },
    {
      "t": 41745,
      "e": 41143,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 41745,
      "e": 41143,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 41857,
      "e": 41255,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Unit"
    },
    {
      "t": 41906,
      "e": 41304,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 41907,
      "e": 41305,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 41994,
      "e": 41392,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 42082,
      "e": 41480,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "68"
    },
    {
      "t": 42082,
      "e": 41480,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 42138,
      "e": 41536,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 42139,
      "e": 41537,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 42170,
      "e": 41568,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||d "
    },
    {
      "t": 42250,
      "e": 41648,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 42338,
      "e": 41736,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 42378,
      "e": 41776,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 42378,
      "e": 41776,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 42522,
      "e": 41920,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||S"
    },
    {
      "t": 42538,
      "e": 41936,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 42586,
      "e": 41984,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 42587,
      "e": 41985,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 42665,
      "e": 42063,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 42746,
      "e": 42144,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 42746,
      "e": 42144,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 42873,
      "e": 42271,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 42882,
      "e": 42280,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 42883,
      "e": 42281,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 42998,
      "e": 42396,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United Stat"
    },
    {
      "t": 43017,
      "e": 42415,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||t"
    },
    {
      "t": 43025,
      "e": 42423,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 43026,
      "e": 42424,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 43199,
      "e": 42597,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United State"
    },
    {
      "t": 43218,
      "e": 42616,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 43219,
      "e": 42617,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 43242,
      "e": 42640,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||es"
    },
    {
      "t": 43298,
      "e": 42696,
      "ty": 2,
      "x": 846,
      "y": 657
    },
    {
      "t": 43346,
      "e": 42744,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 43397,
      "e": 42795,
      "ty": 2,
      "x": 848,
      "y": 657
    },
    {
      "t": 43498,
      "e": 42896,
      "ty": 2,
      "x": 890,
      "y": 664
    },
    {
      "t": 43498,
      "e": 42896,
      "ty": 41,
      "x": 17735,
      "y": 53052,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 43511,
      "e": 42909,
      "ty": 7,
      "x": 901,
      "y": 669,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 43526,
      "e": 42924,
      "ty": 6,
      "x": 910,
      "y": 676,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 43576,
      "e": 42974,
      "ty": 7,
      "x": 929,
      "y": 713,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 43597,
      "e": 42995,
      "ty": 2,
      "x": 930,
      "y": 717
    },
    {
      "t": 43698,
      "e": 43096,
      "ty": 2,
      "x": 935,
      "y": 718
    },
    {
      "t": 43748,
      "e": 43146,
      "ty": 41,
      "x": 31923,
      "y": 39332,
      "ta": "html > body"
    },
    {
      "t": 43897,
      "e": 43295,
      "ty": 2,
      "x": 943,
      "y": 716
    },
    {
      "t": 43997,
      "e": 43395,
      "ty": 2,
      "x": 944,
      "y": 715
    },
    {
      "t": 43998,
      "e": 43396,
      "ty": 41,
      "x": 32233,
      "y": 39165,
      "ta": "html > body"
    },
    {
      "t": 44097,
      "e": 43495,
      "ty": 2,
      "x": 950,
      "y": 711
    },
    {
      "t": 44196,
      "e": 43594,
      "ty": 6,
      "x": 954,
      "y": 708,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 44197,
      "e": 43595,
      "ty": 2,
      "x": 954,
      "y": 708
    },
    {
      "t": 44248,
      "e": 43646,
      "ty": 41,
      "x": 33025,
      "y": 55605,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 44297,
      "e": 43695,
      "ty": 2,
      "x": 960,
      "y": 704
    },
    {
      "t": 44495,
      "e": 43893,
      "ty": 3,
      "x": 960,
      "y": 704,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 44496,
      "e": 43893,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "United States"
    },
    {
      "t": 44498,
      "e": 43895,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 44498,
      "e": 43895,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 44573,
      "e": 43970,
      "ty": 4,
      "x": 33025,
      "y": 55605,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 44573,
      "e": 43970,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 44574,
      "e": 43971,
      "ty": 5,
      "x": 960,
      "y": 704,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 44575,
      "e": 43972,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 45598,
      "e": 44995,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 46097,
      "e": 45494,
      "ty": 2,
      "x": 869,
      "y": 384
    },
    {
      "t": 46113,
      "e": 45510,
      "ty": 6,
      "x": 835,
      "y": 322,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 46128,
      "e": 45525,
      "ty": 7,
      "x": 807,
      "y": 268,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 46198,
      "e": 45595,
      "ty": 2,
      "x": 757,
      "y": 204
    },
    {
      "t": 46247,
      "e": 45644,
      "ty": 41,
      "x": 25793,
      "y": 10857,
      "ta": "html > body"
    },
    {
      "t": 46397,
      "e": 45794,
      "ty": 2,
      "x": 773,
      "y": 199
    },
    {
      "t": 46497,
      "e": 45894,
      "ty": 2,
      "x": 827,
      "y": 193
    },
    {
      "t": 46498,
      "e": 45895,
      "ty": 41,
      "x": 1323,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-0 > p"
    },
    {
      "t": 46597,
      "e": 45994,
      "ty": 2,
      "x": 818,
      "y": 206
    },
    {
      "t": 46697,
      "e": 46094,
      "ty": 2,
      "x": 816,
      "y": 223
    },
    {
      "t": 46746,
      "e": 46143,
      "ty": 6,
      "x": 829,
      "y": 234,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 46747,
      "e": 46144,
      "ty": 41,
      "x": 12996,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 46797,
      "e": 46194,
      "ty": 2,
      "x": 837,
      "y": 234
    },
    {
      "t": 46997,
      "e": 46394,
      "ty": 41,
      "x": 53325,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 47086,
      "e": 46483,
      "ty": 3,
      "x": 837,
      "y": 234,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 47087,
      "e": 46484,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 47117,
      "e": 46514,
      "ty": 7,
      "x": 842,
      "y": 234,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 47173,
      "e": 46570,
      "ty": 4,
      "x": 16850,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 47198,
      "e": 46595,
      "ty": 2,
      "x": 842,
      "y": 234
    },
    {
      "t": 47248,
      "e": 46645,
      "ty": 41,
      "x": 16850,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 47297,
      "e": 46694,
      "ty": 2,
      "x": 843,
      "y": 241
    },
    {
      "t": 47498,
      "e": 46895,
      "ty": 41,
      "x": 17669,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 47648,
      "e": 47045,
      "ty": 6,
      "x": 837,
      "y": 243,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 47680,
      "e": 47077,
      "ty": 7,
      "x": 832,
      "y": 245,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 47697,
      "e": 47094,
      "ty": 2,
      "x": 830,
      "y": 246
    },
    {
      "t": 47748,
      "e": 47145,
      "ty": 41,
      "x": 7024,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 47898,
      "e": 47295,
      "ty": 2,
      "x": 836,
      "y": 245
    },
    {
      "t": 47997,
      "e": 47394,
      "ty": 2,
      "x": 837,
      "y": 245
    },
    {
      "t": 47998,
      "e": 47395,
      "ty": 41,
      "x": 12756,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 48071,
      "e": 47468,
      "ty": 3,
      "x": 837,
      "y": 245,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 48072,
      "e": 47469,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 48165,
      "e": 47562,
      "ty": 4,
      "x": 12756,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 48165,
      "e": 47562,
      "ty": 5,
      "x": 837,
      "y": 245,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 48166,
      "e": 47563,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 48166,
      "e": 47563,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 48597,
      "e": 47994,
      "ty": 2,
      "x": 1002,
      "y": 562
    },
    {
      "t": 48698,
      "e": 48095,
      "ty": 2,
      "x": 1005,
      "y": 568
    },
    {
      "t": 48748,
      "e": 48145,
      "ty": 41,
      "x": 42618,
      "y": 46810,
      "ta": "#jspsych-survey-multi-choice-option-1-5"
    },
    {
      "t": 48797,
      "e": 48194,
      "ty": 2,
      "x": 967,
      "y": 539
    },
    {
      "t": 48898,
      "e": 48295,
      "ty": 2,
      "x": 934,
      "y": 516
    },
    {
      "t": 48998,
      "e": 48395,
      "ty": 2,
      "x": 911,
      "y": 504
    },
    {
      "t": 48998,
      "e": 48395,
      "ty": 41,
      "x": 21259,
      "y": 44470,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 49097,
      "e": 48494,
      "ty": 2,
      "x": 909,
      "y": 504
    },
    {
      "t": 49198,
      "e": 48595,
      "ty": 2,
      "x": 895,
      "y": 505
    },
    {
      "t": 49248,
      "e": 48645,
      "ty": 41,
      "x": 56166,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 49298,
      "e": 48695,
      "ty": 2,
      "x": 868,
      "y": 500
    },
    {
      "t": 49398,
      "e": 48795,
      "ty": 2,
      "x": 864,
      "y": 499
    },
    {
      "t": 49497,
      "e": 48894,
      "ty": 2,
      "x": 863,
      "y": 480
    },
    {
      "t": 49498,
      "e": 48895,
      "ty": 41,
      "x": 43948,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 49597,
      "e": 48994,
      "ty": 2,
      "x": 849,
      "y": 447
    },
    {
      "t": 49748,
      "e": 49145,
      "ty": 41,
      "x": 22028,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 49816,
      "e": 49145,
      "ty": 6,
      "x": 836,
      "y": 448,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 49832,
      "e": 49161,
      "ty": 7,
      "x": 826,
      "y": 449,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 49897,
      "e": 49226,
      "ty": 2,
      "x": 815,
      "y": 448
    },
    {
      "t": 49997,
      "e": 49326,
      "ty": 2,
      "x": 815,
      "y": 444
    },
    {
      "t": 49997,
      "e": 49326,
      "ty": 41,
      "x": 27791,
      "y": 24153,
      "ta": "html > body"
    },
    {
      "t": 50097,
      "e": 49426,
      "ty": 2,
      "x": 837,
      "y": 430
    },
    {
      "t": 50247,
      "e": 49576,
      "ty": 41,
      "x": 3697,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 50598,
      "e": 49927,
      "ty": 2,
      "x": 837,
      "y": 432
    },
    {
      "t": 50748,
      "e": 50077,
      "ty": 41,
      "x": 3697,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 50966,
      "e": 50295,
      "ty": 3,
      "x": 837,
      "y": 432,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 50967,
      "e": 50296,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 51029,
      "e": 50358,
      "ty": 4,
      "x": 3697,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 51029,
      "e": 50358,
      "ty": 5,
      "x": 837,
      "y": 432,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 51569,
      "e": 50898,
      "ty": 6,
      "x": 835,
      "y": 440,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 51598,
      "e": 50927,
      "ty": 2,
      "x": 835,
      "y": 442
    },
    {
      "t": 51698,
      "e": 51027,
      "ty": 2,
      "x": 835,
      "y": 443
    },
    {
      "t": 51748,
      "e": 51077,
      "ty": 41,
      "x": 43243,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 51863,
      "e": 51192,
      "ty": 3,
      "x": 835,
      "y": 443,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 51863,
      "e": 51192,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 51941,
      "e": 51270,
      "ty": 4,
      "x": 43243,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 51943,
      "e": 51272,
      "ty": 5,
      "x": 835,
      "y": 443,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 51944,
      "e": 51273,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf",
      "v": "Second"
    },
    {
      "t": 52406,
      "e": 51735,
      "ty": 7,
      "x": 835,
      "y": 449,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 52498,
      "e": 51827,
      "ty": 2,
      "x": 895,
      "y": 572
    },
    {
      "t": 52498,
      "e": 51827,
      "ty": 41,
      "x": 17461,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-1-6"
    },
    {
      "t": 52597,
      "e": 51926,
      "ty": 2,
      "x": 911,
      "y": 665
    },
    {
      "t": 52698,
      "e": 52027,
      "ty": 2,
      "x": 880,
      "y": 740
    },
    {
      "t": 52748,
      "e": 52077,
      "ty": 41,
      "x": 25771,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 52798,
      "e": 52127,
      "ty": 2,
      "x": 842,
      "y": 887
    },
    {
      "t": 52897,
      "e": 52226,
      "ty": 2,
      "x": 840,
      "y": 890
    },
    {
      "t": 52998,
      "e": 52327,
      "ty": 2,
      "x": 840,
      "y": 888
    },
    {
      "t": 52998,
      "e": 52327,
      "ty": 41,
      "x": 4409,
      "y": 30426,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 53097,
      "e": 52426,
      "ty": 2,
      "x": 842,
      "y": 851
    },
    {
      "t": 53198,
      "e": 52527,
      "ty": 2,
      "x": 842,
      "y": 843
    },
    {
      "t": 53248,
      "e": 52577,
      "ty": 41,
      "x": 14498,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 53298,
      "e": 52627,
      "ty": 2,
      "x": 843,
      "y": 832
    },
    {
      "t": 53398,
      "e": 52727,
      "ty": 2,
      "x": 842,
      "y": 823
    },
    {
      "t": 53498,
      "e": 52827,
      "ty": 41,
      "x": 12146,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 53698,
      "e": 53027,
      "ty": 2,
      "x": 837,
      "y": 824
    },
    {
      "t": 53748,
      "e": 53077,
      "ty": 41,
      "x": 9194,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 53798,
      "e": 53127,
      "ty": 2,
      "x": 836,
      "y": 826
    },
    {
      "t": 53969,
      "e": 53298,
      "ty": 6,
      "x": 834,
      "y": 818,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 53998,
      "e": 53327,
      "ty": 2,
      "x": 832,
      "y": 812
    },
    {
      "t": 53998,
      "e": 53327,
      "ty": 41,
      "x": 28120,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 54002,
      "e": 53331,
      "ty": 7,
      "x": 831,
      "y": 807,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 54052,
      "e": 53381,
      "ty": 6,
      "x": 828,
      "y": 791,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 54097,
      "e": 53426,
      "ty": 2,
      "x": 828,
      "y": 788
    },
    {
      "t": 54198,
      "e": 53527,
      "ty": 2,
      "x": 828,
      "y": 784
    },
    {
      "t": 54247,
      "e": 53576,
      "ty": 41,
      "x": 7955,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 54370,
      "e": 53699,
      "ty": 7,
      "x": 831,
      "y": 779,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 54397,
      "e": 53726,
      "ty": 2,
      "x": 838,
      "y": 772
    },
    {
      "t": 54498,
      "e": 53827,
      "ty": 2,
      "x": 843,
      "y": 765
    },
    {
      "t": 54498,
      "e": 53827,
      "ty": 41,
      "x": 9003,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 54698,
      "e": 54027,
      "ty": 2,
      "x": 845,
      "y": 758
    },
    {
      "t": 54748,
      "e": 54077,
      "ty": 41,
      "x": 11507,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 54797,
      "e": 54126,
      "ty": 2,
      "x": 849,
      "y": 752
    },
    {
      "t": 54898,
      "e": 54227,
      "ty": 2,
      "x": 879,
      "y": 739
    },
    {
      "t": 54999,
      "e": 54228,
      "ty": 41,
      "x": 14451,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 55298,
      "e": 54527,
      "ty": 2,
      "x": 880,
      "y": 739
    },
    {
      "t": 55397,
      "e": 54626,
      "ty": 2,
      "x": 896,
      "y": 716
    },
    {
      "t": 55498,
      "e": 54727,
      "ty": 2,
      "x": 884,
      "y": 692
    },
    {
      "t": 55498,
      "e": 54727,
      "ty": 41,
      "x": 14851,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 55598,
      "e": 54827,
      "ty": 2,
      "x": 863,
      "y": 693
    },
    {
      "t": 55637,
      "e": 54866,
      "ty": 6,
      "x": 836,
      "y": 702,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 55697,
      "e": 54926,
      "ty": 2,
      "x": 831,
      "y": 704
    },
    {
      "t": 55747,
      "e": 54976,
      "ty": 41,
      "x": 23079,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 55934,
      "e": 55163,
      "ty": 3,
      "x": 831,
      "y": 704,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 55936,
      "e": 55165,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 55937,
      "e": 55166,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 55996,
      "e": 55225,
      "ty": 4,
      "x": 23079,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 55998,
      "e": 55227,
      "ty": 5,
      "x": 831,
      "y": 704,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 55998,
      "e": 55227,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 56325,
      "e": 55554,
      "ty": 7,
      "x": 839,
      "y": 713,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 56398,
      "e": 55627,
      "ty": 2,
      "x": 919,
      "y": 758
    },
    {
      "t": 56497,
      "e": 55726,
      "ty": 2,
      "x": 929,
      "y": 767
    },
    {
      "t": 56497,
      "e": 55726,
      "ty": 41,
      "x": 44887,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 56597,
      "e": 55826,
      "ty": 2,
      "x": 932,
      "y": 800
    },
    {
      "t": 56697,
      "e": 55926,
      "ty": 2,
      "x": 914,
      "y": 887
    },
    {
      "t": 56747,
      "e": 55976,
      "ty": 41,
      "x": 21971,
      "y": 35108,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 56798,
      "e": 56027,
      "ty": 2,
      "x": 914,
      "y": 894
    },
    {
      "t": 56897,
      "e": 56126,
      "ty": 2,
      "x": 912,
      "y": 897
    },
    {
      "t": 56997,
      "e": 56226,
      "ty": 2,
      "x": 866,
      "y": 931
    },
    {
      "t": 56997,
      "e": 56226,
      "ty": 41,
      "x": 48690,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 57097,
      "e": 56326,
      "ty": 2,
      "x": 865,
      "y": 931
    },
    {
      "t": 57197,
      "e": 56426,
      "ty": 2,
      "x": 853,
      "y": 938
    },
    {
      "t": 57247,
      "e": 56476,
      "ty": 41,
      "x": 4171,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 57297,
      "e": 56526,
      "ty": 2,
      "x": 839,
      "y": 947
    },
    {
      "t": 57372,
      "e": 56601,
      "ty": 6,
      "x": 832,
      "y": 956,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 57397,
      "e": 56626,
      "ty": 2,
      "x": 832,
      "y": 956
    },
    {
      "t": 57497,
      "e": 56726,
      "ty": 41,
      "x": 28120,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 57597,
      "e": 56826,
      "ty": 2,
      "x": 834,
      "y": 956
    },
    {
      "t": 57606,
      "e": 56835,
      "ty": 7,
      "x": 837,
      "y": 955,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 57608,
      "e": 56837,
      "ty": 3,
      "x": 837,
      "y": 955,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 57609,
      "e": 56838,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 57693,
      "e": 56922,
      "ty": 4,
      "x": 15028,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 57693,
      "e": 56922,
      "ty": 5,
      "x": 840,
      "y": 955,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 57697,
      "e": 56926,
      "ty": 2,
      "x": 840,
      "y": 955
    },
    {
      "t": 57747,
      "e": 56976,
      "ty": 41,
      "x": 15028,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 57997,
      "e": 57226,
      "ty": 2,
      "x": 841,
      "y": 955
    },
    {
      "t": 57997,
      "e": 57226,
      "ty": 41,
      "x": 15837,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 58054,
      "e": 57283,
      "ty": 6,
      "x": 839,
      "y": 961,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 58097,
      "e": 57326,
      "ty": 2,
      "x": 839,
      "y": 961
    },
    {
      "t": 58247,
      "e": 57476,
      "ty": 41,
      "x": 63408,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 58597,
      "e": 57826,
      "ty": 2,
      "x": 835,
      "y": 961
    },
    {
      "t": 58697,
      "e": 57926,
      "ty": 2,
      "x": 832,
      "y": 961
    },
    {
      "t": 58747,
      "e": 57976,
      "ty": 41,
      "x": 28120,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 58855,
      "e": 58084,
      "ty": 3,
      "x": 832,
      "y": 961,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 58855,
      "e": 58084,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 58917,
      "e": 58146,
      "ty": 4,
      "x": 28120,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 58917,
      "e": 58146,
      "ty": 5,
      "x": 832,
      "y": 961,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 58917,
      "e": 58146,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 59124,
      "e": 58353,
      "ty": 7,
      "x": 843,
      "y": 972,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 59197,
      "e": 58426,
      "ty": 2,
      "x": 878,
      "y": 995
    },
    {
      "t": 59247,
      "e": 58476,
      "ty": 41,
      "x": 56166,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-3-2 > label"
    },
    {
      "t": 59397,
      "e": 58626,
      "ty": 2,
      "x": 880,
      "y": 996
    },
    {
      "t": 59459,
      "e": 58628,
      "ty": 6,
      "x": 882,
      "y": 1005,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 59496,
      "e": 58665,
      "ty": 2,
      "x": 882,
      "y": 1012
    },
    {
      "t": 59496,
      "e": 58665,
      "ty": 41,
      "x": 27098,
      "y": 13901,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 59597,
      "e": 58766,
      "ty": 2,
      "x": 884,
      "y": 1016
    },
    {
      "t": 59697,
      "e": 58866,
      "ty": 2,
      "x": 884,
      "y": 1017
    },
    {
      "t": 59748,
      "e": 58917,
      "ty": 41,
      "x": 28128,
      "y": 23830,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 60109,
      "e": 59278,
      "ty": 3,
      "x": 884,
      "y": 1017,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 60109,
      "e": 59278,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 60109,
      "e": 59278,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 60245,
      "e": 59414,
      "ty": 4,
      "x": 28128,
      "y": 23830,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 60245,
      "e": 59414,
      "ty": 5,
      "x": 884,
      "y": 1017,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 60248,
      "e": 59417,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 60249,
      "e": 59418,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 60250,
      "e": 59419,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 60697,
      "e": 59866,
      "ty": 2,
      "x": 883,
      "y": 1014
    },
    {
      "t": 60747,
      "e": 59916,
      "ty": 41,
      "x": 30064,
      "y": 55397,
      "ta": "html > body"
    },
    {
      "t": 60797,
      "e": 59966,
      "ty": 2,
      "x": 881,
      "y": 1008
    },
    {
      "t": 61597,
      "e": 60766,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 62097,
      "e": 61266,
      "ty": 2,
      "x": 743,
      "y": 809
    },
    {
      "t": 62197,
      "e": 61366,
      "ty": 2,
      "x": 412,
      "y": 504
    },
    {
      "t": 62247,
      "e": 61416,
      "ty": 41,
      "x": 5340,
      "y": 15459,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 62297,
      "e": 61466,
      "ty": 2,
      "x": 424,
      "y": 430
    },
    {
      "t": 62397,
      "e": 61566,
      "ty": 2,
      "x": 454,
      "y": 394
    },
    {
      "t": 62497,
      "e": 61666,
      "ty": 2,
      "x": 463,
      "y": 383
    },
    {
      "t": 62497,
      "e": 61666,
      "ty": 41,
      "x": 8341,
      "y": 1962,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 62697,
      "e": 61866,
      "ty": 2,
      "x": 479,
      "y": 386
    },
    {
      "t": 62748,
      "e": 61917,
      "ty": 41,
      "x": 9767,
      "y": 16786,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 62797,
      "e": 61966,
      "ty": 2,
      "x": 503,
      "y": 407
    },
    {
      "t": 62897,
      "e": 62066,
      "ty": 2,
      "x": 565,
      "y": 422
    },
    {
      "t": 62997,
      "e": 62166,
      "ty": 2,
      "x": 570,
      "y": 423
    },
    {
      "t": 62998,
      "e": 62167,
      "ty": 41,
      "x": 13605,
      "y": 33169,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 63097,
      "e": 62266,
      "ty": 2,
      "x": 591,
      "y": 423
    },
    {
      "t": 63197,
      "e": 62366,
      "ty": 2,
      "x": 706,
      "y": 423
    },
    {
      "t": 63247,
      "e": 62416,
      "ty": 41,
      "x": 20394,
      "y": 33169,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 63297,
      "e": 62466,
      "ty": 2,
      "x": 711,
      "y": 423
    },
    {
      "t": 63397,
      "e": 62566,
      "ty": 2,
      "x": 726,
      "y": 418
    },
    {
      "t": 63497,
      "e": 62666,
      "ty": 41,
      "x": 21280,
      "y": 29268,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 63597,
      "e": 62766,
      "ty": 2,
      "x": 705,
      "y": 428
    },
    {
      "t": 63748,
      "e": 62917,
      "ty": 41,
      "x": 16114,
      "y": 15111,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 63797,
      "e": 62966,
      "ty": 2,
      "x": 585,
      "y": 478
    },
    {
      "t": 63997,
      "e": 63166,
      "ty": 41,
      "x": 14343,
      "y": 16617,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 64097,
      "e": 63266,
      "ty": 2,
      "x": 646,
      "y": 432
    },
    {
      "t": 64197,
      "e": 63366,
      "ty": 2,
      "x": 759,
      "y": 387
    },
    {
      "t": 64247,
      "e": 63416,
      "ty": 41,
      "x": 22903,
      "y": 5083,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 64297,
      "e": 63466,
      "ty": 2,
      "x": 788,
      "y": 400
    },
    {
      "t": 64397,
      "e": 63566,
      "ty": 2,
      "x": 827,
      "y": 397
    },
    {
      "t": 64498,
      "e": 63667,
      "ty": 41,
      "x": 26248,
      "y": 12885,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 64597,
      "e": 63766,
      "ty": 2,
      "x": 830,
      "y": 398
    },
    {
      "t": 64697,
      "e": 63866,
      "ty": 2,
      "x": 830,
      "y": 399
    },
    {
      "t": 64748,
      "e": 63917,
      "ty": 41,
      "x": 26396,
      "y": 14445,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 64997,
      "e": 64166,
      "ty": 2,
      "x": 836,
      "y": 420
    },
    {
      "t": 64997,
      "e": 64166,
      "ty": 41,
      "x": 26691,
      "y": 30829,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 65097,
      "e": 64266,
      "ty": 2,
      "x": 829,
      "y": 432
    },
    {
      "t": 65197,
      "e": 64366,
      "ty": 2,
      "x": 773,
      "y": 462
    },
    {
      "t": 65247,
      "e": 64416,
      "ty": 41,
      "x": 23543,
      "y": 64376,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 65297,
      "e": 64466,
      "ty": 2,
      "x": 772,
      "y": 463
    },
    {
      "t": 65398,
      "e": 64567,
      "ty": 2,
      "x": 772,
      "y": 485
    },
    {
      "t": 65498,
      "e": 64667,
      "ty": 41,
      "x": 23543,
      "y": 981,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 65598,
      "e": 64767,
      "ty": 2,
      "x": 641,
      "y": 472
    },
    {
      "t": 65697,
      "e": 64866,
      "ty": 2,
      "x": 329,
      "y": 409
    },
    {
      "t": 65748,
      "e": 64917,
      "ty": 41,
      "x": 1748,
      "y": 22247,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 65897,
      "e": 65066,
      "ty": 2,
      "x": 616,
      "y": 577
    },
    {
      "t": 65997,
      "e": 65166,
      "ty": 2,
      "x": 819,
      "y": 600
    },
    {
      "t": 65997,
      "e": 65166,
      "ty": 41,
      "x": 25855,
      "y": 45841,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 66097,
      "e": 65266,
      "ty": 2,
      "x": 822,
      "y": 591
    },
    {
      "t": 66197,
      "e": 65366,
      "ty": 2,
      "x": 820,
      "y": 577
    },
    {
      "t": 66248,
      "e": 65417,
      "ty": 41,
      "x": 25904,
      "y": 36869,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 66297,
      "e": 65466,
      "ty": 2,
      "x": 860,
      "y": 556
    },
    {
      "t": 66397,
      "e": 65566,
      "ty": 2,
      "x": 1057,
      "y": 522
    },
    {
      "t": 66497,
      "e": 65666,
      "ty": 2,
      "x": 1061,
      "y": 520
    },
    {
      "t": 66498,
      "e": 65667,
      "ty": 41,
      "x": 37760,
      "y": 14634,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 66597,
      "e": 65766,
      "ty": 2,
      "x": 1095,
      "y": 512
    },
    {
      "t": 66697,
      "e": 65866,
      "ty": 2,
      "x": 1202,
      "y": 463
    },
    {
      "t": 66747,
      "e": 65916,
      "ty": 41,
      "x": 44697,
      "y": 64376,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 66897,
      "e": 66066,
      "ty": 2,
      "x": 1199,
      "y": 467
    },
    {
      "t": 66997,
      "e": 66166,
      "ty": 41,
      "x": 44550,
      "y": 15343,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 67097,
      "e": 66266,
      "ty": 2,
      "x": 1223,
      "y": 463
    },
    {
      "t": 67247,
      "e": 66416,
      "ty": 41,
      "x": 45435,
      "y": 64376,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 67297,
      "e": 66466,
      "ty": 2,
      "x": 1175,
      "y": 475
    },
    {
      "t": 67398,
      "e": 66567,
      "ty": 2,
      "x": 1129,
      "y": 492
    },
    {
      "t": 67497,
      "e": 66666,
      "ty": 2,
      "x": 1091,
      "y": 505
    },
    {
      "t": 67498,
      "e": 66667,
      "ty": 41,
      "x": 39236,
      "y": 8783,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 67598,
      "e": 66767,
      "ty": 2,
      "x": 721,
      "y": 539
    },
    {
      "t": 67697,
      "e": 66866,
      "ty": 2,
      "x": 611,
      "y": 540
    },
    {
      "t": 67747,
      "e": 66916,
      "ty": 41,
      "x": 15622,
      "y": 22436,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 67897,
      "e": 67066,
      "ty": 2,
      "x": 640,
      "y": 525
    },
    {
      "t": 67997,
      "e": 67166,
      "ty": 2,
      "x": 665,
      "y": 518
    },
    {
      "t": 67997,
      "e": 67166,
      "ty": 41,
      "x": 18278,
      "y": 13854,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 68097,
      "e": 67266,
      "ty": 2,
      "x": 705,
      "y": 521
    },
    {
      "t": 68197,
      "e": 67366,
      "ty": 2,
      "x": 929,
      "y": 566
    },
    {
      "t": 68247,
      "e": 67416,
      "ty": 41,
      "x": 32792,
      "y": 32578,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 68297,
      "e": 67466,
      "ty": 2,
      "x": 981,
      "y": 566
    },
    {
      "t": 68397,
      "e": 67566,
      "ty": 2,
      "x": 1000,
      "y": 564
    },
    {
      "t": 68498,
      "e": 67667,
      "ty": 2,
      "x": 1057,
      "y": 549
    },
    {
      "t": 68498,
      "e": 67667,
      "ty": 41,
      "x": 37564,
      "y": 25947,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 68597,
      "e": 67766,
      "ty": 2,
      "x": 1074,
      "y": 546
    },
    {
      "t": 68748,
      "e": 67917,
      "ty": 41,
      "x": 38400,
      "y": 24776,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 69497,
      "e": 68666,
      "ty": 2,
      "x": 1073,
      "y": 546
    },
    {
      "t": 69498,
      "e": 68667,
      "ty": 41,
      "x": 38351,
      "y": 24776,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 69597,
      "e": 68766,
      "ty": 2,
      "x": 1059,
      "y": 550
    },
    {
      "t": 69697,
      "e": 68866,
      "ty": 2,
      "x": 1047,
      "y": 554
    },
    {
      "t": 69748,
      "e": 68917,
      "ty": 41,
      "x": 36727,
      "y": 29067,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 69797,
      "e": 68966,
      "ty": 2,
      "x": 1024,
      "y": 562
    },
    {
      "t": 69898,
      "e": 69067,
      "ty": 2,
      "x": 914,
      "y": 570
    },
    {
      "t": 69997,
      "e": 69166,
      "ty": 2,
      "x": 724,
      "y": 571
    },
    {
      "t": 69997,
      "e": 69166,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 70001,
      "e": 69170,
      "ty": 41,
      "x": 21181,
      "y": 34528,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 70097,
      "e": 69266,
      "ty": 2,
      "x": 432,
      "y": 556
    },
    {
      "t": 70197,
      "e": 69366,
      "ty": 2,
      "x": 396,
      "y": 545
    },
    {
      "t": 70247,
      "e": 69416,
      "ty": 41,
      "x": 5044,
      "y": 24386,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 70397,
      "e": 69566,
      "ty": 2,
      "x": 437,
      "y": 548
    },
    {
      "t": 70497,
      "e": 69666,
      "ty": 2,
      "x": 540,
      "y": 564
    },
    {
      "t": 70497,
      "e": 69666,
      "ty": 41,
      "x": 12129,
      "y": 31798,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 70597,
      "e": 69766,
      "ty": 2,
      "x": 621,
      "y": 578
    },
    {
      "t": 70698,
      "e": 69867,
      "ty": 2,
      "x": 629,
      "y": 578
    },
    {
      "t": 70748,
      "e": 69917,
      "ty": 41,
      "x": 16507,
      "y": 37259,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 70897,
      "e": 70066,
      "ty": 2,
      "x": 629,
      "y": 579
    },
    {
      "t": 70997,
      "e": 70166,
      "ty": 2,
      "x": 630,
      "y": 589
    },
    {
      "t": 70998,
      "e": 70167,
      "ty": 41,
      "x": 16557,
      "y": 41550,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 71097,
      "e": 70266,
      "ty": 2,
      "x": 632,
      "y": 594
    },
    {
      "t": 71197,
      "e": 70366,
      "ty": 2,
      "x": 633,
      "y": 597
    },
    {
      "t": 71248,
      "e": 70417,
      "ty": 41,
      "x": 16704,
      "y": 44671,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 71897,
      "e": 71066,
      "ty": 2,
      "x": 663,
      "y": 606
    },
    {
      "t": 71998,
      "e": 71167,
      "ty": 2,
      "x": 710,
      "y": 620
    },
    {
      "t": 71998,
      "e": 71167,
      "ty": 41,
      "x": 20492,
      "y": 53643,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 72098,
      "e": 71267,
      "ty": 2,
      "x": 755,
      "y": 641
    },
    {
      "t": 72197,
      "e": 71366,
      "ty": 2,
      "x": 825,
      "y": 660
    },
    {
      "t": 72248,
      "e": 71417,
      "ty": 41,
      "x": 26150,
      "y": 37690,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 72297,
      "e": 71466,
      "ty": 2,
      "x": 826,
      "y": 660
    },
    {
      "t": 72397,
      "e": 71566,
      "ty": 2,
      "x": 828,
      "y": 662
    },
    {
      "t": 72497,
      "e": 71666,
      "ty": 2,
      "x": 829,
      "y": 662
    },
    {
      "t": 72498,
      "e": 71667,
      "ty": 41,
      "x": 26347,
      "y": 37921,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 74398,
      "e": 73567,
      "ty": 2,
      "x": 829,
      "y": 663
    },
    {
      "t": 74499,
      "e": 73668,
      "ty": 41,
      "x": 26347,
      "y": 38037,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 75397,
      "e": 74566,
      "ty": 2,
      "x": 826,
      "y": 665
    },
    {
      "t": 75498,
      "e": 74667,
      "ty": 41,
      "x": 26199,
      "y": 38269,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 77998,
      "e": 77167,
      "ty": 2,
      "x": 885,
      "y": 802
    },
    {
      "t": 77998,
      "e": 77167,
      "ty": 41,
      "x": 29102,
      "y": 4114,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 78098,
      "e": 77267,
      "ty": 2,
      "x": 900,
      "y": 837
    },
    {
      "t": 78248,
      "e": 77417,
      "ty": 41,
      "x": 29840,
      "y": 45073,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 78397,
      "e": 77566,
      "ty": 2,
      "x": 898,
      "y": 844
    },
    {
      "t": 78497,
      "e": 77666,
      "ty": 2,
      "x": 890,
      "y": 852
    },
    {
      "t": 78498,
      "e": 77667,
      "ty": 41,
      "x": 29348,
      "y": 62627,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 78598,
      "e": 77767,
      "ty": 2,
      "x": 883,
      "y": 863
    },
    {
      "t": 78698,
      "e": 77867,
      "ty": 2,
      "x": 883,
      "y": 867
    },
    {
      "t": 78748,
      "e": 77917,
      "ty": 41,
      "x": 28856,
      "y": 62121,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 78798,
      "e": 77967,
      "ty": 2,
      "x": 880,
      "y": 871
    },
    {
      "t": 78897,
      "e": 78066,
      "ty": 2,
      "x": 880,
      "y": 872
    },
    {
      "t": 78998,
      "e": 78167,
      "ty": 2,
      "x": 880,
      "y": 875
    },
    {
      "t": 78998,
      "e": 78167,
      "ty": 41,
      "x": 28856,
      "y": 5887,
      "ta": "> div.masterdiv > div:[2] > div > p:[6]"
    },
    {
      "t": 79098,
      "e": 78267,
      "ty": 2,
      "x": 892,
      "y": 895
    },
    {
      "t": 79197,
      "e": 78366,
      "ty": 2,
      "x": 927,
      "y": 951
    },
    {
      "t": 79248,
      "e": 78417,
      "ty": 41,
      "x": 31266,
      "y": 57316,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 79297,
      "e": 78466,
      "ty": 2,
      "x": 929,
      "y": 954
    },
    {
      "t": 79397,
      "e": 78566,
      "ty": 2,
      "x": 929,
      "y": 963
    },
    {
      "t": 79497,
      "e": 78666,
      "ty": 2,
      "x": 952,
      "y": 1001
    },
    {
      "t": 79498,
      "e": 78667,
      "ty": 41,
      "x": 32398,
      "y": 60570,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 79998,
      "e": 79167,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 80698,
      "e": 79867,
      "ty": 2,
      "x": 952,
      "y": 1002
    },
    {
      "t": 80748,
      "e": 79917,
      "ty": 41,
      "x": 32398,
      "y": 60640,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 80898,
      "e": 80067,
      "ty": 2,
      "x": 994,
      "y": 1036
    },
    {
      "t": 80997,
      "e": 80166,
      "ty": 2,
      "x": 1062,
      "y": 1080
    },
    {
      "t": 80998,
      "e": 80167,
      "ty": 41,
      "x": 36297,
      "y": 59385,
      "ta": "> div.masterdiv"
    },
    {
      "t": 81098,
      "e": 80267,
      "ty": 2,
      "x": 1072,
      "y": 1086
    },
    {
      "t": 81248,
      "e": 80417,
      "ty": 41,
      "x": 36641,
      "y": 59718,
      "ta": "> div.masterdiv"
    },
    {
      "t": 81897,
      "e": 81066,
      "ty": 2,
      "x": 1072,
      "y": 1089
    },
    {
      "t": 81997,
      "e": 81166,
      "ty": 2,
      "x": 1072,
      "y": 1091
    },
    {
      "t": 81997,
      "e": 81166,
      "ty": 41,
      "x": 36641,
      "y": 59995,
      "ta": "> div.masterdiv"
    },
    {
      "t": 82247,
      "e": 81416,
      "ty": 41,
      "x": 36641,
      "y": 60050,
      "ta": "> div.masterdiv"
    },
    {
      "t": 82296,
      "e": 81465,
      "ty": 2,
      "x": 1072,
      "y": 1093
    },
    {
      "t": 82497,
      "e": 81666,
      "ty": 2,
      "x": 1070,
      "y": 1094
    },
    {
      "t": 82497,
      "e": 81666,
      "ty": 41,
      "x": 36572,
      "y": 60161,
      "ta": "> div.masterdiv"
    },
    {
      "t": 82597,
      "e": 81766,
      "ty": 2,
      "x": 1063,
      "y": 1100
    },
    {
      "t": 82748,
      "e": 81917,
      "ty": 41,
      "x": 36331,
      "y": 60493,
      "ta": "> div.masterdiv"
    },
    {
      "t": 83397,
      "e": 82566,
      "ty": 2,
      "x": 1050,
      "y": 1104
    },
    {
      "t": 83497,
      "e": 82666,
      "ty": 2,
      "x": 1041,
      "y": 1107
    },
    {
      "t": 83498,
      "e": 82667,
      "ty": 41,
      "x": 35574,
      "y": 60881,
      "ta": "> div.masterdiv"
    },
    {
      "t": 83596,
      "e": 82765,
      "ty": 2,
      "x": 1022,
      "y": 1107
    },
    {
      "t": 83669,
      "e": 82838,
      "ty": 6,
      "x": 998,
      "y": 1105,
      "ta": "#start"
    },
    {
      "t": 83696,
      "e": 82865,
      "ty": 2,
      "x": 991,
      "y": 1104
    },
    {
      "t": 83746,
      "e": 82915,
      "ty": 41,
      "x": 40686,
      "y": 60354,
      "ta": "#start"
    },
    {
      "t": 83796,
      "e": 82965,
      "ty": 2,
      "x": 982,
      "y": 1104
    },
    {
      "t": 83897,
      "e": 83066,
      "ty": 2,
      "x": 980,
      "y": 1104
    },
    {
      "t": 83997,
      "e": 83166,
      "ty": 41,
      "x": 38501,
      "y": 60354,
      "ta": "#start"
    },
    {
      "t": 85097,
      "e": 84266,
      "ty": 2,
      "x": 979,
      "y": 1096
    },
    {
      "t": 85196,
      "e": 84365,
      "ty": 2,
      "x": 979,
      "y": 1095
    },
    {
      "t": 85247,
      "e": 84416,
      "ty": 41,
      "x": 37955,
      "y": 43007,
      "ta": "#start"
    },
    {
      "t": 86447,
      "e": 85616,
      "ty": 3,
      "x": 979,
      "y": 1095,
      "ta": "#start"
    },
    {
      "t": 86448,
      "e": 85617,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 86613,
      "e": 85782,
      "ty": 4,
      "x": 37955,
      "y": 43007,
      "ta": "#start"
    },
    {
      "t": 86613,
      "e": 85782,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 86614,
      "e": 85783,
      "ty": 5,
      "x": 979,
      "y": 1095,
      "ta": "#start"
    },
    {
      "t": 86616,
      "e": 85785,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 87650,
      "e": 86819,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 88977,
      "e": 88146,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 97220, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 97225, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"967LR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 7837, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 106377, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"967LR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 16588, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"MIKE\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"115\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 123972, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"967LR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 7663, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 132723, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"967LR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 8826, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 142551, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"967LR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 9763, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 153654, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"967LR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:917,y:809,t:1527268106064};\\\", \\\"{x:978,y:823,t:1527268106071};\\\", \\\"{x:1073,y:865,t:1527268106086};\\\", \\\"{x:1198,y:1003,t:1527268106103};\\\", \\\"{x:1243,y:1105,t:1527268106119};\\\", \\\"{x:1249,y:1183,t:1527268106136};\\\", \\\"{x:1246,y:1188,t:1527268106152};\\\", \\\"{x:1235,y:1199,t:1527268106169};\\\", \\\"{x:1225,y:1199,t:1527268106185};\\\", \\\"{x:1221,y:1199,t:1527268106203};\\\", \\\"{x:1219,y:1199,t:1527268106219};\\\", \\\"{x:1218,y:1192,t:1527268106608};\\\", \\\"{x:1196,y:1162,t:1527268106620};\\\", \\\"{x:1114,y:1061,t:1527268106635};\\\", \\\"{x:1029,y:986,t:1527268106653};\\\", \\\"{x:942,y:908,t:1527268106670};\\\", \\\"{x:869,y:835,t:1527268106687};\\\", \\\"{x:827,y:787,t:1527268106702};\\\", \\\"{x:815,y:767,t:1527268106719};\\\", \\\"{x:813,y:759,t:1527268106736};\\\", \\\"{x:813,y:758,t:1527268106751};\\\", \\\"{x:813,y:756,t:1527268106769};\\\", \\\"{x:817,y:750,t:1527268106786};\\\", \\\"{x:824,y:741,t:1527268106801};\\\", \\\"{x:836,y:731,t:1527268106819};\\\", \\\"{x:853,y:719,t:1527268106836};\\\", \\\"{x:876,y:706,t:1527268106852};\\\", \\\"{x:903,y:689,t:1527268106869};\\\", \\\"{x:941,y:666,t:1527268106887};\\\", \\\"{x:973,y:648,t:1527268106903};\\\", \\\"{x:1049,y:632,t:1527268106920};\\\", \\\"{x:1092,y:624,t:1527268106935};\\\", \\\"{x:1115,y:624,t:1527268106952};\\\", \\\"{x:1128,y:624,t:1527268106969};\\\", \\\"{x:1133,y:623,t:1527268106986};\\\", \\\"{x:1138,y:623,t:1527268107003};\\\", \\\"{x:1144,y:623,t:1527268107019};\\\", \\\"{x:1153,y:624,t:1527268107037};\\\", \\\"{x:1163,y:625,t:1527268107053};\\\", \\\"{x:1171,y:629,t:1527268107070};\\\", \\\"{x:1180,y:635,t:1527268107086};\\\", \\\"{x:1192,y:649,t:1527268107103};\\\", \\\"{x:1201,y:662,t:1527268107119};\\\", \\\"{x:1214,y:677,t:1527268107136};\\\", \\\"{x:1229,y:693,t:1527268107154};\\\", \\\"{x:1240,y:711,t:1527268107169};\\\", \\\"{x:1253,y:728,t:1527268107187};\\\", \\\"{x:1266,y:740,t:1527268107203};\\\", \\\"{x:1279,y:752,t:1527268107220};\\\", \\\"{x:1288,y:762,t:1527268107237};\\\", \\\"{x:1290,y:769,t:1527268107253};\\\", \\\"{x:1291,y:771,t:1527268107269};\\\", \\\"{x:1291,y:772,t:1527268107286};\\\", \\\"{x:1292,y:774,t:1527268107336};\\\", \\\"{x:1292,y:776,t:1527268107425};\\\", \\\"{x:1292,y:780,t:1527268107437};\\\", \\\"{x:1292,y:791,t:1527268107454};\\\", \\\"{x:1290,y:800,t:1527268107470};\\\", \\\"{x:1289,y:811,t:1527268107487};\\\", \\\"{x:1289,y:821,t:1527268107504};\\\", \\\"{x:1289,y:823,t:1527268107521};\\\", \\\"{x:1290,y:824,t:1527268107536};\\\", \\\"{x:1291,y:825,t:1527268107584};\\\", \\\"{x:1293,y:826,t:1527268107839};\\\", \\\"{x:1293,y:828,t:1527268107853};\\\", \\\"{x:1293,y:834,t:1527268107870};\\\", \\\"{x:1294,y:836,t:1527268107886};\\\", \\\"{x:1296,y:843,t:1527268107903};\\\", \\\"{x:1297,y:846,t:1527268107920};\\\", \\\"{x:1298,y:847,t:1527268107937};\\\", \\\"{x:1298,y:848,t:1527268107953};\\\", \\\"{x:1298,y:849,t:1527268107971};\\\", \\\"{x:1297,y:849,t:1527268110649};\\\", \\\"{x:1296,y:849,t:1527268110784};\\\", \\\"{x:1294,y:849,t:1527268110889};\\\", \\\"{x:1292,y:849,t:1527268110912};\\\", \\\"{x:1289,y:847,t:1527268110922};\\\", \\\"{x:1281,y:842,t:1527268110940};\\\", \\\"{x:1276,y:839,t:1527268110957};\\\", \\\"{x:1275,y:837,t:1527268110973};\\\", \\\"{x:1273,y:836,t:1527268110990};\\\", \\\"{x:1273,y:835,t:1527268111007};\\\", \\\"{x:1272,y:834,t:1527268111023};\\\", \\\"{x:1263,y:832,t:1527268111039};\\\", \\\"{x:1243,y:827,t:1527268111056};\\\", \\\"{x:1212,y:815,t:1527268111073};\\\", \\\"{x:1164,y:800,t:1527268111090};\\\", \\\"{x:1079,y:781,t:1527268111106};\\\", \\\"{x:978,y:761,t:1527268111122};\\\", \\\"{x:878,y:747,t:1527268111139};\\\", \\\"{x:776,y:737,t:1527268111156};\\\", \\\"{x:713,y:731,t:1527268111171};\\\", \\\"{x:678,y:729,t:1527268111189};\\\", \\\"{x:666,y:729,t:1527268111206};\\\", \\\"{x:664,y:729,t:1527268111255};\\\", \\\"{x:662,y:731,t:1527268111272};\\\", \\\"{x:661,y:734,t:1527268111289};\\\", \\\"{x:661,y:735,t:1527268111751};\\\", \\\"{x:658,y:736,t:1527268111759};\\\", \\\"{x:655,y:737,t:1527268111773};\\\", \\\"{x:654,y:737,t:1527268111789};\\\", \\\"{x:653,y:737,t:1527268111806};\\\", \\\"{x:652,y:737,t:1527268111896};\\\", \\\"{x:651,y:738,t:1527268111928};\\\", \\\"{x:650,y:738,t:1527268111943};\\\", \\\"{x:649,y:738,t:1527268111957};\\\", \\\"{x:647,y:739,t:1527268111974};\\\", \\\"{x:645,y:739,t:1527268111990};\\\", \\\"{x:644,y:740,t:1527268112007};\\\", \\\"{x:639,y:740,t:1527268112023};\\\", \\\"{x:630,y:740,t:1527268112041};\\\", \\\"{x:621,y:740,t:1527268112056};\\\", \\\"{x:611,y:740,t:1527268112073};\\\", \\\"{x:603,y:737,t:1527268112090};\\\", \\\"{x:594,y:735,t:1527268112107};\\\", \\\"{x:582,y:732,t:1527268112123};\\\", \\\"{x:567,y:729,t:1527268112141};\\\", \\\"{x:552,y:724,t:1527268112158};\\\", \\\"{x:538,y:719,t:1527268112173};\\\", \\\"{x:527,y:714,t:1527268112190};\\\", \\\"{x:522,y:707,t:1527268112206};\\\", \\\"{x:513,y:694,t:1527268112224};\\\", \\\"{x:502,y:673,t:1527268112240};\\\", \\\"{x:494,y:653,t:1527268112257};\\\", \\\"{x:480,y:630,t:1527268112274};\\\", \\\"{x:469,y:611,t:1527268112291};\\\", \\\"{x:456,y:591,t:1527268112307};\\\", \\\"{x:440,y:573,t:1527268112324};\\\", \\\"{x:422,y:559,t:1527268112340};\\\", \\\"{x:401,y:543,t:1527268112361};\\\", \\\"{x:396,y:539,t:1527268112373};\\\", \\\"{x:388,y:534,t:1527268112390};\\\", \\\"{x:381,y:528,t:1527268112406};\\\", \\\"{x:379,y:527,t:1527268112423};\\\", \\\"{x:378,y:527,t:1527268112440};\\\", \\\"{x:376,y:527,t:1527268112457};\\\", \\\"{x:375,y:526,t:1527268112474};\\\", \\\"{x:371,y:526,t:1527268112490};\\\", \\\"{x:370,y:526,t:1527268112511};\\\", \\\"{x:372,y:526,t:1527268112591};\\\", \\\"{x:380,y:525,t:1527268112607};\\\", \\\"{x:388,y:522,t:1527268112623};\\\", \\\"{x:389,y:522,t:1527268112640};\\\", \\\"{x:390,y:522,t:1527268112657};\\\", \\\"{x:391,y:521,t:1527268112999};\\\", \\\"{x:394,y:521,t:1527268113007};\\\", \\\"{x:398,y:519,t:1527268113024};\\\", \\\"{x:404,y:519,t:1527268113040};\\\", \\\"{x:412,y:531,t:1527268113057};\\\", \\\"{x:420,y:544,t:1527268113075};\\\", \\\"{x:431,y:559,t:1527268113091};\\\", \\\"{x:440,y:571,t:1527268113107};\\\", \\\"{x:450,y:583,t:1527268113125};\\\", \\\"{x:454,y:590,t:1527268113141};\\\", \\\"{x:457,y:597,t:1527268113157};\\\", \\\"{x:459,y:599,t:1527268113174};\\\", \\\"{x:464,y:603,t:1527268113191};\\\", \\\"{x:465,y:605,t:1527268113207};\\\", \\\"{x:466,y:608,t:1527268113224};\\\", \\\"{x:468,y:612,t:1527268113241};\\\", \\\"{x:468,y:619,t:1527268113257};\\\", \\\"{x:468,y:632,t:1527268113275};\\\", \\\"{x:468,y:645,t:1527268113291};\\\", \\\"{x:468,y:658,t:1527268113308};\\\", \\\"{x:468,y:668,t:1527268113324};\\\", \\\"{x:469,y:677,t:1527268113341};\\\", \\\"{x:474,y:687,t:1527268113358};\\\", \\\"{x:480,y:697,t:1527268113375};\\\", \\\"{x:488,y:710,t:1527268113391};\\\", \\\"{x:489,y:714,t:1527268113407};\\\", \\\"{x:491,y:719,t:1527268113424};\\\", \\\"{x:491,y:721,t:1527268113441};\\\", \\\"{x:492,y:721,t:1527268113903};\\\", \\\"{x:493,y:721,t:1527268113919};\\\", \\\"{x:494,y:721,t:1527268113927};\\\", \\\"{x:496,y:721,t:1527268113941};\\\", \\\"{x:498,y:720,t:1527268113958};\\\", \\\"{x:504,y:717,t:1527268113975};\\\", \\\"{x:509,y:714,t:1527268113992};\\\", \\\"{x:515,y:710,t:1527268114008};\\\", \\\"{x:522,y:705,t:1527268114025};\\\", \\\"{x:529,y:700,t:1527268114041};\\\", \\\"{x:536,y:693,t:1527268114059};\\\", \\\"{x:546,y:687,t:1527268114075};\\\", \\\"{x:552,y:680,t:1527268114091};\\\", \\\"{x:559,y:676,t:1527268114108};\\\", \\\"{x:563,y:674,t:1527268114125};\\\", \\\"{x:565,y:672,t:1527268114141};\\\", \\\"{x:567,y:669,t:1527268114760};\\\", \\\"{x:584,y:648,t:1527268114832};\\\" ] }, { \\\"rt\\\": 15827, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 170738, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"967LR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -E -E -D -D -D -E -E -04 PM-04 PM-J \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:584,y:647,t:1527268115109};\\\", \\\"{x:587,y:647,t:1527268115127};\\\", \\\"{x:589,y:644,t:1527268115142};\\\", \\\"{x:596,y:639,t:1527268115159};\\\", \\\"{x:598,y:638,t:1527268115176};\\\", \\\"{x:598,y:637,t:1527268115344};\\\", \\\"{x:601,y:633,t:1527268115361};\\\", \\\"{x:603,y:630,t:1527268115377};\\\", \\\"{x:607,y:625,t:1527268115392};\\\", \\\"{x:611,y:622,t:1527268115409};\\\", \\\"{x:612,y:617,t:1527268115426};\\\", \\\"{x:614,y:610,t:1527268115442};\\\", \\\"{x:615,y:603,t:1527268115459};\\\", \\\"{x:618,y:594,t:1527268115476};\\\", \\\"{x:619,y:588,t:1527268115492};\\\", \\\"{x:622,y:579,t:1527268115509};\\\", \\\"{x:632,y:558,t:1527268115611};\\\", \\\"{x:633,y:557,t:1527268115626};\\\", \\\"{x:636,y:555,t:1527268115642};\\\", \\\"{x:638,y:553,t:1527268115659};\\\", \\\"{x:646,y:551,t:1527268115677};\\\", \\\"{x:659,y:545,t:1527268115692};\\\", \\\"{x:675,y:539,t:1527268115710};\\\", \\\"{x:695,y:532,t:1527268115726};\\\", \\\"{x:732,y:522,t:1527268115743};\\\", \\\"{x:774,y:516,t:1527268115759};\\\", \\\"{x:878,y:510,t:1527268115776};\\\", \\\"{x:1005,y:510,t:1527268115793};\\\", \\\"{x:1132,y:510,t:1527268115810};\\\", \\\"{x:1254,y:510,t:1527268115826};\\\", \\\"{x:1347,y:514,t:1527268115843};\\\", \\\"{x:1408,y:523,t:1527268115859};\\\", \\\"{x:1489,y:536,t:1527268115876};\\\", \\\"{x:1545,y:544,t:1527268115893};\\\", \\\"{x:1572,y:546,t:1527268115909};\\\", \\\"{x:1596,y:552,t:1527268115926};\\\", \\\"{x:1610,y:555,t:1527268115943};\\\", \\\"{x:1613,y:557,t:1527268115960};\\\", \\\"{x:1613,y:558,t:1527268116083};\\\", \\\"{x:1611,y:558,t:1527268116094};\\\", \\\"{x:1605,y:560,t:1527268116110};\\\", \\\"{x:1597,y:560,t:1527268116126};\\\", \\\"{x:1583,y:567,t:1527268116144};\\\", \\\"{x:1580,y:568,t:1527268116160};\\\", \\\"{x:1577,y:568,t:1527268116176};\\\", \\\"{x:1575,y:569,t:1527268116193};\\\", \\\"{x:1574,y:569,t:1527268116210};\\\", \\\"{x:1574,y:570,t:1527268116464};\\\", \\\"{x:1572,y:571,t:1527268116560};\\\", \\\"{x:1570,y:572,t:1527268116578};\\\", \\\"{x:1567,y:572,t:1527268116594};\\\", \\\"{x:1563,y:573,t:1527268116611};\\\", \\\"{x:1562,y:574,t:1527268116628};\\\", \\\"{x:1560,y:574,t:1527268116644};\\\", \\\"{x:1557,y:575,t:1527268116661};\\\", \\\"{x:1552,y:576,t:1527268116678};\\\", \\\"{x:1546,y:578,t:1527268116694};\\\", \\\"{x:1541,y:579,t:1527268116711};\\\", \\\"{x:1534,y:581,t:1527268116728};\\\", \\\"{x:1533,y:581,t:1527268116824};\\\", \\\"{x:1531,y:581,t:1527268116840};\\\", \\\"{x:1529,y:582,t:1527268116856};\\\", \\\"{x:1528,y:583,t:1527268116879};\\\", \\\"{x:1527,y:583,t:1527268116896};\\\", \\\"{x:1526,y:583,t:1527268116911};\\\", \\\"{x:1525,y:584,t:1527268116928};\\\", \\\"{x:1524,y:584,t:1527268116945};\\\", \\\"{x:1521,y:585,t:1527268116961};\\\", \\\"{x:1520,y:586,t:1527268116978};\\\", \\\"{x:1518,y:586,t:1527268116995};\\\", \\\"{x:1517,y:586,t:1527268117011};\\\", \\\"{x:1516,y:586,t:1527268117048};\\\", \\\"{x:1515,y:587,t:1527268117061};\\\", \\\"{x:1514,y:587,t:1527268117078};\\\", \\\"{x:1513,y:587,t:1527268117119};\\\", \\\"{x:1510,y:587,t:1527268117128};\\\", \\\"{x:1509,y:587,t:1527268117145};\\\", \\\"{x:1508,y:587,t:1527268117392};\\\", \\\"{x:1507,y:588,t:1527268117400};\\\", \\\"{x:1506,y:589,t:1527268117411};\\\", \\\"{x:1501,y:591,t:1527268117428};\\\", \\\"{x:1496,y:593,t:1527268117445};\\\", \\\"{x:1490,y:595,t:1527268117462};\\\", \\\"{x:1486,y:597,t:1527268117479};\\\", \\\"{x:1481,y:600,t:1527268117495};\\\", \\\"{x:1470,y:605,t:1527268117512};\\\", \\\"{x:1460,y:609,t:1527268117529};\\\", \\\"{x:1447,y:614,t:1527268117544};\\\", \\\"{x:1429,y:620,t:1527268117562};\\\", \\\"{x:1413,y:624,t:1527268117579};\\\", \\\"{x:1398,y:629,t:1527268117595};\\\", \\\"{x:1388,y:631,t:1527268117612};\\\", \\\"{x:1386,y:633,t:1527268117628};\\\", \\\"{x:1384,y:633,t:1527268117645};\\\", \\\"{x:1383,y:633,t:1527268117662};\\\", \\\"{x:1382,y:634,t:1527268117679};\\\", \\\"{x:1380,y:634,t:1527268117694};\\\", \\\"{x:1376,y:637,t:1527268117711};\\\", \\\"{x:1370,y:642,t:1527268117729};\\\", \\\"{x:1368,y:647,t:1527268117745};\\\", \\\"{x:1364,y:655,t:1527268117761};\\\", \\\"{x:1363,y:661,t:1527268117778};\\\", \\\"{x:1361,y:668,t:1527268117794};\\\", \\\"{x:1361,y:674,t:1527268117811};\\\", \\\"{x:1361,y:687,t:1527268117828};\\\", \\\"{x:1361,y:697,t:1527268117845};\\\", \\\"{x:1361,y:711,t:1527268117861};\\\", \\\"{x:1363,y:721,t:1527268117878};\\\", \\\"{x:1363,y:723,t:1527268117895};\\\", \\\"{x:1363,y:725,t:1527268118024};\\\", \\\"{x:1363,y:728,t:1527268118032};\\\", \\\"{x:1362,y:730,t:1527268118045};\\\", \\\"{x:1359,y:735,t:1527268118062};\\\", \\\"{x:1352,y:746,t:1527268118079};\\\", \\\"{x:1347,y:754,t:1527268118094};\\\", \\\"{x:1343,y:770,t:1527268118111};\\\", \\\"{x:1337,y:783,t:1527268118128};\\\", \\\"{x:1332,y:794,t:1527268118145};\\\", \\\"{x:1326,y:803,t:1527268118161};\\\", \\\"{x:1323,y:807,t:1527268118178};\\\", \\\"{x:1322,y:808,t:1527268118239};\\\", \\\"{x:1323,y:809,t:1527268118312};\\\", \\\"{x:1325,y:810,t:1527268118329};\\\", \\\"{x:1328,y:811,t:1527268118346};\\\", \\\"{x:1335,y:814,t:1527268118363};\\\", \\\"{x:1337,y:816,t:1527268118379};\\\", \\\"{x:1338,y:817,t:1527268118416};\\\", \\\"{x:1339,y:817,t:1527268118830};\\\", \\\"{x:1340,y:817,t:1527268118846};\\\", \\\"{x:1345,y:814,t:1527268118862};\\\", \\\"{x:1346,y:814,t:1527268118880};\\\", \\\"{x:1349,y:813,t:1527268118895};\\\", \\\"{x:1350,y:811,t:1527268118912};\\\", \\\"{x:1351,y:811,t:1527268118929};\\\", \\\"{x:1352,y:809,t:1527268118945};\\\", \\\"{x:1354,y:808,t:1527268118962};\\\", \\\"{x:1355,y:807,t:1527268118980};\\\", \\\"{x:1357,y:806,t:1527268118997};\\\", \\\"{x:1358,y:805,t:1527268119012};\\\", \\\"{x:1360,y:804,t:1527268119029};\\\", \\\"{x:1362,y:804,t:1527268119046};\\\", \\\"{x:1362,y:803,t:1527268119063};\\\", \\\"{x:1365,y:803,t:1527268119080};\\\", \\\"{x:1367,y:802,t:1527268119096};\\\", \\\"{x:1368,y:802,t:1527268119112};\\\", \\\"{x:1369,y:801,t:1527268119129};\\\", \\\"{x:1372,y:800,t:1527268119146};\\\", \\\"{x:1376,y:798,t:1527268119162};\\\", \\\"{x:1377,y:798,t:1527268119180};\\\", \\\"{x:1383,y:796,t:1527268119196};\\\", \\\"{x:1386,y:793,t:1527268119212};\\\", \\\"{x:1387,y:793,t:1527268119230};\\\", \\\"{x:1393,y:790,t:1527268119246};\\\", \\\"{x:1399,y:787,t:1527268119262};\\\", \\\"{x:1416,y:781,t:1527268119280};\\\", \\\"{x:1428,y:776,t:1527268119297};\\\", \\\"{x:1438,y:771,t:1527268119313};\\\", \\\"{x:1445,y:769,t:1527268119330};\\\", \\\"{x:1449,y:767,t:1527268119347};\\\", \\\"{x:1453,y:766,t:1527268119363};\\\", \\\"{x:1461,y:763,t:1527268119380};\\\", \\\"{x:1472,y:759,t:1527268119397};\\\", \\\"{x:1489,y:755,t:1527268119414};\\\", \\\"{x:1505,y:749,t:1527268119430};\\\", \\\"{x:1527,y:746,t:1527268119447};\\\", \\\"{x:1558,y:737,t:1527268119463};\\\", \\\"{x:1579,y:733,t:1527268119480};\\\", \\\"{x:1595,y:732,t:1527268119497};\\\", \\\"{x:1606,y:731,t:1527268119513};\\\", \\\"{x:1614,y:728,t:1527268119530};\\\", \\\"{x:1615,y:727,t:1527268119547};\\\", \\\"{x:1614,y:727,t:1527268119792};\\\", \\\"{x:1613,y:727,t:1527268119800};\\\", \\\"{x:1611,y:728,t:1527268119814};\\\", \\\"{x:1610,y:728,t:1527268119831};\\\", \\\"{x:1609,y:728,t:1527268119847};\\\", \\\"{x:1608,y:723,t:1527268120367};\\\", \\\"{x:1608,y:715,t:1527268120381};\\\", \\\"{x:1608,y:696,t:1527268120399};\\\", \\\"{x:1608,y:672,t:1527268120414};\\\", \\\"{x:1609,y:648,t:1527268120431};\\\", \\\"{x:1613,y:611,t:1527268120447};\\\", \\\"{x:1613,y:589,t:1527268120464};\\\", \\\"{x:1613,y:571,t:1527268120481};\\\", \\\"{x:1613,y:556,t:1527268120498};\\\", \\\"{x:1613,y:541,t:1527268120515};\\\", \\\"{x:1608,y:529,t:1527268120531};\\\", \\\"{x:1608,y:514,t:1527268120548};\\\", \\\"{x:1608,y:501,t:1527268120565};\\\", \\\"{x:1608,y:495,t:1527268120582};\\\", \\\"{x:1608,y:483,t:1527268120598};\\\", \\\"{x:1608,y:479,t:1527268120615};\\\", \\\"{x:1610,y:475,t:1527268120631};\\\", \\\"{x:1611,y:469,t:1527268120647};\\\", \\\"{x:1612,y:466,t:1527268120665};\\\", \\\"{x:1613,y:464,t:1527268120681};\\\", \\\"{x:1613,y:461,t:1527268120698};\\\", \\\"{x:1613,y:458,t:1527268120715};\\\", \\\"{x:1613,y:456,t:1527268120731};\\\", \\\"{x:1613,y:455,t:1527268120748};\\\", \\\"{x:1613,y:454,t:1527268120765};\\\", \\\"{x:1613,y:452,t:1527268120781};\\\", \\\"{x:1613,y:450,t:1527268120798};\\\", \\\"{x:1613,y:446,t:1527268120815};\\\", \\\"{x:1613,y:441,t:1527268120832};\\\", \\\"{x:1613,y:437,t:1527268120848};\\\", \\\"{x:1615,y:433,t:1527268120866};\\\", \\\"{x:1615,y:431,t:1527268120881};\\\", \\\"{x:1615,y:430,t:1527268120897};\\\", \\\"{x:1615,y:429,t:1527268120914};\\\", \\\"{x:1615,y:428,t:1527268120951};\\\", \\\"{x:1615,y:427,t:1527268120975};\\\", \\\"{x:1615,y:426,t:1527268120991};\\\", \\\"{x:1615,y:425,t:1527268120999};\\\", \\\"{x:1615,y:424,t:1527268121016};\\\", \\\"{x:1612,y:424,t:1527268121191};\\\", \\\"{x:1611,y:427,t:1527268121256};\\\", \\\"{x:1610,y:432,t:1527268121265};\\\", \\\"{x:1610,y:438,t:1527268121282};\\\", \\\"{x:1608,y:444,t:1527268121299};\\\", \\\"{x:1608,y:447,t:1527268121314};\\\", \\\"{x:1608,y:451,t:1527268121332};\\\", \\\"{x:1607,y:455,t:1527268121348};\\\", \\\"{x:1606,y:459,t:1527268121364};\\\", \\\"{x:1606,y:461,t:1527268121381};\\\", \\\"{x:1606,y:464,t:1527268121399};\\\", \\\"{x:1606,y:466,t:1527268121415};\\\", \\\"{x:1606,y:469,t:1527268121438};\\\", \\\"{x:1606,y:470,t:1527268121449};\\\", \\\"{x:1606,y:473,t:1527268121464};\\\", \\\"{x:1606,y:475,t:1527268121482};\\\", \\\"{x:1606,y:476,t:1527268121498};\\\", \\\"{x:1606,y:479,t:1527268121515};\\\", \\\"{x:1606,y:480,t:1527268121531};\\\", \\\"{x:1606,y:482,t:1527268121549};\\\", \\\"{x:1606,y:485,t:1527268121565};\\\", \\\"{x:1606,y:487,t:1527268121582};\\\", \\\"{x:1606,y:491,t:1527268121600};\\\", \\\"{x:1606,y:495,t:1527268121615};\\\", \\\"{x:1606,y:500,t:1527268121632};\\\", \\\"{x:1607,y:506,t:1527268121648};\\\", \\\"{x:1609,y:515,t:1527268121665};\\\", \\\"{x:1609,y:522,t:1527268121682};\\\", \\\"{x:1610,y:528,t:1527268121699};\\\", \\\"{x:1612,y:536,t:1527268121715};\\\", \\\"{x:1613,y:540,t:1527268121732};\\\", \\\"{x:1614,y:544,t:1527268121749};\\\", \\\"{x:1614,y:546,t:1527268121766};\\\", \\\"{x:1614,y:549,t:1527268121782};\\\", \\\"{x:1615,y:553,t:1527268121799};\\\", \\\"{x:1615,y:556,t:1527268121815};\\\", \\\"{x:1615,y:558,t:1527268121836};\\\", \\\"{x:1615,y:559,t:1527268121848};\\\", \\\"{x:1615,y:560,t:1527268121871};\\\", \\\"{x:1615,y:561,t:1527268121886};\\\", \\\"{x:1615,y:562,t:1527268121898};\\\", \\\"{x:1615,y:563,t:1527268121927};\\\", \\\"{x:1615,y:564,t:1527268121942};\\\", \\\"{x:1615,y:565,t:1527268121951};\\\", \\\"{x:1615,y:566,t:1527268121965};\\\", \\\"{x:1615,y:569,t:1527268121982};\\\", \\\"{x:1616,y:572,t:1527268121999};\\\", \\\"{x:1616,y:574,t:1527268122152};\\\", \\\"{x:1616,y:576,t:1527268122166};\\\", \\\"{x:1616,y:583,t:1527268122183};\\\", \\\"{x:1616,y:589,t:1527268122199};\\\", \\\"{x:1616,y:598,t:1527268122216};\\\", \\\"{x:1616,y:606,t:1527268122234};\\\", \\\"{x:1616,y:614,t:1527268122249};\\\", \\\"{x:1616,y:620,t:1527268122266};\\\", \\\"{x:1616,y:626,t:1527268122283};\\\", \\\"{x:1616,y:634,t:1527268122299};\\\", \\\"{x:1616,y:645,t:1527268122316};\\\", \\\"{x:1616,y:662,t:1527268122333};\\\", \\\"{x:1616,y:683,t:1527268122349};\\\", \\\"{x:1614,y:708,t:1527268122367};\\\", \\\"{x:1611,y:741,t:1527268122383};\\\", \\\"{x:1610,y:760,t:1527268122400};\\\", \\\"{x:1606,y:773,t:1527268122416};\\\", \\\"{x:1606,y:782,t:1527268122434};\\\", \\\"{x:1606,y:786,t:1527268122450};\\\", \\\"{x:1605,y:786,t:1527268122568};\\\", \\\"{x:1605,y:787,t:1527268122838};\\\", \\\"{x:1605,y:788,t:1527268122850};\\\", \\\"{x:1605,y:790,t:1527268122867};\\\", \\\"{x:1605,y:791,t:1527268122883};\\\", \\\"{x:1606,y:795,t:1527268122899};\\\", \\\"{x:1608,y:799,t:1527268122916};\\\", \\\"{x:1610,y:803,t:1527268122933};\\\", \\\"{x:1612,y:808,t:1527268122949};\\\", \\\"{x:1614,y:814,t:1527268122967};\\\", \\\"{x:1616,y:819,t:1527268122983};\\\", \\\"{x:1617,y:824,t:1527268122999};\\\", \\\"{x:1618,y:829,t:1527268123018};\\\", \\\"{x:1618,y:833,t:1527268123033};\\\", \\\"{x:1618,y:837,t:1527268123050};\\\", \\\"{x:1620,y:841,t:1527268123067};\\\", \\\"{x:1621,y:847,t:1527268123083};\\\", \\\"{x:1621,y:852,t:1527268123100};\\\", \\\"{x:1621,y:858,t:1527268123117};\\\", \\\"{x:1621,y:862,t:1527268123133};\\\", \\\"{x:1622,y:867,t:1527268123150};\\\", \\\"{x:1622,y:875,t:1527268123167};\\\", \\\"{x:1622,y:882,t:1527268123183};\\\", \\\"{x:1622,y:889,t:1527268123200};\\\", \\\"{x:1620,y:898,t:1527268123217};\\\", \\\"{x:1619,y:906,t:1527268123234};\\\", \\\"{x:1616,y:915,t:1527268123251};\\\", \\\"{x:1614,y:921,t:1527268123267};\\\", \\\"{x:1612,y:929,t:1527268123284};\\\", \\\"{x:1610,y:937,t:1527268123300};\\\", \\\"{x:1608,y:943,t:1527268123317};\\\", \\\"{x:1605,y:955,t:1527268123334};\\\", \\\"{x:1601,y:964,t:1527268123350};\\\", \\\"{x:1597,y:980,t:1527268123367};\\\", \\\"{x:1593,y:989,t:1527268123384};\\\", \\\"{x:1593,y:995,t:1527268123400};\\\", \\\"{x:1593,y:997,t:1527268123417};\\\", \\\"{x:1593,y:998,t:1527268123435};\\\", \\\"{x:1594,y:998,t:1527268123463};\\\", \\\"{x:1596,y:998,t:1527268123471};\\\", \\\"{x:1598,y:997,t:1527268123484};\\\", \\\"{x:1602,y:992,t:1527268123500};\\\", \\\"{x:1608,y:985,t:1527268123517};\\\", \\\"{x:1611,y:983,t:1527268123534};\\\", \\\"{x:1612,y:978,t:1527268123576};\\\", \\\"{x:1612,y:976,t:1527268123583};\\\", \\\"{x:1612,y:969,t:1527268123600};\\\", \\\"{x:1612,y:961,t:1527268123618};\\\", \\\"{x:1612,y:955,t:1527268123634};\\\", \\\"{x:1612,y:951,t:1527268123651};\\\", \\\"{x:1611,y:946,t:1527268123667};\\\", \\\"{x:1610,y:942,t:1527268123684};\\\", \\\"{x:1609,y:937,t:1527268123701};\\\", \\\"{x:1609,y:935,t:1527268123717};\\\", \\\"{x:1609,y:933,t:1527268123734};\\\", \\\"{x:1608,y:930,t:1527268123752};\\\", \\\"{x:1607,y:927,t:1527268123767};\\\", \\\"{x:1606,y:925,t:1527268123784};\\\", \\\"{x:1606,y:922,t:1527268123801};\\\", \\\"{x:1606,y:919,t:1527268123817};\\\", \\\"{x:1605,y:915,t:1527268123834};\\\", \\\"{x:1605,y:911,t:1527268123851};\\\", \\\"{x:1604,y:906,t:1527268123867};\\\", \\\"{x:1602,y:900,t:1527268123884};\\\", \\\"{x:1602,y:894,t:1527268123901};\\\", \\\"{x:1602,y:887,t:1527268123917};\\\", \\\"{x:1601,y:878,t:1527268123934};\\\", \\\"{x:1600,y:861,t:1527268123951};\\\", \\\"{x:1598,y:851,t:1527268123967};\\\", \\\"{x:1596,y:842,t:1527268123984};\\\", \\\"{x:1596,y:834,t:1527268124001};\\\", \\\"{x:1596,y:824,t:1527268124018};\\\", \\\"{x:1596,y:810,t:1527268124034};\\\", \\\"{x:1596,y:796,t:1527268124051};\\\", \\\"{x:1596,y:780,t:1527268124068};\\\", \\\"{x:1596,y:764,t:1527268124084};\\\", \\\"{x:1593,y:747,t:1527268124102};\\\", \\\"{x:1593,y:729,t:1527268124118};\\\", \\\"{x:1593,y:714,t:1527268124135};\\\", \\\"{x:1593,y:687,t:1527268124152};\\\", \\\"{x:1592,y:661,t:1527268124168};\\\", \\\"{x:1592,y:636,t:1527268124184};\\\", \\\"{x:1586,y:606,t:1527268124201};\\\", \\\"{x:1578,y:578,t:1527268124218};\\\", \\\"{x:1567,y:553,t:1527268124234};\\\", \\\"{x:1549,y:526,t:1527268124251};\\\", \\\"{x:1522,y:497,t:1527268124268};\\\", \\\"{x:1498,y:479,t:1527268124285};\\\", \\\"{x:1462,y:458,t:1527268124301};\\\", \\\"{x:1416,y:435,t:1527268124318};\\\", \\\"{x:1328,y:401,t:1527268124336};\\\", \\\"{x:1261,y:382,t:1527268124352};\\\", \\\"{x:1187,y:365,t:1527268124367};\\\", \\\"{x:1109,y:354,t:1527268124385};\\\", \\\"{x:1029,y:345,t:1527268124401};\\\", \\\"{x:943,y:345,t:1527268124418};\\\", \\\"{x:860,y:345,t:1527268124435};\\\", \\\"{x:784,y:359,t:1527268124451};\\\", \\\"{x:713,y:371,t:1527268124468};\\\", \\\"{x:663,y:385,t:1527268124485};\\\", \\\"{x:619,y:405,t:1527268124500};\\\", \\\"{x:593,y:419,t:1527268124518};\\\", \\\"{x:555,y:446,t:1527268124535};\\\", \\\"{x:533,y:464,t:1527268124551};\\\", \\\"{x:512,y:485,t:1527268124568};\\\", \\\"{x:484,y:508,t:1527268124586};\\\", \\\"{x:467,y:524,t:1527268124600};\\\", \\\"{x:453,y:535,t:1527268124617};\\\", \\\"{x:446,y:540,t:1527268124634};\\\", \\\"{x:444,y:542,t:1527268124649};\\\", \\\"{x:446,y:541,t:1527268124719};\\\", \\\"{x:447,y:540,t:1527268124734};\\\", \\\"{x:456,y:535,t:1527268124752};\\\", \\\"{x:465,y:531,t:1527268124766};\\\", \\\"{x:478,y:526,t:1527268124783};\\\", \\\"{x:486,y:524,t:1527268124800};\\\", \\\"{x:493,y:522,t:1527268124816};\\\", \\\"{x:496,y:521,t:1527268124834};\\\", \\\"{x:498,y:521,t:1527268124851};\\\", \\\"{x:500,y:520,t:1527268124867};\\\", \\\"{x:505,y:519,t:1527268124883};\\\", \\\"{x:509,y:519,t:1527268124900};\\\", \\\"{x:515,y:521,t:1527268124916};\\\", \\\"{x:527,y:525,t:1527268124933};\\\", \\\"{x:538,y:528,t:1527268124950};\\\", \\\"{x:545,y:529,t:1527268124966};\\\", \\\"{x:548,y:529,t:1527268124984};\\\", \\\"{x:550,y:529,t:1527268125001};\\\", \\\"{x:552,y:529,t:1527268125017};\\\", \\\"{x:556,y:530,t:1527268125034};\\\", \\\"{x:558,y:530,t:1527268125051};\\\", \\\"{x:562,y:531,t:1527268125067};\\\", \\\"{x:567,y:532,t:1527268125083};\\\", \\\"{x:569,y:533,t:1527268125100};\\\", \\\"{x:571,y:533,t:1527268125119};\\\", \\\"{x:572,y:534,t:1527268125239};\\\", \\\"{x:572,y:535,t:1527268125251};\\\", \\\"{x:572,y:538,t:1527268125269};\\\", \\\"{x:572,y:539,t:1527268125283};\\\", \\\"{x:573,y:542,t:1527268125301};\\\", \\\"{x:576,y:544,t:1527268125318};\\\", \\\"{x:577,y:545,t:1527268125334};\\\", \\\"{x:579,y:546,t:1527268125351};\\\", \\\"{x:577,y:547,t:1527268125807};\\\", \\\"{x:574,y:549,t:1527268125818};\\\", \\\"{x:566,y:550,t:1527268125834};\\\", \\\"{x:563,y:553,t:1527268125851};\\\", \\\"{x:562,y:553,t:1527268125868};\\\", \\\"{x:559,y:554,t:1527268125895};\\\", \\\"{x:557,y:554,t:1527268125911};\\\", \\\"{x:555,y:555,t:1527268125919};\\\", \\\"{x:551,y:557,t:1527268125935};\\\", \\\"{x:546,y:559,t:1527268125952};\\\", \\\"{x:544,y:559,t:1527268125968};\\\", \\\"{x:542,y:560,t:1527268125985};\\\", \\\"{x:538,y:561,t:1527268126002};\\\", \\\"{x:524,y:561,t:1527268126018};\\\", \\\"{x:504,y:561,t:1527268126035};\\\", \\\"{x:477,y:561,t:1527268126055};\\\", \\\"{x:449,y:561,t:1527268126068};\\\", \\\"{x:425,y:561,t:1527268126084};\\\", \\\"{x:405,y:561,t:1527268126101};\\\", \\\"{x:386,y:561,t:1527268126117};\\\", \\\"{x:356,y:561,t:1527268126134};\\\", \\\"{x:340,y:561,t:1527268126151};\\\", \\\"{x:335,y:561,t:1527268126167};\\\", \\\"{x:333,y:561,t:1527268126185};\\\", \\\"{x:327,y:561,t:1527268126367};\\\", \\\"{x:297,y:551,t:1527268126385};\\\", \\\"{x:251,y:541,t:1527268126403};\\\", \\\"{x:193,y:525,t:1527268126419};\\\", \\\"{x:87,y:509,t:1527268126434};\\\", \\\"{x:0,y:491,t:1527268126451};\\\", \\\"{x:0,y:476,t:1527268126469};\\\", \\\"{x:0,y:469,t:1527268126485};\\\", \\\"{x:0,y:471,t:1527268126501};\\\", \\\"{x:1,y:472,t:1527268126526};\\\", \\\"{x:6,y:472,t:1527268126534};\\\", \\\"{x:23,y:472,t:1527268126552};\\\", \\\"{x:41,y:477,t:1527268126569};\\\", \\\"{x:64,y:488,t:1527268126585};\\\", \\\"{x:87,y:500,t:1527268126602};\\\", \\\"{x:111,y:519,t:1527268126619};\\\", \\\"{x:128,y:534,t:1527268126634};\\\", \\\"{x:147,y:550,t:1527268126653};\\\", \\\"{x:162,y:565,t:1527268126668};\\\", \\\"{x:168,y:571,t:1527268126685};\\\", \\\"{x:177,y:580,t:1527268126702};\\\", \\\"{x:188,y:595,t:1527268126719};\\\", \\\"{x:193,y:605,t:1527268126735};\\\", \\\"{x:196,y:617,t:1527268126752};\\\", \\\"{x:197,y:628,t:1527268126769};\\\", \\\"{x:197,y:637,t:1527268126784};\\\", \\\"{x:197,y:645,t:1527268126801};\\\", \\\"{x:197,y:654,t:1527268126819};\\\", \\\"{x:198,y:665,t:1527268126835};\\\", \\\"{x:201,y:679,t:1527268126852};\\\", \\\"{x:201,y:689,t:1527268126868};\\\", \\\"{x:201,y:694,t:1527268126885};\\\", \\\"{x:201,y:696,t:1527268126901};\\\", \\\"{x:200,y:697,t:1527268126918};\\\", \\\"{x:198,y:693,t:1527268127110};\\\", \\\"{x:198,y:691,t:1527268127118};\\\", \\\"{x:196,y:686,t:1527268127136};\\\", \\\"{x:195,y:680,t:1527268127151};\\\", \\\"{x:192,y:676,t:1527268127169};\\\", \\\"{x:191,y:675,t:1527268127185};\\\", \\\"{x:190,y:674,t:1527268127279};\\\", \\\"{x:190,y:673,t:1527268127287};\\\", \\\"{x:190,y:672,t:1527268127302};\\\", \\\"{x:189,y:668,t:1527268127319};\\\", \\\"{x:187,y:665,t:1527268127335};\\\", \\\"{x:185,y:665,t:1527268127352};\\\", \\\"{x:184,y:665,t:1527268127416};\\\", \\\"{x:182,y:665,t:1527268127430};\\\", \\\"{x:181,y:665,t:1527268127439};\\\", \\\"{x:178,y:665,t:1527268127452};\\\", \\\"{x:176,y:665,t:1527268127468};\\\", \\\"{x:175,y:665,t:1527268127486};\\\", \\\"{x:174,y:665,t:1527268127711};\\\", \\\"{x:173,y:665,t:1527268127976};\\\", \\\"{x:171,y:663,t:1527268127991};\\\", \\\"{x:171,y:662,t:1527268128002};\\\", \\\"{x:170,y:659,t:1527268128019};\\\", \\\"{x:169,y:658,t:1527268128036};\\\", \\\"{x:167,y:658,t:1527268128264};\\\", \\\"{x:164,y:656,t:1527268128279};\\\", \\\"{x:163,y:655,t:1527268128287};\\\", \\\"{x:162,y:654,t:1527268128303};\\\", \\\"{x:160,y:652,t:1527268128320};\\\", \\\"{x:157,y:648,t:1527268128336};\\\", \\\"{x:156,y:647,t:1527268128351};\\\", \\\"{x:156,y:645,t:1527268128487};\\\", \\\"{x:156,y:643,t:1527268128503};\\\", \\\"{x:156,y:641,t:1527268128920};\\\", \\\"{x:157,y:640,t:1527268128943};\\\", \\\"{x:158,y:640,t:1527268128954};\\\", \\\"{x:159,y:640,t:1527268128975};\\\", \\\"{x:161,y:639,t:1527268128999};\\\", \\\"{x:161,y:638,t:1527268129007};\\\", \\\"{x:162,y:638,t:1527268129020};\\\", \\\"{x:164,y:637,t:1527268129038};\\\", \\\"{x:166,y:636,t:1527268129279};\\\", \\\"{x:166,y:635,t:1527268129287};\\\", \\\"{x:169,y:635,t:1527268129304};\\\", \\\"{x:172,y:633,t:1527268129321};\\\", \\\"{x:175,y:632,t:1527268129337};\\\", \\\"{x:180,y:629,t:1527268129354};\\\", \\\"{x:197,y:628,t:1527268129371};\\\", \\\"{x:226,y:626,t:1527268129386};\\\", \\\"{x:255,y:621,t:1527268129404};\\\", \\\"{x:283,y:620,t:1527268129421};\\\", \\\"{x:319,y:620,t:1527268129437};\\\", \\\"{x:342,y:620,t:1527268129453};\\\", \\\"{x:417,y:627,t:1527268129471};\\\", \\\"{x:450,y:632,t:1527268129488};\\\", \\\"{x:477,y:637,t:1527268129503};\\\", \\\"{x:513,y:646,t:1527268129521};\\\", \\\"{x:533,y:651,t:1527268129538};\\\", \\\"{x:545,y:658,t:1527268129554};\\\", \\\"{x:549,y:661,t:1527268129571};\\\", \\\"{x:550,y:661,t:1527268129647};\\\", \\\"{x:550,y:662,t:1527268129960};\\\", \\\"{x:550,y:663,t:1527268129971};\\\", \\\"{x:550,y:664,t:1527268129988};\\\", \\\"{x:549,y:665,t:1527268130005};\\\", \\\"{x:547,y:666,t:1527268130021};\\\", \\\"{x:546,y:667,t:1527268130038};\\\", \\\"{x:540,y:670,t:1527268130056};\\\", \\\"{x:537,y:671,t:1527268130071};\\\", \\\"{x:535,y:673,t:1527268130088};\\\", \\\"{x:533,y:673,t:1527268130105};\\\", \\\"{x:530,y:675,t:1527268130121};\\\", \\\"{x:527,y:676,t:1527268130138};\\\", \\\"{x:524,y:677,t:1527268130155};\\\", \\\"{x:523,y:677,t:1527268130171};\\\", \\\"{x:522,y:679,t:1527268130188};\\\", \\\"{x:520,y:680,t:1527268130205};\\\", \\\"{x:520,y:681,t:1527268130222};\\\", \\\"{x:518,y:683,t:1527268130238};\\\", \\\"{x:516,y:685,t:1527268130255};\\\", \\\"{x:515,y:685,t:1527268130271};\\\", \\\"{x:515,y:686,t:1527268130447};\\\", \\\"{x:515,y:688,t:1527268130455};\\\", \\\"{x:515,y:690,t:1527268130472};\\\", \\\"{x:512,y:694,t:1527268130488};\\\", \\\"{x:512,y:697,t:1527268130505};\\\", \\\"{x:510,y:702,t:1527268130523};\\\", \\\"{x:509,y:705,t:1527268130539};\\\", \\\"{x:507,y:708,t:1527268130554};\\\", \\\"{x:507,y:711,t:1527268130572};\\\", \\\"{x:505,y:713,t:1527268130590};\\\", \\\"{x:505,y:714,t:1527268130606};\\\", \\\"{x:504,y:715,t:1527268130622};\\\", \\\"{x:505,y:715,t:1527268131216};\\\", \\\"{x:506,y:715,t:1527268131263};\\\", \\\"{x:507,y:714,t:1527268131287};\\\", \\\"{x:508,y:714,t:1527268131342};\\\", \\\"{x:509,y:713,t:1527268131358};\\\", \\\"{x:510,y:713,t:1527268131422};\\\", \\\"{x:511,y:713,t:1527268131511};\\\" ] }, { \\\"rt\\\": 26714, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 198687, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"967LR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -C -C -A -A -A -C -C -Z \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:516,y:711,t:1527268132081};\\\", \\\"{x:517,y:711,t:1527268132134};\\\", \\\"{x:519,y:711,t:1527268132278};\\\", \\\"{x:520,y:711,t:1527268132318};\\\", \\\"{x:522,y:710,t:1527268132343};\\\", \\\"{x:524,y:710,t:1527268132367};\\\", \\\"{x:525,y:709,t:1527268132375};\\\", \\\"{x:526,y:709,t:1527268132390};\\\", \\\"{x:527,y:708,t:1527268132406};\\\", \\\"{x:533,y:705,t:1527268132423};\\\", \\\"{x:537,y:703,t:1527268132440};\\\", \\\"{x:543,y:698,t:1527268132458};\\\", \\\"{x:551,y:691,t:1527268132473};\\\", \\\"{x:561,y:679,t:1527268132490};\\\", \\\"{x:573,y:664,t:1527268132507};\\\", \\\"{x:582,y:651,t:1527268132522};\\\", \\\"{x:588,y:637,t:1527268132540};\\\", \\\"{x:593,y:627,t:1527268132557};\\\", \\\"{x:599,y:613,t:1527268132573};\\\", \\\"{x:658,y:556,t:1527268132667};\\\", \\\"{x:665,y:551,t:1527268132675};\\\", \\\"{x:680,y:543,t:1527268132690};\\\", \\\"{x:696,y:535,t:1527268132707};\\\", \\\"{x:712,y:530,t:1527268132723};\\\", \\\"{x:735,y:522,t:1527268132740};\\\", \\\"{x:788,y:522,t:1527268132757};\\\", \\\"{x:867,y:518,t:1527268132774};\\\", \\\"{x:951,y:512,t:1527268132790};\\\", \\\"{x:1068,y:512,t:1527268132807};\\\", \\\"{x:1116,y:512,t:1527268132824};\\\", \\\"{x:1149,y:512,t:1527268132840};\\\", \\\"{x:1171,y:512,t:1527268132857};\\\", \\\"{x:1184,y:512,t:1527268132874};\\\", \\\"{x:1189,y:512,t:1527268132890};\\\", \\\"{x:1192,y:512,t:1527268132907};\\\", \\\"{x:1192,y:511,t:1527268132926};\\\", \\\"{x:1191,y:504,t:1527268132940};\\\", \\\"{x:1179,y:487,t:1527268132957};\\\", \\\"{x:1162,y:467,t:1527268132974};\\\", \\\"{x:1134,y:446,t:1527268132990};\\\", \\\"{x:1105,y:426,t:1527268133007};\\\", \\\"{x:1087,y:408,t:1527268133024};\\\", \\\"{x:1074,y:388,t:1527268133040};\\\", \\\"{x:1053,y:353,t:1527268133057};\\\", \\\"{x:1042,y:330,t:1527268133074};\\\", \\\"{x:1039,y:322,t:1527268133090};\\\", \\\"{x:1037,y:322,t:1527268133107};\\\", \\\"{x:1042,y:304,t:1527268133671};\\\", \\\"{x:1043,y:304,t:1527268133775};\\\", \\\"{x:1045,y:301,t:1527268133791};\\\", \\\"{x:1046,y:300,t:1527268133809};\\\", \\\"{x:1046,y:301,t:1527268133920};\\\", \\\"{x:1047,y:303,t:1527268133927};\\\", \\\"{x:1049,y:305,t:1527268133942};\\\", \\\"{x:1050,y:306,t:1527268133958};\\\", \\\"{x:1051,y:312,t:1527268133974};\\\", \\\"{x:1057,y:316,t:1527268133990};\\\", \\\"{x:1063,y:321,t:1527268134007};\\\", \\\"{x:1072,y:327,t:1527268134024};\\\", \\\"{x:1085,y:335,t:1527268134041};\\\", \\\"{x:1097,y:340,t:1527268134058};\\\", \\\"{x:1113,y:350,t:1527268134075};\\\", \\\"{x:1128,y:361,t:1527268134090};\\\", \\\"{x:1147,y:369,t:1527268134108};\\\", \\\"{x:1169,y:375,t:1527268134125};\\\", \\\"{x:1193,y:386,t:1527268134141};\\\", \\\"{x:1216,y:397,t:1527268134158};\\\", \\\"{x:1242,y:408,t:1527268134174};\\\", \\\"{x:1255,y:414,t:1527268134190};\\\", \\\"{x:1266,y:419,t:1527268134208};\\\", \\\"{x:1270,y:421,t:1527268134225};\\\", \\\"{x:1274,y:424,t:1527268134241};\\\", \\\"{x:1278,y:426,t:1527268134259};\\\", \\\"{x:1286,y:429,t:1527268134275};\\\", \\\"{x:1293,y:434,t:1527268134292};\\\", \\\"{x:1297,y:439,t:1527268134308};\\\", \\\"{x:1303,y:444,t:1527268134325};\\\", \\\"{x:1307,y:447,t:1527268134342};\\\", \\\"{x:1310,y:453,t:1527268134358};\\\", \\\"{x:1312,y:463,t:1527268134374};\\\", \\\"{x:1316,y:475,t:1527268134392};\\\", \\\"{x:1319,y:485,t:1527268134408};\\\", \\\"{x:1322,y:493,t:1527268134425};\\\", \\\"{x:1324,y:500,t:1527268134442};\\\", \\\"{x:1325,y:506,t:1527268134458};\\\", \\\"{x:1326,y:513,t:1527268134475};\\\", \\\"{x:1326,y:517,t:1527268134492};\\\", \\\"{x:1326,y:521,t:1527268134509};\\\", \\\"{x:1326,y:527,t:1527268134525};\\\", \\\"{x:1328,y:535,t:1527268134542};\\\", \\\"{x:1329,y:549,t:1527268134559};\\\", \\\"{x:1329,y:574,t:1527268134575};\\\", \\\"{x:1329,y:594,t:1527268134592};\\\", \\\"{x:1325,y:618,t:1527268134609};\\\", \\\"{x:1321,y:640,t:1527268134625};\\\", \\\"{x:1320,y:655,t:1527268134643};\\\", \\\"{x:1320,y:661,t:1527268134660};\\\", \\\"{x:1320,y:664,t:1527268134675};\\\", \\\"{x:1321,y:667,t:1527268134692};\\\", \\\"{x:1321,y:670,t:1527268134774};\\\", \\\"{x:1321,y:671,t:1527268134792};\\\", \\\"{x:1321,y:672,t:1527268134855};\\\", \\\"{x:1321,y:673,t:1527268134862};\\\", \\\"{x:1321,y:674,t:1527268134879};\\\", \\\"{x:1321,y:677,t:1527268134893};\\\", \\\"{x:1321,y:681,t:1527268134909};\\\", \\\"{x:1321,y:687,t:1527268134925};\\\", \\\"{x:1322,y:693,t:1527268134942};\\\", \\\"{x:1326,y:701,t:1527268134959};\\\", \\\"{x:1331,y:707,t:1527268134976};\\\", \\\"{x:1339,y:711,t:1527268134992};\\\", \\\"{x:1342,y:714,t:1527268135009};\\\", \\\"{x:1346,y:717,t:1527268135025};\\\", \\\"{x:1351,y:718,t:1527268135043};\\\", \\\"{x:1352,y:719,t:1527268135059};\\\", \\\"{x:1353,y:720,t:1527268135231};\\\", \\\"{x:1354,y:722,t:1527268135243};\\\", \\\"{x:1354,y:725,t:1527268135260};\\\", \\\"{x:1354,y:730,t:1527268135276};\\\", \\\"{x:1351,y:736,t:1527268135292};\\\", \\\"{x:1345,y:746,t:1527268135310};\\\", \\\"{x:1339,y:754,t:1527268135327};\\\", \\\"{x:1335,y:760,t:1527268135343};\\\", \\\"{x:1332,y:763,t:1527268135360};\\\", \\\"{x:1331,y:764,t:1527268135377};\\\", \\\"{x:1329,y:766,t:1527268135393};\\\", \\\"{x:1324,y:770,t:1527268135410};\\\", \\\"{x:1318,y:774,t:1527268135426};\\\", \\\"{x:1305,y:781,t:1527268135443};\\\", \\\"{x:1299,y:784,t:1527268135460};\\\", \\\"{x:1294,y:786,t:1527268135476};\\\", \\\"{x:1293,y:787,t:1527268135494};\\\", \\\"{x:1290,y:789,t:1527268135510};\\\", \\\"{x:1290,y:790,t:1527268135527};\\\", \\\"{x:1284,y:792,t:1527268135543};\\\", \\\"{x:1278,y:795,t:1527268135559};\\\", \\\"{x:1270,y:797,t:1527268135577};\\\", \\\"{x:1268,y:798,t:1527268135594};\\\", \\\"{x:1267,y:798,t:1527268135609};\\\", \\\"{x:1265,y:798,t:1527268135627};\\\", \\\"{x:1264,y:798,t:1527268135644};\\\", \\\"{x:1262,y:800,t:1527268135659};\\\", \\\"{x:1260,y:800,t:1527268135676};\\\", \\\"{x:1255,y:801,t:1527268135694};\\\", \\\"{x:1250,y:803,t:1527268135710};\\\", \\\"{x:1245,y:805,t:1527268135726};\\\", \\\"{x:1243,y:806,t:1527268135743};\\\", \\\"{x:1242,y:807,t:1527268135759};\\\", \\\"{x:1238,y:808,t:1527268135776};\\\", \\\"{x:1235,y:809,t:1527268135794};\\\", \\\"{x:1234,y:809,t:1527268135811};\\\", \\\"{x:1233,y:810,t:1527268135827};\\\", \\\"{x:1232,y:810,t:1527268135844};\\\", \\\"{x:1230,y:811,t:1527268135860};\\\", \\\"{x:1230,y:812,t:1527268135879};\\\", \\\"{x:1228,y:813,t:1527268135896};\\\", \\\"{x:1227,y:814,t:1527268135919};\\\", \\\"{x:1226,y:814,t:1527268135927};\\\", \\\"{x:1224,y:815,t:1527268135951};\\\", \\\"{x:1221,y:818,t:1527268135968};\\\", \\\"{x:1220,y:818,t:1527268135983};\\\", \\\"{x:1219,y:818,t:1527268135993};\\\", \\\"{x:1218,y:819,t:1527268136023};\\\", \\\"{x:1217,y:819,t:1527268136040};\\\", \\\"{x:1215,y:820,t:1527268136046};\\\", \\\"{x:1213,y:821,t:1527268136060};\\\", \\\"{x:1206,y:822,t:1527268136076};\\\", \\\"{x:1202,y:822,t:1527268136093};\\\", \\\"{x:1201,y:822,t:1527268136110};\\\", \\\"{x:1202,y:822,t:1527268136551};\\\", \\\"{x:1204,y:821,t:1527268136574};\\\", \\\"{x:1205,y:821,t:1527268136590};\\\", \\\"{x:1207,y:821,t:1527268136606};\\\", \\\"{x:1208,y:821,t:1527268136646};\\\", \\\"{x:1210,y:821,t:1527268136686};\\\", \\\"{x:1211,y:821,t:1527268136735};\\\", \\\"{x:1212,y:821,t:1527268136759};\\\", \\\"{x:1213,y:821,t:1527268136766};\\\", \\\"{x:1214,y:821,t:1527268136783};\\\", \\\"{x:1216,y:822,t:1527268137014};\\\", \\\"{x:1217,y:822,t:1527268137134};\\\", \\\"{x:1219,y:822,t:1527268137198};\\\", \\\"{x:1220,y:822,t:1527268137230};\\\", \\\"{x:1221,y:822,t:1527268137326};\\\", \\\"{x:1222,y:822,t:1527268137334};\\\", \\\"{x:1221,y:823,t:1527268137943};\\\", \\\"{x:1220,y:823,t:1527268138048};\\\", \\\"{x:1219,y:823,t:1527268138063};\\\", \\\"{x:1218,y:823,t:1527268138079};\\\", \\\"{x:1217,y:823,t:1527268138096};\\\", \\\"{x:1221,y:823,t:1527268138520};\\\", \\\"{x:1223,y:823,t:1527268138530};\\\", \\\"{x:1225,y:823,t:1527268138545};\\\", \\\"{x:1226,y:822,t:1527268138562};\\\", \\\"{x:1228,y:822,t:1527268138607};\\\", \\\"{x:1229,y:822,t:1527268138623};\\\", \\\"{x:1230,y:822,t:1527268138640};\\\", \\\"{x:1231,y:821,t:1527268138647};\\\", \\\"{x:1232,y:821,t:1527268138671};\\\", \\\"{x:1233,y:821,t:1527268138679};\\\", \\\"{x:1234,y:821,t:1527268138696};\\\", \\\"{x:1237,y:820,t:1527268138713};\\\", \\\"{x:1246,y:820,t:1527268138730};\\\", \\\"{x:1253,y:820,t:1527268138746};\\\", \\\"{x:1261,y:820,t:1527268138763};\\\", \\\"{x:1267,y:820,t:1527268138780};\\\", \\\"{x:1271,y:820,t:1527268138795};\\\", \\\"{x:1276,y:822,t:1527268138813};\\\", \\\"{x:1280,y:823,t:1527268138830};\\\", \\\"{x:1283,y:825,t:1527268138848};\\\", \\\"{x:1289,y:825,t:1527268138865};\\\", \\\"{x:1291,y:827,t:1527268138879};\\\", \\\"{x:1292,y:828,t:1527268138897};\\\", \\\"{x:1294,y:829,t:1527268138913};\\\", \\\"{x:1295,y:830,t:1527268138930};\\\", \\\"{x:1296,y:831,t:1527268138947};\\\", \\\"{x:1297,y:834,t:1527268138963};\\\", \\\"{x:1299,y:839,t:1527268138980};\\\", \\\"{x:1300,y:844,t:1527268138996};\\\", \\\"{x:1301,y:848,t:1527268139012};\\\", \\\"{x:1302,y:852,t:1527268139029};\\\", \\\"{x:1302,y:853,t:1527268139046};\\\", \\\"{x:1301,y:853,t:1527268139176};\\\", \\\"{x:1299,y:853,t:1527268139191};\\\", \\\"{x:1298,y:852,t:1527268139199};\\\", \\\"{x:1296,y:851,t:1527268139213};\\\", \\\"{x:1294,y:850,t:1527268139233};\\\", \\\"{x:1293,y:850,t:1527268139259};\\\", \\\"{x:1293,y:848,t:1527268139371};\\\", \\\"{x:1293,y:846,t:1527268139383};\\\", \\\"{x:1293,y:845,t:1527268139400};\\\", \\\"{x:1293,y:843,t:1527268139417};\\\", \\\"{x:1293,y:840,t:1527268139433};\\\", \\\"{x:1293,y:839,t:1527268139450};\\\", \\\"{x:1293,y:837,t:1527268139482};\\\", \\\"{x:1293,y:836,t:1527268139627};\\\", \\\"{x:1293,y:835,t:1527268139643};\\\", \\\"{x:1295,y:834,t:1527268139667};\\\", \\\"{x:1296,y:833,t:1527268139691};\\\", \\\"{x:1297,y:833,t:1527268139723};\\\", \\\"{x:1298,y:832,t:1527268139734};\\\", \\\"{x:1299,y:832,t:1527268139750};\\\", \\\"{x:1300,y:832,t:1527268139787};\\\", \\\"{x:1301,y:831,t:1527268139802};\\\", \\\"{x:1302,y:831,t:1527268139819};\\\", \\\"{x:1304,y:830,t:1527268139835};\\\", \\\"{x:1307,y:829,t:1527268139851};\\\", \\\"{x:1309,y:829,t:1527268139867};\\\", \\\"{x:1313,y:828,t:1527268139885};\\\", \\\"{x:1314,y:827,t:1527268139900};\\\", \\\"{x:1316,y:827,t:1527268139917};\\\", \\\"{x:1317,y:827,t:1527268139934};\\\", \\\"{x:1318,y:826,t:1527268139950};\\\", \\\"{x:1321,y:825,t:1527268139967};\\\", \\\"{x:1322,y:825,t:1527268139984};\\\", \\\"{x:1323,y:825,t:1527268140001};\\\", \\\"{x:1324,y:824,t:1527268140018};\\\", \\\"{x:1325,y:824,t:1527268140034};\\\", \\\"{x:1326,y:824,t:1527268140059};\\\", \\\"{x:1328,y:824,t:1527268140098};\\\", \\\"{x:1328,y:823,t:1527268140106};\\\", \\\"{x:1329,y:823,t:1527268140260};\\\", \\\"{x:1331,y:823,t:1527268140275};\\\", \\\"{x:1332,y:823,t:1527268140285};\\\", \\\"{x:1335,y:823,t:1527268140301};\\\", \\\"{x:1338,y:822,t:1527268140317};\\\", \\\"{x:1339,y:822,t:1527268140403};\\\", \\\"{x:1342,y:822,t:1527268140418};\\\", \\\"{x:1345,y:822,t:1527268140435};\\\", \\\"{x:1348,y:822,t:1527268140451};\\\", \\\"{x:1351,y:823,t:1527268140469};\\\", \\\"{x:1352,y:824,t:1527268140491};\\\", \\\"{x:1353,y:826,t:1527268140501};\\\", \\\"{x:1354,y:827,t:1527268140517};\\\", \\\"{x:1355,y:828,t:1527268140538};\\\", \\\"{x:1355,y:829,t:1527268140578};\\\", \\\"{x:1356,y:831,t:1527268140667};\\\", \\\"{x:1356,y:832,t:1527268140683};\\\", \\\"{x:1357,y:834,t:1527268140698};\\\", \\\"{x:1358,y:835,t:1527268140714};\\\", \\\"{x:1358,y:836,t:1527268141434};\\\", \\\"{x:1358,y:837,t:1527268141450};\\\", \\\"{x:1357,y:837,t:1527268141458};\\\", \\\"{x:1356,y:837,t:1527268141469};\\\", \\\"{x:1355,y:839,t:1527268141484};\\\", \\\"{x:1353,y:839,t:1527268141546};\\\", \\\"{x:1352,y:840,t:1527268141577};\\\", \\\"{x:1351,y:840,t:1527268141610};\\\", \\\"{x:1350,y:842,t:1527268141642};\\\", \\\"{x:1349,y:842,t:1527268141666};\\\", \\\"{x:1348,y:842,t:1527268141682};\\\", \\\"{x:1348,y:844,t:1527268141962};\\\", \\\"{x:1348,y:845,t:1527268141970};\\\", \\\"{x:1348,y:847,t:1527268141986};\\\", \\\"{x:1348,y:849,t:1527268142002};\\\", \\\"{x:1348,y:851,t:1527268142019};\\\", \\\"{x:1349,y:853,t:1527268142036};\\\", \\\"{x:1349,y:854,t:1527268142052};\\\", \\\"{x:1349,y:855,t:1527268142069};\\\", \\\"{x:1349,y:857,t:1527268142086};\\\", \\\"{x:1349,y:858,t:1527268142102};\\\", \\\"{x:1349,y:860,t:1527268142119};\\\", \\\"{x:1350,y:862,t:1527268142136};\\\", \\\"{x:1352,y:863,t:1527268142163};\\\", \\\"{x:1352,y:864,t:1527268142171};\\\", \\\"{x:1352,y:865,t:1527268142186};\\\", \\\"{x:1352,y:867,t:1527268142202};\\\", \\\"{x:1352,y:870,t:1527268142219};\\\", \\\"{x:1352,y:872,t:1527268142236};\\\", \\\"{x:1353,y:873,t:1527268142252};\\\", \\\"{x:1354,y:875,t:1527268142363};\\\", \\\"{x:1355,y:875,t:1527268142387};\\\", \\\"{x:1355,y:876,t:1527268142404};\\\", \\\"{x:1356,y:877,t:1527268142419};\\\", \\\"{x:1356,y:879,t:1527268142436};\\\", \\\"{x:1356,y:880,t:1527268142507};\\\", \\\"{x:1357,y:880,t:1527268142520};\\\", \\\"{x:1357,y:883,t:1527268142537};\\\", \\\"{x:1358,y:884,t:1527268142553};\\\", \\\"{x:1358,y:885,t:1527268142579};\\\", \\\"{x:1358,y:886,t:1527268142587};\\\", \\\"{x:1359,y:887,t:1527268142603};\\\", \\\"{x:1359,y:886,t:1527268142971};\\\", \\\"{x:1360,y:884,t:1527268142986};\\\", \\\"{x:1360,y:883,t:1527268143043};\\\", \\\"{x:1360,y:882,t:1527268143053};\\\", \\\"{x:1361,y:881,t:1527268143071};\\\", \\\"{x:1361,y:880,t:1527268143147};\\\", \\\"{x:1361,y:879,t:1527268143171};\\\", \\\"{x:1361,y:878,t:1527268143187};\\\", \\\"{x:1361,y:877,t:1527268143204};\\\", \\\"{x:1361,y:874,t:1527268143221};\\\", \\\"{x:1361,y:871,t:1527268143238};\\\", \\\"{x:1361,y:867,t:1527268143253};\\\", \\\"{x:1361,y:863,t:1527268143271};\\\", \\\"{x:1361,y:859,t:1527268143287};\\\", \\\"{x:1361,y:857,t:1527268143304};\\\", \\\"{x:1361,y:854,t:1527268143320};\\\", \\\"{x:1360,y:850,t:1527268143338};\\\", \\\"{x:1359,y:840,t:1527268143353};\\\", \\\"{x:1355,y:822,t:1527268143371};\\\", \\\"{x:1351,y:807,t:1527268143388};\\\", \\\"{x:1347,y:795,t:1527268143404};\\\", \\\"{x:1345,y:784,t:1527268143421};\\\", \\\"{x:1344,y:766,t:1527268143438};\\\", \\\"{x:1344,y:743,t:1527268143454};\\\", \\\"{x:1340,y:706,t:1527268143471};\\\", \\\"{x:1335,y:664,t:1527268143487};\\\", \\\"{x:1326,y:619,t:1527268143504};\\\", \\\"{x:1319,y:588,t:1527268143520};\\\", \\\"{x:1311,y:559,t:1527268143536};\\\", \\\"{x:1302,y:527,t:1527268143554};\\\", \\\"{x:1301,y:510,t:1527268143570};\\\", \\\"{x:1301,y:494,t:1527268143586};\\\", \\\"{x:1301,y:480,t:1527268143604};\\\", \\\"{x:1301,y:473,t:1527268143620};\\\", \\\"{x:1300,y:469,t:1527268143637};\\\", \\\"{x:1300,y:467,t:1527268143654};\\\", \\\"{x:1298,y:466,t:1527268143670};\\\", \\\"{x:1290,y:466,t:1527268143687};\\\", \\\"{x:1270,y:466,t:1527268143704};\\\", \\\"{x:1235,y:468,t:1527268143720};\\\", \\\"{x:1181,y:477,t:1527268143737};\\\", \\\"{x:1069,y:491,t:1527268143754};\\\", \\\"{x:972,y:503,t:1527268143770};\\\", \\\"{x:877,y:503,t:1527268143787};\\\", \\\"{x:789,y:503,t:1527268143804};\\\", \\\"{x:724,y:503,t:1527268143821};\\\", \\\"{x:688,y:506,t:1527268143838};\\\", \\\"{x:677,y:509,t:1527268143854};\\\", \\\"{x:676,y:511,t:1527268143871};\\\", \\\"{x:674,y:514,t:1527268143880};\\\", \\\"{x:674,y:522,t:1527268143897};\\\", \\\"{x:678,y:532,t:1527268143913};\\\", \\\"{x:680,y:548,t:1527268143930};\\\", \\\"{x:683,y:558,t:1527268143947};\\\", \\\"{x:683,y:563,t:1527268143969};\\\", \\\"{x:685,y:567,t:1527268143985};\\\", \\\"{x:686,y:568,t:1527268144042};\\\", \\\"{x:682,y:570,t:1527268144053};\\\", \\\"{x:673,y:573,t:1527268144070};\\\", \\\"{x:665,y:577,t:1527268144086};\\\", \\\"{x:660,y:579,t:1527268144103};\\\", \\\"{x:662,y:581,t:1527268144283};\\\", \\\"{x:668,y:585,t:1527268144292};\\\", \\\"{x:674,y:588,t:1527268144303};\\\", \\\"{x:686,y:594,t:1527268144320};\\\", \\\"{x:702,y:603,t:1527268144336};\\\", \\\"{x:720,y:613,t:1527268144353};\\\", \\\"{x:754,y:628,t:1527268144369};\\\", \\\"{x:780,y:636,t:1527268144386};\\\", \\\"{x:805,y:644,t:1527268144402};\\\", \\\"{x:826,y:651,t:1527268144420};\\\", \\\"{x:845,y:659,t:1527268144437};\\\", \\\"{x:858,y:666,t:1527268144452};\\\", \\\"{x:863,y:668,t:1527268144470};\\\", \\\"{x:865,y:669,t:1527268144486};\\\", \\\"{x:866,y:669,t:1527268144503};\\\", \\\"{x:866,y:670,t:1527268145315};\\\", \\\"{x:865,y:670,t:1527268145330};\\\", \\\"{x:863,y:670,t:1527268145354};\\\", \\\"{x:862,y:670,t:1527268145378};\\\", \\\"{x:862,y:669,t:1527268145963};\\\", \\\"{x:862,y:667,t:1527268145979};\\\", \\\"{x:864,y:666,t:1527268145988};\\\", \\\"{x:869,y:665,t:1527268146004};\\\", \\\"{x:876,y:662,t:1527268146022};\\\", \\\"{x:891,y:658,t:1527268146038};\\\", \\\"{x:921,y:658,t:1527268146055};\\\", \\\"{x:983,y:661,t:1527268146072};\\\", \\\"{x:1065,y:668,t:1527268146088};\\\", \\\"{x:1157,y:681,t:1527268146105};\\\", \\\"{x:1252,y:697,t:1527268146122};\\\", \\\"{x:1383,y:735,t:1527268146139};\\\", \\\"{x:1457,y:755,t:1527268146154};\\\", \\\"{x:1513,y:774,t:1527268146171};\\\", \\\"{x:1550,y:784,t:1527268146189};\\\", \\\"{x:1567,y:788,t:1527268146206};\\\", \\\"{x:1569,y:789,t:1527268146222};\\\", \\\"{x:1570,y:789,t:1527268146239};\\\", \\\"{x:1571,y:789,t:1527268146255};\\\", \\\"{x:1573,y:788,t:1527268146272};\\\", \\\"{x:1576,y:781,t:1527268146288};\\\", \\\"{x:1576,y:778,t:1527268146306};\\\", \\\"{x:1576,y:774,t:1527268146322};\\\", \\\"{x:1576,y:767,t:1527268146338};\\\", \\\"{x:1572,y:762,t:1527268146355};\\\", \\\"{x:1565,y:758,t:1527268146372};\\\", \\\"{x:1560,y:756,t:1527268146389};\\\", \\\"{x:1557,y:753,t:1527268146406};\\\", \\\"{x:1555,y:751,t:1527268146422};\\\", \\\"{x:1552,y:751,t:1527268146439};\\\", \\\"{x:1546,y:751,t:1527268146456};\\\", \\\"{x:1531,y:751,t:1527268146472};\\\", \\\"{x:1511,y:751,t:1527268146489};\\\", \\\"{x:1494,y:751,t:1527268146506};\\\", \\\"{x:1477,y:754,t:1527268146522};\\\", \\\"{x:1465,y:759,t:1527268146538};\\\", \\\"{x:1461,y:761,t:1527268146555};\\\", \\\"{x:1457,y:764,t:1527268146571};\\\", \\\"{x:1451,y:767,t:1527268146588};\\\", \\\"{x:1445,y:770,t:1527268146605};\\\", \\\"{x:1434,y:775,t:1527268146622};\\\", \\\"{x:1425,y:779,t:1527268146638};\\\", \\\"{x:1419,y:782,t:1527268146655};\\\", \\\"{x:1413,y:785,t:1527268146672};\\\", \\\"{x:1411,y:787,t:1527268146688};\\\", \\\"{x:1405,y:792,t:1527268146705};\\\", \\\"{x:1393,y:801,t:1527268146721};\\\", \\\"{x:1384,y:808,t:1527268146738};\\\", \\\"{x:1378,y:813,t:1527268146756};\\\", \\\"{x:1365,y:817,t:1527268146772};\\\", \\\"{x:1344,y:822,t:1527268146788};\\\", \\\"{x:1317,y:825,t:1527268146806};\\\", \\\"{x:1278,y:830,t:1527268146823};\\\", \\\"{x:1255,y:832,t:1527268146839};\\\", \\\"{x:1240,y:832,t:1527268146855};\\\", \\\"{x:1230,y:832,t:1527268146872};\\\", \\\"{x:1226,y:832,t:1527268146889};\\\", \\\"{x:1226,y:831,t:1527268146905};\\\", \\\"{x:1225,y:831,t:1527268146923};\\\", \\\"{x:1223,y:831,t:1527268147195};\\\", \\\"{x:1221,y:832,t:1527268147205};\\\", \\\"{x:1216,y:835,t:1527268147223};\\\", \\\"{x:1213,y:836,t:1527268147241};\\\", \\\"{x:1214,y:836,t:1527268147627};\\\", \\\"{x:1215,y:835,t:1527268147640};\\\", \\\"{x:1216,y:835,t:1527268147657};\\\", \\\"{x:1217,y:835,t:1527268147674};\\\", \\\"{x:1218,y:835,t:1527268147691};\\\", \\\"{x:1220,y:835,t:1527268147707};\\\", \\\"{x:1223,y:835,t:1527268147723};\\\", \\\"{x:1229,y:835,t:1527268147740};\\\", \\\"{x:1234,y:836,t:1527268147756};\\\", \\\"{x:1238,y:838,t:1527268147773};\\\", \\\"{x:1246,y:840,t:1527268147790};\\\", \\\"{x:1253,y:842,t:1527268147807};\\\", \\\"{x:1258,y:845,t:1527268147823};\\\", \\\"{x:1265,y:846,t:1527268147840};\\\", \\\"{x:1270,y:849,t:1527268147856};\\\", \\\"{x:1272,y:851,t:1527268147873};\\\", \\\"{x:1278,y:856,t:1527268147890};\\\", \\\"{x:1282,y:861,t:1527268147907};\\\", \\\"{x:1287,y:865,t:1527268147923};\\\", \\\"{x:1293,y:870,t:1527268147939};\\\", \\\"{x:1298,y:874,t:1527268147956};\\\", \\\"{x:1306,y:880,t:1527268147974};\\\", \\\"{x:1314,y:887,t:1527268147990};\\\", \\\"{x:1323,y:893,t:1527268148007};\\\", \\\"{x:1334,y:900,t:1527268148024};\\\", \\\"{x:1345,y:908,t:1527268148039};\\\", \\\"{x:1354,y:914,t:1527268148056};\\\", \\\"{x:1359,y:917,t:1527268148074};\\\", \\\"{x:1365,y:920,t:1527268148090};\\\", \\\"{x:1366,y:921,t:1527268148115};\\\", \\\"{x:1367,y:921,t:1527268148163};\\\", \\\"{x:1368,y:921,t:1527268148174};\\\", \\\"{x:1369,y:921,t:1527268148189};\\\", \\\"{x:1370,y:921,t:1527268148207};\\\", \\\"{x:1370,y:922,t:1527268148379};\\\", \\\"{x:1370,y:923,t:1527268148390};\\\", \\\"{x:1370,y:926,t:1527268148407};\\\", \\\"{x:1368,y:929,t:1527268148424};\\\", \\\"{x:1368,y:931,t:1527268148441};\\\", \\\"{x:1365,y:935,t:1527268148457};\\\", \\\"{x:1365,y:937,t:1527268148474};\\\", \\\"{x:1364,y:940,t:1527268148491};\\\", \\\"{x:1361,y:942,t:1527268148507};\\\", \\\"{x:1357,y:946,t:1527268148523};\\\", \\\"{x:1348,y:956,t:1527268148541};\\\", \\\"{x:1346,y:959,t:1527268148557};\\\", \\\"{x:1344,y:960,t:1527268148574};\\\", \\\"{x:1343,y:961,t:1527268148590};\\\", \\\"{x:1344,y:961,t:1527268148859};\\\", \\\"{x:1345,y:961,t:1527268149482};\\\", \\\"{x:1346,y:961,t:1527268149491};\\\", \\\"{x:1346,y:960,t:1527268149619};\\\", \\\"{x:1346,y:959,t:1527268149675};\\\", \\\"{x:1346,y:957,t:1527268149691};\\\", \\\"{x:1346,y:953,t:1527268149708};\\\", \\\"{x:1346,y:951,t:1527268149725};\\\", \\\"{x:1346,y:946,t:1527268149741};\\\", \\\"{x:1346,y:940,t:1527268149757};\\\", \\\"{x:1348,y:935,t:1527268149775};\\\", \\\"{x:1349,y:930,t:1527268149792};\\\", \\\"{x:1350,y:927,t:1527268149807};\\\", \\\"{x:1350,y:926,t:1527268149824};\\\", \\\"{x:1350,y:924,t:1527268149842};\\\", \\\"{x:1350,y:923,t:1527268149858};\\\", \\\"{x:1350,y:921,t:1527268149874};\\\", \\\"{x:1350,y:920,t:1527268149891};\\\", \\\"{x:1350,y:918,t:1527268149907};\\\", \\\"{x:1350,y:916,t:1527268149925};\\\", \\\"{x:1350,y:913,t:1527268149941};\\\", \\\"{x:1350,y:912,t:1527268149958};\\\", \\\"{x:1350,y:911,t:1527268149975};\\\", \\\"{x:1350,y:910,t:1527268149992};\\\", \\\"{x:1350,y:907,t:1527268150008};\\\", \\\"{x:1350,y:906,t:1527268150025};\\\", \\\"{x:1350,y:904,t:1527268150042};\\\", \\\"{x:1349,y:903,t:1527268150058};\\\", \\\"{x:1349,y:902,t:1527268150076};\\\", \\\"{x:1349,y:901,t:1527268150131};\\\", \\\"{x:1348,y:900,t:1527268155723};\\\", \\\"{x:1342,y:900,t:1527268155731};\\\", \\\"{x:1312,y:893,t:1527268155746};\\\", \\\"{x:1142,y:854,t:1527268155763};\\\", \\\"{x:995,y:805,t:1527268155778};\\\", \\\"{x:833,y:747,t:1527268155796};\\\", \\\"{x:666,y:684,t:1527268155812};\\\", \\\"{x:520,y:624,t:1527268155831};\\\", \\\"{x:396,y:571,t:1527268155846};\\\", \\\"{x:304,y:525,t:1527268155863};\\\", \\\"{x:253,y:499,t:1527268155875};\\\", \\\"{x:218,y:479,t:1527268155893};\\\", \\\"{x:201,y:469,t:1527268155912};\\\", \\\"{x:196,y:467,t:1527268155929};\\\", \\\"{x:195,y:466,t:1527268155953};\\\", \\\"{x:195,y:465,t:1527268155986};\\\", \\\"{x:196,y:464,t:1527268156001};\\\", \\\"{x:198,y:462,t:1527268156012};\\\", \\\"{x:201,y:462,t:1527268156029};\\\", \\\"{x:207,y:461,t:1527268156045};\\\", \\\"{x:213,y:458,t:1527268156062};\\\", \\\"{x:224,y:455,t:1527268156079};\\\", \\\"{x:237,y:451,t:1527268156096};\\\", \\\"{x:247,y:448,t:1527268156112};\\\", \\\"{x:255,y:448,t:1527268156129};\\\", \\\"{x:256,y:448,t:1527268156146};\\\", \\\"{x:257,y:451,t:1527268156194};\\\", \\\"{x:258,y:455,t:1527268156202};\\\", \\\"{x:261,y:460,t:1527268156213};\\\", \\\"{x:267,y:472,t:1527268156230};\\\", \\\"{x:276,y:486,t:1527268156247};\\\", \\\"{x:282,y:500,t:1527268156263};\\\", \\\"{x:287,y:512,t:1527268156280};\\\", \\\"{x:292,y:522,t:1527268156296};\\\", \\\"{x:294,y:530,t:1527268156313};\\\", \\\"{x:300,y:543,t:1527268156330};\\\", \\\"{x:306,y:553,t:1527268156347};\\\", \\\"{x:311,y:559,t:1527268156362};\\\", \\\"{x:318,y:563,t:1527268156379};\\\", \\\"{x:332,y:568,t:1527268156397};\\\", \\\"{x:360,y:573,t:1527268156412};\\\", \\\"{x:393,y:578,t:1527268156430};\\\", \\\"{x:456,y:590,t:1527268156447};\\\", \\\"{x:536,y:601,t:1527268156463};\\\", \\\"{x:616,y:619,t:1527268156480};\\\", \\\"{x:676,y:633,t:1527268156497};\\\", \\\"{x:729,y:647,t:1527268156513};\\\", \\\"{x:775,y:655,t:1527268156529};\\\", \\\"{x:791,y:655,t:1527268156546};\\\", \\\"{x:794,y:655,t:1527268156563};\\\", \\\"{x:795,y:655,t:1527268156579};\\\", \\\"{x:797,y:655,t:1527268156602};\\\", \\\"{x:798,y:654,t:1527268156619};\\\", \\\"{x:801,y:653,t:1527268156630};\\\", \\\"{x:806,y:650,t:1527268156647};\\\", \\\"{x:814,y:646,t:1527268156663};\\\", \\\"{x:815,y:646,t:1527268156679};\\\", \\\"{x:811,y:646,t:1527268156723};\\\", \\\"{x:805,y:646,t:1527268156730};\\\", \\\"{x:787,y:649,t:1527268156746};\\\", \\\"{x:766,y:656,t:1527268156763};\\\", \\\"{x:741,y:664,t:1527268156779};\\\", \\\"{x:727,y:665,t:1527268156795};\\\", \\\"{x:713,y:667,t:1527268156813};\\\", \\\"{x:699,y:667,t:1527268156829};\\\", \\\"{x:689,y:667,t:1527268156846};\\\", \\\"{x:674,y:664,t:1527268156862};\\\", \\\"{x:659,y:659,t:1527268156879};\\\", \\\"{x:649,y:659,t:1527268156896};\\\", \\\"{x:642,y:658,t:1527268156913};\\\", \\\"{x:633,y:655,t:1527268156929};\\\", \\\"{x:608,y:653,t:1527268156946};\\\", \\\"{x:578,y:647,t:1527268156963};\\\", \\\"{x:544,y:643,t:1527268156978};\\\", \\\"{x:490,y:635,t:1527268156996};\\\", \\\"{x:435,y:627,t:1527268157012};\\\", \\\"{x:376,y:617,t:1527268157031};\\\", \\\"{x:296,y:610,t:1527268157047};\\\", \\\"{x:208,y:604,t:1527268157064};\\\", \\\"{x:119,y:600,t:1527268157080};\\\", \\\"{x:47,y:592,t:1527268157097};\\\", \\\"{x:18,y:587,t:1527268157113};\\\", \\\"{x:18,y:586,t:1527268157146};\\\", \\\"{x:22,y:584,t:1527268157153};\\\", \\\"{x:25,y:583,t:1527268157170};\\\", \\\"{x:26,y:583,t:1527268157180};\\\", \\\"{x:29,y:582,t:1527268157291};\\\", \\\"{x:32,y:581,t:1527268157298};\\\", \\\"{x:40,y:581,t:1527268157314};\\\", \\\"{x:50,y:581,t:1527268157330};\\\", \\\"{x:60,y:581,t:1527268157348};\\\", \\\"{x:79,y:581,t:1527268157365};\\\", \\\"{x:100,y:581,t:1527268157381};\\\", \\\"{x:122,y:583,t:1527268157399};\\\", \\\"{x:139,y:583,t:1527268157414};\\\", \\\"{x:150,y:583,t:1527268157430};\\\", \\\"{x:157,y:582,t:1527268157448};\\\", \\\"{x:158,y:582,t:1527268157465};\\\", \\\"{x:159,y:581,t:1527268157651};\\\", \\\"{x:159,y:578,t:1527268157663};\\\", \\\"{x:160,y:576,t:1527268157680};\\\", \\\"{x:160,y:575,t:1527268157697};\\\", \\\"{x:160,y:573,t:1527268157714};\\\", \\\"{x:160,y:572,t:1527268157745};\\\", \\\"{x:160,y:571,t:1527268157754};\\\", \\\"{x:160,y:569,t:1527268157764};\\\", \\\"{x:160,y:568,t:1527268157780};\\\", \\\"{x:160,y:566,t:1527268157797};\\\", \\\"{x:160,y:563,t:1527268157813};\\\", \\\"{x:160,y:561,t:1527268157831};\\\", \\\"{x:168,y:567,t:1527268158073};\\\", \\\"{x:179,y:579,t:1527268158082};\\\", \\\"{x:222,y:609,t:1527268158097};\\\", \\\"{x:262,y:631,t:1527268158115};\\\", \\\"{x:307,y:653,t:1527268158130};\\\", \\\"{x:366,y:682,t:1527268158147};\\\", \\\"{x:414,y:708,t:1527268158164};\\\", \\\"{x:459,y:738,t:1527268158181};\\\", \\\"{x:489,y:754,t:1527268158197};\\\", \\\"{x:502,y:762,t:1527268158214};\\\", \\\"{x:509,y:767,t:1527268158230};\\\", \\\"{x:510,y:767,t:1527268158289};\\\", \\\"{x:511,y:767,t:1527268158313};\\\", \\\"{x:513,y:767,t:1527268158329};\\\", \\\"{x:516,y:766,t:1527268158337};\\\", \\\"{x:516,y:765,t:1527268158347};\\\", \\\"{x:521,y:764,t:1527268158364};\\\", \\\"{x:527,y:762,t:1527268158381};\\\", \\\"{x:529,y:761,t:1527268158398};\\\", \\\"{x:530,y:760,t:1527268158489};\\\", \\\"{x:530,y:757,t:1527268158497};\\\", \\\"{x:530,y:744,t:1527268158514};\\\", \\\"{x:530,y:740,t:1527268158531};\\\", \\\"{x:527,y:731,t:1527268158548};\\\", \\\"{x:518,y:720,t:1527268158564};\\\", \\\"{x:514,y:714,t:1527268158581};\\\", \\\"{x:513,y:710,t:1527268158598};\\\", \\\"{x:512,y:710,t:1527268158614};\\\", \\\"{x:512,y:709,t:1527268159081};\\\", \\\"{x:519,y:705,t:1527268159098};\\\", \\\"{x:536,y:700,t:1527268159115};\\\", \\\"{x:553,y:694,t:1527268159131};\\\", \\\"{x:570,y:688,t:1527268159148};\\\", \\\"{x:593,y:682,t:1527268159165};\\\", \\\"{x:611,y:677,t:1527268159181};\\\", \\\"{x:621,y:674,t:1527268159198};\\\", \\\"{x:627,y:672,t:1527268159215};\\\", \\\"{x:628,y:672,t:1527268159232};\\\" ] }, { \\\"rt\\\": 81446, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 281712, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"967LR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-03 PM-C -F -F -F -O -O -O -O -I -I -I -I -J -U -F -U -U -U -U -H -U -08 PM-U -F -O \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:629,y:671,t:1527268161106};\\\", \\\"{x:630,y:670,t:1527268161116};\\\", \\\"{x:633,y:669,t:1527268161133};\\\", \\\"{x:642,y:665,t:1527268161150};\\\", \\\"{x:668,y:663,t:1527268161167};\\\", \\\"{x:701,y:660,t:1527268161183};\\\", \\\"{x:733,y:660,t:1527268161200};\\\", \\\"{x:765,y:660,t:1527268161217};\\\", \\\"{x:813,y:660,t:1527268161233};\\\", \\\"{x:847,y:660,t:1527268161249};\\\", \\\"{x:888,y:656,t:1527268161266};\\\", \\\"{x:944,y:650,t:1527268161284};\\\", \\\"{x:979,y:643,t:1527268161300};\\\", \\\"{x:1005,y:638,t:1527268161317};\\\", \\\"{x:1030,y:633,t:1527268161334};\\\", \\\"{x:1054,y:626,t:1527268161351};\\\", \\\"{x:1077,y:620,t:1527268161366};\\\", \\\"{x:1094,y:616,t:1527268161383};\\\", \\\"{x:1109,y:611,t:1527268161401};\\\", \\\"{x:1116,y:607,t:1527268161417};\\\", \\\"{x:1123,y:606,t:1527268161433};\\\", \\\"{x:1126,y:606,t:1527268161450};\\\", \\\"{x:1126,y:605,t:1527268161466};\\\", \\\"{x:1134,y:605,t:1527268161484};\\\", \\\"{x:1149,y:605,t:1527268161501};\\\", \\\"{x:1169,y:605,t:1527268161517};\\\", \\\"{x:1197,y:605,t:1527268161534};\\\", \\\"{x:1240,y:606,t:1527268161551};\\\", \\\"{x:1308,y:618,t:1527268161566};\\\", \\\"{x:1407,y:630,t:1527268161584};\\\", \\\"{x:1529,y:648,t:1527268161601};\\\", \\\"{x:1670,y:665,t:1527268161616};\\\", \\\"{x:1882,y:676,t:1527268161634};\\\", \\\"{x:1919,y:691,t:1527268161651};\\\", \\\"{x:1919,y:706,t:1527268161666};\\\", \\\"{x:1919,y:714,t:1527268161683};\\\", \\\"{x:1919,y:735,t:1527268161700};\\\", \\\"{x:1919,y:756,t:1527268161717};\\\", \\\"{x:1919,y:789,t:1527268161734};\\\", \\\"{x:1919,y:819,t:1527268161751};\\\", \\\"{x:1919,y:842,t:1527268161768};\\\", \\\"{x:1919,y:861,t:1527268161783};\\\", \\\"{x:1919,y:886,t:1527268161800};\\\", \\\"{x:1903,y:934,t:1527268161817};\\\", \\\"{x:1867,y:987,t:1527268161833};\\\", \\\"{x:1823,y:1036,t:1527268161850};\\\", \\\"{x:1768,y:1083,t:1527268161867};\\\", \\\"{x:1698,y:1114,t:1527268161883};\\\", \\\"{x:1640,y:1139,t:1527268161900};\\\", \\\"{x:1585,y:1152,t:1527268161918};\\\", \\\"{x:1538,y:1152,t:1527268161933};\\\", \\\"{x:1520,y:1154,t:1527268161950};\\\", \\\"{x:1510,y:1155,t:1527268161967};\\\", \\\"{x:1508,y:1155,t:1527268161983};\\\", \\\"{x:1507,y:1155,t:1527268162009};\\\", \\\"{x:1507,y:1154,t:1527268162034};\\\", \\\"{x:1507,y:1151,t:1527268162051};\\\", \\\"{x:1508,y:1146,t:1527268162067};\\\", \\\"{x:1509,y:1140,t:1527268162084};\\\", \\\"{x:1510,y:1134,t:1527268162100};\\\", \\\"{x:1510,y:1128,t:1527268162118};\\\", \\\"{x:1511,y:1122,t:1527268162134};\\\", \\\"{x:1511,y:1119,t:1527268162151};\\\", \\\"{x:1512,y:1115,t:1527268162167};\\\", \\\"{x:1512,y:1114,t:1527268162184};\\\", \\\"{x:1514,y:1110,t:1527268162201};\\\", \\\"{x:1515,y:1105,t:1527268162217};\\\", \\\"{x:1515,y:1101,t:1527268162234};\\\", \\\"{x:1516,y:1095,t:1527268162251};\\\", \\\"{x:1518,y:1089,t:1527268162268};\\\", \\\"{x:1519,y:1081,t:1527268162284};\\\", \\\"{x:1524,y:1072,t:1527268162300};\\\", \\\"{x:1529,y:1061,t:1527268162318};\\\", \\\"{x:1534,y:1049,t:1527268162335};\\\", \\\"{x:1537,y:1041,t:1527268162351};\\\", \\\"{x:1541,y:1031,t:1527268162368};\\\", \\\"{x:1543,y:1024,t:1527268162385};\\\", \\\"{x:1546,y:1021,t:1527268162400};\\\", \\\"{x:1548,y:1015,t:1527268162417};\\\", \\\"{x:1548,y:1013,t:1527268162435};\\\", \\\"{x:1549,y:1011,t:1527268162457};\\\", \\\"{x:1549,y:1010,t:1527268162468};\\\", \\\"{x:1550,y:1006,t:1527268162484};\\\", \\\"{x:1552,y:1000,t:1527268162500};\\\", \\\"{x:1555,y:995,t:1527268162517};\\\", \\\"{x:1559,y:990,t:1527268162535};\\\", \\\"{x:1560,y:987,t:1527268162550};\\\", \\\"{x:1562,y:985,t:1527268162567};\\\", \\\"{x:1563,y:984,t:1527268162585};\\\", \\\"{x:1564,y:983,t:1527268162601};\\\", \\\"{x:1566,y:981,t:1527268162618};\\\", \\\"{x:1567,y:980,t:1527268162635};\\\", \\\"{x:1568,y:980,t:1527268162658};\\\", \\\"{x:1568,y:979,t:1527268162668};\\\", \\\"{x:1569,y:979,t:1527268162705};\\\", \\\"{x:1572,y:978,t:1527268162717};\\\", \\\"{x:1578,y:975,t:1527268162735};\\\", \\\"{x:1582,y:972,t:1527268162752};\\\", \\\"{x:1586,y:971,t:1527268162767};\\\", \\\"{x:1587,y:970,t:1527268162785};\\\", \\\"{x:1588,y:970,t:1527268162817};\\\", \\\"{x:1589,y:969,t:1527268162841};\\\", \\\"{x:1590,y:969,t:1527268162852};\\\", \\\"{x:1593,y:968,t:1527268162868};\\\", \\\"{x:1594,y:966,t:1527268162885};\\\", \\\"{x:1595,y:966,t:1527268162902};\\\", \\\"{x:1594,y:965,t:1527268163089};\\\", \\\"{x:1590,y:965,t:1527268163102};\\\", \\\"{x:1578,y:964,t:1527268163119};\\\", \\\"{x:1567,y:960,t:1527268163134};\\\", \\\"{x:1560,y:956,t:1527268163151};\\\", \\\"{x:1556,y:951,t:1527268163169};\\\", \\\"{x:1555,y:949,t:1527268163185};\\\", \\\"{x:1553,y:940,t:1527268163201};\\\", \\\"{x:1551,y:932,t:1527268163219};\\\", \\\"{x:1548,y:927,t:1527268163235};\\\", \\\"{x:1547,y:924,t:1527268163252};\\\", \\\"{x:1547,y:923,t:1527268163268};\\\", \\\"{x:1547,y:922,t:1527268163284};\\\", \\\"{x:1547,y:921,t:1527268163302};\\\", \\\"{x:1547,y:919,t:1527268163318};\\\", \\\"{x:1547,y:917,t:1527268163335};\\\", \\\"{x:1547,y:915,t:1527268163352};\\\", \\\"{x:1547,y:911,t:1527268163369};\\\", \\\"{x:1547,y:905,t:1527268163385};\\\", \\\"{x:1547,y:894,t:1527268163401};\\\", \\\"{x:1544,y:884,t:1527268163419};\\\", \\\"{x:1542,y:871,t:1527268163435};\\\", \\\"{x:1533,y:852,t:1527268163451};\\\", \\\"{x:1528,y:842,t:1527268163468};\\\", \\\"{x:1522,y:831,t:1527268163485};\\\", \\\"{x:1517,y:823,t:1527268163502};\\\", \\\"{x:1512,y:814,t:1527268163519};\\\", \\\"{x:1508,y:807,t:1527268163535};\\\", \\\"{x:1503,y:793,t:1527268163551};\\\", \\\"{x:1494,y:782,t:1527268163568};\\\", \\\"{x:1473,y:772,t:1527268163585};\\\", \\\"{x:1457,y:762,t:1527268163602};\\\", \\\"{x:1447,y:758,t:1527268163619};\\\", \\\"{x:1439,y:753,t:1527268163635};\\\", \\\"{x:1428,y:744,t:1527268163651};\\\", \\\"{x:1418,y:736,t:1527268163669};\\\", \\\"{x:1414,y:732,t:1527268163686};\\\", \\\"{x:1414,y:731,t:1527268163702};\\\", \\\"{x:1413,y:730,t:1527268163718};\\\", \\\"{x:1412,y:730,t:1527268163769};\\\", \\\"{x:1409,y:730,t:1527268163786};\\\", \\\"{x:1403,y:730,t:1527268163803};\\\", \\\"{x:1394,y:730,t:1527268163819};\\\", \\\"{x:1381,y:727,t:1527268163836};\\\", \\\"{x:1357,y:724,t:1527268163852};\\\", \\\"{x:1319,y:718,t:1527268163869};\\\", \\\"{x:1257,y:710,t:1527268163886};\\\", \\\"{x:1175,y:700,t:1527268163902};\\\", \\\"{x:1094,y:687,t:1527268163919};\\\", \\\"{x:1030,y:679,t:1527268163936};\\\", \\\"{x:971,y:671,t:1527268163952};\\\", \\\"{x:938,y:667,t:1527268163968};\\\", \\\"{x:906,y:662,t:1527268163985};\\\", \\\"{x:891,y:657,t:1527268164003};\\\", \\\"{x:877,y:653,t:1527268164018};\\\", \\\"{x:867,y:650,t:1527268164035};\\\", \\\"{x:864,y:649,t:1527268164052};\\\", \\\"{x:863,y:648,t:1527268164089};\\\", \\\"{x:863,y:647,t:1527268164103};\\\", \\\"{x:867,y:645,t:1527268164119};\\\", \\\"{x:876,y:640,t:1527268164136};\\\", \\\"{x:885,y:636,t:1527268164152};\\\", \\\"{x:891,y:635,t:1527268164168};\\\", \\\"{x:899,y:631,t:1527268164185};\\\", \\\"{x:904,y:629,t:1527268164202};\\\", \\\"{x:910,y:628,t:1527268164219};\\\", \\\"{x:916,y:625,t:1527268164236};\\\", \\\"{x:922,y:624,t:1527268164252};\\\", \\\"{x:930,y:621,t:1527268164270};\\\", \\\"{x:939,y:618,t:1527268164285};\\\", \\\"{x:953,y:616,t:1527268164302};\\\", \\\"{x:964,y:614,t:1527268164319};\\\", \\\"{x:974,y:613,t:1527268164335};\\\", \\\"{x:991,y:613,t:1527268164352};\\\", \\\"{x:1019,y:613,t:1527268164369};\\\", \\\"{x:1040,y:613,t:1527268164385};\\\", \\\"{x:1061,y:613,t:1527268164402};\\\", \\\"{x:1073,y:613,t:1527268164419};\\\", \\\"{x:1088,y:613,t:1527268164435};\\\", \\\"{x:1106,y:613,t:1527268164453};\\\", \\\"{x:1121,y:613,t:1527268164470};\\\", \\\"{x:1132,y:613,t:1527268164486};\\\", \\\"{x:1143,y:613,t:1527268164503};\\\", \\\"{x:1153,y:613,t:1527268164520};\\\", \\\"{x:1163,y:613,t:1527268164536};\\\", \\\"{x:1173,y:613,t:1527268164552};\\\", \\\"{x:1197,y:613,t:1527268164569};\\\", \\\"{x:1225,y:613,t:1527268164586};\\\", \\\"{x:1250,y:609,t:1527268164603};\\\", \\\"{x:1276,y:605,t:1527268164619};\\\", \\\"{x:1303,y:605,t:1527268164635};\\\", \\\"{x:1324,y:605,t:1527268164653};\\\", \\\"{x:1343,y:605,t:1527268164670};\\\", \\\"{x:1356,y:605,t:1527268164685};\\\", \\\"{x:1368,y:605,t:1527268164703};\\\", \\\"{x:1374,y:605,t:1527268164720};\\\", \\\"{x:1378,y:605,t:1527268164736};\\\", \\\"{x:1379,y:605,t:1527268164753};\\\", \\\"{x:1380,y:605,t:1527268164986};\\\", \\\"{x:1380,y:606,t:1527268164994};\\\", \\\"{x:1380,y:607,t:1527268165003};\\\", \\\"{x:1380,y:608,t:1527268165020};\\\", \\\"{x:1380,y:610,t:1527268165037};\\\", \\\"{x:1380,y:612,t:1527268165058};\\\", \\\"{x:1379,y:612,t:1527268165070};\\\", \\\"{x:1378,y:613,t:1527268165087};\\\", \\\"{x:1377,y:616,t:1527268165102};\\\", \\\"{x:1376,y:618,t:1527268165120};\\\", \\\"{x:1371,y:621,t:1527268165137};\\\", \\\"{x:1366,y:625,t:1527268165153};\\\", \\\"{x:1363,y:628,t:1527268165170};\\\", \\\"{x:1360,y:633,t:1527268165186};\\\", \\\"{x:1355,y:642,t:1527268165204};\\\", \\\"{x:1351,y:650,t:1527268165220};\\\", \\\"{x:1345,y:663,t:1527268165236};\\\", \\\"{x:1339,y:678,t:1527268165254};\\\", \\\"{x:1329,y:697,t:1527268165270};\\\", \\\"{x:1312,y:722,t:1527268165286};\\\", \\\"{x:1291,y:750,t:1527268165304};\\\", \\\"{x:1252,y:802,t:1527268165320};\\\", \\\"{x:1183,y:859,t:1527268165336};\\\", \\\"{x:1142,y:906,t:1527268165354};\\\", \\\"{x:1138,y:914,t:1527268165370};\\\", \\\"{x:1138,y:915,t:1527268165386};\\\", \\\"{x:1138,y:916,t:1527268165433};\\\", \\\"{x:1138,y:915,t:1527268165610};\\\", \\\"{x:1138,y:913,t:1527268165620};\\\", \\\"{x:1140,y:911,t:1527268165637};\\\", \\\"{x:1140,y:910,t:1527268165653};\\\", \\\"{x:1140,y:909,t:1527268165674};\\\", \\\"{x:1141,y:908,t:1527268165686};\\\", \\\"{x:1142,y:906,t:1527268165746};\\\", \\\"{x:1143,y:904,t:1527268165761};\\\", \\\"{x:1143,y:903,t:1527268165771};\\\", \\\"{x:1144,y:900,t:1527268165786};\\\", \\\"{x:1146,y:898,t:1527268165803};\\\", \\\"{x:1147,y:895,t:1527268165821};\\\", \\\"{x:1149,y:890,t:1527268165836};\\\", \\\"{x:1156,y:878,t:1527268165854};\\\", \\\"{x:1165,y:867,t:1527268165871};\\\", \\\"{x:1176,y:851,t:1527268165886};\\\", \\\"{x:1185,y:842,t:1527268165904};\\\", \\\"{x:1191,y:835,t:1527268165921};\\\", \\\"{x:1196,y:831,t:1527268165937};\\\", \\\"{x:1196,y:828,t:1527268165953};\\\", \\\"{x:1197,y:828,t:1527268166345};\\\", \\\"{x:1198,y:828,t:1527268166354};\\\", \\\"{x:1201,y:827,t:1527268166371};\\\", \\\"{x:1204,y:826,t:1527268166388};\\\", \\\"{x:1205,y:825,t:1527268166417};\\\", \\\"{x:1206,y:824,t:1527268166857};\\\", \\\"{x:1208,y:823,t:1527268166872};\\\", \\\"{x:1212,y:823,t:1527268166888};\\\", \\\"{x:1214,y:822,t:1527268166904};\\\", \\\"{x:1219,y:820,t:1527268166922};\\\", \\\"{x:1221,y:820,t:1527268166938};\\\", \\\"{x:1222,y:820,t:1527268166993};\\\", \\\"{x:1226,y:818,t:1527268167009};\\\", \\\"{x:1228,y:817,t:1527268167025};\\\", \\\"{x:1229,y:817,t:1527268167038};\\\", \\\"{x:1232,y:817,t:1527268167055};\\\", \\\"{x:1233,y:817,t:1527268167071};\\\", \\\"{x:1235,y:817,t:1527268167209};\\\", \\\"{x:1236,y:817,t:1527268167225};\\\", \\\"{x:1238,y:817,t:1527268167238};\\\", \\\"{x:1239,y:817,t:1527268167297};\\\", \\\"{x:1241,y:817,t:1527268167313};\\\", \\\"{x:1243,y:817,t:1527268167329};\\\", \\\"{x:1246,y:817,t:1527268167338};\\\", \\\"{x:1251,y:817,t:1527268167355};\\\", \\\"{x:1253,y:816,t:1527268167371};\\\", \\\"{x:1255,y:816,t:1527268167389};\\\", \\\"{x:1256,y:816,t:1527268167827};\\\", \\\"{x:1258,y:815,t:1527268167839};\\\", \\\"{x:1259,y:815,t:1527268167856};\\\", \\\"{x:1259,y:814,t:1527268167873};\\\", \\\"{x:1263,y:814,t:1527268167889};\\\", \\\"{x:1264,y:807,t:1527268167906};\\\", \\\"{x:1265,y:807,t:1527268167922};\\\", \\\"{x:1265,y:806,t:1527268167939};\\\", \\\"{x:1265,y:803,t:1527268168051};\\\", \\\"{x:1265,y:801,t:1527268168074};\\\", \\\"{x:1266,y:800,t:1527268168090};\\\", \\\"{x:1267,y:798,t:1527268168106};\\\", \\\"{x:1268,y:795,t:1527268168123};\\\", \\\"{x:1273,y:797,t:1527268168443};\\\", \\\"{x:1283,y:803,t:1527268168457};\\\", \\\"{x:1299,y:813,t:1527268168474};\\\", \\\"{x:1311,y:819,t:1527268168489};\\\", \\\"{x:1317,y:822,t:1527268168506};\\\", \\\"{x:1318,y:822,t:1527268168570};\\\", \\\"{x:1319,y:822,t:1527268168578};\\\", \\\"{x:1323,y:824,t:1527268168589};\\\", \\\"{x:1328,y:828,t:1527268168607};\\\", \\\"{x:1335,y:832,t:1527268168625};\\\", \\\"{x:1337,y:833,t:1527268168639};\\\", \\\"{x:1340,y:835,t:1527268168656};\\\", \\\"{x:1343,y:836,t:1527268168673};\\\", \\\"{x:1344,y:839,t:1527268168690};\\\", \\\"{x:1345,y:843,t:1527268168706};\\\", \\\"{x:1347,y:848,t:1527268168723};\\\", \\\"{x:1350,y:854,t:1527268168740};\\\", \\\"{x:1354,y:862,t:1527268168757};\\\", \\\"{x:1355,y:865,t:1527268168773};\\\", \\\"{x:1357,y:868,t:1527268168791};\\\", \\\"{x:1358,y:869,t:1527268168807};\\\", \\\"{x:1359,y:869,t:1527268168874};\\\", \\\"{x:1365,y:867,t:1527268168890};\\\", \\\"{x:1368,y:864,t:1527268168907};\\\", \\\"{x:1371,y:861,t:1527268168924};\\\", \\\"{x:1375,y:857,t:1527268168941};\\\", \\\"{x:1377,y:855,t:1527268168957};\\\", \\\"{x:1382,y:851,t:1527268168974};\\\", \\\"{x:1389,y:845,t:1527268168990};\\\", \\\"{x:1394,y:841,t:1527268169007};\\\", \\\"{x:1401,y:836,t:1527268169024};\\\", \\\"{x:1404,y:834,t:1527268169041};\\\", \\\"{x:1407,y:831,t:1527268169056};\\\", \\\"{x:1411,y:828,t:1527268169073};\\\", \\\"{x:1415,y:827,t:1527268169090};\\\", \\\"{x:1416,y:825,t:1527268169107};\\\", \\\"{x:1417,y:824,t:1527268169124};\\\", \\\"{x:1419,y:822,t:1527268169141};\\\", \\\"{x:1419,y:819,t:1527268169157};\\\", \\\"{x:1423,y:812,t:1527268169174};\\\", \\\"{x:1424,y:809,t:1527268169190};\\\", \\\"{x:1424,y:807,t:1527268169207};\\\", \\\"{x:1424,y:804,t:1527268169224};\\\", \\\"{x:1424,y:803,t:1527268169250};\\\", \\\"{x:1424,y:802,t:1527268169258};\\\", \\\"{x:1424,y:801,t:1527268169273};\\\", \\\"{x:1421,y:800,t:1527268169290};\\\", \\\"{x:1420,y:799,t:1527268169307};\\\", \\\"{x:1418,y:799,t:1527268169322};\\\", \\\"{x:1416,y:799,t:1527268169340};\\\", \\\"{x:1414,y:799,t:1527268169357};\\\", \\\"{x:1413,y:799,t:1527268169373};\\\", \\\"{x:1411,y:799,t:1527268169390};\\\", \\\"{x:1409,y:800,t:1527268169407};\\\", \\\"{x:1407,y:800,t:1527268169424};\\\", \\\"{x:1407,y:801,t:1527268169441};\\\", \\\"{x:1405,y:801,t:1527268169457};\\\", \\\"{x:1401,y:802,t:1527268169474};\\\", \\\"{x:1391,y:811,t:1527268169490};\\\", \\\"{x:1383,y:824,t:1527268169507};\\\", \\\"{x:1373,y:840,t:1527268169523};\\\", \\\"{x:1368,y:849,t:1527268169540};\\\", \\\"{x:1365,y:859,t:1527268169557};\\\", \\\"{x:1365,y:866,t:1527268169574};\\\", \\\"{x:1365,y:872,t:1527268169590};\\\", \\\"{x:1365,y:877,t:1527268169607};\\\", \\\"{x:1365,y:879,t:1527268169624};\\\", \\\"{x:1365,y:882,t:1527268169641};\\\", \\\"{x:1365,y:884,t:1527268169657};\\\", \\\"{x:1363,y:888,t:1527268169673};\\\", \\\"{x:1363,y:891,t:1527268169690};\\\", \\\"{x:1363,y:893,t:1527268169708};\\\", \\\"{x:1362,y:894,t:1527268170027};\\\", \\\"{x:1362,y:895,t:1527268170163};\\\", \\\"{x:1361,y:896,t:1527268170175};\\\", \\\"{x:1358,y:898,t:1527268170191};\\\", \\\"{x:1356,y:898,t:1527268170207};\\\", \\\"{x:1355,y:898,t:1527268170251};\\\", \\\"{x:1355,y:899,t:1527268170258};\\\", \\\"{x:1357,y:899,t:1527268170418};\\\", \\\"{x:1359,y:898,t:1527268170426};\\\", \\\"{x:1361,y:892,t:1527268170442};\\\", \\\"{x:1364,y:884,t:1527268170458};\\\", \\\"{x:1373,y:865,t:1527268170474};\\\", \\\"{x:1381,y:846,t:1527268170491};\\\", \\\"{x:1385,y:831,t:1527268170509};\\\", \\\"{x:1388,y:821,t:1527268170525};\\\", \\\"{x:1391,y:812,t:1527268170541};\\\", \\\"{x:1394,y:803,t:1527268170559};\\\", \\\"{x:1394,y:794,t:1527268170574};\\\", \\\"{x:1394,y:782,t:1527268170591};\\\", \\\"{x:1394,y:768,t:1527268170609};\\\", \\\"{x:1394,y:752,t:1527268170629};\\\", \\\"{x:1392,y:749,t:1527268170641};\\\", \\\"{x:1390,y:744,t:1527268170658};\\\", \\\"{x:1389,y:742,t:1527268170674};\\\", \\\"{x:1389,y:741,t:1527268170691};\\\", \\\"{x:1384,y:741,t:1527268170708};\\\", \\\"{x:1379,y:741,t:1527268170724};\\\", \\\"{x:1377,y:741,t:1527268170741};\\\", \\\"{x:1375,y:746,t:1527268170882};\\\", \\\"{x:1375,y:750,t:1527268170892};\\\", \\\"{x:1375,y:756,t:1527268170909};\\\", \\\"{x:1375,y:759,t:1527268170925};\\\", \\\"{x:1376,y:761,t:1527268170942};\\\", \\\"{x:1376,y:762,t:1527268170958};\\\", \\\"{x:1376,y:763,t:1527268172961};\\\", \\\"{x:1377,y:765,t:1527268173931};\\\", \\\"{x:1379,y:768,t:1527268173944};\\\", \\\"{x:1379,y:769,t:1527268173962};\\\", \\\"{x:1380,y:772,t:1527268173978};\\\", \\\"{x:1380,y:773,t:1527268173994};\\\", \\\"{x:1381,y:774,t:1527268174011};\\\", \\\"{x:1382,y:775,t:1527268174028};\\\", \\\"{x:1382,y:776,t:1527268174050};\\\", \\\"{x:1382,y:777,t:1527268174060};\\\", \\\"{x:1382,y:778,t:1527268174090};\\\", \\\"{x:1383,y:778,t:1527268174298};\\\", \\\"{x:1384,y:778,t:1527268174386};\\\", \\\"{x:1385,y:778,t:1527268174530};\\\", \\\"{x:1385,y:777,t:1527268174545};\\\", \\\"{x:1385,y:774,t:1527268174562};\\\", \\\"{x:1386,y:772,t:1527268174578};\\\", \\\"{x:1386,y:770,t:1527268174595};\\\", \\\"{x:1386,y:768,t:1527268174611};\\\", \\\"{x:1386,y:765,t:1527268174629};\\\", \\\"{x:1386,y:763,t:1527268174644};\\\", \\\"{x:1386,y:761,t:1527268174661};\\\", \\\"{x:1386,y:759,t:1527268174679};\\\", \\\"{x:1386,y:758,t:1527268174915};\\\", \\\"{x:1386,y:756,t:1527268174928};\\\", \\\"{x:1386,y:754,t:1527268174945};\\\", \\\"{x:1384,y:752,t:1527268174962};\\\", \\\"{x:1382,y:749,t:1527268174978};\\\", \\\"{x:1381,y:748,t:1527268174995};\\\", \\\"{x:1381,y:747,t:1527268175011};\\\", \\\"{x:1380,y:746,t:1527268175041};\\\", \\\"{x:1380,y:745,t:1527268175058};\\\", \\\"{x:1378,y:742,t:1527268175067};\\\", \\\"{x:1376,y:741,t:1527268175079};\\\", \\\"{x:1371,y:738,t:1527268175094};\\\", \\\"{x:1365,y:735,t:1527268175112};\\\", \\\"{x:1361,y:734,t:1527268175129};\\\", \\\"{x:1359,y:733,t:1527268175145};\\\", \\\"{x:1359,y:732,t:1527268175210};\\\", \\\"{x:1357,y:729,t:1527268175229};\\\", \\\"{x:1357,y:727,t:1527268175246};\\\", \\\"{x:1356,y:726,t:1527268175261};\\\", \\\"{x:1355,y:723,t:1527268175279};\\\", \\\"{x:1353,y:720,t:1527268175296};\\\", \\\"{x:1347,y:713,t:1527268175312};\\\", \\\"{x:1337,y:704,t:1527268175329};\\\", \\\"{x:1321,y:687,t:1527268175346};\\\", \\\"{x:1314,y:676,t:1527268175362};\\\", \\\"{x:1311,y:667,t:1527268175378};\\\", \\\"{x:1310,y:659,t:1527268175395};\\\", \\\"{x:1310,y:655,t:1527268175411};\\\", \\\"{x:1310,y:653,t:1527268175428};\\\", \\\"{x:1310,y:652,t:1527268175507};\\\", \\\"{x:1310,y:650,t:1527268175514};\\\", \\\"{x:1310,y:649,t:1527268175530};\\\", \\\"{x:1310,y:646,t:1527268175546};\\\", \\\"{x:1310,y:642,t:1527268175562};\\\", \\\"{x:1311,y:637,t:1527268175579};\\\", \\\"{x:1312,y:635,t:1527268175596};\\\", \\\"{x:1312,y:633,t:1527268175611};\\\", \\\"{x:1312,y:632,t:1527268175628};\\\", \\\"{x:1313,y:631,t:1527268175665};\\\", \\\"{x:1313,y:630,t:1527268175689};\\\", \\\"{x:1313,y:629,t:1527268175697};\\\", \\\"{x:1313,y:628,t:1527268175713};\\\", \\\"{x:1313,y:626,t:1527268175728};\\\", \\\"{x:1313,y:625,t:1527268175745};\\\", \\\"{x:1314,y:625,t:1527268175762};\\\", \\\"{x:1312,y:625,t:1527268178698};\\\", \\\"{x:1308,y:625,t:1527268178715};\\\", \\\"{x:1304,y:625,t:1527268178731};\\\", \\\"{x:1296,y:627,t:1527268178747};\\\", \\\"{x:1288,y:629,t:1527268178765};\\\", \\\"{x:1284,y:631,t:1527268178782};\\\", \\\"{x:1283,y:627,t:1527268179002};\\\", \\\"{x:1284,y:621,t:1527268179015};\\\", \\\"{x:1284,y:619,t:1527268179032};\\\", \\\"{x:1288,y:619,t:1527268179058};\\\", \\\"{x:1289,y:619,t:1527268179066};\\\", \\\"{x:1290,y:619,t:1527268179090};\\\", \\\"{x:1292,y:619,t:1527268179098};\\\", \\\"{x:1294,y:618,t:1527268179114};\\\", \\\"{x:1301,y:617,t:1527268179132};\\\", \\\"{x:1303,y:617,t:1527268179148};\\\", \\\"{x:1305,y:617,t:1527268179337};\\\", \\\"{x:1306,y:617,t:1527268179348};\\\", \\\"{x:1307,y:617,t:1527268179364};\\\", \\\"{x:1308,y:617,t:1527268179448};\\\", \\\"{x:1309,y:617,t:1527268179473};\\\", \\\"{x:1309,y:616,t:1527268179497};\\\", \\\"{x:1309,y:618,t:1527268179841};\\\", \\\"{x:1309,y:621,t:1527268179849};\\\", \\\"{x:1309,y:626,t:1527268179865};\\\", \\\"{x:1309,y:632,t:1527268179881};\\\", \\\"{x:1309,y:637,t:1527268179898};\\\", \\\"{x:1310,y:639,t:1527268179915};\\\", \\\"{x:1311,y:639,t:1527268180074};\\\", \\\"{x:1312,y:639,t:1527268180082};\\\", \\\"{x:1313,y:639,t:1527268180099};\\\", \\\"{x:1312,y:640,t:1527268180689};\\\", \\\"{x:1311,y:640,t:1527268180706};\\\", \\\"{x:1310,y:640,t:1527268180716};\\\", \\\"{x:1309,y:640,t:1527268180733};\\\", \\\"{x:1311,y:640,t:1527268181274};\\\", \\\"{x:1313,y:640,t:1527268181306};\\\", \\\"{x:1314,y:640,t:1527268181321};\\\", \\\"{x:1315,y:640,t:1527268181337};\\\", \\\"{x:1316,y:640,t:1527268181698};\\\", \\\"{x:1316,y:633,t:1527268183627};\\\", \\\"{x:1316,y:630,t:1527268183635};\\\", \\\"{x:1316,y:625,t:1527268183652};\\\", \\\"{x:1316,y:620,t:1527268183670};\\\", \\\"{x:1314,y:614,t:1527268183685};\\\", \\\"{x:1314,y:612,t:1527268183702};\\\", \\\"{x:1313,y:610,t:1527268183720};\\\", \\\"{x:1313,y:609,t:1527268184010};\\\", \\\"{x:1313,y:605,t:1527268184020};\\\", \\\"{x:1313,y:592,t:1527268184036};\\\", \\\"{x:1313,y:583,t:1527268184052};\\\", \\\"{x:1313,y:570,t:1527268184069};\\\", \\\"{x:1313,y:565,t:1527268184086};\\\", \\\"{x:1313,y:562,t:1527268184102};\\\", \\\"{x:1313,y:561,t:1527268184178};\\\", \\\"{x:1313,y:558,t:1527268184186};\\\", \\\"{x:1312,y:554,t:1527268184202};\\\", \\\"{x:1312,y:548,t:1527268184219};\\\", \\\"{x:1311,y:546,t:1527268184236};\\\", \\\"{x:1311,y:543,t:1527268184252};\\\", \\\"{x:1310,y:538,t:1527268184269};\\\", \\\"{x:1310,y:530,t:1527268184286};\\\", \\\"{x:1310,y:519,t:1527268184303};\\\", \\\"{x:1310,y:508,t:1527268184319};\\\", \\\"{x:1310,y:496,t:1527268184336};\\\", \\\"{x:1310,y:482,t:1527268184353};\\\", \\\"{x:1310,y:473,t:1527268184369};\\\", \\\"{x:1310,y:467,t:1527268184386};\\\", \\\"{x:1310,y:466,t:1527268184402};\\\", \\\"{x:1310,y:465,t:1527268184420};\\\", \\\"{x:1310,y:467,t:1527268185179};\\\", \\\"{x:1310,y:468,t:1527268185185};\\\", \\\"{x:1310,y:472,t:1527268185203};\\\", \\\"{x:1310,y:474,t:1527268185220};\\\", \\\"{x:1311,y:475,t:1527268185236};\\\", \\\"{x:1311,y:476,t:1527268185394};\\\", \\\"{x:1311,y:478,t:1527268185442};\\\", \\\"{x:1311,y:479,t:1527268185453};\\\", \\\"{x:1311,y:482,t:1527268185470};\\\", \\\"{x:1311,y:483,t:1527268185489};\\\", \\\"{x:1311,y:484,t:1527268185521};\\\", \\\"{x:1311,y:485,t:1527268185546};\\\", \\\"{x:1311,y:486,t:1527268185562};\\\", \\\"{x:1311,y:487,t:1527268185578};\\\", \\\"{x:1311,y:488,t:1527268185602};\\\", \\\"{x:1311,y:489,t:1527268185650};\\\", \\\"{x:1311,y:490,t:1527268185674};\\\", \\\"{x:1311,y:491,t:1527268186386};\\\", \\\"{x:1311,y:493,t:1527268186483};\\\", \\\"{x:1312,y:499,t:1527268186504};\\\", \\\"{x:1313,y:506,t:1527268186522};\\\", \\\"{x:1313,y:509,t:1527268186537};\\\", \\\"{x:1313,y:514,t:1527268186553};\\\", \\\"{x:1313,y:515,t:1527268186571};\\\", \\\"{x:1313,y:516,t:1527268186587};\\\", \\\"{x:1313,y:516,t:1527268186787};\\\", \\\"{x:1315,y:515,t:1527268187026};\\\", \\\"{x:1315,y:513,t:1527268187038};\\\", \\\"{x:1315,y:511,t:1527268187055};\\\", \\\"{x:1315,y:510,t:1527268187071};\\\", \\\"{x:1315,y:509,t:1527268187088};\\\", \\\"{x:1315,y:507,t:1527268187104};\\\", \\\"{x:1316,y:506,t:1527268187121};\\\", \\\"{x:1316,y:505,t:1527268187138};\\\", \\\"{x:1316,y:504,t:1527268187178};\\\", \\\"{x:1318,y:503,t:1527268197122};\\\", \\\"{x:1326,y:498,t:1527268197129};\\\", \\\"{x:1336,y:488,t:1527268197146};\\\", \\\"{x:1344,y:478,t:1527268197162};\\\", \\\"{x:1351,y:468,t:1527268197179};\\\", \\\"{x:1353,y:465,t:1527268197196};\\\", \\\"{x:1355,y:461,t:1527268197212};\\\", \\\"{x:1361,y:456,t:1527268197229};\\\", \\\"{x:1371,y:450,t:1527268197245};\\\", \\\"{x:1380,y:446,t:1527268197262};\\\", \\\"{x:1389,y:441,t:1527268197278};\\\", \\\"{x:1394,y:439,t:1527268197295};\\\", \\\"{x:1396,y:439,t:1527268197312};\\\", \\\"{x:1398,y:438,t:1527268197329};\\\", \\\"{x:1400,y:437,t:1527268197346};\\\", \\\"{x:1401,y:436,t:1527268197410};\\\", \\\"{x:1403,y:436,t:1527268197418};\\\", \\\"{x:1405,y:436,t:1527268197429};\\\", \\\"{x:1409,y:435,t:1527268197446};\\\", \\\"{x:1411,y:435,t:1527268197463};\\\", \\\"{x:1412,y:435,t:1527268197530};\\\", \\\"{x:1413,y:434,t:1527268197545};\\\", \\\"{x:1412,y:434,t:1527268197641};\\\", \\\"{x:1411,y:434,t:1527268197649};\\\", \\\"{x:1410,y:434,t:1527268197663};\\\", \\\"{x:1410,y:435,t:1527268199122};\\\", \\\"{x:1410,y:446,t:1527268199130};\\\", \\\"{x:1412,y:475,t:1527268199148};\\\", \\\"{x:1418,y:502,t:1527268199164};\\\", \\\"{x:1427,y:530,t:1527268199180};\\\", \\\"{x:1433,y:551,t:1527268199197};\\\", \\\"{x:1438,y:574,t:1527268199213};\\\", \\\"{x:1444,y:602,t:1527268199231};\\\", \\\"{x:1451,y:637,t:1527268199246};\\\", \\\"{x:1461,y:702,t:1527268199262};\\\", \\\"{x:1471,y:761,t:1527268199278};\\\", \\\"{x:1483,y:820,t:1527268199295};\\\", \\\"{x:1485,y:842,t:1527268199312};\\\", \\\"{x:1490,y:858,t:1527268199328};\\\", \\\"{x:1490,y:866,t:1527268199345};\\\", \\\"{x:1490,y:875,t:1527268199362};\\\", \\\"{x:1490,y:884,t:1527268199378};\\\", \\\"{x:1488,y:894,t:1527268199395};\\\", \\\"{x:1486,y:899,t:1527268199412};\\\", \\\"{x:1483,y:906,t:1527268199428};\\\", \\\"{x:1480,y:910,t:1527268199445};\\\", \\\"{x:1476,y:914,t:1527268199462};\\\", \\\"{x:1472,y:916,t:1527268199478};\\\", \\\"{x:1464,y:916,t:1527268199494};\\\", \\\"{x:1460,y:915,t:1527268199512};\\\", \\\"{x:1453,y:907,t:1527268199528};\\\", \\\"{x:1448,y:897,t:1527268199544};\\\", \\\"{x:1444,y:891,t:1527268199561};\\\", \\\"{x:1441,y:886,t:1527268199577};\\\", \\\"{x:1439,y:882,t:1527268199595};\\\", \\\"{x:1437,y:879,t:1527268199612};\\\", \\\"{x:1436,y:877,t:1527268199627};\\\", \\\"{x:1435,y:874,t:1527268199644};\\\", \\\"{x:1432,y:869,t:1527268199662};\\\", \\\"{x:1429,y:863,t:1527268199678};\\\", \\\"{x:1425,y:853,t:1527268199694};\\\", \\\"{x:1422,y:847,t:1527268199712};\\\", \\\"{x:1419,y:840,t:1527268199729};\\\", \\\"{x:1418,y:837,t:1527268199745};\\\", \\\"{x:1418,y:835,t:1527268199762};\\\", \\\"{x:1417,y:835,t:1527268199783};\\\", \\\"{x:1416,y:832,t:1527268199839};\\\", \\\"{x:1416,y:831,t:1527268199847};\\\", \\\"{x:1415,y:830,t:1527268199862};\\\", \\\"{x:1413,y:825,t:1527268199880};\\\", \\\"{x:1412,y:822,t:1527268199894};\\\", \\\"{x:1411,y:819,t:1527268199912};\\\", \\\"{x:1409,y:817,t:1527268199929};\\\", \\\"{x:1408,y:816,t:1527268199945};\\\", \\\"{x:1406,y:814,t:1527268199962};\\\", \\\"{x:1406,y:813,t:1527268199991};\\\", \\\"{x:1404,y:813,t:1527268201054};\\\", \\\"{x:1401,y:809,t:1527268201062};\\\", \\\"{x:1395,y:803,t:1527268201079};\\\", \\\"{x:1390,y:798,t:1527268201095};\\\", \\\"{x:1389,y:796,t:1527268201112};\\\", \\\"{x:1387,y:792,t:1527268201129};\\\", \\\"{x:1386,y:790,t:1527268201145};\\\", \\\"{x:1386,y:789,t:1527268201162};\\\", \\\"{x:1386,y:786,t:1527268201180};\\\", \\\"{x:1386,y:784,t:1527268201196};\\\", \\\"{x:1386,y:782,t:1527268201213};\\\", \\\"{x:1385,y:780,t:1527268201230};\\\", \\\"{x:1385,y:778,t:1527268201246};\\\", \\\"{x:1385,y:777,t:1527268201263};\\\", \\\"{x:1385,y:776,t:1527268201311};\\\", \\\"{x:1385,y:775,t:1527268201319};\\\", \\\"{x:1385,y:773,t:1527268201330};\\\", \\\"{x:1384,y:771,t:1527268201346};\\\", \\\"{x:1384,y:769,t:1527268201362};\\\", \\\"{x:1384,y:768,t:1527268201380};\\\", \\\"{x:1384,y:767,t:1527268201396};\\\", \\\"{x:1384,y:764,t:1527268202167};\\\", \\\"{x:1387,y:764,t:1527268202181};\\\", \\\"{x:1397,y:760,t:1527268202198};\\\", \\\"{x:1412,y:757,t:1527268202215};\\\", \\\"{x:1430,y:758,t:1527268202231};\\\", \\\"{x:1453,y:762,t:1527268202247};\\\", \\\"{x:1457,y:765,t:1527268202264};\\\", \\\"{x:1458,y:766,t:1527268202295};\\\", \\\"{x:1458,y:767,t:1527268202303};\\\", \\\"{x:1460,y:768,t:1527268202314};\\\", \\\"{x:1462,y:771,t:1527268202330};\\\", \\\"{x:1466,y:775,t:1527268202347};\\\", \\\"{x:1470,y:779,t:1527268202365};\\\", \\\"{x:1475,y:782,t:1527268202380};\\\", \\\"{x:1478,y:784,t:1527268202398};\\\", \\\"{x:1479,y:784,t:1527268202479};\\\", \\\"{x:1479,y:785,t:1527268202497};\\\", \\\"{x:1480,y:786,t:1527268202514};\\\", \\\"{x:1480,y:790,t:1527268202530};\\\", \\\"{x:1482,y:792,t:1527268202547};\\\", \\\"{x:1482,y:794,t:1527268202564};\\\", \\\"{x:1483,y:796,t:1527268202582};\\\", \\\"{x:1483,y:799,t:1527268202597};\\\", \\\"{x:1483,y:800,t:1527268202614};\\\", \\\"{x:1483,y:802,t:1527268202631};\\\", \\\"{x:1483,y:805,t:1527268202647};\\\", \\\"{x:1484,y:809,t:1527268202664};\\\", \\\"{x:1484,y:812,t:1527268202681};\\\", \\\"{x:1484,y:815,t:1527268202696};\\\", \\\"{x:1484,y:816,t:1527268202790};\\\", \\\"{x:1484,y:818,t:1527268202870};\\\", \\\"{x:1484,y:819,t:1527268202895};\\\", \\\"{x:1484,y:821,t:1527268203320};\\\", \\\"{x:1484,y:823,t:1527268203331};\\\", \\\"{x:1485,y:825,t:1527268203348};\\\", \\\"{x:1485,y:826,t:1527268203365};\\\", \\\"{x:1485,y:827,t:1527268208223};\\\", \\\"{x:1485,y:828,t:1527268208255};\\\", \\\"{x:1485,y:829,t:1527268208320};\\\", \\\"{x:1485,y:832,t:1527268208335};\\\", \\\"{x:1485,y:834,t:1527268208352};\\\", \\\"{x:1485,y:836,t:1527268208369};\\\", \\\"{x:1485,y:838,t:1527268208386};\\\", \\\"{x:1485,y:839,t:1527268208402};\\\", \\\"{x:1485,y:840,t:1527268208418};\\\", \\\"{x:1485,y:841,t:1527268208435};\\\", \\\"{x:1485,y:842,t:1527268208455};\\\", \\\"{x:1485,y:843,t:1527268208469};\\\", \\\"{x:1485,y:846,t:1527268208485};\\\", \\\"{x:1485,y:847,t:1527268208501};\\\", \\\"{x:1484,y:851,t:1527268208519};\\\", \\\"{x:1483,y:855,t:1527268208535};\\\", \\\"{x:1482,y:859,t:1527268208551};\\\", \\\"{x:1482,y:862,t:1527268208569};\\\", \\\"{x:1482,y:865,t:1527268208586};\\\", \\\"{x:1481,y:867,t:1527268208601};\\\", \\\"{x:1481,y:868,t:1527268208619};\\\", \\\"{x:1480,y:870,t:1527268208636};\\\", \\\"{x:1480,y:874,t:1527268208651};\\\", \\\"{x:1480,y:876,t:1527268208668};\\\", \\\"{x:1479,y:879,t:1527268208685};\\\", \\\"{x:1478,y:885,t:1527268208702};\\\", \\\"{x:1478,y:891,t:1527268208718};\\\", \\\"{x:1478,y:902,t:1527268208735};\\\", \\\"{x:1478,y:907,t:1527268208752};\\\", \\\"{x:1478,y:910,t:1527268208768};\\\", \\\"{x:1479,y:914,t:1527268208785};\\\", \\\"{x:1479,y:915,t:1527268208803};\\\", \\\"{x:1479,y:917,t:1527268208819};\\\", \\\"{x:1481,y:920,t:1527268208835};\\\", \\\"{x:1483,y:923,t:1527268208853};\\\", \\\"{x:1485,y:925,t:1527268209111};\\\", \\\"{x:1485,y:924,t:1527268209127};\\\", \\\"{x:1486,y:919,t:1527268209135};\\\", \\\"{x:1487,y:907,t:1527268209153};\\\", \\\"{x:1490,y:895,t:1527268209168};\\\", \\\"{x:1491,y:886,t:1527268209185};\\\", \\\"{x:1491,y:881,t:1527268209202};\\\", \\\"{x:1491,y:877,t:1527268209219};\\\", \\\"{x:1491,y:874,t:1527268209235};\\\", \\\"{x:1491,y:870,t:1527268209253};\\\", \\\"{x:1491,y:864,t:1527268209270};\\\", \\\"{x:1491,y:860,t:1527268209285};\\\", \\\"{x:1491,y:856,t:1527268209302};\\\", \\\"{x:1491,y:852,t:1527268209319};\\\", \\\"{x:1490,y:849,t:1527268209336};\\\", \\\"{x:1489,y:847,t:1527268209353};\\\", \\\"{x:1488,y:846,t:1527268209370};\\\", \\\"{x:1488,y:844,t:1527268209386};\\\", \\\"{x:1488,y:843,t:1527268209407};\\\", \\\"{x:1487,y:843,t:1527268209420};\\\", \\\"{x:1487,y:841,t:1527268209438};\\\", \\\"{x:1487,y:838,t:1527268211752};\\\", \\\"{x:1484,y:829,t:1527268211759};\\\", \\\"{x:1484,y:827,t:1527268211771};\\\", \\\"{x:1483,y:814,t:1527268211789};\\\", \\\"{x:1481,y:801,t:1527268211805};\\\", \\\"{x:1478,y:788,t:1527268211822};\\\", \\\"{x:1477,y:779,t:1527268211838};\\\", \\\"{x:1475,y:772,t:1527268211854};\\\", \\\"{x:1473,y:767,t:1527268211871};\\\", \\\"{x:1473,y:761,t:1527268211888};\\\", \\\"{x:1471,y:751,t:1527268211905};\\\", \\\"{x:1470,y:739,t:1527268211921};\\\", \\\"{x:1468,y:726,t:1527268211938};\\\", \\\"{x:1466,y:710,t:1527268211955};\\\", \\\"{x:1465,y:702,t:1527268211971};\\\", \\\"{x:1463,y:692,t:1527268211988};\\\", \\\"{x:1462,y:685,t:1527268212004};\\\", \\\"{x:1460,y:678,t:1527268212022};\\\", \\\"{x:1459,y:669,t:1527268212037};\\\", \\\"{x:1456,y:660,t:1527268212054};\\\", \\\"{x:1455,y:654,t:1527268212070};\\\", \\\"{x:1453,y:649,t:1527268212088};\\\", \\\"{x:1451,y:643,t:1527268212105};\\\", \\\"{x:1449,y:636,t:1527268212122};\\\", \\\"{x:1447,y:630,t:1527268212137};\\\", \\\"{x:1446,y:625,t:1527268212155};\\\", \\\"{x:1443,y:618,t:1527268212172};\\\", \\\"{x:1440,y:611,t:1527268212187};\\\", \\\"{x:1438,y:605,t:1527268212204};\\\", \\\"{x:1436,y:601,t:1527268212222};\\\", \\\"{x:1435,y:596,t:1527268212237};\\\", \\\"{x:1430,y:586,t:1527268212255};\\\", \\\"{x:1428,y:584,t:1527268212270};\\\", \\\"{x:1427,y:580,t:1527268212287};\\\", \\\"{x:1426,y:579,t:1527268212304};\\\", \\\"{x:1426,y:578,t:1527268212335};\\\", \\\"{x:1425,y:578,t:1527268212623};\\\", \\\"{x:1424,y:577,t:1527268212719};\\\", \\\"{x:1420,y:575,t:1527268212727};\\\", \\\"{x:1419,y:573,t:1527268212739};\\\", \\\"{x:1415,y:568,t:1527268212755};\\\", \\\"{x:1412,y:566,t:1527268212772};\\\", \\\"{x:1410,y:566,t:1527268216079};\\\", \\\"{x:1404,y:566,t:1527268216092};\\\", \\\"{x:1382,y:575,t:1527268216108};\\\", \\\"{x:1371,y:578,t:1527268216124};\\\", \\\"{x:1370,y:579,t:1527268216191};\\\", \\\"{x:1373,y:578,t:1527268217471};\\\", \\\"{x:1376,y:577,t:1527268217479};\\\", \\\"{x:1377,y:577,t:1527268217815};\\\", \\\"{x:1383,y:572,t:1527268217825};\\\", \\\"{x:1404,y:541,t:1527268217842};\\\", \\\"{x:1448,y:474,t:1527268217859};\\\", \\\"{x:1497,y:387,t:1527268217876};\\\", \\\"{x:1532,y:317,t:1527268217892};\\\", \\\"{x:1547,y:271,t:1527268217909};\\\", \\\"{x:1553,y:248,t:1527268217926};\\\", \\\"{x:1556,y:236,t:1527268217941};\\\", \\\"{x:1556,y:227,t:1527268217959};\\\", \\\"{x:1555,y:225,t:1527268217976};\\\", \\\"{x:1561,y:225,t:1527268218047};\\\", \\\"{x:1566,y:225,t:1527268218059};\\\", \\\"{x:1588,y:225,t:1527268218076};\\\", \\\"{x:1602,y:225,t:1527268218092};\\\", \\\"{x:1613,y:227,t:1527268218109};\\\", \\\"{x:1634,y:239,t:1527268218126};\\\", \\\"{x:1677,y:271,t:1527268218142};\\\", \\\"{x:1741,y:330,t:1527268218159};\\\", \\\"{x:1750,y:364,t:1527268218176};\\\", \\\"{x:1753,y:400,t:1527268218192};\\\", \\\"{x:1753,y:443,t:1527268218208};\\\", \\\"{x:1753,y:496,t:1527268218226};\\\", \\\"{x:1767,y:564,t:1527268218242};\\\", \\\"{x:1802,y:647,t:1527268218258};\\\", \\\"{x:1829,y:718,t:1527268218276};\\\", \\\"{x:1832,y:761,t:1527268218292};\\\", \\\"{x:1832,y:796,t:1527268218309};\\\", \\\"{x:1821,y:838,t:1527268218326};\\\", \\\"{x:1772,y:925,t:1527268218343};\\\", \\\"{x:1715,y:982,t:1527268218358};\\\", \\\"{x:1633,y:1024,t:1527268218376};\\\", \\\"{x:1546,y:1043,t:1527268218393};\\\", \\\"{x:1457,y:1056,t:1527268218409};\\\", \\\"{x:1409,y:1064,t:1527268218426};\\\", \\\"{x:1394,y:1064,t:1527268218443};\\\", \\\"{x:1389,y:1064,t:1527268218459};\\\", \\\"{x:1386,y:1063,t:1527268218479};\\\", \\\"{x:1386,y:1061,t:1527268218492};\\\", \\\"{x:1386,y:1051,t:1527268218509};\\\", \\\"{x:1385,y:1040,t:1527268218526};\\\", \\\"{x:1385,y:1017,t:1527268218543};\\\", \\\"{x:1385,y:1003,t:1527268218559};\\\", \\\"{x:1385,y:986,t:1527268218576};\\\", \\\"{x:1385,y:970,t:1527268218592};\\\", \\\"{x:1382,y:952,t:1527268218609};\\\", \\\"{x:1382,y:935,t:1527268218626};\\\", \\\"{x:1382,y:918,t:1527268218643};\\\", \\\"{x:1384,y:902,t:1527268218659};\\\", \\\"{x:1388,y:889,t:1527268218676};\\\", \\\"{x:1392,y:881,t:1527268218693};\\\", \\\"{x:1395,y:874,t:1527268218708};\\\", \\\"{x:1401,y:865,t:1527268218725};\\\", \\\"{x:1414,y:851,t:1527268218742};\\\", \\\"{x:1426,y:843,t:1527268218759};\\\", \\\"{x:1438,y:834,t:1527268218776};\\\", \\\"{x:1449,y:830,t:1527268218793};\\\", \\\"{x:1458,y:826,t:1527268218811};\\\", \\\"{x:1465,y:823,t:1527268218826};\\\", \\\"{x:1471,y:820,t:1527268218843};\\\", \\\"{x:1477,y:817,t:1527268218860};\\\", \\\"{x:1485,y:813,t:1527268218877};\\\", \\\"{x:1495,y:810,t:1527268218893};\\\", \\\"{x:1498,y:809,t:1527268218910};\\\", \\\"{x:1499,y:809,t:1527268218951};\\\", \\\"{x:1504,y:809,t:1527268218959};\\\", \\\"{x:1530,y:824,t:1527268218975};\\\", \\\"{x:1596,y:850,t:1527268218993};\\\", \\\"{x:1687,y:888,t:1527268219010};\\\", \\\"{x:1782,y:919,t:1527268219026};\\\", \\\"{x:1840,y:943,t:1527268219043};\\\", \\\"{x:1875,y:963,t:1527268219060};\\\", \\\"{x:1893,y:974,t:1527268219076};\\\", \\\"{x:1897,y:984,t:1527268219092};\\\", \\\"{x:1895,y:999,t:1527268219110};\\\", \\\"{x:1879,y:1014,t:1527268219125};\\\", \\\"{x:1856,y:1029,t:1527268219143};\\\", \\\"{x:1853,y:1033,t:1527268219160};\\\", \\\"{x:1853,y:1035,t:1527268219176};\\\", \\\"{x:1850,y:1038,t:1527268219193};\\\", \\\"{x:1844,y:1038,t:1527268219210};\\\", \\\"{x:1840,y:1038,t:1527268219227};\\\", \\\"{x:1830,y:1025,t:1527268219243};\\\", \\\"{x:1818,y:1008,t:1527268219260};\\\", \\\"{x:1802,y:991,t:1527268219277};\\\", \\\"{x:1794,y:979,t:1527268219293};\\\", \\\"{x:1788,y:972,t:1527268219310};\\\", \\\"{x:1785,y:965,t:1527268219327};\\\", \\\"{x:1782,y:961,t:1527268219343};\\\", \\\"{x:1779,y:956,t:1527268219360};\\\", \\\"{x:1778,y:953,t:1527268219377};\\\", \\\"{x:1774,y:947,t:1527268219393};\\\", \\\"{x:1769,y:943,t:1527268219409};\\\", \\\"{x:1757,y:937,t:1527268219427};\\\", \\\"{x:1737,y:929,t:1527268219443};\\\", \\\"{x:1710,y:921,t:1527268219460};\\\", \\\"{x:1674,y:911,t:1527268219477};\\\", \\\"{x:1632,y:898,t:1527268219493};\\\", \\\"{x:1579,y:884,t:1527268219510};\\\", \\\"{x:1507,y:863,t:1527268219527};\\\", \\\"{x:1494,y:861,t:1527268219543};\\\", \\\"{x:1493,y:861,t:1527268219623};\\\", \\\"{x:1494,y:861,t:1527268219662};\\\", \\\"{x:1499,y:865,t:1527268219677};\\\", \\\"{x:1509,y:879,t:1527268219694};\\\", \\\"{x:1519,y:892,t:1527268219710};\\\", \\\"{x:1528,y:908,t:1527268219727};\\\", \\\"{x:1532,y:913,t:1527268219743};\\\", \\\"{x:1534,y:916,t:1527268219760};\\\", \\\"{x:1537,y:918,t:1527268219777};\\\", \\\"{x:1538,y:919,t:1527268219794};\\\", \\\"{x:1538,y:920,t:1527268219810};\\\", \\\"{x:1539,y:921,t:1527268219827};\\\", \\\"{x:1544,y:922,t:1527268219843};\\\", \\\"{x:1553,y:927,t:1527268219859};\\\", \\\"{x:1564,y:932,t:1527268219877};\\\", \\\"{x:1571,y:936,t:1527268219893};\\\", \\\"{x:1576,y:940,t:1527268219909};\\\", \\\"{x:1578,y:943,t:1527268219927};\\\", \\\"{x:1580,y:945,t:1527268219944};\\\", \\\"{x:1582,y:946,t:1527268219966};\\\", \\\"{x:1583,y:947,t:1527268219982};\\\", \\\"{x:1584,y:947,t:1527268219993};\\\", \\\"{x:1585,y:947,t:1527268220009};\\\", \\\"{x:1587,y:947,t:1527268220027};\\\", \\\"{x:1588,y:947,t:1527268220044};\\\", \\\"{x:1591,y:947,t:1527268220060};\\\", \\\"{x:1592,y:947,t:1527268220076};\\\", \\\"{x:1596,y:947,t:1527268220093};\\\", \\\"{x:1600,y:946,t:1527268220110};\\\", \\\"{x:1602,y:944,t:1527268220126};\\\", \\\"{x:1603,y:943,t:1527268220143};\\\", \\\"{x:1605,y:941,t:1527268220160};\\\", \\\"{x:1605,y:940,t:1527268220176};\\\", \\\"{x:1606,y:940,t:1527268220194};\\\", \\\"{x:1606,y:938,t:1527268220230};\\\", \\\"{x:1606,y:937,t:1527268220244};\\\", \\\"{x:1606,y:932,t:1527268220260};\\\", \\\"{x:1606,y:926,t:1527268220276};\\\", \\\"{x:1606,y:922,t:1527268220293};\\\", \\\"{x:1606,y:918,t:1527268220310};\\\", \\\"{x:1606,y:917,t:1527268220327};\\\", \\\"{x:1606,y:916,t:1527268220344};\\\", \\\"{x:1606,y:914,t:1527268220360};\\\", \\\"{x:1606,y:913,t:1527268220415};\\\", \\\"{x:1606,y:912,t:1527268220427};\\\", \\\"{x:1606,y:911,t:1527268220444};\\\", \\\"{x:1606,y:908,t:1527268220461};\\\", \\\"{x:1606,y:905,t:1527268220477};\\\", \\\"{x:1606,y:901,t:1527268220493};\\\", \\\"{x:1606,y:889,t:1527268220510};\\\", \\\"{x:1606,y:875,t:1527268220526};\\\", \\\"{x:1606,y:864,t:1527268220543};\\\", \\\"{x:1606,y:851,t:1527268220561};\\\", \\\"{x:1605,y:836,t:1527268220577};\\\", \\\"{x:1603,y:822,t:1527268220594};\\\", \\\"{x:1599,y:804,t:1527268220610};\\\", \\\"{x:1594,y:781,t:1527268220627};\\\", \\\"{x:1591,y:765,t:1527268220644};\\\", \\\"{x:1587,y:751,t:1527268220661};\\\", \\\"{x:1583,y:742,t:1527268220678};\\\", \\\"{x:1579,y:735,t:1527268220694};\\\", \\\"{x:1570,y:722,t:1527268220710};\\\", \\\"{x:1559,y:711,t:1527268220727};\\\", \\\"{x:1543,y:699,t:1527268220744};\\\", \\\"{x:1534,y:691,t:1527268220760};\\\", \\\"{x:1520,y:684,t:1527268220778};\\\", \\\"{x:1511,y:680,t:1527268220794};\\\", \\\"{x:1508,y:680,t:1527268220811};\\\", \\\"{x:1505,y:679,t:1527268220828};\\\", \\\"{x:1503,y:682,t:1527268220862};\\\", \\\"{x:1500,y:694,t:1527268220878};\\\", \\\"{x:1498,y:718,t:1527268220894};\\\", \\\"{x:1493,y:757,t:1527268220910};\\\", \\\"{x:1492,y:778,t:1527268220928};\\\", \\\"{x:1492,y:799,t:1527268220944};\\\", \\\"{x:1494,y:813,t:1527268220961};\\\", \\\"{x:1497,y:825,t:1527268220978};\\\", \\\"{x:1499,y:830,t:1527268220994};\\\", \\\"{x:1500,y:835,t:1527268221011};\\\", \\\"{x:1501,y:836,t:1527268221028};\\\", \\\"{x:1502,y:837,t:1527268221044};\\\", \\\"{x:1502,y:838,t:1527268221095};\\\", \\\"{x:1502,y:841,t:1527268221111};\\\", \\\"{x:1502,y:843,t:1527268221128};\\\", \\\"{x:1502,y:845,t:1527268221144};\\\", \\\"{x:1500,y:842,t:1527268221342};\\\", \\\"{x:1499,y:841,t:1527268221349};\\\", \\\"{x:1497,y:840,t:1527268221360};\\\", \\\"{x:1494,y:837,t:1527268221377};\\\", \\\"{x:1491,y:833,t:1527268221395};\\\", \\\"{x:1489,y:831,t:1527268221411};\\\", \\\"{x:1488,y:830,t:1527268221430};\\\", \\\"{x:1486,y:830,t:1527268221704};\\\", \\\"{x:1485,y:830,t:1527268221712};\\\", \\\"{x:1483,y:830,t:1527268221728};\\\", \\\"{x:1481,y:828,t:1527268221744};\\\", \\\"{x:1480,y:828,t:1527268221762};\\\", \\\"{x:1478,y:827,t:1527268221778};\\\", \\\"{x:1475,y:826,t:1527268221796};\\\", \\\"{x:1473,y:825,t:1527268221814};\\\", \\\"{x:1472,y:824,t:1527268221828};\\\", \\\"{x:1468,y:823,t:1527268221844};\\\", \\\"{x:1464,y:820,t:1527268221862};\\\", \\\"{x:1461,y:818,t:1527268221877};\\\", \\\"{x:1454,y:814,t:1527268221894};\\\", \\\"{x:1449,y:811,t:1527268221911};\\\", \\\"{x:1440,y:806,t:1527268221928};\\\", \\\"{x:1429,y:802,t:1527268221944};\\\", \\\"{x:1418,y:795,t:1527268221961};\\\", \\\"{x:1409,y:791,t:1527268221978};\\\", \\\"{x:1402,y:788,t:1527268221995};\\\", \\\"{x:1394,y:785,t:1527268222012};\\\", \\\"{x:1386,y:781,t:1527268222028};\\\", \\\"{x:1380,y:778,t:1527268222044};\\\", \\\"{x:1373,y:777,t:1527268222062};\\\", \\\"{x:1371,y:777,t:1527268222079};\\\", \\\"{x:1367,y:777,t:1527268222095};\\\", \\\"{x:1363,y:777,t:1527268222112};\\\", \\\"{x:1357,y:779,t:1527268222129};\\\", \\\"{x:1343,y:790,t:1527268222145};\\\", \\\"{x:1321,y:805,t:1527268222162};\\\", \\\"{x:1285,y:821,t:1527268222179};\\\", \\\"{x:1245,y:840,t:1527268222195};\\\", \\\"{x:1217,y:851,t:1527268222212};\\\", \\\"{x:1195,y:859,t:1527268222229};\\\", \\\"{x:1179,y:865,t:1527268222245};\\\", \\\"{x:1173,y:868,t:1527268222262};\\\", \\\"{x:1171,y:869,t:1527268222278};\\\", \\\"{x:1171,y:870,t:1527268222375};\\\", \\\"{x:1171,y:871,t:1527268222391};\\\", \\\"{x:1171,y:872,t:1527268222406};\\\", \\\"{x:1172,y:872,t:1527268222415};\\\", \\\"{x:1173,y:872,t:1527268222429};\\\", \\\"{x:1181,y:874,t:1527268222445};\\\", \\\"{x:1188,y:875,t:1527268222462};\\\", \\\"{x:1210,y:879,t:1527268222478};\\\", \\\"{x:1226,y:881,t:1527268222495};\\\", \\\"{x:1240,y:882,t:1527268222512};\\\", \\\"{x:1251,y:882,t:1527268222529};\\\", \\\"{x:1264,y:884,t:1527268222545};\\\", \\\"{x:1273,y:885,t:1527268222562};\\\", \\\"{x:1279,y:885,t:1527268222579};\\\", \\\"{x:1282,y:885,t:1527268222596};\\\", \\\"{x:1283,y:885,t:1527268222612};\\\", \\\"{x:1285,y:885,t:1527268222654};\\\", \\\"{x:1286,y:885,t:1527268222662};\\\", \\\"{x:1289,y:885,t:1527268222678};\\\", \\\"{x:1294,y:884,t:1527268222696};\\\", \\\"{x:1299,y:883,t:1527268222712};\\\", \\\"{x:1304,y:883,t:1527268222729};\\\", \\\"{x:1313,y:881,t:1527268222746};\\\", \\\"{x:1320,y:881,t:1527268222762};\\\", \\\"{x:1324,y:881,t:1527268222779};\\\", \\\"{x:1327,y:881,t:1527268222796};\\\", \\\"{x:1328,y:881,t:1527268222966};\\\", \\\"{x:1329,y:881,t:1527268222990};\\\", \\\"{x:1330,y:881,t:1527268223006};\\\", \\\"{x:1331,y:880,t:1527268223021};\\\", \\\"{x:1332,y:880,t:1527268223119};\\\", \\\"{x:1335,y:878,t:1527268223311};\\\", \\\"{x:1335,y:877,t:1527268223318};\\\", \\\"{x:1335,y:876,t:1527268223329};\\\", \\\"{x:1336,y:875,t:1527268223346};\\\", \\\"{x:1336,y:874,t:1527268223367};\\\", \\\"{x:1336,y:873,t:1527268223379};\\\", \\\"{x:1336,y:872,t:1527268223396};\\\", \\\"{x:1336,y:871,t:1527268223431};\\\", \\\"{x:1336,y:870,t:1527268223447};\\\", \\\"{x:1336,y:868,t:1527268223463};\\\", \\\"{x:1335,y:867,t:1527268223480};\\\", \\\"{x:1334,y:862,t:1527268223496};\\\", \\\"{x:1332,y:856,t:1527268223513};\\\", \\\"{x:1328,y:848,t:1527268223530};\\\", \\\"{x:1321,y:834,t:1527268223546};\\\", \\\"{x:1311,y:822,t:1527268223563};\\\", \\\"{x:1303,y:814,t:1527268223580};\\\", \\\"{x:1294,y:811,t:1527268223596};\\\", \\\"{x:1287,y:807,t:1527268223613};\\\", \\\"{x:1286,y:807,t:1527268223630};\\\", \\\"{x:1284,y:806,t:1527268223646};\\\", \\\"{x:1285,y:806,t:1527268223927};\\\", \\\"{x:1289,y:806,t:1527268223935};\\\", \\\"{x:1294,y:806,t:1527268223946};\\\", \\\"{x:1310,y:806,t:1527268223963};\\\", \\\"{x:1324,y:808,t:1527268223980};\\\", \\\"{x:1336,y:808,t:1527268223997};\\\", \\\"{x:1347,y:808,t:1527268224013};\\\", \\\"{x:1358,y:808,t:1527268224030};\\\", \\\"{x:1366,y:808,t:1527268224047};\\\", \\\"{x:1370,y:808,t:1527268224063};\\\", \\\"{x:1372,y:805,t:1527268224080};\\\", \\\"{x:1374,y:804,t:1527268224097};\\\", \\\"{x:1377,y:799,t:1527268224113};\\\", \\\"{x:1378,y:798,t:1527268224130};\\\", \\\"{x:1378,y:797,t:1527268224147};\\\", \\\"{x:1378,y:795,t:1527268224163};\\\", \\\"{x:1381,y:791,t:1527268224180};\\\", \\\"{x:1381,y:786,t:1527268224197};\\\", \\\"{x:1382,y:782,t:1527268224213};\\\", \\\"{x:1383,y:780,t:1527268224230};\\\", \\\"{x:1384,y:777,t:1527268224247};\\\", \\\"{x:1384,y:776,t:1527268224271};\\\", \\\"{x:1385,y:776,t:1527268224295};\\\", \\\"{x:1385,y:774,t:1527268224303};\\\", \\\"{x:1385,y:773,t:1527268224319};\\\", \\\"{x:1385,y:771,t:1527268224599};\\\", \\\"{x:1385,y:770,t:1527268224639};\\\", \\\"{x:1385,y:768,t:1527268224942};\\\", \\\"{x:1385,y:767,t:1527268224950};\\\", \\\"{x:1385,y:766,t:1527268224964};\\\", \\\"{x:1385,y:765,t:1527268224980};\\\", \\\"{x:1385,y:764,t:1527268225015};\\\", \\\"{x:1385,y:761,t:1527268226599};\\\", \\\"{x:1386,y:755,t:1527268226616};\\\", \\\"{x:1386,y:751,t:1527268226632};\\\", \\\"{x:1386,y:749,t:1527268226648};\\\", \\\"{x:1386,y:747,t:1527268226815};\\\", \\\"{x:1386,y:746,t:1527268226832};\\\", \\\"{x:1386,y:743,t:1527268226849};\\\", \\\"{x:1386,y:740,t:1527268226865};\\\", \\\"{x:1383,y:737,t:1527268226882};\\\", \\\"{x:1380,y:735,t:1527268226900};\\\", \\\"{x:1377,y:730,t:1527268226916};\\\", \\\"{x:1376,y:728,t:1527268226932};\\\", \\\"{x:1374,y:724,t:1527268226950};\\\", \\\"{x:1372,y:722,t:1527268226965};\\\", \\\"{x:1368,y:715,t:1527268226982};\\\", \\\"{x:1365,y:709,t:1527268226998};\\\", \\\"{x:1361,y:701,t:1527268227015};\\\", \\\"{x:1356,y:694,t:1527268227032};\\\", \\\"{x:1352,y:687,t:1527268227050};\\\", \\\"{x:1349,y:683,t:1527268227065};\\\", \\\"{x:1348,y:681,t:1527268227082};\\\", \\\"{x:1346,y:680,t:1527268227099};\\\", \\\"{x:1346,y:679,t:1527268227115};\\\", \\\"{x:1345,y:679,t:1527268227142};\\\", \\\"{x:1345,y:678,t:1527268227158};\\\", \\\"{x:1344,y:678,t:1527268227167};\\\", \\\"{x:1344,y:677,t:1527268227182};\\\", \\\"{x:1340,y:674,t:1527268227199};\\\", \\\"{x:1339,y:673,t:1527268227215};\\\", \\\"{x:1337,y:672,t:1527268227233};\\\", \\\"{x:1334,y:670,t:1527268227249};\\\", \\\"{x:1327,y:664,t:1527268227265};\\\", \\\"{x:1320,y:657,t:1527268227283};\\\", \\\"{x:1313,y:649,t:1527268227299};\\\", \\\"{x:1306,y:643,t:1527268227315};\\\", \\\"{x:1303,y:638,t:1527268227332};\\\", \\\"{x:1302,y:637,t:1527268227349};\\\", \\\"{x:1302,y:636,t:1527268227439};\\\", \\\"{x:1302,y:635,t:1527268227575};\\\", \\\"{x:1302,y:634,t:1527268227599};\\\", \\\"{x:1303,y:633,t:1527268227616};\\\", \\\"{x:1306,y:632,t:1527268227632};\\\", \\\"{x:1308,y:631,t:1527268227650};\\\", \\\"{x:1309,y:630,t:1527268227667};\\\", \\\"{x:1311,y:630,t:1527268227699};\\\", \\\"{x:1312,y:630,t:1527268227734};\\\", \\\"{x:1307,y:630,t:1527268238376};\\\", \\\"{x:1295,y:634,t:1527268238382};\\\", \\\"{x:1283,y:637,t:1527268238394};\\\", \\\"{x:1236,y:648,t:1527268238411};\\\", \\\"{x:1142,y:655,t:1527268238428};\\\", \\\"{x:1007,y:655,t:1527268238444};\\\", \\\"{x:866,y:655,t:1527268238460};\\\", \\\"{x:719,y:639,t:1527268238479};\\\", \\\"{x:559,y:615,t:1527268238494};\\\", \\\"{x:297,y:572,t:1527268238510};\\\", \\\"{x:136,y:544,t:1527268238528};\\\", \\\"{x:31,y:517,t:1527268238544};\\\", \\\"{x:0,y:501,t:1527268238560};\\\", \\\"{x:0,y:493,t:1527268238576};\\\", \\\"{x:2,y:492,t:1527268238605};\\\", \\\"{x:8,y:491,t:1527268238613};\\\", \\\"{x:14,y:489,t:1527268238627};\\\", \\\"{x:31,y:484,t:1527268238644};\\\", \\\"{x:44,y:480,t:1527268238660};\\\", \\\"{x:62,y:478,t:1527268238677};\\\", \\\"{x:92,y:478,t:1527268238693};\\\", \\\"{x:119,y:478,t:1527268238710};\\\", \\\"{x:160,y:478,t:1527268238728};\\\", \\\"{x:240,y:484,t:1527268238744};\\\", \\\"{x:326,y:497,t:1527268238762};\\\", \\\"{x:393,y:507,t:1527268238778};\\\", \\\"{x:416,y:514,t:1527268238794};\\\", \\\"{x:420,y:516,t:1527268238811};\\\", \\\"{x:420,y:518,t:1527268238827};\\\", \\\"{x:424,y:524,t:1527268238844};\\\", \\\"{x:436,y:536,t:1527268238861};\\\", \\\"{x:448,y:541,t:1527268238877};\\\", \\\"{x:459,y:544,t:1527268238894};\\\", \\\"{x:471,y:546,t:1527268238911};\\\", \\\"{x:486,y:546,t:1527268238927};\\\", \\\"{x:505,y:543,t:1527268238945};\\\", \\\"{x:526,y:536,t:1527268238961};\\\", \\\"{x:537,y:532,t:1527268238977};\\\", \\\"{x:539,y:532,t:1527268238994};\\\", \\\"{x:541,y:532,t:1527268239011};\\\", \\\"{x:551,y:528,t:1527268239027};\\\", \\\"{x:576,y:521,t:1527268239044};\\\", \\\"{x:602,y:513,t:1527268239061};\\\", \\\"{x:621,y:508,t:1527268239077};\\\", \\\"{x:623,y:507,t:1527268239094};\\\", \\\"{x:631,y:507,t:1527268239111};\\\", \\\"{x:685,y:520,t:1527268239127};\\\", \\\"{x:788,y:551,t:1527268239145};\\\", \\\"{x:878,y:570,t:1527268239161};\\\", \\\"{x:907,y:577,t:1527268239177};\\\", \\\"{x:911,y:577,t:1527268239194};\\\", \\\"{x:908,y:577,t:1527268239350};\\\", \\\"{x:901,y:575,t:1527268239361};\\\", \\\"{x:877,y:566,t:1527268239380};\\\", \\\"{x:848,y:555,t:1527268239395};\\\", \\\"{x:835,y:552,t:1527268239412};\\\", \\\"{x:831,y:552,t:1527268239428};\\\", \\\"{x:830,y:552,t:1527268239445};\\\", \\\"{x:829,y:553,t:1527268239461};\\\", \\\"{x:830,y:553,t:1527268239559};\\\", \\\"{x:833,y:552,t:1527268239566};\\\", \\\"{x:834,y:552,t:1527268239582};\\\", \\\"{x:835,y:551,t:1527268239766};\\\", \\\"{x:838,y:550,t:1527268239925};\\\", \\\"{x:839,y:550,t:1527268239933};\\\", \\\"{x:838,y:550,t:1527268239981};\\\", \\\"{x:835,y:550,t:1527268239998};\\\", \\\"{x:834,y:550,t:1527268240021};\\\", \\\"{x:834,y:548,t:1527268240086};\\\", \\\"{x:834,y:545,t:1527268240096};\\\", \\\"{x:833,y:538,t:1527268240114};\\\", \\\"{x:830,y:529,t:1527268240129};\\\", \\\"{x:821,y:518,t:1527268240145};\\\", \\\"{x:814,y:508,t:1527268240162};\\\", \\\"{x:811,y:502,t:1527268240179};\\\", \\\"{x:811,y:500,t:1527268240195};\\\", \\\"{x:813,y:496,t:1527268240212};\\\", \\\"{x:814,y:496,t:1527268240229};\\\", \\\"{x:814,y:495,t:1527268240246};\\\", \\\"{x:815,y:495,t:1527268240262};\\\", \\\"{x:819,y:494,t:1527268240279};\\\", \\\"{x:821,y:493,t:1527268240295};\\\", \\\"{x:823,y:492,t:1527268240312};\\\", \\\"{x:824,y:492,t:1527268240329};\\\", \\\"{x:825,y:492,t:1527268240345};\\\", \\\"{x:826,y:492,t:1527268240415};\\\", \\\"{x:827,y:492,t:1527268240429};\\\", \\\"{x:828,y:492,t:1527268240445};\\\", \\\"{x:828,y:493,t:1527268240486};\\\", \\\"{x:828,y:497,t:1527268240495};\\\", \\\"{x:829,y:504,t:1527268240512};\\\", \\\"{x:829,y:512,t:1527268240530};\\\", \\\"{x:829,y:519,t:1527268240545};\\\", \\\"{x:829,y:521,t:1527268240562};\\\", \\\"{x:829,y:522,t:1527268240606};\\\", \\\"{x:827,y:522,t:1527268240933};\\\", \\\"{x:823,y:525,t:1527268240947};\\\", \\\"{x:805,y:534,t:1527268240961};\\\", \\\"{x:760,y:562,t:1527268240979};\\\", \\\"{x:628,y:612,t:1527268240997};\\\", \\\"{x:466,y:656,t:1527268241012};\\\", \\\"{x:322,y:695,t:1527268241029};\\\", \\\"{x:164,y:761,t:1527268241045};\\\", \\\"{x:107,y:779,t:1527268241062};\\\", \\\"{x:79,y:787,t:1527268241079};\\\", \\\"{x:76,y:788,t:1527268241096};\\\", \\\"{x:78,y:789,t:1527268241142};\\\", \\\"{x:79,y:789,t:1527268241150};\\\", \\\"{x:83,y:790,t:1527268241163};\\\", \\\"{x:88,y:790,t:1527268241179};\\\", \\\"{x:93,y:790,t:1527268241196};\\\", \\\"{x:99,y:790,t:1527268241212};\\\", \\\"{x:116,y:790,t:1527268241229};\\\", \\\"{x:149,y:795,t:1527268241246};\\\", \\\"{x:197,y:798,t:1527268241263};\\\", \\\"{x:263,y:803,t:1527268241279};\\\", \\\"{x:316,y:803,t:1527268241296};\\\", \\\"{x:353,y:803,t:1527268241312};\\\", \\\"{x:380,y:802,t:1527268241329};\\\", \\\"{x:396,y:796,t:1527268241346};\\\", \\\"{x:401,y:793,t:1527268241363};\\\", \\\"{x:405,y:790,t:1527268241379};\\\", \\\"{x:410,y:786,t:1527268241396};\\\", \\\"{x:413,y:781,t:1527268241413};\\\", \\\"{x:415,y:780,t:1527268241429};\\\", \\\"{x:424,y:772,t:1527268241446};\\\", \\\"{x:433,y:765,t:1527268241463};\\\", \\\"{x:440,y:759,t:1527268241479};\\\", \\\"{x:445,y:751,t:1527268241496};\\\", \\\"{x:452,y:743,t:1527268241513};\\\", \\\"{x:456,y:736,t:1527268241530};\\\", \\\"{x:466,y:730,t:1527268241548};\\\", \\\"{x:477,y:723,t:1527268241563};\\\", \\\"{x:481,y:721,t:1527268241579};\\\", \\\"{x:485,y:719,t:1527268241595};\\\", \\\"{x:486,y:719,t:1527268241612};\\\", \\\"{x:487,y:719,t:1527268241628};\\\" ] }, { \\\"rt\\\": 57418, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 340673, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"967LR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 0, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -I -I -I \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:490,y:719,t:1527268243823};\\\", \\\"{x:494,y:717,t:1527268243833};\\\", \\\"{x:513,y:708,t:1527268243849};\\\", \\\"{x:540,y:700,t:1527268243865};\\\", \\\"{x:582,y:686,t:1527268243881};\\\", \\\"{x:635,y:672,t:1527268243899};\\\", \\\"{x:671,y:663,t:1527268243915};\\\", \\\"{x:703,y:653,t:1527268243931};\\\", \\\"{x:725,y:646,t:1527268243949};\\\", \\\"{x:744,y:639,t:1527268243965};\\\", \\\"{x:772,y:627,t:1527268243981};\\\", \\\"{x:787,y:621,t:1527268244000};\\\", \\\"{x:799,y:616,t:1527268244016};\\\", \\\"{x:806,y:614,t:1527268244031};\\\", \\\"{x:812,y:612,t:1527268244048};\\\", \\\"{x:813,y:612,t:1527268244150};\\\", \\\"{x:814,y:611,t:1527268244165};\\\", \\\"{x:815,y:611,t:1527268244198};\\\", \\\"{x:817,y:611,t:1527268244216};\\\", \\\"{x:828,y:608,t:1527268244232};\\\", \\\"{x:838,y:606,t:1527268244249};\\\", \\\"{x:855,y:603,t:1527268244266};\\\", \\\"{x:873,y:601,t:1527268244282};\\\", \\\"{x:880,y:600,t:1527268244299};\\\", \\\"{x:884,y:600,t:1527268244315};\\\", \\\"{x:893,y:600,t:1527268244332};\\\", \\\"{x:898,y:600,t:1527268244348};\\\", \\\"{x:899,y:600,t:1527268244366};\\\", \\\"{x:903,y:603,t:1527268245478};\\\", \\\"{x:913,y:607,t:1527268245486};\\\", \\\"{x:924,y:609,t:1527268245500};\\\", \\\"{x:955,y:619,t:1527268245517};\\\", \\\"{x:1008,y:635,t:1527268245533};\\\", \\\"{x:1116,y:662,t:1527268245549};\\\", \\\"{x:1214,y:679,t:1527268245566};\\\", \\\"{x:1319,y:693,t:1527268245583};\\\", \\\"{x:1430,y:714,t:1527268245599};\\\", \\\"{x:1557,y:741,t:1527268245616};\\\", \\\"{x:1685,y:764,t:1527268245633};\\\", \\\"{x:1825,y:799,t:1527268245649};\\\", \\\"{x:1919,y:830,t:1527268245666};\\\", \\\"{x:1919,y:859,t:1527268245683};\\\", \\\"{x:1919,y:890,t:1527268245700};\\\", \\\"{x:1919,y:917,t:1527268245716};\\\", \\\"{x:1919,y:953,t:1527268245734};\\\", \\\"{x:1919,y:965,t:1527268245749};\\\", \\\"{x:1919,y:989,t:1527268245766};\\\", \\\"{x:1919,y:996,t:1527268245784};\\\", \\\"{x:1919,y:998,t:1527268245799};\\\", \\\"{x:1918,y:998,t:1527268245902};\\\", \\\"{x:1913,y:997,t:1527268245916};\\\", \\\"{x:1887,y:987,t:1527268245935};\\\", \\\"{x:1857,y:979,t:1527268245950};\\\", \\\"{x:1814,y:964,t:1527268245966};\\\", \\\"{x:1761,y:948,t:1527268245984};\\\", \\\"{x:1706,y:937,t:1527268246000};\\\", \\\"{x:1654,y:924,t:1527268246016};\\\", \\\"{x:1613,y:914,t:1527268246033};\\\", \\\"{x:1566,y:902,t:1527268246050};\\\", \\\"{x:1525,y:893,t:1527268246067};\\\", \\\"{x:1485,y:887,t:1527268246084};\\\", \\\"{x:1441,y:881,t:1527268246101};\\\", \\\"{x:1404,y:876,t:1527268246117};\\\", \\\"{x:1376,y:870,t:1527268246134};\\\", \\\"{x:1363,y:867,t:1527268246150};\\\", \\\"{x:1362,y:867,t:1527268246166};\\\", \\\"{x:1361,y:865,t:1527268246184};\\\", \\\"{x:1361,y:863,t:1527268246201};\\\", \\\"{x:1362,y:858,t:1527268246217};\\\", \\\"{x:1364,y:855,t:1527268246234};\\\", \\\"{x:1367,y:852,t:1527268246251};\\\", \\\"{x:1367,y:851,t:1527268246267};\\\", \\\"{x:1369,y:850,t:1527268246283};\\\", \\\"{x:1372,y:847,t:1527268246301};\\\", \\\"{x:1374,y:846,t:1527268246317};\\\", \\\"{x:1376,y:844,t:1527268246334};\\\", \\\"{x:1380,y:843,t:1527268246351};\\\", \\\"{x:1382,y:841,t:1527268246367};\\\", \\\"{x:1386,y:838,t:1527268246384};\\\", \\\"{x:1389,y:836,t:1527268246401};\\\", \\\"{x:1391,y:833,t:1527268246417};\\\", \\\"{x:1395,y:827,t:1527268246434};\\\", \\\"{x:1400,y:819,t:1527268246451};\\\", \\\"{x:1405,y:811,t:1527268246467};\\\", \\\"{x:1408,y:800,t:1527268246484};\\\", \\\"{x:1410,y:795,t:1527268246501};\\\", \\\"{x:1411,y:789,t:1527268246518};\\\", \\\"{x:1411,y:788,t:1527268246534};\\\", \\\"{x:1410,y:786,t:1527268246639};\\\", \\\"{x:1409,y:786,t:1527268246651};\\\", \\\"{x:1405,y:785,t:1527268246668};\\\", \\\"{x:1403,y:785,t:1527268246684};\\\", \\\"{x:1401,y:785,t:1527268246701};\\\", \\\"{x:1400,y:785,t:1527268246718};\\\", \\\"{x:1399,y:785,t:1527268246798};\\\", \\\"{x:1396,y:784,t:1527268246807};\\\", \\\"{x:1391,y:783,t:1527268246818};\\\", \\\"{x:1383,y:782,t:1527268246834};\\\", \\\"{x:1374,y:780,t:1527268246851};\\\", \\\"{x:1368,y:780,t:1527268246868};\\\", \\\"{x:1362,y:778,t:1527268246884};\\\", \\\"{x:1360,y:777,t:1527268246901};\\\", \\\"{x:1354,y:774,t:1527268246918};\\\", \\\"{x:1348,y:772,t:1527268246935};\\\", \\\"{x:1343,y:769,t:1527268246951};\\\", \\\"{x:1336,y:768,t:1527268246968};\\\", \\\"{x:1333,y:768,t:1527268246985};\\\", \\\"{x:1331,y:767,t:1527268247000};\\\", \\\"{x:1328,y:766,t:1527268247018};\\\", \\\"{x:1326,y:766,t:1527268247035};\\\", \\\"{x:1323,y:765,t:1527268247050};\\\", \\\"{x:1320,y:765,t:1527268247068};\\\", \\\"{x:1318,y:765,t:1527268247084};\\\", \\\"{x:1318,y:764,t:1527268247101};\\\", \\\"{x:1317,y:764,t:1527268247159};\\\", \\\"{x:1316,y:764,t:1527268247168};\\\", \\\"{x:1315,y:764,t:1527268247186};\\\", \\\"{x:1311,y:765,t:1527268247201};\\\", \\\"{x:1306,y:766,t:1527268247218};\\\", \\\"{x:1299,y:771,t:1527268247235};\\\", \\\"{x:1292,y:774,t:1527268247251};\\\", \\\"{x:1288,y:777,t:1527268247268};\\\", \\\"{x:1282,y:782,t:1527268247285};\\\", \\\"{x:1280,y:785,t:1527268247302};\\\", \\\"{x:1278,y:789,t:1527268247318};\\\", \\\"{x:1277,y:791,t:1527268247335};\\\", \\\"{x:1278,y:789,t:1527268248414};\\\", \\\"{x:1278,y:786,t:1527268248422};\\\", \\\"{x:1279,y:784,t:1527268248436};\\\", \\\"{x:1281,y:778,t:1527268248453};\\\", \\\"{x:1282,y:773,t:1527268248469};\\\", \\\"{x:1283,y:764,t:1527268248486};\\\", \\\"{x:1283,y:757,t:1527268248503};\\\", \\\"{x:1283,y:749,t:1527268248519};\\\", \\\"{x:1283,y:737,t:1527268248536};\\\", \\\"{x:1283,y:721,t:1527268248552};\\\", \\\"{x:1283,y:705,t:1527268248569};\\\", \\\"{x:1283,y:685,t:1527268248586};\\\", \\\"{x:1287,y:663,t:1527268248603};\\\", \\\"{x:1291,y:638,t:1527268248619};\\\", \\\"{x:1298,y:615,t:1527268248636};\\\", \\\"{x:1303,y:586,t:1527268248653};\\\", \\\"{x:1310,y:558,t:1527268248669};\\\", \\\"{x:1320,y:518,t:1527268248687};\\\", \\\"{x:1332,y:494,t:1527268248702};\\\", \\\"{x:1338,y:475,t:1527268248719};\\\", \\\"{x:1345,y:463,t:1527268248736};\\\", \\\"{x:1347,y:460,t:1527268248753};\\\", \\\"{x:1347,y:459,t:1527268248769};\\\", \\\"{x:1346,y:460,t:1527268248895};\\\", \\\"{x:1345,y:460,t:1527268248902};\\\", \\\"{x:1342,y:462,t:1527268248919};\\\", \\\"{x:1337,y:466,t:1527268248936};\\\", \\\"{x:1334,y:471,t:1527268248953};\\\", \\\"{x:1333,y:476,t:1527268248969};\\\", \\\"{x:1331,y:482,t:1527268248986};\\\", \\\"{x:1331,y:490,t:1527268249003};\\\", \\\"{x:1331,y:498,t:1527268249019};\\\", \\\"{x:1331,y:504,t:1527268249036};\\\", \\\"{x:1331,y:513,t:1527268249054};\\\", \\\"{x:1331,y:518,t:1527268249069};\\\", \\\"{x:1339,y:530,t:1527268249086};\\\", \\\"{x:1348,y:535,t:1527268249102};\\\", \\\"{x:1355,y:538,t:1527268249121};\\\", \\\"{x:1358,y:538,t:1527268249136};\\\", \\\"{x:1358,y:537,t:1527268249270};\\\", \\\"{x:1353,y:534,t:1527268249286};\\\", \\\"{x:1349,y:530,t:1527268249303};\\\", \\\"{x:1348,y:529,t:1527268249320};\\\", \\\"{x:1346,y:527,t:1527268249336};\\\", \\\"{x:1345,y:526,t:1527268249353};\\\", \\\"{x:1343,y:525,t:1527268249370};\\\", \\\"{x:1341,y:524,t:1527268249387};\\\", \\\"{x:1337,y:523,t:1527268249543};\\\", \\\"{x:1333,y:523,t:1527268249553};\\\", \\\"{x:1327,y:520,t:1527268249570};\\\", \\\"{x:1325,y:519,t:1527268249587};\\\", \\\"{x:1324,y:519,t:1527268249678};\\\", \\\"{x:1322,y:519,t:1527268250822};\\\", \\\"{x:1321,y:519,t:1527268250837};\\\", \\\"{x:1320,y:522,t:1527268250854};\\\", \\\"{x:1320,y:526,t:1527268250871};\\\", \\\"{x:1318,y:531,t:1527268250888};\\\", \\\"{x:1317,y:536,t:1527268250904};\\\", \\\"{x:1316,y:541,t:1527268250921};\\\", \\\"{x:1314,y:548,t:1527268250938};\\\", \\\"{x:1311,y:557,t:1527268250954};\\\", \\\"{x:1306,y:569,t:1527268250971};\\\", \\\"{x:1302,y:579,t:1527268250988};\\\", \\\"{x:1295,y:590,t:1527268251004};\\\", \\\"{x:1288,y:598,t:1527268251021};\\\", \\\"{x:1283,y:605,t:1527268251038};\\\", \\\"{x:1283,y:606,t:1527268251054};\\\", \\\"{x:1283,y:608,t:1527268251072};\\\", \\\"{x:1282,y:609,t:1527268251088};\\\", \\\"{x:1282,y:610,t:1527268251105};\\\", \\\"{x:1282,y:613,t:1527268251121};\\\", \\\"{x:1282,y:616,t:1527268251138};\\\", \\\"{x:1282,y:618,t:1527268251154};\\\", \\\"{x:1282,y:620,t:1527268251171};\\\", \\\"{x:1282,y:623,t:1527268251189};\\\", \\\"{x:1282,y:626,t:1527268251205};\\\", \\\"{x:1283,y:628,t:1527268251221};\\\", \\\"{x:1286,y:634,t:1527268251238};\\\", \\\"{x:1287,y:636,t:1527268251255};\\\", \\\"{x:1288,y:639,t:1527268251271};\\\", \\\"{x:1290,y:643,t:1527268251288};\\\", \\\"{x:1291,y:647,t:1527268251306};\\\", \\\"{x:1293,y:650,t:1527268251320};\\\", \\\"{x:1295,y:655,t:1527268251338};\\\", \\\"{x:1297,y:659,t:1527268251355};\\\", \\\"{x:1299,y:663,t:1527268251371};\\\", \\\"{x:1301,y:668,t:1527268251387};\\\", \\\"{x:1301,y:670,t:1527268251404};\\\", \\\"{x:1303,y:673,t:1527268251420};\\\", \\\"{x:1305,y:676,t:1527268251437};\\\", \\\"{x:1306,y:677,t:1527268251455};\\\", \\\"{x:1307,y:678,t:1527268251477};\\\", \\\"{x:1308,y:680,t:1527268251501};\\\", \\\"{x:1309,y:682,t:1527268251510};\\\", \\\"{x:1310,y:683,t:1527268251521};\\\", \\\"{x:1311,y:686,t:1527268251537};\\\", \\\"{x:1313,y:690,t:1527268251555};\\\", \\\"{x:1314,y:694,t:1527268251571};\\\", \\\"{x:1315,y:698,t:1527268251588};\\\", \\\"{x:1316,y:701,t:1527268251605};\\\", \\\"{x:1318,y:704,t:1527268251621};\\\", \\\"{x:1320,y:711,t:1527268251639};\\\", \\\"{x:1321,y:718,t:1527268251656};\\\", \\\"{x:1322,y:723,t:1527268251673};\\\", \\\"{x:1326,y:731,t:1527268251688};\\\", \\\"{x:1329,y:736,t:1527268251705};\\\", \\\"{x:1329,y:740,t:1527268251723};\\\", \\\"{x:1329,y:746,t:1527268251738};\\\", \\\"{x:1329,y:752,t:1527268251755};\\\", \\\"{x:1329,y:759,t:1527268251772};\\\", \\\"{x:1330,y:763,t:1527268251788};\\\", \\\"{x:1331,y:766,t:1527268251805};\\\", \\\"{x:1331,y:772,t:1527268251822};\\\", \\\"{x:1332,y:773,t:1527268251839};\\\", \\\"{x:1332,y:775,t:1527268251856};\\\", \\\"{x:1332,y:777,t:1527268251872};\\\", \\\"{x:1332,y:778,t:1527268251902};\\\", \\\"{x:1332,y:779,t:1527268251918};\\\", \\\"{x:1332,y:780,t:1527268251935};\\\", \\\"{x:1332,y:781,t:1527268251942};\\\", \\\"{x:1332,y:782,t:1527268251955};\\\", \\\"{x:1331,y:785,t:1527268251973};\\\", \\\"{x:1331,y:786,t:1527268251988};\\\", \\\"{x:1330,y:789,t:1527268252005};\\\", \\\"{x:1330,y:791,t:1527268252022};\\\", \\\"{x:1329,y:793,t:1527268252039};\\\", \\\"{x:1328,y:795,t:1527268252057};\\\", \\\"{x:1328,y:798,t:1527268252072};\\\", \\\"{x:1326,y:801,t:1527268252089};\\\", \\\"{x:1325,y:805,t:1527268252105};\\\", \\\"{x:1324,y:807,t:1527268252122};\\\", \\\"{x:1324,y:812,t:1527268252139};\\\", \\\"{x:1322,y:816,t:1527268252155};\\\", \\\"{x:1322,y:822,t:1527268252172};\\\", \\\"{x:1322,y:830,t:1527268252190};\\\", \\\"{x:1321,y:844,t:1527268252206};\\\", \\\"{x:1321,y:858,t:1527268252222};\\\", \\\"{x:1321,y:864,t:1527268252238};\\\", \\\"{x:1321,y:865,t:1527268252256};\\\", \\\"{x:1321,y:867,t:1527268252272};\\\", \\\"{x:1321,y:868,t:1527268252294};\\\", \\\"{x:1321,y:870,t:1527268252326};\\\", \\\"{x:1321,y:871,t:1527268252342};\\\", \\\"{x:1319,y:872,t:1527268252355};\\\", \\\"{x:1319,y:873,t:1527268252372};\\\", \\\"{x:1318,y:875,t:1527268252389};\\\", \\\"{x:1318,y:876,t:1527268252405};\\\", \\\"{x:1317,y:878,t:1527268252422};\\\", \\\"{x:1316,y:879,t:1527268252439};\\\", \\\"{x:1313,y:883,t:1527268252457};\\\", \\\"{x:1312,y:885,t:1527268252472};\\\", \\\"{x:1310,y:890,t:1527268252489};\\\", \\\"{x:1308,y:897,t:1527268252506};\\\", \\\"{x:1308,y:902,t:1527268252522};\\\", \\\"{x:1307,y:907,t:1527268252539};\\\", \\\"{x:1307,y:910,t:1527268252556};\\\", \\\"{x:1307,y:912,t:1527268252574};\\\", \\\"{x:1307,y:914,t:1527268252591};\\\", \\\"{x:1307,y:916,t:1527268252614};\\\", \\\"{x:1305,y:916,t:1527268252710};\\\", \\\"{x:1303,y:916,t:1527268252722};\\\", \\\"{x:1303,y:913,t:1527268252739};\\\", \\\"{x:1303,y:910,t:1527268252756};\\\", \\\"{x:1303,y:903,t:1527268252773};\\\", \\\"{x:1303,y:894,t:1527268252790};\\\", \\\"{x:1303,y:869,t:1527268252807};\\\", \\\"{x:1303,y:842,t:1527268252822};\\\", \\\"{x:1303,y:814,t:1527268252839};\\\", \\\"{x:1303,y:780,t:1527268252856};\\\", \\\"{x:1303,y:744,t:1527268252872};\\\", \\\"{x:1303,y:716,t:1527268252889};\\\", \\\"{x:1303,y:687,t:1527268252905};\\\", \\\"{x:1303,y:657,t:1527268252921};\\\", \\\"{x:1303,y:630,t:1527268252939};\\\", \\\"{x:1303,y:604,t:1527268252956};\\\", \\\"{x:1300,y:581,t:1527268252972};\\\", \\\"{x:1299,y:558,t:1527268252989};\\\", \\\"{x:1299,y:530,t:1527268253005};\\\", \\\"{x:1302,y:515,t:1527268253023};\\\", \\\"{x:1311,y:500,t:1527268253039};\\\", \\\"{x:1315,y:491,t:1527268253055};\\\", \\\"{x:1317,y:487,t:1527268253074};\\\", \\\"{x:1318,y:485,t:1527268253088};\\\", \\\"{x:1319,y:484,t:1527268253199};\\\", \\\"{x:1318,y:484,t:1527268253558};\\\", \\\"{x:1318,y:485,t:1527268253573};\\\", \\\"{x:1317,y:485,t:1527268253590};\\\", \\\"{x:1316,y:486,t:1527268253606};\\\", \\\"{x:1315,y:487,t:1527268253703};\\\", \\\"{x:1314,y:488,t:1527268253725};\\\", \\\"{x:1313,y:489,t:1527268253741};\\\", \\\"{x:1306,y:492,t:1527268254230};\\\", \\\"{x:1296,y:498,t:1527268254240};\\\", \\\"{x:1284,y:505,t:1527268254258};\\\", \\\"{x:1282,y:505,t:1527268254274};\\\", \\\"{x:1281,y:506,t:1527268254855};\\\", \\\"{x:1280,y:506,t:1527268255085};\\\", \\\"{x:1283,y:504,t:1527268255149};\\\", \\\"{x:1292,y:501,t:1527268255157};\\\", \\\"{x:1309,y:498,t:1527268255173};\\\", \\\"{x:1317,y:494,t:1527268255191};\\\", \\\"{x:1318,y:494,t:1527268255208};\\\", \\\"{x:1319,y:494,t:1527268255253};\\\", \\\"{x:1320,y:494,t:1527268255262};\\\", \\\"{x:1322,y:493,t:1527268255274};\\\", \\\"{x:1323,y:492,t:1527268255291};\\\", \\\"{x:1323,y:493,t:1527268255783};\\\", \\\"{x:1322,y:494,t:1527268255791};\\\", \\\"{x:1317,y:495,t:1527268255809};\\\", \\\"{x:1312,y:496,t:1527268255825};\\\", \\\"{x:1307,y:499,t:1527268255842};\\\", \\\"{x:1304,y:506,t:1527268255858};\\\", \\\"{x:1304,y:510,t:1527268255876};\\\", \\\"{x:1305,y:511,t:1527268256214};\\\", \\\"{x:1307,y:511,t:1527268256225};\\\", \\\"{x:1311,y:509,t:1527268256242};\\\", \\\"{x:1315,y:506,t:1527268256259};\\\", \\\"{x:1317,y:504,t:1527268256275};\\\", \\\"{x:1317,y:503,t:1527268256292};\\\", \\\"{x:1318,y:502,t:1527268256309};\\\", \\\"{x:1318,y:501,t:1527268256325};\\\", \\\"{x:1318,y:500,t:1527268256390};\\\", \\\"{x:1318,y:495,t:1527268256398};\\\", \\\"{x:1319,y:488,t:1527268256409};\\\", \\\"{x:1321,y:479,t:1527268256426};\\\", \\\"{x:1321,y:470,t:1527268256442};\\\", \\\"{x:1321,y:461,t:1527268256459};\\\", \\\"{x:1321,y:453,t:1527268256475};\\\", \\\"{x:1320,y:448,t:1527268256492};\\\", \\\"{x:1321,y:442,t:1527268256509};\\\", \\\"{x:1322,y:436,t:1527268256526};\\\", \\\"{x:1329,y:428,t:1527268256542};\\\", \\\"{x:1334,y:425,t:1527268256560};\\\", \\\"{x:1336,y:423,t:1527268256575};\\\", \\\"{x:1337,y:423,t:1527268256599};\\\", \\\"{x:1337,y:422,t:1527268256630};\\\", \\\"{x:1338,y:420,t:1527268256643};\\\", \\\"{x:1341,y:419,t:1527268256659};\\\", \\\"{x:1347,y:416,t:1527268256676};\\\", \\\"{x:1349,y:416,t:1527268256693};\\\", \\\"{x:1350,y:416,t:1527268256709};\\\", \\\"{x:1352,y:414,t:1527268256750};\\\", \\\"{x:1354,y:413,t:1527268256766};\\\", \\\"{x:1355,y:413,t:1527268257183};\\\", \\\"{x:1355,y:414,t:1527268257192};\\\", \\\"{x:1356,y:420,t:1527268257210};\\\", \\\"{x:1356,y:426,t:1527268257226};\\\", \\\"{x:1356,y:431,t:1527268257243};\\\", \\\"{x:1358,y:434,t:1527268257259};\\\", \\\"{x:1358,y:436,t:1527268257276};\\\", \\\"{x:1359,y:439,t:1527268257293};\\\", \\\"{x:1359,y:442,t:1527268257309};\\\", \\\"{x:1359,y:445,t:1527268257327};\\\", \\\"{x:1359,y:446,t:1527268257518};\\\", \\\"{x:1359,y:449,t:1527268257527};\\\", \\\"{x:1359,y:456,t:1527268257543};\\\", \\\"{x:1360,y:461,t:1527268257560};\\\", \\\"{x:1360,y:467,t:1527268257576};\\\", \\\"{x:1363,y:473,t:1527268257593};\\\", \\\"{x:1364,y:479,t:1527268257609};\\\", \\\"{x:1367,y:484,t:1527268257626};\\\", \\\"{x:1367,y:488,t:1527268257643};\\\", \\\"{x:1369,y:495,t:1527268257660};\\\", \\\"{x:1370,y:496,t:1527268257676};\\\", \\\"{x:1371,y:500,t:1527268257694};\\\", \\\"{x:1372,y:501,t:1527268257917};\\\", \\\"{x:1373,y:501,t:1527268257926};\\\", \\\"{x:1376,y:501,t:1527268257943};\\\", \\\"{x:1379,y:501,t:1527268257959};\\\", \\\"{x:1383,y:498,t:1527268257976};\\\", \\\"{x:1385,y:498,t:1527268257993};\\\", \\\"{x:1386,y:498,t:1527268258009};\\\", \\\"{x:1383,y:498,t:1527268258263};\\\", \\\"{x:1382,y:498,t:1527268258277};\\\", \\\"{x:1377,y:499,t:1527268258294};\\\", \\\"{x:1375,y:500,t:1527268258310};\\\", \\\"{x:1374,y:501,t:1527268258327};\\\", \\\"{x:1375,y:501,t:1527268258543};\\\", \\\"{x:1376,y:501,t:1527268258560};\\\", \\\"{x:1378,y:501,t:1527268258578};\\\", \\\"{x:1379,y:501,t:1527268258703};\\\", \\\"{x:1380,y:500,t:1527268258710};\\\", \\\"{x:1381,y:500,t:1527268258727};\\\", \\\"{x:1382,y:500,t:1527268258745};\\\", \\\"{x:1383,y:499,t:1527268258863};\\\", \\\"{x:1384,y:499,t:1527268258878};\\\", \\\"{x:1390,y:497,t:1527268258894};\\\", \\\"{x:1397,y:495,t:1527268258911};\\\", \\\"{x:1401,y:494,t:1527268258928};\\\", \\\"{x:1409,y:492,t:1527268258944};\\\", \\\"{x:1415,y:489,t:1527268258960};\\\", \\\"{x:1416,y:489,t:1527268258977};\\\", \\\"{x:1417,y:489,t:1527268258995};\\\", \\\"{x:1419,y:489,t:1527268259110};\\\", \\\"{x:1424,y:487,t:1527268259127};\\\", \\\"{x:1431,y:485,t:1527268259144};\\\", \\\"{x:1438,y:482,t:1527268259162};\\\", \\\"{x:1440,y:482,t:1527268259178};\\\", \\\"{x:1442,y:482,t:1527268259222};\\\", \\\"{x:1443,y:481,t:1527268259230};\\\", \\\"{x:1447,y:481,t:1527268259244};\\\", \\\"{x:1468,y:487,t:1527268259260};\\\", \\\"{x:1492,y:497,t:1527268259276};\\\", \\\"{x:1516,y:510,t:1527268259292};\\\", \\\"{x:1519,y:512,t:1527268259309};\\\", \\\"{x:1519,y:515,t:1527268259325};\\\", \\\"{x:1514,y:519,t:1527268259343};\\\", \\\"{x:1509,y:521,t:1527268259360};\\\", \\\"{x:1506,y:523,t:1527268259375};\\\", \\\"{x:1505,y:523,t:1527268259393};\\\", \\\"{x:1504,y:523,t:1527268259452};\\\", \\\"{x:1502,y:523,t:1527268259460};\\\", \\\"{x:1499,y:525,t:1527268259475};\\\", \\\"{x:1496,y:526,t:1527268259492};\\\", \\\"{x:1494,y:526,t:1527268259509};\\\", \\\"{x:1492,y:526,t:1527268259524};\\\", \\\"{x:1489,y:527,t:1527268259541};\\\", \\\"{x:1486,y:528,t:1527268259559};\\\", \\\"{x:1483,y:529,t:1527268259576};\\\", \\\"{x:1479,y:530,t:1527268259592};\\\", \\\"{x:1477,y:530,t:1527268259609};\\\", \\\"{x:1476,y:531,t:1527268259626};\\\", \\\"{x:1475,y:531,t:1527268259643};\\\", \\\"{x:1474,y:531,t:1527268259668};\\\", \\\"{x:1473,y:531,t:1527268259676};\\\", \\\"{x:1472,y:531,t:1527268259707};\\\", \\\"{x:1469,y:531,t:1527268259715};\\\", \\\"{x:1467,y:531,t:1527268259732};\\\", \\\"{x:1465,y:529,t:1527268259742};\\\", \\\"{x:1463,y:528,t:1527268259759};\\\", \\\"{x:1462,y:526,t:1527268259988};\\\", \\\"{x:1462,y:524,t:1527268259996};\\\", \\\"{x:1462,y:522,t:1527268260009};\\\", \\\"{x:1458,y:518,t:1527268260026};\\\", \\\"{x:1454,y:516,t:1527268260042};\\\", \\\"{x:1451,y:514,t:1527268260059};\\\", \\\"{x:1452,y:513,t:1527268260099};\\\", \\\"{x:1457,y:510,t:1527268260108};\\\", \\\"{x:1469,y:504,t:1527268260126};\\\", \\\"{x:1474,y:500,t:1527268260143};\\\", \\\"{x:1478,y:497,t:1527268260159};\\\", \\\"{x:1479,y:497,t:1527268260176};\\\", \\\"{x:1478,y:496,t:1527268260317};\\\", \\\"{x:1475,y:496,t:1527268260326};\\\", \\\"{x:1471,y:497,t:1527268260343};\\\", \\\"{x:1465,y:499,t:1527268260359};\\\", \\\"{x:1464,y:499,t:1527268260376};\\\", \\\"{x:1463,y:500,t:1527268260393};\\\", \\\"{x:1461,y:500,t:1527268260452};\\\", \\\"{x:1460,y:501,t:1527268260460};\\\", \\\"{x:1459,y:501,t:1527268260476};\\\", \\\"{x:1458,y:501,t:1527268260492};\\\", \\\"{x:1457,y:501,t:1527268260571};\\\", \\\"{x:1454,y:501,t:1527268260579};\\\", \\\"{x:1452,y:501,t:1527268260592};\\\", \\\"{x:1447,y:501,t:1527268260609};\\\", \\\"{x:1443,y:501,t:1527268260626};\\\", \\\"{x:1443,y:500,t:1527268260700};\\\", \\\"{x:1444,y:499,t:1527268260732};\\\", \\\"{x:1445,y:499,t:1527268260764};\\\", \\\"{x:1446,y:499,t:1527268260777};\\\", \\\"{x:1447,y:498,t:1527268260793};\\\", \\\"{x:1448,y:497,t:1527268260811};\\\", \\\"{x:1449,y:497,t:1527268260827};\\\", \\\"{x:1447,y:497,t:1527268261268};\\\", \\\"{x:1446,y:497,t:1527268261284};\\\", \\\"{x:1446,y:496,t:1527268261757};\\\", \\\"{x:1448,y:496,t:1527268261788};\\\", \\\"{x:1449,y:495,t:1527268261797};\\\", \\\"{x:1450,y:494,t:1527268261812};\\\", \\\"{x:1452,y:493,t:1527268261828};\\\", \\\"{x:1454,y:493,t:1527268261845};\\\", \\\"{x:1456,y:492,t:1527268261861};\\\", \\\"{x:1456,y:491,t:1527268261878};\\\", \\\"{x:1457,y:491,t:1527268261895};\\\", \\\"{x:1458,y:490,t:1527268261916};\\\", \\\"{x:1459,y:490,t:1527268261972};\\\", \\\"{x:1459,y:489,t:1527268261988};\\\", \\\"{x:1460,y:488,t:1527268261996};\\\", \\\"{x:1462,y:487,t:1527268262012};\\\", \\\"{x:1464,y:486,t:1527268262028};\\\", \\\"{x:1465,y:485,t:1527268262044};\\\", \\\"{x:1465,y:484,t:1527268262062};\\\", \\\"{x:1467,y:483,t:1527268262078};\\\", \\\"{x:1470,y:482,t:1527268262094};\\\", \\\"{x:1472,y:481,t:1527268262111};\\\", \\\"{x:1474,y:481,t:1527268262128};\\\", \\\"{x:1476,y:480,t:1527268262145};\\\", \\\"{x:1478,y:479,t:1527268262162};\\\", \\\"{x:1481,y:478,t:1527268262179};\\\", \\\"{x:1485,y:475,t:1527268262195};\\\", \\\"{x:1487,y:475,t:1527268262211};\\\", \\\"{x:1488,y:475,t:1527268262229};\\\", \\\"{x:1490,y:475,t:1527268262276};\\\", \\\"{x:1490,y:474,t:1527268262283};\\\", \\\"{x:1491,y:474,t:1527268262300};\\\", \\\"{x:1492,y:474,t:1527268262316};\\\", \\\"{x:1493,y:473,t:1527268262332};\\\", \\\"{x:1493,y:472,t:1527268262413};\\\", \\\"{x:1494,y:472,t:1527268262428};\\\", \\\"{x:1497,y:471,t:1527268262445};\\\", \\\"{x:1498,y:471,t:1527268262462};\\\", \\\"{x:1500,y:471,t:1527268262717};\\\", \\\"{x:1503,y:475,t:1527268262729};\\\", \\\"{x:1511,y:482,t:1527268262745};\\\", \\\"{x:1516,y:487,t:1527268262762};\\\", \\\"{x:1523,y:492,t:1527268262779};\\\", \\\"{x:1526,y:496,t:1527268262796};\\\", \\\"{x:1529,y:498,t:1527268262812};\\\", \\\"{x:1529,y:499,t:1527268262829};\\\", \\\"{x:1529,y:500,t:1527268262955};\\\", \\\"{x:1529,y:501,t:1527268262962};\\\", \\\"{x:1526,y:501,t:1527268262978};\\\", \\\"{x:1517,y:501,t:1527268262995};\\\", \\\"{x:1514,y:501,t:1527268263011};\\\", \\\"{x:1515,y:501,t:1527268264100};\\\", \\\"{x:1516,y:501,t:1527268264116};\\\", \\\"{x:1518,y:501,t:1527268264130};\\\", \\\"{x:1520,y:501,t:1527268264146};\\\", \\\"{x:1522,y:499,t:1527268264162};\\\", \\\"{x:1524,y:497,t:1527268264180};\\\", \\\"{x:1529,y:493,t:1527268264196};\\\", \\\"{x:1538,y:490,t:1527268264212};\\\", \\\"{x:1547,y:488,t:1527268264230};\\\", \\\"{x:1553,y:486,t:1527268264246};\\\", \\\"{x:1558,y:485,t:1527268264262};\\\", \\\"{x:1560,y:484,t:1527268264279};\\\", \\\"{x:1562,y:484,t:1527268264297};\\\", \\\"{x:1563,y:483,t:1527268264324};\\\", \\\"{x:1564,y:483,t:1527268264628};\\\", \\\"{x:1566,y:483,t:1527268264652};\\\", \\\"{x:1567,y:483,t:1527268264663};\\\", \\\"{x:1569,y:483,t:1527268264680};\\\", \\\"{x:1571,y:483,t:1527268264697};\\\", \\\"{x:1574,y:483,t:1527268264714};\\\", \\\"{x:1580,y:484,t:1527268264730};\\\", \\\"{x:1586,y:485,t:1527268264747};\\\", \\\"{x:1592,y:487,t:1527268264764};\\\", \\\"{x:1597,y:488,t:1527268264780};\\\", \\\"{x:1599,y:490,t:1527268264797};\\\", \\\"{x:1599,y:491,t:1527268264853};\\\", \\\"{x:1599,y:492,t:1527268264892};\\\", \\\"{x:1598,y:493,t:1527268264932};\\\", \\\"{x:1597,y:493,t:1527268264947};\\\", \\\"{x:1594,y:493,t:1527268264964};\\\", \\\"{x:1592,y:494,t:1527268264980};\\\", \\\"{x:1591,y:494,t:1527268264996};\\\", \\\"{x:1590,y:494,t:1527268265044};\\\", \\\"{x:1589,y:494,t:1527268265060};\\\", \\\"{x:1588,y:494,t:1527268265068};\\\", \\\"{x:1586,y:496,t:1527268265084};\\\", \\\"{x:1584,y:496,t:1527268265097};\\\", \\\"{x:1581,y:498,t:1527268265114};\\\", \\\"{x:1579,y:498,t:1527268265130};\\\", \\\"{x:1580,y:498,t:1527268266365};\\\", \\\"{x:1581,y:498,t:1527268266484};\\\", \\\"{x:1581,y:497,t:1527268266498};\\\", \\\"{x:1581,y:496,t:1527268266524};\\\", \\\"{x:1582,y:495,t:1527268266532};\\\", \\\"{x:1582,y:494,t:1527268266900};\\\", \\\"{x:1584,y:493,t:1527268266915};\\\", \\\"{x:1587,y:490,t:1527268266932};\\\", \\\"{x:1587,y:487,t:1527268267668};\\\", \\\"{x:1587,y:486,t:1527268267683};\\\", \\\"{x:1586,y:485,t:1527268267698};\\\", \\\"{x:1585,y:485,t:1527268269460};\\\", \\\"{x:1584,y:487,t:1527268269475};\\\", \\\"{x:1584,y:488,t:1527268269483};\\\", \\\"{x:1583,y:490,t:1527268269501};\\\", \\\"{x:1583,y:491,t:1527268269517};\\\", \\\"{x:1583,y:492,t:1527268269534};\\\", \\\"{x:1583,y:493,t:1527268269551};\\\", \\\"{x:1583,y:494,t:1527268269901};\\\", \\\"{x:1583,y:495,t:1527268269917};\\\", \\\"{x:1583,y:496,t:1527268269934};\\\", \\\"{x:1583,y:497,t:1527268269951};\\\", \\\"{x:1583,y:498,t:1527268269971};\\\", \\\"{x:1583,y:499,t:1527268270131};\\\", \\\"{x:1582,y:500,t:1527268273620};\\\", \\\"{x:1584,y:500,t:1527268279875};\\\", \\\"{x:1585,y:500,t:1527268279948};\\\", \\\"{x:1586,y:499,t:1527268279960};\\\", \\\"{x:1587,y:499,t:1527268279980};\\\", \\\"{x:1588,y:498,t:1527268280003};\\\", \\\"{x:1588,y:497,t:1527268280011};\\\", \\\"{x:1588,y:497,t:1527268283004};\\\", \\\"{x:1583,y:496,t:1527268286020};\\\", \\\"{x:1528,y:486,t:1527268286031};\\\", \\\"{x:1309,y:476,t:1527268286048};\\\", \\\"{x:1073,y:499,t:1527268286064};\\\", \\\"{x:924,y:515,t:1527268286081};\\\", \\\"{x:859,y:517,t:1527268286097};\\\", \\\"{x:829,y:519,t:1527268286114};\\\", \\\"{x:802,y:519,t:1527268286130};\\\", \\\"{x:766,y:515,t:1527268286147};\\\", \\\"{x:758,y:514,t:1527268286163};\\\", \\\"{x:754,y:514,t:1527268286180};\\\", \\\"{x:752,y:514,t:1527268286197};\\\", \\\"{x:751,y:514,t:1527268286213};\\\", \\\"{x:750,y:514,t:1527268286230};\\\", \\\"{x:749,y:512,t:1527268286452};\\\", \\\"{x:749,y:511,t:1527268286465};\\\", \\\"{x:749,y:500,t:1527268286480};\\\", \\\"{x:740,y:489,t:1527268286498};\\\", \\\"{x:738,y:488,t:1527268286514};\\\", \\\"{x:724,y:493,t:1527268286530};\\\", \\\"{x:710,y:534,t:1527268286548};\\\", \\\"{x:699,y:570,t:1527268286564};\\\", \\\"{x:671,y:632,t:1527268286597};\\\", \\\"{x:655,y:666,t:1527268286614};\\\", \\\"{x:633,y:693,t:1527268286631};\\\", \\\"{x:629,y:696,t:1527268286647};\\\", \\\"{x:633,y:696,t:1527268287724};\\\", \\\"{x:642,y:693,t:1527268287732};\\\", \\\"{x:655,y:684,t:1527268287749};\\\", \\\"{x:671,y:673,t:1527268287765};\\\", \\\"{x:687,y:661,t:1527268287783};\\\", \\\"{x:705,y:649,t:1527268287798};\\\", \\\"{x:723,y:639,t:1527268287815};\\\", \\\"{x:742,y:632,t:1527268287832};\\\", \\\"{x:767,y:622,t:1527268287849};\\\", \\\"{x:804,y:613,t:1527268287864};\\\", \\\"{x:862,y:605,t:1527268287882};\\\", \\\"{x:982,y:605,t:1527268287898};\\\", \\\"{x:1071,y:601,t:1527268287914};\\\", \\\"{x:1138,y:593,t:1527268287932};\\\", \\\"{x:1177,y:593,t:1527268287949};\\\", \\\"{x:1192,y:592,t:1527268287965};\\\", \\\"{x:1196,y:590,t:1527268287982};\\\", \\\"{x:1197,y:590,t:1527268287998};\\\", \\\"{x:1200,y:589,t:1527268288015};\\\", \\\"{x:1207,y:587,t:1527268288032};\\\", \\\"{x:1220,y:584,t:1527268288048};\\\", \\\"{x:1234,y:583,t:1527268288065};\\\", \\\"{x:1240,y:583,t:1527268288081};\\\", \\\"{x:1252,y:583,t:1527268288099};\\\", \\\"{x:1309,y:575,t:1527268288115};\\\", \\\"{x:1375,y:575,t:1527268288132};\\\", \\\"{x:1421,y:583,t:1527268288149};\\\", \\\"{x:1444,y:597,t:1527268288165};\\\", \\\"{x:1448,y:599,t:1527268288182};\\\", \\\"{x:1457,y:605,t:1527268288199};\\\", \\\"{x:1457,y:606,t:1527268288215};\\\", \\\"{x:1456,y:606,t:1527268288356};\\\", \\\"{x:1455,y:606,t:1527268288372};\\\", \\\"{x:1454,y:608,t:1527268288383};\\\", \\\"{x:1453,y:608,t:1527268288399};\\\", \\\"{x:1452,y:608,t:1527268288417};\\\", \\\"{x:1450,y:609,t:1527268288432};\\\", \\\"{x:1448,y:610,t:1527268288449};\\\", \\\"{x:1446,y:610,t:1527268288467};\\\", \\\"{x:1444,y:610,t:1527268289108};\\\", \\\"{x:1441,y:610,t:1527268289116};\\\", \\\"{x:1438,y:609,t:1527268289134};\\\", \\\"{x:1434,y:608,t:1527268289150};\\\", \\\"{x:1429,y:608,t:1527268289167};\\\", \\\"{x:1424,y:607,t:1527268289183};\\\", \\\"{x:1416,y:607,t:1527268289201};\\\", \\\"{x:1406,y:607,t:1527268289216};\\\", \\\"{x:1396,y:607,t:1527268289233};\\\", \\\"{x:1391,y:606,t:1527268289251};\\\", \\\"{x:1376,y:577,t:1527268289266};\\\", \\\"{x:1352,y:513,t:1527268289283};\\\", \\\"{x:1347,y:502,t:1527268289300};\\\", \\\"{x:1346,y:501,t:1527268289317};\\\", \\\"{x:1345,y:501,t:1527268289364};\\\", \\\"{x:1343,y:501,t:1527268289372};\\\", \\\"{x:1341,y:501,t:1527268289383};\\\", \\\"{x:1339,y:503,t:1527268289400};\\\", \\\"{x:1338,y:503,t:1527268289416};\\\", \\\"{x:1336,y:504,t:1527268289467};\\\", \\\"{x:1326,y:509,t:1527268289483};\\\", \\\"{x:1302,y:513,t:1527268289500};\\\", \\\"{x:1262,y:517,t:1527268289516};\\\", \\\"{x:1232,y:517,t:1527268289533};\\\", \\\"{x:1203,y:518,t:1527268289550};\\\", \\\"{x:1195,y:518,t:1527268289566};\\\", \\\"{x:1192,y:518,t:1527268289700};\\\", \\\"{x:1190,y:518,t:1527268289718};\\\", \\\"{x:1186,y:521,t:1527268289734};\\\", \\\"{x:1182,y:524,t:1527268289750};\\\", \\\"{x:1177,y:526,t:1527268289767};\\\", \\\"{x:1173,y:527,t:1527268289783};\\\", \\\"{x:1171,y:527,t:1527268289801};\\\", \\\"{x:1170,y:527,t:1527268289818};\\\", \\\"{x:1169,y:529,t:1527268289876};\\\", \\\"{x:1166,y:529,t:1527268289892};\\\", \\\"{x:1164,y:529,t:1527268289907};\\\", \\\"{x:1163,y:530,t:1527268289917};\\\", \\\"{x:1156,y:533,t:1527268289934};\\\", \\\"{x:1153,y:534,t:1527268289950};\\\", \\\"{x:1151,y:535,t:1527268289968};\\\", \\\"{x:1151,y:536,t:1527268289984};\\\", \\\"{x:1152,y:536,t:1527268290220};\\\", \\\"{x:1155,y:536,t:1527268290234};\\\", \\\"{x:1156,y:536,t:1527268290251};\\\", \\\"{x:1157,y:536,t:1527268290436};\\\", \\\"{x:1158,y:537,t:1527268290620};\\\", \\\"{x:1159,y:539,t:1527268290635};\\\", \\\"{x:1161,y:543,t:1527268290651};\\\", \\\"{x:1162,y:545,t:1527268290668};\\\", \\\"{x:1170,y:552,t:1527268290685};\\\", \\\"{x:1182,y:562,t:1527268290701};\\\", \\\"{x:1193,y:571,t:1527268290717};\\\", \\\"{x:1210,y:585,t:1527268290735};\\\", \\\"{x:1226,y:604,t:1527268290752};\\\", \\\"{x:1242,y:625,t:1527268290767};\\\", \\\"{x:1254,y:647,t:1527268290785};\\\", \\\"{x:1260,y:668,t:1527268290801};\\\", \\\"{x:1264,y:681,t:1527268290817};\\\", \\\"{x:1267,y:693,t:1527268290834};\\\", \\\"{x:1269,y:696,t:1527268290851};\\\", \\\"{x:1270,y:697,t:1527268290867};\\\", \\\"{x:1271,y:698,t:1527268290884};\\\", \\\"{x:1272,y:698,t:1527268290907};\\\", \\\"{x:1272,y:699,t:1527268290917};\\\", \\\"{x:1275,y:701,t:1527268290934};\\\", \\\"{x:1278,y:704,t:1527268290951};\\\", \\\"{x:1280,y:706,t:1527268290967};\\\", \\\"{x:1281,y:706,t:1527268290984};\\\", \\\"{x:1282,y:704,t:1527268291172};\\\", \\\"{x:1282,y:700,t:1527268291184};\\\", \\\"{x:1285,y:687,t:1527268291202};\\\", \\\"{x:1286,y:673,t:1527268291218};\\\", \\\"{x:1288,y:659,t:1527268291234};\\\", \\\"{x:1295,y:637,t:1527268291251};\\\", \\\"{x:1297,y:626,t:1527268291269};\\\", \\\"{x:1299,y:620,t:1527268291285};\\\", \\\"{x:1299,y:619,t:1527268291301};\\\", \\\"{x:1299,y:618,t:1527268291318};\\\", \\\"{x:1300,y:616,t:1527268291355};\\\", \\\"{x:1300,y:614,t:1527268291388};\\\", \\\"{x:1302,y:612,t:1527268291401};\\\", \\\"{x:1302,y:610,t:1527268291419};\\\", \\\"{x:1303,y:609,t:1527268291434};\\\", \\\"{x:1304,y:609,t:1527268291468};\\\", \\\"{x:1304,y:610,t:1527268291620};\\\", \\\"{x:1302,y:614,t:1527268291635};\\\", \\\"{x:1302,y:616,t:1527268291652};\\\", \\\"{x:1302,y:618,t:1527268291796};\\\", \\\"{x:1302,y:619,t:1527268291803};\\\", \\\"{x:1302,y:620,t:1527268291819};\\\", \\\"{x:1300,y:624,t:1527268291835};\\\", \\\"{x:1299,y:626,t:1527268291852};\\\", \\\"{x:1298,y:630,t:1527268291869};\\\", \\\"{x:1298,y:632,t:1527268291886};\\\", \\\"{x:1297,y:635,t:1527268291902};\\\", \\\"{x:1297,y:636,t:1527268291908};\\\", \\\"{x:1297,y:637,t:1527268291918};\\\", \\\"{x:1296,y:643,t:1527268291935};\\\", \\\"{x:1295,y:649,t:1527268291952};\\\", \\\"{x:1295,y:656,t:1527268291967};\\\", \\\"{x:1294,y:663,t:1527268291985};\\\", \\\"{x:1294,y:668,t:1527268292001};\\\", \\\"{x:1293,y:675,t:1527268292019};\\\", \\\"{x:1293,y:678,t:1527268292035};\\\", \\\"{x:1293,y:681,t:1527268292052};\\\", \\\"{x:1292,y:684,t:1527268292068};\\\", \\\"{x:1289,y:688,t:1527268292085};\\\", \\\"{x:1288,y:690,t:1527268292103};\\\", \\\"{x:1287,y:692,t:1527268292118};\\\", \\\"{x:1286,y:693,t:1527268292135};\\\", \\\"{x:1285,y:695,t:1527268292152};\\\", \\\"{x:1285,y:695,t:1527268292180};\\\", \\\"{x:1285,y:693,t:1527268292443};\\\", \\\"{x:1285,y:691,t:1527268292453};\\\", \\\"{x:1285,y:686,t:1527268292469};\\\", \\\"{x:1286,y:682,t:1527268292486};\\\", \\\"{x:1287,y:679,t:1527268292502};\\\", \\\"{x:1289,y:676,t:1527268292520};\\\", \\\"{x:1290,y:674,t:1527268292535};\\\", \\\"{x:1290,y:673,t:1527268292552};\\\", \\\"{x:1291,y:672,t:1527268292570};\\\", \\\"{x:1291,y:670,t:1527268292587};\\\", \\\"{x:1293,y:666,t:1527268292603};\\\", \\\"{x:1295,y:658,t:1527268292619};\\\", \\\"{x:1296,y:650,t:1527268292635};\\\", \\\"{x:1298,y:646,t:1527268292653};\\\", \\\"{x:1300,y:641,t:1527268292670};\\\", \\\"{x:1300,y:640,t:1527268292686};\\\", \\\"{x:1301,y:639,t:1527268292703};\\\", \\\"{x:1302,y:638,t:1527268292719};\\\", \\\"{x:1302,y:636,t:1527268292735};\\\", \\\"{x:1304,y:633,t:1527268292753};\\\", \\\"{x:1305,y:633,t:1527268292770};\\\", \\\"{x:1305,y:631,t:1527268292785};\\\", \\\"{x:1306,y:630,t:1527268292899};\\\", \\\"{x:1306,y:633,t:1527268293780};\\\", \\\"{x:1306,y:638,t:1527268293803};\\\", \\\"{x:1306,y:640,t:1527268293819};\\\", \\\"{x:1306,y:640,t:1527268294413};\\\", \\\"{x:1310,y:649,t:1527268297084};\\\", \\\"{x:1322,y:663,t:1527268297092};\\\", \\\"{x:1328,y:673,t:1527268297107};\\\", \\\"{x:1337,y:691,t:1527268297124};\\\", \\\"{x:1338,y:695,t:1527268297139};\\\", \\\"{x:1340,y:697,t:1527268297156};\\\", \\\"{x:1340,y:698,t:1527268298963};\\\", \\\"{x:1340,y:698,t:1527268299277};\\\", \\\"{x:1339,y:700,t:1527268299347};\\\", \\\"{x:1336,y:701,t:1527268299359};\\\", \\\"{x:1332,y:703,t:1527268299375};\\\", \\\"{x:1327,y:705,t:1527268299392};\\\", \\\"{x:1322,y:707,t:1527268299409};\\\", \\\"{x:1316,y:708,t:1527268299424};\\\", \\\"{x:1307,y:708,t:1527268299442};\\\", \\\"{x:1285,y:708,t:1527268299458};\\\", \\\"{x:1278,y:708,t:1527268299475};\\\", \\\"{x:1252,y:707,t:1527268299491};\\\", \\\"{x:1235,y:704,t:1527268299509};\\\", \\\"{x:1216,y:696,t:1527268299526};\\\", \\\"{x:1202,y:694,t:1527268299543};\\\", \\\"{x:1181,y:691,t:1527268299559};\\\", \\\"{x:1158,y:687,t:1527268299576};\\\", \\\"{x:1112,y:682,t:1527268299592};\\\", \\\"{x:1059,y:674,t:1527268299609};\\\", \\\"{x:981,y:663,t:1527268299625};\\\", \\\"{x:917,y:653,t:1527268299642};\\\", \\\"{x:821,y:643,t:1527268299659};\\\", \\\"{x:752,y:632,t:1527268299676};\\\", \\\"{x:669,y:623,t:1527268299693};\\\", \\\"{x:557,y:605,t:1527268299708};\\\", \\\"{x:436,y:590,t:1527268299725};\\\", \\\"{x:326,y:578,t:1527268299742};\\\", \\\"{x:255,y:566,t:1527268299759};\\\", \\\"{x:224,y:559,t:1527268299775};\\\", \\\"{x:214,y:554,t:1527268299791};\\\", \\\"{x:211,y:551,t:1527268299808};\\\", \\\"{x:211,y:546,t:1527268299826};\\\", \\\"{x:211,y:542,t:1527268299841};\\\", \\\"{x:214,y:536,t:1527268299858};\\\", \\\"{x:222,y:534,t:1527268299874};\\\", \\\"{x:228,y:531,t:1527268299892};\\\", \\\"{x:232,y:530,t:1527268299909};\\\", \\\"{x:235,y:528,t:1527268299926};\\\", \\\"{x:242,y:526,t:1527268299941};\\\", \\\"{x:247,y:525,t:1527268299959};\\\", \\\"{x:257,y:523,t:1527268299975};\\\", \\\"{x:276,y:523,t:1527268299993};\\\", \\\"{x:298,y:525,t:1527268300009};\\\", \\\"{x:314,y:529,t:1527268300026};\\\", \\\"{x:324,y:534,t:1527268300042};\\\", \\\"{x:329,y:538,t:1527268300058};\\\", \\\"{x:340,y:549,t:1527268300075};\\\", \\\"{x:349,y:563,t:1527268300092};\\\", \\\"{x:358,y:579,t:1527268300108};\\\", \\\"{x:365,y:596,t:1527268300125};\\\", \\\"{x:370,y:607,t:1527268300141};\\\", \\\"{x:378,y:622,t:1527268300159};\\\", \\\"{x:382,y:631,t:1527268300176};\\\", \\\"{x:388,y:643,t:1527268300193};\\\", \\\"{x:393,y:657,t:1527268300208};\\\", \\\"{x:403,y:674,t:1527268300226};\\\", \\\"{x:421,y:695,t:1527268300242};\\\", \\\"{x:437,y:709,t:1527268300258};\\\", \\\"{x:471,y:721,t:1527268300276};\\\", \\\"{x:527,y:729,t:1527268300292};\\\", \\\"{x:566,y:732,t:1527268300308};\\\", \\\"{x:589,y:728,t:1527268300325};\\\", \\\"{x:595,y:723,t:1527268300342};\\\", \\\"{x:597,y:718,t:1527268300358};\\\", \\\"{x:596,y:714,t:1527268300375};\\\", \\\"{x:593,y:710,t:1527268300392};\\\", \\\"{x:591,y:710,t:1527268300409};\\\", \\\"{x:589,y:710,t:1527268300425};\\\", \\\"{x:577,y:713,t:1527268300442};\\\", \\\"{x:572,y:717,t:1527268300459};\\\", \\\"{x:564,y:724,t:1527268300475};\\\", \\\"{x:557,y:728,t:1527268300492};\\\", \\\"{x:554,y:730,t:1527268300508};\\\", \\\"{x:548,y:732,t:1527268300525};\\\", \\\"{x:541,y:732,t:1527268300543};\\\", \\\"{x:538,y:732,t:1527268300558};\\\", \\\"{x:534,y:733,t:1527268300576};\\\", \\\"{x:533,y:733,t:1527268300593};\\\", \\\"{x:531,y:734,t:1527268300608};\\\", \\\"{x:529,y:735,t:1527268300626};\\\", \\\"{x:528,y:735,t:1527268300731};\\\", \\\"{x:528,y:735,t:1527268300797};\\\", \\\"{x:529,y:735,t:1527268301730};\\\", \\\"{x:530,y:734,t:1527268301743};\\\" ] }, { \\\"rt\\\": 12886, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 354783, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"967LR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 3.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:580,y:663,t:1527268302473};\\\", \\\"{x:606,y:624,t:1527268302477};\\\", \\\"{x:666,y:533,t:1527268302494};\\\", \\\"{x:725,y:439,t:1527268302511};\\\", \\\"{x:780,y:346,t:1527268302527};\\\", \\\"{x:820,y:270,t:1527268302543};\\\", \\\"{x:851,y:211,t:1527268302561};\\\", \\\"{x:865,y:188,t:1527268302577};\\\", \\\"{x:869,y:177,t:1527268302593};\\\", \\\"{x:870,y:176,t:1527268302618};\\\", \\\"{x:870,y:177,t:1527268302690};\\\", \\\"{x:870,y:178,t:1527268302698};\\\", \\\"{x:870,y:182,t:1527268302710};\\\", \\\"{x:870,y:188,t:1527268302728};\\\", \\\"{x:870,y:194,t:1527268302743};\\\", \\\"{x:879,y:210,t:1527268302761};\\\", \\\"{x:897,y:230,t:1527268302777};\\\", \\\"{x:933,y:263,t:1527268302793};\\\", \\\"{x:1017,y:323,t:1527268302811};\\\", \\\"{x:1118,y:381,t:1527268302828};\\\", \\\"{x:1247,y:455,t:1527268302844};\\\", \\\"{x:1375,y:520,t:1527268302860};\\\", \\\"{x:1480,y:567,t:1527268302878};\\\", \\\"{x:1570,y:601,t:1527268302893};\\\", \\\"{x:1628,y:626,t:1527268302910};\\\", \\\"{x:1667,y:642,t:1527268302927};\\\", \\\"{x:1681,y:650,t:1527268302943};\\\", \\\"{x:1683,y:651,t:1527268302960};\\\", \\\"{x:1686,y:653,t:1527268302978};\\\", \\\"{x:1690,y:654,t:1527268302994};\\\", \\\"{x:1695,y:656,t:1527268303010};\\\", \\\"{x:1697,y:658,t:1527268303027};\\\", \\\"{x:1699,y:661,t:1527268303044};\\\", \\\"{x:1699,y:663,t:1527268303060};\\\", \\\"{x:1699,y:664,t:1527268303077};\\\", \\\"{x:1698,y:665,t:1527268303106};\\\", \\\"{x:1697,y:667,t:1527268303115};\\\", \\\"{x:1695,y:668,t:1527268303128};\\\", \\\"{x:1690,y:670,t:1527268303144};\\\", \\\"{x:1687,y:671,t:1527268303161};\\\", \\\"{x:1682,y:671,t:1527268303177};\\\", \\\"{x:1678,y:673,t:1527268303194};\\\", \\\"{x:1675,y:673,t:1527268303210};\\\", \\\"{x:1670,y:674,t:1527268303228};\\\", \\\"{x:1665,y:676,t:1527268303245};\\\", \\\"{x:1661,y:677,t:1527268303261};\\\", \\\"{x:1655,y:679,t:1527268303277};\\\", \\\"{x:1649,y:679,t:1527268303294};\\\", \\\"{x:1640,y:681,t:1527268303310};\\\", \\\"{x:1633,y:682,t:1527268303327};\\\", \\\"{x:1621,y:682,t:1527268303345};\\\", \\\"{x:1605,y:682,t:1527268303361};\\\", \\\"{x:1590,y:682,t:1527268303378};\\\", \\\"{x:1554,y:680,t:1527268303395};\\\", \\\"{x:1524,y:675,t:1527268303411};\\\", \\\"{x:1494,y:669,t:1527268303427};\\\", \\\"{x:1457,y:660,t:1527268303445};\\\", \\\"{x:1431,y:648,t:1527268303461};\\\", \\\"{x:1409,y:638,t:1527268303477};\\\", \\\"{x:1390,y:630,t:1527268303495};\\\", \\\"{x:1375,y:623,t:1527268303511};\\\", \\\"{x:1362,y:617,t:1527268303528};\\\", \\\"{x:1352,y:614,t:1527268303545};\\\", \\\"{x:1344,y:613,t:1527268303561};\\\", \\\"{x:1336,y:613,t:1527268303578};\\\", \\\"{x:1331,y:613,t:1527268303595};\\\", \\\"{x:1330,y:613,t:1527268303667};\\\", \\\"{x:1329,y:611,t:1527268303678};\\\", \\\"{x:1328,y:609,t:1527268303695};\\\", \\\"{x:1328,y:604,t:1527268303713};\\\", \\\"{x:1325,y:598,t:1527268303728};\\\", \\\"{x:1322,y:591,t:1527268303745};\\\", \\\"{x:1319,y:587,t:1527268303762};\\\", \\\"{x:1317,y:585,t:1527268303778};\\\", \\\"{x:1316,y:585,t:1527268303835};\\\", \\\"{x:1315,y:583,t:1527268303859};\\\", \\\"{x:1315,y:580,t:1527268304067};\\\", \\\"{x:1317,y:579,t:1527268304078};\\\", \\\"{x:1326,y:574,t:1527268304095};\\\", \\\"{x:1333,y:572,t:1527268304112};\\\", \\\"{x:1342,y:567,t:1527268304129};\\\", \\\"{x:1345,y:566,t:1527268304146};\\\", \\\"{x:1349,y:565,t:1527268304162};\\\", \\\"{x:1352,y:564,t:1527268304179};\\\", \\\"{x:1353,y:563,t:1527268304195};\\\", \\\"{x:1354,y:562,t:1527268304212};\\\", \\\"{x:1355,y:562,t:1527268304379};\\\", \\\"{x:1361,y:560,t:1527268304395};\\\", \\\"{x:1366,y:558,t:1527268304411};\\\", \\\"{x:1371,y:556,t:1527268304428};\\\", \\\"{x:1373,y:556,t:1527268304445};\\\", \\\"{x:1373,y:555,t:1527268304461};\\\", \\\"{x:1370,y:555,t:1527268305076};\\\", \\\"{x:1367,y:557,t:1527268305083};\\\", \\\"{x:1364,y:557,t:1527268305095};\\\", \\\"{x:1359,y:559,t:1527268305113};\\\", \\\"{x:1356,y:560,t:1527268305129};\\\", \\\"{x:1353,y:561,t:1527268305146};\\\", \\\"{x:1350,y:563,t:1527268305162};\\\", \\\"{x:1346,y:563,t:1527268305179};\\\", \\\"{x:1341,y:562,t:1527268305196};\\\", \\\"{x:1336,y:560,t:1527268305211};\\\", \\\"{x:1332,y:560,t:1527268305229};\\\", \\\"{x:1329,y:560,t:1527268305246};\\\", \\\"{x:1327,y:560,t:1527268305262};\\\", \\\"{x:1325,y:561,t:1527268305280};\\\", \\\"{x:1322,y:561,t:1527268305296};\\\", \\\"{x:1321,y:561,t:1527268305312};\\\", \\\"{x:1320,y:561,t:1527268305329};\\\", \\\"{x:1318,y:561,t:1527268305347};\\\", \\\"{x:1316,y:561,t:1527268305363};\\\", \\\"{x:1311,y:561,t:1527268305379};\\\", \\\"{x:1303,y:560,t:1527268305396};\\\", \\\"{x:1300,y:559,t:1527268305412};\\\", \\\"{x:1299,y:559,t:1527268305429};\\\", \\\"{x:1299,y:564,t:1527268306522};\\\", \\\"{x:1307,y:571,t:1527268306530};\\\", \\\"{x:1313,y:576,t:1527268306546};\\\", \\\"{x:1324,y:584,t:1527268306562};\\\", \\\"{x:1329,y:585,t:1527268306579};\\\", \\\"{x:1331,y:585,t:1527268306595};\\\", \\\"{x:1332,y:585,t:1527268306612};\\\", \\\"{x:1333,y:585,t:1527268306634};\\\", \\\"{x:1334,y:585,t:1527268306646};\\\", \\\"{x:1335,y:585,t:1527268306662};\\\", \\\"{x:1337,y:584,t:1527268306680};\\\", \\\"{x:1338,y:584,t:1527268306696};\\\", \\\"{x:1341,y:584,t:1527268306713};\\\", \\\"{x:1342,y:583,t:1527268306729};\\\", \\\"{x:1346,y:581,t:1527268306746};\\\", \\\"{x:1349,y:580,t:1527268306762};\\\", \\\"{x:1351,y:579,t:1527268306779};\\\", \\\"{x:1353,y:579,t:1527268306796};\\\", \\\"{x:1355,y:578,t:1527268306813};\\\", \\\"{x:1358,y:577,t:1527268306831};\\\", \\\"{x:1363,y:575,t:1527268306846};\\\", \\\"{x:1369,y:574,t:1527268306863};\\\", \\\"{x:1374,y:572,t:1527268306880};\\\", \\\"{x:1380,y:570,t:1527268306896};\\\", \\\"{x:1385,y:568,t:1527268306913};\\\", \\\"{x:1389,y:566,t:1527268306930};\\\", \\\"{x:1392,y:565,t:1527268306946};\\\", \\\"{x:1397,y:563,t:1527268306963};\\\", \\\"{x:1399,y:563,t:1527268306980};\\\", \\\"{x:1401,y:561,t:1527268306996};\\\", \\\"{x:1402,y:561,t:1527268307013};\\\", \\\"{x:1403,y:561,t:1527268307030};\\\", \\\"{x:1402,y:561,t:1527268307132};\\\", \\\"{x:1398,y:563,t:1527268307146};\\\", \\\"{x:1380,y:569,t:1527268307164};\\\", \\\"{x:1364,y:573,t:1527268307180};\\\", \\\"{x:1341,y:573,t:1527268307197};\\\", \\\"{x:1300,y:568,t:1527268307213};\\\", \\\"{x:1237,y:553,t:1527268307230};\\\", \\\"{x:1145,y:537,t:1527268307246};\\\", \\\"{x:1067,y:526,t:1527268307263};\\\", \\\"{x:1014,y:520,t:1527268307281};\\\", \\\"{x:970,y:516,t:1527268307297};\\\", \\\"{x:939,y:511,t:1527268307313};\\\", \\\"{x:919,y:508,t:1527268307329};\\\", \\\"{x:907,y:503,t:1527268307347};\\\", \\\"{x:905,y:503,t:1527268307364};\\\", \\\"{x:904,y:503,t:1527268307381};\\\", \\\"{x:902,y:503,t:1527268307397};\\\", \\\"{x:900,y:503,t:1527268307414};\\\", \\\"{x:893,y:503,t:1527268307431};\\\", \\\"{x:880,y:505,t:1527268307448};\\\", \\\"{x:858,y:505,t:1527268307465};\\\", \\\"{x:826,y:505,t:1527268307482};\\\", \\\"{x:787,y:505,t:1527268307498};\\\", \\\"{x:703,y:505,t:1527268307515};\\\", \\\"{x:659,y:505,t:1527268307531};\\\", \\\"{x:625,y:505,t:1527268307548};\\\", \\\"{x:603,y:505,t:1527268307565};\\\", \\\"{x:588,y:505,t:1527268307582};\\\", \\\"{x:585,y:505,t:1527268307598};\\\", \\\"{x:584,y:504,t:1527268307763};\\\", \\\"{x:584,y:503,t:1527268307771};\\\", \\\"{x:584,y:501,t:1527268307781};\\\", \\\"{x:586,y:496,t:1527268307798};\\\", \\\"{x:588,y:494,t:1527268307815};\\\", \\\"{x:590,y:492,t:1527268307831};\\\", \\\"{x:591,y:491,t:1527268307848};\\\", \\\"{x:593,y:490,t:1527268307954};\\\", \\\"{x:595,y:489,t:1527268307965};\\\", \\\"{x:600,y:488,t:1527268307980};\\\", \\\"{x:605,y:487,t:1527268307997};\\\", \\\"{x:606,y:486,t:1527268308317};\\\", \\\"{x:634,y:499,t:1527268308331};\\\", \\\"{x:705,y:527,t:1527268308349};\\\", \\\"{x:772,y:546,t:1527268308366};\\\", \\\"{x:831,y:558,t:1527268308382};\\\", \\\"{x:853,y:561,t:1527268308398};\\\", \\\"{x:858,y:561,t:1527268308416};\\\", \\\"{x:859,y:561,t:1527268308596};\\\", \\\"{x:859,y:559,t:1527268308602};\\\", \\\"{x:857,y:555,t:1527268308617};\\\", \\\"{x:856,y:554,t:1527268308632};\\\", \\\"{x:855,y:554,t:1527268308648};\\\", \\\"{x:855,y:553,t:1527268308664};\\\", \\\"{x:853,y:552,t:1527268308915};\\\", \\\"{x:851,y:552,t:1527268308931};\\\", \\\"{x:850,y:552,t:1527268308948};\\\", \\\"{x:850,y:551,t:1527268309243};\\\", \\\"{x:850,y:551,t:1527268309251};\\\", \\\"{x:848,y:551,t:1527268309467};\\\", \\\"{x:847,y:551,t:1527268309480};\\\", \\\"{x:845,y:551,t:1527268309497};\\\", \\\"{x:842,y:550,t:1527268309513};\\\", \\\"{x:840,y:549,t:1527268309531};\\\", \\\"{x:836,y:547,t:1527268309550};\\\", \\\"{x:835,y:545,t:1527268309567};\\\", \\\"{x:834,y:545,t:1527268309583};\\\", \\\"{x:833,y:545,t:1527268310010};\\\", \\\"{x:831,y:544,t:1527268310018};\\\", \\\"{x:829,y:544,t:1527268310032};\\\", \\\"{x:824,y:542,t:1527268310050};\\\", \\\"{x:819,y:542,t:1527268310067};\\\", \\\"{x:817,y:542,t:1527268310083};\\\", \\\"{x:816,y:542,t:1527268310100};\\\", \\\"{x:813,y:541,t:1527268310116};\\\", \\\"{x:806,y:540,t:1527268310133};\\\", \\\"{x:789,y:535,t:1527268310149};\\\", \\\"{x:768,y:529,t:1527268310167};\\\", \\\"{x:746,y:521,t:1527268310184};\\\", \\\"{x:731,y:516,t:1527268310201};\\\", \\\"{x:724,y:514,t:1527268310217};\\\", \\\"{x:720,y:511,t:1527268310234};\\\", \\\"{x:716,y:510,t:1527268310249};\\\", \\\"{x:709,y:507,t:1527268310267};\\\", \\\"{x:704,y:504,t:1527268310284};\\\", \\\"{x:689,y:498,t:1527268310299};\\\", \\\"{x:673,y:492,t:1527268310317};\\\", \\\"{x:653,y:485,t:1527268310334};\\\", \\\"{x:632,y:477,t:1527268310350};\\\", \\\"{x:610,y:471,t:1527268310366};\\\", \\\"{x:589,y:465,t:1527268310384};\\\", \\\"{x:567,y:461,t:1527268310400};\\\", \\\"{x:550,y:457,t:1527268310416};\\\", \\\"{x:543,y:456,t:1527268310433};\\\", \\\"{x:542,y:456,t:1527268310474};\\\", \\\"{x:541,y:456,t:1527268310484};\\\", \\\"{x:540,y:456,t:1527268310501};\\\", \\\"{x:539,y:456,t:1527268310517};\\\", \\\"{x:537,y:456,t:1527268310534};\\\", \\\"{x:534,y:457,t:1527268310550};\\\", \\\"{x:532,y:458,t:1527268310567};\\\", \\\"{x:531,y:459,t:1527268310583};\\\", \\\"{x:531,y:460,t:1527268310675};\\\", \\\"{x:531,y:461,t:1527268310690};\\\", \\\"{x:531,y:462,t:1527268310730};\\\", \\\"{x:531,y:464,t:1527268310755};\\\", \\\"{x:531,y:469,t:1527268310767};\\\", \\\"{x:542,y:479,t:1527268310784};\\\", \\\"{x:557,y:489,t:1527268310802};\\\", \\\"{x:568,y:495,t:1527268310817};\\\", \\\"{x:573,y:497,t:1527268310834};\\\", \\\"{x:574,y:498,t:1527268310851};\\\", \\\"{x:575,y:498,t:1527268311019};\\\", \\\"{x:578,y:498,t:1527268311034};\\\", \\\"{x:581,y:496,t:1527268311051};\\\", \\\"{x:582,y:496,t:1527268311068};\\\", \\\"{x:583,y:495,t:1527268311085};\\\", \\\"{x:584,y:495,t:1527268311101};\\\", \\\"{x:585,y:495,t:1527268311118};\\\", \\\"{x:587,y:495,t:1527268311135};\\\", \\\"{x:588,y:495,t:1527268311151};\\\", \\\"{x:589,y:495,t:1527268311252};\\\", \\\"{x:592,y:493,t:1527268311268};\\\", \\\"{x:596,y:493,t:1527268311285};\\\", \\\"{x:598,y:493,t:1527268311302};\\\", \\\"{x:598,y:492,t:1527268311317};\\\", \\\"{x:599,y:492,t:1527268311338};\\\", \\\"{x:600,y:492,t:1527268311363};\\\", \\\"{x:601,y:492,t:1527268311370};\\\", \\\"{x:603,y:492,t:1527268311386};\\\", \\\"{x:604,y:491,t:1527268311401};\\\", \\\"{x:605,y:491,t:1527268311418};\\\", \\\"{x:608,y:489,t:1527268311434};\\\", \\\"{x:609,y:494,t:1527268312308};\\\", \\\"{x:611,y:501,t:1527268312319};\\\", \\\"{x:611,y:509,t:1527268312335};\\\", \\\"{x:611,y:515,t:1527268312352};\\\", \\\"{x:611,y:517,t:1527268312368};\\\", \\\"{x:612,y:518,t:1527268312385};\\\", \\\"{x:614,y:518,t:1527268312715};\\\", \\\"{x:614,y:517,t:1527268312724};\\\", \\\"{x:614,y:516,t:1527268312747};\\\", \\\"{x:615,y:513,t:1527268312900};\\\", \\\"{x:615,y:511,t:1527268312919};\\\", \\\"{x:615,y:510,t:1527268312936};\\\", \\\"{x:611,y:510,t:1527268313290};\\\", \\\"{x:605,y:518,t:1527268313304};\\\", \\\"{x:599,y:532,t:1527268313319};\\\", \\\"{x:589,y:549,t:1527268313336};\\\", \\\"{x:585,y:559,t:1527268313354};\\\", \\\"{x:579,y:573,t:1527268313369};\\\", \\\"{x:573,y:588,t:1527268313386};\\\", \\\"{x:562,y:617,t:1527268313403};\\\", \\\"{x:552,y:634,t:1527268313420};\\\", \\\"{x:547,y:650,t:1527268313435};\\\", \\\"{x:546,y:658,t:1527268313453};\\\", \\\"{x:546,y:659,t:1527268313469};\\\", \\\"{x:546,y:661,t:1527268313486};\\\", \\\"{x:546,y:664,t:1527268313502};\\\", \\\"{x:546,y:665,t:1527268313519};\\\", \\\"{x:546,y:673,t:1527268313536};\\\", \\\"{x:546,y:679,t:1527268313552};\\\", \\\"{x:546,y:687,t:1527268313569};\\\", \\\"{x:546,y:692,t:1527268313587};\\\", \\\"{x:548,y:695,t:1527268313602};\\\", \\\"{x:548,y:696,t:1527268313619};\\\", \\\"{x:548,y:702,t:1527268313635};\\\", \\\"{x:548,y:710,t:1527268313652};\\\", \\\"{x:549,y:719,t:1527268313669};\\\", \\\"{x:551,y:728,t:1527268313686};\\\", \\\"{x:551,y:732,t:1527268313701};\\\", \\\"{x:551,y:733,t:1527268313719};\\\", \\\"{x:548,y:738,t:1527268313735};\\\", \\\"{x:540,y:744,t:1527268313752};\\\", \\\"{x:531,y:753,t:1527268313770};\\\", \\\"{x:526,y:762,t:1527268313787};\\\", \\\"{x:525,y:762,t:1527268313883};\\\", \\\"{x:524,y:754,t:1527268313891};\\\", \\\"{x:524,y:749,t:1527268313903};\\\", \\\"{x:524,y:740,t:1527268313921};\\\", \\\"{x:524,y:733,t:1527268313937};\\\", \\\"{x:524,y:730,t:1527268313953};\\\", \\\"{x:524,y:727,t:1527268313970};\\\", \\\"{x:524,y:722,t:1527268313986};\\\", \\\"{x:524,y:721,t:1527268314003};\\\", \\\"{x:524,y:719,t:1527268314021};\\\", \\\"{x:524,y:715,t:1527268314037};\\\", \\\"{x:524,y:714,t:1527268314053};\\\", \\\"{x:524,y:713,t:1527268314070};\\\", \\\"{x:524,y:712,t:1527268314086};\\\", \\\"{x:524,y:711,t:1527268314103};\\\", \\\"{x:524,y:710,t:1527268314120};\\\", \\\"{x:525,y:710,t:1527268314170};\\\", \\\"{x:526,y:710,t:1527268314203};\\\", \\\"{x:526,y:710,t:1527268314228};\\\", \\\"{x:526,y:711,t:1527268314452};\\\", \\\"{x:526,y:713,t:1527268314459};\\\", \\\"{x:526,y:714,t:1527268314475};\\\", \\\"{x:526,y:715,t:1527268314487};\\\", \\\"{x:526,y:716,t:1527268314505};\\\", \\\"{x:527,y:717,t:1527268314520};\\\", \\\"{x:528,y:719,t:1527268314542};\\\", \\\"{x:529,y:721,t:1527268314569};\\\", \\\"{x:529,y:722,t:1527268314586};\\\", \\\"{x:529,y:723,t:1527268314602};\\\", \\\"{x:530,y:724,t:1527268314698};\\\", \\\"{x:531,y:724,t:1527268314714};\\\", \\\"{x:532,y:724,t:1527268314730};\\\", \\\"{x:532,y:725,t:1527268314738};\\\", \\\"{x:532,y:726,t:1527268314762};\\\", \\\"{x:532,y:727,t:1527268314910};\\\" ] }, { \\\"rt\\\": 25931, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 381964, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"967LR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -X -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:531,y:725,t:1527268316626};\\\", \\\"{x:531,y:721,t:1527268316638};\\\", \\\"{x:535,y:711,t:1527268316656};\\\", \\\"{x:541,y:702,t:1527268316672};\\\", \\\"{x:545,y:695,t:1527268316689};\\\", \\\"{x:551,y:685,t:1527268316705};\\\", \\\"{x:557,y:678,t:1527268316722};\\\", \\\"{x:561,y:671,t:1527268316739};\\\", \\\"{x:565,y:666,t:1527268316755};\\\", \\\"{x:569,y:660,t:1527268316772};\\\", \\\"{x:574,y:652,t:1527268316789};\\\", \\\"{x:579,y:647,t:1527268316805};\\\", \\\"{x:585,y:639,t:1527268316822};\\\", \\\"{x:593,y:631,t:1527268316839};\\\", \\\"{x:604,y:621,t:1527268316855};\\\", \\\"{x:618,y:611,t:1527268316872};\\\", \\\"{x:632,y:603,t:1527268316889};\\\", \\\"{x:640,y:598,t:1527268316905};\\\", \\\"{x:648,y:593,t:1527268316922};\\\", \\\"{x:653,y:590,t:1527268316939};\\\", \\\"{x:662,y:586,t:1527268316956};\\\", \\\"{x:672,y:582,t:1527268316972};\\\", \\\"{x:679,y:578,t:1527268316989};\\\", \\\"{x:687,y:576,t:1527268317006};\\\", \\\"{x:690,y:575,t:1527268317022};\\\", \\\"{x:694,y:574,t:1527268317038};\\\", \\\"{x:695,y:572,t:1527268317056};\\\", \\\"{x:696,y:572,t:1527268317075};\\\", \\\"{x:697,y:572,t:1527268317089};\\\", \\\"{x:698,y:572,t:1527268317147};\\\", \\\"{x:699,y:572,t:1527268317163};\\\", \\\"{x:700,y:573,t:1527268319936};\\\", \\\"{x:700,y:580,t:1527268319943};\\\", \\\"{x:700,y:587,t:1527268319955};\\\", \\\"{x:700,y:601,t:1527268319973};\\\", \\\"{x:700,y:615,t:1527268319988};\\\", \\\"{x:700,y:626,t:1527268320005};\\\", \\\"{x:700,y:631,t:1527268320021};\\\", \\\"{x:700,y:632,t:1527268320039};\\\", \\\"{x:700,y:633,t:1527268320232};\\\", \\\"{x:700,y:636,t:1527268320240};\\\", \\\"{x:706,y:642,t:1527268320256};\\\", \\\"{x:716,y:650,t:1527268320272};\\\", \\\"{x:727,y:658,t:1527268320288};\\\", \\\"{x:741,y:665,t:1527268320305};\\\", \\\"{x:765,y:673,t:1527268320322};\\\", \\\"{x:796,y:682,t:1527268320339};\\\", \\\"{x:839,y:697,t:1527268320355};\\\", \\\"{x:880,y:707,t:1527268320372};\\\", \\\"{x:915,y:720,t:1527268320388};\\\", \\\"{x:966,y:736,t:1527268320405};\\\", \\\"{x:1005,y:747,t:1527268320423};\\\", \\\"{x:1044,y:757,t:1527268320439};\\\", \\\"{x:1090,y:768,t:1527268320455};\\\", \\\"{x:1115,y:770,t:1527268320473};\\\", \\\"{x:1135,y:775,t:1527268320489};\\\", \\\"{x:1149,y:776,t:1527268320505};\\\", \\\"{x:1158,y:777,t:1527268320523};\\\", \\\"{x:1161,y:777,t:1527268320540};\\\", \\\"{x:1169,y:777,t:1527268320556};\\\", \\\"{x:1181,y:778,t:1527268320572};\\\", \\\"{x:1197,y:780,t:1527268320589};\\\", \\\"{x:1215,y:783,t:1527268320606};\\\", \\\"{x:1235,y:783,t:1527268320622};\\\", \\\"{x:1256,y:783,t:1527268320639};\\\", \\\"{x:1266,y:783,t:1527268320655};\\\", \\\"{x:1270,y:783,t:1527268320673};\\\", \\\"{x:1271,y:783,t:1527268320689};\\\", \\\"{x:1272,y:783,t:1527268320728};\\\", \\\"{x:1276,y:783,t:1527268320872};\\\", \\\"{x:1280,y:780,t:1527268320890};\\\", \\\"{x:1284,y:775,t:1527268320906};\\\", \\\"{x:1288,y:770,t:1527268320923};\\\", \\\"{x:1292,y:764,t:1527268320939};\\\", \\\"{x:1295,y:754,t:1527268320959};\\\", \\\"{x:1298,y:744,t:1527268320972};\\\", \\\"{x:1303,y:734,t:1527268320989};\\\", \\\"{x:1308,y:722,t:1527268321006};\\\", \\\"{x:1313,y:709,t:1527268321022};\\\", \\\"{x:1316,y:698,t:1527268321039};\\\", \\\"{x:1318,y:693,t:1527268321056};\\\", \\\"{x:1318,y:691,t:1527268321072};\\\", \\\"{x:1319,y:690,t:1527268321088};\\\", \\\"{x:1319,y:689,t:1527268321119};\\\", \\\"{x:1319,y:687,t:1527268321135};\\\", \\\"{x:1320,y:685,t:1527268321143};\\\", \\\"{x:1320,y:683,t:1527268321156};\\\", \\\"{x:1321,y:676,t:1527268321173};\\\", \\\"{x:1323,y:670,t:1527268321189};\\\", \\\"{x:1323,y:664,t:1527268321206};\\\", \\\"{x:1323,y:663,t:1527268321222};\\\", \\\"{x:1323,y:662,t:1527268321239};\\\", \\\"{x:1324,y:661,t:1527268321352};\\\", \\\"{x:1325,y:661,t:1527268321359};\\\", \\\"{x:1327,y:660,t:1527268321373};\\\", \\\"{x:1339,y:656,t:1527268321390};\\\", \\\"{x:1350,y:654,t:1527268321406};\\\", \\\"{x:1364,y:649,t:1527268321422};\\\", \\\"{x:1370,y:647,t:1527268321439};\\\", \\\"{x:1373,y:646,t:1527268321456};\\\", \\\"{x:1375,y:645,t:1527268321474};\\\", \\\"{x:1379,y:644,t:1527268321489};\\\", \\\"{x:1381,y:643,t:1527268321506};\\\", \\\"{x:1382,y:643,t:1527268321523};\\\", \\\"{x:1384,y:643,t:1527268321543};\\\", \\\"{x:1386,y:642,t:1527268321567};\\\", \\\"{x:1387,y:642,t:1527268321583};\\\", \\\"{x:1389,y:641,t:1527268321599};\\\", \\\"{x:1390,y:641,t:1527268321607};\\\", \\\"{x:1395,y:640,t:1527268321623};\\\", \\\"{x:1405,y:640,t:1527268321639};\\\", \\\"{x:1417,y:640,t:1527268321656};\\\", \\\"{x:1427,y:640,t:1527268321674};\\\", \\\"{x:1438,y:640,t:1527268321689};\\\", \\\"{x:1445,y:640,t:1527268321707};\\\", \\\"{x:1453,y:640,t:1527268321724};\\\", \\\"{x:1459,y:640,t:1527268321740};\\\", \\\"{x:1465,y:639,t:1527268321757};\\\", \\\"{x:1473,y:639,t:1527268321774};\\\", \\\"{x:1479,y:639,t:1527268321790};\\\", \\\"{x:1485,y:639,t:1527268321806};\\\", \\\"{x:1490,y:639,t:1527268321824};\\\", \\\"{x:1493,y:639,t:1527268321839};\\\", \\\"{x:1494,y:639,t:1527268321872};\\\", \\\"{x:1495,y:639,t:1527268322296};\\\", \\\"{x:1495,y:640,t:1527268322311};\\\", \\\"{x:1494,y:641,t:1527268322328};\\\", \\\"{x:1494,y:642,t:1527268322341};\\\", \\\"{x:1493,y:643,t:1527268322357};\\\", \\\"{x:1493,y:644,t:1527268322373};\\\", \\\"{x:1492,y:645,t:1527268322391};\\\", \\\"{x:1490,y:647,t:1527268322407};\\\", \\\"{x:1490,y:648,t:1527268322423};\\\", \\\"{x:1488,y:650,t:1527268322441};\\\", \\\"{x:1487,y:650,t:1527268322464};\\\", \\\"{x:1486,y:651,t:1527268322474};\\\", \\\"{x:1485,y:652,t:1527268322491};\\\", \\\"{x:1483,y:654,t:1527268322507};\\\", \\\"{x:1481,y:656,t:1527268322524};\\\", \\\"{x:1478,y:660,t:1527268322541};\\\", \\\"{x:1475,y:664,t:1527268322557};\\\", \\\"{x:1471,y:667,t:1527268322574};\\\", \\\"{x:1468,y:670,t:1527268322591};\\\", \\\"{x:1461,y:674,t:1527268322608};\\\", \\\"{x:1459,y:676,t:1527268322624};\\\", \\\"{x:1455,y:679,t:1527268322641};\\\", \\\"{x:1452,y:682,t:1527268322658};\\\", \\\"{x:1448,y:685,t:1527268322674};\\\", \\\"{x:1442,y:690,t:1527268322691};\\\", \\\"{x:1433,y:696,t:1527268322708};\\\", \\\"{x:1418,y:707,t:1527268322724};\\\", \\\"{x:1401,y:718,t:1527268322741};\\\", \\\"{x:1379,y:730,t:1527268322757};\\\", \\\"{x:1360,y:738,t:1527268322774};\\\", \\\"{x:1346,y:744,t:1527268322791};\\\", \\\"{x:1336,y:747,t:1527268322809};\\\", \\\"{x:1335,y:747,t:1527268322825};\\\", \\\"{x:1335,y:745,t:1527268323023};\\\", \\\"{x:1337,y:734,t:1527268323041};\\\", \\\"{x:1344,y:724,t:1527268323057};\\\", \\\"{x:1352,y:715,t:1527268323074};\\\", \\\"{x:1362,y:711,t:1527268323091};\\\", \\\"{x:1371,y:707,t:1527268323108};\\\", \\\"{x:1380,y:702,t:1527268323124};\\\", \\\"{x:1387,y:700,t:1527268323140};\\\", \\\"{x:1395,y:696,t:1527268323157};\\\", \\\"{x:1405,y:693,t:1527268323175};\\\", \\\"{x:1419,y:691,t:1527268323191};\\\", \\\"{x:1447,y:688,t:1527268323207};\\\", \\\"{x:1469,y:687,t:1527268323224};\\\", \\\"{x:1489,y:687,t:1527268323241};\\\", \\\"{x:1518,y:687,t:1527268323258};\\\", \\\"{x:1540,y:687,t:1527268323274};\\\", \\\"{x:1555,y:687,t:1527268323291};\\\", \\\"{x:1561,y:687,t:1527268323307};\\\", \\\"{x:1567,y:688,t:1527268323324};\\\", \\\"{x:1571,y:690,t:1527268323341};\\\", \\\"{x:1575,y:692,t:1527268323357};\\\", \\\"{x:1579,y:694,t:1527268323374};\\\", \\\"{x:1582,y:695,t:1527268323391};\\\", \\\"{x:1583,y:695,t:1527268323456};\\\", \\\"{x:1584,y:695,t:1527268323504};\\\", \\\"{x:1586,y:697,t:1527268323512};\\\", \\\"{x:1587,y:699,t:1527268323524};\\\", \\\"{x:1588,y:701,t:1527268323542};\\\", \\\"{x:1588,y:702,t:1527268323592};\\\", \\\"{x:1588,y:703,t:1527268323623};\\\", \\\"{x:1587,y:706,t:1527268323642};\\\", \\\"{x:1581,y:709,t:1527268323657};\\\", \\\"{x:1578,y:711,t:1527268323674};\\\", \\\"{x:1573,y:713,t:1527268323692};\\\", \\\"{x:1569,y:714,t:1527268323708};\\\", \\\"{x:1565,y:716,t:1527268323725};\\\", \\\"{x:1562,y:717,t:1527268323742};\\\", \\\"{x:1560,y:718,t:1527268323760};\\\", \\\"{x:1559,y:719,t:1527268323775};\\\", \\\"{x:1556,y:720,t:1527268323792};\\\", \\\"{x:1554,y:720,t:1527268323808};\\\", \\\"{x:1549,y:722,t:1527268323824};\\\", \\\"{x:1544,y:723,t:1527268323841};\\\", \\\"{x:1533,y:727,t:1527268323858};\\\", \\\"{x:1523,y:730,t:1527268323874};\\\", \\\"{x:1511,y:733,t:1527268323891};\\\", \\\"{x:1505,y:734,t:1527268323908};\\\", \\\"{x:1498,y:736,t:1527268323924};\\\", \\\"{x:1493,y:737,t:1527268323941};\\\", \\\"{x:1487,y:737,t:1527268323958};\\\", \\\"{x:1482,y:737,t:1527268323973};\\\", \\\"{x:1466,y:738,t:1527268323990};\\\", \\\"{x:1457,y:740,t:1527268324008};\\\", \\\"{x:1450,y:741,t:1527268324024};\\\", \\\"{x:1444,y:742,t:1527268324041};\\\", \\\"{x:1439,y:742,t:1527268324058};\\\", \\\"{x:1436,y:742,t:1527268324074};\\\", \\\"{x:1432,y:742,t:1527268324091};\\\", \\\"{x:1426,y:742,t:1527268324108};\\\", \\\"{x:1421,y:742,t:1527268324125};\\\", \\\"{x:1415,y:742,t:1527268324142};\\\", \\\"{x:1409,y:743,t:1527268324158};\\\", \\\"{x:1399,y:745,t:1527268324175};\\\", \\\"{x:1395,y:745,t:1527268324191};\\\", \\\"{x:1393,y:745,t:1527268324208};\\\", \\\"{x:1392,y:745,t:1527268324225};\\\", \\\"{x:1391,y:746,t:1527268324241};\\\", \\\"{x:1389,y:746,t:1527268324368};\\\", \\\"{x:1388,y:746,t:1527268324376};\\\", \\\"{x:1387,y:746,t:1527268324440};\\\", \\\"{x:1384,y:746,t:1527268324448};\\\", \\\"{x:1380,y:746,t:1527268324459};\\\", \\\"{x:1349,y:743,t:1527268324476};\\\", \\\"{x:1257,y:728,t:1527268324492};\\\", \\\"{x:1139,y:703,t:1527268324509};\\\", \\\"{x:985,y:663,t:1527268324525};\\\", \\\"{x:833,y:626,t:1527268324543};\\\", \\\"{x:692,y:587,t:1527268324558};\\\", \\\"{x:545,y:543,t:1527268324575};\\\", \\\"{x:476,y:516,t:1527268324609};\\\", \\\"{x:460,y:510,t:1527268324625};\\\", \\\"{x:449,y:503,t:1527268324642};\\\", \\\"{x:444,y:500,t:1527268324658};\\\", \\\"{x:442,y:498,t:1527268324675};\\\", \\\"{x:440,y:496,t:1527268324692};\\\", \\\"{x:443,y:496,t:1527268324840};\\\", \\\"{x:446,y:496,t:1527268324847};\\\", \\\"{x:452,y:496,t:1527268324859};\\\", \\\"{x:457,y:497,t:1527268324875};\\\", \\\"{x:468,y:500,t:1527268324892};\\\", \\\"{x:480,y:503,t:1527268324909};\\\", \\\"{x:489,y:506,t:1527268324925};\\\", \\\"{x:500,y:511,t:1527268324944};\\\", \\\"{x:526,y:522,t:1527268324959};\\\", \\\"{x:548,y:531,t:1527268324976};\\\", \\\"{x:567,y:537,t:1527268324992};\\\", \\\"{x:582,y:541,t:1527268325010};\\\", \\\"{x:595,y:544,t:1527268325025};\\\", \\\"{x:610,y:549,t:1527268325043};\\\", \\\"{x:614,y:549,t:1527268325059};\\\", \\\"{x:616,y:549,t:1527268325076};\\\", \\\"{x:615,y:549,t:1527268325231};\\\", \\\"{x:614,y:549,t:1527268325242};\\\", \\\"{x:612,y:549,t:1527268325259};\\\", \\\"{x:611,y:549,t:1527268325276};\\\", \\\"{x:606,y:551,t:1527268325292};\\\", \\\"{x:595,y:551,t:1527268325310};\\\", \\\"{x:594,y:551,t:1527268325800};\\\", \\\"{x:589,y:551,t:1527268325809};\\\", \\\"{x:571,y:553,t:1527268325827};\\\", \\\"{x:552,y:558,t:1527268325845};\\\", \\\"{x:534,y:560,t:1527268325859};\\\", \\\"{x:525,y:562,t:1527268325876};\\\", \\\"{x:521,y:562,t:1527268325894};\\\", \\\"{x:520,y:562,t:1527268325911};\\\", \\\"{x:519,y:562,t:1527268325952};\\\", \\\"{x:519,y:563,t:1527268325969};\\\", \\\"{x:518,y:563,t:1527268325991};\\\", \\\"{x:517,y:563,t:1527268326038};\\\", \\\"{x:516,y:563,t:1527268326047};\\\", \\\"{x:515,y:564,t:1527268326062};\\\", \\\"{x:513,y:564,t:1527268326086};\\\", \\\"{x:512,y:564,t:1527268326095};\\\", \\\"{x:511,y:564,t:1527268326110};\\\", \\\"{x:510,y:564,t:1527268326126};\\\", \\\"{x:507,y:563,t:1527268326143};\\\", \\\"{x:503,y:561,t:1527268326161};\\\", \\\"{x:494,y:557,t:1527268326177};\\\", \\\"{x:483,y:552,t:1527268326194};\\\", \\\"{x:474,y:548,t:1527268326210};\\\", \\\"{x:462,y:544,t:1527268326226};\\\", \\\"{x:456,y:541,t:1527268326243};\\\", \\\"{x:454,y:541,t:1527268326260};\\\", \\\"{x:454,y:540,t:1527268326312};\\\", \\\"{x:453,y:539,t:1527268326327};\\\", \\\"{x:450,y:536,t:1527268326343};\\\", \\\"{x:447,y:534,t:1527268326360};\\\", \\\"{x:445,y:532,t:1527268326377};\\\", \\\"{x:442,y:531,t:1527268326393};\\\", \\\"{x:436,y:529,t:1527268326411};\\\", \\\"{x:426,y:527,t:1527268326427};\\\", \\\"{x:421,y:527,t:1527268326443};\\\", \\\"{x:421,y:526,t:1527268326902};\\\", \\\"{x:421,y:525,t:1527268326918};\\\", \\\"{x:421,y:524,t:1527268326935};\\\", \\\"{x:423,y:523,t:1527268326944};\\\", \\\"{x:430,y:520,t:1527268326959};\\\", \\\"{x:440,y:515,t:1527268326976};\\\", \\\"{x:449,y:511,t:1527268326992};\\\", \\\"{x:456,y:509,t:1527268327010};\\\", \\\"{x:461,y:506,t:1527268327027};\\\", \\\"{x:472,y:501,t:1527268327044};\\\", \\\"{x:486,y:494,t:1527268327060};\\\", \\\"{x:503,y:488,t:1527268327077};\\\", \\\"{x:521,y:483,t:1527268327095};\\\", \\\"{x:535,y:480,t:1527268327110};\\\", \\\"{x:545,y:476,t:1527268327126};\\\", \\\"{x:547,y:476,t:1527268327144};\\\", \\\"{x:548,y:476,t:1527268327214};\\\", \\\"{x:549,y:476,t:1527268327227};\\\", \\\"{x:550,y:476,t:1527268327244};\\\", \\\"{x:551,y:475,t:1527268327262};\\\", \\\"{x:553,y:475,t:1527268327391};\\\", \\\"{x:556,y:475,t:1527268327398};\\\", \\\"{x:558,y:475,t:1527268327412};\\\", \\\"{x:566,y:474,t:1527268327427};\\\", \\\"{x:590,y:474,t:1527268327444};\\\", \\\"{x:615,y:481,t:1527268327460};\\\", \\\"{x:638,y:486,t:1527268327477};\\\", \\\"{x:651,y:491,t:1527268327495};\\\", \\\"{x:678,y:503,t:1527268327511};\\\", \\\"{x:704,y:515,t:1527268327527};\\\", \\\"{x:751,y:536,t:1527268327545};\\\", \\\"{x:798,y:556,t:1527268327562};\\\", \\\"{x:845,y:578,t:1527268327578};\\\", \\\"{x:904,y:597,t:1527268327595};\\\", \\\"{x:971,y:618,t:1527268327611};\\\", \\\"{x:1062,y:641,t:1527268327627};\\\", \\\"{x:1167,y:670,t:1527268327644};\\\", \\\"{x:1268,y:690,t:1527268327661};\\\", \\\"{x:1352,y:701,t:1527268327678};\\\", \\\"{x:1436,y:716,t:1527268327694};\\\", \\\"{x:1599,y:761,t:1527268327711};\\\", \\\"{x:1759,y:807,t:1527268327728};\\\", \\\"{x:1919,y:857,t:1527268327744};\\\", \\\"{x:1919,y:890,t:1527268327761};\\\", \\\"{x:1919,y:904,t:1527268327777};\\\", \\\"{x:1919,y:912,t:1527268327794};\\\", \\\"{x:1919,y:919,t:1527268327810};\\\", \\\"{x:1919,y:924,t:1527268327827};\\\", \\\"{x:1919,y:925,t:1527268327843};\\\", \\\"{x:1919,y:926,t:1527268327861};\\\", \\\"{x:1919,y:927,t:1527268327974};\\\", \\\"{x:1919,y:928,t:1527268327990};\\\", \\\"{x:1919,y:929,t:1527268327999};\\\", \\\"{x:1919,y:930,t:1527268328159};\\\", \\\"{x:1919,y:931,t:1527268328176};\\\", \\\"{x:1918,y:934,t:1527268328193};\\\", \\\"{x:1916,y:934,t:1527268328209};\\\", \\\"{x:1910,y:935,t:1527268328227};\\\", \\\"{x:1907,y:937,t:1527268328242};\\\", \\\"{x:1905,y:937,t:1527268328259};\\\", \\\"{x:1903,y:937,t:1527268328276};\\\", \\\"{x:1901,y:938,t:1527268328293};\\\", \\\"{x:1900,y:939,t:1527268328309};\\\", \\\"{x:1898,y:939,t:1527268328329};\\\", \\\"{x:1896,y:940,t:1527268328832};\\\", \\\"{x:1894,y:941,t:1527268328848};\\\", \\\"{x:1893,y:941,t:1527268328862};\\\", \\\"{x:1890,y:941,t:1527268328879};\\\", \\\"{x:1889,y:942,t:1527268329591};\\\", \\\"{x:1886,y:944,t:1527268329598};\\\", \\\"{x:1883,y:944,t:1527268329612};\\\", \\\"{x:1879,y:945,t:1527268329629};\\\", \\\"{x:1875,y:946,t:1527268329646};\\\", \\\"{x:1871,y:948,t:1527268329662};\\\", \\\"{x:1856,y:950,t:1527268329679};\\\", \\\"{x:1833,y:950,t:1527268329697};\\\", \\\"{x:1792,y:937,t:1527268329713};\\\", \\\"{x:1762,y:928,t:1527268329730};\\\", \\\"{x:1741,y:922,t:1527268329746};\\\", \\\"{x:1725,y:919,t:1527268329763};\\\", \\\"{x:1716,y:915,t:1527268329779};\\\", \\\"{x:1707,y:910,t:1527268329797};\\\", \\\"{x:1691,y:904,t:1527268329815};\\\", \\\"{x:1668,y:894,t:1527268329829};\\\", \\\"{x:1640,y:882,t:1527268329846};\\\", \\\"{x:1598,y:865,t:1527268329863};\\\", \\\"{x:1578,y:860,t:1527268329880};\\\", \\\"{x:1559,y:854,t:1527268329896};\\\", \\\"{x:1539,y:849,t:1527268329913};\\\", \\\"{x:1521,y:841,t:1527268329929};\\\", \\\"{x:1507,y:834,t:1527268329946};\\\", \\\"{x:1501,y:830,t:1527268329964};\\\", \\\"{x:1496,y:827,t:1527268329979};\\\", \\\"{x:1482,y:820,t:1527268329997};\\\", \\\"{x:1461,y:811,t:1527268330014};\\\", \\\"{x:1413,y:789,t:1527268330030};\\\", \\\"{x:1361,y:766,t:1527268330046};\\\", \\\"{x:1319,y:748,t:1527268330064};\\\", \\\"{x:1312,y:746,t:1527268330080};\\\", \\\"{x:1310,y:744,t:1527268330097};\\\", \\\"{x:1310,y:742,t:1527268330114};\\\", \\\"{x:1308,y:738,t:1527268330130};\\\", \\\"{x:1308,y:734,t:1527268330147};\\\", \\\"{x:1308,y:730,t:1527268330163};\\\", \\\"{x:1308,y:726,t:1527268330180};\\\", \\\"{x:1308,y:724,t:1527268330196};\\\", \\\"{x:1308,y:721,t:1527268330213};\\\", \\\"{x:1308,y:716,t:1527268330231};\\\", \\\"{x:1308,y:714,t:1527268330246};\\\", \\\"{x:1311,y:710,t:1527268330263};\\\", \\\"{x:1314,y:709,t:1527268330280};\\\", \\\"{x:1316,y:706,t:1527268330296};\\\", \\\"{x:1321,y:705,t:1527268330314};\\\", \\\"{x:1322,y:705,t:1527268330331};\\\", \\\"{x:1324,y:703,t:1527268330346};\\\", \\\"{x:1326,y:703,t:1527268330407};\\\", \\\"{x:1327,y:702,t:1527268330415};\\\", \\\"{x:1329,y:701,t:1527268330431};\\\", \\\"{x:1330,y:701,t:1527268330447};\\\", \\\"{x:1333,y:699,t:1527268330463};\\\", \\\"{x:1334,y:699,t:1527268330481};\\\", \\\"{x:1336,y:699,t:1527268330497};\\\", \\\"{x:1337,y:698,t:1527268330514};\\\", \\\"{x:1340,y:696,t:1527268330531};\\\", \\\"{x:1343,y:695,t:1527268330548};\\\", \\\"{x:1345,y:695,t:1527268330581};\\\", \\\"{x:1346,y:695,t:1527268330597};\\\", \\\"{x:1344,y:695,t:1527268331703};\\\", \\\"{x:1343,y:695,t:1527268331715};\\\", \\\"{x:1340,y:699,t:1527268331732};\\\", \\\"{x:1340,y:701,t:1527268331747};\\\", \\\"{x:1340,y:703,t:1527268331764};\\\", \\\"{x:1340,y:704,t:1527268332112};\\\", \\\"{x:1340,y:708,t:1527268332119};\\\", \\\"{x:1340,y:712,t:1527268332132};\\\", \\\"{x:1340,y:718,t:1527268332149};\\\", \\\"{x:1340,y:721,t:1527268332165};\\\", \\\"{x:1340,y:725,t:1527268332181};\\\", \\\"{x:1340,y:726,t:1527268332199};\\\", \\\"{x:1340,y:728,t:1527268332216};\\\", \\\"{x:1340,y:730,t:1527268333936};\\\", \\\"{x:1340,y:731,t:1527268333950};\\\", \\\"{x:1340,y:735,t:1527268333967};\\\", \\\"{x:1340,y:736,t:1527268333983};\\\", \\\"{x:1340,y:738,t:1527268334000};\\\", \\\"{x:1340,y:740,t:1527268334017};\\\", \\\"{x:1340,y:741,t:1527268334034};\\\", \\\"{x:1340,y:742,t:1527268334144};\\\", \\\"{x:1340,y:744,t:1527268334168};\\\", \\\"{x:1340,y:746,t:1527268334184};\\\", \\\"{x:1340,y:748,t:1527268334201};\\\", \\\"{x:1340,y:751,t:1527268334218};\\\", \\\"{x:1340,y:754,t:1527268334234};\\\", \\\"{x:1340,y:759,t:1527268334251};\\\", \\\"{x:1340,y:762,t:1527268334267};\\\", \\\"{x:1340,y:765,t:1527268334284};\\\", \\\"{x:1339,y:769,t:1527268334301};\\\", \\\"{x:1337,y:773,t:1527268334317};\\\", \\\"{x:1334,y:778,t:1527268334335};\\\", \\\"{x:1318,y:785,t:1527268334351};\\\", \\\"{x:1307,y:790,t:1527268334367};\\\", \\\"{x:1294,y:795,t:1527268334384};\\\", \\\"{x:1278,y:800,t:1527268334401};\\\", \\\"{x:1259,y:807,t:1527268334418};\\\", \\\"{x:1230,y:813,t:1527268334435};\\\", \\\"{x:1201,y:813,t:1527268334451};\\\", \\\"{x:1168,y:812,t:1527268334467};\\\", \\\"{x:1143,y:809,t:1527268334484};\\\", \\\"{x:1122,y:802,t:1527268334501};\\\", \\\"{x:1109,y:798,t:1527268334517};\\\", \\\"{x:1095,y:789,t:1527268334534};\\\", \\\"{x:1067,y:768,t:1527268334551};\\\", \\\"{x:1055,y:763,t:1527268334567};\\\", \\\"{x:1006,y:739,t:1527268334584};\\\", \\\"{x:979,y:727,t:1527268334601};\\\", \\\"{x:960,y:719,t:1527268334616};\\\", \\\"{x:950,y:717,t:1527268334634};\\\", \\\"{x:945,y:717,t:1527268334651};\\\", \\\"{x:936,y:712,t:1527268334668};\\\", \\\"{x:919,y:703,t:1527268334684};\\\", \\\"{x:897,y:692,t:1527268334700};\\\", \\\"{x:876,y:684,t:1527268334719};\\\", \\\"{x:855,y:679,t:1527268334734};\\\", \\\"{x:822,y:673,t:1527268334751};\\\", \\\"{x:798,y:670,t:1527268334767};\\\", \\\"{x:777,y:664,t:1527268334784};\\\", \\\"{x:760,y:658,t:1527268334801};\\\", \\\"{x:748,y:647,t:1527268334818};\\\", \\\"{x:736,y:636,t:1527268334833};\\\", \\\"{x:722,y:619,t:1527268334852};\\\", \\\"{x:703,y:602,t:1527268334867};\\\", \\\"{x:685,y:591,t:1527268334884};\\\", \\\"{x:674,y:583,t:1527268334900};\\\", \\\"{x:669,y:580,t:1527268334916};\\\", \\\"{x:667,y:578,t:1527268334934};\\\", \\\"{x:667,y:571,t:1527268334951};\\\", \\\"{x:664,y:565,t:1527268334966};\\\", \\\"{x:654,y:554,t:1527268334984};\\\", \\\"{x:645,y:543,t:1527268335000};\\\", \\\"{x:635,y:535,t:1527268335017};\\\", \\\"{x:634,y:534,t:1527268335033};\\\", \\\"{x:633,y:534,t:1527268335051};\\\", \\\"{x:633,y:532,t:1527268335127};\\\", \\\"{x:631,y:529,t:1527268335135};\\\", \\\"{x:618,y:523,t:1527268335153};\\\", \\\"{x:600,y:521,t:1527268335167};\\\", \\\"{x:580,y:520,t:1527268335184};\\\", \\\"{x:564,y:520,t:1527268335200};\\\", \\\"{x:544,y:520,t:1527268335217};\\\", \\\"{x:523,y:520,t:1527268335234};\\\", \\\"{x:499,y:520,t:1527268335251};\\\", \\\"{x:481,y:520,t:1527268335267};\\\", \\\"{x:471,y:520,t:1527268335283};\\\", \\\"{x:468,y:520,t:1527268335301};\\\", \\\"{x:466,y:520,t:1527268335375};\\\", \\\"{x:464,y:520,t:1527268335384};\\\", \\\"{x:458,y:521,t:1527268335401};\\\", \\\"{x:450,y:523,t:1527268335418};\\\", \\\"{x:430,y:528,t:1527268335436};\\\", \\\"{x:405,y:532,t:1527268335451};\\\", \\\"{x:378,y:534,t:1527268335468};\\\", \\\"{x:351,y:534,t:1527268335484};\\\", \\\"{x:322,y:534,t:1527268335500};\\\", \\\"{x:298,y:534,t:1527268335518};\\\", \\\"{x:279,y:534,t:1527268335534};\\\", \\\"{x:269,y:534,t:1527268335551};\\\", \\\"{x:268,y:534,t:1527268335567};\\\", \\\"{x:267,y:534,t:1527268335614};\\\", \\\"{x:265,y:534,t:1527268335623};\\\", \\\"{x:264,y:534,t:1527268335634};\\\", \\\"{x:260,y:534,t:1527268335650};\\\", \\\"{x:259,y:535,t:1527268335668};\\\", \\\"{x:258,y:536,t:1527268335685};\\\", \\\"{x:257,y:537,t:1527268335703};\\\", \\\"{x:253,y:538,t:1527268335717};\\\", \\\"{x:246,y:544,t:1527268335735};\\\", \\\"{x:238,y:549,t:1527268335751};\\\", \\\"{x:232,y:553,t:1527268335768};\\\", \\\"{x:228,y:555,t:1527268335785};\\\", \\\"{x:224,y:557,t:1527268335803};\\\", \\\"{x:220,y:559,t:1527268335818};\\\", \\\"{x:218,y:561,t:1527268335835};\\\", \\\"{x:212,y:566,t:1527268335853};\\\", \\\"{x:206,y:572,t:1527268335867};\\\", \\\"{x:193,y:581,t:1527268335884};\\\", \\\"{x:182,y:589,t:1527268335901};\\\", \\\"{x:177,y:592,t:1527268335918};\\\", \\\"{x:175,y:593,t:1527268335934};\\\", \\\"{x:175,y:594,t:1527268335975};\\\", \\\"{x:173,y:596,t:1527268335984};\\\", \\\"{x:170,y:602,t:1527268336003};\\\", \\\"{x:166,y:609,t:1527268336018};\\\", \\\"{x:162,y:614,t:1527268336035};\\\", \\\"{x:160,y:617,t:1527268336052};\\\", \\\"{x:159,y:618,t:1527268336068};\\\", \\\"{x:160,y:617,t:1527268336208};\\\", \\\"{x:162,y:615,t:1527268336218};\\\", \\\"{x:168,y:610,t:1527268336234};\\\", \\\"{x:172,y:605,t:1527268336252};\\\", \\\"{x:176,y:600,t:1527268336270};\\\", \\\"{x:179,y:597,t:1527268336285};\\\", \\\"{x:179,y:596,t:1527268336320};\\\", \\\"{x:180,y:595,t:1527268336335};\\\", \\\"{x:191,y:589,t:1527268336352};\\\", \\\"{x:204,y:582,t:1527268336367};\\\", \\\"{x:211,y:577,t:1527268336385};\\\", \\\"{x:208,y:557,t:1527268336402};\\\", \\\"{x:168,y:501,t:1527268336419};\\\", \\\"{x:122,y:446,t:1527268336435};\\\", \\\"{x:70,y:403,t:1527268336452};\\\", \\\"{x:37,y:372,t:1527268336469};\\\", \\\"{x:19,y:359,t:1527268336485};\\\", \\\"{x:16,y:356,t:1527268336502};\\\", \\\"{x:15,y:356,t:1527268336575};\\\", \\\"{x:15,y:357,t:1527268336584};\\\", \\\"{x:15,y:366,t:1527268336601};\\\", \\\"{x:20,y:384,t:1527268336619};\\\", \\\"{x:38,y:409,t:1527268336635};\\\", \\\"{x:55,y:434,t:1527268336653};\\\", \\\"{x:72,y:454,t:1527268336669};\\\", \\\"{x:88,y:469,t:1527268336685};\\\", \\\"{x:101,y:485,t:1527268336703};\\\", \\\"{x:117,y:507,t:1527268336719};\\\", \\\"{x:125,y:519,t:1527268336735};\\\", \\\"{x:130,y:528,t:1527268336752};\\\", \\\"{x:131,y:535,t:1527268336768};\\\", \\\"{x:134,y:540,t:1527268336784};\\\", \\\"{x:135,y:544,t:1527268336801};\\\", \\\"{x:137,y:546,t:1527268336819};\\\", \\\"{x:138,y:546,t:1527268336967};\\\", \\\"{x:140,y:546,t:1527268336975};\\\", \\\"{x:141,y:546,t:1527268336986};\\\", \\\"{x:144,y:543,t:1527268337002};\\\", \\\"{x:149,y:542,t:1527268337019};\\\", \\\"{x:155,y:538,t:1527268337036};\\\", \\\"{x:157,y:538,t:1527268337051};\\\", \\\"{x:159,y:538,t:1527268337278};\\\", \\\"{x:162,y:538,t:1527268337287};\\\", \\\"{x:180,y:534,t:1527268337303};\\\", \\\"{x:233,y:531,t:1527268337318};\\\", \\\"{x:358,y:549,t:1527268337336};\\\", \\\"{x:499,y:568,t:1527268337353};\\\", \\\"{x:676,y:595,t:1527268337369};\\\", \\\"{x:850,y:624,t:1527268337385};\\\", \\\"{x:997,y:646,t:1527268337403};\\\", \\\"{x:1143,y:661,t:1527268337418};\\\", \\\"{x:1243,y:663,t:1527268337435};\\\", \\\"{x:1287,y:666,t:1527268337453};\\\", \\\"{x:1295,y:666,t:1527268337469};\\\", \\\"{x:1296,y:667,t:1527268337487};\\\", \\\"{x:1295,y:667,t:1527268337502};\\\", \\\"{x:1294,y:667,t:1527268337519};\\\", \\\"{x:1292,y:666,t:1527268337559};\\\", \\\"{x:1289,y:656,t:1527268337569};\\\", \\\"{x:1280,y:636,t:1527268337586};\\\", \\\"{x:1268,y:616,t:1527268337603};\\\", \\\"{x:1257,y:601,t:1527268337619};\\\", \\\"{x:1249,y:595,t:1527268337636};\\\", \\\"{x:1247,y:594,t:1527268337653};\\\", \\\"{x:1243,y:594,t:1527268337669};\\\", \\\"{x:1239,y:593,t:1527268337686};\\\", \\\"{x:1230,y:591,t:1527268337704};\\\", \\\"{x:1225,y:591,t:1527268337719};\\\", \\\"{x:1223,y:591,t:1527268337736};\\\", \\\"{x:1219,y:591,t:1527268337754};\\\", \\\"{x:1212,y:591,t:1527268337770};\\\", \\\"{x:1190,y:591,t:1527268337786};\\\", \\\"{x:1160,y:591,t:1527268337803};\\\", \\\"{x:1123,y:591,t:1527268337821};\\\", \\\"{x:1080,y:577,t:1527268337836};\\\", \\\"{x:1039,y:561,t:1527268337853};\\\", \\\"{x:995,y:543,t:1527268337870};\\\", \\\"{x:955,y:521,t:1527268337886};\\\", \\\"{x:905,y:491,t:1527268337905};\\\", \\\"{x:892,y:485,t:1527268337920};\\\", \\\"{x:885,y:482,t:1527268337935};\\\", \\\"{x:884,y:481,t:1527268337954};\\\", \\\"{x:882,y:481,t:1527268338103};\\\", \\\"{x:880,y:481,t:1527268338120};\\\", \\\"{x:875,y:482,t:1527268338138};\\\", \\\"{x:871,y:484,t:1527268338156};\\\", \\\"{x:868,y:485,t:1527268338170};\\\", \\\"{x:865,y:485,t:1527268338187};\\\", \\\"{x:864,y:485,t:1527268338203};\\\", \\\"{x:863,y:486,t:1527268338544};\\\", \\\"{x:862,y:486,t:1527268338555};\\\", \\\"{x:860,y:487,t:1527268338571};\\\", \\\"{x:857,y:488,t:1527268338587};\\\", \\\"{x:854,y:489,t:1527268338603};\\\", \\\"{x:853,y:489,t:1527268338620};\\\", \\\"{x:851,y:489,t:1527268338695};\\\", \\\"{x:847,y:493,t:1527268338703};\\\", \\\"{x:842,y:498,t:1527268338720};\\\", \\\"{x:839,y:501,t:1527268338737};\\\", \\\"{x:838,y:502,t:1527268338754};\\\", \\\"{x:838,y:503,t:1527268339791};\\\", \\\"{x:834,y:506,t:1527268339804};\\\", \\\"{x:827,y:513,t:1527268339821};\\\", \\\"{x:820,y:519,t:1527268339840};\\\", \\\"{x:816,y:522,t:1527268339855};\\\", \\\"{x:813,y:524,t:1527268339871};\\\", \\\"{x:813,y:525,t:1527268339888};\\\", \\\"{x:811,y:525,t:1527268340352};\\\", \\\"{x:808,y:528,t:1527268340359};\\\", \\\"{x:807,y:534,t:1527268340372};\\\", \\\"{x:801,y:545,t:1527268340388};\\\", \\\"{x:794,y:558,t:1527268340406};\\\", \\\"{x:789,y:570,t:1527268340423};\\\", \\\"{x:783,y:582,t:1527268340439};\\\", \\\"{x:781,y:586,t:1527268340455};\\\", \\\"{x:780,y:587,t:1527268340471};\\\", \\\"{x:780,y:589,t:1527268340526};\\\", \\\"{x:779,y:590,t:1527268340538};\\\", \\\"{x:776,y:594,t:1527268340555};\\\", \\\"{x:775,y:596,t:1527268340572};\\\", \\\"{x:773,y:600,t:1527268340589};\\\", \\\"{x:773,y:604,t:1527268340606};\\\", \\\"{x:772,y:610,t:1527268340622};\\\", \\\"{x:772,y:615,t:1527268340638};\\\", \\\"{x:772,y:628,t:1527268340655};\\\", \\\"{x:772,y:643,t:1527268340673};\\\", \\\"{x:772,y:658,t:1527268340688};\\\", \\\"{x:772,y:670,t:1527268340705};\\\", \\\"{x:772,y:681,t:1527268340722};\\\", \\\"{x:770,y:690,t:1527268340739};\\\", \\\"{x:767,y:698,t:1527268340755};\\\", \\\"{x:763,y:706,t:1527268340772};\\\", \\\"{x:757,y:711,t:1527268340789};\\\", \\\"{x:753,y:716,t:1527268340805};\\\", \\\"{x:746,y:721,t:1527268340822};\\\", \\\"{x:728,y:731,t:1527268340839};\\\", \\\"{x:712,y:736,t:1527268340856};\\\", \\\"{x:691,y:742,t:1527268340872};\\\", \\\"{x:674,y:746,t:1527268340889};\\\", \\\"{x:660,y:747,t:1527268340905};\\\", \\\"{x:642,y:747,t:1527268340922};\\\", \\\"{x:632,y:747,t:1527268340939};\\\", \\\"{x:617,y:745,t:1527268340954};\\\", \\\"{x:592,y:738,t:1527268340972};\\\", \\\"{x:570,y:731,t:1527268340989};\\\", \\\"{x:560,y:729,t:1527268341006};\\\", \\\"{x:540,y:737,t:1527268341021};\\\", \\\"{x:501,y:769,t:1527268341039};\\\", \\\"{x:485,y:783,t:1527268341056};\\\", \\\"{x:480,y:788,t:1527268341071};\\\", \\\"{x:480,y:787,t:1527268341166};\\\", \\\"{x:482,y:787,t:1527268341175};\\\", \\\"{x:482,y:786,t:1527268341190};\\\", \\\"{x:483,y:785,t:1527268341206};\\\", \\\"{x:484,y:780,t:1527268341222};\\\", \\\"{x:484,y:769,t:1527268341239};\\\", \\\"{x:484,y:758,t:1527268341256};\\\", \\\"{x:483,y:745,t:1527268341272};\\\", \\\"{x:483,y:739,t:1527268341289};\\\", \\\"{x:481,y:733,t:1527268341306};\\\", \\\"{x:481,y:729,t:1527268341323};\\\", \\\"{x:481,y:724,t:1527268341338};\\\", \\\"{x:481,y:720,t:1527268341355};\\\", \\\"{x:480,y:717,t:1527268341374};\\\", \\\"{x:480,y:715,t:1527268341389};\\\", \\\"{x:478,y:715,t:1527268341511};\\\", \\\"{x:477,y:715,t:1527268341523};\\\", \\\"{x:473,y:714,t:1527268341535};\\\", \\\"{x:473,y:714,t:1527268341538};\\\", \\\"{x:472,y:713,t:1527268341599};\\\", \\\"{x:471,y:713,t:1527268341607};\\\", \\\"{x:469,y:713,t:1527268341623};\\\", \\\"{x:471,y:715,t:1527268341752};\\\", \\\"{x:472,y:715,t:1527268341776};\\\", \\\"{x:472,y:716,t:1527268341790};\\\", \\\"{x:474,y:718,t:1527268341807};\\\", \\\"{x:474,y:723,t:1527268341823};\\\", \\\"{x:474,y:730,t:1527268341841};\\\", \\\"{x:474,y:734,t:1527268341856};\\\", \\\"{x:474,y:736,t:1527268341873};\\\", \\\"{x:474,y:737,t:1527268341928};\\\", \\\"{x:475,y:737,t:1527268342062};\\\", \\\"{x:476,y:737,t:1527268342070};\\\", \\\"{x:476,y:737,t:1527268342091};\\\", \\\"{x:476,y:734,t:1527268342328};\\\", \\\"{x:476,y:733,t:1527268342340};\\\", \\\"{x:476,y:730,t:1527268342356};\\\", \\\"{x:476,y:724,t:1527268342374};\\\", \\\"{x:476,y:720,t:1527268342390};\\\", \\\"{x:476,y:715,t:1527268342407};\\\", \\\"{x:476,y:709,t:1527268342424};\\\", \\\"{x:476,y:706,t:1527268342440};\\\", \\\"{x:476,y:703,t:1527268342457};\\\", \\\"{x:476,y:702,t:1527268342473};\\\", \\\"{x:476,y:701,t:1527268342559};\\\", \\\"{x:476,y:700,t:1527268342575};\\\", \\\"{x:476,y:699,t:1527268342599};\\\", \\\"{x:477,y:697,t:1527268342647};\\\", \\\"{x:477,y:696,t:1527268342696};\\\", \\\"{x:477,y:695,t:1527268342816};\\\" ] }, { \\\"rt\\\": 18783, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 401959, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"967LR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:477,y:691,t:1527268343282};\\\", \\\"{x:477,y:690,t:1527268343308};\\\", \\\"{x:478,y:690,t:1527268343324};\\\", \\\"{x:478,y:685,t:1527268343615};\\\", \\\"{x:482,y:681,t:1527268343624};\\\", \\\"{x:486,y:674,t:1527268343642};\\\", \\\"{x:489,y:668,t:1527268343658};\\\", \\\"{x:490,y:663,t:1527268343673};\\\", \\\"{x:508,y:617,t:1527268343732};\\\", \\\"{x:517,y:594,t:1527268343746};\\\", \\\"{x:521,y:582,t:1527268343758};\\\", \\\"{x:531,y:562,t:1527268343774};\\\", \\\"{x:537,y:544,t:1527268343791};\\\", \\\"{x:538,y:537,t:1527268343807};\\\", \\\"{x:538,y:533,t:1527268343824};\\\", \\\"{x:538,y:528,t:1527268343841};\\\", \\\"{x:538,y:521,t:1527268343857};\\\", \\\"{x:537,y:515,t:1527268343874};\\\", \\\"{x:536,y:511,t:1527268343891};\\\", \\\"{x:533,y:507,t:1527268343908};\\\", \\\"{x:530,y:505,t:1527268343924};\\\", \\\"{x:521,y:501,t:1527268343941};\\\", \\\"{x:510,y:499,t:1527268343958};\\\", \\\"{x:497,y:497,t:1527268343974};\\\", \\\"{x:479,y:495,t:1527268343991};\\\", \\\"{x:470,y:494,t:1527268344008};\\\", \\\"{x:461,y:491,t:1527268344025};\\\", \\\"{x:453,y:488,t:1527268344041};\\\", \\\"{x:449,y:488,t:1527268344058};\\\", \\\"{x:445,y:487,t:1527268344074};\\\", \\\"{x:443,y:486,t:1527268344092};\\\", \\\"{x:439,y:485,t:1527268344108};\\\", \\\"{x:436,y:485,t:1527268344124};\\\", \\\"{x:430,y:485,t:1527268344141};\\\", \\\"{x:424,y:485,t:1527268344158};\\\", \\\"{x:414,y:485,t:1527268344175};\\\", \\\"{x:414,y:484,t:1527268344239};\\\", \\\"{x:414,y:483,t:1527268344247};\\\", \\\"{x:414,y:482,t:1527268344258};\\\", \\\"{x:415,y:481,t:1527268344275};\\\", \\\"{x:416,y:477,t:1527268344291};\\\", \\\"{x:419,y:476,t:1527268344308};\\\", \\\"{x:424,y:473,t:1527268344325};\\\", \\\"{x:431,y:470,t:1527268344341};\\\", \\\"{x:440,y:467,t:1527268344359};\\\", \\\"{x:451,y:464,t:1527268344375};\\\", \\\"{x:458,y:461,t:1527268344392};\\\", \\\"{x:462,y:459,t:1527268344408};\\\", \\\"{x:465,y:458,t:1527268344425};\\\", \\\"{x:467,y:458,t:1527268344441};\\\", \\\"{x:468,y:457,t:1527268344458};\\\", \\\"{x:469,y:456,t:1527268344476};\\\", \\\"{x:472,y:456,t:1527268344491};\\\", \\\"{x:475,y:454,t:1527268344508};\\\", \\\"{x:480,y:453,t:1527268344525};\\\", \\\"{x:483,y:452,t:1527268344542};\\\", \\\"{x:485,y:451,t:1527268344559};\\\", \\\"{x:491,y:449,t:1527268344575};\\\", \\\"{x:497,y:446,t:1527268344591};\\\", \\\"{x:501,y:446,t:1527268344608};\\\", \\\"{x:507,y:444,t:1527268344626};\\\", \\\"{x:509,y:443,t:1527268344642};\\\", \\\"{x:512,y:442,t:1527268344659};\\\", \\\"{x:514,y:442,t:1527268344676};\\\", \\\"{x:516,y:441,t:1527268344692};\\\", \\\"{x:518,y:441,t:1527268344708};\\\", \\\"{x:522,y:439,t:1527268344725};\\\", \\\"{x:523,y:439,t:1527268344742};\\\", \\\"{x:525,y:438,t:1527268344759};\\\", \\\"{x:526,y:438,t:1527268344776};\\\", \\\"{x:527,y:438,t:1527268345727};\\\", \\\"{x:553,y:443,t:1527268345742};\\\", \\\"{x:595,y:455,t:1527268345759};\\\", \\\"{x:634,y:460,t:1527268345776};\\\", \\\"{x:666,y:465,t:1527268345792};\\\", \\\"{x:699,y:471,t:1527268345809};\\\", \\\"{x:745,y:477,t:1527268345826};\\\", \\\"{x:791,y:486,t:1527268345843};\\\", \\\"{x:833,y:492,t:1527268345859};\\\", \\\"{x:856,y:497,t:1527268345876};\\\", \\\"{x:867,y:501,t:1527268345892};\\\", \\\"{x:871,y:502,t:1527268345909};\\\", \\\"{x:871,y:503,t:1527268346271};\\\", \\\"{x:871,y:504,t:1527268346279};\\\", \\\"{x:871,y:505,t:1527268346294};\\\", \\\"{x:868,y:505,t:1527268346310};\\\", \\\"{x:863,y:508,t:1527268346328};\\\", \\\"{x:855,y:511,t:1527268346343};\\\", \\\"{x:850,y:512,t:1527268346360};\\\", \\\"{x:845,y:515,t:1527268346376};\\\", \\\"{x:839,y:516,t:1527268346392};\\\", \\\"{x:833,y:517,t:1527268346410};\\\", \\\"{x:826,y:519,t:1527268346427};\\\", \\\"{x:819,y:521,t:1527268346443};\\\", \\\"{x:812,y:524,t:1527268346460};\\\", \\\"{x:806,y:525,t:1527268346476};\\\", \\\"{x:797,y:527,t:1527268346493};\\\", \\\"{x:783,y:529,t:1527268346510};\\\", \\\"{x:768,y:532,t:1527268346526};\\\", \\\"{x:762,y:533,t:1527268346543};\\\", \\\"{x:761,y:533,t:1527268346560};\\\", \\\"{x:765,y:532,t:1527268346856};\\\", \\\"{x:770,y:531,t:1527268346863};\\\", \\\"{x:773,y:530,t:1527268346877};\\\", \\\"{x:778,y:528,t:1527268346894};\\\", \\\"{x:783,y:527,t:1527268346911};\\\", \\\"{x:788,y:525,t:1527268346927};\\\", \\\"{x:789,y:524,t:1527268346944};\\\", \\\"{x:790,y:524,t:1527268346960};\\\", \\\"{x:791,y:524,t:1527268346977};\\\", \\\"{x:794,y:524,t:1527268346993};\\\", \\\"{x:796,y:523,t:1527268347010};\\\", \\\"{x:801,y:522,t:1527268347027};\\\", \\\"{x:804,y:520,t:1527268347044};\\\", \\\"{x:808,y:520,t:1527268347060};\\\", \\\"{x:813,y:518,t:1527268347077};\\\", \\\"{x:816,y:518,t:1527268347093};\\\", \\\"{x:817,y:517,t:1527268347111};\\\", \\\"{x:823,y:515,t:1527268347127};\\\", \\\"{x:826,y:515,t:1527268347144};\\\", \\\"{x:831,y:515,t:1527268347160};\\\", \\\"{x:837,y:515,t:1527268347177};\\\", \\\"{x:844,y:516,t:1527268347194};\\\", \\\"{x:851,y:518,t:1527268347211};\\\", \\\"{x:858,y:520,t:1527268347227};\\\", \\\"{x:869,y:524,t:1527268347244};\\\", \\\"{x:880,y:528,t:1527268347261};\\\", \\\"{x:893,y:531,t:1527268347278};\\\", \\\"{x:904,y:534,t:1527268347294};\\\", \\\"{x:924,y:540,t:1527268347311};\\\", \\\"{x:940,y:545,t:1527268347327};\\\", \\\"{x:954,y:550,t:1527268347344};\\\", \\\"{x:970,y:554,t:1527268347360};\\\", \\\"{x:991,y:560,t:1527268347378};\\\", \\\"{x:1009,y:565,t:1527268347395};\\\", \\\"{x:1028,y:570,t:1527268347410};\\\", \\\"{x:1042,y:575,t:1527268347427};\\\", \\\"{x:1050,y:576,t:1527268347445};\\\", \\\"{x:1059,y:580,t:1527268347461};\\\", \\\"{x:1064,y:580,t:1527268347477};\\\", \\\"{x:1072,y:583,t:1527268347494};\\\", \\\"{x:1085,y:586,t:1527268347510};\\\", \\\"{x:1099,y:590,t:1527268347527};\\\", \\\"{x:1107,y:594,t:1527268347544};\\\", \\\"{x:1127,y:599,t:1527268347561};\\\", \\\"{x:1141,y:602,t:1527268347577};\\\", \\\"{x:1162,y:604,t:1527268347594};\\\", \\\"{x:1185,y:609,t:1527268347611};\\\", \\\"{x:1210,y:611,t:1527268347627};\\\", \\\"{x:1232,y:615,t:1527268347644};\\\", \\\"{x:1256,y:618,t:1527268347661};\\\", \\\"{x:1271,y:623,t:1527268347677};\\\", \\\"{x:1287,y:626,t:1527268347694};\\\", \\\"{x:1306,y:633,t:1527268347710};\\\", \\\"{x:1315,y:636,t:1527268347728};\\\", \\\"{x:1329,y:638,t:1527268347745};\\\", \\\"{x:1342,y:642,t:1527268347762};\\\", \\\"{x:1360,y:645,t:1527268347779};\\\", \\\"{x:1374,y:647,t:1527268347794};\\\", \\\"{x:1388,y:651,t:1527268347811};\\\", \\\"{x:1395,y:651,t:1527268347828};\\\", \\\"{x:1397,y:653,t:1527268347844};\\\", \\\"{x:1395,y:653,t:1527268348127};\\\", \\\"{x:1383,y:653,t:1527268348146};\\\", \\\"{x:1371,y:653,t:1527268348162};\\\", \\\"{x:1352,y:653,t:1527268348179};\\\", \\\"{x:1333,y:653,t:1527268348196};\\\", \\\"{x:1314,y:653,t:1527268348212};\\\", \\\"{x:1296,y:653,t:1527268348228};\\\", \\\"{x:1282,y:645,t:1527268348246};\\\", \\\"{x:1272,y:639,t:1527268348262};\\\", \\\"{x:1267,y:635,t:1527268348278};\\\", \\\"{x:1264,y:632,t:1527268348296};\\\", \\\"{x:1264,y:631,t:1527268348312};\\\", \\\"{x:1263,y:631,t:1527268348329};\\\", \\\"{x:1262,y:629,t:1527268348346};\\\", \\\"{x:1262,y:626,t:1527268348362};\\\", \\\"{x:1262,y:622,t:1527268348379};\\\", \\\"{x:1262,y:617,t:1527268348395};\\\", \\\"{x:1262,y:614,t:1527268348413};\\\", \\\"{x:1262,y:610,t:1527268348429};\\\", \\\"{x:1262,y:605,t:1527268348446};\\\", \\\"{x:1262,y:600,t:1527268348463};\\\", \\\"{x:1261,y:596,t:1527268348479};\\\", \\\"{x:1261,y:592,t:1527268348496};\\\", \\\"{x:1261,y:590,t:1527268348513};\\\", \\\"{x:1262,y:586,t:1527268348528};\\\", \\\"{x:1263,y:584,t:1527268348546};\\\", \\\"{x:1263,y:583,t:1527268348562};\\\", \\\"{x:1263,y:582,t:1527268348579};\\\", \\\"{x:1264,y:579,t:1527268348595};\\\", \\\"{x:1264,y:576,t:1527268348613};\\\", \\\"{x:1264,y:574,t:1527268348629};\\\", \\\"{x:1264,y:573,t:1527268348646};\\\", \\\"{x:1265,y:572,t:1527268348696};\\\", \\\"{x:1265,y:571,t:1527268348719};\\\", \\\"{x:1266,y:569,t:1527268348730};\\\", \\\"{x:1269,y:567,t:1527268348745};\\\", \\\"{x:1270,y:565,t:1527268348762};\\\", \\\"{x:1271,y:564,t:1527268348780};\\\", \\\"{x:1271,y:563,t:1527268348799};\\\", \\\"{x:1272,y:563,t:1527268348855};\\\", \\\"{x:1272,y:562,t:1527268348872};\\\", \\\"{x:1273,y:562,t:1527268348895};\\\", \\\"{x:1274,y:562,t:1527268348913};\\\", \\\"{x:1275,y:561,t:1527268349032};\\\", \\\"{x:1272,y:563,t:1527268356751};\\\", \\\"{x:1259,y:565,t:1527268356759};\\\", \\\"{x:1243,y:570,t:1527268356772};\\\", \\\"{x:1188,y:581,t:1527268356789};\\\", \\\"{x:1124,y:581,t:1527268356805};\\\", \\\"{x:1055,y:581,t:1527268356822};\\\", \\\"{x:966,y:576,t:1527268356839};\\\", \\\"{x:935,y:572,t:1527268356857};\\\", \\\"{x:906,y:564,t:1527268356872};\\\", \\\"{x:883,y:562,t:1527268356889};\\\", \\\"{x:867,y:559,t:1527268356901};\\\", \\\"{x:819,y:546,t:1527268356919};\\\", \\\"{x:780,y:536,t:1527268356935};\\\", \\\"{x:750,y:525,t:1527268356951};\\\", \\\"{x:729,y:521,t:1527268356968};\\\", \\\"{x:714,y:519,t:1527268356985};\\\", \\\"{x:702,y:517,t:1527268357001};\\\", \\\"{x:695,y:516,t:1527268357018};\\\", \\\"{x:691,y:515,t:1527268357034};\\\", \\\"{x:688,y:515,t:1527268357051};\\\", \\\"{x:684,y:514,t:1527268357068};\\\", \\\"{x:683,y:514,t:1527268357086};\\\", \\\"{x:680,y:514,t:1527268357103};\\\", \\\"{x:679,y:514,t:1527268357126};\\\", \\\"{x:678,y:514,t:1527268357151};\\\", \\\"{x:675,y:515,t:1527268357168};\\\", \\\"{x:665,y:518,t:1527268357187};\\\", \\\"{x:649,y:523,t:1527268357202};\\\", \\\"{x:634,y:524,t:1527268357218};\\\", \\\"{x:621,y:524,t:1527268357235};\\\", \\\"{x:619,y:524,t:1527268357251};\\\", \\\"{x:617,y:524,t:1527268357268};\\\", \\\"{x:614,y:524,t:1527268357285};\\\", \\\"{x:613,y:523,t:1527268357301};\\\", \\\"{x:609,y:521,t:1527268357318};\\\", \\\"{x:606,y:518,t:1527268357335};\\\", \\\"{x:603,y:516,t:1527268357352};\\\", \\\"{x:603,y:515,t:1527268357368};\\\", \\\"{x:603,y:514,t:1527268357386};\\\", \\\"{x:602,y:513,t:1527268357403};\\\", \\\"{x:602,y:512,t:1527268357419};\\\", \\\"{x:602,y:510,t:1527268357436};\\\", \\\"{x:601,y:509,t:1527268357451};\\\", \\\"{x:600,y:508,t:1527268357936};\\\", \\\"{x:597,y:512,t:1527268357954};\\\", \\\"{x:594,y:523,t:1527268357969};\\\", \\\"{x:590,y:532,t:1527268357986};\\\", \\\"{x:588,y:541,t:1527268358002};\\\", \\\"{x:585,y:547,t:1527268358020};\\\", \\\"{x:583,y:553,t:1527268358035};\\\", \\\"{x:582,y:554,t:1527268358062};\\\", \\\"{x:583,y:554,t:1527268358263};\\\", \\\"{x:586,y:554,t:1527268358270};\\\", \\\"{x:590,y:554,t:1527268358286};\\\", \\\"{x:606,y:555,t:1527268358303};\\\", \\\"{x:621,y:558,t:1527268358321};\\\", \\\"{x:641,y:561,t:1527268358336};\\\", \\\"{x:660,y:564,t:1527268358353};\\\", \\\"{x:694,y:565,t:1527268358369};\\\", \\\"{x:754,y:570,t:1527268358387};\\\", \\\"{x:845,y:580,t:1527268358403};\\\", \\\"{x:939,y:580,t:1527268358420};\\\", \\\"{x:1051,y:586,t:1527268358437};\\\", \\\"{x:1144,y:591,t:1527268358452};\\\", \\\"{x:1219,y:602,t:1527268358469};\\\", \\\"{x:1280,y:609,t:1527268358486};\\\", \\\"{x:1290,y:612,t:1527268358502};\\\", \\\"{x:1291,y:612,t:1527268358520};\\\", \\\"{x:1291,y:613,t:1527268359056};\\\", \\\"{x:1290,y:613,t:1527268359087};\\\", \\\"{x:1289,y:614,t:1527268359105};\\\", \\\"{x:1288,y:614,t:1527268359127};\\\", \\\"{x:1287,y:614,t:1527268359137};\\\", \\\"{x:1286,y:615,t:1527268359154};\\\", \\\"{x:1284,y:616,t:1527268359183};\\\", \\\"{x:1283,y:617,t:1527268359215};\\\", \\\"{x:1283,y:618,t:1527268359222};\\\", \\\"{x:1282,y:620,t:1527268359237};\\\", \\\"{x:1282,y:621,t:1527268359254};\\\", \\\"{x:1281,y:623,t:1527268359270};\\\", \\\"{x:1281,y:625,t:1527268359286};\\\", \\\"{x:1281,y:628,t:1527268359303};\\\", \\\"{x:1280,y:632,t:1527268359321};\\\", \\\"{x:1278,y:636,t:1527268359336};\\\", \\\"{x:1278,y:641,t:1527268359354};\\\", \\\"{x:1276,y:647,t:1527268359370};\\\", \\\"{x:1275,y:651,t:1527268359387};\\\", \\\"{x:1275,y:652,t:1527268359404};\\\", \\\"{x:1275,y:656,t:1527268359488};\\\", \\\"{x:1275,y:664,t:1527268359504};\\\", \\\"{x:1275,y:675,t:1527268359521};\\\", \\\"{x:1276,y:681,t:1527268359537};\\\", \\\"{x:1276,y:684,t:1527268359554};\\\", \\\"{x:1276,y:685,t:1527268359571};\\\", \\\"{x:1277,y:687,t:1527268359588};\\\", \\\"{x:1277,y:688,t:1527268359847};\\\", \\\"{x:1277,y:691,t:1527268359855};\\\", \\\"{x:1277,y:696,t:1527268359871};\\\", \\\"{x:1275,y:701,t:1527268359888};\\\", \\\"{x:1274,y:706,t:1527268359904};\\\", \\\"{x:1271,y:709,t:1527268359921};\\\", \\\"{x:1271,y:710,t:1527268359937};\\\", \\\"{x:1270,y:711,t:1527268360814};\\\", \\\"{x:1269,y:711,t:1527268360822};\\\", \\\"{x:1268,y:712,t:1527268360838};\\\", \\\"{x:1261,y:715,t:1527268360854};\\\", \\\"{x:1251,y:719,t:1527268360871};\\\", \\\"{x:1237,y:727,t:1527268360888};\\\", \\\"{x:1223,y:735,t:1527268360905};\\\", \\\"{x:1206,y:744,t:1527268360922};\\\", \\\"{x:1189,y:751,t:1527268360938};\\\", \\\"{x:1164,y:759,t:1527268360954};\\\", \\\"{x:1138,y:766,t:1527268360972};\\\", \\\"{x:1110,y:769,t:1527268360989};\\\", \\\"{x:1077,y:773,t:1527268361004};\\\", \\\"{x:1049,y:773,t:1527268361022};\\\", \\\"{x:986,y:768,t:1527268361038};\\\", \\\"{x:926,y:758,t:1527268361054};\\\", \\\"{x:857,y:750,t:1527268361071};\\\", \\\"{x:800,y:738,t:1527268361089};\\\", \\\"{x:752,y:729,t:1527268361104};\\\", \\\"{x:712,y:722,t:1527268361122};\\\", \\\"{x:685,y:717,t:1527268361138};\\\", \\\"{x:666,y:715,t:1527268361154};\\\", \\\"{x:653,y:713,t:1527268361171};\\\", \\\"{x:644,y:713,t:1527268361189};\\\", \\\"{x:639,y:713,t:1527268361204};\\\", \\\"{x:638,y:713,t:1527268361222};\\\", \\\"{x:636,y:714,t:1527268361239};\\\", \\\"{x:631,y:717,t:1527268361255};\\\", \\\"{x:621,y:721,t:1527268361271};\\\", \\\"{x:606,y:727,t:1527268361288};\\\", \\\"{x:588,y:730,t:1527268361305};\\\", \\\"{x:574,y:731,t:1527268361322};\\\", \\\"{x:555,y:731,t:1527268361340};\\\", \\\"{x:533,y:725,t:1527268361355};\\\", \\\"{x:503,y:713,t:1527268361371};\\\", \\\"{x:477,y:704,t:1527268361389};\\\", \\\"{x:453,y:697,t:1527268361405};\\\", \\\"{x:436,y:693,t:1527268361422};\\\", \\\"{x:425,y:689,t:1527268361438};\\\", \\\"{x:427,y:689,t:1527268361567};\\\", \\\"{x:428,y:689,t:1527268361582};\\\", \\\"{x:428,y:691,t:1527268361655};\\\", \\\"{x:432,y:701,t:1527268361672};\\\", \\\"{x:445,y:715,t:1527268361689};\\\", \\\"{x:458,y:730,t:1527268361707};\\\", \\\"{x:472,y:739,t:1527268361722};\\\", \\\"{x:478,y:748,t:1527268361738};\\\", \\\"{x:486,y:752,t:1527268361754};\\\", \\\"{x:488,y:753,t:1527268361772};\\\", \\\"{x:488,y:752,t:1527268361838};\\\", \\\"{x:487,y:749,t:1527268361855};\\\", \\\"{x:486,y:747,t:1527268361872};\\\", \\\"{x:485,y:746,t:1527268361889};\\\", \\\"{x:485,y:745,t:1527268362158};\\\", \\\"{x:485,y:744,t:1527268362173};\\\", \\\"{x:486,y:741,t:1527268362189};\\\", \\\"{x:486,y:738,t:1527268362205};\\\", \\\"{x:487,y:737,t:1527268362230};\\\", \\\"{x:487,y:736,t:1527268362240};\\\", \\\"{x:487,y:734,t:1527268362256};\\\", \\\"{x:489,y:732,t:1527268362272};\\\", \\\"{x:490,y:731,t:1527268362289};\\\", \\\"{x:493,y:727,t:1527268362306};\\\", \\\"{x:495,y:724,t:1527268362322};\\\", \\\"{x:502,y:716,t:1527268362340};\\\", \\\"{x:513,y:708,t:1527268362356};\\\", \\\"{x:530,y:698,t:1527268362372};\\\", \\\"{x:543,y:687,t:1527268362390};\\\", \\\"{x:557,y:676,t:1527268362406};\\\", \\\"{x:567,y:669,t:1527268362423};\\\", \\\"{x:570,y:666,t:1527268362440};\\\", \\\"{x:573,y:664,t:1527268362456};\\\", \\\"{x:574,y:663,t:1527268362472};\\\", \\\"{x:576,y:661,t:1527268362489};\\\", \\\"{x:578,y:660,t:1527268362506};\\\", \\\"{x:579,y:659,t:1527268362523};\\\", \\\"{x:580,y:658,t:1527268362540};\\\", \\\"{x:581,y:658,t:1527268362556};\\\", \\\"{x:581,y:657,t:1527268362639};\\\" ] }, { \\\"rt\\\": 12228, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 415429, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"967LR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:583,y:657,t:1527268363766};\\\", \\\"{x:586,y:654,t:1527268363774};\\\", \\\"{x:592,y:648,t:1527268363790};\\\", \\\"{x:597,y:644,t:1527268363807};\\\", \\\"{x:603,y:639,t:1527268363823};\\\", \\\"{x:606,y:637,t:1527268363841};\\\", \\\"{x:609,y:634,t:1527268363857};\\\", \\\"{x:610,y:632,t:1527268363874};\\\", \\\"{x:613,y:631,t:1527268363891};\\\", \\\"{x:617,y:627,t:1527268363907};\\\", \\\"{x:623,y:623,t:1527268363924};\\\", \\\"{x:625,y:621,t:1527268363941};\\\", \\\"{x:627,y:620,t:1527268363956};\\\", \\\"{x:628,y:620,t:1527268363973};\\\", \\\"{x:629,y:618,t:1527268363991};\\\", \\\"{x:632,y:617,t:1527268364038};\\\", \\\"{x:633,y:617,t:1527268364062};\\\", \\\"{x:636,y:616,t:1527268364074};\\\", \\\"{x:639,y:614,t:1527268364091};\\\", \\\"{x:643,y:613,t:1527268364107};\\\", \\\"{x:648,y:612,t:1527268364124};\\\", \\\"{x:650,y:610,t:1527268364140};\\\", \\\"{x:655,y:610,t:1527268364157};\\\", \\\"{x:664,y:606,t:1527268364173};\\\", \\\"{x:678,y:602,t:1527268364190};\\\", \\\"{x:694,y:599,t:1527268364208};\\\", \\\"{x:708,y:594,t:1527268364224};\\\", \\\"{x:721,y:592,t:1527268364241};\\\", \\\"{x:728,y:590,t:1527268364259};\\\", \\\"{x:735,y:587,t:1527268364273};\\\", \\\"{x:740,y:586,t:1527268364290};\\\", \\\"{x:748,y:583,t:1527268364307};\\\", \\\"{x:752,y:582,t:1527268364324};\\\", \\\"{x:758,y:581,t:1527268364340};\\\", \\\"{x:762,y:579,t:1527268364358};\\\", \\\"{x:765,y:578,t:1527268364374};\\\", \\\"{x:766,y:578,t:1527268364391};\\\", \\\"{x:767,y:578,t:1527268364423};\\\", \\\"{x:765,y:580,t:1527268365719};\\\", \\\"{x:760,y:586,t:1527268365726};\\\", \\\"{x:754,y:592,t:1527268365743};\\\", \\\"{x:752,y:595,t:1527268365760};\\\", \\\"{x:752,y:596,t:1527268365776};\\\", \\\"{x:752,y:598,t:1527268365791};\\\", \\\"{x:754,y:598,t:1527268365934};\\\", \\\"{x:755,y:598,t:1527268365942};\\\", \\\"{x:761,y:588,t:1527268365959};\\\", \\\"{x:762,y:581,t:1527268365975};\\\", \\\"{x:763,y:580,t:1527268365992};\\\", \\\"{x:763,y:579,t:1527268366247};\\\", \\\"{x:764,y:578,t:1527268366263};\\\", \\\"{x:766,y:577,t:1527268366296};\\\", \\\"{x:768,y:577,t:1527268366309};\\\", \\\"{x:772,y:574,t:1527268366326};\\\", \\\"{x:790,y:565,t:1527268366343};\\\", \\\"{x:809,y:556,t:1527268366361};\\\", \\\"{x:821,y:551,t:1527268366377};\\\", \\\"{x:827,y:547,t:1527268366393};\\\", \\\"{x:832,y:542,t:1527268366409};\\\", \\\"{x:834,y:542,t:1527268366426};\\\", \\\"{x:835,y:542,t:1527268366487};\\\", \\\"{x:843,y:546,t:1527268366496};\\\", \\\"{x:846,y:548,t:1527268366510};\\\", \\\"{x:856,y:556,t:1527268366527};\\\", \\\"{x:868,y:571,t:1527268366544};\\\", \\\"{x:877,y:580,t:1527268366560};\\\", \\\"{x:883,y:586,t:1527268366576};\\\", \\\"{x:884,y:586,t:1527268366593};\\\", \\\"{x:892,y:586,t:1527268367446};\\\", \\\"{x:895,y:586,t:1527268367460};\\\", \\\"{x:898,y:586,t:1527268367477};\\\", \\\"{x:924,y:588,t:1527268367493};\\\", \\\"{x:960,y:588,t:1527268367510};\\\", \\\"{x:1001,y:588,t:1527268367526};\\\", \\\"{x:1004,y:588,t:1527268367544};\\\", \\\"{x:1019,y:590,t:1527268367561};\\\", \\\"{x:1039,y:593,t:1527268367577};\\\", \\\"{x:1061,y:598,t:1527268367595};\\\", \\\"{x:1083,y:605,t:1527268367610};\\\", \\\"{x:1103,y:608,t:1527268367627};\\\", \\\"{x:1121,y:611,t:1527268367644};\\\", \\\"{x:1131,y:612,t:1527268367661};\\\", \\\"{x:1141,y:612,t:1527268367677};\\\", \\\"{x:1148,y:612,t:1527268367694};\\\", \\\"{x:1157,y:612,t:1527268367711};\\\", \\\"{x:1177,y:606,t:1527268367728};\\\", \\\"{x:1215,y:596,t:1527268367744};\\\", \\\"{x:1279,y:584,t:1527268367761};\\\", \\\"{x:1356,y:570,t:1527268367777};\\\", \\\"{x:1445,y:557,t:1527268367794};\\\", \\\"{x:1510,y:545,t:1527268367811};\\\", \\\"{x:1555,y:538,t:1527268367827};\\\", \\\"{x:1574,y:537,t:1527268367844};\\\", \\\"{x:1578,y:535,t:1527268367861};\\\", \\\"{x:1579,y:535,t:1527268367878};\\\", \\\"{x:1579,y:534,t:1527268368135};\\\", \\\"{x:1580,y:532,t:1527268368158};\\\", \\\"{x:1584,y:530,t:1527268368166};\\\", \\\"{x:1588,y:526,t:1527268368178};\\\", \\\"{x:1602,y:519,t:1527268368194};\\\", \\\"{x:1603,y:517,t:1527268368211};\\\", \\\"{x:1601,y:517,t:1527268368471};\\\", \\\"{x:1599,y:518,t:1527268368478};\\\", \\\"{x:1592,y:521,t:1527268368495};\\\", \\\"{x:1577,y:524,t:1527268368512};\\\", \\\"{x:1563,y:528,t:1527268368528};\\\", \\\"{x:1547,y:536,t:1527268368545};\\\", \\\"{x:1531,y:543,t:1527268368561};\\\", \\\"{x:1517,y:554,t:1527268368579};\\\", \\\"{x:1504,y:570,t:1527268368595};\\\", \\\"{x:1492,y:592,t:1527268368611};\\\", \\\"{x:1483,y:618,t:1527268368629};\\\", \\\"{x:1466,y:657,t:1527268368646};\\\", \\\"{x:1436,y:713,t:1527268368661};\\\", \\\"{x:1394,y:784,t:1527268368679};\\\", \\\"{x:1377,y:809,t:1527268368695};\\\", \\\"{x:1372,y:821,t:1527268368711};\\\", \\\"{x:1371,y:823,t:1527268368728};\\\", \\\"{x:1370,y:824,t:1527268368746};\\\", \\\"{x:1369,y:825,t:1527268368830};\\\", \\\"{x:1362,y:827,t:1527268368845};\\\", \\\"{x:1337,y:835,t:1527268368862};\\\", \\\"{x:1315,y:841,t:1527268368878};\\\", \\\"{x:1300,y:847,t:1527268368896};\\\", \\\"{x:1296,y:848,t:1527268368912};\\\", \\\"{x:1295,y:849,t:1527268368951};\\\", \\\"{x:1293,y:849,t:1527268369071};\\\", \\\"{x:1291,y:849,t:1527268369079};\\\", \\\"{x:1283,y:846,t:1527268369096};\\\", \\\"{x:1268,y:833,t:1527268369112};\\\", \\\"{x:1252,y:822,t:1527268369128};\\\", \\\"{x:1229,y:809,t:1527268369145};\\\", \\\"{x:1210,y:797,t:1527268369161};\\\", \\\"{x:1193,y:785,t:1527268369179};\\\", \\\"{x:1185,y:778,t:1527268369195};\\\", \\\"{x:1182,y:775,t:1527268369212};\\\", \\\"{x:1181,y:774,t:1527268369229};\\\", \\\"{x:1178,y:774,t:1527268372904};\\\", \\\"{x:1171,y:774,t:1527268372916};\\\", \\\"{x:1147,y:767,t:1527268372933};\\\", \\\"{x:1108,y:743,t:1527268372948};\\\", \\\"{x:1060,y:710,t:1527268372966};\\\", \\\"{x:966,y:658,t:1527268372983};\\\", \\\"{x:899,y:628,t:1527268373000};\\\", \\\"{x:829,y:595,t:1527268373016};\\\", \\\"{x:765,y:564,t:1527268373032};\\\", \\\"{x:703,y:540,t:1527268373049};\\\", \\\"{x:644,y:522,t:1527268373065};\\\", \\\"{x:588,y:507,t:1527268373082};\\\", \\\"{x:545,y:498,t:1527268373098};\\\", \\\"{x:518,y:495,t:1527268373114};\\\", \\\"{x:510,y:495,t:1527268373130};\\\", \\\"{x:509,y:495,t:1527268373148};\\\", \\\"{x:506,y:496,t:1527268373279};\\\", \\\"{x:491,y:502,t:1527268373287};\\\", \\\"{x:484,y:505,t:1527268373298};\\\", \\\"{x:465,y:512,t:1527268373315};\\\", \\\"{x:455,y:517,t:1527268373332};\\\", \\\"{x:439,y:521,t:1527268373349};\\\", \\\"{x:424,y:523,t:1527268373365};\\\", \\\"{x:402,y:523,t:1527268373382};\\\", \\\"{x:389,y:523,t:1527268373398};\\\", \\\"{x:369,y:523,t:1527268373415};\\\", \\\"{x:356,y:527,t:1527268373433};\\\", \\\"{x:345,y:527,t:1527268373448};\\\", \\\"{x:337,y:528,t:1527268373465};\\\", \\\"{x:334,y:529,t:1527268373482};\\\", \\\"{x:332,y:529,t:1527268373518};\\\", \\\"{x:325,y:530,t:1527268373531};\\\", \\\"{x:306,y:530,t:1527268373549};\\\", \\\"{x:280,y:530,t:1527268373565};\\\", \\\"{x:237,y:526,t:1527268373583};\\\", \\\"{x:158,y:508,t:1527268373599};\\\", \\\"{x:110,y:494,t:1527268373615};\\\", \\\"{x:68,y:481,t:1527268373633};\\\", \\\"{x:47,y:476,t:1527268373648};\\\", \\\"{x:39,y:475,t:1527268373666};\\\", \\\"{x:39,y:474,t:1527268373766};\\\", \\\"{x:39,y:473,t:1527268373782};\\\", \\\"{x:45,y:470,t:1527268373799};\\\", \\\"{x:51,y:467,t:1527268373816};\\\", \\\"{x:66,y:462,t:1527268373832};\\\", \\\"{x:71,y:459,t:1527268373849};\\\", \\\"{x:72,y:459,t:1527268373865};\\\", \\\"{x:73,y:459,t:1527268373882};\\\", \\\"{x:75,y:458,t:1527268373911};\\\", \\\"{x:77,y:458,t:1527268373926};\\\", \\\"{x:79,y:457,t:1527268373934};\\\", \\\"{x:81,y:456,t:1527268373949};\\\", \\\"{x:83,y:456,t:1527268373965};\\\", \\\"{x:84,y:456,t:1527268373982};\\\", \\\"{x:85,y:456,t:1527268374030};\\\", \\\"{x:86,y:456,t:1527268374039};\\\", \\\"{x:86,y:458,t:1527268374049};\\\", \\\"{x:88,y:465,t:1527268374065};\\\", \\\"{x:99,y:474,t:1527268374083};\\\", \\\"{x:112,y:481,t:1527268374099};\\\", \\\"{x:116,y:484,t:1527268374116};\\\", \\\"{x:121,y:487,t:1527268374133};\\\", \\\"{x:127,y:491,t:1527268374149};\\\", \\\"{x:134,y:492,t:1527268374165};\\\", \\\"{x:143,y:496,t:1527268374183};\\\", \\\"{x:148,y:497,t:1527268374198};\\\", \\\"{x:149,y:497,t:1527268374216};\\\", \\\"{x:150,y:497,t:1527268374233};\\\", \\\"{x:152,y:497,t:1527268374248};\\\", \\\"{x:157,y:497,t:1527268374266};\\\", \\\"{x:160,y:499,t:1527268374282};\\\", \\\"{x:162,y:500,t:1527268374299};\\\", \\\"{x:163,y:501,t:1527268374317};\\\", \\\"{x:170,y:505,t:1527268374590};\\\", \\\"{x:173,y:507,t:1527268374599};\\\", \\\"{x:204,y:528,t:1527268374617};\\\", \\\"{x:261,y:570,t:1527268374633};\\\", \\\"{x:330,y:617,t:1527268374649};\\\", \\\"{x:416,y:670,t:1527268374667};\\\", \\\"{x:521,y:718,t:1527268374683};\\\", \\\"{x:646,y:756,t:1527268374699};\\\", \\\"{x:771,y:796,t:1527268374716};\\\", \\\"{x:870,y:822,t:1527268374733};\\\", \\\"{x:929,y:839,t:1527268374749};\\\", \\\"{x:939,y:842,t:1527268374766};\\\", \\\"{x:938,y:844,t:1527268374798};\\\", \\\"{x:936,y:844,t:1527268374814};\\\", \\\"{x:935,y:845,t:1527268374823};\\\", \\\"{x:933,y:846,t:1527268374834};\\\", \\\"{x:928,y:847,t:1527268374849};\\\", \\\"{x:924,y:848,t:1527268374866};\\\", \\\"{x:916,y:848,t:1527268374883};\\\", \\\"{x:903,y:847,t:1527268374899};\\\", \\\"{x:884,y:841,t:1527268374916};\\\", \\\"{x:865,y:836,t:1527268374933};\\\", \\\"{x:845,y:829,t:1527268374949};\\\", \\\"{x:807,y:820,t:1527268374967};\\\", \\\"{x:776,y:815,t:1527268374983};\\\", \\\"{x:748,y:810,t:1527268374999};\\\", \\\"{x:724,y:806,t:1527268375016};\\\", \\\"{x:700,y:803,t:1527268375033};\\\", \\\"{x:677,y:799,t:1527268375049};\\\", \\\"{x:645,y:793,t:1527268375066};\\\", \\\"{x:603,y:782,t:1527268375083};\\\", \\\"{x:567,y:771,t:1527268375100};\\\", \\\"{x:538,y:763,t:1527268375117};\\\", \\\"{x:517,y:756,t:1527268375134};\\\", \\\"{x:497,y:749,t:1527268375152};\\\", \\\"{x:494,y:745,t:1527268375166};\\\", \\\"{x:491,y:743,t:1527268375183};\\\", \\\"{x:489,y:742,t:1527268375200};\\\", \\\"{x:488,y:740,t:1527268375216};\\\", \\\"{x:485,y:736,t:1527268375233};\\\", \\\"{x:484,y:729,t:1527268375250};\\\", \\\"{x:482,y:722,t:1527268375267};\\\", \\\"{x:481,y:721,t:1527268375283};\\\", \\\"{x:480,y:720,t:1527268375462};\\\", \\\"{x:480,y:720,t:1527268375554};\\\", \\\"{x:482,y:720,t:1527268375879};\\\", \\\"{x:485,y:719,t:1527268375886};\\\", \\\"{x:486,y:718,t:1527268375900};\\\", \\\"{x:490,y:716,t:1527268375918};\\\", \\\"{x:495,y:715,t:1527268375933};\\\", \\\"{x:496,y:713,t:1527268375950};\\\", \\\"{x:499,y:712,t:1527268375967};\\\", \\\"{x:501,y:711,t:1527268375984};\\\", \\\"{x:503,y:710,t:1527268376000};\\\", \\\"{x:504,y:709,t:1527268376017};\\\", \\\"{x:505,y:709,t:1527268376038};\\\", \\\"{x:506,y:709,t:1527268376102};\\\", \\\"{x:506,y:708,t:1527268376118};\\\", \\\"{x:507,y:707,t:1527268376142};\\\", \\\"{x:508,y:707,t:1527268376158};\\\" ] }, { \\\"rt\\\": 29234, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 445893, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"967LR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F -F -F -B -B -M -M -M -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:509,y:706,t:1527268377255};\\\", \\\"{x:516,y:695,t:1527268377335};\\\", \\\"{x:520,y:691,t:1527268377351};\\\", \\\"{x:522,y:688,t:1527268377368};\\\", \\\"{x:530,y:683,t:1527268377385};\\\", \\\"{x:542,y:675,t:1527268377401};\\\", \\\"{x:556,y:666,t:1527268377418};\\\", \\\"{x:568,y:658,t:1527268377435};\\\", \\\"{x:583,y:650,t:1527268377451};\\\", \\\"{x:594,y:643,t:1527268377468};\\\", \\\"{x:610,y:636,t:1527268377485};\\\", \\\"{x:659,y:618,t:1527268377501};\\\", \\\"{x:838,y:598,t:1527268377519};\\\", \\\"{x:977,y:593,t:1527268377535};\\\", \\\"{x:1085,y:593,t:1527268377551};\\\", \\\"{x:1168,y:593,t:1527268377568};\\\", \\\"{x:1242,y:588,t:1527268377585};\\\", \\\"{x:1278,y:588,t:1527268377601};\\\", \\\"{x:1337,y:591,t:1527268377619};\\\", \\\"{x:1388,y:589,t:1527268377636};\\\", \\\"{x:1409,y:582,t:1527268377652};\\\", \\\"{x:1420,y:580,t:1527268377669};\\\", \\\"{x:1422,y:579,t:1527268377685};\\\", \\\"{x:1421,y:579,t:1527268377887};\\\", \\\"{x:1416,y:580,t:1527268377902};\\\", \\\"{x:1412,y:582,t:1527268377919};\\\", \\\"{x:1407,y:585,t:1527268377935};\\\", \\\"{x:1405,y:586,t:1527268377952};\\\", \\\"{x:1401,y:587,t:1527268377968};\\\", \\\"{x:1398,y:589,t:1527268377985};\\\", \\\"{x:1397,y:589,t:1527268378002};\\\", \\\"{x:1396,y:589,t:1527268378018};\\\", \\\"{x:1395,y:590,t:1527268378035};\\\", \\\"{x:1394,y:591,t:1527268378255};\\\", \\\"{x:1394,y:593,t:1527268378279};\\\", \\\"{x:1394,y:597,t:1527268378287};\\\", \\\"{x:1391,y:605,t:1527268378303};\\\", \\\"{x:1391,y:610,t:1527268378320};\\\", \\\"{x:1391,y:613,t:1527268378336};\\\", \\\"{x:1391,y:619,t:1527268378353};\\\", \\\"{x:1391,y:624,t:1527268378370};\\\", \\\"{x:1391,y:630,t:1527268378386};\\\", \\\"{x:1391,y:632,t:1527268378403};\\\", \\\"{x:1391,y:637,t:1527268378420};\\\", \\\"{x:1391,y:640,t:1527268378435};\\\", \\\"{x:1393,y:646,t:1527268378452};\\\", \\\"{x:1397,y:654,t:1527268378470};\\\", \\\"{x:1400,y:657,t:1527268378485};\\\", \\\"{x:1401,y:659,t:1527268378503};\\\", \\\"{x:1402,y:660,t:1527268378520};\\\", \\\"{x:1403,y:660,t:1527268378575};\\\", \\\"{x:1404,y:661,t:1527268378586};\\\", \\\"{x:1405,y:662,t:1527268378603};\\\", \\\"{x:1406,y:663,t:1527268378687};\\\", \\\"{x:1401,y:667,t:1527268378703};\\\", \\\"{x:1393,y:670,t:1527268378720};\\\", \\\"{x:1388,y:673,t:1527268378737};\\\", \\\"{x:1383,y:675,t:1527268378753};\\\", \\\"{x:1381,y:676,t:1527268378770};\\\", \\\"{x:1379,y:676,t:1527268378787};\\\", \\\"{x:1378,y:677,t:1527268378803};\\\", \\\"{x:1376,y:677,t:1527268378820};\\\", \\\"{x:1375,y:678,t:1527268378911};\\\", \\\"{x:1373,y:680,t:1527268378935};\\\", \\\"{x:1372,y:680,t:1527268378951};\\\", \\\"{x:1371,y:681,t:1527268378958};\\\", \\\"{x:1369,y:681,t:1527268378999};\\\", \\\"{x:1368,y:682,t:1527268379031};\\\", \\\"{x:1367,y:683,t:1527268379047};\\\", \\\"{x:1366,y:683,t:1527268379055};\\\", \\\"{x:1365,y:684,t:1527268379070};\\\", \\\"{x:1365,y:685,t:1527268379240};\\\", \\\"{x:1364,y:686,t:1527268379254};\\\", \\\"{x:1363,y:686,t:1527268379271};\\\", \\\"{x:1362,y:687,t:1527268379287};\\\", \\\"{x:1361,y:687,t:1527268379304};\\\", \\\"{x:1359,y:688,t:1527268379860};\\\", \\\"{x:1359,y:689,t:1527268379868};\\\", \\\"{x:1358,y:690,t:1527268379885};\\\", \\\"{x:1357,y:692,t:1527268379909};\\\", \\\"{x:1357,y:693,t:1527268380052};\\\", \\\"{x:1357,y:694,t:1527268380118};\\\", \\\"{x:1356,y:694,t:1527268380222};\\\", \\\"{x:1356,y:695,t:1527268380245};\\\", \\\"{x:1356,y:696,t:1527268380285};\\\", \\\"{x:1355,y:696,t:1527268380308};\\\", \\\"{x:1355,y:698,t:1527268380324};\\\", \\\"{x:1354,y:699,t:1527268380364};\\\", \\\"{x:1353,y:699,t:1527268380373};\\\", \\\"{x:1353,y:700,t:1527268380386};\\\", \\\"{x:1352,y:702,t:1527268380403};\\\", \\\"{x:1352,y:704,t:1527268380436};\\\", \\\"{x:1351,y:704,t:1527268380452};\\\", \\\"{x:1350,y:705,t:1527268380469};\\\", \\\"{x:1350,y:701,t:1527268389295};\\\", \\\"{x:1349,y:699,t:1527268389309};\\\", \\\"{x:1348,y:693,t:1527268389327};\\\", \\\"{x:1348,y:689,t:1527268389344};\\\", \\\"{x:1348,y:686,t:1527268389359};\\\", \\\"{x:1348,y:684,t:1527268389376};\\\", \\\"{x:1348,y:685,t:1527268390285};\\\", \\\"{x:1348,y:687,t:1527268390293};\\\", \\\"{x:1347,y:692,t:1527268390311};\\\", \\\"{x:1346,y:696,t:1527268390328};\\\", \\\"{x:1346,y:698,t:1527268390345};\\\", \\\"{x:1345,y:699,t:1527268390361};\\\", \\\"{x:1345,y:700,t:1527268390381};\\\", \\\"{x:1345,y:701,t:1527268390405};\\\", \\\"{x:1345,y:702,t:1527268390518};\\\", \\\"{x:1345,y:703,t:1527268390528};\\\", \\\"{x:1345,y:705,t:1527268390545};\\\", \\\"{x:1345,y:707,t:1527268390561};\\\", \\\"{x:1345,y:710,t:1527268390577};\\\", \\\"{x:1345,y:712,t:1527268390595};\\\", \\\"{x:1345,y:713,t:1527268390610};\\\", \\\"{x:1345,y:715,t:1527268390627};\\\", \\\"{x:1345,y:716,t:1527268390644};\\\", \\\"{x:1345,y:717,t:1527268390660};\\\", \\\"{x:1345,y:718,t:1527268390677};\\\", \\\"{x:1345,y:719,t:1527268390695};\\\", \\\"{x:1345,y:722,t:1527268390710};\\\", \\\"{x:1345,y:725,t:1527268390727};\\\", \\\"{x:1345,y:728,t:1527268390744};\\\", \\\"{x:1345,y:729,t:1527268390761};\\\", \\\"{x:1345,y:730,t:1527268390777};\\\", \\\"{x:1345,y:731,t:1527268390795};\\\", \\\"{x:1345,y:732,t:1527268390810};\\\", \\\"{x:1345,y:735,t:1527268390827};\\\", \\\"{x:1345,y:739,t:1527268390845};\\\", \\\"{x:1345,y:743,t:1527268390861};\\\", \\\"{x:1346,y:745,t:1527268390878};\\\", \\\"{x:1346,y:746,t:1527268390894};\\\", \\\"{x:1346,y:747,t:1527268390949};\\\", \\\"{x:1346,y:748,t:1527268390972};\\\", \\\"{x:1346,y:749,t:1527268390989};\\\", \\\"{x:1346,y:750,t:1527268391005};\\\", \\\"{x:1346,y:752,t:1527268391021};\\\", \\\"{x:1346,y:754,t:1527268391701};\\\", \\\"{x:1346,y:756,t:1527268391711};\\\", \\\"{x:1346,y:758,t:1527268391729};\\\", \\\"{x:1346,y:759,t:1527268391780};\\\", \\\"{x:1346,y:759,t:1527268392119};\\\", \\\"{x:1346,y:762,t:1527268397005};\\\", \\\"{x:1346,y:770,t:1527268397017};\\\", \\\"{x:1346,y:792,t:1527268397033};\\\", \\\"{x:1346,y:810,t:1527268397050};\\\", \\\"{x:1348,y:824,t:1527268397065};\\\", \\\"{x:1350,y:834,t:1527268397083};\\\", \\\"{x:1350,y:838,t:1527268397100};\\\", \\\"{x:1351,y:840,t:1527268397116};\\\", \\\"{x:1351,y:843,t:1527268397181};\\\", \\\"{x:1352,y:844,t:1527268397188};\\\", \\\"{x:1353,y:847,t:1527268397200};\\\", \\\"{x:1354,y:853,t:1527268397216};\\\", \\\"{x:1356,y:856,t:1527268397233};\\\", \\\"{x:1357,y:860,t:1527268397250};\\\", \\\"{x:1359,y:862,t:1527268397266};\\\", \\\"{x:1360,y:864,t:1527268397283};\\\", \\\"{x:1360,y:865,t:1527268397300};\\\", \\\"{x:1361,y:866,t:1527268397316};\\\", \\\"{x:1366,y:874,t:1527268397333};\\\", \\\"{x:1370,y:881,t:1527268397350};\\\", \\\"{x:1375,y:886,t:1527268397367};\\\", \\\"{x:1378,y:890,t:1527268397383};\\\", \\\"{x:1380,y:893,t:1527268397400};\\\", \\\"{x:1382,y:894,t:1527268397417};\\\", \\\"{x:1383,y:896,t:1527268397433};\\\", \\\"{x:1386,y:899,t:1527268397629};\\\", \\\"{x:1387,y:901,t:1527268397638};\\\", \\\"{x:1390,y:905,t:1527268397650};\\\", \\\"{x:1392,y:908,t:1527268397667};\\\", \\\"{x:1393,y:909,t:1527268397683};\\\", \\\"{x:1396,y:910,t:1527268397700};\\\", \\\"{x:1396,y:911,t:1527268397725};\\\", \\\"{x:1396,y:909,t:1527268397901};\\\", \\\"{x:1394,y:900,t:1527268397917};\\\", \\\"{x:1390,y:893,t:1527268397934};\\\", \\\"{x:1386,y:885,t:1527268397950};\\\", \\\"{x:1383,y:880,t:1527268397967};\\\", \\\"{x:1382,y:879,t:1527268397983};\\\", \\\"{x:1381,y:877,t:1527268398000};\\\", \\\"{x:1380,y:876,t:1527268398017};\\\", \\\"{x:1380,y:875,t:1527268399069};\\\", \\\"{x:1380,y:874,t:1527268399085};\\\", \\\"{x:1379,y:873,t:1527268399101};\\\", \\\"{x:1379,y:872,t:1527268399132};\\\", \\\"{x:1379,y:870,t:1527268399149};\\\", \\\"{x:1379,y:869,t:1527268399173};\\\", \\\"{x:1379,y:867,t:1527268399189};\\\", \\\"{x:1379,y:866,t:1527268399213};\\\", \\\"{x:1379,y:864,t:1527268399245};\\\", \\\"{x:1379,y:863,t:1527268399261};\\\", \\\"{x:1379,y:861,t:1527268399285};\\\", \\\"{x:1379,y:860,t:1527268399301};\\\", \\\"{x:1379,y:858,t:1527268399318};\\\", \\\"{x:1379,y:855,t:1527268399336};\\\", \\\"{x:1379,y:850,t:1527268399351};\\\", \\\"{x:1379,y:842,t:1527268399368};\\\", \\\"{x:1381,y:832,t:1527268399385};\\\", \\\"{x:1383,y:821,t:1527268399401};\\\", \\\"{x:1386,y:807,t:1527268399418};\\\", \\\"{x:1387,y:793,t:1527268399435};\\\", \\\"{x:1391,y:776,t:1527268399452};\\\", \\\"{x:1393,y:762,t:1527268399469};\\\", \\\"{x:1397,y:743,t:1527268399485};\\\", \\\"{x:1401,y:731,t:1527268399501};\\\", \\\"{x:1403,y:718,t:1527268399519};\\\", \\\"{x:1406,y:704,t:1527268399535};\\\", \\\"{x:1408,y:691,t:1527268399552};\\\", \\\"{x:1408,y:681,t:1527268399568};\\\", \\\"{x:1410,y:672,t:1527268399585};\\\", \\\"{x:1411,y:662,t:1527268399603};\\\", \\\"{x:1415,y:653,t:1527268399618};\\\", \\\"{x:1415,y:646,t:1527268399635};\\\", \\\"{x:1417,y:640,t:1527268399653};\\\", \\\"{x:1417,y:635,t:1527268399668};\\\", \\\"{x:1419,y:629,t:1527268399684};\\\", \\\"{x:1420,y:625,t:1527268399702};\\\", \\\"{x:1420,y:624,t:1527268399718};\\\", \\\"{x:1420,y:622,t:1527268399735};\\\", \\\"{x:1420,y:617,t:1527268399752};\\\", \\\"{x:1420,y:613,t:1527268399769};\\\", \\\"{x:1420,y:609,t:1527268399785};\\\", \\\"{x:1420,y:605,t:1527268399802};\\\", \\\"{x:1420,y:601,t:1527268399818};\\\", \\\"{x:1420,y:598,t:1527268399835};\\\", \\\"{x:1421,y:593,t:1527268399853};\\\", \\\"{x:1421,y:590,t:1527268399868};\\\", \\\"{x:1421,y:586,t:1527268399884};\\\", \\\"{x:1421,y:583,t:1527268399902};\\\", \\\"{x:1421,y:581,t:1527268399918};\\\", \\\"{x:1421,y:580,t:1527268399935};\\\", \\\"{x:1421,y:579,t:1527268400085};\\\", \\\"{x:1417,y:582,t:1527268400102};\\\", \\\"{x:1414,y:586,t:1527268400119};\\\", \\\"{x:1412,y:589,t:1527268400135};\\\", \\\"{x:1411,y:593,t:1527268400152};\\\", \\\"{x:1410,y:596,t:1527268400168};\\\", \\\"{x:1409,y:602,t:1527268400184};\\\", \\\"{x:1408,y:608,t:1527268400201};\\\", \\\"{x:1407,y:619,t:1527268400218};\\\", \\\"{x:1406,y:629,t:1527268400234};\\\", \\\"{x:1403,y:647,t:1527268400252};\\\", \\\"{x:1402,y:657,t:1527268400268};\\\", \\\"{x:1402,y:666,t:1527268400285};\\\", \\\"{x:1401,y:671,t:1527268400302};\\\", \\\"{x:1400,y:677,t:1527268400318};\\\", \\\"{x:1400,y:682,t:1527268400335};\\\", \\\"{x:1400,y:689,t:1527268400352};\\\", \\\"{x:1400,y:697,t:1527268400368};\\\", \\\"{x:1400,y:707,t:1527268400385};\\\", \\\"{x:1402,y:725,t:1527268400402};\\\", \\\"{x:1404,y:745,t:1527268400419};\\\", \\\"{x:1407,y:762,t:1527268400436};\\\", \\\"{x:1410,y:775,t:1527268400452};\\\", \\\"{x:1414,y:784,t:1527268400468};\\\", \\\"{x:1415,y:791,t:1527268400486};\\\", \\\"{x:1419,y:799,t:1527268400502};\\\", \\\"{x:1425,y:811,t:1527268400519};\\\", \\\"{x:1431,y:822,t:1527268400536};\\\", \\\"{x:1436,y:830,t:1527268400552};\\\", \\\"{x:1438,y:833,t:1527268400569};\\\", \\\"{x:1439,y:834,t:1527268400586};\\\", \\\"{x:1440,y:836,t:1527268400602};\\\", \\\"{x:1441,y:836,t:1527268400653};\\\", \\\"{x:1444,y:836,t:1527268400669};\\\", \\\"{x:1445,y:836,t:1527268400686};\\\", \\\"{x:1447,y:836,t:1527268400703};\\\", \\\"{x:1448,y:836,t:1527268400749};\\\", \\\"{x:1449,y:836,t:1527268400756};\\\", \\\"{x:1450,y:836,t:1527268400770};\\\", \\\"{x:1450,y:835,t:1527268400786};\\\", \\\"{x:1451,y:834,t:1527268400802};\\\", \\\"{x:1452,y:834,t:1527268400819};\\\", \\\"{x:1453,y:834,t:1527268400837};\\\", \\\"{x:1453,y:833,t:1527268400901};\\\", \\\"{x:1454,y:833,t:1527268400917};\\\", \\\"{x:1457,y:831,t:1527268400924};\\\", \\\"{x:1460,y:831,t:1527268400936};\\\", \\\"{x:1463,y:830,t:1527268400954};\\\", \\\"{x:1466,y:829,t:1527268400970};\\\", \\\"{x:1468,y:828,t:1527268400986};\\\", \\\"{x:1475,y:826,t:1527268402678};\\\", \\\"{x:1483,y:825,t:1527268402688};\\\", \\\"{x:1511,y:829,t:1527268402706};\\\", \\\"{x:1552,y:846,t:1527268402721};\\\", \\\"{x:1600,y:860,t:1527268402738};\\\", \\\"{x:1618,y:869,t:1527268402754};\\\", \\\"{x:1621,y:870,t:1527268402771};\\\", \\\"{x:1623,y:870,t:1527268402787};\\\", \\\"{x:1626,y:870,t:1527268402804};\\\", \\\"{x:1627,y:871,t:1527268402877};\\\", \\\"{x:1627,y:873,t:1527268402949};\\\", \\\"{x:1621,y:873,t:1527268402957};\\\", \\\"{x:1610,y:873,t:1527268402971};\\\", \\\"{x:1581,y:864,t:1527268402987};\\\", \\\"{x:1543,y:852,t:1527268403004};\\\", \\\"{x:1453,y:825,t:1527268403021};\\\", \\\"{x:1370,y:800,t:1527268403038};\\\", \\\"{x:1280,y:771,t:1527268403055};\\\", \\\"{x:1183,y:741,t:1527268403071};\\\", \\\"{x:1074,y:707,t:1527268403088};\\\", \\\"{x:971,y:670,t:1527268403105};\\\", \\\"{x:879,y:639,t:1527268403121};\\\", \\\"{x:800,y:610,t:1527268403140};\\\", \\\"{x:759,y:596,t:1527268403154};\\\", \\\"{x:715,y:574,t:1527268403188};\\\", \\\"{x:713,y:573,t:1527268403202};\\\", \\\"{x:709,y:571,t:1527268403217};\\\", \\\"{x:698,y:568,t:1527268403235};\\\", \\\"{x:674,y:564,t:1527268403251};\\\", \\\"{x:647,y:562,t:1527268403268};\\\", \\\"{x:611,y:555,t:1527268403285};\\\", \\\"{x:578,y:552,t:1527268403304};\\\", \\\"{x:528,y:544,t:1527268403320};\\\", \\\"{x:462,y:528,t:1527268403338};\\\", \\\"{x:416,y:519,t:1527268403355};\\\", \\\"{x:388,y:511,t:1527268403371};\\\", \\\"{x:374,y:505,t:1527268403388};\\\", \\\"{x:373,y:505,t:1527268403405};\\\", \\\"{x:370,y:505,t:1527268403460};\\\", \\\"{x:366,y:505,t:1527268403470};\\\", \\\"{x:357,y:507,t:1527268403488};\\\", \\\"{x:348,y:511,t:1527268403505};\\\", \\\"{x:343,y:514,t:1527268403521};\\\", \\\"{x:342,y:515,t:1527268403538};\\\", \\\"{x:341,y:515,t:1527268403685};\\\", \\\"{x:341,y:516,t:1527268403700};\\\", \\\"{x:342,y:516,t:1527268403716};\\\", \\\"{x:342,y:517,t:1527268403724};\\\", \\\"{x:342,y:518,t:1527268403740};\\\", \\\"{x:343,y:519,t:1527268403754};\\\", \\\"{x:345,y:531,t:1527268403772};\\\", \\\"{x:351,y:554,t:1527268403789};\\\", \\\"{x:365,y:590,t:1527268403805};\\\", \\\"{x:387,y:640,t:1527268403822};\\\", \\\"{x:403,y:681,t:1527268403838};\\\", \\\"{x:411,y:703,t:1527268403855};\\\", \\\"{x:412,y:710,t:1527268403871};\\\", \\\"{x:412,y:712,t:1527268403889};\\\", \\\"{x:411,y:713,t:1527268403916};\\\", \\\"{x:409,y:714,t:1527268403924};\\\", \\\"{x:405,y:716,t:1527268403938};\\\", \\\"{x:392,y:718,t:1527268403954};\\\", \\\"{x:349,y:718,t:1527268403972};\\\", \\\"{x:311,y:718,t:1527268403988};\\\", \\\"{x:283,y:715,t:1527268404004};\\\", \\\"{x:270,y:711,t:1527268404021};\\\", \\\"{x:266,y:709,t:1527268404038};\\\", \\\"{x:265,y:708,t:1527268404054};\\\", \\\"{x:262,y:706,t:1527268404072};\\\", \\\"{x:261,y:705,t:1527268404089};\\\", \\\"{x:259,y:702,t:1527268404105};\\\", \\\"{x:257,y:699,t:1527268404122};\\\", \\\"{x:255,y:696,t:1527268404139};\\\", \\\"{x:254,y:692,t:1527268404155};\\\", \\\"{x:252,y:685,t:1527268404173};\\\", \\\"{x:249,y:682,t:1527268404188};\\\", \\\"{x:246,y:678,t:1527268404206};\\\", \\\"{x:245,y:677,t:1527268404222};\\\", \\\"{x:245,y:674,t:1527268404244};\\\", \\\"{x:244,y:673,t:1527268404255};\\\", \\\"{x:241,y:667,t:1527268404273};\\\", \\\"{x:230,y:658,t:1527268404289};\\\", \\\"{x:223,y:656,t:1527268404304};\\\", \\\"{x:215,y:653,t:1527268404321};\\\", \\\"{x:213,y:652,t:1527268404338};\\\", \\\"{x:213,y:651,t:1527268404364};\\\", \\\"{x:217,y:646,t:1527268404372};\\\", \\\"{x:243,y:633,t:1527268404389};\\\", \\\"{x:286,y:618,t:1527268404406};\\\", \\\"{x:323,y:606,t:1527268404421};\\\", \\\"{x:343,y:599,t:1527268404439};\\\", \\\"{x:360,y:591,t:1527268404456};\\\", \\\"{x:374,y:589,t:1527268404471};\\\", \\\"{x:390,y:585,t:1527268404489};\\\", \\\"{x:415,y:583,t:1527268404505};\\\", \\\"{x:461,y:583,t:1527268404522};\\\", \\\"{x:529,y:578,t:1527268404539};\\\", \\\"{x:610,y:578,t:1527268404557};\\\", \\\"{x:661,y:578,t:1527268404573};\\\", \\\"{x:690,y:578,t:1527268404588};\\\", \\\"{x:709,y:579,t:1527268404605};\\\", \\\"{x:726,y:581,t:1527268404622};\\\", \\\"{x:741,y:581,t:1527268404638};\\\", \\\"{x:763,y:581,t:1527268404655};\\\", \\\"{x:783,y:581,t:1527268404671};\\\", \\\"{x:800,y:581,t:1527268404688};\\\", \\\"{x:810,y:578,t:1527268404705};\\\", \\\"{x:812,y:578,t:1527268404721};\\\", \\\"{x:803,y:578,t:1527268404893};\\\", \\\"{x:791,y:578,t:1527268404906};\\\", \\\"{x:739,y:588,t:1527268404923};\\\", \\\"{x:690,y:600,t:1527268404940};\\\", \\\"{x:651,y:616,t:1527268404956};\\\", \\\"{x:641,y:618,t:1527268404973};\\\", \\\"{x:639,y:619,t:1527268404988};\\\", \\\"{x:638,y:619,t:1527268405100};\\\", \\\"{x:638,y:615,t:1527268405108};\\\", \\\"{x:638,y:613,t:1527268405122};\\\", \\\"{x:638,y:607,t:1527268405139};\\\", \\\"{x:638,y:602,t:1527268405156};\\\", \\\"{x:637,y:598,t:1527268405173};\\\", \\\"{x:634,y:594,t:1527268405190};\\\", \\\"{x:631,y:593,t:1527268405206};\\\", \\\"{x:628,y:591,t:1527268405222};\\\", \\\"{x:627,y:590,t:1527268405240};\\\", \\\"{x:627,y:589,t:1527268405256};\\\", \\\"{x:625,y:587,t:1527268405273};\\\", \\\"{x:624,y:587,t:1527268405290};\\\", \\\"{x:622,y:587,t:1527268405305};\\\", \\\"{x:622,y:586,t:1527268405380};\\\", \\\"{x:620,y:587,t:1527268405595};\\\", \\\"{x:612,y:596,t:1527268405606};\\\", \\\"{x:579,y:641,t:1527268405623};\\\", \\\"{x:542,y:690,t:1527268405639};\\\", \\\"{x:523,y:711,t:1527268405656};\\\", \\\"{x:512,y:727,t:1527268405674};\\\", \\\"{x:510,y:733,t:1527268405690};\\\", \\\"{x:510,y:739,t:1527268405706};\\\", \\\"{x:508,y:740,t:1527268405723};\\\", \\\"{x:508,y:741,t:1527268405740};\\\", \\\"{x:508,y:739,t:1527268406316};\\\", \\\"{x:508,y:738,t:1527268406323};\\\", \\\"{x:508,y:737,t:1527268406340};\\\", \\\"{x:508,y:736,t:1527268406363};\\\", \\\"{x:508,y:735,t:1527268406373};\\\", \\\"{x:509,y:734,t:1527268406390};\\\" ] }, { \\\"rt\\\": 10929, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 458169, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"967LR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-12 PM-B -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:527,y:720,t:1527268407729};\\\", \\\"{x:537,y:714,t:1527268407742};\\\", \\\"{x:547,y:706,t:1527268407758};\\\", \\\"{x:562,y:694,t:1527268407774};\\\", \\\"{x:580,y:679,t:1527268407790};\\\", \\\"{x:598,y:658,t:1527268407808};\\\", \\\"{x:620,y:638,t:1527268407824};\\\", \\\"{x:646,y:623,t:1527268407841};\\\", \\\"{x:669,y:606,t:1527268407858};\\\", \\\"{x:697,y:590,t:1527268407875};\\\", \\\"{x:749,y:560,t:1527268407892};\\\", \\\"{x:780,y:545,t:1527268407908};\\\", \\\"{x:803,y:536,t:1527268407925};\\\", \\\"{x:826,y:526,t:1527268407941};\\\", \\\"{x:847,y:517,t:1527268407958};\\\", \\\"{x:860,y:514,t:1527268407974};\\\", \\\"{x:867,y:510,t:1527268407993};\\\", \\\"{x:875,y:506,t:1527268408009};\\\", \\\"{x:880,y:505,t:1527268408024};\\\", \\\"{x:898,y:503,t:1527268408041};\\\", \\\"{x:922,y:499,t:1527268408058};\\\", \\\"{x:950,y:499,t:1527268408074};\\\", \\\"{x:985,y:504,t:1527268408093};\\\", \\\"{x:1006,y:511,t:1527268408108};\\\", \\\"{x:1016,y:516,t:1527268408125};\\\", \\\"{x:1017,y:518,t:1527268408142};\\\", \\\"{x:1018,y:519,t:1527268408159};\\\", \\\"{x:1019,y:520,t:1527268408628};\\\", \\\"{x:1020,y:520,t:1527268408641};\\\", \\\"{x:1030,y:532,t:1527268408659};\\\", \\\"{x:1056,y:547,t:1527268408676};\\\", \\\"{x:1072,y:557,t:1527268408692};\\\", \\\"{x:1091,y:569,t:1527268408709};\\\", \\\"{x:1119,y:589,t:1527268408726};\\\", \\\"{x:1145,y:608,t:1527268408742};\\\", \\\"{x:1169,y:630,t:1527268408759};\\\", \\\"{x:1191,y:651,t:1527268408776};\\\", \\\"{x:1215,y:672,t:1527268408792};\\\", \\\"{x:1232,y:693,t:1527268408809};\\\", \\\"{x:1250,y:716,t:1527268408826};\\\", \\\"{x:1265,y:739,t:1527268408842};\\\", \\\"{x:1285,y:767,t:1527268408860};\\\", \\\"{x:1307,y:801,t:1527268408876};\\\", \\\"{x:1318,y:818,t:1527268408892};\\\", \\\"{x:1324,y:834,t:1527268408910};\\\", \\\"{x:1328,y:852,t:1527268408927};\\\", \\\"{x:1331,y:875,t:1527268408942};\\\", \\\"{x:1331,y:898,t:1527268408959};\\\", \\\"{x:1331,y:926,t:1527268408977};\\\", \\\"{x:1331,y:953,t:1527268408993};\\\", \\\"{x:1333,y:973,t:1527268409009};\\\", \\\"{x:1335,y:986,t:1527268409028};\\\", \\\"{x:1337,y:993,t:1527268409043};\\\", \\\"{x:1338,y:994,t:1527268409059};\\\", \\\"{x:1340,y:993,t:1527268409141};\\\", \\\"{x:1341,y:992,t:1527268409149};\\\", \\\"{x:1343,y:989,t:1527268409159};\\\", \\\"{x:1348,y:982,t:1527268409177};\\\", \\\"{x:1354,y:976,t:1527268409193};\\\", \\\"{x:1356,y:973,t:1527268409209};\\\", \\\"{x:1357,y:971,t:1527268409226};\\\", \\\"{x:1358,y:970,t:1527268409244};\\\", \\\"{x:1359,y:969,t:1527268409260};\\\", \\\"{x:1364,y:964,t:1527268409277};\\\", \\\"{x:1365,y:962,t:1527268409294};\\\", \\\"{x:1366,y:962,t:1527268409389};\\\", \\\"{x:1366,y:961,t:1527268409396};\\\", \\\"{x:1366,y:959,t:1527268409410};\\\", \\\"{x:1366,y:957,t:1527268409426};\\\", \\\"{x:1366,y:953,t:1527268409443};\\\", \\\"{x:1366,y:951,t:1527268409459};\\\", \\\"{x:1366,y:948,t:1527268409476};\\\", \\\"{x:1366,y:945,t:1527268409494};\\\", \\\"{x:1366,y:942,t:1527268409510};\\\", \\\"{x:1366,y:941,t:1527268409527};\\\", \\\"{x:1366,y:937,t:1527268409544};\\\", \\\"{x:1366,y:935,t:1527268409561};\\\", \\\"{x:1366,y:933,t:1527268409577};\\\", \\\"{x:1366,y:931,t:1527268409594};\\\", \\\"{x:1366,y:927,t:1527268409611};\\\", \\\"{x:1366,y:922,t:1527268409627};\\\", \\\"{x:1365,y:917,t:1527268409643};\\\", \\\"{x:1364,y:910,t:1527268409660};\\\", \\\"{x:1364,y:905,t:1527268409677};\\\", \\\"{x:1363,y:898,t:1527268409694};\\\", \\\"{x:1360,y:888,t:1527268409711};\\\", \\\"{x:1358,y:878,t:1527268409726};\\\", \\\"{x:1355,y:860,t:1527268409743};\\\", \\\"{x:1353,y:843,t:1527268409761};\\\", \\\"{x:1351,y:822,t:1527268409776};\\\", \\\"{x:1351,y:806,t:1527268409794};\\\", \\\"{x:1351,y:791,t:1527268409810};\\\", \\\"{x:1351,y:777,t:1527268409826};\\\", \\\"{x:1351,y:767,t:1527268409846};\\\", \\\"{x:1351,y:749,t:1527268409860};\\\", \\\"{x:1351,y:738,t:1527268409876};\\\", \\\"{x:1351,y:731,t:1527268409892};\\\", \\\"{x:1351,y:725,t:1527268409909};\\\", \\\"{x:1351,y:721,t:1527268409926};\\\", \\\"{x:1351,y:716,t:1527268409943};\\\", \\\"{x:1351,y:712,t:1527268409959};\\\", \\\"{x:1352,y:706,t:1527268409977};\\\", \\\"{x:1353,y:701,t:1527268409994};\\\", \\\"{x:1353,y:698,t:1527268410010};\\\", \\\"{x:1353,y:695,t:1527268410027};\\\", \\\"{x:1354,y:692,t:1527268410044};\\\", \\\"{x:1354,y:689,t:1527268410060};\\\", \\\"{x:1354,y:683,t:1527268410078};\\\", \\\"{x:1354,y:678,t:1527268410093};\\\", \\\"{x:1354,y:673,t:1527268410111};\\\", \\\"{x:1354,y:670,t:1527268410128};\\\", \\\"{x:1354,y:669,t:1527268410143};\\\", \\\"{x:1354,y:668,t:1527268410161};\\\", \\\"{x:1354,y:666,t:1527268410325};\\\", \\\"{x:1354,y:662,t:1527268410332};\\\", \\\"{x:1354,y:659,t:1527268410343};\\\", \\\"{x:1353,y:646,t:1527268410360};\\\", \\\"{x:1350,y:632,t:1527268410377};\\\", \\\"{x:1346,y:614,t:1527268410394};\\\", \\\"{x:1344,y:597,t:1527268410410};\\\", \\\"{x:1341,y:576,t:1527268410428};\\\", \\\"{x:1335,y:551,t:1527268410445};\\\", \\\"{x:1333,y:535,t:1527268410460};\\\", \\\"{x:1332,y:527,t:1527268410477};\\\", \\\"{x:1331,y:520,t:1527268410494};\\\", \\\"{x:1330,y:515,t:1527268410510};\\\", \\\"{x:1330,y:513,t:1527268410527};\\\", \\\"{x:1330,y:512,t:1527268410549};\\\", \\\"{x:1330,y:511,t:1527268410561};\\\", \\\"{x:1329,y:511,t:1527268410780};\\\", \\\"{x:1328,y:520,t:1527268410795};\\\", \\\"{x:1324,y:541,t:1527268410811};\\\", \\\"{x:1322,y:565,t:1527268410827};\\\", \\\"{x:1316,y:604,t:1527268410844};\\\", \\\"{x:1311,y:630,t:1527268410861};\\\", \\\"{x:1311,y:656,t:1527268410878};\\\", \\\"{x:1311,y:667,t:1527268410885};\\\", \\\"{x:1311,y:678,t:1527268410894};\\\", \\\"{x:1313,y:692,t:1527268410911};\\\", \\\"{x:1317,y:702,t:1527268410927};\\\", \\\"{x:1318,y:708,t:1527268410944};\\\", \\\"{x:1320,y:712,t:1527268410961};\\\", \\\"{x:1320,y:713,t:1527268410977};\\\", \\\"{x:1320,y:713,t:1527268411028};\\\", \\\"{x:1320,y:715,t:1527268411253};\\\", \\\"{x:1320,y:716,t:1527268411261};\\\", \\\"{x:1320,y:717,t:1527268411277};\\\", \\\"{x:1320,y:719,t:1527268411363};\\\", \\\"{x:1320,y:721,t:1527268411378};\\\", \\\"{x:1315,y:729,t:1527268411394};\\\", \\\"{x:1307,y:734,t:1527268411411};\\\", \\\"{x:1293,y:741,t:1527268411427};\\\", \\\"{x:1282,y:744,t:1527268411443};\\\", \\\"{x:1268,y:748,t:1527268411461};\\\", \\\"{x:1244,y:752,t:1527268411478};\\\", \\\"{x:1197,y:752,t:1527268411495};\\\", \\\"{x:1106,y:742,t:1527268411511};\\\", \\\"{x:1009,y:730,t:1527268411528};\\\", \\\"{x:912,y:717,t:1527268411544};\\\", \\\"{x:809,y:701,t:1527268411561};\\\", \\\"{x:734,y:681,t:1527268411578};\\\", \\\"{x:700,y:669,t:1527268411594};\\\", \\\"{x:675,y:653,t:1527268411611};\\\", \\\"{x:659,y:639,t:1527268411628};\\\", \\\"{x:652,y:629,t:1527268411645};\\\", \\\"{x:649,y:622,t:1527268411660};\\\", \\\"{x:645,y:618,t:1527268411678};\\\", \\\"{x:642,y:615,t:1527268411694};\\\", \\\"{x:636,y:613,t:1527268411710};\\\", \\\"{x:631,y:613,t:1527268411728};\\\", \\\"{x:630,y:613,t:1527268411744};\\\", \\\"{x:624,y:613,t:1527268411761};\\\", \\\"{x:616,y:613,t:1527268411778};\\\", \\\"{x:598,y:616,t:1527268411796};\\\", \\\"{x:581,y:617,t:1527268411811};\\\", \\\"{x:562,y:617,t:1527268411827};\\\", \\\"{x:552,y:617,t:1527268411845};\\\", \\\"{x:538,y:617,t:1527268411861};\\\", \\\"{x:518,y:617,t:1527268411878};\\\", \\\"{x:491,y:617,t:1527268411896};\\\", \\\"{x:465,y:617,t:1527268411911};\\\", \\\"{x:449,y:614,t:1527268411928};\\\", \\\"{x:434,y:608,t:1527268411944};\\\", \\\"{x:424,y:604,t:1527268411960};\\\", \\\"{x:421,y:601,t:1527268411978};\\\", \\\"{x:417,y:600,t:1527268411995};\\\", \\\"{x:407,y:595,t:1527268412011};\\\", \\\"{x:382,y:580,t:1527268412029};\\\", \\\"{x:358,y:562,t:1527268412045};\\\", \\\"{x:322,y:535,t:1527268412062};\\\", \\\"{x:276,y:508,t:1527268412078};\\\", \\\"{x:215,y:482,t:1527268412095};\\\", \\\"{x:131,y:455,t:1527268412112};\\\", \\\"{x:60,y:439,t:1527268412127};\\\", \\\"{x:0,y:431,t:1527268412145};\\\", \\\"{x:0,y:429,t:1527268412162};\\\", \\\"{x:1,y:429,t:1527268412252};\\\", \\\"{x:1,y:430,t:1527268412292};\\\", \\\"{x:1,y:431,t:1527268412300};\\\", \\\"{x:2,y:435,t:1527268412312};\\\", \\\"{x:16,y:445,t:1527268412329};\\\", \\\"{x:42,y:456,t:1527268412346};\\\", \\\"{x:89,y:478,t:1527268412363};\\\", \\\"{x:122,y:505,t:1527268412381};\\\", \\\"{x:137,y:537,t:1527268412397};\\\", \\\"{x:140,y:563,t:1527268412412};\\\", \\\"{x:142,y:594,t:1527268412430};\\\", \\\"{x:141,y:616,t:1527268412445};\\\", \\\"{x:138,y:642,t:1527268412463};\\\", \\\"{x:134,y:660,t:1527268412478};\\\", \\\"{x:134,y:668,t:1527268412494};\\\", \\\"{x:134,y:675,t:1527268412512};\\\", \\\"{x:135,y:678,t:1527268412529};\\\", \\\"{x:135,y:680,t:1527268412545};\\\", \\\"{x:138,y:680,t:1527268412562};\\\", \\\"{x:148,y:680,t:1527268412579};\\\", \\\"{x:170,y:680,t:1527268412595};\\\", \\\"{x:257,y:680,t:1527268412612};\\\", \\\"{x:368,y:680,t:1527268412629};\\\", \\\"{x:489,y:680,t:1527268412644};\\\", \\\"{x:598,y:682,t:1527268412662};\\\", \\\"{x:692,y:682,t:1527268412679};\\\", \\\"{x:781,y:682,t:1527268412695};\\\", \\\"{x:864,y:682,t:1527268412712};\\\", \\\"{x:940,y:672,t:1527268412729};\\\", \\\"{x:970,y:656,t:1527268412746};\\\", \\\"{x:989,y:649,t:1527268412762};\\\", \\\"{x:994,y:647,t:1527268412779};\\\", \\\"{x:995,y:645,t:1527268412796};\\\", \\\"{x:997,y:640,t:1527268412812};\\\", \\\"{x:1000,y:634,t:1527268412830};\\\", \\\"{x:1002,y:630,t:1527268412846};\\\", \\\"{x:1003,y:624,t:1527268412863};\\\", \\\"{x:1003,y:619,t:1527268412880};\\\", \\\"{x:994,y:609,t:1527268412897};\\\", \\\"{x:971,y:595,t:1527268412912};\\\", \\\"{x:939,y:576,t:1527268412931};\\\", \\\"{x:914,y:561,t:1527268412948};\\\", \\\"{x:886,y:545,t:1527268412963};\\\", \\\"{x:867,y:534,t:1527268412980};\\\", \\\"{x:860,y:529,t:1527268412995};\\\", \\\"{x:859,y:527,t:1527268413013};\\\", \\\"{x:859,y:525,t:1527268413029};\\\", \\\"{x:859,y:524,t:1527268413047};\\\", \\\"{x:859,y:522,t:1527268413062};\\\", \\\"{x:860,y:520,t:1527268413079};\\\", \\\"{x:860,y:519,t:1527268413100};\\\", \\\"{x:860,y:518,t:1527268413112};\\\", \\\"{x:861,y:516,t:1527268413156};\\\", \\\"{x:861,y:515,t:1527268413285};\\\", \\\"{x:861,y:514,t:1527268413297};\\\", \\\"{x:859,y:512,t:1527268413312};\\\", \\\"{x:858,y:510,t:1527268413329};\\\", \\\"{x:858,y:509,t:1527268413345};\\\", \\\"{x:857,y:509,t:1527268413732};\\\", \\\"{x:856,y:509,t:1527268413746};\\\", \\\"{x:849,y:509,t:1527268413763};\\\", \\\"{x:842,y:510,t:1527268413780};\\\", \\\"{x:834,y:512,t:1527268413796};\\\", \\\"{x:828,y:514,t:1527268413815};\\\", \\\"{x:820,y:516,t:1527268413829};\\\", \\\"{x:801,y:518,t:1527268413847};\\\", \\\"{x:761,y:524,t:1527268413863};\\\", \\\"{x:703,y:529,t:1527268413881};\\\", \\\"{x:650,y:529,t:1527268413896};\\\", \\\"{x:591,y:530,t:1527268413913};\\\", \\\"{x:534,y:532,t:1527268413929};\\\", \\\"{x:487,y:532,t:1527268413947};\\\", \\\"{x:439,y:532,t:1527268413962};\\\", \\\"{x:369,y:532,t:1527268413979};\\\", \\\"{x:350,y:532,t:1527268413996};\\\", \\\"{x:340,y:535,t:1527268414013};\\\", \\\"{x:338,y:536,t:1527268414030};\\\", \\\"{x:334,y:537,t:1527268414046};\\\", \\\"{x:328,y:541,t:1527268414064};\\\", \\\"{x:317,y:550,t:1527268414081};\\\", \\\"{x:308,y:557,t:1527268414097};\\\", \\\"{x:304,y:566,t:1527268414114};\\\", \\\"{x:304,y:567,t:1527268414130};\\\", \\\"{x:304,y:569,t:1527268414146};\\\", \\\"{x:304,y:570,t:1527268414212};\\\", \\\"{x:304,y:571,t:1527268414220};\\\", \\\"{x:304,y:573,t:1527268414230};\\\", \\\"{x:304,y:576,t:1527268414246};\\\", \\\"{x:304,y:580,t:1527268414264};\\\", \\\"{x:304,y:581,t:1527268414280};\\\", \\\"{x:304,y:588,t:1527268414296};\\\", \\\"{x:297,y:604,t:1527268414314};\\\", \\\"{x:288,y:615,t:1527268414330};\\\", \\\"{x:283,y:617,t:1527268414346};\\\", \\\"{x:275,y:620,t:1527268414362};\\\", \\\"{x:256,y:630,t:1527268414381};\\\", \\\"{x:235,y:633,t:1527268414397};\\\", \\\"{x:215,y:633,t:1527268414413};\\\", \\\"{x:200,y:633,t:1527268414430};\\\", \\\"{x:190,y:631,t:1527268414448};\\\", \\\"{x:185,y:629,t:1527268414463};\\\", \\\"{x:180,y:627,t:1527268414480};\\\", \\\"{x:175,y:624,t:1527268414497};\\\", \\\"{x:171,y:621,t:1527268414513};\\\", \\\"{x:167,y:615,t:1527268414530};\\\", \\\"{x:160,y:607,t:1527268414547};\\\", \\\"{x:154,y:597,t:1527268414564};\\\", \\\"{x:146,y:586,t:1527268414581};\\\", \\\"{x:143,y:581,t:1527268414597};\\\", \\\"{x:139,y:572,t:1527268414614};\\\", \\\"{x:132,y:562,t:1527268414631};\\\", \\\"{x:130,y:557,t:1527268414647};\\\", \\\"{x:130,y:555,t:1527268414665};\\\", \\\"{x:130,y:551,t:1527268414680};\\\", \\\"{x:130,y:547,t:1527268414697};\\\", \\\"{x:130,y:544,t:1527268414713};\\\", \\\"{x:130,y:542,t:1527268414730};\\\", \\\"{x:131,y:540,t:1527268414748};\\\", \\\"{x:133,y:539,t:1527268414813};\\\", \\\"{x:135,y:538,t:1527268414820};\\\", \\\"{x:137,y:536,t:1527268414831};\\\", \\\"{x:142,y:533,t:1527268414847};\\\", \\\"{x:143,y:533,t:1527268414864};\\\", \\\"{x:153,y:534,t:1527268415221};\\\", \\\"{x:178,y:549,t:1527268415231};\\\", \\\"{x:260,y:592,t:1527268415247};\\\", \\\"{x:348,y:631,t:1527268415264};\\\", \\\"{x:424,y:671,t:1527268415281};\\\", \\\"{x:481,y:706,t:1527268415297};\\\", \\\"{x:531,y:737,t:1527268415315};\\\", \\\"{x:575,y:764,t:1527268415332};\\\", \\\"{x:596,y:780,t:1527268415347};\\\", \\\"{x:604,y:789,t:1527268415363};\\\", \\\"{x:604,y:790,t:1527268415381};\\\", \\\"{x:604,y:791,t:1527268415403};\\\", \\\"{x:603,y:792,t:1527268415419};\\\", \\\"{x:602,y:792,t:1527268415431};\\\", \\\"{x:600,y:792,t:1527268415447};\\\", \\\"{x:595,y:792,t:1527268415464};\\\", \\\"{x:592,y:792,t:1527268415481};\\\", \\\"{x:590,y:792,t:1527268415497};\\\", \\\"{x:586,y:790,t:1527268415514};\\\", \\\"{x:581,y:787,t:1527268415532};\\\", \\\"{x:565,y:775,t:1527268415548};\\\", \\\"{x:543,y:760,t:1527268415565};\\\", \\\"{x:501,y:732,t:1527268415582};\\\", \\\"{x:448,y:700,t:1527268415600};\\\", \\\"{x:374,y:657,t:1527268415617};\\\", \\\"{x:306,y:618,t:1527268415632};\\\", \\\"{x:233,y:579,t:1527268415648};\\\", \\\"{x:169,y:546,t:1527268415664};\\\", \\\"{x:123,y:521,t:1527268415681};\\\", \\\"{x:96,y:505,t:1527268415699};\\\", \\\"{x:87,y:500,t:1527268415714};\\\", \\\"{x:82,y:499,t:1527268415731};\\\", \\\"{x:78,y:497,t:1527268415748};\\\", \\\"{x:75,y:497,t:1527268415764};\\\", \\\"{x:68,y:497,t:1527268415781};\\\", \\\"{x:66,y:497,t:1527268415798};\\\", \\\"{x:66,y:496,t:1527268415868};\\\", \\\"{x:66,y:495,t:1527268415916};\\\", \\\"{x:68,y:495,t:1527268415932};\\\", \\\"{x:75,y:495,t:1527268415948};\\\", \\\"{x:80,y:495,t:1527268415966};\\\", \\\"{x:88,y:495,t:1527268415981};\\\", \\\"{x:93,y:495,t:1527268415998};\\\", \\\"{x:98,y:495,t:1527268416016};\\\", \\\"{x:102,y:495,t:1527268416032};\\\", \\\"{x:108,y:495,t:1527268416049};\\\", \\\"{x:114,y:496,t:1527268416066};\\\", \\\"{x:117,y:497,t:1527268416082};\\\", \\\"{x:119,y:498,t:1527268416099};\\\", \\\"{x:122,y:498,t:1527268416116};\\\", \\\"{x:124,y:501,t:1527268416132};\\\", \\\"{x:130,y:504,t:1527268416149};\\\", \\\"{x:136,y:511,t:1527268416165};\\\", \\\"{x:143,y:521,t:1527268416183};\\\", \\\"{x:153,y:532,t:1527268416199};\\\", \\\"{x:162,y:543,t:1527268416215};\\\", \\\"{x:170,y:549,t:1527268416231};\\\", \\\"{x:175,y:556,t:1527268416248};\\\", \\\"{x:177,y:560,t:1527268416265};\\\", \\\"{x:178,y:561,t:1527268416281};\\\", \\\"{x:178,y:562,t:1527268416298};\\\", \\\"{x:178,y:563,t:1527268416356};\\\", \\\"{x:176,y:563,t:1527268416484};\\\", \\\"{x:172,y:563,t:1527268416498};\\\", \\\"{x:169,y:563,t:1527268416516};\\\", \\\"{x:168,y:561,t:1527268416630};\\\", \\\"{x:168,y:557,t:1527268416648};\\\", \\\"{x:168,y:553,t:1527268416665};\\\", \\\"{x:166,y:551,t:1527268416682};\\\", \\\"{x:166,y:549,t:1527268416698};\\\", \\\"{x:165,y:549,t:1527268416715};\\\", \\\"{x:165,y:548,t:1527268417076};\\\", \\\"{x:169,y:547,t:1527268417083};\\\", \\\"{x:180,y:551,t:1527268417099};\\\", \\\"{x:204,y:570,t:1527268417116};\\\", \\\"{x:251,y:621,t:1527268417132};\\\", \\\"{x:282,y:662,t:1527268417149};\\\", \\\"{x:313,y:702,t:1527268417165};\\\", \\\"{x:332,y:724,t:1527268417182};\\\", \\\"{x:346,y:740,t:1527268417199};\\\", \\\"{x:354,y:748,t:1527268417215};\\\", \\\"{x:358,y:752,t:1527268417232};\\\", \\\"{x:360,y:754,t:1527268417249};\\\", \\\"{x:360,y:755,t:1527268417266};\\\", \\\"{x:361,y:755,t:1527268417283};\\\", \\\"{x:362,y:755,t:1527268417299};\\\", \\\"{x:363,y:755,t:1527268417316};\\\", \\\"{x:365,y:755,t:1527268417332};\\\", \\\"{x:367,y:755,t:1527268417349};\\\", \\\"{x:369,y:754,t:1527268417366};\\\", \\\"{x:372,y:753,t:1527268417382};\\\", \\\"{x:373,y:752,t:1527268417400};\\\", \\\"{x:375,y:749,t:1527268417417};\\\", \\\"{x:377,y:747,t:1527268417432};\\\", \\\"{x:377,y:746,t:1527268417450};\\\", \\\"{x:378,y:744,t:1527268417466};\\\", \\\"{x:379,y:743,t:1527268417482};\\\", \\\"{x:380,y:740,t:1527268417500};\\\", \\\"{x:387,y:732,t:1527268417517};\\\", \\\"{x:391,y:726,t:1527268417533};\\\", \\\"{x:394,y:721,t:1527268417549};\\\", \\\"{x:396,y:718,t:1527268417567};\\\", \\\"{x:397,y:716,t:1527268417583};\\\", \\\"{x:399,y:715,t:1527268417600};\\\", \\\"{x:401,y:713,t:1527268417617};\\\", \\\"{x:409,y:711,t:1527268417633};\\\", \\\"{x:419,y:710,t:1527268417650};\\\", \\\"{x:431,y:710,t:1527268417667};\\\", \\\"{x:446,y:712,t:1527268417683};\\\", \\\"{x:449,y:713,t:1527268417700};\\\", \\\"{x:452,y:714,t:1527268417716};\\\", \\\"{x:453,y:715,t:1527268417733};\\\", \\\"{x:456,y:718,t:1527268417756};\\\", \\\"{x:460,y:723,t:1527268417768};\\\", \\\"{x:472,y:736,t:1527268417783};\\\", \\\"{x:491,y:749,t:1527268417799};\\\", \\\"{x:506,y:758,t:1527268417816};\\\", \\\"{x:514,y:764,t:1527268417833};\\\", \\\"{x:517,y:767,t:1527268417849};\\\", \\\"{x:518,y:768,t:1527268417866};\\\", \\\"{x:519,y:768,t:1527268417955};\\\", \\\"{x:520,y:768,t:1527268417972};\\\", \\\"{x:520,y:766,t:1527268417983};\\\", \\\"{x:520,y:762,t:1527268418000};\\\", \\\"{x:520,y:761,t:1527268418016};\\\", \\\"{x:520,y:759,t:1527268418034};\\\", \\\"{x:520,y:756,t:1527268418050};\\\", \\\"{x:520,y:752,t:1527268418067};\\\", \\\"{x:520,y:748,t:1527268418083};\\\", \\\"{x:520,y:741,t:1527268418100};\\\", \\\"{x:520,y:732,t:1527268418116};\\\", \\\"{x:520,y:729,t:1527268418133};\\\", \\\"{x:520,y:728,t:1527268418901};\\\", \\\"{x:520,y:726,t:1527268418918};\\\" ] }, { \\\"rt\\\": 11897, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 471284, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"967LR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:520,y:725,t:1527268419812};\\\", \\\"{x:497,y:637,t:1527268419970};\\\", \\\"{x:496,y:611,t:1527268419985};\\\", \\\"{x:500,y:557,t:1527268420002};\\\", \\\"{x:532,y:462,t:1527268420018};\\\", \\\"{x:577,y:400,t:1527268420034};\\\", \\\"{x:694,y:323,t:1527268420051};\\\", \\\"{x:790,y:281,t:1527268420067};\\\", \\\"{x:895,y:238,t:1527268420084};\\\", \\\"{x:993,y:202,t:1527268420101};\\\", \\\"{x:1097,y:182,t:1527268420118};\\\", \\\"{x:1191,y:168,t:1527268420134};\\\", \\\"{x:1274,y:161,t:1527268420152};\\\", \\\"{x:1313,y:161,t:1527268420169};\\\", \\\"{x:1341,y:161,t:1527268420184};\\\", \\\"{x:1369,y:164,t:1527268420202};\\\", \\\"{x:1393,y:170,t:1527268420218};\\\", \\\"{x:1415,y:180,t:1527268420234};\\\", \\\"{x:1453,y:203,t:1527268420252};\\\", \\\"{x:1482,y:225,t:1527268420268};\\\", \\\"{x:1527,y:258,t:1527268420285};\\\", \\\"{x:1577,y:289,t:1527268420302};\\\", \\\"{x:1614,y:316,t:1527268420319};\\\", \\\"{x:1636,y:330,t:1527268420334};\\\", \\\"{x:1651,y:338,t:1527268420352};\\\", \\\"{x:1653,y:340,t:1527268420369};\\\", \\\"{x:1653,y:341,t:1527268420469};\\\", \\\"{x:1653,y:342,t:1527268420485};\\\", \\\"{x:1651,y:338,t:1527268420619};\\\", \\\"{x:1649,y:327,t:1527268420635};\\\", \\\"{x:1643,y:308,t:1527268420652};\\\", \\\"{x:1637,y:297,t:1527268420668};\\\", \\\"{x:1632,y:291,t:1527268420686};\\\", \\\"{x:1631,y:289,t:1527268420701};\\\", \\\"{x:1630,y:289,t:1527268420718};\\\", \\\"{x:1630,y:288,t:1527268420736};\\\", \\\"{x:1626,y:288,t:1527268420752};\\\", \\\"{x:1622,y:287,t:1527268420769};\\\", \\\"{x:1614,y:286,t:1527268420785};\\\", \\\"{x:1609,y:285,t:1527268420802};\\\", \\\"{x:1606,y:285,t:1527268420818};\\\", \\\"{x:1606,y:284,t:1527268420835};\\\", \\\"{x:1605,y:284,t:1527268420989};\\\", \\\"{x:1603,y:284,t:1527268421003};\\\", \\\"{x:1602,y:285,t:1527268421019};\\\", \\\"{x:1600,y:285,t:1527268421036};\\\", \\\"{x:1597,y:286,t:1527268421053};\\\", \\\"{x:1594,y:289,t:1527268421069};\\\", \\\"{x:1591,y:290,t:1527268421086};\\\", \\\"{x:1588,y:291,t:1527268421103};\\\", \\\"{x:1586,y:293,t:1527268421119};\\\", \\\"{x:1585,y:294,t:1527268421149};\\\", \\\"{x:1584,y:295,t:1527268421156};\\\", \\\"{x:1583,y:296,t:1527268421169};\\\", \\\"{x:1579,y:298,t:1527268421187};\\\", \\\"{x:1574,y:303,t:1527268421203};\\\", \\\"{x:1567,y:308,t:1527268421220};\\\", \\\"{x:1559,y:313,t:1527268421236};\\\", \\\"{x:1539,y:327,t:1527268421253};\\\", \\\"{x:1527,y:335,t:1527268421269};\\\", \\\"{x:1515,y:343,t:1527268421286};\\\", \\\"{x:1508,y:349,t:1527268421302};\\\", \\\"{x:1503,y:353,t:1527268421318};\\\", \\\"{x:1500,y:357,t:1527268421335};\\\", \\\"{x:1496,y:362,t:1527268421352};\\\", \\\"{x:1492,y:369,t:1527268421369};\\\", \\\"{x:1484,y:382,t:1527268421385};\\\", \\\"{x:1475,y:397,t:1527268421402};\\\", \\\"{x:1459,y:425,t:1527268421419};\\\", \\\"{x:1452,y:442,t:1527268421435};\\\", \\\"{x:1445,y:457,t:1527268421453};\\\", \\\"{x:1441,y:467,t:1527268421469};\\\", \\\"{x:1432,y:484,t:1527268421485};\\\", \\\"{x:1420,y:505,t:1527268421502};\\\", \\\"{x:1396,y:547,t:1527268421520};\\\", \\\"{x:1364,y:601,t:1527268421535};\\\", \\\"{x:1329,y:666,t:1527268421552};\\\", \\\"{x:1301,y:727,t:1527268421570};\\\", \\\"{x:1284,y:776,t:1527268421585};\\\", \\\"{x:1266,y:813,t:1527268421602};\\\", \\\"{x:1253,y:839,t:1527268421620};\\\", \\\"{x:1251,y:843,t:1527268421636};\\\", \\\"{x:1252,y:843,t:1527268421837};\\\", \\\"{x:1258,y:829,t:1527268421853};\\\", \\\"{x:1262,y:817,t:1527268421870};\\\", \\\"{x:1266,y:803,t:1527268421886};\\\", \\\"{x:1268,y:786,t:1527268421903};\\\", \\\"{x:1271,y:773,t:1527268421919};\\\", \\\"{x:1274,y:762,t:1527268421936};\\\", \\\"{x:1276,y:757,t:1527268421953};\\\", \\\"{x:1278,y:749,t:1527268421970};\\\", \\\"{x:1280,y:744,t:1527268421986};\\\", \\\"{x:1283,y:738,t:1527268422003};\\\", \\\"{x:1284,y:736,t:1527268422020};\\\", \\\"{x:1287,y:732,t:1527268422036};\\\", \\\"{x:1290,y:729,t:1527268422053};\\\", \\\"{x:1293,y:726,t:1527268422070};\\\", \\\"{x:1295,y:724,t:1527268422087};\\\", \\\"{x:1298,y:722,t:1527268422103};\\\", \\\"{x:1302,y:717,t:1527268422120};\\\", \\\"{x:1304,y:715,t:1527268422137};\\\", \\\"{x:1310,y:712,t:1527268422153};\\\", \\\"{x:1314,y:711,t:1527268422170};\\\", \\\"{x:1316,y:709,t:1527268422187};\\\", \\\"{x:1317,y:709,t:1527268422349};\\\", \\\"{x:1318,y:708,t:1527268422365};\\\", \\\"{x:1319,y:708,t:1527268422844};\\\", \\\"{x:1322,y:706,t:1527268422854};\\\", \\\"{x:1326,y:704,t:1527268422870};\\\", \\\"{x:1328,y:703,t:1527268422887};\\\", \\\"{x:1329,y:702,t:1527268422904};\\\", \\\"{x:1330,y:702,t:1527268422924};\\\", \\\"{x:1331,y:702,t:1527268422948};\\\", \\\"{x:1332,y:701,t:1527268422956};\\\", \\\"{x:1333,y:701,t:1527268422970};\\\", \\\"{x:1337,y:700,t:1527268422987};\\\", \\\"{x:1341,y:699,t:1527268423005};\\\", \\\"{x:1343,y:698,t:1527268423023};\\\", \\\"{x:1343,y:699,t:1527268425340};\\\", \\\"{x:1343,y:701,t:1527268425356};\\\", \\\"{x:1343,y:709,t:1527268425372};\\\", \\\"{x:1343,y:713,t:1527268425388};\\\", \\\"{x:1343,y:715,t:1527268425405};\\\", \\\"{x:1343,y:716,t:1527268425422};\\\", \\\"{x:1343,y:717,t:1527268425438};\\\", \\\"{x:1343,y:718,t:1527268425455};\\\", \\\"{x:1343,y:719,t:1527268425637};\\\", \\\"{x:1343,y:720,t:1527268425644};\\\", \\\"{x:1343,y:723,t:1527268425655};\\\", \\\"{x:1343,y:725,t:1527268425672};\\\", \\\"{x:1343,y:727,t:1527268425689};\\\", \\\"{x:1343,y:729,t:1527268425705};\\\", \\\"{x:1343,y:731,t:1527268425721};\\\", \\\"{x:1343,y:733,t:1527268425773};\\\", \\\"{x:1343,y:735,t:1527268425789};\\\", \\\"{x:1343,y:738,t:1527268425805};\\\", \\\"{x:1344,y:742,t:1527268425822};\\\", \\\"{x:1345,y:743,t:1527268425839};\\\", \\\"{x:1345,y:746,t:1527268425855};\\\", \\\"{x:1347,y:748,t:1527268425872};\\\", \\\"{x:1347,y:749,t:1527268425893};\\\", \\\"{x:1348,y:751,t:1527268425948};\\\", \\\"{x:1348,y:752,t:1527268425957};\\\", \\\"{x:1348,y:755,t:1527268425972};\\\", \\\"{x:1349,y:758,t:1527268425990};\\\", \\\"{x:1349,y:762,t:1527268426005};\\\", \\\"{x:1349,y:763,t:1527268426028};\\\", \\\"{x:1349,y:764,t:1527268426044};\\\", \\\"{x:1349,y:765,t:1527268426055};\\\", \\\"{x:1350,y:765,t:1527268426072};\\\", \\\"{x:1350,y:769,t:1527268426090};\\\", \\\"{x:1350,y:772,t:1527268426105};\\\", \\\"{x:1351,y:775,t:1527268426122};\\\", \\\"{x:1351,y:776,t:1527268426139};\\\", \\\"{x:1352,y:777,t:1527268426205};\\\", \\\"{x:1352,y:778,t:1527268426244};\\\", \\\"{x:1352,y:779,t:1527268426260};\\\", \\\"{x:1352,y:781,t:1527268426276};\\\", \\\"{x:1352,y:782,t:1527268426293};\\\", \\\"{x:1352,y:784,t:1527268426308};\\\", \\\"{x:1352,y:785,t:1527268426324};\\\", \\\"{x:1353,y:786,t:1527268426339};\\\", \\\"{x:1353,y:787,t:1527268426356};\\\", \\\"{x:1353,y:788,t:1527268426380};\\\", \\\"{x:1353,y:790,t:1527268426396};\\\", \\\"{x:1353,y:791,t:1527268426412};\\\", \\\"{x:1353,y:794,t:1527268426422};\\\", \\\"{x:1353,y:796,t:1527268426439};\\\", \\\"{x:1353,y:798,t:1527268426456};\\\", \\\"{x:1353,y:799,t:1527268426472};\\\", \\\"{x:1353,y:800,t:1527268426489};\\\", \\\"{x:1353,y:801,t:1527268426517};\\\", \\\"{x:1353,y:802,t:1527268426548};\\\", \\\"{x:1353,y:803,t:1527268426572};\\\", \\\"{x:1353,y:804,t:1527268426637};\\\", \\\"{x:1354,y:807,t:1527268426652};\\\", \\\"{x:1354,y:808,t:1527268426669};\\\", \\\"{x:1354,y:809,t:1527268426676};\\\", \\\"{x:1355,y:813,t:1527268426689};\\\", \\\"{x:1356,y:815,t:1527268426706};\\\", \\\"{x:1357,y:819,t:1527268426723};\\\", \\\"{x:1358,y:822,t:1527268426739};\\\", \\\"{x:1359,y:825,t:1527268426757};\\\", \\\"{x:1360,y:827,t:1527268426772};\\\", \\\"{x:1360,y:828,t:1527268426789};\\\", \\\"{x:1361,y:830,t:1527268426806};\\\", \\\"{x:1361,y:834,t:1527268426824};\\\", \\\"{x:1361,y:840,t:1527268426839};\\\", \\\"{x:1362,y:849,t:1527268426856};\\\", \\\"{x:1365,y:857,t:1527268426873};\\\", \\\"{x:1365,y:859,t:1527268426890};\\\", \\\"{x:1366,y:863,t:1527268426906};\\\", \\\"{x:1367,y:866,t:1527268426924};\\\", \\\"{x:1367,y:868,t:1527268426949};\\\", \\\"{x:1367,y:869,t:1527268426956};\\\", \\\"{x:1367,y:870,t:1527268426972};\\\", \\\"{x:1367,y:872,t:1527268426989};\\\", \\\"{x:1367,y:875,t:1527268427006};\\\", \\\"{x:1367,y:876,t:1527268427023};\\\", \\\"{x:1367,y:879,t:1527268427039};\\\", \\\"{x:1367,y:880,t:1527268427056};\\\", \\\"{x:1367,y:881,t:1527268427073};\\\", \\\"{x:1363,y:878,t:1527268428557};\\\", \\\"{x:1333,y:868,t:1527268428575};\\\", \\\"{x:1299,y:858,t:1527268428590};\\\", \\\"{x:1245,y:847,t:1527268428607};\\\", \\\"{x:1178,y:830,t:1527268428625};\\\", \\\"{x:1095,y:803,t:1527268428641};\\\", \\\"{x:1011,y:774,t:1527268428657};\\\", \\\"{x:934,y:746,t:1527268428674};\\\", \\\"{x:854,y:712,t:1527268428690};\\\", \\\"{x:780,y:681,t:1527268428707};\\\", \\\"{x:677,y:637,t:1527268428724};\\\", \\\"{x:620,y:619,t:1527268428741};\\\", \\\"{x:566,y:597,t:1527268428758};\\\", \\\"{x:516,y:581,t:1527268428790};\\\", \\\"{x:506,y:578,t:1527268428808};\\\", \\\"{x:501,y:578,t:1527268428825};\\\", \\\"{x:499,y:578,t:1527268428841};\\\", \\\"{x:496,y:578,t:1527268428859};\\\", \\\"{x:493,y:578,t:1527268428875};\\\", \\\"{x:488,y:578,t:1527268428891};\\\", \\\"{x:484,y:578,t:1527268428909};\\\", \\\"{x:472,y:578,t:1527268428925};\\\", \\\"{x:456,y:578,t:1527268428941};\\\", \\\"{x:435,y:578,t:1527268428958};\\\", \\\"{x:420,y:578,t:1527268428974};\\\", \\\"{x:413,y:578,t:1527268428992};\\\", \\\"{x:409,y:578,t:1527268429008};\\\", \\\"{x:405,y:579,t:1527268429025};\\\", \\\"{x:398,y:581,t:1527268429042};\\\", \\\"{x:390,y:588,t:1527268429059};\\\", \\\"{x:377,y:593,t:1527268429076};\\\", \\\"{x:361,y:597,t:1527268429093};\\\", \\\"{x:345,y:600,t:1527268429109};\\\", \\\"{x:331,y:603,t:1527268429126};\\\", \\\"{x:320,y:603,t:1527268429142};\\\", \\\"{x:303,y:604,t:1527268429159};\\\", \\\"{x:280,y:604,t:1527268429175};\\\", \\\"{x:251,y:604,t:1527268429193};\\\", \\\"{x:212,y:604,t:1527268429209};\\\", \\\"{x:173,y:604,t:1527268429226};\\\", \\\"{x:147,y:604,t:1527268429242};\\\", \\\"{x:137,y:604,t:1527268429259};\\\", \\\"{x:136,y:604,t:1527268429275};\\\", \\\"{x:135,y:604,t:1527268429380};\\\", \\\"{x:135,y:603,t:1527268429419};\\\", \\\"{x:137,y:603,t:1527268429427};\\\", \\\"{x:142,y:600,t:1527268429443};\\\", \\\"{x:160,y:594,t:1527268429459};\\\", \\\"{x:188,y:588,t:1527268429476};\\\", \\\"{x:196,y:586,t:1527268429493};\\\", \\\"{x:199,y:585,t:1527268429508};\\\", \\\"{x:203,y:584,t:1527268429525};\\\", \\\"{x:203,y:583,t:1527268429543};\\\", \\\"{x:208,y:583,t:1527268429559};\\\", \\\"{x:226,y:583,t:1527268429575};\\\", \\\"{x:252,y:587,t:1527268429593};\\\", \\\"{x:294,y:593,t:1527268429610};\\\", \\\"{x:341,y:599,t:1527268429626};\\\", \\\"{x:384,y:600,t:1527268429643};\\\", \\\"{x:413,y:600,t:1527268429659};\\\", \\\"{x:434,y:600,t:1527268429676};\\\", \\\"{x:442,y:600,t:1527268429693};\\\", \\\"{x:447,y:598,t:1527268429708};\\\", \\\"{x:449,y:598,t:1527268429726};\\\", \\\"{x:450,y:596,t:1527268429743};\\\", \\\"{x:451,y:596,t:1527268429760};\\\", \\\"{x:451,y:594,t:1527268429812};\\\", \\\"{x:451,y:593,t:1527268429826};\\\", \\\"{x:450,y:592,t:1527268429842};\\\", \\\"{x:449,y:591,t:1527268429859};\\\", \\\"{x:449,y:587,t:1527268429875};\\\", \\\"{x:448,y:583,t:1527268429893};\\\", \\\"{x:448,y:578,t:1527268429910};\\\", \\\"{x:444,y:571,t:1527268429927};\\\", \\\"{x:441,y:567,t:1527268429943};\\\", \\\"{x:440,y:563,t:1527268429959};\\\", \\\"{x:440,y:561,t:1527268429978};\\\", \\\"{x:437,y:559,t:1527268429992};\\\", \\\"{x:437,y:558,t:1527268430027};\\\", \\\"{x:437,y:557,t:1527268430042};\\\", \\\"{x:454,y:547,t:1527268430060};\\\", \\\"{x:461,y:543,t:1527268430076};\\\", \\\"{x:459,y:543,t:1527268430116};\\\", \\\"{x:441,y:543,t:1527268430126};\\\", \\\"{x:387,y:552,t:1527268430143};\\\", \\\"{x:337,y:558,t:1527268430160};\\\", \\\"{x:298,y:558,t:1527268430177};\\\", \\\"{x:265,y:558,t:1527268430193};\\\", \\\"{x:244,y:557,t:1527268430210};\\\", \\\"{x:234,y:556,t:1527268430227};\\\", \\\"{x:228,y:555,t:1527268430244};\\\", \\\"{x:222,y:555,t:1527268430260};\\\", \\\"{x:222,y:554,t:1527268430276};\\\", \\\"{x:220,y:554,t:1527268430388};\\\", \\\"{x:212,y:554,t:1527268430395};\\\", \\\"{x:205,y:554,t:1527268430410};\\\", \\\"{x:186,y:555,t:1527268430427};\\\", \\\"{x:178,y:555,t:1527268430443};\\\", \\\"{x:174,y:555,t:1527268430460};\\\", \\\"{x:173,y:554,t:1527268430524};\\\", \\\"{x:173,y:550,t:1527268430532};\\\", \\\"{x:173,y:549,t:1527268430545};\\\", \\\"{x:173,y:548,t:1527268430560};\\\", \\\"{x:173,y:547,t:1527268430747};\\\", \\\"{x:174,y:547,t:1527268430759};\\\", \\\"{x:188,y:555,t:1527268430777};\\\", \\\"{x:221,y:570,t:1527268430794};\\\", \\\"{x:277,y:590,t:1527268430811};\\\", \\\"{x:351,y:617,t:1527268430827};\\\", \\\"{x:437,y:651,t:1527268430844};\\\", \\\"{x:492,y:682,t:1527268430860};\\\", \\\"{x:532,y:702,t:1527268430876};\\\", \\\"{x:559,y:720,t:1527268430894};\\\", \\\"{x:574,y:736,t:1527268430910};\\\", \\\"{x:584,y:749,t:1527268430926};\\\", \\\"{x:591,y:760,t:1527268430944};\\\", \\\"{x:594,y:769,t:1527268430960};\\\", \\\"{x:596,y:773,t:1527268430976};\\\", \\\"{x:596,y:776,t:1527268430994};\\\", \\\"{x:596,y:777,t:1527268431053};\\\", \\\"{x:595,y:777,t:1527268431060};\\\", \\\"{x:588,y:776,t:1527268431077};\\\", \\\"{x:586,y:774,t:1527268431094};\\\", \\\"{x:585,y:774,t:1527268431111};\\\", \\\"{x:584,y:772,t:1527268431127};\\\", \\\"{x:575,y:768,t:1527268431144};\\\", \\\"{x:553,y:762,t:1527268431162};\\\", \\\"{x:524,y:755,t:1527268431177};\\\", \\\"{x:507,y:750,t:1527268431195};\\\", \\\"{x:502,y:747,t:1527268431210};\\\", \\\"{x:502,y:746,t:1527268431227};\\\", \\\"{x:501,y:746,t:1527268431363};\\\", \\\"{x:501,y:746,t:1527268431408};\\\", \\\"{x:500,y:746,t:1527268431764};\\\", \\\"{x:500,y:744,t:1527268431778};\\\", \\\"{x:501,y:744,t:1527268431793};\\\", \\\"{x:503,y:742,t:1527268431810};\\\", \\\"{x:505,y:741,t:1527268431827};\\\", \\\"{x:506,y:740,t:1527268431844};\\\", \\\"{x:507,y:739,t:1527268431868};\\\", \\\"{x:508,y:738,t:1527268431878};\\\" ] }, { \\\"rt\\\": 33470, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 506069, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"967LR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -Z \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:509,y:738,t:1527268433348};\\\", \\\"{x:510,y:736,t:1527268433362};\\\", \\\"{x:513,y:727,t:1527268433379};\\\", \\\"{x:514,y:711,t:1527268433397};\\\", \\\"{x:514,y:691,t:1527268433412};\\\", \\\"{x:514,y:676,t:1527268433429};\\\", \\\"{x:514,y:659,t:1527268433446};\\\", \\\"{x:514,y:642,t:1527268433462};\\\", \\\"{x:514,y:621,t:1527268433479};\\\", \\\"{x:514,y:611,t:1527268433495};\\\", \\\"{x:515,y:600,t:1527268433512};\\\", \\\"{x:517,y:587,t:1527268433530};\\\", \\\"{x:521,y:575,t:1527268433545};\\\", \\\"{x:523,y:568,t:1527268433562};\\\", \\\"{x:525,y:564,t:1527268433578};\\\", \\\"{x:531,y:555,t:1527268433596};\\\", \\\"{x:535,y:551,t:1527268433613};\\\", \\\"{x:541,y:545,t:1527268433628};\\\", \\\"{x:548,y:539,t:1527268433646};\\\", \\\"{x:556,y:533,t:1527268433662};\\\", \\\"{x:572,y:526,t:1527268433679};\\\", \\\"{x:586,y:517,t:1527268433697};\\\", \\\"{x:606,y:510,t:1527268433713};\\\", \\\"{x:627,y:501,t:1527268433729};\\\", \\\"{x:639,y:495,t:1527268433746};\\\", \\\"{x:648,y:492,t:1527268433763};\\\", \\\"{x:650,y:491,t:1527268433779};\\\", \\\"{x:651,y:491,t:1527268433795};\\\", \\\"{x:654,y:498,t:1527268434452};\\\", \\\"{x:662,y:516,t:1527268434463};\\\", \\\"{x:672,y:546,t:1527268434482};\\\", \\\"{x:688,y:594,t:1527268434497};\\\", \\\"{x:695,y:639,t:1527268434513};\\\", \\\"{x:698,y:666,t:1527268434529};\\\", \\\"{x:698,y:668,t:1527268434546};\\\", \\\"{x:698,y:669,t:1527268434804};\\\", \\\"{x:694,y:671,t:1527268434813};\\\", \\\"{x:684,y:676,t:1527268434830};\\\", \\\"{x:669,y:685,t:1527268434847};\\\", \\\"{x:653,y:694,t:1527268434864};\\\", \\\"{x:639,y:703,t:1527268434881};\\\", \\\"{x:628,y:713,t:1527268434898};\\\", \\\"{x:616,y:722,t:1527268434913};\\\", \\\"{x:610,y:727,t:1527268434930};\\\", \\\"{x:603,y:733,t:1527268434948};\\\", \\\"{x:597,y:737,t:1527268434963};\\\", \\\"{x:592,y:742,t:1527268434980};\\\", \\\"{x:591,y:744,t:1527268434997};\\\", \\\"{x:589,y:745,t:1527268435014};\\\", \\\"{x:587,y:749,t:1527268435030};\\\", \\\"{x:583,y:753,t:1527268435048};\\\", \\\"{x:579,y:758,t:1527268435065};\\\", \\\"{x:573,y:764,t:1527268435080};\\\", \\\"{x:563,y:772,t:1527268435098};\\\", \\\"{x:552,y:781,t:1527268435114};\\\", \\\"{x:540,y:788,t:1527268435130};\\\", \\\"{x:533,y:793,t:1527268435148};\\\", \\\"{x:522,y:799,t:1527268435163};\\\", \\\"{x:518,y:802,t:1527268435180};\\\", \\\"{x:515,y:804,t:1527268435197};\\\", \\\"{x:514,y:804,t:1527268435214};\\\", \\\"{x:514,y:805,t:1527268435244};\\\", \\\"{x:515,y:802,t:1527268435356};\\\", \\\"{x:515,y:799,t:1527268435364};\\\", \\\"{x:516,y:795,t:1527268435382};\\\", \\\"{x:516,y:791,t:1527268435397};\\\", \\\"{x:516,y:789,t:1527268435414};\\\", \\\"{x:516,y:786,t:1527268435431};\\\", \\\"{x:516,y:784,t:1527268435447};\\\", \\\"{x:516,y:780,t:1527268435465};\\\", \\\"{x:515,y:775,t:1527268435482};\\\", \\\"{x:515,y:770,t:1527268435498};\\\", \\\"{x:515,y:761,t:1527268435514};\\\", \\\"{x:515,y:758,t:1527268435531};\\\", \\\"{x:514,y:752,t:1527268435549};\\\", \\\"{x:514,y:749,t:1527268435563};\\\", \\\"{x:514,y:743,t:1527268435581};\\\", \\\"{x:514,y:736,t:1527268435597};\\\", \\\"{x:517,y:722,t:1527268435614};\\\", \\\"{x:526,y:704,t:1527268435632};\\\", \\\"{x:534,y:686,t:1527268435648};\\\", \\\"{x:543,y:670,t:1527268435664};\\\", \\\"{x:549,y:661,t:1527268435681};\\\", \\\"{x:556,y:654,t:1527268435697};\\\", \\\"{x:565,y:649,t:1527268435714};\\\", \\\"{x:580,y:646,t:1527268435731};\\\", \\\"{x:605,y:637,t:1527268435747};\\\", \\\"{x:614,y:635,t:1527268435763};\\\", \\\"{x:617,y:634,t:1527268435781};\\\", \\\"{x:618,y:634,t:1527268435820};\\\", \\\"{x:620,y:633,t:1527268435831};\\\", \\\"{x:629,y:629,t:1527268435849};\\\", \\\"{x:641,y:625,t:1527268435864};\\\", \\\"{x:662,y:619,t:1527268435881};\\\", \\\"{x:684,y:616,t:1527268435898};\\\", \\\"{x:712,y:609,t:1527268435914};\\\", \\\"{x:739,y:604,t:1527268435932};\\\", \\\"{x:780,y:596,t:1527268435947};\\\", \\\"{x:812,y:592,t:1527268435965};\\\", \\\"{x:843,y:588,t:1527268435981};\\\", \\\"{x:877,y:579,t:1527268435997};\\\", \\\"{x:918,y:561,t:1527268436014};\\\", \\\"{x:966,y:537,t:1527268436031};\\\", \\\"{x:1026,y:504,t:1527268436048};\\\", \\\"{x:1079,y:469,t:1527268436064};\\\", \\\"{x:1127,y:433,t:1527268436081};\\\", \\\"{x:1178,y:406,t:1527268436097};\\\", \\\"{x:1226,y:391,t:1527268436114};\\\", \\\"{x:1288,y:387,t:1527268436131};\\\", \\\"{x:1383,y:418,t:1527268436147};\\\", \\\"{x:1453,y:480,t:1527268436164};\\\", \\\"{x:1516,y:587,t:1527268436181};\\\", \\\"{x:1561,y:694,t:1527268436198};\\\", \\\"{x:1604,y:781,t:1527268436214};\\\", \\\"{x:1637,y:831,t:1527268436231};\\\", \\\"{x:1665,y:855,t:1527268436249};\\\", \\\"{x:1681,y:868,t:1527268436265};\\\", \\\"{x:1689,y:874,t:1527268436281};\\\", \\\"{x:1690,y:874,t:1527268436298};\\\", \\\"{x:1690,y:878,t:1527268436316};\\\", \\\"{x:1690,y:883,t:1527268436331};\\\", \\\"{x:1685,y:898,t:1527268436348};\\\", \\\"{x:1678,y:909,t:1527268436365};\\\", \\\"{x:1672,y:917,t:1527268436382};\\\", \\\"{x:1669,y:917,t:1527268436398};\\\", \\\"{x:1668,y:918,t:1527268436416};\\\", \\\"{x:1666,y:919,t:1527268436431};\\\", \\\"{x:1663,y:921,t:1527268436447};\\\", \\\"{x:1653,y:925,t:1527268436465};\\\", \\\"{x:1635,y:931,t:1527268436481};\\\", \\\"{x:1611,y:940,t:1527268436497};\\\", \\\"{x:1570,y:956,t:1527268436515};\\\", \\\"{x:1557,y:959,t:1527268436530};\\\", \\\"{x:1524,y:965,t:1527268436547};\\\", \\\"{x:1510,y:965,t:1527268436565};\\\", \\\"{x:1502,y:964,t:1527268436581};\\\", \\\"{x:1494,y:962,t:1527268436598};\\\", \\\"{x:1485,y:958,t:1527268436615};\\\", \\\"{x:1474,y:950,t:1527268436631};\\\", \\\"{x:1466,y:940,t:1527268436648};\\\", \\\"{x:1458,y:929,t:1527268436665};\\\", \\\"{x:1457,y:926,t:1527268436682};\\\", \\\"{x:1455,y:925,t:1527268436698};\\\", \\\"{x:1454,y:925,t:1527268436773};\\\", \\\"{x:1451,y:925,t:1527268436783};\\\", \\\"{x:1443,y:925,t:1527268436798};\\\", \\\"{x:1432,y:928,t:1527268436815};\\\", \\\"{x:1425,y:931,t:1527268436833};\\\", \\\"{x:1423,y:931,t:1527268436848};\\\", \\\"{x:1422,y:931,t:1527268436908};\\\", \\\"{x:1421,y:932,t:1527268436924};\\\", \\\"{x:1420,y:932,t:1527268436948};\\\", \\\"{x:1421,y:927,t:1527268436965};\\\", \\\"{x:1422,y:925,t:1527268437468};\\\", \\\"{x:1428,y:923,t:1527268437482};\\\", \\\"{x:1439,y:918,t:1527268437499};\\\", \\\"{x:1450,y:911,t:1527268437515};\\\", \\\"{x:1463,y:901,t:1527268437533};\\\", \\\"{x:1469,y:897,t:1527268437550};\\\", \\\"{x:1471,y:894,t:1527268437566};\\\", \\\"{x:1473,y:892,t:1527268437583};\\\", \\\"{x:1474,y:891,t:1527268437600};\\\", \\\"{x:1475,y:890,t:1527268437616};\\\", \\\"{x:1478,y:888,t:1527268438005};\\\", \\\"{x:1486,y:880,t:1527268438017};\\\", \\\"{x:1505,y:867,t:1527268438034};\\\", \\\"{x:1535,y:842,t:1527268438049};\\\", \\\"{x:1568,y:813,t:1527268438066};\\\", \\\"{x:1602,y:777,t:1527268438083};\\\", \\\"{x:1639,y:726,t:1527268438099};\\\", \\\"{x:1656,y:687,t:1527268438115};\\\", \\\"{x:1675,y:647,t:1527268438133};\\\", \\\"{x:1685,y:609,t:1527268438149};\\\", \\\"{x:1693,y:582,t:1527268438166};\\\", \\\"{x:1698,y:559,t:1527268438183};\\\", \\\"{x:1703,y:547,t:1527268438199};\\\", \\\"{x:1704,y:541,t:1527268438216};\\\", \\\"{x:1704,y:539,t:1527268438233};\\\", \\\"{x:1703,y:541,t:1527268438284};\\\", \\\"{x:1689,y:545,t:1527268438299};\\\", \\\"{x:1680,y:548,t:1527268438316};\\\", \\\"{x:1674,y:549,t:1527268438333};\\\", \\\"{x:1669,y:551,t:1527268438349};\\\", \\\"{x:1668,y:551,t:1527268438366};\\\", \\\"{x:1668,y:552,t:1527268438383};\\\", \\\"{x:1666,y:553,t:1527268438421};\\\", \\\"{x:1665,y:553,t:1527268438434};\\\", \\\"{x:1663,y:554,t:1527268438450};\\\", \\\"{x:1659,y:561,t:1527268438467};\\\", \\\"{x:1656,y:570,t:1527268438484};\\\", \\\"{x:1653,y:583,t:1527268438500};\\\", \\\"{x:1649,y:611,t:1527268438517};\\\", \\\"{x:1649,y:627,t:1527268438534};\\\", \\\"{x:1649,y:634,t:1527268438551};\\\", \\\"{x:1648,y:636,t:1527268438661};\\\", \\\"{x:1647,y:637,t:1527268438668};\\\", \\\"{x:1645,y:639,t:1527268438683};\\\", \\\"{x:1639,y:642,t:1527268438701};\\\", \\\"{x:1634,y:645,t:1527268438717};\\\", \\\"{x:1630,y:646,t:1527268438733};\\\", \\\"{x:1630,y:647,t:1527268438751};\\\", \\\"{x:1629,y:648,t:1527268438767};\\\", \\\"{x:1629,y:650,t:1527268438783};\\\", \\\"{x:1628,y:652,t:1527268438801};\\\", \\\"{x:1627,y:654,t:1527268438817};\\\", \\\"{x:1626,y:656,t:1527268438834};\\\", \\\"{x:1623,y:661,t:1527268438851};\\\", \\\"{x:1621,y:668,t:1527268438866};\\\", \\\"{x:1618,y:675,t:1527268438884};\\\", \\\"{x:1615,y:689,t:1527268438900};\\\", \\\"{x:1615,y:691,t:1527268438917};\\\", \\\"{x:1614,y:695,t:1527268438936};\\\", \\\"{x:1614,y:696,t:1527268438950};\\\", \\\"{x:1614,y:699,t:1527268438965};\\\", \\\"{x:1613,y:701,t:1527268438982};\\\", \\\"{x:1613,y:702,t:1527268439003};\\\", \\\"{x:1613,y:704,t:1527268439019};\\\", \\\"{x:1613,y:705,t:1527268439035};\\\", \\\"{x:1612,y:706,t:1527268439051};\\\", \\\"{x:1602,y:706,t:1527268446744};\\\", \\\"{x:1579,y:706,t:1527268446753};\\\", \\\"{x:1466,y:678,t:1527268446769};\\\", \\\"{x:1301,y:633,t:1527268446786};\\\", \\\"{x:1088,y:575,t:1527268446803};\\\", \\\"{x:856,y:504,t:1527268446821};\\\", \\\"{x:662,y:437,t:1527268446837};\\\", \\\"{x:518,y:391,t:1527268446853};\\\", \\\"{x:431,y:362,t:1527268446870};\\\", \\\"{x:407,y:353,t:1527268446886};\\\", \\\"{x:404,y:351,t:1527268446904};\\\", \\\"{x:413,y:352,t:1527268447001};\\\", \\\"{x:423,y:357,t:1527268447008};\\\", \\\"{x:440,y:365,t:1527268447021};\\\", \\\"{x:506,y:391,t:1527268447037};\\\", \\\"{x:613,y:432,t:1527268447053};\\\", \\\"{x:726,y:465,t:1527268447070};\\\", \\\"{x:835,y:500,t:1527268447087};\\\", \\\"{x:915,y:523,t:1527268447104};\\\", \\\"{x:969,y:540,t:1527268447120};\\\", \\\"{x:977,y:543,t:1527268447138};\\\", \\\"{x:977,y:540,t:1527268447281};\\\", \\\"{x:974,y:536,t:1527268447288};\\\", \\\"{x:956,y:527,t:1527268447304};\\\", \\\"{x:940,y:521,t:1527268447320};\\\", \\\"{x:923,y:516,t:1527268447338};\\\", \\\"{x:912,y:516,t:1527268447355};\\\", \\\"{x:905,y:515,t:1527268447371};\\\", \\\"{x:904,y:515,t:1527268447388};\\\", \\\"{x:903,y:515,t:1527268447416};\\\", \\\"{x:902,y:515,t:1527268447433};\\\", \\\"{x:901,y:515,t:1527268447440};\\\", \\\"{x:899,y:516,t:1527268447454};\\\", \\\"{x:895,y:517,t:1527268447471};\\\", \\\"{x:892,y:517,t:1527268447487};\\\", \\\"{x:891,y:517,t:1527268447505};\\\", \\\"{x:889,y:517,t:1527268447561};\\\", \\\"{x:887,y:518,t:1527268447571};\\\", \\\"{x:882,y:519,t:1527268447588};\\\", \\\"{x:877,y:519,t:1527268447604};\\\", \\\"{x:871,y:519,t:1527268447620};\\\", \\\"{x:868,y:519,t:1527268447712};\\\", \\\"{x:863,y:519,t:1527268447721};\\\", \\\"{x:858,y:516,t:1527268447738};\\\", \\\"{x:856,y:515,t:1527268447755};\\\", \\\"{x:855,y:514,t:1527268447771};\\\", \\\"{x:854,y:513,t:1527268447787};\\\", \\\"{x:852,y:512,t:1527268449160};\\\", \\\"{x:850,y:511,t:1527268449173};\\\", \\\"{x:848,y:509,t:1527268449189};\\\", \\\"{x:846,y:508,t:1527268449205};\\\", \\\"{x:848,y:506,t:1527268450112};\\\", \\\"{x:855,y:505,t:1527268450123};\\\", \\\"{x:868,y:501,t:1527268450139};\\\", \\\"{x:877,y:500,t:1527268450157};\\\", \\\"{x:885,y:500,t:1527268450172};\\\", \\\"{x:894,y:500,t:1527268450189};\\\", \\\"{x:902,y:500,t:1527268450206};\\\", \\\"{x:918,y:502,t:1527268450222};\\\", \\\"{x:940,y:507,t:1527268450239};\\\", \\\"{x:975,y:518,t:1527268450257};\\\", \\\"{x:991,y:523,t:1527268450272};\\\", \\\"{x:1021,y:531,t:1527268450290};\\\", \\\"{x:1051,y:540,t:1527268450307};\\\", \\\"{x:1078,y:547,t:1527268450322};\\\", \\\"{x:1096,y:552,t:1527268450340};\\\", \\\"{x:1114,y:559,t:1527268450356};\\\", \\\"{x:1137,y:565,t:1527268450373};\\\", \\\"{x:1162,y:575,t:1527268450390};\\\", \\\"{x:1186,y:581,t:1527268450407};\\\", \\\"{x:1207,y:587,t:1527268450423};\\\", \\\"{x:1224,y:592,t:1527268450440};\\\", \\\"{x:1243,y:597,t:1527268450457};\\\", \\\"{x:1252,y:598,t:1527268450473};\\\", \\\"{x:1253,y:598,t:1527268450489};\\\", \\\"{x:1254,y:598,t:1527268450507};\\\", \\\"{x:1254,y:600,t:1527268450688};\\\", \\\"{x:1257,y:603,t:1527268450696};\\\", \\\"{x:1257,y:605,t:1527268450706};\\\", \\\"{x:1261,y:610,t:1527268450723};\\\", \\\"{x:1265,y:617,t:1527268450740};\\\", \\\"{x:1274,y:627,t:1527268450756};\\\", \\\"{x:1283,y:635,t:1527268450773};\\\", \\\"{x:1286,y:639,t:1527268450790};\\\", \\\"{x:1289,y:642,t:1527268450806};\\\", \\\"{x:1290,y:642,t:1527268450824};\\\", \\\"{x:1291,y:643,t:1527268450840};\\\", \\\"{x:1293,y:642,t:1527268455424};\\\", \\\"{x:1295,y:639,t:1527268455432};\\\", \\\"{x:1298,y:638,t:1527268455444};\\\", \\\"{x:1300,y:636,t:1527268455461};\\\", \\\"{x:1301,y:636,t:1527268455477};\\\", \\\"{x:1302,y:635,t:1527268455494};\\\", \\\"{x:1303,y:635,t:1527268455529};\\\", \\\"{x:1305,y:633,t:1527268455544};\\\", \\\"{x:1308,y:632,t:1527268455561};\\\", \\\"{x:1311,y:631,t:1527268455576};\\\", \\\"{x:1313,y:630,t:1527268455594};\\\", \\\"{x:1313,y:629,t:1527268455611};\\\", \\\"{x:1314,y:629,t:1527268456184};\\\", \\\"{x:1320,y:628,t:1527268456196};\\\", \\\"{x:1343,y:624,t:1527268456211};\\\", \\\"{x:1388,y:634,t:1527268456228};\\\", \\\"{x:1453,y:649,t:1527268456245};\\\", \\\"{x:1522,y:665,t:1527268456261};\\\", \\\"{x:1566,y:677,t:1527268456278};\\\", \\\"{x:1582,y:683,t:1527268456295};\\\", \\\"{x:1586,y:685,t:1527268456311};\\\", \\\"{x:1587,y:686,t:1527268456376};\\\", \\\"{x:1587,y:687,t:1527268456392};\\\", \\\"{x:1587,y:688,t:1527268456408};\\\", \\\"{x:1587,y:689,t:1527268456416};\\\", \\\"{x:1587,y:690,t:1527268456441};\\\", \\\"{x:1587,y:691,t:1527268456448};\\\", \\\"{x:1586,y:692,t:1527268456461};\\\", \\\"{x:1584,y:694,t:1527268456478};\\\", \\\"{x:1580,y:695,t:1527268456495};\\\", \\\"{x:1574,y:698,t:1527268456512};\\\", \\\"{x:1570,y:699,t:1527268456528};\\\", \\\"{x:1565,y:701,t:1527268456545};\\\", \\\"{x:1561,y:703,t:1527268456562};\\\", \\\"{x:1557,y:704,t:1527268456578};\\\", \\\"{x:1548,y:706,t:1527268456594};\\\", \\\"{x:1539,y:710,t:1527268456611};\\\", \\\"{x:1531,y:712,t:1527268456628};\\\", \\\"{x:1523,y:714,t:1527268456645};\\\", \\\"{x:1519,y:716,t:1527268456662};\\\", \\\"{x:1513,y:718,t:1527268456678};\\\", \\\"{x:1509,y:719,t:1527268456695};\\\", \\\"{x:1503,y:722,t:1527268456712};\\\", \\\"{x:1502,y:723,t:1527268456728};\\\", \\\"{x:1502,y:722,t:1527268456865};\\\", \\\"{x:1503,y:721,t:1527268456952};\\\", \\\"{x:1504,y:718,t:1527268462648};\\\", \\\"{x:1543,y:666,t:1527268462656};\\\", \\\"{x:1636,y:536,t:1527268462666};\\\", \\\"{x:1843,y:256,t:1527268462683};\\\", \\\"{x:1919,y:32,t:1527268462700};\\\", \\\"{x:1919,y:0,t:1527268462716};\\\", \\\"{x:1904,y:0,t:1527268462760};\\\", \\\"{x:1849,y:0,t:1527268462767};\\\", \\\"{x:1764,y:0,t:1527268462783};\\\", \\\"{x:1434,y:0,t:1527268462799};\\\", \\\"{x:1234,y:0,t:1527268462817};\\\", \\\"{x:1102,y:0,t:1527268462833};\\\", \\\"{x:1077,y:0,t:1527268462850};\\\", \\\"{x:1077,y:1,t:1527268462904};\\\", \\\"{x:1075,y:7,t:1527268462917};\\\", \\\"{x:1064,y:10,t:1527268462933};\\\", \\\"{x:1062,y:11,t:1527268462950};\\\", \\\"{x:1061,y:12,t:1527268462984};\\\", \\\"{x:1059,y:27,t:1527268463000};\\\", \\\"{x:1058,y:56,t:1527268463017};\\\", \\\"{x:1067,y:87,t:1527268463034};\\\", \\\"{x:1068,y:103,t:1527268463050};\\\", \\\"{x:1068,y:111,t:1527268463067};\\\", \\\"{x:1074,y:118,t:1527268463084};\\\", \\\"{x:1107,y:135,t:1527268463100};\\\", \\\"{x:1244,y:194,t:1527268463117};\\\", \\\"{x:1421,y:267,t:1527268463134};\\\", \\\"{x:1591,y:333,t:1527268463150};\\\", \\\"{x:1720,y:369,t:1527268463167};\\\", \\\"{x:1899,y:409,t:1527268463184};\\\", \\\"{x:1919,y:427,t:1527268463200};\\\", \\\"{x:1919,y:429,t:1527268463217};\\\", \\\"{x:1919,y:427,t:1527268463233};\\\", \\\"{x:1919,y:423,t:1527268463250};\\\", \\\"{x:1919,y:411,t:1527268463267};\\\", \\\"{x:1919,y:401,t:1527268463284};\\\", \\\"{x:1919,y:392,t:1527268463300};\\\", \\\"{x:1919,y:387,t:1527268463317};\\\", \\\"{x:1919,y:383,t:1527268463334};\\\", \\\"{x:1919,y:377,t:1527268463350};\\\", \\\"{x:1919,y:371,t:1527268463368};\\\", \\\"{x:1919,y:363,t:1527268463383};\\\", \\\"{x:1919,y:360,t:1527268463400};\\\", \\\"{x:1919,y:357,t:1527268463417};\\\", \\\"{x:1919,y:356,t:1527268463520};\\\", \\\"{x:1919,y:355,t:1527268463536};\\\", \\\"{x:1919,y:353,t:1527268463550};\\\", \\\"{x:1916,y:359,t:1527268463584};\\\", \\\"{x:1872,y:405,t:1527268463600};\\\", \\\"{x:1784,y:515,t:1527268463617};\\\", \\\"{x:1668,y:663,t:1527268463634};\\\", \\\"{x:1538,y:837,t:1527268463651};\\\", \\\"{x:1400,y:987,t:1527268463667};\\\", \\\"{x:1251,y:1086,t:1527268463684};\\\", \\\"{x:1097,y:1122,t:1527268463700};\\\", \\\"{x:954,y:1108,t:1527268463717};\\\", \\\"{x:858,y:1068,t:1527268463734};\\\", \\\"{x:834,y:1050,t:1527268463751};\\\", \\\"{x:833,y:1046,t:1527268463767};\\\", \\\"{x:834,y:1042,t:1527268463784};\\\", \\\"{x:836,y:1042,t:1527268463801};\\\", \\\"{x:838,y:1042,t:1527268463841};\\\", \\\"{x:839,y:1043,t:1527268463852};\\\", \\\"{x:839,y:1049,t:1527268463867};\\\", \\\"{x:837,y:1053,t:1527268463884};\\\", \\\"{x:836,y:1056,t:1527268463902};\\\", \\\"{x:835,y:1058,t:1527268463917};\\\", \\\"{x:834,y:1059,t:1527268463934};\\\", \\\"{x:830,y:1056,t:1527268463952};\\\", \\\"{x:816,y:1008,t:1527268463968};\\\", \\\"{x:808,y:940,t:1527268463985};\\\", \\\"{x:808,y:903,t:1527268464002};\\\", \\\"{x:808,y:874,t:1527268464018};\\\", \\\"{x:805,y:843,t:1527268464035};\\\", \\\"{x:795,y:797,t:1527268464052};\\\", \\\"{x:785,y:756,t:1527268464068};\\\", \\\"{x:776,y:715,t:1527268464084};\\\", \\\"{x:773,y:684,t:1527268464101};\\\", \\\"{x:773,y:663,t:1527268464118};\\\", \\\"{x:774,y:641,t:1527268464135};\\\", \\\"{x:774,y:613,t:1527268464152};\\\", \\\"{x:774,y:575,t:1527268464169};\\\", \\\"{x:772,y:552,t:1527268464185};\\\", \\\"{x:766,y:534,t:1527268464201};\\\", \\\"{x:759,y:525,t:1527268464218};\\\", \\\"{x:753,y:524,t:1527268464235};\\\", \\\"{x:740,y:528,t:1527268464251};\\\", \\\"{x:721,y:536,t:1527268464269};\\\", \\\"{x:705,y:546,t:1527268464284};\\\", \\\"{x:688,y:560,t:1527268464302};\\\", \\\"{x:665,y:573,t:1527268464318};\\\", \\\"{x:624,y:585,t:1527268464334};\\\", \\\"{x:561,y:588,t:1527268464351};\\\", \\\"{x:514,y:588,t:1527268464367};\\\", \\\"{x:509,y:588,t:1527268464384};\\\", \\\"{x:508,y:588,t:1527268464464};\\\", \\\"{x:511,y:586,t:1527268464472};\\\", \\\"{x:512,y:586,t:1527268464484};\\\", \\\"{x:516,y:584,t:1527268464529};\\\", \\\"{x:519,y:580,t:1527268464536};\\\", \\\"{x:526,y:576,t:1527268464551};\\\", \\\"{x:545,y:566,t:1527268464568};\\\", \\\"{x:561,y:562,t:1527268464585};\\\", \\\"{x:574,y:558,t:1527268464602};\\\", \\\"{x:578,y:556,t:1527268464617};\\\", \\\"{x:582,y:554,t:1527268464635};\\\", \\\"{x:587,y:552,t:1527268464652};\\\", \\\"{x:589,y:552,t:1527268464672};\\\", \\\"{x:590,y:552,t:1527268464685};\\\", \\\"{x:592,y:553,t:1527268464701};\\\", \\\"{x:593,y:553,t:1527268464718};\\\", \\\"{x:594,y:553,t:1527268464752};\\\", \\\"{x:595,y:553,t:1527268464776};\\\", \\\"{x:597,y:554,t:1527268464785};\\\", \\\"{x:598,y:565,t:1527268464803};\\\", \\\"{x:599,y:582,t:1527268464818};\\\", \\\"{x:601,y:599,t:1527268464836};\\\", \\\"{x:602,y:605,t:1527268464853};\\\", \\\"{x:602,y:606,t:1527268464881};\\\", \\\"{x:604,y:606,t:1527268464921};\\\", \\\"{x:605,y:605,t:1527268464936};\\\", \\\"{x:605,y:604,t:1527268465017};\\\", \\\"{x:606,y:602,t:1527268465025};\\\", \\\"{x:609,y:599,t:1527268465037};\\\", \\\"{x:610,y:594,t:1527268465052};\\\", \\\"{x:613,y:590,t:1527268465068};\\\", \\\"{x:614,y:588,t:1527268465086};\\\", \\\"{x:615,y:586,t:1527268465102};\\\", \\\"{x:615,y:587,t:1527268465392};\\\", \\\"{x:611,y:596,t:1527268465402};\\\", \\\"{x:605,y:615,t:1527268465419};\\\", \\\"{x:603,y:635,t:1527268465435};\\\", \\\"{x:603,y:646,t:1527268465452};\\\", \\\"{x:602,y:649,t:1527268465470};\\\", \\\"{x:601,y:650,t:1527268465485};\\\", \\\"{x:600,y:652,t:1527268465502};\\\", \\\"{x:594,y:654,t:1527268465520};\\\", \\\"{x:579,y:659,t:1527268465536};\\\", \\\"{x:564,y:667,t:1527268465552};\\\", \\\"{x:558,y:671,t:1527268465570};\\\", \\\"{x:555,y:673,t:1527268465586};\\\", \\\"{x:555,y:674,t:1527268465603};\\\", \\\"{x:552,y:679,t:1527268465621};\\\", \\\"{x:548,y:687,t:1527268465636};\\\", \\\"{x:537,y:705,t:1527268465653};\\\", \\\"{x:524,y:729,t:1527268465669};\\\", \\\"{x:516,y:750,t:1527268465686};\\\", \\\"{x:508,y:762,t:1527268465702};\\\", \\\"{x:506,y:764,t:1527268465718};\\\", \\\"{x:505,y:765,t:1527268465735};\\\", \\\"{x:505,y:766,t:1527268465801};\\\", \\\"{x:505,y:767,t:1527268465809};\\\", \\\"{x:505,y:768,t:1527268465841};\\\", \\\"{x:505,y:763,t:1527268465873};\\\", \\\"{x:504,y:758,t:1527268465886};\\\", \\\"{x:503,y:750,t:1527268465904};\\\", \\\"{x:501,y:746,t:1527268465919};\\\", \\\"{x:501,y:743,t:1527268466024};\\\", \\\"{x:501,y:742,t:1527268466037};\\\", \\\"{x:501,y:739,t:1527268466053};\\\", \\\"{x:501,y:738,t:1527268466070};\\\", \\\"{x:503,y:738,t:1527268466808};\\\", \\\"{x:506,y:738,t:1527268466820};\\\", \\\"{x:507,y:738,t:1527268466912};\\\", \\\"{x:508,y:738,t:1527268466928};\\\", \\\"{x:510,y:738,t:1527268466936};\\\", \\\"{x:511,y:738,t:1527268466953};\\\", \\\"{x:512,y:737,t:1527268466971};\\\", \\\"{x:512,y:736,t:1527268467041};\\\", \\\"{x:513,y:736,t:1527268467054};\\\", \\\"{x:514,y:735,t:1527268467231};\\\", \\\"{x:515,y:735,t:1527268467239};\\\", \\\"{x:517,y:735,t:1527268467256};\\\", \\\"{x:518,y:734,t:1527268467304};\\\" ] }, { \\\"rt\\\": 26783, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 534148, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"967LR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-M -B -3\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:526,y:731,t:1527268467474};\\\", \\\"{x:527,y:731,t:1527268467680};\\\", \\\"{x:533,y:731,t:1527268467688};\\\", \\\"{x:534,y:731,t:1527268467704};\\\", \\\"{x:536,y:731,t:1527268467720};\\\", \\\"{x:536,y:730,t:1527268467760};\\\", \\\"{x:536,y:727,t:1527268467880};\\\", \\\"{x:537,y:723,t:1527268467888};\\\", \\\"{x:543,y:708,t:1527268467905};\\\", \\\"{x:556,y:677,t:1527268467920};\\\", \\\"{x:573,y:626,t:1527268467938};\\\", \\\"{x:588,y:571,t:1527268467955};\\\", \\\"{x:600,y:524,t:1527268467971};\\\", \\\"{x:604,y:485,t:1527268467988};\\\", \\\"{x:608,y:446,t:1527268468005};\\\", \\\"{x:613,y:419,t:1527268468021};\\\", \\\"{x:619,y:391,t:1527268468038};\\\", \\\"{x:627,y:366,t:1527268468055};\\\", \\\"{x:630,y:344,t:1527268468071};\\\", \\\"{x:634,y:327,t:1527268468088};\\\", \\\"{x:635,y:309,t:1527268468104};\\\", \\\"{x:623,y:291,t:1527268468122};\\\", \\\"{x:622,y:286,t:1527268468137};\\\", \\\"{x:637,y:247,t:1527268468569};\\\", \\\"{x:680,y:141,t:1527268468576};\\\", \\\"{x:707,y:42,t:1527268468588};\\\", \\\"{x:748,y:0,t:1527268468607};\\\", \\\"{x:778,y:0,t:1527268468622};\\\", \\\"{x:821,y:0,t:1527268468638};\\\", \\\"{x:861,y:0,t:1527268468655};\\\", \\\"{x:902,y:0,t:1527268468672};\\\", \\\"{x:925,y:0,t:1527268468688};\\\", \\\"{x:961,y:0,t:1527268468704};\\\", \\\"{x:996,y:0,t:1527268468722};\\\", \\\"{x:1038,y:0,t:1527268468738};\\\", \\\"{x:1055,y:0,t:1527268468755};\\\", \\\"{x:1067,y:0,t:1527268468772};\\\", \\\"{x:1051,y:0,t:1527268468833};\\\", \\\"{x:1042,y:0,t:1527268468841};\\\", \\\"{x:1035,y:0,t:1527268468855};\\\", \\\"{x:1031,y:0,t:1527268468872};\\\", \\\"{x:1032,y:1,t:1527268468921};\\\", \\\"{x:1031,y:20,t:1527268468939};\\\", \\\"{x:1028,y:52,t:1527268468955};\\\", \\\"{x:1035,y:103,t:1527268468972};\\\", \\\"{x:1066,y:175,t:1527268468989};\\\", \\\"{x:1152,y:258,t:1527268469007};\\\", \\\"{x:1305,y:315,t:1527268469022};\\\", \\\"{x:1490,y:370,t:1527268469039};\\\", \\\"{x:1642,y:410,t:1527268469055};\\\", \\\"{x:1787,y:465,t:1527268469072};\\\", \\\"{x:1919,y:557,t:1527268469089};\\\", \\\"{x:1919,y:593,t:1527268469105};\\\", \\\"{x:1919,y:616,t:1527268469120};\\\", \\\"{x:1919,y:622,t:1527268469137};\\\", \\\"{x:1917,y:630,t:1527268469154};\\\", \\\"{x:1872,y:655,t:1527268469171};\\\", \\\"{x:1766,y:707,t:1527268469187};\\\", \\\"{x:1675,y:766,t:1527268469206};\\\", \\\"{x:1635,y:797,t:1527268469222};\\\", \\\"{x:1617,y:799,t:1527268469239};\\\", \\\"{x:1585,y:802,t:1527268469255};\\\", \\\"{x:1532,y:801,t:1527268469272};\\\", \\\"{x:1429,y:773,t:1527268469289};\\\", \\\"{x:1386,y:750,t:1527268469305};\\\", \\\"{x:1366,y:734,t:1527268469323};\\\", \\\"{x:1341,y:715,t:1527268469339};\\\", \\\"{x:1322,y:700,t:1527268469356};\\\", \\\"{x:1294,y:684,t:1527268469372};\\\", \\\"{x:1260,y:672,t:1527268469389};\\\", \\\"{x:1236,y:666,t:1527268469405};\\\", \\\"{x:1222,y:663,t:1527268469422};\\\", \\\"{x:1220,y:663,t:1527268469439};\\\", \\\"{x:1219,y:663,t:1527268469456};\\\", \\\"{x:1219,y:662,t:1527268469521};\\\", \\\"{x:1221,y:661,t:1527268469528};\\\", \\\"{x:1228,y:658,t:1527268469538};\\\", \\\"{x:1246,y:653,t:1527268469556};\\\", \\\"{x:1266,y:650,t:1527268469573};\\\", \\\"{x:1288,y:654,t:1527268469589};\\\", \\\"{x:1364,y:693,t:1527268469606};\\\", \\\"{x:1486,y:753,t:1527268469623};\\\", \\\"{x:1610,y:806,t:1527268469639};\\\", \\\"{x:1691,y:830,t:1527268469656};\\\", \\\"{x:1710,y:842,t:1527268469673};\\\", \\\"{x:1710,y:847,t:1527268469689};\\\", \\\"{x:1691,y:855,t:1527268469706};\\\", \\\"{x:1671,y:863,t:1527268469723};\\\", \\\"{x:1650,y:868,t:1527268469739};\\\", \\\"{x:1633,y:875,t:1527268469756};\\\", \\\"{x:1619,y:879,t:1527268469773};\\\", \\\"{x:1604,y:882,t:1527268469790};\\\", \\\"{x:1574,y:888,t:1527268469806};\\\", \\\"{x:1530,y:888,t:1527268469823};\\\", \\\"{x:1477,y:888,t:1527268469839};\\\", \\\"{x:1426,y:888,t:1527268469856};\\\", \\\"{x:1394,y:888,t:1527268469873};\\\", \\\"{x:1378,y:890,t:1527268469890};\\\", \\\"{x:1368,y:892,t:1527268469907};\\\", \\\"{x:1359,y:894,t:1527268469923};\\\", \\\"{x:1357,y:895,t:1527268469940};\\\", \\\"{x:1356,y:896,t:1527268469956};\\\", \\\"{x:1352,y:898,t:1527268469973};\\\", \\\"{x:1348,y:898,t:1527268469990};\\\", \\\"{x:1340,y:898,t:1527268470007};\\\", \\\"{x:1322,y:898,t:1527268470023};\\\", \\\"{x:1305,y:897,t:1527268470041};\\\", \\\"{x:1288,y:890,t:1527268470056};\\\", \\\"{x:1256,y:873,t:1527268470073};\\\", \\\"{x:1225,y:861,t:1527268470091};\\\", \\\"{x:1190,y:841,t:1527268470106};\\\", \\\"{x:1163,y:832,t:1527268470123};\\\", \\\"{x:1142,y:825,t:1527268470140};\\\", \\\"{x:1127,y:811,t:1527268470157};\\\", \\\"{x:1125,y:792,t:1527268470173};\\\", \\\"{x:1140,y:765,t:1527268470190};\\\", \\\"{x:1169,y:731,t:1527268470207};\\\", \\\"{x:1199,y:715,t:1527268470223};\\\", \\\"{x:1218,y:706,t:1527268470241};\\\", \\\"{x:1244,y:695,t:1527268470257};\\\", \\\"{x:1252,y:692,t:1527268470273};\\\", \\\"{x:1255,y:692,t:1527268470291};\\\", \\\"{x:1262,y:690,t:1527268470307};\\\", \\\"{x:1272,y:688,t:1527268470324};\\\", \\\"{x:1279,y:685,t:1527268470341};\\\", \\\"{x:1284,y:684,t:1527268470357};\\\", \\\"{x:1286,y:684,t:1527268470373};\\\", \\\"{x:1287,y:684,t:1527268470545};\\\", \\\"{x:1290,y:684,t:1527268470557};\\\", \\\"{x:1307,y:688,t:1527268470574};\\\", \\\"{x:1329,y:694,t:1527268470590};\\\", \\\"{x:1351,y:703,t:1527268470607};\\\", \\\"{x:1368,y:710,t:1527268470624};\\\", \\\"{x:1383,y:721,t:1527268470640};\\\", \\\"{x:1394,y:729,t:1527268470657};\\\", \\\"{x:1398,y:733,t:1527268470674};\\\", \\\"{x:1400,y:735,t:1527268470690};\\\", \\\"{x:1402,y:736,t:1527268470707};\\\", \\\"{x:1402,y:738,t:1527268470921};\\\", \\\"{x:1406,y:739,t:1527268471033};\\\", \\\"{x:1417,y:740,t:1527268471041};\\\", \\\"{x:1435,y:743,t:1527268471057};\\\", \\\"{x:1452,y:745,t:1527268471074};\\\", \\\"{x:1467,y:751,t:1527268471091};\\\", \\\"{x:1474,y:754,t:1527268471107};\\\", \\\"{x:1482,y:758,t:1527268471123};\\\", \\\"{x:1488,y:763,t:1527268471140};\\\", \\\"{x:1491,y:764,t:1527268471157};\\\", \\\"{x:1491,y:765,t:1527268471353};\\\", \\\"{x:1489,y:767,t:1527268471361};\\\", \\\"{x:1486,y:767,t:1527268471375};\\\", \\\"{x:1476,y:771,t:1527268471391};\\\", \\\"{x:1459,y:776,t:1527268471407};\\\", \\\"{x:1445,y:781,t:1527268471424};\\\", \\\"{x:1427,y:786,t:1527268471441};\\\", \\\"{x:1420,y:788,t:1527268471458};\\\", \\\"{x:1412,y:790,t:1527268471474};\\\", \\\"{x:1406,y:791,t:1527268471491};\\\", \\\"{x:1394,y:793,t:1527268471507};\\\", \\\"{x:1385,y:795,t:1527268471524};\\\", \\\"{x:1379,y:796,t:1527268471541};\\\", \\\"{x:1374,y:796,t:1527268471557};\\\", \\\"{x:1371,y:796,t:1527268471574};\\\", \\\"{x:1364,y:796,t:1527268471591};\\\", \\\"{x:1355,y:796,t:1527268471609};\\\", \\\"{x:1335,y:796,t:1527268471625};\\\", \\\"{x:1318,y:796,t:1527268471641};\\\", \\\"{x:1294,y:796,t:1527268471658};\\\", \\\"{x:1274,y:792,t:1527268471674};\\\", \\\"{x:1260,y:791,t:1527268471691};\\\", \\\"{x:1256,y:791,t:1527268471708};\\\", \\\"{x:1254,y:790,t:1527268471724};\\\", \\\"{x:1262,y:788,t:1527268471841};\\\", \\\"{x:1277,y:783,t:1527268471858};\\\", \\\"{x:1288,y:780,t:1527268471874};\\\", \\\"{x:1295,y:778,t:1527268471891};\\\", \\\"{x:1296,y:777,t:1527268471908};\\\", \\\"{x:1297,y:777,t:1527268472074};\\\", \\\"{x:1300,y:777,t:1527268472081};\\\", \\\"{x:1304,y:777,t:1527268472091};\\\", \\\"{x:1316,y:773,t:1527268472108};\\\", \\\"{x:1323,y:771,t:1527268472126};\\\", \\\"{x:1326,y:770,t:1527268472142};\\\", \\\"{x:1328,y:770,t:1527268472159};\\\", \\\"{x:1329,y:770,t:1527268472361};\\\", \\\"{x:1331,y:770,t:1527268472375};\\\", \\\"{x:1336,y:769,t:1527268472391};\\\", \\\"{x:1338,y:767,t:1527268472408};\\\", \\\"{x:1339,y:767,t:1527268472425};\\\", \\\"{x:1341,y:767,t:1527268472472};\\\", \\\"{x:1342,y:767,t:1527268472689};\\\", \\\"{x:1343,y:767,t:1527268472729};\\\", \\\"{x:1343,y:766,t:1527268472755};\\\", \\\"{x:1345,y:766,t:1527268473889};\\\", \\\"{x:1346,y:766,t:1527268473897};\\\", \\\"{x:1348,y:766,t:1527268473920};\\\", \\\"{x:1348,y:765,t:1527268476321};\\\", \\\"{x:1348,y:764,t:1527268476441};\\\", \\\"{x:1349,y:763,t:1527268476448};\\\", \\\"{x:1349,y:762,t:1527268476464};\\\", \\\"{x:1349,y:761,t:1527268476478};\\\", \\\"{x:1350,y:761,t:1527268476496};\\\", \\\"{x:1350,y:760,t:1527268486841};\\\", \\\"{x:1340,y:762,t:1527268486855};\\\", \\\"{x:1311,y:769,t:1527268486870};\\\", \\\"{x:1255,y:770,t:1527268486887};\\\", \\\"{x:1169,y:770,t:1527268486904};\\\", \\\"{x:1063,y:770,t:1527268486920};\\\", \\\"{x:892,y:770,t:1527268486937};\\\", \\\"{x:764,y:769,t:1527268486954};\\\", \\\"{x:635,y:742,t:1527268486970};\\\", \\\"{x:507,y:719,t:1527268486987};\\\", \\\"{x:385,y:700,t:1527268487004};\\\", \\\"{x:267,y:671,t:1527268487020};\\\", \\\"{x:140,y:639,t:1527268487037};\\\", \\\"{x:0,y:618,t:1527268487054};\\\", \\\"{x:0,y:590,t:1527268487069};\\\", \\\"{x:0,y:559,t:1527268487086};\\\", \\\"{x:0,y:536,t:1527268487103};\\\", \\\"{x:0,y:514,t:1527268487119};\\\", \\\"{x:0,y:512,t:1527268487136};\\\", \\\"{x:0,y:509,t:1527268487153};\\\", \\\"{x:10,y:500,t:1527268487170};\\\", \\\"{x:26,y:494,t:1527268487186};\\\", \\\"{x:38,y:488,t:1527268487203};\\\", \\\"{x:50,y:484,t:1527268487220};\\\", \\\"{x:57,y:481,t:1527268487236};\\\", \\\"{x:60,y:480,t:1527268487253};\\\", \\\"{x:63,y:479,t:1527268487271};\\\", \\\"{x:68,y:478,t:1527268487287};\\\", \\\"{x:83,y:475,t:1527268487303};\\\", \\\"{x:123,y:471,t:1527268487320};\\\", \\\"{x:150,y:471,t:1527268487336};\\\", \\\"{x:160,y:471,t:1527268487353};\\\", \\\"{x:162,y:471,t:1527268487370};\\\", \\\"{x:163,y:472,t:1527268487387};\\\", \\\"{x:163,y:473,t:1527268487403};\\\", \\\"{x:163,y:477,t:1527268487421};\\\", \\\"{x:162,y:481,t:1527268487437};\\\", \\\"{x:161,y:484,t:1527268487454};\\\", \\\"{x:158,y:488,t:1527268487471};\\\", \\\"{x:158,y:490,t:1527268487487};\\\", \\\"{x:158,y:491,t:1527268487503};\\\", \\\"{x:158,y:496,t:1527268487520};\\\", \\\"{x:158,y:503,t:1527268487537};\\\", \\\"{x:158,y:514,t:1527268487553};\\\", \\\"{x:158,y:525,t:1527268487571};\\\", \\\"{x:159,y:535,t:1527268487588};\\\", \\\"{x:164,y:546,t:1527268487602};\\\", \\\"{x:172,y:560,t:1527268487621};\\\", \\\"{x:183,y:573,t:1527268487638};\\\", \\\"{x:187,y:581,t:1527268487653};\\\", \\\"{x:192,y:591,t:1527268487671};\\\", \\\"{x:195,y:601,t:1527268487688};\\\", \\\"{x:196,y:609,t:1527268487703};\\\", \\\"{x:198,y:617,t:1527268487720};\\\", \\\"{x:199,y:623,t:1527268487737};\\\", \\\"{x:200,y:628,t:1527268487753};\\\", \\\"{x:205,y:638,t:1527268487770};\\\", \\\"{x:218,y:646,t:1527268487787};\\\", \\\"{x:257,y:649,t:1527268487803};\\\", \\\"{x:349,y:649,t:1527268487821};\\\", \\\"{x:462,y:649,t:1527268487837};\\\", \\\"{x:570,y:637,t:1527268487854};\\\", \\\"{x:681,y:623,t:1527268487871};\\\", \\\"{x:775,y:611,t:1527268487888};\\\", \\\"{x:851,y:598,t:1527268487904};\\\", \\\"{x:882,y:597,t:1527268487921};\\\", \\\"{x:884,y:597,t:1527268487937};\\\", \\\"{x:882,y:597,t:1527268488048};\\\", \\\"{x:878,y:597,t:1527268488056};\\\", \\\"{x:875,y:597,t:1527268488070};\\\", \\\"{x:865,y:599,t:1527268488086};\\\", \\\"{x:853,y:599,t:1527268488103};\\\", \\\"{x:852,y:599,t:1527268488136};\\\", \\\"{x:852,y:597,t:1527268488159};\\\", \\\"{x:852,y:595,t:1527268488169};\\\", \\\"{x:852,y:592,t:1527268488187};\\\", \\\"{x:852,y:588,t:1527268488203};\\\", \\\"{x:852,y:587,t:1527268488224};\\\", \\\"{x:852,y:584,t:1527268488280};\\\", \\\"{x:852,y:582,t:1527268488288};\\\", \\\"{x:852,y:578,t:1527268488304};\\\", \\\"{x:848,y:570,t:1527268488321};\\\", \\\"{x:843,y:563,t:1527268488339};\\\", \\\"{x:840,y:558,t:1527268488354};\\\", \\\"{x:838,y:556,t:1527268488371};\\\", \\\"{x:836,y:553,t:1527268488387};\\\", \\\"{x:833,y:553,t:1527268488405};\\\", \\\"{x:830,y:552,t:1527268488421};\\\", \\\"{x:825,y:552,t:1527268488437};\\\", \\\"{x:815,y:551,t:1527268488454};\\\", \\\"{x:795,y:547,t:1527268488471};\\\", \\\"{x:756,y:547,t:1527268488488};\\\", \\\"{x:716,y:547,t:1527268488505};\\\", \\\"{x:670,y:543,t:1527268488521};\\\", \\\"{x:619,y:543,t:1527268488538};\\\", \\\"{x:566,y:541,t:1527268488554};\\\", \\\"{x:504,y:541,t:1527268488571};\\\", \\\"{x:457,y:541,t:1527268488588};\\\", \\\"{x:425,y:540,t:1527268488604};\\\", \\\"{x:403,y:536,t:1527268488621};\\\", \\\"{x:392,y:534,t:1527268488637};\\\", \\\"{x:390,y:534,t:1527268488655};\\\", \\\"{x:389,y:534,t:1527268488696};\\\", \\\"{x:387,y:534,t:1527268488704};\\\", \\\"{x:382,y:535,t:1527268488721};\\\", \\\"{x:380,y:538,t:1527268488737};\\\", \\\"{x:377,y:544,t:1527268488754};\\\", \\\"{x:374,y:547,t:1527268488772};\\\", \\\"{x:373,y:551,t:1527268488789};\\\", \\\"{x:371,y:554,t:1527268488806};\\\", \\\"{x:371,y:557,t:1527268488822};\\\", \\\"{x:370,y:560,t:1527268488838};\\\", \\\"{x:370,y:561,t:1527268488854};\\\", \\\"{x:369,y:563,t:1527268488871};\\\", \\\"{x:369,y:565,t:1527268488896};\\\", \\\"{x:368,y:566,t:1527268488992};\\\", \\\"{x:368,y:568,t:1527268489006};\\\", \\\"{x:369,y:576,t:1527268489022};\\\", \\\"{x:373,y:593,t:1527268489039};\\\", \\\"{x:380,y:618,t:1527268489058};\\\", \\\"{x:392,y:659,t:1527268489072};\\\", \\\"{x:399,y:681,t:1527268489089};\\\", \\\"{x:409,y:699,t:1527268489104};\\\", \\\"{x:420,y:712,t:1527268489121};\\\", \\\"{x:433,y:719,t:1527268489138};\\\", \\\"{x:451,y:728,t:1527268489155};\\\", \\\"{x:480,y:733,t:1527268489172};\\\", \\\"{x:516,y:734,t:1527268489189};\\\", \\\"{x:555,y:724,t:1527268489205};\\\", \\\"{x:586,y:704,t:1527268489222};\\\", \\\"{x:604,y:691,t:1527268489238};\\\", \\\"{x:616,y:678,t:1527268489256};\\\", \\\"{x:623,y:657,t:1527268489271};\\\", \\\"{x:626,y:636,t:1527268489288};\\\", \\\"{x:627,y:614,t:1527268489305};\\\", \\\"{x:626,y:599,t:1527268489322};\\\", \\\"{x:623,y:589,t:1527268489338};\\\", \\\"{x:621,y:575,t:1527268489356};\\\", \\\"{x:618,y:556,t:1527268489372};\\\", \\\"{x:610,y:540,t:1527268489389};\\\", \\\"{x:595,y:525,t:1527268489406};\\\", \\\"{x:570,y:511,t:1527268489423};\\\", \\\"{x:552,y:502,t:1527268489438};\\\", \\\"{x:544,y:498,t:1527268489455};\\\", \\\"{x:548,y:495,t:1527268489576};\\\", \\\"{x:551,y:494,t:1527268489589};\\\", \\\"{x:556,y:493,t:1527268489606};\\\", \\\"{x:557,y:492,t:1527268489623};\\\", \\\"{x:558,y:491,t:1527268489680};\\\", \\\"{x:560,y:492,t:1527268489689};\\\", \\\"{x:571,y:499,t:1527268489706};\\\", \\\"{x:575,y:502,t:1527268489723};\\\", \\\"{x:582,y:505,t:1527268489739};\\\", \\\"{x:588,y:509,t:1527268489756};\\\", \\\"{x:596,y:513,t:1527268489774};\\\", \\\"{x:600,y:513,t:1527268489791};\\\", \\\"{x:603,y:514,t:1527268489806};\\\", \\\"{x:604,y:514,t:1527268490008};\\\", \\\"{x:605,y:514,t:1527268490022};\\\", \\\"{x:605,y:514,t:1527268490114};\\\", \\\"{x:606,y:514,t:1527268490481};\\\", \\\"{x:607,y:514,t:1527268490490};\\\", \\\"{x:609,y:514,t:1527268490507};\\\", \\\"{x:610,y:514,t:1527268490793};\\\", \\\"{x:608,y:514,t:1527268490808};\\\", \\\"{x:606,y:515,t:1527268490823};\\\", \\\"{x:604,y:516,t:1527268490840};\\\", \\\"{x:603,y:516,t:1527268490857};\\\", \\\"{x:596,y:518,t:1527268490875};\\\", \\\"{x:578,y:524,t:1527268490889};\\\", \\\"{x:555,y:528,t:1527268490906};\\\", \\\"{x:538,y:532,t:1527268490924};\\\", \\\"{x:544,y:530,t:1527268490951};\\\", \\\"{x:560,y:518,t:1527268490960};\\\", \\\"{x:581,y:507,t:1527268490973};\\\", \\\"{x:675,y:461,t:1527268490990};\\\", \\\"{x:745,y:430,t:1527268491006};\\\", \\\"{x:777,y:413,t:1527268491024};\\\", \\\"{x:779,y:413,t:1527268491039};\\\", \\\"{x:780,y:413,t:1527268491056};\\\", \\\"{x:776,y:415,t:1527268491079};\\\", \\\"{x:775,y:415,t:1527268491096};\\\", \\\"{x:775,y:416,t:1527268491106};\\\", \\\"{x:773,y:418,t:1527268491123};\\\", \\\"{x:769,y:419,t:1527268491139};\\\", \\\"{x:768,y:420,t:1527268491168};\\\", \\\"{x:766,y:421,t:1527268491176};\\\", \\\"{x:763,y:421,t:1527268491192};\\\", \\\"{x:761,y:423,t:1527268491206};\\\", \\\"{x:756,y:424,t:1527268491224};\\\", \\\"{x:751,y:426,t:1527268491241};\\\", \\\"{x:748,y:428,t:1527268491256};\\\", \\\"{x:741,y:431,t:1527268491274};\\\", \\\"{x:724,y:435,t:1527268491290};\\\", \\\"{x:707,y:441,t:1527268491307};\\\", \\\"{x:690,y:445,t:1527268491323};\\\", \\\"{x:677,y:449,t:1527268491340};\\\", \\\"{x:669,y:454,t:1527268491356};\\\", \\\"{x:659,y:458,t:1527268491373};\\\", \\\"{x:650,y:465,t:1527268491390};\\\", \\\"{x:638,y:472,t:1527268491406};\\\", \\\"{x:632,y:477,t:1527268491423};\\\", \\\"{x:627,y:481,t:1527268491440};\\\", \\\"{x:626,y:482,t:1527268491457};\\\", \\\"{x:624,y:485,t:1527268491474};\\\", \\\"{x:622,y:486,t:1527268491490};\\\", \\\"{x:620,y:488,t:1527268491507};\\\", \\\"{x:618,y:492,t:1527268491524};\\\", \\\"{x:616,y:496,t:1527268491541};\\\", \\\"{x:614,y:500,t:1527268491556};\\\", \\\"{x:611,y:502,t:1527268491574};\\\", \\\"{x:611,y:504,t:1527268491591};\\\", \\\"{x:607,y:505,t:1527268491847};\\\", \\\"{x:591,y:510,t:1527268491858};\\\", \\\"{x:531,y:515,t:1527268491873};\\\", \\\"{x:439,y:515,t:1527268491891};\\\", \\\"{x:340,y:515,t:1527268491907};\\\", \\\"{x:237,y:515,t:1527268491924};\\\", \\\"{x:143,y:506,t:1527268491941};\\\", \\\"{x:82,y:496,t:1527268491958};\\\", \\\"{x:34,y:488,t:1527268491974};\\\", \\\"{x:12,y:488,t:1527268491990};\\\", \\\"{x:6,y:488,t:1527268492007};\\\", \\\"{x:3,y:492,t:1527268492088};\\\", \\\"{x:3,y:499,t:1527268492096};\\\", \\\"{x:1,y:507,t:1527268492108};\\\", \\\"{x:1,y:528,t:1527268492124};\\\", \\\"{x:2,y:548,t:1527268492140};\\\", \\\"{x:4,y:564,t:1527268492157};\\\", \\\"{x:5,y:572,t:1527268492174};\\\", \\\"{x:6,y:575,t:1527268492191};\\\", \\\"{x:12,y:575,t:1527268492281};\\\", \\\"{x:18,y:571,t:1527268492290};\\\", \\\"{x:35,y:562,t:1527268492308};\\\", \\\"{x:54,y:555,t:1527268492326};\\\", \\\"{x:68,y:555,t:1527268492340};\\\", \\\"{x:73,y:555,t:1527268492357};\\\", \\\"{x:74,y:555,t:1527268492383};\\\", \\\"{x:75,y:555,t:1527268492399};\\\", \\\"{x:79,y:555,t:1527268492407};\\\", \\\"{x:88,y:555,t:1527268492425};\\\", \\\"{x:103,y:555,t:1527268492441};\\\", \\\"{x:120,y:556,t:1527268492458};\\\", \\\"{x:127,y:557,t:1527268492474};\\\", \\\"{x:129,y:557,t:1527268492536};\\\", \\\"{x:135,y:557,t:1527268492544};\\\", \\\"{x:142,y:557,t:1527268492558};\\\", \\\"{x:162,y:549,t:1527268492575};\\\", \\\"{x:180,y:543,t:1527268492592};\\\", \\\"{x:182,y:542,t:1527268492607};\\\", \\\"{x:181,y:542,t:1527268492648};\\\", \\\"{x:177,y:543,t:1527268492658};\\\", \\\"{x:173,y:545,t:1527268492674};\\\", \\\"{x:172,y:545,t:1527268492692};\\\", \\\"{x:171,y:545,t:1527268492792};\\\", \\\"{x:170,y:545,t:1527268492880};\\\", \\\"{x:170,y:544,t:1527268493167};\\\", \\\"{x:170,y:543,t:1527268493176};\\\", \\\"{x:171,y:542,t:1527268493296};\\\", \\\"{x:179,y:544,t:1527268493308};\\\", \\\"{x:206,y:565,t:1527268493326};\\\", \\\"{x:270,y:612,t:1527268493342};\\\", \\\"{x:364,y:673,t:1527268493359};\\\", \\\"{x:465,y:726,t:1527268493375};\\\", \\\"{x:621,y:794,t:1527268493392};\\\", \\\"{x:719,y:832,t:1527268493409};\\\", \\\"{x:801,y:860,t:1527268493425};\\\", \\\"{x:837,y:876,t:1527268493441};\\\", \\\"{x:849,y:883,t:1527268493459};\\\", \\\"{x:853,y:885,t:1527268493475};\\\", \\\"{x:848,y:885,t:1527268493512};\\\", \\\"{x:837,y:885,t:1527268493526};\\\", \\\"{x:812,y:878,t:1527268493543};\\\", \\\"{x:783,y:867,t:1527268493558};\\\", \\\"{x:747,y:850,t:1527268493576};\\\", \\\"{x:726,y:837,t:1527268493593};\\\", \\\"{x:713,y:828,t:1527268493610};\\\", \\\"{x:692,y:816,t:1527268493626};\\\", \\\"{x:671,y:804,t:1527268493643};\\\", \\\"{x:646,y:793,t:1527268493660};\\\", \\\"{x:615,y:785,t:1527268493676};\\\", \\\"{x:589,y:780,t:1527268493693};\\\", \\\"{x:566,y:775,t:1527268493709};\\\", \\\"{x:552,y:774,t:1527268493728};\\\", \\\"{x:548,y:773,t:1527268493743};\\\", \\\"{x:547,y:773,t:1527268493760};\\\", \\\"{x:545,y:772,t:1527268493825};\\\", \\\"{x:543,y:770,t:1527268493833};\\\", \\\"{x:541,y:770,t:1527268493844};\\\", \\\"{x:537,y:767,t:1527268493861};\\\", \\\"{x:536,y:767,t:1527268493888};\\\", \\\"{x:536,y:766,t:1527268493913};\\\", \\\"{x:536,y:764,t:1527268493927};\\\", \\\"{x:536,y:761,t:1527268493944};\\\", \\\"{x:536,y:759,t:1527268493961};\\\", \\\"{x:536,y:758,t:1527268493978};\\\", \\\"{x:536,y:757,t:1527268494032};\\\", \\\"{x:536,y:754,t:1527268494046};\\\", \\\"{x:536,y:746,t:1527268494060};\\\", \\\"{x:536,y:736,t:1527268494075};\\\", \\\"{x:536,y:729,t:1527268494092};\\\", \\\"{x:535,y:727,t:1527268494108};\\\" ] }, { \\\"rt\\\": 31210, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 566605, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"967LR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-G -H -X -X -B -B -B -B -F -F -F -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:541,y:723,t:1527268495964};\\\", \\\"{x:548,y:719,t:1527268495978};\\\", \\\"{x:557,y:712,t:1527268495993};\\\", \\\"{x:569,y:700,t:1527268496010};\\\", \\\"{x:582,y:685,t:1527268496027};\\\", \\\"{x:593,y:672,t:1527268496044};\\\", \\\"{x:605,y:662,t:1527268496061};\\\", \\\"{x:612,y:656,t:1527268496077};\\\", \\\"{x:617,y:653,t:1527268496093};\\\", \\\"{x:621,y:650,t:1527268496111};\\\", \\\"{x:630,y:644,t:1527268496128};\\\", \\\"{x:642,y:637,t:1527268496144};\\\", \\\"{x:657,y:628,t:1527268496161};\\\", \\\"{x:666,y:622,t:1527268496177};\\\", \\\"{x:672,y:619,t:1527268496193};\\\", \\\"{x:678,y:615,t:1527268496211};\\\", \\\"{x:683,y:612,t:1527268496228};\\\", \\\"{x:689,y:608,t:1527268496244};\\\", \\\"{x:694,y:602,t:1527268496261};\\\", \\\"{x:696,y:600,t:1527268496277};\\\", \\\"{x:697,y:599,t:1527268496913};\\\", \\\"{x:697,y:598,t:1527268496927};\\\", \\\"{x:699,y:596,t:1527268496944};\\\", \\\"{x:702,y:595,t:1527268496961};\\\", \\\"{x:703,y:594,t:1527268496983};\\\", \\\"{x:704,y:593,t:1527268496998};\\\", \\\"{x:705,y:592,t:1527268497015};\\\", \\\"{x:706,y:592,t:1527268497039};\\\", \\\"{x:706,y:591,t:1527268497055};\\\", \\\"{x:708,y:590,t:1527268497064};\\\", \\\"{x:709,y:589,t:1527268497079};\\\", \\\"{x:711,y:588,t:1527268497119};\\\", \\\"{x:712,y:587,t:1527268497129};\\\", \\\"{x:717,y:585,t:1527268497144};\\\", \\\"{x:723,y:582,t:1527268497161};\\\", \\\"{x:737,y:576,t:1527268497179};\\\", \\\"{x:748,y:574,t:1527268497195};\\\", \\\"{x:756,y:571,t:1527268497211};\\\", \\\"{x:762,y:569,t:1527268497229};\\\", \\\"{x:766,y:568,t:1527268497244};\\\", \\\"{x:773,y:567,t:1527268497261};\\\", \\\"{x:790,y:562,t:1527268497278};\\\", \\\"{x:814,y:558,t:1527268497294};\\\", \\\"{x:853,y:555,t:1527268497311};\\\", \\\"{x:886,y:551,t:1527268497329};\\\", \\\"{x:921,y:551,t:1527268497344};\\\", \\\"{x:963,y:551,t:1527268497362};\\\", \\\"{x:1011,y:551,t:1527268497379};\\\", \\\"{x:1080,y:551,t:1527268497395};\\\", \\\"{x:1153,y:552,t:1527268497411};\\\", \\\"{x:1207,y:554,t:1527268497429};\\\", \\\"{x:1258,y:555,t:1527268497445};\\\", \\\"{x:1303,y:555,t:1527268497462};\\\", \\\"{x:1330,y:553,t:1527268497479};\\\", \\\"{x:1352,y:552,t:1527268497495};\\\", \\\"{x:1364,y:549,t:1527268497512};\\\", \\\"{x:1366,y:549,t:1527268497529};\\\", \\\"{x:1373,y:548,t:1527268497545};\\\", \\\"{x:1385,y:544,t:1527268497562};\\\", \\\"{x:1398,y:544,t:1527268497579};\\\", \\\"{x:1418,y:544,t:1527268497595};\\\", \\\"{x:1434,y:544,t:1527268497613};\\\", \\\"{x:1445,y:544,t:1527268497629};\\\", \\\"{x:1451,y:544,t:1527268497645};\\\", \\\"{x:1458,y:544,t:1527268497662};\\\", \\\"{x:1464,y:545,t:1527268497679};\\\", \\\"{x:1472,y:547,t:1527268497696};\\\", \\\"{x:1474,y:548,t:1527268497712};\\\", \\\"{x:1475,y:548,t:1527268497730};\\\", \\\"{x:1476,y:549,t:1527268498209};\\\", \\\"{x:1476,y:551,t:1527268498225};\\\", \\\"{x:1476,y:552,t:1527268498248};\\\", \\\"{x:1480,y:552,t:1527268498385};\\\", \\\"{x:1488,y:553,t:1527268498396};\\\", \\\"{x:1503,y:558,t:1527268498413};\\\", \\\"{x:1518,y:564,t:1527268498429};\\\", \\\"{x:1532,y:572,t:1527268498447};\\\", \\\"{x:1553,y:578,t:1527268498463};\\\", \\\"{x:1575,y:585,t:1527268498481};\\\", \\\"{x:1580,y:585,t:1527268498497};\\\", \\\"{x:1581,y:585,t:1527268498513};\\\", \\\"{x:1581,y:586,t:1527268498601};\\\", \\\"{x:1582,y:588,t:1527268498613};\\\", \\\"{x:1583,y:594,t:1527268498630};\\\", \\\"{x:1583,y:602,t:1527268498646};\\\", \\\"{x:1584,y:605,t:1527268498663};\\\", \\\"{x:1584,y:607,t:1527268498680};\\\", \\\"{x:1584,y:608,t:1527268498696};\\\", \\\"{x:1584,y:609,t:1527268498713};\\\", \\\"{x:1584,y:612,t:1527268498731};\\\", \\\"{x:1581,y:617,t:1527268498747};\\\", \\\"{x:1572,y:623,t:1527268498764};\\\", \\\"{x:1565,y:629,t:1527268498780};\\\", \\\"{x:1558,y:634,t:1527268498797};\\\", \\\"{x:1555,y:636,t:1527268498813};\\\", \\\"{x:1554,y:637,t:1527268498831};\\\", \\\"{x:1553,y:638,t:1527268498847};\\\", \\\"{x:1551,y:641,t:1527268498863};\\\", \\\"{x:1544,y:649,t:1527268498880};\\\", \\\"{x:1538,y:656,t:1527268498897};\\\", \\\"{x:1534,y:658,t:1527268498913};\\\", \\\"{x:1531,y:661,t:1527268498930};\\\", \\\"{x:1525,y:670,t:1527268498947};\\\", \\\"{x:1519,y:680,t:1527268498963};\\\", \\\"{x:1511,y:701,t:1527268498981};\\\", \\\"{x:1506,y:718,t:1527268498997};\\\", \\\"{x:1505,y:730,t:1527268499013};\\\", \\\"{x:1504,y:736,t:1527268499030};\\\", \\\"{x:1504,y:738,t:1527268499047};\\\", \\\"{x:1504,y:739,t:1527268499063};\\\", \\\"{x:1503,y:742,t:1527268499080};\\\", \\\"{x:1503,y:745,t:1527268499096};\\\", \\\"{x:1502,y:749,t:1527268499114};\\\", \\\"{x:1502,y:754,t:1527268499131};\\\", \\\"{x:1501,y:760,t:1527268499147};\\\", \\\"{x:1500,y:764,t:1527268499164};\\\", \\\"{x:1498,y:769,t:1527268499180};\\\", \\\"{x:1496,y:772,t:1527268499198};\\\", \\\"{x:1493,y:779,t:1527268499215};\\\", \\\"{x:1489,y:783,t:1527268499230};\\\", \\\"{x:1489,y:791,t:1527268499247};\\\", \\\"{x:1488,y:795,t:1527268499265};\\\", \\\"{x:1488,y:796,t:1527268499280};\\\", \\\"{x:1487,y:799,t:1527268499297};\\\", \\\"{x:1487,y:800,t:1527268499368};\\\", \\\"{x:1487,y:801,t:1527268499391};\\\", \\\"{x:1487,y:802,t:1527268499400};\\\", \\\"{x:1487,y:803,t:1527268499416};\\\", \\\"{x:1487,y:804,t:1527268499427};\\\", \\\"{x:1486,y:805,t:1527268499444};\\\", \\\"{x:1485,y:809,t:1527268499461};\\\", \\\"{x:1485,y:811,t:1527268499478};\\\", \\\"{x:1485,y:812,t:1527268499526};\\\", \\\"{x:1485,y:815,t:1527268499535};\\\", \\\"{x:1485,y:818,t:1527268499544};\\\", \\\"{x:1485,y:822,t:1527268499562};\\\", \\\"{x:1485,y:826,t:1527268499579};\\\", \\\"{x:1485,y:829,t:1527268499595};\\\", \\\"{x:1485,y:830,t:1527268499611};\\\", \\\"{x:1486,y:831,t:1527268499950};\\\", \\\"{x:1487,y:832,t:1527268501823};\\\", \\\"{x:1487,y:833,t:1527268502454};\\\", \\\"{x:1485,y:834,t:1527268502465};\\\", \\\"{x:1484,y:834,t:1527268502481};\\\", \\\"{x:1479,y:834,t:1527268502498};\\\", \\\"{x:1472,y:834,t:1527268502515};\\\", \\\"{x:1464,y:834,t:1527268502532};\\\", \\\"{x:1457,y:834,t:1527268502548};\\\", \\\"{x:1446,y:830,t:1527268502565};\\\", \\\"{x:1435,y:827,t:1527268502582};\\\", \\\"{x:1415,y:825,t:1527268502598};\\\", \\\"{x:1391,y:821,t:1527268502614};\\\", \\\"{x:1364,y:819,t:1527268502631};\\\", \\\"{x:1340,y:814,t:1527268502649};\\\", \\\"{x:1319,y:809,t:1527268502665};\\\", \\\"{x:1304,y:803,t:1527268502681};\\\", \\\"{x:1297,y:801,t:1527268502698};\\\", \\\"{x:1295,y:800,t:1527268502715};\\\", \\\"{x:1295,y:798,t:1527268502767};\\\", \\\"{x:1295,y:795,t:1527268502782};\\\", \\\"{x:1295,y:791,t:1527268502798};\\\", \\\"{x:1296,y:789,t:1527268502815};\\\", \\\"{x:1300,y:786,t:1527268502832};\\\", \\\"{x:1304,y:785,t:1527268502848};\\\", \\\"{x:1308,y:781,t:1527268502865};\\\", \\\"{x:1308,y:780,t:1527268502881};\\\", \\\"{x:1310,y:779,t:1527268502898};\\\", \\\"{x:1311,y:779,t:1527268502918};\\\", \\\"{x:1312,y:778,t:1527268502931};\\\", \\\"{x:1315,y:777,t:1527268502948};\\\", \\\"{x:1320,y:775,t:1527268502965};\\\", \\\"{x:1327,y:770,t:1527268502982};\\\", \\\"{x:1330,y:767,t:1527268502998};\\\", \\\"{x:1334,y:764,t:1527268503015};\\\", \\\"{x:1336,y:763,t:1527268503032};\\\", \\\"{x:1337,y:763,t:1527268503093};\\\", \\\"{x:1338,y:763,t:1527268503109};\\\", \\\"{x:1339,y:763,t:1527268503149};\\\", \\\"{x:1339,y:762,t:1527268503686};\\\", \\\"{x:1339,y:761,t:1527268503699};\\\", \\\"{x:1346,y:755,t:1527268503714};\\\", \\\"{x:1351,y:752,t:1527268503731};\\\", \\\"{x:1354,y:749,t:1527268503748};\\\", \\\"{x:1355,y:748,t:1527268503765};\\\", \\\"{x:1353,y:749,t:1527268504062};\\\", \\\"{x:1352,y:749,t:1527268504078};\\\", \\\"{x:1351,y:749,t:1527268504085};\\\", \\\"{x:1351,y:750,t:1527268504134};\\\", \\\"{x:1350,y:751,t:1527268504221};\\\", \\\"{x:1349,y:751,t:1527268504232};\\\", \\\"{x:1348,y:751,t:1527268504249};\\\", \\\"{x:1348,y:752,t:1527268504265};\\\", \\\"{x:1347,y:752,t:1527268504389};\\\", \\\"{x:1347,y:754,t:1527268504421};\\\", \\\"{x:1346,y:754,t:1527268504445};\\\", \\\"{x:1345,y:754,t:1527268504542};\\\", \\\"{x:1345,y:755,t:1527268504990};\\\", \\\"{x:1345,y:756,t:1527268505006};\\\", \\\"{x:1345,y:757,t:1527268505016};\\\", \\\"{x:1345,y:758,t:1527268505033};\\\", \\\"{x:1345,y:760,t:1527268505050};\\\", \\\"{x:1344,y:762,t:1527268505067};\\\", \\\"{x:1344,y:763,t:1527268505166};\\\", \\\"{x:1344,y:765,t:1527268505183};\\\", \\\"{x:1344,y:766,t:1527268505214};\\\", \\\"{x:1344,y:765,t:1527268505686};\\\", \\\"{x:1344,y:764,t:1527268505702};\\\", \\\"{x:1344,y:761,t:1527268505717};\\\", \\\"{x:1344,y:759,t:1527268505733};\\\", \\\"{x:1344,y:758,t:1527268505752};\\\", \\\"{x:1344,y:757,t:1527268505774};\\\", \\\"{x:1344,y:756,t:1527268505798};\\\", \\\"{x:1344,y:755,t:1527268505806};\\\", \\\"{x:1344,y:754,t:1527268505817};\\\", \\\"{x:1344,y:752,t:1527268505834};\\\", \\\"{x:1344,y:749,t:1527268505851};\\\", \\\"{x:1344,y:748,t:1527268505878};\\\", \\\"{x:1344,y:746,t:1527268505990};\\\", \\\"{x:1345,y:744,t:1527268506001};\\\", \\\"{x:1347,y:738,t:1527268506018};\\\", \\\"{x:1350,y:730,t:1527268506034};\\\", \\\"{x:1354,y:723,t:1527268506051};\\\", \\\"{x:1356,y:717,t:1527268506068};\\\", \\\"{x:1358,y:712,t:1527268506084};\\\", \\\"{x:1359,y:710,t:1527268506101};\\\", \\\"{x:1360,y:708,t:1527268506117};\\\", \\\"{x:1360,y:707,t:1527268506134};\\\", \\\"{x:1360,y:706,t:1527268506166};\\\", \\\"{x:1360,y:704,t:1527268506542};\\\", \\\"{x:1357,y:700,t:1527268506551};\\\", \\\"{x:1355,y:696,t:1527268506569};\\\", \\\"{x:1351,y:691,t:1527268506586};\\\", \\\"{x:1344,y:688,t:1527268506601};\\\", \\\"{x:1336,y:684,t:1527268506619};\\\", \\\"{x:1330,y:684,t:1527268506635};\\\", \\\"{x:1329,y:684,t:1527268506652};\\\", \\\"{x:1328,y:683,t:1527268506678};\\\", \\\"{x:1330,y:685,t:1527268506838};\\\", \\\"{x:1336,y:691,t:1527268506852};\\\", \\\"{x:1352,y:696,t:1527268506869};\\\", \\\"{x:1364,y:698,t:1527268506886};\\\", \\\"{x:1376,y:701,t:1527268506901};\\\", \\\"{x:1378,y:702,t:1527268506918};\\\", \\\"{x:1378,y:703,t:1527268507054};\\\", \\\"{x:1378,y:705,t:1527268507068};\\\", \\\"{x:1370,y:708,t:1527268507085};\\\", \\\"{x:1360,y:710,t:1527268507102};\\\", \\\"{x:1356,y:710,t:1527268507118};\\\", \\\"{x:1353,y:710,t:1527268507486};\\\", \\\"{x:1352,y:706,t:1527268507502};\\\", \\\"{x:1352,y:703,t:1527268507519};\\\", \\\"{x:1349,y:700,t:1527268507536};\\\", \\\"{x:1349,y:699,t:1527268507569};\\\", \\\"{x:1349,y:698,t:1527268507586};\\\", \\\"{x:1348,y:696,t:1527268517774};\\\", \\\"{x:1331,y:686,t:1527268517783};\\\", \\\"{x:1314,y:675,t:1527268517793};\\\", \\\"{x:1278,y:658,t:1527268517808};\\\", \\\"{x:1251,y:647,t:1527268517825};\\\", \\\"{x:1228,y:635,t:1527268517842};\\\", \\\"{x:1213,y:627,t:1527268517859};\\\", \\\"{x:1209,y:623,t:1527268517875};\\\", \\\"{x:1208,y:619,t:1527268517893};\\\", \\\"{x:1208,y:615,t:1527268517910};\\\", \\\"{x:1208,y:611,t:1527268517925};\\\", \\\"{x:1206,y:607,t:1527268517942};\\\", \\\"{x:1206,y:604,t:1527268517959};\\\", \\\"{x:1206,y:601,t:1527268517975};\\\", \\\"{x:1210,y:593,t:1527268517993};\\\", \\\"{x:1218,y:588,t:1527268518009};\\\", \\\"{x:1226,y:583,t:1527268518026};\\\", \\\"{x:1235,y:578,t:1527268518042};\\\", \\\"{x:1242,y:574,t:1527268518059};\\\", \\\"{x:1243,y:572,t:1527268518076};\\\", \\\"{x:1245,y:570,t:1527268518092};\\\", \\\"{x:1246,y:569,t:1527268518109};\\\", \\\"{x:1247,y:568,t:1527268518125};\\\", \\\"{x:1250,y:564,t:1527268518142};\\\", \\\"{x:1255,y:561,t:1527268518159};\\\", \\\"{x:1260,y:560,t:1527268518175};\\\", \\\"{x:1264,y:557,t:1527268518192};\\\", \\\"{x:1265,y:556,t:1527268518209};\\\", \\\"{x:1266,y:556,t:1527268518225};\\\", \\\"{x:1267,y:554,t:1527268518285};\\\", \\\"{x:1269,y:554,t:1527268518301};\\\", \\\"{x:1270,y:554,t:1527268518309};\\\", \\\"{x:1271,y:553,t:1527268518327};\\\", \\\"{x:1273,y:552,t:1527268518342};\\\", \\\"{x:1273,y:550,t:1527268518726};\\\", \\\"{x:1278,y:546,t:1527268518744};\\\", \\\"{x:1292,y:541,t:1527268518760};\\\", \\\"{x:1303,y:537,t:1527268518777};\\\", \\\"{x:1306,y:537,t:1527268518792};\\\", \\\"{x:1307,y:536,t:1527268518809};\\\", \\\"{x:1308,y:535,t:1527268518950};\\\", \\\"{x:1309,y:535,t:1527268519030};\\\", \\\"{x:1311,y:534,t:1527268519046};\\\", \\\"{x:1312,y:534,t:1527268519059};\\\", \\\"{x:1313,y:533,t:1527268519077};\\\", \\\"{x:1315,y:533,t:1527268519093};\\\", \\\"{x:1317,y:532,t:1527268519110};\\\", \\\"{x:1318,y:532,t:1527268519134};\\\", \\\"{x:1318,y:531,t:1527268519144};\\\", \\\"{x:1319,y:531,t:1527268519160};\\\", \\\"{x:1320,y:530,t:1527268519182};\\\", \\\"{x:1321,y:530,t:1527268519310};\\\", \\\"{x:1322,y:530,t:1527268519422};\\\", \\\"{x:1323,y:530,t:1527268519430};\\\", \\\"{x:1324,y:530,t:1527268519445};\\\", \\\"{x:1325,y:530,t:1527268519460};\\\", \\\"{x:1328,y:533,t:1527268519477};\\\", \\\"{x:1331,y:542,t:1527268519493};\\\", \\\"{x:1333,y:543,t:1527268519510};\\\", \\\"{x:1335,y:546,t:1527268519527};\\\", \\\"{x:1336,y:547,t:1527268519544};\\\", \\\"{x:1337,y:547,t:1527268519561};\\\", \\\"{x:1338,y:547,t:1527268519630};\\\", \\\"{x:1339,y:547,t:1527268519958};\\\", \\\"{x:1339,y:552,t:1527268520846};\\\", \\\"{x:1339,y:568,t:1527268520861};\\\", \\\"{x:1339,y:576,t:1527268520878};\\\", \\\"{x:1340,y:579,t:1527268520895};\\\", \\\"{x:1342,y:576,t:1527268521222};\\\", \\\"{x:1343,y:575,t:1527268521229};\\\", \\\"{x:1346,y:571,t:1527268521244};\\\", \\\"{x:1352,y:565,t:1527268521262};\\\", \\\"{x:1355,y:562,t:1527268521279};\\\", \\\"{x:1356,y:561,t:1527268521294};\\\", \\\"{x:1357,y:561,t:1527268521334};\\\", \\\"{x:1358,y:561,t:1527268521349};\\\", \\\"{x:1359,y:560,t:1527268521362};\\\", \\\"{x:1362,y:559,t:1527268521379};\\\", \\\"{x:1363,y:558,t:1527268521395};\\\", \\\"{x:1365,y:558,t:1527268521502};\\\", \\\"{x:1368,y:557,t:1527268521511};\\\", \\\"{x:1375,y:554,t:1527268521529};\\\", \\\"{x:1379,y:554,t:1527268521545};\\\", \\\"{x:1382,y:553,t:1527268521562};\\\", \\\"{x:1384,y:552,t:1527268521578};\\\", \\\"{x:1386,y:551,t:1527268521595};\\\", \\\"{x:1388,y:551,t:1527268521612};\\\", \\\"{x:1390,y:550,t:1527268521750};\\\", \\\"{x:1394,y:549,t:1527268521762};\\\", \\\"{x:1405,y:549,t:1527268521779};\\\", \\\"{x:1419,y:552,t:1527268521796};\\\", \\\"{x:1426,y:554,t:1527268521812};\\\", \\\"{x:1428,y:555,t:1527268521828};\\\", \\\"{x:1428,y:556,t:1527268521926};\\\", \\\"{x:1428,y:557,t:1527268522062};\\\", \\\"{x:1428,y:558,t:1527268522086};\\\", \\\"{x:1428,y:559,t:1527268522134};\\\", \\\"{x:1428,y:560,t:1527268522190};\\\", \\\"{x:1428,y:561,t:1527268522205};\\\", \\\"{x:1428,y:562,t:1527268522214};\\\", \\\"{x:1428,y:563,t:1527268522229};\\\", \\\"{x:1428,y:566,t:1527268522245};\\\", \\\"{x:1428,y:568,t:1527268522263};\\\", \\\"{x:1427,y:568,t:1527268522279};\\\", \\\"{x:1427,y:569,t:1527268522518};\\\", \\\"{x:1428,y:569,t:1527268522529};\\\", \\\"{x:1430,y:569,t:1527268522546};\\\", \\\"{x:1433,y:569,t:1527268522563};\\\", \\\"{x:1435,y:569,t:1527268522638};\\\", \\\"{x:1437,y:568,t:1527268522646};\\\", \\\"{x:1443,y:568,t:1527268522663};\\\", \\\"{x:1457,y:572,t:1527268522680};\\\", \\\"{x:1471,y:578,t:1527268522696};\\\", \\\"{x:1481,y:583,t:1527268522713};\\\", \\\"{x:1490,y:589,t:1527268522730};\\\", \\\"{x:1493,y:592,t:1527268522746};\\\", \\\"{x:1493,y:593,t:1527268522763};\\\", \\\"{x:1495,y:599,t:1527268522780};\\\", \\\"{x:1497,y:609,t:1527268522796};\\\", \\\"{x:1497,y:625,t:1527268522813};\\\", \\\"{x:1477,y:659,t:1527268522829};\\\", \\\"{x:1434,y:698,t:1527268522845};\\\", \\\"{x:1346,y:737,t:1527268522863};\\\", \\\"{x:1236,y:760,t:1527268522880};\\\", \\\"{x:1103,y:762,t:1527268522896};\\\", \\\"{x:940,y:762,t:1527268522913};\\\", \\\"{x:747,y:740,t:1527268522929};\\\", \\\"{x:537,y:710,t:1527268522946};\\\", \\\"{x:343,y:678,t:1527268522964};\\\", \\\"{x:191,y:656,t:1527268522981};\\\", \\\"{x:86,y:643,t:1527268522996};\\\", \\\"{x:40,y:631,t:1527268523014};\\\", \\\"{x:38,y:631,t:1527268523030};\\\", \\\"{x:40,y:628,t:1527268523052};\\\", \\\"{x:47,y:624,t:1527268523063};\\\", \\\"{x:54,y:617,t:1527268523080};\\\", \\\"{x:60,y:610,t:1527268523097};\\\", \\\"{x:69,y:600,t:1527268523113};\\\", \\\"{x:87,y:585,t:1527268523130};\\\", \\\"{x:118,y:562,t:1527268523148};\\\", \\\"{x:159,y:538,t:1527268523164};\\\", \\\"{x:194,y:518,t:1527268523180};\\\", \\\"{x:217,y:505,t:1527268523197};\\\", \\\"{x:243,y:496,t:1527268523213};\\\", \\\"{x:265,y:493,t:1527268523230};\\\", \\\"{x:287,y:491,t:1527268523247};\\\", \\\"{x:329,y:491,t:1527268523263};\\\", \\\"{x:387,y:491,t:1527268523280};\\\", \\\"{x:433,y:489,t:1527268523297};\\\", \\\"{x:469,y:489,t:1527268523314};\\\", \\\"{x:506,y:489,t:1527268523330};\\\", \\\"{x:543,y:489,t:1527268523347};\\\", \\\"{x:577,y:489,t:1527268523364};\\\", \\\"{x:622,y:492,t:1527268523381};\\\", \\\"{x:646,y:497,t:1527268523397};\\\", \\\"{x:662,y:504,t:1527268523416};\\\", \\\"{x:667,y:507,t:1527268523431};\\\", \\\"{x:668,y:509,t:1527268523447};\\\", \\\"{x:668,y:511,t:1527268523464};\\\", \\\"{x:669,y:516,t:1527268523481};\\\", \\\"{x:669,y:519,t:1527268523497};\\\", \\\"{x:669,y:523,t:1527268523514};\\\", \\\"{x:667,y:527,t:1527268523531};\\\", \\\"{x:663,y:531,t:1527268523547};\\\", \\\"{x:657,y:535,t:1527268523566};\\\", \\\"{x:648,y:540,t:1527268523581};\\\", \\\"{x:631,y:547,t:1527268523597};\\\", \\\"{x:611,y:552,t:1527268523615};\\\", \\\"{x:593,y:555,t:1527268523631};\\\", \\\"{x:566,y:558,t:1527268523647};\\\", \\\"{x:536,y:561,t:1527268523664};\\\", \\\"{x:499,y:561,t:1527268523680};\\\", \\\"{x:463,y:561,t:1527268523698};\\\", \\\"{x:421,y:561,t:1527268523714};\\\", \\\"{x:382,y:561,t:1527268523730};\\\", \\\"{x:342,y:561,t:1527268523748};\\\", \\\"{x:313,y:561,t:1527268523764};\\\", \\\"{x:288,y:561,t:1527268523780};\\\", \\\"{x:285,y:561,t:1527268523797};\\\", \\\"{x:284,y:561,t:1527268523973};\\\", \\\"{x:284,y:566,t:1527268523981};\\\", \\\"{x:286,y:583,t:1527268523999};\\\", \\\"{x:299,y:611,t:1527268524014};\\\", \\\"{x:323,y:656,t:1527268524030};\\\", \\\"{x:344,y:685,t:1527268524048};\\\", \\\"{x:372,y:712,t:1527268524064};\\\", \\\"{x:399,y:730,t:1527268524081};\\\", \\\"{x:423,y:742,t:1527268524097};\\\", \\\"{x:433,y:747,t:1527268524114};\\\", \\\"{x:440,y:749,t:1527268524131};\\\", \\\"{x:441,y:749,t:1527268524147};\\\", \\\"{x:442,y:749,t:1527268524165};\\\", \\\"{x:448,y:749,t:1527268524182};\\\", \\\"{x:461,y:744,t:1527268524198};\\\", \\\"{x:486,y:732,t:1527268524217};\\\", \\\"{x:520,y:712,t:1527268524231};\\\", \\\"{x:563,y:689,t:1527268524247};\\\", \\\"{x:610,y:660,t:1527268524264};\\\", \\\"{x:648,y:638,t:1527268524282};\\\", \\\"{x:668,y:624,t:1527268524298};\\\", \\\"{x:680,y:613,t:1527268524316};\\\", \\\"{x:687,y:603,t:1527268524332};\\\", \\\"{x:689,y:599,t:1527268524347};\\\", \\\"{x:689,y:591,t:1527268524364};\\\", \\\"{x:689,y:587,t:1527268524381};\\\", \\\"{x:687,y:584,t:1527268524398};\\\", \\\"{x:685,y:582,t:1527268524414};\\\", \\\"{x:684,y:580,t:1527268524431};\\\", \\\"{x:682,y:579,t:1527268524493};\\\", \\\"{x:680,y:577,t:1527268524500};\\\", \\\"{x:677,y:575,t:1527268524515};\\\", \\\"{x:672,y:573,t:1527268524531};\\\", \\\"{x:667,y:570,t:1527268524548};\\\", \\\"{x:662,y:567,t:1527268524566};\\\", \\\"{x:656,y:564,t:1527268524582};\\\", \\\"{x:647,y:562,t:1527268524598};\\\", \\\"{x:630,y:559,t:1527268524615};\\\", \\\"{x:612,y:556,t:1527268524631};\\\", \\\"{x:596,y:552,t:1527268524649};\\\", \\\"{x:586,y:547,t:1527268524665};\\\", \\\"{x:579,y:542,t:1527268524682};\\\", \\\"{x:576,y:539,t:1527268524698};\\\", \\\"{x:575,y:538,t:1527268524715};\\\", \\\"{x:575,y:536,t:1527268524731};\\\", \\\"{x:575,y:534,t:1527268524748};\\\", \\\"{x:578,y:530,t:1527268524766};\\\", \\\"{x:590,y:525,t:1527268524782};\\\", \\\"{x:595,y:523,t:1527268524798};\\\", \\\"{x:596,y:522,t:1527268524814};\\\", \\\"{x:597,y:521,t:1527268524877};\\\", \\\"{x:599,y:521,t:1527268524885};\\\", \\\"{x:603,y:520,t:1527268524899};\\\", \\\"{x:607,y:519,t:1527268524915};\\\", \\\"{x:611,y:518,t:1527268524931};\\\", \\\"{x:614,y:517,t:1527268524949};\\\", \\\"{x:617,y:517,t:1527268525197};\\\", \\\"{x:624,y:514,t:1527268525205};\\\", \\\"{x:635,y:511,t:1527268525215};\\\", \\\"{x:654,y:506,t:1527268525231};\\\", \\\"{x:667,y:502,t:1527268525248};\\\", \\\"{x:675,y:499,t:1527268525266};\\\", \\\"{x:679,y:498,t:1527268525283};\\\", \\\"{x:681,y:498,t:1527268525298};\\\", \\\"{x:682,y:498,t:1527268525317};\\\", \\\"{x:684,y:497,t:1527268525340};\\\", \\\"{x:689,y:495,t:1527268525349};\\\", \\\"{x:706,y:494,t:1527268525365};\\\", \\\"{x:730,y:492,t:1527268525382};\\\", \\\"{x:749,y:492,t:1527268525398};\\\", \\\"{x:756,y:492,t:1527268525416};\\\", \\\"{x:757,y:492,t:1527268525433};\\\", \\\"{x:758,y:492,t:1527268525477};\\\", \\\"{x:767,y:492,t:1527268525485};\\\", \\\"{x:779,y:492,t:1527268525498};\\\", \\\"{x:810,y:505,t:1527268525517};\\\", \\\"{x:831,y:511,t:1527268525533};\\\", \\\"{x:846,y:516,t:1527268525548};\\\", \\\"{x:849,y:517,t:1527268525566};\\\", \\\"{x:850,y:517,t:1527268525583};\\\", \\\"{x:853,y:517,t:1527268525621};\\\", \\\"{x:856,y:517,t:1527268525633};\\\", \\\"{x:861,y:517,t:1527268525649};\\\", \\\"{x:863,y:517,t:1527268525666};\\\", \\\"{x:864,y:517,t:1527268525685};\\\", \\\"{x:861,y:517,t:1527268525742};\\\", \\\"{x:860,y:517,t:1527268525749};\\\", \\\"{x:854,y:520,t:1527268525765};\\\", \\\"{x:852,y:521,t:1527268525782};\\\", \\\"{x:849,y:522,t:1527268525799};\\\", \\\"{x:845,y:523,t:1527268525816};\\\", \\\"{x:843,y:523,t:1527268525833};\\\", \\\"{x:842,y:523,t:1527268525850};\\\", \\\"{x:841,y:523,t:1527268525866};\\\", \\\"{x:840,y:524,t:1527268526036};\\\", \\\"{x:834,y:526,t:1527268526049};\\\", \\\"{x:813,y:533,t:1527268526066};\\\", \\\"{x:793,y:542,t:1527268526082};\\\", \\\"{x:776,y:549,t:1527268526099};\\\", \\\"{x:758,y:563,t:1527268526115};\\\", \\\"{x:730,y:595,t:1527268526133};\\\", \\\"{x:699,y:623,t:1527268526150};\\\", \\\"{x:671,y:648,t:1527268526166};\\\", \\\"{x:657,y:663,t:1527268526183};\\\", \\\"{x:648,y:680,t:1527268526199};\\\", \\\"{x:640,y:692,t:1527268526215};\\\", \\\"{x:629,y:707,t:1527268526232};\\\", \\\"{x:612,y:729,t:1527268526249};\\\", \\\"{x:589,y:755,t:1527268526267};\\\", \\\"{x:570,y:783,t:1527268526283};\\\", \\\"{x:559,y:801,t:1527268526299};\\\", \\\"{x:554,y:808,t:1527268526317};\\\", \\\"{x:554,y:809,t:1527268526332};\\\", \\\"{x:552,y:809,t:1527268526398};\\\", \\\"{x:547,y:807,t:1527268526405};\\\", \\\"{x:544,y:805,t:1527268526417};\\\", \\\"{x:540,y:802,t:1527268526433};\\\", \\\"{x:536,y:796,t:1527268526450};\\\", \\\"{x:533,y:786,t:1527268526467};\\\", \\\"{x:529,y:774,t:1527268526485};\\\", \\\"{x:526,y:763,t:1527268526501};\\\", \\\"{x:523,y:753,t:1527268526516};\\\", \\\"{x:519,y:748,t:1527268526532};\\\" ] }, { \\\"rt\\\": 35620, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 603455, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"967LR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"To figure out what events start at 12 pm, you trace the start time of 12pm to the duration in hours.\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 7740, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"19\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"United States\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 612197, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"967LR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 14652, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Second\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 627872, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"967LR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 25027, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 654237, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"967LR\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"mike\\\", \\\"condition\\\": \\\"115\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"967LR\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 179, dom: 888, initialDom: 966",
  "javascriptErrors": []
}