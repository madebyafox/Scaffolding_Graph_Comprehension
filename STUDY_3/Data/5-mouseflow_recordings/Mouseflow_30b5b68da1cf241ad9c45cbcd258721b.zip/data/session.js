var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "30b5b68da1cf241ad9c45cbcd258721b",
  "created": "2018-06-01T11:15:29.4718046-07:00",
  "lastActivity": "2018-06-01T11:17:05.3908046-07:00",
  "pageViews": [
    {
      "id": "060129521463058f4be567877698c43a41331945",
      "startTime": "2018-06-01T11:15:29.4718046-07:00",
      "endTime": "2018-06-01T11:17:05.3908046-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/8",
      "visitTime": 95919,
      "engagementTime": 82720,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 95919,
  "engagementTime": 82720,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.41",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=5KWEX",
    "CONDITION=311",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "9488deed6060bcea2b85eaa617552d9e",
  "gdpr": false
}