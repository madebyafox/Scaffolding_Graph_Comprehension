var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["06012322de40a28f4dd9be2abd42e4fff778292a"] = {
  "startTime": "2018-06-01T17:18:23.5467533Z",
  "websitePageUrl": "/16",
  "visitTime": 75117,
  "engagementTime": 72721,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "bb1dc67f097ea74ebe30f0628a6bedda",
    "created": "2018-06-01T17:18:23.5467533+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=QGUGU",
      "CONDITION=115"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "b244c9bd616521100c44cb02e170898d",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/bb1dc67f097ea74ebe30f0628a6bedda/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 231,
      "e": 231,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 232,
      "e": 232,
      "ty": 2,
      "x": 553,
      "y": 707
    },
    {
      "t": 251,
      "e": 251,
      "ty": 41,
      "x": 51248,
      "y": 38722,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1201,
      "e": 1201,
      "ty": 2,
      "x": 550,
      "y": 673
    },
    {
      "t": 1251,
      "e": 1251,
      "ty": 41,
      "x": 50349,
      "y": 35177,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1301,
      "e": 1301,
      "ty": 2,
      "x": 542,
      "y": 611
    },
    {
      "t": 1321,
      "e": 1321,
      "ty": 6,
      "x": 540,
      "y": 603,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1401,
      "e": 1401,
      "ty": 2,
      "x": 537,
      "y": 594
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 2,
      "x": 536,
      "y": 591
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 41,
      "x": 49337,
      "y": 55231,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1600,
      "e": 1600,
      "ty": 2,
      "x": 536,
      "y": 586
    },
    {
      "t": 1752,
      "e": 1752,
      "ty": 41,
      "x": 49337,
      "y": 51186,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2747,
      "e": 2747,
      "ty": 3,
      "x": 536,
      "y": 586,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2749,
      "e": 2749,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2891,
      "e": 2891,
      "ty": 4,
      "x": 49337,
      "y": 51186,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2891,
      "e": 2891,
      "ty": 5,
      "x": 536,
      "y": 586,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9088,
      "e": 7891,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 9383,
      "e": 8186,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 9384,
      "e": 8187,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9454,
      "e": 8257,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "L"
    },
    {
      "t": 9590,
      "e": 8393,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "L"
    },
    {
      "t": 9838,
      "e": 8641,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 9839,
      "e": 8642,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9943,
      "e": 8746,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Lo"
    },
    {
      "t": 10000,
      "e": 8803,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10062,
      "e": 8865,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 10063,
      "e": 8866,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10103,
      "e": 8906,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 10103,
      "e": 8906,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10126,
      "e": 8929,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look"
    },
    {
      "t": 10230,
      "e": 9033,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 10343,
      "e": 9146,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 10343,
      "e": 9146,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10462,
      "e": 9265,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 10534,
      "e": 9337,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 10535,
      "e": 9338,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10662,
      "e": 9465,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 10663,
      "e": 9466,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10725,
      "e": 9528,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 10774,
      "e": 9577,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 10782,
      "e": 9585,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 10782,
      "e": 9585,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10870,
      "e": 9673,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 10902,
      "e": 9705,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 10903,
      "e": 9706,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10982,
      "e": 9785,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 11014,
      "e": 9817,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 11014,
      "e": 9817,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11118,
      "e": 9921,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 11126,
      "e": 9929,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 11126,
      "e": 9929,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11230,
      "e": 10033,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 11303,
      "e": 10106,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11304,
      "e": 10107,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11406,
      "e": 10209,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 12398,
      "e": 11201,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 12400,
      "e": 11203,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12510,
      "e": 11313,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 12550,
      "e": 11353,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12550,
      "e": 11353,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12655,
      "e": 11458,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 12663,
      "e": 11466,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 12663,
      "e": 11466,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12790,
      "e": 11593,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 12862,
      "e": 11665,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 12863,
      "e": 11666,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12991,
      "e": 11794,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 12991,
      "e": 11794,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12999,
      "e": 11802,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||xi"
    },
    {
      "t": 13102,
      "e": 11905,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13134,
      "e": 11937,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 13134,
      "e": 11937,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13279,
      "e": 12082,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 13310,
      "e": 12113,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13311,
      "e": 12114,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13414,
      "e": 12217,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 14767,
      "e": 13570,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 14767,
      "e": 13570,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14902,
      "e": 13705,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 14903,
      "e": 13706,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 14903,
      "e": 13706,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14982,
      "e": 13785,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 15014,
      "e": 13817,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 15015,
      "e": 13818,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15118,
      "e": 13921,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 15126,
      "e": 13929,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15127,
      "e": 13930,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15230,
      "e": 14033,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 15246,
      "e": 14049,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 15247,
      "e": 14050,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15310,
      "e": 14113,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 15310,
      "e": 14113,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15375,
      "e": 14178,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||se"
    },
    {
      "t": 15390,
      "e": 14193,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 15494,
      "e": 14297,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 15496,
      "e": 14299,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15574,
      "e": 14377,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 15582,
      "e": 14385,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15582,
      "e": 14385,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15654,
      "e": 14457,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20001,
      "e": 18804,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20070,
      "e": 18873,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 20070,
      "e": 18873,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20190,
      "e": 18993,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 20238,
      "e": 19041,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 20239,
      "e": 19042,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20302,
      "e": 19105,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 20390,
      "e": 19193,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 20390,
      "e": 19193,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20534,
      "e": 19337,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 20534,
      "e": 19337,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20614,
      "e": 19417,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 20661,
      "e": 19464,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20752,
      "e": 19555,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 20752,
      "e": 19555,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20886,
      "e": 19689,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 21311,
      "e": 20114,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 21312,
      "e": 20115,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21439,
      "e": 20242,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 21455,
      "e": 20258,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 21455,
      "e": 20258,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21603,
      "e": 20406,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x axis and see what do"
    },
    {
      "t": 21646,
      "e": 20449,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 22495,
      "e": 21298,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 22559,
      "e": 21362,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x axis and see what d"
    },
    {
      "t": 22646,
      "e": 21449,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 22719,
      "e": 21522,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x axis and see what "
    },
    {
      "t": 23143,
      "e": 21946,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 23144,
      "e": 21947,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23190,
      "e": 21993,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 23190,
      "e": 21993,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23326,
      "e": 22129,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||po"
    },
    {
      "t": 23334,
      "e": 22137,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23470,
      "e": 22273,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 23470,
      "e": 22273,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23566,
      "e": 22369,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 23567,
      "e": 22370,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23614,
      "e": 22417,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 23671,
      "e": 22474,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 23672,
      "e": 22475,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23686,
      "e": 22489,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 23798,
      "e": 22601,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 23799,
      "e": 22602,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23822,
      "e": 22625,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 23918,
      "e": 22721,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24174,
      "e": 22977,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24175,
      "e": 22978,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24326,
      "e": 23129,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30003,
      "e": 28129,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30426,
      "e": 28129,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 30427,
      "e": 28130,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30489,
      "e": 28192,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 30489,
      "e": 28192,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30586,
      "e": 28289,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 30586,
      "e": 28289,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30609,
      "e": 28312,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||lin"
    },
    {
      "t": 30657,
      "e": 28360,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30690,
      "e": 28393,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30729,
      "e": 28432,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 30729,
      "e": 28432,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30858,
      "e": 28561,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 30898,
      "e": 28601,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30898,
      "e": 28601,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31002,
      "e": 28705,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 31265,
      "e": 28968,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 31265,
      "e": 28968,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31337,
      "e": 29040,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 31481,
      "e": 29184,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 31482,
      "e": 29185,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31577,
      "e": 29280,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 31666,
      "e": 29369,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31666,
      "e": 29369,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31778,
      "e": 29481,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 31882,
      "e": 29585,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 31883,
      "e": 29586,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32005,
      "e": 29708,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x axis and see what points line up a"
    },
    {
      "t": 32057,
      "e": 29760,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 32058,
      "e": 29761,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32106,
      "e": 29809,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 32161,
      "e": 29864,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32370,
      "e": 30073,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32370,
      "e": 30073,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32538,
      "e": 30241,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 34930,
      "e": 32633,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 34931,
      "e": 32634,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35081,
      "e": 32784,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 35082,
      "e": 32785,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35178,
      "e": 32881,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 35314,
      "e": 33017,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 38921,
      "e": 36624,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 39002,
      "e": 36705,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x axis and see what points line up at 1"
    },
    {
      "t": 39090,
      "e": 36793,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 39146,
      "e": 36849,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x axis and see what points line up at "
    },
    {
      "t": 39242,
      "e": 36945,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 39289,
      "e": 36992,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x axis and see what points line up at"
    },
    {
      "t": 39377,
      "e": 37080,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 39433,
      "e": 37136,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x axis and see what points line up a"
    },
    {
      "t": 39834,
      "e": 37537,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 39937,
      "e": 37640,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x axis and see what points line up "
    },
    {
      "t": 40004,
      "e": 37707,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40234,
      "e": 37937,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 40234,
      "e": 37937,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40345,
      "e": 38048,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 40345,
      "e": 38048,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40369,
      "e": 38072,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||wi"
    },
    {
      "t": 40393,
      "e": 38096,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40474,
      "e": 38177,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 40475,
      "e": 38178,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40537,
      "e": 38240,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 40537,
      "e": 38240,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40577,
      "e": 38280,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 40634,
      "e": 38337,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40690,
      "e": 38393,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 40690,
      "e": 38393,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40793,
      "e": 38496,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 40906,
      "e": 38609,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 40907,
      "e": 38610,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40978,
      "e": 38681,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 40978,
      "e": 38681,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41034,
      "e": 38737,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 41122,
      "e": 38825,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 42593,
      "e": 40296,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 42595,
      "e": 40298,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42705,
      "e": 40408,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 42794,
      "e": 40497,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 42842,
      "e": 40545,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 42842,
      "e": 40545,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42953,
      "e": 40656,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||P"
    },
    {
      "t": 42961,
      "e": 40664,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 42961,
      "e": 40664,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43057,
      "e": 40760,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||M"
    },
    {
      "t": 43153,
      "e": 40856,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 43282,
      "e": 40985,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 43283,
      "e": 40986,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43406,
      "e": 41109,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x axis and see what points line up with 12 PM."
    },
    {
      "t": 43409,
      "e": 41112,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 43482,
      "e": 41185,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 43482,
      "e": 41185,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43606,
      "e": 41309,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x axis and see what points line up with 12 PM. "
    },
    {
      "t": 43641,
      "e": 41344,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 44033,
      "e": 41736,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 44450,
      "e": 42153,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "57"
    },
    {
      "t": 44450,
      "e": 42153,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44553,
      "e": 42256,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||("
    },
    {
      "t": 44601,
      "e": 42304,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 44761,
      "e": 42464,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 44763,
      "e": 42466,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44833,
      "e": 42536,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 44833,
      "e": 42536,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44857,
      "e": 42560,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ve"
    },
    {
      "t": 44913,
      "e": 42616,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 44913,
      "e": 42616,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44986,
      "e": 42689,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 44994,
      "e": 42697,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 45105,
      "e": 42808,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 45107,
      "e": 42810,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45162,
      "e": 42865,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 45162,
      "e": 42865,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45193,
      "e": 42896,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ti"
    },
    {
      "t": 45233,
      "e": 42936,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 45313,
      "e": 43016,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 45314,
      "e": 43017,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45353,
      "e": 43056,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 45354,
      "e": 43057,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45416,
      "e": 43119,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ca"
    },
    {
      "t": 45417,
      "e": 43120,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 45417,
      "e": 43120,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45473,
      "e": 43176,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 45474,
      "e": 43177,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 45577,
      "e": 43280,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 45577,
      "e": 43280,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45633,
      "e": 43336,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 45753,
      "e": 43456,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 45754,
      "e": 43457,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45817,
      "e": 43520,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 46057,
      "e": 43760,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 46130,
      "e": 43833,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "48"
    },
    {
      "t": 46131,
      "e": 43834,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46185,
      "e": 43888,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||)"
    },
    {
      "t": 46354,
      "e": 44057,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 46950,
      "e": 44653,
      "ty": 7,
      "x": 499,
      "y": 609,
      "ta": "#strategyAnswer"
    },
    {
      "t": 46994,
      "e": 44697,
      "ty": 6,
      "x": 418,
      "y": 660,
      "ta": "#strategyButton"
    },
    {
      "t": 47005,
      "e": 44708,
      "ty": 2,
      "x": 418,
      "y": 660
    },
    {
      "t": 47005,
      "e": 44708,
      "ty": 41,
      "x": 43365,
      "y": 10149,
      "ta": "#strategyButton"
    },
    {
      "t": 47104,
      "e": 44807,
      "ty": 2,
      "x": 392,
      "y": 682
    },
    {
      "t": 47237,
      "e": 44940,
      "ty": 3,
      "x": 392,
      "y": 682,
      "ta": "#strategyButton"
    },
    {
      "t": 47238,
      "e": 44941,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at the x axis and see what points line up with 12 PM. (vertically)"
    },
    {
      "t": 47238,
      "e": 44941,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47239,
      "e": 44942,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 47254,
      "e": 44957,
      "ty": 41,
      "x": 29166,
      "y": 52554,
      "ta": "#strategyButton"
    },
    {
      "t": 47293,
      "e": 44996,
      "ty": 4,
      "x": 29166,
      "y": 52554,
      "ta": "#strategyButton"
    },
    {
      "t": 47304,
      "e": 45007,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 47305,
      "e": 45008,
      "ty": 5,
      "x": 392,
      "y": 682,
      "ta": "#strategyButton"
    },
    {
      "t": 47311,
      "e": 45014,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 47704,
      "e": 45407,
      "ty": 2,
      "x": 398,
      "y": 724
    },
    {
      "t": 47755,
      "e": 45458,
      "ty": 41,
      "x": 13430,
      "y": 39664,
      "ta": "html > body"
    },
    {
      "t": 48313,
      "e": 46016,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 48705,
      "e": 46408,
      "ty": 2,
      "x": 435,
      "y": 715
    },
    {
      "t": 48755,
      "e": 46458,
      "ty": 41,
      "x": 16977,
      "y": 38501,
      "ta": "html > body"
    },
    {
      "t": 48804,
      "e": 46507,
      "ty": 2,
      "x": 663,
      "y": 666
    },
    {
      "t": 48862,
      "e": 46565,
      "ty": 6,
      "x": 809,
      "y": 647,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 48878,
      "e": 46581,
      "ty": 7,
      "x": 814,
      "y": 644,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 48905,
      "e": 46608,
      "ty": 2,
      "x": 821,
      "y": 642
    },
    {
      "t": 49005,
      "e": 46708,
      "ty": 2,
      "x": 845,
      "y": 627
    },
    {
      "t": 49005,
      "e": 46708,
      "ty": 41,
      "x": 8002,
      "y": 60853,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 49103,
      "e": 46806,
      "ty": 2,
      "x": 878,
      "y": 578
    },
    {
      "t": 49130,
      "e": 46833,
      "ty": 6,
      "x": 880,
      "y": 574,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 49203,
      "e": 46906,
      "ty": 2,
      "x": 881,
      "y": 567
    },
    {
      "t": 49254,
      "e": 46957,
      "ty": 41,
      "x": 15788,
      "y": 37448,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 49304,
      "e": 47007,
      "ty": 2,
      "x": 881,
      "y": 566
    },
    {
      "t": 49542,
      "e": 47245,
      "ty": 3,
      "x": 881,
      "y": 566,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 49543,
      "e": 47246,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 49653,
      "e": 47356,
      "ty": 4,
      "x": 15788,
      "y": 37448,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 49653,
      "e": 47356,
      "ty": 5,
      "x": 881,
      "y": 566,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 51282,
      "e": 48985,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 51283,
      "e": 48986,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 51386,
      "e": 49089,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 51665,
      "e": 49368,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "189"
    },
    {
      "t": 51666,
      "e": 49369,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 51753,
      "e": 49456,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2-"
    },
    {
      "t": 52178,
      "e": 49881,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 52345,
      "e": 50048,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 53265,
      "e": 50968,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "48"
    },
    {
      "t": 53266,
      "e": 50969,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 53328,
      "e": 51031,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 53866,
      "e": 51569,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 53867,
      "e": 51570,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 53867,
      "e": 51570,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 53868,
      "e": 51571,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 54033,
      "e": 51736,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 54498,
      "e": 52201,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 54650,
      "e": 52353,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 54650,
      "e": 52353,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 54776,
      "e": 52479,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "T"
    },
    {
      "t": 54849,
      "e": 52552,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "T"
    },
    {
      "t": 55026,
      "e": 52729,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 55026,
      "e": 52729,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 55129,
      "e": 52832,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 55129,
      "e": 52832,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 55145,
      "e": 52848,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Tai"
    },
    {
      "t": 55209,
      "e": 52912,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Tai"
    },
    {
      "t": 55250,
      "e": 52953,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "87"
    },
    {
      "t": 55250,
      "e": 52953,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 55296,
      "e": 52999,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 55296,
      "e": 52999,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 55329,
      "e": 53032,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Taiwa"
    },
    {
      "t": 55385,
      "e": 53088,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "78"
    },
    {
      "t": 55385,
      "e": 53088,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 55417,
      "e": 53120,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||n"
    },
    {
      "t": 55433,
      "e": 53136,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 56368,
      "e": 54071,
      "ty": 7,
      "x": 899,
      "y": 582,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 56402,
      "e": 54105,
      "ty": 6,
      "x": 930,
      "y": 666,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 56403,
      "e": 54106,
      "ty": 2,
      "x": 930,
      "y": 666
    },
    {
      "t": 56418,
      "e": 54121,
      "ty": 7,
      "x": 930,
      "y": 675,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 56435,
      "e": 54138,
      "ty": 6,
      "x": 930,
      "y": 679,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 56504,
      "e": 54207,
      "ty": 2,
      "x": 928,
      "y": 691
    },
    {
      "t": 56504,
      "e": 54207,
      "ty": 41,
      "x": 16532,
      "y": 29788,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 56604,
      "e": 54307,
      "ty": 2,
      "x": 927,
      "y": 692
    },
    {
      "t": 56702,
      "e": 54405,
      "ty": 3,
      "x": 927,
      "y": 692,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 56703,
      "e": 54406,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Taiwan"
    },
    {
      "t": 56704,
      "e": 54407,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 56704,
      "e": 54407,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 56754,
      "e": 54457,
      "ty": 41,
      "x": 16017,
      "y": 31774,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 56788,
      "e": 54491,
      "ty": 4,
      "x": 16017,
      "y": 31774,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 56790,
      "e": 54493,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 56790,
      "e": 54493,
      "ty": 5,
      "x": 927,
      "y": 692,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 56790,
      "e": 54493,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 57804,
      "e": 55507,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 58604,
      "e": 56307,
      "ty": 2,
      "x": 923,
      "y": 369
    },
    {
      "t": 58703,
      "e": 56406,
      "ty": 2,
      "x": 901,
      "y": 111
    },
    {
      "t": 58754,
      "e": 56457,
      "ty": 41,
      "x": 30615,
      "y": 4764,
      "ta": "html > body"
    },
    {
      "t": 58803,
      "e": 56506,
      "ty": 2,
      "x": 897,
      "y": 94
    },
    {
      "t": 58904,
      "e": 56607,
      "ty": 2,
      "x": 883,
      "y": 181
    },
    {
      "t": 59004,
      "e": 56707,
      "ty": 2,
      "x": 868,
      "y": 238
    },
    {
      "t": 59004,
      "e": 56707,
      "ty": 41,
      "x": 38141,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 59214,
      "e": 56917,
      "ty": 3,
      "x": 868,
      "y": 238,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 59293,
      "e": 56996,
      "ty": 4,
      "x": 38141,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 59294,
      "e": 56997,
      "ty": 5,
      "x": 868,
      "y": 238,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 59296,
      "e": 56999,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 59298,
      "e": 57001,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 59504,
      "e": 57207,
      "ty": 2,
      "x": 867,
      "y": 257
    },
    {
      "t": 59504,
      "e": 57207,
      "ty": 41,
      "x": 34713,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-0-1 > label"
    },
    {
      "t": 59603,
      "e": 57306,
      "ty": 2,
      "x": 867,
      "y": 316
    },
    {
      "t": 59704,
      "e": 57407,
      "ty": 2,
      "x": 867,
      "y": 362
    },
    {
      "t": 59754,
      "e": 57457,
      "ty": 41,
      "x": 11054,
      "y": 30426,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 59804,
      "e": 57507,
      "ty": 2,
      "x": 868,
      "y": 371
    },
    {
      "t": 59904,
      "e": 57607,
      "ty": 2,
      "x": 868,
      "y": 393
    },
    {
      "t": 60004,
      "e": 57707,
      "ty": 2,
      "x": 868,
      "y": 412
    },
    {
      "t": 60004,
      "e": 57707,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 60005,
      "e": 57708,
      "ty": 41,
      "x": 54524,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 60104,
      "e": 57807,
      "ty": 2,
      "x": 866,
      "y": 418
    },
    {
      "t": 60204,
      "e": 57907,
      "ty": 2,
      "x": 862,
      "y": 426
    },
    {
      "t": 60254,
      "e": 57957,
      "ty": 41,
      "x": 9630,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 60404,
      "e": 58107,
      "ty": 2,
      "x": 862,
      "y": 422
    },
    {
      "t": 60504,
      "e": 58207,
      "ty": 2,
      "x": 858,
      "y": 408
    },
    {
      "t": 60504,
      "e": 58207,
      "ty": 41,
      "x": 42818,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 60754,
      "e": 58457,
      "ty": 41,
      "x": 42818,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 60804,
      "e": 58507,
      "ty": 2,
      "x": 859,
      "y": 422
    },
    {
      "t": 60904,
      "e": 58607,
      "ty": 2,
      "x": 861,
      "y": 435
    },
    {
      "t": 61004,
      "e": 58707,
      "ty": 2,
      "x": 861,
      "y": 438
    },
    {
      "t": 61005,
      "e": 58708,
      "ty": 41,
      "x": 31613,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 61206,
      "e": 58909,
      "ty": 3,
      "x": 861,
      "y": 438,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 61207,
      "e": 58910,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 61308,
      "e": 59011,
      "ty": 4,
      "x": 31613,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 61309,
      "e": 59012,
      "ty": 5,
      "x": 861,
      "y": 438,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 61309,
      "e": 59012,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 61309,
      "e": 59012,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf",
      "v": "Second"
    },
    {
      "t": 61604,
      "e": 59307,
      "ty": 2,
      "x": 861,
      "y": 442
    },
    {
      "t": 61703,
      "e": 59406,
      "ty": 2,
      "x": 861,
      "y": 490
    },
    {
      "t": 61754,
      "e": 59457,
      "ty": 41,
      "x": 9392,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-1-4"
    },
    {
      "t": 61804,
      "e": 59507,
      "ty": 2,
      "x": 862,
      "y": 538
    },
    {
      "t": 61904,
      "e": 59607,
      "ty": 2,
      "x": 866,
      "y": 560
    },
    {
      "t": 62004,
      "e": 59707,
      "ty": 2,
      "x": 866,
      "y": 596
    },
    {
      "t": 62004,
      "e": 59707,
      "ty": 41,
      "x": 10579,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-1-6"
    },
    {
      "t": 62104,
      "e": 59807,
      "ty": 2,
      "x": 866,
      "y": 645
    },
    {
      "t": 62204,
      "e": 59907,
      "ty": 2,
      "x": 870,
      "y": 666
    },
    {
      "t": 62255,
      "e": 59958,
      "ty": 41,
      "x": 13043,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 62304,
      "e": 60007,
      "ty": 2,
      "x": 870,
      "y": 669
    },
    {
      "t": 62404,
      "e": 60107,
      "ty": 2,
      "x": 871,
      "y": 678
    },
    {
      "t": 62504,
      "e": 60207,
      "ty": 2,
      "x": 873,
      "y": 687
    },
    {
      "t": 62504,
      "e": 60207,
      "ty": 41,
      "x": 12240,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 62704,
      "e": 60407,
      "ty": 2,
      "x": 875,
      "y": 686
    },
    {
      "t": 62754,
      "e": 60457,
      "ty": 41,
      "x": 15191,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 62804,
      "e": 60507,
      "ty": 2,
      "x": 879,
      "y": 675
    },
    {
      "t": 63004,
      "e": 60707,
      "ty": 41,
      "x": 15459,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 63191,
      "e": 60894,
      "ty": 3,
      "x": 879,
      "y": 675,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 63192,
      "e": 60895,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 63253,
      "e": 60956,
      "ty": 4,
      "x": 15459,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 63253,
      "e": 60956,
      "ty": 5,
      "x": 879,
      "y": 675,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 63253,
      "e": 60956,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 63253,
      "e": 60956,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf",
      "v": "Math or Computer Sciences"
    },
    {
      "t": 63504,
      "e": 61207,
      "ty": 2,
      "x": 878,
      "y": 687
    },
    {
      "t": 63504,
      "e": 61207,
      "ty": 41,
      "x": 13427,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 63604,
      "e": 61307,
      "ty": 2,
      "x": 876,
      "y": 768
    },
    {
      "t": 63704,
      "e": 61407,
      "ty": 2,
      "x": 877,
      "y": 843
    },
    {
      "t": 63754,
      "e": 61457,
      "ty": 41,
      "x": 13902,
      "y": 21064,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 63804,
      "e": 61507,
      "ty": 2,
      "x": 885,
      "y": 907
    },
    {
      "t": 63904,
      "e": 61607,
      "ty": 2,
      "x": 886,
      "y": 918
    },
    {
      "t": 64004,
      "e": 61707,
      "ty": 2,
      "x": 886,
      "y": 919
    },
    {
      "t": 64005,
      "e": 61708,
      "ty": 41,
      "x": 15325,
      "y": 22181,
      "ta": "#jspsych-survey-multi-choice-3"
    },
    {
      "t": 64106,
      "e": 61710,
      "ty": 2,
      "x": 885,
      "y": 923
    },
    {
      "t": 64204,
      "e": 61808,
      "ty": 2,
      "x": 877,
      "y": 928
    },
    {
      "t": 64254,
      "e": 61858,
      "ty": 41,
      "x": 58520,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 64304,
      "e": 61908,
      "ty": 2,
      "x": 867,
      "y": 943
    },
    {
      "t": 64404,
      "e": 62008,
      "ty": 2,
      "x": 863,
      "y": 946
    },
    {
      "t": 64504,
      "e": 62108,
      "ty": 2,
      "x": 865,
      "y": 950
    },
    {
      "t": 64505,
      "e": 62109,
      "ty": 41,
      "x": 10342,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 64604,
      "e": 62208,
      "ty": 2,
      "x": 865,
      "y": 951
    },
    {
      "t": 64704,
      "e": 62308,
      "ty": 2,
      "x": 865,
      "y": 954
    },
    {
      "t": 64755,
      "e": 62359,
      "ty": 41,
      "x": 35251,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 65004,
      "e": 62608,
      "ty": 2,
      "x": 865,
      "y": 956
    },
    {
      "t": 65005,
      "e": 62609,
      "ty": 41,
      "x": 35251,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 65104,
      "e": 62708,
      "ty": 2,
      "x": 865,
      "y": 966
    },
    {
      "t": 65198,
      "e": 62802,
      "ty": 3,
      "x": 865,
      "y": 966,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 65199,
      "e": 62803,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 65254,
      "e": 62858,
      "ty": 41,
      "x": 35251,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 65301,
      "e": 62905,
      "ty": 4,
      "x": 35251,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 65301,
      "e": 62905,
      "ty": 5,
      "x": 865,
      "y": 966,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 65302,
      "e": 62906,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 65302,
      "e": 62906,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 65505,
      "e": 63109,
      "ty": 2,
      "x": 865,
      "y": 987
    },
    {
      "t": 65505,
      "e": 63109,
      "ty": 41,
      "x": 43260,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-3-2 > label"
    },
    {
      "t": 65604,
      "e": 63208,
      "ty": 2,
      "x": 864,
      "y": 1004
    },
    {
      "t": 65630,
      "e": 63234,
      "ty": 6,
      "x": 864,
      "y": 1005,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 65704,
      "e": 63308,
      "ty": 2,
      "x": 864,
      "y": 1007
    },
    {
      "t": 65754,
      "e": 63358,
      "ty": 41,
      "x": 17821,
      "y": 5957,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 65804,
      "e": 63408,
      "ty": 2,
      "x": 864,
      "y": 1008
    },
    {
      "t": 65934,
      "e": 63538,
      "ty": 3,
      "x": 864,
      "y": 1008,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 65936,
      "e": 63540,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 65936,
      "e": 63540,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 66020,
      "e": 63624,
      "ty": 4,
      "x": 17821,
      "y": 5957,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 66021,
      "e": 63625,
      "ty": 5,
      "x": 864,
      "y": 1008,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 66023,
      "e": 63627,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 66024,
      "e": 63628,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 66026,
      "e": 63630,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 66404,
      "e": 64008,
      "ty": 2,
      "x": 865,
      "y": 1004
    },
    {
      "t": 66504,
      "e": 64108,
      "ty": 2,
      "x": 865,
      "y": 995
    },
    {
      "t": 66505,
      "e": 64109,
      "ty": 41,
      "x": 29513,
      "y": 54677,
      "ta": "html > body"
    },
    {
      "t": 66605,
      "e": 64209,
      "ty": 2,
      "x": 864,
      "y": 995
    },
    {
      "t": 66754,
      "e": 64358,
      "ty": 41,
      "x": 29478,
      "y": 54566,
      "ta": "html > body"
    },
    {
      "t": 66805,
      "e": 64409,
      "ty": 2,
      "x": 864,
      "y": 993
    },
    {
      "t": 67365,
      "e": 64969,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 68104,
      "e": 65708,
      "ty": 2,
      "x": 892,
      "y": 1016
    },
    {
      "t": 68205,
      "e": 65809,
      "ty": 2,
      "x": 916,
      "y": 1048
    },
    {
      "t": 68255,
      "e": 65859,
      "ty": 41,
      "x": 31266,
      "y": 65071,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 68305,
      "e": 65909,
      "ty": 2,
      "x": 931,
      "y": 1070
    },
    {
      "t": 68346,
      "e": 65950,
      "ty": 6,
      "x": 934,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 68404,
      "e": 66008,
      "ty": 2,
      "x": 939,
      "y": 1080
    },
    {
      "t": 68504,
      "e": 66108,
      "ty": 2,
      "x": 944,
      "y": 1090
    },
    {
      "t": 68504,
      "e": 66108,
      "ty": 41,
      "x": 18841,
      "y": 33369,
      "ta": "#start"
    },
    {
      "t": 70004,
      "e": 67608,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 71006,
      "e": 68610,
      "ty": 3,
      "x": 944,
      "y": 1090,
      "ta": "#start"
    },
    {
      "t": 71007,
      "e": 68611,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 72878,
      "e": 70482,
      "ty": 4,
      "x": 18841,
      "y": 33369,
      "ta": "#start"
    },
    {
      "t": 72879,
      "e": 70483,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 72880,
      "e": 70484,
      "ty": 5,
      "x": 944,
      "y": 1090,
      "ta": "#start"
    },
    {
      "t": 72882,
      "e": 70486,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 73914,
      "e": 71518,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 75117,
      "e": 72721,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 78795, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 78799, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"QGUGU\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 4085, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 84217, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"QGUGU\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 10858, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"WHISKEY\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"115\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 96083, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"QGUGU\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 27955, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 125126, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"QGUGU\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 14079, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 140208, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"QGUGU\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 25239, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 166914, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"QGUGU\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -5-A -A -9-12 PM-11 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:984,y:999,t:1527872953497};\\\", \\\"{x:982,y:996,t:1527872953504};\\\", \\\"{x:969,y:989,t:1527872953520};\\\", \\\"{x:962,y:977,t:1527872953536};\\\", \\\"{x:955,y:968,t:1527872953552};\\\", \\\"{x:950,y:960,t:1527872953569};\\\", \\\"{x:946,y:953,t:1527872953586};\\\", \\\"{x:941,y:943,t:1527872953602};\\\", \\\"{x:938,y:935,t:1527872953619};\\\", \\\"{x:936,y:928,t:1527872953637};\\\", \\\"{x:936,y:920,t:1527872953652};\\\", \\\"{x:935,y:911,t:1527872953669};\\\", \\\"{x:933,y:906,t:1527872953686};\\\", \\\"{x:933,y:900,t:1527872953702};\\\", \\\"{x:933,y:896,t:1527872953719};\\\", \\\"{x:934,y:885,t:1527872953735};\\\", \\\"{x:935,y:877,t:1527872953752};\\\", \\\"{x:938,y:869,t:1527872953769};\\\", \\\"{x:941,y:862,t:1527872953786};\\\", \\\"{x:943,y:858,t:1527872953803};\\\", \\\"{x:945,y:853,t:1527872953820};\\\", \\\"{x:947,y:849,t:1527872953836};\\\", \\\"{x:950,y:844,t:1527872953853};\\\", \\\"{x:953,y:838,t:1527872953870};\\\", \\\"{x:956,y:834,t:1527872953887};\\\", \\\"{x:959,y:830,t:1527872953902};\\\", \\\"{x:964,y:825,t:1527872953919};\\\", \\\"{x:967,y:822,t:1527872953935};\\\", \\\"{x:968,y:821,t:1527872953954};\\\", \\\"{x:969,y:820,t:1527872953969};\\\", \\\"{x:969,y:819,t:1527872953986};\\\", \\\"{x:970,y:818,t:1527872954003};\\\", \\\"{x:971,y:817,t:1527872954032};\\\", \\\"{x:972,y:817,t:1527872954344};\\\", \\\"{x:974,y:817,t:1527872954353};\\\", \\\"{x:975,y:818,t:1527872954370};\\\", \\\"{x:975,y:819,t:1527872954387};\\\", \\\"{x:977,y:820,t:1527872956040};\\\", \\\"{x:981,y:812,t:1527872956055};\\\", \\\"{x:997,y:770,t:1527872956072};\\\", \\\"{x:1005,y:746,t:1527872956087};\\\", \\\"{x:1012,y:722,t:1527872956105};\\\", \\\"{x:1020,y:700,t:1527872956122};\\\", \\\"{x:1028,y:678,t:1527872956138};\\\", \\\"{x:1031,y:664,t:1527872956154};\\\", \\\"{x:1033,y:655,t:1527872956172};\\\", \\\"{x:1033,y:652,t:1527872956188};\\\", \\\"{x:1033,y:648,t:1527872956204};\\\", \\\"{x:1033,y:645,t:1527872956221};\\\", \\\"{x:1030,y:639,t:1527872956237};\\\", \\\"{x:1028,y:634,t:1527872956254};\\\", \\\"{x:1026,y:629,t:1527872956271};\\\", \\\"{x:1026,y:628,t:1527872956295};\\\", \\\"{x:1026,y:630,t:1527872957360};\\\", \\\"{x:1028,y:632,t:1527872957372};\\\", \\\"{x:1039,y:638,t:1527872957389};\\\", \\\"{x:1051,y:648,t:1527872957405};\\\", \\\"{x:1062,y:658,t:1527872957423};\\\", \\\"{x:1071,y:669,t:1527872957439};\\\", \\\"{x:1085,y:686,t:1527872957456};\\\", \\\"{x:1096,y:703,t:1527872957472};\\\", \\\"{x:1109,y:720,t:1527872957488};\\\", \\\"{x:1126,y:742,t:1527872957506};\\\", \\\"{x:1139,y:760,t:1527872957522};\\\", \\\"{x:1152,y:778,t:1527872957539};\\\", \\\"{x:1166,y:797,t:1527872957555};\\\", \\\"{x:1187,y:810,t:1527872957573};\\\", \\\"{x:1204,y:822,t:1527872957588};\\\", \\\"{x:1214,y:831,t:1527872957608};\\\", \\\"{x:1215,y:833,t:1527872957622};\\\", \\\"{x:1215,y:834,t:1527872957638};\\\", \\\"{x:1216,y:839,t:1527872957655};\\\", \\\"{x:1216,y:844,t:1527872957672};\\\", \\\"{x:1216,y:848,t:1527872957688};\\\", \\\"{x:1216,y:853,t:1527872957705};\\\", \\\"{x:1210,y:862,t:1527872957722};\\\", \\\"{x:1201,y:871,t:1527872957738};\\\", \\\"{x:1191,y:880,t:1527872957755};\\\", \\\"{x:1176,y:888,t:1527872957772};\\\", \\\"{x:1160,y:897,t:1527872957789};\\\", \\\"{x:1143,y:904,t:1527872957805};\\\", \\\"{x:1132,y:911,t:1527872957823};\\\", \\\"{x:1121,y:916,t:1527872957839};\\\", \\\"{x:1117,y:917,t:1527872957855};\\\", \\\"{x:1115,y:917,t:1527872957872};\\\", \\\"{x:1114,y:917,t:1527872957920};\\\", \\\"{x:1112,y:917,t:1527872957928};\\\", \\\"{x:1111,y:917,t:1527872957940};\\\", \\\"{x:1106,y:917,t:1527872957956};\\\", \\\"{x:1099,y:917,t:1527872957973};\\\", \\\"{x:1094,y:918,t:1527872957990};\\\", \\\"{x:1093,y:918,t:1527872958006};\\\", \\\"{x:1093,y:920,t:1527872959497};\\\", \\\"{x:1093,y:925,t:1527872959507};\\\", \\\"{x:1099,y:939,t:1527872959524};\\\", \\\"{x:1099,y:944,t:1527872959541};\\\", \\\"{x:1099,y:949,t:1527872959556};\\\", \\\"{x:1099,y:951,t:1527872959574};\\\", \\\"{x:1099,y:954,t:1527872959591};\\\", \\\"{x:1099,y:955,t:1527872959607};\\\", \\\"{x:1099,y:957,t:1527872959624};\\\", \\\"{x:1099,y:958,t:1527872959640};\\\", \\\"{x:1099,y:959,t:1527872959657};\\\", \\\"{x:1100,y:960,t:1527872959942};\\\", \\\"{x:1107,y:961,t:1527872959957};\\\", \\\"{x:1116,y:964,t:1527872959973};\\\", \\\"{x:1119,y:965,t:1527872959990};\\\", \\\"{x:1122,y:966,t:1527872960007};\\\", \\\"{x:1123,y:966,t:1527872960024};\\\", \\\"{x:1123,y:967,t:1527872960271};\\\", \\\"{x:1121,y:967,t:1527872960279};\\\", \\\"{x:1119,y:967,t:1527872960290};\\\", \\\"{x:1116,y:967,t:1527872960307};\\\", \\\"{x:1115,y:967,t:1527872960325};\\\", \\\"{x:1112,y:967,t:1527872960340};\\\", \\\"{x:1109,y:967,t:1527872960357};\\\", \\\"{x:1107,y:967,t:1527872960374};\\\", \\\"{x:1105,y:967,t:1527872960390};\\\", \\\"{x:1102,y:967,t:1527872960408};\\\", \\\"{x:1099,y:967,t:1527872960426};\\\", \\\"{x:1096,y:967,t:1527872960441};\\\", \\\"{x:1092,y:967,t:1527872960457};\\\", \\\"{x:1088,y:967,t:1527872960474};\\\", \\\"{x:1083,y:967,t:1527872960490};\\\", \\\"{x:1081,y:966,t:1527872960508};\\\", \\\"{x:1077,y:966,t:1527872960524};\\\", \\\"{x:1075,y:966,t:1527872960540};\\\", \\\"{x:1074,y:966,t:1527872960558};\\\", \\\"{x:1073,y:966,t:1527872960575};\\\", \\\"{x:1072,y:965,t:1527872960785};\\\", \\\"{x:1072,y:963,t:1527872960791};\\\", \\\"{x:1072,y:960,t:1527872960807};\\\", \\\"{x:1072,y:957,t:1527872960824};\\\", \\\"{x:1072,y:955,t:1527872960841};\\\", \\\"{x:1073,y:954,t:1527872960857};\\\", \\\"{x:1073,y:952,t:1527872960874};\\\", \\\"{x:1075,y:951,t:1527872960911};\\\", \\\"{x:1075,y:949,t:1527872961000};\\\", \\\"{x:1076,y:948,t:1527872961025};\\\", \\\"{x:1076,y:947,t:1527872961042};\\\", \\\"{x:1078,y:945,t:1527872961057};\\\", \\\"{x:1079,y:944,t:1527872961075};\\\", \\\"{x:1082,y:942,t:1527872961092};\\\", \\\"{x:1086,y:941,t:1527872961108};\\\", \\\"{x:1090,y:940,t:1527872961124};\\\", \\\"{x:1100,y:938,t:1527872961141};\\\", \\\"{x:1110,y:934,t:1527872961158};\\\", \\\"{x:1129,y:929,t:1527872961175};\\\", \\\"{x:1154,y:924,t:1527872961192};\\\", \\\"{x:1163,y:922,t:1527872961209};\\\", \\\"{x:1170,y:922,t:1527872961225};\\\", \\\"{x:1176,y:922,t:1527872961241};\\\", \\\"{x:1179,y:922,t:1527872961258};\\\", \\\"{x:1181,y:922,t:1527872961274};\\\", \\\"{x:1183,y:922,t:1527872961292};\\\", \\\"{x:1185,y:922,t:1527872961312};\\\", \\\"{x:1187,y:923,t:1527872961325};\\\", \\\"{x:1191,y:926,t:1527872961342};\\\", \\\"{x:1195,y:929,t:1527872961359};\\\", \\\"{x:1201,y:933,t:1527872961374};\\\", \\\"{x:1205,y:938,t:1527872961392};\\\", \\\"{x:1210,y:941,t:1527872961408};\\\", \\\"{x:1216,y:946,t:1527872961425};\\\", \\\"{x:1219,y:948,t:1527872961441};\\\", \\\"{x:1221,y:948,t:1527872961462};\\\", \\\"{x:1221,y:949,t:1527872961474};\\\", \\\"{x:1225,y:951,t:1527872961491};\\\", \\\"{x:1227,y:953,t:1527872961508};\\\", \\\"{x:1228,y:953,t:1527872961524};\\\", \\\"{x:1229,y:954,t:1527872961543};\\\", \\\"{x:1228,y:955,t:1527872961936};\\\", \\\"{x:1223,y:955,t:1527872961943};\\\", \\\"{x:1217,y:955,t:1527872961958};\\\", \\\"{x:1191,y:955,t:1527872961976};\\\", \\\"{x:1173,y:956,t:1527872961992};\\\", \\\"{x:1161,y:957,t:1527872962010};\\\", \\\"{x:1147,y:958,t:1527872962026};\\\", \\\"{x:1137,y:960,t:1527872962042};\\\", \\\"{x:1129,y:960,t:1527872962059};\\\", \\\"{x:1126,y:960,t:1527872962223};\\\", \\\"{x:1123,y:960,t:1527872962230};\\\", \\\"{x:1121,y:959,t:1527872962242};\\\", \\\"{x:1114,y:954,t:1527872962258};\\\", \\\"{x:1106,y:950,t:1527872962275};\\\", \\\"{x:1099,y:945,t:1527872962292};\\\", \\\"{x:1091,y:941,t:1527872962308};\\\", \\\"{x:1079,y:936,t:1527872962325};\\\", \\\"{x:1072,y:932,t:1527872962342};\\\", \\\"{x:1066,y:929,t:1527872962358};\\\", \\\"{x:1062,y:925,t:1527872962375};\\\", \\\"{x:1060,y:922,t:1527872962392};\\\", \\\"{x:1060,y:920,t:1527872962408};\\\", \\\"{x:1058,y:919,t:1527872962425};\\\", \\\"{x:1058,y:917,t:1527872962442};\\\", \\\"{x:1058,y:916,t:1527872962459};\\\", \\\"{x:1066,y:916,t:1527872962520};\\\", \\\"{x:1081,y:924,t:1527872962527};\\\", \\\"{x:1093,y:928,t:1527872962543};\\\", \\\"{x:1118,y:937,t:1527872962558};\\\", \\\"{x:1126,y:939,t:1527872962575};\\\", \\\"{x:1131,y:940,t:1527872962593};\\\", \\\"{x:1134,y:942,t:1527872962609};\\\", \\\"{x:1135,y:939,t:1527872962800};\\\", \\\"{x:1135,y:935,t:1527872962810};\\\", \\\"{x:1135,y:932,t:1527872962826};\\\", \\\"{x:1135,y:928,t:1527872962843};\\\", \\\"{x:1135,y:925,t:1527872962860};\\\", \\\"{x:1135,y:917,t:1527872962876};\\\", \\\"{x:1135,y:909,t:1527872962893};\\\", \\\"{x:1135,y:905,t:1527872962910};\\\", \\\"{x:1135,y:902,t:1527872962926};\\\", \\\"{x:1135,y:900,t:1527872962943};\\\", \\\"{x:1135,y:899,t:1527872962960};\\\", \\\"{x:1135,y:898,t:1527872962976};\\\", \\\"{x:1131,y:899,t:1527872963105};\\\", \\\"{x:1123,y:903,t:1527872963112};\\\", \\\"{x:1117,y:907,t:1527872963127};\\\", \\\"{x:1098,y:916,t:1527872963143};\\\", \\\"{x:1087,y:925,t:1527872963160};\\\", \\\"{x:1080,y:929,t:1527872963177};\\\", \\\"{x:1077,y:929,t:1527872963193};\\\", \\\"{x:1078,y:929,t:1527872963328};\\\", \\\"{x:1079,y:929,t:1527872963343};\\\", \\\"{x:1084,y:928,t:1527872963360};\\\", \\\"{x:1085,y:927,t:1527872963377};\\\", \\\"{x:1086,y:927,t:1527872963393};\\\", \\\"{x:1087,y:926,t:1527872963410};\\\", \\\"{x:1089,y:925,t:1527872963427};\\\", \\\"{x:1091,y:924,t:1527872963442};\\\", \\\"{x:1096,y:921,t:1527872963459};\\\", \\\"{x:1102,y:918,t:1527872963476};\\\", \\\"{x:1110,y:913,t:1527872963492};\\\", \\\"{x:1114,y:911,t:1527872963509};\\\", \\\"{x:1121,y:907,t:1527872963526};\\\", \\\"{x:1134,y:897,t:1527872963542};\\\", \\\"{x:1148,y:886,t:1527872963559};\\\", \\\"{x:1165,y:875,t:1527872963576};\\\", \\\"{x:1179,y:865,t:1527872963593};\\\", \\\"{x:1189,y:859,t:1527872963610};\\\", \\\"{x:1192,y:856,t:1527872963627};\\\", \\\"{x:1195,y:855,t:1527872963644};\\\", \\\"{x:1195,y:854,t:1527872963660};\\\", \\\"{x:1190,y:850,t:1527872964161};\\\", \\\"{x:1173,y:844,t:1527872964177};\\\", \\\"{x:1145,y:832,t:1527872964194};\\\", \\\"{x:1085,y:806,t:1527872964212};\\\", \\\"{x:1002,y:772,t:1527872964226};\\\", \\\"{x:915,y:739,t:1527872964244};\\\", \\\"{x:824,y:701,t:1527872964261};\\\", \\\"{x:732,y:672,t:1527872964276};\\\", \\\"{x:627,y:641,t:1527872964294};\\\", \\\"{x:521,y:611,t:1527872964311};\\\", \\\"{x:413,y:580,t:1527872964327};\\\", \\\"{x:272,y:539,t:1527872964343};\\\", \\\"{x:191,y:515,t:1527872964361};\\\", \\\"{x:132,y:496,t:1527872964377};\\\", \\\"{x:100,y:485,t:1527872964395};\\\", \\\"{x:83,y:477,t:1527872964411};\\\", \\\"{x:79,y:475,t:1527872964427};\\\", \\\"{x:79,y:474,t:1527872964487};\\\", \\\"{x:82,y:473,t:1527872964503};\\\", \\\"{x:83,y:473,t:1527872964511};\\\", \\\"{x:86,y:471,t:1527872964528};\\\", \\\"{x:88,y:471,t:1527872964544};\\\", \\\"{x:90,y:471,t:1527872964562};\\\", \\\"{x:91,y:471,t:1527872964578};\\\", \\\"{x:92,y:471,t:1527872964594};\\\", \\\"{x:95,y:471,t:1527872964612};\\\", \\\"{x:102,y:471,t:1527872964627};\\\", \\\"{x:109,y:472,t:1527872964644};\\\", \\\"{x:127,y:475,t:1527872964661};\\\", \\\"{x:152,y:479,t:1527872964677};\\\", \\\"{x:190,y:479,t:1527872964694};\\\", \\\"{x:249,y:479,t:1527872964711};\\\", \\\"{x:292,y:480,t:1527872964728};\\\", \\\"{x:325,y:481,t:1527872964744};\\\", \\\"{x:349,y:482,t:1527872964761};\\\", \\\"{x:378,y:483,t:1527872964778};\\\", \\\"{x:404,y:488,t:1527872964794};\\\", \\\"{x:426,y:489,t:1527872964811};\\\", \\\"{x:441,y:490,t:1527872964827};\\\", \\\"{x:448,y:490,t:1527872964844};\\\", \\\"{x:454,y:492,t:1527872964861};\\\", \\\"{x:458,y:492,t:1527872964877};\\\", \\\"{x:462,y:492,t:1527872964894};\\\", \\\"{x:465,y:493,t:1527872964911};\\\", \\\"{x:467,y:493,t:1527872964928};\\\", \\\"{x:470,y:494,t:1527872964944};\\\", \\\"{x:479,y:496,t:1527872964961};\\\", \\\"{x:491,y:497,t:1527872964978};\\\", \\\"{x:504,y:499,t:1527872964994};\\\", \\\"{x:518,y:502,t:1527872965012};\\\", \\\"{x:536,y:504,t:1527872965028};\\\", \\\"{x:552,y:506,t:1527872965047};\\\", \\\"{x:565,y:508,t:1527872965061};\\\", \\\"{x:576,y:509,t:1527872965079};\\\", \\\"{x:596,y:512,t:1527872965095};\\\", \\\"{x:603,y:513,t:1527872965111};\\\", \\\"{x:610,y:514,t:1527872965129};\\\", \\\"{x:616,y:515,t:1527872965145};\\\", \\\"{x:619,y:515,t:1527872965161};\\\", \\\"{x:622,y:515,t:1527872965179};\\\", \\\"{x:623,y:515,t:1527872965196};\\\", \\\"{x:627,y:516,t:1527872965344};\\\", \\\"{x:633,y:516,t:1527872965351};\\\", \\\"{x:638,y:517,t:1527872965362};\\\", \\\"{x:652,y:519,t:1527872965380};\\\", \\\"{x:673,y:522,t:1527872965395};\\\", \\\"{x:713,y:532,t:1527872965412};\\\", \\\"{x:765,y:546,t:1527872965429};\\\", \\\"{x:833,y:567,t:1527872965445};\\\", \\\"{x:897,y:587,t:1527872965464};\\\", \\\"{x:963,y:606,t:1527872965478};\\\", \\\"{x:1059,y:637,t:1527872965495};\\\", \\\"{x:1113,y:666,t:1527872965511};\\\", \\\"{x:1152,y:702,t:1527872965528};\\\", \\\"{x:1185,y:745,t:1527872965545};\\\", \\\"{x:1218,y:793,t:1527872965561};\\\", \\\"{x:1251,y:841,t:1527872965578};\\\", \\\"{x:1278,y:880,t:1527872965595};\\\", \\\"{x:1295,y:901,t:1527872965612};\\\", \\\"{x:1304,y:913,t:1527872965629};\\\", \\\"{x:1309,y:923,t:1527872965646};\\\", \\\"{x:1314,y:933,t:1527872965661};\\\", \\\"{x:1315,y:935,t:1527872965678};\\\", \\\"{x:1315,y:937,t:1527872965695};\\\", \\\"{x:1315,y:939,t:1527872965712};\\\", \\\"{x:1317,y:943,t:1527872965728};\\\", \\\"{x:1317,y:945,t:1527872965752};\\\", \\\"{x:1317,y:946,t:1527872965784};\\\", \\\"{x:1317,y:947,t:1527872965796};\\\", \\\"{x:1314,y:950,t:1527872965812};\\\", \\\"{x:1313,y:954,t:1527872965828};\\\", \\\"{x:1313,y:955,t:1527872965846};\\\", \\\"{x:1312,y:957,t:1527872965861};\\\", \\\"{x:1311,y:957,t:1527872965879};\\\", \\\"{x:1309,y:959,t:1527872965895};\\\", \\\"{x:1308,y:960,t:1527872965912};\\\", \\\"{x:1307,y:960,t:1527872965929};\\\", \\\"{x:1307,y:961,t:1527872965952};\\\", \\\"{x:1306,y:961,t:1527872965992};\\\", \\\"{x:1305,y:961,t:1527872966040};\\\", \\\"{x:1304,y:961,t:1527872966048};\\\", \\\"{x:1302,y:961,t:1527872966288};\\\", \\\"{x:1301,y:961,t:1527872966304};\\\", \\\"{x:1299,y:961,t:1527872966319};\\\", \\\"{x:1298,y:961,t:1527872966329};\\\", \\\"{x:1296,y:959,t:1527872966346};\\\", \\\"{x:1294,y:957,t:1527872966362};\\\", \\\"{x:1294,y:953,t:1527872966379};\\\", \\\"{x:1292,y:948,t:1527872966396};\\\", \\\"{x:1291,y:943,t:1527872966412};\\\", \\\"{x:1291,y:938,t:1527872966429};\\\", \\\"{x:1290,y:932,t:1527872966445};\\\", \\\"{x:1287,y:919,t:1527872966461};\\\", \\\"{x:1285,y:907,t:1527872966478};\\\", \\\"{x:1280,y:891,t:1527872966495};\\\", \\\"{x:1278,y:886,t:1527872966511};\\\", \\\"{x:1278,y:881,t:1527872966529};\\\", \\\"{x:1278,y:875,t:1527872966545};\\\", \\\"{x:1278,y:872,t:1527872966561};\\\", \\\"{x:1276,y:867,t:1527872966578};\\\", \\\"{x:1275,y:863,t:1527872966596};\\\", \\\"{x:1274,y:861,t:1527872966611};\\\", \\\"{x:1274,y:859,t:1527872966629};\\\", \\\"{x:1274,y:858,t:1527872966645};\\\", \\\"{x:1274,y:857,t:1527872966662};\\\", \\\"{x:1274,y:856,t:1527872966678};\\\", \\\"{x:1275,y:854,t:1527872966696};\\\", \\\"{x:1278,y:847,t:1527872966712};\\\", \\\"{x:1279,y:843,t:1527872966730};\\\", \\\"{x:1281,y:841,t:1527872966745};\\\", \\\"{x:1282,y:838,t:1527872966762};\\\", \\\"{x:1282,y:836,t:1527872966960};\\\", \\\"{x:1282,y:835,t:1527872966969};\\\", \\\"{x:1282,y:832,t:1527872966981};\\\", \\\"{x:1282,y:827,t:1527872966994};\\\", \\\"{x:1282,y:825,t:1527872967012};\\\", \\\"{x:1281,y:822,t:1527872967028};\\\", \\\"{x:1280,y:819,t:1527872967044};\\\", \\\"{x:1280,y:818,t:1527872967061};\\\", \\\"{x:1280,y:817,t:1527872967200};\\\", \\\"{x:1281,y:819,t:1527872967231};\\\", \\\"{x:1281,y:820,t:1527872967245};\\\", \\\"{x:1281,y:821,t:1527872967262};\\\", \\\"{x:1281,y:822,t:1527872967279};\\\", \\\"{x:1281,y:821,t:1527872967391};\\\", \\\"{x:1281,y:820,t:1527872967398};\\\", \\\"{x:1281,y:818,t:1527872967411};\\\", \\\"{x:1281,y:815,t:1527872967429};\\\", \\\"{x:1281,y:812,t:1527872967444};\\\", \\\"{x:1281,y:809,t:1527872967462};\\\", \\\"{x:1281,y:806,t:1527872967479};\\\", \\\"{x:1280,y:802,t:1527872967495};\\\", \\\"{x:1277,y:791,t:1527872967511};\\\", \\\"{x:1277,y:788,t:1527872967528};\\\", \\\"{x:1277,y:781,t:1527872967545};\\\", \\\"{x:1277,y:774,t:1527872967562};\\\", \\\"{x:1276,y:769,t:1527872967579};\\\", \\\"{x:1275,y:764,t:1527872967595};\\\", \\\"{x:1274,y:758,t:1527872967611};\\\", \\\"{x:1273,y:753,t:1527872967629};\\\", \\\"{x:1273,y:748,t:1527872967645};\\\", \\\"{x:1272,y:745,t:1527872967662};\\\", \\\"{x:1272,y:742,t:1527872967678};\\\", \\\"{x:1271,y:739,t:1527872967694};\\\", \\\"{x:1270,y:734,t:1527872967711};\\\", \\\"{x:1269,y:730,t:1527872967728};\\\", \\\"{x:1268,y:726,t:1527872967744};\\\", \\\"{x:1268,y:718,t:1527872967761};\\\", \\\"{x:1266,y:712,t:1527872967779};\\\", \\\"{x:1266,y:706,t:1527872967794};\\\", \\\"{x:1265,y:701,t:1527872967812};\\\", \\\"{x:1265,y:695,t:1527872967829};\\\", \\\"{x:1265,y:692,t:1527872967845};\\\", \\\"{x:1265,y:688,t:1527872967861};\\\", \\\"{x:1265,y:684,t:1527872967878};\\\", \\\"{x:1265,y:679,t:1527872967894};\\\", \\\"{x:1265,y:667,t:1527872967911};\\\", \\\"{x:1267,y:662,t:1527872967927};\\\", \\\"{x:1269,y:654,t:1527872967945};\\\", \\\"{x:1271,y:648,t:1527872967962};\\\", \\\"{x:1271,y:643,t:1527872967978};\\\", \\\"{x:1274,y:636,t:1527872967995};\\\", \\\"{x:1275,y:632,t:1527872968012};\\\", \\\"{x:1278,y:627,t:1527872968028};\\\", \\\"{x:1278,y:623,t:1527872968044};\\\", \\\"{x:1279,y:620,t:1527872968062};\\\", \\\"{x:1279,y:617,t:1527872968078};\\\", \\\"{x:1279,y:615,t:1527872968095};\\\", \\\"{x:1280,y:614,t:1527872968112};\\\", \\\"{x:1280,y:613,t:1527872968176};\\\", \\\"{x:1280,y:612,t:1527872968183};\\\", \\\"{x:1280,y:610,t:1527872968199};\\\", \\\"{x:1280,y:609,t:1527872968212};\\\", \\\"{x:1280,y:607,t:1527872968228};\\\", \\\"{x:1280,y:606,t:1527872968245};\\\", \\\"{x:1280,y:602,t:1527872968262};\\\", \\\"{x:1278,y:599,t:1527872968279};\\\", \\\"{x:1278,y:595,t:1527872968296};\\\", \\\"{x:1278,y:591,t:1527872968312};\\\", \\\"{x:1278,y:590,t:1527872968328};\\\", \\\"{x:1277,y:589,t:1527872968351};\\\", \\\"{x:1277,y:588,t:1527872970312};\\\", \\\"{x:1277,y:585,t:1527872970327};\\\", \\\"{x:1277,y:584,t:1527872970345};\\\", \\\"{x:1277,y:582,t:1527872970361};\\\", \\\"{x:1277,y:581,t:1527872970392};\\\", \\\"{x:1277,y:579,t:1527872970407};\\\", \\\"{x:1277,y:578,t:1527872970426};\\\", \\\"{x:1277,y:577,t:1527872970455};\\\", \\\"{x:1277,y:576,t:1527872970463};\\\", \\\"{x:1277,y:575,t:1527872970478};\\\", \\\"{x:1277,y:574,t:1527872970528};\\\", \\\"{x:1277,y:573,t:1527872970552};\\\", \\\"{x:1277,y:572,t:1527872970576};\\\", \\\"{x:1277,y:571,t:1527872970583};\\\", \\\"{x:1277,y:570,t:1527872970594};\\\", \\\"{x:1277,y:569,t:1527872970611};\\\", \\\"{x:1277,y:567,t:1527872970628};\\\", \\\"{x:1277,y:566,t:1527872970645};\\\", \\\"{x:1277,y:563,t:1527872970661};\\\", \\\"{x:1277,y:562,t:1527872970678};\\\", \\\"{x:1277,y:561,t:1527872970694};\\\", \\\"{x:1277,y:559,t:1527872970711};\\\", \\\"{x:1277,y:556,t:1527872970727};\\\", \\\"{x:1277,y:553,t:1527872970745};\\\", \\\"{x:1277,y:551,t:1527872970762};\\\", \\\"{x:1277,y:549,t:1527872970779};\\\", \\\"{x:1277,y:546,t:1527872970795};\\\", \\\"{x:1277,y:543,t:1527872970811};\\\", \\\"{x:1277,y:540,t:1527872970828};\\\", \\\"{x:1277,y:537,t:1527872970845};\\\", \\\"{x:1277,y:535,t:1527872970861};\\\", \\\"{x:1277,y:534,t:1527872970879};\\\", \\\"{x:1277,y:532,t:1527872970895};\\\", \\\"{x:1277,y:529,t:1527872970911};\\\", \\\"{x:1277,y:527,t:1527872970928};\\\", \\\"{x:1277,y:524,t:1527872970944};\\\", \\\"{x:1277,y:522,t:1527872970961};\\\", \\\"{x:1277,y:521,t:1527872970992};\\\", \\\"{x:1277,y:519,t:1527872971064};\\\", \\\"{x:1277,y:518,t:1527872971080};\\\", \\\"{x:1277,y:517,t:1527872971094};\\\", \\\"{x:1277,y:515,t:1527872971111};\\\", \\\"{x:1277,y:514,t:1527872971128};\\\", \\\"{x:1277,y:512,t:1527872971144};\\\", \\\"{x:1277,y:511,t:1527872971161};\\\", \\\"{x:1277,y:509,t:1527872971179};\\\", \\\"{x:1277,y:505,t:1527872971195};\\\", \\\"{x:1276,y:501,t:1527872971211};\\\", \\\"{x:1275,y:497,t:1527872971228};\\\", \\\"{x:1274,y:495,t:1527872971243};\\\", \\\"{x:1274,y:494,t:1527872971260};\\\", \\\"{x:1273,y:491,t:1527872971277};\\\", \\\"{x:1273,y:488,t:1527872971293};\\\", \\\"{x:1271,y:485,t:1527872971310};\\\", \\\"{x:1271,y:482,t:1527872971327};\\\", \\\"{x:1271,y:480,t:1527872971344};\\\", \\\"{x:1271,y:479,t:1527872971361};\\\", \\\"{x:1269,y:475,t:1527872971377};\\\", \\\"{x:1267,y:470,t:1527872971394};\\\", \\\"{x:1266,y:465,t:1527872971411};\\\", \\\"{x:1265,y:460,t:1527872971428};\\\", \\\"{x:1265,y:457,t:1527872971443};\\\", \\\"{x:1264,y:454,t:1527872971460};\\\", \\\"{x:1264,y:451,t:1527872971477};\\\", \\\"{x:1262,y:445,t:1527872971494};\\\", \\\"{x:1259,y:433,t:1527872971511};\\\", \\\"{x:1255,y:419,t:1527872971527};\\\", \\\"{x:1249,y:404,t:1527872971543};\\\", \\\"{x:1248,y:396,t:1527872971560};\\\", \\\"{x:1245,y:387,t:1527872971577};\\\", \\\"{x:1243,y:380,t:1527872971594};\\\", \\\"{x:1241,y:373,t:1527872971611};\\\", \\\"{x:1240,y:371,t:1527872971628};\\\", \\\"{x:1240,y:370,t:1527872971647};\\\", \\\"{x:1239,y:369,t:1527872971661};\\\", \\\"{x:1232,y:368,t:1527872971677};\\\", \\\"{x:1212,y:366,t:1527872971693};\\\", \\\"{x:1127,y:366,t:1527872971711};\\\", \\\"{x:1056,y:370,t:1527872971727};\\\", \\\"{x:975,y:381,t:1527872971744};\\\", \\\"{x:898,y:389,t:1527872971760};\\\", \\\"{x:807,y:398,t:1527872971776};\\\", \\\"{x:696,y:414,t:1527872971794};\\\", \\\"{x:566,y:431,t:1527872971811};\\\", \\\"{x:447,y:449,t:1527872971827};\\\", \\\"{x:345,y:475,t:1527872971844};\\\", \\\"{x:279,y:502,t:1527872971861};\\\", \\\"{x:234,y:532,t:1527872971878};\\\", \\\"{x:206,y:550,t:1527872971894};\\\", \\\"{x:188,y:562,t:1527872971911};\\\", \\\"{x:183,y:567,t:1527872971933};\\\", \\\"{x:177,y:571,t:1527872971949};\\\", \\\"{x:176,y:572,t:1527872971966};\\\", \\\"{x:175,y:573,t:1527872972030};\\\", \\\"{x:174,y:573,t:1527872972047};\\\", \\\"{x:173,y:573,t:1527872972054};\\\", \\\"{x:172,y:573,t:1527872972070};\\\", \\\"{x:171,y:572,t:1527872972084};\\\", \\\"{x:171,y:568,t:1527872972101};\\\", \\\"{x:171,y:565,t:1527872972117};\\\", \\\"{x:175,y:561,t:1527872972133};\\\", \\\"{x:223,y:560,t:1527872972151};\\\", \\\"{x:303,y:566,t:1527872972167};\\\", \\\"{x:429,y:596,t:1527872972184};\\\", \\\"{x:584,y:638,t:1527872972201};\\\", \\\"{x:759,y:694,t:1527872972218};\\\", \\\"{x:940,y:765,t:1527872972234};\\\", \\\"{x:1112,y:827,t:1527872972251};\\\", \\\"{x:1225,y:875,t:1527872972268};\\\", \\\"{x:1288,y:910,t:1527872972284};\\\", \\\"{x:1337,y:949,t:1527872972301};\\\", \\\"{x:1363,y:974,t:1527872972318};\\\", \\\"{x:1389,y:996,t:1527872972334};\\\", \\\"{x:1398,y:1008,t:1527872972351};\\\", \\\"{x:1399,y:1010,t:1527872972368};\\\", \\\"{x:1399,y:1011,t:1527872972384};\\\", \\\"{x:1401,y:1010,t:1527872972472};\\\", \\\"{x:1403,y:1009,t:1527872972484};\\\", \\\"{x:1403,y:1007,t:1527872972501};\\\", \\\"{x:1403,y:1001,t:1527872972518};\\\", \\\"{x:1402,y:992,t:1527872972534};\\\", \\\"{x:1390,y:972,t:1527872972552};\\\", \\\"{x:1381,y:959,t:1527872972568};\\\", \\\"{x:1372,y:949,t:1527872972585};\\\", \\\"{x:1365,y:945,t:1527872972601};\\\", \\\"{x:1360,y:943,t:1527872972618};\\\", \\\"{x:1355,y:940,t:1527872972634};\\\", \\\"{x:1354,y:939,t:1527872972651};\\\", \\\"{x:1351,y:937,t:1527872972668};\\\", \\\"{x:1350,y:935,t:1527872972684};\\\", \\\"{x:1347,y:933,t:1527872972701};\\\", \\\"{x:1344,y:929,t:1527872972718};\\\", \\\"{x:1335,y:921,t:1527872972733};\\\", \\\"{x:1324,y:912,t:1527872972751};\\\", \\\"{x:1318,y:907,t:1527872972767};\\\", \\\"{x:1313,y:901,t:1527872972784};\\\", \\\"{x:1305,y:895,t:1527872972801};\\\", \\\"{x:1301,y:892,t:1527872972818};\\\", \\\"{x:1299,y:891,t:1527872972834};\\\", \\\"{x:1299,y:890,t:1527872972851};\\\", \\\"{x:1300,y:890,t:1527872973096};\\\", \\\"{x:1301,y:892,t:1527872973104};\\\", \\\"{x:1302,y:894,t:1527872973119};\\\", \\\"{x:1303,y:900,t:1527872973135};\\\", \\\"{x:1303,y:911,t:1527872973152};\\\", \\\"{x:1303,y:915,t:1527872973168};\\\", \\\"{x:1303,y:917,t:1527872973185};\\\", \\\"{x:1303,y:918,t:1527872973201};\\\", \\\"{x:1303,y:921,t:1527872973219};\\\", \\\"{x:1303,y:924,t:1527872973235};\\\", \\\"{x:1303,y:926,t:1527872973251};\\\", \\\"{x:1301,y:929,t:1527872973268};\\\", \\\"{x:1301,y:932,t:1527872973284};\\\", \\\"{x:1300,y:935,t:1527872973302};\\\", \\\"{x:1298,y:939,t:1527872973319};\\\", \\\"{x:1296,y:945,t:1527872973334};\\\", \\\"{x:1293,y:950,t:1527872973352};\\\", \\\"{x:1293,y:953,t:1527872973367};\\\", \\\"{x:1290,y:961,t:1527872973385};\\\", \\\"{x:1289,y:965,t:1527872973401};\\\", \\\"{x:1289,y:966,t:1527872973418};\\\", \\\"{x:1289,y:968,t:1527872973680};\\\", \\\"{x:1288,y:970,t:1527872973688};\\\", \\\"{x:1287,y:970,t:1527872973711};\\\", \\\"{x:1287,y:971,t:1527872973719};\\\", \\\"{x:1286,y:971,t:1527872973734};\\\", \\\"{x:1286,y:972,t:1527872973751};\\\", \\\"{x:1285,y:973,t:1527872973767};\\\", \\\"{x:1284,y:974,t:1527872973792};\\\", \\\"{x:1283,y:975,t:1527872974048};\\\", \\\"{x:1281,y:975,t:1527872974064};\\\", \\\"{x:1280,y:974,t:1527872974095};\\\", \\\"{x:1279,y:974,t:1527872974119};\\\", \\\"{x:1279,y:973,t:1527872974143};\\\", \\\"{x:1278,y:972,t:1527872974167};\\\", \\\"{x:1278,y:971,t:1527872974184};\\\", \\\"{x:1277,y:970,t:1527872974201};\\\", \\\"{x:1277,y:969,t:1527872974217};\\\", \\\"{x:1276,y:966,t:1527872974234};\\\", \\\"{x:1276,y:964,t:1527872974251};\\\", \\\"{x:1276,y:958,t:1527872974267};\\\", \\\"{x:1276,y:951,t:1527872974283};\\\", \\\"{x:1276,y:944,t:1527872974301};\\\", \\\"{x:1276,y:933,t:1527872974317};\\\", \\\"{x:1276,y:923,t:1527872974334};\\\", \\\"{x:1281,y:903,t:1527872974351};\\\", \\\"{x:1284,y:891,t:1527872974367};\\\", \\\"{x:1289,y:879,t:1527872974384};\\\", \\\"{x:1290,y:873,t:1527872974401};\\\", \\\"{x:1292,y:869,t:1527872974418};\\\", \\\"{x:1292,y:868,t:1527872974434};\\\", \\\"{x:1292,y:866,t:1527872974455};\\\", \\\"{x:1291,y:865,t:1527872974467};\\\", \\\"{x:1277,y:863,t:1527872974484};\\\", \\\"{x:1226,y:856,t:1527872974501};\\\", \\\"{x:1112,y:842,t:1527872974517};\\\", \\\"{x:955,y:826,t:1527872974534};\\\", \\\"{x:652,y:804,t:1527872974551};\\\", \\\"{x:432,y:778,t:1527872974568};\\\", \\\"{x:222,y:750,t:1527872974584};\\\", \\\"{x:31,y:723,t:1527872974601};\\\", \\\"{x:0,y:699,t:1527872974617};\\\", \\\"{x:0,y:672,t:1527872974635};\\\", \\\"{x:0,y:658,t:1527872974651};\\\", \\\"{x:0,y:652,t:1527872974668};\\\", \\\"{x:0,y:651,t:1527872974684};\\\", \\\"{x:0,y:647,t:1527872974701};\\\", \\\"{x:9,y:638,t:1527872974717};\\\", \\\"{x:19,y:629,t:1527872974734};\\\", \\\"{x:42,y:612,t:1527872974751};\\\", \\\"{x:63,y:601,t:1527872974769};\\\", \\\"{x:88,y:586,t:1527872974784};\\\", \\\"{x:120,y:569,t:1527872974801};\\\", \\\"{x:146,y:557,t:1527872974819};\\\", \\\"{x:168,y:548,t:1527872974836};\\\", \\\"{x:196,y:543,t:1527872974853};\\\", \\\"{x:227,y:538,t:1527872974869};\\\", \\\"{x:250,y:536,t:1527872974886};\\\", \\\"{x:279,y:531,t:1527872974903};\\\", \\\"{x:292,y:530,t:1527872974919};\\\", \\\"{x:300,y:528,t:1527872974937};\\\", \\\"{x:302,y:528,t:1527872974953};\\\", \\\"{x:306,y:527,t:1527872974970};\\\", \\\"{x:313,y:526,t:1527872974987};\\\", \\\"{x:318,y:525,t:1527872975003};\\\", \\\"{x:322,y:523,t:1527872975020};\\\", \\\"{x:323,y:522,t:1527872975036};\\\", \\\"{x:326,y:522,t:1527872975053};\\\", \\\"{x:333,y:520,t:1527872975070};\\\", \\\"{x:343,y:518,t:1527872975087};\\\", \\\"{x:348,y:518,t:1527872975103};\\\", \\\"{x:349,y:518,t:1527872975120};\\\", \\\"{x:351,y:518,t:1527872975137};\\\", \\\"{x:355,y:518,t:1527872975154};\\\", \\\"{x:361,y:518,t:1527872975170};\\\", \\\"{x:365,y:520,t:1527872975187};\\\", \\\"{x:367,y:520,t:1527872975204};\\\", \\\"{x:372,y:523,t:1527872975220};\\\", \\\"{x:374,y:523,t:1527872975239};\\\", \\\"{x:375,y:523,t:1527872975254};\\\", \\\"{x:377,y:523,t:1527872975270};\\\", \\\"{x:378,y:523,t:1527872975287};\\\", \\\"{x:379,y:523,t:1527872975535};\\\", \\\"{x:387,y:528,t:1527872975542};\\\", \\\"{x:396,y:540,t:1527872975554};\\\", \\\"{x:426,y:575,t:1527872975570};\\\", \\\"{x:449,y:600,t:1527872975587};\\\", \\\"{x:467,y:617,t:1527872975604};\\\", \\\"{x:487,y:635,t:1527872975620};\\\", \\\"{x:501,y:651,t:1527872975638};\\\", \\\"{x:509,y:663,t:1527872975654};\\\", \\\"{x:511,y:666,t:1527872975670};\\\", \\\"{x:512,y:668,t:1527872975687};\\\", \\\"{x:512,y:669,t:1527872975711};\\\", \\\"{x:512,y:670,t:1527872975727};\\\", \\\"{x:512,y:672,t:1527872975737};\\\", \\\"{x:513,y:675,t:1527872975754};\\\", \\\"{x:513,y:677,t:1527872975770};\\\", \\\"{x:513,y:679,t:1527872975787};\\\", \\\"{x:513,y:687,t:1527872975803};\\\", \\\"{x:513,y:696,t:1527872975819};\\\", \\\"{x:512,y:703,t:1527872975839};\\\", \\\"{x:512,y:708,t:1527872975854};\\\", \\\"{x:509,y:713,t:1527872975870};\\\", \\\"{x:509,y:715,t:1527872975887};\\\", \\\"{x:509,y:719,t:1527872975904};\\\", \\\"{x:509,y:720,t:1527872975921};\\\" ] }, { \\\"rt\\\": 20843, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 189013, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"QGUGU\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-A -A -D \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:509,y:722,t:1527872981576};\\\", \\\"{x:516,y:728,t:1527872981583};\\\", \\\"{x:539,y:741,t:1527872981599};\\\", \\\"{x:616,y:769,t:1527872981615};\\\", \\\"{x:718,y:799,t:1527872981630};\\\", \\\"{x:845,y:831,t:1527872981642};\\\", \\\"{x:984,y:854,t:1527872981658};\\\", \\\"{x:1125,y:873,t:1527872981675};\\\", \\\"{x:1247,y:890,t:1527872981692};\\\", \\\"{x:1336,y:903,t:1527872981708};\\\", \\\"{x:1395,y:905,t:1527872981725};\\\", \\\"{x:1423,y:905,t:1527872981742};\\\", \\\"{x:1442,y:905,t:1527872981759};\\\", \\\"{x:1443,y:905,t:1527872981775};\\\", \\\"{x:1441,y:905,t:1527872981873};\\\", \\\"{x:1439,y:905,t:1527872981887};\\\", \\\"{x:1435,y:904,t:1527872981895};\\\", \\\"{x:1432,y:902,t:1527872981910};\\\", \\\"{x:1423,y:898,t:1527872981926};\\\", \\\"{x:1412,y:893,t:1527872981943};\\\", \\\"{x:1389,y:887,t:1527872981959};\\\", \\\"{x:1376,y:881,t:1527872981976};\\\", \\\"{x:1366,y:876,t:1527872981992};\\\", \\\"{x:1360,y:872,t:1527872982009};\\\", \\\"{x:1354,y:868,t:1527872982026};\\\", \\\"{x:1350,y:864,t:1527872982042};\\\", \\\"{x:1347,y:860,t:1527872982058};\\\", \\\"{x:1346,y:859,t:1527872982076};\\\", \\\"{x:1345,y:858,t:1527872982092};\\\", \\\"{x:1343,y:855,t:1527872982109};\\\", \\\"{x:1343,y:854,t:1527872982126};\\\", \\\"{x:1342,y:854,t:1527872982143};\\\", \\\"{x:1341,y:853,t:1527872982159};\\\", \\\"{x:1340,y:852,t:1527872982191};\\\", \\\"{x:1340,y:851,t:1527872982200};\\\", \\\"{x:1338,y:849,t:1527872982210};\\\", \\\"{x:1336,y:848,t:1527872982227};\\\", \\\"{x:1330,y:846,t:1527872982244};\\\", \\\"{x:1328,y:845,t:1527872982259};\\\", \\\"{x:1324,y:844,t:1527872982276};\\\", \\\"{x:1319,y:844,t:1527872982293};\\\", \\\"{x:1313,y:841,t:1527872982310};\\\", \\\"{x:1308,y:840,t:1527872982327};\\\", \\\"{x:1295,y:834,t:1527872982343};\\\", \\\"{x:1293,y:832,t:1527872982360};\\\", \\\"{x:1291,y:832,t:1527872982377};\\\", \\\"{x:1289,y:830,t:1527872982394};\\\", \\\"{x:1285,y:827,t:1527872982413};\\\", \\\"{x:1284,y:826,t:1527872982426};\\\", \\\"{x:1283,y:826,t:1527872982443};\\\", \\\"{x:1282,y:825,t:1527872982462};\\\", \\\"{x:1282,y:824,t:1527872982478};\\\", \\\"{x:1281,y:823,t:1527872982493};\\\", \\\"{x:1280,y:823,t:1527872982510};\\\", \\\"{x:1280,y:822,t:1527872982527};\\\", \\\"{x:1279,y:821,t:1527872982543};\\\", \\\"{x:1278,y:821,t:1527872982560};\\\", \\\"{x:1284,y:821,t:1527872983095};\\\", \\\"{x:1305,y:826,t:1527872983112};\\\", \\\"{x:1321,y:828,t:1527872983129};\\\", \\\"{x:1337,y:830,t:1527872983145};\\\", \\\"{x:1356,y:830,t:1527872983161};\\\", \\\"{x:1374,y:830,t:1527872983181};\\\", \\\"{x:1388,y:829,t:1527872983195};\\\", \\\"{x:1400,y:823,t:1527872983212};\\\", \\\"{x:1416,y:814,t:1527872983229};\\\", \\\"{x:1431,y:805,t:1527872983245};\\\", \\\"{x:1443,y:800,t:1527872983262};\\\", \\\"{x:1448,y:799,t:1527872983278};\\\", \\\"{x:1455,y:796,t:1527872983295};\\\", \\\"{x:1458,y:795,t:1527872983312};\\\", \\\"{x:1459,y:794,t:1527872983329};\\\", \\\"{x:1462,y:791,t:1527872983346};\\\", \\\"{x:1463,y:789,t:1527872983362};\\\", \\\"{x:1465,y:787,t:1527872983380};\\\", \\\"{x:1466,y:785,t:1527872983396};\\\", \\\"{x:1468,y:783,t:1527872983411};\\\", \\\"{x:1470,y:780,t:1527872983428};\\\", \\\"{x:1471,y:779,t:1527872983446};\\\", \\\"{x:1472,y:778,t:1527872983462};\\\", \\\"{x:1472,y:777,t:1527872983478};\\\", \\\"{x:1472,y:774,t:1527872983495};\\\", \\\"{x:1472,y:773,t:1527872983512};\\\", \\\"{x:1472,y:769,t:1527872983528};\\\", \\\"{x:1472,y:763,t:1527872983546};\\\", \\\"{x:1470,y:753,t:1527872983563};\\\", \\\"{x:1467,y:745,t:1527872983580};\\\", \\\"{x:1463,y:736,t:1527872983596};\\\", \\\"{x:1462,y:731,t:1527872983613};\\\", \\\"{x:1460,y:724,t:1527872983628};\\\", \\\"{x:1459,y:718,t:1527872983645};\\\", \\\"{x:1456,y:713,t:1527872983662};\\\", \\\"{x:1454,y:709,t:1527872983679};\\\", \\\"{x:1453,y:707,t:1527872983696};\\\", \\\"{x:1453,y:706,t:1527872983713};\\\", \\\"{x:1452,y:706,t:1527872985304};\\\", \\\"{x:1450,y:707,t:1527872988464};\\\", \\\"{x:1448,y:711,t:1527872988472};\\\", \\\"{x:1444,y:716,t:1527872988488};\\\", \\\"{x:1442,y:718,t:1527872988505};\\\", \\\"{x:1439,y:720,t:1527872988522};\\\", \\\"{x:1438,y:721,t:1527872988538};\\\", \\\"{x:1437,y:724,t:1527872988555};\\\", \\\"{x:1436,y:725,t:1527872988572};\\\", \\\"{x:1435,y:727,t:1527872988591};\\\", \\\"{x:1434,y:728,t:1527872988608};\\\", \\\"{x:1434,y:729,t:1527872988622};\\\", \\\"{x:1433,y:729,t:1527872988637};\\\", \\\"{x:1432,y:731,t:1527872988655};\\\", \\\"{x:1431,y:733,t:1527872988671};\\\", \\\"{x:1430,y:734,t:1527872988688};\\\", \\\"{x:1428,y:737,t:1527872988705};\\\", \\\"{x:1427,y:739,t:1527872988722};\\\", \\\"{x:1426,y:740,t:1527872988739};\\\", \\\"{x:1424,y:741,t:1527872988754};\\\", \\\"{x:1424,y:743,t:1527872988772};\\\", \\\"{x:1422,y:745,t:1527872988789};\\\", \\\"{x:1422,y:747,t:1527872988805};\\\", \\\"{x:1421,y:749,t:1527872988822};\\\", \\\"{x:1420,y:751,t:1527872988839};\\\", \\\"{x:1420,y:752,t:1527872988855};\\\", \\\"{x:1421,y:750,t:1527872989024};\\\", \\\"{x:1425,y:743,t:1527872989040};\\\", \\\"{x:1429,y:738,t:1527872989055};\\\", \\\"{x:1433,y:732,t:1527872989072};\\\", \\\"{x:1434,y:728,t:1527872989089};\\\", \\\"{x:1434,y:722,t:1527872989106};\\\", \\\"{x:1434,y:717,t:1527872989123};\\\", \\\"{x:1434,y:711,t:1527872989139};\\\", \\\"{x:1434,y:706,t:1527872989156};\\\", \\\"{x:1434,y:699,t:1527872989173};\\\", \\\"{x:1434,y:694,t:1527872989189};\\\", \\\"{x:1432,y:689,t:1527872989206};\\\", \\\"{x:1429,y:682,t:1527872989223};\\\", \\\"{x:1426,y:675,t:1527872989239};\\\", \\\"{x:1421,y:667,t:1527872989256};\\\", \\\"{x:1418,y:662,t:1527872989273};\\\", \\\"{x:1414,y:655,t:1527872989290};\\\", \\\"{x:1409,y:648,t:1527872989307};\\\", \\\"{x:1403,y:642,t:1527872989326};\\\", \\\"{x:1397,y:636,t:1527872989343};\\\", \\\"{x:1391,y:631,t:1527872989359};\\\", \\\"{x:1385,y:625,t:1527872989376};\\\", \\\"{x:1378,y:617,t:1527872989393};\\\", \\\"{x:1374,y:610,t:1527872989409};\\\", \\\"{x:1368,y:600,t:1527872989426};\\\", \\\"{x:1367,y:597,t:1527872989443};\\\", \\\"{x:1367,y:594,t:1527872989460};\\\", \\\"{x:1367,y:593,t:1527872989477};\\\", \\\"{x:1366,y:590,t:1527872989493};\\\", \\\"{x:1366,y:588,t:1527872989510};\\\", \\\"{x:1366,y:586,t:1527872989526};\\\", \\\"{x:1367,y:586,t:1527872989946};\\\", \\\"{x:1371,y:586,t:1527872989960};\\\", \\\"{x:1384,y:581,t:1527872989977};\\\", \\\"{x:1418,y:573,t:1527872989993};\\\", \\\"{x:1444,y:570,t:1527872990010};\\\", \\\"{x:1471,y:565,t:1527872990027};\\\", \\\"{x:1515,y:550,t:1527872990043};\\\", \\\"{x:1552,y:530,t:1527872990061};\\\", \\\"{x:1583,y:516,t:1527872990077};\\\", \\\"{x:1606,y:506,t:1527872990093};\\\", \\\"{x:1631,y:498,t:1527872990110};\\\", \\\"{x:1659,y:488,t:1527872990126};\\\", \\\"{x:1668,y:486,t:1527872990144};\\\", \\\"{x:1671,y:483,t:1527872990161};\\\", \\\"{x:1674,y:481,t:1527872990177};\\\", \\\"{x:1676,y:476,t:1527872990194};\\\", \\\"{x:1676,y:473,t:1527872990211};\\\", \\\"{x:1676,y:470,t:1527872990228};\\\", \\\"{x:1676,y:469,t:1527872990266};\\\", \\\"{x:1676,y:468,t:1527872990278};\\\", \\\"{x:1673,y:465,t:1527872990293};\\\", \\\"{x:1668,y:465,t:1527872990310};\\\", \\\"{x:1664,y:462,t:1527872990328};\\\", \\\"{x:1662,y:461,t:1527872990344};\\\", \\\"{x:1660,y:459,t:1527872990361};\\\", \\\"{x:1655,y:456,t:1527872990379};\\\", \\\"{x:1655,y:455,t:1527872990394};\\\", \\\"{x:1654,y:453,t:1527872990411};\\\", \\\"{x:1652,y:449,t:1527872990428};\\\", \\\"{x:1651,y:445,t:1527872990445};\\\", \\\"{x:1648,y:440,t:1527872990461};\\\", \\\"{x:1645,y:437,t:1527872990478};\\\", \\\"{x:1644,y:435,t:1527872990495};\\\", \\\"{x:1643,y:435,t:1527872990511};\\\", \\\"{x:1642,y:434,t:1527872990528};\\\", \\\"{x:1641,y:434,t:1527872990544};\\\", \\\"{x:1639,y:434,t:1527872990561};\\\", \\\"{x:1635,y:432,t:1527872990578};\\\", \\\"{x:1632,y:431,t:1527872990595};\\\", \\\"{x:1631,y:431,t:1527872990611};\\\", \\\"{x:1629,y:431,t:1527872990628};\\\", \\\"{x:1626,y:430,t:1527872990645};\\\", \\\"{x:1623,y:430,t:1527872990662};\\\", \\\"{x:1622,y:430,t:1527872990677};\\\", \\\"{x:1621,y:429,t:1527872990803};\\\", \\\"{x:1619,y:429,t:1527872990836};\\\", \\\"{x:1618,y:429,t:1527872990866};\\\", \\\"{x:1618,y:428,t:1527872990915};\\\", \\\"{x:1616,y:428,t:1527872990947};\\\", \\\"{x:1616,y:429,t:1527872991435};\\\", \\\"{x:1616,y:431,t:1527872991446};\\\", \\\"{x:1616,y:432,t:1527872991463};\\\", \\\"{x:1615,y:434,t:1527872991480};\\\", \\\"{x:1615,y:438,t:1527872991497};\\\", \\\"{x:1612,y:442,t:1527872991513};\\\", \\\"{x:1610,y:446,t:1527872991531};\\\", \\\"{x:1603,y:457,t:1527872991547};\\\", \\\"{x:1588,y:472,t:1527872991563};\\\", \\\"{x:1564,y:489,t:1527872991580};\\\", \\\"{x:1531,y:510,t:1527872991597};\\\", \\\"{x:1503,y:524,t:1527872991614};\\\", \\\"{x:1470,y:536,t:1527872991631};\\\", \\\"{x:1420,y:548,t:1527872991648};\\\", \\\"{x:1356,y:556,t:1527872991663};\\\", \\\"{x:1271,y:566,t:1527872991681};\\\", \\\"{x:1179,y:566,t:1527872991697};\\\", \\\"{x:1082,y:566,t:1527872991714};\\\", \\\"{x:918,y:566,t:1527872991732};\\\", \\\"{x:819,y:566,t:1527872991746};\\\", \\\"{x:730,y:566,t:1527872991763};\\\", \\\"{x:605,y:566,t:1527872991787};\\\", \\\"{x:533,y:566,t:1527872991802};\\\", \\\"{x:461,y:571,t:1527872991820};\\\", \\\"{x:412,y:576,t:1527872991837};\\\", \\\"{x:386,y:578,t:1527872991852};\\\", \\\"{x:377,y:581,t:1527872991869};\\\", \\\"{x:376,y:581,t:1527872991887};\\\", \\\"{x:375,y:581,t:1527872991903};\\\", \\\"{x:373,y:581,t:1527872992435};\\\", \\\"{x:372,y:583,t:1527872992444};\\\", \\\"{x:371,y:584,t:1527872992453};\\\", \\\"{x:368,y:588,t:1527872992470};\\\", \\\"{x:367,y:590,t:1527872992486};\\\", \\\"{x:366,y:591,t:1527872992503};\\\", \\\"{x:362,y:592,t:1527872992520};\\\", \\\"{x:359,y:595,t:1527872992536};\\\", \\\"{x:358,y:602,t:1527872992554};\\\", \\\"{x:358,y:605,t:1527872992571};\\\", \\\"{x:357,y:606,t:1527872992587};\\\", \\\"{x:357,y:605,t:1527872992682};\\\", \\\"{x:357,y:600,t:1527872992689};\\\", \\\"{x:357,y:593,t:1527872992703};\\\", \\\"{x:357,y:583,t:1527872992720};\\\", \\\"{x:357,y:574,t:1527872992737};\\\", \\\"{x:353,y:565,t:1527872992753};\\\", \\\"{x:351,y:562,t:1527872992771};\\\", \\\"{x:350,y:561,t:1527872992787};\\\", \\\"{x:347,y:558,t:1527872992804};\\\", \\\"{x:341,y:557,t:1527872992821};\\\", \\\"{x:331,y:557,t:1527872992836};\\\", \\\"{x:321,y:557,t:1527872992853};\\\", \\\"{x:309,y:557,t:1527872992871};\\\", \\\"{x:292,y:557,t:1527872992887};\\\", \\\"{x:272,y:557,t:1527872992905};\\\", \\\"{x:250,y:557,t:1527872992920};\\\", \\\"{x:230,y:557,t:1527872992936};\\\", \\\"{x:210,y:556,t:1527872992953};\\\", \\\"{x:200,y:554,t:1527872992971};\\\", \\\"{x:195,y:554,t:1527872992987};\\\", \\\"{x:193,y:554,t:1527872993004};\\\", \\\"{x:192,y:554,t:1527872993020};\\\", \\\"{x:191,y:555,t:1527872993107};\\\", \\\"{x:191,y:563,t:1527872993122};\\\", \\\"{x:193,y:585,t:1527872993141};\\\", \\\"{x:195,y:593,t:1527872993153};\\\", \\\"{x:196,y:599,t:1527872993171};\\\", \\\"{x:197,y:603,t:1527872993188};\\\", \\\"{x:197,y:606,t:1527872993204};\\\", \\\"{x:197,y:607,t:1527872993220};\\\", \\\"{x:197,y:609,t:1527872993238};\\\", \\\"{x:193,y:612,t:1527872993255};\\\", \\\"{x:181,y:617,t:1527872993271};\\\", \\\"{x:170,y:620,t:1527872993289};\\\", \\\"{x:165,y:621,t:1527872993304};\\\", \\\"{x:163,y:621,t:1527872993320};\\\", \\\"{x:162,y:621,t:1527872993337};\\\", \\\"{x:161,y:621,t:1527872993353};\\\", \\\"{x:160,y:621,t:1527872993386};\\\", \\\"{x:160,y:623,t:1527872993739};\\\", \\\"{x:181,y:632,t:1527872993754};\\\", \\\"{x:217,y:648,t:1527872993771};\\\", \\\"{x:258,y:664,t:1527872993788};\\\", \\\"{x:283,y:674,t:1527872993805};\\\", \\\"{x:315,y:682,t:1527872993821};\\\", \\\"{x:340,y:687,t:1527872993837};\\\", \\\"{x:361,y:691,t:1527872993855};\\\", \\\"{x:383,y:698,t:1527872993872};\\\", \\\"{x:402,y:704,t:1527872993887};\\\", \\\"{x:410,y:708,t:1527872993905};\\\", \\\"{x:411,y:708,t:1527872994035};\\\", \\\"{x:410,y:708,t:1527872994042};\\\", \\\"{x:401,y:705,t:1527872994056};\\\", \\\"{x:367,y:694,t:1527872994072};\\\", \\\"{x:340,y:682,t:1527872994088};\\\", \\\"{x:311,y:670,t:1527872994105};\\\", \\\"{x:268,y:657,t:1527872994123};\\\", \\\"{x:246,y:651,t:1527872994138};\\\", \\\"{x:230,y:646,t:1527872994157};\\\", \\\"{x:225,y:645,t:1527872994172};\\\", \\\"{x:224,y:644,t:1527872994187};\\\", \\\"{x:223,y:643,t:1527872994205};\\\", \\\"{x:222,y:643,t:1527872994222};\\\", \\\"{x:220,y:643,t:1527872994238};\\\", \\\"{x:216,y:642,t:1527872994255};\\\", \\\"{x:213,y:640,t:1527872994272};\\\", \\\"{x:209,y:640,t:1527872994288};\\\", \\\"{x:203,y:641,t:1527872994304};\\\", \\\"{x:196,y:645,t:1527872994322};\\\", \\\"{x:194,y:646,t:1527872994337};\\\", \\\"{x:191,y:647,t:1527872994354};\\\", \\\"{x:188,y:648,t:1527872994371};\\\", \\\"{x:186,y:649,t:1527872994394};\\\", \\\"{x:185,y:649,t:1527872994434};\\\", \\\"{x:189,y:649,t:1527872994538};\\\", \\\"{x:194,y:650,t:1527872994555};\\\", \\\"{x:196,y:650,t:1527872994572};\\\", \\\"{x:196,y:650,t:1527872994618};\\\", \\\"{x:196,y:649,t:1527872995035};\\\", \\\"{x:195,y:648,t:1527872995042};\\\", \\\"{x:193,y:647,t:1527872995056};\\\", \\\"{x:193,y:645,t:1527872995072};\\\", \\\"{x:193,y:643,t:1527872995089};\\\", \\\"{x:192,y:642,t:1527872995106};\\\", \\\"{x:191,y:642,t:1527872995155};\\\", \\\"{x:190,y:642,t:1527872995172};\\\", \\\"{x:188,y:641,t:1527872995188};\\\", \\\"{x:187,y:641,t:1527872995218};\\\", \\\"{x:188,y:642,t:1527872995650};\\\", \\\"{x:193,y:646,t:1527872995659};\\\", \\\"{x:201,y:649,t:1527872995673};\\\", \\\"{x:234,y:662,t:1527872995690};\\\", \\\"{x:288,y:690,t:1527872995705};\\\", \\\"{x:344,y:709,t:1527872995723};\\\", \\\"{x:373,y:719,t:1527872995739};\\\", \\\"{x:394,y:725,t:1527872995756};\\\", \\\"{x:407,y:727,t:1527872995773};\\\", \\\"{x:417,y:731,t:1527872995789};\\\", \\\"{x:419,y:732,t:1527872995805};\\\", \\\"{x:420,y:733,t:1527872995822};\\\", \\\"{x:424,y:735,t:1527872995840};\\\", \\\"{x:433,y:737,t:1527872995857};\\\", \\\"{x:441,y:740,t:1527872995873};\\\", \\\"{x:446,y:741,t:1527872995890};\\\", \\\"{x:453,y:741,t:1527872995906};\\\", \\\"{x:467,y:741,t:1527872995923};\\\", \\\"{x:479,y:741,t:1527872995940};\\\", \\\"{x:486,y:741,t:1527872995957};\\\", \\\"{x:491,y:738,t:1527872995973};\\\", \\\"{x:495,y:737,t:1527872995990};\\\", \\\"{x:501,y:733,t:1527872996007};\\\", \\\"{x:504,y:731,t:1527872996023};\\\", \\\"{x:506,y:729,t:1527872996039};\\\", \\\"{x:506,y:728,t:1527872996227};\\\", \\\"{x:506,y:727,t:1527872996240};\\\", \\\"{x:505,y:723,t:1527872996257};\\\", \\\"{x:504,y:720,t:1527872996273};\\\", \\\"{x:500,y:716,t:1527872996290};\\\", \\\"{x:498,y:713,t:1527872996307};\\\", \\\"{x:497,y:712,t:1527872996330};\\\" ] }, { \\\"rt\\\": 22079, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 212358, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"QGUGU\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:496,y:712,t:1527873001050};\\\", \\\"{x:496,y:713,t:1527873001060};\\\", \\\"{x:496,y:715,t:1527873001077};\\\", \\\"{x:497,y:715,t:1527873003883};\\\", \\\"{x:499,y:716,t:1527873003914};\\\", \\\"{x:500,y:717,t:1527873003954};\\\", \\\"{x:501,y:717,t:1527873003986};\\\", \\\"{x:502,y:717,t:1527873004018};\\\", \\\"{x:503,y:717,t:1527873004028};\\\", \\\"{x:505,y:718,t:1527873004044};\\\", \\\"{x:505,y:719,t:1527873004061};\\\", \\\"{x:508,y:719,t:1527873004078};\\\", \\\"{x:508,y:720,t:1527873004095};\\\", \\\"{x:510,y:720,t:1527873004112};\\\", \\\"{x:513,y:721,t:1527873004128};\\\", \\\"{x:519,y:723,t:1527873004144};\\\", \\\"{x:529,y:727,t:1527873004162};\\\", \\\"{x:533,y:728,t:1527873004178};\\\", \\\"{x:535,y:728,t:1527873004195};\\\", \\\"{x:537,y:729,t:1527873004212};\\\", \\\"{x:539,y:730,t:1527873004229};\\\", \\\"{x:543,y:732,t:1527873004245};\\\", \\\"{x:547,y:735,t:1527873004261};\\\", \\\"{x:552,y:738,t:1527873004279};\\\", \\\"{x:555,y:739,t:1527873004294};\\\", \\\"{x:559,y:742,t:1527873004311};\\\", \\\"{x:569,y:748,t:1527873004329};\\\", \\\"{x:581,y:753,t:1527873004346};\\\", \\\"{x:593,y:758,t:1527873004363};\\\", \\\"{x:611,y:765,t:1527873004380};\\\", \\\"{x:632,y:776,t:1527873004396};\\\", \\\"{x:653,y:787,t:1527873004414};\\\", \\\"{x:681,y:799,t:1527873004430};\\\", \\\"{x:703,y:809,t:1527873004447};\\\", \\\"{x:724,y:815,t:1527873004463};\\\", \\\"{x:747,y:824,t:1527873004480};\\\", \\\"{x:772,y:830,t:1527873004496};\\\", \\\"{x:794,y:837,t:1527873004513};\\\", \\\"{x:830,y:847,t:1527873004530};\\\", \\\"{x:854,y:854,t:1527873004546};\\\", \\\"{x:882,y:861,t:1527873004564};\\\", \\\"{x:904,y:869,t:1527873004581};\\\", \\\"{x:926,y:872,t:1527873004596};\\\", \\\"{x:946,y:877,t:1527873004613};\\\", \\\"{x:965,y:881,t:1527873004631};\\\", \\\"{x:979,y:883,t:1527873004648};\\\", \\\"{x:995,y:885,t:1527873004663};\\\", \\\"{x:1010,y:887,t:1527873004680};\\\", \\\"{x:1024,y:888,t:1527873004697};\\\", \\\"{x:1042,y:888,t:1527873004714};\\\", \\\"{x:1080,y:886,t:1527873004731};\\\", \\\"{x:1101,y:884,t:1527873004746};\\\", \\\"{x:1112,y:883,t:1527873004764};\\\", \\\"{x:1124,y:881,t:1527873004781};\\\", \\\"{x:1134,y:879,t:1527873004798};\\\", \\\"{x:1140,y:878,t:1527873004814};\\\", \\\"{x:1147,y:876,t:1527873004831};\\\", \\\"{x:1153,y:871,t:1527873004849};\\\", \\\"{x:1156,y:868,t:1527873004864};\\\", \\\"{x:1161,y:866,t:1527873004880};\\\", \\\"{x:1166,y:863,t:1527873004898};\\\", \\\"{x:1169,y:861,t:1527873004914};\\\", \\\"{x:1175,y:856,t:1527873004930};\\\", \\\"{x:1178,y:851,t:1527873004948};\\\", \\\"{x:1180,y:848,t:1527873004964};\\\", \\\"{x:1182,y:846,t:1527873004981};\\\", \\\"{x:1187,y:841,t:1527873004998};\\\", \\\"{x:1191,y:835,t:1527873005014};\\\", \\\"{x:1192,y:834,t:1527873005031};\\\", \\\"{x:1193,y:833,t:1527873005048};\\\", \\\"{x:1193,y:832,t:1527873005064};\\\", \\\"{x:1195,y:830,t:1527873005081};\\\", \\\"{x:1197,y:829,t:1527873005098};\\\", \\\"{x:1198,y:827,t:1527873005114};\\\", \\\"{x:1199,y:826,t:1527873005130};\\\", \\\"{x:1200,y:826,t:1527873005148};\\\", \\\"{x:1202,y:826,t:1527873005226};\\\", \\\"{x:1203,y:826,t:1527873005242};\\\", \\\"{x:1204,y:826,t:1527873005267};\\\", \\\"{x:1206,y:826,t:1527873005281};\\\", \\\"{x:1207,y:826,t:1527873005298};\\\", \\\"{x:1211,y:826,t:1527873005317};\\\", \\\"{x:1212,y:826,t:1527873005331};\\\", \\\"{x:1213,y:827,t:1527873005361};\\\", \\\"{x:1215,y:827,t:1527873005449};\\\", \\\"{x:1216,y:828,t:1527873005498};\\\", \\\"{x:1215,y:828,t:1527873010002};\\\", \\\"{x:1187,y:821,t:1527873010020};\\\", \\\"{x:1143,y:809,t:1527873010034};\\\", \\\"{x:1088,y:798,t:1527873010052};\\\", \\\"{x:1029,y:788,t:1527873010068};\\\", \\\"{x:973,y:769,t:1527873010085};\\\", \\\"{x:918,y:757,t:1527873010101};\\\", \\\"{x:871,y:744,t:1527873010117};\\\", \\\"{x:834,y:733,t:1527873010134};\\\", \\\"{x:794,y:719,t:1527873010151};\\\", \\\"{x:770,y:709,t:1527873010168};\\\", \\\"{x:757,y:704,t:1527873010184};\\\", \\\"{x:751,y:700,t:1527873010202};\\\", \\\"{x:748,y:699,t:1527873010218};\\\", \\\"{x:746,y:698,t:1527873010241};\\\", \\\"{x:744,y:698,t:1527873010252};\\\", \\\"{x:736,y:695,t:1527873010267};\\\", \\\"{x:731,y:692,t:1527873010284};\\\", \\\"{x:725,y:690,t:1527873010301};\\\", \\\"{x:719,y:686,t:1527873010318};\\\", \\\"{x:711,y:682,t:1527873010335};\\\", \\\"{x:701,y:676,t:1527873010352};\\\", \\\"{x:678,y:665,t:1527873010368};\\\", \\\"{x:651,y:653,t:1527873010384};\\\", \\\"{x:588,y:631,t:1527873010402};\\\", \\\"{x:546,y:619,t:1527873010418};\\\", \\\"{x:507,y:608,t:1527873010435};\\\", \\\"{x:465,y:597,t:1527873010452};\\\", \\\"{x:420,y:583,t:1527873010467};\\\", \\\"{x:390,y:576,t:1527873010484};\\\", \\\"{x:371,y:570,t:1527873010502};\\\", \\\"{x:361,y:569,t:1527873010518};\\\", \\\"{x:354,y:568,t:1527873010534};\\\", \\\"{x:351,y:567,t:1527873010551};\\\", \\\"{x:347,y:566,t:1527873010568};\\\", \\\"{x:346,y:566,t:1527873010617};\\\", \\\"{x:341,y:566,t:1527873010636};\\\", \\\"{x:334,y:566,t:1527873010652};\\\", \\\"{x:323,y:569,t:1527873010668};\\\", \\\"{x:311,y:574,t:1527873010685};\\\", \\\"{x:304,y:577,t:1527873010703};\\\", \\\"{x:298,y:579,t:1527873010719};\\\", \\\"{x:290,y:583,t:1527873010736};\\\", \\\"{x:283,y:586,t:1527873010751};\\\", \\\"{x:275,y:590,t:1527873010768};\\\", \\\"{x:253,y:600,t:1527873010787};\\\", \\\"{x:242,y:605,t:1527873010801};\\\", \\\"{x:236,y:608,t:1527873010819};\\\", \\\"{x:230,y:608,t:1527873010835};\\\", \\\"{x:226,y:608,t:1527873010851};\\\", \\\"{x:221,y:608,t:1527873010869};\\\", \\\"{x:215,y:608,t:1527873010885};\\\", \\\"{x:212,y:608,t:1527873010901};\\\", \\\"{x:208,y:608,t:1527873010918};\\\", \\\"{x:204,y:608,t:1527873010935};\\\", \\\"{x:196,y:605,t:1527873010951};\\\", \\\"{x:191,y:604,t:1527873010969};\\\", \\\"{x:189,y:602,t:1527873010985};\\\", \\\"{x:184,y:598,t:1527873011001};\\\", \\\"{x:178,y:592,t:1527873011018};\\\", \\\"{x:173,y:586,t:1527873011035};\\\", \\\"{x:168,y:581,t:1527873011052};\\\", \\\"{x:166,y:578,t:1527873011068};\\\", \\\"{x:166,y:575,t:1527873011086};\\\", \\\"{x:163,y:570,t:1527873011102};\\\", \\\"{x:162,y:565,t:1527873011118};\\\", \\\"{x:162,y:563,t:1527873011135};\\\", \\\"{x:162,y:562,t:1527873011151};\\\", \\\"{x:161,y:561,t:1527873011169};\\\", \\\"{x:160,y:561,t:1527873011226};\\\", \\\"{x:159,y:560,t:1527873011236};\\\", \\\"{x:158,y:560,t:1527873011251};\\\", \\\"{x:157,y:560,t:1527873011273};\\\", \\\"{x:157,y:561,t:1527873011618};\\\", \\\"{x:161,y:564,t:1527873011626};\\\", \\\"{x:166,y:570,t:1527873011635};\\\", \\\"{x:178,y:582,t:1527873011653};\\\", \\\"{x:191,y:592,t:1527873011669};\\\", \\\"{x:205,y:603,t:1527873011686};\\\", \\\"{x:228,y:617,t:1527873011703};\\\", \\\"{x:258,y:632,t:1527873011719};\\\", \\\"{x:292,y:646,t:1527873011737};\\\", \\\"{x:324,y:658,t:1527873011753};\\\", \\\"{x:363,y:672,t:1527873011770};\\\", \\\"{x:384,y:679,t:1527873011786};\\\", \\\"{x:397,y:682,t:1527873011802};\\\", \\\"{x:403,y:684,t:1527873011819};\\\", \\\"{x:405,y:684,t:1527873011836};\\\", \\\"{x:406,y:684,t:1527873011873};\\\", \\\"{x:407,y:684,t:1527873011963};\\\", \\\"{x:412,y:687,t:1527873011970};\\\", \\\"{x:443,y:701,t:1527873011986};\\\", \\\"{x:492,y:720,t:1527873012004};\\\", \\\"{x:525,y:731,t:1527873012020};\\\", \\\"{x:546,y:735,t:1527873012036};\\\", \\\"{x:560,y:737,t:1527873012053};\\\", \\\"{x:570,y:738,t:1527873012070};\\\", \\\"{x:574,y:740,t:1527873012087};\\\", \\\"{x:574,y:739,t:1527873012226};\\\", \\\"{x:569,y:736,t:1527873012237};\\\", \\\"{x:561,y:734,t:1527873012254};\\\", \\\"{x:556,y:732,t:1527873012271};\\\", \\\"{x:549,y:728,t:1527873012287};\\\", \\\"{x:542,y:724,t:1527873012303};\\\", \\\"{x:539,y:723,t:1527873012320};\\\" ] }, { \\\"rt\\\": 39966, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 253578, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"QGUGU\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-05 PM-04 PM-04 PM-03 PM-C -Z -Z -F -O -O -O -O -H -H -U \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:545,y:723,t:1527873024947};\\\", \\\"{x:613,y:734,t:1527873024962};\\\", \\\"{x:697,y:734,t:1527873024979};\\\", \\\"{x:806,y:740,t:1527873024995};\\\", \\\"{x:928,y:758,t:1527873025014};\\\", \\\"{x:1038,y:770,t:1527873025031};\\\", \\\"{x:1139,y:786,t:1527873025046};\\\", \\\"{x:1216,y:797,t:1527873025063};\\\", \\\"{x:1268,y:806,t:1527873025080};\\\", \\\"{x:1292,y:813,t:1527873025097};\\\", \\\"{x:1309,y:822,t:1527873025113};\\\", \\\"{x:1311,y:824,t:1527873025130};\\\", \\\"{x:1312,y:825,t:1527873025161};\\\", \\\"{x:1313,y:825,t:1527873025185};\\\", \\\"{x:1313,y:826,t:1527873025201};\\\", \\\"{x:1313,y:827,t:1527873025213};\\\", \\\"{x:1314,y:827,t:1527873025231};\\\", \\\"{x:1314,y:828,t:1527873025267};\\\", \\\"{x:1314,y:829,t:1527873025281};\\\", \\\"{x:1314,y:830,t:1527873025298};\\\", \\\"{x:1314,y:831,t:1527873025314};\\\", \\\"{x:1314,y:833,t:1527873025330};\\\", \\\"{x:1313,y:836,t:1527873025348};\\\", \\\"{x:1311,y:838,t:1527873025364};\\\", \\\"{x:1310,y:841,t:1527873025380};\\\", \\\"{x:1310,y:843,t:1527873025398};\\\", \\\"{x:1307,y:847,t:1527873025414};\\\", \\\"{x:1305,y:855,t:1527873025431};\\\", \\\"{x:1299,y:865,t:1527873025448};\\\", \\\"{x:1293,y:874,t:1527873025466};\\\", \\\"{x:1292,y:878,t:1527873025481};\\\", \\\"{x:1287,y:885,t:1527873025499};\\\", \\\"{x:1286,y:890,t:1527873025514};\\\", \\\"{x:1285,y:898,t:1527873025531};\\\", \\\"{x:1285,y:909,t:1527873025548};\\\", \\\"{x:1285,y:921,t:1527873025565};\\\", \\\"{x:1286,y:935,t:1527873025581};\\\", \\\"{x:1287,y:940,t:1527873025598};\\\", \\\"{x:1288,y:944,t:1527873025615};\\\", \\\"{x:1290,y:946,t:1527873025631};\\\", \\\"{x:1295,y:951,t:1527873025648};\\\", \\\"{x:1299,y:955,t:1527873025665};\\\", \\\"{x:1306,y:960,t:1527873025681};\\\", \\\"{x:1310,y:961,t:1527873025698};\\\", \\\"{x:1312,y:961,t:1527873025995};\\\", \\\"{x:1313,y:961,t:1527873026003};\\\", \\\"{x:1314,y:961,t:1527873026018};\\\", \\\"{x:1314,y:960,t:1527873026032};\\\", \\\"{x:1317,y:957,t:1527873026048};\\\", \\\"{x:1320,y:955,t:1527873026065};\\\", \\\"{x:1327,y:949,t:1527873026082};\\\", \\\"{x:1331,y:948,t:1527873026099};\\\", \\\"{x:1334,y:945,t:1527873026115};\\\", \\\"{x:1341,y:941,t:1527873026132};\\\", \\\"{x:1349,y:941,t:1527873026149};\\\", \\\"{x:1352,y:941,t:1527873026165};\\\", \\\"{x:1355,y:940,t:1527873026182};\\\", \\\"{x:1358,y:940,t:1527873026199};\\\", \\\"{x:1362,y:940,t:1527873026215};\\\", \\\"{x:1368,y:940,t:1527873026232};\\\", \\\"{x:1373,y:940,t:1527873026249};\\\", \\\"{x:1380,y:940,t:1527873026265};\\\", \\\"{x:1389,y:940,t:1527873026282};\\\", \\\"{x:1393,y:940,t:1527873026298};\\\", \\\"{x:1398,y:940,t:1527873026315};\\\", \\\"{x:1403,y:940,t:1527873026332};\\\", \\\"{x:1410,y:942,t:1527873026349};\\\", \\\"{x:1415,y:944,t:1527873026365};\\\", \\\"{x:1422,y:944,t:1527873026382};\\\", \\\"{x:1428,y:946,t:1527873026399};\\\", \\\"{x:1439,y:947,t:1527873026415};\\\", \\\"{x:1451,y:948,t:1527873026432};\\\", \\\"{x:1466,y:951,t:1527873026449};\\\", \\\"{x:1481,y:954,t:1527873026465};\\\", \\\"{x:1500,y:960,t:1527873026482};\\\", \\\"{x:1517,y:962,t:1527873026499};\\\", \\\"{x:1533,y:966,t:1527873026516};\\\", \\\"{x:1550,y:967,t:1527873026532};\\\", \\\"{x:1574,y:972,t:1527873026549};\\\", \\\"{x:1592,y:977,t:1527873026566};\\\", \\\"{x:1608,y:979,t:1527873026582};\\\", \\\"{x:1621,y:983,t:1527873026598};\\\", \\\"{x:1636,y:988,t:1527873026616};\\\", \\\"{x:1645,y:989,t:1527873026631};\\\", \\\"{x:1652,y:989,t:1527873026649};\\\", \\\"{x:1656,y:989,t:1527873026666};\\\", \\\"{x:1657,y:989,t:1527873026682};\\\", \\\"{x:1658,y:989,t:1527873026699};\\\", \\\"{x:1659,y:991,t:1527873026716};\\\", \\\"{x:1660,y:991,t:1527873026738};\\\", \\\"{x:1661,y:991,t:1527873026810};\\\", \\\"{x:1662,y:991,t:1527873026826};\\\", \\\"{x:1664,y:991,t:1527873026834};\\\", \\\"{x:1664,y:990,t:1527873026851};\\\", \\\"{x:1666,y:990,t:1527873026866};\\\", \\\"{x:1667,y:988,t:1527873026882};\\\", \\\"{x:1667,y:986,t:1527873026906};\\\", \\\"{x:1667,y:985,t:1527873026916};\\\", \\\"{x:1667,y:982,t:1527873026933};\\\", \\\"{x:1667,y:979,t:1527873026949};\\\", \\\"{x:1667,y:978,t:1527873026966};\\\", \\\"{x:1667,y:976,t:1527873026994};\\\", \\\"{x:1667,y:975,t:1527873027019};\\\", \\\"{x:1667,y:974,t:1527873027034};\\\", \\\"{x:1667,y:972,t:1527873027050};\\\", \\\"{x:1666,y:972,t:1527873027066};\\\", \\\"{x:1665,y:972,t:1527873027090};\\\", \\\"{x:1664,y:971,t:1527873027100};\\\", \\\"{x:1663,y:970,t:1527873027116};\\\", \\\"{x:1661,y:970,t:1527873027133};\\\", \\\"{x:1660,y:970,t:1527873027163};\\\", \\\"{x:1659,y:969,t:1527873027170};\\\", \\\"{x:1658,y:969,t:1527873027183};\\\", \\\"{x:1657,y:969,t:1527873027200};\\\", \\\"{x:1655,y:969,t:1527873027216};\\\", \\\"{x:1650,y:969,t:1527873027233};\\\", \\\"{x:1643,y:969,t:1527873027250};\\\", \\\"{x:1638,y:969,t:1527873027266};\\\", \\\"{x:1632,y:969,t:1527873027283};\\\", \\\"{x:1629,y:969,t:1527873027300};\\\", \\\"{x:1625,y:969,t:1527873027316};\\\", \\\"{x:1624,y:969,t:1527873027402};\\\", \\\"{x:1622,y:969,t:1527873027416};\\\", \\\"{x:1621,y:969,t:1527873027433};\\\", \\\"{x:1616,y:968,t:1527873027450};\\\", \\\"{x:1610,y:966,t:1527873027466};\\\", \\\"{x:1604,y:965,t:1527873027483};\\\", \\\"{x:1600,y:964,t:1527873027501};\\\", \\\"{x:1596,y:962,t:1527873027518};\\\", \\\"{x:1591,y:962,t:1527873027533};\\\", \\\"{x:1588,y:962,t:1527873027550};\\\", \\\"{x:1586,y:961,t:1527873027567};\\\", \\\"{x:1585,y:961,t:1527873027583};\\\", \\\"{x:1584,y:960,t:1527873027626};\\\", \\\"{x:1584,y:961,t:1527873027787};\\\", \\\"{x:1585,y:962,t:1527873027799};\\\", \\\"{x:1589,y:963,t:1527873027816};\\\", \\\"{x:1594,y:964,t:1527873027833};\\\", \\\"{x:1597,y:966,t:1527873027849};\\\", \\\"{x:1603,y:967,t:1527873027866};\\\", \\\"{x:1609,y:967,t:1527873027883};\\\", \\\"{x:1613,y:969,t:1527873027900};\\\", \\\"{x:1614,y:969,t:1527873027921};\\\", \\\"{x:1615,y:969,t:1527873028210};\\\", \\\"{x:1615,y:968,t:1527873028260};\\\", \\\"{x:1615,y:967,t:1527873028282};\\\", \\\"{x:1614,y:966,t:1527873028315};\\\", \\\"{x:1613,y:965,t:1527873028355};\\\", \\\"{x:1612,y:964,t:1527873028499};\\\", \\\"{x:1610,y:964,t:1527873028763};\\\", \\\"{x:1609,y:964,t:1527873028770};\\\", \\\"{x:1607,y:964,t:1527873028785};\\\", \\\"{x:1604,y:964,t:1527873028800};\\\", \\\"{x:1599,y:964,t:1527873028817};\\\", \\\"{x:1594,y:964,t:1527873028834};\\\", \\\"{x:1590,y:965,t:1527873028850};\\\", \\\"{x:1588,y:965,t:1527873028868};\\\", \\\"{x:1586,y:965,t:1527873028885};\\\", \\\"{x:1583,y:965,t:1527873028900};\\\", \\\"{x:1579,y:967,t:1527873028918};\\\", \\\"{x:1575,y:967,t:1527873028935};\\\", \\\"{x:1571,y:968,t:1527873028950};\\\", \\\"{x:1567,y:969,t:1527873028968};\\\", \\\"{x:1563,y:970,t:1527873028985};\\\", \\\"{x:1558,y:972,t:1527873029002};\\\", \\\"{x:1556,y:972,t:1527873029017};\\\", \\\"{x:1555,y:972,t:1527873029418};\\\", \\\"{x:1553,y:972,t:1527873029435};\\\", \\\"{x:1551,y:971,t:1527873029452};\\\", \\\"{x:1549,y:971,t:1527873029469};\\\", \\\"{x:1549,y:970,t:1527873029489};\\\", \\\"{x:1548,y:970,t:1527873030003};\\\", \\\"{x:1548,y:969,t:1527873030675};\\\", \\\"{x:1548,y:968,t:1527873030688};\\\", \\\"{x:1548,y:964,t:1527873030703};\\\", \\\"{x:1551,y:962,t:1527873030721};\\\", \\\"{x:1553,y:961,t:1527873030737};\\\", \\\"{x:1554,y:960,t:1527873030753};\\\", \\\"{x:1555,y:959,t:1527873030770};\\\", \\\"{x:1556,y:959,t:1527873030946};\\\", \\\"{x:1558,y:959,t:1527873030954};\\\", \\\"{x:1561,y:961,t:1527873030970};\\\", \\\"{x:1567,y:964,t:1527873030989};\\\", \\\"{x:1571,y:966,t:1527873031005};\\\", \\\"{x:1574,y:969,t:1527873031020};\\\", \\\"{x:1577,y:970,t:1527873031037};\\\", \\\"{x:1579,y:970,t:1527873031054};\\\", \\\"{x:1578,y:969,t:1527873031243};\\\", \\\"{x:1576,y:969,t:1527873031254};\\\", \\\"{x:1566,y:964,t:1527873031272};\\\", \\\"{x:1556,y:960,t:1527873031288};\\\", \\\"{x:1547,y:957,t:1527873031304};\\\", \\\"{x:1537,y:954,t:1527873031322};\\\", \\\"{x:1523,y:952,t:1527873031338};\\\", \\\"{x:1511,y:950,t:1527873031355};\\\", \\\"{x:1505,y:949,t:1527873031371};\\\", \\\"{x:1500,y:949,t:1527873031388};\\\", \\\"{x:1496,y:948,t:1527873031404};\\\", \\\"{x:1491,y:948,t:1527873031422};\\\", \\\"{x:1483,y:948,t:1527873031438};\\\", \\\"{x:1473,y:948,t:1527873031455};\\\", \\\"{x:1462,y:948,t:1527873031471};\\\", \\\"{x:1450,y:948,t:1527873031488};\\\", \\\"{x:1432,y:945,t:1527873031504};\\\", \\\"{x:1407,y:941,t:1527873031522};\\\", \\\"{x:1376,y:931,t:1527873031538};\\\", \\\"{x:1357,y:926,t:1527873031554};\\\", \\\"{x:1340,y:920,t:1527873031571};\\\", \\\"{x:1327,y:917,t:1527873031589};\\\", \\\"{x:1316,y:913,t:1527873031604};\\\", \\\"{x:1301,y:908,t:1527873031621};\\\", \\\"{x:1292,y:904,t:1527873031638};\\\", \\\"{x:1282,y:900,t:1527873031654};\\\", \\\"{x:1272,y:896,t:1527873031671};\\\", \\\"{x:1267,y:894,t:1527873031689};\\\", \\\"{x:1264,y:891,t:1527873031705};\\\", \\\"{x:1262,y:889,t:1527873031721};\\\", \\\"{x:1258,y:885,t:1527873031739};\\\", \\\"{x:1253,y:878,t:1527873031754};\\\", \\\"{x:1249,y:872,t:1527873031771};\\\", \\\"{x:1248,y:870,t:1527873031794};\\\", \\\"{x:1247,y:868,t:1527873031804};\\\", \\\"{x:1244,y:865,t:1527873031821};\\\", \\\"{x:1243,y:862,t:1527873031837};\\\", \\\"{x:1242,y:858,t:1527873031855};\\\", \\\"{x:1241,y:855,t:1527873031870};\\\", \\\"{x:1239,y:851,t:1527873031887};\\\", \\\"{x:1237,y:850,t:1527873031904};\\\", \\\"{x:1237,y:847,t:1527873031921};\\\", \\\"{x:1236,y:846,t:1527873031938};\\\", \\\"{x:1235,y:845,t:1527873031969};\\\", \\\"{x:1234,y:845,t:1527873032347};\\\", \\\"{x:1233,y:845,t:1527873032355};\\\", \\\"{x:1231,y:844,t:1527873032378};\\\", \\\"{x:1229,y:843,t:1527873032394};\\\", \\\"{x:1226,y:841,t:1527873032409};\\\", \\\"{x:1225,y:841,t:1527873032426};\\\", \\\"{x:1225,y:840,t:1527873032442};\\\", \\\"{x:1224,y:840,t:1527873032455};\\\", \\\"{x:1223,y:838,t:1527873032472};\\\", \\\"{x:1221,y:837,t:1527873032683};\\\", \\\"{x:1220,y:836,t:1527873032690};\\\", \\\"{x:1219,y:836,t:1527873032706};\\\", \\\"{x:1218,y:834,t:1527873032725};\\\", \\\"{x:1216,y:833,t:1527873032739};\\\", \\\"{x:1215,y:832,t:1527873032802};\\\", \\\"{x:1214,y:832,t:1527873032834};\\\", \\\"{x:1219,y:833,t:1527873032994};\\\", \\\"{x:1227,y:836,t:1527873033007};\\\", \\\"{x:1239,y:839,t:1527873033022};\\\", \\\"{x:1247,y:841,t:1527873033039};\\\", \\\"{x:1257,y:842,t:1527873033056};\\\", \\\"{x:1262,y:843,t:1527873033072};\\\", \\\"{x:1267,y:843,t:1527873033089};\\\", \\\"{x:1270,y:845,t:1527873033106};\\\", \\\"{x:1271,y:845,t:1527873033122};\\\", \\\"{x:1272,y:845,t:1527873033138};\\\", \\\"{x:1273,y:845,t:1527873033156};\\\", \\\"{x:1275,y:845,t:1527873033172};\\\", \\\"{x:1277,y:845,t:1527873033189};\\\", \\\"{x:1280,y:845,t:1527873033205};\\\", \\\"{x:1282,y:845,t:1527873033222};\\\", \\\"{x:1284,y:844,t:1527873033239};\\\", \\\"{x:1285,y:844,t:1527873033255};\\\", \\\"{x:1286,y:842,t:1527873033273};\\\", \\\"{x:1289,y:841,t:1527873033289};\\\", \\\"{x:1290,y:840,t:1527873033306};\\\", \\\"{x:1291,y:839,t:1527873033323};\\\", \\\"{x:1292,y:838,t:1527873033346};\\\", \\\"{x:1292,y:837,t:1527873033391};\\\", \\\"{x:1292,y:836,t:1527873033425};\\\", \\\"{x:1293,y:836,t:1527873033682};\\\", \\\"{x:1296,y:837,t:1527873033690};\\\", \\\"{x:1303,y:842,t:1527873033706};\\\", \\\"{x:1307,y:845,t:1527873033723};\\\", \\\"{x:1312,y:850,t:1527873033740};\\\", \\\"{x:1317,y:857,t:1527873033757};\\\", \\\"{x:1323,y:863,t:1527873033773};\\\", \\\"{x:1326,y:867,t:1527873033790};\\\", \\\"{x:1327,y:870,t:1527873033807};\\\", \\\"{x:1328,y:871,t:1527873033823};\\\", \\\"{x:1329,y:872,t:1527873033839};\\\", \\\"{x:1330,y:875,t:1527873033899};\\\", \\\"{x:1332,y:877,t:1527873033907};\\\", \\\"{x:1338,y:884,t:1527873033923};\\\", \\\"{x:1343,y:893,t:1527873033941};\\\", \\\"{x:1347,y:897,t:1527873033957};\\\", \\\"{x:1350,y:900,t:1527873033973};\\\", \\\"{x:1354,y:905,t:1527873033991};\\\", \\\"{x:1355,y:906,t:1527873034007};\\\", \\\"{x:1356,y:907,t:1527873034023};\\\", \\\"{x:1356,y:906,t:1527873034147};\\\", \\\"{x:1355,y:905,t:1527873034157};\\\", \\\"{x:1354,y:902,t:1527873034174};\\\", \\\"{x:1354,y:901,t:1527873034190};\\\", \\\"{x:1352,y:897,t:1527873034207};\\\", \\\"{x:1352,y:896,t:1527873034223};\\\", \\\"{x:1352,y:895,t:1527873034240};\\\", \\\"{x:1352,y:894,t:1527873034609};\\\", \\\"{x:1352,y:892,t:1527873034624};\\\", \\\"{x:1352,y:887,t:1527873034640};\\\", \\\"{x:1353,y:880,t:1527873034657};\\\", \\\"{x:1360,y:865,t:1527873034673};\\\", \\\"{x:1365,y:849,t:1527873034690};\\\", \\\"{x:1369,y:838,t:1527873034708};\\\", \\\"{x:1374,y:825,t:1527873034723};\\\", \\\"{x:1377,y:817,t:1527873034741};\\\", \\\"{x:1379,y:812,t:1527873034758};\\\", \\\"{x:1381,y:808,t:1527873034774};\\\", \\\"{x:1381,y:804,t:1527873034791};\\\", \\\"{x:1382,y:803,t:1527873034808};\\\", \\\"{x:1382,y:801,t:1527873034824};\\\", \\\"{x:1382,y:800,t:1527873034841};\\\", \\\"{x:1382,y:795,t:1527873034858};\\\", \\\"{x:1382,y:790,t:1527873034874};\\\", \\\"{x:1382,y:784,t:1527873034890};\\\", \\\"{x:1382,y:779,t:1527873034908};\\\", \\\"{x:1383,y:775,t:1527873034924};\\\", \\\"{x:1383,y:773,t:1527873034941};\\\", \\\"{x:1383,y:772,t:1527873034958};\\\", \\\"{x:1383,y:770,t:1527873034975};\\\", \\\"{x:1383,y:769,t:1527873034991};\\\", \\\"{x:1383,y:767,t:1527873035009};\\\", \\\"{x:1383,y:766,t:1527873035041};\\\", \\\"{x:1382,y:766,t:1527873037514};\\\", \\\"{x:1382,y:765,t:1527873037689};\\\", \\\"{x:1382,y:767,t:1527873039794};\\\", \\\"{x:1382,y:769,t:1527873039803};\\\", \\\"{x:1381,y:771,t:1527873039813};\\\", \\\"{x:1381,y:776,t:1527873039830};\\\", \\\"{x:1380,y:783,t:1527873039846};\\\", \\\"{x:1380,y:788,t:1527873039864};\\\", \\\"{x:1380,y:790,t:1527873039880};\\\", \\\"{x:1380,y:792,t:1527873039896};\\\", \\\"{x:1380,y:793,t:1527873039931};\\\", \\\"{x:1381,y:795,t:1527873039946};\\\", \\\"{x:1384,y:797,t:1527873039963};\\\", \\\"{x:1386,y:799,t:1527873039981};\\\", \\\"{x:1389,y:800,t:1527873039996};\\\", \\\"{x:1391,y:801,t:1527873040014};\\\", \\\"{x:1393,y:803,t:1527873040031};\\\", \\\"{x:1398,y:805,t:1527873040047};\\\", \\\"{x:1400,y:805,t:1527873040064};\\\", \\\"{x:1401,y:806,t:1527873040080};\\\", \\\"{x:1402,y:806,t:1527873040098};\\\", \\\"{x:1403,y:806,t:1527873040113};\\\", \\\"{x:1404,y:806,t:1527873040130};\\\", \\\"{x:1405,y:806,t:1527873040146};\\\", \\\"{x:1406,y:806,t:1527873040163};\\\", \\\"{x:1407,y:805,t:1527873040242};\\\", \\\"{x:1407,y:800,t:1527873040249};\\\", \\\"{x:1403,y:793,t:1527873040263};\\\", \\\"{x:1390,y:774,t:1527873040281};\\\", \\\"{x:1368,y:755,t:1527873040297};\\\", \\\"{x:1350,y:732,t:1527873040313};\\\", \\\"{x:1327,y:712,t:1527873040331};\\\", \\\"{x:1312,y:701,t:1527873040347};\\\", \\\"{x:1301,y:690,t:1527873040363};\\\", \\\"{x:1297,y:685,t:1527873040381};\\\", \\\"{x:1292,y:676,t:1527873040398};\\\", \\\"{x:1289,y:668,t:1527873040415};\\\", \\\"{x:1288,y:661,t:1527873040431};\\\", \\\"{x:1288,y:657,t:1527873040447};\\\", \\\"{x:1288,y:653,t:1527873040464};\\\", \\\"{x:1288,y:648,t:1527873040481};\\\", \\\"{x:1291,y:646,t:1527873040498};\\\", \\\"{x:1293,y:644,t:1527873040514};\\\", \\\"{x:1296,y:642,t:1527873040530};\\\", \\\"{x:1296,y:641,t:1527873040554};\\\", \\\"{x:1298,y:641,t:1527873040565};\\\", \\\"{x:1301,y:638,t:1527873040580};\\\", \\\"{x:1306,y:637,t:1527873040597};\\\", \\\"{x:1309,y:635,t:1527873040614};\\\", \\\"{x:1313,y:633,t:1527873040631};\\\", \\\"{x:1319,y:631,t:1527873040648};\\\", \\\"{x:1325,y:629,t:1527873040665};\\\", \\\"{x:1329,y:628,t:1527873040681};\\\", \\\"{x:1330,y:627,t:1527873040697};\\\", \\\"{x:1331,y:627,t:1527873041139};\\\", \\\"{x:1331,y:628,t:1527873041563};\\\", \\\"{x:1329,y:629,t:1527873041570};\\\", \\\"{x:1323,y:629,t:1527873041581};\\\", \\\"{x:1315,y:629,t:1527873041599};\\\", \\\"{x:1309,y:631,t:1527873041615};\\\", \\\"{x:1305,y:631,t:1527873041632};\\\", \\\"{x:1303,y:631,t:1527873041649};\\\", \\\"{x:1303,y:632,t:1527873041994};\\\", \\\"{x:1304,y:632,t:1527873042018};\\\", \\\"{x:1305,y:632,t:1527873042032};\\\", \\\"{x:1307,y:632,t:1527873042049};\\\", \\\"{x:1307,y:633,t:1527873042065};\\\", \\\"{x:1308,y:633,t:1527873043162};\\\", \\\"{x:1309,y:633,t:1527873043243};\\\", \\\"{x:1309,y:632,t:1527873043251};\\\", \\\"{x:1309,y:631,t:1527873043284};\\\", \\\"{x:1311,y:627,t:1527873043300};\\\", \\\"{x:1311,y:623,t:1527873043319};\\\", \\\"{x:1312,y:616,t:1527873043333};\\\", \\\"{x:1312,y:607,t:1527873043352};\\\", \\\"{x:1312,y:600,t:1527873043368};\\\", \\\"{x:1312,y:596,t:1527873043384};\\\", \\\"{x:1312,y:591,t:1527873043400};\\\", \\\"{x:1312,y:582,t:1527873043417};\\\", \\\"{x:1312,y:576,t:1527873043433};\\\", \\\"{x:1313,y:569,t:1527873043450};\\\", \\\"{x:1313,y:565,t:1527873043467};\\\", \\\"{x:1313,y:559,t:1527873043483};\\\", \\\"{x:1315,y:554,t:1527873043500};\\\", \\\"{x:1316,y:549,t:1527873043517};\\\", \\\"{x:1317,y:542,t:1527873043534};\\\", \\\"{x:1317,y:539,t:1527873043550};\\\", \\\"{x:1317,y:534,t:1527873043567};\\\", \\\"{x:1317,y:530,t:1527873043585};\\\", \\\"{x:1317,y:527,t:1527873043600};\\\", \\\"{x:1317,y:524,t:1527873043617};\\\", \\\"{x:1317,y:521,t:1527873043633};\\\", \\\"{x:1317,y:519,t:1527873043650};\\\", \\\"{x:1317,y:517,t:1527873043667};\\\", \\\"{x:1317,y:514,t:1527873043684};\\\", \\\"{x:1317,y:513,t:1527873043700};\\\", \\\"{x:1317,y:511,t:1527873043718};\\\", \\\"{x:1317,y:510,t:1527873043770};\\\", \\\"{x:1317,y:509,t:1527873043786};\\\", \\\"{x:1317,y:508,t:1527873043810};\\\", \\\"{x:1318,y:508,t:1527873043850};\\\", \\\"{x:1319,y:508,t:1527873044027};\\\", \\\"{x:1319,y:509,t:1527873044035};\\\", \\\"{x:1320,y:513,t:1527873044051};\\\", \\\"{x:1323,y:522,t:1527873044067};\\\", \\\"{x:1325,y:535,t:1527873044085};\\\", \\\"{x:1331,y:552,t:1527873044101};\\\", \\\"{x:1335,y:566,t:1527873044118};\\\", \\\"{x:1339,y:582,t:1527873044135};\\\", \\\"{x:1343,y:595,t:1527873044152};\\\", \\\"{x:1344,y:606,t:1527873044169};\\\", \\\"{x:1346,y:616,t:1527873044185};\\\", \\\"{x:1353,y:636,t:1527873044202};\\\", \\\"{x:1355,y:646,t:1527873044218};\\\", \\\"{x:1358,y:656,t:1527873044235};\\\", \\\"{x:1361,y:670,t:1527873044252};\\\", \\\"{x:1365,y:684,t:1527873044269};\\\", \\\"{x:1369,y:695,t:1527873044285};\\\", \\\"{x:1370,y:703,t:1527873044301};\\\", \\\"{x:1372,y:707,t:1527873044318};\\\", \\\"{x:1373,y:710,t:1527873044334};\\\", \\\"{x:1376,y:717,t:1527873044351};\\\", \\\"{x:1378,y:724,t:1527873044368};\\\", \\\"{x:1382,y:738,t:1527873044385};\\\", \\\"{x:1385,y:750,t:1527873044402};\\\", \\\"{x:1386,y:752,t:1527873044419};\\\", \\\"{x:1386,y:754,t:1527873044435};\\\", \\\"{x:1386,y:756,t:1527873044452};\\\", \\\"{x:1387,y:760,t:1527873044468};\\\", \\\"{x:1387,y:766,t:1527873044485};\\\", \\\"{x:1387,y:772,t:1527873044501};\\\", \\\"{x:1387,y:773,t:1527873044518};\\\", \\\"{x:1389,y:772,t:1527873045386};\\\", \\\"{x:1389,y:764,t:1527873045403};\\\", \\\"{x:1390,y:758,t:1527873045420};\\\", \\\"{x:1391,y:753,t:1527873045436};\\\", \\\"{x:1393,y:748,t:1527873045453};\\\", \\\"{x:1393,y:745,t:1527873045470};\\\", \\\"{x:1394,y:741,t:1527873045486};\\\", \\\"{x:1395,y:738,t:1527873045503};\\\", \\\"{x:1396,y:733,t:1527873045520};\\\", \\\"{x:1397,y:726,t:1527873045537};\\\", \\\"{x:1401,y:715,t:1527873045553};\\\", \\\"{x:1405,y:703,t:1527873045570};\\\", \\\"{x:1408,y:695,t:1527873045586};\\\", \\\"{x:1411,y:685,t:1527873045602};\\\", \\\"{x:1415,y:671,t:1527873045620};\\\", \\\"{x:1418,y:660,t:1527873045637};\\\", \\\"{x:1424,y:646,t:1527873045653};\\\", \\\"{x:1430,y:631,t:1527873045670};\\\", \\\"{x:1432,y:617,t:1527873045687};\\\", \\\"{x:1434,y:604,t:1527873045703};\\\", \\\"{x:1435,y:595,t:1527873045720};\\\", \\\"{x:1436,y:590,t:1527873045737};\\\", \\\"{x:1436,y:584,t:1527873045754};\\\", \\\"{x:1436,y:579,t:1527873045770};\\\", \\\"{x:1436,y:574,t:1527873045786};\\\", \\\"{x:1434,y:566,t:1527873045804};\\\", \\\"{x:1431,y:560,t:1527873045820};\\\", \\\"{x:1427,y:556,t:1527873045837};\\\", \\\"{x:1424,y:553,t:1527873045854};\\\", \\\"{x:1424,y:552,t:1527873045870};\\\", \\\"{x:1423,y:551,t:1527873045888};\\\", \\\"{x:1421,y:550,t:1527873045904};\\\", \\\"{x:1420,y:550,t:1527873046067};\\\", \\\"{x:1419,y:550,t:1527873046090};\\\", \\\"{x:1418,y:550,t:1527873046104};\\\", \\\"{x:1417,y:553,t:1527873046122};\\\", \\\"{x:1415,y:558,t:1527873046138};\\\", \\\"{x:1414,y:558,t:1527873046153};\\\", \\\"{x:1413,y:560,t:1527873046170};\\\", \\\"{x:1413,y:561,t:1527873046189};\\\", \\\"{x:1412,y:562,t:1527873046209};\\\", \\\"{x:1412,y:563,t:1527873046242};\\\", \\\"{x:1411,y:564,t:1527873046258};\\\", \\\"{x:1410,y:564,t:1527873046282};\\\", \\\"{x:1410,y:565,t:1527873046306};\\\", \\\"{x:1410,y:558,t:1527873048340};\\\", \\\"{x:1418,y:541,t:1527873048356};\\\", \\\"{x:1426,y:528,t:1527873048373};\\\", \\\"{x:1434,y:517,t:1527873048390};\\\", \\\"{x:1439,y:507,t:1527873048406};\\\", \\\"{x:1440,y:503,t:1527873048423};\\\", \\\"{x:1442,y:500,t:1527873048440};\\\", \\\"{x:1442,y:495,t:1527873048456};\\\", \\\"{x:1442,y:492,t:1527873048472};\\\", \\\"{x:1442,y:487,t:1527873048490};\\\", \\\"{x:1442,y:485,t:1527873048507};\\\", \\\"{x:1442,y:483,t:1527873048523};\\\", \\\"{x:1442,y:482,t:1527873048540};\\\", \\\"{x:1442,y:480,t:1527873048555};\\\", \\\"{x:1442,y:478,t:1527873048578};\\\", \\\"{x:1440,y:475,t:1527873048590};\\\", \\\"{x:1436,y:472,t:1527873048606};\\\", \\\"{x:1432,y:467,t:1527873048623};\\\", \\\"{x:1429,y:463,t:1527873048639};\\\", \\\"{x:1426,y:460,t:1527873048656};\\\", \\\"{x:1426,y:459,t:1527873048673};\\\", \\\"{x:1424,y:457,t:1527873048689};\\\", \\\"{x:1423,y:455,t:1527873048707};\\\", \\\"{x:1422,y:455,t:1527873048753};\\\", \\\"{x:1422,y:454,t:1527873048769};\\\", \\\"{x:1421,y:453,t:1527873048809};\\\", \\\"{x:1421,y:452,t:1527873048841};\\\", \\\"{x:1420,y:452,t:1527873048856};\\\", \\\"{x:1420,y:451,t:1527873048874};\\\", \\\"{x:1420,y:450,t:1527873048890};\\\", \\\"{x:1420,y:449,t:1527873048914};\\\", \\\"{x:1420,y:453,t:1527873049186};\\\", \\\"{x:1420,y:462,t:1527873049194};\\\", \\\"{x:1420,y:469,t:1527873049207};\\\", \\\"{x:1424,y:485,t:1527873049223};\\\", \\\"{x:1428,y:498,t:1527873049240};\\\", \\\"{x:1432,y:513,t:1527873049257};\\\", \\\"{x:1440,y:534,t:1527873049274};\\\", \\\"{x:1449,y:552,t:1527873049290};\\\", \\\"{x:1455,y:574,t:1527873049307};\\\", \\\"{x:1460,y:598,t:1527873049324};\\\", \\\"{x:1471,y:628,t:1527873049344};\\\", \\\"{x:1479,y:653,t:1527873049360};\\\", \\\"{x:1485,y:673,t:1527873049377};\\\", \\\"{x:1490,y:694,t:1527873049394};\\\", \\\"{x:1496,y:715,t:1527873049409};\\\", \\\"{x:1501,y:732,t:1527873049426};\\\", \\\"{x:1507,y:747,t:1527873049444};\\\", \\\"{x:1510,y:758,t:1527873049460};\\\", \\\"{x:1515,y:776,t:1527873049476};\\\", \\\"{x:1517,y:785,t:1527873049493};\\\", \\\"{x:1519,y:788,t:1527873049510};\\\", \\\"{x:1519,y:791,t:1527873049527};\\\", \\\"{x:1519,y:794,t:1527873049543};\\\", \\\"{x:1519,y:797,t:1527873049560};\\\", \\\"{x:1520,y:798,t:1527873049576};\\\", \\\"{x:1520,y:800,t:1527873049594};\\\", \\\"{x:1520,y:802,t:1527873049610};\\\", \\\"{x:1520,y:805,t:1527873049627};\\\", \\\"{x:1521,y:810,t:1527873049644};\\\", \\\"{x:1521,y:817,t:1527873049660};\\\", \\\"{x:1521,y:820,t:1527873049676};\\\", \\\"{x:1520,y:822,t:1527873049693};\\\", \\\"{x:1519,y:824,t:1527873049711};\\\", \\\"{x:1518,y:826,t:1527873049772};\\\", \\\"{x:1518,y:827,t:1527873049812};\\\", \\\"{x:1517,y:827,t:1527873049828};\\\", \\\"{x:1516,y:827,t:1527873049844};\\\", \\\"{x:1513,y:827,t:1527873049860};\\\", \\\"{x:1509,y:827,t:1527873049877};\\\", \\\"{x:1506,y:827,t:1527873049894};\\\", \\\"{x:1504,y:827,t:1527873049916};\\\", \\\"{x:1503,y:827,t:1527873049932};\\\", \\\"{x:1501,y:827,t:1527873049964};\\\", \\\"{x:1500,y:827,t:1527873049980};\\\", \\\"{x:1498,y:827,t:1527873050004};\\\", \\\"{x:1497,y:827,t:1527873050020};\\\", \\\"{x:1495,y:827,t:1527873050036};\\\", \\\"{x:1493,y:826,t:1527873050044};\\\", \\\"{x:1491,y:826,t:1527873050060};\\\", \\\"{x:1490,y:825,t:1527873050078};\\\", \\\"{x:1489,y:825,t:1527873050093};\\\", \\\"{x:1486,y:825,t:1527873050111};\\\", \\\"{x:1485,y:825,t:1527873050127};\\\", \\\"{x:1484,y:825,t:1527873050157};\\\", \\\"{x:1483,y:825,t:1527873050189};\\\", \\\"{x:1482,y:825,t:1527873050207};\\\", \\\"{x:1481,y:825,t:1527873050501};\\\", \\\"{x:1481,y:826,t:1527873050533};\\\", \\\"{x:1481,y:827,t:1527873050549};\\\", \\\"{x:1481,y:828,t:1527873050621};\\\", \\\"{x:1480,y:829,t:1527873054878};\\\", \\\"{x:1462,y:829,t:1527873054886};\\\", \\\"{x:1426,y:829,t:1527873054899};\\\", \\\"{x:1316,y:819,t:1527873054916};\\\", \\\"{x:1099,y:804,t:1527873054932};\\\", \\\"{x:930,y:782,t:1527873054948};\\\", \\\"{x:753,y:753,t:1527873054965};\\\", \\\"{x:581,y:728,t:1527873054983};\\\", \\\"{x:404,y:704,t:1527873054999};\\\", \\\"{x:241,y:679,t:1527873055015};\\\", \\\"{x:97,y:658,t:1527873055033};\\\", \\\"{x:0,y:639,t:1527873055050};\\\", \\\"{x:0,y:622,t:1527873055066};\\\", \\\"{x:0,y:598,t:1527873055083};\\\", \\\"{x:0,y:582,t:1527873055100};\\\", \\\"{x:0,y:578,t:1527873055115};\\\", \\\"{x:0,y:575,t:1527873055133};\\\", \\\"{x:0,y:572,t:1527873055149};\\\", \\\"{x:0,y:569,t:1527873055166};\\\", \\\"{x:0,y:566,t:1527873055183};\\\", \\\"{x:4,y:562,t:1527873055199};\\\", \\\"{x:13,y:559,t:1527873055216};\\\", \\\"{x:34,y:556,t:1527873055233};\\\", \\\"{x:56,y:554,t:1527873055251};\\\", \\\"{x:85,y:554,t:1527873055267};\\\", \\\"{x:116,y:554,t:1527873055282};\\\", \\\"{x:159,y:554,t:1527873055308};\\\", \\\"{x:183,y:556,t:1527873055324};\\\", \\\"{x:214,y:561,t:1527873055341};\\\", \\\"{x:227,y:565,t:1527873055357};\\\", \\\"{x:234,y:568,t:1527873055374};\\\", \\\"{x:235,y:568,t:1527873055390};\\\", \\\"{x:235,y:569,t:1527873055605};\\\", \\\"{x:233,y:571,t:1527873055612};\\\", \\\"{x:229,y:573,t:1527873055624};\\\", \\\"{x:222,y:577,t:1527873055642};\\\", \\\"{x:218,y:580,t:1527873055658};\\\", \\\"{x:212,y:586,t:1527873055675};\\\", \\\"{x:210,y:589,t:1527873055691};\\\", \\\"{x:210,y:590,t:1527873055707};\\\", \\\"{x:224,y:594,t:1527873055724};\\\", \\\"{x:258,y:600,t:1527873055741};\\\", \\\"{x:356,y:601,t:1527873055760};\\\", \\\"{x:483,y:604,t:1527873055775};\\\", \\\"{x:614,y:604,t:1527873055791};\\\", \\\"{x:741,y:604,t:1527873055808};\\\", \\\"{x:854,y:604,t:1527873055825};\\\", \\\"{x:932,y:604,t:1527873055841};\\\", \\\"{x:961,y:604,t:1527873055858};\\\", \\\"{x:970,y:604,t:1527873055875};\\\", \\\"{x:971,y:604,t:1527873055890};\\\", \\\"{x:970,y:603,t:1527873055908};\\\", \\\"{x:959,y:601,t:1527873055924};\\\", \\\"{x:947,y:596,t:1527873055941};\\\", \\\"{x:936,y:592,t:1527873055957};\\\", \\\"{x:929,y:588,t:1527873055975};\\\", \\\"{x:924,y:585,t:1527873055991};\\\", \\\"{x:920,y:583,t:1527873056008};\\\", \\\"{x:913,y:580,t:1527873056026};\\\", \\\"{x:899,y:578,t:1527873056040};\\\", \\\"{x:884,y:575,t:1527873056057};\\\", \\\"{x:867,y:575,t:1527873056075};\\\", \\\"{x:850,y:575,t:1527873056092};\\\", \\\"{x:824,y:575,t:1527873056108};\\\", \\\"{x:782,y:575,t:1527873056125};\\\", \\\"{x:756,y:575,t:1527873056142};\\\", \\\"{x:732,y:575,t:1527873056157};\\\", \\\"{x:710,y:574,t:1527873056176};\\\", \\\"{x:692,y:571,t:1527873056192};\\\", \\\"{x:681,y:569,t:1527873056208};\\\", \\\"{x:679,y:569,t:1527873056225};\\\", \\\"{x:678,y:569,t:1527873056242};\\\", \\\"{x:676,y:569,t:1527873056261};\\\", \\\"{x:674,y:569,t:1527873056275};\\\", \\\"{x:671,y:569,t:1527873056292};\\\", \\\"{x:663,y:570,t:1527873056308};\\\", \\\"{x:659,y:572,t:1527873056325};\\\", \\\"{x:657,y:574,t:1527873056342};\\\", \\\"{x:655,y:575,t:1527873056360};\\\", \\\"{x:653,y:578,t:1527873056375};\\\", \\\"{x:652,y:581,t:1527873056392};\\\", \\\"{x:649,y:584,t:1527873056409};\\\", \\\"{x:648,y:586,t:1527873056437};\\\", \\\"{x:647,y:586,t:1527873056501};\\\", \\\"{x:645,y:586,t:1527873056509};\\\", \\\"{x:645,y:588,t:1527873056525};\\\", \\\"{x:644,y:588,t:1527873056542};\\\", \\\"{x:643,y:588,t:1527873056560};\\\", \\\"{x:643,y:589,t:1527873056876};\\\", \\\"{x:636,y:598,t:1527873056892};\\\", \\\"{x:627,y:608,t:1527873056909};\\\", \\\"{x:612,y:622,t:1527873056926};\\\", \\\"{x:598,y:633,t:1527873056942};\\\", \\\"{x:583,y:641,t:1527873056958};\\\", \\\"{x:571,y:648,t:1527873056976};\\\", \\\"{x:566,y:650,t:1527873056991};\\\", \\\"{x:565,y:652,t:1527873057009};\\\", \\\"{x:562,y:654,t:1527873057026};\\\", \\\"{x:559,y:660,t:1527873057042};\\\", \\\"{x:555,y:668,t:1527873057059};\\\", \\\"{x:549,y:674,t:1527873057076};\\\", \\\"{x:543,y:682,t:1527873057093};\\\", \\\"{x:541,y:684,t:1527873057109};\\\", \\\"{x:538,y:688,t:1527873057126};\\\", \\\"{x:533,y:694,t:1527873057143};\\\", \\\"{x:525,y:706,t:1527873057160};\\\", \\\"{x:520,y:713,t:1527873057175};\\\", \\\"{x:516,y:718,t:1527873057193};\\\", \\\"{x:516,y:719,t:1527873057209};\\\", \\\"{x:515,y:719,t:1527873057226};\\\" ] }, { \\\"rt\\\": 112755, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 367618, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"QGUGU\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -I -F -F -H -H -H -J -H -H -F -O -O -I -I \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:518,y:719,t:1527873075365};\\\", \\\"{x:542,y:719,t:1527873075373};\\\", \\\"{x:636,y:697,t:1527873075391};\\\", \\\"{x:758,y:661,t:1527873075407};\\\", \\\"{x:857,y:623,t:1527873075423};\\\", \\\"{x:874,y:614,t:1527873075441};\\\", \\\"{x:874,y:610,t:1527873075476};\\\", \\\"{x:879,y:584,t:1527873075491};\\\", \\\"{x:883,y:451,t:1527873075507};\\\", \\\"{x:885,y:185,t:1527873075524};\\\", \\\"{x:885,y:11,t:1527873075540};\\\", \\\"{x:894,y:0,t:1527873075557};\\\", \\\"{x:912,y:0,t:1527873075574};\\\", \\\"{x:940,y:0,t:1527873075590};\\\", \\\"{x:968,y:0,t:1527873075607};\\\", \\\"{x:985,y:0,t:1527873075624};\\\", \\\"{x:999,y:0,t:1527873075641};\\\", \\\"{x:1009,y:4,t:1527873075658};\\\", \\\"{x:1021,y:15,t:1527873075674};\\\", \\\"{x:1029,y:29,t:1527873075691};\\\", \\\"{x:1034,y:42,t:1527873075708};\\\", \\\"{x:1041,y:62,t:1527873075723};\\\", \\\"{x:1052,y:96,t:1527873075741};\\\", \\\"{x:1063,y:126,t:1527873075758};\\\", \\\"{x:1080,y:162,t:1527873075775};\\\", \\\"{x:1103,y:199,t:1527873075790};\\\", \\\"{x:1135,y:237,t:1527873075809};\\\", \\\"{x:1179,y:274,t:1527873075824};\\\", \\\"{x:1236,y:314,t:1527873075841};\\\", \\\"{x:1299,y:356,t:1527873075858};\\\", \\\"{x:1353,y:385,t:1527873075874};\\\", \\\"{x:1391,y:407,t:1527873075891};\\\", \\\"{x:1435,y:432,t:1527873075908};\\\", \\\"{x:1470,y:451,t:1527873075924};\\\", \\\"{x:1523,y:490,t:1527873075941};\\\", \\\"{x:1562,y:522,t:1527873075959};\\\", \\\"{x:1590,y:555,t:1527873075975};\\\", \\\"{x:1612,y:586,t:1527873075991};\\\", \\\"{x:1624,y:609,t:1527873076009};\\\", \\\"{x:1632,y:623,t:1527873076024};\\\", \\\"{x:1635,y:639,t:1527873076041};\\\", \\\"{x:1638,y:653,t:1527873076058};\\\", \\\"{x:1639,y:666,t:1527873076075};\\\", \\\"{x:1639,y:675,t:1527873076091};\\\", \\\"{x:1637,y:684,t:1527873076108};\\\", \\\"{x:1630,y:690,t:1527873076124};\\\", \\\"{x:1629,y:691,t:1527873076141};\\\", \\\"{x:1630,y:697,t:1527873076214};\\\", \\\"{x:1634,y:707,t:1527873076225};\\\", \\\"{x:1643,y:725,t:1527873076240};\\\", \\\"{x:1648,y:739,t:1527873076257};\\\", \\\"{x:1657,y:758,t:1527873076275};\\\", \\\"{x:1667,y:775,t:1527873076291};\\\", \\\"{x:1679,y:794,t:1527873076308};\\\", \\\"{x:1684,y:802,t:1527873076324};\\\", \\\"{x:1688,y:806,t:1527873076341};\\\", \\\"{x:1690,y:808,t:1527873076358};\\\", \\\"{x:1688,y:808,t:1527873076412};\\\", \\\"{x:1687,y:808,t:1527873076425};\\\", \\\"{x:1682,y:806,t:1527873076441};\\\", \\\"{x:1678,y:805,t:1527873076458};\\\", \\\"{x:1674,y:802,t:1527873076475};\\\", \\\"{x:1671,y:800,t:1527873076491};\\\", \\\"{x:1668,y:798,t:1527873076508};\\\", \\\"{x:1665,y:793,t:1527873076525};\\\", \\\"{x:1664,y:788,t:1527873076541};\\\", \\\"{x:1663,y:783,t:1527873076558};\\\", \\\"{x:1661,y:779,t:1527873076575};\\\", \\\"{x:1660,y:772,t:1527873076592};\\\", \\\"{x:1659,y:763,t:1527873076610};\\\", \\\"{x:1656,y:752,t:1527873076626};\\\", \\\"{x:1654,y:738,t:1527873076641};\\\", \\\"{x:1649,y:722,t:1527873076659};\\\", \\\"{x:1644,y:710,t:1527873076676};\\\", \\\"{x:1639,y:702,t:1527873076691};\\\", \\\"{x:1636,y:699,t:1527873076708};\\\", \\\"{x:1628,y:690,t:1527873076724};\\\", \\\"{x:1620,y:684,t:1527873076742};\\\", \\\"{x:1609,y:681,t:1527873076759};\\\", \\\"{x:1589,y:675,t:1527873076775};\\\", \\\"{x:1570,y:670,t:1527873076793};\\\", \\\"{x:1548,y:665,t:1527873076809};\\\", \\\"{x:1528,y:661,t:1527873076824};\\\", \\\"{x:1511,y:654,t:1527873076842};\\\", \\\"{x:1487,y:646,t:1527873076858};\\\", \\\"{x:1466,y:640,t:1527873076875};\\\", \\\"{x:1447,y:636,t:1527873076892};\\\", \\\"{x:1444,y:636,t:1527873076908};\\\", \\\"{x:1440,y:634,t:1527873076925};\\\", \\\"{x:1436,y:632,t:1527873076942};\\\", \\\"{x:1432,y:628,t:1527873076958};\\\", \\\"{x:1425,y:624,t:1527873076975};\\\", \\\"{x:1421,y:621,t:1527873076992};\\\", \\\"{x:1419,y:620,t:1527873077009};\\\", \\\"{x:1413,y:616,t:1527873077025};\\\", \\\"{x:1409,y:612,t:1527873077042};\\\", \\\"{x:1400,y:607,t:1527873077058};\\\", \\\"{x:1396,y:603,t:1527873077074};\\\", \\\"{x:1391,y:594,t:1527873077092};\\\", \\\"{x:1384,y:587,t:1527873077108};\\\", \\\"{x:1380,y:583,t:1527873077125};\\\", \\\"{x:1375,y:579,t:1527873077142};\\\", \\\"{x:1373,y:576,t:1527873077158};\\\", \\\"{x:1370,y:573,t:1527873077175};\\\", \\\"{x:1362,y:563,t:1527873077193};\\\", \\\"{x:1357,y:546,t:1527873077209};\\\", \\\"{x:1356,y:526,t:1527873077225};\\\", \\\"{x:1356,y:505,t:1527873077243};\\\", \\\"{x:1363,y:487,t:1527873077259};\\\", \\\"{x:1370,y:474,t:1527873077275};\\\", \\\"{x:1382,y:461,t:1527873077293};\\\", \\\"{x:1387,y:456,t:1527873077308};\\\", \\\"{x:1387,y:455,t:1527873077389};\\\", \\\"{x:1384,y:456,t:1527873077405};\\\", \\\"{x:1384,y:457,t:1527873077413};\\\", \\\"{x:1382,y:458,t:1527873077425};\\\", \\\"{x:1376,y:464,t:1527873077442};\\\", \\\"{x:1372,y:469,t:1527873077459};\\\", \\\"{x:1370,y:472,t:1527873077475};\\\", \\\"{x:1369,y:474,t:1527873077492};\\\", \\\"{x:1368,y:474,t:1527873077509};\\\", \\\"{x:1368,y:475,t:1527873077525};\\\", \\\"{x:1366,y:476,t:1527873077542};\\\", \\\"{x:1363,y:477,t:1527873077559};\\\", \\\"{x:1361,y:478,t:1527873077575};\\\", \\\"{x:1358,y:480,t:1527873077592};\\\", \\\"{x:1355,y:481,t:1527873077610};\\\", \\\"{x:1349,y:483,t:1527873077625};\\\", \\\"{x:1343,y:486,t:1527873077643};\\\", \\\"{x:1339,y:487,t:1527873077660};\\\", \\\"{x:1336,y:489,t:1527873077676};\\\", \\\"{x:1333,y:489,t:1527873077691};\\\", \\\"{x:1331,y:491,t:1527873077709};\\\", \\\"{x:1330,y:491,t:1527873077748};\\\", \\\"{x:1330,y:492,t:1527873077788};\\\", \\\"{x:1329,y:492,t:1527873077812};\\\", \\\"{x:1329,y:493,t:1527873077825};\\\", \\\"{x:1328,y:494,t:1527873077842};\\\", \\\"{x:1328,y:495,t:1527873077989};\\\", \\\"{x:1327,y:495,t:1527873078013};\\\", \\\"{x:1325,y:495,t:1527873078182};\\\", \\\"{x:1323,y:497,t:1527873078269};\\\", \\\"{x:1321,y:498,t:1527873078285};\\\", \\\"{x:1320,y:498,t:1527873078303};\\\", \\\"{x:1318,y:499,t:1527873078326};\\\", \\\"{x:1317,y:499,t:1527873078348};\\\", \\\"{x:1316,y:500,t:1527873078364};\\\", \\\"{x:1316,y:501,t:1527873078376};\\\", \\\"{x:1314,y:501,t:1527873078391};\\\", \\\"{x:1313,y:503,t:1527873078409};\\\", \\\"{x:1310,y:509,t:1527873078426};\\\", \\\"{x:1306,y:526,t:1527873078443};\\\", \\\"{x:1300,y:543,t:1527873078459};\\\", \\\"{x:1296,y:562,t:1527873078476};\\\", \\\"{x:1292,y:571,t:1527873078492};\\\", \\\"{x:1292,y:576,t:1527873078509};\\\", \\\"{x:1290,y:582,t:1527873078526};\\\", \\\"{x:1290,y:590,t:1527873078544};\\\", \\\"{x:1290,y:605,t:1527873078559};\\\", \\\"{x:1291,y:619,t:1527873078576};\\\", \\\"{x:1292,y:629,t:1527873078593};\\\", \\\"{x:1294,y:637,t:1527873078609};\\\", \\\"{x:1294,y:640,t:1527873078626};\\\", \\\"{x:1295,y:644,t:1527873078643};\\\", \\\"{x:1296,y:647,t:1527873078659};\\\", \\\"{x:1298,y:652,t:1527873078676};\\\", \\\"{x:1299,y:653,t:1527873078877};\\\", \\\"{x:1302,y:659,t:1527873078893};\\\", \\\"{x:1303,y:660,t:1527873078925};\\\", \\\"{x:1304,y:658,t:1527873079998};\\\", \\\"{x:1304,y:654,t:1527873080010};\\\", \\\"{x:1307,y:635,t:1527873080028};\\\", \\\"{x:1313,y:605,t:1527873080044};\\\", \\\"{x:1320,y:556,t:1527873080061};\\\", \\\"{x:1323,y:534,t:1527873080077};\\\", \\\"{x:1324,y:528,t:1527873080094};\\\", \\\"{x:1324,y:526,t:1527873080117};\\\", \\\"{x:1324,y:525,t:1527873080127};\\\", \\\"{x:1324,y:524,t:1527873080173};\\\", \\\"{x:1324,y:523,t:1527873080381};\\\", \\\"{x:1324,y:522,t:1527873080395};\\\", \\\"{x:1324,y:519,t:1527873080411};\\\", \\\"{x:1323,y:515,t:1527873080427};\\\", \\\"{x:1321,y:508,t:1527873080445};\\\", \\\"{x:1320,y:507,t:1527873080461};\\\", \\\"{x:1320,y:505,t:1527873080966};\\\", \\\"{x:1317,y:503,t:1527873080977};\\\", \\\"{x:1315,y:501,t:1527873080995};\\\", \\\"{x:1314,y:501,t:1527873081012};\\\", \\\"{x:1313,y:500,t:1527873081029};\\\", \\\"{x:1312,y:499,t:1527873081061};\\\", \\\"{x:1314,y:501,t:1527873094061};\\\", \\\"{x:1316,y:509,t:1527873094070};\\\", \\\"{x:1319,y:519,t:1527873094086};\\\", \\\"{x:1321,y:528,t:1527873094103};\\\", \\\"{x:1321,y:533,t:1527873094120};\\\", \\\"{x:1324,y:537,t:1527873094136};\\\", \\\"{x:1324,y:541,t:1527873094152};\\\", \\\"{x:1325,y:548,t:1527873094170};\\\", \\\"{x:1327,y:553,t:1527873094187};\\\", \\\"{x:1327,y:559,t:1527873094202};\\\", \\\"{x:1328,y:565,t:1527873094220};\\\", \\\"{x:1329,y:574,t:1527873094237};\\\", \\\"{x:1329,y:579,t:1527873094253};\\\", \\\"{x:1329,y:583,t:1527873094269};\\\", \\\"{x:1329,y:587,t:1527873094286};\\\", \\\"{x:1329,y:594,t:1527873094303};\\\", \\\"{x:1330,y:602,t:1527873094320};\\\", \\\"{x:1331,y:608,t:1527873094336};\\\", \\\"{x:1333,y:619,t:1527873094353};\\\", \\\"{x:1335,y:629,t:1527873094369};\\\", \\\"{x:1336,y:641,t:1527873094386};\\\", \\\"{x:1337,y:648,t:1527873094403};\\\", \\\"{x:1338,y:655,t:1527873094419};\\\", \\\"{x:1340,y:664,t:1527873094436};\\\", \\\"{x:1341,y:671,t:1527873094453};\\\", \\\"{x:1342,y:681,t:1527873094469};\\\", \\\"{x:1344,y:689,t:1527873094487};\\\", \\\"{x:1345,y:695,t:1527873094503};\\\", \\\"{x:1345,y:701,t:1527873094520};\\\", \\\"{x:1345,y:706,t:1527873094537};\\\", \\\"{x:1345,y:712,t:1527873094553};\\\", \\\"{x:1345,y:718,t:1527873094569};\\\", \\\"{x:1346,y:723,t:1527873094587};\\\", \\\"{x:1346,y:729,t:1527873094603};\\\", \\\"{x:1348,y:737,t:1527873094619};\\\", \\\"{x:1349,y:742,t:1527873094636};\\\", \\\"{x:1349,y:744,t:1527873094653};\\\", \\\"{x:1351,y:749,t:1527873094668};\\\", \\\"{x:1351,y:751,t:1527873094686};\\\", \\\"{x:1353,y:754,t:1527873094703};\\\", \\\"{x:1353,y:756,t:1527873094718};\\\", \\\"{x:1354,y:757,t:1527873094748};\\\", \\\"{x:1355,y:758,t:1527873094756};\\\", \\\"{x:1355,y:759,t:1527873094768};\\\", \\\"{x:1356,y:760,t:1527873094788};\\\", \\\"{x:1356,y:761,t:1527873094813};\\\", \\\"{x:1357,y:761,t:1527873094828};\\\", \\\"{x:1357,y:763,t:1527873094845};\\\", \\\"{x:1357,y:765,t:1527873094852};\\\", \\\"{x:1359,y:767,t:1527873094876};\\\", \\\"{x:1359,y:769,t:1527873094892};\\\", \\\"{x:1359,y:771,t:1527873094909};\\\", \\\"{x:1360,y:773,t:1527873094949};\\\", \\\"{x:1360,y:774,t:1527873094957};\\\", \\\"{x:1361,y:775,t:1527873094970};\\\", \\\"{x:1362,y:777,t:1527873094986};\\\", \\\"{x:1363,y:778,t:1527873095005};\\\", \\\"{x:1364,y:778,t:1527873095020};\\\", \\\"{x:1364,y:779,t:1527873095036};\\\", \\\"{x:1365,y:779,t:1527873095053};\\\", \\\"{x:1367,y:780,t:1527873095070};\\\", \\\"{x:1369,y:780,t:1527873095140};\\\", \\\"{x:1371,y:780,t:1527873095156};\\\", \\\"{x:1373,y:780,t:1527873095170};\\\", \\\"{x:1376,y:778,t:1527873095186};\\\", \\\"{x:1377,y:777,t:1527873095203};\\\", \\\"{x:1380,y:774,t:1527873095220};\\\", \\\"{x:1381,y:774,t:1527873095293};\\\", \\\"{x:1381,y:773,t:1527873095309};\\\", \\\"{x:1381,y:772,t:1527873095320};\\\", \\\"{x:1381,y:771,t:1527873095341};\\\", \\\"{x:1382,y:770,t:1527873095381};\\\", \\\"{x:1382,y:769,t:1527873095485};\\\", \\\"{x:1382,y:768,t:1527873095501};\\\", \\\"{x:1382,y:767,t:1527873095532};\\\", \\\"{x:1382,y:766,t:1527873095557};\\\", \\\"{x:1382,y:765,t:1527873095597};\\\", \\\"{x:1382,y:764,t:1527873099541};\\\", \\\"{x:1382,y:757,t:1527873099556};\\\", \\\"{x:1388,y:718,t:1527873099573};\\\", \\\"{x:1390,y:706,t:1527873099589};\\\", \\\"{x:1394,y:693,t:1527873099607};\\\", \\\"{x:1397,y:683,t:1527873099622};\\\", \\\"{x:1400,y:674,t:1527873099639};\\\", \\\"{x:1402,y:661,t:1527873099656};\\\", \\\"{x:1403,y:651,t:1527873099672};\\\", \\\"{x:1403,y:643,t:1527873099689};\\\", \\\"{x:1404,y:637,t:1527873099705};\\\", \\\"{x:1406,y:632,t:1527873099721};\\\", \\\"{x:1406,y:628,t:1527873099739};\\\", \\\"{x:1406,y:627,t:1527873099756};\\\", \\\"{x:1406,y:625,t:1527873099796};\\\", \\\"{x:1406,y:624,t:1527873099806};\\\", \\\"{x:1406,y:621,t:1527873099822};\\\", \\\"{x:1406,y:617,t:1527873099840};\\\", \\\"{x:1406,y:615,t:1527873099856};\\\", \\\"{x:1405,y:611,t:1527873099872};\\\", \\\"{x:1405,y:608,t:1527873099889};\\\", \\\"{x:1405,y:605,t:1527873099906};\\\", \\\"{x:1405,y:603,t:1527873099923};\\\", \\\"{x:1405,y:601,t:1527873099939};\\\", \\\"{x:1405,y:599,t:1527873099956};\\\", \\\"{x:1405,y:597,t:1527873099972};\\\", \\\"{x:1405,y:592,t:1527873099990};\\\", \\\"{x:1405,y:588,t:1527873100007};\\\", \\\"{x:1405,y:587,t:1527873100023};\\\", \\\"{x:1405,y:584,t:1527873100039};\\\", \\\"{x:1405,y:583,t:1527873100056};\\\", \\\"{x:1405,y:581,t:1527873100074};\\\", \\\"{x:1405,y:580,t:1527873100089};\\\", \\\"{x:1405,y:578,t:1527873100106};\\\", \\\"{x:1405,y:573,t:1527873100124};\\\", \\\"{x:1405,y:568,t:1527873100140};\\\", \\\"{x:1407,y:563,t:1527873100157};\\\", \\\"{x:1408,y:559,t:1527873100173};\\\", \\\"{x:1410,y:557,t:1527873100197};\\\", \\\"{x:1410,y:556,t:1527873100588};\\\", \\\"{x:1411,y:556,t:1527873100676};\\\", \\\"{x:1411,y:557,t:1527873100700};\\\", \\\"{x:1411,y:558,t:1527873100725};\\\", \\\"{x:1413,y:559,t:1527873100741};\\\", \\\"{x:1413,y:560,t:1527873100757};\\\", \\\"{x:1413,y:561,t:1527873100788};\\\", \\\"{x:1414,y:562,t:1527873100829};\\\", \\\"{x:1414,y:563,t:1527873100877};\\\", \\\"{x:1414,y:564,t:1527873100890};\\\", \\\"{x:1415,y:565,t:1527873100906};\\\", \\\"{x:1416,y:566,t:1527873100988};\\\", \\\"{x:1417,y:569,t:1527873102182};\\\", \\\"{x:1417,y:572,t:1527873102191};\\\", \\\"{x:1417,y:577,t:1527873102208};\\\", \\\"{x:1418,y:584,t:1527873102224};\\\", \\\"{x:1418,y:590,t:1527873102241};\\\", \\\"{x:1419,y:596,t:1527873102258};\\\", \\\"{x:1420,y:602,t:1527873102275};\\\", \\\"{x:1422,y:612,t:1527873102291};\\\", \\\"{x:1424,y:623,t:1527873102307};\\\", \\\"{x:1425,y:643,t:1527873102324};\\\", \\\"{x:1425,y:651,t:1527873102341};\\\", \\\"{x:1425,y:658,t:1527873102358};\\\", \\\"{x:1425,y:667,t:1527873102375};\\\", \\\"{x:1426,y:681,t:1527873102392};\\\", \\\"{x:1427,y:695,t:1527873102407};\\\", \\\"{x:1427,y:710,t:1527873102424};\\\", \\\"{x:1427,y:725,t:1527873102441};\\\", \\\"{x:1427,y:741,t:1527873102457};\\\", \\\"{x:1424,y:758,t:1527873102475};\\\", \\\"{x:1421,y:775,t:1527873102490};\\\", \\\"{x:1416,y:792,t:1527873102507};\\\", \\\"{x:1406,y:819,t:1527873102524};\\\", \\\"{x:1402,y:837,t:1527873102541};\\\", \\\"{x:1397,y:848,t:1527873102557};\\\", \\\"{x:1394,y:853,t:1527873102574};\\\", \\\"{x:1393,y:857,t:1527873102591};\\\", \\\"{x:1392,y:859,t:1527873102608};\\\", \\\"{x:1392,y:860,t:1527873102624};\\\", \\\"{x:1391,y:865,t:1527873102642};\\\", \\\"{x:1391,y:867,t:1527873102657};\\\", \\\"{x:1391,y:869,t:1527873102674};\\\", \\\"{x:1390,y:871,t:1527873102692};\\\", \\\"{x:1390,y:872,t:1527873102707};\\\", \\\"{x:1390,y:876,t:1527873102724};\\\", \\\"{x:1391,y:881,t:1527873102741};\\\", \\\"{x:1394,y:886,t:1527873102758};\\\", \\\"{x:1394,y:891,t:1527873102775};\\\", \\\"{x:1396,y:897,t:1527873102792};\\\", \\\"{x:1398,y:900,t:1527873102807};\\\", \\\"{x:1398,y:903,t:1527873102824};\\\", \\\"{x:1402,y:909,t:1527873102842};\\\", \\\"{x:1404,y:917,t:1527873102858};\\\", \\\"{x:1407,y:925,t:1527873102874};\\\", \\\"{x:1411,y:933,t:1527873102891};\\\", \\\"{x:1412,y:936,t:1527873102908};\\\", \\\"{x:1412,y:937,t:1527873102924};\\\", \\\"{x:1412,y:939,t:1527873102957};\\\", \\\"{x:1414,y:941,t:1527873102965};\\\", \\\"{x:1415,y:943,t:1527873102975};\\\", \\\"{x:1415,y:946,t:1527873102991};\\\", \\\"{x:1415,y:947,t:1527873103011};\\\", \\\"{x:1415,y:949,t:1527873103117};\\\", \\\"{x:1416,y:949,t:1527873103125};\\\", \\\"{x:1416,y:951,t:1527873103221};\\\", \\\"{x:1417,y:951,t:1527873103228};\\\", \\\"{x:1418,y:951,t:1527873103244};\\\", \\\"{x:1419,y:951,t:1527873103365};\\\", \\\"{x:1419,y:949,t:1527873103375};\\\", \\\"{x:1419,y:943,t:1527873103392};\\\", \\\"{x:1419,y:936,t:1527873103410};\\\", \\\"{x:1419,y:921,t:1527873103425};\\\", \\\"{x:1414,y:898,t:1527873103441};\\\", \\\"{x:1414,y:883,t:1527873103458};\\\", \\\"{x:1413,y:873,t:1527873103475};\\\", \\\"{x:1413,y:863,t:1527873103491};\\\", \\\"{x:1413,y:851,t:1527873103509};\\\", \\\"{x:1411,y:844,t:1527873103525};\\\", \\\"{x:1411,y:836,t:1527873103542};\\\", \\\"{x:1410,y:832,t:1527873103559};\\\", \\\"{x:1410,y:831,t:1527873103574};\\\", \\\"{x:1410,y:830,t:1527873103592};\\\", \\\"{x:1409,y:827,t:1527873103610};\\\", \\\"{x:1409,y:823,t:1527873103626};\\\", \\\"{x:1408,y:818,t:1527873103641};\\\", \\\"{x:1408,y:813,t:1527873103659};\\\", \\\"{x:1407,y:803,t:1527873103675};\\\", \\\"{x:1406,y:796,t:1527873103691};\\\", \\\"{x:1406,y:782,t:1527873103707};\\\", \\\"{x:1405,y:773,t:1527873103725};\\\", \\\"{x:1405,y:762,t:1527873103741};\\\", \\\"{x:1405,y:747,t:1527873103758};\\\", \\\"{x:1405,y:731,t:1527873103775};\\\", \\\"{x:1405,y:714,t:1527873103791};\\\", \\\"{x:1405,y:699,t:1527873103808};\\\", \\\"{x:1402,y:685,t:1527873103824};\\\", \\\"{x:1401,y:672,t:1527873103841};\\\", \\\"{x:1400,y:658,t:1527873103858};\\\", \\\"{x:1400,y:647,t:1527873103875};\\\", \\\"{x:1397,y:635,t:1527873103890};\\\", \\\"{x:1396,y:627,t:1527873103908};\\\", \\\"{x:1396,y:622,t:1527873103924};\\\", \\\"{x:1396,y:617,t:1527873103941};\\\", \\\"{x:1396,y:612,t:1527873103958};\\\", \\\"{x:1396,y:607,t:1527873103975};\\\", \\\"{x:1396,y:602,t:1527873103992};\\\", \\\"{x:1396,y:598,t:1527873104008};\\\", \\\"{x:1396,y:594,t:1527873104025};\\\", \\\"{x:1397,y:590,t:1527873104042};\\\", \\\"{x:1397,y:588,t:1527873104058};\\\", \\\"{x:1398,y:585,t:1527873104075};\\\", \\\"{x:1399,y:583,t:1527873104092};\\\", \\\"{x:1400,y:580,t:1527873104108};\\\", \\\"{x:1401,y:580,t:1527873104125};\\\", \\\"{x:1401,y:577,t:1527873104142};\\\", \\\"{x:1402,y:577,t:1527873104158};\\\", \\\"{x:1403,y:575,t:1527873104175};\\\", \\\"{x:1403,y:574,t:1527873104195};\\\", \\\"{x:1404,y:573,t:1527873104211};\\\", \\\"{x:1405,y:572,t:1527873104235};\\\", \\\"{x:1406,y:571,t:1527873104243};\\\", \\\"{x:1407,y:570,t:1527873104258};\\\", \\\"{x:1410,y:568,t:1527873104275};\\\", \\\"{x:1412,y:566,t:1527873104292};\\\", \\\"{x:1414,y:565,t:1527873104308};\\\", \\\"{x:1415,y:564,t:1527873104339};\\\", \\\"{x:1417,y:563,t:1527873104355};\\\", \\\"{x:1418,y:563,t:1527873104371};\\\", \\\"{x:1419,y:562,t:1527873104395};\\\", \\\"{x:1419,y:561,t:1527873104408};\\\", \\\"{x:1420,y:561,t:1527873104492};\\\", \\\"{x:1420,y:553,t:1527873119512};\\\", \\\"{x:1420,y:544,t:1527873119521};\\\", \\\"{x:1420,y:536,t:1527873119538};\\\", \\\"{x:1420,y:530,t:1527873119554};\\\", \\\"{x:1419,y:526,t:1527873119571};\\\", \\\"{x:1419,y:523,t:1527873119587};\\\", \\\"{x:1418,y:519,t:1527873119604};\\\", \\\"{x:1418,y:514,t:1527873119620};\\\", \\\"{x:1416,y:508,t:1527873119638};\\\", \\\"{x:1416,y:504,t:1527873119654};\\\", \\\"{x:1415,y:499,t:1527873119671};\\\", \\\"{x:1415,y:498,t:1527873119687};\\\", \\\"{x:1414,y:497,t:1527873119704};\\\", \\\"{x:1414,y:496,t:1527873119721};\\\", \\\"{x:1414,y:495,t:1527873119738};\\\", \\\"{x:1414,y:493,t:1527873119754};\\\", \\\"{x:1414,y:491,t:1527873119771};\\\", \\\"{x:1414,y:490,t:1527873119788};\\\", \\\"{x:1414,y:489,t:1527873119804};\\\", \\\"{x:1414,y:487,t:1527873119821};\\\", \\\"{x:1414,y:486,t:1527873119838};\\\", \\\"{x:1412,y:482,t:1527873119855};\\\", \\\"{x:1412,y:478,t:1527873119871};\\\", \\\"{x:1412,y:475,t:1527873119888};\\\", \\\"{x:1412,y:472,t:1527873119906};\\\", \\\"{x:1412,y:470,t:1527873119922};\\\", \\\"{x:1411,y:468,t:1527873119938};\\\", \\\"{x:1411,y:465,t:1527873119955};\\\", \\\"{x:1411,y:460,t:1527873119972};\\\", \\\"{x:1411,y:457,t:1527873119989};\\\", \\\"{x:1410,y:455,t:1527873120005};\\\", \\\"{x:1410,y:453,t:1527873120021};\\\", \\\"{x:1410,y:451,t:1527873120038};\\\", \\\"{x:1410,y:446,t:1527873120054};\\\", \\\"{x:1410,y:443,t:1527873120071};\\\", \\\"{x:1410,y:441,t:1527873120088};\\\", \\\"{x:1410,y:439,t:1527873120105};\\\", \\\"{x:1410,y:436,t:1527873120121};\\\", \\\"{x:1410,y:435,t:1527873120138};\\\", \\\"{x:1410,y:431,t:1527873120155};\\\", \\\"{x:1410,y:429,t:1527873120171};\\\", \\\"{x:1410,y:428,t:1527873120188};\\\", \\\"{x:1409,y:430,t:1527873127503};\\\", \\\"{x:1408,y:433,t:1527873127513};\\\", \\\"{x:1407,y:436,t:1527873127527};\\\", \\\"{x:1407,y:445,t:1527873127543};\\\", \\\"{x:1407,y:452,t:1527873127560};\\\", \\\"{x:1408,y:462,t:1527873127577};\\\", \\\"{x:1409,y:466,t:1527873127593};\\\", \\\"{x:1410,y:470,t:1527873127610};\\\", \\\"{x:1411,y:474,t:1527873127626};\\\", \\\"{x:1419,y:486,t:1527873127643};\\\", \\\"{x:1430,y:505,t:1527873127660};\\\", \\\"{x:1434,y:518,t:1527873127677};\\\", \\\"{x:1440,y:529,t:1527873127692};\\\", \\\"{x:1444,y:540,t:1527873127710};\\\", \\\"{x:1446,y:547,t:1527873127727};\\\", \\\"{x:1448,y:550,t:1527873127742};\\\", \\\"{x:1448,y:554,t:1527873127760};\\\", \\\"{x:1448,y:555,t:1527873127777};\\\", \\\"{x:1448,y:558,t:1527873127793};\\\", \\\"{x:1448,y:559,t:1527873127810};\\\", \\\"{x:1448,y:561,t:1527873127827};\\\", \\\"{x:1448,y:563,t:1527873127843};\\\", \\\"{x:1448,y:564,t:1527873127872};\\\", \\\"{x:1446,y:567,t:1527873128023};\\\", \\\"{x:1445,y:567,t:1527873128032};\\\", \\\"{x:1442,y:569,t:1527873128044};\\\", \\\"{x:1438,y:572,t:1527873128060};\\\", \\\"{x:1431,y:575,t:1527873128076};\\\", \\\"{x:1427,y:575,t:1527873128094};\\\", \\\"{x:1425,y:576,t:1527873128110};\\\", \\\"{x:1424,y:576,t:1527873128127};\\\", \\\"{x:1424,y:577,t:1527873128144};\\\", \\\"{x:1423,y:577,t:1527873128159};\\\", \\\"{x:1422,y:577,t:1527873128191};\\\", \\\"{x:1422,y:576,t:1527873128344};\\\", \\\"{x:1421,y:573,t:1527873128360};\\\", \\\"{x:1419,y:570,t:1527873128377};\\\", \\\"{x:1419,y:568,t:1527873128393};\\\", \\\"{x:1419,y:567,t:1527873128423};\\\", \\\"{x:1419,y:566,t:1527873128448};\\\", \\\"{x:1419,y:565,t:1527873128459};\\\", \\\"{x:1419,y:564,t:1527873128496};\\\", \\\"{x:1419,y:563,t:1527873128544};\\\", \\\"{x:1419,y:562,t:1527873128568};\\\", \\\"{x:1419,y:561,t:1527873128591};\\\", \\\"{x:1419,y:560,t:1527873128599};\\\", \\\"{x:1418,y:559,t:1527873128615};\\\", \\\"{x:1418,y:558,t:1527873128681};\\\", \\\"{x:1417,y:558,t:1527873129968};\\\", \\\"{x:1417,y:559,t:1527873129978};\\\", \\\"{x:1417,y:560,t:1527873129995};\\\", \\\"{x:1417,y:562,t:1527873133119};\\\", \\\"{x:1417,y:569,t:1527873133681};\\\", \\\"{x:1411,y:606,t:1527873133698};\\\", \\\"{x:1397,y:648,t:1527873133713};\\\", \\\"{x:1388,y:690,t:1527873133731};\\\", \\\"{x:1379,y:717,t:1527873133747};\\\", \\\"{x:1371,y:739,t:1527873133763};\\\", \\\"{x:1362,y:756,t:1527873133780};\\\", \\\"{x:1353,y:768,t:1527873133797};\\\", \\\"{x:1350,y:772,t:1527873133814};\\\", \\\"{x:1348,y:776,t:1527873133830};\\\", \\\"{x:1347,y:779,t:1527873133847};\\\", \\\"{x:1350,y:778,t:1527873134144};\\\", \\\"{x:1352,y:777,t:1527873134151};\\\", \\\"{x:1354,y:776,t:1527873134164};\\\", \\\"{x:1357,y:774,t:1527873134181};\\\", \\\"{x:1359,y:773,t:1527873134197};\\\", \\\"{x:1362,y:770,t:1527873134214};\\\", \\\"{x:1364,y:770,t:1527873134230};\\\", \\\"{x:1367,y:768,t:1527873134247};\\\", \\\"{x:1368,y:768,t:1527873134279};\\\", \\\"{x:1370,y:768,t:1527873134297};\\\", \\\"{x:1372,y:767,t:1527873134336};\\\", \\\"{x:1373,y:767,t:1527873134384};\\\", \\\"{x:1375,y:767,t:1527873134407};\\\", \\\"{x:1376,y:767,t:1527873134423};\\\", \\\"{x:1377,y:767,t:1527873134448};\\\", \\\"{x:1378,y:767,t:1527873134464};\\\", \\\"{x:1379,y:766,t:1527873134481};\\\", \\\"{x:1380,y:766,t:1527873134511};\\\", \\\"{x:1381,y:766,t:1527873134519};\\\", \\\"{x:1382,y:766,t:1527873134531};\\\", \\\"{x:1383,y:766,t:1527873134547};\\\", \\\"{x:1384,y:764,t:1527873134567};\\\", \\\"{x:1384,y:768,t:1527873142136};\\\", \\\"{x:1384,y:779,t:1527873142153};\\\", \\\"{x:1383,y:801,t:1527873142168};\\\", \\\"{x:1379,y:817,t:1527873142185};\\\", \\\"{x:1375,y:831,t:1527873142202};\\\", \\\"{x:1371,y:841,t:1527873142219};\\\", \\\"{x:1369,y:844,t:1527873142235};\\\", \\\"{x:1367,y:850,t:1527873142252};\\\", \\\"{x:1367,y:852,t:1527873142268};\\\", \\\"{x:1367,y:855,t:1527873142285};\\\", \\\"{x:1366,y:858,t:1527873142302};\\\", \\\"{x:1365,y:859,t:1527873142319};\\\", \\\"{x:1365,y:860,t:1527873142351};\\\", \\\"{x:1364,y:863,t:1527873142368};\\\", \\\"{x:1362,y:868,t:1527873142386};\\\", \\\"{x:1361,y:871,t:1527873142402};\\\", \\\"{x:1359,y:875,t:1527873142418};\\\", \\\"{x:1358,y:879,t:1527873142436};\\\", \\\"{x:1355,y:885,t:1527873142452};\\\", \\\"{x:1354,y:888,t:1527873142469};\\\", \\\"{x:1353,y:890,t:1527873142485};\\\", \\\"{x:1353,y:891,t:1527873142662};\\\", \\\"{x:1352,y:891,t:1527873142927};\\\", \\\"{x:1352,y:889,t:1527873142943};\\\", \\\"{x:1352,y:887,t:1527873142953};\\\", \\\"{x:1352,y:883,t:1527873142970};\\\", \\\"{x:1352,y:879,t:1527873142985};\\\", \\\"{x:1352,y:877,t:1527873143002};\\\", \\\"{x:1352,y:874,t:1527873143020};\\\", \\\"{x:1352,y:873,t:1527873143036};\\\", \\\"{x:1352,y:870,t:1527873143053};\\\", \\\"{x:1352,y:868,t:1527873143079};\\\", \\\"{x:1352,y:867,t:1527873143087};\\\", \\\"{x:1352,y:866,t:1527873143103};\\\", \\\"{x:1352,y:860,t:1527873143119};\\\", \\\"{x:1352,y:853,t:1527873143137};\\\", \\\"{x:1352,y:849,t:1527873143153};\\\", \\\"{x:1352,y:845,t:1527873143169};\\\", \\\"{x:1352,y:839,t:1527873143186};\\\", \\\"{x:1352,y:834,t:1527873143202};\\\", \\\"{x:1352,y:830,t:1527873143219};\\\", \\\"{x:1352,y:827,t:1527873143237};\\\", \\\"{x:1352,y:826,t:1527873143253};\\\", \\\"{x:1351,y:823,t:1527873143270};\\\", \\\"{x:1351,y:822,t:1527873143287};\\\", \\\"{x:1351,y:821,t:1527873143303};\\\", \\\"{x:1351,y:820,t:1527873143319};\\\", \\\"{x:1351,y:817,t:1527873143336};\\\", \\\"{x:1351,y:813,t:1527873143353};\\\", \\\"{x:1350,y:806,t:1527873143369};\\\", \\\"{x:1350,y:799,t:1527873143386};\\\", \\\"{x:1348,y:792,t:1527873143403};\\\", \\\"{x:1347,y:788,t:1527873143419};\\\", \\\"{x:1344,y:775,t:1527873143436};\\\", \\\"{x:1339,y:763,t:1527873143453};\\\", \\\"{x:1336,y:755,t:1527873143469};\\\", \\\"{x:1330,y:743,t:1527873143487};\\\", \\\"{x:1329,y:741,t:1527873143503};\\\", \\\"{x:1325,y:732,t:1527873143519};\\\", \\\"{x:1323,y:726,t:1527873143536};\\\", \\\"{x:1321,y:721,t:1527873143552};\\\", \\\"{x:1316,y:711,t:1527873143569};\\\", \\\"{x:1311,y:700,t:1527873143586};\\\", \\\"{x:1309,y:693,t:1527873143602};\\\", \\\"{x:1307,y:685,t:1527873143619};\\\", \\\"{x:1305,y:676,t:1527873143637};\\\", \\\"{x:1303,y:667,t:1527873143652};\\\", \\\"{x:1302,y:659,t:1527873143670};\\\", \\\"{x:1301,y:653,t:1527873143687};\\\", \\\"{x:1301,y:649,t:1527873143702};\\\", \\\"{x:1301,y:639,t:1527873143719};\\\", \\\"{x:1301,y:631,t:1527873143737};\\\", \\\"{x:1301,y:624,t:1527873143753};\\\", \\\"{x:1301,y:620,t:1527873143769};\\\", \\\"{x:1301,y:617,t:1527873143786};\\\", \\\"{x:1301,y:615,t:1527873143803};\\\", \\\"{x:1301,y:614,t:1527873143864};\\\", \\\"{x:1302,y:614,t:1527873144047};\\\", \\\"{x:1302,y:615,t:1527873144079};\\\", \\\"{x:1303,y:615,t:1527873144095};\\\", \\\"{x:1304,y:617,t:1527873144103};\\\", \\\"{x:1305,y:617,t:1527873144119};\\\", \\\"{x:1306,y:618,t:1527873144159};\\\", \\\"{x:1306,y:619,t:1527873144200};\\\", \\\"{x:1307,y:620,t:1527873144207};\\\", \\\"{x:1308,y:620,t:1527873144219};\\\", \\\"{x:1308,y:621,t:1527873144236};\\\", \\\"{x:1308,y:622,t:1527873144253};\\\", \\\"{x:1309,y:623,t:1527873144270};\\\", \\\"{x:1311,y:625,t:1527873144286};\\\", \\\"{x:1313,y:629,t:1527873144302};\\\", \\\"{x:1314,y:630,t:1527873144326};\\\", \\\"{x:1314,y:632,t:1527873144383};\\\", \\\"{x:1316,y:623,t:1527873163288};\\\", \\\"{x:1321,y:607,t:1527873163298};\\\", \\\"{x:1328,y:590,t:1527873163315};\\\", \\\"{x:1335,y:571,t:1527873163331};\\\", \\\"{x:1342,y:556,t:1527873163348};\\\", \\\"{x:1343,y:550,t:1527873163365};\\\", \\\"{x:1344,y:543,t:1527873163381};\\\", \\\"{x:1344,y:538,t:1527873163398};\\\", \\\"{x:1344,y:533,t:1527873163415};\\\", \\\"{x:1344,y:530,t:1527873163431};\\\", \\\"{x:1344,y:526,t:1527873163448};\\\", \\\"{x:1344,y:524,t:1527873163465};\\\", \\\"{x:1344,y:520,t:1527873163481};\\\", \\\"{x:1344,y:518,t:1527873163498};\\\", \\\"{x:1344,y:517,t:1527873163516};\\\", \\\"{x:1344,y:516,t:1527873163532};\\\", \\\"{x:1344,y:515,t:1527873163671};\\\", \\\"{x:1344,y:514,t:1527873163682};\\\", \\\"{x:1342,y:513,t:1527873163698};\\\", \\\"{x:1339,y:513,t:1527873163715};\\\", \\\"{x:1337,y:512,t:1527873163733};\\\", \\\"{x:1333,y:510,t:1527873163748};\\\", \\\"{x:1331,y:509,t:1527873163765};\\\", \\\"{x:1330,y:509,t:1527873163783};\\\", \\\"{x:1328,y:509,t:1527873163799};\\\", \\\"{x:1327,y:509,t:1527873163823};\\\", \\\"{x:1326,y:509,t:1527873163833};\\\", \\\"{x:1325,y:509,t:1527873163848};\\\", \\\"{x:1322,y:508,t:1527873163865};\\\", \\\"{x:1321,y:507,t:1527873163883};\\\", \\\"{x:1320,y:506,t:1527873163898};\\\", \\\"{x:1317,y:506,t:1527873163915};\\\", \\\"{x:1316,y:506,t:1527873163932};\\\", \\\"{x:1312,y:504,t:1527873163949};\\\", \\\"{x:1310,y:503,t:1527873163965};\\\", \\\"{x:1309,y:502,t:1527873163983};\\\", \\\"{x:1307,y:501,t:1527873163999};\\\", \\\"{x:1306,y:500,t:1527873164023};\\\", \\\"{x:1306,y:499,t:1527873164071};\\\", \\\"{x:1305,y:497,t:1527873164088};\\\", \\\"{x:1305,y:496,t:1527873164200};\\\", \\\"{x:1305,y:495,t:1527873164216};\\\", \\\"{x:1305,y:494,t:1527873164233};\\\", \\\"{x:1305,y:493,t:1527873164249};\\\", \\\"{x:1308,y:491,t:1527873164266};\\\", \\\"{x:1310,y:490,t:1527873164282};\\\", \\\"{x:1312,y:489,t:1527873164319};\\\", \\\"{x:1313,y:489,t:1527873164536};\\\", \\\"{x:1315,y:490,t:1527873164551};\\\", \\\"{x:1316,y:491,t:1527873164566};\\\", \\\"{x:1317,y:493,t:1527873164583};\\\", \\\"{x:1319,y:496,t:1527873164599};\\\", \\\"{x:1309,y:507,t:1527873173444};\\\", \\\"{x:1198,y:566,t:1527873173458};\\\", \\\"{x:1063,y:618,t:1527873173474};\\\", \\\"{x:930,y:661,t:1527873173492};\\\", \\\"{x:808,y:701,t:1527873173509};\\\", \\\"{x:693,y:722,t:1527873173525};\\\", \\\"{x:611,y:729,t:1527873173541};\\\", \\\"{x:569,y:729,t:1527873173559};\\\", \\\"{x:546,y:725,t:1527873173576};\\\", \\\"{x:533,y:718,t:1527873173591};\\\", \\\"{x:527,y:713,t:1527873173608};\\\", \\\"{x:526,y:712,t:1527873173634};\\\", \\\"{x:525,y:710,t:1527873173722};\\\", \\\"{x:524,y:697,t:1527873173739};\\\", \\\"{x:516,y:678,t:1527873173755};\\\", \\\"{x:509,y:663,t:1527873173772};\\\", \\\"{x:501,y:654,t:1527873173789};\\\", \\\"{x:486,y:638,t:1527873173811};\\\", \\\"{x:471,y:627,t:1527873173826};\\\", \\\"{x:455,y:619,t:1527873173843};\\\", \\\"{x:439,y:613,t:1527873173859};\\\", \\\"{x:420,y:605,t:1527873173876};\\\", \\\"{x:409,y:600,t:1527873173894};\\\", \\\"{x:406,y:599,t:1527873173910};\\\", \\\"{x:397,y:598,t:1527873173927};\\\", \\\"{x:382,y:597,t:1527873173944};\\\", \\\"{x:365,y:594,t:1527873173960};\\\", \\\"{x:351,y:593,t:1527873173977};\\\", \\\"{x:340,y:593,t:1527873173994};\\\", \\\"{x:334,y:593,t:1527873174010};\\\", \\\"{x:331,y:593,t:1527873174027};\\\", \\\"{x:327,y:593,t:1527873174044};\\\", \\\"{x:318,y:593,t:1527873174060};\\\", \\\"{x:310,y:593,t:1527873174077};\\\", \\\"{x:301,y:595,t:1527873174094};\\\", \\\"{x:289,y:598,t:1527873174111};\\\", \\\"{x:280,y:599,t:1527873174127};\\\", \\\"{x:274,y:601,t:1527873174144};\\\", \\\"{x:272,y:602,t:1527873174161};\\\", \\\"{x:271,y:603,t:1527873174177};\\\", \\\"{x:271,y:604,t:1527873174194};\\\", \\\"{x:275,y:606,t:1527873174212};\\\", \\\"{x:285,y:610,t:1527873174227};\\\", \\\"{x:302,y:612,t:1527873174243};\\\", \\\"{x:332,y:614,t:1527873174260};\\\", \\\"{x:380,y:614,t:1527873174277};\\\", \\\"{x:451,y:612,t:1527873174295};\\\", \\\"{x:514,y:607,t:1527873174311};\\\", \\\"{x:565,y:605,t:1527873174327};\\\", \\\"{x:629,y:604,t:1527873174344};\\\", \\\"{x:670,y:600,t:1527873174360};\\\", \\\"{x:687,y:596,t:1527873174377};\\\", \\\"{x:690,y:596,t:1527873174394};\\\", \\\"{x:690,y:595,t:1527873174426};\\\", \\\"{x:691,y:594,t:1527873174443};\\\", \\\"{x:691,y:592,t:1527873174460};\\\", \\\"{x:692,y:590,t:1527873174477};\\\", \\\"{x:692,y:589,t:1527873174494};\\\", \\\"{x:685,y:589,t:1527873174570};\\\", \\\"{x:678,y:590,t:1527873174578};\\\", \\\"{x:663,y:596,t:1527873174596};\\\", \\\"{x:643,y:601,t:1527873174611};\\\", \\\"{x:619,y:607,t:1527873174627};\\\", \\\"{x:600,y:612,t:1527873174644};\\\", \\\"{x:585,y:615,t:1527873174661};\\\", \\\"{x:575,y:616,t:1527873174677};\\\", \\\"{x:571,y:617,t:1527873174694};\\\", \\\"{x:569,y:617,t:1527873174710};\\\", \\\"{x:568,y:617,t:1527873174727};\\\", \\\"{x:568,y:618,t:1527873174818};\\\", \\\"{x:570,y:620,t:1527873174827};\\\", \\\"{x:586,y:623,t:1527873174844};\\\", \\\"{x:597,y:624,t:1527873174861};\\\", \\\"{x:601,y:624,t:1527873174877};\\\", \\\"{x:607,y:624,t:1527873174894};\\\", \\\"{x:613,y:624,t:1527873174911};\\\", \\\"{x:615,y:624,t:1527873174927};\\\", \\\"{x:616,y:624,t:1527873174944};\\\", \\\"{x:616,y:623,t:1527873175171};\\\", \\\"{x:615,y:621,t:1527873175187};\\\", \\\"{x:614,y:621,t:1527873175194};\\\", \\\"{x:613,y:619,t:1527873175211};\\\", \\\"{x:613,y:618,t:1527873175228};\\\", \\\"{x:612,y:618,t:1527873175378};\\\", \\\"{x:612,y:618,t:1527873175422};\\\", \\\"{x:616,y:618,t:1527873176018};\\\", \\\"{x:622,y:618,t:1527873176028};\\\", \\\"{x:645,y:619,t:1527873176046};\\\", \\\"{x:677,y:619,t:1527873176061};\\\", \\\"{x:713,y:625,t:1527873176078};\\\", \\\"{x:758,y:631,t:1527873176095};\\\", \\\"{x:808,y:639,t:1527873176112};\\\", \\\"{x:854,y:646,t:1527873176129};\\\", \\\"{x:942,y:658,t:1527873176145};\\\", \\\"{x:1082,y:677,t:1527873176162};\\\", \\\"{x:1166,y:688,t:1527873176179};\\\", \\\"{x:1252,y:699,t:1527873176195};\\\", \\\"{x:1320,y:702,t:1527873176212};\\\", \\\"{x:1350,y:706,t:1527873176229};\\\", \\\"{x:1376,y:711,t:1527873176244};\\\", \\\"{x:1398,y:714,t:1527873176262};\\\", \\\"{x:1409,y:715,t:1527873176279};\\\", \\\"{x:1412,y:715,t:1527873176295};\\\", \\\"{x:1414,y:715,t:1527873176313};\\\", \\\"{x:1416,y:715,t:1527873176329};\\\", \\\"{x:1419,y:715,t:1527873176345};\\\", \\\"{x:1427,y:715,t:1527873176362};\\\", \\\"{x:1430,y:714,t:1527873176379};\\\", \\\"{x:1434,y:713,t:1527873176395};\\\", \\\"{x:1437,y:710,t:1527873176413};\\\", \\\"{x:1440,y:706,t:1527873176429};\\\", \\\"{x:1443,y:703,t:1527873176446};\\\", \\\"{x:1445,y:699,t:1527873176462};\\\", \\\"{x:1445,y:697,t:1527873176480};\\\", \\\"{x:1445,y:695,t:1527873176496};\\\", \\\"{x:1445,y:694,t:1527873176512};\\\", \\\"{x:1442,y:694,t:1527873176651};\\\", \\\"{x:1420,y:699,t:1527873176663};\\\", \\\"{x:1320,y:715,t:1527873176680};\\\", \\\"{x:1180,y:745,t:1527873176697};\\\", \\\"{x:1034,y:784,t:1527873176713};\\\", \\\"{x:879,y:831,t:1527873176730};\\\", \\\"{x:742,y:878,t:1527873176746};\\\", \\\"{x:589,y:950,t:1527873176762};\\\", \\\"{x:509,y:969,t:1527873176780};\\\", \\\"{x:457,y:974,t:1527873176797};\\\", \\\"{x:420,y:974,t:1527873176813};\\\", \\\"{x:399,y:969,t:1527873176829};\\\", \\\"{x:389,y:966,t:1527873176846};\\\", \\\"{x:386,y:966,t:1527873176863};\\\", \\\"{x:385,y:965,t:1527873176883};\\\", \\\"{x:385,y:963,t:1527873176896};\\\", \\\"{x:379,y:950,t:1527873176914};\\\", \\\"{x:373,y:938,t:1527873176930};\\\", \\\"{x:366,y:932,t:1527873176947};\\\", \\\"{x:363,y:932,t:1527873176963};\\\", \\\"{x:362,y:931,t:1527873176980};\\\", \\\"{x:360,y:931,t:1527873176996};\\\", \\\"{x:358,y:927,t:1527873177013};\\\", \\\"{x:355,y:919,t:1527873177029};\\\", \\\"{x:355,y:907,t:1527873177047};\\\", \\\"{x:353,y:894,t:1527873177064};\\\", \\\"{x:354,y:880,t:1527873177079};\\\", \\\"{x:359,y:865,t:1527873177096};\\\", \\\"{x:375,y:847,t:1527873177114};\\\", \\\"{x:384,y:841,t:1527873177130};\\\", \\\"{x:422,y:817,t:1527873177147};\\\", \\\"{x:454,y:799,t:1527873177163};\\\", \\\"{x:467,y:792,t:1527873177180};\\\", \\\"{x:473,y:788,t:1527873177196};\\\", \\\"{x:476,y:786,t:1527873177213};\\\", \\\"{x:477,y:786,t:1527873177229};\\\", \\\"{x:481,y:783,t:1527873177246};\\\", \\\"{x:486,y:779,t:1527873177263};\\\", \\\"{x:491,y:775,t:1527873177280};\\\", \\\"{x:496,y:770,t:1527873177296};\\\", \\\"{x:500,y:766,t:1527873177313};\\\", \\\"{x:505,y:757,t:1527873177330};\\\", \\\"{x:510,y:748,t:1527873177348};\\\", \\\"{x:510,y:744,t:1527873177363};\\\", \\\"{x:510,y:741,t:1527873177378};\\\", \\\"{x:510,y:739,t:1527873177396};\\\", \\\"{x:510,y:738,t:1527873177413};\\\" ] }, { \\\"rt\\\": 8852, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 378110, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"QGUGU\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:515,y:738,t:1527873180651};\\\", \\\"{x:537,y:745,t:1527873180665};\\\", \\\"{x:674,y:786,t:1527873180684};\\\", \\\"{x:764,y:805,t:1527873180699};\\\", \\\"{x:831,y:814,t:1527873180715};\\\", \\\"{x:897,y:820,t:1527873180732};\\\", \\\"{x:956,y:823,t:1527873180749};\\\", \\\"{x:1015,y:823,t:1527873180766};\\\", \\\"{x:1068,y:823,t:1527873180782};\\\", \\\"{x:1107,y:819,t:1527873180799};\\\", \\\"{x:1131,y:816,t:1527873180816};\\\", \\\"{x:1142,y:815,t:1527873180833};\\\", \\\"{x:1144,y:814,t:1527873180849};\\\", \\\"{x:1144,y:812,t:1527873180938};\\\", \\\"{x:1142,y:811,t:1527873180949};\\\", \\\"{x:1139,y:807,t:1527873180967};\\\", \\\"{x:1139,y:806,t:1527873180984};\\\", \\\"{x:1138,y:806,t:1527873181002};\\\", \\\"{x:1137,y:804,t:1527873181016};\\\", \\\"{x:1132,y:799,t:1527873181033};\\\", \\\"{x:1129,y:796,t:1527873181049};\\\", \\\"{x:1121,y:784,t:1527873181066};\\\", \\\"{x:1118,y:780,t:1527873181084};\\\", \\\"{x:1116,y:776,t:1527873181100};\\\", \\\"{x:1113,y:770,t:1527873181116};\\\", \\\"{x:1111,y:763,t:1527873181134};\\\", \\\"{x:1110,y:759,t:1527873181149};\\\", \\\"{x:1108,y:753,t:1527873181167};\\\", \\\"{x:1107,y:750,t:1527873181183};\\\", \\\"{x:1107,y:744,t:1527873181199};\\\", \\\"{x:1107,y:740,t:1527873181217};\\\", \\\"{x:1106,y:732,t:1527873181234};\\\", \\\"{x:1106,y:718,t:1527873181249};\\\", \\\"{x:1106,y:690,t:1527873181267};\\\", \\\"{x:1106,y:675,t:1527873181283};\\\", \\\"{x:1108,y:658,t:1527873181299};\\\", \\\"{x:1110,y:644,t:1527873181317};\\\", \\\"{x:1111,y:634,t:1527873181334};\\\", \\\"{x:1111,y:628,t:1527873181351};\\\", \\\"{x:1111,y:624,t:1527873181367};\\\", \\\"{x:1111,y:620,t:1527873181384};\\\", \\\"{x:1111,y:617,t:1527873181400};\\\", \\\"{x:1111,y:615,t:1527873181417};\\\", \\\"{x:1111,y:614,t:1527873181434};\\\", \\\"{x:1112,y:614,t:1527873181515};\\\", \\\"{x:1118,y:614,t:1527873181522};\\\", \\\"{x:1122,y:614,t:1527873181534};\\\", \\\"{x:1134,y:614,t:1527873181551};\\\", \\\"{x:1149,y:614,t:1527873181567};\\\", \\\"{x:1162,y:614,t:1527873181584};\\\", \\\"{x:1176,y:611,t:1527873181600};\\\", \\\"{x:1191,y:610,t:1527873181616};\\\", \\\"{x:1208,y:609,t:1527873181634};\\\", \\\"{x:1231,y:608,t:1527873181650};\\\", \\\"{x:1247,y:602,t:1527873181666};\\\", \\\"{x:1258,y:598,t:1527873181683};\\\", \\\"{x:1264,y:597,t:1527873181700};\\\", \\\"{x:1266,y:596,t:1527873181717};\\\", \\\"{x:1266,y:595,t:1527873181891};\\\", \\\"{x:1266,y:593,t:1527873181901};\\\", \\\"{x:1266,y:592,t:1527873181917};\\\", \\\"{x:1266,y:590,t:1527873181934};\\\", \\\"{x:1266,y:588,t:1527873181950};\\\", \\\"{x:1266,y:587,t:1527873181967};\\\", \\\"{x:1264,y:585,t:1527873182539};\\\", \\\"{x:1261,y:583,t:1527873182552};\\\", \\\"{x:1248,y:582,t:1527873182568};\\\", \\\"{x:1225,y:582,t:1527873182585};\\\", \\\"{x:1195,y:582,t:1527873182601};\\\", \\\"{x:1161,y:582,t:1527873182617};\\\", \\\"{x:1117,y:582,t:1527873182634};\\\", \\\"{x:1091,y:582,t:1527873182652};\\\", \\\"{x:1062,y:582,t:1527873182668};\\\", \\\"{x:1030,y:582,t:1527873182685};\\\", \\\"{x:985,y:582,t:1527873182701};\\\", \\\"{x:943,y:582,t:1527873182718};\\\", \\\"{x:907,y:582,t:1527873182734};\\\", \\\"{x:882,y:582,t:1527873182751};\\\", \\\"{x:855,y:582,t:1527873182768};\\\", \\\"{x:827,y:582,t:1527873182785};\\\", \\\"{x:799,y:581,t:1527873182800};\\\", \\\"{x:754,y:573,t:1527873182817};\\\", \\\"{x:727,y:571,t:1527873182834};\\\", \\\"{x:701,y:570,t:1527873182851};\\\", \\\"{x:674,y:570,t:1527873182867};\\\", \\\"{x:650,y:570,t:1527873182884};\\\", \\\"{x:624,y:570,t:1527873182900};\\\", \\\"{x:592,y:570,t:1527873182918};\\\", \\\"{x:560,y:567,t:1527873182935};\\\", \\\"{x:538,y:565,t:1527873182951};\\\", \\\"{x:524,y:565,t:1527873182967};\\\", \\\"{x:514,y:565,t:1527873182984};\\\", \\\"{x:505,y:564,t:1527873183001};\\\", \\\"{x:503,y:564,t:1527873183017};\\\", \\\"{x:502,y:564,t:1527873183058};\\\", \\\"{x:499,y:564,t:1527873183067};\\\", \\\"{x:496,y:564,t:1527873183086};\\\", \\\"{x:488,y:564,t:1527873183101};\\\", \\\"{x:473,y:564,t:1527873183118};\\\", \\\"{x:459,y:564,t:1527873183134};\\\", \\\"{x:444,y:564,t:1527873183151};\\\", \\\"{x:427,y:564,t:1527873183167};\\\", \\\"{x:407,y:564,t:1527873183184};\\\", \\\"{x:382,y:564,t:1527873183201};\\\", \\\"{x:375,y:564,t:1527873183218};\\\", \\\"{x:371,y:564,t:1527873183235};\\\", \\\"{x:370,y:564,t:1527873183252};\\\", \\\"{x:368,y:564,t:1527873183268};\\\", \\\"{x:368,y:563,t:1527873183538};\\\", \\\"{x:368,y:562,t:1527873183553};\\\", \\\"{x:370,y:562,t:1527873183569};\\\", \\\"{x:375,y:562,t:1527873183584};\\\", \\\"{x:386,y:562,t:1527873183601};\\\", \\\"{x:393,y:562,t:1527873183617};\\\", \\\"{x:397,y:562,t:1527873183634};\\\", \\\"{x:400,y:561,t:1527873183651};\\\", \\\"{x:401,y:560,t:1527873183690};\\\", \\\"{x:402,y:560,t:1527873183713};\\\", \\\"{x:402,y:559,t:1527873183729};\\\", \\\"{x:402,y:558,t:1527873183746};\\\", \\\"{x:402,y:557,t:1527873183762};\\\", \\\"{x:402,y:556,t:1527873183769};\\\", \\\"{x:402,y:555,t:1527873183794};\\\", \\\"{x:401,y:555,t:1527873183801};\\\", \\\"{x:398,y:554,t:1527873183818};\\\", \\\"{x:394,y:554,t:1527873183835};\\\", \\\"{x:375,y:554,t:1527873183851};\\\", \\\"{x:352,y:554,t:1527873183868};\\\", \\\"{x:327,y:554,t:1527873183885};\\\", \\\"{x:300,y:561,t:1527873183902};\\\", \\\"{x:270,y:564,t:1527873183918};\\\", \\\"{x:237,y:572,t:1527873183934};\\\", \\\"{x:215,y:575,t:1527873183951};\\\", \\\"{x:201,y:576,t:1527873183968};\\\", \\\"{x:194,y:577,t:1527873183985};\\\", \\\"{x:193,y:577,t:1527873184114};\\\", \\\"{x:193,y:576,t:1527873184130};\\\", \\\"{x:193,y:575,t:1527873184145};\\\", \\\"{x:192,y:575,t:1527873184227};\\\", \\\"{x:191,y:575,t:1527873184242};\\\", \\\"{x:191,y:576,t:1527873184281};\\\", \\\"{x:191,y:577,t:1527873184290};\\\", \\\"{x:195,y:579,t:1527873184302};\\\", \\\"{x:225,y:585,t:1527873184318};\\\", \\\"{x:300,y:586,t:1527873184336};\\\", \\\"{x:417,y:586,t:1527873184352};\\\", \\\"{x:541,y:571,t:1527873184369};\\\", \\\"{x:714,y:546,t:1527873184386};\\\", \\\"{x:801,y:533,t:1527873184403};\\\", \\\"{x:853,y:527,t:1527873184418};\\\", \\\"{x:870,y:525,t:1527873184436};\\\", \\\"{x:873,y:523,t:1527873184452};\\\", \\\"{x:874,y:523,t:1527873184514};\\\", \\\"{x:876,y:523,t:1527873184522};\\\", \\\"{x:877,y:521,t:1527873184535};\\\", \\\"{x:881,y:519,t:1527873184552};\\\", \\\"{x:885,y:517,t:1527873184570};\\\", \\\"{x:883,y:517,t:1527873184635};\\\", \\\"{x:880,y:517,t:1527873184653};\\\", \\\"{x:874,y:517,t:1527873184669};\\\", \\\"{x:853,y:517,t:1527873184685};\\\", \\\"{x:826,y:517,t:1527873184702};\\\", \\\"{x:798,y:517,t:1527873184719};\\\", \\\"{x:773,y:517,t:1527873184735};\\\", \\\"{x:752,y:513,t:1527873184753};\\\", \\\"{x:731,y:508,t:1527873184770};\\\", \\\"{x:722,y:507,t:1527873184787};\\\", \\\"{x:718,y:504,t:1527873184803};\\\", \\\"{x:717,y:504,t:1527873184820};\\\", \\\"{x:715,y:504,t:1527873184835};\\\", \\\"{x:712,y:504,t:1527873184852};\\\", \\\"{x:707,y:504,t:1527873184870};\\\", \\\"{x:699,y:504,t:1527873184885};\\\", \\\"{x:690,y:504,t:1527873184903};\\\", \\\"{x:684,y:504,t:1527873184920};\\\", \\\"{x:674,y:504,t:1527873184936};\\\", \\\"{x:667,y:506,t:1527873184953};\\\", \\\"{x:654,y:507,t:1527873184969};\\\", \\\"{x:647,y:509,t:1527873184986};\\\", \\\"{x:642,y:509,t:1527873185003};\\\", \\\"{x:640,y:509,t:1527873185019};\\\", \\\"{x:639,y:509,t:1527873185035};\\\", \\\"{x:638,y:509,t:1527873185074};\\\", \\\"{x:637,y:509,t:1527873185114};\\\", \\\"{x:636,y:509,t:1527873185154};\\\", \\\"{x:639,y:509,t:1527873185546};\\\", \\\"{x:641,y:509,t:1527873185553};\\\", \\\"{x:647,y:510,t:1527873185570};\\\", \\\"{x:659,y:510,t:1527873185587};\\\", \\\"{x:677,y:510,t:1527873185603};\\\", \\\"{x:703,y:510,t:1527873185620};\\\", \\\"{x:729,y:510,t:1527873185638};\\\", \\\"{x:754,y:510,t:1527873185654};\\\", \\\"{x:775,y:510,t:1527873185670};\\\", \\\"{x:785,y:510,t:1527873185686};\\\", \\\"{x:786,y:510,t:1527873185704};\\\", \\\"{x:788,y:510,t:1527873185795};\\\", \\\"{x:791,y:510,t:1527873185804};\\\", \\\"{x:797,y:510,t:1527873185820};\\\", \\\"{x:803,y:511,t:1527873185837};\\\", \\\"{x:811,y:514,t:1527873185854};\\\", \\\"{x:817,y:515,t:1527873185870};\\\", \\\"{x:824,y:517,t:1527873185887};\\\", \\\"{x:828,y:518,t:1527873185905};\\\", \\\"{x:829,y:520,t:1527873185954};\\\", \\\"{x:829,y:523,t:1527873185970};\\\", \\\"{x:829,y:525,t:1527873185988};\\\", \\\"{x:829,y:528,t:1527873186003};\\\", \\\"{x:829,y:531,t:1527873186020};\\\", \\\"{x:829,y:532,t:1527873186036};\\\", \\\"{x:829,y:534,t:1527873186053};\\\", \\\"{x:829,y:538,t:1527873186401};\\\", \\\"{x:826,y:544,t:1527873186409};\\\", \\\"{x:821,y:553,t:1527873186421};\\\", \\\"{x:810,y:572,t:1527873186438};\\\", \\\"{x:799,y:592,t:1527873186453};\\\", \\\"{x:783,y:611,t:1527873186472};\\\", \\\"{x:770,y:623,t:1527873186487};\\\", \\\"{x:759,y:630,t:1527873186503};\\\", \\\"{x:754,y:633,t:1527873186521};\\\", \\\"{x:750,y:635,t:1527873186538};\\\", \\\"{x:750,y:636,t:1527873186554};\\\", \\\"{x:749,y:637,t:1527873186593};\\\", \\\"{x:748,y:639,t:1527873186603};\\\", \\\"{x:747,y:641,t:1527873186620};\\\", \\\"{x:746,y:644,t:1527873186638};\\\", \\\"{x:743,y:648,t:1527873186653};\\\", \\\"{x:740,y:652,t:1527873186670};\\\", \\\"{x:736,y:657,t:1527873186688};\\\", \\\"{x:732,y:661,t:1527873186704};\\\", \\\"{x:727,y:663,t:1527873186720};\\\", \\\"{x:720,y:666,t:1527873186738};\\\", \\\"{x:718,y:667,t:1527873186754};\\\", \\\"{x:713,y:668,t:1527873186771};\\\", \\\"{x:708,y:670,t:1527873186787};\\\", \\\"{x:701,y:672,t:1527873186804};\\\", \\\"{x:695,y:674,t:1527873186821};\\\", \\\"{x:686,y:676,t:1527873186838};\\\", \\\"{x:677,y:677,t:1527873186854};\\\", \\\"{x:671,y:679,t:1527873186871};\\\", \\\"{x:663,y:680,t:1527873186888};\\\", \\\"{x:658,y:682,t:1527873186904};\\\", \\\"{x:652,y:683,t:1527873186921};\\\", \\\"{x:644,y:684,t:1527873186938};\\\", \\\"{x:637,y:685,t:1527873186954};\\\", \\\"{x:628,y:686,t:1527873186971};\\\", \\\"{x:620,y:687,t:1527873186988};\\\", \\\"{x:614,y:688,t:1527873187004};\\\", \\\"{x:607,y:689,t:1527873187021};\\\", \\\"{x:602,y:690,t:1527873187038};\\\", \\\"{x:599,y:691,t:1527873187055};\\\", \\\"{x:595,y:691,t:1527873187071};\\\", \\\"{x:589,y:692,t:1527873187088};\\\", \\\"{x:584,y:693,t:1527873187104};\\\", \\\"{x:578,y:694,t:1527873187120};\\\", \\\"{x:568,y:695,t:1527873187138};\\\", \\\"{x:562,y:696,t:1527873187154};\\\", \\\"{x:554,y:697,t:1527873187171};\\\", \\\"{x:548,y:698,t:1527873187188};\\\", \\\"{x:542,y:699,t:1527873187205};\\\", \\\"{x:538,y:699,t:1527873187221};\\\", \\\"{x:534,y:700,t:1527873187238};\\\", \\\"{x:530,y:700,t:1527873187255};\\\", \\\"{x:527,y:701,t:1527873187271};\\\", \\\"{x:522,y:704,t:1527873187287};\\\", \\\"{x:515,y:706,t:1527873187304};\\\", \\\"{x:509,y:707,t:1527873187321};\\\", \\\"{x:502,y:711,t:1527873187339};\\\", \\\"{x:498,y:712,t:1527873187354};\\\", \\\"{x:495,y:715,t:1527873187370};\\\", \\\"{x:491,y:716,t:1527873187388};\\\", \\\"{x:488,y:718,t:1527873187405};\\\", \\\"{x:486,y:719,t:1527873187421};\\\", \\\"{x:484,y:722,t:1527873187439};\\\", \\\"{x:481,y:727,t:1527873187454};\\\", \\\"{x:480,y:734,t:1527873187470};\\\", \\\"{x:477,y:739,t:1527873187487};\\\", \\\"{x:476,y:742,t:1527873187503};\\\", \\\"{x:475,y:744,t:1527873187521};\\\", \\\"{x:474,y:744,t:1527873187536};\\\", \\\"{x:474,y:747,t:1527873187554};\\\", \\\"{x:475,y:755,t:1527873187570};\\\", \\\"{x:476,y:758,t:1527873187586};\\\", \\\"{x:476,y:760,t:1527873187604};\\\", \\\"{x:479,y:759,t:1527873187842};\\\", \\\"{x:481,y:757,t:1527873187854};\\\", \\\"{x:486,y:751,t:1527873187871};\\\", \\\"{x:489,y:747,t:1527873187887};\\\", \\\"{x:491,y:746,t:1527873187904};\\\", \\\"{x:491,y:744,t:1527873187921};\\\", \\\"{x:492,y:744,t:1527873188410};\\\" ] }, { \\\"rt\\\": 42136, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 421465, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"QGUGU\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -C -C -F -F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:502,y:744,t:1527873206131};\\\", \\\"{x:519,y:741,t:1527873206142};\\\", \\\"{x:563,y:737,t:1527873206157};\\\", \\\"{x:603,y:736,t:1527873206177};\\\", \\\"{x:637,y:735,t:1527873206191};\\\", \\\"{x:665,y:735,t:1527873206209};\\\", \\\"{x:687,y:735,t:1527873206219};\\\", \\\"{x:701,y:735,t:1527873206236};\\\", \\\"{x:709,y:735,t:1527873206253};\\\", \\\"{x:713,y:735,t:1527873206270};\\\", \\\"{x:720,y:735,t:1527873206286};\\\", \\\"{x:727,y:734,t:1527873206303};\\\", \\\"{x:739,y:734,t:1527873206319};\\\", \\\"{x:754,y:734,t:1527873206336};\\\", \\\"{x:779,y:734,t:1527873206353};\\\", \\\"{x:798,y:734,t:1527873206369};\\\", \\\"{x:825,y:733,t:1527873206386};\\\", \\\"{x:853,y:729,t:1527873206404};\\\", \\\"{x:875,y:728,t:1527873206419};\\\", \\\"{x:901,y:728,t:1527873206436};\\\", \\\"{x:924,y:728,t:1527873206454};\\\", \\\"{x:949,y:728,t:1527873206469};\\\", \\\"{x:973,y:728,t:1527873206487};\\\", \\\"{x:994,y:728,t:1527873206504};\\\", \\\"{x:1012,y:728,t:1527873206519};\\\", \\\"{x:1031,y:728,t:1527873206537};\\\", \\\"{x:1055,y:728,t:1527873206554};\\\", \\\"{x:1069,y:725,t:1527873206570};\\\", \\\"{x:1084,y:723,t:1527873206587};\\\", \\\"{x:1101,y:720,t:1527873206604};\\\", \\\"{x:1120,y:718,t:1527873206620};\\\", \\\"{x:1141,y:714,t:1527873206638};\\\", \\\"{x:1163,y:710,t:1527873206654};\\\", \\\"{x:1187,y:708,t:1527873206671};\\\", \\\"{x:1209,y:704,t:1527873206687};\\\", \\\"{x:1231,y:701,t:1527873206704};\\\", \\\"{x:1252,y:698,t:1527873206721};\\\", \\\"{x:1270,y:696,t:1527873206737};\\\", \\\"{x:1289,y:692,t:1527873206755};\\\", \\\"{x:1301,y:691,t:1527873206770};\\\", \\\"{x:1308,y:689,t:1527873206786};\\\", \\\"{x:1315,y:689,t:1527873206803};\\\", \\\"{x:1323,y:688,t:1527873206821};\\\", \\\"{x:1331,y:687,t:1527873206837};\\\", \\\"{x:1339,y:686,t:1527873206854};\\\", \\\"{x:1349,y:683,t:1527873206871};\\\", \\\"{x:1361,y:682,t:1527873206887};\\\", \\\"{x:1374,y:679,t:1527873206904};\\\", \\\"{x:1384,y:678,t:1527873206921};\\\", \\\"{x:1396,y:677,t:1527873206937};\\\", \\\"{x:1403,y:676,t:1527873206954};\\\", \\\"{x:1404,y:675,t:1527873206972};\\\", \\\"{x:1406,y:673,t:1527873207435};\\\", \\\"{x:1408,y:671,t:1527873207443};\\\", \\\"{x:1410,y:670,t:1527873207454};\\\", \\\"{x:1415,y:667,t:1527873207471};\\\", \\\"{x:1418,y:666,t:1527873207488};\\\", \\\"{x:1420,y:664,t:1527873207504};\\\", \\\"{x:1422,y:663,t:1527873207521};\\\", \\\"{x:1425,y:660,t:1527873207538};\\\", \\\"{x:1425,y:659,t:1527873207554};\\\", \\\"{x:1426,y:658,t:1527873207571};\\\", \\\"{x:1429,y:653,t:1527873207588};\\\", \\\"{x:1432,y:648,t:1527873207606};\\\", \\\"{x:1433,y:647,t:1527873207621};\\\", \\\"{x:1433,y:646,t:1527873207638};\\\", \\\"{x:1433,y:644,t:1527873207665};\\\", \\\"{x:1433,y:643,t:1527873207681};\\\", \\\"{x:1435,y:641,t:1527873207689};\\\", \\\"{x:1436,y:639,t:1527873207704};\\\", \\\"{x:1438,y:634,t:1527873207721};\\\", \\\"{x:1441,y:626,t:1527873207738};\\\", \\\"{x:1443,y:625,t:1527873207755};\\\", \\\"{x:1443,y:624,t:1527873207770};\\\", \\\"{x:1446,y:622,t:1527873207787};\\\", \\\"{x:1450,y:620,t:1527873207805};\\\", \\\"{x:1454,y:619,t:1527873207820};\\\", \\\"{x:1458,y:619,t:1527873207838};\\\", \\\"{x:1463,y:619,t:1527873207854};\\\", \\\"{x:1465,y:619,t:1527873207870};\\\", \\\"{x:1467,y:619,t:1527873207887};\\\", \\\"{x:1467,y:620,t:1527873208122};\\\", \\\"{x:1467,y:621,t:1527873208138};\\\", \\\"{x:1465,y:622,t:1527873208155};\\\", \\\"{x:1464,y:622,t:1527873208172};\\\", \\\"{x:1462,y:622,t:1527873208188};\\\", \\\"{x:1461,y:623,t:1527873208205};\\\", \\\"{x:1458,y:624,t:1527873208222};\\\", \\\"{x:1456,y:625,t:1527873208239};\\\", \\\"{x:1454,y:626,t:1527873208255};\\\", \\\"{x:1452,y:627,t:1527873208274};\\\", \\\"{x:1451,y:627,t:1527873208287};\\\", \\\"{x:1450,y:627,t:1527873208304};\\\", \\\"{x:1449,y:627,t:1527873208403};\\\", \\\"{x:1444,y:630,t:1527873218451};\\\", \\\"{x:1438,y:631,t:1527873218465};\\\", \\\"{x:1425,y:635,t:1527873218480};\\\", \\\"{x:1411,y:637,t:1527873218497};\\\", \\\"{x:1401,y:638,t:1527873218513};\\\", \\\"{x:1395,y:639,t:1527873218530};\\\", \\\"{x:1394,y:639,t:1527873218546};\\\", \\\"{x:1391,y:639,t:1527873218754};\\\", \\\"{x:1388,y:639,t:1527873218763};\\\", \\\"{x:1381,y:638,t:1527873218780};\\\", \\\"{x:1379,y:636,t:1527873218797};\\\", \\\"{x:1377,y:635,t:1527873218813};\\\", \\\"{x:1376,y:634,t:1527873218858};\\\", \\\"{x:1376,y:633,t:1527873218874};\\\", \\\"{x:1376,y:632,t:1527873218898};\\\", \\\"{x:1376,y:631,t:1527873218922};\\\", \\\"{x:1377,y:631,t:1527873218963};\\\", \\\"{x:1379,y:631,t:1527873218980};\\\", \\\"{x:1379,y:630,t:1527873218997};\\\", \\\"{x:1376,y:633,t:1527873219395};\\\", \\\"{x:1373,y:634,t:1527873219403};\\\", \\\"{x:1370,y:635,t:1527873219414};\\\", \\\"{x:1366,y:637,t:1527873219431};\\\", \\\"{x:1365,y:638,t:1527873219448};\\\", \\\"{x:1363,y:638,t:1527873219463};\\\", \\\"{x:1362,y:640,t:1527873219681};\\\", \\\"{x:1359,y:644,t:1527873219697};\\\", \\\"{x:1357,y:649,t:1527873219714};\\\", \\\"{x:1355,y:653,t:1527873219730};\\\", \\\"{x:1353,y:660,t:1527873219747};\\\", \\\"{x:1351,y:665,t:1527873219764};\\\", \\\"{x:1349,y:671,t:1527873219780};\\\", \\\"{x:1347,y:675,t:1527873219797};\\\", \\\"{x:1346,y:679,t:1527873219814};\\\", \\\"{x:1345,y:682,t:1527873219830};\\\", \\\"{x:1345,y:687,t:1527873219847};\\\", \\\"{x:1344,y:689,t:1527873219864};\\\", \\\"{x:1343,y:693,t:1527873219880};\\\", \\\"{x:1343,y:696,t:1527873219897};\\\", \\\"{x:1343,y:697,t:1527873219913};\\\", \\\"{x:1343,y:699,t:1527873219945};\\\", \\\"{x:1343,y:700,t:1527873219970};\\\", \\\"{x:1343,y:702,t:1527873219994};\\\", \\\"{x:1343,y:701,t:1527873220562};\\\", \\\"{x:1343,y:700,t:1527873220570};\\\", \\\"{x:1344,y:699,t:1527873220581};\\\", \\\"{x:1344,y:697,t:1527873220598};\\\", \\\"{x:1345,y:696,t:1527873220614};\\\", \\\"{x:1346,y:695,t:1527873220631};\\\", \\\"{x:1347,y:694,t:1527873220648};\\\", \\\"{x:1339,y:693,t:1527873227484};\\\", \\\"{x:1318,y:693,t:1527873227490};\\\", \\\"{x:1280,y:698,t:1527873227504};\\\", \\\"{x:1177,y:702,t:1527873227522};\\\", \\\"{x:1080,y:702,t:1527873227537};\\\", \\\"{x:949,y:701,t:1527873227554};\\\", \\\"{x:860,y:701,t:1527873227570};\\\", \\\"{x:772,y:682,t:1527873227587};\\\", \\\"{x:695,y:664,t:1527873227604};\\\", \\\"{x:637,y:647,t:1527873227621};\\\", \\\"{x:603,y:638,t:1527873227637};\\\", \\\"{x:577,y:634,t:1527873227653};\\\", \\\"{x:555,y:631,t:1527873227672};\\\", \\\"{x:536,y:627,t:1527873227686};\\\", \\\"{x:512,y:618,t:1527873227703};\\\", \\\"{x:477,y:603,t:1527873227721};\\\", \\\"{x:440,y:587,t:1527873227737};\\\", \\\"{x:412,y:574,t:1527873227755};\\\", \\\"{x:389,y:561,t:1527873227771};\\\", \\\"{x:371,y:550,t:1527873227788};\\\", \\\"{x:357,y:541,t:1527873227803};\\\", \\\"{x:352,y:537,t:1527873227820};\\\", \\\"{x:348,y:534,t:1527873227837};\\\", \\\"{x:347,y:533,t:1527873227853};\\\", \\\"{x:347,y:532,t:1527873227961};\\\", \\\"{x:347,y:530,t:1527873227970};\\\", \\\"{x:347,y:528,t:1527873227993};\\\", \\\"{x:347,y:527,t:1527873228018};\\\", \\\"{x:346,y:527,t:1527873228042};\\\", \\\"{x:346,y:526,t:1527873228065};\\\", \\\"{x:346,y:525,t:1527873228090};\\\", \\\"{x:344,y:525,t:1527873228162};\\\", \\\"{x:338,y:525,t:1527873228171};\\\", \\\"{x:321,y:527,t:1527873228188};\\\", \\\"{x:305,y:532,t:1527873228205};\\\", \\\"{x:288,y:537,t:1527873228221};\\\", \\\"{x:277,y:538,t:1527873228237};\\\", \\\"{x:269,y:539,t:1527873228257};\\\", \\\"{x:268,y:540,t:1527873228270};\\\", \\\"{x:264,y:540,t:1527873228287};\\\", \\\"{x:256,y:544,t:1527873228304};\\\", \\\"{x:255,y:544,t:1527873228320};\\\", \\\"{x:253,y:545,t:1527873228337};\\\", \\\"{x:251,y:546,t:1527873228355};\\\", \\\"{x:250,y:546,t:1527873228371};\\\", \\\"{x:248,y:548,t:1527873228387};\\\", \\\"{x:246,y:549,t:1527873228405};\\\", \\\"{x:242,y:553,t:1527873228420};\\\", \\\"{x:236,y:559,t:1527873228438};\\\", \\\"{x:227,y:566,t:1527873228455};\\\", \\\"{x:222,y:573,t:1527873228471};\\\", \\\"{x:215,y:582,t:1527873228488};\\\", \\\"{x:211,y:590,t:1527873228504};\\\", \\\"{x:207,y:599,t:1527873228522};\\\", \\\"{x:205,y:604,t:1527873228538};\\\", \\\"{x:205,y:605,t:1527873228554};\\\", \\\"{x:204,y:609,t:1527873228571};\\\", \\\"{x:203,y:611,t:1527873228587};\\\", \\\"{x:203,y:613,t:1527873228604};\\\", \\\"{x:202,y:616,t:1527873228621};\\\", \\\"{x:202,y:619,t:1527873228637};\\\", \\\"{x:202,y:623,t:1527873228654};\\\", \\\"{x:202,y:624,t:1527873228697};\\\", \\\"{x:207,y:625,t:1527873228705};\\\", \\\"{x:230,y:625,t:1527873228721};\\\", \\\"{x:274,y:625,t:1527873228738};\\\", \\\"{x:343,y:610,t:1527873228755};\\\", \\\"{x:425,y:592,t:1527873228772};\\\", \\\"{x:499,y:573,t:1527873228789};\\\", \\\"{x:565,y:560,t:1527873228805};\\\", \\\"{x:609,y:555,t:1527873228822};\\\", \\\"{x:637,y:550,t:1527873228838};\\\", \\\"{x:649,y:547,t:1527873228855};\\\", \\\"{x:651,y:546,t:1527873228871};\\\", \\\"{x:651,y:545,t:1527873228914};\\\", \\\"{x:653,y:543,t:1527873228921};\\\", \\\"{x:655,y:542,t:1527873228938};\\\", \\\"{x:660,y:534,t:1527873228954};\\\", \\\"{x:667,y:525,t:1527873228971};\\\", \\\"{x:670,y:521,t:1527873228989};\\\", \\\"{x:674,y:518,t:1527873229005};\\\", \\\"{x:679,y:515,t:1527873229022};\\\", \\\"{x:686,y:510,t:1527873229037};\\\", \\\"{x:695,y:507,t:1527873229054};\\\", \\\"{x:704,y:505,t:1527873229071};\\\", \\\"{x:722,y:504,t:1527873229089};\\\", \\\"{x:746,y:504,t:1527873229105};\\\", \\\"{x:783,y:499,t:1527873229121};\\\", \\\"{x:802,y:498,t:1527873229138};\\\", \\\"{x:812,y:496,t:1527873229156};\\\", \\\"{x:815,y:495,t:1527873229172};\\\", \\\"{x:817,y:495,t:1527873229188};\\\", \\\"{x:819,y:495,t:1527873229249};\\\", \\\"{x:820,y:495,t:1527873229257};\\\", \\\"{x:821,y:495,t:1527873229271};\\\", \\\"{x:824,y:494,t:1527873229288};\\\", \\\"{x:826,y:494,t:1527873229305};\\\", \\\"{x:827,y:494,t:1527873229377};\\\", \\\"{x:828,y:494,t:1527873229388};\\\", \\\"{x:830,y:494,t:1527873229405};\\\", \\\"{x:831,y:494,t:1527873229424};\\\", \\\"{x:832,y:494,t:1527873229442};\\\", \\\"{x:824,y:494,t:1527873229708};\\\", \\\"{x:785,y:501,t:1527873229725};\\\", \\\"{x:716,y:509,t:1527873229742};\\\", \\\"{x:624,y:525,t:1527873229759};\\\", \\\"{x:516,y:539,t:1527873229776};\\\", \\\"{x:410,y:554,t:1527873229792};\\\", \\\"{x:328,y:562,t:1527873229809};\\\", \\\"{x:260,y:565,t:1527873229826};\\\", \\\"{x:218,y:571,t:1527873229841};\\\", \\\"{x:199,y:572,t:1527873229858};\\\", \\\"{x:193,y:573,t:1527873229875};\\\", \\\"{x:190,y:574,t:1527873229891};\\\", \\\"{x:188,y:574,t:1527873229957};\\\", \\\"{x:185,y:574,t:1527873229965};\\\", \\\"{x:181,y:574,t:1527873229975};\\\", \\\"{x:173,y:574,t:1527873229991};\\\", \\\"{x:160,y:574,t:1527873230009};\\\", \\\"{x:142,y:567,t:1527873230026};\\\", \\\"{x:129,y:559,t:1527873230043};\\\", \\\"{x:121,y:555,t:1527873230058};\\\", \\\"{x:118,y:554,t:1527873230075};\\\", \\\"{x:118,y:553,t:1527873230189};\\\", \\\"{x:118,y:551,t:1527873230196};\\\", \\\"{x:120,y:549,t:1527873230209};\\\", \\\"{x:124,y:547,t:1527873230226};\\\", \\\"{x:125,y:547,t:1527873230243};\\\", \\\"{x:126,y:546,t:1527873230258};\\\", \\\"{x:127,y:546,t:1527873230276};\\\", \\\"{x:130,y:544,t:1527873230293};\\\", \\\"{x:135,y:543,t:1527873230309};\\\", \\\"{x:138,y:542,t:1527873230325};\\\", \\\"{x:141,y:540,t:1527873230342};\\\", \\\"{x:145,y:538,t:1527873230359};\\\", \\\"{x:150,y:536,t:1527873230377};\\\", \\\"{x:155,y:534,t:1527873230393};\\\", \\\"{x:158,y:532,t:1527873230408};\\\", \\\"{x:163,y:529,t:1527873230426};\\\", \\\"{x:165,y:529,t:1527873230442};\\\", \\\"{x:173,y:532,t:1527873230724};\\\", \\\"{x:188,y:543,t:1527873230732};\\\", \\\"{x:221,y:561,t:1527873230743};\\\", \\\"{x:306,y:610,t:1527873230759};\\\", \\\"{x:401,y:659,t:1527873230775};\\\", \\\"{x:482,y:689,t:1527873230793};\\\", \\\"{x:524,y:700,t:1527873230810};\\\", \\\"{x:545,y:705,t:1527873230825};\\\", \\\"{x:550,y:706,t:1527873230842};\\\", \\\"{x:550,y:708,t:1527873231125};\\\", \\\"{x:551,y:711,t:1527873231133};\\\", \\\"{x:551,y:714,t:1527873231143};\\\", \\\"{x:553,y:721,t:1527873231160};\\\", \\\"{x:553,y:727,t:1527873231176};\\\", \\\"{x:553,y:729,t:1527873231192};\\\", \\\"{x:553,y:731,t:1527873231209};\\\" ] }, { \\\"rt\\\": 40991, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 463706, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"QGUGU\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:555,y:732,t:1527873235061};\\\", \\\"{x:561,y:733,t:1527873235069};\\\", \\\"{x:567,y:735,t:1527873235084};\\\", \\\"{x:583,y:735,t:1527873235098};\\\", \\\"{x:598,y:735,t:1527873235114};\\\", \\\"{x:617,y:735,t:1527873235130};\\\", \\\"{x:635,y:735,t:1527873235145};\\\", \\\"{x:655,y:735,t:1527873235162};\\\", \\\"{x:673,y:735,t:1527873235180};\\\", \\\"{x:691,y:736,t:1527873235196};\\\", \\\"{x:712,y:736,t:1527873235213};\\\", \\\"{x:724,y:736,t:1527873235230};\\\", \\\"{x:733,y:737,t:1527873235246};\\\", \\\"{x:738,y:738,t:1527873235263};\\\", \\\"{x:743,y:739,t:1527873235279};\\\", \\\"{x:748,y:740,t:1527873235297};\\\", \\\"{x:756,y:741,t:1527873235312};\\\", \\\"{x:773,y:742,t:1527873235329};\\\", \\\"{x:795,y:745,t:1527873235346};\\\", \\\"{x:818,y:746,t:1527873235363};\\\", \\\"{x:840,y:747,t:1527873235380};\\\", \\\"{x:878,y:747,t:1527873235396};\\\", \\\"{x:910,y:747,t:1527873235413};\\\", \\\"{x:946,y:747,t:1527873235430};\\\", \\\"{x:977,y:747,t:1527873235446};\\\", \\\"{x:1005,y:747,t:1527873235463};\\\", \\\"{x:1040,y:747,t:1527873235480};\\\", \\\"{x:1080,y:740,t:1527873235497};\\\", \\\"{x:1119,y:735,t:1527873235513};\\\", \\\"{x:1158,y:729,t:1527873235531};\\\", \\\"{x:1190,y:723,t:1527873235547};\\\", \\\"{x:1215,y:715,t:1527873235563};\\\", \\\"{x:1238,y:703,t:1527873235580};\\\", \\\"{x:1272,y:688,t:1527873235597};\\\", \\\"{x:1291,y:679,t:1527873235613};\\\", \\\"{x:1302,y:674,t:1527873235630};\\\", \\\"{x:1307,y:673,t:1527873235647};\\\", \\\"{x:1309,y:671,t:1527873235663};\\\", \\\"{x:1310,y:671,t:1527873235680};\\\", \\\"{x:1311,y:670,t:1527873235697};\\\", \\\"{x:1313,y:670,t:1527873235713};\\\", \\\"{x:1314,y:669,t:1527873235729};\\\", \\\"{x:1315,y:668,t:1527873235747};\\\", \\\"{x:1317,y:666,t:1527873235763};\\\", \\\"{x:1319,y:664,t:1527873235780};\\\", \\\"{x:1325,y:661,t:1527873235797};\\\", \\\"{x:1331,y:658,t:1527873235813};\\\", \\\"{x:1337,y:654,t:1527873235830};\\\", \\\"{x:1347,y:650,t:1527873235847};\\\", \\\"{x:1363,y:644,t:1527873235863};\\\", \\\"{x:1380,y:635,t:1527873235880};\\\", \\\"{x:1402,y:628,t:1527873235898};\\\", \\\"{x:1426,y:623,t:1527873235914};\\\", \\\"{x:1450,y:617,t:1527873235931};\\\", \\\"{x:1473,y:610,t:1527873235948};\\\", \\\"{x:1493,y:606,t:1527873235965};\\\", \\\"{x:1503,y:603,t:1527873235980};\\\", \\\"{x:1507,y:602,t:1527873235997};\\\", \\\"{x:1508,y:600,t:1527873236333};\\\", \\\"{x:1508,y:599,t:1527873236348};\\\", \\\"{x:1504,y:598,t:1527873236365};\\\", \\\"{x:1499,y:596,t:1527873236821};\\\", \\\"{x:1489,y:593,t:1527873236832};\\\", \\\"{x:1461,y:584,t:1527873236848};\\\", \\\"{x:1430,y:576,t:1527873236864};\\\", \\\"{x:1397,y:568,t:1527873236881};\\\", \\\"{x:1360,y:557,t:1527873236898};\\\", \\\"{x:1335,y:553,t:1527873236914};\\\", \\\"{x:1320,y:551,t:1527873236932};\\\", \\\"{x:1313,y:550,t:1527873236949};\\\", \\\"{x:1312,y:549,t:1527873237013};\\\", \\\"{x:1309,y:549,t:1527873237157};\\\", \\\"{x:1305,y:549,t:1527873237165};\\\", \\\"{x:1295,y:549,t:1527873237181};\\\", \\\"{x:1281,y:550,t:1527873237198};\\\", \\\"{x:1270,y:551,t:1527873237216};\\\", \\\"{x:1258,y:553,t:1527873237231};\\\", \\\"{x:1247,y:554,t:1527873237249};\\\", \\\"{x:1239,y:554,t:1527873237265};\\\", \\\"{x:1231,y:554,t:1527873237281};\\\", \\\"{x:1227,y:554,t:1527873237298};\\\", \\\"{x:1225,y:554,t:1527873237315};\\\", \\\"{x:1222,y:554,t:1527873237331};\\\", \\\"{x:1219,y:554,t:1527873237349};\\\", \\\"{x:1215,y:554,t:1527873237365};\\\", \\\"{x:1212,y:554,t:1527873237381};\\\", \\\"{x:1210,y:553,t:1527873237398};\\\", \\\"{x:1207,y:553,t:1527873237415};\\\", \\\"{x:1204,y:552,t:1527873237431};\\\", \\\"{x:1196,y:552,t:1527873237449};\\\", \\\"{x:1189,y:550,t:1527873237465};\\\", \\\"{x:1179,y:549,t:1527873237481};\\\", \\\"{x:1170,y:548,t:1527873237499};\\\", \\\"{x:1165,y:547,t:1527873237516};\\\", \\\"{x:1157,y:546,t:1527873237532};\\\", \\\"{x:1153,y:545,t:1527873237548};\\\", \\\"{x:1147,y:543,t:1527873237564};\\\", \\\"{x:1144,y:543,t:1527873237581};\\\", \\\"{x:1142,y:541,t:1527873237598};\\\", \\\"{x:1140,y:541,t:1527873237616};\\\", \\\"{x:1137,y:541,t:1527873237631};\\\", \\\"{x:1136,y:541,t:1527873237649};\\\", \\\"{x:1134,y:540,t:1527873237665};\\\", \\\"{x:1131,y:539,t:1527873237683};\\\", \\\"{x:1130,y:538,t:1527873237698};\\\", \\\"{x:1128,y:537,t:1527873237715};\\\", \\\"{x:1124,y:535,t:1527873237731};\\\", \\\"{x:1123,y:534,t:1527873237748};\\\", \\\"{x:1120,y:531,t:1527873237765};\\\", \\\"{x:1118,y:531,t:1527873237782};\\\", \\\"{x:1115,y:528,t:1527873237798};\\\", \\\"{x:1113,y:527,t:1527873237814};\\\", \\\"{x:1112,y:526,t:1527873237852};\\\", \\\"{x:1112,y:525,t:1527873237865};\\\", \\\"{x:1110,y:524,t:1527873237882};\\\", \\\"{x:1107,y:522,t:1527873237898};\\\", \\\"{x:1106,y:520,t:1527873237915};\\\", \\\"{x:1105,y:519,t:1527873237932};\\\", \\\"{x:1104,y:518,t:1527873237948};\\\", \\\"{x:1103,y:517,t:1527873237965};\\\", \\\"{x:1103,y:516,t:1527873237983};\\\", \\\"{x:1102,y:515,t:1527873238005};\\\", \\\"{x:1101,y:514,t:1527873238045};\\\", \\\"{x:1101,y:513,t:1527873238061};\\\", \\\"{x:1101,y:512,t:1527873238085};\\\", \\\"{x:1101,y:511,t:1527873238133};\\\", \\\"{x:1101,y:510,t:1527873238149};\\\", \\\"{x:1101,y:507,t:1527873238165};\\\", \\\"{x:1101,y:506,t:1527873238183};\\\", \\\"{x:1101,y:505,t:1527873238205};\\\", \\\"{x:1102,y:504,t:1527873238221};\\\", \\\"{x:1102,y:503,t:1527873238236};\\\", \\\"{x:1103,y:503,t:1527873238253};\\\", \\\"{x:1104,y:502,t:1527873238268};\\\", \\\"{x:1106,y:501,t:1527873238284};\\\", \\\"{x:1107,y:501,t:1527873238299};\\\", \\\"{x:1109,y:500,t:1527873238315};\\\", \\\"{x:1115,y:499,t:1527873238332};\\\", \\\"{x:1123,y:499,t:1527873238348};\\\", \\\"{x:1134,y:499,t:1527873238365};\\\", \\\"{x:1146,y:499,t:1527873238382};\\\", \\\"{x:1160,y:499,t:1527873238399};\\\", \\\"{x:1179,y:499,t:1527873238415};\\\", \\\"{x:1198,y:499,t:1527873238432};\\\", \\\"{x:1223,y:499,t:1527873238449};\\\", \\\"{x:1245,y:502,t:1527873238465};\\\", \\\"{x:1261,y:503,t:1527873238482};\\\", \\\"{x:1278,y:504,t:1527873238499};\\\", \\\"{x:1294,y:507,t:1527873238515};\\\", \\\"{x:1309,y:508,t:1527873238533};\\\", \\\"{x:1332,y:509,t:1527873238549};\\\", \\\"{x:1343,y:509,t:1527873238567};\\\", \\\"{x:1353,y:509,t:1527873238583};\\\", \\\"{x:1364,y:509,t:1527873238599};\\\", \\\"{x:1373,y:509,t:1527873238616};\\\", \\\"{x:1383,y:509,t:1527873238632};\\\", \\\"{x:1392,y:509,t:1527873238649};\\\", \\\"{x:1405,y:509,t:1527873238666};\\\", \\\"{x:1420,y:509,t:1527873238682};\\\", \\\"{x:1436,y:509,t:1527873238699};\\\", \\\"{x:1458,y:509,t:1527873238715};\\\", \\\"{x:1475,y:509,t:1527873238731};\\\", \\\"{x:1488,y:509,t:1527873238748};\\\", \\\"{x:1497,y:509,t:1527873238766};\\\", \\\"{x:1502,y:509,t:1527873238782};\\\", \\\"{x:1504,y:509,t:1527873238798};\\\", \\\"{x:1505,y:509,t:1527873238816};\\\", \\\"{x:1507,y:509,t:1527873238832};\\\", \\\"{x:1509,y:509,t:1527873238893};\\\", \\\"{x:1512,y:509,t:1527873238900};\\\", \\\"{x:1518,y:509,t:1527873238916};\\\", \\\"{x:1527,y:509,t:1527873238933};\\\", \\\"{x:1538,y:509,t:1527873238950};\\\", \\\"{x:1546,y:509,t:1527873238967};\\\", \\\"{x:1553,y:508,t:1527873238982};\\\", \\\"{x:1555,y:507,t:1527873238999};\\\", \\\"{x:1551,y:508,t:1527873263597};\\\", \\\"{x:1540,y:510,t:1527873263604};\\\", \\\"{x:1527,y:513,t:1527873263619};\\\", \\\"{x:1503,y:518,t:1527873263635};\\\", \\\"{x:1464,y:524,t:1527873263652};\\\", \\\"{x:1438,y:527,t:1527873263669};\\\", \\\"{x:1412,y:530,t:1527873263685};\\\", \\\"{x:1395,y:531,t:1527873263702};\\\", \\\"{x:1379,y:531,t:1527873263719};\\\", \\\"{x:1370,y:531,t:1527873263735};\\\", \\\"{x:1367,y:531,t:1527873263752};\\\", \\\"{x:1365,y:531,t:1527873263769};\\\", \\\"{x:1364,y:531,t:1527873263785};\\\", \\\"{x:1361,y:531,t:1527873263803};\\\", \\\"{x:1357,y:531,t:1527873263819};\\\", \\\"{x:1334,y:531,t:1527873263836};\\\", \\\"{x:1308,y:531,t:1527873263852};\\\", \\\"{x:1253,y:525,t:1527873263869};\\\", \\\"{x:1134,y:508,t:1527873263886};\\\", \\\"{x:976,y:489,t:1527873263902};\\\", \\\"{x:815,y:484,t:1527873263919};\\\", \\\"{x:682,y:487,t:1527873263937};\\\", \\\"{x:565,y:504,t:1527873263952};\\\", \\\"{x:473,y:507,t:1527873263970};\\\", \\\"{x:384,y:509,t:1527873263986};\\\", \\\"{x:327,y:511,t:1527873264003};\\\", \\\"{x:306,y:514,t:1527873264019};\\\", \\\"{x:304,y:515,t:1527873264036};\\\", \\\"{x:307,y:516,t:1527873264284};\\\", \\\"{x:322,y:516,t:1527873264292};\\\", \\\"{x:342,y:516,t:1527873264302};\\\", \\\"{x:417,y:523,t:1527873264320};\\\", \\\"{x:492,y:523,t:1527873264336};\\\", \\\"{x:545,y:523,t:1527873264353};\\\", \\\"{x:573,y:523,t:1527873264369};\\\", \\\"{x:595,y:523,t:1527873264386};\\\", \\\"{x:603,y:523,t:1527873264403};\\\", \\\"{x:604,y:523,t:1527873264420};\\\", \\\"{x:605,y:523,t:1527873264869};\\\", \\\"{x:607,y:523,t:1527873264876};\\\", \\\"{x:610,y:523,t:1527873264888};\\\", \\\"{x:614,y:523,t:1527873264903};\\\", \\\"{x:619,y:523,t:1527873264920};\\\", \\\"{x:623,y:522,t:1527873264937};\\\", \\\"{x:626,y:522,t:1527873264953};\\\", \\\"{x:627,y:522,t:1527873265020};\\\", \\\"{x:628,y:522,t:1527873265045};\\\", \\\"{x:629,y:522,t:1527873265068};\\\", \\\"{x:629,y:523,t:1527873265100};\\\", \\\"{x:627,y:522,t:1527873265357};\\\", \\\"{x:624,y:518,t:1527873265371};\\\", \\\"{x:620,y:512,t:1527873265389};\\\", \\\"{x:617,y:507,t:1527873265403};\\\", \\\"{x:616,y:507,t:1527873265420};\\\", \\\"{x:616,y:506,t:1527873265884};\\\", \\\"{x:615,y:506,t:1527873265892};\\\", \\\"{x:615,y:507,t:1527873265905};\\\", \\\"{x:612,y:512,t:1527873265921};\\\", \\\"{x:609,y:519,t:1527873265939};\\\", \\\"{x:604,y:527,t:1527873265954};\\\", \\\"{x:598,y:538,t:1527873265971};\\\", \\\"{x:593,y:550,t:1527873265987};\\\", \\\"{x:582,y:574,t:1527873266005};\\\", \\\"{x:573,y:596,t:1527873266022};\\\", \\\"{x:567,y:610,t:1527873266039};\\\", \\\"{x:562,y:622,t:1527873266053};\\\", \\\"{x:557,y:632,t:1527873266071};\\\", \\\"{x:555,y:640,t:1527873266087};\\\", \\\"{x:553,y:644,t:1527873266104};\\\", \\\"{x:550,y:650,t:1527873266121};\\\", \\\"{x:549,y:653,t:1527873266138};\\\", \\\"{x:548,y:658,t:1527873266154};\\\", \\\"{x:545,y:662,t:1527873266171};\\\", \\\"{x:544,y:666,t:1527873266187};\\\", \\\"{x:544,y:667,t:1527873266204};\\\", \\\"{x:543,y:669,t:1527873266221};\\\", \\\"{x:542,y:670,t:1527873266238};\\\", \\\"{x:542,y:671,t:1527873266267};\\\", \\\"{x:541,y:672,t:1527873266300};\\\", \\\"{x:541,y:673,t:1527873266316};\\\", \\\"{x:541,y:674,t:1527873266332};\\\", \\\"{x:541,y:675,t:1527873266340};\\\", \\\"{x:539,y:677,t:1527873266355};\\\", \\\"{x:539,y:681,t:1527873266372};\\\", \\\"{x:538,y:692,t:1527873266389};\\\", \\\"{x:538,y:699,t:1527873266405};\\\", \\\"{x:538,y:704,t:1527873266421};\\\", \\\"{x:538,y:716,t:1527873266439};\\\", \\\"{x:538,y:727,t:1527873266457};\\\", \\\"{x:538,y:735,t:1527873266471};\\\", \\\"{x:538,y:741,t:1527873266488};\\\", \\\"{x:538,y:742,t:1527873266504};\\\", \\\"{x:538,y:744,t:1527873266521};\\\", \\\"{x:537,y:745,t:1527873266538};\\\", \\\"{x:537,y:747,t:1527873266555};\\\", \\\"{x:535,y:747,t:1527873266773};\\\", \\\"{x:534,y:743,t:1527873266788};\\\", \\\"{x:532,y:738,t:1527873266806};\\\", \\\"{x:531,y:733,t:1527873266821};\\\", \\\"{x:531,y:730,t:1527873266839};\\\", \\\"{x:531,y:729,t:1527873266855};\\\", \\\"{x:530,y:729,t:1527873266871};\\\", \\\"{x:530,y:726,t:1527873274332};\\\", \\\"{x:530,y:724,t:1527873274345};\\\", \\\"{x:530,y:719,t:1527873274360};\\\", \\\"{x:530,y:714,t:1527873274377};\\\", \\\"{x:530,y:711,t:1527873274394};\\\", \\\"{x:530,y:708,t:1527873274411};\\\", \\\"{x:531,y:705,t:1527873274427};\\\", \\\"{x:531,y:702,t:1527873274444};\\\", \\\"{x:532,y:701,t:1527873274461};\\\", \\\"{x:532,y:698,t:1527873274477};\\\", \\\"{x:532,y:695,t:1527873274494};\\\", \\\"{x:532,y:693,t:1527873274511};\\\", \\\"{x:533,y:691,t:1527873274528};\\\", \\\"{x:535,y:688,t:1527873274545};\\\", \\\"{x:535,y:686,t:1527873274561};\\\", \\\"{x:535,y:685,t:1527873274578};\\\", \\\"{x:536,y:682,t:1527873274595};\\\", \\\"{x:537,y:679,t:1527873274610};\\\", \\\"{x:537,y:678,t:1527873274628};\\\", \\\"{x:537,y:674,t:1527873274644};\\\", \\\"{x:538,y:672,t:1527873274661};\\\", \\\"{x:538,y:667,t:1527873274678};\\\", \\\"{x:538,y:662,t:1527873274695};\\\", \\\"{x:538,y:658,t:1527873274711};\\\", \\\"{x:538,y:655,t:1527873274764};\\\", \\\"{x:537,y:654,t:1527873274802};\\\", \\\"{x:536,y:654,t:1527873274819};\\\" ] }, { \\\"rt\\\": 28273, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 493285, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"QGUGU\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -J -I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:480,y:708,t:1527873275008};\\\", \\\"{x:475,y:714,t:1527873275023};\\\", \\\"{x:474,y:716,t:1527873275035};\\\", \\\"{x:472,y:718,t:1527873275044};\\\", \\\"{x:469,y:723,t:1527873275062};\\\", \\\"{x:463,y:731,t:1527873275078};\\\", \\\"{x:454,y:739,t:1527873275094};\\\", \\\"{x:446,y:745,t:1527873275112};\\\", \\\"{x:444,y:748,t:1527873275143};\\\", \\\"{x:441,y:749,t:1527873275162};\\\", \\\"{x:442,y:748,t:1527873275700};\\\", \\\"{x:444,y:747,t:1527873275712};\\\", \\\"{x:447,y:741,t:1527873275729};\\\", \\\"{x:452,y:735,t:1527873275745};\\\", \\\"{x:456,y:728,t:1527873275763};\\\", \\\"{x:460,y:723,t:1527873275778};\\\", \\\"{x:467,y:713,t:1527873275796};\\\", \\\"{x:470,y:709,t:1527873275813};\\\", \\\"{x:474,y:705,t:1527873275828};\\\", \\\"{x:476,y:702,t:1527873275846};\\\", \\\"{x:480,y:694,t:1527873275862};\\\", \\\"{x:485,y:684,t:1527873275879};\\\", \\\"{x:488,y:675,t:1527873275896};\\\", \\\"{x:493,y:662,t:1527873275913};\\\", \\\"{x:496,y:651,t:1527873275928};\\\", \\\"{x:498,y:643,t:1527873275946};\\\", \\\"{x:501,y:636,t:1527873275963};\\\", \\\"{x:501,y:634,t:1527873275980};\\\", \\\"{x:501,y:632,t:1527873275995};\\\", \\\"{x:501,y:631,t:1527873276013};\\\", \\\"{x:501,y:629,t:1527873276029};\\\", \\\"{x:501,y:627,t:1527873276166};\\\", \\\"{x:498,y:626,t:1527873276181};\\\", \\\"{x:493,y:625,t:1527873276196};\\\", \\\"{x:491,y:624,t:1527873276235};\\\", \\\"{x:490,y:624,t:1527873276252};\\\", \\\"{x:489,y:624,t:1527873276267};\\\", \\\"{x:488,y:624,t:1527873276279};\\\", \\\"{x:487,y:624,t:1527873276365};\\\", \\\"{x:492,y:624,t:1527873277244};\\\", \\\"{x:506,y:624,t:1527873277254};\\\", \\\"{x:527,y:624,t:1527873277264};\\\", \\\"{x:586,y:624,t:1527873277280};\\\", \\\"{x:666,y:624,t:1527873277297};\\\", \\\"{x:765,y:616,t:1527873277314};\\\", \\\"{x:887,y:616,t:1527873277330};\\\", \\\"{x:1009,y:616,t:1527873277347};\\\", \\\"{x:1191,y:616,t:1527873277363};\\\", \\\"{x:1294,y:616,t:1527873277380};\\\", \\\"{x:1352,y:616,t:1527873277397};\\\", \\\"{x:1384,y:616,t:1527873277414};\\\", \\\"{x:1405,y:618,t:1527873277430};\\\", \\\"{x:1420,y:619,t:1527873277446};\\\", \\\"{x:1429,y:623,t:1527873277464};\\\", \\\"{x:1436,y:626,t:1527873277481};\\\", \\\"{x:1444,y:630,t:1527873277499};\\\", \\\"{x:1455,y:635,t:1527873277514};\\\", \\\"{x:1468,y:641,t:1527873277531};\\\", \\\"{x:1490,y:652,t:1527873277547};\\\", \\\"{x:1516,y:672,t:1527873277565};\\\", \\\"{x:1523,y:681,t:1527873277580};\\\", \\\"{x:1529,y:691,t:1527873277597};\\\", \\\"{x:1535,y:708,t:1527873277613};\\\", \\\"{x:1538,y:719,t:1527873277631};\\\", \\\"{x:1539,y:731,t:1527873277646};\\\", \\\"{x:1539,y:744,t:1527873277665};\\\", \\\"{x:1538,y:755,t:1527873277681};\\\", \\\"{x:1535,y:763,t:1527873277697};\\\", \\\"{x:1529,y:772,t:1527873277714};\\\", \\\"{x:1522,y:779,t:1527873277731};\\\", \\\"{x:1512,y:786,t:1527873277748};\\\", \\\"{x:1492,y:796,t:1527873277765};\\\", \\\"{x:1475,y:803,t:1527873277780};\\\", \\\"{x:1463,y:808,t:1527873277797};\\\", \\\"{x:1454,y:810,t:1527873277814};\\\", \\\"{x:1442,y:810,t:1527873277831};\\\", \\\"{x:1424,y:810,t:1527873277848};\\\", \\\"{x:1402,y:810,t:1527873277864};\\\", \\\"{x:1382,y:810,t:1527873277881};\\\", \\\"{x:1365,y:810,t:1527873277897};\\\", \\\"{x:1349,y:810,t:1527873277914};\\\", \\\"{x:1334,y:810,t:1527873277931};\\\", \\\"{x:1320,y:810,t:1527873277948};\\\", \\\"{x:1302,y:812,t:1527873277965};\\\", \\\"{x:1294,y:812,t:1527873277981};\\\", \\\"{x:1288,y:814,t:1527873277998};\\\", \\\"{x:1284,y:814,t:1527873278014};\\\", \\\"{x:1281,y:815,t:1527873278031};\\\", \\\"{x:1277,y:817,t:1527873278047};\\\", \\\"{x:1272,y:818,t:1527873278064};\\\", \\\"{x:1266,y:820,t:1527873278081};\\\", \\\"{x:1262,y:821,t:1527873278098};\\\", \\\"{x:1259,y:822,t:1527873278114};\\\", \\\"{x:1256,y:823,t:1527873278132};\\\", \\\"{x:1253,y:823,t:1527873278147};\\\", \\\"{x:1250,y:823,t:1527873278166};\\\", \\\"{x:1247,y:823,t:1527873278181};\\\", \\\"{x:1244,y:823,t:1527873278197};\\\", \\\"{x:1240,y:823,t:1527873278214};\\\", \\\"{x:1235,y:823,t:1527873278231};\\\", \\\"{x:1229,y:823,t:1527873278248};\\\", \\\"{x:1228,y:823,t:1527873278264};\\\", \\\"{x:1227,y:823,t:1527873278281};\\\", \\\"{x:1225,y:823,t:1527873278557};\\\", \\\"{x:1224,y:823,t:1527873278566};\\\", \\\"{x:1220,y:826,t:1527873278581};\\\", \\\"{x:1216,y:828,t:1527873278599};\\\", \\\"{x:1214,y:829,t:1527873278614};\\\", \\\"{x:1213,y:830,t:1527873278632};\\\", \\\"{x:1212,y:830,t:1527873292248};\\\", \\\"{x:1210,y:830,t:1527873292336};\\\", \\\"{x:1205,y:822,t:1527873292345};\\\", \\\"{x:1198,y:815,t:1527873292356};\\\", \\\"{x:1189,y:806,t:1527873292373};\\\", \\\"{x:1185,y:799,t:1527873292390};\\\", \\\"{x:1182,y:795,t:1527873292406};\\\", \\\"{x:1180,y:791,t:1527873292423};\\\", \\\"{x:1179,y:790,t:1527873292440};\\\", \\\"{x:1179,y:789,t:1527873292457};\\\", \\\"{x:1179,y:788,t:1527873293336};\\\", \\\"{x:1178,y:786,t:1527873293344};\\\", \\\"{x:1177,y:785,t:1527873293356};\\\", \\\"{x:1175,y:784,t:1527873293374};\\\", \\\"{x:1173,y:783,t:1527873293391};\\\", \\\"{x:1171,y:781,t:1527873293406};\\\", \\\"{x:1168,y:778,t:1527873293424};\\\", \\\"{x:1166,y:775,t:1527873293440};\\\", \\\"{x:1164,y:774,t:1527873293457};\\\", \\\"{x:1161,y:772,t:1527873293473};\\\", \\\"{x:1158,y:770,t:1527873293490};\\\", \\\"{x:1155,y:767,t:1527873293508};\\\", \\\"{x:1151,y:763,t:1527873293524};\\\", \\\"{x:1147,y:759,t:1527873293541};\\\", \\\"{x:1145,y:756,t:1527873293557};\\\", \\\"{x:1143,y:754,t:1527873293574};\\\", \\\"{x:1142,y:751,t:1527873293591};\\\", \\\"{x:1141,y:751,t:1527873293607};\\\", \\\"{x:1141,y:750,t:1527873293623};\\\", \\\"{x:1141,y:751,t:1527873294496};\\\", \\\"{x:1142,y:753,t:1527873294507};\\\", \\\"{x:1142,y:755,t:1527873294524};\\\", \\\"{x:1145,y:758,t:1527873294540};\\\", \\\"{x:1145,y:759,t:1527873294558};\\\", \\\"{x:1147,y:759,t:1527873294609};\\\", \\\"{x:1148,y:759,t:1527873294624};\\\", \\\"{x:1152,y:761,t:1527873294641};\\\", \\\"{x:1158,y:764,t:1527873294657};\\\", \\\"{x:1165,y:766,t:1527873294675};\\\", \\\"{x:1173,y:768,t:1527873294691};\\\", \\\"{x:1180,y:769,t:1527873294707};\\\", \\\"{x:1183,y:770,t:1527873294725};\\\", \\\"{x:1185,y:770,t:1527873294741};\\\", \\\"{x:1187,y:770,t:1527873294757};\\\", \\\"{x:1188,y:772,t:1527873294774};\\\", \\\"{x:1190,y:772,t:1527873294792};\\\", \\\"{x:1191,y:772,t:1527873294824};\\\", \\\"{x:1193,y:772,t:1527873294840};\\\", \\\"{x:1194,y:772,t:1527873294857};\\\", \\\"{x:1196,y:772,t:1527873294874};\\\", \\\"{x:1196,y:771,t:1527873296856};\\\", \\\"{x:1193,y:769,t:1527873296864};\\\", \\\"{x:1190,y:768,t:1527873296874};\\\", \\\"{x:1187,y:767,t:1527873296892};\\\", \\\"{x:1186,y:766,t:1527873296909};\\\", \\\"{x:1185,y:766,t:1527873296944};\\\", \\\"{x:1186,y:766,t:1527873297840};\\\", \\\"{x:1188,y:766,t:1527873297849};\\\", \\\"{x:1189,y:766,t:1527873297864};\\\", \\\"{x:1190,y:766,t:1527873297875};\\\", \\\"{x:1192,y:767,t:1527873297892};\\\", \\\"{x:1193,y:769,t:1527873297909};\\\", \\\"{x:1195,y:770,t:1527873297925};\\\", \\\"{x:1197,y:771,t:1527873297942};\\\", \\\"{x:1197,y:772,t:1527873297959};\\\", \\\"{x:1198,y:774,t:1527873297976};\\\", \\\"{x:1198,y:773,t:1527873298312};\\\", \\\"{x:1198,y:772,t:1527873298325};\\\", \\\"{x:1198,y:771,t:1527873298760};\\\", \\\"{x:1157,y:774,t:1527873298775};\\\", \\\"{x:1054,y:776,t:1527873298792};\\\", \\\"{x:916,y:776,t:1527873298808};\\\", \\\"{x:744,y:776,t:1527873298825};\\\", \\\"{x:589,y:776,t:1527873298842};\\\", \\\"{x:460,y:748,t:1527873298859};\\\", \\\"{x:348,y:704,t:1527873298875};\\\", \\\"{x:264,y:659,t:1527873298892};\\\", \\\"{x:176,y:607,t:1527873298911};\\\", \\\"{x:147,y:587,t:1527873298929};\\\", \\\"{x:135,y:574,t:1527873298950};\\\", \\\"{x:137,y:574,t:1527873299022};\\\", \\\"{x:138,y:574,t:1527873299055};\\\", \\\"{x:142,y:573,t:1527873299200};\\\", \\\"{x:144,y:570,t:1527873299208};\\\", \\\"{x:148,y:567,t:1527873299219};\\\", \\\"{x:151,y:563,t:1527873299235};\\\", \\\"{x:156,y:557,t:1527873299253};\\\", \\\"{x:158,y:555,t:1527873299269};\\\", \\\"{x:158,y:553,t:1527873299310};\\\", \\\"{x:158,y:552,t:1527873299335};\\\", \\\"{x:157,y:550,t:1527873299383};\\\", \\\"{x:156,y:549,t:1527873299403};\\\", \\\"{x:154,y:548,t:1527873299418};\\\", \\\"{x:153,y:546,t:1527873299435};\\\", \\\"{x:153,y:540,t:1527873299451};\\\", \\\"{x:155,y:534,t:1527873299468};\\\", \\\"{x:160,y:528,t:1527873299485};\\\", \\\"{x:166,y:524,t:1527873299502};\\\", \\\"{x:168,y:524,t:1527873299518};\\\", \\\"{x:171,y:524,t:1527873299535};\\\", \\\"{x:172,y:524,t:1527873299559};\\\", \\\"{x:173,y:524,t:1527873299576};\\\", \\\"{x:174,y:524,t:1527873299586};\\\", \\\"{x:175,y:524,t:1527873299607};\\\", \\\"{x:176,y:524,t:1527873299618};\\\", \\\"{x:177,y:524,t:1527873299635};\\\", \\\"{x:180,y:524,t:1527873299653};\\\", \\\"{x:181,y:525,t:1527873299669};\\\", \\\"{x:183,y:529,t:1527873299685};\\\", \\\"{x:184,y:535,t:1527873299702};\\\", \\\"{x:185,y:538,t:1527873299718};\\\", \\\"{x:185,y:543,t:1527873299735};\\\", \\\"{x:186,y:546,t:1527873299752};\\\", \\\"{x:186,y:547,t:1527873299768};\\\", \\\"{x:187,y:549,t:1527873300208};\\\", \\\"{x:191,y:554,t:1527873300221};\\\", \\\"{x:201,y:564,t:1527873300235};\\\", \\\"{x:223,y:584,t:1527873300252};\\\", \\\"{x:278,y:619,t:1527873300270};\\\", \\\"{x:359,y:663,t:1527873300286};\\\", \\\"{x:456,y:705,t:1527873300303};\\\", \\\"{x:562,y:749,t:1527873300318};\\\", \\\"{x:603,y:759,t:1527873300335};\\\", \\\"{x:629,y:764,t:1527873300352};\\\", \\\"{x:655,y:766,t:1527873300369};\\\", \\\"{x:682,y:766,t:1527873300385};\\\", \\\"{x:705,y:766,t:1527873300402};\\\", \\\"{x:716,y:766,t:1527873300419};\\\", \\\"{x:723,y:764,t:1527873300435};\\\", \\\"{x:724,y:763,t:1527873300452};\\\", \\\"{x:721,y:763,t:1527873300592};\\\", \\\"{x:717,y:764,t:1527873300602};\\\", \\\"{x:702,y:764,t:1527873300619};\\\", \\\"{x:680,y:764,t:1527873300636};\\\", \\\"{x:648,y:756,t:1527873300652};\\\", \\\"{x:610,y:742,t:1527873300670};\\\", \\\"{x:567,y:726,t:1527873300686};\\\", \\\"{x:525,y:706,t:1527873300703};\\\", \\\"{x:476,y:676,t:1527873300720};\\\", \\\"{x:456,y:658,t:1527873300738};\\\", \\\"{x:443,y:639,t:1527873300752};\\\", \\\"{x:435,y:625,t:1527873300769};\\\", \\\"{x:435,y:614,t:1527873300785};\\\", \\\"{x:435,y:607,t:1527873300801};\\\", \\\"{x:435,y:598,t:1527873300820};\\\", \\\"{x:435,y:583,t:1527873300836};\\\", \\\"{x:437,y:565,t:1527873300852};\\\", \\\"{x:437,y:550,t:1527873300870};\\\", \\\"{x:437,y:538,t:1527873300886};\\\", \\\"{x:438,y:530,t:1527873300902};\\\", \\\"{x:439,y:521,t:1527873300919};\\\", \\\"{x:441,y:518,t:1527873300936};\\\", \\\"{x:441,y:517,t:1527873300954};\\\", \\\"{x:441,y:515,t:1527873301023};\\\", \\\"{x:440,y:514,t:1527873301039};\\\", \\\"{x:435,y:514,t:1527873301053};\\\", \\\"{x:410,y:514,t:1527873301069};\\\", \\\"{x:362,y:514,t:1527873301086};\\\", \\\"{x:306,y:514,t:1527873301103};\\\", \\\"{x:249,y:504,t:1527873301121};\\\", \\\"{x:228,y:498,t:1527873301136};\\\", \\\"{x:216,y:494,t:1527873301153};\\\", \\\"{x:215,y:494,t:1527873301169};\\\", \\\"{x:214,y:493,t:1527873301186};\\\", \\\"{x:214,y:492,t:1527873301203};\\\", \\\"{x:214,y:493,t:1527873301295};\\\", \\\"{x:213,y:494,t:1527873301310};\\\", \\\"{x:213,y:495,t:1527873301320};\\\", \\\"{x:210,y:499,t:1527873301336};\\\", \\\"{x:206,y:502,t:1527873301353};\\\", \\\"{x:204,y:504,t:1527873301371};\\\", \\\"{x:201,y:505,t:1527873301386};\\\", \\\"{x:200,y:505,t:1527873301447};\\\", \\\"{x:198,y:505,t:1527873301470};\\\", \\\"{x:197,y:505,t:1527873301503};\\\", \\\"{x:196,y:505,t:1527873301521};\\\", \\\"{x:197,y:508,t:1527873301711};\\\", \\\"{x:206,y:517,t:1527873301720};\\\", \\\"{x:240,y:546,t:1527873301738};\\\", \\\"{x:307,y:592,t:1527873301754};\\\", \\\"{x:383,y:636,t:1527873301770};\\\", \\\"{x:458,y:684,t:1527873301787};\\\", \\\"{x:522,y:732,t:1527873301804};\\\", \\\"{x:571,y:760,t:1527873301820};\\\", \\\"{x:586,y:765,t:1527873301837};\\\", \\\"{x:588,y:767,t:1527873301853};\\\", \\\"{x:590,y:767,t:1527873301870};\\\", \\\"{x:590,y:768,t:1527873301911};\\\", \\\"{x:586,y:766,t:1527873301959};\\\", \\\"{x:578,y:761,t:1527873301971};\\\", \\\"{x:557,y:755,t:1527873301987};\\\", \\\"{x:529,y:742,t:1527873302004};\\\", \\\"{x:466,y:704,t:1527873302021};\\\", \\\"{x:380,y:647,t:1527873302037};\\\", \\\"{x:299,y:589,t:1527873302053};\\\", \\\"{x:248,y:554,t:1527873302071};\\\", \\\"{x:202,y:528,t:1527873302087};\\\", \\\"{x:173,y:511,t:1527873302103};\\\", \\\"{x:159,y:503,t:1527873302120};\\\", \\\"{x:154,y:499,t:1527873302137};\\\", \\\"{x:153,y:499,t:1527873302154};\\\", \\\"{x:153,y:497,t:1527873302170};\\\", \\\"{x:153,y:495,t:1527873302187};\\\", \\\"{x:153,y:494,t:1527873302204};\\\", \\\"{x:153,y:493,t:1527873302543};\\\", \\\"{x:158,y:495,t:1527873302555};\\\", \\\"{x:184,y:513,t:1527873302570};\\\", \\\"{x:254,y:552,t:1527873302588};\\\", \\\"{x:358,y:606,t:1527873302605};\\\", \\\"{x:474,y:665,t:1527873302620};\\\", \\\"{x:568,y:703,t:1527873302638};\\\", \\\"{x:616,y:719,t:1527873302654};\\\", \\\"{x:647,y:726,t:1527873302670};\\\", \\\"{x:650,y:727,t:1527873302687};\\\", \\\"{x:650,y:728,t:1527873302719};\\\", \\\"{x:650,y:730,t:1527873302760};\\\", \\\"{x:649,y:730,t:1527873302771};\\\", \\\"{x:641,y:730,t:1527873302787};\\\", \\\"{x:629,y:730,t:1527873302805};\\\", \\\"{x:614,y:730,t:1527873302822};\\\", \\\"{x:598,y:730,t:1527873302838};\\\", \\\"{x:594,y:730,t:1527873302855};\\\", \\\"{x:593,y:730,t:1527873302872};\\\", \\\"{x:591,y:730,t:1527873302888};\\\", \\\"{x:590,y:730,t:1527873302944};\\\", \\\"{x:588,y:730,t:1527873302959};\\\", \\\"{x:586,y:730,t:1527873302975};\\\", \\\"{x:583,y:729,t:1527873302988};\\\", \\\"{x:580,y:729,t:1527873303005};\\\", \\\"{x:571,y:728,t:1527873303022};\\\", \\\"{x:556,y:728,t:1527873303039};\\\", \\\"{x:541,y:728,t:1527873303055};\\\", \\\"{x:526,y:728,t:1527873303071};\\\", \\\"{x:521,y:728,t:1527873303088};\\\", \\\"{x:518,y:728,t:1527873303105};\\\", \\\"{x:516,y:728,t:1527873303122};\\\", \\\"{x:517,y:729,t:1527873303298};\\\" ] }, { \\\"rt\\\": 8060, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 502659, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"QGUGU\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:517,y:728,t:1527873309337};\\\", \\\"{x:518,y:715,t:1527873309352};\\\", \\\"{x:523,y:682,t:1527873309366};\\\", \\\"{x:527,y:663,t:1527873309383};\\\", \\\"{x:529,y:652,t:1527873309392};\\\", \\\"{x:532,y:632,t:1527873309409};\\\", \\\"{x:532,y:625,t:1527873309427};\\\", \\\"{x:532,y:615,t:1527873309443};\\\", \\\"{x:532,y:607,t:1527873309460};\\\", \\\"{x:532,y:599,t:1527873309477};\\\", \\\"{x:529,y:592,t:1527873309493};\\\", \\\"{x:523,y:582,t:1527873309510};\\\", \\\"{x:513,y:569,t:1527873309526};\\\", \\\"{x:505,y:564,t:1527873309542};\\\", \\\"{x:491,y:556,t:1527873309560};\\\", \\\"{x:475,y:551,t:1527873309577};\\\", \\\"{x:453,y:548,t:1527873309594};\\\", \\\"{x:414,y:543,t:1527873309610};\\\", \\\"{x:365,y:538,t:1527873309627};\\\", \\\"{x:322,y:537,t:1527873309643};\\\", \\\"{x:293,y:535,t:1527873309659};\\\", \\\"{x:266,y:535,t:1527873309678};\\\", \\\"{x:239,y:535,t:1527873309693};\\\", \\\"{x:221,y:537,t:1527873309710};\\\", \\\"{x:209,y:539,t:1527873309726};\\\", \\\"{x:207,y:540,t:1527873309744};\\\", \\\"{x:205,y:541,t:1527873309760};\\\", \\\"{x:204,y:544,t:1527873309776};\\\", \\\"{x:204,y:547,t:1527873309794};\\\", \\\"{x:204,y:548,t:1527873309810};\\\", \\\"{x:204,y:550,t:1527873309827};\\\", \\\"{x:202,y:550,t:1527873309944};\\\", \\\"{x:200,y:548,t:1527873309960};\\\", \\\"{x:195,y:546,t:1527873309977};\\\", \\\"{x:194,y:544,t:1527873309994};\\\", \\\"{x:193,y:544,t:1527873310010};\\\", \\\"{x:193,y:543,t:1527873310047};\\\", \\\"{x:192,y:543,t:1527873310060};\\\", \\\"{x:190,y:543,t:1527873310080};\\\", \\\"{x:194,y:544,t:1527873311753};\\\", \\\"{x:201,y:552,t:1527873311761};\\\", \\\"{x:219,y:564,t:1527873311778};\\\", \\\"{x:241,y:575,t:1527873311794};\\\", \\\"{x:261,y:587,t:1527873311812};\\\", \\\"{x:277,y:594,t:1527873311828};\\\", \\\"{x:293,y:600,t:1527873311845};\\\", \\\"{x:301,y:602,t:1527873311862};\\\", \\\"{x:309,y:605,t:1527873311878};\\\", \\\"{x:317,y:609,t:1527873311894};\\\", \\\"{x:322,y:612,t:1527873311912};\\\", \\\"{x:330,y:614,t:1527873311928};\\\", \\\"{x:335,y:618,t:1527873311944};\\\", \\\"{x:341,y:621,t:1527873311962};\\\", \\\"{x:347,y:623,t:1527873311979};\\\", \\\"{x:355,y:625,t:1527873311995};\\\", \\\"{x:371,y:633,t:1527873312012};\\\", \\\"{x:410,y:656,t:1527873312029};\\\", \\\"{x:456,y:682,t:1527873312045};\\\", \\\"{x:476,y:695,t:1527873312062};\\\", \\\"{x:482,y:699,t:1527873312077};\\\", \\\"{x:488,y:700,t:1527873312095};\\\", \\\"{x:489,y:701,t:1527873312112};\\\", \\\"{x:489,y:702,t:1527873312295};\\\", \\\"{x:489,y:704,t:1527873312312};\\\", \\\"{x:487,y:707,t:1527873312330};\\\", \\\"{x:487,y:709,t:1527873312347};\\\", \\\"{x:484,y:715,t:1527873312362};\\\", \\\"{x:484,y:723,t:1527873312380};\\\", \\\"{x:484,y:725,t:1527873312396};\\\", \\\"{x:484,y:728,t:1527873312411};\\\", \\\"{x:485,y:729,t:1527873312438};\\\", \\\"{x:485,y:730,t:1527873312462};\\\", \\\"{x:487,y:730,t:1527873312543};\\\", \\\"{x:488,y:730,t:1527873312559};\\\", \\\"{x:490,y:730,t:1527873312579};\\\", \\\"{x:490,y:730,t:1527873312670};\\\" ] }, { \\\"rt\\\": 10420, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 514286, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"QGUGU\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:490,y:729,t:1527873319384};\\\", \\\"{x:489,y:725,t:1527873319392};\\\", \\\"{x:488,y:714,t:1527873319411};\\\", \\\"{x:486,y:706,t:1527873319425};\\\", \\\"{x:482,y:698,t:1527873319442};\\\", \\\"{x:480,y:689,t:1527873319459};\\\", \\\"{x:477,y:687,t:1527873319468};\\\", \\\"{x:476,y:680,t:1527873319484};\\\", \\\"{x:473,y:676,t:1527873319501};\\\", \\\"{x:473,y:669,t:1527873319519};\\\", \\\"{x:473,y:666,t:1527873319534};\\\", \\\"{x:470,y:659,t:1527873319550};\\\", \\\"{x:466,y:653,t:1527873319567};\\\", \\\"{x:465,y:650,t:1527873319584};\\\", \\\"{x:464,y:645,t:1527873319601};\\\", \\\"{x:460,y:638,t:1527873319619};\\\", \\\"{x:456,y:634,t:1527873319634};\\\", \\\"{x:453,y:629,t:1527873319652};\\\", \\\"{x:449,y:624,t:1527873319668};\\\", \\\"{x:447,y:621,t:1527873319684};\\\", \\\"{x:444,y:618,t:1527873319701};\\\", \\\"{x:441,y:614,t:1527873319718};\\\", \\\"{x:438,y:610,t:1527873319734};\\\", \\\"{x:437,y:608,t:1527873319751};\\\", \\\"{x:433,y:605,t:1527873319768};\\\", \\\"{x:432,y:605,t:1527873319785};\\\", \\\"{x:430,y:604,t:1527873319801};\\\", \\\"{x:429,y:602,t:1527873319818};\\\", \\\"{x:425,y:601,t:1527873319835};\\\", \\\"{x:423,y:600,t:1527873319852};\\\", \\\"{x:420,y:599,t:1527873319868};\\\", \\\"{x:415,y:596,t:1527873319885};\\\", \\\"{x:411,y:594,t:1527873319901};\\\", \\\"{x:406,y:593,t:1527873319919};\\\", \\\"{x:399,y:592,t:1527873319934};\\\", \\\"{x:396,y:592,t:1527873319950};\\\", \\\"{x:394,y:591,t:1527873319968};\\\", \\\"{x:393,y:590,t:1527873319985};\\\", \\\"{x:392,y:590,t:1527873320031};\\\", \\\"{x:391,y:590,t:1527873320038};\\\", \\\"{x:390,y:590,t:1527873320052};\\\", \\\"{x:387,y:590,t:1527873320068};\\\", \\\"{x:382,y:590,t:1527873320086};\\\", \\\"{x:375,y:590,t:1527873320101};\\\", \\\"{x:365,y:590,t:1527873320118};\\\", \\\"{x:348,y:588,t:1527873320134};\\\", \\\"{x:333,y:587,t:1527873320151};\\\", \\\"{x:316,y:585,t:1527873320168};\\\", \\\"{x:302,y:584,t:1527873320185};\\\", \\\"{x:292,y:582,t:1527873320201};\\\", \\\"{x:283,y:580,t:1527873320218};\\\", \\\"{x:277,y:580,t:1527873320236};\\\", \\\"{x:273,y:580,t:1527873320251};\\\", \\\"{x:272,y:579,t:1527873320306};\\\", \\\"{x:270,y:577,t:1527873320318};\\\", \\\"{x:266,y:575,t:1527873320335};\\\", \\\"{x:257,y:573,t:1527873320352};\\\", \\\"{x:247,y:571,t:1527873320369};\\\", \\\"{x:235,y:567,t:1527873320385};\\\", \\\"{x:222,y:563,t:1527873320402};\\\", \\\"{x:212,y:560,t:1527873320420};\\\", \\\"{x:205,y:558,t:1527873320434};\\\", \\\"{x:200,y:554,t:1527873320453};\\\", \\\"{x:195,y:552,t:1527873320468};\\\", \\\"{x:191,y:551,t:1527873320486};\\\", \\\"{x:188,y:550,t:1527873320503};\\\", \\\"{x:187,y:549,t:1527873320519};\\\", \\\"{x:186,y:549,t:1527873320567};\\\", \\\"{x:186,y:548,t:1527873320583};\\\", \\\"{x:186,y:547,t:1527873321118};\\\", \\\"{x:199,y:547,t:1527873321137};\\\", \\\"{x:226,y:547,t:1527873321152};\\\", \\\"{x:253,y:547,t:1527873321170};\\\", \\\"{x:283,y:547,t:1527873321187};\\\", \\\"{x:313,y:547,t:1527873321202};\\\", \\\"{x:341,y:547,t:1527873321219};\\\", \\\"{x:370,y:547,t:1527873321236};\\\", \\\"{x:394,y:547,t:1527873321252};\\\", \\\"{x:421,y:547,t:1527873321269};\\\", \\\"{x:443,y:547,t:1527873321286};\\\", \\\"{x:458,y:547,t:1527873321302};\\\", \\\"{x:475,y:547,t:1527873321319};\\\", \\\"{x:480,y:546,t:1527873321336};\\\", \\\"{x:482,y:546,t:1527873321352};\\\", \\\"{x:484,y:543,t:1527873321369};\\\", \\\"{x:489,y:540,t:1527873321386};\\\", \\\"{x:494,y:538,t:1527873321402};\\\", \\\"{x:502,y:535,t:1527873321421};\\\", \\\"{x:509,y:533,t:1527873321436};\\\", \\\"{x:522,y:529,t:1527873321453};\\\", \\\"{x:539,y:526,t:1527873321469};\\\", \\\"{x:599,y:518,t:1527873321487};\\\", \\\"{x:636,y:512,t:1527873321504};\\\", \\\"{x:668,y:512,t:1527873321519};\\\", \\\"{x:696,y:512,t:1527873321536};\\\", \\\"{x:722,y:512,t:1527873321553};\\\", \\\"{x:741,y:512,t:1527873321569};\\\", \\\"{x:753,y:512,t:1527873321586};\\\", \\\"{x:757,y:512,t:1527873321603};\\\", \\\"{x:758,y:512,t:1527873321646};\\\", \\\"{x:761,y:512,t:1527873321671};\\\", \\\"{x:764,y:512,t:1527873321686};\\\", \\\"{x:777,y:512,t:1527873321702};\\\", \\\"{x:780,y:512,t:1527873321719};\\\", \\\"{x:781,y:512,t:1527873321737};\\\", \\\"{x:782,y:512,t:1527873321753};\\\", \\\"{x:783,y:512,t:1527873321769};\\\", \\\"{x:784,y:512,t:1527873321824};\\\", \\\"{x:786,y:512,t:1527873321837};\\\", \\\"{x:788,y:512,t:1527873321854};\\\", \\\"{x:794,y:512,t:1527873321869};\\\", \\\"{x:802,y:508,t:1527873321886};\\\", \\\"{x:809,y:507,t:1527873321902};\\\", \\\"{x:814,y:506,t:1527873321919};\\\", \\\"{x:815,y:506,t:1527873321936};\\\", \\\"{x:816,y:506,t:1527873321953};\\\", \\\"{x:818,y:506,t:1527873321969};\\\", \\\"{x:821,y:504,t:1527873321986};\\\", \\\"{x:823,y:504,t:1527873322032};\\\", \\\"{x:816,y:510,t:1527873322512};\\\", \\\"{x:803,y:524,t:1527873322522};\\\", \\\"{x:766,y:560,t:1527873322537};\\\", \\\"{x:733,y:589,t:1527873322554};\\\", \\\"{x:700,y:617,t:1527873322571};\\\", \\\"{x:674,y:636,t:1527873322587};\\\", \\\"{x:655,y:649,t:1527873322603};\\\", \\\"{x:640,y:660,t:1527873322620};\\\", \\\"{x:625,y:671,t:1527873322637};\\\", \\\"{x:615,y:680,t:1527873322653};\\\", \\\"{x:608,y:684,t:1527873322671};\\\", \\\"{x:601,y:689,t:1527873322686};\\\", \\\"{x:595,y:692,t:1527873322703};\\\", \\\"{x:594,y:693,t:1527873322727};\\\", \\\"{x:593,y:694,t:1527873322737};\\\", \\\"{x:593,y:690,t:1527873322806};\\\", \\\"{x:598,y:679,t:1527873322820};\\\", \\\"{x:612,y:653,t:1527873322837};\\\", \\\"{x:633,y:624,t:1527873322855};\\\", \\\"{x:671,y:586,t:1527873322871};\\\", \\\"{x:695,y:571,t:1527873322887};\\\", \\\"{x:718,y:560,t:1527873322905};\\\", \\\"{x:739,y:551,t:1527873322921};\\\", \\\"{x:760,y:544,t:1527873322937};\\\", \\\"{x:779,y:539,t:1527873322954};\\\", \\\"{x:792,y:535,t:1527873322970};\\\", \\\"{x:800,y:532,t:1527873322987};\\\", \\\"{x:802,y:531,t:1527873323046};\\\", \\\"{x:803,y:530,t:1527873323054};\\\", \\\"{x:805,y:529,t:1527873323070};\\\", \\\"{x:810,y:527,t:1527873323087};\\\", \\\"{x:812,y:526,t:1527873323104};\\\", \\\"{x:812,y:525,t:1527873323120};\\\", \\\"{x:819,y:521,t:1527873323137};\\\", \\\"{x:823,y:518,t:1527873323154};\\\", \\\"{x:827,y:515,t:1527873323170};\\\", \\\"{x:828,y:514,t:1527873323187};\\\", \\\"{x:831,y:513,t:1527873323205};\\\", \\\"{x:831,y:512,t:1527873323221};\\\", \\\"{x:832,y:511,t:1527873323335};\\\", \\\"{x:831,y:512,t:1527873323639};\\\", \\\"{x:810,y:531,t:1527873323655};\\\", \\\"{x:776,y:562,t:1527873323672};\\\", \\\"{x:732,y:601,t:1527873323689};\\\", \\\"{x:686,y:633,t:1527873323704};\\\", \\\"{x:648,y:657,t:1527873323721};\\\", \\\"{x:615,y:678,t:1527873323737};\\\", \\\"{x:582,y:696,t:1527873323754};\\\", \\\"{x:563,y:708,t:1527873323772};\\\", \\\"{x:549,y:718,t:1527873323787};\\\", \\\"{x:536,y:728,t:1527873323805};\\\", \\\"{x:531,y:733,t:1527873323821};\\\", \\\"{x:528,y:738,t:1527873323839};\\\", \\\"{x:528,y:739,t:1527873323854};\\\", \\\"{x:527,y:741,t:1527873323871};\\\", \\\"{x:527,y:742,t:1527873323888};\\\", \\\"{x:526,y:744,t:1527873323904};\\\", \\\"{x:525,y:745,t:1527873323922};\\\", \\\"{x:525,y:746,t:1527873323975};\\\", \\\"{x:525,y:747,t:1527873323988};\\\" ] }, { \\\"rt\\\": 11674, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 527217, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"QGUGU\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:523,y:747,t:1527873328408};\\\", \\\"{x:523,y:746,t:1527873328416};\\\", \\\"{x:523,y:744,t:1527873328433};\\\", \\\"{x:523,y:742,t:1527873328450};\\\", \\\"{x:523,y:741,t:1527873328864};\\\", \\\"{x:522,y:741,t:1527873328871};\\\", \\\"{x:522,y:740,t:1527873328888};\\\", \\\"{x:522,y:739,t:1527873328901};\\\", \\\"{x:522,y:736,t:1527873328917};\\\", \\\"{x:522,y:735,t:1527873328935};\\\", \\\"{x:522,y:732,t:1527873328952};\\\", \\\"{x:522,y:730,t:1527873328967};\\\", \\\"{x:522,y:729,t:1527873328985};\\\", \\\"{x:522,y:727,t:1527873329001};\\\", \\\"{x:523,y:725,t:1527873329018};\\\", \\\"{x:523,y:723,t:1527873329035};\\\", \\\"{x:524,y:722,t:1527873329051};\\\", \\\"{x:525,y:719,t:1527873329069};\\\", \\\"{x:525,y:718,t:1527873329085};\\\", \\\"{x:525,y:717,t:1527873329102};\\\", \\\"{x:525,y:716,t:1527873329118};\\\", \\\"{x:527,y:714,t:1527873329159};\\\", \\\"{x:527,y:713,t:1527873329199};\\\", \\\"{x:528,y:713,t:1527873329214};\\\", \\\"{x:528,y:711,t:1527873329238};\\\", \\\"{x:529,y:708,t:1527873329254};\\\", \\\"{x:531,y:707,t:1527873329262};\\\", \\\"{x:531,y:706,t:1527873329276};\\\", \\\"{x:532,y:702,t:1527873329293};\\\", \\\"{x:534,y:696,t:1527873329308};\\\", \\\"{x:538,y:690,t:1527873329326};\\\", \\\"{x:542,y:680,t:1527873329343};\\\", \\\"{x:544,y:673,t:1527873329359};\\\", \\\"{x:547,y:665,t:1527873329376};\\\", \\\"{x:549,y:658,t:1527873329392};\\\", \\\"{x:551,y:653,t:1527873329409};\\\", \\\"{x:552,y:649,t:1527873329425};\\\", \\\"{x:552,y:646,t:1527873329443};\\\", \\\"{x:552,y:644,t:1527873329459};\\\", \\\"{x:553,y:644,t:1527873329476};\\\", \\\"{x:554,y:643,t:1527873329664};\\\", \\\"{x:554,y:642,t:1527873329676};\\\", \\\"{x:553,y:641,t:1527873329693};\\\", \\\"{x:552,y:640,t:1527873329709};\\\", \\\"{x:551,y:640,t:1527873329728};\\\", \\\"{x:550,y:640,t:1527873330432};\\\", \\\"{x:548,y:641,t:1527873330444};\\\", \\\"{x:548,y:642,t:1527873330460};\\\", \\\"{x:546,y:643,t:1527873330477};\\\", \\\"{x:545,y:643,t:1527873330496};\\\", \\\"{x:544,y:645,t:1527873331096};\\\", \\\"{x:542,y:647,t:1527873331112};\\\", \\\"{x:541,y:648,t:1527873331135};\\\", \\\"{x:540,y:648,t:1527873331144};\\\", \\\"{x:540,y:650,t:1527873331161};\\\", \\\"{x:539,y:650,t:1527873331264};\\\", \\\"{x:538,y:646,t:1527873333128};\\\", \\\"{x:539,y:635,t:1527873333136};\\\", \\\"{x:540,y:629,t:1527873333148};\\\", \\\"{x:540,y:616,t:1527873333161};\\\", \\\"{x:539,y:607,t:1527873333179};\\\", \\\"{x:537,y:599,t:1527873333196};\\\", \\\"{x:535,y:589,t:1527873333212};\\\", \\\"{x:534,y:584,t:1527873333229};\\\", \\\"{x:533,y:578,t:1527873333245};\\\", \\\"{x:533,y:577,t:1527873333261};\\\", \\\"{x:531,y:574,t:1527873333367};\\\", \\\"{x:531,y:573,t:1527873333379};\\\", \\\"{x:528,y:569,t:1527873333395};\\\", \\\"{x:526,y:567,t:1527873333413};\\\", \\\"{x:526,y:566,t:1527873333428};\\\", \\\"{x:524,y:564,t:1527873333446};\\\", \\\"{x:524,y:563,t:1527873333463};\\\", \\\"{x:523,y:563,t:1527873333815};\\\", \\\"{x:518,y:563,t:1527873333830};\\\", \\\"{x:505,y:563,t:1527873333846};\\\", \\\"{x:475,y:563,t:1527873333865};\\\", \\\"{x:452,y:563,t:1527873333879};\\\", \\\"{x:426,y:561,t:1527873333896};\\\", \\\"{x:407,y:561,t:1527873333913};\\\", \\\"{x:388,y:561,t:1527873333929};\\\", \\\"{x:374,y:561,t:1527873333945};\\\", \\\"{x:366,y:559,t:1527873333963};\\\", \\\"{x:361,y:559,t:1527873333980};\\\", \\\"{x:360,y:559,t:1527873333996};\\\", \\\"{x:359,y:559,t:1527873334012};\\\", \\\"{x:357,y:559,t:1527873334030};\\\", \\\"{x:353,y:559,t:1527873334046};\\\", \\\"{x:346,y:559,t:1527873334062};\\\", \\\"{x:340,y:559,t:1527873334080};\\\", \\\"{x:329,y:559,t:1527873334123};\\\", \\\"{x:325,y:559,t:1527873334130};\\\", \\\"{x:321,y:559,t:1527873334147};\\\", \\\"{x:314,y:559,t:1527873334162};\\\", \\\"{x:311,y:559,t:1527873334179};\\\", \\\"{x:307,y:559,t:1527873334196};\\\", \\\"{x:302,y:560,t:1527873334213};\\\", \\\"{x:296,y:560,t:1527873334229};\\\", \\\"{x:284,y:560,t:1527873334246};\\\", \\\"{x:278,y:560,t:1527873334263};\\\", \\\"{x:272,y:560,t:1527873334280};\\\", \\\"{x:262,y:560,t:1527873334297};\\\", \\\"{x:249,y:560,t:1527873334312};\\\", \\\"{x:236,y:558,t:1527873334329};\\\", \\\"{x:225,y:558,t:1527873334347};\\\", \\\"{x:215,y:558,t:1527873334363};\\\", \\\"{x:210,y:558,t:1527873334379};\\\", \\\"{x:208,y:558,t:1527873334397};\\\", \\\"{x:206,y:558,t:1527873334413};\\\", \\\"{x:205,y:559,t:1527873334430};\\\", \\\"{x:203,y:561,t:1527873334447};\\\", \\\"{x:203,y:564,t:1527873334464};\\\", \\\"{x:203,y:568,t:1527873334479};\\\", \\\"{x:203,y:570,t:1527873334495};\\\", \\\"{x:203,y:571,t:1527873334513};\\\", \\\"{x:203,y:572,t:1527873334529};\\\", \\\"{x:200,y:574,t:1527873334545};\\\", \\\"{x:197,y:576,t:1527873334563};\\\", \\\"{x:194,y:578,t:1527873334579};\\\", \\\"{x:193,y:579,t:1527873334595};\\\", \\\"{x:191,y:580,t:1527873334613};\\\", \\\"{x:190,y:580,t:1527873334654};\\\", \\\"{x:189,y:580,t:1527873334662};\\\", \\\"{x:187,y:580,t:1527873334680};\\\", \\\"{x:184,y:577,t:1527873334697};\\\", \\\"{x:179,y:569,t:1527873334718};\\\", \\\"{x:171,y:551,t:1527873334760};\\\", \\\"{x:171,y:549,t:1527873334767};\\\", \\\"{x:170,y:546,t:1527873334779};\\\", \\\"{x:169,y:545,t:1527873334797};\\\", \\\"{x:178,y:545,t:1527873335295};\\\", \\\"{x:195,y:558,t:1527873335303};\\\", \\\"{x:218,y:572,t:1527873335314};\\\", \\\"{x:260,y:602,t:1527873335331};\\\", \\\"{x:288,y:619,t:1527873335347};\\\", \\\"{x:299,y:626,t:1527873335364};\\\", \\\"{x:303,y:630,t:1527873335381};\\\", \\\"{x:305,y:632,t:1527873335398};\\\", \\\"{x:306,y:633,t:1527873335413};\\\", \\\"{x:310,y:640,t:1527873335431};\\\", \\\"{x:314,y:645,t:1527873335448};\\\", \\\"{x:317,y:649,t:1527873335464};\\\", \\\"{x:322,y:654,t:1527873335481};\\\", \\\"{x:331,y:659,t:1527873335496};\\\", \\\"{x:337,y:664,t:1527873335514};\\\", \\\"{x:343,y:670,t:1527873335531};\\\", \\\"{x:350,y:674,t:1527873335547};\\\", \\\"{x:353,y:674,t:1527873335564};\\\", \\\"{x:356,y:675,t:1527873335581};\\\", \\\"{x:358,y:675,t:1527873335597};\\\", \\\"{x:364,y:677,t:1527873335615};\\\", \\\"{x:367,y:679,t:1527873335631};\\\", \\\"{x:375,y:683,t:1527873335648};\\\", \\\"{x:382,y:686,t:1527873335665};\\\", \\\"{x:390,y:691,t:1527873335681};\\\", \\\"{x:403,y:697,t:1527873335698};\\\", \\\"{x:426,y:711,t:1527873335716};\\\", \\\"{x:451,y:725,t:1527873335731};\\\", \\\"{x:474,y:737,t:1527873335748};\\\", \\\"{x:485,y:742,t:1527873335764};\\\", \\\"{x:491,y:744,t:1527873335781};\\\", \\\"{x:493,y:745,t:1527873335798};\\\", \\\"{x:494,y:745,t:1527873335887};\\\", \\\"{x:495,y:744,t:1527873335898};\\\", \\\"{x:495,y:741,t:1527873335915};\\\", \\\"{x:495,y:737,t:1527873335931};\\\", \\\"{x:496,y:734,t:1527873335948};\\\", \\\"{x:496,y:732,t:1527873335966};\\\" ] }, { \\\"rt\\\": 75968, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 604425, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"QGUGU\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-N -N -Z -Z -Z -X -C -F -04 PM-03 PM-02 PM-02 PM-01 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:514,y:726,t:1527873342392};\\\", \\\"{x:554,y:721,t:1527873342401};\\\", \\\"{x:602,y:720,t:1527873342419};\\\", \\\"{x:665,y:716,t:1527873342435};\\\", \\\"{x:740,y:716,t:1527873342451};\\\", \\\"{x:867,y:716,t:1527873342470};\\\", \\\"{x:975,y:716,t:1527873342486};\\\", \\\"{x:1097,y:728,t:1527873342503};\\\", \\\"{x:1213,y:742,t:1527873342520};\\\", \\\"{x:1321,y:758,t:1527873342536};\\\", \\\"{x:1401,y:769,t:1527873342553};\\\", \\\"{x:1469,y:779,t:1527873342570};\\\", \\\"{x:1538,y:788,t:1527873342587};\\\", \\\"{x:1600,y:800,t:1527873342603};\\\", \\\"{x:1631,y:803,t:1527873342620};\\\", \\\"{x:1652,y:807,t:1527873342637};\\\", \\\"{x:1665,y:811,t:1527873342654};\\\", \\\"{x:1674,y:816,t:1527873342670};\\\", \\\"{x:1681,y:819,t:1527873342686};\\\", \\\"{x:1683,y:821,t:1527873342703};\\\", \\\"{x:1684,y:822,t:1527873342720};\\\", \\\"{x:1685,y:823,t:1527873342738};\\\", \\\"{x:1685,y:825,t:1527873342832};\\\", \\\"{x:1685,y:826,t:1527873342842};\\\", \\\"{x:1683,y:827,t:1527873342855};\\\", \\\"{x:1681,y:830,t:1527873342871};\\\", \\\"{x:1675,y:835,t:1527873342889};\\\", \\\"{x:1667,y:839,t:1527873342905};\\\", \\\"{x:1663,y:842,t:1527873342920};\\\", \\\"{x:1661,y:843,t:1527873342938};\\\", \\\"{x:1658,y:844,t:1527873342954};\\\", \\\"{x:1655,y:845,t:1527873342972};\\\", \\\"{x:1652,y:846,t:1527873342988};\\\", \\\"{x:1645,y:846,t:1527873343005};\\\", \\\"{x:1638,y:846,t:1527873343022};\\\", \\\"{x:1630,y:846,t:1527873343038};\\\", \\\"{x:1615,y:846,t:1527873343055};\\\", \\\"{x:1605,y:846,t:1527873343071};\\\", \\\"{x:1597,y:846,t:1527873343087};\\\", \\\"{x:1588,y:846,t:1527873343105};\\\", \\\"{x:1580,y:846,t:1527873343122};\\\", \\\"{x:1576,y:846,t:1527873343137};\\\", \\\"{x:1575,y:846,t:1527873343155};\\\", \\\"{x:1576,y:846,t:1527873343279};\\\", \\\"{x:1579,y:845,t:1527873343289};\\\", \\\"{x:1589,y:844,t:1527873343304};\\\", \\\"{x:1604,y:843,t:1527873343321};\\\", \\\"{x:1618,y:843,t:1527873343338};\\\", \\\"{x:1635,y:843,t:1527873343354};\\\", \\\"{x:1647,y:843,t:1527873343372};\\\", \\\"{x:1656,y:843,t:1527873343388};\\\", \\\"{x:1662,y:843,t:1527873343405};\\\", \\\"{x:1664,y:843,t:1527873343421};\\\", \\\"{x:1665,y:843,t:1527873343438};\\\", \\\"{x:1665,y:841,t:1527873343592};\\\", \\\"{x:1665,y:839,t:1527873343605};\\\", \\\"{x:1665,y:825,t:1527873343623};\\\", \\\"{x:1665,y:816,t:1527873343640};\\\", \\\"{x:1665,y:811,t:1527873343656};\\\", \\\"{x:1664,y:804,t:1527873343673};\\\", \\\"{x:1662,y:799,t:1527873343689};\\\", \\\"{x:1658,y:787,t:1527873343706};\\\", \\\"{x:1653,y:777,t:1527873343723};\\\", \\\"{x:1646,y:770,t:1527873343739};\\\", \\\"{x:1641,y:765,t:1527873343756};\\\", \\\"{x:1638,y:763,t:1527873343773};\\\", \\\"{x:1634,y:761,t:1527873343790};\\\", \\\"{x:1630,y:758,t:1527873343806};\\\", \\\"{x:1625,y:754,t:1527873343823};\\\", \\\"{x:1622,y:750,t:1527873343840};\\\", \\\"{x:1621,y:747,t:1527873343856};\\\", \\\"{x:1620,y:747,t:1527873343873};\\\", \\\"{x:1620,y:746,t:1527873343890};\\\", \\\"{x:1619,y:741,t:1527873343906};\\\", \\\"{x:1618,y:738,t:1527873343923};\\\", \\\"{x:1616,y:730,t:1527873343940};\\\", \\\"{x:1615,y:725,t:1527873343956};\\\", \\\"{x:1615,y:719,t:1527873343973};\\\", \\\"{x:1615,y:715,t:1527873343990};\\\", \\\"{x:1615,y:711,t:1527873344007};\\\", \\\"{x:1614,y:707,t:1527873344023};\\\", \\\"{x:1614,y:703,t:1527873344040};\\\", \\\"{x:1612,y:700,t:1527873344057};\\\", \\\"{x:1612,y:699,t:1527873344073};\\\", \\\"{x:1612,y:697,t:1527873344089};\\\", \\\"{x:1611,y:695,t:1527873344107};\\\", \\\"{x:1611,y:693,t:1527873344123};\\\", \\\"{x:1611,y:691,t:1527873344140};\\\", \\\"{x:1611,y:692,t:1527873345406};\\\", \\\"{x:1612,y:692,t:1527873345425};\\\", \\\"{x:1613,y:694,t:1527873345808};\\\", \\\"{x:1613,y:698,t:1527873351218};\\\", \\\"{x:1613,y:701,t:1527873351226};\\\", \\\"{x:1613,y:703,t:1527873351239};\\\", \\\"{x:1613,y:706,t:1527873351255};\\\", \\\"{x:1611,y:710,t:1527873351271};\\\", \\\"{x:1610,y:713,t:1527873351288};\\\", \\\"{x:1609,y:715,t:1527873351306};\\\", \\\"{x:1608,y:718,t:1527873351322};\\\", \\\"{x:1607,y:720,t:1527873351339};\\\", \\\"{x:1607,y:721,t:1527873351356};\\\", \\\"{x:1607,y:723,t:1527873351372};\\\", \\\"{x:1607,y:724,t:1527873351389};\\\", \\\"{x:1607,y:726,t:1527873351405};\\\", \\\"{x:1607,y:728,t:1527873351426};\\\", \\\"{x:1606,y:729,t:1527873351450};\\\", \\\"{x:1605,y:730,t:1527873351466};\\\", \\\"{x:1605,y:731,t:1527873351474};\\\", \\\"{x:1605,y:732,t:1527873351489};\\\", \\\"{x:1605,y:734,t:1527873351505};\\\", \\\"{x:1601,y:740,t:1527873351522};\\\", \\\"{x:1598,y:746,t:1527873351539};\\\", \\\"{x:1595,y:751,t:1527873351555};\\\", \\\"{x:1591,y:757,t:1527873351572};\\\", \\\"{x:1587,y:763,t:1527873351590};\\\", \\\"{x:1583,y:766,t:1527873351605};\\\", \\\"{x:1577,y:771,t:1527873351623};\\\", \\\"{x:1572,y:775,t:1527873351640};\\\", \\\"{x:1566,y:777,t:1527873351656};\\\", \\\"{x:1562,y:780,t:1527873351672};\\\", \\\"{x:1558,y:783,t:1527873351690};\\\", \\\"{x:1554,y:786,t:1527873351706};\\\", \\\"{x:1552,y:786,t:1527873351722};\\\", \\\"{x:1547,y:789,t:1527873351740};\\\", \\\"{x:1545,y:790,t:1527873351756};\\\", \\\"{x:1542,y:791,t:1527873351773};\\\", \\\"{x:1539,y:794,t:1527873351790};\\\", \\\"{x:1535,y:797,t:1527873351806};\\\", \\\"{x:1530,y:801,t:1527873351822};\\\", \\\"{x:1520,y:807,t:1527873351839};\\\", \\\"{x:1509,y:815,t:1527873351856};\\\", \\\"{x:1496,y:823,t:1527873351873};\\\", \\\"{x:1484,y:829,t:1527873351889};\\\", \\\"{x:1468,y:837,t:1527873351907};\\\", \\\"{x:1451,y:841,t:1527873351924};\\\", \\\"{x:1438,y:841,t:1527873351940};\\\", \\\"{x:1420,y:841,t:1527873351957};\\\", \\\"{x:1390,y:833,t:1527873351974};\\\", \\\"{x:1335,y:819,t:1527873351990};\\\", \\\"{x:1248,y:788,t:1527873352006};\\\", \\\"{x:1134,y:750,t:1527873352023};\\\", \\\"{x:992,y:704,t:1527873352040};\\\", \\\"{x:848,y:663,t:1527873352056};\\\", \\\"{x:707,y:619,t:1527873352074};\\\", \\\"{x:527,y:565,t:1527873352090};\\\", \\\"{x:433,y:542,t:1527873352106};\\\", \\\"{x:339,y:516,t:1527873352132};\\\", \\\"{x:299,y:505,t:1527873352147};\\\", \\\"{x:284,y:499,t:1527873352164};\\\", \\\"{x:281,y:499,t:1527873352181};\\\", \\\"{x:280,y:499,t:1527873352209};\\\", \\\"{x:280,y:498,t:1527873352217};\\\", \\\"{x:283,y:501,t:1527873352306};\\\", \\\"{x:285,y:505,t:1527873352314};\\\", \\\"{x:288,y:508,t:1527873352331};\\\", \\\"{x:293,y:515,t:1527873352348};\\\", \\\"{x:302,y:524,t:1527873352365};\\\", \\\"{x:323,y:536,t:1527873352383};\\\", \\\"{x:338,y:546,t:1527873352398};\\\", \\\"{x:357,y:557,t:1527873352416};\\\", \\\"{x:375,y:566,t:1527873352432};\\\", \\\"{x:402,y:574,t:1527873352448};\\\", \\\"{x:433,y:579,t:1527873352465};\\\", \\\"{x:468,y:583,t:1527873352480};\\\", \\\"{x:516,y:583,t:1527873352498};\\\", \\\"{x:544,y:583,t:1527873352515};\\\", \\\"{x:566,y:576,t:1527873352531};\\\", \\\"{x:578,y:572,t:1527873352547};\\\", \\\"{x:581,y:571,t:1527873352563};\\\", \\\"{x:581,y:570,t:1527873352580};\\\", \\\"{x:581,y:568,t:1527873352602};\\\", \\\"{x:581,y:567,t:1527873352613};\\\", \\\"{x:578,y:561,t:1527873352631};\\\", \\\"{x:571,y:558,t:1527873352648};\\\", \\\"{x:568,y:557,t:1527873352664};\\\", \\\"{x:568,y:556,t:1527873352682};\\\", \\\"{x:569,y:556,t:1527873352738};\\\", \\\"{x:571,y:556,t:1527873352748};\\\", \\\"{x:573,y:558,t:1527873352765};\\\", \\\"{x:575,y:558,t:1527873352782};\\\", \\\"{x:581,y:562,t:1527873352798};\\\", \\\"{x:583,y:564,t:1527873352817};\\\", \\\"{x:585,y:565,t:1527873352832};\\\", \\\"{x:586,y:566,t:1527873352848};\\\", \\\"{x:587,y:567,t:1527873352865};\\\", \\\"{x:588,y:568,t:1527873352882};\\\", \\\"{x:590,y:569,t:1527873352898};\\\", \\\"{x:590,y:572,t:1527873352915};\\\", \\\"{x:591,y:574,t:1527873352931};\\\", \\\"{x:592,y:575,t:1527873352948};\\\", \\\"{x:593,y:577,t:1527873352965};\\\", \\\"{x:594,y:577,t:1527873352986};\\\", \\\"{x:594,y:578,t:1527873353010};\\\", \\\"{x:595,y:578,t:1527873353034};\\\", \\\"{x:596,y:578,t:1527873353090};\\\", \\\"{x:597,y:578,t:1527873353138};\\\", \\\"{x:599,y:578,t:1527873353154};\\\", \\\"{x:600,y:578,t:1527873353166};\\\", \\\"{x:603,y:578,t:1527873353181};\\\", \\\"{x:605,y:578,t:1527873353186};\\\", \\\"{x:607,y:578,t:1527873353198};\\\", \\\"{x:608,y:577,t:1527873353214};\\\", \\\"{x:609,y:577,t:1527873353232};\\\", \\\"{x:609,y:576,t:1527873353248};\\\", \\\"{x:609,y:576,t:1527873353303};\\\", \\\"{x:610,y:576,t:1527873353587};\\\", \\\"{x:614,y:576,t:1527873353599};\\\", \\\"{x:642,y:579,t:1527873353615};\\\", \\\"{x:722,y:590,t:1527873353633};\\\", \\\"{x:855,y:611,t:1527873353649};\\\", \\\"{x:1027,y:633,t:1527873353666};\\\", \\\"{x:1289,y:658,t:1527873353682};\\\", \\\"{x:1486,y:667,t:1527873353699};\\\", \\\"{x:1683,y:674,t:1527873353715};\\\", \\\"{x:1835,y:689,t:1527873353732};\\\", \\\"{x:1919,y:700,t:1527873353750};\\\", \\\"{x:1919,y:712,t:1527873353766};\\\", \\\"{x:1919,y:719,t:1527873353782};\\\", \\\"{x:1919,y:722,t:1527873353799};\\\", \\\"{x:1919,y:728,t:1527873353816};\\\", \\\"{x:1919,y:736,t:1527873353832};\\\", \\\"{x:1916,y:748,t:1527873353849};\\\", \\\"{x:1906,y:768,t:1527873353865};\\\", \\\"{x:1899,y:783,t:1527873353884};\\\", \\\"{x:1888,y:800,t:1527873353899};\\\", \\\"{x:1878,y:812,t:1527873353916};\\\", \\\"{x:1866,y:822,t:1527873353932};\\\", \\\"{x:1856,y:827,t:1527873353949};\\\", \\\"{x:1846,y:828,t:1527873353966};\\\", \\\"{x:1831,y:830,t:1527873353982};\\\", \\\"{x:1816,y:830,t:1527873353999};\\\", \\\"{x:1803,y:830,t:1527873354016};\\\", \\\"{x:1791,y:829,t:1527873354032};\\\", \\\"{x:1777,y:823,t:1527873354049};\\\", \\\"{x:1756,y:814,t:1527873354066};\\\", \\\"{x:1742,y:805,t:1527873354082};\\\", \\\"{x:1731,y:799,t:1527873354099};\\\", \\\"{x:1726,y:794,t:1527873354116};\\\", \\\"{x:1717,y:786,t:1527873354132};\\\", \\\"{x:1705,y:778,t:1527873354150};\\\", \\\"{x:1690,y:772,t:1527873354166};\\\", \\\"{x:1677,y:766,t:1527873354183};\\\", \\\"{x:1663,y:760,t:1527873354199};\\\", \\\"{x:1650,y:755,t:1527873354217};\\\", \\\"{x:1637,y:750,t:1527873354233};\\\", \\\"{x:1618,y:744,t:1527873354249};\\\", \\\"{x:1590,y:736,t:1527873354266};\\\", \\\"{x:1569,y:731,t:1527873354283};\\\", \\\"{x:1544,y:723,t:1527873354299};\\\", \\\"{x:1519,y:716,t:1527873354316};\\\", \\\"{x:1500,y:711,t:1527873354333};\\\", \\\"{x:1484,y:705,t:1527873354348};\\\", \\\"{x:1476,y:702,t:1527873354366};\\\", \\\"{x:1470,y:699,t:1527873354383};\\\", \\\"{x:1466,y:696,t:1527873354399};\\\", \\\"{x:1463,y:691,t:1527873354416};\\\", \\\"{x:1460,y:686,t:1527873354433};\\\", \\\"{x:1459,y:683,t:1527873354449};\\\", \\\"{x:1457,y:675,t:1527873354466};\\\", \\\"{x:1456,y:670,t:1527873354483};\\\", \\\"{x:1456,y:666,t:1527873354499};\\\", \\\"{x:1455,y:664,t:1527873354516};\\\", \\\"{x:1455,y:663,t:1527873354533};\\\", \\\"{x:1455,y:661,t:1527873354550};\\\", \\\"{x:1455,y:660,t:1527873354566};\\\", \\\"{x:1454,y:657,t:1527873354583};\\\", \\\"{x:1454,y:655,t:1527873354602};\\\", \\\"{x:1454,y:653,t:1527873354618};\\\", \\\"{x:1453,y:653,t:1527873354634};\\\", \\\"{x:1453,y:651,t:1527873354650};\\\", \\\"{x:1452,y:647,t:1527873354666};\\\", \\\"{x:1452,y:644,t:1527873354683};\\\", \\\"{x:1450,y:640,t:1527873354699};\\\", \\\"{x:1449,y:635,t:1527873354716};\\\", \\\"{x:1449,y:633,t:1527873354734};\\\", \\\"{x:1449,y:631,t:1527873354750};\\\", \\\"{x:1449,y:630,t:1527873354766};\\\", \\\"{x:1449,y:628,t:1527873354783};\\\", \\\"{x:1449,y:626,t:1527873354802};\\\", \\\"{x:1449,y:627,t:1527873355139};\\\", \\\"{x:1450,y:628,t:1527873355163};\\\", \\\"{x:1450,y:629,t:1527873355234};\\\", \\\"{x:1450,y:630,t:1527873355331};\\\", \\\"{x:1450,y:631,t:1527873355346};\\\", \\\"{x:1450,y:632,t:1527873355354};\\\", \\\"{x:1450,y:633,t:1527873355370};\\\", \\\"{x:1450,y:634,t:1527873355402};\\\", \\\"{x:1450,y:637,t:1527873364091};\\\", \\\"{x:1449,y:642,t:1527873364108};\\\", \\\"{x:1446,y:649,t:1527873364124};\\\", \\\"{x:1443,y:652,t:1527873364141};\\\", \\\"{x:1441,y:655,t:1527873364157};\\\", \\\"{x:1440,y:656,t:1527873364174};\\\", \\\"{x:1439,y:657,t:1527873364190};\\\", \\\"{x:1437,y:659,t:1527873364208};\\\", \\\"{x:1435,y:661,t:1527873364224};\\\", \\\"{x:1432,y:663,t:1527873364240};\\\", \\\"{x:1427,y:665,t:1527873364258};\\\", \\\"{x:1422,y:667,t:1527873364274};\\\", \\\"{x:1416,y:670,t:1527873364291};\\\", \\\"{x:1413,y:671,t:1527873364308};\\\", \\\"{x:1410,y:674,t:1527873364324};\\\", \\\"{x:1408,y:675,t:1527873364341};\\\", \\\"{x:1405,y:677,t:1527873364358};\\\", \\\"{x:1404,y:678,t:1527873364374};\\\", \\\"{x:1403,y:679,t:1527873364391};\\\", \\\"{x:1402,y:681,t:1527873364408};\\\", \\\"{x:1399,y:683,t:1527873364423};\\\", \\\"{x:1399,y:684,t:1527873364442};\\\", \\\"{x:1398,y:684,t:1527873364466};\\\", \\\"{x:1398,y:686,t:1527873364482};\\\", \\\"{x:1396,y:687,t:1527873364491};\\\", \\\"{x:1395,y:690,t:1527873364508};\\\", \\\"{x:1393,y:692,t:1527873364525};\\\", \\\"{x:1392,y:694,t:1527873364541};\\\", \\\"{x:1390,y:696,t:1527873364558};\\\", \\\"{x:1389,y:697,t:1527873364575};\\\", \\\"{x:1388,y:698,t:1527873364591};\\\", \\\"{x:1387,y:698,t:1527873364619};\\\", \\\"{x:1385,y:698,t:1527873364659};\\\", \\\"{x:1383,y:699,t:1527873364682};\\\", \\\"{x:1381,y:700,t:1527873364691};\\\", \\\"{x:1375,y:701,t:1527873364708};\\\", \\\"{x:1371,y:703,t:1527873364725};\\\", \\\"{x:1368,y:705,t:1527873364742};\\\", \\\"{x:1367,y:705,t:1527873364827};\\\", \\\"{x:1366,y:705,t:1527873364841};\\\", \\\"{x:1365,y:705,t:1527873364891};\\\", \\\"{x:1364,y:705,t:1527873364922};\\\", \\\"{x:1362,y:705,t:1527873364930};\\\", \\\"{x:1361,y:705,t:1527873364954};\\\", \\\"{x:1360,y:705,t:1527873364962};\\\", \\\"{x:1358,y:704,t:1527873364975};\\\", \\\"{x:1357,y:703,t:1527873364992};\\\", \\\"{x:1356,y:703,t:1527873365008};\\\", \\\"{x:1355,y:703,t:1527873365025};\\\", \\\"{x:1353,y:703,t:1527873365042};\\\", \\\"{x:1351,y:701,t:1527873365059};\\\", \\\"{x:1350,y:701,t:1527873365107};\\\", \\\"{x:1349,y:701,t:1527873365227};\\\", \\\"{x:1348,y:701,t:1527873365242};\\\", \\\"{x:1348,y:700,t:1527873365258};\\\", \\\"{x:1347,y:700,t:1527873365275};\\\", \\\"{x:1346,y:700,t:1527873365369};\\\", \\\"{x:1345,y:699,t:1527873365385};\\\", \\\"{x:1344,y:699,t:1527873365417};\\\", \\\"{x:1343,y:699,t:1527873365441};\\\", \\\"{x:1340,y:698,t:1527873373603};\\\", \\\"{x:1326,y:698,t:1527873373615};\\\", \\\"{x:1280,y:698,t:1527873373632};\\\", \\\"{x:1218,y:698,t:1527873373650};\\\", \\\"{x:1138,y:698,t:1527873373665};\\\", \\\"{x:985,y:698,t:1527873373682};\\\", \\\"{x:866,y:698,t:1527873373698};\\\", \\\"{x:753,y:698,t:1527873373715};\\\", \\\"{x:644,y:694,t:1527873373732};\\\", \\\"{x:550,y:682,t:1527873373749};\\\", \\\"{x:480,y:670,t:1527873373765};\\\", \\\"{x:423,y:659,t:1527873373783};\\\", \\\"{x:389,y:644,t:1527873373798};\\\", \\\"{x:375,y:636,t:1527873373815};\\\", \\\"{x:374,y:635,t:1527873373828};\\\", \\\"{x:374,y:632,t:1527873373845};\\\", \\\"{x:376,y:618,t:1527873373864};\\\", \\\"{x:387,y:600,t:1527873373879};\\\", \\\"{x:411,y:578,t:1527873373898};\\\", \\\"{x:430,y:565,t:1527873373914};\\\", \\\"{x:450,y:553,t:1527873373933};\\\", \\\"{x:471,y:544,t:1527873373949};\\\", \\\"{x:495,y:534,t:1527873373965};\\\", \\\"{x:516,y:528,t:1527873373982};\\\", \\\"{x:536,y:522,t:1527873374000};\\\", \\\"{x:555,y:519,t:1527873374014};\\\", \\\"{x:577,y:517,t:1527873374033};\\\", \\\"{x:600,y:517,t:1527873374049};\\\", \\\"{x:622,y:517,t:1527873374065};\\\", \\\"{x:644,y:514,t:1527873374081};\\\", \\\"{x:654,y:514,t:1527873374099};\\\", \\\"{x:662,y:514,t:1527873374115};\\\", \\\"{x:666,y:514,t:1527873374132};\\\", \\\"{x:667,y:514,t:1527873374153};\\\", \\\"{x:669,y:514,t:1527873374165};\\\", \\\"{x:674,y:514,t:1527873374182};\\\", \\\"{x:680,y:514,t:1527873374199};\\\", \\\"{x:684,y:514,t:1527873374215};\\\", \\\"{x:691,y:514,t:1527873374232};\\\", \\\"{x:701,y:514,t:1527873374250};\\\", \\\"{x:719,y:514,t:1527873374266};\\\", \\\"{x:737,y:514,t:1527873374284};\\\", \\\"{x:763,y:514,t:1527873374299};\\\", \\\"{x:793,y:514,t:1527873374316};\\\", \\\"{x:813,y:514,t:1527873374332};\\\", \\\"{x:823,y:514,t:1527873374348};\\\", \\\"{x:831,y:515,t:1527873374366};\\\", \\\"{x:834,y:515,t:1527873374382};\\\", \\\"{x:837,y:515,t:1527873374399};\\\", \\\"{x:837,y:514,t:1527873375243};\\\", \\\"{x:837,y:513,t:1527873375251};\\\", \\\"{x:837,y:510,t:1527873375266};\\\", \\\"{x:837,y:509,t:1527873375306};\\\", \\\"{x:838,y:508,t:1527873375987};\\\", \\\"{x:848,y:509,t:1527873376000};\\\", \\\"{x:881,y:519,t:1527873376017};\\\", \\\"{x:953,y:531,t:1527873376033};\\\", \\\"{x:1032,y:544,t:1527873376050};\\\", \\\"{x:1115,y:555,t:1527873376067};\\\", \\\"{x:1208,y:576,t:1527873376084};\\\", \\\"{x:1287,y:602,t:1527873376101};\\\", \\\"{x:1366,y:633,t:1527873376117};\\\", \\\"{x:1419,y:657,t:1527873376135};\\\", \\\"{x:1462,y:682,t:1527873376151};\\\", \\\"{x:1491,y:701,t:1527873376167};\\\", \\\"{x:1512,y:720,t:1527873376185};\\\", \\\"{x:1532,y:743,t:1527873376200};\\\", \\\"{x:1551,y:765,t:1527873376218};\\\", \\\"{x:1570,y:789,t:1527873376234};\\\", \\\"{x:1579,y:799,t:1527873376251};\\\", \\\"{x:1585,y:806,t:1527873376268};\\\", \\\"{x:1591,y:813,t:1527873376285};\\\", \\\"{x:1597,y:819,t:1527873376300};\\\", \\\"{x:1604,y:830,t:1527873376317};\\\", \\\"{x:1610,y:839,t:1527873376334};\\\", \\\"{x:1612,y:845,t:1527873376350};\\\", \\\"{x:1615,y:855,t:1527873376367};\\\", \\\"{x:1618,y:870,t:1527873376384};\\\", \\\"{x:1622,y:881,t:1527873376400};\\\", \\\"{x:1622,y:892,t:1527873376417};\\\", \\\"{x:1621,y:917,t:1527873376433};\\\", \\\"{x:1611,y:940,t:1527873376450};\\\", \\\"{x:1602,y:959,t:1527873376467};\\\", \\\"{x:1593,y:970,t:1527873376484};\\\", \\\"{x:1584,y:979,t:1527873376500};\\\", \\\"{x:1579,y:983,t:1527873376517};\\\", \\\"{x:1578,y:984,t:1527873376534};\\\", \\\"{x:1577,y:985,t:1527873376561};\\\", \\\"{x:1579,y:985,t:1527873376699};\\\", \\\"{x:1582,y:985,t:1527873376707};\\\", \\\"{x:1585,y:985,t:1527873376717};\\\", \\\"{x:1591,y:984,t:1527873376734};\\\", \\\"{x:1601,y:984,t:1527873376751};\\\", \\\"{x:1609,y:984,t:1527873376768};\\\", \\\"{x:1614,y:984,t:1527873376785};\\\", \\\"{x:1617,y:984,t:1527873376801};\\\", \\\"{x:1618,y:984,t:1527873376906};\\\", \\\"{x:1617,y:982,t:1527873376918};\\\", \\\"{x:1610,y:982,t:1527873376934};\\\", \\\"{x:1605,y:982,t:1527873376952};\\\", \\\"{x:1603,y:981,t:1527873376967};\\\", \\\"{x:1602,y:981,t:1527873376984};\\\", \\\"{x:1600,y:981,t:1527873377001};\\\", \\\"{x:1595,y:980,t:1527873377017};\\\", \\\"{x:1592,y:979,t:1527873377034};\\\", \\\"{x:1585,y:979,t:1527873377051};\\\", \\\"{x:1575,y:977,t:1527873377067};\\\", \\\"{x:1565,y:975,t:1527873377084};\\\", \\\"{x:1559,y:975,t:1527873377101};\\\", \\\"{x:1555,y:974,t:1527873377118};\\\", \\\"{x:1551,y:974,t:1527873377134};\\\", \\\"{x:1548,y:974,t:1527873377151};\\\", \\\"{x:1547,y:974,t:1527873377168};\\\", \\\"{x:1545,y:974,t:1527873377186};\\\", \\\"{x:1545,y:973,t:1527873377275};\\\", \\\"{x:1545,y:972,t:1527873377283};\\\", \\\"{x:1545,y:971,t:1527873377300};\\\", \\\"{x:1545,y:968,t:1527873377318};\\\", \\\"{x:1545,y:967,t:1527873377345};\\\", \\\"{x:1545,y:966,t:1527873377393};\\\", \\\"{x:1545,y:965,t:1527873377690};\\\", \\\"{x:1545,y:964,t:1527873377701};\\\", \\\"{x:1545,y:961,t:1527873377719};\\\", \\\"{x:1545,y:959,t:1527873377735};\\\", \\\"{x:1545,y:958,t:1527873377754};\\\", \\\"{x:1544,y:958,t:1527873378466};\\\", \\\"{x:1542,y:958,t:1527873378474};\\\", \\\"{x:1541,y:958,t:1527873378485};\\\", \\\"{x:1538,y:958,t:1527873378502};\\\", \\\"{x:1534,y:958,t:1527873378519};\\\", \\\"{x:1531,y:958,t:1527873378535};\\\", \\\"{x:1529,y:958,t:1527873378553};\\\", \\\"{x:1525,y:958,t:1527873378569};\\\", \\\"{x:1524,y:958,t:1527873378586};\\\", \\\"{x:1516,y:959,t:1527873378603};\\\", \\\"{x:1513,y:959,t:1527873378620};\\\", \\\"{x:1511,y:960,t:1527873378636};\\\", \\\"{x:1508,y:961,t:1527873378652};\\\", \\\"{x:1505,y:962,t:1527873378669};\\\", \\\"{x:1504,y:962,t:1527873378685};\\\", \\\"{x:1502,y:963,t:1527873378702};\\\", \\\"{x:1500,y:964,t:1527873378719};\\\", \\\"{x:1498,y:965,t:1527873378736};\\\", \\\"{x:1497,y:966,t:1527873378753};\\\", \\\"{x:1496,y:967,t:1527873378769};\\\", \\\"{x:1494,y:967,t:1527873378794};\\\", \\\"{x:1494,y:968,t:1527873378826};\\\", \\\"{x:1493,y:968,t:1527873378914};\\\", \\\"{x:1491,y:968,t:1527873378930};\\\", \\\"{x:1491,y:969,t:1527873378946};\\\", \\\"{x:1490,y:969,t:1527873378954};\\\", \\\"{x:1488,y:970,t:1527873378970};\\\", \\\"{x:1487,y:970,t:1527873379186};\\\", \\\"{x:1486,y:970,t:1527873379203};\\\", \\\"{x:1484,y:970,t:1527873379219};\\\", \\\"{x:1484,y:969,t:1527873379236};\\\", \\\"{x:1485,y:967,t:1527873379259};\\\", \\\"{x:1485,y:966,t:1527873379270};\\\", \\\"{x:1489,y:966,t:1527873379286};\\\", \\\"{x:1492,y:965,t:1527873379303};\\\", \\\"{x:1493,y:964,t:1527873379319};\\\", \\\"{x:1494,y:964,t:1527873379336};\\\", \\\"{x:1495,y:964,t:1527873379385};\\\", \\\"{x:1495,y:963,t:1527873379393};\\\", \\\"{x:1496,y:962,t:1527873379409};\\\", \\\"{x:1497,y:962,t:1527873379419};\\\", \\\"{x:1498,y:961,t:1527873379436};\\\", \\\"{x:1501,y:959,t:1527873379453};\\\", \\\"{x:1503,y:959,t:1527873379470};\\\", \\\"{x:1506,y:959,t:1527873379486};\\\", \\\"{x:1508,y:959,t:1527873379504};\\\", \\\"{x:1511,y:958,t:1527873379519};\\\", \\\"{x:1512,y:958,t:1527873379674};\\\", \\\"{x:1513,y:958,t:1527873379687};\\\", \\\"{x:1514,y:958,t:1527873379703};\\\", \\\"{x:1515,y:958,t:1527873379747};\\\", \\\"{x:1515,y:959,t:1527873379754};\\\", \\\"{x:1516,y:959,t:1527873379771};\\\", \\\"{x:1516,y:960,t:1527873379787};\\\", \\\"{x:1517,y:960,t:1527873379923};\\\", \\\"{x:1518,y:961,t:1527873379937};\\\", \\\"{x:1518,y:962,t:1527873379954};\\\", \\\"{x:1518,y:963,t:1527873379971};\\\", \\\"{x:1519,y:964,t:1527873381034};\\\", \\\"{x:1519,y:965,t:1527873389475};\\\", \\\"{x:1519,y:967,t:1527873389482};\\\", \\\"{x:1516,y:968,t:1527873389495};\\\", \\\"{x:1507,y:971,t:1527873389511};\\\", \\\"{x:1496,y:974,t:1527873389529};\\\", \\\"{x:1489,y:975,t:1527873389545};\\\", \\\"{x:1485,y:977,t:1527873389562};\\\", \\\"{x:1483,y:977,t:1527873389706};\\\", \\\"{x:1482,y:977,t:1527873389722};\\\", \\\"{x:1481,y:977,t:1527873389746};\\\", \\\"{x:1480,y:977,t:1527873389778};\\\", \\\"{x:1479,y:977,t:1527873389795};\\\", \\\"{x:1479,y:975,t:1527873389826};\\\", \\\"{x:1479,y:974,t:1527873389834};\\\", \\\"{x:1481,y:974,t:1527873389858};\\\", \\\"{x:1481,y:973,t:1527873389874};\\\", \\\"{x:1478,y:973,t:1527873392115};\\\", \\\"{x:1469,y:975,t:1527873392130};\\\", \\\"{x:1463,y:976,t:1527873392148};\\\", \\\"{x:1453,y:979,t:1527873392163};\\\", \\\"{x:1449,y:980,t:1527873392180};\\\", \\\"{x:1445,y:980,t:1527873392198};\\\", \\\"{x:1444,y:980,t:1527873392213};\\\", \\\"{x:1442,y:980,t:1527873392434};\\\", \\\"{x:1441,y:980,t:1527873392448};\\\", \\\"{x:1440,y:977,t:1527873392463};\\\", \\\"{x:1439,y:975,t:1527873392482};\\\", \\\"{x:1438,y:974,t:1527873392498};\\\", \\\"{x:1438,y:973,t:1527873392522};\\\", \\\"{x:1438,y:972,t:1527873392674};\\\", \\\"{x:1439,y:972,t:1527873392698};\\\", \\\"{x:1440,y:971,t:1527873392714};\\\", \\\"{x:1441,y:971,t:1527873392746};\\\", \\\"{x:1442,y:971,t:1527873392765};\\\", \\\"{x:1444,y:970,t:1527873392780};\\\", \\\"{x:1445,y:969,t:1527873392834};\\\", \\\"{x:1446,y:969,t:1527873392850};\\\", \\\"{x:1447,y:969,t:1527873392865};\\\", \\\"{x:1448,y:968,t:1527873392883};\\\", \\\"{x:1448,y:967,t:1527873392897};\\\", \\\"{x:1450,y:967,t:1527873392914};\\\", \\\"{x:1451,y:966,t:1527873392962};\\\", \\\"{x:1452,y:966,t:1527873393355};\\\", \\\"{x:1453,y:966,t:1527873393364};\\\", \\\"{x:1453,y:965,t:1527873393939};\\\", \\\"{x:1451,y:965,t:1527873395027};\\\", \\\"{x:1449,y:965,t:1527873395034};\\\", \\\"{x:1447,y:965,t:1527873395050};\\\", \\\"{x:1444,y:965,t:1527873395066};\\\", \\\"{x:1443,y:965,t:1527873395082};\\\", \\\"{x:1442,y:965,t:1527873395186};\\\", \\\"{x:1440,y:965,t:1527873395199};\\\", \\\"{x:1436,y:965,t:1527873395217};\\\", \\\"{x:1433,y:965,t:1527873395232};\\\", \\\"{x:1429,y:965,t:1527873395249};\\\", \\\"{x:1427,y:965,t:1527873395266};\\\", \\\"{x:1426,y:965,t:1527873395282};\\\", \\\"{x:1424,y:965,t:1527873395634};\\\", \\\"{x:1420,y:967,t:1527873395650};\\\", \\\"{x:1417,y:968,t:1527873395666};\\\", \\\"{x:1416,y:968,t:1527873395684};\\\", \\\"{x:1415,y:969,t:1527873395699};\\\", \\\"{x:1414,y:969,t:1527873396571};\\\", \\\"{x:1410,y:969,t:1527873396584};\\\", \\\"{x:1405,y:969,t:1527873396601};\\\", \\\"{x:1402,y:969,t:1527873396618};\\\", \\\"{x:1398,y:969,t:1527873396634};\\\", \\\"{x:1395,y:969,t:1527873396650};\\\", \\\"{x:1392,y:968,t:1527873396668};\\\", \\\"{x:1387,y:967,t:1527873396683};\\\", \\\"{x:1379,y:966,t:1527873396700};\\\", \\\"{x:1371,y:966,t:1527873396718};\\\", \\\"{x:1367,y:966,t:1527873396734};\\\", \\\"{x:1365,y:966,t:1527873396751};\\\", \\\"{x:1367,y:966,t:1527873396962};\\\", \\\"{x:1371,y:966,t:1527873396970};\\\", \\\"{x:1373,y:964,t:1527873396985};\\\", \\\"{x:1378,y:963,t:1527873397000};\\\", \\\"{x:1381,y:962,t:1527873397018};\\\", \\\"{x:1383,y:961,t:1527873397467};\\\", \\\"{x:1383,y:960,t:1527873397484};\\\", \\\"{x:1383,y:959,t:1527873397502};\\\", \\\"{x:1383,y:958,t:1527873397518};\\\", \\\"{x:1383,y:957,t:1527873397538};\\\", \\\"{x:1383,y:956,t:1527873397552};\\\", \\\"{x:1383,y:955,t:1527873397568};\\\", \\\"{x:1383,y:954,t:1527873397594};\\\", \\\"{x:1381,y:953,t:1527873397907};\\\", \\\"{x:1377,y:953,t:1527873397918};\\\", \\\"{x:1370,y:953,t:1527873397934};\\\", \\\"{x:1366,y:953,t:1527873397952};\\\", \\\"{x:1364,y:953,t:1527873397968};\\\", \\\"{x:1363,y:953,t:1527873397985};\\\", \\\"{x:1362,y:953,t:1527873398203};\\\", \\\"{x:1357,y:953,t:1527873398218};\\\", \\\"{x:1354,y:953,t:1527873398235};\\\", \\\"{x:1350,y:953,t:1527873398252};\\\", \\\"{x:1347,y:953,t:1527873398269};\\\", \\\"{x:1347,y:954,t:1527873398285};\\\", \\\"{x:1346,y:954,t:1527873398401};\\\", \\\"{x:1344,y:954,t:1527873398418};\\\", \\\"{x:1342,y:955,t:1527873398435};\\\", \\\"{x:1341,y:955,t:1527873398466};\\\", \\\"{x:1340,y:955,t:1527873398473};\\\", \\\"{x:1339,y:955,t:1527873398490};\\\", \\\"{x:1338,y:956,t:1527873400306};\\\", \\\"{x:1338,y:958,t:1527873400570};\\\", \\\"{x:1338,y:959,t:1527873400602};\\\", \\\"{x:1338,y:960,t:1527873400626};\\\", \\\"{x:1338,y:961,t:1527873400746};\\\", \\\"{x:1338,y:962,t:1527873400794};\\\", \\\"{x:1338,y:963,t:1527873401019};\\\", \\\"{x:1339,y:964,t:1527873401042};\\\", \\\"{x:1340,y:964,t:1527873401058};\\\", \\\"{x:1342,y:964,t:1527873401099};\\\", \\\"{x:1342,y:965,t:1527873401122};\\\", \\\"{x:1343,y:965,t:1527873401226};\\\", \\\"{x:1343,y:964,t:1527873401611};\\\", \\\"{x:1343,y:963,t:1527873401634};\\\", \\\"{x:1343,y:962,t:1527873401771};\\\", \\\"{x:1343,y:961,t:1527873401788};\\\", \\\"{x:1343,y:960,t:1527873401810};\\\", \\\"{x:1342,y:959,t:1527873401970};\\\", \\\"{x:1342,y:958,t:1527873401986};\\\", \\\"{x:1342,y:957,t:1527873402018};\\\", \\\"{x:1341,y:957,t:1527873403370};\\\", \\\"{x:1339,y:957,t:1527873403378};\\\", \\\"{x:1334,y:957,t:1527873403389};\\\", \\\"{x:1327,y:957,t:1527873403405};\\\", \\\"{x:1321,y:957,t:1527873403423};\\\", \\\"{x:1319,y:957,t:1527873403439};\\\", \\\"{x:1318,y:957,t:1527873403458};\\\", \\\"{x:1317,y:957,t:1527873403650};\\\", \\\"{x:1313,y:957,t:1527873403658};\\\", \\\"{x:1308,y:957,t:1527873403673};\\\", \\\"{x:1297,y:957,t:1527873403690};\\\", \\\"{x:1291,y:957,t:1527873403706};\\\", \\\"{x:1285,y:957,t:1527873403723};\\\", \\\"{x:1283,y:956,t:1527873403740};\\\", \\\"{x:1282,y:956,t:1527873403756};\\\", \\\"{x:1280,y:956,t:1527873403773};\\\", \\\"{x:1278,y:956,t:1527873403790};\\\", \\\"{x:1278,y:955,t:1527873403806};\\\", \\\"{x:1276,y:955,t:1527873403826};\\\", \\\"{x:1275,y:954,t:1527873404282};\\\", \\\"{x:1273,y:954,t:1527873404305};\\\", \\\"{x:1275,y:953,t:1527873404370};\\\", \\\"{x:1279,y:953,t:1527873404378};\\\", \\\"{x:1285,y:953,t:1527873404390};\\\", \\\"{x:1293,y:953,t:1527873404407};\\\", \\\"{x:1303,y:953,t:1527873404423};\\\", \\\"{x:1311,y:953,t:1527873404440};\\\", \\\"{x:1320,y:953,t:1527873404457};\\\", \\\"{x:1331,y:953,t:1527873404474};\\\", \\\"{x:1338,y:953,t:1527873404490};\\\", \\\"{x:1339,y:953,t:1527873404506};\\\", \\\"{x:1342,y:953,t:1527873404553};\\\", \\\"{x:1343,y:953,t:1527873404577};\\\", \\\"{x:1344,y:953,t:1527873404601};\\\", \\\"{x:1344,y:954,t:1527873404609};\\\", \\\"{x:1345,y:954,t:1527873404623};\\\", \\\"{x:1346,y:955,t:1527873404639};\\\", \\\"{x:1347,y:956,t:1527873404657};\\\", \\\"{x:1348,y:957,t:1527873404673};\\\", \\\"{x:1348,y:958,t:1527873404689};\\\", \\\"{x:1348,y:960,t:1527873404707};\\\", \\\"{x:1345,y:961,t:1527873404724};\\\", \\\"{x:1343,y:961,t:1527873404739};\\\", \\\"{x:1342,y:962,t:1527873404756};\\\", \\\"{x:1341,y:962,t:1527873404850};\\\", \\\"{x:1340,y:962,t:1527873404858};\\\", \\\"{x:1338,y:962,t:1527873404874};\\\", \\\"{x:1336,y:962,t:1527873404890};\\\", \\\"{x:1335,y:962,t:1527873404907};\\\", \\\"{x:1333,y:962,t:1527873404924};\\\", \\\"{x:1331,y:962,t:1527873404941};\\\", \\\"{x:1330,y:962,t:1527873404957};\\\", \\\"{x:1327,y:962,t:1527873404973};\\\", \\\"{x:1326,y:962,t:1527873404991};\\\", \\\"{x:1325,y:962,t:1527873405074};\\\", \\\"{x:1324,y:962,t:1527873405106};\\\", \\\"{x:1323,y:962,t:1527873405124};\\\", \\\"{x:1322,y:962,t:1527873405141};\\\", \\\"{x:1322,y:961,t:1527873405157};\\\", \\\"{x:1321,y:960,t:1527873405174};\\\", \\\"{x:1318,y:958,t:1527873405202};\\\", \\\"{x:1317,y:957,t:1527873405218};\\\", \\\"{x:1316,y:956,t:1527873405226};\\\", \\\"{x:1316,y:955,t:1527873405241};\\\", \\\"{x:1314,y:949,t:1527873405257};\\\", \\\"{x:1314,y:943,t:1527873405274};\\\", \\\"{x:1313,y:933,t:1527873405291};\\\", \\\"{x:1313,y:921,t:1527873405307};\\\", \\\"{x:1313,y:910,t:1527873405324};\\\", \\\"{x:1315,y:900,t:1527873405341};\\\", \\\"{x:1316,y:888,t:1527873405358};\\\", \\\"{x:1319,y:873,t:1527873405374};\\\", \\\"{x:1321,y:860,t:1527873405391};\\\", \\\"{x:1321,y:851,t:1527873405408};\\\", \\\"{x:1321,y:844,t:1527873405424};\\\", \\\"{x:1321,y:836,t:1527873405441};\\\", \\\"{x:1321,y:824,t:1527873405457};\\\", \\\"{x:1321,y:819,t:1527873405474};\\\", \\\"{x:1321,y:818,t:1527873405491};\\\", \\\"{x:1321,y:814,t:1527873405508};\\\", \\\"{x:1319,y:805,t:1527873405525};\\\", \\\"{x:1315,y:796,t:1527873405541};\\\", \\\"{x:1313,y:790,t:1527873405558};\\\", \\\"{x:1310,y:784,t:1527873405574};\\\", \\\"{x:1307,y:775,t:1527873405591};\\\", \\\"{x:1300,y:763,t:1527873405608};\\\", \\\"{x:1295,y:750,t:1527873405625};\\\", \\\"{x:1292,y:743,t:1527873405640};\\\", \\\"{x:1290,y:739,t:1527873405658};\\\", \\\"{x:1290,y:736,t:1527873405674};\\\", \\\"{x:1288,y:733,t:1527873405690};\\\", \\\"{x:1287,y:730,t:1527873405708};\\\", \\\"{x:1287,y:729,t:1527873405724};\\\", \\\"{x:1287,y:728,t:1527873405741};\\\", \\\"{x:1286,y:731,t:1527873405834};\\\", \\\"{x:1286,y:736,t:1527873405842};\\\", \\\"{x:1284,y:752,t:1527873405858};\\\", \\\"{x:1283,y:766,t:1527873405875};\\\", \\\"{x:1283,y:778,t:1527873405891};\\\", \\\"{x:1282,y:784,t:1527873405908};\\\", \\\"{x:1282,y:791,t:1527873405926};\\\", \\\"{x:1282,y:799,t:1527873405941};\\\", \\\"{x:1282,y:806,t:1527873405958};\\\", \\\"{x:1282,y:812,t:1527873405975};\\\", \\\"{x:1283,y:818,t:1527873405991};\\\", \\\"{x:1283,y:823,t:1527873406008};\\\", \\\"{x:1283,y:829,t:1527873406025};\\\", \\\"{x:1284,y:836,t:1527873406041};\\\", \\\"{x:1285,y:847,t:1527873406058};\\\", \\\"{x:1287,y:856,t:1527873406075};\\\", \\\"{x:1288,y:863,t:1527873406091};\\\", \\\"{x:1292,y:875,t:1527873406108};\\\", \\\"{x:1293,y:883,t:1527873406125};\\\", \\\"{x:1294,y:892,t:1527873406141};\\\", \\\"{x:1296,y:900,t:1527873406158};\\\", \\\"{x:1296,y:906,t:1527873406175};\\\", \\\"{x:1298,y:911,t:1527873406191};\\\", \\\"{x:1298,y:916,t:1527873406209};\\\", \\\"{x:1298,y:919,t:1527873406225};\\\", \\\"{x:1298,y:923,t:1527873406242};\\\", \\\"{x:1298,y:925,t:1527873406258};\\\", \\\"{x:1298,y:926,t:1527873406275};\\\", \\\"{x:1298,y:928,t:1527873406292};\\\", \\\"{x:1297,y:931,t:1527873406308};\\\", \\\"{x:1294,y:938,t:1527873406324};\\\", \\\"{x:1291,y:943,t:1527873406341};\\\", \\\"{x:1289,y:946,t:1527873406358};\\\", \\\"{x:1288,y:948,t:1527873406374};\\\", \\\"{x:1288,y:950,t:1527873406401};\\\", \\\"{x:1287,y:951,t:1527873408042};\\\", \\\"{x:1286,y:951,t:1527873408074};\\\", \\\"{x:1285,y:951,t:1527873408145};\\\", \\\"{x:1284,y:949,t:1527873411229};\\\", \\\"{x:1283,y:949,t:1527873411245};\\\", \\\"{x:1282,y:949,t:1527873411276};\\\", \\\"{x:1271,y:945,t:1527873412941};\\\", \\\"{x:1261,y:942,t:1527873412950};\\\", \\\"{x:1237,y:932,t:1527873412966};\\\", \\\"{x:1215,y:924,t:1527873412983};\\\", \\\"{x:1193,y:915,t:1527873413000};\\\", \\\"{x:1169,y:902,t:1527873413016};\\\", \\\"{x:1149,y:886,t:1527873413033};\\\", \\\"{x:1131,y:868,t:1527873413050};\\\", \\\"{x:1115,y:850,t:1527873413066};\\\", \\\"{x:1096,y:821,t:1527873413084};\\\", \\\"{x:1093,y:812,t:1527873413099};\\\", \\\"{x:1082,y:796,t:1527873413116};\\\", \\\"{x:1073,y:779,t:1527873413133};\\\", \\\"{x:1065,y:768,t:1527873413150};\\\", \\\"{x:1057,y:751,t:1527873413166};\\\", \\\"{x:1045,y:733,t:1527873413182};\\\", \\\"{x:1032,y:719,t:1527873413199};\\\", \\\"{x:1019,y:703,t:1527873413215};\\\", \\\"{x:1007,y:690,t:1527873413232};\\\", \\\"{x:993,y:679,t:1527873413250};\\\", \\\"{x:977,y:671,t:1527873413265};\\\", \\\"{x:948,y:655,t:1527873413283};\\\", \\\"{x:932,y:648,t:1527873413299};\\\", \\\"{x:914,y:641,t:1527873413315};\\\", \\\"{x:895,y:636,t:1527873413332};\\\", \\\"{x:872,y:631,t:1527873413350};\\\", \\\"{x:849,y:628,t:1527873413366};\\\", \\\"{x:828,y:626,t:1527873413383};\\\", \\\"{x:813,y:626,t:1527873413398};\\\", \\\"{x:802,y:626,t:1527873413415};\\\", \\\"{x:796,y:626,t:1527873413433};\\\", \\\"{x:792,y:626,t:1527873413449};\\\", \\\"{x:788,y:629,t:1527873413466};\\\", \\\"{x:782,y:630,t:1527873413483};\\\", \\\"{x:781,y:631,t:1527873413499};\\\", \\\"{x:779,y:631,t:1527873413516};\\\", \\\"{x:778,y:631,t:1527873413533};\\\", \\\"{x:777,y:631,t:1527873413549};\\\", \\\"{x:776,y:631,t:1527873413772};\\\", \\\"{x:772,y:631,t:1527873413784};\\\", \\\"{x:758,y:631,t:1527873413801};\\\", \\\"{x:740,y:631,t:1527873413816};\\\", \\\"{x:716,y:631,t:1527873413835};\\\", \\\"{x:686,y:631,t:1527873413850};\\\", \\\"{x:656,y:631,t:1527873413866};\\\", \\\"{x:649,y:632,t:1527873413884};\\\", \\\"{x:647,y:634,t:1527873413900};\\\", \\\"{x:645,y:636,t:1527873413916};\\\", \\\"{x:640,y:640,t:1527873413933};\\\", \\\"{x:633,y:647,t:1527873413950};\\\", \\\"{x:621,y:659,t:1527873413966};\\\", \\\"{x:614,y:665,t:1527873413983};\\\", \\\"{x:608,y:668,t:1527873414000};\\\", \\\"{x:604,y:670,t:1527873414016};\\\", \\\"{x:600,y:673,t:1527873414033};\\\", \\\"{x:591,y:681,t:1527873414051};\\\", \\\"{x:584,y:691,t:1527873414067};\\\", \\\"{x:564,y:710,t:1527873414084};\\\", \\\"{x:545,y:723,t:1527873414101};\\\", \\\"{x:530,y:734,t:1527873414117};\\\", \\\"{x:520,y:740,t:1527873414133};\\\", \\\"{x:515,y:741,t:1527873414150};\\\", \\\"{x:514,y:741,t:1527873414167};\\\", \\\"{x:517,y:741,t:1527873414717};\\\", \\\"{x:525,y:741,t:1527873414724};\\\", \\\"{x:539,y:741,t:1527873414735};\\\", \\\"{x:564,y:744,t:1527873414750};\\\", \\\"{x:587,y:749,t:1527873414767};\\\", \\\"{x:601,y:753,t:1527873414784};\\\", \\\"{x:605,y:756,t:1527873414801};\\\", \\\"{x:606,y:757,t:1527873414818};\\\", \\\"{x:606,y:758,t:1527873415531};\\\", \\\"{x:605,y:758,t:1527873415644};\\\", \\\"{x:603,y:758,t:1527873415675};\\\", \\\"{x:603,y:757,t:1527873415684};\\\", \\\"{x:602,y:757,t:1527873415716};\\\", \\\"{x:601,y:756,t:1527873415739};\\\" ] }, { \\\"rt\\\": 36143, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 642076, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"QGUGU\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-03 PM-03 PM-03 PM-O -03 PM-01 PM-12 PM-2\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:592,y:747,t:1527873415927};\\\", \\\"{x:592,y:746,t:1527873415954};\\\", \\\"{x:590,y:746,t:1527873415968};\\\", \\\"{x:590,y:745,t:1527873415985};\\\", \\\"{x:589,y:745,t:1527873416308};\\\", \\\"{x:588,y:743,t:1527873416318};\\\", \\\"{x:582,y:729,t:1527873416335};\\\", \\\"{x:571,y:711,t:1527873416352};\\\", \\\"{x:558,y:689,t:1527873416369};\\\", \\\"{x:549,y:677,t:1527873416386};\\\", \\\"{x:545,y:671,t:1527873416402};\\\", \\\"{x:542,y:667,t:1527873416418};\\\", \\\"{x:535,y:654,t:1527873416436};\\\", \\\"{x:531,y:646,t:1527873416452};\\\", \\\"{x:525,y:630,t:1527873416469};\\\", \\\"{x:517,y:613,t:1527873416486};\\\", \\\"{x:514,y:604,t:1527873416501};\\\", \\\"{x:511,y:594,t:1527873416519};\\\", \\\"{x:508,y:585,t:1527873416536};\\\", \\\"{x:505,y:578,t:1527873416553};\\\", \\\"{x:504,y:576,t:1527873416568};\\\", \\\"{x:504,y:574,t:1527873416585};\\\", \\\"{x:503,y:574,t:1527873416602};\\\", \\\"{x:509,y:574,t:1527873416924};\\\", \\\"{x:525,y:574,t:1527873416936};\\\", \\\"{x:587,y:574,t:1527873416953};\\\", \\\"{x:678,y:574,t:1527873416970};\\\", \\\"{x:792,y:574,t:1527873416988};\\\", \\\"{x:929,y:588,t:1527873417003};\\\", \\\"{x:1147,y:618,t:1527873417019};\\\", \\\"{x:1274,y:639,t:1527873417035};\\\", \\\"{x:1393,y:653,t:1527873417053};\\\", \\\"{x:1494,y:671,t:1527873417069};\\\", \\\"{x:1565,y:689,t:1527873417086};\\\", \\\"{x:1596,y:698,t:1527873417103};\\\", \\\"{x:1615,y:706,t:1527873417119};\\\", \\\"{x:1624,y:713,t:1527873417136};\\\", \\\"{x:1629,y:718,t:1527873417153};\\\", \\\"{x:1633,y:725,t:1527873417170};\\\", \\\"{x:1638,y:738,t:1527873417186};\\\", \\\"{x:1644,y:746,t:1527873417202};\\\", \\\"{x:1650,y:758,t:1527873417219};\\\", \\\"{x:1653,y:773,t:1527873417236};\\\", \\\"{x:1657,y:796,t:1527873417252};\\\", \\\"{x:1662,y:823,t:1527873417270};\\\", \\\"{x:1664,y:842,t:1527873417287};\\\", \\\"{x:1666,y:856,t:1527873417302};\\\", \\\"{x:1666,y:870,t:1527873417319};\\\", \\\"{x:1666,y:885,t:1527873417337};\\\", \\\"{x:1665,y:906,t:1527873417353};\\\", \\\"{x:1655,y:927,t:1527873417370};\\\", \\\"{x:1647,y:946,t:1527873417387};\\\", \\\"{x:1639,y:958,t:1527873417402};\\\", \\\"{x:1629,y:975,t:1527873417420};\\\", \\\"{x:1623,y:984,t:1527873417437};\\\", \\\"{x:1615,y:991,t:1527873417454};\\\", \\\"{x:1615,y:992,t:1527873417470};\\\", \\\"{x:1613,y:993,t:1527873417487};\\\", \\\"{x:1612,y:993,t:1527873417524};\\\", \\\"{x:1608,y:993,t:1527873417537};\\\", \\\"{x:1596,y:993,t:1527873417553};\\\", \\\"{x:1591,y:993,t:1527873417570};\\\", \\\"{x:1581,y:992,t:1527873417587};\\\", \\\"{x:1568,y:989,t:1527873417603};\\\", \\\"{x:1547,y:987,t:1527873417621};\\\", \\\"{x:1537,y:986,t:1527873417637};\\\", \\\"{x:1531,y:984,t:1527873417654};\\\", \\\"{x:1528,y:983,t:1527873417670};\\\", \\\"{x:1526,y:982,t:1527873417687};\\\", \\\"{x:1527,y:981,t:1527873417828};\\\", \\\"{x:1529,y:981,t:1527873417861};\\\", \\\"{x:1531,y:980,t:1527873417870};\\\", \\\"{x:1533,y:980,t:1527873417887};\\\", \\\"{x:1534,y:979,t:1527873417904};\\\", \\\"{x:1536,y:978,t:1527873417941};\\\", \\\"{x:1537,y:977,t:1527873417956};\\\", \\\"{x:1538,y:976,t:1527873417970};\\\", \\\"{x:1538,y:975,t:1527873417996};\\\", \\\"{x:1539,y:974,t:1527873418045};\\\", \\\"{x:1539,y:973,t:1527873418060};\\\", \\\"{x:1539,y:972,t:1527873418084};\\\", \\\"{x:1540,y:971,t:1527873418093};\\\", \\\"{x:1541,y:969,t:1527873418133};\\\", \\\"{x:1541,y:968,t:1527873418189};\\\", \\\"{x:1541,y:966,t:1527873418205};\\\", \\\"{x:1541,y:964,t:1527873418220};\\\", \\\"{x:1541,y:962,t:1527873418237};\\\", \\\"{x:1543,y:959,t:1527873418254};\\\", \\\"{x:1544,y:956,t:1527873418271};\\\", \\\"{x:1544,y:954,t:1527873418287};\\\", \\\"{x:1545,y:950,t:1527873418304};\\\", \\\"{x:1547,y:947,t:1527873418321};\\\", \\\"{x:1547,y:944,t:1527873418337};\\\", \\\"{x:1547,y:942,t:1527873418354};\\\", \\\"{x:1547,y:940,t:1527873418371};\\\", \\\"{x:1547,y:938,t:1527873418387};\\\", \\\"{x:1548,y:935,t:1527873418405};\\\", \\\"{x:1548,y:932,t:1527873418420};\\\", \\\"{x:1549,y:929,t:1527873418437};\\\", \\\"{x:1549,y:923,t:1527873418453};\\\", \\\"{x:1549,y:917,t:1527873418470};\\\", \\\"{x:1549,y:912,t:1527873418487};\\\", \\\"{x:1549,y:906,t:1527873418503};\\\", \\\"{x:1549,y:900,t:1527873418520};\\\", \\\"{x:1549,y:893,t:1527873418537};\\\", \\\"{x:1549,y:889,t:1527873418554};\\\", \\\"{x:1549,y:885,t:1527873418571};\\\", \\\"{x:1549,y:881,t:1527873418587};\\\", \\\"{x:1549,y:879,t:1527873418604};\\\", \\\"{x:1549,y:876,t:1527873418620};\\\", \\\"{x:1549,y:873,t:1527873418638};\\\", \\\"{x:1549,y:872,t:1527873418654};\\\", \\\"{x:1549,y:868,t:1527873418671};\\\", \\\"{x:1549,y:862,t:1527873418689};\\\", \\\"{x:1549,y:859,t:1527873418704};\\\", \\\"{x:1549,y:855,t:1527873418721};\\\", \\\"{x:1549,y:852,t:1527873418738};\\\", \\\"{x:1549,y:848,t:1527873418754};\\\", \\\"{x:1548,y:844,t:1527873418771};\\\", \\\"{x:1548,y:835,t:1527873418788};\\\", \\\"{x:1548,y:822,t:1527873418804};\\\", \\\"{x:1548,y:814,t:1527873418821};\\\", \\\"{x:1548,y:809,t:1527873418838};\\\", \\\"{x:1548,y:802,t:1527873418854};\\\", \\\"{x:1548,y:793,t:1527873418871};\\\", \\\"{x:1548,y:785,t:1527873418888};\\\", \\\"{x:1548,y:780,t:1527873418904};\\\", \\\"{x:1548,y:774,t:1527873418921};\\\", \\\"{x:1548,y:770,t:1527873418938};\\\", \\\"{x:1548,y:764,t:1527873418955};\\\", \\\"{x:1548,y:757,t:1527873418971};\\\", \\\"{x:1547,y:750,t:1527873418988};\\\", \\\"{x:1547,y:746,t:1527873419004};\\\", \\\"{x:1547,y:744,t:1527873419021};\\\", \\\"{x:1546,y:738,t:1527873419038};\\\", \\\"{x:1544,y:728,t:1527873419055};\\\", \\\"{x:1542,y:716,t:1527873419071};\\\", \\\"{x:1542,y:710,t:1527873419088};\\\", \\\"{x:1541,y:706,t:1527873419105};\\\", \\\"{x:1539,y:697,t:1527873419121};\\\", \\\"{x:1538,y:690,t:1527873419138};\\\", \\\"{x:1537,y:682,t:1527873419155};\\\", \\\"{x:1537,y:674,t:1527873419171};\\\", \\\"{x:1537,y:664,t:1527873419189};\\\", \\\"{x:1535,y:659,t:1527873419204};\\\", \\\"{x:1534,y:656,t:1527873419222};\\\", \\\"{x:1534,y:655,t:1527873419268};\\\", \\\"{x:1534,y:654,t:1527873419629};\\\", \\\"{x:1535,y:658,t:1527873419668};\\\", \\\"{x:1540,y:663,t:1527873419677};\\\", \\\"{x:1545,y:671,t:1527873419688};\\\", \\\"{x:1554,y:685,t:1527873419706};\\\", \\\"{x:1562,y:700,t:1527873419722};\\\", \\\"{x:1572,y:716,t:1527873419739};\\\", \\\"{x:1579,y:729,t:1527873419756};\\\", \\\"{x:1590,y:750,t:1527873419772};\\\", \\\"{x:1595,y:769,t:1527873419788};\\\", \\\"{x:1599,y:784,t:1527873419805};\\\", \\\"{x:1606,y:800,t:1527873419822};\\\", \\\"{x:1609,y:810,t:1527873419839};\\\", \\\"{x:1610,y:823,t:1527873419855};\\\", \\\"{x:1613,y:833,t:1527873419873};\\\", \\\"{x:1613,y:840,t:1527873419889};\\\", \\\"{x:1613,y:848,t:1527873419906};\\\", \\\"{x:1613,y:855,t:1527873419922};\\\", \\\"{x:1613,y:865,t:1527873419940};\\\", \\\"{x:1613,y:871,t:1527873419956};\\\", \\\"{x:1613,y:884,t:1527873419972};\\\", \\\"{x:1613,y:890,t:1527873419988};\\\", \\\"{x:1613,y:895,t:1527873420005};\\\", \\\"{x:1611,y:903,t:1527873420022};\\\", \\\"{x:1606,y:913,t:1527873420039};\\\", \\\"{x:1602,y:927,t:1527873420056};\\\", \\\"{x:1601,y:942,t:1527873420072};\\\", \\\"{x:1596,y:952,t:1527873420089};\\\", \\\"{x:1591,y:956,t:1527873420105};\\\", \\\"{x:1587,y:958,t:1527873420122};\\\", \\\"{x:1586,y:959,t:1527873420139};\\\", \\\"{x:1586,y:960,t:1527873420413};\\\", \\\"{x:1582,y:963,t:1527873420423};\\\", \\\"{x:1578,y:966,t:1527873420440};\\\", \\\"{x:1571,y:968,t:1527873420456};\\\", \\\"{x:1567,y:970,t:1527873420473};\\\", \\\"{x:1564,y:972,t:1527873420489};\\\", \\\"{x:1563,y:972,t:1527873420677};\\\", \\\"{x:1560,y:972,t:1527873420689};\\\", \\\"{x:1557,y:970,t:1527873420706};\\\", \\\"{x:1555,y:969,t:1527873420722};\\\", \\\"{x:1553,y:967,t:1527873420740};\\\", \\\"{x:1552,y:965,t:1527873420756};\\\", \\\"{x:1550,y:964,t:1527873420773};\\\", \\\"{x:1549,y:962,t:1527873420790};\\\", \\\"{x:1549,y:961,t:1527873420806};\\\", \\\"{x:1549,y:960,t:1527873420822};\\\", \\\"{x:1549,y:959,t:1527873420839};\\\", \\\"{x:1548,y:958,t:1527873420856};\\\", \\\"{x:1547,y:958,t:1527873420884};\\\", \\\"{x:1547,y:957,t:1527873420892};\\\", \\\"{x:1547,y:956,t:1527873420924};\\\", \\\"{x:1547,y:954,t:1527873420940};\\\", \\\"{x:1547,y:953,t:1527873420957};\\\", \\\"{x:1547,y:951,t:1527873420972};\\\", \\\"{x:1547,y:948,t:1527873420989};\\\", \\\"{x:1546,y:945,t:1527873421006};\\\", \\\"{x:1546,y:943,t:1527873421023};\\\", \\\"{x:1544,y:939,t:1527873421039};\\\", \\\"{x:1540,y:930,t:1527873421056};\\\", \\\"{x:1534,y:920,t:1527873421073};\\\", \\\"{x:1528,y:905,t:1527873421089};\\\", \\\"{x:1522,y:891,t:1527873421106};\\\", \\\"{x:1518,y:882,t:1527873421123};\\\", \\\"{x:1515,y:870,t:1527873421139};\\\", \\\"{x:1509,y:850,t:1527873421156};\\\", \\\"{x:1507,y:834,t:1527873421173};\\\", \\\"{x:1507,y:823,t:1527873421190};\\\", \\\"{x:1506,y:815,t:1527873421206};\\\", \\\"{x:1506,y:809,t:1527873421223};\\\", \\\"{x:1504,y:804,t:1527873421240};\\\", \\\"{x:1504,y:799,t:1527873421256};\\\", \\\"{x:1504,y:797,t:1527873421273};\\\", \\\"{x:1504,y:795,t:1527873421290};\\\", \\\"{x:1505,y:790,t:1527873421306};\\\", \\\"{x:1506,y:787,t:1527873421323};\\\", \\\"{x:1510,y:779,t:1527873421340};\\\", \\\"{x:1513,y:774,t:1527873421356};\\\", \\\"{x:1513,y:773,t:1527873421373};\\\", \\\"{x:1515,y:770,t:1527873421390};\\\", \\\"{x:1516,y:768,t:1527873421408};\\\", \\\"{x:1517,y:767,t:1527873421423};\\\", \\\"{x:1517,y:766,t:1527873421440};\\\", \\\"{x:1517,y:764,t:1527873421773};\\\", \\\"{x:1517,y:763,t:1527873421790};\\\", \\\"{x:1517,y:762,t:1527873421807};\\\", \\\"{x:1517,y:761,t:1527873421844};\\\", \\\"{x:1517,y:759,t:1527873421860};\\\", \\\"{x:1516,y:759,t:1527873421940};\\\", \\\"{x:1516,y:760,t:1527873422181};\\\", \\\"{x:1516,y:766,t:1527873422190};\\\", \\\"{x:1517,y:784,t:1527873422209};\\\", \\\"{x:1518,y:804,t:1527873422224};\\\", \\\"{x:1520,y:815,t:1527873422241};\\\", \\\"{x:1521,y:824,t:1527873422258};\\\", \\\"{x:1522,y:836,t:1527873422274};\\\", \\\"{x:1527,y:850,t:1527873422290};\\\", \\\"{x:1532,y:863,t:1527873422307};\\\", \\\"{x:1537,y:879,t:1527873422324};\\\", \\\"{x:1542,y:892,t:1527873422341};\\\", \\\"{x:1547,y:904,t:1527873422357};\\\", \\\"{x:1551,y:913,t:1527873422374};\\\", \\\"{x:1553,y:921,t:1527873422390};\\\", \\\"{x:1554,y:925,t:1527873422408};\\\", \\\"{x:1555,y:929,t:1527873422424};\\\", \\\"{x:1556,y:935,t:1527873422440};\\\", \\\"{x:1556,y:939,t:1527873422457};\\\", \\\"{x:1556,y:942,t:1527873422474};\\\", \\\"{x:1556,y:945,t:1527873422492};\\\", \\\"{x:1556,y:946,t:1527873422509};\\\", \\\"{x:1556,y:947,t:1527873422524};\\\", \\\"{x:1555,y:950,t:1527873422540};\\\", \\\"{x:1555,y:952,t:1527873422557};\\\", \\\"{x:1553,y:957,t:1527873422575};\\\", \\\"{x:1553,y:959,t:1527873422591};\\\", \\\"{x:1552,y:960,t:1527873422608};\\\", \\\"{x:1550,y:964,t:1527873422625};\\\", \\\"{x:1550,y:967,t:1527873422642};\\\", \\\"{x:1550,y:970,t:1527873422657};\\\", \\\"{x:1549,y:971,t:1527873422674};\\\", \\\"{x:1549,y:974,t:1527873422692};\\\", \\\"{x:1549,y:976,t:1527873422724};\\\", \\\"{x:1548,y:976,t:1527873423085};\\\", \\\"{x:1548,y:974,t:1527873423100};\\\", \\\"{x:1548,y:973,t:1527873423108};\\\", \\\"{x:1548,y:971,t:1527873423124};\\\", \\\"{x:1546,y:969,t:1527873423141};\\\", \\\"{x:1546,y:968,t:1527873423159};\\\", \\\"{x:1546,y:967,t:1527873423277};\\\", \\\"{x:1545,y:967,t:1527873423324};\\\", \\\"{x:1545,y:965,t:1527873423349};\\\", \\\"{x:1545,y:964,t:1527873423477};\\\", \\\"{x:1544,y:964,t:1527873423492};\\\", \\\"{x:1543,y:964,t:1527873423508};\\\", \\\"{x:1542,y:964,t:1527873423532};\\\", \\\"{x:1541,y:964,t:1527873423844};\\\", \\\"{x:1541,y:962,t:1527873423917};\\\", \\\"{x:1541,y:961,t:1527873423932};\\\", \\\"{x:1541,y:959,t:1527873423942};\\\", \\\"{x:1541,y:957,t:1527873423958};\\\", \\\"{x:1543,y:954,t:1527873423976};\\\", \\\"{x:1543,y:951,t:1527873423993};\\\", \\\"{x:1543,y:950,t:1527873424009};\\\", \\\"{x:1543,y:949,t:1527873424025};\\\", \\\"{x:1544,y:948,t:1527873424044};\\\", \\\"{x:1545,y:947,t:1527873424092};\\\", \\\"{x:1545,y:946,t:1527873424108};\\\", \\\"{x:1545,y:944,t:1527873424125};\\\", \\\"{x:1545,y:942,t:1527873424143};\\\", \\\"{x:1546,y:937,t:1527873424159};\\\", \\\"{x:1546,y:936,t:1527873424175};\\\", \\\"{x:1546,y:934,t:1527873424192};\\\", \\\"{x:1547,y:933,t:1527873424213};\\\", \\\"{x:1547,y:932,t:1527873424226};\\\", \\\"{x:1547,y:931,t:1527873424245};\\\", \\\"{x:1547,y:930,t:1527873424259};\\\", \\\"{x:1547,y:932,t:1527873424349};\\\", \\\"{x:1544,y:935,t:1527873424359};\\\", \\\"{x:1541,y:942,t:1527873424375};\\\", \\\"{x:1537,y:950,t:1527873424393};\\\", \\\"{x:1536,y:953,t:1527873424409};\\\", \\\"{x:1535,y:954,t:1527873424425};\\\", \\\"{x:1535,y:956,t:1527873424444};\\\", \\\"{x:1534,y:956,t:1527873424467};\\\", \\\"{x:1533,y:957,t:1527873424491};\\\", \\\"{x:1532,y:959,t:1527873424508};\\\", \\\"{x:1529,y:963,t:1527873424525};\\\", \\\"{x:1528,y:964,t:1527873424547};\\\", \\\"{x:1527,y:965,t:1527873424559};\\\", \\\"{x:1526,y:966,t:1527873424574};\\\", \\\"{x:1523,y:968,t:1527873424592};\\\", \\\"{x:1522,y:968,t:1527873424609};\\\", \\\"{x:1521,y:969,t:1527873424644};\\\", \\\"{x:1520,y:969,t:1527873424668};\\\", \\\"{x:1518,y:970,t:1527873424676};\\\", \\\"{x:1517,y:970,t:1527873424700};\\\", \\\"{x:1516,y:970,t:1527873424932};\\\", \\\"{x:1515,y:970,t:1527873424980};\\\", \\\"{x:1514,y:970,t:1527873424992};\\\", \\\"{x:1514,y:969,t:1527873425052};\\\", \\\"{x:1513,y:968,t:1527873425060};\\\", \\\"{x:1513,y:967,t:1527873425092};\\\", \\\"{x:1513,y:966,t:1527873425124};\\\", \\\"{x:1512,y:966,t:1527873425149};\\\", \\\"{x:1512,y:965,t:1527873425364};\\\", \\\"{x:1510,y:964,t:1527873425377};\\\", \\\"{x:1503,y:964,t:1527873425394};\\\", \\\"{x:1494,y:963,t:1527873425410};\\\", \\\"{x:1487,y:963,t:1527873425426};\\\", \\\"{x:1484,y:962,t:1527873425445};\\\", \\\"{x:1483,y:962,t:1527873425532};\\\", \\\"{x:1483,y:963,t:1527873425773};\\\", \\\"{x:1483,y:966,t:1527873425781};\\\", \\\"{x:1483,y:967,t:1527873425793};\\\", \\\"{x:1482,y:967,t:1527873425810};\\\", \\\"{x:1482,y:968,t:1527873425826};\\\", \\\"{x:1481,y:968,t:1527873426605};\\\", \\\"{x:1480,y:968,t:1527873426661};\\\", \\\"{x:1479,y:967,t:1527873428085};\\\", \\\"{x:1476,y:967,t:1527873428096};\\\", \\\"{x:1467,y:965,t:1527873428111};\\\", \\\"{x:1458,y:963,t:1527873428129};\\\", \\\"{x:1450,y:962,t:1527873428146};\\\", \\\"{x:1447,y:962,t:1527873428162};\\\", \\\"{x:1444,y:962,t:1527873428178};\\\", \\\"{x:1443,y:962,t:1527873428357};\\\", \\\"{x:1440,y:962,t:1527873428869};\\\", \\\"{x:1439,y:962,t:1527873428884};\\\", \\\"{x:1438,y:962,t:1527873428900};\\\", \\\"{x:1439,y:962,t:1527873429260};\\\", \\\"{x:1441,y:963,t:1527873429269};\\\", \\\"{x:1442,y:963,t:1527873429284};\\\", \\\"{x:1443,y:963,t:1527873429297};\\\", \\\"{x:1444,y:964,t:1527873429312};\\\", \\\"{x:1446,y:964,t:1527873429329};\\\", \\\"{x:1447,y:965,t:1527873429347};\\\", \\\"{x:1446,y:965,t:1527873429629};\\\", \\\"{x:1446,y:964,t:1527873429709};\\\", \\\"{x:1448,y:963,t:1527873429717};\\\", \\\"{x:1451,y:962,t:1527873429730};\\\", \\\"{x:1455,y:960,t:1527873429747};\\\", \\\"{x:1458,y:959,t:1527873429763};\\\", \\\"{x:1460,y:959,t:1527873429779};\\\", \\\"{x:1461,y:959,t:1527873429963};\\\", \\\"{x:1463,y:960,t:1527873429980};\\\", \\\"{x:1464,y:961,t:1527873429996};\\\", \\\"{x:1464,y:962,t:1527873430013};\\\", \\\"{x:1464,y:963,t:1527873430030};\\\", \\\"{x:1464,y:964,t:1527873430046};\\\", \\\"{x:1464,y:965,t:1527873430064};\\\", \\\"{x:1464,y:966,t:1527873430260};\\\", \\\"{x:1463,y:966,t:1527873430300};\\\", \\\"{x:1462,y:966,t:1527873430313};\\\", \\\"{x:1461,y:966,t:1527873430330};\\\", \\\"{x:1460,y:966,t:1527873430347};\\\", \\\"{x:1459,y:966,t:1527873430363};\\\", \\\"{x:1458,y:965,t:1527873430380};\\\", \\\"{x:1457,y:964,t:1527873430403};\\\", \\\"{x:1456,y:964,t:1527873430427};\\\", \\\"{x:1455,y:964,t:1527873430435};\\\", \\\"{x:1454,y:964,t:1527873430467};\\\", \\\"{x:1453,y:964,t:1527873430484};\\\", \\\"{x:1452,y:963,t:1527873430499};\\\", \\\"{x:1451,y:963,t:1527873430523};\\\", \\\"{x:1450,y:963,t:1527873430571};\\\", \\\"{x:1449,y:963,t:1527873431013};\\\", \\\"{x:1449,y:962,t:1527873432213};\\\", \\\"{x:1447,y:962,t:1527873432980};\\\", \\\"{x:1444,y:962,t:1527873432988};\\\", \\\"{x:1442,y:962,t:1527873432999};\\\", \\\"{x:1437,y:962,t:1527873433015};\\\", \\\"{x:1435,y:963,t:1527873433033};\\\", \\\"{x:1433,y:963,t:1527873433221};\\\", \\\"{x:1431,y:964,t:1527873433232};\\\", \\\"{x:1429,y:965,t:1527873433250};\\\", \\\"{x:1426,y:967,t:1527873433266};\\\", \\\"{x:1424,y:968,t:1527873433292};\\\", \\\"{x:1423,y:969,t:1527873433333};\\\", \\\"{x:1422,y:969,t:1527873433356};\\\", \\\"{x:1421,y:969,t:1527873433388};\\\", \\\"{x:1420,y:970,t:1527873433400};\\\", \\\"{x:1419,y:970,t:1527873433416};\\\", \\\"{x:1418,y:971,t:1527873433432};\\\", \\\"{x:1417,y:971,t:1527873433483};\\\", \\\"{x:1416,y:971,t:1527873433508};\\\", \\\"{x:1415,y:971,t:1527873433523};\\\", \\\"{x:1414,y:971,t:1527873433555};\\\", \\\"{x:1413,y:971,t:1527873433565};\\\", \\\"{x:1412,y:971,t:1527873433582};\\\", \\\"{x:1410,y:970,t:1527873435571};\\\", \\\"{x:1406,y:970,t:1527873435585};\\\", \\\"{x:1395,y:970,t:1527873435600};\\\", \\\"{x:1382,y:970,t:1527873435617};\\\", \\\"{x:1371,y:970,t:1527873435634};\\\", \\\"{x:1364,y:970,t:1527873435651};\\\", \\\"{x:1356,y:970,t:1527873435668};\\\", \\\"{x:1353,y:970,t:1527873435684};\\\", \\\"{x:1351,y:970,t:1527873435701};\\\", \\\"{x:1350,y:970,t:1527873435718};\\\", \\\"{x:1351,y:969,t:1527873435876};\\\", \\\"{x:1355,y:969,t:1527873435884};\\\", \\\"{x:1365,y:969,t:1527873435901};\\\", \\\"{x:1371,y:969,t:1527873435919};\\\", \\\"{x:1375,y:969,t:1527873435935};\\\", \\\"{x:1376,y:969,t:1527873435952};\\\", \\\"{x:1377,y:969,t:1527873435968};\\\", \\\"{x:1378,y:969,t:1527873436269};\\\", \\\"{x:1380,y:969,t:1527873436285};\\\", \\\"{x:1381,y:968,t:1527873436302};\\\", \\\"{x:1381,y:967,t:1527873437468};\\\", \\\"{x:1381,y:966,t:1527873437486};\\\", \\\"{x:1381,y:965,t:1527873437508};\\\", \\\"{x:1381,y:964,t:1527873437524};\\\", \\\"{x:1381,y:963,t:1527873437757};\\\", \\\"{x:1384,y:963,t:1527873438140};\\\", \\\"{x:1386,y:963,t:1527873438155};\\\", \\\"{x:1387,y:963,t:1527873438169};\\\", \\\"{x:1390,y:964,t:1527873438186};\\\", \\\"{x:1391,y:964,t:1527873438203};\\\", \\\"{x:1392,y:965,t:1527873438220};\\\", \\\"{x:1393,y:965,t:1527873438275};\\\", \\\"{x:1394,y:965,t:1527873438340};\\\", \\\"{x:1394,y:966,t:1527873438353};\\\", \\\"{x:1396,y:966,t:1527873438372};\\\", \\\"{x:1397,y:966,t:1527873438509};\\\", \\\"{x:1397,y:965,t:1527873438532};\\\", \\\"{x:1395,y:965,t:1527873438540};\\\", \\\"{x:1394,y:965,t:1527873438554};\\\", \\\"{x:1391,y:963,t:1527873438571};\\\", \\\"{x:1390,y:963,t:1527873438587};\\\", \\\"{x:1388,y:962,t:1527873438749};\\\", \\\"{x:1387,y:962,t:1527873438764};\\\", \\\"{x:1385,y:962,t:1527873438788};\\\", \\\"{x:1384,y:962,t:1527873438829};\\\", \\\"{x:1382,y:961,t:1527873439884};\\\", \\\"{x:1381,y:961,t:1527873439916};\\\", \\\"{x:1380,y:961,t:1527873439940};\\\", \\\"{x:1379,y:960,t:1527873441181};\\\", \\\"{x:1377,y:960,t:1527873441189};\\\", \\\"{x:1371,y:960,t:1527873441206};\\\", \\\"{x:1368,y:960,t:1527873441222};\\\", \\\"{x:1366,y:960,t:1527873441239};\\\", \\\"{x:1365,y:960,t:1527873441256};\\\", \\\"{x:1364,y:960,t:1527873441272};\\\", \\\"{x:1363,y:960,t:1527873441289};\\\", \\\"{x:1362,y:960,t:1527873441461};\\\", \\\"{x:1361,y:961,t:1527873441472};\\\", \\\"{x:1360,y:961,t:1527873441489};\\\", \\\"{x:1359,y:961,t:1527873441506};\\\", \\\"{x:1358,y:961,t:1527873441556};\\\", \\\"{x:1357,y:961,t:1527873441644};\\\", \\\"{x:1355,y:961,t:1527873441657};\\\", \\\"{x:1354,y:961,t:1527873441673};\\\", \\\"{x:1352,y:962,t:1527873441689};\\\", \\\"{x:1350,y:963,t:1527873442205};\\\", \\\"{x:1349,y:964,t:1527873442223};\\\", \\\"{x:1347,y:965,t:1527873442241};\\\", \\\"{x:1344,y:966,t:1527873442260};\\\", \\\"{x:1341,y:966,t:1527873446284};\\\", \\\"{x:1333,y:964,t:1527873446293};\\\", \\\"{x:1306,y:956,t:1527873446309};\\\", \\\"{x:1277,y:946,t:1527873446326};\\\", \\\"{x:1248,y:935,t:1527873446343};\\\", \\\"{x:1210,y:921,t:1527873446359};\\\", \\\"{x:1173,y:905,t:1527873446376};\\\", \\\"{x:1136,y:885,t:1527873446393};\\\", \\\"{x:1097,y:859,t:1527873446411};\\\", \\\"{x:1062,y:833,t:1527873446427};\\\", \\\"{x:1006,y:796,t:1527873446444};\\\", \\\"{x:983,y:780,t:1527873446460};\\\", \\\"{x:956,y:761,t:1527873446476};\\\", \\\"{x:929,y:745,t:1527873446493};\\\", \\\"{x:900,y:730,t:1527873446510};\\\", \\\"{x:869,y:713,t:1527873446526};\\\", \\\"{x:835,y:696,t:1527873446543};\\\", \\\"{x:795,y:675,t:1527873446560};\\\", \\\"{x:747,y:653,t:1527873446577};\\\", \\\"{x:700,y:639,t:1527873446593};\\\", \\\"{x:658,y:627,t:1527873446611};\\\", \\\"{x:613,y:616,t:1527873446626};\\\", \\\"{x:575,y:606,t:1527873446643};\\\", \\\"{x:523,y:598,t:1527873446661};\\\", \\\"{x:492,y:594,t:1527873446676};\\\", \\\"{x:455,y:588,t:1527873446693};\\\", \\\"{x:432,y:585,t:1527873446710};\\\", \\\"{x:418,y:583,t:1527873446727};\\\", \\\"{x:405,y:582,t:1527873446744};\\\", \\\"{x:394,y:579,t:1527873446759};\\\", \\\"{x:385,y:577,t:1527873446777};\\\", \\\"{x:377,y:575,t:1527873446793};\\\", \\\"{x:371,y:575,t:1527873446810};\\\", \\\"{x:357,y:574,t:1527873446826};\\\", \\\"{x:322,y:568,t:1527873446843};\\\", \\\"{x:304,y:565,t:1527873446859};\\\", \\\"{x:295,y:562,t:1527873446878};\\\", \\\"{x:292,y:561,t:1527873446894};\\\", \\\"{x:289,y:560,t:1527873446910};\\\", \\\"{x:284,y:559,t:1527873446927};\\\", \\\"{x:274,y:559,t:1527873446943};\\\", \\\"{x:269,y:559,t:1527873446960};\\\", \\\"{x:265,y:557,t:1527873446977};\\\", \\\"{x:259,y:556,t:1527873446993};\\\", \\\"{x:250,y:554,t:1527873447011};\\\", \\\"{x:227,y:551,t:1527873447027};\\\", \\\"{x:215,y:551,t:1527873447043};\\\", \\\"{x:206,y:550,t:1527873447061};\\\", \\\"{x:197,y:547,t:1527873447077};\\\", \\\"{x:190,y:546,t:1527873447095};\\\", \\\"{x:180,y:546,t:1527873447111};\\\", \\\"{x:168,y:547,t:1527873447127};\\\", \\\"{x:162,y:548,t:1527873447144};\\\", \\\"{x:160,y:548,t:1527873447160};\\\", \\\"{x:159,y:545,t:1527873448788};\\\", \\\"{x:160,y:543,t:1527873448795};\\\", \\\"{x:164,y:539,t:1527873448812};\\\", \\\"{x:169,y:535,t:1527873448828};\\\", \\\"{x:173,y:532,t:1527873448845};\\\", \\\"{x:178,y:529,t:1527873448862};\\\", \\\"{x:184,y:526,t:1527873448879};\\\", \\\"{x:193,y:522,t:1527873448895};\\\", \\\"{x:207,y:518,t:1527873448911};\\\", \\\"{x:225,y:515,t:1527873448928};\\\", \\\"{x:251,y:514,t:1527873448945};\\\", \\\"{x:274,y:514,t:1527873448963};\\\", \\\"{x:294,y:514,t:1527873448978};\\\", \\\"{x:304,y:516,t:1527873448995};\\\", \\\"{x:306,y:516,t:1527873449012};\\\", \\\"{x:309,y:519,t:1527873449030};\\\", \\\"{x:310,y:520,t:1527873449045};\\\", \\\"{x:311,y:520,t:1527873449124};\\\", \\\"{x:311,y:521,t:1527873449155};\\\", \\\"{x:311,y:522,t:1527873449164};\\\", \\\"{x:312,y:526,t:1527873449180};\\\", \\\"{x:313,y:526,t:1527873449195};\\\", \\\"{x:313,y:529,t:1527873449211};\\\", \\\"{x:314,y:531,t:1527873449229};\\\", \\\"{x:314,y:532,t:1527873449245};\\\", \\\"{x:315,y:534,t:1527873449262};\\\", \\\"{x:315,y:537,t:1527873449279};\\\", \\\"{x:316,y:539,t:1527873449295};\\\", \\\"{x:317,y:542,t:1527873449312};\\\", \\\"{x:318,y:546,t:1527873449329};\\\", \\\"{x:320,y:549,t:1527873449345};\\\", \\\"{x:320,y:552,t:1527873449362};\\\", \\\"{x:321,y:555,t:1527873449379};\\\", \\\"{x:322,y:560,t:1527873449397};\\\", \\\"{x:323,y:562,t:1527873449411};\\\", \\\"{x:324,y:564,t:1527873449429};\\\", \\\"{x:325,y:565,t:1527873449445};\\\", \\\"{x:325,y:566,t:1527873449462};\\\", \\\"{x:325,y:567,t:1527873449479};\\\", \\\"{x:325,y:568,t:1527873449496};\\\", \\\"{x:327,y:567,t:1527873449732};\\\", \\\"{x:327,y:565,t:1527873449747};\\\", \\\"{x:330,y:558,t:1527873449763};\\\", \\\"{x:335,y:542,t:1527873449780};\\\", \\\"{x:337,y:532,t:1527873449795};\\\", \\\"{x:341,y:522,t:1527873449813};\\\", \\\"{x:342,y:514,t:1527873449829};\\\", \\\"{x:342,y:512,t:1527873449846};\\\", \\\"{x:344,y:508,t:1527873449899};\\\", \\\"{x:346,y:506,t:1527873449913};\\\", \\\"{x:350,y:499,t:1527873449930};\\\", \\\"{x:353,y:491,t:1527873449946};\\\", \\\"{x:353,y:478,t:1527873449964};\\\", \\\"{x:353,y:472,t:1527873449979};\\\", \\\"{x:353,y:468,t:1527873449995};\\\", \\\"{x:354,y:468,t:1527873450059};\\\", \\\"{x:359,y:472,t:1527873450067};\\\", \\\"{x:364,y:476,t:1527873450078};\\\", \\\"{x:367,y:479,t:1527873450095};\\\", \\\"{x:368,y:482,t:1527873450112};\\\", \\\"{x:368,y:486,t:1527873450128};\\\", \\\"{x:370,y:492,t:1527873450146};\\\", \\\"{x:372,y:498,t:1527873450160};\\\", \\\"{x:375,y:501,t:1527873450179};\\\", \\\"{x:375,y:502,t:1527873450203};\\\", \\\"{x:375,y:504,t:1527873450972};\\\", \\\"{x:375,y:507,t:1527873450980};\\\", \\\"{x:375,y:511,t:1527873450998};\\\", \\\"{x:375,y:517,t:1527873451013};\\\", \\\"{x:375,y:522,t:1527873451032};\\\", \\\"{x:375,y:529,t:1527873451047};\\\", \\\"{x:379,y:535,t:1527873451063};\\\", \\\"{x:386,y:541,t:1527873451079};\\\", \\\"{x:403,y:554,t:1527873451097};\\\", \\\"{x:442,y:579,t:1527873451113};\\\", \\\"{x:497,y:613,t:1527873451131};\\\", \\\"{x:572,y:655,t:1527873451147};\\\", \\\"{x:599,y:671,t:1527873451163};\\\", \\\"{x:621,y:688,t:1527873451180};\\\", \\\"{x:637,y:700,t:1527873451197};\\\", \\\"{x:639,y:704,t:1527873451214};\\\", \\\"{x:639,y:705,t:1527873451230};\\\", \\\"{x:639,y:710,t:1527873451247};\\\", \\\"{x:639,y:712,t:1527873451264};\\\", \\\"{x:637,y:716,t:1527873451280};\\\", \\\"{x:635,y:719,t:1527873451297};\\\", \\\"{x:633,y:723,t:1527873451314};\\\", \\\"{x:633,y:730,t:1527873451330};\\\", \\\"{x:633,y:731,t:1527873451348};\\\", \\\"{x:632,y:731,t:1527873451363};\\\", \\\"{x:625,y:729,t:1527873451380};\\\", \\\"{x:612,y:724,t:1527873451398};\\\", \\\"{x:603,y:722,t:1527873451414};\\\", \\\"{x:597,y:720,t:1527873451430};\\\", \\\"{x:592,y:719,t:1527873451447};\\\", \\\"{x:588,y:719,t:1527873451464};\\\", \\\"{x:577,y:719,t:1527873451480};\\\", \\\"{x:564,y:719,t:1527873451497};\\\", \\\"{x:555,y:719,t:1527873451514};\\\", \\\"{x:547,y:719,t:1527873451530};\\\", \\\"{x:545,y:719,t:1527873451547};\\\", \\\"{x:544,y:719,t:1527873451796};\\\", \\\"{x:544,y:720,t:1527873451816};\\\", \\\"{x:545,y:723,t:1527873451831};\\\", \\\"{x:546,y:724,t:1527873451847};\\\", \\\"{x:547,y:724,t:1527873452620};\\\", \\\"{x:548,y:724,t:1527873452631};\\\", \\\"{x:551,y:721,t:1527873452648};\\\", \\\"{x:552,y:716,t:1527873452665};\\\", \\\"{x:556,y:712,t:1527873452681};\\\", \\\"{x:557,y:709,t:1527873452698};\\\", \\\"{x:558,y:708,t:1527873452715};\\\", \\\"{x:559,y:707,t:1527873452731};\\\", \\\"{x:559,y:706,t:1527873452748};\\\" ] }, { \\\"rt\\\": 49387, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 692707, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"QGUGU\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XFull-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-M -M -C -G -M -M -B -B -F -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:559,y:705,t:1527873453835};\\\", \\\"{x:555,y:698,t:1527873453849};\\\", \\\"{x:547,y:681,t:1527873453866};\\\", \\\"{x:538,y:657,t:1527873453881};\\\", \\\"{x:521,y:626,t:1527873453899};\\\", \\\"{x:511,y:610,t:1527873453916};\\\", \\\"{x:505,y:598,t:1527873453932};\\\", \\\"{x:499,y:587,t:1527873453949};\\\", \\\"{x:492,y:575,t:1527873453965};\\\", \\\"{x:488,y:562,t:1527873453982};\\\", \\\"{x:486,y:551,t:1527873453999};\\\", \\\"{x:481,y:541,t:1527873454016};\\\", \\\"{x:478,y:533,t:1527873454033};\\\", \\\"{x:477,y:531,t:1527873454049};\\\", \\\"{x:476,y:529,t:1527873454066};\\\", \\\"{x:475,y:528,t:1527873454082};\\\", \\\"{x:475,y:526,t:1527873454452};\\\", \\\"{x:475,y:521,t:1527873454465};\\\", \\\"{x:477,y:507,t:1527873454482};\\\", \\\"{x:485,y:487,t:1527873454500};\\\", \\\"{x:494,y:474,t:1527873454516};\\\", \\\"{x:503,y:463,t:1527873454532};\\\", \\\"{x:508,y:454,t:1527873454550};\\\", \\\"{x:513,y:448,t:1527873454566};\\\", \\\"{x:516,y:444,t:1527873454583};\\\", \\\"{x:519,y:439,t:1527873454600};\\\", \\\"{x:520,y:436,t:1527873454616};\\\", \\\"{x:520,y:435,t:1527873454633};\\\", \\\"{x:521,y:435,t:1527873455260};\\\", \\\"{x:521,y:437,t:1527873455268};\\\", \\\"{x:521,y:440,t:1527873455284};\\\", \\\"{x:520,y:442,t:1527873455302};\\\", \\\"{x:520,y:444,t:1527873455317};\\\", \\\"{x:520,y:445,t:1527873455333};\\\", \\\"{x:523,y:447,t:1527873455684};\\\", \\\"{x:559,y:452,t:1527873455702};\\\", \\\"{x:606,y:458,t:1527873455717};\\\", \\\"{x:666,y:463,t:1527873455734};\\\", \\\"{x:750,y:467,t:1527873455751};\\\", \\\"{x:835,y:470,t:1527873455768};\\\", \\\"{x:914,y:478,t:1527873455784};\\\", \\\"{x:987,y:479,t:1527873455801};\\\", \\\"{x:1065,y:479,t:1527873455817};\\\", \\\"{x:1118,y:479,t:1527873455833};\\\", \\\"{x:1161,y:479,t:1527873455850};\\\", \\\"{x:1197,y:479,t:1527873455868};\\\", \\\"{x:1211,y:479,t:1527873455884};\\\", \\\"{x:1221,y:478,t:1527873455903};\\\", \\\"{x:1226,y:478,t:1527873455918};\\\", \\\"{x:1228,y:478,t:1527873455934};\\\", \\\"{x:1236,y:478,t:1527873456325};\\\", \\\"{x:1248,y:481,t:1527873456335};\\\", \\\"{x:1293,y:499,t:1527873456351};\\\", \\\"{x:1349,y:517,t:1527873456368};\\\", \\\"{x:1411,y:536,t:1527873456385};\\\", \\\"{x:1484,y:562,t:1527873456401};\\\", \\\"{x:1532,y:586,t:1527873456418};\\\", \\\"{x:1553,y:599,t:1527873456435};\\\", \\\"{x:1574,y:626,t:1527873456452};\\\", \\\"{x:1586,y:653,t:1527873456467};\\\", \\\"{x:1592,y:676,t:1527873456485};\\\", \\\"{x:1595,y:696,t:1527873456503};\\\", \\\"{x:1595,y:714,t:1527873456519};\\\", \\\"{x:1595,y:736,t:1527873456535};\\\", \\\"{x:1595,y:759,t:1527873456552};\\\", \\\"{x:1589,y:779,t:1527873456568};\\\", \\\"{x:1583,y:795,t:1527873456585};\\\", \\\"{x:1574,y:815,t:1527873456602};\\\", \\\"{x:1562,y:834,t:1527873456618};\\\", \\\"{x:1549,y:848,t:1527873456635};\\\", \\\"{x:1530,y:861,t:1527873456652};\\\", \\\"{x:1517,y:867,t:1527873456668};\\\", \\\"{x:1503,y:873,t:1527873456685};\\\", \\\"{x:1490,y:877,t:1527873456703};\\\", \\\"{x:1482,y:877,t:1527873456718};\\\", \\\"{x:1475,y:878,t:1527873456735};\\\", \\\"{x:1474,y:880,t:1527873456752};\\\", \\\"{x:1473,y:880,t:1527873456772};\\\", \\\"{x:1472,y:880,t:1527873456924};\\\", \\\"{x:1470,y:880,t:1527873456935};\\\", \\\"{x:1457,y:882,t:1527873456952};\\\", \\\"{x:1438,y:890,t:1527873456969};\\\", \\\"{x:1400,y:901,t:1527873456985};\\\", \\\"{x:1363,y:913,t:1527873457002};\\\", \\\"{x:1326,y:918,t:1527873457019};\\\", \\\"{x:1303,y:924,t:1527873457035};\\\", \\\"{x:1283,y:926,t:1527873457052};\\\", \\\"{x:1285,y:926,t:1527873457212};\\\", \\\"{x:1291,y:924,t:1527873457220};\\\", \\\"{x:1299,y:921,t:1527873457235};\\\", \\\"{x:1327,y:911,t:1527873457252};\\\", \\\"{x:1353,y:904,t:1527873457268};\\\", \\\"{x:1369,y:900,t:1527873457285};\\\", \\\"{x:1381,y:897,t:1527873457305};\\\", \\\"{x:1391,y:896,t:1527873457318};\\\", \\\"{x:1393,y:896,t:1527873457334};\\\", \\\"{x:1394,y:896,t:1527873457436};\\\", \\\"{x:1395,y:896,t:1527873457451};\\\", \\\"{x:1398,y:897,t:1527873457469};\\\", \\\"{x:1402,y:904,t:1527873457484};\\\", \\\"{x:1403,y:910,t:1527873457501};\\\", \\\"{x:1405,y:916,t:1527873457518};\\\", \\\"{x:1406,y:921,t:1527873457535};\\\", \\\"{x:1406,y:927,t:1527873457552};\\\", \\\"{x:1406,y:933,t:1527873457568};\\\", \\\"{x:1406,y:936,t:1527873457586};\\\", \\\"{x:1406,y:939,t:1527873457602};\\\", \\\"{x:1406,y:943,t:1527873457618};\\\", \\\"{x:1406,y:948,t:1527873457635};\\\", \\\"{x:1406,y:949,t:1527873457652};\\\", \\\"{x:1406,y:951,t:1527873457676};\\\", \\\"{x:1406,y:952,t:1527873457708};\\\", \\\"{x:1405,y:953,t:1527873457719};\\\", \\\"{x:1405,y:954,t:1527873457736};\\\", \\\"{x:1404,y:954,t:1527873458004};\\\", \\\"{x:1403,y:951,t:1527873458019};\\\", \\\"{x:1401,y:947,t:1527873458036};\\\", \\\"{x:1399,y:944,t:1527873458052};\\\", \\\"{x:1397,y:941,t:1527873458069};\\\", \\\"{x:1394,y:938,t:1527873458086};\\\", \\\"{x:1394,y:936,t:1527873458103};\\\", \\\"{x:1392,y:934,t:1527873458118};\\\", \\\"{x:1390,y:930,t:1527873458135};\\\", \\\"{x:1387,y:927,t:1527873458152};\\\", \\\"{x:1384,y:924,t:1527873458168};\\\", \\\"{x:1382,y:922,t:1527873458186};\\\", \\\"{x:1381,y:921,t:1527873458203};\\\", \\\"{x:1380,y:920,t:1527873458219};\\\", \\\"{x:1377,y:917,t:1527873458236};\\\", \\\"{x:1374,y:914,t:1527873458253};\\\", \\\"{x:1373,y:912,t:1527873458269};\\\", \\\"{x:1371,y:910,t:1527873458286};\\\", \\\"{x:1370,y:910,t:1527873458303};\\\", \\\"{x:1369,y:910,t:1527873458893};\\\", \\\"{x:1368,y:910,t:1527873458907};\\\", \\\"{x:1366,y:910,t:1527873458920};\\\", \\\"{x:1365,y:911,t:1527873458936};\\\", \\\"{x:1364,y:913,t:1527873458953};\\\", \\\"{x:1362,y:916,t:1527873458970};\\\", \\\"{x:1361,y:917,t:1527873458986};\\\", \\\"{x:1361,y:916,t:1527873459244};\\\", \\\"{x:1361,y:914,t:1527873459260};\\\", \\\"{x:1362,y:913,t:1527873459270};\\\", \\\"{x:1364,y:911,t:1527873459287};\\\", \\\"{x:1365,y:908,t:1527873459303};\\\", \\\"{x:1366,y:906,t:1527873459320};\\\", \\\"{x:1367,y:906,t:1527873459337};\\\", \\\"{x:1368,y:904,t:1527873459353};\\\", \\\"{x:1369,y:903,t:1527873459370};\\\", \\\"{x:1370,y:903,t:1527873459387};\\\", \\\"{x:1372,y:901,t:1527873459403};\\\", \\\"{x:1373,y:900,t:1527873459420};\\\", \\\"{x:1374,y:900,t:1527873459612};\\\", \\\"{x:1376,y:900,t:1527873459620};\\\", \\\"{x:1378,y:900,t:1527873459637};\\\", \\\"{x:1382,y:902,t:1527873459653};\\\", \\\"{x:1384,y:906,t:1527873459670};\\\", \\\"{x:1387,y:910,t:1527873459687};\\\", \\\"{x:1389,y:912,t:1527873459704};\\\", \\\"{x:1390,y:914,t:1527873459719};\\\", \\\"{x:1390,y:915,t:1527873459737};\\\", \\\"{x:1390,y:916,t:1527873459756};\\\", \\\"{x:1390,y:915,t:1527873459979};\\\", \\\"{x:1390,y:913,t:1527873459986};\\\", \\\"{x:1390,y:912,t:1527873460003};\\\", \\\"{x:1390,y:910,t:1527873460020};\\\", \\\"{x:1390,y:908,t:1527873460037};\\\", \\\"{x:1390,y:907,t:1527873460054};\\\", \\\"{x:1390,y:906,t:1527873460070};\\\", \\\"{x:1390,y:905,t:1527873460087};\\\", \\\"{x:1390,y:904,t:1527873460104};\\\", \\\"{x:1390,y:903,t:1527873460123};\\\", \\\"{x:1390,y:902,t:1527873460139};\\\", \\\"{x:1390,y:901,t:1527873460163};\\\", \\\"{x:1390,y:900,t:1527873460171};\\\", \\\"{x:1390,y:899,t:1527873460219};\\\", \\\"{x:1390,y:898,t:1527873460243};\\\", \\\"{x:1390,y:897,t:1527873460259};\\\", \\\"{x:1391,y:896,t:1527873465132};\\\", \\\"{x:1399,y:896,t:1527873465140};\\\", \\\"{x:1446,y:889,t:1527873465158};\\\", \\\"{x:1488,y:883,t:1527873465174};\\\", \\\"{x:1505,y:881,t:1527873465191};\\\", \\\"{x:1511,y:881,t:1527873465207};\\\", \\\"{x:1516,y:881,t:1527873465224};\\\", \\\"{x:1517,y:882,t:1527873465240};\\\", \\\"{x:1519,y:883,t:1527873465258};\\\", \\\"{x:1521,y:883,t:1527873465274};\\\", \\\"{x:1522,y:884,t:1527873465291};\\\", \\\"{x:1522,y:885,t:1527873465308};\\\", \\\"{x:1522,y:886,t:1527873465323};\\\", \\\"{x:1520,y:889,t:1527873465340};\\\", \\\"{x:1511,y:903,t:1527873465357};\\\", \\\"{x:1493,y:928,t:1527873465374};\\\", \\\"{x:1466,y:961,t:1527873465392};\\\", \\\"{x:1447,y:983,t:1527873465407};\\\", \\\"{x:1437,y:990,t:1527873465424};\\\", \\\"{x:1431,y:994,t:1527873465442};\\\", \\\"{x:1428,y:997,t:1527873465458};\\\", \\\"{x:1427,y:998,t:1527873465492};\\\", \\\"{x:1428,y:993,t:1527873465596};\\\", \\\"{x:1430,y:986,t:1527873465607};\\\", \\\"{x:1437,y:963,t:1527873465624};\\\", \\\"{x:1442,y:942,t:1527873465641};\\\", \\\"{x:1445,y:927,t:1527873465658};\\\", \\\"{x:1445,y:921,t:1527873465674};\\\", \\\"{x:1447,y:918,t:1527873465691};\\\", \\\"{x:1446,y:918,t:1527873465707};\\\", \\\"{x:1444,y:917,t:1527873465724};\\\", \\\"{x:1443,y:915,t:1527873466068};\\\", \\\"{x:1443,y:912,t:1527873466076};\\\", \\\"{x:1443,y:911,t:1527873466091};\\\", \\\"{x:1444,y:907,t:1527873466109};\\\", \\\"{x:1444,y:904,t:1527873466125};\\\", \\\"{x:1445,y:904,t:1527873466142};\\\", \\\"{x:1445,y:902,t:1527873466164};\\\", \\\"{x:1446,y:901,t:1527873466180};\\\", \\\"{x:1446,y:899,t:1527873466845};\\\", \\\"{x:1443,y:891,t:1527873466859};\\\", \\\"{x:1437,y:868,t:1527873466875};\\\", \\\"{x:1436,y:850,t:1527873466892};\\\", \\\"{x:1435,y:829,t:1527873466909};\\\", \\\"{x:1435,y:807,t:1527873466926};\\\", \\\"{x:1435,y:782,t:1527873466942};\\\", \\\"{x:1435,y:757,t:1527873466959};\\\", \\\"{x:1439,y:728,t:1527873466976};\\\", \\\"{x:1443,y:697,t:1527873466993};\\\", \\\"{x:1452,y:666,t:1527873467008};\\\", \\\"{x:1456,y:651,t:1527873467026};\\\", \\\"{x:1456,y:645,t:1527873467043};\\\", \\\"{x:1456,y:642,t:1527873467059};\\\", \\\"{x:1456,y:636,t:1527873467076};\\\", \\\"{x:1456,y:634,t:1527873467092};\\\", \\\"{x:1454,y:632,t:1527873467107};\\\", \\\"{x:1454,y:631,t:1527873467147};\\\", \\\"{x:1453,y:630,t:1527873467309};\\\", \\\"{x:1452,y:630,t:1527873467343};\\\", \\\"{x:1452,y:629,t:1527873467358};\\\", \\\"{x:1451,y:629,t:1527873467376};\\\", \\\"{x:1450,y:630,t:1527873467612};\\\", \\\"{x:1450,y:632,t:1527873467625};\\\", \\\"{x:1450,y:638,t:1527873467644};\\\", \\\"{x:1450,y:648,t:1527873467659};\\\", \\\"{x:1450,y:655,t:1527873467676};\\\", \\\"{x:1450,y:662,t:1527873467692};\\\", \\\"{x:1450,y:669,t:1527873467709};\\\", \\\"{x:1450,y:673,t:1527873467724};\\\", \\\"{x:1450,y:677,t:1527873467741};\\\", \\\"{x:1450,y:682,t:1527873467759};\\\", \\\"{x:1450,y:684,t:1527873467774};\\\", \\\"{x:1450,y:690,t:1527873467792};\\\", \\\"{x:1450,y:698,t:1527873467809};\\\", \\\"{x:1450,y:712,t:1527873467825};\\\", \\\"{x:1450,y:724,t:1527873467842};\\\", \\\"{x:1454,y:749,t:1527873467859};\\\", \\\"{x:1454,y:758,t:1527873467875};\\\", \\\"{x:1454,y:771,t:1527873467892};\\\", \\\"{x:1455,y:789,t:1527873467909};\\\", \\\"{x:1460,y:814,t:1527873467925};\\\", \\\"{x:1462,y:835,t:1527873467942};\\\", \\\"{x:1463,y:851,t:1527873467959};\\\", \\\"{x:1465,y:864,t:1527873467975};\\\", \\\"{x:1465,y:877,t:1527873467991};\\\", \\\"{x:1465,y:886,t:1527873468009};\\\", \\\"{x:1465,y:899,t:1527873468025};\\\", \\\"{x:1465,y:909,t:1527873468042};\\\", \\\"{x:1465,y:916,t:1527873468059};\\\", \\\"{x:1465,y:919,t:1527873468076};\\\", \\\"{x:1465,y:922,t:1527873468093};\\\", \\\"{x:1465,y:926,t:1527873468109};\\\", \\\"{x:1465,y:931,t:1527873468127};\\\", \\\"{x:1465,y:935,t:1527873468142};\\\", \\\"{x:1465,y:941,t:1527873468160};\\\", \\\"{x:1465,y:943,t:1527873468176};\\\", \\\"{x:1465,y:944,t:1527873468192};\\\", \\\"{x:1465,y:946,t:1527873468209};\\\", \\\"{x:1465,y:947,t:1527873468227};\\\", \\\"{x:1465,y:948,t:1527873468242};\\\", \\\"{x:1465,y:953,t:1527873468260};\\\", \\\"{x:1465,y:955,t:1527873468276};\\\", \\\"{x:1465,y:957,t:1527873468293};\\\", \\\"{x:1465,y:958,t:1527873468309};\\\", \\\"{x:1465,y:960,t:1527873468327};\\\", \\\"{x:1464,y:962,t:1527873468348};\\\", \\\"{x:1464,y:963,t:1527873468364};\\\", \\\"{x:1462,y:964,t:1527873468376};\\\", \\\"{x:1461,y:964,t:1527873468396};\\\", \\\"{x:1458,y:964,t:1527873468604};\\\", \\\"{x:1458,y:963,t:1527873468611};\\\", \\\"{x:1457,y:960,t:1527873468627};\\\", \\\"{x:1452,y:946,t:1527873468644};\\\", \\\"{x:1447,y:930,t:1527873468660};\\\", \\\"{x:1438,y:911,t:1527873468676};\\\", \\\"{x:1436,y:901,t:1527873468694};\\\", \\\"{x:1433,y:889,t:1527873468710};\\\", \\\"{x:1428,y:870,t:1527873468727};\\\", \\\"{x:1424,y:847,t:1527873468743};\\\", \\\"{x:1421,y:817,t:1527873468760};\\\", \\\"{x:1417,y:791,t:1527873468777};\\\", \\\"{x:1412,y:766,t:1527873468793};\\\", \\\"{x:1411,y:740,t:1527873468809};\\\", \\\"{x:1410,y:717,t:1527873468826};\\\", \\\"{x:1409,y:696,t:1527873468844};\\\", \\\"{x:1408,y:691,t:1527873468860};\\\", \\\"{x:1408,y:686,t:1527873468876};\\\", \\\"{x:1406,y:672,t:1527873468893};\\\", \\\"{x:1402,y:656,t:1527873468909};\\\", \\\"{x:1401,y:645,t:1527873468926};\\\", \\\"{x:1401,y:638,t:1527873468943};\\\", \\\"{x:1398,y:633,t:1527873468959};\\\", \\\"{x:1398,y:630,t:1527873468977};\\\", \\\"{x:1396,y:625,t:1527873468994};\\\", \\\"{x:1394,y:619,t:1527873469009};\\\", \\\"{x:1394,y:614,t:1527873469027};\\\", \\\"{x:1393,y:607,t:1527873469044};\\\", \\\"{x:1393,y:603,t:1527873469060};\\\", \\\"{x:1392,y:601,t:1527873469077};\\\", \\\"{x:1392,y:598,t:1527873469094};\\\", \\\"{x:1392,y:596,t:1527873469110};\\\", \\\"{x:1392,y:592,t:1527873469127};\\\", \\\"{x:1392,y:587,t:1527873469143};\\\", \\\"{x:1392,y:585,t:1527873469161};\\\", \\\"{x:1392,y:583,t:1527873469177};\\\", \\\"{x:1392,y:581,t:1527873469194};\\\", \\\"{x:1393,y:578,t:1527873469210};\\\", \\\"{x:1393,y:577,t:1527873469227};\\\", \\\"{x:1394,y:576,t:1527873469244};\\\", \\\"{x:1394,y:575,t:1527873469260};\\\", \\\"{x:1397,y:572,t:1527873469276};\\\", \\\"{x:1397,y:571,t:1527873469293};\\\", \\\"{x:1398,y:569,t:1527873469310};\\\", \\\"{x:1400,y:567,t:1527873469327};\\\", \\\"{x:1401,y:566,t:1527873469344};\\\", \\\"{x:1402,y:565,t:1527873469361};\\\", \\\"{x:1403,y:564,t:1527873469377};\\\", \\\"{x:1404,y:563,t:1527873469517};\\\", \\\"{x:1405,y:563,t:1527873469748};\\\", \\\"{x:1406,y:563,t:1527873469764};\\\", \\\"{x:1407,y:563,t:1527873469788};\\\", \\\"{x:1408,y:563,t:1527873469828};\\\", \\\"{x:1409,y:563,t:1527873469844};\\\", \\\"{x:1410,y:563,t:1527873469918};\\\", \\\"{x:1411,y:563,t:1527873469942};\\\", \\\"{x:1412,y:563,t:1527873469958};\\\", \\\"{x:1413,y:563,t:1527873470055};\\\", \\\"{x:1413,y:564,t:1527873470079};\\\", \\\"{x:1414,y:564,t:1527873470104};\\\", \\\"{x:1415,y:564,t:1527873470118};\\\", \\\"{x:1415,y:566,t:1527873470150};\\\", \\\"{x:1415,y:567,t:1527873470166};\\\", \\\"{x:1415,y:569,t:1527873470181};\\\", \\\"{x:1415,y:570,t:1527873470198};\\\", \\\"{x:1415,y:573,t:1527873470213};\\\", \\\"{x:1415,y:577,t:1527873470230};\\\", \\\"{x:1415,y:582,t:1527873470247};\\\", \\\"{x:1415,y:587,t:1527873470264};\\\", \\\"{x:1416,y:591,t:1527873470281};\\\", \\\"{x:1416,y:596,t:1527873470298};\\\", \\\"{x:1416,y:599,t:1527873470314};\\\", \\\"{x:1416,y:603,t:1527873470331};\\\", \\\"{x:1416,y:606,t:1527873470348};\\\", \\\"{x:1415,y:612,t:1527873470364};\\\", \\\"{x:1415,y:617,t:1527873470381};\\\", \\\"{x:1414,y:622,t:1527873470398};\\\", \\\"{x:1414,y:628,t:1527873470414};\\\", \\\"{x:1413,y:632,t:1527873470431};\\\", \\\"{x:1412,y:635,t:1527873470447};\\\", \\\"{x:1412,y:639,t:1527873470464};\\\", \\\"{x:1411,y:642,t:1527873470481};\\\", \\\"{x:1410,y:647,t:1527873470498};\\\", \\\"{x:1409,y:653,t:1527873470515};\\\", \\\"{x:1409,y:657,t:1527873470531};\\\", \\\"{x:1408,y:661,t:1527873470548};\\\", \\\"{x:1408,y:664,t:1527873470565};\\\", \\\"{x:1408,y:668,t:1527873470581};\\\", \\\"{x:1408,y:671,t:1527873470598};\\\", \\\"{x:1408,y:673,t:1527873470614};\\\", \\\"{x:1408,y:676,t:1527873470632};\\\", \\\"{x:1408,y:678,t:1527873470648};\\\", \\\"{x:1408,y:681,t:1527873470665};\\\", \\\"{x:1408,y:683,t:1527873470682};\\\", \\\"{x:1408,y:685,t:1527873470698};\\\", \\\"{x:1408,y:687,t:1527873470715};\\\", \\\"{x:1408,y:689,t:1527873470732};\\\", \\\"{x:1408,y:690,t:1527873470748};\\\", \\\"{x:1408,y:692,t:1527873470765};\\\", \\\"{x:1408,y:694,t:1527873470782};\\\", \\\"{x:1408,y:697,t:1527873470798};\\\", \\\"{x:1408,y:700,t:1527873470816};\\\", \\\"{x:1408,y:702,t:1527873470831};\\\", \\\"{x:1408,y:703,t:1527873470848};\\\", \\\"{x:1408,y:705,t:1527873470865};\\\", \\\"{x:1408,y:706,t:1527873470881};\\\", \\\"{x:1408,y:708,t:1527873470899};\\\", \\\"{x:1408,y:709,t:1527873470915};\\\", \\\"{x:1408,y:711,t:1527873470932};\\\", \\\"{x:1408,y:712,t:1527873470948};\\\", \\\"{x:1408,y:714,t:1527873470966};\\\", \\\"{x:1408,y:716,t:1527873470981};\\\", \\\"{x:1408,y:719,t:1527873470998};\\\", \\\"{x:1408,y:725,t:1527873471016};\\\", \\\"{x:1408,y:728,t:1527873471031};\\\", \\\"{x:1408,y:731,t:1527873471048};\\\", \\\"{x:1408,y:736,t:1527873471065};\\\", \\\"{x:1408,y:739,t:1527873471081};\\\", \\\"{x:1408,y:744,t:1527873471099};\\\", \\\"{x:1408,y:749,t:1527873471116};\\\", \\\"{x:1408,y:751,t:1527873471131};\\\", \\\"{x:1408,y:754,t:1527873471149};\\\", \\\"{x:1408,y:760,t:1527873471166};\\\", \\\"{x:1408,y:762,t:1527873471182};\\\", \\\"{x:1408,y:764,t:1527873471198};\\\", \\\"{x:1408,y:767,t:1527873471215};\\\", \\\"{x:1408,y:769,t:1527873471231};\\\", \\\"{x:1408,y:770,t:1527873471248};\\\", \\\"{x:1408,y:773,t:1527873471265};\\\", \\\"{x:1408,y:775,t:1527873471282};\\\", \\\"{x:1408,y:779,t:1527873471298};\\\", \\\"{x:1408,y:781,t:1527873471315};\\\", \\\"{x:1408,y:786,t:1527873471333};\\\", \\\"{x:1408,y:790,t:1527873471348};\\\", \\\"{x:1408,y:795,t:1527873471365};\\\", \\\"{x:1408,y:801,t:1527873471383};\\\", \\\"{x:1408,y:806,t:1527873471398};\\\", \\\"{x:1408,y:814,t:1527873471415};\\\", \\\"{x:1408,y:820,t:1527873471431};\\\", \\\"{x:1408,y:825,t:1527873471448};\\\", \\\"{x:1408,y:831,t:1527873471465};\\\", \\\"{x:1408,y:837,t:1527873471482};\\\", \\\"{x:1408,y:846,t:1527873471499};\\\", \\\"{x:1408,y:853,t:1527873471516};\\\", \\\"{x:1409,y:861,t:1527873471532};\\\", \\\"{x:1410,y:870,t:1527873471548};\\\", \\\"{x:1411,y:874,t:1527873471565};\\\", \\\"{x:1412,y:880,t:1527873471582};\\\", \\\"{x:1412,y:883,t:1527873471598};\\\", \\\"{x:1412,y:889,t:1527873471615};\\\", \\\"{x:1412,y:892,t:1527873471631};\\\", \\\"{x:1412,y:896,t:1527873471648};\\\", \\\"{x:1412,y:899,t:1527873471665};\\\", \\\"{x:1412,y:901,t:1527873471682};\\\", \\\"{x:1412,y:904,t:1527873471699};\\\", \\\"{x:1412,y:907,t:1527873471715};\\\", \\\"{x:1412,y:912,t:1527873471733};\\\", \\\"{x:1412,y:916,t:1527873471750};\\\", \\\"{x:1412,y:919,t:1527873471766};\\\", \\\"{x:1412,y:922,t:1527873471783};\\\", \\\"{x:1412,y:926,t:1527873471799};\\\", \\\"{x:1412,y:929,t:1527873471816};\\\", \\\"{x:1412,y:932,t:1527873471833};\\\", \\\"{x:1412,y:933,t:1527873471849};\\\", \\\"{x:1412,y:935,t:1527873471865};\\\", \\\"{x:1412,y:936,t:1527873471882};\\\", \\\"{x:1412,y:938,t:1527873471900};\\\", \\\"{x:1412,y:940,t:1527873471915};\\\", \\\"{x:1412,y:941,t:1527873471932};\\\", \\\"{x:1412,y:942,t:1527873471948};\\\", \\\"{x:1412,y:944,t:1527873471965};\\\", \\\"{x:1413,y:945,t:1527873471981};\\\", \\\"{x:1413,y:949,t:1527873471998};\\\", \\\"{x:1413,y:951,t:1527873472015};\\\", \\\"{x:1415,y:952,t:1527873472031};\\\", \\\"{x:1415,y:954,t:1527873472049};\\\", \\\"{x:1415,y:955,t:1527873472071};\\\", \\\"{x:1415,y:956,t:1527873472087};\\\", \\\"{x:1413,y:956,t:1527873473928};\\\", \\\"{x:1411,y:956,t:1527873473936};\\\", \\\"{x:1409,y:956,t:1527873473951};\\\", \\\"{x:1407,y:956,t:1527873473967};\\\", \\\"{x:1405,y:956,t:1527873474056};\\\", \\\"{x:1404,y:956,t:1527873474071};\\\", \\\"{x:1402,y:956,t:1527873474083};\\\", \\\"{x:1401,y:956,t:1527873474101};\\\", \\\"{x:1399,y:956,t:1527873474117};\\\", \\\"{x:1398,y:956,t:1527873474133};\\\", \\\"{x:1397,y:956,t:1527873474151};\\\", \\\"{x:1395,y:956,t:1527873474166};\\\", \\\"{x:1392,y:956,t:1527873474183};\\\", \\\"{x:1390,y:956,t:1527873474200};\\\", \\\"{x:1386,y:956,t:1527873474216};\\\", \\\"{x:1384,y:956,t:1527873474233};\\\", \\\"{x:1382,y:956,t:1527873474250};\\\", \\\"{x:1380,y:956,t:1527873474266};\\\", \\\"{x:1379,y:956,t:1527873474736};\\\", \\\"{x:1379,y:957,t:1527873474759};\\\", \\\"{x:1378,y:958,t:1527873474816};\\\", \\\"{x:1378,y:959,t:1527873475160};\\\", \\\"{x:1379,y:959,t:1527873475191};\\\", \\\"{x:1380,y:959,t:1527873475824};\\\", \\\"{x:1380,y:958,t:1527873475839};\\\", \\\"{x:1380,y:957,t:1527873475856};\\\", \\\"{x:1380,y:956,t:1527873475869};\\\", \\\"{x:1380,y:955,t:1527873475884};\\\", \\\"{x:1380,y:954,t:1527873475907};\\\", \\\"{x:1380,y:953,t:1527873475918};\\\", \\\"{x:1380,y:951,t:1527873475935};\\\", \\\"{x:1380,y:950,t:1527873476006};\\\", \\\"{x:1380,y:949,t:1527873476030};\\\", \\\"{x:1380,y:948,t:1527873476063};\\\", \\\"{x:1380,y:947,t:1527873476079};\\\", \\\"{x:1380,y:946,t:1527873476087};\\\", \\\"{x:1380,y:945,t:1527873476111};\\\", \\\"{x:1380,y:944,t:1527873476127};\\\", \\\"{x:1380,y:943,t:1527873476160};\\\", \\\"{x:1379,y:943,t:1527873476175};\\\", \\\"{x:1379,y:942,t:1527873476199};\\\", \\\"{x:1379,y:941,t:1527873476215};\\\", \\\"{x:1379,y:940,t:1527873476240};\\\", \\\"{x:1379,y:939,t:1527873476312};\\\", \\\"{x:1379,y:938,t:1527873476600};\\\", \\\"{x:1379,y:937,t:1527873476607};\\\", \\\"{x:1379,y:936,t:1527873476624};\\\", \\\"{x:1379,y:935,t:1527873476640};\\\", \\\"{x:1379,y:934,t:1527873476652};\\\", \\\"{x:1379,y:933,t:1527873476680};\\\", \\\"{x:1379,y:932,t:1527873476687};\\\", \\\"{x:1379,y:931,t:1527873476702};\\\", \\\"{x:1379,y:930,t:1527873476718};\\\", \\\"{x:1379,y:927,t:1527873476735};\\\", \\\"{x:1379,y:925,t:1527873476752};\\\", \\\"{x:1379,y:924,t:1527873476768};\\\", \\\"{x:1379,y:922,t:1527873476785};\\\", \\\"{x:1379,y:921,t:1527873476807};\\\", \\\"{x:1379,y:920,t:1527873476818};\\\", \\\"{x:1379,y:919,t:1527873476836};\\\", \\\"{x:1379,y:918,t:1527873476855};\\\", \\\"{x:1379,y:917,t:1527873476871};\\\", \\\"{x:1379,y:916,t:1527873476896};\\\", \\\"{x:1379,y:915,t:1527873476935};\\\", \\\"{x:1379,y:914,t:1527873476952};\\\", \\\"{x:1379,y:913,t:1527873476969};\\\", \\\"{x:1379,y:912,t:1527873476991};\\\", \\\"{x:1379,y:911,t:1527873477007};\\\", \\\"{x:1379,y:910,t:1527873477019};\\\", \\\"{x:1379,y:909,t:1527873477036};\\\", \\\"{x:1379,y:907,t:1527873477053};\\\", \\\"{x:1379,y:906,t:1527873477112};\\\", \\\"{x:1379,y:905,t:1527873477120};\\\", \\\"{x:1379,y:903,t:1527873477136};\\\", \\\"{x:1379,y:902,t:1527873477153};\\\", \\\"{x:1379,y:901,t:1527873477170};\\\", \\\"{x:1379,y:899,t:1527873477202};\\\", \\\"{x:1379,y:898,t:1527873477219};\\\", \\\"{x:1379,y:897,t:1527873477235};\\\", \\\"{x:1379,y:896,t:1527873477263};\\\", \\\"{x:1379,y:895,t:1527873477280};\\\", \\\"{x:1379,y:892,t:1527873477464};\\\", \\\"{x:1379,y:891,t:1527873477473};\\\", \\\"{x:1379,y:888,t:1527873477485};\\\", \\\"{x:1379,y:887,t:1527873477501};\\\", \\\"{x:1379,y:885,t:1527873477519};\\\", \\\"{x:1379,y:883,t:1527873477535};\\\", \\\"{x:1379,y:879,t:1527873477551};\\\", \\\"{x:1379,y:878,t:1527873477569};\\\", \\\"{x:1379,y:875,t:1527873477586};\\\", \\\"{x:1379,y:872,t:1527873477602};\\\", \\\"{x:1379,y:869,t:1527873477619};\\\", \\\"{x:1379,y:866,t:1527873477637};\\\", \\\"{x:1379,y:863,t:1527873477652};\\\", \\\"{x:1378,y:859,t:1527873477669};\\\", \\\"{x:1377,y:857,t:1527873477687};\\\", \\\"{x:1377,y:852,t:1527873477702};\\\", \\\"{x:1375,y:841,t:1527873477719};\\\", \\\"{x:1374,y:830,t:1527873477736};\\\", \\\"{x:1372,y:821,t:1527873477752};\\\", \\\"{x:1371,y:814,t:1527873477770};\\\", \\\"{x:1371,y:811,t:1527873477786};\\\", \\\"{x:1371,y:810,t:1527873477807};\\\", \\\"{x:1370,y:809,t:1527873477847};\\\", \\\"{x:1369,y:809,t:1527873477855};\\\", \\\"{x:1367,y:814,t:1527873477869};\\\", \\\"{x:1362,y:831,t:1527873477887};\\\", \\\"{x:1357,y:847,t:1527873477903};\\\", \\\"{x:1350,y:865,t:1527873477919};\\\", \\\"{x:1348,y:871,t:1527873477936};\\\", \\\"{x:1347,y:876,t:1527873477953};\\\", \\\"{x:1347,y:880,t:1527873477969};\\\", \\\"{x:1347,y:882,t:1527873477986};\\\", \\\"{x:1347,y:885,t:1527873478003};\\\", \\\"{x:1347,y:886,t:1527873478019};\\\", \\\"{x:1347,y:889,t:1527873478036};\\\", \\\"{x:1347,y:891,t:1527873478053};\\\", \\\"{x:1347,y:896,t:1527873478070};\\\", \\\"{x:1347,y:898,t:1527873478087};\\\", \\\"{x:1347,y:903,t:1527873478104};\\\", \\\"{x:1347,y:913,t:1527873478119};\\\", \\\"{x:1347,y:926,t:1527873478136};\\\", \\\"{x:1347,y:935,t:1527873478154};\\\", \\\"{x:1347,y:940,t:1527873478170};\\\", \\\"{x:1347,y:943,t:1527873478186};\\\", \\\"{x:1345,y:946,t:1527873478203};\\\", \\\"{x:1345,y:955,t:1527873478219};\\\", \\\"{x:1345,y:962,t:1527873478237};\\\", \\\"{x:1345,y:966,t:1527873478253};\\\", \\\"{x:1344,y:966,t:1527873478712};\\\", \\\"{x:1344,y:965,t:1527873478752};\\\", \\\"{x:1344,y:964,t:1527873478767};\\\", \\\"{x:1344,y:963,t:1527873478783};\\\", \\\"{x:1344,y:962,t:1527873478808};\\\", \\\"{x:1344,y:961,t:1527873478821};\\\", \\\"{x:1344,y:960,t:1527873478837};\\\", \\\"{x:1344,y:959,t:1527873478854};\\\", \\\"{x:1344,y:958,t:1527873478870};\\\", \\\"{x:1344,y:957,t:1527873478886};\\\", \\\"{x:1344,y:955,t:1527873478903};\\\", \\\"{x:1344,y:953,t:1527873478920};\\\", \\\"{x:1344,y:951,t:1527873478936};\\\", \\\"{x:1344,y:948,t:1527873478953};\\\", \\\"{x:1344,y:945,t:1527873478970};\\\", \\\"{x:1344,y:942,t:1527873478986};\\\", \\\"{x:1344,y:937,t:1527873479003};\\\", \\\"{x:1344,y:934,t:1527873479020};\\\", \\\"{x:1344,y:930,t:1527873479036};\\\", \\\"{x:1344,y:928,t:1527873479053};\\\", \\\"{x:1344,y:926,t:1527873479070};\\\", \\\"{x:1344,y:924,t:1527873479087};\\\", \\\"{x:1344,y:921,t:1527873479103};\\\", \\\"{x:1344,y:920,t:1527873479120};\\\", \\\"{x:1344,y:918,t:1527873479137};\\\", \\\"{x:1344,y:917,t:1527873479154};\\\", \\\"{x:1344,y:915,t:1527873479170};\\\", \\\"{x:1344,y:913,t:1527873479188};\\\", \\\"{x:1344,y:911,t:1527873479204};\\\", \\\"{x:1344,y:907,t:1527873479220};\\\", \\\"{x:1344,y:905,t:1527873479238};\\\", \\\"{x:1344,y:901,t:1527873479254};\\\", \\\"{x:1344,y:900,t:1527873479271};\\\", \\\"{x:1344,y:898,t:1527873479288};\\\", \\\"{x:1344,y:896,t:1527873479304};\\\", \\\"{x:1344,y:894,t:1527873479321};\\\", \\\"{x:1344,y:892,t:1527873479337};\\\", \\\"{x:1344,y:889,t:1527873479353};\\\", \\\"{x:1344,y:885,t:1527873479371};\\\", \\\"{x:1344,y:882,t:1527873479388};\\\", \\\"{x:1344,y:878,t:1527873479404};\\\", \\\"{x:1345,y:877,t:1527873479420};\\\", \\\"{x:1345,y:875,t:1527873479480};\\\", \\\"{x:1345,y:874,t:1527873479487};\\\", \\\"{x:1345,y:867,t:1527873479503};\\\", \\\"{x:1345,y:860,t:1527873479521};\\\", \\\"{x:1345,y:855,t:1527873479538};\\\", \\\"{x:1346,y:849,t:1527873479554};\\\", \\\"{x:1346,y:844,t:1527873479570};\\\", \\\"{x:1346,y:837,t:1527873479588};\\\", \\\"{x:1346,y:829,t:1527873479604};\\\", \\\"{x:1346,y:823,t:1527873479620};\\\", \\\"{x:1346,y:817,t:1527873479638};\\\", \\\"{x:1346,y:814,t:1527873479654};\\\", \\\"{x:1346,y:812,t:1527873479671};\\\", \\\"{x:1346,y:810,t:1527873479687};\\\", \\\"{x:1346,y:806,t:1527873479708};\\\", \\\"{x:1346,y:803,t:1527873479720};\\\", \\\"{x:1346,y:796,t:1527873479737};\\\", \\\"{x:1346,y:787,t:1527873479754};\\\", \\\"{x:1346,y:783,t:1527873479770};\\\", \\\"{x:1346,y:780,t:1527873479787};\\\", \\\"{x:1346,y:778,t:1527873479804};\\\", \\\"{x:1346,y:773,t:1527873479820};\\\", \\\"{x:1346,y:770,t:1527873479837};\\\", \\\"{x:1346,y:769,t:1527873479854};\\\", \\\"{x:1346,y:768,t:1527873479870};\\\", \\\"{x:1346,y:766,t:1527873479886};\\\", \\\"{x:1346,y:765,t:1527873479905};\\\", \\\"{x:1346,y:763,t:1527873479951};\\\", \\\"{x:1346,y:761,t:1527873481720};\\\", \\\"{x:1346,y:759,t:1527873481727};\\\", \\\"{x:1346,y:756,t:1527873481740};\\\", \\\"{x:1346,y:753,t:1527873481755};\\\", \\\"{x:1346,y:748,t:1527873481772};\\\", \\\"{x:1345,y:747,t:1527873481788};\\\", \\\"{x:1345,y:744,t:1527873481806};\\\", \\\"{x:1345,y:740,t:1527873481823};\\\", \\\"{x:1345,y:737,t:1527873481839};\\\", \\\"{x:1345,y:733,t:1527873481856};\\\", \\\"{x:1345,y:731,t:1527873481873};\\\", \\\"{x:1345,y:728,t:1527873481888};\\\", \\\"{x:1345,y:726,t:1527873481908};\\\", \\\"{x:1345,y:724,t:1527873481928};\\\", \\\"{x:1345,y:723,t:1527873481943};\\\", \\\"{x:1345,y:722,t:1527873481955};\\\", \\\"{x:1345,y:721,t:1527873481973};\\\", \\\"{x:1345,y:720,t:1527873481991};\\\", \\\"{x:1345,y:719,t:1527873482016};\\\", \\\"{x:1345,y:718,t:1527873482047};\\\", \\\"{x:1345,y:717,t:1527873482063};\\\", \\\"{x:1345,y:716,t:1527873482073};\\\", \\\"{x:1345,y:715,t:1527873482089};\\\", \\\"{x:1345,y:714,t:1527873482107};\\\", \\\"{x:1345,y:712,t:1527873482122};\\\", \\\"{x:1345,y:710,t:1527873482167};\\\", \\\"{x:1346,y:710,t:1527873482175};\\\", \\\"{x:1346,y:709,t:1527873482256};\\\", \\\"{x:1346,y:707,t:1527873482888};\\\", \\\"{x:1346,y:705,t:1527873482895};\\\", \\\"{x:1346,y:704,t:1527873482906};\\\", \\\"{x:1346,y:702,t:1527873482923};\\\", \\\"{x:1345,y:699,t:1527873482940};\\\", \\\"{x:1345,y:697,t:1527873482956};\\\", \\\"{x:1345,y:696,t:1527873482975};\\\", \\\"{x:1344,y:695,t:1527873487152};\\\", \\\"{x:1336,y:695,t:1527873487160};\\\", \\\"{x:1297,y:694,t:1527873487176};\\\", \\\"{x:1216,y:683,t:1527873487193};\\\", \\\"{x:1126,y:663,t:1527873487209};\\\", \\\"{x:1026,y:633,t:1527873487226};\\\", \\\"{x:937,y:604,t:1527873487244};\\\", \\\"{x:845,y:579,t:1527873487259};\\\", \\\"{x:795,y:557,t:1527873487275};\\\", \\\"{x:766,y:544,t:1527873487294};\\\", \\\"{x:761,y:541,t:1527873487311};\\\", \\\"{x:758,y:537,t:1527873487375};\\\", \\\"{x:755,y:534,t:1527873487390};\\\", \\\"{x:754,y:531,t:1527873487399};\\\", \\\"{x:751,y:529,t:1527873487413};\\\", \\\"{x:750,y:527,t:1527873487429};\\\", \\\"{x:750,y:526,t:1527873487447};\\\", \\\"{x:751,y:525,t:1527873487559};\\\", \\\"{x:753,y:524,t:1527873487567};\\\", \\\"{x:756,y:523,t:1527873487580};\\\", \\\"{x:764,y:521,t:1527873487597};\\\", \\\"{x:775,y:518,t:1527873487614};\\\", \\\"{x:794,y:516,t:1527873487631};\\\", \\\"{x:802,y:516,t:1527873487647};\\\", \\\"{x:805,y:516,t:1527873487664};\\\", \\\"{x:806,y:515,t:1527873487681};\\\", \\\"{x:807,y:515,t:1527873487743};\\\", \\\"{x:808,y:515,t:1527873487751};\\\", \\\"{x:811,y:515,t:1527873487764};\\\", \\\"{x:818,y:516,t:1527873487781};\\\", \\\"{x:825,y:518,t:1527873487796};\\\", \\\"{x:833,y:521,t:1527873487814};\\\", \\\"{x:844,y:524,t:1527873487830};\\\", \\\"{x:846,y:525,t:1527873487847};\\\", \\\"{x:848,y:526,t:1527873487871};\\\", \\\"{x:850,y:526,t:1527873488199};\\\", \\\"{x:854,y:527,t:1527873488214};\\\", \\\"{x:876,y:529,t:1527873488231};\\\", \\\"{x:902,y:529,t:1527873488247};\\\", \\\"{x:940,y:529,t:1527873488264};\\\", \\\"{x:1007,y:529,t:1527873488282};\\\", \\\"{x:1085,y:529,t:1527873488297};\\\", \\\"{x:1143,y:534,t:1527873488314};\\\", \\\"{x:1191,y:537,t:1527873488330};\\\", \\\"{x:1232,y:540,t:1527873488347};\\\", \\\"{x:1254,y:541,t:1527873488365};\\\", \\\"{x:1262,y:542,t:1527873488382};\\\", \\\"{x:1266,y:543,t:1527873488397};\\\", \\\"{x:1270,y:543,t:1527873488414};\\\", \\\"{x:1271,y:544,t:1527873488431};\\\", \\\"{x:1271,y:545,t:1527873488447};\\\", \\\"{x:1273,y:545,t:1527873488465};\\\", \\\"{x:1279,y:545,t:1527873488482};\\\", \\\"{x:1294,y:545,t:1527873488498};\\\", \\\"{x:1307,y:547,t:1527873488515};\\\", \\\"{x:1313,y:549,t:1527873488531};\\\", \\\"{x:1322,y:553,t:1527873488548};\\\", \\\"{x:1326,y:555,t:1527873488565};\\\", \\\"{x:1330,y:558,t:1527873488582};\\\", \\\"{x:1330,y:561,t:1527873488599};\\\", \\\"{x:1327,y:565,t:1527873488615};\\\", \\\"{x:1324,y:568,t:1527873488632};\\\", \\\"{x:1323,y:569,t:1527873488649};\\\", \\\"{x:1323,y:570,t:1527873488672};\\\", \\\"{x:1322,y:570,t:1527873488682};\\\", \\\"{x:1321,y:571,t:1527873488727};\\\", \\\"{x:1321,y:572,t:1527873488735};\\\", \\\"{x:1320,y:572,t:1527873488749};\\\", \\\"{x:1318,y:572,t:1527873488768};\\\", \\\"{x:1317,y:572,t:1527873488783};\\\", \\\"{x:1314,y:572,t:1527873488799};\\\", \\\"{x:1307,y:572,t:1527873488816};\\\", \\\"{x:1304,y:572,t:1527873488832};\\\", \\\"{x:1303,y:572,t:1527873488849};\\\", \\\"{x:1302,y:572,t:1527873488866};\\\", \\\"{x:1301,y:572,t:1527873488883};\\\", \\\"{x:1300,y:572,t:1527873488899};\\\", \\\"{x:1300,y:571,t:1527873488916};\\\", \\\"{x:1299,y:571,t:1527873488951};\\\", \\\"{x:1298,y:571,t:1527873488984};\\\", \\\"{x:1297,y:571,t:1527873488999};\\\", \\\"{x:1294,y:570,t:1527873489016};\\\", \\\"{x:1293,y:569,t:1527873489033};\\\", \\\"{x:1289,y:568,t:1527873489050};\\\", \\\"{x:1288,y:567,t:1527873489088};\\\", \\\"{x:1287,y:567,t:1527873489120};\\\", \\\"{x:1286,y:567,t:1527873489168};\\\", \\\"{x:1285,y:568,t:1527873489272};\\\", \\\"{x:1284,y:574,t:1527873489283};\\\", \\\"{x:1283,y:585,t:1527873489300};\\\", \\\"{x:1283,y:593,t:1527873489317};\\\", \\\"{x:1283,y:599,t:1527873489333};\\\", \\\"{x:1282,y:605,t:1527873489350};\\\", \\\"{x:1282,y:609,t:1527873489367};\\\", \\\"{x:1282,y:612,t:1527873489384};\\\", \\\"{x:1282,y:616,t:1527873489400};\\\", \\\"{x:1282,y:620,t:1527873489417};\\\", \\\"{x:1282,y:623,t:1527873489434};\\\", \\\"{x:1282,y:627,t:1527873489450};\\\", \\\"{x:1282,y:630,t:1527873489467};\\\", \\\"{x:1282,y:632,t:1527873489484};\\\", \\\"{x:1282,y:635,t:1527873489500};\\\", \\\"{x:1282,y:639,t:1527873489517};\\\", \\\"{x:1282,y:644,t:1527873489534};\\\", \\\"{x:1282,y:660,t:1527873489551};\\\", \\\"{x:1282,y:671,t:1527873489567};\\\", \\\"{x:1282,y:680,t:1527873489584};\\\", \\\"{x:1282,y:688,t:1527873489601};\\\", \\\"{x:1282,y:699,t:1527873489617};\\\", \\\"{x:1283,y:712,t:1527873489634};\\\", \\\"{x:1285,y:727,t:1527873489651};\\\", \\\"{x:1289,y:744,t:1527873489667};\\\", \\\"{x:1290,y:758,t:1527873489684};\\\", \\\"{x:1290,y:768,t:1527873489701};\\\", \\\"{x:1290,y:779,t:1527873489718};\\\", \\\"{x:1290,y:787,t:1527873489734};\\\", \\\"{x:1290,y:801,t:1527873489751};\\\", \\\"{x:1290,y:810,t:1527873489768};\\\", \\\"{x:1290,y:815,t:1527873489784};\\\", \\\"{x:1290,y:821,t:1527873489801};\\\", \\\"{x:1290,y:825,t:1527873489818};\\\", \\\"{x:1290,y:828,t:1527873489835};\\\", \\\"{x:1290,y:833,t:1527873489851};\\\", \\\"{x:1290,y:840,t:1527873489868};\\\", \\\"{x:1290,y:845,t:1527873489885};\\\", \\\"{x:1290,y:851,t:1527873489901};\\\", \\\"{x:1290,y:856,t:1527873489918};\\\", \\\"{x:1290,y:868,t:1527873489935};\\\", \\\"{x:1290,y:876,t:1527873489950};\\\", \\\"{x:1290,y:885,t:1527873489967};\\\", \\\"{x:1290,y:888,t:1527873489984};\\\", \\\"{x:1289,y:891,t:1527873490001};\\\", \\\"{x:1289,y:894,t:1527873490018};\\\", \\\"{x:1289,y:899,t:1527873490035};\\\", \\\"{x:1288,y:909,t:1527873490052};\\\", \\\"{x:1285,y:923,t:1527873490068};\\\", \\\"{x:1284,y:931,t:1527873490085};\\\", \\\"{x:1282,y:939,t:1527873490102};\\\", \\\"{x:1280,y:943,t:1527873490118};\\\", \\\"{x:1278,y:950,t:1527873490135};\\\", \\\"{x:1276,y:955,t:1527873490152};\\\", \\\"{x:1276,y:956,t:1527873490169};\\\", \\\"{x:1276,y:957,t:1527873490185};\\\", \\\"{x:1275,y:957,t:1527873493270};\\\", \\\"{x:1272,y:956,t:1527873493279};\\\", \\\"{x:1269,y:951,t:1527873493292};\\\", \\\"{x:1253,y:938,t:1527873493308};\\\", \\\"{x:1227,y:923,t:1527873493324};\\\", \\\"{x:1175,y:895,t:1527873493341};\\\", \\\"{x:1118,y:862,t:1527873493358};\\\", \\\"{x:1030,y:794,t:1527873493375};\\\", \\\"{x:988,y:755,t:1527873493392};\\\", \\\"{x:955,y:726,t:1527873493408};\\\", \\\"{x:932,y:701,t:1527873493425};\\\", \\\"{x:919,y:683,t:1527873493442};\\\", \\\"{x:910,y:668,t:1527873493459};\\\", \\\"{x:905,y:653,t:1527873493475};\\\", \\\"{x:899,y:641,t:1527873493493};\\\", \\\"{x:892,y:627,t:1527873493508};\\\", \\\"{x:882,y:613,t:1527873493525};\\\", \\\"{x:873,y:602,t:1527873493534};\\\", \\\"{x:863,y:590,t:1527873493551};\\\", \\\"{x:852,y:579,t:1527873493568};\\\", \\\"{x:848,y:571,t:1527873493584};\\\", \\\"{x:845,y:566,t:1527873493602};\\\", \\\"{x:841,y:559,t:1527873493619};\\\", \\\"{x:839,y:555,t:1527873493634};\\\", \\\"{x:837,y:551,t:1527873493652};\\\", \\\"{x:836,y:548,t:1527873493667};\\\", \\\"{x:834,y:544,t:1527873493684};\\\", \\\"{x:832,y:537,t:1527873493702};\\\", \\\"{x:829,y:534,t:1527873493718};\\\", \\\"{x:828,y:533,t:1527873493734};\\\", \\\"{x:827,y:532,t:1527873493839};\\\", \\\"{x:827,y:531,t:1527873493863};\\\", \\\"{x:827,y:530,t:1527873493878};\\\", \\\"{x:827,y:529,t:1527873493887};\\\", \\\"{x:827,y:526,t:1527873493902};\\\", \\\"{x:839,y:520,t:1527873493919};\\\", \\\"{x:845,y:517,t:1527873493935};\\\", \\\"{x:853,y:513,t:1527873493952};\\\", \\\"{x:856,y:513,t:1527873493969};\\\", \\\"{x:857,y:513,t:1527873494079};\\\", \\\"{x:856,y:513,t:1527873494128};\\\", \\\"{x:855,y:513,t:1527873494143};\\\", \\\"{x:854,y:513,t:1527873494152};\\\", \\\"{x:853,y:513,t:1527873494247};\\\", \\\"{x:852,y:513,t:1527873494263};\\\", \\\"{x:851,y:513,t:1527873494279};\\\", \\\"{x:850,y:513,t:1527873494311};\\\", \\\"{x:848,y:512,t:1527873494327};\\\", \\\"{x:847,y:512,t:1527873494335};\\\", \\\"{x:843,y:512,t:1527873495440};\\\", \\\"{x:837,y:512,t:1527873495453};\\\", \\\"{x:817,y:516,t:1527873495472};\\\", \\\"{x:776,y:522,t:1527873495486};\\\", \\\"{x:746,y:523,t:1527873495502};\\\", \\\"{x:708,y:523,t:1527873495521};\\\", \\\"{x:681,y:523,t:1527873495537};\\\", \\\"{x:662,y:523,t:1527873495553};\\\", \\\"{x:652,y:523,t:1527873495570};\\\", \\\"{x:645,y:523,t:1527873495587};\\\", \\\"{x:643,y:523,t:1527873495603};\\\", \\\"{x:641,y:523,t:1527873495809};\\\", \\\"{x:640,y:523,t:1527873495819};\\\", \\\"{x:639,y:523,t:1527873495836};\\\", \\\"{x:638,y:523,t:1527873495854};\\\", \\\"{x:636,y:524,t:1527873501871};\\\", \\\"{x:633,y:532,t:1527873501880};\\\", \\\"{x:630,y:539,t:1527873501894};\\\", \\\"{x:612,y:570,t:1527873501925};\\\", \\\"{x:603,y:588,t:1527873501942};\\\", \\\"{x:593,y:606,t:1527873501959};\\\", \\\"{x:588,y:618,t:1527873501975};\\\", \\\"{x:581,y:630,t:1527873501992};\\\", \\\"{x:576,y:641,t:1527873502008};\\\", \\\"{x:575,y:644,t:1527873502025};\\\", \\\"{x:574,y:647,t:1527873502041};\\\", \\\"{x:574,y:648,t:1527873502058};\\\", \\\"{x:572,y:651,t:1527873502074};\\\", \\\"{x:569,y:657,t:1527873502092};\\\", \\\"{x:567,y:661,t:1527873502108};\\\", \\\"{x:566,y:663,t:1527873502125};\\\", \\\"{x:566,y:664,t:1527873502183};\\\", \\\"{x:564,y:666,t:1527873502193};\\\", \\\"{x:561,y:670,t:1527873502208};\\\", \\\"{x:560,y:674,t:1527873502225};\\\", \\\"{x:558,y:679,t:1527873502242};\\\", \\\"{x:556,y:685,t:1527873502258};\\\", \\\"{x:556,y:691,t:1527873502275};\\\", \\\"{x:553,y:696,t:1527873502292};\\\", \\\"{x:552,y:703,t:1527873502308};\\\", \\\"{x:548,y:715,t:1527873502325};\\\", \\\"{x:544,y:726,t:1527873502342};\\\", \\\"{x:541,y:731,t:1527873502359};\\\", \\\"{x:540,y:732,t:1527873502376};\\\", \\\"{x:539,y:734,t:1527873502393};\\\", \\\"{x:537,y:735,t:1527873502409};\\\", \\\"{x:533,y:737,t:1527873502425};\\\", \\\"{x:529,y:742,t:1527873502442};\\\", \\\"{x:526,y:744,t:1527873502460};\\\", \\\"{x:525,y:745,t:1527873502527};\\\", \\\"{x:525,y:746,t:1527873502542};\\\", \\\"{x:524,y:746,t:1527873503383};\\\", \\\"{x:523,y:746,t:1527873503394};\\\", \\\"{x:522,y:746,t:1527873503409};\\\", \\\"{x:522,y:742,t:1527873503427};\\\", \\\"{x:522,y:740,t:1527873503442};\\\", \\\"{x:522,y:738,t:1527873503459};\\\", \\\"{x:525,y:734,t:1527873503475};\\\", \\\"{x:526,y:732,t:1527873503493};\\\", \\\"{x:528,y:731,t:1527873503509};\\\", \\\"{x:531,y:728,t:1527873503526};\\\", \\\"{x:532,y:728,t:1527873503542};\\\", \\\"{x:534,y:726,t:1527873503559};\\\", \\\"{x:534,y:725,t:1527873503575};\\\", \\\"{x:536,y:724,t:1527873503593};\\\", \\\"{x:537,y:722,t:1527873503609};\\\", \\\"{x:540,y:720,t:1527873503626};\\\", \\\"{x:542,y:717,t:1527873503643};\\\", \\\"{x:547,y:714,t:1527873503659};\\\", \\\"{x:550,y:712,t:1527873503676};\\\", \\\"{x:551,y:711,t:1527873503693};\\\", \\\"{x:552,y:709,t:1527873503709};\\\", \\\"{x:553,y:707,t:1527873503726};\\\" ] }, { \\\"rt\\\": 47065, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 741024, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"QGUGU\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"Look at the x axis and see what points line up with 12 PM. (vertically)\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 8479, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"20\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Taiwan\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 750509, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"QGUGU\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 8220, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Second\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Math or Computer Sciences\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 759743, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"QGUGU\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\" }, { \\\"rt\\\": 5522, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 766599, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"QGUGU\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"whiskey\\\", \\\"condition\\\": \\\"115\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"QGUGU\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"800\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"0\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 288, dom: 806, initialDom: 875",
  "javascriptErrors": []
}