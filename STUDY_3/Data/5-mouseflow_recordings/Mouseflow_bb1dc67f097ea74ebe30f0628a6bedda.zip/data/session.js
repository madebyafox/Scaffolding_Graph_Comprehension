var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "bb1dc67f097ea74ebe30f0628a6bedda",
  "created": "2018-06-01T10:18:23.5467533-07:00",
  "lastActivity": "2018-06-01T10:19:38.6191364-07:00",
  "pageViews": [
    {
      "id": "06012322de40a28f4dd9be2abd42e4fff778292a",
      "startTime": "2018-06-01T10:18:23.5467533-07:00",
      "endTime": "2018-06-01T10:19:38.6191364-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 75117,
      "engagementTime": 72721,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 75117,
  "engagementTime": 72721,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.28",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=QGUGU",
    "CONDITION=115"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "b244c9bd616521100c44cb02e170898d",
  "gdpr": false
}