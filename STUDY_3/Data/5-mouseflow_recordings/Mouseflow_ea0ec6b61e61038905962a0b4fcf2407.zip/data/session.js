var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "ea0ec6b61e61038905962a0b4fcf2407",
  "created": "2018-05-31T12:10:45.6347582-07:00",
  "lastActivity": "2018-05-31T12:11:24.2795559-07:00",
  "pageViews": [
    {
      "id": "053145625f4c3f0f7e2d02d7c20eab8391be7d52",
      "startTime": "2018-05-31T12:10:45.6347582-07:00",
      "endTime": "2018-05-31T12:11:24.2795559-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/8",
      "visitTime": 39006,
      "engagementTime": 33985,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 39006,
  "engagementTime": 33985,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.23",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "67.0.3396.62",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=XQ4O8",
    "CONDITION=115",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "9dff996f79d0d64e37314bd386698611",
  "gdpr": false
}