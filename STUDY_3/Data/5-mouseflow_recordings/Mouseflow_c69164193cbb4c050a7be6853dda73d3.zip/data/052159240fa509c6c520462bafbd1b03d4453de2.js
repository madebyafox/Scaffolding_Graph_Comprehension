var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["052159240fa509c6c520462bafbd1b03d4453de2"] = {
  "startTime": "2018-05-21T15:34:47.5519896Z",
  "websitePageUrl": "/",
  "visitTime": 1963481,
  "engagementTime": 48167,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1353,
  "viewportHeight": 780,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "c69164193cbb4c050a7be6853dda73d3",
    "created": "2018-05-21T15:34:47.5519896+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.139",
    "os": "macOS",
    "osVersion": "10.12 Sierra",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1440x900",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "a095ac515983084c6e60136215a85e6e",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/c69164193cbb4c050a7be6853dda73d3/play"
  },
  "events": [
    {
      "t": 175,
      "e": 175,
      "ty": 0,
      "x": 1353,
      "y": 780
    },
    {
      "t": 1126,
      "e": 1126,
      "ty": 14,
      "x": 0,
      "y": 798
    },
    {
      "t": 10129,
      "e": 5175,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 816580,
      "e": 5175,
      "ty": 2,
      "x": 991,
      "y": 2
    },
    {
      "t": 816584,
      "e": 5179,
      "ty": 41,
      "x": 49506,
      "y": 327,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 816642,
      "e": 5237,
      "ty": 2,
      "x": 950,
      "y": 114
    },
    {
      "t": 816744,
      "e": 5339,
      "ty": 2,
      "x": 950,
      "y": 115
    },
    {
      "t": 816794,
      "e": 5389,
      "ty": 41,
      "x": 47267,
      "y": 9584,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 817198,
      "e": 5793,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 818537,
      "e": 7132,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 818674,
      "e": 7269,
      "ty": 2,
      "x": 957,
      "y": 103
    },
    {
      "t": 818677,
      "e": 7272,
      "ty": 41,
      "x": 51623,
      "y": 59391,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 818680,
      "e": 7275,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 818743,
      "e": 7338,
      "ty": 2,
      "x": 1048,
      "y": 1
    },
    {
      "t": 818792,
      "e": 7387,
      "ty": 41,
      "x": 50761,
      "y": 84,
      "ta": "html"
    },
    {
      "t": 830174,
      "e": 12387,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 964449,
      "e": 12387,
      "ty": 2,
      "x": 775,
      "y": 119
    },
    {
      "t": 964550,
      "e": 12488,
      "ty": 2,
      "x": 471,
      "y": 305
    },
    {
      "t": 964550,
      "e": 12488,
      "ty": 41,
      "x": 17994,
      "y": 31237,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 964750,
      "e": 12688,
      "ty": 2,
      "x": 471,
      "y": 379
    },
    {
      "t": 964799,
      "e": 12737,
      "ty": 41,
      "x": 28093,
      "y": 61334,
      "ta": "> div.masterdiv"
    },
    {
      "t": 964849,
      "e": 12787,
      "ty": 2,
      "x": 643,
      "y": 779
    },
    {
      "t": 964950,
      "e": 12888,
      "ty": 2,
      "x": 654,
      "y": 779
    },
    {
      "t": 965049,
      "e": 12987,
      "ty": 2,
      "x": 669,
      "y": 751
    },
    {
      "t": 965050,
      "e": 12988,
      "ty": 41,
      "x": 25511,
      "y": 34447,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 965064,
      "e": 13002,
      "ty": 6,
      "x": 678,
      "y": 737,
      "ta": "#start"
    },
    {
      "t": 965150,
      "e": 13088,
      "ty": 2,
      "x": 698,
      "y": 716
    },
    {
      "t": 965185,
      "e": 13123,
      "ty": 3,
      "x": 699,
      "y": 716,
      "ta": "#start"
    },
    {
      "t": 965187,
      "e": 13125,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 965241,
      "e": 13179,
      "ty": 4,
      "x": 35225,
      "y": 11565,
      "ta": "#start"
    },
    {
      "t": 966520,
      "e": 14458,
      "ty": 5,
      "x": 699,
      "y": 716,
      "ta": "#start"
    },
    {
      "t": 966522,
      "e": 14460,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 966524,
      "e": 14462,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 966524,
      "e": 14462,
      "ty": 2,
      "x": 699,
      "y": 716
    },
    {
      "t": 966576,
      "e": 14514,
      "ty": 41,
      "x": 35225,
      "y": 11565,
      "ta": "#start"
    },
    {
      "t": 966720,
      "e": 14658,
      "ty": 7,
      "x": 830,
      "y": 115,
      "ta": "#start"
    },
    {
      "t": 966725,
      "e": 14663,
      "ty": 2,
      "x": 830,
      "y": 115
    },
    {
      "t": 966829,
      "e": 14767,
      "ty": 2,
      "x": 770,
      "y": 251
    },
    {
      "t": 966829,
      "e": 14767,
      "ty": 41,
      "x": 38683,
      "y": 21514,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 967018,
      "e": 14956,
      "ty": 39,
      "x": 0,
      "y": 223,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 967224,
      "e": 15162,
      "ty": 2,
      "x": 761,
      "y": 255
    },
    {
      "t": 967325,
      "e": 15263,
      "ty": 2,
      "x": 328,
      "y": 515
    },
    {
      "t": 967329,
      "e": 15267,
      "ty": 41,
      "x": 8099,
      "y": 30036,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 967427,
      "e": 15365,
      "ty": 2,
      "x": 348,
      "y": 561
    },
    {
      "t": 967525,
      "e": 15463,
      "ty": 2,
      "x": 488,
      "y": 610
    },
    {
      "t": 967575,
      "e": 15513,
      "ty": 41,
      "x": 19170,
      "y": 62145,
      "ta": "> div.masterdiv > div:[2] > div > div"
    },
    {
      "t": 967625,
      "e": 15563,
      "ty": 2,
      "x": 490,
      "y": 603
    },
    {
      "t": 967725,
      "e": 15663,
      "ty": 2,
      "x": 518,
      "y": 606
    },
    {
      "t": 967826,
      "e": 15764,
      "ty": 2,
      "x": 529,
      "y": 602
    },
    {
      "t": 967827,
      "e": 15765,
      "ty": 41,
      "x": 1843,
      "y": 57343,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 967864,
      "e": 15802,
      "ty": 3,
      "x": 533,
      "y": 600,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 967866,
      "e": 15804,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 967921,
      "e": 15859,
      "ty": 4,
      "x": 14950,
      "y": 50789,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 967921,
      "e": 15859,
      "ty": 5,
      "x": 533,
      "y": 600,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 967922,
      "e": 15860,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 967935,
      "e": 15873,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 967937,
      "e": 15875,
      "ty": 2,
      "x": 533,
      "y": 600
    },
    {
      "t": 968077,
      "e": 16015,
      "ty": 41,
      "x": 14950,
      "y": 50789,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 968126,
      "e": 16064,
      "ty": 2,
      "x": 538,
      "y": 602
    },
    {
      "t": 968226,
      "e": 16164,
      "ty": 2,
      "x": 686,
      "y": 697
    },
    {
      "t": 968326,
      "e": 16264,
      "ty": 2,
      "x": 695,
      "y": 703
    },
    {
      "t": 968326,
      "e": 16264,
      "ty": 41,
      "x": 33494,
      "y": 64799,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 968424,
      "e": 16362,
      "ty": 2,
      "x": 696,
      "y": 704
    },
    {
      "t": 968464,
      "e": 16402,
      "ty": 6,
      "x": 696,
      "y": 712,
      "ta": "#start"
    },
    {
      "t": 968527,
      "e": 16465,
      "ty": 2,
      "x": 696,
      "y": 718
    },
    {
      "t": 968539,
      "e": 16477,
      "ty": 3,
      "x": 696,
      "y": 719,
      "ta": "#start"
    },
    {
      "t": 968539,
      "e": 16477,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 968540,
      "e": 16478,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 968576,
      "e": 16514,
      "ty": 41,
      "x": 33586,
      "y": 17347,
      "ta": "#start"
    },
    {
      "t": 968617,
      "e": 16555,
      "ty": 4,
      "x": 33586,
      "y": 17347,
      "ta": "#start"
    },
    {
      "t": 968619,
      "e": 16557,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 968620,
      "e": 16558,
      "ty": 5,
      "x": 696,
      "y": 719,
      "ta": "#start"
    },
    {
      "t": 968621,
      "e": 16559,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 968625,
      "e": 16563,
      "ty": 2,
      "x": 696,
      "y": 719
    },
    {
      "t": 969025,
      "e": 16963,
      "ty": 2,
      "x": 675,
      "y": 692
    },
    {
      "t": 969077,
      "e": 17015,
      "ty": 41,
      "x": 24169,
      "y": 37556,
      "ta": "html > body"
    },
    {
      "t": 969127,
      "e": 17065,
      "ty": 2,
      "x": 432,
      "y": 273
    },
    {
      "t": 969226,
      "e": 17164,
      "ty": 2,
      "x": 428,
      "y": 237
    },
    {
      "t": 969331,
      "e": 17269,
      "ty": 41,
      "x": 20343,
      "y": 19240,
      "ta": "html > body"
    },
    {
      "t": 969630,
      "e": 17568,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 970134,
      "e": 18072,
      "ty": 2,
      "x": 469,
      "y": 294
    },
    {
      "t": 970226,
      "e": 18164,
      "ty": 2,
      "x": 571,
      "y": 379
    },
    {
      "t": 970281,
      "e": 18219,
      "ty": 6,
      "x": 578,
      "y": 386,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 970327,
      "e": 18265,
      "ty": 2,
      "x": 579,
      "y": 388
    },
    {
      "t": 970327,
      "e": 18265,
      "ty": 41,
      "x": 6378,
      "y": 5173,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 970426,
      "e": 18364,
      "ty": 2,
      "x": 581,
      "y": 400
    },
    {
      "t": 970528,
      "e": 18466,
      "ty": 2,
      "x": 581,
      "y": 393
    },
    {
      "t": 970558,
      "e": 18496,
      "ty": 3,
      "x": 581,
      "y": 393,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 970559,
      "e": 18497,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 970576,
      "e": 18514,
      "ty": 41,
      "x": 6878,
      "y": 22419,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 970612,
      "e": 18550,
      "ty": 4,
      "x": 6878,
      "y": 22419,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 970613,
      "e": 18551,
      "ty": 5,
      "x": 581,
      "y": 393,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 971064,
      "e": 19002,
      "ty": 7,
      "x": 589,
      "y": 383,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 971076,
      "e": 19014,
      "ty": 41,
      "x": 8879,
      "y": 43808,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 971128,
      "e": 19066,
      "ty": 2,
      "x": 795,
      "y": 173
    },
    {
      "t": 971225,
      "e": 19163,
      "ty": 2,
      "x": 983,
      "y": 11
    },
    {
      "t": 971328,
      "e": 19266,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 971331,
      "e": 19269,
      "ty": 2,
      "x": 1008,
      "y": 11
    },
    {
      "t": 971331,
      "e": 19269,
      "ty": 41,
      "x": 48436,
      "y": 252,
      "ta": "html > body"
    },
    {
      "t": 971333,
      "e": 19271,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 971425,
      "e": 19363,
      "ty": 2,
      "x": 1020,
      "y": 4
    },
    {
      "t": 971576,
      "e": 19514,
      "ty": 41,
      "x": 49405,
      "y": 336,
      "ta": "html"
    },
    {
      "t": 972226,
      "e": 20164,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 974747,
      "e": 22685,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 975026,
      "e": 22964,
      "ty": 2,
      "x": 1033,
      "y": 81
    },
    {
      "t": 975076,
      "e": 23014,
      "ty": 41,
      "x": 53937,
      "y": 3583,
      "ta": "#jspsych-survey-text-preamble"
    },
    {
      "t": 975127,
      "e": 23065,
      "ty": 2,
      "x": 778,
      "y": 331
    },
    {
      "t": 975196,
      "e": 23134,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "91"
    },
    {
      "t": 975226,
      "e": 23164,
      "ty": 2,
      "x": 750,
      "y": 363
    },
    {
      "t": 975260,
      "e": 23198,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "86"
    },
    {
      "t": 975326,
      "e": 23264,
      "ty": 2,
      "x": 750,
      "y": 364
    },
    {
      "t": 975327,
      "e": 23265,
      "ty": 41,
      "x": 49151,
      "y": 57343,
      "ta": "#jspsych-survey-text-0 > p"
    },
    {
      "t": 975373,
      "e": 23311,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "STRATEGY-SATISFICING"
    },
    {
      "t": 975394,
      "e": 23332,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 975415,
      "e": 23353,
      "ty": 6,
      "x": 727,
      "y": 391,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 975426,
      "e": 23364,
      "ty": 2,
      "x": 727,
      "y": 391
    },
    {
      "t": 975432,
      "e": 23370,
      "ty": 7,
      "x": 714,
      "y": 406,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 975528,
      "e": 23466,
      "ty": 2,
      "x": 671,
      "y": 467
    },
    {
      "t": 975580,
      "e": 23518,
      "ty": 41,
      "x": 29390,
      "y": 38110,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 975726,
      "e": 23664,
      "ty": 2,
      "x": 659,
      "y": 472
    },
    {
      "t": 975748,
      "e": 23686,
      "ty": 6,
      "x": 650,
      "y": 479,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 975826,
      "e": 23764,
      "ty": 2,
      "x": 630,
      "y": 492
    },
    {
      "t": 975826,
      "e": 23764,
      "ty": 41,
      "x": 19135,
      "y": 46564,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 975910,
      "e": 23848,
      "ty": 3,
      "x": 622,
      "y": 496,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 975911,
      "e": 23849,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "STRATEGY-SATISFICING"
    },
    {
      "t": 975911,
      "e": 23849,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 975912,
      "e": 23850,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 975927,
      "e": 23865,
      "ty": 2,
      "x": 622,
      "y": 496
    },
    {
      "t": 975957,
      "e": 23895,
      "ty": 4,
      "x": 17134,
      "y": 60361,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 975957,
      "e": 23895,
      "ty": 5,
      "x": 622,
      "y": 496,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 976078,
      "e": 24016,
      "ty": 41,
      "x": 17134,
      "y": 60361,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 976419,
      "e": 24357,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 976420,
      "e": 24358,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 976506,
      "e": 24444,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "50"
    },
    {
      "t": 976506,
      "e": 24444,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 976556,
      "e": 24494,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "12"
    },
    {
      "t": 976642,
      "e": 24580,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 976643,
      "e": 24581,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 976692,
      "e": 24630,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "12*"
    },
    {
      "t": 976764,
      "e": 24702,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "12*"
    },
    {
      "t": 976964,
      "e": 24902,
      "ty": 7,
      "x": 625,
      "y": 498,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 976998,
      "e": 24936,
      "ty": 6,
      "x": 636,
      "y": 505,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 977025,
      "e": 24963,
      "ty": 2,
      "x": 642,
      "y": 509
    },
    {
      "t": 977076,
      "e": 25014,
      "ty": 41,
      "x": 18078,
      "y": 30781,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 977125,
      "e": 25063,
      "ty": 2,
      "x": 661,
      "y": 524
    },
    {
      "t": 977175,
      "e": 25113,
      "ty": 3,
      "x": 662,
      "y": 525,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 977175,
      "e": 25113,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "12*"
    },
    {
      "t": 977175,
      "e": 25113,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 977176,
      "e": 25114,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 977229,
      "e": 25167,
      "ty": 2,
      "x": 662,
      "y": 525
    },
    {
      "t": 977231,
      "e": 25169,
      "ty": 4,
      "x": 21171,
      "y": 38725,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 977233,
      "e": 25171,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 977234,
      "e": 25172,
      "ty": 5,
      "x": 662,
      "y": 525,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 977235,
      "e": 25173,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 977325,
      "e": 25263,
      "ty": 41,
      "x": 31677,
      "y": 43437,
      "ta": "html > body"
    },
    {
      "t": 978569,
      "e": 26507,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 978611,
      "e": 26549,
      "ty": 6,
      "x": 662,
      "y": 525,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 980066,
      "e": 28004,
      "ty": 7,
      "x": 664,
      "y": 477,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 980077,
      "e": 28015,
      "ty": 41,
      "x": 31348,
      "y": 41631,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 980099,
      "e": 28037,
      "ty": 6,
      "x": 694,
      "y": 341,
      "ta": "#da1"
    },
    {
      "t": 980115,
      "e": 28053,
      "ty": 7,
      "x": 718,
      "y": 265,
      "ta": "#da1"
    },
    {
      "t": 980127,
      "e": 28065,
      "ty": 2,
      "x": 718,
      "y": 265
    },
    {
      "t": 980225,
      "e": 28163,
      "ty": 2,
      "x": 790,
      "y": 55
    },
    {
      "t": 980326,
      "e": 28264,
      "ty": 41,
      "x": 37877,
      "y": 3948,
      "ta": "> div.masterdiv"
    },
    {
      "t": 981329,
      "e": 29267,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 982028,
      "e": 29966,
      "ty": 2,
      "x": 790,
      "y": 39
    },
    {
      "t": 982048,
      "e": 29986,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 982077,
      "e": 30015,
      "ty": 41,
      "x": 38216,
      "y": 0,
      "ta": "> div.masterdiv"
    },
    {
      "t": 982126,
      "e": 30064,
      "ty": 2,
      "x": 797,
      "y": 8
    },
    {
      "t": 992142,
      "e": 35064,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 1950378,
      "e": 35064,
      "ty": 2,
      "x": 1029,
      "y": 106
    },
    {
      "t": 1950380,
      "e": 35066,
      "ty": 41,
      "x": 56605,
      "y": 2100,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 1950410,
      "e": 35096,
      "ty": 6,
      "x": 842,
      "y": 340,
      "ta": "#da1"
    },
    {
      "t": 1950426,
      "e": 35112,
      "ty": 7,
      "x": 766,
      "y": 459,
      "ta": "#da1"
    },
    {
      "t": 1950443,
      "e": 35129,
      "ty": 6,
      "x": 738,
      "y": 517,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 1950459,
      "e": 35145,
      "ty": 7,
      "x": 727,
      "y": 555,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 1950459,
      "e": 35145,
      "ty": 6,
      "x": 727,
      "y": 555,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 1950476,
      "e": 35162,
      "ty": 7,
      "x": 723,
      "y": 580,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 1950476,
      "e": 35162,
      "ty": 6,
      "x": 723,
      "y": 580,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 1950478,
      "e": 35164,
      "ty": 2,
      "x": 723,
      "y": 580
    },
    {
      "t": 1950628,
      "e": 35314,
      "ty": 41,
      "x": 34153,
      "y": 29256,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 1950661,
      "e": 35347,
      "ty": 7,
      "x": 720,
      "y": 608,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 1950677,
      "e": 35363,
      "ty": 2,
      "x": 720,
      "y": 630
    },
    {
      "t": 1950777,
      "e": 35463,
      "ty": 2,
      "x": 716,
      "y": 708
    },
    {
      "t": 1950794,
      "e": 35480,
      "ty": 6,
      "x": 716,
      "y": 712,
      "ta": "#start"
    },
    {
      "t": 1950877,
      "e": 35563,
      "ty": 2,
      "x": 716,
      "y": 719
    },
    {
      "t": 1950878,
      "e": 35564,
      "ty": 41,
      "x": 44509,
      "y": 17347,
      "ta": "#start"
    },
    {
      "t": 1950978,
      "e": 35664,
      "ty": 2,
      "x": 715,
      "y": 733
    },
    {
      "t": 1951080,
      "e": 35766,
      "ty": 2,
      "x": 714,
      "y": 732
    },
    {
      "t": 1951128,
      "e": 35814,
      "ty": 41,
      "x": 43416,
      "y": 42405,
      "ta": "#start"
    },
    {
      "t": 1951277,
      "e": 35963,
      "ty": 2,
      "x": 709,
      "y": 732
    },
    {
      "t": 1951378,
      "e": 36064,
      "ty": 2,
      "x": 707,
      "y": 732
    },
    {
      "t": 1951378,
      "e": 36064,
      "ty": 41,
      "x": 39594,
      "y": 42405,
      "ta": "#start"
    },
    {
      "t": 1951478,
      "e": 36164,
      "ty": 2,
      "x": 704,
      "y": 730
    },
    {
      "t": 1951579,
      "e": 36265,
      "ty": 2,
      "x": 703,
      "y": 730
    },
    {
      "t": 1951633,
      "e": 36319,
      "ty": 41,
      "x": 37409,
      "y": 38550,
      "ta": "#start"
    },
    {
      "t": 1952078,
      "e": 36764,
      "ty": 2,
      "x": 705,
      "y": 730
    },
    {
      "t": 1952093,
      "e": 36779,
      "ty": 7,
      "x": 726,
      "y": 690,
      "ta": "#start"
    },
    {
      "t": 1952128,
      "e": 36814,
      "ty": 41,
      "x": 45049,
      "y": 5851,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 1952174,
      "e": 36860,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 1952178,
      "e": 36864,
      "ty": 2,
      "x": 1090,
      "y": 32
    },
    {
      "t": 1952379,
      "e": 37065,
      "ty": 41,
      "x": 52408,
      "y": 2016,
      "ta": "> div.masterdiv"
    },
    {
      "t": 1957279,
      "e": 41965,
      "ty": 2,
      "x": 846,
      "y": 407
    },
    {
      "t": 1957293,
      "e": 41979,
      "ty": 6,
      "x": 780,
      "y": 514,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 1957310,
      "e": 41996,
      "ty": 7,
      "x": 741,
      "y": 583,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 1957310,
      "e": 41996,
      "ty": 6,
      "x": 741,
      "y": 583,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 1957327,
      "e": 42013,
      "ty": 7,
      "x": 727,
      "y": 610,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 1957378,
      "e": 42064,
      "ty": 2,
      "x": 710,
      "y": 640
    },
    {
      "t": 1957378,
      "e": 42064,
      "ty": 41,
      "x": 34531,
      "y": 62024,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 1957576,
      "e": 42262,
      "ty": 6,
      "x": 681,
      "y": 720,
      "ta": "#start"
    },
    {
      "t": 1957577,
      "e": 42263,
      "ty": 2,
      "x": 681,
      "y": 720
    },
    {
      "t": 1957610,
      "e": 42296,
      "ty": 7,
      "x": 671,
      "y": 746,
      "ta": "#start"
    },
    {
      "t": 1957628,
      "e": 42314,
      "ty": 41,
      "x": 23171,
      "y": 43690,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 1957678,
      "e": 42364,
      "ty": 2,
      "x": 663,
      "y": 767
    },
    {
      "t": 1957778,
      "e": 42464,
      "ty": 2,
      "x": 663,
      "y": 760
    },
    {
      "t": 1957878,
      "e": 42564,
      "ty": 2,
      "x": 659,
      "y": 748
    },
    {
      "t": 1957879,
      "e": 42565,
      "ty": 41,
      "x": 20830,
      "y": 31927,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 1957945,
      "e": 42631,
      "ty": 6,
      "x": 658,
      "y": 743,
      "ta": "#start"
    },
    {
      "t": 1957951,
      "e": 42637,
      "ty": 3,
      "x": 658,
      "y": 743,
      "ta": "#start"
    },
    {
      "t": 1957953,
      "e": 42639,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 1957979,
      "e": 42665,
      "ty": 2,
      "x": 658,
      "y": 743
    },
    {
      "t": 1958029,
      "e": 42715,
      "ty": 4,
      "x": 12833,
      "y": 63607,
      "ta": "#start"
    },
    {
      "t": 1958032,
      "e": 42718,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 1958034,
      "e": 42720,
      "ty": 5,
      "x": 658,
      "y": 743,
      "ta": "#start"
    },
    {
      "t": 1958037,
      "e": 42723,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 1958133,
      "e": 42819,
      "ty": 41,
      "x": 31483,
      "y": 61754,
      "ta": "html > body"
    },
    {
      "t": 1958378,
      "e": 43064,
      "ty": 2,
      "x": 641,
      "y": 691
    },
    {
      "t": 1958378,
      "e": 43064,
      "ty": 41,
      "x": 30660,
      "y": 57385,
      "ta": "html > body"
    },
    {
      "t": 1958477,
      "e": 43163,
      "ty": 2,
      "x": 477,
      "y": 513
    },
    {
      "t": 1958581,
      "e": 43267,
      "ty": 2,
      "x": 462,
      "y": 510
    },
    {
      "t": 1958628,
      "e": 43314,
      "ty": 41,
      "x": 21990,
      "y": 42177,
      "ta": "html > body"
    },
    {
      "t": 1959044,
      "e": 43730,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 1961384,
      "e": 46070,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 1962471,
      "e": 47157,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 1963481,
      "e": 48167,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":66,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":67,\"previousSibling\":{\"id\":66},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":68,\"textContent\":\" \",\"previousSibling\":{\"id\":67},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":69,\"textContent\":\" \",\"parentNode\":{\"id\":66}},{\"nodeType\":1,\"id\":70,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":69},\"parentNode\":{\"id\":66}},{\"nodeType\":3,\"id\":71,\"textContent\":\" \",\"previousSibling\":{\"id\":70},\"parentNode\":{\"id\":66}},{\"nodeType\":8,\"id\":72,\"previousSibling\":{\"id\":71},\"parentNode\":{\"id\":66}},{\"nodeType\":3,\"id\":73,\"textContent\":\" \",\"previousSibling\":{\"id\":72},\"parentNode\":{\"id\":66}},{\"nodeType\":1,\"id\":74,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":73},\"parentNode\":{\"id\":66}},{\"nodeType\":8,\"id\":75,\"previousSibling\":{\"id\":74},\"parentNode\":{\"id\":66}},{\"nodeType\":3,\"id\":76,\"textContent\":\" \",\"previousSibling\":{\"id\":75},\"parentNode\":{\"id\":66}},{\"nodeType\":1,\"id\":77,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":76},\"parentNode\":{\"id\":66}},{\"nodeType\":8,\"id\":78,\"previousSibling\":{\"id\":77},\"parentNode\":{\"id\":66}},{\"nodeType\":3,\"id\":79,\"textContent\":\" \",\"previousSibling\":{\"id\":78},\"parentNode\":{\"id\":66}},{\"nodeType\":3,\"id\":80,\"textContent\":\" \",\"parentNode\":{\"id\":70}},{\"nodeType\":1,\"id\":81,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":80},\"parentNode\":{\"id\":70}},{\"nodeType\":3,\"id\":82,\"textContent\":\" \",\"previousSibling\":{\"id\":81},\"parentNode\":{\"id\":70}},{\"nodeType\":3,\"id\":83,\"textContent\":\" \",\"parentNode\":{\"id\":81}},{\"nodeType\":1,\"id\":84,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":83},\"parentNode\":{\"id\":81}},{\"nodeType\":3,\"id\":85,\"textContent\":\" \",\"previousSibling\":{\"id\":84},\"parentNode\":{\"id\":81}},{\"nodeType\":3,\"id\":86,\"textContent\":\"UNIVERSITY OF CALIFORNIA, SAN DIEGO CONSENT TO ACT AS A RESEARCH SUBJECT\",\"parentNode\":{\"id\":84}},{\"nodeType\":3,\"id\":87,\"textContent\":\" \",\"parentNode\":{\"id\":74}},{\"nodeType\":1,\"id\":88,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":87},\"parentNode\":{\"id\":74}},{\"nodeType\":3,\"id\":89,\"textContent\":\" \",\"previousSibling\":{\"id\":88},\"parentNode\":{\"id\":74}},{\"nodeType\":3,\"id\":90,\"textContent\":\" \",\"parentNode\":{\"id\":88}},{\"nodeType\":1,\"id\":91,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":90},\"parentNode\":{\"id\":88}},{\"nodeType\":3,\"id\":92,\"textContent\":\" \",\"previousSibling\":{\"id\":91},\"parentNode\":{\"id\":88}},{\"nodeType\":1,\"id\":93,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":92},\"parentNode\":{\"id\":88}},{\"nodeType\":3,\"id\":94,\"textContent\":\" \",\"previousSibling\":{\"id\":93},\"parentNode\":{\"id\":88}},{\"nodeType\":1,\"id\":95,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":94},\"parentNode\":{\"id\":88}},{\"nodeType\":3,\"id\":96,\"textContent\":\" \",\"previousSibling\":{\"id\":95},\"parentNode\":{\"id\":88}},{\"nodeType\":1,\"id\":97,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":96},\"parentNode\":{\"id\":88}},{\"nodeType\":3,\"id\":98,\"textContent\":\" \",\"previousSibling\":{\"id\":97},\"parentNode\":{\"id\":88}},{\"nodeType\":8,\"id\":99,\"previousSibling\":{\"id\":98},\"parentNode\":{\"id\":88}},{\"nodeType\":3,\"id\":100,\"textContent\":\" \",\"previousSibling\":{\"id\":99},\"parentNode\":{\"id\":88}},{\"nodeType\":1,\"id\":101,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control-group centered\"},\"previousSibling\":{\"id\":100},\"parentNode\":{\"id\":88}},{\"nodeType\":3,\"id\":102,\"textContent\":\" \",\"previousSibling\":{\"id\":101},\"parentNode\":{\"id\":88}},{\"nodeType\":3,\"id\":103,\"textContent\":\" You are being invited to participate in a research study titled Learning Diagrams: Evaluating Learning With External Representations. This study is being done by Amy Fox and Dr. Jim Hollan from the University of California - San Diego (UCSD). You were selected to participate in this study because we think you might use graphs and diagrams in your work and educational activities.\",\"parentNode\":{\"id\":91}},{\"nodeType\":3,\"id\":104,\"textContent\":\" The purpose of this research study is to understand how humans try to make sense of charts, diagrams and graphs that are unconventional and that we may not have seen before. If you agree to take part in this study, you will be asked to read a series of instructions and answer a series of questions. The entire study should take no more than 60 minutes to complete. The researchers expect there will be no direct benefit to you from this research, other than any enjoyment you might have in contributing to research. We hope that you will find the questions interesting, though at times you may feel bored. The investigator(s), however, may learn more about how different types of instructions trigger different levels of understanding when using graphs. There are minimal risks associated with this research study, including a loss of confidentiality of your participation. The researchers are taking all required steps to protect your confidentiality, including storing all of your responses to questions in a secure, encrypted database separate from any information that can personally identify you. The only records containing your name and other personally identifying information are those stored in the system through which you signed up to participate in the study. These records will never be connected with the data we collect from you today. Research records will be kept confidential to the extent allowed by law and may be reviewed by the UCSD Institutional Review Board.\",\"parentNode\":{\"id\":93}},{\"nodeType\":3,\"id\":105,\"textContent\":\" Your participation in this study is completely voluntary and you can withdraw at any time by notifying the researcher that you wish to end your participation. Choosing not to participate or withdrawing will result in no penalty or loss of benefits to which you are entitled. You are free to skip any questions that you choose. If you have questions about this project or if you have a research-related problem, you may contact the researcher(s), Amy Fox: 919 886 4455: a2fox@ucsd.edu, and Jim Hollan: hollan@ucsd.edu. If you have any questions concerning your rights as a research subject, you may contact the UCSD Human Research Protections Program Office at 858-246-HRPP (858-246-4777). \",\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":106,\"textContent\":\" By clicking “I agree” below you are indicating that: you are at least 18 years old, have read this consent form, and agree to participate in this research study. If you do not wish to participate in the study, please notify the researcher now.\",\"parentNode\":{\"id\":97}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \",\"parentNode\":{\"id\":101}},{\"nodeType\":1,\"id\":108,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"centered control control-checkbox\"},\"previousSibling\":{\"id\":107},\"parentNode\":{\"id\":101}},{\"nodeType\":3,\"id\":109,\"textContent\":\" \",\"previousSibling\":{\"id\":108},\"parentNode\":{\"id\":101}},{\"nodeType\":3,\"id\":110,\"textContent\":\" I agree to take part in this study. \",\"parentNode\":{\"id\":108}},{\"nodeType\":1,\"id\":111,\"tagName\":\"INPUT\",\"attributes\":{\"id\":\"consent_checkbox\",\"type\":\"checkbox\"},\"previousSibling\":{\"id\":110},\"parentNode\":{\"id\":108}},{\"nodeType\":3,\"id\":112,\"textContent\":\" \",\"previousSibling\":{\"id\":111},\"parentNode\":{\"id\":108}},{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"},\"previousSibling\":{\"id\":112},\"parentNode\":{\"id\":108}},{\"nodeType\":3,\"id\":114,\"textContent\":\" \",\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":108}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \",\"parentNode\":{\"id\":77}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":77}},{\"nodeType\":3,\"id\":117,\"textContent\":\" \",\"previousSibling\":{\"id\":116},\"parentNode\":{\"id\":77}},{\"nodeType\":3,\"id\":118,\"textContent\":\"START\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":66},{\"id\":69},{\"id\":70},{\"id\":80},{\"id\":81},{\"id\":83},{\"id\":84},{\"id\":86},{\"id\":85},{\"id\":82},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":87},{\"id\":88},{\"id\":90},{\"id\":91},{\"id\":103},{\"id\":92},{\"id\":93},{\"id\":104},{\"id\":94},{\"id\":95},{\"id\":105},{\"id\":96},{\"id\":97},{\"id\":106},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":107},{\"id\":108},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":109},{\"id\":102},{\"id\":89},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":115},{\"id\":116},{\"id\":118},{\"id\":117},{\"id\":78},{\"id\":79},{\"id\":67},{\"id\":68}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":119,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":120,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":121,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":120},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":122,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":121},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":123,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":119}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":123}},{\"nodeType\":1,\"id\":125,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":120}},{\"nodeType\":1,\"id\":126,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":125},\"parentNode\":{\"id\":120}},{\"nodeType\":3,\"id\":127,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":125}},{\"nodeType\":1,\"id\":128,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":121}},{\"nodeType\":1,\"id\":129,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":121}},{\"nodeType\":3,\"id\":130,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":131,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":122}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":119},{\"id\":123},{\"id\":124},{\"id\":120},{\"id\":125},{\"id\":127},{\"id\":126},{\"id\":121},{\"id\":128},{\"id\":130},{\"id\":129},{\"id\":122},{\"id\":131}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":132,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":133,\"textContent\":\" \",\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":134,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":135,\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":136,\"textContent\":\" \",\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":132}},{\"nodeType\":3,\"id\":138,\"textContent\":\" \",\"parentNode\":{\"id\":134}},{\"nodeType\":1,\"id\":139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":134}},{\"nodeType\":8,\"id\":140,\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":134}},{\"nodeType\":3,\"id\":141,\"textContent\":\" \",\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":134}},{\"nodeType\":1,\"id\":142,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":134}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"previousSibling\":{\"id\":142},\"parentNode\":{\"id\":134}},{\"nodeType\":8,\"id\":144,\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":134}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":134}},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":145},\"parentNode\":{\"id\":134}},{\"nodeType\":8,\"id\":147,\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":134}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":134}},{\"nodeType\":3,\"id\":149,\"textContent\":\" \",\"parentNode\":{\"id\":139}},{\"nodeType\":1,\"id\":150,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":149},\"parentNode\":{\"id\":139}},{\"nodeType\":3,\"id\":151,\"textContent\":\" \",\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":139}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"parentNode\":{\"id\":150}},{\"nodeType\":1,\"id\":153,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":150}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":150}},{\"nodeType\":3,\"id\":155,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":153}},{\"nodeType\":3,\"id\":156,\"textContent\":\" \",\"parentNode\":{\"id\":142}},{\"nodeType\":1,\"id\":157,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":142}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":142}},{\"nodeType\":8,\"id\":159,\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":142}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":142}},{\"nodeType\":3,\"id\":161,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":162,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":163,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":157}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":165,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":164},\"parentNode\":{\"id\":157}},{\"nodeType\":3,\"id\":166,\"textContent\":\" \",\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":167,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":157}},{\"nodeType\":3,\"id\":168,\"textContent\":\" \",\"previousSibling\":{\"id\":167},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":169,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":168},\"parentNode\":{\"id\":157}},{\"nodeType\":3,\"id\":170,\"textContent\":\" \",\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":3,\"id\":171,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":162}},{\"nodeType\":1,\"id\":172,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":162}},{\"nodeType\":3,\"id\":173,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":162}},{\"nodeType\":3,\"id\":174,\"textContent\":\"all\",\"parentNode\":{\"id\":172}},{\"nodeType\":3,\"id\":175,\"textContent\":\" \",\"parentNode\":{\"id\":163}},{\"nodeType\":1,\"id\":176,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":163}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":176}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":176}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":176}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":176}},{\"nodeType\":1,\"id\":181,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":180},\"parentNode\":{\"id\":176}},{\"nodeType\":3,\"id\":182,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":176}},{\"nodeType\":1,\"id\":183,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":176}},{\"nodeType\":3,\"id\":184,\"textContent\":\" \",\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":176}},{\"nodeType\":1,\"id\":185,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":176}},{\"nodeType\":3,\"id\":186,\"textContent\":\" \",\"previousSibling\":{\"id\":185},\"parentNode\":{\"id\":176}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":188,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":187},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":189,\"textContent\":\" \",\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":190,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":191,\"textContent\":\" \",\"previousSibling\":{\"id\":190},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":192,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":188}},{\"nodeType\":3,\"id\":193,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":190}},{\"nodeType\":3,\"id\":194,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":195,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":196,\"textContent\":\" \",\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":197,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":195}},{\"nodeType\":3,\"id\":198,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":197}},{\"nodeType\":3,\"id\":199,\"textContent\":\" \",\"parentNode\":{\"id\":183}},{\"nodeType\":1,\"id\":200,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":199},\"parentNode\":{\"id\":183}},{\"nodeType\":3,\"id\":201,\"textContent\":\" \",\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":183}},{\"nodeType\":1,\"id\":202,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":183}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \",\"previousSibling\":{\"id\":202},\"parentNode\":{\"id\":183}},{\"nodeType\":1,\"id\":204,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":200}},{\"nodeType\":3,\"id\":205,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":202}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"parentNode\":{\"id\":185}},{\"nodeType\":1,\"id\":207,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":206},\"parentNode\":{\"id\":185}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \",\"previousSibling\":{\"id\":207},\"parentNode\":{\"id\":185}},{\"nodeType\":1,\"id\":209,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":207}},{\"nodeType\":3,\"id\":210,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":211,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":165}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":165}},{\"nodeType\":3,\"id\":213,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"parentNode\":{\"id\":167}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":167}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":167}},{\"nodeType\":1,\"id\":217,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":216},\"parentNode\":{\"id\":167}},{\"nodeType\":3,\"id\":218,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":167}},{\"nodeType\":1,\"id\":219,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":167}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":167}},{\"nodeType\":1,\"id\":221,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":220},\"parentNode\":{\"id\":167}},{\"nodeType\":3,\"id\":222,\"textContent\":\" \",\"previousSibling\":{\"id\":221},\"parentNode\":{\"id\":167}},{\"nodeType\":1,\"id\":223,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":224,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":223},\"parentNode\":{\"id\":215}},{\"nodeType\":1,\"id\":225,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":226,\"textContent\":\" \",\"previousSibling\":{\"id\":225},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"carefully\",\"parentNode\":{\"id\":225}},{\"nodeType\":1,\"id\":228,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":217}},{\"nodeType\":3,\"id\":229,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":228},\"parentNode\":{\"id\":217}},{\"nodeType\":1,\"id\":230,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":219}},{\"nodeType\":3,\"id\":231,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":232,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":221}},{\"nodeType\":3,\"id\":233,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":232},\"parentNode\":{\"id\":221}},{\"nodeType\":3,\"id\":234,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":169}},{\"nodeType\":3,\"id\":235,\"textContent\":\" \\t\",\"parentNode\":{\"id\":146}},{\"nodeType\":1,\"id\":236,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":235},\"parentNode\":{\"id\":146}},{\"nodeType\":3,\"id\":237,\"textContent\":\" \",\"previousSibling\":{\"id\":236},\"parentNode\":{\"id\":146}},{\"nodeType\":3,\"id\":238,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":236}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":132},{\"id\":137},{\"id\":133},{\"id\":134},{\"id\":138},{\"id\":139},{\"id\":149},{\"id\":150},{\"id\":152},{\"id\":153},{\"id\":155},{\"id\":154},{\"id\":151},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":156},{\"id\":157},{\"id\":161},{\"id\":162},{\"id\":171},{\"id\":172},{\"id\":174},{\"id\":173},{\"id\":163},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":187},{\"id\":188},{\"id\":192},{\"id\":189},{\"id\":190},{\"id\":193},{\"id\":191},{\"id\":178},{\"id\":179},{\"id\":194},{\"id\":195},{\"id\":197},{\"id\":198},{\"id\":196},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":199},{\"id\":200},{\"id\":204},{\"id\":201},{\"id\":202},{\"id\":205},{\"id\":203},{\"id\":184},{\"id\":185},{\"id\":206},{\"id\":207},{\"id\":209},{\"id\":210},{\"id\":208},{\"id\":186},{\"id\":164},{\"id\":165},{\"id\":211},{\"id\":213},{\"id\":212},{\"id\":166},{\"id\":167},{\"id\":214},{\"id\":215},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":227},{\"id\":226},{\"id\":216},{\"id\":217},{\"id\":228},{\"id\":229},{\"id\":218},{\"id\":219},{\"id\":230},{\"id\":231},{\"id\":220},{\"id\":221},{\"id\":232},{\"id\":233},{\"id\":222},{\"id\":168},{\"id\":169},{\"id\":234},{\"id\":170},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":235},{\"id\":236},{\"id\":238},{\"id\":237},{\"id\":147},{\"id\":148},{\"id\":135},{\"id\":136}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":239,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":240,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":239},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":241,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":240}}],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":239},{\"id\":240},{\"id\":241}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"ambiance-notification\"}},{\"nodeType\":1,\"id\":60,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"blue_light_filter\",\"style\":\"width: 100%; height: 100%; z-index: 2147483646; transition: -webkit-transform 10s ease-in-out; position: fixed !important; left: 0px !important; bottom: 0px !important; overflow: hidden !important; pointer-events: none !important; background: rgb(214, 107, 0); opacity: 0;\"}},{\"nodeType\":1,\"id\":61,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"blf_status\",\"style\":\"position: fixed !important; width: 105px; height: 27px;\\tcolor: white; text-shadow: 1px 2px 4px #000; font-size: 20px;\\tfont-weight: bold; background-color: blue; z-index: 2147483647;\\tright: 0px; top: 0px; display:none; font-family: arial,sans-serif; text-align: center;\"}},{\"nodeType\":1,\"id\":62,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}},{\"nodeType\":1,\"id\":63,\"tagName\":\"SPAN\",\"attributes\":{\"style\":\"border-radius: 3px; text-indent: 20px; width: auto; padding: 0px 4px 0px 0px; text-align: center; font-style: normal; font-variant: normal; font-weight: bold; font-stretch: normal; font-size: 11px; line-height: 20px; font-family: \\\"Helvetica Neue\\\", Helvetica, sans-serif; color: rgb(255, 255, 255); background: url(\\\"data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIGhlaWdodD0iMzBweCIgd2lkdGg9IjMwcHgiIHZpZXdCb3g9Ii0xIC0xIDMxIDMxIj48Zz48cGF0aCBkPSJNMjkuNDQ5LDE0LjY2MiBDMjkuNDQ5LDIyLjcyMiAyMi44NjgsMjkuMjU2IDE0Ljc1LDI5LjI1NiBDNi42MzIsMjkuMjU2IDAuMDUxLDIyLjcyMiAwLjA1MSwxNC42NjIgQzAuMDUxLDYuNjAxIDYuNjMyLDAuMDY3IDE0Ljc1LDAuMDY3IEMyMi44NjgsMC4wNjcgMjkuNDQ5LDYuNjAxIDI5LjQ0OSwxNC42NjIiIGZpbGw9IiNmZmYiIHN0cm9rZT0iI2ZmZiIgc3Ryb2tlLXdpZHRoPSIxIj48L3BhdGg+PHBhdGggZD0iTTE0LjczMywxLjY4NiBDNy41MTYsMS42ODYgMS42NjUsNy40OTUgMS42NjUsMTQuNjYyIEMxLjY2NSwyMC4xNTkgNS4xMDksMjQuODU0IDkuOTcsMjYuNzQ0IEM5Ljg1NiwyNS43MTggOS43NTMsMjQuMTQzIDEwLjAxNiwyMy4wMjIgQzEwLjI1MywyMi4wMSAxMS41NDgsMTYuNTcyIDExLjU0OCwxNi41NzIgQzExLjU0OCwxNi41NzIgMTEuMTU3LDE1Ljc5NSAxMS4xNTcsMTQuNjQ2IEMxMS4xNTcsMTIuODQyIDEyLjIxMSwxMS40OTUgMTMuNTIyLDExLjQ5NSBDMTQuNjM3LDExLjQ5NSAxNS4xNzUsMTIuMzI2IDE1LjE3NSwxMy4zMjMgQzE1LjE3NSwxNC40MzYgMTQuNDYyLDE2LjEgMTQuMDkzLDE3LjY0MyBDMTMuNzg1LDE4LjkzNSAxNC43NDUsMTkuOTg4IDE2LjAyOCwxOS45ODggQzE4LjM1MSwxOS45ODggMjAuMTM2LDE3LjU1NiAyMC4xMzYsMTQuMDQ2IEMyMC4xMzYsMTAuOTM5IDE3Ljg4OCw4Ljc2NyAxNC42NzgsOC43NjcgQzEwLjk1OSw4Ljc2NyA4Ljc3NywxMS41MzYgOC43NzcsMTQuMzk4IEM4Ljc3NywxNS41MTMgOS4yMSwxNi43MDkgOS43NDksMTcuMzU5IEM5Ljg1NiwxNy40ODggOS44NzIsMTcuNiA5Ljg0LDE3LjczMSBDOS43NDEsMTguMTQxIDkuNTIsMTkuMDIzIDkuNDc3LDE5LjIwMyBDOS40MiwxOS40NCA5LjI4OCwxOS40OTEgOS4wNCwxOS4zNzYgQzcuNDA4LDE4LjYyMiA2LjM4NywxNi4yNTIgNi4zODcsMTQuMzQ5IEM2LjM4NywxMC4yNTYgOS4zODMsNi40OTcgMTUuMDIyLDYuNDk3IEMxOS41NTUsNi40OTcgMjMuMDc4LDkuNzA1IDIzLjA3OCwxMy45OTEgQzIzLjA3OCwxOC40NjMgMjAuMjM5LDIyLjA2MiAxNi4yOTcsMjIuMDYyIEMxNC45NzMsMjIuMDYyIDEzLjcyOCwyMS4zNzkgMTMuMzAyLDIwLjU3MiBDMTMuMzAyLDIwLjU3MiAxMi42NDcsMjMuMDUgMTIuNDg4LDIzLjY1NyBDMTIuMTkzLDI0Ljc4NCAxMS4zOTYsMjYuMTk2IDEwLjg2MywyNy4wNTggQzEyLjA4NiwyNy40MzQgMTMuMzg2LDI3LjYzNyAxNC43MzMsMjcuNjM3IEMyMS45NSwyNy42MzcgMjcuODAxLDIxLjgyOCAyNy44MDEsMTQuNjYyIEMyNy44MDEsNy40OTUgMjEuOTUsMS42ODYgMTQuNzMzLDEuNjg2IiBmaWxsPSIjYmQwODFjIj48L3BhdGg+PC9nPjwvc3ZnPg==\\\") 3px 50% / 14px 14px no-repeat rgb(189, 8, 28); position: absolute; opacity: 1; z-index: 8675309; display: none; cursor: pointer; border: none; -webkit-font-smoothing: antialiased;\"},\"childNodes\":[{\"nodeType\":3,\"id\":64,\"textContent\":\"Save\"}]},{\"nodeType\":1,\"id\":65,\"tagName\":\"SPAN\",\"attributes\":{\"style\":\"width: 24px; height: 24px; background: url(\\\"data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiA/Pjxzdmcgd2lkdGg9IjI0cHgiIGhlaWdodD0iMjRweCIgdmlld0JveD0iMCAwIDI0IDI0IiB2ZXJzaW9uPSIxLjEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiPjxkZWZzPjxtYXNrIGlkPSJtIj48cmVjdCBmaWxsPSIjZmZmIiB4PSIwIiB5PSIwIiB3aWR0aD0iMjQiIGhlaWdodD0iMjQiIHJ4PSI2IiByeT0iNiIvPjxyZWN0IGZpbGw9IiMwMDAiIHg9IjUiIHk9IjUiIHdpZHRoPSIxNCIgaGVpZ2h0PSIxNCIgcng9IjEiIHJ5PSIxIi8+PHJlY3QgZmlsbD0iIzAwMCIgeD0iMTAiIHk9IjAiIHdpZHRoPSI0IiBoZWlnaHQ9IjI0Ii8+PHJlY3QgZmlsbD0iIzAwMCIgeD0iMCIgeT0iMTAiIHdpZHRoPSIyNCIgaGVpZ2h0PSI0Ii8+PC9tYXNrPjwvZGVmcz48cmVjdCB4PSIwIiB5PSIwIiB3aWR0aD0iMjQiIGhlaWdodD0iMjQiIGZpbGw9IiNmZmYiIG1hc2s9InVybCgjbSkiLz48L3N2Zz4=\\\") 50% 50% / 14px 14px no-repeat rgba(0, 0, 0, 0.4); position: absolute; opacity: 1; z-index: 8675309; display: none; cursor: pointer; border: none; border-radius: 12px;\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 189, dom: 860, initialDom: 897",
  "javascriptErrors": []
}