var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "c69164193cbb4c050a7be6853dda73d3",
  "created": "2018-05-21T08:34:47.5519896-07:00",
  "lastActivity": "2018-05-21T09:07:30.8819826-07:00",
  "pageViews": [
    {
      "id": "052159240fa509c6c520462bafbd1b03d4453de2",
      "startTime": "2018-05-21T08:34:47.5519896-07:00",
      "endTime": "2018-05-21T09:07:30.8819826-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 1963481,
      "engagementTime": 48167,
      "scroll": 97.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 1963481,
  "engagementTime": 48167,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "69.196.34.183",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.139",
  "os": "macOS",
  "osVersion": "10.12 Sierra",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1440x900",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "a095ac515983084c6e60136215a85e6e",
  "gdpr": false
}