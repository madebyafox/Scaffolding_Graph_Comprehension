var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "0f311e9a9dd2efeef4beefb268b172c8",
  "created": "2018-05-21T13:18:03.9293253-07:00",
  "lastActivity": "2018-05-21T13:19:18.4861823-07:00",
  "pageViews": [
    {
      "id": "05210401ed1acdf54104f133a5fc9c76189ccbb0",
      "startTime": "2018-05-21T13:18:03.9293253-07:00",
      "endTime": "2018-05-21T13:19:18.4861823-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/15",
      "visitTime": 74565,
      "engagementTime": 74514,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 74565,
  "engagementTime": 74514,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=FJV2A",
    "CONDITION=113"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "5f7abc381bc3a4f4e544b126a6820390",
  "gdpr": false
}