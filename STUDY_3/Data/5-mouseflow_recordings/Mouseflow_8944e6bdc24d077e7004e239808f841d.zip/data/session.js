var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "8944e6bdc24d077e7004e239808f841d",
  "created": "2018-05-21T12:12:32.0384902-07:00",
  "lastActivity": "2018-05-21T12:12:58.1794902-07:00",
  "pageViews": [
    {
      "id": "0521322336efd5e0bf56db7d62335bb07b78bb59",
      "startTime": "2018-05-21T12:12:32.0384902-07:00",
      "endTime": "2018-05-21T12:12:58.1794902-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/7",
      "visitTime": 26141,
      "engagementTime": 18938,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 26141,
  "engagementTime": 18938,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.28",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=CC7G0",
    "CONDITION=111",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "9f99bef7d64e50a88905ab134a4aa3fe",
  "gdpr": false
}