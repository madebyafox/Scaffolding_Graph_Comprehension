var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "70a2c915da4ab39a8c1f36891d06a22f",
  "created": "2018-06-01T10:12:26.5648433-07:00",
  "lastActivity": "2018-06-01T10:12:34.5605313-07:00",
  "pageViews": [
    {
      "id": "06012633e74f951e4bb9c1a5e07fb68e322b9dd2",
      "startTime": "2018-06-01T10:12:26.5965313-07:00",
      "endTime": "2018-06-01T10:12:34.5605313-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/12",
      "visitTime": 7964,
      "engagementTime": 7948,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 7964,
  "engagementTime": 7948,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.25",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=GZ705",
    "CONDITION=115",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "62da89caf8fd547177da74edce64c809",
  "gdpr": false
}