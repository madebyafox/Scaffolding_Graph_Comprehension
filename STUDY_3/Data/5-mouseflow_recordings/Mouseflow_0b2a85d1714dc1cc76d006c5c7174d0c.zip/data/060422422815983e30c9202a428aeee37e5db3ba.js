var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["060422422815983e30c9202a428aeee37e5db3ba"] = {
  "startTime": "2018-06-04T19:17:22.0549785Z",
  "websitePageUrl": "/16",
  "visitTime": 109226,
  "engagementTime": 103842,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "0b2a85d1714dc1cc76d006c5c7174d0c",
    "created": "2018-06-04T19:17:22.0182104+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=ZEPVG",
      "CONDITION=311"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "607f270ac11e3b24bd2517815d539c17",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/0b2a85d1714dc1cc76d006c5c7174d0c/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 259,
      "e": 259,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 259,
      "e": 259,
      "ty": 2,
      "x": 1115,
      "y": 319
    },
    {
      "t": 260,
      "e": 260,
      "ty": 41,
      "x": 23184,
      "y": 12963,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 400,
      "e": 400,
      "ty": 2,
      "x": 1115,
      "y": 318
    },
    {
      "t": 500,
      "e": 500,
      "ty": 2,
      "x": 1115,
      "y": 317
    },
    {
      "t": 501,
      "e": 501,
      "ty": 41,
      "x": 23184,
      "y": 12820,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 700,
      "e": 700,
      "ty": 2,
      "x": 1113,
      "y": 317
    },
    {
      "t": 751,
      "e": 751,
      "ty": 41,
      "x": 22973,
      "y": 12605,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 843,
      "e": 843,
      "ty": 2,
      "x": 1112,
      "y": 314
    },
    {
      "t": 1101,
      "e": 1101,
      "ty": 2,
      "x": 810,
      "y": 296
    },
    {
      "t": 1200,
      "e": 1200,
      "ty": 2,
      "x": 287,
      "y": 208
    },
    {
      "t": 1251,
      "e": 1251,
      "ty": 41,
      "x": 21347,
      "y": 11079,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1401,
      "e": 1401,
      "ty": 2,
      "x": 286,
      "y": 222
    },
    {
      "t": 1500,
      "e": 1500,
      "ty": 2,
      "x": 358,
      "y": 482
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 41,
      "x": 29328,
      "y": 2154,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 1565,
      "e": 1565,
      "ty": 6,
      "x": 377,
      "y": 525,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1601,
      "e": 1601,
      "ty": 2,
      "x": 379,
      "y": 527
    },
    {
      "t": 1700,
      "e": 1700,
      "ty": 2,
      "x": 405,
      "y": 557
    },
    {
      "t": 1750,
      "e": 1750,
      "ty": 41,
      "x": 34611,
      "y": 27723,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1806,
      "e": 1806,
      "ty": 3,
      "x": 405,
      "y": 557,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1808,
      "e": 1808,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1966,
      "e": 1966,
      "ty": 4,
      "x": 34611,
      "y": 27723,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1966,
      "e": 1966,
      "ty": 5,
      "x": 405,
      "y": 557,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2501,
      "e": 2501,
      "ty": 2,
      "x": 406,
      "y": 555
    },
    {
      "t": 2501,
      "e": 2501,
      "ty": 41,
      "x": 34724,
      "y": 26105,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2601,
      "e": 2601,
      "ty": 2,
      "x": 406,
      "y": 552
    },
    {
      "t": 2701,
      "e": 2701,
      "ty": 2,
      "x": 406,
      "y": 551
    },
    {
      "t": 2751,
      "e": 2751,
      "ty": 41,
      "x": 34724,
      "y": 21250,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2801,
      "e": 2801,
      "ty": 2,
      "x": 406,
      "y": 549
    },
    {
      "t": 2900,
      "e": 2900,
      "ty": 2,
      "x": 406,
      "y": 547
    },
    {
      "t": 3000,
      "e": 3000,
      "ty": 2,
      "x": 406,
      "y": 542
    },
    {
      "t": 3001,
      "e": 3001,
      "ty": 41,
      "x": 34724,
      "y": 15587,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3100,
      "e": 3100,
      "ty": 2,
      "x": 406,
      "y": 540
    },
    {
      "t": 3201,
      "e": 3201,
      "ty": 2,
      "x": 406,
      "y": 539
    },
    {
      "t": 3251,
      "e": 3251,
      "ty": 41,
      "x": 34724,
      "y": 13160,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5301,
      "e": 5301,
      "ty": 2,
      "x": 405,
      "y": 539
    },
    {
      "t": 5501,
      "e": 5501,
      "ty": 41,
      "x": 34611,
      "y": 13160,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6307,
      "e": 6307,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 6434,
      "e": 6434,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 6434,
      "e": 6434,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6578,
      "e": 6578,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "S"
    },
    {
      "t": 6625,
      "e": 6625,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 6626,
      "e": 6626,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6658,
      "e": 6658,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Se"
    },
    {
      "t": 6722,
      "e": 6722,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Se"
    },
    {
      "t": 6771,
      "e": 6771,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 6771,
      "e": 6771,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6883,
      "e": 6883,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "See"
    },
    {
      "t": 7091,
      "e": 7091,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 7091,
      "e": 7091,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7194,
      "e": 7194,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Seee"
    },
    {
      "t": 7787,
      "e": 7787,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 7849,
      "e": 7849,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "See"
    },
    {
      "t": 8395,
      "e": 8395,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 8450,
      "e": 8450,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Se"
    },
    {
      "t": 8522,
      "e": 8522,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 8585,
      "e": 8585,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "S"
    },
    {
      "t": 8649,
      "e": 8649,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 8697,
      "e": 8697,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 8803,
      "e": 8803,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 8866,
      "e": 8866,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 8962,
      "e": 8962,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 8963,
      "e": 8963,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9026,
      "e": 9026,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Y"
    },
    {
      "t": 9218,
      "e": 9218,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Y"
    },
    {
      "t": 9498,
      "e": 9498,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 9554,
      "e": 9554,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": ""
    },
    {
      "t": 9826,
      "e": 9826,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 9914,
      "e": 9914,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 9915,
      "e": 9915,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9977,
      "e": 9977,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Y"
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Y"
    },
    {
      "t": 10106,
      "e": 10106,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 10106,
      "e": 10106,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10162,
      "e": 10162,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 10162,
      "e": 10162,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10233,
      "e": 10233,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You"
    },
    {
      "t": 10299,
      "e": 10299,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You"
    },
    {
      "t": 10370,
      "e": 10370,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 10370,
      "e": 10370,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10466,
      "e": 10466,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You "
    },
    {
      "t": 10505,
      "e": 10505,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 10506,
      "e": 10506,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10610,
      "e": 10610,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 10626,
      "e": 10626,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 10627,
      "e": 10627,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10738,
      "e": 10738,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 10738,
      "e": 10738,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 10738,
      "e": 10738,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10817,
      "e": 10817,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 10954,
      "e": 10954,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 10955,
      "e": 10955,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10977,
      "e": 10977,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 10977,
      "e": 10977,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11057,
      "e": 11057,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||st"
    },
    {
      "t": 11097,
      "e": 11097,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11097,
      "e": 11097,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11113,
      "e": 11113,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 11186,
      "e": 11186,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 11266,
      "e": 11266,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 11267,
      "e": 11267,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11345,
      "e": 11345,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 11410,
      "e": 11410,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 11410,
      "e": 11410,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11498,
      "e": 11498,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 11506,
      "e": 11506,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 11506,
      "e": 11506,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11585,
      "e": 11585,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 11666,
      "e": 11666,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 11666,
      "e": 11666,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11730,
      "e": 11730,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 11754,
      "e": 11754,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 11755,
      "e": 11755,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11826,
      "e": 11826,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 11906,
      "e": 11906,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 11907,
      "e": 11907,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11978,
      "e": 11978,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 11979,
      "e": 11979,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12041,
      "e": 12041,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 12041,
      "e": 12041,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12098,
      "e": 12098,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||lat"
    },
    {
      "t": 12105,
      "e": 12105,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12145,
      "e": 12145,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12218,
      "e": 12218,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 12219,
      "e": 12219,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12306,
      "e": 12306,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12307,
      "e": 12307,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12338,
      "e": 12338,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 12402,
      "e": 12402,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12890,
      "e": 12890,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13002,
      "e": 13002,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first calculate"
    },
    {
      "t": 13390,
      "e": 13390,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13423,
      "e": 13423,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13456,
      "e": 13456,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13488,
      "e": 13488,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13522,
      "e": 13522,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13554,
      "e": 13554,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13587,
      "e": 13587,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13621,
      "e": 13621,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13654,
      "e": 13654,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13686,
      "e": 13686,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13719,
      "e": 13719,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13753,
      "e": 13753,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 13777,
      "e": 13777,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You fir"
    },
    {
      "t": 14426,
      "e": 14426,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 14427,
      "e": 14427,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14513,
      "e": 14513,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 14513,
      "e": 14513,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14553,
      "e": 14553,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||st"
    },
    {
      "t": 14625,
      "e": 14625,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14626,
      "e": 14626,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14641,
      "e": 14641,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 14714,
      "e": 14714,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14762,
      "e": 14762,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 14762,
      "e": 14762,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14833,
      "e": 14833,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 14833,
      "e": 14833,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14873,
      "e": 14873,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||se"
    },
    {
      "t": 14945,
      "e": 14945,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 15026,
      "e": 15026,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 15027,
      "e": 15027,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15137,
      "e": 15137,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 15137,
      "e": 15137,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15138,
      "e": 15138,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15202,
      "e": 15202,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 15250,
      "e": 15250,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 15251,
      "e": 15251,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15322,
      "e": 15322,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 15323,
      "e": 15323,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15338,
      "e": 15338,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 15418,
      "e": 15418,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 15441,
      "e": 15441,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 15442,
      "e": 15442,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15514,
      "e": 15514,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15514,
      "e": 15514,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15538,
      "e": 15538,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 15594,
      "e": 15594,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 15658,
      "e": 15658,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 15659,
      "e": 15659,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15705,
      "e": 15705,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 15705,
      "e": 15705,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15745,
      "e": 15745,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||st"
    },
    {
      "t": 15786,
      "e": 15786,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 15938,
      "e": 15938,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 15939,
      "e": 15939,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16001,
      "e": 16001,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 16074,
      "e": 16074,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 16075,
      "e": 16075,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16114,
      "e": 16114,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 16266,
      "e": 16266,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16321,
      "e": 16321,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see the str"
    },
    {
      "t": 16393,
      "e": 16393,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16457,
      "e": 16457,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see the st"
    },
    {
      "t": 16538,
      "e": 16538,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 16539,
      "e": 16539,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16594,
      "e": 16594,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 16595,
      "e": 16595,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16657,
      "e": 16657,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 16713,
      "e": 16713,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 16809,
      "e": 16809,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 16810,
      "e": 16810,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16906,
      "e": 16906,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 16938,
      "e": 16938,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 16939,
      "e": 16939,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17081,
      "e": 17081,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 17082,
      "e": 17082,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17097,
      "e": 17097,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 17098,
      "e": 17098,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17114,
      "e": 17114,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ign"
    },
    {
      "t": 17146,
      "e": 17146,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17241,
      "e": 17241,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17465,
      "e": 17465,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 17530,
      "e": 17530,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see the startig"
    },
    {
      "t": 17603,
      "e": 17603,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 17649,
      "e": 17649,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see the starti"
    },
    {
      "t": 17803,
      "e": 17803,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see the starti"
    },
    {
      "t": 17811,
      "e": 17811,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 17812,
      "e": 17812,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17865,
      "e": 17865,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 17889,
      "e": 17889,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 17889,
      "e": 17889,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18002,
      "e": 18002,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see the starting"
    },
    {
      "t": 18010,
      "e": 18010,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 18075,
      "e": 18075,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18075,
      "e": 18075,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18161,
      "e": 18161,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 18162,
      "e": 18162,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18169,
      "e": 18169,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 18258,
      "e": 18258,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18266,
      "e": 18266,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 18266,
      "e": 18266,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18369,
      "e": 18369,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 18371,
      "e": 18371,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18410,
      "e": 18410,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||im"
    },
    {
      "t": 18450,
      "e": 18450,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 18451,
      "e": 18451,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18473,
      "e": 18473,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 18553,
      "e": 18553,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18553,
      "e": 18553,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18585,
      "e": 18585,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18633,
      "e": 18633,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18641,
      "e": 18641,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 18641,
      "e": 18641,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18761,
      "e": 18761,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 18761,
      "e": 18761,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18785,
      "e": 18785,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||of"
    },
    {
      "t": 18873,
      "e": 18873,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18882,
      "e": 18882,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18882,
      "e": 18882,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18969,
      "e": 18969,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 19618,
      "e": 19618,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 19619,
      "e": 19619,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19713,
      "e": 19713,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 19722,
      "e": 19722,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 19722,
      "e": 19722,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19841,
      "e": 19841,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 19842,
      "e": 19842,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 19843,
      "e": 19843,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19938,
      "e": 19938,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19938,
      "e": 19938,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19946,
      "e": 19946,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 20018,
      "e": 20018,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20066,
      "e": 20066,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 20067,
      "e": 20067,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20129,
      "e": 20129,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 20130,
      "e": 20130,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20169,
      "e": 20169,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||di"
    },
    {
      "t": 20282,
      "e": 20282,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20289,
      "e": 20289,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 20290,
      "e": 20290,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20346,
      "e": 20346,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 20434,
      "e": 20434,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 20435,
      "e": 20435,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20497,
      "e": 20497,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 20578,
      "e": 20578,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 20578,
      "e": 20578,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20666,
      "e": 20666,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 20666,
      "e": 20666,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20692,
      "e": 20692,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 20778,
      "e": 20778,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20785,
      "e": 20785,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 20786,
      "e": 20786,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20874,
      "e": 20874,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 20874,
      "e": 20874,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20881,
      "e": 20881,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||en"
    },
    {
      "t": 20969,
      "e": 20969,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20971,
      "e": 20971,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 20974,
      "e": 20974,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21073,
      "e": 21073,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 21081,
      "e": 21081,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21081,
      "e": 21081,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21137,
      "e": 21137,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 21161,
      "e": 21161,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 21162,
      "e": 21162,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21258,
      "e": 21258,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 21259,
      "e": 21259,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21305,
      "e": 21305,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||po"
    },
    {
      "t": 21377,
      "e": 21377,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21498,
      "e": 21498,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 21499,
      "e": 21499,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21601,
      "e": 21601,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see the starting time of the different poi"
    },
    {
      "t": 21609,
      "e": 21609,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 21610,
      "e": 21610,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21665,
      "e": 21665,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 21681,
      "e": 21681,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 21682,
      "e": 21682,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21746,
      "e": 21746,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 21778,
      "e": 21778,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21842,
      "e": 21842,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 21843,
      "e": 21843,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21946,
      "e": 21946,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 21946,
      "e": 21946,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21947,
      "e": 21947,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22034,
      "e": 22034,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 22034,
      "e": 22034,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22049,
      "e": 22049,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| a"
    },
    {
      "t": 22121,
      "e": 22121,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 22121,
      "e": 22121,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22129,
      "e": 22129,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 22217,
      "e": 22217,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 22218,
      "e": 22218,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22225,
      "e": 22225,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 22281,
      "e": 22281,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22306,
      "e": 22306,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22306,
      "e": 22306,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22385,
      "e": 22385,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 22385,
      "e": 22385,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22426,
      "e": 22426,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 22441,
      "e": 22441,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 22441,
      "e": 22441,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22466,
      "e": 22466,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 22514,
      "e": 22514,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22562,
      "e": 22562,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 22563,
      "e": 22563,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22633,
      "e": 22633,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 22634,
      "e": 22634,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22681,
      "e": 22681,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||en"
    },
    {
      "t": 22738,
      "e": 22738,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 22778,
      "e": 22778,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22778,
      "e": 22778,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22850,
      "e": 22850,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22890,
      "e": 22890,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 22891,
      "e": 22891,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22961,
      "e": 22961,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 22961,
      "e": 22961,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22993,
      "e": 22993,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ad"
    },
    {
      "t": 23066,
      "e": 23066,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23162,
      "e": 23162,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 23162,
      "e": 23162,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23266,
      "e": 23266,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 23266,
      "e": 23266,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23273,
      "e": 23273,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d "
    },
    {
      "t": 23345,
      "e": 23345,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23994,
      "e": 23994,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 23994,
      "e": 23994,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24074,
      "e": 24074,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 24074,
      "e": 24074,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24082,
      "e": 24082,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 24186,
      "e": 24186,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 24186,
      "e": 24186,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24194,
      "e": 24194,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 24265,
      "e": 24265,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24266,
      "e": 24266,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24273,
      "e": 24273,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 24338,
      "e": 24338,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24386,
      "e": 24386,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 24386,
      "e": 24386,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24441,
      "e": 24441,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 24441,
      "e": 24441,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24457,
      "e": 24457,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||du"
    },
    {
      "t": 24561,
      "e": 24561,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 24561,
      "e": 24561,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24569,
      "e": 24569,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 24634,
      "e": 24634,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24683,
      "e": 24683,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 24683,
      "e": 24683,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24794,
      "e": 24794,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 24794,
      "e": 24794,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24809,
      "e": 24809,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 24906,
      "e": 24906,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 24906,
      "e": 24906,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24913,
      "e": 24913,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 25034,
      "e": 25034,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 25034,
      "e": 25034,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25056,
      "e": 25056,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 25073,
      "e": 25073,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 25073,
      "e": 25073,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25145,
      "e": 25145,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 25233,
      "e": 25233,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25234,
      "e": 25234,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25241,
      "e": 25241,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25353,
      "e": 25353,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26594,
      "e": 26594,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 26595,
      "e": 26595,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26697,
      "e": 26697,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 26697,
      "e": 26697,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26721,
      "e": 26721,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||of"
    },
    {
      "t": 26801,
      "e": 26801,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26802,
      "e": 26802,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26802,
      "e": 26802,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26897,
      "e": 26897,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 26994,
      "e": 26994,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 26994,
      "e": 26994,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27098,
      "e": 27098,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 27099,
      "e": 27099,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27129,
      "e": 27129,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||it"
    },
    {
      "t": 27210,
      "e": 27210,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27218,
      "e": 27218,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27219,
      "e": 27219,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27329,
      "e": 27329,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27329,
      "e": 27329,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 27329,
      "e": 27329,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27393,
      "e": 27393,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 27393,
      "e": 27393,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27409,
      "e": 27409,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||to"
    },
    {
      "t": 27498,
      "e": 27498,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27506,
      "e": 27506,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27507,
      "e": 27507,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27586,
      "e": 27586,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 27587,
      "e": 27587,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27601,
      "e": 27601,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 27682,
      "e": 27682,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 27682,
      "e": 27682,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27697,
      "e": 27697,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 27785,
      "e": 27785,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27794,
      "e": 27794,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 27794,
      "e": 27794,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27889,
      "e": 27889,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27889,
      "e": 27889,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27937,
      "e": 27937,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 28009,
      "e": 28009,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 28138,
      "e": 28138,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 28139,
      "e": 28139,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28217,
      "e": 28217,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 28345,
      "e": 28345,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 28346,
      "e": 28346,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28450,
      "e": 28450,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 28610,
      "e": 28610,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 28611,
      "e": 28611,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28729,
      "e": 28729,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 29018,
      "e": 29018,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 29081,
      "e": 29018,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see the starting time of the different points and then add the duration of it to the nu"
    },
    {
      "t": 29153,
      "e": 29090,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 29194,
      "e": 29131,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see the starting time of the different points and then add the duration of it to the n"
    },
    {
      "t": 29266,
      "e": 29203,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 29345,
      "e": 29282,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see the starting time of the different points and then add the duration of it to the "
    },
    {
      "t": 29425,
      "e": 29362,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 29426,
      "e": 29363,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29514,
      "e": 29451,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 29514,
      "e": 29451,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29562,
      "e": 29499,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||st"
    },
    {
      "t": 29625,
      "e": 29562,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 29706,
      "e": 29643,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 29706,
      "e": 29643,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29771,
      "e": 29708,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 29772,
      "e": 29709,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29834,
      "e": 29771,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 29866,
      "e": 29803,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 29962,
      "e": 29899,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 29962,
      "e": 29899,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30050,
      "e": 29987,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 30058,
      "e": 29995,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 30059,
      "e": 29996,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30121,
      "e": 30058,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 30122,
      "e": 30059,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30185,
      "e": 30122,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 30201,
      "e": 30138,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 30201,
      "e": 30138,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30249,
      "e": 30186,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 30281,
      "e": 30218,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30282,
      "e": 30219,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30282,
      "e": 30219,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30370,
      "e": 30307,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 30371,
      "e": 30308,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30386,
      "e": 30323,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 30434,
      "e": 30371,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 30435,
      "e": 30372,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30464,
      "e": 30401,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 30497,
      "e": 30434,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 30497,
      "e": 30434,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30537,
      "e": 30474,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 30585,
      "e": 30522,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 30586,
      "e": 30523,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30593,
      "e": 30530,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 30714,
      "e": 30651,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30729,
      "e": 30666,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 30731,
      "e": 30668,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30882,
      "e": 30819,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 30884,
      "e": 30821,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30885,
      "e": 30822,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30969,
      "e": 30906,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 31001,
      "e": 30938,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 31065,
      "e": 31002,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 31066,
      "e": 31003,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31121,
      "e": 31058,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||I"
    },
    {
      "t": 31170,
      "e": 31107,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 31194,
      "e": 31131,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 31195,
      "e": 31132,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31330,
      "e": 31267,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 31339,
      "e": 31276,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31340,
      "e": 31277,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31433,
      "e": 31370,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 31617,
      "e": 31554,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 31619,
      "e": 31556,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31729,
      "e": 31666,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 31729,
      "e": 31666,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31745,
      "e": 31682,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||it"
    },
    {
      "t": 31841,
      "e": 31778,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31842,
      "e": 31779,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31865,
      "e": 31802,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 31954,
      "e": 31891,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33706,
      "e": 33643,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 33708,
      "e": 33645,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33761,
      "e": 33698,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 33914,
      "e": 33851,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "81"
    },
    {
      "t": 33915,
      "e": 33852,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34033,
      "e": 33970,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||q"
    },
    {
      "t": 34041,
      "e": 33978,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 34041,
      "e": 33978,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34130,
      "e": 34067,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 34162,
      "e": 34099,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 34163,
      "e": 34100,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34258,
      "e": 34195,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 34266,
      "e": 34203,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 34266,
      "e": 34203,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34385,
      "e": 34322,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 34385,
      "e": 34322,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34409,
      "e": 34346,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ls"
    },
    {
      "t": 34497,
      "e": 34434,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34506,
      "e": 34443,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34507,
      "e": 34444,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34585,
      "e": 34522,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 34681,
      "e": 34618,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 34682,
      "e": 34619,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34805,
      "e": 34620,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see the starting time of the different points and then add the duration of it to the starting time. If it equals 1"
    },
    {
      "t": 34825,
      "e": 34640,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 34825,
      "e": 34640,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34881,
      "e": 34696,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 34993,
      "e": 34808,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 35378,
      "e": 35193,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 35378,
      "e": 35193,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35466,
      "e": 35281,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 35490,
      "e": 35305,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 35491,
      "e": 35306,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35577,
      "e": 35392,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 35585,
      "e": 35400,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 35586,
      "e": 35401,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35673,
      "e": 35488,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 35714,
      "e": 35529,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 35715,
      "e": 35530,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35793,
      "e": 35608,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 35793,
      "e": 35608,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35825,
      "e": 35640,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||an"
    },
    {
      "t": 35898,
      "e": 35713,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36010,
      "e": 35825,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36010,
      "e": 35825,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36074,
      "e": 35889,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 36204,
      "e": 36019,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see the starting time of the different points and then add the duration of it to the starting time. If it equals 12 than "
    },
    {
      "t": 36433,
      "e": 36248,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 36435,
      "e": 36250,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36465,
      "e": 36280,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 36465,
      "e": 36280,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36505,
      "e": 36320,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 36585,
      "e": 36400,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36593,
      "e": 36408,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 36593,
      "e": 36408,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36681,
      "e": 36496,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36682,
      "e": 36497,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36697,
      "e": 36512,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 36785,
      "e": 36600,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 37092,
      "e": 36907,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 37093,
      "e": 36908,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37149,
      "e": 36964,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 37285,
      "e": 37100,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 37286,
      "e": 37101,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37324,
      "e": 37139,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 37364,
      "e": 37179,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 37364,
      "e": 37179,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37453,
      "e": 37268,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 37461,
      "e": 37276,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 37461,
      "e": 37276,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37572,
      "e": 37387,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 37612,
      "e": 37427,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 37613,
      "e": 37428,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37748,
      "e": 37563,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 37757,
      "e": 37572,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37757,
      "e": 37572,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37862,
      "e": 37677,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 37958,
      "e": 37773,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 37960,
      "e": 37775,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38028,
      "e": 37843,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 38029,
      "e": 37844,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38077,
      "e": 37892,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||wi"
    },
    {
      "t": 38101,
      "e": 37916,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 38197,
      "e": 38012,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 38198,
      "e": 38013,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38252,
      "e": 38067,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 38332,
      "e": 38147,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 38333,
      "e": 38148,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38437,
      "e": 38252,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 38453,
      "e": 38268,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 38454,
      "e": 38269,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38540,
      "e": 38355,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 38541,
      "e": 38356,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38588,
      "e": 38403,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| s"
    },
    {
      "t": 38621,
      "e": 38436,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 38621,
      "e": 38436,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38677,
      "e": 38492,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 38757,
      "e": 38572,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 38837,
      "e": 38652,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 38838,
      "e": 38653,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38917,
      "e": 38732,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 38917,
      "e": 38732,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38956,
      "e": 38771,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 39029,
      "e": 38844,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 39220,
      "e": 39035,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 39221,
      "e": 39036,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39373,
      "e": 39188,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 39373,
      "e": 39188,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39381,
      "e": 39196,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 39501,
      "e": 39316,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 40005,
      "e": 39820,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40601,
      "e": 40416,
      "ty": 7,
      "x": 524,
      "y": 518,
      "ta": "#strategyAnswer"
    },
    {
      "t": 40605,
      "e": 40420,
      "ty": 2,
      "x": 524,
      "y": 518
    },
    {
      "t": 40705,
      "e": 40520,
      "ty": 2,
      "x": 1118,
      "y": 449
    },
    {
      "t": 40755,
      "e": 40570,
      "ty": 41,
      "x": 22832,
      "y": 23778,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 40804,
      "e": 40619,
      "ty": 2,
      "x": 1100,
      "y": 509
    },
    {
      "t": 40904,
      "e": 40719,
      "ty": 2,
      "x": 1103,
      "y": 557
    },
    {
      "t": 41006,
      "e": 40821,
      "ty": 41,
      "x": 22339,
      "y": 30010,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 41104,
      "e": 40919,
      "ty": 2,
      "x": 1051,
      "y": 540
    },
    {
      "t": 41204,
      "e": 41019,
      "ty": 2,
      "x": 716,
      "y": 576
    },
    {
      "t": 41216,
      "e": 41031,
      "ty": 6,
      "x": 632,
      "y": 592,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41233,
      "e": 41048,
      "ty": 7,
      "x": 474,
      "y": 620,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41255,
      "e": 41070,
      "ty": 41,
      "x": 28276,
      "y": 8693,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 41304,
      "e": 41119,
      "ty": 2,
      "x": 351,
      "y": 635
    },
    {
      "t": 41350,
      "e": 41165,
      "ty": 6,
      "x": 381,
      "y": 589,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41404,
      "e": 41219,
      "ty": 2,
      "x": 425,
      "y": 541
    },
    {
      "t": 41434,
      "e": 41249,
      "ty": 7,
      "x": 461,
      "y": 519,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41504,
      "e": 41319,
      "ty": 2,
      "x": 493,
      "y": 517
    },
    {
      "t": 41504,
      "e": 41319,
      "ty": 41,
      "x": 44503,
      "y": 52113,
      "ta": "#.strategy > p"
    },
    {
      "t": 41517,
      "e": 41332,
      "ty": 6,
      "x": 503,
      "y": 522,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41604,
      "e": 41419,
      "ty": 2,
      "x": 603,
      "y": 552
    },
    {
      "t": 41755,
      "e": 41570,
      "ty": 41,
      "x": 56868,
      "y": 23678,
      "ta": "#strategyAnswer"
    },
    {
      "t": 41905,
      "e": 41720,
      "ty": 2,
      "x": 649,
      "y": 548
    },
    {
      "t": 42005,
      "e": 41820,
      "ty": 2,
      "x": 659,
      "y": 543
    },
    {
      "t": 42005,
      "e": 41820,
      "ty": 41,
      "x": 63163,
      "y": 16396,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42105,
      "e": 41920,
      "ty": 2,
      "x": 660,
      "y": 542
    },
    {
      "t": 42204,
      "e": 42019,
      "ty": 2,
      "x": 663,
      "y": 542
    },
    {
      "t": 42255,
      "e": 42070,
      "ty": 41,
      "x": 63950,
      "y": 14778,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42305,
      "e": 42120,
      "ty": 2,
      "x": 666,
      "y": 541
    },
    {
      "t": 42538,
      "e": 42353,
      "ty": 3,
      "x": 666,
      "y": 541,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42605,
      "e": 42420,
      "ty": 2,
      "x": 667,
      "y": 541
    },
    {
      "t": 42745,
      "e": 42560,
      "ty": 4,
      "x": 64063,
      "y": 14778,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42745,
      "e": 42560,
      "ty": 5,
      "x": 667,
      "y": 541,
      "ta": "#strategyAnswer"
    },
    {
      "t": 42755,
      "e": 42570,
      "ty": 41,
      "x": 64063,
      "y": 14778,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43005,
      "e": 42820,
      "ty": 2,
      "x": 667,
      "y": 542
    },
    {
      "t": 43006,
      "e": 42821,
      "ty": 41,
      "x": 64063,
      "y": 15587,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43105,
      "e": 42920,
      "ty": 2,
      "x": 675,
      "y": 562
    },
    {
      "t": 43136,
      "e": 42951,
      "ty": 7,
      "x": 681,
      "y": 570,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43205,
      "e": 43020,
      "ty": 2,
      "x": 681,
      "y": 570
    },
    {
      "t": 43256,
      "e": 43071,
      "ty": 41,
      "x": 52,
      "y": 30672,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 43405,
      "e": 43220,
      "ty": 2,
      "x": 681,
      "y": 568
    },
    {
      "t": 43449,
      "e": 43264,
      "ty": 6,
      "x": 680,
      "y": 566,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43504,
      "e": 43319,
      "ty": 2,
      "x": 680,
      "y": 566
    },
    {
      "t": 43504,
      "e": 43319,
      "ty": 41,
      "x": 65524,
      "y": 35005,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43604,
      "e": 43419,
      "ty": 2,
      "x": 677,
      "y": 560
    },
    {
      "t": 43703,
      "e": 43518,
      "ty": 2,
      "x": 675,
      "y": 556
    },
    {
      "t": 43755,
      "e": 43570,
      "ty": 41,
      "x": 64962,
      "y": 26914,
      "ta": "#strategyAnswer"
    },
    {
      "t": 43826,
      "e": 43641,
      "ty": 3,
      "x": 675,
      "y": 556,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44104,
      "e": 43919,
      "ty": 2,
      "x": 670,
      "y": 556
    },
    {
      "t": 44254,
      "e": 44069,
      "ty": 41,
      "x": 63501,
      "y": 26914,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44304,
      "e": 44119,
      "ty": 2,
      "x": 638,
      "y": 546
    },
    {
      "t": 44386,
      "e": 44201,
      "ty": 7,
      "x": 590,
      "y": 514,
      "ta": "#strategyAnswer"
    },
    {
      "t": 44404,
      "e": 44219,
      "ty": 2,
      "x": 580,
      "y": 505
    },
    {
      "t": 44504,
      "e": 44319,
      "ty": 2,
      "x": 566,
      "y": 495
    },
    {
      "t": 44504,
      "e": 44319,
      "ty": 41,
      "x": 52709,
      "y": 621,
      "ta": "#.strategy > p"
    },
    {
      "t": 44904,
      "e": 44719,
      "ty": 2,
      "x": 538,
      "y": 495
    },
    {
      "t": 45004,
      "e": 44819,
      "ty": 2,
      "x": 436,
      "y": 512
    },
    {
      "t": 45004,
      "e": 44819,
      "ty": 41,
      "x": 38096,
      "y": 40410,
      "ta": "#.strategy > p"
    },
    {
      "t": 45037,
      "e": 44852,
      "ty": 6,
      "x": 379,
      "y": 526,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45103,
      "e": 44918,
      "ty": 2,
      "x": 378,
      "y": 526
    },
    {
      "t": 45205,
      "e": 45020,
      "ty": 2,
      "x": 347,
      "y": 536
    },
    {
      "t": 45236,
      "e": 45051,
      "ty": 7,
      "x": 100,
      "y": 605,
      "ta": "#strategyAnswer"
    },
    {
      "t": 45254,
      "e": 45069,
      "ty": 41,
      "x": 0,
      "y": 35786,
      "ta": "html"
    },
    {
      "t": 45304,
      "e": 45119,
      "ty": 2,
      "x": 0,
      "y": 714
    },
    {
      "t": 45504,
      "e": 45319,
      "ty": 41,
      "x": 0,
      "y": 39553,
      "ta": "html"
    },
    {
      "t": 45754,
      "e": 45569,
      "ty": 41,
      "x": 0,
      "y": 39387,
      "ta": "html"
    },
    {
      "t": 45804,
      "e": 45619,
      "ty": 2,
      "x": 0,
      "y": 708
    },
    {
      "t": 45904,
      "e": 45719,
      "ty": 2,
      "x": 9,
      "y": 570
    },
    {
      "t": 46004,
      "e": 45819,
      "ty": 2,
      "x": 12,
      "y": 506
    },
    {
      "t": 46004,
      "e": 45819,
      "ty": 41,
      "x": 137,
      "y": 27587,
      "ta": "> div.stimulus"
    },
    {
      "t": 46234,
      "e": 46049,
      "ty": 4,
      "x": 137,
      "y": 27587,
      "ta": "> div.stimulus"
    },
    {
      "t": 46718,
      "e": 46533,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "18"
    },
    {
      "t": 46949,
      "e": 46764,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 47205,
      "e": 47020,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 47221,
      "e": 47036,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 47716,
      "e": 47531,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 47829,
      "e": 47644,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 47829,
      "e": 47644,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 47892,
      "e": 47707,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Y "
    },
    {
      "t": 47908,
      "e": 47723,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Y "
    },
    {
      "t": 47988,
      "e": 47803,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 47989,
      "e": 47804,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48044,
      "e": 47859,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 48045,
      "e": 47860,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48117,
      "e": 47932,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You "
    },
    {
      "t": 48124,
      "e": 47939,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 48125,
      "e": 47940,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48172,
      "e": 47987,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 48213,
      "e": 48028,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 48213,
      "e": 48028,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48244,
      "e": 48059,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You f "
    },
    {
      "t": 48293,
      "e": 48108,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 48293,
      "e": 48108,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48301,
      "e": 48116,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You fi "
    },
    {
      "t": 48389,
      "e": 48204,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 48390,
      "e": 48205,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48453,
      "e": 48268,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You fir "
    },
    {
      "t": 48492,
      "e": 48307,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 48564,
      "e": 48379,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 48565,
      "e": 48380,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48621,
      "e": 48436,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 48621,
      "e": 48436,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48701,
      "e": 48516,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first "
    },
    {
      "t": 48717,
      "e": 48532,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 48722,
      "e": 48537,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48749,
      "e": 48564,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 48812,
      "e": 48627,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 48876,
      "e": 48691,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 48876,
      "e": 48691,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48941,
      "e": 48756,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 48941,
      "e": 48756,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 48997,
      "e": 48812,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first se "
    },
    {
      "t": 49053,
      "e": 48868,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 49125,
      "e": 48940,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 49126,
      "e": 48941,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49220,
      "e": 49035,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 49221,
      "e": 49036,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 49268,
      "e": 49083,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see  "
    },
    {
      "t": 49333,
      "e": 49148,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 50004,
      "e": 49819,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 50933,
      "e": 50748,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 50934,
      "e": 50749,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51021,
      "e": 50836,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 51021,
      "e": 50836,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51052,
      "e": 50867,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see wh "
    },
    {
      "t": 51100,
      "e": 50915,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 51100,
      "e": 50915,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51132,
      "e": 50947,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see whi "
    },
    {
      "t": 51197,
      "e": 51012,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 51197,
      "e": 51012,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51236,
      "e": 51051,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see whic "
    },
    {
      "t": 51301,
      "e": 51116,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 51308,
      "e": 51123,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 51308,
      "e": 51123,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51412,
      "e": 51227,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which "
    },
    {
      "t": 51437,
      "e": 51252,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 51437,
      "e": 51252,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51501,
      "e": 51316,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 51556,
      "e": 51371,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 51556,
      "e": 51371,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51652,
      "e": 51467,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 51653,
      "e": 51468,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51717,
      "e": 51532,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which on "
    },
    {
      "t": 51749,
      "e": 51564,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 51749,
      "e": 51564,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51804,
      "e": 51619,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one "
    },
    {
      "t": 51836,
      "e": 51651,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 51836,
      "e": 51651,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 51868,
      "e": 51683,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 51933,
      "e": 51748,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 51940,
      "e": 51755,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 51940,
      "e": 51755,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52036,
      "e": 51851,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 52036,
      "e": 51851,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52092,
      "e": 51907,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one is "
    },
    {
      "t": 52141,
      "e": 51956,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 52141,
      "e": 51956,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 52180,
      "e": 51995,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 52252,
      "e": 52067,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 60004,
      "e": 57067,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 61918,
      "e": 57067,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 62417,
      "e": 57566,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 62450,
      "e": 57599,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 62482,
      "e": 57631,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 62515,
      "e": 57664,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 62548,
      "e": 57697,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 62581,
      "e": 57730,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 62614,
      "e": 57763,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 62647,
      "e": 57796,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 62676,
      "e": 57825,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see whic "
    },
    {
      "t": 62806,
      "e": 57955,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see whic "
    },
    {
      "t": 63333,
      "e": 58482,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 63334,
      "e": 58483,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63412,
      "e": 58561,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which "
    },
    {
      "t": 63436,
      "e": 58585,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 63437,
      "e": 58586,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63525,
      "e": 58674,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 63525,
      "e": 58674,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63532,
      "e": 58681,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o "
    },
    {
      "t": 63581,
      "e": 58730,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 63581,
      "e": 58730,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63645,
      "e": 58794,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which on "
    },
    {
      "t": 63717,
      "e": 58866,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 63774,
      "e": 58923,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 63774,
      "e": 58923,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63892,
      "e": 59041,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 63892,
      "e": 59041,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 63940,
      "e": 59089,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one  "
    },
    {
      "t": 63997,
      "e": 59146,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 64012,
      "e": 59161,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 64013,
      "e": 59162,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64132,
      "e": 59281,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one o "
    },
    {
      "t": 64132,
      "e": 59281,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 64133,
      "e": 59282,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64205,
      "e": 59354,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one of "
    },
    {
      "t": 64212,
      "e": 59361,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 64213,
      "e": 59362,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64268,
      "e": 59417,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 64407,
      "e": 59556,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one of  "
    },
    {
      "t": 64428,
      "e": 59577,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 64492,
      "e": 59641,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one of "
    },
    {
      "t": 64556,
      "e": 59705,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 64620,
      "e": 59769,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one o "
    },
    {
      "t": 64741,
      "e": 59890,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 64741,
      "e": 59890,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64820,
      "e": 59969,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on "
    },
    {
      "t": 64828,
      "e": 59977,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 64828,
      "e": 59977,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64884,
      "e": 60033,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 64885,
      "e": 60034,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 64924,
      "e": 60073,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 64956,
      "e": 60105,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 64957,
      "e": 60106,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65004,
      "e": 60153,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on th "
    },
    {
      "t": 65045,
      "e": 60194,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 65045,
      "e": 60194,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65076,
      "e": 60225,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the "
    },
    {
      "t": 65140,
      "e": 60289,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 65140,
      "e": 60289,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65156,
      "e": 60305,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 65220,
      "e": 60369,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 65277,
      "e": 60426,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 65277,
      "e": 60426,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65397,
      "e": 60546,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x "
    },
    {
      "t": 65429,
      "e": 60578,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 65429,
      "e": 60578,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65508,
      "e": 60657,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 65532,
      "e": 60681,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 65532,
      "e": 60681,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65668,
      "e": 60817,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x a "
    },
    {
      "t": 65861,
      "e": 61010,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 65862,
      "e": 61011,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 65924,
      "e": 61073,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x ax "
    },
    {
      "t": 65948,
      "e": 61097,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 65950,
      "e": 61099,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66101,
      "e": 61250,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x axi "
    },
    {
      "t": 66108,
      "e": 61257,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 66109,
      "e": 61258,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66246,
      "e": 61259,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 66248,
      "e": 61261,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66253,
      "e": 61266,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x axis  "
    },
    {
      "t": 66332,
      "e": 61345,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 66388,
      "e": 61401,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 66388,
      "e": 61401,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66476,
      "e": 61489,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x axis s "
    },
    {
      "t": 66676,
      "e": 61689,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 66678,
      "e": 61691,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66789,
      "e": 61802,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 66789,
      "e": 61802,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 66796,
      "e": 61809,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x axis say "
    },
    {
      "t": 66884,
      "e": 61897,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 66981,
      "e": 61994,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 66982,
      "e": 61995,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67028,
      "e": 62041,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x axis sayi "
    },
    {
      "t": 67324,
      "e": 62337,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 67388,
      "e": 62401,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x axis say "
    },
    {
      "t": 67444,
      "e": 62457,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 67533,
      "e": 62546,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x axis sa "
    },
    {
      "t": 67548,
      "e": 62561,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 67548,
      "e": 62561,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67709,
      "e": 62722,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x axis sas "
    },
    {
      "t": 67773,
      "e": 62786,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 67773,
      "e": 62786,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 67956,
      "e": 62969,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x axis sasy "
    },
    {
      "t": 68100,
      "e": 63113,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 68156,
      "e": 63169,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x axis sas "
    },
    {
      "t": 68236,
      "e": 63249,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 68268,
      "e": 63281,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x axis sa "
    },
    {
      "t": 68316,
      "e": 63329,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 68317,
      "e": 63330,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68468,
      "e": 63481,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x axis say "
    },
    {
      "t": 68588,
      "e": 63601,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 68589,
      "e": 63602,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68733,
      "e": 63746,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 68734,
      "e": 63747,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 68748,
      "e": 63761,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x axis says  "
    },
    {
      "t": 68836,
      "e": 63849,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 68925,
      "e": 63938,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 68925,
      "e": 63938,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69092,
      "e": 64105,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 69092,
      "e": 64105,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69100,
      "e": 64113,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x axis says sy "
    },
    {
      "t": 69125,
      "e": 64138,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 69324,
      "e": 64337,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 69325,
      "e": 64338,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69461,
      "e": 64474,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 69462,
      "e": 64475,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69493,
      "e": 64506,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x axis says syar "
    },
    {
      "t": 69581,
      "e": 64594,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 69701,
      "e": 64714,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 69703,
      "e": 64716,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69773,
      "e": 64786,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x axis says syart "
    },
    {
      "t": 69780,
      "e": 64793,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 69781,
      "e": 64794,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69869,
      "e": 64795,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 69892,
      "e": 64818,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 69892,
      "e": 64818,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69940,
      "e": 64866,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 69940,
      "e": 64866,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 69980,
      "e": 64906,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x axis says syart ti "
    },
    {
      "t": 70028,
      "e": 64954,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 70029,
      "e": 64955,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70077,
      "e": 65003,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x axis says syart tim "
    },
    {
      "t": 70108,
      "e": 65034,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 70108,
      "e": 65034,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70156,
      "e": 65082,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x axis says syart time "
    },
    {
      "t": 70180,
      "e": 65106,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 70180,
      "e": 65106,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 70220,
      "e": 65146,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 70268,
      "e": 65194,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 71316,
      "e": 66242,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "45"
    },
    {
      "t": 71788,
      "e": 66714,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 72029,
      "e": 66955,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 72206,
      "e": 67132,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x axis says syart time "
    },
    {
      "t": 72528,
      "e": 67454,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 72561,
      "e": 67487,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 72593,
      "e": 67519,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 72627,
      "e": 67553,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 72660,
      "e": 67586,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 72693,
      "e": 67619,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 72725,
      "e": 67651,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 72759,
      "e": 67685,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 72792,
      "e": 67718,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 72824,
      "e": 67750,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 72858,
      "e": 67784,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 72868,
      "e": 67794,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x axis says "
    },
    {
      "t": 73006,
      "e": 67932,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x axis says "
    },
    {
      "t": 73277,
      "e": 68203,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 73277,
      "e": 68203,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73364,
      "e": 68290,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 73365,
      "e": 68291,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73395,
      "e": 68321,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x axis saysst "
    },
    {
      "t": 73476,
      "e": 68402,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 73613,
      "e": 68539,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 73613,
      "e": 68539,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 73708,
      "e": 68634,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x axis sayssta "
    },
    {
      "t": 73981,
      "e": 68907,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 74036,
      "e": 68962,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x axis saysst "
    },
    {
      "t": 74084,
      "e": 69010,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 74188,
      "e": 69114,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x axis sayss "
    },
    {
      "t": 74269,
      "e": 69195,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 74324,
      "e": 69250,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x axis says "
    },
    {
      "t": 74532,
      "e": 69458,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 74534,
      "e": 69460,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74612,
      "e": 69538,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 74652,
      "e": 69578,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 74652,
      "e": 69578,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74740,
      "e": 69666,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 74740,
      "e": 69666,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 74788,
      "e": 69714,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x axis says st "
    },
    {
      "t": 74852,
      "e": 69778,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 74949,
      "e": 69875,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 74950,
      "e": 69876,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75012,
      "e": 69938,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 75012,
      "e": 69938,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75093,
      "e": 69939,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x axis says star "
    },
    {
      "t": 75116,
      "e": 69962,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 75244,
      "e": 70090,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 75245,
      "e": 70091,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75332,
      "e": 70178,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x axis says start "
    },
    {
      "t": 75339,
      "e": 70185,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 75340,
      "e": 70186,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75437,
      "e": 70283,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 75444,
      "e": 70290,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 75445,
      "e": 70291,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75548,
      "e": 70394,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x axis says start t "
    },
    {
      "t": 75813,
      "e": 70659,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 75813,
      "e": 70659,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75908,
      "e": 70754,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "188"
    },
    {
      "t": 75908,
      "e": 70754,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 75964,
      "e": 70810,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x axis says start to, "
    },
    {
      "t": 76060,
      "e": 70906,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 76085,
      "e": 70931,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 76085,
      "e": 70931,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76172,
      "e": 71018,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 76172,
      "e": 71018,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76252,
      "e": 71098,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x axis says start to,e  "
    },
    {
      "t": 76292,
      "e": 71138,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 76348,
      "e": 71194,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 76349,
      "e": 71195,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76438,
      "e": 71284,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 76438,
      "e": 71284,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76493,
      "e": 71339,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x axis says start to,e at "
    },
    {
      "t": 76596,
      "e": 71442,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 76597,
      "e": 71443,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 76628,
      "e": 71474,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 76676,
      "e": 71522,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 77509,
      "e": 72355,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 77564,
      "e": 72410,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x axis says start to,e at "
    },
    {
      "t": 77732,
      "e": 72578,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 77763,
      "e": 72609,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x axis says start to,e a "
    },
    {
      "t": 77844,
      "e": 72690,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 77900,
      "e": 72746,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x axis says start to,e  "
    },
    {
      "t": 77972,
      "e": 72818,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 78020,
      "e": 72866,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x axis says start to,e "
    },
    {
      "t": 78092,
      "e": 72938,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 78140,
      "e": 72986,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x axis says start to, "
    },
    {
      "t": 78268,
      "e": 73114,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 78308,
      "e": 73154,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x axis says start to "
    },
    {
      "t": 78397,
      "e": 73243,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 78452,
      "e": 73243,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x axis says start t "
    },
    {
      "t": 78819,
      "e": 73610,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 78819,
      "e": 73610,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 78988,
      "e": 73779,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x axis says start ti "
    },
    {
      "t": 80029,
      "e": 74820,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 80029,
      "e": 74820,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80108,
      "e": 74899,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x axis says start tim "
    },
    {
      "t": 80188,
      "e": 74979,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 80188,
      "e": 74979,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80269,
      "e": 75060,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 80269,
      "e": 75060,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80316,
      "e": 75107,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x axis says start time  "
    },
    {
      "t": 80364,
      "e": 75155,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 80396,
      "e": 75187,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 80396,
      "e": 75187,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80468,
      "e": 75259,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 80468,
      "e": 75259,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80515,
      "e": 75306,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x axis says start time at "
    },
    {
      "t": 80588,
      "e": 75379,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 80589,
      "e": 75380,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 80620,
      "e": 75411,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 80669,
      "e": 75460,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 81028,
      "e": 75819,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 81029,
      "e": 75820,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81132,
      "e": 75923,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 81132,
      "e": 75923,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81180,
      "e": 75971,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x axis says start time at 12 "
    },
    {
      "t": 81292,
      "e": 76083,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 81309,
      "e": 76100,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 81309,
      "e": 76100,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81380,
      "e": 76171,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 81452,
      "e": 76243,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 81452,
      "e": 76243,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81549,
      "e": 76340,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 81551,
      "e": 76342,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81604,
      "e": 76395,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x axis says start time at 12 pm "
    },
    {
      "t": 81716,
      "e": 76507,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 81732,
      "e": 76523,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 81732,
      "e": 76523,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 81812,
      "e": 76603,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 82621,
      "e": 77412,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 82684,
      "e": 77475,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x axis says start time at 12 pm "
    },
    {
      "t": 82806,
      "e": 77597,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x axis says start time at 12 pm "
    },
    {
      "t": 82941,
      "e": 77732,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 82942,
      "e": 77733,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 82995,
      "e": 77786,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x axis says start time at 12 pm. "
    },
    {
      "t": 83052,
      "e": 77843,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 83052,
      "e": 77843,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 83148,
      "e": 77939,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 83503,
      "e": 78294,
      "ty": 6,
      "x": 97,
      "y": 529,
      "ta": "#strategyAnswer"
    },
    {
      "t": 83504,
      "e": 78295,
      "ty": 2,
      "x": 97,
      "y": 529
    },
    {
      "t": 83504,
      "e": 78295,
      "ty": 41,
      "x": 0,
      "y": 5069,
      "ta": "#strategyAnswer"
    },
    {
      "t": 83518,
      "e": 78309,
      "ty": 7,
      "x": 168,
      "y": 617,
      "ta": "#strategyAnswer"
    },
    {
      "t": 83605,
      "e": 78396,
      "ty": 2,
      "x": 233,
      "y": 768
    },
    {
      "t": 83704,
      "e": 78495,
      "ty": 2,
      "x": 268,
      "y": 819
    },
    {
      "t": 83755,
      "e": 78546,
      "ty": 41,
      "x": 19436,
      "y": 45093,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 83804,
      "e": 78595,
      "ty": 2,
      "x": 284,
      "y": 793
    },
    {
      "t": 83904,
      "e": 78695,
      "ty": 2,
      "x": 315,
      "y": 690
    },
    {
      "t": 84004,
      "e": 78795,
      "ty": 2,
      "x": 303,
      "y": 698
    },
    {
      "t": 84005,
      "e": 78796,
      "ty": 41,
      "x": 23145,
      "y": 38224,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 84104,
      "e": 78895,
      "ty": 2,
      "x": 319,
      "y": 692
    },
    {
      "t": 84120,
      "e": 78911,
      "ty": 6,
      "x": 344,
      "y": 677,
      "ta": "#strategyButton"
    },
    {
      "t": 84152,
      "e": 78911,
      "ty": 7,
      "x": 388,
      "y": 651,
      "ta": "#strategyButton"
    },
    {
      "t": 84204,
      "e": 78963,
      "ty": 2,
      "x": 394,
      "y": 647
    },
    {
      "t": 84254,
      "e": 79013,
      "ty": 41,
      "x": 35298,
      "y": 16557,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 84296,
      "e": 79055,
      "ty": 3,
      "x": 394,
      "y": 647,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 84297,
      "e": 79056,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "You first see which one on the x axis says start time at 12 pm.  "
    },
    {
      "t": 84297,
      "e": 79056,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 84433,
      "e": 79192,
      "ty": 4,
      "x": 35298,
      "y": 16557,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 84433,
      "e": 79192,
      "ty": 5,
      "x": 394,
      "y": 647,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 84586,
      "e": 79345,
      "ty": 6,
      "x": 410,
      "y": 661,
      "ta": "#strategyButton"
    },
    {
      "t": 84604,
      "e": 79363,
      "ty": 2,
      "x": 415,
      "y": 666
    },
    {
      "t": 84704,
      "e": 79463,
      "ty": 2,
      "x": 426,
      "y": 671
    },
    {
      "t": 84736,
      "e": 79495,
      "ty": 3,
      "x": 426,
      "y": 671,
      "ta": "#strategyButton"
    },
    {
      "t": 84737,
      "e": 79496,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 84755,
      "e": 79514,
      "ty": 41,
      "x": 47734,
      "y": 31351,
      "ta": "#strategyButton"
    },
    {
      "t": 84865,
      "e": 79624,
      "ty": 4,
      "x": 47734,
      "y": 31351,
      "ta": "#strategyButton"
    },
    {
      "t": 84876,
      "e": 79635,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 84877,
      "e": 79636,
      "ty": 5,
      "x": 426,
      "y": 671,
      "ta": "#strategyButton"
    },
    {
      "t": 84882,
      "e": 79641,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 85005,
      "e": 79764,
      "ty": 2,
      "x": 427,
      "y": 671
    },
    {
      "t": 85005,
      "e": 79764,
      "ty": 41,
      "x": 14429,
      "y": 36728,
      "ta": "html > body"
    },
    {
      "t": 85205,
      "e": 79964,
      "ty": 2,
      "x": 431,
      "y": 669
    },
    {
      "t": 85255,
      "e": 80014,
      "ty": 41,
      "x": 14601,
      "y": 36562,
      "ta": "html > body"
    },
    {
      "t": 85304,
      "e": 80063,
      "ty": 2,
      "x": 427,
      "y": 658
    },
    {
      "t": 85404,
      "e": 80163,
      "ty": 2,
      "x": 427,
      "y": 640
    },
    {
      "t": 85505,
      "e": 80264,
      "ty": 41,
      "x": 14429,
      "y": 35011,
      "ta": "html > body"
    },
    {
      "t": 85754,
      "e": 80513,
      "ty": 41,
      "x": 16116,
      "y": 33792,
      "ta": "html > body"
    },
    {
      "t": 85804,
      "e": 80563,
      "ty": 2,
      "x": 548,
      "y": 609
    },
    {
      "t": 85884,
      "e": 80643,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 86005,
      "e": 80764,
      "ty": 41,
      "x": 18596,
      "y": 33293,
      "ta": "html > body"
    },
    {
      "t": 86205,
      "e": 80964,
      "ty": 2,
      "x": 632,
      "y": 593
    },
    {
      "t": 86255,
      "e": 81014,
      "ty": 41,
      "x": 26620,
      "y": 32795,
      "ta": "html > body"
    },
    {
      "t": 86304,
      "e": 81063,
      "ty": 2,
      "x": 815,
      "y": 606
    },
    {
      "t": 86405,
      "e": 81164,
      "ty": 2,
      "x": 873,
      "y": 635
    },
    {
      "t": 86487,
      "e": 81246,
      "ty": 6,
      "x": 883,
      "y": 571,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 86505,
      "e": 81264,
      "ty": 2,
      "x": 884,
      "y": 564
    },
    {
      "t": 86505,
      "e": 81264,
      "ty": 41,
      "x": 16437,
      "y": 31207,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 86605,
      "e": 81364,
      "ty": 2,
      "x": 885,
      "y": 563
    },
    {
      "t": 86665,
      "e": 81424,
      "ty": 3,
      "x": 885,
      "y": 563,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 86666,
      "e": 81425,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 86755,
      "e": 81514,
      "ty": 41,
      "x": 16654,
      "y": 28086,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 86760,
      "e": 81519,
      "ty": 4,
      "x": 16654,
      "y": 28086,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 86761,
      "e": 81520,
      "ty": 5,
      "x": 885,
      "y": 563,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 87156,
      "e": 81915,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 87157,
      "e": 81916,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 87299,
      "e": 82058,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 88348,
      "e": 83107,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "56"
    },
    {
      "t": 88349,
      "e": 83108,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 88412,
      "e": 83171,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "18"
    },
    {
      "t": 88484,
      "e": 83243,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 88484,
      "e": 83243,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "18"
    },
    {
      "t": 88484,
      "e": 83243,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 88485,
      "e": 83244,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 88572,
      "e": 83331,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 89077,
      "e": 83836,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 89205,
      "e": 83964,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "67"
    },
    {
      "t": 89205,
      "e": 83964,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 89316,
      "e": 84075,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "C"
    },
    {
      "t": 89348,
      "e": 84107,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "C"
    },
    {
      "t": 90005,
      "e": 84764,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 90285,
      "e": 85044,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 90355,
      "e": 85114,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 90460,
      "e": 85219,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 90893,
      "e": 85652,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 90893,
      "e": 85652,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 90956,
      "e": 85715,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 91132,
      "e": 85891,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 91133,
      "e": 85892,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 91204,
      "e": 85963,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 91227,
      "e": 85986,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 91805,
      "e": 86564,
      "ty": 2,
      "x": 885,
      "y": 561
    },
    {
      "t": 91825,
      "e": 86584,
      "ty": 7,
      "x": 893,
      "y": 588,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 91905,
      "e": 86664,
      "ty": 2,
      "x": 898,
      "y": 604
    },
    {
      "t": 92005,
      "e": 86764,
      "ty": 41,
      "x": 19465,
      "y": 7021,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 92105,
      "e": 86864,
      "ty": 2,
      "x": 897,
      "y": 604
    },
    {
      "t": 92255,
      "e": 87014,
      "ty": 41,
      "x": 19249,
      "y": 7021,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 92377,
      "e": 87136,
      "ty": 6,
      "x": 944,
      "y": 651,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 92404,
      "e": 87163,
      "ty": 2,
      "x": 953,
      "y": 659
    },
    {
      "t": 92459,
      "e": 87218,
      "ty": 7,
      "x": 965,
      "y": 668,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 92504,
      "e": 87263,
      "ty": 2,
      "x": 965,
      "y": 668
    },
    {
      "t": 92504,
      "e": 87263,
      "ty": 41,
      "x": 33957,
      "y": 59897,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 92677,
      "e": 87436,
      "ty": 6,
      "x": 965,
      "y": 677,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 92704,
      "e": 87463,
      "ty": 2,
      "x": 965,
      "y": 678
    },
    {
      "t": 92754,
      "e": 87513,
      "ty": 41,
      "x": 36117,
      "y": 7943,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 92805,
      "e": 87564,
      "ty": 2,
      "x": 966,
      "y": 680
    },
    {
      "t": 92824,
      "e": 87583,
      "ty": 3,
      "x": 966,
      "y": 680,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 92824,
      "e": 87583,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 92824,
      "e": 87583,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 92824,
      "e": 87583,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 92944,
      "e": 87703,
      "ty": 4,
      "x": 36117,
      "y": 7943,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 92944,
      "e": 87703,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 92944,
      "e": 87703,
      "ty": 5,
      "x": 966,
      "y": 680,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 92944,
      "e": 87703,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 93254,
      "e": 88013,
      "ty": 41,
      "x": 32991,
      "y": 37005,
      "ta": "html > body"
    },
    {
      "t": 93305,
      "e": 88064,
      "ty": 2,
      "x": 960,
      "y": 629
    },
    {
      "t": 93404,
      "e": 88163,
      "ty": 2,
      "x": 669,
      "y": 345
    },
    {
      "t": 93504,
      "e": 88263,
      "ty": 2,
      "x": 645,
      "y": 326
    },
    {
      "t": 93504,
      "e": 88263,
      "ty": 41,
      "x": 21936,
      "y": 17616,
      "ta": "html > body"
    },
    {
      "t": 93604,
      "e": 88363,
      "ty": 2,
      "x": 664,
      "y": 342
    },
    {
      "t": 93704,
      "e": 88463,
      "ty": 2,
      "x": 744,
      "y": 385
    },
    {
      "t": 93754,
      "e": 88513,
      "ty": 41,
      "x": 25346,
      "y": 20884,
      "ta": "html > body"
    },
    {
      "t": 93957,
      "e": 88716,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 94004,
      "e": 88763,
      "ty": 2,
      "x": 769,
      "y": 363
    },
    {
      "t": 94004,
      "e": 88763,
      "ty": 41,
      "x": 26207,
      "y": 19666,
      "ta": "html > body"
    },
    {
      "t": 94104,
      "e": 88863,
      "ty": 2,
      "x": 787,
      "y": 352
    },
    {
      "t": 94204,
      "e": 88963,
      "ty": 2,
      "x": 790,
      "y": 349
    },
    {
      "t": 94255,
      "e": 89014,
      "ty": 41,
      "x": 26930,
      "y": 18890,
      "ta": "html > body"
    },
    {
      "t": 94304,
      "e": 89063,
      "ty": 2,
      "x": 793,
      "y": 345
    },
    {
      "t": 94403,
      "e": 89162,
      "ty": 2,
      "x": 830,
      "y": 248
    },
    {
      "t": 94410,
      "e": 89169,
      "ty": 6,
      "x": 834,
      "y": 235,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 94428,
      "e": 89187,
      "ty": 7,
      "x": 835,
      "y": 223,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 94504,
      "e": 89263,
      "ty": 2,
      "x": 840,
      "y": 207
    },
    {
      "t": 94504,
      "e": 89263,
      "ty": 41,
      "x": 4409,
      "y": 11613,
      "ta": "#jspsych-survey-multi-choice-0"
    },
    {
      "t": 94704,
      "e": 89463,
      "ty": 2,
      "x": 840,
      "y": 210
    },
    {
      "t": 94754,
      "e": 89513,
      "ty": 41,
      "x": 4409,
      "y": 12858,
      "ta": "#jspsych-survey-multi-choice-0"
    },
    {
      "t": 94895,
      "e": 89654,
      "ty": 6,
      "x": 838,
      "y": 233,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 94904,
      "e": 89663,
      "ty": 2,
      "x": 838,
      "y": 233
    },
    {
      "t": 95004,
      "e": 89763,
      "ty": 2,
      "x": 838,
      "y": 237
    },
    {
      "t": 95005,
      "e": 89764,
      "ty": 41,
      "x": 58367,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 95097,
      "e": 89856,
      "ty": 3,
      "x": 838,
      "y": 237,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 95098,
      "e": 89857,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 95216,
      "e": 89975,
      "ty": 4,
      "x": 58367,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 95217,
      "e": 89976,
      "ty": 5,
      "x": 838,
      "y": 237,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 95218,
      "e": 89977,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 95462,
      "e": 90221,
      "ty": 7,
      "x": 838,
      "y": 246,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 95496,
      "e": 90255,
      "ty": 6,
      "x": 839,
      "y": 271,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 95504,
      "e": 90263,
      "ty": 2,
      "x": 839,
      "y": 271
    },
    {
      "t": 95504,
      "e": 90263,
      "ty": 41,
      "x": 63408,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 95511,
      "e": 90270,
      "ty": 7,
      "x": 843,
      "y": 286,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 95604,
      "e": 90363,
      "ty": 2,
      "x": 857,
      "y": 407
    },
    {
      "t": 95704,
      "e": 90463,
      "ty": 2,
      "x": 859,
      "y": 463
    },
    {
      "t": 95754,
      "e": 90513,
      "ty": 41,
      "x": 35492,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 95804,
      "e": 90563,
      "ty": 2,
      "x": 855,
      "y": 478
    },
    {
      "t": 96004,
      "e": 90763,
      "ty": 2,
      "x": 853,
      "y": 475
    },
    {
      "t": 96004,
      "e": 90763,
      "ty": 41,
      "x": 33378,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 96079,
      "e": 90838,
      "ty": 6,
      "x": 838,
      "y": 420,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 96103,
      "e": 90862,
      "ty": 2,
      "x": 833,
      "y": 413
    },
    {
      "t": 96112,
      "e": 90871,
      "ty": 7,
      "x": 830,
      "y": 405,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 96204,
      "e": 90963,
      "ty": 2,
      "x": 826,
      "y": 395
    },
    {
      "t": 96254,
      "e": 91013,
      "ty": 41,
      "x": 1086,
      "y": 10832,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 96404,
      "e": 91163,
      "ty": 2,
      "x": 826,
      "y": 400
    },
    {
      "t": 96504,
      "e": 91163,
      "ty": 2,
      "x": 826,
      "y": 404
    },
    {
      "t": 96506,
      "e": 91165,
      "ty": 41,
      "x": 1086,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 96529,
      "e": 91188,
      "ty": 3,
      "x": 826,
      "y": 404,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 96530,
      "e": 91189,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 96639,
      "e": 91298,
      "ty": 4,
      "x": 1086,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 96639,
      "e": 91298,
      "ty": 5,
      "x": 826,
      "y": 404,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 96696,
      "e": 91355,
      "ty": 6,
      "x": 827,
      "y": 410,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 96704,
      "e": 91363,
      "ty": 2,
      "x": 827,
      "y": 410
    },
    {
      "t": 96729,
      "e": 91388,
      "ty": 7,
      "x": 836,
      "y": 424,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 96754,
      "e": 91413,
      "ty": 41,
      "x": 4409,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 96803,
      "e": 91462,
      "ty": 2,
      "x": 841,
      "y": 433
    },
    {
      "t": 96904,
      "e": 91563,
      "ty": 2,
      "x": 842,
      "y": 434
    },
    {
      "t": 97005,
      "e": 91664,
      "ty": 41,
      "x": 16436,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 97108,
      "e": 91767,
      "ty": 2,
      "x": 843,
      "y": 434
    },
    {
      "t": 97207,
      "e": 91866,
      "ty": 2,
      "x": 843,
      "y": 433
    },
    {
      "t": 97257,
      "e": 91916,
      "ty": 41,
      "x": 17235,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 97324,
      "e": 91983,
      "ty": 3,
      "x": 843,
      "y": 433,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 97444,
      "e": 92103,
      "ty": 4,
      "x": 17235,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 97445,
      "e": 92104,
      "ty": 5,
      "x": 843,
      "y": 433,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 97445,
      "e": 92104,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 97447,
      "e": 92106,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf",
      "v": "Second"
    },
    {
      "t": 97607,
      "e": 92266,
      "ty": 2,
      "x": 843,
      "y": 432
    },
    {
      "t": 97707,
      "e": 92366,
      "ty": 2,
      "x": 838,
      "y": 426
    },
    {
      "t": 97758,
      "e": 92417,
      "ty": 41,
      "x": 3934,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 97796,
      "e": 92455,
      "ty": 3,
      "x": 838,
      "y": 426,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 97797,
      "e": 92456,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 97923,
      "e": 92582,
      "ty": 4,
      "x": 3934,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 97923,
      "e": 92582,
      "ty": 5,
      "x": 838,
      "y": 426,
      "ta": "#jspsych-survey-multi-choice-option-1-0"
    },
    {
      "t": 97971,
      "e": 92630,
      "ty": 6,
      "x": 835,
      "y": 420,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 98007,
      "e": 92666,
      "ty": 2,
      "x": 829,
      "y": 413
    },
    {
      "t": 98008,
      "e": 92667,
      "ty": 41,
      "x": 12996,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 98034,
      "e": 92693,
      "ty": 7,
      "x": 825,
      "y": 408,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 98107,
      "e": 92766,
      "ty": 2,
      "x": 825,
      "y": 408
    },
    {
      "t": 98188,
      "e": 92847,
      "ty": 3,
      "x": 825,
      "y": 408,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 98258,
      "e": 92917,
      "ty": 41,
      "x": 4188,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 98307,
      "e": 92966,
      "ty": 4,
      "x": 4188,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 98307,
      "e": 92966,
      "ty": 5,
      "x": 825,
      "y": 408,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 98307,
      "e": 92966,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 98308,
      "e": 92967,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf",
      "v": "First"
    },
    {
      "t": 98408,
      "e": 93067,
      "ty": 2,
      "x": 825,
      "y": 407
    },
    {
      "t": 98508,
      "e": 93167,
      "ty": 2,
      "x": 827,
      "y": 407
    },
    {
      "t": 98508,
      "e": 93167,
      "ty": 41,
      "x": 6529,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 98620,
      "e": 93279,
      "ty": 6,
      "x": 828,
      "y": 410,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 98651,
      "e": 93310,
      "ty": 7,
      "x": 839,
      "y": 431,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 98707,
      "e": 93366,
      "ty": 2,
      "x": 890,
      "y": 530
    },
    {
      "t": 98757,
      "e": 93416,
      "ty": 41,
      "x": 46110,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-1-5 > label"
    },
    {
      "t": 98807,
      "e": 93466,
      "ty": 2,
      "x": 891,
      "y": 552
    },
    {
      "t": 98907,
      "e": 93566,
      "ty": 2,
      "x": 861,
      "y": 634
    },
    {
      "t": 99008,
      "e": 93667,
      "ty": 2,
      "x": 772,
      "y": 793
    },
    {
      "t": 99008,
      "e": 93667,
      "ty": 41,
      "x": 26310,
      "y": 43486,
      "ta": "html > body"
    },
    {
      "t": 99257,
      "e": 93916,
      "ty": 41,
      "x": 26413,
      "y": 42988,
      "ta": "html > body"
    },
    {
      "t": 99307,
      "e": 93966,
      "ty": 2,
      "x": 779,
      "y": 738
    },
    {
      "t": 99407,
      "e": 94066,
      "ty": 2,
      "x": 782,
      "y": 708
    },
    {
      "t": 99507,
      "e": 94166,
      "ty": 2,
      "x": 784,
      "y": 700
    },
    {
      "t": 99507,
      "e": 94166,
      "ty": 41,
      "x": 26723,
      "y": 38334,
      "ta": "html > body"
    },
    {
      "t": 99607,
      "e": 94266,
      "ty": 2,
      "x": 795,
      "y": 715
    },
    {
      "t": 99708,
      "e": 94367,
      "ty": 2,
      "x": 807,
      "y": 710
    },
    {
      "t": 99758,
      "e": 94417,
      "ty": 41,
      "x": 27928,
      "y": 38445,
      "ta": "html > body"
    },
    {
      "t": 99808,
      "e": 94467,
      "ty": 2,
      "x": 821,
      "y": 700
    },
    {
      "t": 100008,
      "e": 94667,
      "ty": 41,
      "x": 0,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 100385,
      "e": 95044,
      "ty": 6,
      "x": 834,
      "y": 733,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 100403,
      "e": 95062,
      "ty": 7,
      "x": 835,
      "y": 739,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 100408,
      "e": 95067,
      "ty": 2,
      "x": 835,
      "y": 739
    },
    {
      "t": 100436,
      "e": 95067,
      "ty": 6,
      "x": 838,
      "y": 753,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 100507,
      "e": 95138,
      "ty": 2,
      "x": 838,
      "y": 756
    },
    {
      "t": 100507,
      "e": 95138,
      "ty": 41,
      "x": 58367,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 100572,
      "e": 95203,
      "ty": 7,
      "x": 838,
      "y": 748,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 100608,
      "e": 95239,
      "ty": 2,
      "x": 837,
      "y": 737
    },
    {
      "t": 100619,
      "e": 95250,
      "ty": 6,
      "x": 836,
      "y": 730,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 100653,
      "e": 95284,
      "ty": 7,
      "x": 834,
      "y": 723,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 100707,
      "e": 95338,
      "ty": 2,
      "x": 834,
      "y": 714
    },
    {
      "t": 100758,
      "e": 95389,
      "ty": 41,
      "x": 2917,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 100771,
      "e": 95402,
      "ty": 6,
      "x": 833,
      "y": 708,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 100808,
      "e": 95439,
      "ty": 2,
      "x": 833,
      "y": 705
    },
    {
      "t": 100908,
      "e": 95539,
      "ty": 2,
      "x": 835,
      "y": 698
    },
    {
      "t": 100996,
      "e": 95627,
      "ty": 3,
      "x": 835,
      "y": 698,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 100997,
      "e": 95628,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 100998,
      "e": 95629,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 101008,
      "e": 95639,
      "ty": 41,
      "x": 43243,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 101147,
      "e": 95778,
      "ty": 4,
      "x": 43243,
      "y": 10082,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 101147,
      "e": 95778,
      "ty": 5,
      "x": 835,
      "y": 698,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 101148,
      "e": 95779,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 101258,
      "e": 95889,
      "ty": 41,
      "x": 53325,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 101260,
      "e": 95891,
      "ty": 7,
      "x": 837,
      "y": 713,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 101308,
      "e": 95939,
      "ty": 2,
      "x": 840,
      "y": 757
    },
    {
      "t": 101407,
      "e": 96038,
      "ty": 2,
      "x": 843,
      "y": 782
    },
    {
      "t": 101508,
      "e": 96139,
      "ty": 2,
      "x": 844,
      "y": 886
    },
    {
      "t": 101508,
      "e": 96139,
      "ty": 41,
      "x": 5358,
      "y": 25745,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 101608,
      "e": 96239,
      "ty": 2,
      "x": 852,
      "y": 955
    },
    {
      "t": 101708,
      "e": 96339,
      "ty": 2,
      "x": 853,
      "y": 964
    },
    {
      "t": 101758,
      "e": 96389,
      "ty": 41,
      "x": 25544,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 101808,
      "e": 96439,
      "ty": 2,
      "x": 855,
      "y": 965
    },
    {
      "t": 101907,
      "e": 96538,
      "ty": 2,
      "x": 855,
      "y": 957
    },
    {
      "t": 102008,
      "e": 96639,
      "ty": 2,
      "x": 855,
      "y": 956
    },
    {
      "t": 102009,
      "e": 96640,
      "ty": 41,
      "x": 27161,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 102408,
      "e": 97039,
      "ty": 2,
      "x": 847,
      "y": 945
    },
    {
      "t": 102437,
      "e": 97068,
      "ty": 6,
      "x": 838,
      "y": 932,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 102472,
      "e": 97103,
      "ty": 7,
      "x": 833,
      "y": 925,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 102507,
      "e": 97138,
      "ty": 2,
      "x": 833,
      "y": 925
    },
    {
      "t": 102508,
      "e": 97139,
      "ty": 41,
      "x": 12646,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 102607,
      "e": 97238,
      "ty": 2,
      "x": 820,
      "y": 947
    },
    {
      "t": 102708,
      "e": 97339,
      "ty": 2,
      "x": 819,
      "y": 953
    },
    {
      "t": 102758,
      "e": 97389,
      "ty": 41,
      "x": 27894,
      "y": 52405,
      "ta": "html > body"
    },
    {
      "t": 102808,
      "e": 97439,
      "ty": 2,
      "x": 818,
      "y": 954
    },
    {
      "t": 102905,
      "e": 97536,
      "ty": 6,
      "x": 833,
      "y": 960,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 102909,
      "e": 97540,
      "ty": 2,
      "x": 833,
      "y": 960
    },
    {
      "t": 103008,
      "e": 97639,
      "ty": 2,
      "x": 836,
      "y": 962
    },
    {
      "t": 103008,
      "e": 97639,
      "ty": 41,
      "x": 48284,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 103060,
      "e": 97691,
      "ty": 3,
      "x": 836,
      "y": 962,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 103060,
      "e": 97691,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 103060,
      "e": 97691,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 103203,
      "e": 97834,
      "ty": 4,
      "x": 48284,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 103204,
      "e": 97835,
      "ty": 5,
      "x": 836,
      "y": 962,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 103205,
      "e": 97836,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 103238,
      "e": 97869,
      "ty": 7,
      "x": 844,
      "y": 977,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 103257,
      "e": 97888,
      "ty": 41,
      "x": 29362,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-3-2 > label"
    },
    {
      "t": 103272,
      "e": 97888,
      "ty": 6,
      "x": 861,
      "y": 1005,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 103308,
      "e": 97924,
      "ty": 2,
      "x": 878,
      "y": 1037
    },
    {
      "t": 103321,
      "e": 97937,
      "ty": 7,
      "x": 882,
      "y": 1049,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 103408,
      "e": 98024,
      "ty": 2,
      "x": 887,
      "y": 1053
    },
    {
      "t": 103508,
      "e": 98124,
      "ty": 2,
      "x": 892,
      "y": 1065
    },
    {
      "t": 103508,
      "e": 98124,
      "ty": 41,
      "x": 30442,
      "y": 58554,
      "ta": "html > body"
    },
    {
      "t": 103607,
      "e": 98223,
      "ty": 2,
      "x": 893,
      "y": 1057
    },
    {
      "t": 103639,
      "e": 98255,
      "ty": 6,
      "x": 893,
      "y": 1033,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 103708,
      "e": 98324,
      "ty": 2,
      "x": 893,
      "y": 1016
    },
    {
      "t": 103758,
      "e": 98374,
      "ty": 41,
      "x": 32767,
      "y": 21845,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 103973,
      "e": 98589,
      "ty": 3,
      "x": 893,
      "y": 1016,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 103973,
      "e": 98589,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 103974,
      "e": 98590,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 104091,
      "e": 98707,
      "ty": 4,
      "x": 32767,
      "y": 21845,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 104091,
      "e": 98707,
      "ty": 5,
      "x": 893,
      "y": 1016,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 104094,
      "e": 98710,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 104095,
      "e": 98711,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 104096,
      "e": 98712,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 104258,
      "e": 98874,
      "ty": 41,
      "x": 30477,
      "y": 55895,
      "ta": "html > body"
    },
    {
      "t": 104308,
      "e": 98924,
      "ty": 2,
      "x": 893,
      "y": 1017
    },
    {
      "t": 104508,
      "e": 99124,
      "ty": 2,
      "x": 889,
      "y": 1003
    },
    {
      "t": 104508,
      "e": 99124,
      "ty": 41,
      "x": 30339,
      "y": 55120,
      "ta": "html > body"
    },
    {
      "t": 104607,
      "e": 99223,
      "ty": 2,
      "x": 838,
      "y": 703
    },
    {
      "t": 104708,
      "e": 99324,
      "ty": 2,
      "x": 414,
      "y": 255
    },
    {
      "t": 104758,
      "e": 99374,
      "ty": 41,
      "x": 13671,
      "y": 12962,
      "ta": "html > body"
    },
    {
      "t": 104808,
      "e": 99424,
      "ty": 2,
      "x": 405,
      "y": 242
    },
    {
      "t": 104907,
      "e": 99523,
      "ty": 2,
      "x": 413,
      "y": 242
    },
    {
      "t": 105007,
      "e": 99623,
      "ty": 2,
      "x": 529,
      "y": 272
    },
    {
      "t": 105009,
      "e": 99625,
      "ty": 41,
      "x": 17942,
      "y": 14624,
      "ta": "html > body"
    },
    {
      "t": 105208,
      "e": 99824,
      "ty": 2,
      "x": 529,
      "y": 273
    },
    {
      "t": 105258,
      "e": 99874,
      "ty": 41,
      "x": 17942,
      "y": 14680,
      "ta": "html > body"
    },
    {
      "t": 105437,
      "e": 100053,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 105907,
      "e": 100523,
      "ty": 2,
      "x": 725,
      "y": 509
    },
    {
      "t": 106008,
      "e": 100624,
      "ty": 2,
      "x": 855,
      "y": 721
    },
    {
      "t": 106008,
      "e": 100624,
      "ty": 41,
      "x": 27626,
      "y": 30728,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 106108,
      "e": 100724,
      "ty": 2,
      "x": 903,
      "y": 1098
    },
    {
      "t": 106207,
      "e": 100823,
      "ty": 2,
      "x": 952,
      "y": 1199
    },
    {
      "t": 106507,
      "e": 101123,
      "ty": 2,
      "x": 952,
      "y": 1198
    },
    {
      "t": 106607,
      "e": 101223,
      "ty": 2,
      "x": 984,
      "y": 1127
    },
    {
      "t": 106708,
      "e": 101324,
      "ty": 2,
      "x": 989,
      "y": 1107
    },
    {
      "t": 106758,
      "e": 101374,
      "ty": 41,
      "x": 46576,
      "y": 19008,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 106808,
      "e": 101424,
      "ty": 2,
      "x": 1001,
      "y": 1115
    },
    {
      "t": 106908,
      "e": 101524,
      "ty": 2,
      "x": 1021,
      "y": 1131
    },
    {
      "t": 107008,
      "e": 101624,
      "ty": 2,
      "x": 1012,
      "y": 1120
    },
    {
      "t": 107009,
      "e": 101625,
      "ty": 41,
      "x": 57343,
      "y": 26210,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 107043,
      "e": 101659,
      "ty": 6,
      "x": 966,
      "y": 1097,
      "ta": "#start"
    },
    {
      "t": 107108,
      "e": 101724,
      "ty": 2,
      "x": 938,
      "y": 1083
    },
    {
      "t": 107258,
      "e": 101874,
      "ty": 41,
      "x": 15564,
      "y": 19877,
      "ta": "#start"
    },
    {
      "t": 107325,
      "e": 101941,
      "ty": 3,
      "x": 938,
      "y": 1083,
      "ta": "#start"
    },
    {
      "t": 107326,
      "e": 101942,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 107427,
      "e": 102043,
      "ty": 4,
      "x": 16110,
      "y": 19877,
      "ta": "#start"
    },
    {
      "t": 107428,
      "e": 102044,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 107429,
      "e": 102045,
      "ty": 5,
      "x": 939,
      "y": 1083,
      "ta": "#start"
    },
    {
      "t": 107430,
      "e": 102046,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 107508,
      "e": 102124,
      "ty": 2,
      "x": 999,
      "y": 1104
    },
    {
      "t": 107508,
      "e": 102124,
      "ty": 41,
      "x": 34403,
      "y": 60826,
      "ta": "html > body"
    },
    {
      "t": 107608,
      "e": 102224,
      "ty": 2,
      "x": 1007,
      "y": 1106
    },
    {
      "t": 108449,
      "e": 103065,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 108825,
      "e": 103441,
      "ty": 2,
      "x": 1015,
      "y": 1121
    },
    {
      "t": 108825,
      "e": 103441,
      "ty": 41,
      "x": 35963,
      "y": 32984,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 108908,
      "e": 103524,
      "ty": 2,
      "x": 1015,
      "y": 1123
    },
    {
      "t": 109008,
      "e": 103624,
      "ty": 41,
      "x": 35963,
      "y": 32985,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 109208,
      "e": 103824,
      "ty": 2,
      "x": 1026,
      "y": 1123
    },
    {
      "t": 109226,
      "e": 103842,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 100606, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 100612, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"ZEPVG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 6403, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 108336, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"ZEPVG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 6849, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"YANKEE\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"311\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 116194, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"ZEPVG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 5554, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 122837, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"ZEPVG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 4326, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 128166, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"ZEPVG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 16687, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 146205, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"ZEPVG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1031,y:971,t:1528139530868};\\\", \\\"{x:1023,y:893,t:1528139530881};\\\", \\\"{x:995,y:788,t:1528139530897};\\\", \\\"{x:969,y:691,t:1528139530914};\\\", \\\"{x:939,y:627,t:1528139530932};\\\", \\\"{x:916,y:581,t:1528139530949};\\\", \\\"{x:889,y:543,t:1528139530965};\\\", \\\"{x:882,y:539,t:1528139530982};\\\", \\\"{x:881,y:539,t:1528139530998};\\\", \\\"{x:881,y:536,t:1528139531044};\\\", \\\"{x:880,y:533,t:1528139531052};\\\", \\\"{x:877,y:530,t:1528139531064};\\\", \\\"{x:869,y:525,t:1528139531082};\\\", \\\"{x:857,y:514,t:1528139531099};\\\", \\\"{x:842,y:499,t:1528139531114};\\\", \\\"{x:820,y:473,t:1528139531132};\\\", \\\"{x:786,y:410,t:1528139531148};\\\", \\\"{x:769,y:349,t:1528139531165};\\\", \\\"{x:750,y:301,t:1528139531181};\\\", \\\"{x:749,y:270,t:1528139531198};\\\", \\\"{x:752,y:249,t:1528139531215};\\\", \\\"{x:758,y:238,t:1528139531231};\\\", \\\"{x:764,y:233,t:1528139531249};\\\", \\\"{x:766,y:231,t:1528139531265};\\\", \\\"{x:768,y:231,t:1528139531533};\\\", \\\"{x:778,y:225,t:1528139531549};\\\", \\\"{x:790,y:220,t:1528139531566};\\\", \\\"{x:803,y:215,t:1528139531582};\\\", \\\"{x:808,y:214,t:1528139531599};\\\", \\\"{x:809,y:214,t:1528139531629};\\\", \\\"{x:811,y:213,t:1528139531637};\\\", \\\"{x:811,y:212,t:1528139531649};\\\", \\\"{x:818,y:212,t:1528139531666};\\\", \\\"{x:825,y:216,t:1528139531682};\\\", \\\"{x:835,y:221,t:1528139531700};\\\", \\\"{x:842,y:228,t:1528139531716};\\\", \\\"{x:847,y:233,t:1528139531732};\\\", \\\"{x:851,y:242,t:1528139531749};\\\", \\\"{x:854,y:251,t:1528139531766};\\\", \\\"{x:857,y:256,t:1528139531782};\\\", \\\"{x:857,y:263,t:1528139531799};\\\", \\\"{x:857,y:271,t:1528139531816};\\\", \\\"{x:857,y:278,t:1528139531833};\\\", \\\"{x:857,y:283,t:1528139531849};\\\", \\\"{x:857,y:286,t:1528139531866};\\\", \\\"{x:857,y:289,t:1528139531883};\\\", \\\"{x:857,y:290,t:1528139531899};\\\", \\\"{x:857,y:291,t:1528139531916};\\\", \\\"{x:857,y:292,t:1528139531933};\\\", \\\"{x:857,y:294,t:1528139532142};\\\", \\\"{x:857,y:296,t:1528139532151};\\\", \\\"{x:855,y:302,t:1528139532166};\\\", \\\"{x:844,y:314,t:1528139532184};\\\", \\\"{x:832,y:323,t:1528139532200};\\\", \\\"{x:807,y:342,t:1528139532217};\\\", \\\"{x:763,y:370,t:1528139532233};\\\", \\\"{x:725,y:392,t:1528139532250};\\\", \\\"{x:706,y:400,t:1528139532267};\\\", \\\"{x:700,y:403,t:1528139532284};\\\", \\\"{x:699,y:403,t:1528139532733};\\\", \\\"{x:700,y:393,t:1528139532751};\\\", \\\"{x:705,y:377,t:1528139532768};\\\", \\\"{x:710,y:365,t:1528139532783};\\\", \\\"{x:717,y:349,t:1528139532801};\\\", \\\"{x:723,y:337,t:1528139532818};\\\", \\\"{x:726,y:329,t:1528139532833};\\\", \\\"{x:728,y:328,t:1528139532851};\\\", \\\"{x:730,y:327,t:1528139532933};\\\", \\\"{x:749,y:327,t:1528139532949};\\\", \\\"{x:791,y:347,t:1528139532967};\\\", \\\"{x:873,y:377,t:1528139532982};\\\", \\\"{x:975,y:418,t:1528139533000};\\\", \\\"{x:1097,y:458,t:1528139533017};\\\", \\\"{x:1211,y:495,t:1528139533034};\\\", \\\"{x:1296,y:530,t:1528139533050};\\\", \\\"{x:1326,y:547,t:1528139533067};\\\", \\\"{x:1340,y:553,t:1528139533084};\\\", \\\"{x:1338,y:556,t:1528139533910};\\\", \\\"{x:1316,y:572,t:1528139533919};\\\", \\\"{x:1258,y:608,t:1528139533934};\\\", \\\"{x:1244,y:619,t:1528139533952};\\\", \\\"{x:1242,y:619,t:1528139533968};\\\", \\\"{x:1242,y:620,t:1528139534228};\\\", \\\"{x:1243,y:632,t:1528139534236};\\\", \\\"{x:1243,y:657,t:1528139534251};\\\", \\\"{x:1251,y:699,t:1528139534268};\\\", \\\"{x:1262,y:716,t:1528139534284};\\\", \\\"{x:1267,y:714,t:1528139534302};\\\", \\\"{x:1269,y:714,t:1528139534477};\\\", \\\"{x:1269,y:716,t:1528139534493};\\\", \\\"{x:1269,y:729,t:1528139534501};\\\", \\\"{x:1269,y:789,t:1528139534519};\\\", \\\"{x:1293,y:867,t:1528139534536};\\\", \\\"{x:1315,y:898,t:1528139534551};\\\", \\\"{x:1327,y:917,t:1528139534569};\\\", \\\"{x:1334,y:938,t:1528139534586};\\\", \\\"{x:1341,y:953,t:1528139534602};\\\", \\\"{x:1342,y:963,t:1528139534619};\\\", \\\"{x:1344,y:965,t:1528139534636};\\\", \\\"{x:1344,y:970,t:1528139534652};\\\", \\\"{x:1344,y:972,t:1528139534669};\\\", \\\"{x:1344,y:970,t:1528139534749};\\\", \\\"{x:1342,y:965,t:1528139534758};\\\", \\\"{x:1339,y:962,t:1528139534768};\\\", \\\"{x:1330,y:947,t:1528139534786};\\\", \\\"{x:1314,y:932,t:1528139534803};\\\", \\\"{x:1303,y:913,t:1528139534819};\\\", \\\"{x:1296,y:894,t:1528139534835};\\\", \\\"{x:1290,y:867,t:1528139534853};\\\", \\\"{x:1290,y:858,t:1528139534868};\\\", \\\"{x:1286,y:845,t:1528139534885};\\\", \\\"{x:1285,y:841,t:1528139534902};\\\", \\\"{x:1285,y:838,t:1528139534919};\\\", \\\"{x:1284,y:836,t:1528139534939};\\\", \\\"{x:1283,y:835,t:1528139534955};\\\", \\\"{x:1283,y:834,t:1528139535021};\\\", \\\"{x:1283,y:833,t:1528139535034};\\\", \\\"{x:1282,y:832,t:1528139535051};\\\", \\\"{x:1279,y:826,t:1528139542877};\\\", \\\"{x:1245,y:800,t:1528139542893};\\\", \\\"{x:1086,y:709,t:1528139542906};\\\", \\\"{x:887,y:613,t:1528139542923};\\\", \\\"{x:518,y:445,t:1528139542942};\\\", \\\"{x:282,y:344,t:1528139542958};\\\", \\\"{x:74,y:231,t:1528139542976};\\\", \\\"{x:0,y:105,t:1528139542992};\\\", \\\"{x:0,y:14,t:1528139543008};\\\", \\\"{x:0,y:0,t:1528139543025};\\\", \\\"{x:0,y:2,t:1528139543158};\\\", \\\"{x:0,y:16,t:1528139543165};\\\", \\\"{x:0,y:38,t:1528139543176};\\\", \\\"{x:6,y:110,t:1528139543192};\\\", \\\"{x:27,y:162,t:1528139543209};\\\", \\\"{x:41,y:185,t:1528139543226};\\\", \\\"{x:54,y:204,t:1528139543242};\\\", \\\"{x:67,y:218,t:1528139543259};\\\", \\\"{x:78,y:230,t:1528139543276};\\\", \\\"{x:86,y:243,t:1528139543292};\\\", \\\"{x:103,y:270,t:1528139543309};\\\", \\\"{x:115,y:291,t:1528139543326};\\\", \\\"{x:131,y:308,t:1528139543342};\\\", \\\"{x:145,y:326,t:1528139543359};\\\", \\\"{x:157,y:349,t:1528139543376};\\\", \\\"{x:173,y:374,t:1528139543393};\\\", \\\"{x:183,y:386,t:1528139543409};\\\", \\\"{x:194,y:397,t:1528139543427};\\\", \\\"{x:206,y:408,t:1528139543443};\\\", \\\"{x:218,y:420,t:1528139543460};\\\", \\\"{x:231,y:433,t:1528139543476};\\\", \\\"{x:254,y:462,t:1528139543493};\\\", \\\"{x:282,y:486,t:1528139543509};\\\", \\\"{x:304,y:503,t:1528139543526};\\\", \\\"{x:325,y:513,t:1528139543543};\\\", \\\"{x:340,y:520,t:1528139543559};\\\", \\\"{x:352,y:525,t:1528139543576};\\\", \\\"{x:360,y:529,t:1528139543593};\\\", \\\"{x:362,y:529,t:1528139543621};\\\", \\\"{x:362,y:530,t:1528139543637};\\\", \\\"{x:362,y:532,t:1528139543669};\\\", \\\"{x:363,y:533,t:1528139543677};\\\", \\\"{x:364,y:539,t:1528139543693};\\\", \\\"{x:364,y:541,t:1528139543709};\\\", \\\"{x:365,y:542,t:1528139543743};\\\", \\\"{x:366,y:542,t:1528139543759};\\\", \\\"{x:366,y:545,t:1528139543776};\\\", \\\"{x:370,y:555,t:1528139543792};\\\", \\\"{x:375,y:562,t:1528139543809};\\\", \\\"{x:379,y:567,t:1528139543825};\\\", \\\"{x:381,y:570,t:1528139543843};\\\", \\\"{x:381,y:571,t:1528139543859};\\\", \\\"{x:382,y:571,t:1528139544069};\\\", \\\"{x:383,y:569,t:1528139544077};\\\", \\\"{x:383,y:566,t:1528139544093};\\\", \\\"{x:383,y:560,t:1528139544109};\\\", \\\"{x:383,y:559,t:1528139544127};\\\", \\\"{x:383,y:557,t:1528139544142};\\\", \\\"{x:383,y:556,t:1528139544412};\\\", \\\"{x:383,y:560,t:1528139544426};\\\", \\\"{x:400,y:584,t:1528139544443};\\\", \\\"{x:432,y:612,t:1528139544460};\\\", \\\"{x:450,y:625,t:1528139544477};\\\", \\\"{x:453,y:630,t:1528139544493};\\\", \\\"{x:455,y:633,t:1528139544510};\\\", \\\"{x:456,y:635,t:1528139544549};\\\", \\\"{x:456,y:636,t:1528139544694};\\\", \\\"{x:453,y:639,t:1528139544710};\\\", \\\"{x:445,y:644,t:1528139544727};\\\", \\\"{x:440,y:653,t:1528139544746};\\\", \\\"{x:436,y:658,t:1528139544760};\\\", \\\"{x:436,y:660,t:1528139544776};\\\", \\\"{x:435,y:664,t:1528139544793};\\\", \\\"{x:434,y:672,t:1528139544810};\\\", \\\"{x:434,y:690,t:1528139544827};\\\", \\\"{x:433,y:693,t:1528139544844};\\\", \\\"{x:431,y:697,t:1528139544859};\\\", \\\"{x:430,y:698,t:1528139544877};\\\", \\\"{x:429,y:698,t:1528139544893};\\\", \\\"{x:429,y:701,t:1528139544911};\\\", \\\"{x:429,y:708,t:1528139544927};\\\", \\\"{x:433,y:718,t:1528139544944};\\\", \\\"{x:435,y:724,t:1528139544959};\\\", \\\"{x:435,y:726,t:1528139544976};\\\", \\\"{x:435,y:727,t:1528139545053};\\\", \\\"{x:435,y:729,t:1528139545061};\\\", \\\"{x:435,y:731,t:1528139545077};\\\", \\\"{x:435,y:733,t:1528139545094};\\\", \\\"{x:435,y:734,t:1528139545229};\\\", \\\"{x:435,y:735,t:1528139545244};\\\", \\\"{x:435,y:738,t:1528139545709};\\\", \\\"{x:436,y:742,t:1528139545717};\\\", \\\"{x:438,y:744,t:1528139545728};\\\", \\\"{x:445,y:752,t:1528139545746};\\\", \\\"{x:449,y:760,t:1528139545761};\\\", \\\"{x:450,y:760,t:1528139545860};\\\", \\\"{x:450,y:760,t:1528139545980};\\\", \\\"{x:455,y:758,t:1528139546293};\\\", \\\"{x:464,y:752,t:1528139546312};\\\", \\\"{x:470,y:746,t:1528139546327};\\\", \\\"{x:470,y:743,t:1528139546344};\\\" ] }, { \\\"rt\\\": 13047, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 160512, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"ZEPVG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-G -U -D -D -D \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:470,y:742,t:1528139548205};\\\", \\\"{x:468,y:739,t:1528139548212};\\\", \\\"{x:464,y:739,t:1528139548229};\\\", \\\"{x:463,y:739,t:1528139548285};\\\", \\\"{x:462,y:739,t:1528139548317};\\\", \\\"{x:458,y:736,t:1528139548331};\\\", \\\"{x:450,y:734,t:1528139548346};\\\", \\\"{x:442,y:730,t:1528139548362};\\\", \\\"{x:441,y:730,t:1528139548379};\\\", \\\"{x:440,y:730,t:1528139548396};\\\", \\\"{x:440,y:728,t:1528139549117};\\\", \\\"{x:441,y:728,t:1528139549130};\\\", \\\"{x:441,y:724,t:1528139549147};\\\", \\\"{x:441,y:712,t:1528139549164};\\\", \\\"{x:439,y:706,t:1528139549180};\\\", \\\"{x:438,y:705,t:1528139549493};\\\", \\\"{x:438,y:703,t:1528139549501};\\\", \\\"{x:438,y:702,t:1528139549514};\\\", \\\"{x:444,y:697,t:1528139549531};\\\", \\\"{x:456,y:689,t:1528139549547};\\\", \\\"{x:483,y:669,t:1528139549566};\\\", \\\"{x:540,y:653,t:1528139549581};\\\", \\\"{x:619,y:637,t:1528139549597};\\\", \\\"{x:694,y:628,t:1528139549614};\\\", \\\"{x:805,y:616,t:1528139549631};\\\", \\\"{x:930,y:612,t:1528139549646};\\\", \\\"{x:1073,y:628,t:1528139549664};\\\", \\\"{x:1240,y:655,t:1528139549681};\\\", \\\"{x:1404,y:668,t:1528139549697};\\\", \\\"{x:1565,y:690,t:1528139549714};\\\", \\\"{x:1711,y:710,t:1528139549731};\\\", \\\"{x:1775,y:720,t:1528139549747};\\\", \\\"{x:1765,y:720,t:1528139550005};\\\", \\\"{x:1754,y:719,t:1528139550014};\\\", \\\"{x:1735,y:716,t:1528139550031};\\\", \\\"{x:1730,y:716,t:1528139550048};\\\", \\\"{x:1726,y:716,t:1528139550125};\\\", \\\"{x:1715,y:722,t:1528139550133};\\\", \\\"{x:1704,y:730,t:1528139550149};\\\", \\\"{x:1661,y:760,t:1528139550164};\\\", \\\"{x:1661,y:761,t:1528139550181};\\\", \\\"{x:1659,y:761,t:1528139550494};\\\", \\\"{x:1655,y:763,t:1528139550741};\\\", \\\"{x:1652,y:764,t:1528139550762};\\\", \\\"{x:1624,y:776,t:1528139550783};\\\", \\\"{x:1610,y:782,t:1528139550797};\\\", \\\"{x:1600,y:786,t:1528139550813};\\\", \\\"{x:1585,y:789,t:1528139550830};\\\", \\\"{x:1571,y:791,t:1528139550846};\\\", \\\"{x:1554,y:796,t:1528139550864};\\\", \\\"{x:1545,y:800,t:1528139550880};\\\", \\\"{x:1542,y:801,t:1528139550897};\\\", \\\"{x:1538,y:803,t:1528139550914};\\\", \\\"{x:1537,y:804,t:1528139550931};\\\", \\\"{x:1536,y:805,t:1528139550947};\\\", \\\"{x:1531,y:807,t:1528139550964};\\\", \\\"{x:1511,y:811,t:1528139550981};\\\", \\\"{x:1489,y:811,t:1528139550997};\\\", \\\"{x:1476,y:811,t:1528139551014};\\\", \\\"{x:1460,y:811,t:1528139551032};\\\", \\\"{x:1458,y:811,t:1528139551047};\\\", \\\"{x:1444,y:810,t:1528139551064};\\\", \\\"{x:1436,y:806,t:1528139551081};\\\", \\\"{x:1431,y:805,t:1528139551097};\\\", \\\"{x:1431,y:804,t:1528139551114};\\\", \\\"{x:1429,y:805,t:1528139551237};\\\", \\\"{x:1428,y:808,t:1528139551248};\\\", \\\"{x:1422,y:816,t:1528139551264};\\\", \\\"{x:1418,y:821,t:1528139551280};\\\", \\\"{x:1416,y:821,t:1528139551405};\\\", \\\"{x:1415,y:821,t:1528139551429};\\\", \\\"{x:1415,y:820,t:1528139551445};\\\", \\\"{x:1414,y:818,t:1528139551452};\\\", \\\"{x:1414,y:817,t:1528139551464};\\\", \\\"{x:1412,y:815,t:1528139551517};\\\", \\\"{x:1411,y:815,t:1528139551530};\\\", \\\"{x:1406,y:813,t:1528139551547};\\\", \\\"{x:1398,y:809,t:1528139551564};\\\", \\\"{x:1385,y:807,t:1528139551580};\\\", \\\"{x:1384,y:807,t:1528139551597};\\\", \\\"{x:1385,y:806,t:1528139551741};\\\", \\\"{x:1385,y:805,t:1528139551749};\\\", \\\"{x:1386,y:805,t:1528139551764};\\\", \\\"{x:1387,y:805,t:1528139551893};\\\", \\\"{x:1394,y:805,t:1528139551901};\\\", \\\"{x:1423,y:807,t:1528139551915};\\\", \\\"{x:1527,y:798,t:1528139551931};\\\", \\\"{x:1620,y:763,t:1528139551948};\\\", \\\"{x:1735,y:714,t:1528139551965};\\\", \\\"{x:1778,y:694,t:1528139551981};\\\", \\\"{x:1812,y:678,t:1528139551997};\\\", \\\"{x:1825,y:670,t:1528139552015};\\\", \\\"{x:1826,y:669,t:1528139552030};\\\", \\\"{x:1827,y:669,t:1528139552053};\\\", \\\"{x:1827,y:668,t:1528139552093};\\\", \\\"{x:1826,y:668,t:1528139552181};\\\", \\\"{x:1809,y:672,t:1528139552197};\\\", \\\"{x:1782,y:669,t:1528139552215};\\\", \\\"{x:1743,y:660,t:1528139552230};\\\", \\\"{x:1714,y:647,t:1528139552247};\\\", \\\"{x:1674,y:634,t:1528139552268};\\\", \\\"{x:1649,y:625,t:1528139552280};\\\", \\\"{x:1630,y:618,t:1528139552297};\\\", \\\"{x:1619,y:609,t:1528139552314};\\\", \\\"{x:1609,y:602,t:1528139552329};\\\", \\\"{x:1595,y:595,t:1528139552347};\\\", \\\"{x:1583,y:588,t:1528139552364};\\\", \\\"{x:1571,y:582,t:1528139552380};\\\", \\\"{x:1563,y:578,t:1528139552397};\\\", \\\"{x:1560,y:574,t:1528139552414};\\\", \\\"{x:1558,y:571,t:1528139552430};\\\", \\\"{x:1558,y:569,t:1528139552447};\\\", \\\"{x:1556,y:567,t:1528139552464};\\\", \\\"{x:1554,y:566,t:1528139552480};\\\", \\\"{x:1553,y:565,t:1528139552497};\\\", \\\"{x:1552,y:563,t:1528139552514};\\\", \\\"{x:1544,y:557,t:1528139552530};\\\", \\\"{x:1534,y:550,t:1528139552547};\\\", \\\"{x:1520,y:542,t:1528139552564};\\\", \\\"{x:1504,y:534,t:1528139552580};\\\", \\\"{x:1484,y:524,t:1528139552597};\\\", \\\"{x:1473,y:517,t:1528139552614};\\\", \\\"{x:1462,y:510,t:1528139552630};\\\", \\\"{x:1453,y:504,t:1528139552648};\\\", \\\"{x:1439,y:498,t:1528139552664};\\\", \\\"{x:1434,y:495,t:1528139552680};\\\", \\\"{x:1429,y:493,t:1528139552697};\\\", \\\"{x:1425,y:493,t:1528139552714};\\\", \\\"{x:1418,y:493,t:1528139552730};\\\", \\\"{x:1412,y:494,t:1528139552747};\\\", \\\"{x:1407,y:498,t:1528139552765};\\\", \\\"{x:1406,y:500,t:1528139552780};\\\", \\\"{x:1400,y:519,t:1528139552796};\\\", \\\"{x:1399,y:533,t:1528139552815};\\\", \\\"{x:1398,y:547,t:1528139552830};\\\", \\\"{x:1398,y:558,t:1528139552848};\\\", \\\"{x:1398,y:566,t:1528139552864};\\\", \\\"{x:1398,y:572,t:1528139552880};\\\", \\\"{x:1402,y:576,t:1528139552898};\\\", \\\"{x:1404,y:578,t:1528139552914};\\\", \\\"{x:1404,y:579,t:1528139552930};\\\", \\\"{x:1403,y:579,t:1528139553037};\\\", \\\"{x:1403,y:581,t:1528139553173};\\\", \\\"{x:1407,y:582,t:1528139553181};\\\", \\\"{x:1413,y:583,t:1528139553197};\\\", \\\"{x:1413,y:593,t:1528139553541};\\\", \\\"{x:1424,y:610,t:1528139553549};\\\", \\\"{x:1434,y:639,t:1528139553564};\\\", \\\"{x:1458,y:720,t:1528139553580};\\\", \\\"{x:1482,y:795,t:1528139553597};\\\", \\\"{x:1487,y:818,t:1528139553613};\\\", \\\"{x:1489,y:832,t:1528139553631};\\\", \\\"{x:1489,y:835,t:1528139553647};\\\", \\\"{x:1489,y:837,t:1528139553669};\\\", \\\"{x:1489,y:828,t:1528139553773};\\\", \\\"{x:1489,y:817,t:1528139553781};\\\", \\\"{x:1493,y:794,t:1528139553797};\\\", \\\"{x:1511,y:747,t:1528139553813};\\\", \\\"{x:1540,y:634,t:1528139553830};\\\", \\\"{x:1557,y:541,t:1528139553847};\\\", \\\"{x:1577,y:440,t:1528139553864};\\\", \\\"{x:1582,y:361,t:1528139553880};\\\", \\\"{x:1585,y:332,t:1528139553897};\\\", \\\"{x:1585,y:305,t:1528139553913};\\\", \\\"{x:1584,y:284,t:1528139553930};\\\", \\\"{x:1583,y:268,t:1528139553947};\\\", \\\"{x:1571,y:249,t:1528139553963};\\\", \\\"{x:1567,y:236,t:1528139553980};\\\", \\\"{x:1565,y:234,t:1528139553998};\\\", \\\"{x:1565,y:241,t:1528139554077};\\\", \\\"{x:1568,y:264,t:1528139554085};\\\", \\\"{x:1575,y:302,t:1528139554098};\\\", \\\"{x:1593,y:359,t:1528139554113};\\\", \\\"{x:1603,y:389,t:1528139554130};\\\", \\\"{x:1607,y:400,t:1528139554148};\\\", \\\"{x:1611,y:408,t:1528139554163};\\\", \\\"{x:1613,y:416,t:1528139554180};\\\", \\\"{x:1616,y:423,t:1528139554196};\\\", \\\"{x:1618,y:427,t:1528139554218};\\\", \\\"{x:1618,y:432,t:1528139554229};\\\", \\\"{x:1620,y:436,t:1528139554248};\\\", \\\"{x:1621,y:437,t:1528139554263};\\\", \\\"{x:1621,y:439,t:1528139554280};\\\", \\\"{x:1621,y:447,t:1528139554297};\\\", \\\"{x:1623,y:455,t:1528139554314};\\\", \\\"{x:1624,y:456,t:1528139554330};\\\", \\\"{x:1624,y:453,t:1528139554436};\\\", \\\"{x:1624,y:447,t:1528139554447};\\\", \\\"{x:1624,y:440,t:1528139554463};\\\", \\\"{x:1624,y:438,t:1528139554480};\\\", \\\"{x:1624,y:434,t:1528139554497};\\\", \\\"{x:1623,y:433,t:1528139554750};\\\", \\\"{x:1619,y:433,t:1528139554767};\\\", \\\"{x:1583,y:430,t:1528139554801};\\\", \\\"{x:1580,y:430,t:1528139554818};\\\", \\\"{x:1580,y:428,t:1528139554997};\\\", \\\"{x:1583,y:427,t:1528139555005};\\\", \\\"{x:1584,y:426,t:1528139555018};\\\", \\\"{x:1591,y:424,t:1528139555035};\\\", \\\"{x:1596,y:423,t:1528139555053};\\\", \\\"{x:1597,y:422,t:1528139555069};\\\", \\\"{x:1598,y:422,t:1528139555117};\\\", \\\"{x:1600,y:422,t:1528139555341};\\\", \\\"{x:1602,y:425,t:1528139555352};\\\", \\\"{x:1607,y:432,t:1528139555369};\\\", \\\"{x:1613,y:437,t:1528139555386};\\\", \\\"{x:1615,y:439,t:1528139555402};\\\", \\\"{x:1616,y:439,t:1528139555419};\\\", \\\"{x:1617,y:439,t:1528139555709};\\\", \\\"{x:1617,y:438,t:1528139555748};\\\", \\\"{x:1607,y:449,t:1528139557285};\\\", \\\"{x:1585,y:463,t:1528139557292};\\\", \\\"{x:1554,y:483,t:1528139557303};\\\", \\\"{x:1469,y:519,t:1528139557320};\\\", \\\"{x:1379,y:551,t:1528139557337};\\\", \\\"{x:1269,y:575,t:1528139557354};\\\", \\\"{x:1141,y:599,t:1528139557370};\\\", \\\"{x:1026,y:609,t:1528139557388};\\\", \\\"{x:884,y:615,t:1528139557404};\\\", \\\"{x:683,y:618,t:1528139557421};\\\", \\\"{x:562,y:614,t:1528139557438};\\\", \\\"{x:484,y:614,t:1528139557453};\\\", \\\"{x:427,y:607,t:1528139557470};\\\", \\\"{x:403,y:598,t:1528139557487};\\\", \\\"{x:401,y:598,t:1528139557504};\\\", \\\"{x:401,y:597,t:1528139557520};\\\", \\\"{x:399,y:596,t:1528139557580};\\\", \\\"{x:398,y:593,t:1528139557588};\\\", \\\"{x:393,y:586,t:1528139557604};\\\", \\\"{x:390,y:581,t:1528139557621};\\\", \\\"{x:388,y:576,t:1528139557637};\\\", \\\"{x:386,y:573,t:1528139557654};\\\", \\\"{x:386,y:571,t:1528139557672};\\\", \\\"{x:386,y:570,t:1528139557687};\\\", \\\"{x:386,y:569,t:1528139557703};\\\", \\\"{x:389,y:572,t:1528139557821};\\\", \\\"{x:399,y:590,t:1528139557839};\\\", \\\"{x:407,y:604,t:1528139557854};\\\", \\\"{x:408,y:607,t:1528139557871};\\\", \\\"{x:409,y:609,t:1528139557887};\\\", \\\"{x:407,y:609,t:1528139557941};\\\", \\\"{x:396,y:609,t:1528139557954};\\\", \\\"{x:380,y:599,t:1528139557972};\\\", \\\"{x:364,y:598,t:1528139557988};\\\", \\\"{x:316,y:598,t:1528139558004};\\\", \\\"{x:313,y:598,t:1528139558021};\\\", \\\"{x:312,y:598,t:1528139558116};\\\", \\\"{x:310,y:598,t:1528139558164};\\\", \\\"{x:306,y:602,t:1528139558172};\\\", \\\"{x:297,y:609,t:1528139558188};\\\", \\\"{x:290,y:617,t:1528139558205};\\\", \\\"{x:283,y:623,t:1528139558222};\\\", \\\"{x:275,y:626,t:1528139558236};\\\", \\\"{x:271,y:628,t:1528139558254};\\\", \\\"{x:260,y:634,t:1528139558270};\\\", \\\"{x:245,y:639,t:1528139558288};\\\", \\\"{x:233,y:642,t:1528139558304};\\\", \\\"{x:226,y:643,t:1528139558321};\\\", \\\"{x:224,y:644,t:1528139558337};\\\", \\\"{x:224,y:646,t:1528139558388};\\\", \\\"{x:222,y:646,t:1528139558404};\\\", \\\"{x:221,y:646,t:1528139558477};\\\", \\\"{x:220,y:646,t:1528139558488};\\\", \\\"{x:219,y:646,t:1528139558505};\\\", \\\"{x:219,y:647,t:1528139558539};\\\", \\\"{x:219,y:649,t:1528139558555};\\\", \\\"{x:218,y:649,t:1528139558652};\\\", \\\"{x:216,y:649,t:1528139558660};\\\", \\\"{x:212,y:653,t:1528139558724};\\\", \\\"{x:188,y:669,t:1528139558738};\\\", \\\"{x:184,y:673,t:1528139558754};\\\", \\\"{x:183,y:674,t:1528139558771};\\\", \\\"{x:186,y:674,t:1528139559188};\\\", \\\"{x:230,y:686,t:1528139559206};\\\", \\\"{x:286,y:705,t:1528139559223};\\\", \\\"{x:361,y:738,t:1528139559238};\\\", \\\"{x:451,y:774,t:1528139559255};\\\", \\\"{x:510,y:799,t:1528139559272};\\\", \\\"{x:555,y:814,t:1528139559288};\\\", \\\"{x:570,y:817,t:1528139559305};\\\", \\\"{x:573,y:817,t:1528139559322};\\\", \\\"{x:573,y:818,t:1528139559338};\\\", \\\"{x:574,y:818,t:1528139559445};\\\", \\\"{x:576,y:818,t:1528139559455};\\\", \\\"{x:577,y:813,t:1528139559473};\\\", \\\"{x:580,y:810,t:1528139559488};\\\", \\\"{x:580,y:806,t:1528139559505};\\\", \\\"{x:581,y:802,t:1528139559523};\\\", \\\"{x:581,y:798,t:1528139559540};\\\", \\\"{x:582,y:796,t:1528139559556};\\\", \\\"{x:582,y:794,t:1528139559572};\\\", \\\"{x:582,y:793,t:1528139559589};\\\", \\\"{x:582,y:791,t:1528139559605};\\\", \\\"{x:582,y:788,t:1528139559622};\\\", \\\"{x:579,y:781,t:1528139559640};\\\", \\\"{x:578,y:779,t:1528139559655};\\\", \\\"{x:577,y:777,t:1528139559672};\\\", \\\"{x:575,y:777,t:1528139559690};\\\", \\\"{x:575,y:775,t:1528139559705};\\\", \\\"{x:575,y:773,t:1528139559722};\\\", \\\"{x:572,y:769,t:1528139559739};\\\", \\\"{x:572,y:768,t:1528139559755};\\\", \\\"{x:571,y:766,t:1528139559773};\\\", \\\"{x:570,y:766,t:1528139559797};\\\", \\\"{x:570,y:765,t:1528139560004};\\\", \\\"{x:567,y:762,t:1528139560013};\\\", \\\"{x:562,y:760,t:1528139560023};\\\", \\\"{x:550,y:754,t:1528139560039};\\\", \\\"{x:540,y:753,t:1528139560056};\\\", \\\"{x:530,y:751,t:1528139560072};\\\", \\\"{x:529,y:751,t:1528139560089};\\\", \\\"{x:534,y:751,t:1528139560356};\\\", \\\"{x:553,y:745,t:1528139560373};\\\", \\\"{x:578,y:735,t:1528139560389};\\\", \\\"{x:601,y:728,t:1528139560406};\\\", \\\"{x:613,y:723,t:1528139560423};\\\", \\\"{x:620,y:721,t:1528139560557};\\\", \\\"{x:673,y:708,t:1528139560573};\\\", \\\"{x:681,y:706,t:1528139560589};\\\", \\\"{x:681,y:705,t:1528139561204};\\\", \\\"{x:681,y:703,t:1528139561213};\\\", \\\"{x:682,y:699,t:1528139561223};\\\", \\\"{x:684,y:694,t:1528139561240};\\\", \\\"{x:685,y:693,t:1528139561258};\\\", \\\"{x:693,y:687,t:1528139561274};\\\", \\\"{x:716,y:667,t:1528139561296};\\\", \\\"{x:725,y:660,t:1528139561307};\\\", \\\"{x:750,y:642,t:1528139561322};\\\", \\\"{x:781,y:612,t:1528139561339};\\\", \\\"{x:855,y:587,t:1528139561357};\\\", \\\"{x:967,y:558,t:1528139561373};\\\" ] }, { \\\"rt\\\": 15118, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 176845, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"ZEPVG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -C -C -Z \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1254,y:429,t:1528139561479};\\\", \\\"{x:1251,y:437,t:1528139565038};\\\", \\\"{x:1241,y:464,t:1528139565044};\\\", \\\"{x:1219,y:502,t:1528139565061};\\\", \\\"{x:1211,y:520,t:1528139565077};\\\", \\\"{x:1203,y:538,t:1528139565093};\\\", \\\"{x:1198,y:547,t:1528139565109};\\\", \\\"{x:1191,y:549,t:1528139565173};\\\", \\\"{x:1187,y:553,t:1528139565181};\\\", \\\"{x:1181,y:562,t:1528139565194};\\\", \\\"{x:1178,y:574,t:1528139565211};\\\", \\\"{x:1176,y:582,t:1528139565227};\\\", \\\"{x:1175,y:589,t:1528139565244};\\\", \\\"{x:1179,y:605,t:1528139565260};\\\", \\\"{x:1181,y:607,t:1528139565277};\\\", \\\"{x:1182,y:609,t:1528139565301};\\\", \\\"{x:1184,y:607,t:1528139565311};\\\", \\\"{x:1186,y:610,t:1528139565629};\\\", \\\"{x:1188,y:618,t:1528139565644};\\\", \\\"{x:1204,y:648,t:1528139565661};\\\", \\\"{x:1220,y:676,t:1528139565678};\\\", \\\"{x:1236,y:702,t:1528139565694};\\\", \\\"{x:1236,y:703,t:1528139565716};\\\", \\\"{x:1234,y:705,t:1528139565861};\\\", \\\"{x:1233,y:709,t:1528139565878};\\\", \\\"{x:1233,y:723,t:1528139565894};\\\", \\\"{x:1229,y:735,t:1528139565910};\\\", \\\"{x:1226,y:754,t:1528139565928};\\\", \\\"{x:1220,y:775,t:1528139565944};\\\", \\\"{x:1215,y:796,t:1528139565961};\\\", \\\"{x:1208,y:822,t:1528139565978};\\\", \\\"{x:1198,y:838,t:1528139565994};\\\", \\\"{x:1195,y:847,t:1528139566011};\\\", \\\"{x:1194,y:849,t:1528139566028};\\\", \\\"{x:1193,y:850,t:1528139566045};\\\", \\\"{x:1193,y:853,t:1528139566061};\\\", \\\"{x:1193,y:861,t:1528139566078};\\\", \\\"{x:1193,y:867,t:1528139566095};\\\", \\\"{x:1193,y:869,t:1528139566111};\\\", \\\"{x:1193,y:870,t:1528139566141};\\\", \\\"{x:1193,y:869,t:1528139566204};\\\", \\\"{x:1193,y:866,t:1528139566212};\\\", \\\"{x:1193,y:861,t:1528139566228};\\\", \\\"{x:1199,y:842,t:1528139566245};\\\", \\\"{x:1205,y:831,t:1528139566261};\\\", \\\"{x:1209,y:826,t:1528139566278};\\\", \\\"{x:1210,y:823,t:1528139566295};\\\", \\\"{x:1210,y:822,t:1528139566323};\\\", \\\"{x:1210,y:824,t:1528139566412};\\\", \\\"{x:1210,y:831,t:1528139566433};\\\", \\\"{x:1213,y:841,t:1528139566446};\\\", \\\"{x:1214,y:843,t:1528139566477};\\\", \\\"{x:1214,y:841,t:1528139566781};\\\", \\\"{x:1214,y:840,t:1528139566795};\\\", \\\"{x:1213,y:837,t:1528139566812};\\\", \\\"{x:1213,y:836,t:1528139566829};\\\", \\\"{x:1216,y:833,t:1528139567577};\\\", \\\"{x:1229,y:829,t:1528139567596};\\\", \\\"{x:1240,y:826,t:1528139567611};\\\", \\\"{x:1242,y:825,t:1528139567629};\\\", \\\"{x:1246,y:826,t:1528139567676};\\\", \\\"{x:1251,y:829,t:1528139567684};\\\", \\\"{x:1264,y:832,t:1528139567695};\\\", \\\"{x:1289,y:844,t:1528139567712};\\\", \\\"{x:1328,y:855,t:1528139567728};\\\", \\\"{x:1360,y:865,t:1528139567745};\\\", \\\"{x:1382,y:872,t:1528139567763};\\\", \\\"{x:1393,y:877,t:1528139567778};\\\", \\\"{x:1396,y:878,t:1528139567796};\\\", \\\"{x:1396,y:880,t:1528139567853};\\\", \\\"{x:1396,y:881,t:1528139567863};\\\", \\\"{x:1396,y:884,t:1528139567879};\\\", \\\"{x:1397,y:888,t:1528139567896};\\\", \\\"{x:1397,y:889,t:1528139567913};\\\", \\\"{x:1397,y:891,t:1528139567930};\\\", \\\"{x:1397,y:892,t:1528139567972};\\\", \\\"{x:1397,y:893,t:1528139567979};\\\", \\\"{x:1396,y:894,t:1528139567996};\\\", \\\"{x:1393,y:896,t:1528139568012};\\\", \\\"{x:1392,y:897,t:1528139568029};\\\", \\\"{x:1389,y:897,t:1528139568045};\\\", \\\"{x:1388,y:898,t:1528139568063};\\\", \\\"{x:1386,y:900,t:1528139568080};\\\", \\\"{x:1385,y:900,t:1528139568096};\\\", \\\"{x:1382,y:902,t:1528139568112};\\\", \\\"{x:1380,y:903,t:1528139568130};\\\", \\\"{x:1380,y:904,t:1528139568145};\\\", \\\"{x:1376,y:907,t:1528139568163};\\\", \\\"{x:1372,y:909,t:1528139568180};\\\", \\\"{x:1369,y:912,t:1528139568196};\\\", \\\"{x:1364,y:915,t:1528139568213};\\\", \\\"{x:1362,y:917,t:1528139568230};\\\", \\\"{x:1360,y:917,t:1528139568260};\\\", \\\"{x:1360,y:918,t:1528139568268};\\\", \\\"{x:1359,y:918,t:1528139568280};\\\", \\\"{x:1358,y:919,t:1528139568298};\\\", \\\"{x:1357,y:920,t:1528139568312};\\\", \\\"{x:1356,y:920,t:1528139568330};\\\", \\\"{x:1356,y:921,t:1528139568347};\\\", \\\"{x:1355,y:921,t:1528139568380};\\\", \\\"{x:1355,y:922,t:1528139568413};\\\", \\\"{x:1354,y:923,t:1528139568430};\\\", \\\"{x:1353,y:924,t:1528139568446};\\\", \\\"{x:1352,y:924,t:1528139568463};\\\", \\\"{x:1351,y:925,t:1528139568480};\\\", \\\"{x:1351,y:926,t:1528139568496};\\\", \\\"{x:1350,y:927,t:1528139568513};\\\", \\\"{x:1349,y:929,t:1528139568530};\\\", \\\"{x:1349,y:930,t:1528139568547};\\\", \\\"{x:1349,y:931,t:1528139568563};\\\", \\\"{x:1348,y:933,t:1528139568580};\\\", \\\"{x:1348,y:934,t:1528139568597};\\\", \\\"{x:1347,y:937,t:1528139568613};\\\", \\\"{x:1346,y:939,t:1528139568630};\\\", \\\"{x:1346,y:940,t:1528139568669};\\\", \\\"{x:1346,y:941,t:1528139568741};\\\", \\\"{x:1346,y:939,t:1528139568861};\\\", \\\"{x:1346,y:934,t:1528139568869};\\\", \\\"{x:1346,y:930,t:1528139568880};\\\", \\\"{x:1346,y:924,t:1528139568898};\\\", \\\"{x:1346,y:919,t:1528139568914};\\\", \\\"{x:1346,y:916,t:1528139568930};\\\", \\\"{x:1346,y:912,t:1528139568947};\\\", \\\"{x:1346,y:909,t:1528139568964};\\\", \\\"{x:1345,y:908,t:1528139568980};\\\", \\\"{x:1345,y:906,t:1528139568997};\\\", \\\"{x:1345,y:905,t:1528139569014};\\\", \\\"{x:1344,y:903,t:1528139569030};\\\", \\\"{x:1342,y:902,t:1528139569237};\\\", \\\"{x:1342,y:900,t:1528139569252};\\\", \\\"{x:1342,y:899,t:1528139569277};\\\", \\\"{x:1342,y:897,t:1528139569314};\\\", \\\"{x:1339,y:891,t:1528139572414};\\\", \\\"{x:1300,y:857,t:1528139572421};\\\", \\\"{x:1148,y:781,t:1528139572437};\\\", \\\"{x:1056,y:752,t:1528139572449};\\\", \\\"{x:860,y:694,t:1528139572466};\\\", \\\"{x:630,y:623,t:1528139572483};\\\", \\\"{x:280,y:519,t:1528139572500};\\\", \\\"{x:74,y:470,t:1528139572515};\\\", \\\"{x:0,y:428,t:1528139572533};\\\", \\\"{x:0,y:411,t:1528139572549};\\\", \\\"{x:0,y:408,t:1528139572565};\\\", \\\"{x:6,y:412,t:1528139572612};\\\", \\\"{x:11,y:416,t:1528139572621};\\\", \\\"{x:17,y:423,t:1528139572633};\\\", \\\"{x:26,y:430,t:1528139572650};\\\", \\\"{x:37,y:442,t:1528139572666};\\\", \\\"{x:55,y:454,t:1528139572683};\\\", \\\"{x:85,y:472,t:1528139572700};\\\", \\\"{x:107,y:487,t:1528139572716};\\\", \\\"{x:128,y:503,t:1528139572732};\\\", \\\"{x:151,y:517,t:1528139572750};\\\", \\\"{x:172,y:528,t:1528139572767};\\\", \\\"{x:193,y:535,t:1528139572783};\\\", \\\"{x:212,y:542,t:1528139572800};\\\", \\\"{x:237,y:549,t:1528139572816};\\\", \\\"{x:255,y:554,t:1528139572832};\\\", \\\"{x:269,y:559,t:1528139572850};\\\", \\\"{x:273,y:560,t:1528139572868};\\\", \\\"{x:278,y:561,t:1528139572884};\\\", \\\"{x:278,y:563,t:1528139572973};\\\", \\\"{x:276,y:563,t:1528139572983};\\\", \\\"{x:264,y:563,t:1528139573002};\\\", \\\"{x:252,y:566,t:1528139573016};\\\", \\\"{x:239,y:566,t:1528139573033};\\\", \\\"{x:215,y:564,t:1528139573050};\\\", \\\"{x:198,y:561,t:1528139573067};\\\", \\\"{x:184,y:561,t:1528139573084};\\\", \\\"{x:180,y:561,t:1528139573099};\\\", \\\"{x:179,y:561,t:1528139573117};\\\", \\\"{x:178,y:561,t:1528139573133};\\\", \\\"{x:176,y:563,t:1528139573164};\\\", \\\"{x:175,y:569,t:1528139573173};\\\", \\\"{x:175,y:570,t:1528139573184};\\\", \\\"{x:175,y:573,t:1528139573200};\\\", \\\"{x:172,y:579,t:1528139573217};\\\", \\\"{x:172,y:583,t:1528139573234};\\\", \\\"{x:172,y:589,t:1528139573249};\\\", \\\"{x:172,y:591,t:1528139573267};\\\", \\\"{x:172,y:592,t:1528139573356};\\\", \\\"{x:175,y:592,t:1528139573367};\\\", \\\"{x:188,y:592,t:1528139573384};\\\", \\\"{x:203,y:595,t:1528139573400};\\\", \\\"{x:222,y:599,t:1528139573416};\\\", \\\"{x:244,y:601,t:1528139573433};\\\", \\\"{x:265,y:606,t:1528139573450};\\\", \\\"{x:285,y:611,t:1528139573467};\\\", \\\"{x:325,y:623,t:1528139573484};\\\", \\\"{x:346,y:627,t:1528139573500};\\\", \\\"{x:360,y:630,t:1528139573516};\\\", \\\"{x:369,y:634,t:1528139573533};\\\", \\\"{x:373,y:638,t:1528139573551};\\\", \\\"{x:377,y:638,t:1528139573568};\\\", \\\"{x:378,y:640,t:1528139573584};\\\", \\\"{x:381,y:641,t:1528139573601};\\\", \\\"{x:383,y:642,t:1528139573618};\\\", \\\"{x:384,y:642,t:1528139573634};\\\", \\\"{x:388,y:642,t:1528139573651};\\\", \\\"{x:398,y:642,t:1528139573669};\\\", \\\"{x:409,y:642,t:1528139573684};\\\", \\\"{x:424,y:640,t:1528139573702};\\\", \\\"{x:439,y:637,t:1528139573718};\\\", \\\"{x:457,y:632,t:1528139573734};\\\", \\\"{x:479,y:627,t:1528139573750};\\\", \\\"{x:507,y:627,t:1528139573767};\\\", \\\"{x:529,y:626,t:1528139573784};\\\", \\\"{x:556,y:626,t:1528139573801};\\\", \\\"{x:588,y:626,t:1528139573816};\\\", \\\"{x:601,y:626,t:1528139573833};\\\", \\\"{x:607,y:627,t:1528139573850};\\\", \\\"{x:611,y:627,t:1528139573867};\\\", \\\"{x:612,y:627,t:1528139573883};\\\", \\\"{x:613,y:627,t:1528139573964};\\\", \\\"{x:618,y:627,t:1528139573972};\\\", \\\"{x:627,y:628,t:1528139573984};\\\", \\\"{x:649,y:628,t:1528139574002};\\\", \\\"{x:679,y:628,t:1528139574017};\\\", \\\"{x:743,y:628,t:1528139574034};\\\", \\\"{x:796,y:628,t:1528139574050};\\\", \\\"{x:858,y:623,t:1528139574068};\\\", \\\"{x:875,y:620,t:1528139574084};\\\", \\\"{x:878,y:619,t:1528139574100};\\\", \\\"{x:879,y:619,t:1528139574118};\\\", \\\"{x:879,y:618,t:1528139574133};\\\", \\\"{x:879,y:615,t:1528139574172};\\\", \\\"{x:878,y:611,t:1528139574184};\\\", \\\"{x:870,y:604,t:1528139574201};\\\", \\\"{x:855,y:592,t:1528139574217};\\\", \\\"{x:829,y:577,t:1528139574234};\\\", \\\"{x:792,y:565,t:1528139574251};\\\", \\\"{x:701,y:557,t:1528139574269};\\\", \\\"{x:637,y:557,t:1528139574284};\\\", \\\"{x:594,y:557,t:1528139574301};\\\", \\\"{x:568,y:557,t:1528139574318};\\\", \\\"{x:550,y:560,t:1528139574333};\\\", \\\"{x:537,y:561,t:1528139574351};\\\", \\\"{x:526,y:565,t:1528139574368};\\\", \\\"{x:516,y:568,t:1528139574384};\\\", \\\"{x:509,y:572,t:1528139574402};\\\", \\\"{x:506,y:575,t:1528139574418};\\\", \\\"{x:498,y:579,t:1528139574435};\\\", \\\"{x:484,y:582,t:1528139574453};\\\", \\\"{x:466,y:583,t:1528139574468};\\\", \\\"{x:454,y:580,t:1528139574484};\\\", \\\"{x:445,y:579,t:1528139574501};\\\", \\\"{x:439,y:577,t:1528139574518};\\\", \\\"{x:431,y:572,t:1528139574535};\\\", \\\"{x:426,y:571,t:1528139574551};\\\", \\\"{x:423,y:569,t:1528139574567};\\\", \\\"{x:422,y:569,t:1528139574585};\\\", \\\"{x:421,y:569,t:1528139574660};\\\", \\\"{x:421,y:573,t:1528139574676};\\\", \\\"{x:421,y:579,t:1528139574685};\\\", \\\"{x:421,y:583,t:1528139574702};\\\", \\\"{x:421,y:584,t:1528139574717};\\\", \\\"{x:421,y:585,t:1528139574805};\\\", \\\"{x:419,y:585,t:1528139574869};\\\", \\\"{x:404,y:590,t:1528139574885};\\\", \\\"{x:403,y:591,t:1528139574902};\\\", \\\"{x:402,y:591,t:1528139574918};\\\", \\\"{x:401,y:591,t:1528139574934};\\\", \\\"{x:401,y:594,t:1528139574951};\\\", \\\"{x:401,y:596,t:1528139574969};\\\", \\\"{x:401,y:597,t:1528139574985};\\\", \\\"{x:401,y:599,t:1528139575002};\\\", \\\"{x:401,y:600,t:1528139575027};\\\", \\\"{x:401,y:603,t:1528139575044};\\\", \\\"{x:401,y:606,t:1528139575052};\\\", \\\"{x:401,y:611,t:1528139575069};\\\", \\\"{x:400,y:614,t:1528139575085};\\\", \\\"{x:397,y:616,t:1528139575102};\\\", \\\"{x:394,y:618,t:1528139575118};\\\", \\\"{x:381,y:615,t:1528139575135};\\\", \\\"{x:350,y:589,t:1528139575152};\\\", \\\"{x:320,y:572,t:1528139575168};\\\", \\\"{x:298,y:568,t:1528139575184};\\\", \\\"{x:275,y:566,t:1528139575201};\\\", \\\"{x:249,y:566,t:1528139575220};\\\", \\\"{x:237,y:566,t:1528139575234};\\\", \\\"{x:225,y:563,t:1528139575252};\\\", \\\"{x:224,y:562,t:1528139575268};\\\", \\\"{x:222,y:563,t:1528139575291};\\\", \\\"{x:220,y:565,t:1528139575339};\\\", \\\"{x:218,y:567,t:1528139575351};\\\", \\\"{x:213,y:572,t:1528139575369};\\\", \\\"{x:198,y:583,t:1528139575386};\\\", \\\"{x:187,y:590,t:1528139575403};\\\", \\\"{x:187,y:592,t:1528139575419};\\\", \\\"{x:183,y:592,t:1528139575435};\\\", \\\"{x:177,y:591,t:1528139575452};\\\", \\\"{x:175,y:590,t:1528139575469};\\\", \\\"{x:174,y:590,t:1528139575516};\\\", \\\"{x:174,y:589,t:1528139575525};\\\", \\\"{x:174,y:588,t:1528139575557};\\\", \\\"{x:175,y:586,t:1528139575613};\\\", \\\"{x:181,y:586,t:1528139575915};\\\", \\\"{x:189,y:589,t:1528139575923};\\\", \\\"{x:195,y:594,t:1528139575936};\\\", \\\"{x:225,y:610,t:1528139575951};\\\", \\\"{x:247,y:621,t:1528139575969};\\\", \\\"{x:280,y:634,t:1528139575987};\\\", \\\"{x:308,y:650,t:1528139576003};\\\", \\\"{x:343,y:672,t:1528139576019};\\\", \\\"{x:368,y:688,t:1528139576036};\\\", \\\"{x:378,y:694,t:1528139576052};\\\", \\\"{x:387,y:700,t:1528139576068};\\\", \\\"{x:391,y:704,t:1528139576085};\\\", \\\"{x:395,y:709,t:1528139576103};\\\", \\\"{x:395,y:710,t:1528139576119};\\\", \\\"{x:396,y:711,t:1528139576135};\\\", \\\"{x:400,y:717,t:1528139576153};\\\", \\\"{x:403,y:721,t:1528139576169};\\\", \\\"{x:403,y:722,t:1528139576196};\\\", \\\"{x:405,y:724,t:1528139576212};\\\", \\\"{x:406,y:724,t:1528139576229};\\\", \\\"{x:408,y:726,t:1528139576237};\\\", \\\"{x:415,y:730,t:1528139576253};\\\", \\\"{x:419,y:733,t:1528139576284};\\\", \\\"{x:419,y:734,t:1528139576292};\\\", \\\"{x:419,y:736,t:1528139576304};\\\", \\\"{x:428,y:740,t:1528139576319};\\\", \\\"{x:430,y:742,t:1528139576340};\\\", \\\"{x:432,y:742,t:1528139576353};\\\", \\\"{x:435,y:744,t:1528139576369};\\\", \\\"{x:445,y:750,t:1528139576386};\\\", \\\"{x:446,y:750,t:1528139576403};\\\", \\\"{x:447,y:751,t:1528139576420};\\\", \\\"{x:447,y:752,t:1528139576435};\\\", \\\"{x:447,y:753,t:1528139576644};\\\", \\\"{x:447,y:752,t:1528139576900};\\\", \\\"{x:444,y:743,t:1528139576908};\\\", \\\"{x:444,y:741,t:1528139576924};\\\", \\\"{x:444,y:740,t:1528139576936};\\\", \\\"{x:461,y:723,t:1528139576952};\\\", \\\"{x:493,y:708,t:1528139576970};\\\", \\\"{x:521,y:682,t:1528139576985};\\\", \\\"{x:557,y:651,t:1528139577003};\\\", \\\"{x:594,y:608,t:1528139577019};\\\", \\\"{x:618,y:583,t:1528139577036};\\\", \\\"{x:626,y:576,t:1528139577053};\\\", \\\"{x:651,y:558,t:1528139577070};\\\", \\\"{x:668,y:536,t:1528139577088};\\\", \\\"{x:686,y:524,t:1528139577103};\\\", \\\"{x:711,y:507,t:1528139577120};\\\", \\\"{x:718,y:502,t:1528139577137};\\\", \\\"{x:720,y:501,t:1528139577153};\\\", \\\"{x:721,y:501,t:1528139577170};\\\" ] }, { \\\"rt\\\": 30725, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 208784, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"ZEPVG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-04 PM-04 PM-03 PM-A -Z -Z -Z -Z -O -F -U -U -U -U \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:724,y:500,t:1528139578860};\\\", \\\"{x:750,y:500,t:1528139578871};\\\", \\\"{x:886,y:538,t:1528139578888};\\\", \\\"{x:983,y:565,t:1528139578909};\\\", \\\"{x:1121,y:597,t:1528139578925};\\\", \\\"{x:1232,y:615,t:1528139578942};\\\", \\\"{x:1299,y:627,t:1528139578959};\\\", \\\"{x:1327,y:637,t:1528139578975};\\\", \\\"{x:1340,y:648,t:1528139578992};\\\", \\\"{x:1342,y:651,t:1528139579009};\\\", \\\"{x:1342,y:652,t:1528139579473};\\\", \\\"{x:1342,y:653,t:1528139579488};\\\", \\\"{x:1342,y:658,t:1528139579497};\\\", \\\"{x:1342,y:660,t:1528139579509};\\\", \\\"{x:1342,y:661,t:1528139579526};\\\", \\\"{x:1339,y:667,t:1528139579542};\\\", \\\"{x:1333,y:674,t:1528139579559};\\\", \\\"{x:1321,y:686,t:1528139579577};\\\", \\\"{x:1320,y:689,t:1528139579592};\\\", \\\"{x:1320,y:692,t:1528139579609};\\\", \\\"{x:1319,y:693,t:1528139579689};\\\", \\\"{x:1318,y:693,t:1528139579784};\\\", \\\"{x:1320,y:705,t:1528139580375};\\\", \\\"{x:1389,y:751,t:1528139580392};\\\", \\\"{x:1445,y:812,t:1528139580409};\\\", \\\"{x:1519,y:875,t:1528139580426};\\\", \\\"{x:1606,y:937,t:1528139580443};\\\", \\\"{x:1656,y:984,t:1528139580460};\\\", \\\"{x:1687,y:1016,t:1528139580476};\\\", \\\"{x:1719,y:1035,t:1528139580492};\\\", \\\"{x:1729,y:1046,t:1528139580510};\\\", \\\"{x:1737,y:1051,t:1528139580526};\\\", \\\"{x:1748,y:1057,t:1528139580544};\\\", \\\"{x:1752,y:1057,t:1528139580559};\\\", \\\"{x:1748,y:1054,t:1528139580649};\\\", \\\"{x:1745,y:1048,t:1528139580660};\\\", \\\"{x:1731,y:1035,t:1528139580677};\\\", \\\"{x:1713,y:1025,t:1528139580693};\\\", \\\"{x:1688,y:1009,t:1528139580710};\\\", \\\"{x:1626,y:976,t:1528139580728};\\\", \\\"{x:1559,y:954,t:1528139580744};\\\", \\\"{x:1510,y:935,t:1528139580760};\\\", \\\"{x:1498,y:933,t:1528139580777};\\\", \\\"{x:1496,y:933,t:1528139580793};\\\", \\\"{x:1498,y:933,t:1528139580992};\\\", \\\"{x:1519,y:935,t:1528139581011};\\\", \\\"{x:1533,y:942,t:1528139581027};\\\", \\\"{x:1557,y:946,t:1528139581043};\\\", \\\"{x:1569,y:948,t:1528139581060};\\\", \\\"{x:1584,y:951,t:1528139581078};\\\", \\\"{x:1594,y:952,t:1528139581094};\\\", \\\"{x:1589,y:952,t:1528139581217};\\\", \\\"{x:1579,y:948,t:1528139581228};\\\", \\\"{x:1565,y:945,t:1528139581244};\\\", \\\"{x:1541,y:942,t:1528139581260};\\\", \\\"{x:1527,y:938,t:1528139581277};\\\", \\\"{x:1525,y:938,t:1528139581294};\\\", \\\"{x:1524,y:937,t:1528139581310};\\\", \\\"{x:1526,y:936,t:1528139581385};\\\", \\\"{x:1527,y:936,t:1528139581395};\\\", \\\"{x:1539,y:936,t:1528139581411};\\\", \\\"{x:1546,y:939,t:1528139581428};\\\", \\\"{x:1558,y:944,t:1528139581444};\\\", \\\"{x:1575,y:947,t:1528139581461};\\\", \\\"{x:1583,y:951,t:1528139581478};\\\", \\\"{x:1596,y:955,t:1528139581494};\\\", \\\"{x:1600,y:956,t:1528139581510};\\\", \\\"{x:1604,y:958,t:1528139581527};\\\", \\\"{x:1608,y:958,t:1528139581544};\\\", \\\"{x:1609,y:959,t:1528139581672};\\\", \\\"{x:1610,y:959,t:1528139582033};\\\", \\\"{x:1614,y:961,t:1528139582044};\\\", \\\"{x:1618,y:966,t:1528139582061};\\\", \\\"{x:1624,y:971,t:1528139582078};\\\", \\\"{x:1628,y:974,t:1528139582094};\\\", \\\"{x:1630,y:973,t:1528139582305};\\\", \\\"{x:1630,y:972,t:1528139582329};\\\", \\\"{x:1630,y:971,t:1528139582345};\\\", \\\"{x:1630,y:970,t:1528139582448};\\\", \\\"{x:1630,y:969,t:1528139582496};\\\", \\\"{x:1630,y:968,t:1528139582512};\\\", \\\"{x:1630,y:965,t:1528139582528};\\\", \\\"{x:1630,y:963,t:1528139582545};\\\", \\\"{x:1630,y:960,t:1528139582562};\\\", \\\"{x:1629,y:955,t:1528139582578};\\\", \\\"{x:1629,y:953,t:1528139582594};\\\", \\\"{x:1629,y:950,t:1528139582611};\\\", \\\"{x:1627,y:944,t:1528139582629};\\\", \\\"{x:1624,y:932,t:1528139582645};\\\", \\\"{x:1621,y:923,t:1528139582661};\\\", \\\"{x:1620,y:914,t:1528139582679};\\\", \\\"{x:1618,y:905,t:1528139582695};\\\", \\\"{x:1617,y:898,t:1528139582712};\\\", \\\"{x:1616,y:895,t:1528139582729};\\\", \\\"{x:1616,y:894,t:1528139582768};\\\", \\\"{x:1616,y:893,t:1528139582784};\\\", \\\"{x:1616,y:892,t:1528139582795};\\\", \\\"{x:1616,y:891,t:1528139582812};\\\", \\\"{x:1616,y:889,t:1528139582828};\\\", \\\"{x:1616,y:899,t:1528139582952};\\\", \\\"{x:1616,y:916,t:1528139582962};\\\", \\\"{x:1616,y:935,t:1528139582978};\\\", \\\"{x:1616,y:944,t:1528139582995};\\\", \\\"{x:1616,y:949,t:1528139583012};\\\", \\\"{x:1616,y:952,t:1528139583029};\\\", \\\"{x:1616,y:955,t:1528139583056};\\\", \\\"{x:1616,y:957,t:1528139583336};\\\", \\\"{x:1615,y:960,t:1528139583345};\\\", \\\"{x:1614,y:964,t:1528139583362};\\\", \\\"{x:1613,y:967,t:1528139583378};\\\", \\\"{x:1611,y:968,t:1528139583921};\\\", \\\"{x:1604,y:971,t:1528139583929};\\\", \\\"{x:1577,y:971,t:1528139583946};\\\", \\\"{x:1556,y:970,t:1528139583963};\\\", \\\"{x:1532,y:967,t:1528139583980};\\\", \\\"{x:1505,y:965,t:1528139583995};\\\", \\\"{x:1474,y:965,t:1528139584012};\\\", \\\"{x:1436,y:965,t:1528139584029};\\\", \\\"{x:1394,y:965,t:1528139584045};\\\", \\\"{x:1377,y:959,t:1528139584062};\\\", \\\"{x:1354,y:952,t:1528139584079};\\\", \\\"{x:1338,y:944,t:1528139584096};\\\", \\\"{x:1328,y:938,t:1528139584112};\\\", \\\"{x:1319,y:930,t:1528139584130};\\\", \\\"{x:1308,y:919,t:1528139584146};\\\", \\\"{x:1308,y:916,t:1528139584162};\\\", \\\"{x:1299,y:915,t:1528139584180};\\\", \\\"{x:1297,y:910,t:1528139584196};\\\", \\\"{x:1295,y:910,t:1528139584212};\\\", \\\"{x:1294,y:908,t:1528139584229};\\\", \\\"{x:1293,y:907,t:1528139584248};\\\", \\\"{x:1291,y:905,t:1528139584262};\\\", \\\"{x:1288,y:904,t:1528139584280};\\\", \\\"{x:1288,y:903,t:1528139584328};\\\", \\\"{x:1278,y:902,t:1528139584346};\\\", \\\"{x:1268,y:900,t:1528139584363};\\\", \\\"{x:1264,y:899,t:1528139584380};\\\", \\\"{x:1262,y:897,t:1528139584473};\\\", \\\"{x:1260,y:895,t:1528139584480};\\\", \\\"{x:1254,y:888,t:1528139584496};\\\", \\\"{x:1251,y:882,t:1528139584513};\\\", \\\"{x:1248,y:877,t:1528139584530};\\\", \\\"{x:1247,y:873,t:1528139584546};\\\", \\\"{x:1244,y:868,t:1528139584563};\\\", \\\"{x:1243,y:864,t:1528139584580};\\\", \\\"{x:1239,y:856,t:1528139584597};\\\", \\\"{x:1235,y:847,t:1528139584613};\\\", \\\"{x:1230,y:842,t:1528139584629};\\\", \\\"{x:1229,y:841,t:1528139584656};\\\", \\\"{x:1230,y:841,t:1528139585175};\\\", \\\"{x:1235,y:839,t:1528139585183};\\\", \\\"{x:1244,y:839,t:1528139585196};\\\", \\\"{x:1267,y:838,t:1528139585212};\\\", \\\"{x:1284,y:838,t:1528139585230};\\\", \\\"{x:1299,y:838,t:1528139585246};\\\", \\\"{x:1304,y:838,t:1528139585262};\\\", \\\"{x:1305,y:838,t:1528139585280};\\\", \\\"{x:1302,y:836,t:1528139585529};\\\", \\\"{x:1298,y:833,t:1528139585536};\\\", \\\"{x:1291,y:831,t:1528139585548};\\\", \\\"{x:1288,y:829,t:1528139585563};\\\", \\\"{x:1285,y:829,t:1528139585587};\\\", \\\"{x:1285,y:828,t:1528139585613};\\\", \\\"{x:1291,y:832,t:1528139587712};\\\", \\\"{x:1304,y:844,t:1528139587719};\\\", \\\"{x:1315,y:852,t:1528139587733};\\\", \\\"{x:1337,y:866,t:1528139587749};\\\", \\\"{x:1351,y:878,t:1528139587766};\\\", \\\"{x:1352,y:880,t:1528139587782};\\\", \\\"{x:1355,y:882,t:1528139587799};\\\", \\\"{x:1356,y:882,t:1528139587816};\\\", \\\"{x:1356,y:884,t:1528139587920};\\\", \\\"{x:1355,y:885,t:1528139587932};\\\", \\\"{x:1351,y:886,t:1528139587959};\\\", \\\"{x:1350,y:886,t:1528139587968};\\\", \\\"{x:1349,y:886,t:1528139587983};\\\", \\\"{x:1349,y:887,t:1528139588056};\\\", \\\"{x:1349,y:888,t:1528139588071};\\\", \\\"{x:1349,y:889,t:1528139588088};\\\", \\\"{x:1349,y:890,t:1528139588120};\\\", \\\"{x:1349,y:892,t:1528139588137};\\\", \\\"{x:1349,y:894,t:1528139588149};\\\", \\\"{x:1350,y:895,t:1528139588166};\\\", \\\"{x:1349,y:895,t:1528139588271};\\\", \\\"{x:1348,y:894,t:1528139588288};\\\", \\\"{x:1347,y:892,t:1528139588299};\\\", \\\"{x:1344,y:886,t:1528139588318};\\\", \\\"{x:1341,y:881,t:1528139588334};\\\", \\\"{x:1339,y:876,t:1528139588349};\\\", \\\"{x:1336,y:867,t:1528139588366};\\\", \\\"{x:1335,y:860,t:1528139588383};\\\", \\\"{x:1335,y:853,t:1528139588399};\\\", \\\"{x:1335,y:844,t:1528139588417};\\\", \\\"{x:1335,y:837,t:1528139588433};\\\", \\\"{x:1335,y:828,t:1528139588450};\\\", \\\"{x:1333,y:822,t:1528139588465};\\\", \\\"{x:1332,y:819,t:1528139588483};\\\", \\\"{x:1332,y:818,t:1528139588500};\\\", \\\"{x:1331,y:818,t:1528139588516};\\\", \\\"{x:1330,y:818,t:1528139588648};\\\", \\\"{x:1326,y:818,t:1528139588656};\\\", \\\"{x:1324,y:824,t:1528139588666};\\\", \\\"{x:1319,y:838,t:1528139588683};\\\", \\\"{x:1315,y:855,t:1528139588701};\\\", \\\"{x:1310,y:876,t:1528139588716};\\\", \\\"{x:1307,y:884,t:1528139588734};\\\", \\\"{x:1305,y:894,t:1528139588750};\\\", \\\"{x:1305,y:901,t:1528139588766};\\\", \\\"{x:1305,y:902,t:1528139588784};\\\", \\\"{x:1305,y:905,t:1528139588920};\\\", \\\"{x:1307,y:906,t:1528139589008};\\\", \\\"{x:1308,y:907,t:1528139589018};\\\", \\\"{x:1311,y:909,t:1528139589033};\\\", \\\"{x:1312,y:909,t:1528139589050};\\\", \\\"{x:1313,y:910,t:1528139589088};\\\", \\\"{x:1313,y:911,t:1528139589368};\\\", \\\"{x:1313,y:912,t:1528139589384};\\\", \\\"{x:1312,y:912,t:1528139589407};\\\", \\\"{x:1311,y:913,t:1528139589432};\\\", \\\"{x:1311,y:914,t:1528139589552};\\\", \\\"{x:1311,y:915,t:1528139589584};\\\", \\\"{x:1311,y:916,t:1528139589657};\\\", \\\"{x:1311,y:919,t:1528139589668};\\\", \\\"{x:1312,y:925,t:1528139589684};\\\", \\\"{x:1315,y:930,t:1528139589701};\\\", \\\"{x:1320,y:935,t:1528139589718};\\\", \\\"{x:1323,y:938,t:1528139589735};\\\", \\\"{x:1324,y:941,t:1528139589750};\\\", \\\"{x:1324,y:942,t:1528139589776};\\\", \\\"{x:1325,y:944,t:1528139589784};\\\", \\\"{x:1327,y:942,t:1528139589919};\\\", \\\"{x:1327,y:939,t:1528139589934};\\\", \\\"{x:1332,y:915,t:1528139589951};\\\", \\\"{x:1335,y:901,t:1528139589967};\\\", \\\"{x:1343,y:878,t:1528139589984};\\\", \\\"{x:1346,y:860,t:1528139590001};\\\", \\\"{x:1346,y:846,t:1528139590017};\\\", \\\"{x:1346,y:813,t:1528139590034};\\\", \\\"{x:1346,y:765,t:1528139590051};\\\", \\\"{x:1346,y:738,t:1528139590067};\\\", \\\"{x:1346,y:725,t:1528139590084};\\\", \\\"{x:1346,y:708,t:1528139590102};\\\", \\\"{x:1346,y:698,t:1528139590117};\\\", \\\"{x:1345,y:689,t:1528139590134};\\\", \\\"{x:1342,y:682,t:1528139590152};\\\", \\\"{x:1340,y:676,t:1528139590168};\\\", \\\"{x:1340,y:674,t:1528139590184};\\\", \\\"{x:1339,y:674,t:1528139590249};\\\", \\\"{x:1339,y:671,t:1528139590312};\\\", \\\"{x:1338,y:668,t:1528139590320};\\\", \\\"{x:1337,y:667,t:1528139590334};\\\", \\\"{x:1335,y:656,t:1528139590351};\\\", \\\"{x:1330,y:640,t:1528139590368};\\\", \\\"{x:1320,y:621,t:1528139590385};\\\", \\\"{x:1315,y:609,t:1528139590402};\\\", \\\"{x:1315,y:607,t:1528139590448};\\\", \\\"{x:1315,y:608,t:1528139590656};\\\", \\\"{x:1315,y:609,t:1528139590669};\\\", \\\"{x:1315,y:610,t:1528139590686};\\\", \\\"{x:1315,y:611,t:1528139591625};\\\", \\\"{x:1315,y:620,t:1528139591636};\\\", \\\"{x:1317,y:659,t:1528139591652};\\\", \\\"{x:1322,y:719,t:1528139591669};\\\", \\\"{x:1335,y:771,t:1528139591685};\\\", \\\"{x:1343,y:795,t:1528139591702};\\\", \\\"{x:1350,y:814,t:1528139591719};\\\", \\\"{x:1354,y:831,t:1528139591735};\\\", \\\"{x:1355,y:850,t:1528139591752};\\\", \\\"{x:1356,y:867,t:1528139591769};\\\", \\\"{x:1356,y:877,t:1528139591785};\\\", \\\"{x:1356,y:890,t:1528139591803};\\\", \\\"{x:1356,y:895,t:1528139591819};\\\", \\\"{x:1357,y:897,t:1528139591835};\\\", \\\"{x:1357,y:898,t:1528139591852};\\\", \\\"{x:1358,y:898,t:1528139592024};\\\", \\\"{x:1361,y:897,t:1528139592040};\\\", \\\"{x:1363,y:894,t:1528139592052};\\\", \\\"{x:1368,y:883,t:1528139592070};\\\", \\\"{x:1375,y:867,t:1528139592086};\\\", \\\"{x:1380,y:857,t:1528139592103};\\\", \\\"{x:1382,y:839,t:1528139592120};\\\", \\\"{x:1383,y:835,t:1528139592136};\\\", \\\"{x:1384,y:829,t:1528139592153};\\\", \\\"{x:1384,y:824,t:1528139592170};\\\", \\\"{x:1385,y:821,t:1528139592186};\\\", \\\"{x:1385,y:820,t:1528139592202};\\\", \\\"{x:1385,y:817,t:1528139592220};\\\", \\\"{x:1385,y:816,t:1528139592240};\\\", \\\"{x:1385,y:815,t:1528139592252};\\\", \\\"{x:1385,y:814,t:1528139592272};\\\", \\\"{x:1385,y:812,t:1528139592287};\\\", \\\"{x:1386,y:808,t:1528139592304};\\\", \\\"{x:1388,y:805,t:1528139592320};\\\", \\\"{x:1388,y:799,t:1528139592336};\\\", \\\"{x:1388,y:790,t:1528139592353};\\\", \\\"{x:1388,y:778,t:1528139592370};\\\", \\\"{x:1388,y:769,t:1528139592387};\\\", \\\"{x:1388,y:768,t:1528139592404};\\\", \\\"{x:1387,y:768,t:1528139593753};\\\", \\\"{x:1385,y:768,t:1528139593760};\\\", \\\"{x:1383,y:768,t:1528139593774};\\\", \\\"{x:1381,y:768,t:1528139593787};\\\", \\\"{x:1379,y:768,t:1528139593804};\\\", \\\"{x:1378,y:769,t:1528139599091};\\\", \\\"{x:1400,y:810,t:1528139599109};\\\", \\\"{x:1422,y:830,t:1528139599126};\\\", \\\"{x:1445,y:846,t:1528139599141};\\\", \\\"{x:1472,y:855,t:1528139599159};\\\", \\\"{x:1489,y:867,t:1528139599175};\\\", \\\"{x:1496,y:869,t:1528139599191};\\\", \\\"{x:1497,y:870,t:1528139599208};\\\", \\\"{x:1498,y:872,t:1528139599255};\\\", \\\"{x:1498,y:874,t:1528139599263};\\\", \\\"{x:1499,y:875,t:1528139599276};\\\", \\\"{x:1499,y:876,t:1528139599295};\\\", \\\"{x:1499,y:872,t:1528139599407};\\\", \\\"{x:1498,y:869,t:1528139599415};\\\", \\\"{x:1495,y:863,t:1528139599426};\\\", \\\"{x:1493,y:855,t:1528139599442};\\\", \\\"{x:1488,y:849,t:1528139599459};\\\", \\\"{x:1484,y:840,t:1528139599476};\\\", \\\"{x:1481,y:834,t:1528139599494};\\\", \\\"{x:1480,y:830,t:1528139599509};\\\", \\\"{x:1479,y:826,t:1528139599526};\\\", \\\"{x:1478,y:824,t:1528139599543};\\\", \\\"{x:1477,y:823,t:1528139599559};\\\", \\\"{x:1476,y:822,t:1528139599848};\\\", \\\"{x:1473,y:822,t:1528139599912};\\\", \\\"{x:1471,y:821,t:1528139599926};\\\", \\\"{x:1466,y:820,t:1528139599942};\\\", \\\"{x:1449,y:820,t:1528139599959};\\\", \\\"{x:1439,y:819,t:1528139599975};\\\", \\\"{x:1427,y:816,t:1528139599993};\\\", \\\"{x:1421,y:816,t:1528139600009};\\\", \\\"{x:1418,y:816,t:1528139600026};\\\", \\\"{x:1415,y:816,t:1528139600080};\\\", \\\"{x:1414,y:815,t:1528139600840};\\\", \\\"{x:1414,y:814,t:1528139600848};\\\", \\\"{x:1414,y:813,t:1528139600880};\\\", \\\"{x:1415,y:813,t:1528139600895};\\\", \\\"{x:1415,y:812,t:1528139600912};\\\", \\\"{x:1416,y:811,t:1528139600936};\\\", \\\"{x:1416,y:810,t:1528139600952};\\\", \\\"{x:1417,y:810,t:1528139600968};\\\", \\\"{x:1419,y:809,t:1528139601008};\\\", \\\"{x:1420,y:809,t:1528139601016};\\\", \\\"{x:1421,y:809,t:1528139601027};\\\", \\\"{x:1424,y:808,t:1528139601044};\\\", \\\"{x:1426,y:807,t:1528139601060};\\\", \\\"{x:1427,y:807,t:1528139601078};\\\", \\\"{x:1432,y:805,t:1528139601094};\\\", \\\"{x:1439,y:805,t:1528139601110};\\\", \\\"{x:1446,y:806,t:1528139601127};\\\", \\\"{x:1465,y:811,t:1528139601144};\\\", \\\"{x:1478,y:814,t:1528139601161};\\\", \\\"{x:1491,y:817,t:1528139601178};\\\", \\\"{x:1496,y:820,t:1528139601194};\\\", \\\"{x:1497,y:820,t:1528139601211};\\\", \\\"{x:1497,y:823,t:1528139601376};\\\", \\\"{x:1496,y:826,t:1528139601394};\\\", \\\"{x:1494,y:828,t:1528139601411};\\\", \\\"{x:1493,y:828,t:1528139601427};\\\", \\\"{x:1491,y:830,t:1528139601444};\\\", \\\"{x:1489,y:831,t:1528139601461};\\\", \\\"{x:1488,y:832,t:1528139601561};\\\", \\\"{x:1487,y:832,t:1528139601672};\\\", \\\"{x:1486,y:832,t:1528139601731};\\\", \\\"{x:1485,y:833,t:1528139602168};\\\", \\\"{x:1461,y:824,t:1528139605000};\\\", \\\"{x:1360,y:808,t:1528139605013};\\\", \\\"{x:1284,y:792,t:1528139605029};\\\", \\\"{x:1237,y:781,t:1528139605046};\\\", \\\"{x:966,y:714,t:1528139605063};\\\", \\\"{x:945,y:676,t:1528139605079};\\\", \\\"{x:946,y:676,t:1528139605367};\\\", \\\"{x:927,y:671,t:1528139605407};\\\", \\\"{x:892,y:663,t:1528139605416};\\\", \\\"{x:856,y:656,t:1528139605431};\\\", \\\"{x:757,y:641,t:1528139605449};\\\", \\\"{x:686,y:625,t:1528139605464};\\\", \\\"{x:594,y:612,t:1528139605481};\\\", \\\"{x:505,y:601,t:1528139605497};\\\", \\\"{x:436,y:592,t:1528139605514};\\\", \\\"{x:390,y:589,t:1528139605531};\\\", \\\"{x:361,y:585,t:1528139605546};\\\", \\\"{x:341,y:580,t:1528139605564};\\\", \\\"{x:331,y:579,t:1528139605581};\\\", \\\"{x:327,y:579,t:1528139605596};\\\", \\\"{x:320,y:579,t:1528139605614};\\\", \\\"{x:300,y:582,t:1528139605631};\\\", \\\"{x:284,y:587,t:1528139605647};\\\", \\\"{x:273,y:592,t:1528139605664};\\\", \\\"{x:265,y:596,t:1528139605682};\\\", \\\"{x:262,y:598,t:1528139605697};\\\", \\\"{x:263,y:600,t:1528139605735};\\\", \\\"{x:272,y:605,t:1528139605747};\\\", \\\"{x:295,y:611,t:1528139605765};\\\", \\\"{x:334,y:616,t:1528139605781};\\\", \\\"{x:380,y:618,t:1528139605797};\\\", \\\"{x:421,y:621,t:1528139605814};\\\", \\\"{x:453,y:627,t:1528139605830};\\\", \\\"{x:480,y:625,t:1528139605847};\\\", \\\"{x:492,y:625,t:1528139605864};\\\", \\\"{x:496,y:625,t:1528139605881};\\\", \\\"{x:499,y:625,t:1528139605898};\\\", \\\"{x:499,y:624,t:1528139605913};\\\", \\\"{x:500,y:623,t:1528139606016};\\\", \\\"{x:502,y:623,t:1528139606031};\\\", \\\"{x:515,y:624,t:1528139606047};\\\", \\\"{x:529,y:627,t:1528139606063};\\\", \\\"{x:546,y:629,t:1528139606081};\\\", \\\"{x:560,y:635,t:1528139606098};\\\", \\\"{x:575,y:640,t:1528139606113};\\\", \\\"{x:590,y:643,t:1528139606131};\\\", \\\"{x:602,y:645,t:1528139606148};\\\", \\\"{x:606,y:645,t:1528139606164};\\\", \\\"{x:607,y:646,t:1528139606296};\\\", \\\"{x:607,y:651,t:1528139606753};\\\", \\\"{x:607,y:662,t:1528139606765};\\\", \\\"{x:597,y:680,t:1528139606782};\\\", \\\"{x:588,y:706,t:1528139606798};\\\", \\\"{x:577,y:729,t:1528139606815};\\\", \\\"{x:575,y:735,t:1528139606831};\\\", \\\"{x:573,y:738,t:1528139606848};\\\", \\\"{x:573,y:734,t:1528139606887};\\\", \\\"{x:573,y:728,t:1528139606898};\\\", \\\"{x:573,y:714,t:1528139606914};\\\", \\\"{x:573,y:702,t:1528139606932};\\\", \\\"{x:577,y:694,t:1528139606949};\\\", \\\"{x:578,y:688,t:1528139606965};\\\", \\\"{x:581,y:683,t:1528139606982};\\\", \\\"{x:581,y:682,t:1528139606999};\\\", \\\"{x:583,y:679,t:1528139607015};\\\", \\\"{x:583,y:678,t:1528139607031};\\\", \\\"{x:585,y:673,t:1528139607047};\\\", \\\"{x:588,y:670,t:1528139607064};\\\", \\\"{x:588,y:668,t:1528139607081};\\\", \\\"{x:588,y:667,t:1528139607098};\\\", \\\"{x:590,y:666,t:1528139607136};\\\", \\\"{x:591,y:665,t:1528139607148};\\\", \\\"{x:594,y:662,t:1528139607164};\\\", \\\"{x:600,y:656,t:1528139607181};\\\", \\\"{x:601,y:654,t:1528139607199};\\\", \\\"{x:602,y:653,t:1528139607213};\\\", \\\"{x:603,y:652,t:1528139607232};\\\", \\\"{x:603,y:650,t:1528139607295};\\\", \\\"{x:603,y:647,t:1528139607303};\\\", \\\"{x:603,y:644,t:1528139607315};\\\", \\\"{x:596,y:651,t:1528139607929};\\\", \\\"{x:582,y:678,t:1528139607949};\\\", \\\"{x:571,y:694,t:1528139607966};\\\", \\\"{x:570,y:701,t:1528139607982};\\\", \\\"{x:569,y:704,t:1528139607999};\\\", \\\"{x:568,y:715,t:1528139608271};\\\", \\\"{x:566,y:725,t:1528139608283};\\\", \\\"{x:564,y:741,t:1528139608299};\\\", \\\"{x:563,y:746,t:1528139608316};\\\", \\\"{x:563,y:749,t:1528139608333};\\\", \\\"{x:562,y:752,t:1528139608349};\\\", \\\"{x:562,y:753,t:1528139608366};\\\", \\\"{x:562,y:754,t:1528139608384};\\\", \\\"{x:559,y:750,t:1528139608863};\\\", \\\"{x:552,y:739,t:1528139608871};\\\", \\\"{x:549,y:729,t:1528139608883};\\\", \\\"{x:540,y:709,t:1528139608900};\\\", \\\"{x:535,y:689,t:1528139608916};\\\", \\\"{x:534,y:669,t:1528139608933};\\\", \\\"{x:534,y:650,t:1528139608950};\\\", \\\"{x:536,y:626,t:1528139608966};\\\", \\\"{x:543,y:607,t:1528139608983};\\\", \\\"{x:580,y:502,t:1528139609000};\\\", \\\"{x:616,y:401,t:1528139609017};\\\", \\\"{x:642,y:342,t:1528139609033};\\\", \\\"{x:669,y:294,t:1528139609050};\\\", \\\"{x:689,y:256,t:1528139609067};\\\", \\\"{x:699,y:241,t:1528139609083};\\\", \\\"{x:704,y:228,t:1528139609100};\\\", \\\"{x:708,y:216,t:1528139609117};\\\", \\\"{x:710,y:211,t:1528139609133};\\\", \\\"{x:710,y:208,t:1528139609150};\\\", \\\"{x:709,y:208,t:1528139609240};\\\", \\\"{x:709,y:207,t:1528139609304};\\\" ] }, { \\\"rt\\\": 35082, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 245089, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"ZEPVG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-10 AM-I -I -I -I -I -O -O \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:706,y:207,t:1528139613064};\\\", \\\"{x:694,y:210,t:1528139613071};\\\", \\\"{x:693,y:210,t:1528139613087};\\\", \\\"{x:693,y:211,t:1528139613296};\\\", \\\"{x:693,y:212,t:1528139613304};\\\", \\\"{x:695,y:218,t:1528139613376};\\\", \\\"{x:704,y:227,t:1528139613387};\\\", \\\"{x:734,y:267,t:1528139613404};\\\", \\\"{x:789,y:348,t:1528139613421};\\\", \\\"{x:876,y:488,t:1528139613437};\\\", \\\"{x:974,y:642,t:1528139613454};\\\", \\\"{x:1066,y:770,t:1528139613471};\\\", \\\"{x:1146,y:866,t:1528139613487};\\\", \\\"{x:1244,y:993,t:1528139613503};\\\", \\\"{x:1285,y:1025,t:1528139613521};\\\", \\\"{x:1302,y:1057,t:1528139613537};\\\", \\\"{x:1306,y:1060,t:1528139613554};\\\", \\\"{x:1304,y:1057,t:1528139615184};\\\", \\\"{x:1299,y:1049,t:1528139615192};\\\", \\\"{x:1293,y:1042,t:1528139615205};\\\", \\\"{x:1276,y:1032,t:1528139615222};\\\", \\\"{x:1258,y:1021,t:1528139615238};\\\", \\\"{x:1243,y:1012,t:1528139615255};\\\", \\\"{x:1233,y:1004,t:1528139615272};\\\", \\\"{x:1232,y:1000,t:1528139615289};\\\", \\\"{x:1231,y:995,t:1528139615304};\\\", \\\"{x:1231,y:987,t:1528139615321};\\\", \\\"{x:1231,y:979,t:1528139615339};\\\", \\\"{x:1234,y:963,t:1528139615356};\\\", \\\"{x:1246,y:930,t:1528139615372};\\\", \\\"{x:1271,y:877,t:1528139615389};\\\", \\\"{x:1292,y:846,t:1528139615406};\\\", \\\"{x:1309,y:833,t:1528139615422};\\\", \\\"{x:1324,y:821,t:1528139615439};\\\", \\\"{x:1347,y:806,t:1528139615456};\\\", \\\"{x:1365,y:798,t:1528139615472};\\\", \\\"{x:1392,y:791,t:1528139615489};\\\", \\\"{x:1415,y:790,t:1528139615506};\\\", \\\"{x:1441,y:790,t:1528139615522};\\\", \\\"{x:1473,y:793,t:1528139615539};\\\", \\\"{x:1505,y:798,t:1528139615556};\\\", \\\"{x:1529,y:802,t:1528139615572};\\\", \\\"{x:1542,y:803,t:1528139615588};\\\", \\\"{x:1543,y:803,t:1528139615606};\\\", \\\"{x:1544,y:803,t:1528139615664};\\\", \\\"{x:1545,y:803,t:1528139615680};\\\", \\\"{x:1551,y:799,t:1528139615689};\\\", \\\"{x:1561,y:786,t:1528139615706};\\\", \\\"{x:1572,y:768,t:1528139615722};\\\", \\\"{x:1581,y:754,t:1528139615738};\\\", \\\"{x:1589,y:740,t:1528139615756};\\\", \\\"{x:1602,y:718,t:1528139615772};\\\", \\\"{x:1609,y:706,t:1528139615788};\\\", \\\"{x:1613,y:700,t:1528139615806};\\\", \\\"{x:1618,y:687,t:1528139615823};\\\", \\\"{x:1618,y:682,t:1528139615839};\\\", \\\"{x:1621,y:676,t:1528139615856};\\\", \\\"{x:1621,y:675,t:1528139616216};\\\", \\\"{x:1618,y:671,t:1528139616223};\\\", \\\"{x:1612,y:660,t:1528139616238};\\\", \\\"{x:1572,y:576,t:1528139616255};\\\", \\\"{x:1514,y:495,t:1528139616272};\\\", \\\"{x:1433,y:401,t:1528139616289};\\\", \\\"{x:1370,y:352,t:1528139616306};\\\", \\\"{x:1306,y:313,t:1528139616322};\\\", \\\"{x:1245,y:281,t:1528139616339};\\\", \\\"{x:1226,y:270,t:1528139616356};\\\", \\\"{x:1217,y:262,t:1528139616372};\\\", \\\"{x:1214,y:261,t:1528139616388};\\\", \\\"{x:1215,y:265,t:1528139616424};\\\", \\\"{x:1232,y:295,t:1528139616440};\\\", \\\"{x:1253,y:330,t:1528139616456};\\\", \\\"{x:1268,y:356,t:1528139616473};\\\", \\\"{x:1282,y:377,t:1528139616490};\\\", \\\"{x:1284,y:377,t:1528139616506};\\\", \\\"{x:1284,y:379,t:1528139616928};\\\", \\\"{x:1287,y:386,t:1528139616940};\\\", \\\"{x:1289,y:395,t:1528139616957};\\\", \\\"{x:1292,y:401,t:1528139616972};\\\", \\\"{x:1295,y:415,t:1528139616989};\\\", \\\"{x:1298,y:432,t:1528139617007};\\\", \\\"{x:1303,y:450,t:1528139617022};\\\", \\\"{x:1303,y:462,t:1528139617040};\\\", \\\"{x:1303,y:463,t:1528139617057};\\\", \\\"{x:1303,y:464,t:1528139617087};\\\", \\\"{x:1303,y:469,t:1528139617096};\\\", \\\"{x:1303,y:476,t:1528139617107};\\\", \\\"{x:1303,y:491,t:1528139617123};\\\", \\\"{x:1303,y:502,t:1528139617140};\\\", \\\"{x:1306,y:515,t:1528139617156};\\\", \\\"{x:1306,y:524,t:1528139617173};\\\", \\\"{x:1306,y:525,t:1528139617190};\\\", \\\"{x:1307,y:526,t:1528139617207};\\\", \\\"{x:1307,y:524,t:1528139617328};\\\", \\\"{x:1307,y:518,t:1528139617339};\\\", \\\"{x:1308,y:511,t:1528139617356};\\\", \\\"{x:1310,y:503,t:1528139617374};\\\", \\\"{x:1313,y:497,t:1528139617396};\\\", \\\"{x:1314,y:495,t:1528139617406};\\\", \\\"{x:1315,y:493,t:1528139617423};\\\", \\\"{x:1315,y:489,t:1528139629224};\\\", \\\"{x:1299,y:471,t:1528139629235};\\\", \\\"{x:1283,y:458,t:1528139629250};\\\", \\\"{x:1256,y:455,t:1528139629267};\\\", \\\"{x:1176,y:455,t:1528139629283};\\\", \\\"{x:1059,y:455,t:1528139629300};\\\", \\\"{x:973,y:453,t:1528139629316};\\\", \\\"{x:945,y:453,t:1528139629333};\\\", \\\"{x:932,y:456,t:1528139629349};\\\", \\\"{x:930,y:458,t:1528139629366};\\\", \\\"{x:946,y:457,t:1528139629471};\\\", \\\"{x:982,y:455,t:1528139629484};\\\", \\\"{x:1115,y:455,t:1528139629500};\\\", \\\"{x:1124,y:457,t:1528139629518};\\\", \\\"{x:1169,y:469,t:1528139629534};\\\", \\\"{x:1261,y:484,t:1528139629551};\\\", \\\"{x:1304,y:490,t:1528139629567};\\\", \\\"{x:1308,y:490,t:1528139629585};\\\", \\\"{x:1310,y:493,t:1528139629716};\\\", \\\"{x:1315,y:502,t:1528139629733};\\\", \\\"{x:1318,y:505,t:1528139630078};\\\", \\\"{x:1318,y:503,t:1528139630086};\\\", \\\"{x:1319,y:502,t:1528139630100};\\\", \\\"{x:1322,y:498,t:1528139630117};\\\", \\\"{x:1325,y:492,t:1528139630133};\\\", \\\"{x:1326,y:490,t:1528139630151};\\\", \\\"{x:1326,y:489,t:1528139630167};\\\", \\\"{x:1326,y:487,t:1528139630206};\\\", \\\"{x:1326,y:488,t:1528139630479};\\\", \\\"{x:1325,y:488,t:1528139630487};\\\", \\\"{x:1321,y:490,t:1528139630501};\\\", \\\"{x:1317,y:492,t:1528139630521};\\\", \\\"{x:1312,y:495,t:1528139630533};\\\", \\\"{x:1311,y:495,t:1528139630575};\\\", \\\"{x:1311,y:492,t:1528139636079};\\\", \\\"{x:1311,y:487,t:1528139636097};\\\", \\\"{x:1311,y:484,t:1528139636112};\\\", \\\"{x:1313,y:478,t:1528139636129};\\\", \\\"{x:1313,y:476,t:1528139636139};\\\", \\\"{x:1314,y:468,t:1528139636156};\\\", \\\"{x:1315,y:461,t:1528139636172};\\\", \\\"{x:1315,y:458,t:1528139636189};\\\", \\\"{x:1318,y:450,t:1528139636205};\\\", \\\"{x:1318,y:448,t:1528139636221};\\\", \\\"{x:1318,y:446,t:1528139636239};\\\", \\\"{x:1318,y:454,t:1528139637224};\\\", \\\"{x:1319,y:469,t:1528139637240};\\\", \\\"{x:1323,y:483,t:1528139637257};\\\", \\\"{x:1324,y:488,t:1528139637273};\\\", \\\"{x:1325,y:492,t:1528139637291};\\\", \\\"{x:1325,y:493,t:1528139637307};\\\", \\\"{x:1325,y:496,t:1528139638512};\\\", \\\"{x:1326,y:498,t:1528139638528};\\\", \\\"{x:1326,y:496,t:1528139638656};\\\", \\\"{x:1326,y:495,t:1528139638664};\\\", \\\"{x:1326,y:492,t:1528139638674};\\\", \\\"{x:1325,y:490,t:1528139638691};\\\", \\\"{x:1324,y:490,t:1528139638707};\\\", \\\"{x:1321,y:490,t:1528139638750};\\\", \\\"{x:1316,y:492,t:1528139638776};\\\", \\\"{x:1312,y:494,t:1528139638791};\\\", \\\"{x:1311,y:494,t:1528139638808};\\\", \\\"{x:1311,y:497,t:1528139639635};\\\", \\\"{x:1310,y:519,t:1528139639662};\\\", \\\"{x:1309,y:527,t:1528139639678};\\\", \\\"{x:1309,y:538,t:1528139639696};\\\", \\\"{x:1309,y:550,t:1528139639712};\\\", \\\"{x:1309,y:562,t:1528139639728};\\\", \\\"{x:1312,y:576,t:1528139639746};\\\", \\\"{x:1312,y:588,t:1528139639762};\\\", \\\"{x:1313,y:599,t:1528139639779};\\\", \\\"{x:1313,y:601,t:1528139639796};\\\", \\\"{x:1313,y:604,t:1528139639811};\\\", \\\"{x:1313,y:605,t:1528139639842};\\\", \\\"{x:1313,y:606,t:1528139639850};\\\", \\\"{x:1313,y:608,t:1528139639866};\\\", \\\"{x:1313,y:611,t:1528139639879};\\\", \\\"{x:1313,y:616,t:1528139639895};\\\", \\\"{x:1314,y:624,t:1528139639912};\\\", \\\"{x:1315,y:629,t:1528139639932};\\\", \\\"{x:1316,y:635,t:1528139639945};\\\", \\\"{x:1317,y:637,t:1528139640018};\\\", \\\"{x:1318,y:638,t:1528139640029};\\\", \\\"{x:1318,y:643,t:1528139640046};\\\", \\\"{x:1318,y:645,t:1528139640063};\\\", \\\"{x:1318,y:646,t:1528139640078};\\\", \\\"{x:1318,y:647,t:1528139640098};\\\", \\\"{x:1319,y:647,t:1528139640915};\\\", \\\"{x:1319,y:646,t:1528139641291};\\\", \\\"{x:1310,y:642,t:1528139641298};\\\", \\\"{x:1282,y:633,t:1528139641313};\\\", \\\"{x:1155,y:599,t:1528139641330};\\\", \\\"{x:930,y:527,t:1528139641347};\\\", \\\"{x:706,y:453,t:1528139641364};\\\", \\\"{x:521,y:396,t:1528139641381};\\\", \\\"{x:381,y:364,t:1528139641397};\\\", \\\"{x:280,y:365,t:1528139641414};\\\", \\\"{x:274,y:365,t:1528139641430};\\\", \\\"{x:273,y:365,t:1528139641450};\\\", \\\"{x:273,y:366,t:1528139641464};\\\", \\\"{x:271,y:369,t:1528139641479};\\\", \\\"{x:271,y:372,t:1528139641497};\\\", \\\"{x:269,y:384,t:1528139641514};\\\", \\\"{x:269,y:398,t:1528139641530};\\\", \\\"{x:281,y:423,t:1528139641547};\\\", \\\"{x:291,y:445,t:1528139641565};\\\", \\\"{x:302,y:467,t:1528139641580};\\\", \\\"{x:309,y:474,t:1528139641596};\\\", \\\"{x:312,y:488,t:1528139641614};\\\", \\\"{x:312,y:495,t:1528139641630};\\\", \\\"{x:312,y:496,t:1528139641647};\\\", \\\"{x:312,y:500,t:1528139641665};\\\", \\\"{x:312,y:501,t:1528139641680};\\\", \\\"{x:312,y:503,t:1528139641715};\\\", \\\"{x:311,y:503,t:1528139641754};\\\", \\\"{x:311,y:504,t:1528139641867};\\\", \\\"{x:311,y:505,t:1528139641906};\\\", \\\"{x:315,y:506,t:1528139642187};\\\", \\\"{x:346,y:505,t:1528139642197};\\\", \\\"{x:443,y:514,t:1528139642214};\\\", \\\"{x:568,y:529,t:1528139642231};\\\", \\\"{x:691,y:552,t:1528139642247};\\\", \\\"{x:796,y:568,t:1528139642265};\\\", \\\"{x:874,y:579,t:1528139642281};\\\", \\\"{x:910,y:587,t:1528139642297};\\\", \\\"{x:920,y:592,t:1528139642315};\\\", \\\"{x:921,y:593,t:1528139642345};\\\", \\\"{x:922,y:594,t:1528139642378};\\\", \\\"{x:924,y:594,t:1528139642397};\\\", \\\"{x:925,y:594,t:1528139642414};\\\", \\\"{x:923,y:594,t:1528139642523};\\\", \\\"{x:913,y:594,t:1528139642531};\\\", \\\"{x:898,y:594,t:1528139642548};\\\", \\\"{x:876,y:592,t:1528139642566};\\\", \\\"{x:857,y:590,t:1528139642581};\\\", \\\"{x:852,y:588,t:1528139642598};\\\", \\\"{x:852,y:587,t:1528139642682};\\\", \\\"{x:852,y:586,t:1528139642707};\\\", \\\"{x:852,y:584,t:1528139642714};\\\", \\\"{x:852,y:582,t:1528139642730};\\\", \\\"{x:852,y:581,t:1528139642747};\\\", \\\"{x:851,y:579,t:1528139642766};\\\", \\\"{x:850,y:579,t:1528139643015};\\\", \\\"{x:828,y:589,t:1528139643033};\\\", \\\"{x:820,y:593,t:1528139643047};\\\", \\\"{x:820,y:596,t:1528139643275};\\\", \\\"{x:818,y:605,t:1528139643282};\\\", \\\"{x:806,y:616,t:1528139643298};\\\", \\\"{x:780,y:630,t:1528139643315};\\\", \\\"{x:770,y:637,t:1528139643332};\\\", \\\"{x:749,y:646,t:1528139643349};\\\", \\\"{x:747,y:646,t:1528139643378};\\\", \\\"{x:746,y:646,t:1528139643755};\\\", \\\"{x:734,y:646,t:1528139643765};\\\", \\\"{x:697,y:657,t:1528139643784};\\\", \\\"{x:674,y:663,t:1528139643799};\\\", \\\"{x:657,y:673,t:1528139643815};\\\", \\\"{x:638,y:680,t:1528139643831};\\\", \\\"{x:626,y:687,t:1528139643848};\\\", \\\"{x:604,y:698,t:1528139643865};\\\", \\\"{x:598,y:707,t:1528139643882};\\\", \\\"{x:596,y:710,t:1528139643899};\\\", \\\"{x:593,y:717,t:1528139643915};\\\", \\\"{x:591,y:717,t:1528139643932};\\\", \\\"{x:590,y:717,t:1528139643954};\\\", \\\"{x:590,y:718,t:1528139643978};\\\", \\\"{x:590,y:719,t:1528139644018};\\\", \\\"{x:588,y:719,t:1528139644031};\\\", \\\"{x:588,y:720,t:1528139644049};\\\", \\\"{x:583,y:721,t:1528139644435};\\\", \\\"{x:575,y:726,t:1528139644448};\\\", \\\"{x:574,y:727,t:1528139644465};\\\", \\\"{x:560,y:736,t:1528139644481};\\\", \\\"{x:554,y:741,t:1528139644498};\\\", \\\"{x:553,y:742,t:1528139644515};\\\", \\\"{x:552,y:743,t:1528139644531};\\\", \\\"{x:541,y:749,t:1528139644548};\\\", \\\"{x:518,y:762,t:1528139644566};\\\", \\\"{x:508,y:769,t:1528139644581};\\\", \\\"{x:497,y:774,t:1528139644598};\\\", \\\"{x:494,y:776,t:1528139644614};\\\" ] }, { \\\"rt\\\": 6948, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 253263, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"ZEPVG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:493,y:772,t:1528139647785};\\\", \\\"{x:507,y:662,t:1528139647802};\\\", \\\"{x:544,y:550,t:1528139647819};\\\", \\\"{x:595,y:453,t:1528139647836};\\\", \\\"{x:654,y:377,t:1528139647852};\\\", \\\"{x:699,y:335,t:1528139647868};\\\", \\\"{x:741,y:286,t:1528139647884};\\\", \\\"{x:752,y:273,t:1528139647902};\\\", \\\"{x:753,y:271,t:1528139647919};\\\", \\\"{x:754,y:270,t:1528139648034};\\\", \\\"{x:758,y:266,t:1528139648042};\\\", \\\"{x:762,y:264,t:1528139648052};\\\", \\\"{x:766,y:260,t:1528139648069};\\\", \\\"{x:780,y:249,t:1528139648086};\\\", \\\"{x:795,y:240,t:1528139648102};\\\", \\\"{x:807,y:236,t:1528139648119};\\\", \\\"{x:834,y:236,t:1528139648136};\\\", \\\"{x:871,y:241,t:1528139648152};\\\", \\\"{x:940,y:268,t:1528139648168};\\\", \\\"{x:990,y:321,t:1528139648186};\\\", \\\"{x:1002,y:353,t:1528139648202};\\\", \\\"{x:1009,y:388,t:1528139648219};\\\", \\\"{x:1011,y:426,t:1528139648236};\\\", \\\"{x:1011,y:451,t:1528139648252};\\\", \\\"{x:1011,y:473,t:1528139648269};\\\", \\\"{x:1011,y:479,t:1528139648286};\\\", \\\"{x:1011,y:490,t:1528139648302};\\\", \\\"{x:1011,y:506,t:1528139648319};\\\", \\\"{x:1010,y:534,t:1528139648337};\\\", \\\"{x:1012,y:554,t:1528139648352};\\\", \\\"{x:1014,y:565,t:1528139648369};\\\", \\\"{x:1014,y:569,t:1528139648386};\\\", \\\"{x:1016,y:579,t:1528139648403};\\\", \\\"{x:1022,y:588,t:1528139648419};\\\", \\\"{x:1024,y:589,t:1528139648436};\\\", \\\"{x:1028,y:590,t:1528139648454};\\\", \\\"{x:1042,y:591,t:1528139648469};\\\", \\\"{x:1062,y:591,t:1528139648486};\\\", \\\"{x:1102,y:591,t:1528139648503};\\\", \\\"{x:1166,y:591,t:1528139648520};\\\", \\\"{x:1212,y:593,t:1528139648537};\\\", \\\"{x:1235,y:593,t:1528139648553};\\\", \\\"{x:1244,y:594,t:1528139648570};\\\", \\\"{x:1269,y:599,t:1528139648587};\\\", \\\"{x:1282,y:601,t:1528139648603};\\\", \\\"{x:1290,y:604,t:1528139648619};\\\", \\\"{x:1298,y:607,t:1528139648637};\\\", \\\"{x:1300,y:607,t:1528139648654};\\\", \\\"{x:1303,y:607,t:1528139648669};\\\", \\\"{x:1304,y:607,t:1528139648687};\\\", \\\"{x:1306,y:607,t:1528139648704};\\\", \\\"{x:1307,y:607,t:1528139648720};\\\", \\\"{x:1310,y:607,t:1528139648736};\\\", \\\"{x:1311,y:607,t:1528139648753};\\\", \\\"{x:1313,y:606,t:1528139648769};\\\", \\\"{x:1317,y:602,t:1528139648786};\\\", \\\"{x:1321,y:597,t:1528139648803};\\\", \\\"{x:1333,y:584,t:1528139648820};\\\", \\\"{x:1345,y:570,t:1528139648836};\\\", \\\"{x:1361,y:556,t:1528139648854};\\\", \\\"{x:1369,y:545,t:1528139648871};\\\", \\\"{x:1372,y:541,t:1528139648886};\\\", \\\"{x:1374,y:540,t:1528139648904};\\\", \\\"{x:1371,y:540,t:1528139648995};\\\", \\\"{x:1362,y:545,t:1528139649004};\\\", \\\"{x:1268,y:563,t:1528139649020};\\\", \\\"{x:1117,y:576,t:1528139649037};\\\", \\\"{x:909,y:581,t:1528139649054};\\\", \\\"{x:654,y:592,t:1528139649070};\\\", \\\"{x:339,y:607,t:1528139649087};\\\", \\\"{x:1,y:644,t:1528139649103};\\\", \\\"{x:0,y:656,t:1528139649120};\\\", \\\"{x:0,y:680,t:1528139649136};\\\", \\\"{x:0,y:682,t:1528139649153};\\\", \\\"{x:0,y:672,t:1528139649170};\\\", \\\"{x:2,y:672,t:1528139649218};\\\", \\\"{x:39,y:672,t:1528139649226};\\\", \\\"{x:96,y:668,t:1528139649236};\\\", \\\"{x:226,y:665,t:1528139649253};\\\", \\\"{x:340,y:665,t:1528139649271};\\\", \\\"{x:423,y:665,t:1528139649286};\\\", \\\"{x:494,y:651,t:1528139649303};\\\", \\\"{x:516,y:643,t:1528139649321};\\\", \\\"{x:530,y:634,t:1528139649337};\\\", \\\"{x:532,y:632,t:1528139649353};\\\", \\\"{x:532,y:630,t:1528139649387};\\\", \\\"{x:533,y:619,t:1528139649403};\\\", \\\"{x:535,y:601,t:1528139649420};\\\", \\\"{x:535,y:577,t:1528139649437};\\\", \\\"{x:535,y:558,t:1528139649453};\\\", \\\"{x:534,y:550,t:1528139649470};\\\", \\\"{x:530,y:543,t:1528139649487};\\\", \\\"{x:516,y:539,t:1528139649503};\\\", \\\"{x:492,y:535,t:1528139649520};\\\", \\\"{x:432,y:535,t:1528139649537};\\\", \\\"{x:354,y:535,t:1528139649553};\\\", \\\"{x:246,y:556,t:1528139649570};\\\", \\\"{x:217,y:558,t:1528139649587};\\\", \\\"{x:186,y:558,t:1528139649603};\\\", \\\"{x:164,y:558,t:1528139649620};\\\", \\\"{x:155,y:558,t:1528139649637};\\\", \\\"{x:153,y:558,t:1528139649654};\\\", \\\"{x:152,y:558,t:1528139649670};\\\", \\\"{x:149,y:555,t:1528139649688};\\\", \\\"{x:136,y:548,t:1528139649704};\\\", \\\"{x:119,y:542,t:1528139649720};\\\", \\\"{x:109,y:541,t:1528139649737};\\\", \\\"{x:105,y:541,t:1528139649754};\\\", \\\"{x:105,y:539,t:1528139649819};\\\", \\\"{x:106,y:537,t:1528139649834};\\\", \\\"{x:107,y:535,t:1528139649842};\\\", \\\"{x:110,y:534,t:1528139649854};\\\", \\\"{x:116,y:527,t:1528139649869};\\\", \\\"{x:124,y:521,t:1528139649887};\\\", \\\"{x:135,y:515,t:1528139649904};\\\", \\\"{x:149,y:510,t:1528139649920};\\\", \\\"{x:165,y:507,t:1528139649937};\\\", \\\"{x:203,y:498,t:1528139649954};\\\", \\\"{x:233,y:485,t:1528139649970};\\\", \\\"{x:249,y:478,t:1528139649987};\\\", \\\"{x:258,y:477,t:1528139650004};\\\", \\\"{x:266,y:476,t:1528139650020};\\\", \\\"{x:275,y:476,t:1528139650037};\\\", \\\"{x:283,y:477,t:1528139650054};\\\", \\\"{x:295,y:482,t:1528139650070};\\\", \\\"{x:313,y:489,t:1528139650088};\\\", \\\"{x:330,y:497,t:1528139650104};\\\", \\\"{x:337,y:504,t:1528139650120};\\\", \\\"{x:354,y:514,t:1528139650137};\\\", \\\"{x:379,y:531,t:1528139650156};\\\", \\\"{x:397,y:537,t:1528139650172};\\\", \\\"{x:414,y:540,t:1528139650187};\\\", \\\"{x:425,y:542,t:1528139650205};\\\", \\\"{x:452,y:542,t:1528139650221};\\\", \\\"{x:485,y:542,t:1528139650237};\\\", \\\"{x:524,y:540,t:1528139650254};\\\", \\\"{x:556,y:540,t:1528139650270};\\\", \\\"{x:579,y:540,t:1528139650287};\\\", \\\"{x:598,y:538,t:1528139650304};\\\", \\\"{x:622,y:531,t:1528139650321};\\\", \\\"{x:632,y:526,t:1528139650337};\\\", \\\"{x:635,y:525,t:1528139650353};\\\", \\\"{x:635,y:524,t:1528139650548};\\\", \\\"{x:635,y:522,t:1528139650555};\\\", \\\"{x:635,y:520,t:1528139650571};\\\", \\\"{x:635,y:515,t:1528139650589};\\\", \\\"{x:629,y:507,t:1528139650604};\\\", \\\"{x:628,y:503,t:1528139650621};\\\", \\\"{x:627,y:502,t:1528139650638};\\\", \\\"{x:626,y:501,t:1528139650654};\\\", \\\"{x:638,y:507,t:1528139650986};\\\", \\\"{x:726,y:529,t:1528139651006};\\\", \\\"{x:822,y:550,t:1528139651021};\\\", \\\"{x:877,y:563,t:1528139651038};\\\", \\\"{x:901,y:570,t:1528139651055};\\\", \\\"{x:914,y:570,t:1528139651071};\\\", \\\"{x:916,y:570,t:1528139651088};\\\", \\\"{x:916,y:569,t:1528139651114};\\\", \\\"{x:916,y:565,t:1528139651122};\\\", \\\"{x:914,y:562,t:1528139651139};\\\", \\\"{x:911,y:557,t:1528139651155};\\\", \\\"{x:909,y:553,t:1528139651172};\\\", \\\"{x:902,y:545,t:1528139651188};\\\", \\\"{x:882,y:534,t:1528139651205};\\\", \\\"{x:852,y:527,t:1528139651221};\\\", \\\"{x:821,y:522,t:1528139651240};\\\", \\\"{x:787,y:520,t:1528139651256};\\\", \\\"{x:769,y:515,t:1528139651273};\\\", \\\"{x:762,y:515,t:1528139651288};\\\", \\\"{x:762,y:516,t:1528139651338};\\\", \\\"{x:765,y:519,t:1528139651355};\\\", \\\"{x:766,y:520,t:1528139651372};\\\", \\\"{x:770,y:523,t:1528139651388};\\\", \\\"{x:773,y:525,t:1528139651405};\\\", \\\"{x:777,y:528,t:1528139651421};\\\", \\\"{x:780,y:529,t:1528139651438};\\\", \\\"{x:782,y:530,t:1528139651455};\\\", \\\"{x:785,y:531,t:1528139651472};\\\", \\\"{x:786,y:531,t:1528139651531};\\\", \\\"{x:788,y:531,t:1528139651538};\\\", \\\"{x:789,y:531,t:1528139651562};\\\", \\\"{x:795,y:532,t:1528139651859};\\\", \\\"{x:808,y:535,t:1528139651872};\\\", \\\"{x:825,y:540,t:1528139651890};\\\", \\\"{x:840,y:541,t:1528139651905};\\\", \\\"{x:846,y:541,t:1528139651923};\\\", \\\"{x:835,y:542,t:1528139652234};\\\", \\\"{x:822,y:555,t:1528139652242};\\\", \\\"{x:799,y:573,t:1528139652256};\\\", \\\"{x:672,y:633,t:1528139652272};\\\", \\\"{x:556,y:667,t:1528139652289};\\\", \\\"{x:484,y:695,t:1528139652306};\\\", \\\"{x:404,y:729,t:1528139652322};\\\", \\\"{x:385,y:738,t:1528139652339};\\\", \\\"{x:382,y:738,t:1528139652357};\\\", \\\"{x:382,y:737,t:1528139652401};\\\", \\\"{x:383,y:737,t:1528139652434};\\\", \\\"{x:384,y:737,t:1528139652491};\\\", \\\"{x:385,y:737,t:1528139652530};\\\", \\\"{x:391,y:737,t:1528139652539};\\\", \\\"{x:395,y:735,t:1528139652556};\\\", \\\"{x:402,y:729,t:1528139652573};\\\", \\\"{x:421,y:723,t:1528139652589};\\\", \\\"{x:426,y:719,t:1528139652607};\\\", \\\"{x:446,y:716,t:1528139652623};\\\", \\\"{x:461,y:716,t:1528139652640};\\\", \\\"{x:469,y:716,t:1528139652656};\\\", \\\"{x:476,y:716,t:1528139652673};\\\", \\\"{x:478,y:717,t:1528139652689};\\\", \\\"{x:480,y:721,t:1528139652788};\\\", \\\"{x:480,y:723,t:1528139652806};\\\", \\\"{x:480,y:729,t:1528139652823};\\\", \\\"{x:480,y:730,t:1528139652840};\\\", \\\"{x:480,y:731,t:1528139652856};\\\", \\\"{x:480,y:732,t:1528139652873};\\\" ] }, { \\\"rt\\\": 26383, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 280876, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"ZEPVG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 4, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -F -F -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:480,y:718,t:1528139654907};\\\", \\\"{x:480,y:706,t:1528139654926};\\\", \\\"{x:478,y:687,t:1528139654941};\\\", \\\"{x:478,y:677,t:1528139654958};\\\", \\\"{x:476,y:668,t:1528139654974};\\\", \\\"{x:476,y:662,t:1528139654991};\\\", \\\"{x:474,y:658,t:1528139655499};\\\", \\\"{x:472,y:654,t:1528139655530};\\\", \\\"{x:471,y:652,t:1528139655542};\\\", \\\"{x:468,y:649,t:1528139655558};\\\", \\\"{x:467,y:648,t:1528139655575};\\\", \\\"{x:466,y:647,t:1528139656859};\\\", \\\"{x:465,y:647,t:1528139656876};\\\", \\\"{x:464,y:647,t:1528139656892};\\\", \\\"{x:459,y:647,t:1528139657010};\\\", \\\"{x:435,y:635,t:1528139657027};\\\", \\\"{x:390,y:623,t:1528139657045};\\\", \\\"{x:388,y:622,t:1528139657058};\\\", \\\"{x:392,y:620,t:1528139658819};\\\", \\\"{x:399,y:615,t:1528139658828};\\\", \\\"{x:415,y:609,t:1528139658845};\\\", \\\"{x:447,y:592,t:1528139658863};\\\", \\\"{x:489,y:576,t:1528139658877};\\\", \\\"{x:550,y:550,t:1528139658894};\\\", \\\"{x:610,y:526,t:1528139658911};\\\", \\\"{x:673,y:503,t:1528139658928};\\\", \\\"{x:722,y:475,t:1528139658944};\\\", \\\"{x:804,y:441,t:1528139658961};\\\", \\\"{x:952,y:352,t:1528139658978};\\\", \\\"{x:1074,y:265,t:1528139658994};\\\", \\\"{x:1187,y:197,t:1528139659011};\\\", \\\"{x:1288,y:139,t:1528139659028};\\\", \\\"{x:1371,y:88,t:1528139659045};\\\", \\\"{x:1439,y:59,t:1528139659062};\\\", \\\"{x:1494,y:28,t:1528139659078};\\\", \\\"{x:1535,y:12,t:1528139659095};\\\", \\\"{x:1558,y:7,t:1528139659111};\\\", \\\"{x:1579,y:1,t:1528139659128};\\\", \\\"{x:1604,y:0,t:1528139659145};\\\", \\\"{x:1619,y:0,t:1528139659161};\\\", \\\"{x:1632,y:1,t:1528139659177};\\\", \\\"{x:1663,y:18,t:1528139659194};\\\", \\\"{x:1732,y:79,t:1528139659212};\\\", \\\"{x:1804,y:187,t:1528139659229};\\\", \\\"{x:1825,y:318,t:1528139659244};\\\", \\\"{x:1824,y:404,t:1528139659261};\\\", \\\"{x:1812,y:464,t:1528139659279};\\\", \\\"{x:1791,y:506,t:1528139659295};\\\", \\\"{x:1771,y:526,t:1528139659312};\\\", \\\"{x:1747,y:553,t:1528139659329};\\\", \\\"{x:1701,y:587,t:1528139659344};\\\", \\\"{x:1659,y:609,t:1528139659362};\\\", \\\"{x:1626,y:618,t:1528139659378};\\\", \\\"{x:1545,y:647,t:1528139659396};\\\", \\\"{x:1440,y:694,t:1528139659412};\\\", \\\"{x:1331,y:729,t:1528139659429};\\\", \\\"{x:1286,y:742,t:1528139659446};\\\", \\\"{x:1274,y:747,t:1528139659462};\\\", \\\"{x:1267,y:748,t:1528139659479};\\\", \\\"{x:1265,y:748,t:1528139659496};\\\", \\\"{x:1264,y:748,t:1528139659571};\\\", \\\"{x:1263,y:743,t:1528139659579};\\\", \\\"{x:1251,y:731,t:1528139659596};\\\", \\\"{x:1240,y:719,t:1528139659612};\\\", \\\"{x:1231,y:705,t:1528139659629};\\\", \\\"{x:1226,y:695,t:1528139659646};\\\", \\\"{x:1223,y:689,t:1528139659662};\\\", \\\"{x:1218,y:679,t:1528139659679};\\\", \\\"{x:1213,y:671,t:1528139659696};\\\", \\\"{x:1209,y:664,t:1528139659712};\\\", \\\"{x:1208,y:661,t:1528139659729};\\\", \\\"{x:1207,y:658,t:1528139659746};\\\", \\\"{x:1206,y:657,t:1528139659763};\\\", \\\"{x:1205,y:655,t:1528139659779};\\\", \\\"{x:1205,y:654,t:1528139659819};\\\", \\\"{x:1204,y:654,t:1528139659835};\\\", \\\"{x:1201,y:654,t:1528139659979};\\\", \\\"{x:1189,y:666,t:1528139659996};\\\", \\\"{x:1176,y:685,t:1528139660013};\\\", \\\"{x:1166,y:713,t:1528139660028};\\\", \\\"{x:1153,y:744,t:1528139660046};\\\", \\\"{x:1147,y:771,t:1528139660063};\\\", \\\"{x:1140,y:785,t:1528139660079};\\\", \\\"{x:1137,y:795,t:1528139660096};\\\", \\\"{x:1135,y:809,t:1528139660113};\\\", \\\"{x:1134,y:824,t:1528139660129};\\\", \\\"{x:1133,y:843,t:1528139660147};\\\", \\\"{x:1133,y:849,t:1528139660162};\\\", \\\"{x:1135,y:855,t:1528139660180};\\\", \\\"{x:1135,y:861,t:1528139660197};\\\", \\\"{x:1135,y:868,t:1528139660213};\\\", \\\"{x:1136,y:868,t:1528139660230};\\\", \\\"{x:1136,y:869,t:1528139660339};\\\", \\\"{x:1138,y:862,t:1528139660347};\\\", \\\"{x:1144,y:844,t:1528139660363};\\\", \\\"{x:1148,y:826,t:1528139660380};\\\", \\\"{x:1148,y:818,t:1528139660396};\\\", \\\"{x:1145,y:802,t:1528139660413};\\\", \\\"{x:1146,y:796,t:1528139660430};\\\", \\\"{x:1146,y:794,t:1528139660446};\\\", \\\"{x:1147,y:793,t:1528139660463};\\\", \\\"{x:1149,y:791,t:1528139660482};\\\", \\\"{x:1149,y:790,t:1528139660497};\\\", \\\"{x:1152,y:782,t:1528139660514};\\\", \\\"{x:1153,y:780,t:1528139660531};\\\", \\\"{x:1154,y:778,t:1528139660554};\\\", \\\"{x:1158,y:773,t:1528139660562};\\\", \\\"{x:1178,y:746,t:1528139660580};\\\", \\\"{x:1195,y:731,t:1528139660598};\\\", \\\"{x:1203,y:725,t:1528139660613};\\\", \\\"{x:1212,y:717,t:1528139660631};\\\", \\\"{x:1220,y:710,t:1528139660647};\\\", \\\"{x:1223,y:708,t:1528139660663};\\\", \\\"{x:1231,y:698,t:1528139660680};\\\", \\\"{x:1241,y:678,t:1528139660697};\\\", \\\"{x:1252,y:644,t:1528139660713};\\\", \\\"{x:1278,y:579,t:1528139660730};\\\", \\\"{x:1287,y:565,t:1528139660746};\\\", \\\"{x:1294,y:551,t:1528139660763};\\\", \\\"{x:1297,y:538,t:1528139660780};\\\", \\\"{x:1299,y:527,t:1528139660797};\\\", \\\"{x:1301,y:524,t:1528139660813};\\\", \\\"{x:1301,y:535,t:1528139660964};\\\", \\\"{x:1298,y:609,t:1528139660980};\\\", \\\"{x:1298,y:701,t:1528139660997};\\\", \\\"{x:1301,y:774,t:1528139661014};\\\", \\\"{x:1301,y:791,t:1528139661030};\\\", \\\"{x:1301,y:785,t:1528139661155};\\\", \\\"{x:1301,y:768,t:1528139661164};\\\", \\\"{x:1301,y:738,t:1528139661180};\\\", \\\"{x:1301,y:725,t:1528139661197};\\\", \\\"{x:1301,y:703,t:1528139661215};\\\", \\\"{x:1296,y:695,t:1528139661230};\\\", \\\"{x:1296,y:666,t:1528139661248};\\\", \\\"{x:1296,y:657,t:1528139661264};\\\", \\\"{x:1297,y:660,t:1528139661339};\\\", \\\"{x:1302,y:673,t:1528139661347};\\\", \\\"{x:1327,y:734,t:1528139661364};\\\", \\\"{x:1353,y:792,t:1528139661381};\\\", \\\"{x:1361,y:814,t:1528139661397};\\\", \\\"{x:1366,y:829,t:1528139661414};\\\", \\\"{x:1367,y:830,t:1528139661431};\\\", \\\"{x:1368,y:830,t:1528139661447};\\\", \\\"{x:1368,y:826,t:1528139661571};\\\", \\\"{x:1368,y:819,t:1528139661581};\\\", \\\"{x:1368,y:805,t:1528139661597};\\\", \\\"{x:1367,y:786,t:1528139661614};\\\", \\\"{x:1362,y:771,t:1528139661631};\\\", \\\"{x:1358,y:757,t:1528139661648};\\\", \\\"{x:1353,y:741,t:1528139661664};\\\", \\\"{x:1350,y:727,t:1528139661681};\\\", \\\"{x:1344,y:695,t:1528139661701};\\\", \\\"{x:1340,y:679,t:1528139661714};\\\", \\\"{x:1337,y:669,t:1528139661730};\\\", \\\"{x:1337,y:668,t:1528139661747};\\\", \\\"{x:1337,y:669,t:1528139661865};\\\", \\\"{x:1337,y:676,t:1528139661881};\\\", \\\"{x:1344,y:703,t:1528139661898};\\\", \\\"{x:1348,y:713,t:1528139661913};\\\", \\\"{x:1349,y:717,t:1528139661931};\\\", \\\"{x:1350,y:717,t:1528139661947};\\\", \\\"{x:1351,y:717,t:1528139661970};\\\", \\\"{x:1352,y:714,t:1528139662275};\\\", \\\"{x:1352,y:708,t:1528139662282};\\\", \\\"{x:1352,y:701,t:1528139662299};\\\", \\\"{x:1352,y:699,t:1528139662315};\\\", \\\"{x:1352,y:697,t:1528139662331};\\\", \\\"{x:1352,y:695,t:1528139662348};\\\", \\\"{x:1348,y:699,t:1528139667539};\\\", \\\"{x:1340,y:717,t:1528139667555};\\\", \\\"{x:1335,y:728,t:1528139667569};\\\", \\\"{x:1329,y:735,t:1528139667586};\\\", \\\"{x:1329,y:736,t:1528139667682};\\\", \\\"{x:1329,y:737,t:1528139667691};\\\", \\\"{x:1329,y:739,t:1528139667707};\\\", \\\"{x:1330,y:740,t:1528139667722};\\\", \\\"{x:1331,y:740,t:1528139667739};\\\", \\\"{x:1332,y:741,t:1528139667771};\\\", \\\"{x:1334,y:742,t:1528139667819};\\\", \\\"{x:1337,y:744,t:1528139667827};\\\", \\\"{x:1339,y:747,t:1528139667836};\\\", \\\"{x:1341,y:752,t:1528139667854};\\\", \\\"{x:1341,y:753,t:1528139667870};\\\", \\\"{x:1341,y:756,t:1528139667887};\\\", \\\"{x:1343,y:759,t:1528139667903};\\\", \\\"{x:1343,y:764,t:1528139667921};\\\", \\\"{x:1343,y:768,t:1528139667937};\\\", \\\"{x:1343,y:771,t:1528139667953};\\\", \\\"{x:1343,y:774,t:1528139667971};\\\", \\\"{x:1343,y:775,t:1528139667986};\\\", \\\"{x:1343,y:777,t:1528139668051};\\\", \\\"{x:1338,y:778,t:1528139668067};\\\", \\\"{x:1324,y:776,t:1528139668074};\\\", \\\"{x:1296,y:767,t:1528139668087};\\\", \\\"{x:1183,y:741,t:1528139668103};\\\", \\\"{x:1032,y:706,t:1528139668121};\\\", \\\"{x:861,y:659,t:1528139668136};\\\", \\\"{x:745,y:611,t:1528139668155};\\\", \\\"{x:743,y:611,t:1528139668170};\\\", \\\"{x:742,y:611,t:1528139668378};\\\", \\\"{x:738,y:610,t:1528139668386};\\\", \\\"{x:735,y:610,t:1528139668426};\\\", \\\"{x:728,y:608,t:1528139668435};\\\", \\\"{x:727,y:607,t:1528139668699};\\\", \\\"{x:722,y:606,t:1528139668707};\\\", \\\"{x:714,y:605,t:1528139668718};\\\", \\\"{x:686,y:602,t:1528139668734};\\\", \\\"{x:670,y:600,t:1528139668751};\\\", \\\"{x:660,y:597,t:1528139668767};\\\", \\\"{x:658,y:597,t:1528139668786};\\\", \\\"{x:657,y:596,t:1528139668954};\\\", \\\"{x:656,y:596,t:1528139669123};\\\", \\\"{x:655,y:596,t:1528139669136};\\\", \\\"{x:654,y:596,t:1528139669154};\\\", \\\"{x:643,y:596,t:1528139669170};\\\", \\\"{x:633,y:594,t:1528139669187};\\\", \\\"{x:623,y:594,t:1528139669203};\\\", \\\"{x:615,y:593,t:1528139669221};\\\", \\\"{x:603,y:593,t:1528139669236};\\\", \\\"{x:598,y:592,t:1528139669252};\\\", \\\"{x:593,y:589,t:1528139669269};\\\", \\\"{x:586,y:588,t:1528139669287};\\\", \\\"{x:581,y:585,t:1528139669303};\\\", \\\"{x:576,y:582,t:1528139669320};\\\", \\\"{x:573,y:582,t:1528139669337};\\\", \\\"{x:571,y:582,t:1528139669353};\\\", \\\"{x:570,y:582,t:1528139669410};\\\", \\\"{x:569,y:582,t:1528139671299};\\\", \\\"{x:566,y:582,t:1528139671314};\\\", \\\"{x:558,y:586,t:1528139671322};\\\", \\\"{x:541,y:593,t:1528139671338};\\\", \\\"{x:528,y:595,t:1528139671357};\\\", \\\"{x:521,y:597,t:1528139671371};\\\", \\\"{x:518,y:598,t:1528139671388};\\\", \\\"{x:516,y:600,t:1528139671404};\\\", \\\"{x:514,y:601,t:1528139671422};\\\", \\\"{x:512,y:601,t:1528139671458};\\\", \\\"{x:510,y:601,t:1528139671538};\\\", \\\"{x:508,y:601,t:1528139671555};\\\", \\\"{x:505,y:600,t:1528139671572};\\\", \\\"{x:504,y:600,t:1528139671588};\\\", \\\"{x:502,y:599,t:1528139671610};\\\", \\\"{x:501,y:598,t:1528139671622};\\\", \\\"{x:499,y:597,t:1528139671638};\\\", \\\"{x:497,y:596,t:1528139671655};\\\", \\\"{x:495,y:596,t:1528139671672};\\\", \\\"{x:494,y:596,t:1528139671810};\\\", \\\"{x:492,y:596,t:1528139672395};\\\", \\\"{x:488,y:596,t:1528139672762};\\\", \\\"{x:483,y:600,t:1528139672772};\\\", \\\"{x:478,y:603,t:1528139672790};\\\", \\\"{x:477,y:603,t:1528139672806};\\\", \\\"{x:475,y:603,t:1528139672842};\\\", \\\"{x:474,y:604,t:1528139672882};\\\", \\\"{x:473,y:605,t:1528139672889};\\\", \\\"{x:473,y:606,t:1528139672906};\\\", \\\"{x:472,y:607,t:1528139672923};\\\", \\\"{x:471,y:607,t:1528139672961};\\\", \\\"{x:466,y:608,t:1528139672977};\\\", \\\"{x:462,y:608,t:1528139672990};\\\", \\\"{x:458,y:608,t:1528139673006};\\\", \\\"{x:449,y:607,t:1528139673023};\\\", \\\"{x:448,y:607,t:1528139673040};\\\", \\\"{x:448,y:606,t:1528139673056};\\\", \\\"{x:447,y:606,t:1528139673073};\\\", \\\"{x:442,y:607,t:1528139673674};\\\", \\\"{x:432,y:607,t:1528139673690};\\\", \\\"{x:406,y:608,t:1528139673708};\\\", \\\"{x:390,y:608,t:1528139673725};\\\", \\\"{x:385,y:608,t:1528139673740};\\\", \\\"{x:382,y:605,t:1528139673803};\\\", \\\"{x:381,y:602,t:1528139673819};\\\", \\\"{x:381,y:600,t:1528139673827};\\\", \\\"{x:381,y:598,t:1528139673840};\\\", \\\"{x:381,y:580,t:1528139673858};\\\", \\\"{x:381,y:573,t:1528139673873};\\\", \\\"{x:381,y:564,t:1528139673890};\\\", \\\"{x:381,y:553,t:1528139673908};\\\", \\\"{x:381,y:545,t:1528139673925};\\\", \\\"{x:380,y:542,t:1528139673940};\\\", \\\"{x:378,y:539,t:1528139673957};\\\", \\\"{x:377,y:534,t:1528139673974};\\\", \\\"{x:374,y:529,t:1528139673990};\\\", \\\"{x:372,y:525,t:1528139674007};\\\", \\\"{x:369,y:523,t:1528139674025};\\\", \\\"{x:369,y:521,t:1528139674040};\\\", \\\"{x:366,y:516,t:1528139674057};\\\", \\\"{x:359,y:505,t:1528139674073};\\\", \\\"{x:348,y:500,t:1528139674090};\\\", \\\"{x:340,y:496,t:1528139674107};\\\", \\\"{x:322,y:495,t:1528139674124};\\\", \\\"{x:314,y:493,t:1528139674140};\\\", \\\"{x:299,y:495,t:1528139674157};\\\", \\\"{x:271,y:510,t:1528139674175};\\\", \\\"{x:244,y:523,t:1528139674190};\\\", \\\"{x:210,y:541,t:1528139674207};\\\", \\\"{x:177,y:552,t:1528139674223};\\\", \\\"{x:154,y:562,t:1528139674241};\\\", \\\"{x:151,y:563,t:1528139674257};\\\", \\\"{x:146,y:565,t:1528139674274};\\\", \\\"{x:144,y:564,t:1528139674354};\\\", \\\"{x:144,y:561,t:1528139674363};\\\", \\\"{x:144,y:560,t:1528139674374};\\\", \\\"{x:143,y:558,t:1528139674391};\\\", \\\"{x:143,y:555,t:1528139674408};\\\", \\\"{x:143,y:552,t:1528139674424};\\\", \\\"{x:143,y:551,t:1528139674441};\\\", \\\"{x:143,y:550,t:1528139674497};\\\", \\\"{x:145,y:548,t:1528139674507};\\\", \\\"{x:148,y:546,t:1528139674524};\\\", \\\"{x:149,y:544,t:1528139674542};\\\", \\\"{x:150,y:542,t:1528139674557};\\\", \\\"{x:151,y:542,t:1528139674635};\\\", \\\"{x:151,y:541,t:1528139674658};\\\", \\\"{x:153,y:538,t:1528139674674};\\\", \\\"{x:154,y:537,t:1528139674698};\\\", \\\"{x:155,y:536,t:1528139674747};\\\", \\\"{x:156,y:536,t:1528139674770};\\\", \\\"{x:156,y:535,t:1528139674786};\\\", \\\"{x:157,y:535,t:1528139675266};\\\", \\\"{x:170,y:535,t:1528139675274};\\\", \\\"{x:239,y:544,t:1528139675292};\\\", \\\"{x:337,y:559,t:1528139675308};\\\", \\\"{x:458,y:570,t:1528139675325};\\\", \\\"{x:562,y:579,t:1528139675342};\\\", \\\"{x:655,y:583,t:1528139675358};\\\", \\\"{x:711,y:591,t:1528139675375};\\\", \\\"{x:740,y:598,t:1528139675391};\\\", \\\"{x:749,y:600,t:1528139675408};\\\", \\\"{x:750,y:600,t:1528139675425};\\\", \\\"{x:749,y:600,t:1528139675529};\\\", \\\"{x:748,y:600,t:1528139675554};\\\", \\\"{x:747,y:600,t:1528139675595};\\\", \\\"{x:746,y:600,t:1528139675619};\\\", \\\"{x:744,y:600,t:1528139675634};\\\", \\\"{x:744,y:598,t:1528139675642};\\\", \\\"{x:743,y:590,t:1528139675659};\\\", \\\"{x:740,y:581,t:1528139675674};\\\", \\\"{x:736,y:568,t:1528139675692};\\\", \\\"{x:728,y:563,t:1528139675708};\\\", \\\"{x:717,y:559,t:1528139675725};\\\", \\\"{x:705,y:554,t:1528139675742};\\\", \\\"{x:696,y:551,t:1528139675758};\\\", \\\"{x:679,y:551,t:1528139675775};\\\", \\\"{x:667,y:551,t:1528139675791};\\\", \\\"{x:657,y:550,t:1528139675808};\\\", \\\"{x:649,y:550,t:1528139675825};\\\", \\\"{x:646,y:550,t:1528139675842};\\\", \\\"{x:647,y:549,t:1528139675922};\\\", \\\"{x:650,y:547,t:1528139675930};\\\", \\\"{x:659,y:541,t:1528139675942};\\\", \\\"{x:675,y:536,t:1528139675958};\\\", \\\"{x:701,y:525,t:1528139675975};\\\", \\\"{x:714,y:520,t:1528139675993};\\\", \\\"{x:717,y:519,t:1528139676009};\\\", \\\"{x:717,y:518,t:1528139676106};\\\", \\\"{x:719,y:516,t:1528139676116};\\\", \\\"{x:728,y:514,t:1528139676125};\\\", \\\"{x:741,y:509,t:1528139676142};\\\", \\\"{x:759,y:505,t:1528139676159};\\\", \\\"{x:779,y:499,t:1528139676175};\\\", \\\"{x:790,y:498,t:1528139676192};\\\", \\\"{x:794,y:497,t:1528139676209};\\\", \\\"{x:790,y:505,t:1528139676690};\\\", \\\"{x:784,y:515,t:1528139676698};\\\", \\\"{x:781,y:520,t:1528139676709};\\\", \\\"{x:776,y:538,t:1528139676726};\\\", \\\"{x:757,y:561,t:1528139676743};\\\", \\\"{x:743,y:583,t:1528139676759};\\\", \\\"{x:733,y:592,t:1528139676776};\\\", \\\"{x:719,y:609,t:1528139676793};\\\", \\\"{x:715,y:609,t:1528139676809};\\\", \\\"{x:715,y:605,t:1528139676857};\\\", \\\"{x:715,y:604,t:1528139676865};\\\", \\\"{x:719,y:596,t:1528139676877};\\\", \\\"{x:730,y:580,t:1528139676894};\\\", \\\"{x:757,y:554,t:1528139676910};\\\", \\\"{x:796,y:520,t:1528139676927};\\\", \\\"{x:848,y:486,t:1528139676943};\\\", \\\"{x:896,y:460,t:1528139676959};\\\", \\\"{x:915,y:448,t:1528139676976};\\\", \\\"{x:922,y:442,t:1528139676993};\\\", \\\"{x:922,y:440,t:1528139677010};\\\", \\\"{x:922,y:439,t:1528139677026};\\\", \\\"{x:921,y:438,t:1528139677114};\\\", \\\"{x:918,y:440,t:1528139677126};\\\", \\\"{x:905,y:457,t:1528139677144};\\\", \\\"{x:895,y:465,t:1528139677160};\\\", \\\"{x:894,y:466,t:1528139677176};\\\", \\\"{x:891,y:467,t:1528139677194};\\\", \\\"{x:888,y:468,t:1528139677210};\\\", \\\"{x:885,y:468,t:1528139677227};\\\", \\\"{x:881,y:469,t:1528139677244};\\\", \\\"{x:874,y:471,t:1528139677261};\\\", \\\"{x:867,y:472,t:1528139677277};\\\", \\\"{x:860,y:473,t:1528139677293};\\\", \\\"{x:857,y:473,t:1528139677310};\\\", \\\"{x:851,y:475,t:1528139677327};\\\", \\\"{x:843,y:479,t:1528139677343};\\\", \\\"{x:832,y:484,t:1528139677361};\\\", \\\"{x:818,y:492,t:1528139677377};\\\", \\\"{x:814,y:495,t:1528139677393};\\\", \\\"{x:818,y:496,t:1528139677666};\\\", \\\"{x:823,y:496,t:1528139677678};\\\", \\\"{x:824,y:496,t:1528139677963};\\\", \\\"{x:825,y:496,t:1528139678161};\\\", \\\"{x:828,y:493,t:1528139678178};\\\", \\\"{x:835,y:488,t:1528139678196};\\\", \\\"{x:835,y:490,t:1528139678547};\\\", \\\"{x:835,y:492,t:1528139678561};\\\", \\\"{x:835,y:497,t:1528139678578};\\\", \\\"{x:835,y:498,t:1528139678594};\\\", \\\"{x:835,y:501,t:1528139678610};\\\", \\\"{x:835,y:503,t:1528139678627};\\\", \\\"{x:835,y:505,t:1528139678645};\\\", \\\"{x:835,y:507,t:1528139678994};\\\", \\\"{x:829,y:508,t:1528139679011};\\\", \\\"{x:825,y:510,t:1528139679028};\\\", \\\"{x:814,y:518,t:1528139679050};\\\", \\\"{x:799,y:534,t:1528139679062};\\\", \\\"{x:792,y:542,t:1528139679077};\\\", \\\"{x:790,y:548,t:1528139679095};\\\", \\\"{x:790,y:554,t:1528139679111};\\\", \\\"{x:792,y:563,t:1528139679129};\\\", \\\"{x:797,y:572,t:1528139679145};\\\", \\\"{x:797,y:574,t:1528139679161};\\\", \\\"{x:797,y:575,t:1528139679179};\\\", \\\"{x:798,y:580,t:1528139679194};\\\", \\\"{x:798,y:588,t:1528139679211};\\\", \\\"{x:798,y:607,t:1528139679230};\\\", \\\"{x:795,y:624,t:1528139679245};\\\", \\\"{x:787,y:640,t:1528139679262};\\\", \\\"{x:779,y:649,t:1528139679278};\\\", \\\"{x:779,y:652,t:1528139679294};\\\", \\\"{x:758,y:656,t:1528139679311};\\\", \\\"{x:746,y:661,t:1528139679328};\\\", \\\"{x:745,y:661,t:1528139679344};\\\", \\\"{x:744,y:661,t:1528139679746};\\\", \\\"{x:724,y:669,t:1528139679762};\\\", \\\"{x:708,y:679,t:1528139679779};\\\", \\\"{x:689,y:692,t:1528139679796};\\\", \\\"{x:659,y:707,t:1528139679811};\\\", \\\"{x:604,y:720,t:1528139679829};\\\", \\\"{x:567,y:733,t:1528139679846};\\\", \\\"{x:539,y:741,t:1528139679863};\\\", \\\"{x:520,y:748,t:1528139679878};\\\", \\\"{x:494,y:755,t:1528139679895};\\\", \\\"{x:475,y:760,t:1528139679913};\\\", \\\"{x:454,y:761,t:1528139679928};\\\", \\\"{x:444,y:759,t:1528139679945};\\\", \\\"{x:433,y:753,t:1528139679962};\\\", \\\"{x:421,y:748,t:1528139679978};\\\", \\\"{x:413,y:741,t:1528139679995};\\\", \\\"{x:412,y:741,t:1528139680122};\\\", \\\"{x:414,y:741,t:1528139680154};\\\", \\\"{x:415,y:740,t:1528139680162};\\\", \\\"{x:419,y:739,t:1528139680179};\\\", \\\"{x:421,y:739,t:1528139680195};\\\", \\\"{x:423,y:739,t:1528139680212};\\\", \\\"{x:425,y:739,t:1528139680242};\\\", \\\"{x:427,y:739,t:1528139680250};\\\", \\\"{x:431,y:739,t:1528139680262};\\\", \\\"{x:440,y:739,t:1528139680279};\\\", \\\"{x:448,y:741,t:1528139680297};\\\", \\\"{x:454,y:742,t:1528139680312};\\\", \\\"{x:458,y:743,t:1528139680329};\\\", \\\"{x:459,y:743,t:1528139680970};\\\", \\\"{x:461,y:743,t:1528139680979};\\\", \\\"{x:462,y:743,t:1528139681002};\\\" ] }, { \\\"rt\\\": 44633, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 326822, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"ZEPVG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 2.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -B -B -B -B -E -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:463,y:743,t:1528139689914};\\\", \\\"{x:453,y:740,t:1528139689932};\\\", \\\"{x:453,y:739,t:1528139690170};\\\", \\\"{x:453,y:735,t:1528139690305};\\\", \\\"{x:453,y:723,t:1528139690322};\\\", \\\"{x:454,y:707,t:1528139690339};\\\", \\\"{x:458,y:688,t:1528139690354};\\\", \\\"{x:458,y:667,t:1528139690372};\\\", \\\"{x:459,y:657,t:1528139690387};\\\", \\\"{x:456,y:638,t:1528139690404};\\\", \\\"{x:440,y:617,t:1528139690420};\\\", \\\"{x:400,y:596,t:1528139690438};\\\", \\\"{x:351,y:586,t:1528139690454};\\\", \\\"{x:351,y:582,t:1528139690745};\\\", \\\"{x:352,y:579,t:1528139690754};\\\", \\\"{x:353,y:579,t:1528139690777};\\\", \\\"{x:354,y:574,t:1528139690788};\\\", \\\"{x:356,y:560,t:1528139690804};\\\", \\\"{x:376,y:523,t:1528139690821};\\\", \\\"{x:428,y:438,t:1528139690837};\\\", \\\"{x:535,y:349,t:1528139690854};\\\", \\\"{x:711,y:276,t:1528139690870};\\\", \\\"{x:891,y:242,t:1528139690888};\\\", \\\"{x:1028,y:235,t:1528139690905};\\\", \\\"{x:1120,y:261,t:1528139690921};\\\", \\\"{x:1129,y:276,t:1528139690937};\\\", \\\"{x:1129,y:283,t:1528139690955};\\\", \\\"{x:1115,y:299,t:1528139690971};\\\", \\\"{x:1110,y:310,t:1528139690987};\\\", \\\"{x:1109,y:310,t:1528139691009};\\\", \\\"{x:1110,y:307,t:1528139691761};\\\", \\\"{x:1110,y:304,t:1528139691772};\\\", \\\"{x:1117,y:297,t:1528139691789};\\\", \\\"{x:1120,y:295,t:1528139691806};\\\", \\\"{x:1127,y:290,t:1528139691821};\\\", \\\"{x:1140,y:282,t:1528139691839};\\\", \\\"{x:1159,y:270,t:1528139691856};\\\", \\\"{x:1179,y:260,t:1528139691872};\\\", \\\"{x:1213,y:242,t:1528139691888};\\\", \\\"{x:1270,y:219,t:1528139691905};\\\", \\\"{x:1283,y:213,t:1528139691922};\\\", \\\"{x:1293,y:209,t:1528139691938};\\\", \\\"{x:1304,y:205,t:1528139691956};\\\", \\\"{x:1305,y:205,t:1528139692113};\\\", \\\"{x:1308,y:209,t:1528139692169};\\\", \\\"{x:1311,y:216,t:1528139692177};\\\", \\\"{x:1318,y:236,t:1528139692188};\\\", \\\"{x:1329,y:259,t:1528139692206};\\\", \\\"{x:1336,y:275,t:1528139692222};\\\", \\\"{x:1343,y:290,t:1528139692239};\\\", \\\"{x:1348,y:300,t:1528139692256};\\\", \\\"{x:1348,y:306,t:1528139692272};\\\", \\\"{x:1351,y:311,t:1528139692289};\\\", \\\"{x:1351,y:314,t:1528139692306};\\\", \\\"{x:1351,y:318,t:1528139692322};\\\", \\\"{x:1351,y:317,t:1528139692817};\\\", \\\"{x:1351,y:316,t:1528139692897};\\\", \\\"{x:1351,y:315,t:1528139692907};\\\", \\\"{x:1351,y:313,t:1528139692923};\\\", \\\"{x:1351,y:310,t:1528139692939};\\\", \\\"{x:1351,y:308,t:1528139692957};\\\", \\\"{x:1351,y:303,t:1528139692973};\\\", \\\"{x:1351,y:301,t:1528139692990};\\\", \\\"{x:1353,y:298,t:1528139693007};\\\", \\\"{x:1353,y:296,t:1528139693024};\\\", \\\"{x:1354,y:294,t:1528139693040};\\\", \\\"{x:1356,y:288,t:1528139693056};\\\", \\\"{x:1359,y:278,t:1528139693073};\\\", \\\"{x:1361,y:274,t:1528139693090};\\\", \\\"{x:1364,y:269,t:1528139693107};\\\", \\\"{x:1364,y:267,t:1528139693124};\\\", \\\"{x:1364,y:265,t:1528139693140};\\\", \\\"{x:1364,y:264,t:1528139693156};\\\", \\\"{x:1364,y:257,t:1528139693173};\\\", \\\"{x:1364,y:252,t:1528139693189};\\\", \\\"{x:1364,y:251,t:1528139693207};\\\", \\\"{x:1367,y:242,t:1528139693224};\\\", \\\"{x:1372,y:234,t:1528139693239};\\\", \\\"{x:1372,y:233,t:1528139693257};\\\", \\\"{x:1372,y:232,t:1528139693289};\\\", \\\"{x:1373,y:231,t:1528139693313};\\\", \\\"{x:1374,y:231,t:1528139693324};\\\", \\\"{x:1377,y:229,t:1528139693340};\\\", \\\"{x:1382,y:229,t:1528139693357};\\\", \\\"{x:1393,y:249,t:1528139693374};\\\", \\\"{x:1412,y:297,t:1528139693391};\\\", \\\"{x:1440,y:358,t:1528139693407};\\\", \\\"{x:1472,y:410,t:1528139693424};\\\", \\\"{x:1485,y:431,t:1528139693440};\\\", \\\"{x:1490,y:443,t:1528139693457};\\\", \\\"{x:1492,y:449,t:1528139693473};\\\", \\\"{x:1492,y:452,t:1528139693491};\\\", \\\"{x:1495,y:457,t:1528139693507};\\\", \\\"{x:1492,y:463,t:1528139693523};\\\", \\\"{x:1489,y:468,t:1528139693540};\\\", \\\"{x:1486,y:471,t:1528139693556};\\\", \\\"{x:1485,y:472,t:1528139693573};\\\", \\\"{x:1484,y:472,t:1528139693633};\\\", \\\"{x:1483,y:472,t:1528139693641};\\\", \\\"{x:1482,y:472,t:1528139693657};\\\", \\\"{x:1480,y:465,t:1528139693674};\\\", \\\"{x:1481,y:455,t:1528139693691};\\\", \\\"{x:1486,y:439,t:1528139693708};\\\", \\\"{x:1493,y:420,t:1528139693724};\\\", \\\"{x:1497,y:411,t:1528139693741};\\\", \\\"{x:1497,y:410,t:1528139693757};\\\", \\\"{x:1497,y:417,t:1528139693809};\\\", \\\"{x:1493,y:429,t:1528139693824};\\\", \\\"{x:1485,y:441,t:1528139693841};\\\", \\\"{x:1481,y:458,t:1528139693857};\\\", \\\"{x:1481,y:459,t:1528139693874};\\\", \\\"{x:1480,y:459,t:1528139693977};\\\", \\\"{x:1476,y:462,t:1528139693991};\\\", \\\"{x:1472,y:463,t:1528139694008};\\\", \\\"{x:1463,y:469,t:1528139694024};\\\", \\\"{x:1461,y:471,t:1528139694041};\\\", \\\"{x:1449,y:478,t:1528139694058};\\\", \\\"{x:1446,y:487,t:1528139694075};\\\", \\\"{x:1430,y:496,t:1528139694091};\\\", \\\"{x:1427,y:498,t:1528139694108};\\\", \\\"{x:1403,y:510,t:1528139694125};\\\", \\\"{x:1381,y:523,t:1528139694141};\\\", \\\"{x:1360,y:533,t:1528139694158};\\\", \\\"{x:1357,y:536,t:1528139694175};\\\", \\\"{x:1357,y:542,t:1528139694465};\\\", \\\"{x:1353,y:565,t:1528139694475};\\\", \\\"{x:1339,y:628,t:1528139694491};\\\", \\\"{x:1320,y:713,t:1528139694507};\\\", \\\"{x:1313,y:758,t:1528139694525};\\\", \\\"{x:1305,y:786,t:1528139694542};\\\", \\\"{x:1305,y:796,t:1528139694558};\\\", \\\"{x:1302,y:805,t:1528139694575};\\\", \\\"{x:1302,y:806,t:1528139694601};\\\", \\\"{x:1302,y:807,t:1528139694617};\\\", \\\"{x:1303,y:807,t:1528139694657};\\\", \\\"{x:1304,y:807,t:1528139694681};\\\", \\\"{x:1309,y:803,t:1528139694697};\\\", \\\"{x:1315,y:798,t:1528139694709};\\\", \\\"{x:1329,y:783,t:1528139694725};\\\", \\\"{x:1340,y:770,t:1528139694742};\\\", \\\"{x:1349,y:761,t:1528139694759};\\\", \\\"{x:1351,y:758,t:1528139694775};\\\", \\\"{x:1352,y:758,t:1528139694792};\\\", \\\"{x:1353,y:756,t:1528139694817};\\\", \\\"{x:1355,y:755,t:1528139694825};\\\", \\\"{x:1357,y:752,t:1528139694842};\\\", \\\"{x:1358,y:751,t:1528139694859};\\\", \\\"{x:1359,y:750,t:1528139694881};\\\", \\\"{x:1358,y:750,t:1528139695025};\\\", \\\"{x:1355,y:751,t:1528139695042};\\\", \\\"{x:1352,y:753,t:1528139695059};\\\", \\\"{x:1351,y:753,t:1528139695075};\\\", \\\"{x:1349,y:753,t:1528139695092};\\\", \\\"{x:1349,y:754,t:1528139695369};\\\", \\\"{x:1348,y:755,t:1528139695385};\\\", \\\"{x:1347,y:756,t:1528139695521};\\\", \\\"{x:1347,y:763,t:1528139696706};\\\", \\\"{x:1347,y:799,t:1528139696727};\\\", \\\"{x:1345,y:810,t:1528139696742};\\\", \\\"{x:1344,y:814,t:1528139696758};\\\", \\\"{x:1344,y:816,t:1528139696776};\\\", \\\"{x:1344,y:821,t:1528139696792};\\\", \\\"{x:1343,y:829,t:1528139696808};\\\", \\\"{x:1343,y:838,t:1528139696826};\\\", \\\"{x:1343,y:844,t:1528139696843};\\\", \\\"{x:1343,y:847,t:1528139696858};\\\", \\\"{x:1343,y:851,t:1528139696876};\\\", \\\"{x:1343,y:854,t:1528139696893};\\\", \\\"{x:1343,y:857,t:1528139696908};\\\", \\\"{x:1341,y:869,t:1528139696926};\\\", \\\"{x:1341,y:883,t:1528139696943};\\\", \\\"{x:1341,y:891,t:1528139696959};\\\", \\\"{x:1340,y:898,t:1528139696976};\\\", \\\"{x:1340,y:906,t:1528139696993};\\\", \\\"{x:1340,y:915,t:1528139697009};\\\", \\\"{x:1340,y:924,t:1528139697026};\\\", \\\"{x:1340,y:927,t:1528139697042};\\\", \\\"{x:1339,y:929,t:1528139697059};\\\", \\\"{x:1339,y:930,t:1528139697075};\\\", \\\"{x:1339,y:931,t:1528139697105};\\\", \\\"{x:1339,y:932,t:1528139697113};\\\", \\\"{x:1339,y:934,t:1528139697145};\\\", \\\"{x:1339,y:933,t:1528139698370};\\\", \\\"{x:1340,y:926,t:1528139698377};\\\", \\\"{x:1340,y:917,t:1528139698394};\\\", \\\"{x:1342,y:911,t:1528139698409};\\\", \\\"{x:1342,y:903,t:1528139698425};\\\", \\\"{x:1345,y:894,t:1528139698442};\\\", \\\"{x:1346,y:888,t:1528139698459};\\\", \\\"{x:1347,y:884,t:1528139698475};\\\", \\\"{x:1347,y:882,t:1528139698492};\\\", \\\"{x:1349,y:879,t:1528139698509};\\\", \\\"{x:1349,y:877,t:1528139698525};\\\", \\\"{x:1349,y:874,t:1528139698542};\\\", \\\"{x:1349,y:873,t:1528139698559};\\\", \\\"{x:1349,y:872,t:1528139698575};\\\", \\\"{x:1349,y:871,t:1528139698592};\\\", \\\"{x:1349,y:870,t:1528139698609};\\\", \\\"{x:1349,y:869,t:1528139698625};\\\", \\\"{x:1350,y:867,t:1528139698642};\\\", \\\"{x:1350,y:866,t:1528139698673};\\\", \\\"{x:1350,y:865,t:1528139698680};\\\", \\\"{x:1350,y:864,t:1528139698693};\\\", \\\"{x:1351,y:862,t:1528139698709};\\\", \\\"{x:1351,y:860,t:1528139698725};\\\", \\\"{x:1351,y:855,t:1528139698742};\\\", \\\"{x:1351,y:848,t:1528139698759};\\\", \\\"{x:1351,y:841,t:1528139698775};\\\", \\\"{x:1351,y:833,t:1528139698792};\\\", \\\"{x:1353,y:820,t:1528139698809};\\\", \\\"{x:1354,y:815,t:1528139698825};\\\", \\\"{x:1354,y:807,t:1528139698844};\\\", \\\"{x:1352,y:795,t:1528139698857};\\\", \\\"{x:1352,y:795,t:1528139698861};\\\", \\\"{x:1352,y:793,t:1528139698878};\\\", \\\"{x:1352,y:791,t:1528139698894};\\\", \\\"{x:1351,y:787,t:1528139699069};\\\", \\\"{x:1347,y:780,t:1528139699082};\\\", \\\"{x:1342,y:770,t:1528139699101};\\\", \\\"{x:1338,y:761,t:1528139699115};\\\", \\\"{x:1337,y:760,t:1528139699132};\\\", \\\"{x:1341,y:757,t:1528139701252};\\\", \\\"{x:1354,y:752,t:1528139701270};\\\", \\\"{x:1358,y:749,t:1528139701287};\\\", \\\"{x:1360,y:749,t:1528139701303};\\\", \\\"{x:1358,y:749,t:1528139704005};\\\", \\\"{x:1351,y:752,t:1528139704013};\\\", \\\"{x:1347,y:756,t:1528139704027};\\\", \\\"{x:1336,y:764,t:1528139704044};\\\", \\\"{x:1334,y:766,t:1528139704060};\\\", \\\"{x:1335,y:766,t:1528139704285};\\\", \\\"{x:1337,y:765,t:1528139704293};\\\", \\\"{x:1341,y:764,t:1528139704310};\\\", \\\"{x:1342,y:764,t:1528139709086};\\\", \\\"{x:1343,y:752,t:1528139711836};\\\", \\\"{x:1342,y:685,t:1528139711844};\\\", \\\"{x:1338,y:621,t:1528139711860};\\\", \\\"{x:1338,y:620,t:1528139711877};\\\", \\\"{x:1338,y:642,t:1528139712252};\\\", \\\"{x:1335,y:680,t:1528139712260};\\\", \\\"{x:1333,y:722,t:1528139712275};\\\", \\\"{x:1334,y:781,t:1528139712292};\\\", \\\"{x:1336,y:798,t:1528139712308};\\\", \\\"{x:1336,y:801,t:1528139712325};\\\", \\\"{x:1336,y:803,t:1528139712342};\\\", \\\"{x:1337,y:802,t:1528139712360};\\\", \\\"{x:1337,y:793,t:1528139712442};\\\", \\\"{x:1338,y:791,t:1528139712638};\\\", \\\"{x:1339,y:791,t:1528139712909};\\\", \\\"{x:1339,y:789,t:1528139712927};\\\", \\\"{x:1338,y:778,t:1528139713494};\\\", \\\"{x:1321,y:748,t:1528139713510};\\\", \\\"{x:1303,y:717,t:1528139713527};\\\", \\\"{x:1292,y:704,t:1528139713543};\\\", \\\"{x:1287,y:699,t:1528139713560};\\\", \\\"{x:1285,y:695,t:1528139713577};\\\", \\\"{x:1283,y:689,t:1528139713594};\\\", \\\"{x:1280,y:677,t:1528139713610};\\\", \\\"{x:1279,y:662,t:1528139713627};\\\", \\\"{x:1277,y:658,t:1528139713643};\\\", \\\"{x:1277,y:655,t:1528139713677};\\\", \\\"{x:1277,y:649,t:1528139713693};\\\", \\\"{x:1277,y:647,t:1528139713717};\\\", \\\"{x:1277,y:645,t:1528139713726};\\\", \\\"{x:1277,y:637,t:1528139713743};\\\", \\\"{x:1282,y:606,t:1528139713760};\\\", \\\"{x:1283,y:576,t:1528139713777};\\\", \\\"{x:1284,y:562,t:1528139713794};\\\", \\\"{x:1287,y:542,t:1528139713812};\\\", \\\"{x:1287,y:532,t:1528139713826};\\\", \\\"{x:1287,y:531,t:1528139713844};\\\", \\\"{x:1288,y:530,t:1528139713860};\\\", \\\"{x:1288,y:533,t:1528139713973};\\\", \\\"{x:1288,y:540,t:1528139713981};\\\", \\\"{x:1288,y:545,t:1528139713994};\\\", \\\"{x:1288,y:552,t:1528139714010};\\\", \\\"{x:1288,y:558,t:1528139714026};\\\", \\\"{x:1287,y:560,t:1528139714043};\\\", \\\"{x:1287,y:563,t:1528139714061};\\\", \\\"{x:1287,y:565,t:1528139714078};\\\", \\\"{x:1287,y:566,t:1528139714093};\\\", \\\"{x:1287,y:567,t:1528139714117};\\\", \\\"{x:1283,y:569,t:1528139721997};\\\", \\\"{x:1223,y:572,t:1528139722005};\\\", \\\"{x:1123,y:568,t:1528139722016};\\\", \\\"{x:1024,y:557,t:1528139722033};\\\", \\\"{x:1022,y:557,t:1528139722285};\\\", \\\"{x:970,y:566,t:1528139722300};\\\", \\\"{x:876,y:566,t:1528139722318};\\\", \\\"{x:779,y:555,t:1528139722333};\\\", \\\"{x:677,y:541,t:1528139722350};\\\", \\\"{x:555,y:525,t:1528139722366};\\\", \\\"{x:445,y:517,t:1528139722384};\\\", \\\"{x:376,y:506,t:1528139722400};\\\", \\\"{x:355,y:506,t:1528139722416};\\\", \\\"{x:340,y:506,t:1528139722433};\\\", \\\"{x:335,y:508,t:1528139722450};\\\", \\\"{x:334,y:509,t:1528139722467};\\\", \\\"{x:331,y:509,t:1528139722483};\\\", \\\"{x:320,y:512,t:1528139722499};\\\", \\\"{x:314,y:512,t:1528139722517};\\\", \\\"{x:310,y:511,t:1528139722534};\\\", \\\"{x:308,y:511,t:1528139722551};\\\", \\\"{x:306,y:511,t:1528139722700};\\\", \\\"{x:298,y:511,t:1528139722718};\\\", \\\"{x:284,y:518,t:1528139722734};\\\", \\\"{x:272,y:519,t:1528139722750};\\\", \\\"{x:271,y:519,t:1528139722767};\\\", \\\"{x:271,y:517,t:1528139722797};\\\", \\\"{x:272,y:514,t:1528139722805};\\\", \\\"{x:278,y:514,t:1528139722818};\\\", \\\"{x:300,y:509,t:1528139722834};\\\", \\\"{x:325,y:502,t:1528139722851};\\\", \\\"{x:388,y:494,t:1528139722868};\\\", \\\"{x:539,y:488,t:1528139722884};\\\", \\\"{x:653,y:488,t:1528139722900};\\\", \\\"{x:758,y:488,t:1528139722918};\\\", \\\"{x:826,y:492,t:1528139722933};\\\", \\\"{x:848,y:495,t:1528139722951};\\\", \\\"{x:850,y:495,t:1528139722967};\\\", \\\"{x:847,y:495,t:1528139723004};\\\", \\\"{x:845,y:495,t:1528139723017};\\\", \\\"{x:837,y:495,t:1528139723035};\\\", \\\"{x:822,y:495,t:1528139723051};\\\", \\\"{x:812,y:491,t:1528139723067};\\\", \\\"{x:790,y:491,t:1528139723084};\\\", \\\"{x:774,y:489,t:1528139723101};\\\", \\\"{x:756,y:486,t:1528139723118};\\\", \\\"{x:741,y:485,t:1528139723134};\\\", \\\"{x:730,y:485,t:1528139723150};\\\", \\\"{x:725,y:485,t:1528139723167};\\\", \\\"{x:724,y:485,t:1528139723185};\\\", \\\"{x:723,y:485,t:1528139723201};\\\", \\\"{x:721,y:485,t:1528139723228};\\\", \\\"{x:716,y:485,t:1528139723245};\\\", \\\"{x:711,y:485,t:1528139723252};\\\", \\\"{x:707,y:485,t:1528139723267};\\\", \\\"{x:692,y:484,t:1528139723285};\\\", \\\"{x:680,y:484,t:1528139723301};\\\", \\\"{x:671,y:484,t:1528139723317};\\\", \\\"{x:665,y:486,t:1528139723335};\\\", \\\"{x:663,y:487,t:1528139723351};\\\", \\\"{x:662,y:488,t:1528139723556};\\\", \\\"{x:659,y:488,t:1528139723572};\\\", \\\"{x:659,y:489,t:1528139723685};\\\", \\\"{x:660,y:489,t:1528139723765};\\\", \\\"{x:662,y:489,t:1528139723773};\\\", \\\"{x:656,y:495,t:1528139723973};\\\", \\\"{x:650,y:498,t:1528139723985};\\\", \\\"{x:649,y:498,t:1528139724002};\\\", \\\"{x:644,y:502,t:1528139724019};\\\", \\\"{x:643,y:502,t:1528139724293};\\\", \\\"{x:643,y:502,t:1528139724294};\\\", \\\"{x:641,y:502,t:1528139724364};\\\", \\\"{x:640,y:502,t:1528139724372};\\\", \\\"{x:639,y:502,t:1528139724385};\\\", \\\"{x:637,y:502,t:1528139724401};\\\", \\\"{x:634,y:502,t:1528139724418};\\\", \\\"{x:632,y:503,t:1528139724435};\\\", \\\"{x:620,y:507,t:1528139724452};\\\", \\\"{x:593,y:517,t:1528139724469};\\\", \\\"{x:580,y:521,t:1528139724485};\\\", \\\"{x:563,y:522,t:1528139724502};\\\", \\\"{x:553,y:522,t:1528139724519};\\\", \\\"{x:551,y:522,t:1528139724536};\\\", \\\"{x:552,y:522,t:1528139724661};\\\", \\\"{x:555,y:521,t:1528139724668};\\\", \\\"{x:558,y:520,t:1528139724686};\\\", \\\"{x:566,y:516,t:1528139724704};\\\", \\\"{x:579,y:513,t:1528139724718};\\\", \\\"{x:593,y:510,t:1528139724735};\\\", \\\"{x:602,y:508,t:1528139724753};\\\", \\\"{x:605,y:508,t:1528139724769};\\\", \\\"{x:607,y:507,t:1528139724785};\\\", \\\"{x:611,y:506,t:1528139724820};\\\", \\\"{x:614,y:506,t:1528139724835};\\\", \\\"{x:625,y:504,t:1528139724852};\\\", \\\"{x:628,y:504,t:1528139724869};\\\", \\\"{x:629,y:504,t:1528139725060};\\\", \\\"{x:629,y:504,t:1528139725065};\\\", \\\"{x:631,y:504,t:1528139725172};\\\", \\\"{x:631,y:505,t:1528139725188};\\\", \\\"{x:630,y:506,t:1528139725202};\\\", \\\"{x:627,y:513,t:1528139725220};\\\", \\\"{x:627,y:520,t:1528139725236};\\\", \\\"{x:627,y:530,t:1528139725253};\\\", \\\"{x:627,y:533,t:1528139725269};\\\", \\\"{x:627,y:534,t:1528139725285};\\\", \\\"{x:627,y:537,t:1528139725303};\\\", \\\"{x:627,y:540,t:1528139725319};\\\", \\\"{x:626,y:545,t:1528139725335};\\\", \\\"{x:625,y:549,t:1528139725352};\\\", \\\"{x:623,y:549,t:1528139725388};\\\", \\\"{x:621,y:549,t:1528139725404};\\\", \\\"{x:620,y:549,t:1528139725420};\\\", \\\"{x:619,y:550,t:1528139725541};\\\", \\\"{x:619,y:551,t:1528139725557};\\\", \\\"{x:616,y:556,t:1528139725598};\\\", \\\"{x:615,y:558,t:1528139725605};\\\", \\\"{x:615,y:559,t:1528139725619};\\\", \\\"{x:615,y:561,t:1528139725636};\\\", \\\"{x:616,y:562,t:1528139725660};\\\", \\\"{x:618,y:565,t:1528139725669};\\\", \\\"{x:618,y:568,t:1528139725687};\\\", \\\"{x:618,y:570,t:1528139725724};\\\", \\\"{x:616,y:581,t:1528139725736};\\\", \\\"{x:611,y:595,t:1528139725753};\\\", \\\"{x:610,y:596,t:1528139725769};\\\", \\\"{x:610,y:598,t:1528139725786};\\\", \\\"{x:610,y:600,t:1528139725804};\\\", \\\"{x:610,y:602,t:1528139726014};\\\", \\\"{x:603,y:615,t:1528139726069};\\\", \\\"{x:589,y:633,t:1528139726088};\\\", \\\"{x:572,y:643,t:1528139726104};\\\", \\\"{x:555,y:657,t:1528139726120};\\\", \\\"{x:541,y:675,t:1528139726136};\\\", \\\"{x:537,y:681,t:1528139726153};\\\", \\\"{x:530,y:687,t:1528139726169};\\\", \\\"{x:523,y:695,t:1528139726186};\\\", \\\"{x:522,y:695,t:1528139726204};\\\", \\\"{x:518,y:695,t:1528139726220};\\\", \\\"{x:515,y:695,t:1528139726237};\\\", \\\"{x:513,y:700,t:1528139726253};\\\", \\\"{x:510,y:703,t:1528139726270};\\\", \\\"{x:509,y:706,t:1528139726287};\\\", \\\"{x:502,y:718,t:1528139726304};\\\", \\\"{x:496,y:726,t:1528139726321};\\\", \\\"{x:492,y:734,t:1528139726336};\\\", \\\"{x:491,y:736,t:1528139726354};\\\", \\\"{x:491,y:737,t:1528139726388};\\\", \\\"{x:490,y:738,t:1528139726413};\\\", \\\"{x:489,y:739,t:1528139726421};\\\", \\\"{x:488,y:739,t:1528139726652};\\\", \\\"{x:488,y:740,t:1528139726860};\\\", \\\"{x:488,y:734,t:1528139727284};\\\", \\\"{x:492,y:725,t:1528139727291};\\\", \\\"{x:498,y:715,t:1528139727304};\\\", \\\"{x:506,y:702,t:1528139727321};\\\", \\\"{x:513,y:691,t:1528139727337};\\\", \\\"{x:518,y:686,t:1528139727355};\\\", \\\"{x:526,y:677,t:1528139727370};\\\", \\\"{x:541,y:665,t:1528139727388};\\\", \\\"{x:570,y:640,t:1528139727404};\\\", \\\"{x:593,y:621,t:1528139727420};\\\", \\\"{x:607,y:609,t:1528139727438};\\\", \\\"{x:609,y:607,t:1528139727455};\\\", \\\"{x:610,y:606,t:1528139727470};\\\", \\\"{x:612,y:603,t:1528139727487};\\\", \\\"{x:614,y:600,t:1528139727504};\\\", \\\"{x:618,y:596,t:1528139727520};\\\", \\\"{x:619,y:593,t:1528139727538};\\\", \\\"{x:622,y:590,t:1528139727555};\\\", \\\"{x:623,y:589,t:1528139727571};\\\" ] }, { \\\"rt\\\": 12219, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 340252, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"ZEPVG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:624,y:589,t:1528139729077};\\\", \\\"{x:625,y:588,t:1528139729102};\\\", \\\"{x:626,y:582,t:1528139729108};\\\", \\\"{x:630,y:571,t:1528139729123};\\\", \\\"{x:631,y:564,t:1528139729139};\\\", \\\"{x:631,y:561,t:1528139729156};\\\", \\\"{x:631,y:560,t:1528139729180};\\\", \\\"{x:631,y:559,t:1528139729196};\\\", \\\"{x:631,y:557,t:1528139729206};\\\", \\\"{x:631,y:556,t:1528139729222};\\\", \\\"{x:630,y:554,t:1528139729239};\\\", \\\"{x:630,y:553,t:1528139729255};\\\", \\\"{x:629,y:552,t:1528139729272};\\\", \\\"{x:629,y:551,t:1528139729290};\\\", \\\"{x:629,y:550,t:1528139735814};\\\", \\\"{x:554,y:520,t:1528139735830};\\\", \\\"{x:554,y:518,t:1528139736133};\\\", \\\"{x:552,y:519,t:1528139736145};\\\", \\\"{x:549,y:521,t:1528139736162};\\\", \\\"{x:546,y:522,t:1528139736309};\\\", \\\"{x:540,y:522,t:1528139736316};\\\", \\\"{x:536,y:522,t:1528139736328};\\\", \\\"{x:531,y:520,t:1528139736346};\\\", \\\"{x:528,y:519,t:1528139736362};\\\", \\\"{x:526,y:512,t:1528139736390};\\\", \\\"{x:499,y:500,t:1528139736396};\\\", \\\"{x:490,y:492,t:1528139736412};\\\", \\\"{x:416,y:479,t:1528139736428};\\\", \\\"{x:410,y:475,t:1528139736445};\\\", \\\"{x:390,y:467,t:1528139736462};\\\", \\\"{x:382,y:466,t:1528139736478};\\\", \\\"{x:379,y:466,t:1528139736495};\\\", \\\"{x:378,y:466,t:1528139736511};\\\", \\\"{x:375,y:467,t:1528139736572};\\\", \\\"{x:375,y:469,t:1528139736588};\\\", \\\"{x:375,y:472,t:1528139736596};\\\", \\\"{x:368,y:483,t:1528139736612};\\\", \\\"{x:358,y:491,t:1528139736629};\\\", \\\"{x:342,y:501,t:1528139736645};\\\", \\\"{x:333,y:506,t:1528139736662};\\\", \\\"{x:332,y:506,t:1528139736678};\\\", \\\"{x:330,y:508,t:1528139736695};\\\", \\\"{x:329,y:508,t:1528139736885};\\\", \\\"{x:311,y:507,t:1528139736896};\\\", \\\"{x:221,y:492,t:1528139736915};\\\", \\\"{x:147,y:486,t:1528139736929};\\\", \\\"{x:130,y:486,t:1528139736946};\\\", \\\"{x:122,y:484,t:1528139736962};\\\", \\\"{x:120,y:484,t:1528139736979};\\\", \\\"{x:125,y:485,t:1528139737381};\\\", \\\"{x:156,y:492,t:1528139737397};\\\", \\\"{x:195,y:505,t:1528139737415};\\\", \\\"{x:228,y:513,t:1528139737430};\\\", \\\"{x:241,y:517,t:1528139737445};\\\", \\\"{x:246,y:518,t:1528139737463};\\\", \\\"{x:241,y:519,t:1528139737588};\\\", \\\"{x:240,y:519,t:1528139737596};\\\", \\\"{x:240,y:520,t:1528139737660};\\\", \\\"{x:233,y:520,t:1528139737973};\\\", \\\"{x:230,y:520,t:1528139737980};\\\", \\\"{x:216,y:517,t:1528139737998};\\\", \\\"{x:196,y:510,t:1528139738013};\\\", \\\"{x:188,y:508,t:1528139738030};\\\", \\\"{x:180,y:507,t:1528139738047};\\\", \\\"{x:179,y:507,t:1528139738064};\\\", \\\"{x:184,y:507,t:1528139738339};\\\", \\\"{x:208,y:508,t:1528139738348};\\\", \\\"{x:250,y:513,t:1528139738363};\\\", \\\"{x:413,y:554,t:1528139738380};\\\", \\\"{x:542,y:588,t:1528139738397};\\\", \\\"{x:609,y:621,t:1528139738414};\\\", \\\"{x:627,y:632,t:1528139738431};\\\", \\\"{x:629,y:632,t:1528139738901};\\\", \\\"{x:629,y:633,t:1528139738914};\\\", \\\"{x:629,y:634,t:1528139738930};\\\", \\\"{x:630,y:634,t:1528139738947};\\\", \\\"{x:628,y:642,t:1528139739005};\\\", \\\"{x:607,y:673,t:1528139739014};\\\", \\\"{x:606,y:678,t:1528139739030};\\\", \\\"{x:606,y:679,t:1528139739047};\\\", \\\"{x:606,y:681,t:1528139739268};\\\", \\\"{x:600,y:681,t:1528139739284};\\\", \\\"{x:592,y:684,t:1528139739298};\\\", \\\"{x:581,y:692,t:1528139739314};\\\", \\\"{x:573,y:696,t:1528139739331};\\\", \\\"{x:569,y:700,t:1528139739347};\\\", \\\"{x:566,y:701,t:1528139739372};\\\", \\\"{x:563,y:702,t:1528139739381};\\\", \\\"{x:550,y:710,t:1528139739397};\\\", \\\"{x:545,y:714,t:1528139739414};\\\", \\\"{x:539,y:719,t:1528139739431};\\\", \\\"{x:537,y:719,t:1528139739447};\\\", \\\"{x:535,y:720,t:1528139739655};\\\", \\\"{x:535,y:721,t:1528139739665};\\\", \\\"{x:535,y:722,t:1528139739732};\\\", \\\"{x:534,y:726,t:1528139739748};\\\", \\\"{x:534,y:729,t:1528139739761};\\\", \\\"{x:534,y:731,t:1528139739777};\\\", \\\"{x:533,y:733,t:1528139739794};\\\", \\\"{x:532,y:733,t:1528139740397};\\\", \\\"{x:582,y:674,t:1528139740404};\\\", \\\"{x:674,y:601,t:1528139740415};\\\", \\\"{x:836,y:501,t:1528139740432};\\\", \\\"{x:937,y:441,t:1528139740448};\\\", \\\"{x:951,y:434,t:1528139740466};\\\", \\\"{x:952,y:434,t:1528139740482};\\\", \\\"{x:933,y:446,t:1528139740498};\\\", \\\"{x:884,y:467,t:1528139740515};\\\", \\\"{x:834,y:484,t:1528139740532};\\\", \\\"{x:833,y:484,t:1528139740548};\\\", \\\"{x:833,y:485,t:1528139740661};\\\", \\\"{x:833,y:484,t:1528139740796};\\\", \\\"{x:833,y:479,t:1528139740804};\\\", \\\"{x:833,y:477,t:1528139740815};\\\", \\\"{x:833,y:474,t:1528139740833};\\\", \\\"{x:833,y:468,t:1528139740849};\\\", \\\"{x:833,y:467,t:1528139740866};\\\", \\\"{x:833,y:466,t:1528139740916};\\\" ] }, { \\\"rt\\\": 24728, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 366185, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"ZEPVG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 3, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:833,y:465,t:1528139761191};\\\", \\\"{x:832,y:465,t:1528139761584};\\\", \\\"{x:818,y:476,t:1528139761592};\\\", \\\"{x:798,y:493,t:1528139761604};\\\", \\\"{x:775,y:520,t:1528139761618};\\\", \\\"{x:770,y:531,t:1528139761636};\\\", \\\"{x:769,y:531,t:1528139761718};\\\", \\\"{x:764,y:529,t:1528139761736};\\\", \\\"{x:763,y:529,t:1528139761752};\\\", \\\"{x:763,y:527,t:1528139761774};\\\", \\\"{x:763,y:525,t:1528139761791};\\\", \\\"{x:754,y:525,t:1528139761903};\\\", \\\"{x:733,y:535,t:1528139761919};\\\", \\\"{x:731,y:535,t:1528139761936};\\\", \\\"{x:728,y:535,t:1528139761952};\\\", \\\"{x:728,y:537,t:1528139762207};\\\", \\\"{x:724,y:540,t:1528139762219};\\\", \\\"{x:717,y:547,t:1528139762238};\\\", \\\"{x:712,y:551,t:1528139762246};\\\", \\\"{x:710,y:552,t:1528139762269};\\\", \\\"{x:710,y:552,t:1528139762367};\\\", \\\"{x:713,y:550,t:1528139762406};\\\", \\\"{x:715,y:550,t:1528139762420};\\\", \\\"{x:710,y:551,t:1528139762615};\\\", \\\"{x:706,y:552,t:1528139762623};\\\", \\\"{x:704,y:552,t:1528139762637};\\\", \\\"{x:700,y:554,t:1528139762654};\\\", \\\"{x:698,y:556,t:1528139762672};\\\", \\\"{x:686,y:563,t:1528139762687};\\\", \\\"{x:676,y:568,t:1528139762703};\\\", \\\"{x:673,y:572,t:1528139762719};\\\", \\\"{x:669,y:574,t:1528139762735};\\\", \\\"{x:666,y:574,t:1528139762753};\\\", \\\"{x:665,y:575,t:1528139762853};\\\", \\\"{x:663,y:576,t:1528139762870};\\\", \\\"{x:663,y:576,t:1528139762961};\\\", \\\"{x:659,y:577,t:1528139763071};\\\", \\\"{x:656,y:579,t:1528139763087};\\\", \\\"{x:653,y:580,t:1528139763103};\\\", \\\"{x:653,y:581,t:1528139763120};\\\", \\\"{x:652,y:583,t:1528139763271};\\\", \\\"{x:647,y:587,t:1528139763287};\\\", \\\"{x:647,y:586,t:1528139763342};\\\", \\\"{x:647,y:581,t:1528139763353};\\\", \\\"{x:647,y:578,t:1528139763369};\\\", \\\"{x:644,y:578,t:1528139763664};\\\", \\\"{x:642,y:580,t:1528139763672};\\\", \\\"{x:630,y:582,t:1528139763687};\\\", \\\"{x:624,y:582,t:1528139763704};\\\", \\\"{x:621,y:582,t:1528139763721};\\\", \\\"{x:617,y:583,t:1528139763738};\\\", \\\"{x:613,y:583,t:1528139763753};\\\", \\\"{x:610,y:583,t:1528139763771};\\\", \\\"{x:603,y:583,t:1528139763788};\\\", \\\"{x:589,y:583,t:1528139763804};\\\", \\\"{x:586,y:583,t:1528139763821};\\\", \\\"{x:585,y:583,t:1528139763839};\\\", \\\"{x:585,y:581,t:1528139763999};\\\", \\\"{x:585,y:579,t:1528139764007};\\\", \\\"{x:590,y:578,t:1528139764015};\\\", \\\"{x:590,y:578,t:1528139764021};\\\", \\\"{x:601,y:574,t:1528139764039};\\\", \\\"{x:613,y:569,t:1528139764054};\\\", \\\"{x:619,y:568,t:1528139764070};\\\", \\\"{x:618,y:568,t:1528139764334};\\\", \\\"{x:615,y:569,t:1528139764342};\\\", \\\"{x:615,y:570,t:1528139764354};\\\", \\\"{x:614,y:570,t:1528139764371};\\\", \\\"{x:614,y:571,t:1528139764388};\\\", \\\"{x:614,y:573,t:1528139764494};\\\", \\\"{x:613,y:577,t:1528139764504};\\\", \\\"{x:611,y:582,t:1528139764521};\\\", \\\"{x:610,y:588,t:1528139764538};\\\", \\\"{x:610,y:593,t:1528139764557};\\\", \\\"{x:606,y:600,t:1528139764571};\\\", \\\"{x:603,y:608,t:1528139764589};\\\", \\\"{x:603,y:615,t:1528139764604};\\\", \\\"{x:603,y:617,t:1528139764621};\\\", \\\"{x:603,y:618,t:1528139764662};\\\", \\\"{x:600,y:621,t:1528139764808};\\\", \\\"{x:595,y:625,t:1528139764822};\\\", \\\"{x:593,y:630,t:1528139764839};\\\", \\\"{x:593,y:632,t:1528139764855};\\\", \\\"{x:591,y:632,t:1528139764879};\\\", \\\"{x:589,y:632,t:1528139764888};\\\", \\\"{x:590,y:632,t:1528139765168};\\\", \\\"{x:591,y:632,t:1528139765176};\\\", \\\"{x:586,y:636,t:1528139765223};\\\", \\\"{x:579,y:643,t:1528139765239};\\\", \\\"{x:567,y:653,t:1528139765255};\\\", \\\"{x:551,y:670,t:1528139765273};\\\", \\\"{x:536,y:693,t:1528139765289};\\\", \\\"{x:511,y:717,t:1528139765305};\\\", \\\"{x:482,y:739,t:1528139765325};\\\", \\\"{x:468,y:748,t:1528139765338};\\\", \\\"{x:460,y:754,t:1528139765354};\\\", \\\"{x:452,y:758,t:1528139765372};\\\", \\\"{x:436,y:771,t:1528139765389};\\\", \\\"{x:419,y:783,t:1528139765405};\\\", \\\"{x:414,y:787,t:1528139765422};\\\", \\\"{x:411,y:788,t:1528139765438};\\\", \\\"{x:411,y:791,t:1528139765487};\\\", \\\"{x:411,y:789,t:1528139765567};\\\", \\\"{x:411,y:786,t:1528139765575};\\\", \\\"{x:417,y:780,t:1528139765590};\\\", \\\"{x:428,y:771,t:1528139765606};\\\", \\\"{x:445,y:758,t:1528139765623};\\\", \\\"{x:455,y:751,t:1528139765640};\\\", \\\"{x:458,y:747,t:1528139765655};\\\", \\\"{x:458,y:746,t:1528139765672};\\\", \\\"{x:459,y:745,t:1528139765689};\\\", \\\"{x:459,y:744,t:1528139765718};\\\", \\\"{x:460,y:744,t:1528139766022};\\\", \\\"{x:461,y:742,t:1528139766039};\\\", \\\"{x:461,y:738,t:1528139766239};\\\", \\\"{x:461,y:737,t:1528139766256};\\\", \\\"{x:461,y:736,t:1528139766295};\\\", \\\"{x:464,y:728,t:1528139766351};\\\", \\\"{x:466,y:720,t:1528139766358};\\\", \\\"{x:468,y:714,t:1528139766372};\\\", \\\"{x:471,y:707,t:1528139766389};\\\", \\\"{x:471,y:705,t:1528139766406};\\\", \\\"{x:471,y:704,t:1528139766430};\\\" ] }, { \\\"rt\\\": 12559, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 380077, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"ZEPVG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 3, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:471,y:703,t:1528139770608};\\\", \\\"{x:461,y:693,t:1528139770614};\\\", \\\"{x:432,y:670,t:1528139770627};\\\", \\\"{x:369,y:632,t:1528139770643};\\\", \\\"{x:308,y:595,t:1528139770659};\\\", \\\"{x:260,y:569,t:1528139770677};\\\", \\\"{x:228,y:544,t:1528139770693};\\\", \\\"{x:219,y:535,t:1528139770709};\\\", \\\"{x:221,y:525,t:1528139770726};\\\", \\\"{x:222,y:525,t:1528139770870};\\\", \\\"{x:224,y:524,t:1528139770879};\\\", \\\"{x:229,y:524,t:1528139770893};\\\", \\\"{x:237,y:524,t:1528139770909};\\\", \\\"{x:240,y:524,t:1528139771031};\\\", \\\"{x:241,y:524,t:1528139771044};\\\", \\\"{x:247,y:524,t:1528139771061};\\\", \\\"{x:252,y:524,t:1528139771077};\\\", \\\"{x:255,y:524,t:1528139771094};\\\", \\\"{x:258,y:524,t:1528139771111};\\\", \\\"{x:259,y:525,t:1528139771200};\\\", \\\"{x:259,y:528,t:1528139771211};\\\", \\\"{x:259,y:543,t:1528139771226};\\\", \\\"{x:258,y:555,t:1528139771244};\\\", \\\"{x:246,y:570,t:1528139771261};\\\", \\\"{x:245,y:570,t:1528139771277};\\\", \\\"{x:246,y:570,t:1528139771560};\\\", \\\"{x:246,y:569,t:1528139774551};\\\", \\\"{x:246,y:566,t:1528139774563};\\\", \\\"{x:249,y:552,t:1528139774581};\\\", \\\"{x:259,y:534,t:1528139774596};\\\", \\\"{x:270,y:519,t:1528139774612};\\\", \\\"{x:290,y:496,t:1528139774629};\\\", \\\"{x:322,y:473,t:1528139774646};\\\", \\\"{x:352,y:451,t:1528139774662};\\\", \\\"{x:396,y:424,t:1528139774679};\\\", \\\"{x:424,y:405,t:1528139774696};\\\", \\\"{x:448,y:384,t:1528139774712};\\\", \\\"{x:462,y:371,t:1528139774729};\\\", \\\"{x:467,y:367,t:1528139774747};\\\", \\\"{x:468,y:366,t:1528139774762};\\\", \\\"{x:475,y:366,t:1528139774798};\\\", \\\"{x:490,y:379,t:1528139774814};\\\", \\\"{x:533,y:421,t:1528139774830};\\\", \\\"{x:604,y:485,t:1528139774846};\\\", \\\"{x:645,y:520,t:1528139774863};\\\", \\\"{x:666,y:545,t:1528139774881};\\\", \\\"{x:678,y:562,t:1528139774897};\\\", \\\"{x:682,y:570,t:1528139774914};\\\", \\\"{x:682,y:577,t:1528139774929};\\\", \\\"{x:682,y:583,t:1528139774946};\\\", \\\"{x:682,y:584,t:1528139774964};\\\", \\\"{x:685,y:574,t:1528139775063};\\\", \\\"{x:690,y:558,t:1528139775080};\\\", \\\"{x:697,y:543,t:1528139775097};\\\", \\\"{x:707,y:533,t:1528139775114};\\\", \\\"{x:719,y:524,t:1528139775130};\\\", \\\"{x:742,y:516,t:1528139775147};\\\", \\\"{x:765,y:511,t:1528139775164};\\\", \\\"{x:787,y:511,t:1528139775180};\\\", \\\"{x:796,y:511,t:1528139775197};\\\", \\\"{x:805,y:511,t:1528139775214};\\\", \\\"{x:806,y:512,t:1528139775262};\\\", \\\"{x:806,y:515,t:1528139775279};\\\", \\\"{x:806,y:517,t:1528139775287};\\\", \\\"{x:807,y:518,t:1528139775298};\\\", \\\"{x:807,y:520,t:1528139775314};\\\", \\\"{x:809,y:517,t:1528139775521};\\\", \\\"{x:809,y:515,t:1528139775531};\\\", \\\"{x:810,y:510,t:1528139775548};\\\", \\\"{x:813,y:502,t:1528139775564};\\\", \\\"{x:817,y:496,t:1528139775580};\\\", \\\"{x:820,y:492,t:1528139775597};\\\", \\\"{x:821,y:491,t:1528139775734};\\\", \\\"{x:821,y:491,t:1528139775824};\\\", \\\"{x:821,y:497,t:1528139775895};\\\", \\\"{x:821,y:506,t:1528139775902};\\\", \\\"{x:821,y:519,t:1528139775916};\\\", \\\"{x:821,y:539,t:1528139775931};\\\", \\\"{x:821,y:548,t:1528139775947};\\\", \\\"{x:820,y:551,t:1528139775963};\\\", \\\"{x:817,y:556,t:1528139775981};\\\", \\\"{x:811,y:560,t:1528139775997};\\\", \\\"{x:800,y:564,t:1528139776014};\\\", \\\"{x:777,y:567,t:1528139776030};\\\", \\\"{x:737,y:564,t:1528139776048};\\\", \\\"{x:668,y:546,t:1528139776064};\\\", \\\"{x:570,y:529,t:1528139776081};\\\", \\\"{x:512,y:518,t:1528139776098};\\\", \\\"{x:492,y:511,t:1528139776114};\\\", \\\"{x:489,y:510,t:1528139776130};\\\", \\\"{x:488,y:510,t:1528139776148};\\\", \\\"{x:497,y:510,t:1528139776164};\\\", \\\"{x:528,y:511,t:1528139776181};\\\", \\\"{x:610,y:506,t:1528139776198};\\\", \\\"{x:684,y:497,t:1528139776214};\\\", \\\"{x:776,y:480,t:1528139776231};\\\", \\\"{x:794,y:476,t:1528139776247};\\\", \\\"{x:796,y:475,t:1528139776265};\\\", \\\"{x:799,y:476,t:1528139776344};\\\", \\\"{x:802,y:481,t:1528139776351};\\\", \\\"{x:806,y:485,t:1528139776365};\\\", \\\"{x:809,y:489,t:1528139776383};\\\", \\\"{x:810,y:489,t:1528139776398};\\\", \\\"{x:811,y:492,t:1528139776446};\\\", \\\"{x:814,y:494,t:1528139776454};\\\", \\\"{x:815,y:494,t:1528139776464};\\\", \\\"{x:819,y:496,t:1528139776480};\\\", \\\"{x:820,y:497,t:1528139776498};\\\", \\\"{x:820,y:498,t:1528139777118};\\\", \\\"{x:821,y:498,t:1528139777130};\\\", \\\"{x:828,y:503,t:1528139777148};\\\", \\\"{x:832,y:506,t:1528139777163};\\\", \\\"{x:833,y:506,t:1528139777182};\\\", \\\"{x:833,y:507,t:1528139777199};\\\", \\\"{x:825,y:509,t:1528139777535};\\\", \\\"{x:821,y:513,t:1528139777548};\\\", \\\"{x:799,y:518,t:1528139777566};\\\", \\\"{x:758,y:523,t:1528139777581};\\\", \\\"{x:741,y:524,t:1528139777599};\\\", \\\"{x:740,y:525,t:1528139777616};\\\", \\\"{x:733,y:528,t:1528139777631};\\\", \\\"{x:722,y:537,t:1528139777649};\\\", \\\"{x:710,y:544,t:1528139777666};\\\", \\\"{x:705,y:545,t:1528139777682};\\\", \\\"{x:705,y:546,t:1528139777699};\\\", \\\"{x:711,y:549,t:1528139778143};\\\", \\\"{x:714,y:549,t:1528139778150};\\\", \\\"{x:713,y:551,t:1528139778191};\\\", \\\"{x:707,y:551,t:1528139778199};\\\", \\\"{x:685,y:551,t:1528139778216};\\\", \\\"{x:649,y:548,t:1528139778233};\\\", \\\"{x:521,y:548,t:1528139778249};\\\", \\\"{x:367,y:528,t:1528139778268};\\\", \\\"{x:190,y:508,t:1528139778283};\\\", \\\"{x:19,y:484,t:1528139778300};\\\", \\\"{x:0,y:465,t:1528139778316};\\\", \\\"{x:0,y:451,t:1528139778333};\\\", \\\"{x:0,y:444,t:1528139778350};\\\", \\\"{x:0,y:443,t:1528139778365};\\\", \\\"{x:0,y:444,t:1528139778414};\\\", \\\"{x:0,y:445,t:1528139778423};\\\", \\\"{x:0,y:446,t:1528139778446};\\\", \\\"{x:0,y:448,t:1528139778454};\\\", \\\"{x:2,y:450,t:1528139778465};\\\", \\\"{x:14,y:456,t:1528139778483};\\\", \\\"{x:34,y:464,t:1528139778499};\\\", \\\"{x:53,y:471,t:1528139778515};\\\", \\\"{x:77,y:478,t:1528139778533};\\\", \\\"{x:95,y:487,t:1528139778550};\\\", \\\"{x:119,y:498,t:1528139778566};\\\", \\\"{x:135,y:507,t:1528139778582};\\\", \\\"{x:146,y:512,t:1528139778599};\\\", \\\"{x:148,y:513,t:1528139778616};\\\", \\\"{x:149,y:513,t:1528139778633};\\\", \\\"{x:150,y:515,t:1528139778650};\\\", \\\"{x:153,y:524,t:1528139778669};\\\", \\\"{x:154,y:530,t:1528139778683};\\\", \\\"{x:154,y:533,t:1528139778699};\\\", \\\"{x:154,y:534,t:1528139778717};\\\", \\\"{x:153,y:539,t:1528139778733};\\\", \\\"{x:151,y:542,t:1528139778749};\\\", \\\"{x:150,y:544,t:1528139778766};\\\", \\\"{x:149,y:546,t:1528139778782};\\\", \\\"{x:157,y:551,t:1528139779086};\\\", \\\"{x:177,y:556,t:1528139779100};\\\", \\\"{x:249,y:576,t:1528139779117};\\\", \\\"{x:355,y:608,t:1528139779134};\\\", \\\"{x:461,y:649,t:1528139779150};\\\", \\\"{x:588,y:726,t:1528139779166};\\\", \\\"{x:631,y:757,t:1528139779183};\\\", \\\"{x:642,y:772,t:1528139779199};\\\", \\\"{x:645,y:785,t:1528139779217};\\\", \\\"{x:645,y:800,t:1528139779232};\\\", \\\"{x:645,y:815,t:1528139779250};\\\", \\\"{x:641,y:835,t:1528139779267};\\\", \\\"{x:639,y:849,t:1528139779283};\\\", \\\"{x:634,y:862,t:1528139779300};\\\", \\\"{x:629,y:868,t:1528139779316};\\\", \\\"{x:627,y:870,t:1528139779333};\\\", \\\"{x:626,y:870,t:1528139779350};\\\", \\\"{x:626,y:871,t:1528139779366};\\\", \\\"{x:625,y:871,t:1528139779383};\\\", \\\"{x:602,y:853,t:1528139779400};\\\", \\\"{x:573,y:825,t:1528139779416};\\\", \\\"{x:544,y:804,t:1528139779433};\\\", \\\"{x:509,y:778,t:1528139779449};\\\", \\\"{x:495,y:762,t:1528139779466};\\\", \\\"{x:495,y:756,t:1528139779484};\\\", \\\"{x:495,y:749,t:1528139779501};\\\", \\\"{x:495,y:738,t:1528139779516};\\\", \\\"{x:495,y:736,t:1528139779534};\\\", \\\"{x:495,y:735,t:1528139779558};\\\", \\\"{x:495,y:734,t:1528139779701};\\\", \\\"{x:495,y:734,t:1528139779848};\\\", \\\"{x:495,y:733,t:1528139779958};\\\", \\\"{x:495,y:731,t:1528139779968};\\\", \\\"{x:497,y:727,t:1528139779984};\\\", \\\"{x:497,y:726,t:1528139780214};\\\" ] }, { \\\"rt\\\": 4577, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 385959, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"ZEPVG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:497,y:725,t:1528139782176};\\\", \\\"{x:497,y:721,t:1528139783431};\\\", \\\"{x:497,y:708,t:1528139783443};\\\", \\\"{x:497,y:683,t:1528139783458};\\\", \\\"{x:497,y:664,t:1528139783476};\\\", \\\"{x:497,y:655,t:1528139783487};\\\", \\\"{x:497,y:647,t:1528139783504};\\\", \\\"{x:497,y:643,t:1528139783520};\\\", \\\"{x:497,y:641,t:1528139783537};\\\", \\\"{x:491,y:636,t:1528139783555};\\\", \\\"{x:472,y:629,t:1528139783570};\\\", \\\"{x:441,y:628,t:1528139783587};\\\", \\\"{x:398,y:628,t:1528139783604};\\\", \\\"{x:322,y:628,t:1528139783621};\\\", \\\"{x:272,y:628,t:1528139783637};\\\", \\\"{x:236,y:628,t:1528139783654};\\\", \\\"{x:235,y:628,t:1528139783670};\\\", \\\"{x:234,y:627,t:1528139783759};\\\", \\\"{x:231,y:624,t:1528139783771};\\\", \\\"{x:210,y:614,t:1528139783787};\\\", \\\"{x:187,y:602,t:1528139783804};\\\", \\\"{x:159,y:584,t:1528139783821};\\\", \\\"{x:129,y:569,t:1528139783837};\\\", \\\"{x:102,y:551,t:1528139783855};\\\", \\\"{x:102,y:543,t:1528139783870};\\\", \\\"{x:103,y:538,t:1528139783887};\\\", \\\"{x:106,y:535,t:1528139783903};\\\", \\\"{x:107,y:535,t:1528139783921};\\\", \\\"{x:110,y:531,t:1528139783937};\\\", \\\"{x:111,y:530,t:1528139783958};\\\", \\\"{x:112,y:530,t:1528139783998};\\\", \\\"{x:113,y:529,t:1528139784014};\\\", \\\"{x:115,y:527,t:1528139784030};\\\", \\\"{x:117,y:527,t:1528139784046};\\\", \\\"{x:120,y:526,t:1528139784054};\\\", \\\"{x:124,y:526,t:1528139784071};\\\", \\\"{x:127,y:524,t:1528139784087};\\\", \\\"{x:130,y:524,t:1528139784104};\\\", \\\"{x:132,y:524,t:1528139784121};\\\", \\\"{x:137,y:524,t:1528139784137};\\\", \\\"{x:143,y:528,t:1528139784154};\\\", \\\"{x:150,y:530,t:1528139784172};\\\", \\\"{x:152,y:532,t:1528139784188};\\\", \\\"{x:153,y:532,t:1528139784204};\\\", \\\"{x:155,y:534,t:1528139784454};\\\", \\\"{x:161,y:551,t:1528139784471};\\\", \\\"{x:178,y:569,t:1528139784488};\\\", \\\"{x:201,y:593,t:1528139784505};\\\", \\\"{x:241,y:620,t:1528139784522};\\\", \\\"{x:281,y:643,t:1528139784539};\\\", \\\"{x:319,y:673,t:1528139784554};\\\", \\\"{x:344,y:693,t:1528139784571};\\\", \\\"{x:364,y:712,t:1528139784588};\\\", \\\"{x:378,y:724,t:1528139784605};\\\", \\\"{x:386,y:734,t:1528139784621};\\\", \\\"{x:391,y:737,t:1528139784638};\\\", \\\"{x:393,y:742,t:1528139784654};\\\", \\\"{x:395,y:747,t:1528139784670};\\\", \\\"{x:400,y:757,t:1528139784688};\\\", \\\"{x:408,y:772,t:1528139784705};\\\", \\\"{x:421,y:785,t:1528139784721};\\\", \\\"{x:429,y:792,t:1528139784739};\\\", \\\"{x:441,y:794,t:1528139784755};\\\", \\\"{x:446,y:795,t:1528139784771};\\\", \\\"{x:449,y:795,t:1528139784788};\\\", \\\"{x:451,y:795,t:1528139784805};\\\", \\\"{x:452,y:795,t:1528139784821};\\\", \\\"{x:460,y:791,t:1528139784838};\\\", \\\"{x:469,y:783,t:1528139784855};\\\", \\\"{x:480,y:778,t:1528139784871};\\\", \\\"{x:489,y:772,t:1528139784888};\\\", \\\"{x:496,y:767,t:1528139784906};\\\", \\\"{x:497,y:763,t:1528139784921};\\\", \\\"{x:499,y:763,t:1528139784938};\\\", \\\"{x:499,y:761,t:1528139784991};\\\", \\\"{x:499,y:760,t:1528139785006};\\\", \\\"{x:500,y:760,t:1528139785022};\\\", \\\"{x:500,y:759,t:1528139785038};\\\", \\\"{x:501,y:758,t:1528139785064};\\\", \\\"{x:502,y:758,t:1528139785118};\\\", \\\"{x:502,y:758,t:1528139785174};\\\", \\\"{x:503,y:749,t:1528139785191};\\\", \\\"{x:503,y:741,t:1528139785205};\\\", \\\"{x:512,y:720,t:1528139785222};\\\", \\\"{x:515,y:712,t:1528139785239};\\\", \\\"{x:517,y:709,t:1528139785255};\\\", \\\"{x:517,y:711,t:1528139785471};\\\", \\\"{x:517,y:720,t:1528139785480};\\\", \\\"{x:517,y:726,t:1528139785490};\\\", \\\"{x:517,y:733,t:1528139785505};\\\", \\\"{x:517,y:734,t:1528139786143};\\\", \\\"{x:512,y:738,t:1528139786156};\\\", \\\"{x:508,y:741,t:1528139786172};\\\", \\\"{x:507,y:741,t:1528139786189};\\\" ] }, { \\\"rt\\\": 21285, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 408477, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"ZEPVG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:507,y:742,t:1528139796614};\\\", \\\"{x:516,y:745,t:1528139796630};\\\", \\\"{x:523,y:747,t:1528139796644};\\\", \\\"{x:540,y:751,t:1528139796661};\\\", \\\"{x:570,y:762,t:1528139796678};\\\", \\\"{x:616,y:775,t:1528139796694};\\\", \\\"{x:696,y:784,t:1528139796711};\\\", \\\"{x:767,y:790,t:1528139796731};\\\", \\\"{x:807,y:788,t:1528139796747};\\\", \\\"{x:840,y:793,t:1528139796765};\\\", \\\"{x:876,y:795,t:1528139796781};\\\", \\\"{x:967,y:819,t:1528139796797};\\\", \\\"{x:978,y:823,t:1528139796814};\\\", \\\"{x:977,y:823,t:1528139796831};\\\", \\\"{x:977,y:820,t:1528139797014};\\\", \\\"{x:1023,y:816,t:1528139797032};\\\", \\\"{x:1090,y:812,t:1528139797048};\\\", \\\"{x:1199,y:810,t:1528139797064};\\\", \\\"{x:1261,y:803,t:1528139797081};\\\", \\\"{x:1317,y:808,t:1528139797099};\\\", \\\"{x:1328,y:806,t:1528139797116};\\\", \\\"{x:1339,y:813,t:1528139797132};\\\", \\\"{x:1350,y:814,t:1528139797149};\\\", \\\"{x:1351,y:814,t:1528139797165};\\\", \\\"{x:1352,y:818,t:1528139797391};\\\", \\\"{x:1357,y:823,t:1528139797399};\\\", \\\"{x:1374,y:829,t:1528139797416};\\\", \\\"{x:1404,y:834,t:1528139797433};\\\", \\\"{x:1434,y:841,t:1528139797449};\\\", \\\"{x:1453,y:841,t:1528139797466};\\\", \\\"{x:1470,y:842,t:1528139797484};\\\", \\\"{x:1473,y:842,t:1528139797499};\\\", \\\"{x:1474,y:842,t:1528139797516};\\\", \\\"{x:1475,y:841,t:1528139798072};\\\", \\\"{x:1475,y:840,t:1528139798083};\\\", \\\"{x:1475,y:838,t:1528139798099};\\\", \\\"{x:1476,y:835,t:1528139798117};\\\", \\\"{x:1476,y:834,t:1528139798133};\\\", \\\"{x:1476,y:833,t:1528139798149};\\\", \\\"{x:1477,y:831,t:1528139798167};\\\", \\\"{x:1478,y:830,t:1528139798200};\\\", \\\"{x:1478,y:829,t:1528139798216};\\\", \\\"{x:1478,y:828,t:1528139798237};\\\", \\\"{x:1478,y:827,t:1528139798262};\\\", \\\"{x:1453,y:815,t:1528139803609};\\\", \\\"{x:1122,y:773,t:1528139803623};\\\", \\\"{x:777,y:704,t:1528139803640};\\\", \\\"{x:574,y:672,t:1528139803657};\\\", \\\"{x:576,y:673,t:1528139803887};\\\", \\\"{x:582,y:671,t:1528139803895};\\\", \\\"{x:590,y:668,t:1528139803907};\\\", \\\"{x:608,y:660,t:1528139803924};\\\", \\\"{x:629,y:654,t:1528139803940};\\\", \\\"{x:651,y:643,t:1528139803957};\\\", \\\"{x:688,y:625,t:1528139803976};\\\", \\\"{x:712,y:608,t:1528139803989};\\\", \\\"{x:739,y:591,t:1528139804008};\\\", \\\"{x:752,y:586,t:1528139804020};\\\", \\\"{x:778,y:577,t:1528139804036};\\\", \\\"{x:799,y:567,t:1528139804053};\\\", \\\"{x:805,y:562,t:1528139804071};\\\", \\\"{x:807,y:560,t:1528139804087};\\\", \\\"{x:809,y:556,t:1528139804134};\\\", \\\"{x:811,y:552,t:1528139804143};\\\", \\\"{x:814,y:547,t:1528139804157};\\\", \\\"{x:815,y:546,t:1528139804171};\\\", \\\"{x:820,y:537,t:1528139804188};\\\", \\\"{x:824,y:531,t:1528139804204};\\\", \\\"{x:827,y:526,t:1528139804221};\\\", \\\"{x:831,y:521,t:1528139804238};\\\", \\\"{x:833,y:516,t:1528139804254};\\\", \\\"{x:837,y:511,t:1528139804271};\\\", \\\"{x:839,y:509,t:1528139804286};\\\", \\\"{x:840,y:508,t:1528139804304};\\\", \\\"{x:848,y:508,t:1528139804646};\\\", \\\"{x:859,y:511,t:1528139804654};\\\", \\\"{x:866,y:513,t:1528139804671};\\\", \\\"{x:866,y:514,t:1528139804701};\\\", \\\"{x:861,y:519,t:1528139804710};\\\", \\\"{x:856,y:527,t:1528139804721};\\\", \\\"{x:804,y:565,t:1528139804738};\\\", \\\"{x:687,y:620,t:1528139804755};\\\", \\\"{x:531,y:653,t:1528139804771};\\\", \\\"{x:528,y:654,t:1528139804788};\\\", \\\"{x:527,y:654,t:1528139804830};\\\", \\\"{x:525,y:656,t:1528139804846};\\\", \\\"{x:525,y:657,t:1528139804878};\\\", \\\"{x:526,y:658,t:1528139804903};\\\", \\\"{x:531,y:659,t:1528139804910};\\\", \\\"{x:541,y:659,t:1528139804922};\\\", \\\"{x:553,y:659,t:1528139804938};\\\", \\\"{x:560,y:657,t:1528139804955};\\\", \\\"{x:600,y:647,t:1528139804972};\\\", \\\"{x:670,y:639,t:1528139804989};\\\", \\\"{x:773,y:619,t:1528139805007};\\\", \\\"{x:915,y:589,t:1528139805022};\\\", \\\"{x:985,y:567,t:1528139805039};\\\", \\\"{x:1013,y:551,t:1528139805055};\\\", \\\"{x:1014,y:549,t:1528139805071};\\\", \\\"{x:1014,y:548,t:1528139805110};\\\", \\\"{x:1014,y:547,t:1528139805121};\\\", \\\"{x:1013,y:546,t:1528139805138};\\\", \\\"{x:1012,y:546,t:1528139805155};\\\", \\\"{x:1009,y:544,t:1528139805172};\\\", \\\"{x:995,y:541,t:1528139805189};\\\", \\\"{x:975,y:538,t:1528139805206};\\\", \\\"{x:910,y:536,t:1528139805224};\\\", \\\"{x:813,y:536,t:1528139805237};\\\", \\\"{x:705,y:536,t:1528139805255};\\\", \\\"{x:600,y:536,t:1528139805272};\\\", \\\"{x:486,y:536,t:1528139805290};\\\", \\\"{x:386,y:536,t:1528139805305};\\\", \\\"{x:328,y:536,t:1528139805322};\\\", \\\"{x:305,y:545,t:1528139805338};\\\", \\\"{x:290,y:550,t:1528139805355};\\\", \\\"{x:286,y:553,t:1528139805372};\\\", \\\"{x:281,y:557,t:1528139805390};\\\", \\\"{x:278,y:561,t:1528139805405};\\\", \\\"{x:278,y:565,t:1528139805422};\\\", \\\"{x:279,y:567,t:1528139805439};\\\", \\\"{x:286,y:570,t:1528139805454};\\\", \\\"{x:304,y:575,t:1528139805471};\\\", \\\"{x:320,y:579,t:1528139805488};\\\", \\\"{x:341,y:584,t:1528139805505};\\\", \\\"{x:357,y:584,t:1528139805521};\\\", \\\"{x:377,y:586,t:1528139805539};\\\", \\\"{x:399,y:589,t:1528139805555};\\\", \\\"{x:420,y:589,t:1528139805571};\\\", \\\"{x:442,y:590,t:1528139805589};\\\", \\\"{x:459,y:590,t:1528139805605};\\\", \\\"{x:478,y:590,t:1528139805622};\\\", \\\"{x:484,y:590,t:1528139805639};\\\", \\\"{x:486,y:590,t:1528139805655};\\\", \\\"{x:488,y:590,t:1528139805672};\\\", \\\"{x:492,y:590,t:1528139805689};\\\", \\\"{x:501,y:589,t:1528139805707};\\\", \\\"{x:518,y:588,t:1528139805721};\\\", \\\"{x:540,y:587,t:1528139805739};\\\", \\\"{x:556,y:587,t:1528139805755};\\\", \\\"{x:574,y:587,t:1528139805772};\\\", \\\"{x:585,y:587,t:1528139805789};\\\", \\\"{x:592,y:587,t:1528139805805};\\\", \\\"{x:595,y:587,t:1528139805821};\\\", \\\"{x:595,y:588,t:1528139806150};\\\", \\\"{x:595,y:599,t:1528139806159};\\\", \\\"{x:594,y:618,t:1528139806172};\\\", \\\"{x:592,y:649,t:1528139806189};\\\", \\\"{x:592,y:669,t:1528139806205};\\\", \\\"{x:593,y:670,t:1528139806245};\\\", \\\"{x:594,y:670,t:1528139806262};\\\", \\\"{x:594,y:672,t:1528139806278};\\\", \\\"{x:594,y:673,t:1528139806289};\\\", \\\"{x:594,y:678,t:1528139806306};\\\", \\\"{x:594,y:680,t:1528139806324};\\\", \\\"{x:595,y:680,t:1528139806367};\\\", \\\"{x:595,y:681,t:1528139806374};\\\", \\\"{x:594,y:681,t:1528139806439};\\\", \\\"{x:592,y:681,t:1528139806456};\\\", \\\"{x:588,y:664,t:1528139806473};\\\", \\\"{x:584,y:654,t:1528139806489};\\\", \\\"{x:584,y:640,t:1528139806506};\\\", \\\"{x:587,y:628,t:1528139806524};\\\", \\\"{x:591,y:615,t:1528139806538};\\\", \\\"{x:597,y:608,t:1528139806556};\\\", \\\"{x:599,y:604,t:1528139806573};\\\", \\\"{x:601,y:601,t:1528139806590};\\\", \\\"{x:602,y:599,t:1528139806606};\\\", \\\"{x:603,y:597,t:1528139806623};\\\", \\\"{x:604,y:594,t:1528139806640};\\\", \\\"{x:606,y:590,t:1528139806657};\\\", \\\"{x:608,y:582,t:1528139806673};\\\", \\\"{x:610,y:576,t:1528139806689};\\\", \\\"{x:611,y:573,t:1528139806706};\\\", \\\"{x:612,y:570,t:1528139806725};\\\", \\\"{x:612,y:568,t:1528139806741};\\\", \\\"{x:612,y:567,t:1528139806758};\\\", \\\"{x:616,y:570,t:1528139806997};\\\", \\\"{x:619,y:576,t:1528139807006};\\\", \\\"{x:627,y:600,t:1528139807023};\\\", \\\"{x:636,y:624,t:1528139807040};\\\", \\\"{x:638,y:632,t:1528139807056};\\\", \\\"{x:638,y:637,t:1528139807073};\\\", \\\"{x:634,y:642,t:1528139807206};\\\", \\\"{x:631,y:644,t:1528139807223};\\\", \\\"{x:621,y:654,t:1528139807240};\\\", \\\"{x:618,y:655,t:1528139807257};\\\", \\\"{x:619,y:655,t:1528139807274};\\\", \\\"{x:614,y:655,t:1528139807302};\\\", \\\"{x:614,y:657,t:1528139807326};\\\", \\\"{x:614,y:658,t:1528139807551};\\\", \\\"{x:614,y:659,t:1528139807558};\\\", \\\"{x:612,y:662,t:1528139807583};\\\", \\\"{x:606,y:668,t:1528139807591};\\\", \\\"{x:586,y:684,t:1528139807608};\\\", \\\"{x:565,y:696,t:1528139807625};\\\", \\\"{x:546,y:707,t:1528139807641};\\\", \\\"{x:534,y:710,t:1528139807658};\\\", \\\"{x:531,y:710,t:1528139807674};\\\", \\\"{x:529,y:710,t:1528139807691};\\\", \\\"{x:528,y:710,t:1528139807886};\\\", \\\"{x:524,y:711,t:1528139807918};\\\", \\\"{x:521,y:716,t:1528139807927};\\\", \\\"{x:516,y:723,t:1528139807944};\\\", \\\"{x:513,y:728,t:1528139807957};\\\", \\\"{x:512,y:729,t:1528139807973};\\\", \\\"{x:512,y:730,t:1528139807991};\\\", \\\"{x:512,y:731,t:1528139808007};\\\", \\\"{x:511,y:736,t:1528139808024};\\\", \\\"{x:511,y:738,t:1528139808041};\\\", \\\"{x:510,y:741,t:1528139808057};\\\", \\\"{x:510,y:742,t:1528139808074};\\\", \\\"{x:512,y:742,t:1528139808638};\\\", \\\"{x:512,y:741,t:1528139808646};\\\", \\\"{x:514,y:740,t:1528139808662};\\\", \\\"{x:514,y:739,t:1528139808678};\\\", \\\"{x:514,y:738,t:1528139808691};\\\", \\\"{x:514,y:736,t:1528139808708};\\\", \\\"{x:514,y:734,t:1528139808724};\\\", \\\"{x:515,y:732,t:1528139808741};\\\", \\\"{x:517,y:729,t:1528139808758};\\\" ] }, { \\\"rt\\\": 20350, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 430106, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"ZEPVG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:518,y:729,t:1528139813415};\\\", \\\"{x:520,y:727,t:1528139813431};\\\", \\\"{x:520,y:726,t:1528139813462};\\\", \\\"{x:520,y:725,t:1528139813511};\\\", \\\"{x:520,y:724,t:1528139813518};\\\", \\\"{x:520,y:722,t:1528139813534};\\\", \\\"{x:520,y:721,t:1528139813566};\\\", \\\"{x:518,y:721,t:1528139823242};\\\", \\\"{x:517,y:721,t:1528139823250};\\\", \\\"{x:516,y:721,t:1528139823273};\\\", \\\"{x:514,y:721,t:1528139823288};\\\", \\\"{x:513,y:722,t:1528139823305};\\\", \\\"{x:513,y:723,t:1528139823317};\\\", \\\"{x:512,y:724,t:1528139823334};\\\", \\\"{x:508,y:726,t:1528139823350};\\\", \\\"{x:506,y:727,t:1528139823366};\\\", \\\"{x:505,y:729,t:1528139823384};\\\", \\\"{x:504,y:729,t:1528139823425};\\\", \\\"{x:503,y:729,t:1528139823602};\\\", \\\"{x:489,y:739,t:1528139823618};\\\", \\\"{x:483,y:755,t:1528139823635};\\\", \\\"{x:481,y:761,t:1528139823651};\\\", \\\"{x:476,y:770,t:1528139823667};\\\", \\\"{x:463,y:788,t:1528139823684};\\\", \\\"{x:446,y:812,t:1528139823707};\\\", \\\"{x:441,y:820,t:1528139823724};\\\", \\\"{x:429,y:828,t:1528139823740};\\\", \\\"{x:400,y:831,t:1528139823757};\\\", \\\"{x:333,y:831,t:1528139823773};\\\", \\\"{x:256,y:826,t:1528139823790};\\\", \\\"{x:241,y:819,t:1528139823807};\\\", \\\"{x:244,y:820,t:1528139823938};\\\", \\\"{x:257,y:812,t:1528139823946};\\\", \\\"{x:266,y:802,t:1528139823958};\\\", \\\"{x:284,y:784,t:1528139823975};\\\", \\\"{x:291,y:777,t:1528139823991};\\\", \\\"{x:292,y:773,t:1528139824007};\\\", \\\"{x:293,y:767,t:1528139824025};\\\", \\\"{x:293,y:760,t:1528139824042};\\\", \\\"{x:293,y:754,t:1528139824058};\\\", \\\"{x:293,y:746,t:1528139824074};\\\", \\\"{x:293,y:738,t:1528139824091};\\\", \\\"{x:293,y:730,t:1528139824107};\\\", \\\"{x:293,y:722,t:1528139824124};\\\", \\\"{x:296,y:712,t:1528139824141};\\\", \\\"{x:298,y:705,t:1528139824158};\\\", \\\"{x:302,y:700,t:1528139824174};\\\", \\\"{x:305,y:696,t:1528139824191};\\\", \\\"{x:313,y:683,t:1528139824207};\\\", \\\"{x:318,y:676,t:1528139824224};\\\", \\\"{x:329,y:661,t:1528139824242};\\\", \\\"{x:336,y:651,t:1528139824258};\\\", \\\"{x:339,y:647,t:1528139824274};\\\", \\\"{x:343,y:643,t:1528139824290};\\\", \\\"{x:343,y:642,t:1528139824321};\\\", \\\"{x:344,y:641,t:1528139824337};\\\", \\\"{x:344,y:638,t:1528139824369};\\\", \\\"{x:343,y:633,t:1528139824377};\\\", \\\"{x:338,y:625,t:1528139824392};\\\", \\\"{x:316,y:611,t:1528139824407};\\\", \\\"{x:292,y:597,t:1528139824425};\\\", \\\"{x:279,y:592,t:1528139824442};\\\", \\\"{x:273,y:589,t:1528139824457};\\\", \\\"{x:264,y:586,t:1528139824475};\\\", \\\"{x:261,y:584,t:1528139824491};\\\", \\\"{x:260,y:584,t:1528139824508};\\\", \\\"{x:258,y:582,t:1528139824562};\\\", \\\"{x:258,y:576,t:1528139824575};\\\", \\\"{x:254,y:567,t:1528139824591};\\\", \\\"{x:252,y:562,t:1528139824609};\\\", \\\"{x:250,y:557,t:1528139824625};\\\", \\\"{x:248,y:555,t:1528139824642};\\\", \\\"{x:247,y:554,t:1528139824658};\\\", \\\"{x:245,y:552,t:1528139824673};\\\", \\\"{x:238,y:549,t:1528139824691};\\\", \\\"{x:217,y:548,t:1528139824708};\\\", \\\"{x:194,y:550,t:1528139824724};\\\", \\\"{x:176,y:554,t:1528139824741};\\\", \\\"{x:153,y:557,t:1528139824759};\\\", \\\"{x:135,y:558,t:1528139824774};\\\", \\\"{x:131,y:558,t:1528139824791};\\\", \\\"{x:130,y:558,t:1528139824849};\\\", \\\"{x:129,y:556,t:1528139824881};\\\", \\\"{x:129,y:554,t:1528139824891};\\\", \\\"{x:129,y:552,t:1528139824908};\\\", \\\"{x:129,y:550,t:1528139824924};\\\", \\\"{x:129,y:549,t:1528139825050};\\\", \\\"{x:133,y:546,t:1528139825058};\\\", \\\"{x:136,y:545,t:1528139825075};\\\", \\\"{x:143,y:540,t:1528139825091};\\\", \\\"{x:159,y:533,t:1528139825109};\\\", \\\"{x:178,y:523,t:1528139825125};\\\", \\\"{x:190,y:518,t:1528139825141};\\\", \\\"{x:190,y:517,t:1528139825158};\\\", \\\"{x:190,y:516,t:1528139825458};\\\", \\\"{x:182,y:522,t:1528139825477};\\\", \\\"{x:178,y:529,t:1528139825492};\\\", \\\"{x:174,y:535,t:1528139825508};\\\", \\\"{x:171,y:538,t:1528139825525};\\\", \\\"{x:170,y:541,t:1528139825542};\\\", \\\"{x:169,y:542,t:1528139825569};\\\", \\\"{x:168,y:544,t:1528139825577};\\\", \\\"{x:168,y:550,t:1528139827210};\\\", \\\"{x:175,y:576,t:1528139827228};\\\", \\\"{x:191,y:598,t:1528139827244};\\\", \\\"{x:198,y:606,t:1528139827259};\\\", \\\"{x:199,y:606,t:1528139827276};\\\", \\\"{x:200,y:608,t:1528139827293};\\\", \\\"{x:202,y:610,t:1528139827310};\\\", \\\"{x:206,y:615,t:1528139827326};\\\", \\\"{x:211,y:626,t:1528139827343};\\\", \\\"{x:218,y:642,t:1528139827361};\\\", \\\"{x:224,y:659,t:1528139827376};\\\", \\\"{x:236,y:689,t:1528139827394};\\\", \\\"{x:245,y:719,t:1528139827409};\\\", \\\"{x:266,y:769,t:1528139827426};\\\", \\\"{x:283,y:835,t:1528139827443};\\\", \\\"{x:297,y:883,t:1528139827460};\\\", \\\"{x:308,y:922,t:1528139827476};\\\", \\\"{x:314,y:943,t:1528139827493};\\\", \\\"{x:314,y:952,t:1528139827511};\\\", \\\"{x:320,y:950,t:1528139828730};\\\", \\\"{x:327,y:943,t:1528139828744};\\\", \\\"{x:327,y:935,t:1528139828761};\\\", \\\"{x:328,y:916,t:1528139828777};\\\", \\\"{x:332,y:900,t:1528139828795};\\\", \\\"{x:333,y:890,t:1528139828812};\\\", \\\"{x:340,y:873,t:1528139828828};\\\", \\\"{x:342,y:863,t:1528139828845};\\\", \\\"{x:346,y:844,t:1528139828862};\\\", \\\"{x:349,y:831,t:1528139828878};\\\", \\\"{x:350,y:814,t:1528139828895};\\\", \\\"{x:354,y:797,t:1528139828911};\\\", \\\"{x:359,y:787,t:1528139828927};\\\", \\\"{x:359,y:782,t:1528139828944};\\\", \\\"{x:362,y:768,t:1528139828961};\\\", \\\"{x:364,y:764,t:1528139828978};\\\", \\\"{x:366,y:760,t:1528139828995};\\\", \\\"{x:371,y:756,t:1528139829012};\\\", \\\"{x:387,y:745,t:1528139829028};\\\", \\\"{x:409,y:733,t:1528139829045};\\\", \\\"{x:439,y:718,t:1528139829062};\\\", \\\"{x:484,y:709,t:1528139829078};\\\", \\\"{x:512,y:707,t:1528139829095};\\\", \\\"{x:529,y:707,t:1528139829112};\\\", \\\"{x:534,y:707,t:1528139829127};\\\", \\\"{x:535,y:708,t:1528139829217};\\\", \\\"{x:537,y:713,t:1528139829280};\\\", \\\"{x:539,y:719,t:1528139829294};\\\", \\\"{x:542,y:739,t:1528139829311};\\\", \\\"{x:545,y:763,t:1528139829329};\\\", \\\"{x:549,y:776,t:1528139829344};\\\", \\\"{x:550,y:779,t:1528139829361};\\\", \\\"{x:551,y:780,t:1528139829449};\\\", \\\"{x:551,y:780,t:1528139829538};\\\", \\\"{x:551,y:776,t:1528139829561};\\\", \\\"{x:551,y:764,t:1528139829579};\\\", \\\"{x:547,y:750,t:1528139829596};\\\", \\\"{x:546,y:745,t:1528139829611};\\\", \\\"{x:545,y:743,t:1528139829628};\\\", \\\"{x:545,y:741,t:1528139829645};\\\", \\\"{x:545,y:740,t:1528139830554};\\\" ] }, { \\\"rt\\\": 10135, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 441462, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"ZEPVG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 1.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:539,y:733,t:1528139831545};\\\", \\\"{x:538,y:729,t:1528139831563};\\\", \\\"{x:537,y:727,t:1528139831581};\\\", \\\"{x:536,y:726,t:1528139831596};\\\", \\\"{x:536,y:725,t:1528139831633};\\\", \\\"{x:534,y:720,t:1528139831646};\\\", \\\"{x:526,y:709,t:1528139831663};\\\", \\\"{x:516,y:693,t:1528139831681};\\\", \\\"{x:506,y:678,t:1528139831697};\\\", \\\"{x:504,y:674,t:1528139831713};\\\", \\\"{x:503,y:670,t:1528139831730};\\\", \\\"{x:502,y:668,t:1528139831747};\\\", \\\"{x:502,y:667,t:1528139831769};\\\", \\\"{x:502,y:666,t:1528139831785};\\\", \\\"{x:503,y:664,t:1528139831798};\\\", \\\"{x:505,y:660,t:1528139831814};\\\", \\\"{x:513,y:653,t:1528139831831};\\\", \\\"{x:528,y:644,t:1528139831849};\\\", \\\"{x:553,y:634,t:1528139831863};\\\", \\\"{x:625,y:605,t:1528139831881};\\\", \\\"{x:774,y:566,t:1528139831898};\\\", \\\"{x:888,y:547,t:1528139831913};\\\", \\\"{x:1008,y:524,t:1528139831931};\\\", \\\"{x:1112,y:502,t:1528139831948};\\\", \\\"{x:1194,y:486,t:1528139831963};\\\", \\\"{x:1227,y:472,t:1528139831980};\\\", \\\"{x:1232,y:471,t:1528139831998};\\\", \\\"{x:1226,y:471,t:1528139832202};\\\", \\\"{x:1215,y:474,t:1528139832214};\\\", \\\"{x:1147,y:482,t:1528139832231};\\\", \\\"{x:1050,y:492,t:1528139832248};\\\", \\\"{x:934,y:510,t:1528139832267};\\\", \\\"{x:831,y:510,t:1528139832281};\\\", \\\"{x:724,y:515,t:1528139832297};\\\", \\\"{x:711,y:515,t:1528139832315};\\\", \\\"{x:706,y:512,t:1528139832330};\\\", \\\"{x:704,y:509,t:1528139832347};\\\", \\\"{x:703,y:509,t:1528139832365};\\\", \\\"{x:703,y:510,t:1528139833170};\\\", \\\"{x:689,y:524,t:1528139833182};\\\", \\\"{x:655,y:545,t:1528139833200};\\\", \\\"{x:634,y:560,t:1528139833216};\\\", \\\"{x:628,y:562,t:1528139833231};\\\", \\\"{x:622,y:559,t:1528139833249};\\\", \\\"{x:622,y:560,t:1528139833273};\\\", \\\"{x:621,y:560,t:1528139833281};\\\", \\\"{x:622,y:558,t:1528139833426};\\\", \\\"{x:622,y:557,t:1528139833433};\\\", \\\"{x:625,y:555,t:1528139833449};\\\", \\\"{x:627,y:551,t:1528139833465};\\\", \\\"{x:634,y:539,t:1528139833482};\\\", \\\"{x:635,y:534,t:1528139833499};\\\", \\\"{x:638,y:528,t:1528139833516};\\\", \\\"{x:639,y:525,t:1528139833537};\\\", \\\"{x:639,y:524,t:1528139833552};\\\", \\\"{x:639,y:522,t:1528139833565};\\\", \\\"{x:639,y:521,t:1528139833582};\\\", \\\"{x:640,y:519,t:1528139833598};\\\", \\\"{x:640,y:518,t:1528139833778};\\\", \\\"{x:638,y:518,t:1528139833785};\\\", \\\"{x:637,y:518,t:1528139833799};\\\", \\\"{x:632,y:518,t:1528139833816};\\\", \\\"{x:625,y:518,t:1528139833833};\\\", \\\"{x:613,y:518,t:1528139833850};\\\", \\\"{x:600,y:518,t:1528139837802};\\\", \\\"{x:586,y:519,t:1528139837810};\\\", \\\"{x:561,y:522,t:1528139837823};\\\", \\\"{x:494,y:534,t:1528139837841};\\\", \\\"{x:476,y:536,t:1528139837852};\\\", \\\"{x:452,y:541,t:1528139837869};\\\", \\\"{x:449,y:542,t:1528139837884};\\\", \\\"{x:448,y:542,t:1528139837984};\\\", \\\"{x:445,y:546,t:1528139838001};\\\", \\\"{x:435,y:555,t:1528139838018};\\\", \\\"{x:426,y:562,t:1528139838035};\\\", \\\"{x:419,y:568,t:1528139838051};\\\", \\\"{x:418,y:569,t:1528139838068};\\\", \\\"{x:418,y:572,t:1528139838086};\\\", \\\"{x:418,y:573,t:1528139838113};\\\", \\\"{x:417,y:573,t:1528139838121};\\\", \\\"{x:417,y:574,t:1528139838135};\\\", \\\"{x:417,y:577,t:1528139838154};\\\", \\\"{x:417,y:585,t:1528139838169};\\\", \\\"{x:415,y:585,t:1528139838193};\\\", \\\"{x:415,y:586,t:1528139838209};\\\", \\\"{x:415,y:587,t:1528139838224};\\\", \\\"{x:415,y:588,t:1528139838257};\\\", \\\"{x:410,y:597,t:1528139838289};\\\", \\\"{x:404,y:604,t:1528139838303};\\\", \\\"{x:387,y:610,t:1528139838319};\\\", \\\"{x:370,y:616,t:1528139838337};\\\", \\\"{x:349,y:620,t:1528139838351};\\\", \\\"{x:329,y:625,t:1528139838369};\\\", \\\"{x:307,y:630,t:1528139838385};\\\", \\\"{x:284,y:637,t:1528139838403};\\\", \\\"{x:255,y:642,t:1528139838420};\\\", \\\"{x:224,y:656,t:1528139838436};\\\", \\\"{x:184,y:671,t:1528139838453};\\\", \\\"{x:166,y:671,t:1528139838470};\\\", \\\"{x:163,y:671,t:1528139838485};\\\", \\\"{x:161,y:671,t:1528139838502};\\\", \\\"{x:160,y:668,t:1528139838520};\\\", \\\"{x:155,y:660,t:1528139838536};\\\", \\\"{x:139,y:643,t:1528139838553};\\\", \\\"{x:124,y:631,t:1528139838569};\\\", \\\"{x:118,y:624,t:1528139838586};\\\", \\\"{x:112,y:612,t:1528139838603};\\\", \\\"{x:108,y:605,t:1528139838620};\\\", \\\"{x:105,y:594,t:1528139838635};\\\", \\\"{x:105,y:581,t:1528139838652};\\\", \\\"{x:106,y:575,t:1528139838671};\\\", \\\"{x:111,y:564,t:1528139838686};\\\", \\\"{x:119,y:554,t:1528139838703};\\\", \\\"{x:128,y:543,t:1528139838719};\\\", \\\"{x:138,y:535,t:1528139838736};\\\", \\\"{x:170,y:529,t:1528139838754};\\\", \\\"{x:202,y:526,t:1528139838769};\\\", \\\"{x:249,y:520,t:1528139838785};\\\", \\\"{x:330,y:519,t:1528139838804};\\\", \\\"{x:407,y:513,t:1528139838819};\\\", \\\"{x:488,y:513,t:1528139838837};\\\", \\\"{x:560,y:513,t:1528139838854};\\\", \\\"{x:610,y:513,t:1528139838870};\\\", \\\"{x:634,y:516,t:1528139838885};\\\", \\\"{x:643,y:520,t:1528139838903};\\\", \\\"{x:645,y:520,t:1528139838920};\\\", \\\"{x:647,y:521,t:1528139839002};\\\", \\\"{x:653,y:521,t:1528139839009};\\\", \\\"{x:660,y:521,t:1528139839020};\\\", \\\"{x:680,y:524,t:1528139839037};\\\", \\\"{x:727,y:528,t:1528139839054};\\\", \\\"{x:776,y:532,t:1528139839070};\\\", \\\"{x:807,y:535,t:1528139839087};\\\", \\\"{x:829,y:536,t:1528139839103};\\\", \\\"{x:839,y:536,t:1528139839119};\\\", \\\"{x:840,y:536,t:1528139839137};\\\", \\\"{x:840,y:537,t:1528139839169};\\\", \\\"{x:840,y:538,t:1528139839185};\\\", \\\"{x:840,y:541,t:1528139839193};\\\", \\\"{x:840,y:544,t:1528139839203};\\\", \\\"{x:838,y:553,t:1528139839220};\\\", \\\"{x:838,y:558,t:1528139839236};\\\", \\\"{x:840,y:564,t:1528139839252};\\\", \\\"{x:840,y:567,t:1528139839270};\\\", \\\"{x:841,y:569,t:1528139839286};\\\", \\\"{x:843,y:572,t:1528139839303};\\\", \\\"{x:844,y:576,t:1528139839320};\\\", \\\"{x:845,y:584,t:1528139839339};\\\", \\\"{x:846,y:587,t:1528139839353};\\\", \\\"{x:846,y:590,t:1528139839370};\\\", \\\"{x:846,y:593,t:1528139839387};\\\", \\\"{x:846,y:594,t:1528139839403};\\\", \\\"{x:846,y:595,t:1528139839425};\\\", \\\"{x:846,y:597,t:1528139839673};\\\", \\\"{x:838,y:604,t:1528139839687};\\\", \\\"{x:818,y:611,t:1528139839704};\\\", \\\"{x:796,y:615,t:1528139839720};\\\", \\\"{x:796,y:616,t:1528139839737};\\\", \\\"{x:787,y:623,t:1528139840442};\\\", \\\"{x:765,y:636,t:1528139840454};\\\", \\\"{x:735,y:659,t:1528139840471};\\\", \\\"{x:698,y:700,t:1528139840487};\\\", \\\"{x:680,y:727,t:1528139840504};\\\", \\\"{x:605,y:781,t:1528139840520};\\\", \\\"{x:589,y:794,t:1528139840537};\\\", \\\"{x:568,y:812,t:1528139840555};\\\", \\\"{x:552,y:822,t:1528139840570};\\\", \\\"{x:542,y:826,t:1528139840587};\\\", \\\"{x:541,y:826,t:1528139840641};\\\", \\\"{x:540,y:822,t:1528139840655};\\\", \\\"{x:535,y:807,t:1528139840671};\\\", \\\"{x:529,y:786,t:1528139840688};\\\", \\\"{x:520,y:745,t:1528139840706};\\\", \\\"{x:515,y:724,t:1528139840723};\\\", \\\"{x:512,y:713,t:1528139840738};\\\", \\\"{x:511,y:711,t:1528139840754};\\\", \\\"{x:511,y:709,t:1528139840771};\\\", \\\"{x:514,y:709,t:1528139840946};\\\", \\\"{x:518,y:720,t:1528139840955};\\\", \\\"{x:527,y:732,t:1528139840969};\\\", \\\"{x:527,y:732,t:1528139840972};\\\", \\\"{x:531,y:741,t:1528139840988};\\\", \\\"{x:532,y:744,t:1528139841005};\\\", \\\"{x:538,y:744,t:1528139841553};\\\", \\\"{x:553,y:735,t:1528139841561};\\\", \\\"{x:557,y:726,t:1528139841572};\\\", \\\"{x:623,y:690,t:1528139841589};\\\", \\\"{x:704,y:653,t:1528139841605};\\\", \\\"{x:793,y:611,t:1528139841622};\\\", \\\"{x:875,y:564,t:1528139841639};\\\", \\\"{x:951,y:522,t:1528139841655};\\\", \\\"{x:999,y:474,t:1528139841672};\\\", \\\"{x:1061,y:414,t:1528139841688};\\\", \\\"{x:1089,y:380,t:1528139841705};\\\", \\\"{x:1102,y:359,t:1528139841722};\\\", \\\"{x:1106,y:350,t:1528139841738};\\\", \\\"{x:1110,y:338,t:1528139841755};\\\", \\\"{x:1112,y:331,t:1528139841772};\\\", \\\"{x:1113,y:328,t:1528139841789};\\\", \\\"{x:1114,y:325,t:1528139841805};\\\", \\\"{x:1115,y:323,t:1528139841822};\\\", \\\"{x:1115,y:322,t:1528139841839};\\\", \\\"{x:1115,y:321,t:1528139841855};\\\", \\\"{x:1115,y:320,t:1528139842280};\\\", \\\"{x:1115,y:319,t:1528139842288};\\\" ] }, { \\\"rt\\\": 84610, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 527356, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"ZEPVG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"You first see which one on the x axis says start time at 12 pm. \\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 7062, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"18\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"US\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 535423, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"ZEPVG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 10140, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"First\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 546574, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"ZEPVG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 1997, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 549908, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"ZEPVG\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"yankee\\\", \\\"condition\\\": \\\"311\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"ZEPVG\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 127, dom: 560, initialDom: 618",
  "javascriptErrors": []
}