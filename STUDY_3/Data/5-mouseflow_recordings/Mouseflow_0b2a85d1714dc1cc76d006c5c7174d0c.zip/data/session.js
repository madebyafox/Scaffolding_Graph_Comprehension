var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "0b2a85d1714dc1cc76d006c5c7174d0c",
  "created": "2018-06-04T12:17:22.0182104-07:00",
  "lastActivity": "2018-06-04T12:19:10.9376301-07:00",
  "pageViews": [
    {
      "id": "060422422815983e30c9202a428aeee37e5db3ba",
      "startTime": "2018-06-04T12:17:22.0549785-07:00",
      "endTime": "2018-06-04T12:19:10.9376301-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/16",
      "visitTime": 109226,
      "engagementTime": 103842,
      "scroll": 100.0,
      "tags": [
        "form-interact",
        "submit"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 109226,
  "engagementTime": 103842,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.27",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact",
    "submit"
  ],
  "variables": [
    "SID=ZEPVG",
    "CONDITION=311"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "607f270ac11e3b24bd2517815d539c17",
  "gdpr": false
}