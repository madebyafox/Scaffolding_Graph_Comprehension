var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "63f04edeb928ba19ce9aa3b1fe9be718",
  "created": "2018-05-29T10:07:55.2373342-07:00",
  "lastActivity": "2018-05-29T10:08:19.7365255-07:00",
  "pageViews": [
    {
      "id": "05295555fc11bfc7a7c8583cebe0a561684e4a0d",
      "startTime": "2018-05-29T10:07:55.5236468-07:00",
      "endTime": "2018-05-29T10:08:19.7365255-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 24410,
      "engagementTime": 24409,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 24410,
  "engagementTime": 24409,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.37",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "471d5cc8c075c848201bb486c6e614f2",
  "gdpr": false
}