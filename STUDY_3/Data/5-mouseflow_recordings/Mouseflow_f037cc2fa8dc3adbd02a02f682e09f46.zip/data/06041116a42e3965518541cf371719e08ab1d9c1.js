var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["06041116a42e3965518541cf371719e08ab1d9c1"] = {
  "startTime": "2018-06-04T20:25:11.5309798Z",
  "websitePageUrl": "/16",
  "visitTime": 68828,
  "engagementTime": 68727,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1094,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "f037cc2fa8dc3adbd02a02f682e09f46",
    "created": "2018-06-04T20:25:11.3493789+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=8182H",
      "CONDITION=211"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "a5d3231e76659a9885cc600195ee8507",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/f037cc2fa8dc3adbd02a02f682e09f46/play"
  },
  "events": [
    {
      "t": 0,
      "e": 0,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 182,
      "e": 182,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 182,
      "e": 182,
      "ty": 2,
      "x": 706,
      "y": 707
    },
    {
      "t": 251,
      "e": 251,
      "ty": 41,
      "x": 1486,
      "y": 44163,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 700,
      "e": 700,
      "ty": 2,
      "x": 698,
      "y": 716
    },
    {
      "t": 750,
      "e": 750,
      "ty": 41,
      "x": 54845,
      "y": 49044,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 800,
      "e": 800,
      "ty": 2,
      "x": 585,
      "y": 814
    },
    {
      "t": 844,
      "e": 844,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 900,
      "e": 900,
      "ty": 2,
      "x": 656,
      "y": 1013
    },
    {
      "t": 1000,
      "e": 1000,
      "ty": 41,
      "x": 62826,
      "y": 61153,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1900,
      "e": 1900,
      "ty": 2,
      "x": 15,
      "y": 856
    },
    {
      "t": 2000,
      "e": 2000,
      "ty": 2,
      "x": 12,
      "y": 828
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 41,
      "x": 137,
      "y": 49896,
      "ta": "> div.stimulus"
    },
    {
      "t": 2200,
      "e": 2200,
      "ty": 6,
      "x": 359,
      "y": 503,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2203,
      "e": 2203,
      "ty": 2,
      "x": 359,
      "y": 503
    },
    {
      "t": 2217,
      "e": 2217,
      "ty": 7,
      "x": 407,
      "y": 395,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2251,
      "e": 2251,
      "ty": 41,
      "x": 35398,
      "y": 21479,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 2299,
      "e": 2299,
      "ty": 2,
      "x": 426,
      "y": 82
    },
    {
      "t": 2316,
      "e": 2316,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 2400,
      "e": 2400,
      "ty": 2,
      "x": 426,
      "y": 13
    },
    {
      "t": 2501,
      "e": 2501,
      "ty": 41,
      "x": 36972,
      "y": 304,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 3100,
      "e": 3100,
      "ty": 2,
      "x": 849,
      "y": 633
    },
    {
      "t": 3200,
      "e": 3200,
      "ty": 2,
      "x": 661,
      "y": 985
    },
    {
      "t": 3250,
      "e": 3250,
      "ty": 41,
      "x": 61814,
      "y": 53486,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 3300,
      "e": 3300,
      "ty": 2,
      "x": 637,
      "y": 886
    },
    {
      "t": 3387,
      "e": 3387,
      "ty": 6,
      "x": 494,
      "y": 522,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3400,
      "e": 3400,
      "ty": 2,
      "x": 494,
      "y": 522
    },
    {
      "t": 3433,
      "e": 3433,
      "ty": 7,
      "x": 494,
      "y": 458,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3501,
      "e": 3501,
      "ty": 2,
      "x": 496,
      "y": 398
    },
    {
      "t": 3501,
      "e": 3501,
      "ty": 41,
      "x": 44841,
      "y": 23731,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 3600,
      "e": 3600,
      "ty": 2,
      "x": 496,
      "y": 409
    },
    {
      "t": 3700,
      "e": 3700,
      "ty": 2,
      "x": 501,
      "y": 456
    },
    {
      "t": 3701,
      "e": 3701,
      "ty": 6,
      "x": 497,
      "y": 487,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3750,
      "e": 3750,
      "ty": 41,
      "x": 44503,
      "y": 48759,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3800,
      "e": 3800,
      "ty": 2,
      "x": 493,
      "y": 532
    },
    {
      "t": 4001,
      "e": 4001,
      "ty": 41,
      "x": 44503,
      "y": 50377,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4021,
      "e": 4021,
      "ty": 3,
      "x": 493,
      "y": 532,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4023,
      "e": 4023,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4116,
      "e": 4116,
      "ty": 4,
      "x": 44503,
      "y": 50377,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4116,
      "e": 4116,
      "ty": 5,
      "x": 493,
      "y": 532,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7633,
      "e": 7633,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 8132,
      "e": 8132,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 8165,
      "e": 8165,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 8198,
      "e": 8198,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 8231,
      "e": 8231,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 8264,
      "e": 8264,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 8296,
      "e": 8296,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 8329,
      "e": 8329,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 8362,
      "e": 8362,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 8395,
      "e": 8395,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 8429,
      "e": 8429,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 8462,
      "e": 8462,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 8495,
      "e": 8495,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 8528,
      "e": 8528,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 8560,
      "e": 8560,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 8594,
      "e": 8594,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 8627,
      "e": 8627,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 8640,
      "e": 8640,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 8641,
      "e": 8641,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8759,
      "e": 8759,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "G"
    },
    {
      "t": 8776,
      "e": 8776,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "G"
    },
    {
      "t": 9040,
      "e": 9040,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 9041,
      "e": 9041,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9096,
      "e": 9096,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go"
    },
    {
      "t": 9203,
      "e": 9203,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go"
    },
    {
      "t": 9488,
      "e": 9488,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 9488,
      "e": 9488,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9602,
      "e": 9602,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go "
    },
    {
      "t": 9615,
      "e": 9615,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go "
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10328,
      "e": 10328,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 10328,
      "e": 10328,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10408,
      "e": 10408,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go u"
    },
    {
      "t": 11776,
      "e": 11776,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 11887,
      "e": 11887,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go "
    },
    {
      "t": 11976,
      "e": 11976,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 12031,
      "e": 12031,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go"
    },
    {
      "t": 12968,
      "e": 12968,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12969,
      "e": 12969,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13072,
      "e": 13072,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go "
    },
    {
      "t": 13223,
      "e": 13223,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 13223,
      "e": 13223,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13296,
      "e": 13296,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go u"
    },
    {
      "t": 13403,
      "e": 13403,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go u"
    },
    {
      "t": 13456,
      "e": 13456,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 13456,
      "e": 13456,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13535,
      "e": 13535,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||p"
    },
    {
      "t": 13639,
      "e": 13639,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13640,
      "e": 13640,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13760,
      "e": 13760,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 13792,
      "e": 13792,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 13793,
      "e": 13793,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13871,
      "e": 13871,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 13904,
      "e": 13904,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 13904,
      "e": 13904,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13968,
      "e": 13968,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 14040,
      "e": 14040,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 14041,
      "e": 14041,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14111,
      "e": 14111,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14112,
      "e": 14112,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14135,
      "e": 14135,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 14223,
      "e": 14223,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 15440,
      "e": 15440,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 15441,
      "e": 15441,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15512,
      "e": 15512,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 15552,
      "e": 15552,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 15553,
      "e": 15553,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15639,
      "e": 15639,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 15969,
      "e": 15969,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 15969,
      "e": 15969,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16048,
      "e": 16048,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 16056,
      "e": 16056,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 16056,
      "e": 16056,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16119,
      "e": 16119,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 16256,
      "e": 16256,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 16256,
      "e": 16256,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16352,
      "e": 16352,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 16456,
      "e": 16456,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 16456,
      "e": 16456,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16519,
      "e": 16519,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 16968,
      "e": 16968,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 17063,
      "e": 17063,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go up the diagn"
    },
    {
      "t": 18264,
      "e": 18264,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 18335,
      "e": 18335,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go up the diag"
    },
    {
      "t": 18968,
      "e": 18968,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 18970,
      "e": 18970,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19031,
      "e": 19031,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 19159,
      "e": 19159,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 19160,
      "e": 19160,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19240,
      "e": 19240,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 19472,
      "e": 19472,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 19473,
      "e": 19473,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19567,
      "e": 19567,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 19671,
      "e": 19671,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 19672,
      "e": 19672,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19767,
      "e": 19767,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 19767,
      "e": 19767,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19776,
      "e": 19776,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||al"
    },
    {
      "t": 19855,
      "e": 19855,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19943,
      "e": 19943,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19944,
      "e": 19944,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20000,
      "e": 20000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20039,
      "e": 20039,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 20344,
      "e": 20344,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 20345,
      "e": 20345,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20447,
      "e": 20447,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 20568,
      "e": 20568,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 20569,
      "e": 20569,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20623,
      "e": 20623,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 20784,
      "e": 20784,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 20785,
      "e": 20785,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20895,
      "e": 20895,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 20959,
      "e": 20959,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 20960,
      "e": 20960,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21032,
      "e": 21032,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 21104,
      "e": 21104,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21104,
      "e": 21104,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21255,
      "e": 21255,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 21728,
      "e": 21728,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 22227,
      "e": 22227,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 22259,
      "e": 22259,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 22293,
      "e": 22293,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 22325,
      "e": 22325,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 22358,
      "e": 22358,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 22391,
      "e": 22391,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 22424,
      "e": 22424,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 22457,
      "e": 22457,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 22491,
      "e": 22491,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 22524,
      "e": 22524,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 22557,
      "e": 22557,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 22559,
      "e": 22559,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go up the dia"
    },
    {
      "t": 23656,
      "e": 23656,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 23656,
      "e": 23656,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23760,
      "e": 23760,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 23912,
      "e": 23912,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 23916,
      "e": 23916,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23991,
      "e": 23991,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 24143,
      "e": 24143,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 24144,
      "e": 24144,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24247,
      "e": 24247,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 24376,
      "e": 24376,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 24377,
      "e": 24377,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24471,
      "e": 24471,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 24472,
      "e": 24472,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24479,
      "e": 24479,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||al"
    },
    {
      "t": 24568,
      "e": 24568,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24863,
      "e": 24863,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24863,
      "e": 24863,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24951,
      "e": 24951,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25624,
      "e": 25624,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 25624,
      "e": 25624,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25703,
      "e": 25703,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 25832,
      "e": 25832,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 25832,
      "e": 25832,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25904,
      "e": 25904,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 26056,
      "e": 26056,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 26056,
      "e": 26056,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26151,
      "e": 26151,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 26832,
      "e": 26832,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 26833,
      "e": 26833,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26936,
      "e": 26936,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 26943,
      "e": 26943,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26944,
      "e": 26944,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27048,
      "e": 27048,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27184,
      "e": 27184,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 27185,
      "e": 27185,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27279,
      "e": 27279,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 27279,
      "e": 27279,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27295,
      "e": 27295,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||to"
    },
    {
      "t": 27384,
      "e": 27384,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27488,
      "e": 27488,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27489,
      "e": 27489,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27603,
      "e": 27603,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go up the diagonal line to "
    },
    {
      "t": 27617,
      "e": 27617,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27672,
      "e": 27672,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 27673,
      "e": 27673,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27743,
      "e": 27743,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 28016,
      "e": 28016,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 28017,
      "e": 28017,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28119,
      "e": 28119,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 28313,
      "e": 28313,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 28313,
      "e": 28313,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28399,
      "e": 28399,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 28416,
      "e": 28416,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28417,
      "e": 28417,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28528,
      "e": 28528,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 28600,
      "e": 28600,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 28600,
      "e": 28600,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28695,
      "e": 28695,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 28728,
      "e": 28728,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 28728,
      "e": 28728,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28856,
      "e": 28856,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 28960,
      "e": 28960,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 28961,
      "e": 28961,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29071,
      "e": 29071,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 29135,
      "e": 29135,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 29136,
      "e": 29136,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29248,
      "e": 29248,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 29519,
      "e": 29519,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 29520,
      "e": 29520,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29647,
      "e": 29647,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 30001,
      "e": 30001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 32360,
      "e": 32360,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 32361,
      "e": 32361,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32503,
      "e": 32503,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 32926,
      "e": 32926,
      "ty": 7,
      "x": 650,
      "y": 575,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33001,
      "e": 33001,
      "ty": 2,
      "x": 667,
      "y": 580
    },
    {
      "t": 33001,
      "e": 33001,
      "ty": 41,
      "x": 64063,
      "y": 34805,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 33025,
      "e": 33025,
      "ty": 6,
      "x": 598,
      "y": 545,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33058,
      "e": 33058,
      "ty": 7,
      "x": 308,
      "y": 402,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33101,
      "e": 33101,
      "ty": 2,
      "x": 0,
      "y": 402
    },
    {
      "t": 33201,
      "e": 33201,
      "ty": 2,
      "x": 1,
      "y": 412
    },
    {
      "t": 33250,
      "e": 33250,
      "ty": 41,
      "x": 275,
      "y": 25617,
      "ta": "> div.stimulus"
    },
    {
      "t": 33301,
      "e": 33301,
      "ty": 2,
      "x": 39,
      "y": 444
    },
    {
      "t": 33400,
      "e": 33400,
      "ty": 2,
      "x": 41,
      "y": 444
    },
    {
      "t": 33500,
      "e": 33500,
      "ty": 2,
      "x": 67,
      "y": 431
    },
    {
      "t": 33501,
      "e": 33501,
      "ty": 41,
      "x": 2031,
      "y": 25739,
      "ta": "> div.stimulus"
    },
    {
      "t": 34024,
      "e": 34024,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34119,
      "e": 34119,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go up the diagonal line to the right"
    },
    {
      "t": 34256,
      "e": 34256,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 34257,
      "e": 34257,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34375,
      "e": 34375,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 34440,
      "e": 34440,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 34440,
      "e": 34440,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34543,
      "e": 34543,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 34648,
      "e": 34648,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 34648,
      "e": 34648,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34735,
      "e": 34735,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 34735,
      "e": 34735,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34751,
      "e": 34751,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||nt"
    },
    {
      "t": 34839,
      "e": 34839,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34864,
      "e": 34864,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 34864,
      "e": 34864,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34960,
      "e": 34960,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 35104,
      "e": 35104,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 35104,
      "e": 35104,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35223,
      "e": 35223,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 35280,
      "e": 35280,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 35280,
      "e": 35280,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35359,
      "e": 35359,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 35528,
      "e": 35528,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 35529,
      "e": 35529,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35599,
      "e": 35599,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 35719,
      "e": 35719,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 35721,
      "e": 35721,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35847,
      "e": 35847,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 35895,
      "e": 35895,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 35896,
      "e": 35896,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35999,
      "e": 35999,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 36040,
      "e": 36040,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36041,
      "e": 36041,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36128,
      "e": 36128,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 36344,
      "e": 36344,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 36345,
      "e": 36345,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36471,
      "e": 36471,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 36479,
      "e": 36479,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 36480,
      "e": 36480,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36562,
      "e": 36562,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 36663,
      "e": 36663,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 36663,
      "e": 36663,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36751,
      "e": 36751,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 36751,
      "e": 36751,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 36752,
      "e": 36752,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36847,
      "e": 36847,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 36887,
      "e": 36887,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36887,
      "e": 36887,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36992,
      "e": 36992,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 37240,
      "e": 37240,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 37241,
      "e": 37241,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37383,
      "e": 37383,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 37391,
      "e": 37391,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37392,
      "e": 37392,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37447,
      "e": 37447,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 37568,
      "e": 37568,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 37569,
      "e": 37569,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37680,
      "e": 37680,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 37792,
      "e": 37792,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 37793,
      "e": 37793,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37880,
      "e": 37880,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 37984,
      "e": 37984,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 37985,
      "e": 37985,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38064,
      "e": 38064,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 38159,
      "e": 38159,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 38159,
      "e": 38159,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38223,
      "e": 38223,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 38224,
      "e": 38224,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38232,
      "e": 38232,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||te"
    },
    {
      "t": 38280,
      "e": 38280,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 38402,
      "e": 38402,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go up the diagonal line to the right until you find a lette"
    },
    {
      "t": 38425,
      "e": 38425,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 38425,
      "e": 38425,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38503,
      "e": 38503,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 38559,
      "e": 38559,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 38560,
      "e": 38560,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38655,
      "e": 38655,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 39300,
      "e": 39300,
      "ty": 2,
      "x": 45,
      "y": 504
    },
    {
      "t": 39400,
      "e": 39400,
      "ty": 2,
      "x": 202,
      "y": 585
    },
    {
      "t": 39500,
      "e": 39500,
      "ty": 2,
      "x": 331,
      "y": 643
    },
    {
      "t": 39501,
      "e": 39501,
      "ty": 41,
      "x": 5807,
      "y": 48669,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 39532,
      "e": 39532,
      "ty": 6,
      "x": 366,
      "y": 635,
      "ta": "#strategyButton"
    },
    {
      "t": 39600,
      "e": 39600,
      "ty": 2,
      "x": 370,
      "y": 631
    },
    {
      "t": 39700,
      "e": 39700,
      "ty": 2,
      "x": 375,
      "y": 631
    },
    {
      "t": 39748,
      "e": 39748,
      "ty": 3,
      "x": 375,
      "y": 631,
      "ta": "#strategyButton"
    },
    {
      "t": 39750,
      "e": 39750,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Go up the diagonal line to the right until you find a letter."
    },
    {
      "t": 39751,
      "e": 39751,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 39751,
      "e": 39751,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 39753,
      "e": 39753,
      "ty": 41,
      "x": 19882,
      "y": 56409,
      "ta": "#strategyButton"
    },
    {
      "t": 39828,
      "e": 39828,
      "ty": 4,
      "x": 19882,
      "y": 56409,
      "ta": "#strategyButton"
    },
    {
      "t": 39836,
      "e": 39836,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 39838,
      "e": 39838,
      "ty": 5,
      "x": 375,
      "y": 631,
      "ta": "#strategyButton"
    },
    {
      "t": 39848,
      "e": 39848,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 40000,
      "e": 40000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40100,
      "e": 40100,
      "ty": 2,
      "x": 75,
      "y": 760
    },
    {
      "t": 40200,
      "e": 40200,
      "ty": 2,
      "x": 0,
      "y": 820
    },
    {
      "t": 40250,
      "e": 40250,
      "ty": 41,
      "x": 0,
      "y": 49896,
      "ta": "html"
    },
    {
      "t": 40400,
      "e": 40400,
      "ty": 2,
      "x": 0,
      "y": 791
    },
    {
      "t": 40501,
      "e": 40501,
      "ty": 2,
      "x": 0,
      "y": 783
    },
    {
      "t": 40501,
      "e": 40501,
      "ty": 41,
      "x": 0,
      "y": 47645,
      "ta": "html"
    },
    {
      "t": 40599,
      "e": 40599,
      "ty": 2,
      "x": 0,
      "y": 780
    },
    {
      "t": 40750,
      "e": 40750,
      "ty": 41,
      "x": 0,
      "y": 47462,
      "ta": "html"
    },
    {
      "t": 40846,
      "e": 40846,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 41000,
      "e": 41000,
      "ty": 2,
      "x": 0,
      "y": 807
    },
    {
      "t": 41000,
      "e": 41000,
      "ty": 41,
      "x": 0,
      "y": 49105,
      "ta": "html"
    },
    {
      "t": 41100,
      "e": 41100,
      "ty": 2,
      "x": 0,
      "y": 811
    },
    {
      "t": 41251,
      "e": 41251,
      "ty": 41,
      "x": 0,
      "y": 49349,
      "ta": "html"
    },
    {
      "t": 41403,
      "e": 41403,
      "ty": 2,
      "x": 12,
      "y": 797
    },
    {
      "t": 41500,
      "e": 41500,
      "ty": 2,
      "x": 251,
      "y": 662
    },
    {
      "t": 41500,
      "e": 41500,
      "ty": 41,
      "x": 8368,
      "y": 39795,
      "ta": "html > body"
    },
    {
      "t": 41600,
      "e": 41600,
      "ty": 2,
      "x": 808,
      "y": 478
    },
    {
      "t": 41700,
      "e": 41700,
      "ty": 2,
      "x": 1190,
      "y": 397
    },
    {
      "t": 41750,
      "e": 41750,
      "ty": 41,
      "x": 40705,
      "y": 23670,
      "ta": "html > body"
    },
    {
      "t": 41800,
      "e": 41800,
      "ty": 2,
      "x": 1121,
      "y": 461
    },
    {
      "t": 41849,
      "e": 41849,
      "ty": 6,
      "x": 921,
      "y": 508,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 41900,
      "e": 41900,
      "ty": 2,
      "x": 865,
      "y": 519
    },
    {
      "t": 41916,
      "e": 41916,
      "ty": 7,
      "x": 861,
      "y": 523,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 42000,
      "e": 42000,
      "ty": 2,
      "x": 861,
      "y": 523
    },
    {
      "t": 42000,
      "e": 42000,
      "ty": 41,
      "x": 11463,
      "y": 60602,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 42069,
      "e": 42069,
      "ty": 6,
      "x": 861,
      "y": 520,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 42100,
      "e": 42100,
      "ty": 2,
      "x": 861,
      "y": 512
    },
    {
      "t": 42200,
      "e": 42200,
      "ty": 2,
      "x": 861,
      "y": 509
    },
    {
      "t": 42212,
      "e": 42212,
      "ty": 3,
      "x": 861,
      "y": 509,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 42213,
      "e": 42213,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 42250,
      "e": 42250,
      "ty": 41,
      "x": 11463,
      "y": 21845,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 42300,
      "e": 42300,
      "ty": 2,
      "x": 861,
      "y": 508
    },
    {
      "t": 42315,
      "e": 42315,
      "ty": 4,
      "x": 11463,
      "y": 21845,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 42315,
      "e": 42315,
      "ty": 5,
      "x": 861,
      "y": 508,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 42936,
      "e": 42936,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 42936,
      "e": 42936,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 43016,
      "e": 43016,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 43143,
      "e": 43143,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 43144,
      "e": 43144,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 43207,
      "e": 43207,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 43300,
      "e": 43300,
      "ty": 7,
      "x": 888,
      "y": 533,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 43301,
      "e": 43301,
      "ty": 2,
      "x": 888,
      "y": 533
    },
    {
      "t": 43401,
      "e": 43401,
      "ty": 2,
      "x": 906,
      "y": 569
    },
    {
      "t": 43500,
      "e": 43500,
      "ty": 2,
      "x": 906,
      "y": 583
    },
    {
      "t": 43500,
      "e": 43500,
      "ty": 41,
      "x": 21196,
      "y": 37347,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 43585,
      "e": 43585,
      "ty": 6,
      "x": 903,
      "y": 599,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 43600,
      "e": 43600,
      "ty": 2,
      "x": 902,
      "y": 600
    },
    {
      "t": 43701,
      "e": 43701,
      "ty": 2,
      "x": 898,
      "y": 602
    },
    {
      "t": 43751,
      "e": 43751,
      "ty": 41,
      "x": 18816,
      "y": 37448,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 43800,
      "e": 43800,
      "ty": 2,
      "x": 894,
      "y": 606
    },
    {
      "t": 43835,
      "e": 43835,
      "ty": 3,
      "x": 894,
      "y": 606,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 43835,
      "e": 43835,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 43836,
      "e": 43836,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 43836,
      "e": 43836,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 43947,
      "e": 43947,
      "ty": 4,
      "x": 18600,
      "y": 37448,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 43947,
      "e": 43947,
      "ty": 5,
      "x": 894,
      "y": 606,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 44001,
      "e": 44001,
      "ty": 41,
      "x": 18600,
      "y": 37448,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 44431,
      "e": 44431,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 44616,
      "e": 44616,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "82"
    },
    {
      "t": 44616,
      "e": 44616,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 44703,
      "e": 44703,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "R"
    },
    {
      "t": 44735,
      "e": 44735,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "R"
    },
    {
      "t": 44864,
      "e": 44864,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 44865,
      "e": 44865,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 44943,
      "e": 44943,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Ru"
    },
    {
      "t": 44982,
      "e": 44982,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 44983,
      "e": 44983,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 45055,
      "e": 45055,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Rus"
    },
    {
      "t": 45160,
      "e": 45160,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 45160,
      "e": 45160,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 45231,
      "e": 45231,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Russ"
    },
    {
      "t": 45239,
      "e": 45239,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "73"
    },
    {
      "t": 45242,
      "e": 45242,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 45327,
      "e": 45327,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||i"
    },
    {
      "t": 45375,
      "e": 45375,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 45376,
      "e": 45376,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 45439,
      "e": 45439,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 45936,
      "e": 45936,
      "ty": 7,
      "x": 891,
      "y": 615,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 45986,
      "e": 45986,
      "ty": 6,
      "x": 906,
      "y": 653,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 46000,
      "e": 46000,
      "ty": 2,
      "x": 906,
      "y": 653
    },
    {
      "t": 46001,
      "e": 46001,
      "ty": 41,
      "x": 5194,
      "y": 59577,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 46002,
      "e": 46002,
      "ty": 7,
      "x": 925,
      "y": 657,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 46100,
      "e": 46100,
      "ty": 2,
      "x": 971,
      "y": 662
    },
    {
      "t": 46201,
      "e": 46201,
      "ty": 2,
      "x": 979,
      "y": 664
    },
    {
      "t": 46251,
      "e": 46251,
      "ty": 41,
      "x": 33439,
      "y": 39491,
      "ta": "html > body"
    },
    {
      "t": 46254,
      "e": 46254,
      "ty": 6,
      "x": 977,
      "y": 653,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 46300,
      "e": 46300,
      "ty": 2,
      "x": 977,
      "y": 649
    },
    {
      "t": 46397,
      "e": 46397,
      "ty": 3,
      "x": 975,
      "y": 642,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 46397,
      "e": 46397,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Russia"
    },
    {
      "t": 46398,
      "e": 46398,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 46398,
      "e": 46398,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 46401,
      "e": 46401,
      "ty": 2,
      "x": 975,
      "y": 642
    },
    {
      "t": 46483,
      "e": 46483,
      "ty": 4,
      "x": 40756,
      "y": 37732,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 46484,
      "e": 46484,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 46484,
      "e": 46484,
      "ty": 5,
      "x": 975,
      "y": 642,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 46484,
      "e": 46484,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 46500,
      "e": 46500,
      "ty": 41,
      "x": 33301,
      "y": 38578,
      "ta": "html > body"
    },
    {
      "t": 46601,
      "e": 46601,
      "ty": 2,
      "x": 935,
      "y": 660
    },
    {
      "t": 46700,
      "e": 46700,
      "ty": 2,
      "x": 396,
      "y": 690
    },
    {
      "t": 46754,
      "e": 46754,
      "ty": 41,
      "x": 11398,
      "y": 41499,
      "ta": "html > body"
    },
    {
      "t": 46804,
      "e": 46804,
      "ty": 2,
      "x": 332,
      "y": 687
    },
    {
      "t": 46904,
      "e": 46904,
      "ty": 2,
      "x": 321,
      "y": 679
    },
    {
      "t": 47004,
      "e": 47004,
      "ty": 41,
      "x": 10779,
      "y": 40830,
      "ta": "html > body"
    },
    {
      "t": 47510,
      "e": 47510,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 48104,
      "e": 48104,
      "ty": 2,
      "x": 317,
      "y": 675
    },
    {
      "t": 48204,
      "e": 48204,
      "ty": 2,
      "x": 156,
      "y": 552
    },
    {
      "t": 48254,
      "e": 48254,
      "ty": 41,
      "x": 2996,
      "y": 30242,
      "ta": "html > body"
    },
    {
      "t": 48304,
      "e": 48304,
      "ty": 2,
      "x": 103,
      "y": 440
    },
    {
      "t": 48400,
      "e": 48400,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 48404,
      "e": 48404,
      "ty": 2,
      "x": 686,
      "y": 5
    },
    {
      "t": 48504,
      "e": 48504,
      "ty": 41,
      "x": 23624,
      "y": 304,
      "ta": "html"
    },
    {
      "t": 48704,
      "e": 48704,
      "ty": 2,
      "x": 1089,
      "y": 34
    },
    {
      "t": 48754,
      "e": 48754,
      "ty": 41,
      "x": 35815,
      "y": 2616,
      "ta": "html > body"
    },
    {
      "t": 48804,
      "e": 48804,
      "ty": 2,
      "x": 1042,
      "y": 62
    },
    {
      "t": 48904,
      "e": 48904,
      "ty": 2,
      "x": 1037,
      "y": 130
    },
    {
      "t": 49004,
      "e": 49004,
      "ty": 2,
      "x": 943,
      "y": 189
    },
    {
      "t": 49004,
      "e": 49004,
      "ty": 41,
      "x": 28853,
      "y": 39789,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 49104,
      "e": 49104,
      "ty": 2,
      "x": 935,
      "y": 193
    },
    {
      "t": 49204,
      "e": 49204,
      "ty": 2,
      "x": 923,
      "y": 223
    },
    {
      "t": 49256,
      "e": 49206,
      "ty": 41,
      "x": 29327,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 49304,
      "e": 49254,
      "ty": 2,
      "x": 907,
      "y": 243
    },
    {
      "t": 49404,
      "e": 49354,
      "ty": 2,
      "x": 874,
      "y": 247
    },
    {
      "t": 49504,
      "e": 49454,
      "ty": 2,
      "x": 870,
      "y": 247
    },
    {
      "t": 49505,
      "e": 49455,
      "ty": 41,
      "x": 15224,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 49604,
      "e": 49554,
      "ty": 2,
      "x": 855,
      "y": 221
    },
    {
      "t": 49704,
      "e": 49654,
      "ty": 2,
      "x": 841,
      "y": 191
    },
    {
      "t": 49754,
      "e": 49704,
      "ty": 41,
      "x": 16031,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 49804,
      "e": 49754,
      "ty": 2,
      "x": 841,
      "y": 182
    },
    {
      "t": 49920,
      "e": 49870,
      "ty": 3,
      "x": 841,
      "y": 182,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 49991,
      "e": 49941,
      "ty": 4,
      "x": 16031,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 49991,
      "e": 49941,
      "ty": 5,
      "x": 841,
      "y": 182,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 49991,
      "e": 49941,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 49992,
      "e": 49942,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 50005,
      "e": 49955,
      "ty": 41,
      "x": 16031,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 50104,
      "e": 50054,
      "ty": 2,
      "x": 861,
      "y": 197
    },
    {
      "t": 50204,
      "e": 50154,
      "ty": 2,
      "x": 897,
      "y": 229
    },
    {
      "t": 50254,
      "e": 50204,
      "ty": 41,
      "x": 31207,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-0-2 > label"
    },
    {
      "t": 50304,
      "e": 50254,
      "ty": 2,
      "x": 1003,
      "y": 350
    },
    {
      "t": 50404,
      "e": 50354,
      "ty": 2,
      "x": 1051,
      "y": 443
    },
    {
      "t": 50504,
      "e": 50454,
      "ty": 2,
      "x": 1051,
      "y": 445
    },
    {
      "t": 50505,
      "e": 50455,
      "ty": 41,
      "x": 54484,
      "y": 30426,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 50604,
      "e": 50554,
      "ty": 2,
      "x": 1041,
      "y": 444
    },
    {
      "t": 50704,
      "e": 50654,
      "ty": 2,
      "x": 1032,
      "y": 440
    },
    {
      "t": 50754,
      "e": 50704,
      "ty": 41,
      "x": 49975,
      "y": 18724,
      "ta": "#jspsych-survey-multi-choice-option-1-3"
    },
    {
      "t": 51604,
      "e": 51554,
      "ty": 2,
      "x": 1024,
      "y": 433
    },
    {
      "t": 51704,
      "e": 51654,
      "ty": 2,
      "x": 1007,
      "y": 424
    },
    {
      "t": 51754,
      "e": 51704,
      "ty": 41,
      "x": 44279,
      "y": 42129,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 51805,
      "e": 51755,
      "ty": 2,
      "x": 1005,
      "y": 418
    },
    {
      "t": 51904,
      "e": 51854,
      "ty": 2,
      "x": 1000,
      "y": 415
    },
    {
      "t": 52004,
      "e": 51954,
      "ty": 2,
      "x": 996,
      "y": 413
    },
    {
      "t": 52004,
      "e": 51954,
      "ty": 41,
      "x": 41431,
      "y": 21064,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 52104,
      "e": 52054,
      "ty": 2,
      "x": 986,
      "y": 405
    },
    {
      "t": 52204,
      "e": 52154,
      "ty": 2,
      "x": 971,
      "y": 395
    },
    {
      "t": 52255,
      "e": 52205,
      "ty": 41,
      "x": 33837,
      "y": 35108,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 52304,
      "e": 52254,
      "ty": 2,
      "x": 964,
      "y": 391
    },
    {
      "t": 52704,
      "e": 52654,
      "ty": 2,
      "x": 962,
      "y": 389
    },
    {
      "t": 52755,
      "e": 52705,
      "ty": 41,
      "x": 32413,
      "y": 30426,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 52804,
      "e": 52754,
      "ty": 2,
      "x": 958,
      "y": 389
    },
    {
      "t": 53004,
      "e": 52954,
      "ty": 2,
      "x": 953,
      "y": 389
    },
    {
      "t": 53004,
      "e": 52954,
      "ty": 41,
      "x": 31226,
      "y": 30426,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 53105,
      "e": 53055,
      "ty": 2,
      "x": 950,
      "y": 390
    },
    {
      "t": 53204,
      "e": 53154,
      "ty": 2,
      "x": 949,
      "y": 390
    },
    {
      "t": 53254,
      "e": 53204,
      "ty": 41,
      "x": 26954,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 53304,
      "e": 53254,
      "ty": 2,
      "x": 919,
      "y": 390
    },
    {
      "t": 53404,
      "e": 53354,
      "ty": 2,
      "x": 886,
      "y": 393
    },
    {
      "t": 53504,
      "e": 53454,
      "ty": 2,
      "x": 870,
      "y": 400
    },
    {
      "t": 53504,
      "e": 53454,
      "ty": 41,
      "x": 11528,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 53604,
      "e": 53554,
      "ty": 2,
      "x": 863,
      "y": 420
    },
    {
      "t": 53704,
      "e": 53654,
      "ty": 2,
      "x": 860,
      "y": 424
    },
    {
      "t": 53755,
      "e": 53705,
      "ty": 41,
      "x": 40777,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 53776,
      "e": 53726,
      "ty": 3,
      "x": 860,
      "y": 424,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 53777,
      "e": 53727,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 53879,
      "e": 53829,
      "ty": 4,
      "x": 40777,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 53879,
      "e": 53829,
      "ty": 5,
      "x": 860,
      "y": 425,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 53879,
      "e": 53829,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 53880,
      "e": 53830,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf",
      "v": "Third"
    },
    {
      "t": 53904,
      "e": 53854,
      "ty": 2,
      "x": 860,
      "y": 425
    },
    {
      "t": 54005,
      "e": 53955,
      "ty": 41,
      "x": 40777,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-1-2 > label"
    },
    {
      "t": 54105,
      "e": 54055,
      "ty": 2,
      "x": 884,
      "y": 438
    },
    {
      "t": 54204,
      "e": 54154,
      "ty": 2,
      "x": 908,
      "y": 442
    },
    {
      "t": 54255,
      "e": 54205,
      "ty": 41,
      "x": 32413,
      "y": 25745,
      "ta": "#jspsych-survey-multi-choice-option-1-4"
    },
    {
      "t": 54304,
      "e": 54254,
      "ty": 2,
      "x": 1025,
      "y": 523
    },
    {
      "t": 54404,
      "e": 54354,
      "ty": 2,
      "x": 1060,
      "y": 549
    },
    {
      "t": 54504,
      "e": 54454,
      "ty": 2,
      "x": 1087,
      "y": 569
    },
    {
      "t": 54508,
      "e": 54458,
      "ty": 41,
      "x": 63028,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 54604,
      "e": 54554,
      "ty": 2,
      "x": 1199,
      "y": 621
    },
    {
      "t": 54704,
      "e": 54654,
      "ty": 2,
      "x": 1208,
      "y": 630
    },
    {
      "t": 54754,
      "e": 54704,
      "ty": 41,
      "x": 41325,
      "y": 37970,
      "ta": "html > body"
    },
    {
      "t": 54804,
      "e": 54754,
      "ty": 2,
      "x": 1208,
      "y": 632
    },
    {
      "t": 54903,
      "e": 54853,
      "ty": 2,
      "x": 1204,
      "y": 630
    },
    {
      "t": 55003,
      "e": 54953,
      "ty": 41,
      "x": 41187,
      "y": 37848,
      "ta": "html > body"
    },
    {
      "t": 55754,
      "e": 55704,
      "ty": 41,
      "x": 41153,
      "y": 37848,
      "ta": "html > body"
    },
    {
      "t": 55803,
      "e": 55753,
      "ty": 2,
      "x": 1203,
      "y": 630
    },
    {
      "t": 55903,
      "e": 55853,
      "ty": 2,
      "x": 1196,
      "y": 624
    },
    {
      "t": 56003,
      "e": 55953,
      "ty": 2,
      "x": 1192,
      "y": 621
    },
    {
      "t": 56003,
      "e": 55953,
      "ty": 41,
      "x": 40774,
      "y": 37300,
      "ta": "html > body"
    },
    {
      "t": 56503,
      "e": 56453,
      "ty": 2,
      "x": 1190,
      "y": 617
    },
    {
      "t": 56504,
      "e": 56454,
      "ty": 41,
      "x": 40705,
      "y": 37057,
      "ta": "html > body"
    },
    {
      "t": 56603,
      "e": 56553,
      "ty": 2,
      "x": 1189,
      "y": 616
    },
    {
      "t": 56704,
      "e": 56654,
      "ty": 2,
      "x": 1174,
      "y": 601
    },
    {
      "t": 56753,
      "e": 56703,
      "ty": 41,
      "x": 40119,
      "y": 36022,
      "ta": "html > body"
    },
    {
      "t": 56804,
      "e": 56754,
      "ty": 2,
      "x": 1164,
      "y": 594
    },
    {
      "t": 56903,
      "e": 56853,
      "ty": 2,
      "x": 1157,
      "y": 588
    },
    {
      "t": 57003,
      "e": 56953,
      "ty": 2,
      "x": 1155,
      "y": 585
    },
    {
      "t": 57004,
      "e": 56954,
      "ty": 41,
      "x": 39500,
      "y": 35110,
      "ta": "html > body"
    },
    {
      "t": 57104,
      "e": 57054,
      "ty": 2,
      "x": 1142,
      "y": 563
    },
    {
      "t": 57254,
      "e": 57204,
      "ty": 41,
      "x": 39052,
      "y": 33771,
      "ta": "html > body"
    },
    {
      "t": 58003,
      "e": 57953,
      "ty": 2,
      "x": 1142,
      "y": 559
    },
    {
      "t": 58003,
      "e": 57953,
      "ty": 41,
      "x": 39052,
      "y": 33528,
      "ta": "html > body"
    },
    {
      "t": 58104,
      "e": 58054,
      "ty": 2,
      "x": 1123,
      "y": 547
    },
    {
      "t": 58204,
      "e": 58154,
      "ty": 2,
      "x": 1081,
      "y": 547
    },
    {
      "t": 58254,
      "e": 58204,
      "ty": 41,
      "x": 61604,
      "y": 32804,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 58304,
      "e": 58254,
      "ty": 2,
      "x": 1080,
      "y": 547
    },
    {
      "t": 58403,
      "e": 58353,
      "ty": 2,
      "x": 1072,
      "y": 584
    },
    {
      "t": 58504,
      "e": 58454,
      "ty": 2,
      "x": 1064,
      "y": 596
    },
    {
      "t": 58504,
      "e": 58454,
      "ty": 41,
      "x": 57569,
      "y": 9207,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 58604,
      "e": 58554,
      "ty": 2,
      "x": 1054,
      "y": 607
    },
    {
      "t": 58703,
      "e": 58653,
      "ty": 2,
      "x": 1037,
      "y": 647
    },
    {
      "t": 58754,
      "e": 58704,
      "ty": 41,
      "x": 54069,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 58803,
      "e": 58753,
      "ty": 2,
      "x": 1036,
      "y": 651
    },
    {
      "t": 58904,
      "e": 58854,
      "ty": 2,
      "x": 1015,
      "y": 648
    },
    {
      "t": 59004,
      "e": 58954,
      "ty": 2,
      "x": 951,
      "y": 673
    },
    {
      "t": 59004,
      "e": 58954,
      "ty": 41,
      "x": 32522,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 59104,
      "e": 59054,
      "ty": 2,
      "x": 936,
      "y": 689
    },
    {
      "t": 59203,
      "e": 59153,
      "ty": 2,
      "x": 932,
      "y": 697
    },
    {
      "t": 59254,
      "e": 59204,
      "ty": 41,
      "x": 46139,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 59403,
      "e": 59353,
      "ty": 2,
      "x": 916,
      "y": 715
    },
    {
      "t": 59504,
      "e": 59454,
      "ty": 2,
      "x": 906,
      "y": 719
    },
    {
      "t": 59504,
      "e": 59454,
      "ty": 41,
      "x": 20072,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 59604,
      "e": 59554,
      "ty": 2,
      "x": 905,
      "y": 721
    },
    {
      "t": 59703,
      "e": 59653,
      "ty": 2,
      "x": 905,
      "y": 725
    },
    {
      "t": 59754,
      "e": 59704,
      "ty": 41,
      "x": 46789,
      "y": 6553,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 59803,
      "e": 59753,
      "ty": 2,
      "x": 905,
      "y": 726
    },
    {
      "t": 59905,
      "e": 59855,
      "ty": 2,
      "x": 906,
      "y": 725
    },
    {
      "t": 60003,
      "e": 59953,
      "ty": 2,
      "x": 914,
      "y": 702
    },
    {
      "t": 60003,
      "e": 59953,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 60004,
      "e": 59954,
      "ty": 41,
      "x": 38628,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 60103,
      "e": 60053,
      "ty": 2,
      "x": 914,
      "y": 692
    },
    {
      "t": 60203,
      "e": 60153,
      "ty": 2,
      "x": 913,
      "y": 681
    },
    {
      "t": 60254,
      "e": 60204,
      "ty": 41,
      "x": 22984,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 60360,
      "e": 60310,
      "ty": 3,
      "x": 913,
      "y": 681,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 60361,
      "e": 60311,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 60399,
      "e": 60349,
      "ty": 4,
      "x": 22984,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 60399,
      "e": 60349,
      "ty": 5,
      "x": 913,
      "y": 681,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 60399,
      "e": 60349,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 60399,
      "e": 60349,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf",
      "v": "Biomedical & Health Sciences"
    },
    {
      "t": 60703,
      "e": 60653,
      "ty": 2,
      "x": 952,
      "y": 740
    },
    {
      "t": 60753,
      "e": 60703,
      "ty": 41,
      "x": 34786,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 60803,
      "e": 60753,
      "ty": 2,
      "x": 1019,
      "y": 854
    },
    {
      "t": 60903,
      "e": 60853,
      "ty": 2,
      "x": 1028,
      "y": 869
    },
    {
      "t": 61004,
      "e": 60954,
      "ty": 2,
      "x": 1029,
      "y": 870
    },
    {
      "t": 61004,
      "e": 60954,
      "ty": 41,
      "x": 49263,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 61103,
      "e": 61053,
      "ty": 2,
      "x": 1024,
      "y": 871
    },
    {
      "t": 61203,
      "e": 61153,
      "ty": 2,
      "x": 1001,
      "y": 864
    },
    {
      "t": 61254,
      "e": 61204,
      "ty": 41,
      "x": 39533,
      "y": 19156,
      "ta": "#jspsych-survey-multi-choice-3"
    },
    {
      "t": 61304,
      "e": 61254,
      "ty": 2,
      "x": 976,
      "y": 859
    },
    {
      "t": 61403,
      "e": 61353,
      "ty": 2,
      "x": 944,
      "y": 904
    },
    {
      "t": 61504,
      "e": 61454,
      "ty": 41,
      "x": 29090,
      "y": 18724,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 61603,
      "e": 61553,
      "ty": 2,
      "x": 939,
      "y": 898
    },
    {
      "t": 61704,
      "e": 61654,
      "ty": 2,
      "x": 928,
      "y": 890
    },
    {
      "t": 61754,
      "e": 61704,
      "ty": 41,
      "x": 21733,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 61803,
      "e": 61753,
      "ty": 2,
      "x": 907,
      "y": 896
    },
    {
      "t": 61904,
      "e": 61854,
      "ty": 2,
      "x": 884,
      "y": 911
    },
    {
      "t": 62004,
      "e": 61954,
      "ty": 41,
      "x": 50620,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 62023,
      "e": 61973,
      "ty": 3,
      "x": 884,
      "y": 911,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 62023,
      "e": 61973,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 62119,
      "e": 62069,
      "ty": 4,
      "x": 50620,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 62120,
      "e": 62070,
      "ty": 5,
      "x": 884,
      "y": 911,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 62121,
      "e": 62071,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 62123,
      "e": 62073,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 62204,
      "e": 62154,
      "ty": 2,
      "x": 883,
      "y": 912
    },
    {
      "t": 62254,
      "e": 62204,
      "ty": 41,
      "x": 49811,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 62303,
      "e": 62253,
      "ty": 2,
      "x": 888,
      "y": 929
    },
    {
      "t": 62403,
      "e": 62353,
      "ty": 2,
      "x": 893,
      "y": 941
    },
    {
      "t": 62504,
      "e": 62454,
      "ty": 2,
      "x": 900,
      "y": 948
    },
    {
      "t": 62504,
      "e": 62454,
      "ty": 41,
      "x": 18648,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 62604,
      "e": 62554,
      "ty": 2,
      "x": 900,
      "y": 951
    },
    {
      "t": 62719,
      "e": 62669,
      "ty": 3,
      "x": 900,
      "y": 951,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 62721,
      "e": 62671,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 62753,
      "e": 62703,
      "ty": 41,
      "x": 18648,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 62815,
      "e": 62765,
      "ty": 4,
      "x": 18648,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 62815,
      "e": 62765,
      "ty": 5,
      "x": 900,
      "y": 951,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 63000,
      "e": 62950,
      "ty": 6,
      "x": 900,
      "y": 952,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 63004,
      "e": 62954,
      "ty": 2,
      "x": 900,
      "y": 952
    },
    {
      "t": 63004,
      "e": 62954,
      "ty": 41,
      "x": 36375,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 63204,
      "e": 63154,
      "ty": 2,
      "x": 901,
      "y": 952
    },
    {
      "t": 63254,
      "e": 63204,
      "ty": 41,
      "x": 36890,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 63264,
      "e": 63214,
      "ty": 3,
      "x": 901,
      "y": 952,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 63265,
      "e": 63215,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 63366,
      "e": 63316,
      "ty": 4,
      "x": 36890,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 63366,
      "e": 63316,
      "ty": 5,
      "x": 901,
      "y": 952,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 63370,
      "e": 63320,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 63370,
      "e": 63320,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 63371,
      "e": 63321,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 63604,
      "e": 63554,
      "ty": 2,
      "x": 902,
      "y": 952
    },
    {
      "t": 63754,
      "e": 63704,
      "ty": 41,
      "x": 30787,
      "y": 57442,
      "ta": "html > body"
    },
    {
      "t": 64104,
      "e": 64054,
      "ty": 2,
      "x": 899,
      "y": 952
    },
    {
      "t": 64254,
      "e": 64204,
      "ty": 41,
      "x": 30856,
      "y": 55920,
      "ta": "html > body"
    },
    {
      "t": 64304,
      "e": 64254,
      "ty": 2,
      "x": 908,
      "y": 902
    },
    {
      "t": 64404,
      "e": 64354,
      "ty": 2,
      "x": 900,
      "y": 771
    },
    {
      "t": 64503,
      "e": 64453,
      "ty": 2,
      "x": 856,
      "y": 680
    },
    {
      "t": 64503,
      "e": 64453,
      "ty": 41,
      "x": 29203,
      "y": 40890,
      "ta": "html > body"
    },
    {
      "t": 64604,
      "e": 64554,
      "ty": 2,
      "x": 778,
      "y": 598
    },
    {
      "t": 64693,
      "e": 64643,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 64703,
      "e": 64653,
      "ty": 2,
      "x": 735,
      "y": 552
    },
    {
      "t": 64754,
      "e": 64653,
      "ty": 41,
      "x": 21575,
      "y": 46615,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 64804,
      "e": 64703,
      "ty": 2,
      "x": 732,
      "y": 549
    },
    {
      "t": 64904,
      "e": 64803,
      "ty": 2,
      "x": 723,
      "y": 533
    },
    {
      "t": 65004,
      "e": 64903,
      "ty": 2,
      "x": 723,
      "y": 532
    },
    {
      "t": 65004,
      "e": 64903,
      "ty": 41,
      "x": 21132,
      "y": 39984,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 65204,
      "e": 65103,
      "ty": 2,
      "x": 729,
      "y": 531
    },
    {
      "t": 65254,
      "e": 65153,
      "ty": 41,
      "x": 23789,
      "y": 47785,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 65304,
      "e": 65203,
      "ty": 2,
      "x": 793,
      "y": 562
    },
    {
      "t": 65404,
      "e": 65303,
      "ty": 2,
      "x": 793,
      "y": 564
    },
    {
      "t": 65504,
      "e": 65403,
      "ty": 2,
      "x": 880,
      "y": 742
    },
    {
      "t": 65505,
      "e": 65404,
      "ty": 41,
      "x": 28856,
      "y": 53319,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 65603,
      "e": 65502,
      "ty": 2,
      "x": 883,
      "y": 752
    },
    {
      "t": 65704,
      "e": 65603,
      "ty": 2,
      "x": 953,
      "y": 904
    },
    {
      "t": 65754,
      "e": 65653,
      "ty": 41,
      "x": 32546,
      "y": 63534,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 65772,
      "e": 65671,
      "ty": 6,
      "x": 955,
      "y": 983,
      "ta": "#start"
    },
    {
      "t": 65803,
      "e": 65702,
      "ty": 2,
      "x": 955,
      "y": 987
    },
    {
      "t": 65904,
      "e": 65803,
      "ty": 2,
      "x": 952,
      "y": 1001
    },
    {
      "t": 66004,
      "e": 65903,
      "ty": 2,
      "x": 952,
      "y": 1003
    },
    {
      "t": 66004,
      "e": 65903,
      "ty": 41,
      "x": 23210,
      "y": 49542,
      "ta": "#start"
    },
    {
      "t": 66104,
      "e": 66003,
      "ty": 2,
      "x": 951,
      "y": 1003
    },
    {
      "t": 66204,
      "e": 66103,
      "ty": 2,
      "x": 941,
      "y": 981
    },
    {
      "t": 66224,
      "e": 66123,
      "ty": 3,
      "x": 941,
      "y": 981,
      "ta": "#start"
    },
    {
      "t": 66224,
      "e": 66123,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 66254,
      "e": 66153,
      "ty": 41,
      "x": 17202,
      "y": 7137,
      "ta": "#start"
    },
    {
      "t": 66326,
      "e": 66225,
      "ty": 4,
      "x": 17202,
      "y": 7137,
      "ta": "#start"
    },
    {
      "t": 66327,
      "e": 66226,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 66327,
      "e": 66226,
      "ty": 5,
      "x": 941,
      "y": 981,
      "ta": "#start"
    },
    {
      "t": 66328,
      "e": 66227,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 66904,
      "e": 66803,
      "ty": 2,
      "x": 940,
      "y": 980
    },
    {
      "t": 67004,
      "e": 66903,
      "ty": 41,
      "x": 32095,
      "y": 59145,
      "ta": "html > body"
    },
    {
      "t": 67104,
      "e": 67003,
      "ty": 2,
      "x": 925,
      "y": 965
    },
    {
      "t": 67204,
      "e": 67103,
      "ty": 2,
      "x": 798,
      "y": 639
    },
    {
      "t": 67248,
      "e": 67147,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 67254,
      "e": 67153,
      "ty": 41,
      "x": 16426,
      "y": 365,
      "ta": "html > body"
    },
    {
      "t": 67304,
      "e": 67203,
      "ty": 2,
      "x": 485,
      "y": 14
    },
    {
      "t": 67360,
      "e": 67259,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 68828,
      "e": 68727,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 1673, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 1679, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"8182H\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 2497, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 5280, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"8182H\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 12922, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"zulu\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"211\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 19208, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"8182H\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 2868, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 23175, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"8182H\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 11059, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 35236, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"8182H\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 28487, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 65021, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"8182H\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-08 AM-09 AM-10 AM-11 AM-12 PM-11 AM-A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:564,y:842,t:1528143515271};\\\", \\\"{x:569,y:844,t:1528143517572};\\\", \\\"{x:575,y:846,t:1528143517578};\\\", \\\"{x:583,y:850,t:1528143517590};\\\", \\\"{x:597,y:852,t:1528143517607};\\\", \\\"{x:619,y:852,t:1528143517624};\\\", \\\"{x:638,y:852,t:1528143517640};\\\", \\\"{x:653,y:852,t:1528143517657};\\\", \\\"{x:665,y:852,t:1528143517674};\\\", \\\"{x:674,y:854,t:1528143517690};\\\", \\\"{x:708,y:861,t:1528143517707};\\\", \\\"{x:735,y:863,t:1528143517724};\\\", \\\"{x:780,y:870,t:1528143517740};\\\", \\\"{x:836,y:878,t:1528143517757};\\\", \\\"{x:883,y:884,t:1528143517774};\\\", \\\"{x:934,y:892,t:1528143517791};\\\", \\\"{x:984,y:899,t:1528143517807};\\\", \\\"{x:1030,y:907,t:1528143517824};\\\", \\\"{x:1054,y:910,t:1528143517841};\\\", \\\"{x:1067,y:912,t:1528143517857};\\\", \\\"{x:1072,y:913,t:1528143517874};\\\", \\\"{x:1079,y:915,t:1528143517890};\\\", \\\"{x:1087,y:917,t:1528143517907};\\\", \\\"{x:1093,y:919,t:1528143517924};\\\", \\\"{x:1107,y:920,t:1528143517941};\\\", \\\"{x:1122,y:921,t:1528143517957};\\\", \\\"{x:1139,y:921,t:1528143517974};\\\", \\\"{x:1157,y:921,t:1528143517991};\\\", \\\"{x:1175,y:924,t:1528143518008};\\\", \\\"{x:1198,y:926,t:1528143518025};\\\", \\\"{x:1220,y:926,t:1528143518041};\\\", \\\"{x:1234,y:927,t:1528143518057};\\\", \\\"{x:1242,y:927,t:1528143518075};\\\", \\\"{x:1245,y:927,t:1528143518091};\\\", \\\"{x:1246,y:927,t:1528143518219};\\\", \\\"{x:1247,y:927,t:1528143518243};\\\", \\\"{x:1249,y:927,t:1528143518636};\\\", \\\"{x:1254,y:928,t:1528143518644};\\\", \\\"{x:1265,y:928,t:1528143518659};\\\", \\\"{x:1280,y:930,t:1528143518675};\\\", \\\"{x:1282,y:930,t:1528143518692};\\\", \\\"{x:1283,y:930,t:1528143519172};\\\", \\\"{x:1283,y:929,t:1528143519187};\\\", \\\"{x:1283,y:927,t:1528143519195};\\\", \\\"{x:1283,y:926,t:1528143520044};\\\", \\\"{x:1278,y:919,t:1528143520282};\\\", \\\"{x:1277,y:914,t:1528143520292};\\\", \\\"{x:1272,y:905,t:1528143520309};\\\", \\\"{x:1266,y:891,t:1528143520327};\\\", \\\"{x:1262,y:882,t:1528143520342};\\\", \\\"{x:1257,y:874,t:1528143520359};\\\", \\\"{x:1255,y:868,t:1528143520376};\\\", \\\"{x:1254,y:863,t:1528143520392};\\\", \\\"{x:1254,y:861,t:1528143520410};\\\", \\\"{x:1253,y:858,t:1528143520427};\\\", \\\"{x:1253,y:856,t:1528143520443};\\\", \\\"{x:1252,y:853,t:1528143520459};\\\", \\\"{x:1251,y:852,t:1528143521381};\\\", \\\"{x:1250,y:852,t:1528143521394};\\\", \\\"{x:1248,y:857,t:1528143521411};\\\", \\\"{x:1248,y:861,t:1528143521428};\\\", \\\"{x:1247,y:867,t:1528143521443};\\\", \\\"{x:1247,y:871,t:1528143521460};\\\", \\\"{x:1247,y:874,t:1528143521477};\\\", \\\"{x:1247,y:876,t:1528143521493};\\\", \\\"{x:1247,y:878,t:1528143521510};\\\", \\\"{x:1247,y:879,t:1528143521527};\\\", \\\"{x:1247,y:880,t:1528143521543};\\\", \\\"{x:1247,y:882,t:1528143521560};\\\", \\\"{x:1247,y:883,t:1528143521577};\\\", \\\"{x:1247,y:887,t:1528143521593};\\\", \\\"{x:1247,y:893,t:1528143521611};\\\", \\\"{x:1247,y:895,t:1528143521627};\\\", \\\"{x:1247,y:898,t:1528143521643};\\\", \\\"{x:1247,y:899,t:1528143521660};\\\", \\\"{x:1247,y:900,t:1528143521677};\\\", \\\"{x:1248,y:901,t:1528143521693};\\\", \\\"{x:1248,y:902,t:1528143521715};\\\", \\\"{x:1252,y:902,t:1528143522757};\\\", \\\"{x:1256,y:902,t:1528143522764};\\\", \\\"{x:1266,y:902,t:1528143522779};\\\", \\\"{x:1287,y:902,t:1528143522796};\\\", \\\"{x:1301,y:903,t:1528143522811};\\\", \\\"{x:1311,y:906,t:1528143522829};\\\", \\\"{x:1316,y:906,t:1528143522845};\\\", \\\"{x:1318,y:907,t:1528143522862};\\\", \\\"{x:1319,y:907,t:1528143522878};\\\", \\\"{x:1320,y:907,t:1528143522895};\\\", \\\"{x:1323,y:909,t:1528143522912};\\\", \\\"{x:1327,y:910,t:1528143522927};\\\", \\\"{x:1331,y:910,t:1528143522944};\\\", \\\"{x:1335,y:911,t:1528143522962};\\\", \\\"{x:1337,y:912,t:1528143522978};\\\", \\\"{x:1340,y:914,t:1528143522995};\\\", \\\"{x:1342,y:914,t:1528143523027};\\\", \\\"{x:1344,y:916,t:1528143523043};\\\", \\\"{x:1345,y:917,t:1528143523058};\\\", \\\"{x:1347,y:918,t:1528143523066};\\\", \\\"{x:1348,y:918,t:1528143523078};\\\", \\\"{x:1350,y:919,t:1528143523095};\\\", \\\"{x:1351,y:919,t:1528143523112};\\\", \\\"{x:1346,y:917,t:1528143524108};\\\", \\\"{x:1341,y:915,t:1528143524116};\\\", \\\"{x:1334,y:914,t:1528143524130};\\\", \\\"{x:1322,y:914,t:1528143524146};\\\", \\\"{x:1307,y:914,t:1528143524164};\\\", \\\"{x:1303,y:914,t:1528143524179};\\\", \\\"{x:1302,y:914,t:1528143524196};\\\", \\\"{x:1299,y:914,t:1528143524460};\\\", \\\"{x:1297,y:916,t:1528143524468};\\\", \\\"{x:1295,y:918,t:1528143524478};\\\", \\\"{x:1291,y:922,t:1528143524496};\\\", \\\"{x:1289,y:924,t:1528143524513};\\\", \\\"{x:1287,y:926,t:1528143524530};\\\", \\\"{x:1284,y:927,t:1528143524545};\\\", \\\"{x:1284,y:928,t:1528143524563};\\\", \\\"{x:1283,y:928,t:1528143524828};\\\", \\\"{x:1283,y:924,t:1528143524835};\\\", \\\"{x:1281,y:920,t:1528143524846};\\\", \\\"{x:1280,y:914,t:1528143524862};\\\", \\\"{x:1277,y:902,t:1528143524879};\\\", \\\"{x:1275,y:890,t:1528143524896};\\\", \\\"{x:1271,y:878,t:1528143524913};\\\", \\\"{x:1266,y:862,t:1528143524930};\\\", \\\"{x:1264,y:849,t:1528143524946};\\\", \\\"{x:1259,y:833,t:1528143524963};\\\", \\\"{x:1258,y:824,t:1528143524980};\\\", \\\"{x:1256,y:815,t:1528143524996};\\\", \\\"{x:1256,y:812,t:1528143525013};\\\", \\\"{x:1256,y:808,t:1528143525030};\\\", \\\"{x:1256,y:805,t:1528143525046};\\\", \\\"{x:1256,y:801,t:1528143525063};\\\", \\\"{x:1256,y:798,t:1528143525079};\\\", \\\"{x:1257,y:794,t:1528143525097};\\\", \\\"{x:1259,y:790,t:1528143525113};\\\", \\\"{x:1260,y:788,t:1528143525130};\\\", \\\"{x:1264,y:785,t:1528143525146};\\\", \\\"{x:1265,y:784,t:1528143525162};\\\", \\\"{x:1268,y:782,t:1528143525180};\\\", \\\"{x:1269,y:781,t:1528143525197};\\\", \\\"{x:1271,y:781,t:1528143525213};\\\", \\\"{x:1271,y:780,t:1528143525230};\\\", \\\"{x:1274,y:778,t:1528143525247};\\\", \\\"{x:1276,y:777,t:1528143525265};\\\", \\\"{x:1278,y:775,t:1528143525280};\\\", \\\"{x:1283,y:772,t:1528143525296};\\\", \\\"{x:1285,y:771,t:1528143525313};\\\", \\\"{x:1287,y:769,t:1528143525329};\\\", \\\"{x:1288,y:768,t:1528143525347};\\\", \\\"{x:1288,y:769,t:1528143527932};\\\", \\\"{x:1260,y:766,t:1528143527949};\\\", \\\"{x:1184,y:751,t:1528143527965};\\\", \\\"{x:1081,y:739,t:1528143527982};\\\", \\\"{x:963,y:725,t:1528143527999};\\\", \\\"{x:865,y:709,t:1528143528014};\\\", \\\"{x:785,y:698,t:1528143528031};\\\", \\\"{x:743,y:693,t:1528143528048};\\\", \\\"{x:726,y:691,t:1528143528065};\\\", \\\"{x:724,y:691,t:1528143528082};\\\", \\\"{x:723,y:690,t:1528143528187};\\\", \\\"{x:720,y:689,t:1528143528199};\\\", \\\"{x:703,y:681,t:1528143528215};\\\", \\\"{x:678,y:666,t:1528143528232};\\\", \\\"{x:620,y:629,t:1528143528249};\\\", \\\"{x:578,y:606,t:1528143528265};\\\", \\\"{x:535,y:591,t:1528143528284};\\\", \\\"{x:461,y:557,t:1528143528299};\\\", \\\"{x:421,y:543,t:1528143528314};\\\", \\\"{x:407,y:537,t:1528143528332};\\\", \\\"{x:401,y:532,t:1528143528349};\\\", \\\"{x:399,y:530,t:1528143528366};\\\", \\\"{x:396,y:527,t:1528143528383};\\\", \\\"{x:395,y:524,t:1528143528399};\\\", \\\"{x:394,y:521,t:1528143528416};\\\", \\\"{x:394,y:519,t:1528143528433};\\\", \\\"{x:393,y:517,t:1528143528449};\\\", \\\"{x:393,y:514,t:1528143528466};\\\", \\\"{x:393,y:510,t:1528143528483};\\\", \\\"{x:393,y:508,t:1528143528500};\\\", \\\"{x:393,y:504,t:1528143528516};\\\", \\\"{x:393,y:502,t:1528143528533};\\\", \\\"{x:393,y:501,t:1528143528550};\\\", \\\"{x:392,y:500,t:1528143528939};\\\", \\\"{x:391,y:500,t:1528143529026};\\\", \\\"{x:390,y:500,t:1528143529058};\\\", \\\"{x:389,y:501,t:1528143529066};\\\", \\\"{x:387,y:503,t:1528143529083};\\\", \\\"{x:386,y:505,t:1528143529100};\\\", \\\"{x:385,y:507,t:1528143529116};\\\", \\\"{x:384,y:507,t:1528143529132};\\\", \\\"{x:383,y:508,t:1528143529149};\\\", \\\"{x:383,y:509,t:1528143529166};\\\", \\\"{x:382,y:510,t:1528143529183};\\\", \\\"{x:382,y:511,t:1528143529203};\\\", \\\"{x:380,y:512,t:1528143541079};\\\", \\\"{x:372,y:516,t:1528143541087};\\\", \\\"{x:366,y:517,t:1528143541103};\\\", \\\"{x:365,y:518,t:1528143541119};\\\", \\\"{x:365,y:519,t:1528143541486};\\\", \\\"{x:365,y:520,t:1528143541501};\\\", \\\"{x:366,y:521,t:1528143541517};\\\", \\\"{x:367,y:521,t:1528143541533};\\\", \\\"{x:368,y:522,t:1528143541547};\\\", \\\"{x:369,y:522,t:1528143541662};\\\", \\\"{x:371,y:522,t:1528143541710};\\\", \\\"{x:375,y:518,t:1528143541719};\\\", \\\"{x:377,y:514,t:1528143541731};\\\", \\\"{x:384,y:500,t:1528143541746};\\\", \\\"{x:387,y:489,t:1528143541764};\\\", \\\"{x:394,y:476,t:1528143541781};\\\", \\\"{x:398,y:465,t:1528143541796};\\\", \\\"{x:401,y:454,t:1528143541813};\\\", \\\"{x:402,y:446,t:1528143541830};\\\", \\\"{x:403,y:442,t:1528143541846};\\\", \\\"{x:403,y:438,t:1528143541863};\\\", \\\"{x:403,y:434,t:1528143541880};\\\", \\\"{x:403,y:430,t:1528143541897};\\\", \\\"{x:403,y:429,t:1528143541913};\\\", \\\"{x:404,y:431,t:1528143541973};\\\", \\\"{x:404,y:432,t:1528143541981};\\\", \\\"{x:405,y:437,t:1528143541998};\\\", \\\"{x:408,y:442,t:1528143542013};\\\", \\\"{x:412,y:447,t:1528143542031};\\\", \\\"{x:418,y:457,t:1528143542047};\\\", \\\"{x:422,y:466,t:1528143542063};\\\", \\\"{x:426,y:475,t:1528143542080};\\\", \\\"{x:427,y:481,t:1528143542097};\\\", \\\"{x:427,y:488,t:1528143542113};\\\", \\\"{x:429,y:491,t:1528143542130};\\\", \\\"{x:429,y:492,t:1528143542149};\\\", \\\"{x:427,y:492,t:1528143542181};\\\", \\\"{x:426,y:493,t:1528143542197};\\\", \\\"{x:425,y:493,t:1528143542229};\\\", \\\"{x:424,y:493,t:1528143542237};\\\", \\\"{x:422,y:493,t:1528143542247};\\\", \\\"{x:413,y:489,t:1528143542263};\\\", \\\"{x:398,y:483,t:1528143542281};\\\", \\\"{x:379,y:477,t:1528143542297};\\\", \\\"{x:360,y:472,t:1528143542314};\\\", \\\"{x:353,y:472,t:1528143542330};\\\", \\\"{x:351,y:472,t:1528143542347};\\\", \\\"{x:349,y:472,t:1528143542364};\\\", \\\"{x:349,y:470,t:1528143542389};\\\", \\\"{x:349,y:469,t:1528143542397};\\\", \\\"{x:350,y:469,t:1528143542413};\\\", \\\"{x:352,y:468,t:1528143542431};\\\", \\\"{x:353,y:468,t:1528143542542};\\\", \\\"{x:355,y:468,t:1528143542558};\\\", \\\"{x:356,y:468,t:1528143542574};\\\", \\\"{x:357,y:468,t:1528143542598};\\\", \\\"{x:359,y:468,t:1528143542613};\\\", \\\"{x:362,y:468,t:1528143542631};\\\", \\\"{x:368,y:468,t:1528143542648};\\\", \\\"{x:373,y:468,t:1528143542665};\\\", \\\"{x:380,y:468,t:1528143542681};\\\", \\\"{x:384,y:468,t:1528143542697};\\\", \\\"{x:388,y:468,t:1528143542714};\\\", \\\"{x:390,y:468,t:1528143542730};\\\", \\\"{x:392,y:466,t:1528143542789};\\\", \\\"{x:393,y:466,t:1528143542941};\\\", \\\"{x:394,y:466,t:1528143542965};\\\", \\\"{x:395,y:467,t:1528143543005};\\\", \\\"{x:395,y:468,t:1528143543014};\\\", \\\"{x:395,y:473,t:1528143543031};\\\", \\\"{x:395,y:478,t:1528143543048};\\\", \\\"{x:395,y:486,t:1528143543065};\\\", \\\"{x:395,y:492,t:1528143543082};\\\", \\\"{x:395,y:501,t:1528143543097};\\\", \\\"{x:395,y:509,t:1528143543114};\\\", \\\"{x:395,y:514,t:1528143543131};\\\", \\\"{x:396,y:523,t:1528143543147};\\\", \\\"{x:402,y:540,t:1528143543165};\\\", \\\"{x:412,y:566,t:1528143543182};\\\", \\\"{x:418,y:582,t:1528143543199};\\\", \\\"{x:422,y:594,t:1528143543214};\\\", \\\"{x:424,y:599,t:1528143543231};\\\", \\\"{x:425,y:601,t:1528143543248};\\\", \\\"{x:426,y:603,t:1528143543264};\\\", \\\"{x:427,y:604,t:1528143543281};\\\", \\\"{x:429,y:606,t:1528143543297};\\\", \\\"{x:430,y:607,t:1528143543314};\\\", \\\"{x:435,y:613,t:1528143543331};\\\", \\\"{x:445,y:625,t:1528143543347};\\\", \\\"{x:451,y:635,t:1528143543364};\\\", \\\"{x:456,y:641,t:1528143543381};\\\", \\\"{x:457,y:642,t:1528143543397};\\\", \\\"{x:457,y:643,t:1528143543414};\\\", \\\"{x:458,y:643,t:1528143543431};\\\", \\\"{x:459,y:644,t:1528143543447};\\\", \\\"{x:459,y:646,t:1528143543464};\\\", \\\"{x:459,y:647,t:1528143543481};\\\", \\\"{x:459,y:654,t:1528143543499};\\\", \\\"{x:463,y:661,t:1528143543514};\\\", \\\"{x:465,y:669,t:1528143543530};\\\", \\\"{x:466,y:671,t:1528143543547};\\\", \\\"{x:467,y:672,t:1528143543563};\\\", \\\"{x:468,y:672,t:1528143543646};\\\", \\\"{x:469,y:672,t:1528143543678};\\\", \\\"{x:470,y:672,t:1528143543701};\\\", \\\"{x:471,y:672,t:1528143543715};\\\", \\\"{x:472,y:672,t:1528143543780};\\\", \\\"{x:465,y:672,t:1528143543949};\\\", \\\"{x:446,y:672,t:1528143543965};\\\", \\\"{x:417,y:673,t:1528143543981};\\\", \\\"{x:386,y:680,t:1528143543998};\\\", \\\"{x:357,y:684,t:1528143544015};\\\", \\\"{x:332,y:689,t:1528143544031};\\\", \\\"{x:322,y:690,t:1528143544048};\\\", \\\"{x:316,y:690,t:1528143544065};\\\", \\\"{x:314,y:690,t:1528143544082};\\\", \\\"{x:313,y:691,t:1528143544622};\\\" ] }, { \\\"rt\\\": 12559, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 78899, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"8182H\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:313,y:693,t:1528143548870};\\\", \\\"{x:335,y:699,t:1528143548884};\\\", \\\"{x:361,y:700,t:1528143548901};\\\", \\\"{x:387,y:705,t:1528143548918};\\\", \\\"{x:411,y:709,t:1528143548936};\\\", \\\"{x:424,y:709,t:1528143548952};\\\", \\\"{x:434,y:708,t:1528143548968};\\\", \\\"{x:451,y:705,t:1528143548985};\\\", \\\"{x:487,y:701,t:1528143549003};\\\", \\\"{x:588,y:695,t:1528143549018};\\\", \\\"{x:722,y:686,t:1528143549035};\\\", \\\"{x:902,y:659,t:1528143549052};\\\", \\\"{x:1098,y:639,t:1528143549069};\\\", \\\"{x:1361,y:634,t:1528143549085};\\\", \\\"{x:1469,y:634,t:1528143549103};\\\", \\\"{x:1539,y:635,t:1528143549118};\\\", \\\"{x:1568,y:638,t:1528143549136};\\\", \\\"{x:1578,y:638,t:1528143549153};\\\", \\\"{x:1584,y:638,t:1528143549169};\\\", \\\"{x:1601,y:638,t:1528143549185};\\\", \\\"{x:1631,y:638,t:1528143549202};\\\", \\\"{x:1670,y:638,t:1528143549218};\\\", \\\"{x:1696,y:638,t:1528143549235};\\\", \\\"{x:1707,y:638,t:1528143549253};\\\", \\\"{x:1707,y:637,t:1528143549285};\\\", \\\"{x:1689,y:636,t:1528143549302};\\\", \\\"{x:1660,y:640,t:1528143549319};\\\", \\\"{x:1632,y:652,t:1528143549335};\\\", \\\"{x:1607,y:666,t:1528143549352};\\\", \\\"{x:1581,y:677,t:1528143549368};\\\", \\\"{x:1566,y:689,t:1528143549385};\\\", \\\"{x:1546,y:705,t:1528143549402};\\\", \\\"{x:1525,y:722,t:1528143549419};\\\", \\\"{x:1503,y:742,t:1528143549435};\\\", \\\"{x:1475,y:773,t:1528143549453};\\\", \\\"{x:1429,y:825,t:1528143549469};\\\", \\\"{x:1400,y:847,t:1528143549485};\\\", \\\"{x:1386,y:856,t:1528143549503};\\\", \\\"{x:1382,y:859,t:1528143549520};\\\", \\\"{x:1380,y:860,t:1528143549535};\\\", \\\"{x:1378,y:860,t:1528143549639};\\\", \\\"{x:1376,y:860,t:1528143549662};\\\", \\\"{x:1373,y:860,t:1528143549670};\\\", \\\"{x:1373,y:861,t:1528143549686};\\\", \\\"{x:1372,y:860,t:1528143549807};\\\", \\\"{x:1372,y:855,t:1528143549820};\\\", \\\"{x:1372,y:847,t:1528143549836};\\\", \\\"{x:1372,y:842,t:1528143549853};\\\", \\\"{x:1376,y:831,t:1528143549870};\\\", \\\"{x:1379,y:825,t:1528143549886};\\\", \\\"{x:1382,y:820,t:1528143549903};\\\", \\\"{x:1386,y:814,t:1528143549920};\\\", \\\"{x:1390,y:806,t:1528143549937};\\\", \\\"{x:1396,y:800,t:1528143549954};\\\", \\\"{x:1401,y:793,t:1528143549970};\\\", \\\"{x:1404,y:788,t:1528143549987};\\\", \\\"{x:1406,y:784,t:1528143550003};\\\", \\\"{x:1407,y:782,t:1528143550020};\\\", \\\"{x:1407,y:779,t:1528143550037};\\\", \\\"{x:1408,y:775,t:1528143550053};\\\", \\\"{x:1408,y:765,t:1528143550070};\\\", \\\"{x:1408,y:752,t:1528143550087};\\\", \\\"{x:1407,y:743,t:1528143550103};\\\", \\\"{x:1406,y:735,t:1528143550120};\\\", \\\"{x:1405,y:730,t:1528143550137};\\\", \\\"{x:1405,y:726,t:1528143550153};\\\", \\\"{x:1405,y:719,t:1528143550170};\\\", \\\"{x:1405,y:711,t:1528143550187};\\\", \\\"{x:1412,y:703,t:1528143550203};\\\", \\\"{x:1418,y:693,t:1528143550220};\\\", \\\"{x:1425,y:685,t:1528143550237};\\\", \\\"{x:1431,y:679,t:1528143550253};\\\", \\\"{x:1442,y:668,t:1528143550270};\\\", \\\"{x:1454,y:662,t:1528143550287};\\\", \\\"{x:1471,y:656,t:1528143550303};\\\", \\\"{x:1491,y:651,t:1528143550319};\\\", \\\"{x:1513,y:648,t:1528143550336};\\\", \\\"{x:1535,y:646,t:1528143550352};\\\", \\\"{x:1556,y:643,t:1528143550369};\\\", \\\"{x:1578,y:642,t:1528143550387};\\\", \\\"{x:1595,y:642,t:1528143550403};\\\", \\\"{x:1612,y:642,t:1528143550419};\\\", \\\"{x:1624,y:642,t:1528143550437};\\\", \\\"{x:1637,y:642,t:1528143550453};\\\", \\\"{x:1640,y:642,t:1528143550469};\\\", \\\"{x:1640,y:641,t:1528143550647};\\\", \\\"{x:1640,y:640,t:1528143550661};\\\", \\\"{x:1635,y:631,t:1528143550670};\\\", \\\"{x:1598,y:572,t:1528143550687};\\\", \\\"{x:1547,y:512,t:1528143550705};\\\", \\\"{x:1506,y:479,t:1528143550720};\\\", \\\"{x:1483,y:465,t:1528143550737};\\\", \\\"{x:1461,y:452,t:1528143550754};\\\", \\\"{x:1443,y:440,t:1528143550770};\\\", \\\"{x:1422,y:424,t:1528143550786};\\\", \\\"{x:1398,y:406,t:1528143550804};\\\", \\\"{x:1369,y:386,t:1528143550820};\\\", \\\"{x:1344,y:372,t:1528143550837};\\\", \\\"{x:1329,y:364,t:1528143550854};\\\", \\\"{x:1331,y:364,t:1528143550998};\\\", \\\"{x:1332,y:364,t:1528143551006};\\\", \\\"{x:1335,y:364,t:1528143551021};\\\", \\\"{x:1336,y:367,t:1528143551174};\\\", \\\"{x:1336,y:373,t:1528143551187};\\\", \\\"{x:1337,y:381,t:1528143551204};\\\", \\\"{x:1337,y:391,t:1528143551221};\\\", \\\"{x:1337,y:400,t:1528143551238};\\\", \\\"{x:1337,y:408,t:1528143551254};\\\", \\\"{x:1338,y:411,t:1528143551271};\\\", \\\"{x:1338,y:414,t:1528143551287};\\\", \\\"{x:1339,y:417,t:1528143551303};\\\", \\\"{x:1339,y:419,t:1528143551320};\\\", \\\"{x:1340,y:423,t:1528143551336};\\\", \\\"{x:1340,y:425,t:1528143551354};\\\", \\\"{x:1341,y:428,t:1528143551370};\\\", \\\"{x:1343,y:434,t:1528143551388};\\\", \\\"{x:1344,y:436,t:1528143551403};\\\", \\\"{x:1347,y:442,t:1528143551420};\\\", \\\"{x:1354,y:452,t:1528143551437};\\\", \\\"{x:1359,y:457,t:1528143551454};\\\", \\\"{x:1372,y:465,t:1528143551470};\\\", \\\"{x:1391,y:471,t:1528143551488};\\\", \\\"{x:1412,y:477,t:1528143551503};\\\", \\\"{x:1434,y:483,t:1528143551521};\\\", \\\"{x:1456,y:486,t:1528143551538};\\\", \\\"{x:1471,y:487,t:1528143551554};\\\", \\\"{x:1482,y:487,t:1528143551571};\\\", \\\"{x:1491,y:487,t:1528143551587};\\\", \\\"{x:1500,y:487,t:1528143551603};\\\", \\\"{x:1507,y:487,t:1528143551621};\\\", \\\"{x:1519,y:485,t:1528143551637};\\\", \\\"{x:1532,y:482,t:1528143551654};\\\", \\\"{x:1545,y:477,t:1528143551671};\\\", \\\"{x:1548,y:475,t:1528143551687};\\\", \\\"{x:1553,y:471,t:1528143551704};\\\", \\\"{x:1553,y:464,t:1528143551721};\\\", \\\"{x:1553,y:459,t:1528143551737};\\\", \\\"{x:1554,y:454,t:1528143551753};\\\", \\\"{x:1555,y:447,t:1528143551771};\\\", \\\"{x:1559,y:438,t:1528143551787};\\\", \\\"{x:1562,y:432,t:1528143551804};\\\", \\\"{x:1564,y:427,t:1528143551820};\\\", \\\"{x:1566,y:421,t:1528143551837};\\\", \\\"{x:1567,y:418,t:1528143551854};\\\", \\\"{x:1569,y:416,t:1528143551871};\\\", \\\"{x:1569,y:415,t:1528143551888};\\\", \\\"{x:1571,y:414,t:1528143552022};\\\", \\\"{x:1574,y:410,t:1528143552038};\\\", \\\"{x:1579,y:406,t:1528143552055};\\\", \\\"{x:1583,y:404,t:1528143552071};\\\", \\\"{x:1586,y:402,t:1528143552088};\\\", \\\"{x:1589,y:400,t:1528143552105};\\\", \\\"{x:1592,y:398,t:1528143552121};\\\", \\\"{x:1594,y:396,t:1528143552138};\\\", \\\"{x:1595,y:395,t:1528143552155};\\\", \\\"{x:1596,y:395,t:1528143552182};\\\", \\\"{x:1598,y:394,t:1528143552365};\\\", \\\"{x:1595,y:392,t:1528143552373};\\\", \\\"{x:1573,y:386,t:1528143552387};\\\", \\\"{x:1501,y:377,t:1528143552405};\\\", \\\"{x:1357,y:377,t:1528143552420};\\\", \\\"{x:1257,y:377,t:1528143552437};\\\", \\\"{x:1163,y:377,t:1528143552455};\\\", \\\"{x:1068,y:378,t:1528143552472};\\\", \\\"{x:990,y:380,t:1528143552487};\\\", \\\"{x:926,y:375,t:1528143552504};\\\", \\\"{x:881,y:361,t:1528143552522};\\\", \\\"{x:829,y:340,t:1528143552538};\\\", \\\"{x:795,y:334,t:1528143552554};\\\", \\\"{x:773,y:326,t:1528143552572};\\\", \\\"{x:762,y:322,t:1528143552587};\\\", \\\"{x:749,y:318,t:1528143552606};\\\", \\\"{x:749,y:320,t:1528143552702};\\\", \\\"{x:749,y:321,t:1528143552718};\\\", \\\"{x:749,y:324,t:1528143552726};\\\", \\\"{x:749,y:325,t:1528143552737};\\\", \\\"{x:749,y:332,t:1528143552755};\\\", \\\"{x:748,y:342,t:1528143552772};\\\", \\\"{x:742,y:361,t:1528143552788};\\\", \\\"{x:733,y:378,t:1528143552805};\\\", \\\"{x:708,y:426,t:1528143552822};\\\", \\\"{x:674,y:465,t:1528143552841};\\\", \\\"{x:643,y:498,t:1528143552855};\\\", \\\"{x:626,y:517,t:1528143552871};\\\", \\\"{x:613,y:542,t:1528143552906};\\\", \\\"{x:611,y:547,t:1528143552922};\\\", \\\"{x:609,y:550,t:1528143552938};\\\", \\\"{x:609,y:551,t:1528143553062};\\\", \\\"{x:607,y:551,t:1528143553093};\\\", \\\"{x:597,y:552,t:1528143553106};\\\", \\\"{x:575,y:557,t:1528143553123};\\\", \\\"{x:551,y:565,t:1528143553138};\\\", \\\"{x:529,y:567,t:1528143553156};\\\", \\\"{x:519,y:570,t:1528143553172};\\\", \\\"{x:518,y:570,t:1528143553349};\\\", \\\"{x:514,y:570,t:1528143553357};\\\", \\\"{x:507,y:568,t:1528143553372};\\\", \\\"{x:480,y:555,t:1528143553390};\\\", \\\"{x:466,y:548,t:1528143553405};\\\", \\\"{x:456,y:540,t:1528143553423};\\\", \\\"{x:451,y:532,t:1528143553439};\\\", \\\"{x:448,y:528,t:1528143553456};\\\", \\\"{x:446,y:526,t:1528143553472};\\\", \\\"{x:446,y:525,t:1528143553489};\\\", \\\"{x:450,y:523,t:1528143553566};\\\", \\\"{x:463,y:522,t:1528143553574};\\\", \\\"{x:489,y:517,t:1528143553590};\\\", \\\"{x:510,y:515,t:1528143553606};\\\", \\\"{x:525,y:511,t:1528143553622};\\\", \\\"{x:535,y:507,t:1528143553639};\\\", \\\"{x:542,y:506,t:1528143553656};\\\", \\\"{x:551,y:506,t:1528143553673};\\\", \\\"{x:563,y:506,t:1528143553690};\\\", \\\"{x:578,y:506,t:1528143553706};\\\", \\\"{x:592,y:506,t:1528143553723};\\\", \\\"{x:599,y:507,t:1528143553741};\\\", \\\"{x:605,y:507,t:1528143553756};\\\", \\\"{x:608,y:507,t:1528143553772};\\\", \\\"{x:608,y:508,t:1528143553997};\\\", \\\"{x:608,y:510,t:1528143554007};\\\", \\\"{x:608,y:514,t:1528143554025};\\\", \\\"{x:605,y:518,t:1528143554042};\\\", \\\"{x:602,y:522,t:1528143554058};\\\", \\\"{x:593,y:529,t:1528143554073};\\\", \\\"{x:586,y:536,t:1528143554089};\\\", \\\"{x:580,y:542,t:1528143554106};\\\", \\\"{x:573,y:546,t:1528143554123};\\\", \\\"{x:565,y:552,t:1528143554140};\\\", \\\"{x:558,y:556,t:1528143554157};\\\", \\\"{x:552,y:561,t:1528143554174};\\\", \\\"{x:552,y:562,t:1528143554190};\\\", \\\"{x:550,y:563,t:1528143554207};\\\", \\\"{x:550,y:564,t:1528143554269};\\\", \\\"{x:551,y:565,t:1528143554294};\\\", \\\"{x:552,y:565,t:1528143555166};\\\", \\\"{x:552,y:564,t:1528143555174};\\\", \\\"{x:551,y:560,t:1528143555191};\\\", \\\"{x:551,y:558,t:1528143555210};\\\", \\\"{x:550,y:554,t:1528143555224};\\\", \\\"{x:550,y:551,t:1528143555240};\\\", \\\"{x:549,y:550,t:1528143555257};\\\", \\\"{x:548,y:548,t:1528143555274};\\\", \\\"{x:547,y:547,t:1528143555293};\\\", \\\"{x:547,y:546,t:1528143555365};\\\", \\\"{x:545,y:546,t:1528143555375};\\\", \\\"{x:544,y:546,t:1528143555390};\\\", \\\"{x:542,y:546,t:1528143555421};\\\", \\\"{x:540,y:544,t:1528143555436};\\\", \\\"{x:536,y:542,t:1528143555445};\\\", \\\"{x:532,y:538,t:1528143555457};\\\", \\\"{x:522,y:534,t:1528143555474};\\\", \\\"{x:512,y:533,t:1528143555490};\\\", \\\"{x:498,y:531,t:1528143555509};\\\", \\\"{x:469,y:528,t:1528143555525};\\\", \\\"{x:451,y:528,t:1528143555541};\\\", \\\"{x:438,y:528,t:1528143555557};\\\", \\\"{x:430,y:528,t:1528143555575};\\\", \\\"{x:429,y:528,t:1528143555591};\\\", \\\"{x:427,y:528,t:1528143555637};\\\", \\\"{x:423,y:528,t:1528143555693};\\\", \\\"{x:420,y:528,t:1528143555708};\\\", \\\"{x:418,y:528,t:1528143555725};\\\", \\\"{x:417,y:528,t:1528143555741};\\\", \\\"{x:416,y:528,t:1528143555806};\\\", \\\"{x:412,y:528,t:1528143555814};\\\", \\\"{x:402,y:528,t:1528143555825};\\\", \\\"{x:391,y:525,t:1528143555841};\\\", \\\"{x:381,y:520,t:1528143555858};\\\", \\\"{x:376,y:517,t:1528143555874};\\\", \\\"{x:374,y:515,t:1528143555891};\\\", \\\"{x:373,y:513,t:1528143555906};\\\", \\\"{x:372,y:513,t:1528143555925};\\\", \\\"{x:372,y:511,t:1528143555940};\\\", \\\"{x:370,y:509,t:1528143555958};\\\", \\\"{x:370,y:506,t:1528143555975};\\\", \\\"{x:368,y:501,t:1528143555991};\\\", \\\"{x:367,y:498,t:1528143556007};\\\", \\\"{x:365,y:495,t:1528143556025};\\\", \\\"{x:359,y:493,t:1528143556042};\\\", \\\"{x:351,y:490,t:1528143556059};\\\", \\\"{x:336,y:490,t:1528143556074};\\\", \\\"{x:321,y:490,t:1528143556091};\\\", \\\"{x:306,y:490,t:1528143556107};\\\", \\\"{x:276,y:491,t:1528143556126};\\\", \\\"{x:249,y:491,t:1528143556142};\\\", \\\"{x:224,y:492,t:1528143556158};\\\", \\\"{x:199,y:509,t:1528143556174};\\\", \\\"{x:190,y:517,t:1528143556192};\\\", \\\"{x:186,y:519,t:1528143556208};\\\", \\\"{x:185,y:519,t:1528143556224};\\\", \\\"{x:182,y:519,t:1528143556452};\\\", \\\"{x:179,y:521,t:1528143556461};\\\", \\\"{x:173,y:525,t:1528143556475};\\\", \\\"{x:165,y:534,t:1528143556492};\\\", \\\"{x:162,y:547,t:1528143556509};\\\", \\\"{x:162,y:553,t:1528143556525};\\\", \\\"{x:161,y:568,t:1528143556543};\\\", \\\"{x:161,y:573,t:1528143556559};\\\", \\\"{x:161,y:574,t:1528143556575};\\\", \\\"{x:161,y:575,t:1528143556653};\\\", \\\"{x:161,y:576,t:1528143556661};\\\", \\\"{x:162,y:580,t:1528143557053};\\\", \\\"{x:182,y:586,t:1528143557061};\\\", \\\"{x:201,y:590,t:1528143557076};\\\", \\\"{x:250,y:611,t:1528143557092};\\\", \\\"{x:323,y:651,t:1528143557108};\\\", \\\"{x:357,y:675,t:1528143557126};\\\", \\\"{x:383,y:691,t:1528143557141};\\\", \\\"{x:400,y:699,t:1528143557158};\\\", \\\"{x:415,y:704,t:1528143557175};\\\", \\\"{x:430,y:708,t:1528143557192};\\\", \\\"{x:445,y:711,t:1528143557208};\\\", \\\"{x:452,y:711,t:1528143557225};\\\", \\\"{x:455,y:711,t:1528143557242};\\\", \\\"{x:456,y:711,t:1528143557258};\\\", \\\"{x:457,y:709,t:1528143557276};\\\", \\\"{x:462,y:704,t:1528143557293};\\\", \\\"{x:470,y:699,t:1528143557309};\\\", \\\"{x:489,y:691,t:1528143557326};\\\", \\\"{x:500,y:684,t:1528143557343};\\\", \\\"{x:509,y:679,t:1528143557361};\\\", \\\"{x:513,y:676,t:1528143557375};\\\", \\\"{x:516,y:675,t:1528143557393};\\\", \\\"{x:517,y:674,t:1528143557409};\\\", \\\"{x:518,y:673,t:1528143557426};\\\", \\\"{x:519,y:673,t:1528143557443};\\\", \\\"{x:520,y:671,t:1528143557459};\\\", \\\"{x:521,y:669,t:1528143557475};\\\", \\\"{x:521,y:668,t:1528143557492};\\\", \\\"{x:521,y:667,t:1528143557509};\\\", \\\"{x:521,y:666,t:1528143557701};\\\", \\\"{x:519,y:668,t:1528143557717};\\\", \\\"{x:513,y:672,t:1528143557725};\\\", \\\"{x:500,y:678,t:1528143557743};\\\", \\\"{x:490,y:683,t:1528143557759};\\\", \\\"{x:481,y:688,t:1528143557775};\\\", \\\"{x:467,y:703,t:1528143557792};\\\", \\\"{x:454,y:717,t:1528143557810};\\\", \\\"{x:440,y:729,t:1528143557825};\\\", \\\"{x:422,y:739,t:1528143557842};\\\", \\\"{x:410,y:746,t:1528143557859};\\\", \\\"{x:404,y:752,t:1528143557875};\\\", \\\"{x:402,y:756,t:1528143557892};\\\", \\\"{x:402,y:757,t:1528143557909};\\\" ] }, { \\\"rt\\\": 12527, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 92752, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"8182H\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:406,y:758,t:1528143561822};\\\", \\\"{x:471,y:736,t:1528143561829};\\\", \\\"{x:647,y:665,t:1528143561846};\\\", \\\"{x:763,y:615,t:1528143561864};\\\", \\\"{x:971,y:580,t:1528143561879};\\\", \\\"{x:1175,y:553,t:1528143561897};\\\", \\\"{x:1407,y:517,t:1528143561913};\\\", \\\"{x:1664,y:484,t:1528143561930};\\\", \\\"{x:1912,y:449,t:1528143561946};\\\", \\\"{x:1919,y:432,t:1528143561964};\\\", \\\"{x:1919,y:417,t:1528143561979};\\\", \\\"{x:1919,y:395,t:1528143561996};\\\", \\\"{x:1919,y:376,t:1528143562013};\\\", \\\"{x:1919,y:373,t:1528143562030};\\\", \\\"{x:1917,y:371,t:1528143562070};\\\", \\\"{x:1908,y:370,t:1528143562080};\\\", \\\"{x:1869,y:370,t:1528143562096};\\\", \\\"{x:1808,y:370,t:1528143562113};\\\", \\\"{x:1730,y:370,t:1528143562130};\\\", \\\"{x:1649,y:370,t:1528143562146};\\\", \\\"{x:1566,y:370,t:1528143562162};\\\", \\\"{x:1488,y:370,t:1528143562180};\\\", \\\"{x:1416,y:378,t:1528143562197};\\\", \\\"{x:1338,y:394,t:1528143562213};\\\", \\\"{x:1314,y:402,t:1528143562230};\\\", \\\"{x:1300,y:410,t:1528143562246};\\\", \\\"{x:1293,y:415,t:1528143562263};\\\", \\\"{x:1293,y:418,t:1528143562280};\\\", \\\"{x:1293,y:421,t:1528143562296};\\\", \\\"{x:1293,y:424,t:1528143562314};\\\", \\\"{x:1295,y:428,t:1528143562330};\\\", \\\"{x:1305,y:434,t:1528143562346};\\\", \\\"{x:1323,y:441,t:1528143562363};\\\", \\\"{x:1342,y:444,t:1528143562380};\\\", \\\"{x:1381,y:449,t:1528143562397};\\\", \\\"{x:1411,y:449,t:1528143562414};\\\", \\\"{x:1442,y:449,t:1528143562431};\\\", \\\"{x:1487,y:449,t:1528143562446};\\\", \\\"{x:1529,y:449,t:1528143562463};\\\", \\\"{x:1560,y:449,t:1528143562480};\\\", \\\"{x:1590,y:449,t:1528143562497};\\\", \\\"{x:1624,y:449,t:1528143562513};\\\", \\\"{x:1652,y:449,t:1528143562530};\\\", \\\"{x:1674,y:449,t:1528143562547};\\\", \\\"{x:1685,y:449,t:1528143562563};\\\", \\\"{x:1688,y:449,t:1528143562580};\\\", \\\"{x:1688,y:448,t:1528143562596};\\\", \\\"{x:1688,y:446,t:1528143562613};\\\", \\\"{x:1687,y:443,t:1528143562630};\\\", \\\"{x:1679,y:439,t:1528143562648};\\\", \\\"{x:1666,y:435,t:1528143562663};\\\", \\\"{x:1649,y:431,t:1528143562680};\\\", \\\"{x:1637,y:429,t:1528143562697};\\\", \\\"{x:1629,y:429,t:1528143562713};\\\", \\\"{x:1627,y:429,t:1528143562730};\\\", \\\"{x:1626,y:428,t:1528143562830};\\\", \\\"{x:1626,y:430,t:1528143563821};\\\", \\\"{x:1625,y:431,t:1528143563831};\\\", \\\"{x:1625,y:434,t:1528143563849};\\\", \\\"{x:1625,y:436,t:1528143563864};\\\", \\\"{x:1625,y:437,t:1528143563885};\\\", \\\"{x:1625,y:439,t:1528143563898};\\\", \\\"{x:1625,y:442,t:1528143563915};\\\", \\\"{x:1625,y:447,t:1528143563931};\\\", \\\"{x:1626,y:454,t:1528143563948};\\\", \\\"{x:1627,y:459,t:1528143563964};\\\", \\\"{x:1628,y:463,t:1528143563981};\\\", \\\"{x:1628,y:465,t:1528143563997};\\\", \\\"{x:1628,y:467,t:1528143564014};\\\", \\\"{x:1628,y:469,t:1528143564031};\\\", \\\"{x:1628,y:471,t:1528143564048};\\\", \\\"{x:1628,y:473,t:1528143564065};\\\", \\\"{x:1628,y:475,t:1528143564081};\\\", \\\"{x:1628,y:477,t:1528143564099};\\\", \\\"{x:1628,y:478,t:1528143564115};\\\", \\\"{x:1628,y:479,t:1528143564142};\\\", \\\"{x:1628,y:480,t:1528143564149};\\\", \\\"{x:1628,y:481,t:1528143564166};\\\", \\\"{x:1628,y:482,t:1528143564190};\\\", \\\"{x:1627,y:485,t:1528143564198};\\\", \\\"{x:1627,y:487,t:1528143564222};\\\", \\\"{x:1626,y:487,t:1528143564232};\\\", \\\"{x:1626,y:488,t:1528143564249};\\\", \\\"{x:1624,y:490,t:1528143564278};\\\", \\\"{x:1624,y:491,t:1528143564454};\\\", \\\"{x:1624,y:493,t:1528143564466};\\\", \\\"{x:1624,y:496,t:1528143564482};\\\", \\\"{x:1624,y:498,t:1528143564498};\\\", \\\"{x:1624,y:501,t:1528143564515};\\\", \\\"{x:1624,y:503,t:1528143564531};\\\", \\\"{x:1624,y:504,t:1528143564547};\\\", \\\"{x:1624,y:505,t:1528143564565};\\\", \\\"{x:1624,y:506,t:1528143564582};\\\", \\\"{x:1624,y:509,t:1528143564598};\\\", \\\"{x:1626,y:512,t:1528143564615};\\\", \\\"{x:1628,y:516,t:1528143564631};\\\", \\\"{x:1628,y:518,t:1528143564648};\\\", \\\"{x:1629,y:520,t:1528143564665};\\\", \\\"{x:1629,y:521,t:1528143564681};\\\", \\\"{x:1629,y:524,t:1528143564966};\\\", \\\"{x:1621,y:535,t:1528143564982};\\\", \\\"{x:1614,y:547,t:1528143564999};\\\", \\\"{x:1609,y:557,t:1528143565015};\\\", \\\"{x:1604,y:567,t:1528143565033};\\\", \\\"{x:1599,y:578,t:1528143565048};\\\", \\\"{x:1597,y:591,t:1528143565065};\\\", \\\"{x:1596,y:614,t:1528143565082};\\\", \\\"{x:1596,y:648,t:1528143565098};\\\", \\\"{x:1596,y:698,t:1528143565115};\\\", \\\"{x:1596,y:738,t:1528143565133};\\\", \\\"{x:1596,y:787,t:1528143565150};\\\", \\\"{x:1598,y:806,t:1528143565165};\\\", \\\"{x:1603,y:820,t:1528143565183};\\\", \\\"{x:1604,y:826,t:1528143565199};\\\", \\\"{x:1605,y:828,t:1528143565222};\\\", \\\"{x:1606,y:828,t:1528143565246};\\\", \\\"{x:1607,y:828,t:1528143565277};\\\", \\\"{x:1607,y:827,t:1528143565414};\\\", \\\"{x:1606,y:825,t:1528143565422};\\\", \\\"{x:1603,y:817,t:1528143565432};\\\", \\\"{x:1593,y:807,t:1528143565449};\\\", \\\"{x:1574,y:793,t:1528143565466};\\\", \\\"{x:1557,y:780,t:1528143565483};\\\", \\\"{x:1549,y:776,t:1528143565499};\\\", \\\"{x:1544,y:772,t:1528143565516};\\\", \\\"{x:1540,y:769,t:1528143565532};\\\", \\\"{x:1531,y:763,t:1528143565548};\\\", \\\"{x:1522,y:755,t:1528143565565};\\\", \\\"{x:1507,y:743,t:1528143565582};\\\", \\\"{x:1496,y:736,t:1528143565599};\\\", \\\"{x:1487,y:730,t:1528143565616};\\\", \\\"{x:1480,y:726,t:1528143565633};\\\", \\\"{x:1473,y:723,t:1528143565649};\\\", \\\"{x:1467,y:719,t:1528143565667};\\\", \\\"{x:1462,y:716,t:1528143565682};\\\", \\\"{x:1451,y:711,t:1528143565699};\\\", \\\"{x:1444,y:709,t:1528143565716};\\\", \\\"{x:1441,y:708,t:1528143565732};\\\", \\\"{x:1440,y:708,t:1528143565750};\\\", \\\"{x:1439,y:708,t:1528143565765};\\\", \\\"{x:1438,y:708,t:1528143565910};\\\", \\\"{x:1436,y:709,t:1528143565917};\\\", \\\"{x:1434,y:711,t:1528143565934};\\\", \\\"{x:1430,y:715,t:1528143565949};\\\", \\\"{x:1426,y:719,t:1528143565967};\\\", \\\"{x:1424,y:721,t:1528143565983};\\\", \\\"{x:1421,y:725,t:1528143566000};\\\", \\\"{x:1419,y:726,t:1528143566017};\\\", \\\"{x:1418,y:728,t:1528143566034};\\\", \\\"{x:1416,y:730,t:1528143566050};\\\", \\\"{x:1415,y:731,t:1528143566078};\\\", \\\"{x:1414,y:732,t:1528143566182};\\\", \\\"{x:1413,y:735,t:1528143566190};\\\", \\\"{x:1411,y:736,t:1528143566199};\\\", \\\"{x:1407,y:740,t:1528143566217};\\\", \\\"{x:1404,y:743,t:1528143566233};\\\", \\\"{x:1400,y:746,t:1528143566250};\\\", \\\"{x:1396,y:749,t:1528143566267};\\\", \\\"{x:1392,y:751,t:1528143566284};\\\", \\\"{x:1390,y:754,t:1528143566300};\\\", \\\"{x:1389,y:756,t:1528143566317};\\\", \\\"{x:1387,y:760,t:1528143566334};\\\", \\\"{x:1383,y:760,t:1528143566406};\\\", \\\"{x:1377,y:758,t:1528143566416};\\\", \\\"{x:1367,y:755,t:1528143566434};\\\", \\\"{x:1359,y:753,t:1528143566450};\\\", \\\"{x:1354,y:752,t:1528143566467};\\\", \\\"{x:1351,y:752,t:1528143566484};\\\", \\\"{x:1350,y:752,t:1528143566501};\\\", \\\"{x:1350,y:754,t:1528143566517};\\\", \\\"{x:1350,y:756,t:1528143566533};\\\", \\\"{x:1348,y:757,t:1528143566620};\\\", \\\"{x:1347,y:758,t:1528143566633};\\\", \\\"{x:1343,y:765,t:1528143566650};\\\", \\\"{x:1339,y:768,t:1528143566666};\\\", \\\"{x:1333,y:771,t:1528143566683};\\\", \\\"{x:1324,y:774,t:1528143566700};\\\", \\\"{x:1317,y:776,t:1528143566716};\\\", \\\"{x:1306,y:777,t:1528143566733};\\\", \\\"{x:1297,y:778,t:1528143566750};\\\", \\\"{x:1283,y:778,t:1528143566767};\\\", \\\"{x:1268,y:778,t:1528143566784};\\\", \\\"{x:1257,y:778,t:1528143566800};\\\", \\\"{x:1246,y:788,t:1528143566816};\\\", \\\"{x:1224,y:806,t:1528143566833};\\\", \\\"{x:1200,y:812,t:1528143566851};\\\", \\\"{x:1199,y:813,t:1528143566866};\\\", \\\"{x:1199,y:811,t:1528143567166};\\\", \\\"{x:1199,y:804,t:1528143567173};\\\", \\\"{x:1202,y:797,t:1528143567183};\\\", \\\"{x:1210,y:788,t:1528143567200};\\\", \\\"{x:1220,y:780,t:1528143567217};\\\", \\\"{x:1231,y:772,t:1528143567233};\\\", \\\"{x:1239,y:767,t:1528143567251};\\\", \\\"{x:1244,y:765,t:1528143567267};\\\", \\\"{x:1247,y:765,t:1528143567283};\\\", \\\"{x:1250,y:765,t:1528143567301};\\\", \\\"{x:1251,y:765,t:1528143567318};\\\", \\\"{x:1253,y:765,t:1528143567335};\\\", \\\"{x:1254,y:765,t:1528143567422};\\\", \\\"{x:1258,y:767,t:1528143567434};\\\", \\\"{x:1264,y:773,t:1528143567451};\\\", \\\"{x:1267,y:776,t:1528143567467};\\\", \\\"{x:1268,y:778,t:1528143567485};\\\", \\\"{x:1269,y:779,t:1528143567501};\\\", \\\"{x:1261,y:774,t:1528143567725};\\\", \\\"{x:1248,y:768,t:1528143567735};\\\", \\\"{x:1223,y:755,t:1528143567751};\\\", \\\"{x:1193,y:737,t:1528143567768};\\\", \\\"{x:1133,y:705,t:1528143567784};\\\", \\\"{x:904,y:598,t:1528143567800};\\\", \\\"{x:782,y:523,t:1528143567817};\\\", \\\"{x:777,y:516,t:1528143567836};\\\", \\\"{x:739,y:496,t:1528143567851};\\\", \\\"{x:664,y:446,t:1528143567868};\\\", \\\"{x:653,y:435,t:1528143567880};\\\", \\\"{x:652,y:429,t:1528143567897};\\\", \\\"{x:642,y:419,t:1528143567913};\\\", \\\"{x:617,y:401,t:1528143567930};\\\", \\\"{x:577,y:380,t:1528143567947};\\\", \\\"{x:517,y:366,t:1528143567963};\\\", \\\"{x:450,y:366,t:1528143567980};\\\", \\\"{x:363,y:355,t:1528143567996};\\\", \\\"{x:327,y:351,t:1528143568013};\\\", \\\"{x:313,y:348,t:1528143568030};\\\", \\\"{x:309,y:347,t:1528143568047};\\\", \\\"{x:309,y:348,t:1528143568901};\\\", \\\"{x:312,y:354,t:1528143568914};\\\", \\\"{x:318,y:362,t:1528143568931};\\\", \\\"{x:326,y:372,t:1528143568947};\\\", \\\"{x:332,y:381,t:1528143568964};\\\", \\\"{x:340,y:394,t:1528143568980};\\\", \\\"{x:349,y:407,t:1528143568997};\\\", \\\"{x:353,y:413,t:1528143569015};\\\", \\\"{x:357,y:418,t:1528143569030};\\\", \\\"{x:360,y:422,t:1528143569047};\\\", \\\"{x:363,y:427,t:1528143569064};\\\", \\\"{x:366,y:430,t:1528143569080};\\\", \\\"{x:368,y:431,t:1528143569097};\\\", \\\"{x:368,y:432,t:1528143569117};\\\", \\\"{x:368,y:433,t:1528143569133};\\\", \\\"{x:369,y:434,t:1528143569148};\\\", \\\"{x:371,y:437,t:1528143569165};\\\", \\\"{x:374,y:445,t:1528143569181};\\\", \\\"{x:383,y:460,t:1528143569198};\\\", \\\"{x:387,y:466,t:1528143569214};\\\", \\\"{x:388,y:469,t:1528143569235};\\\", \\\"{x:388,y:471,t:1528143569252};\\\", \\\"{x:389,y:473,t:1528143569269};\\\", \\\"{x:389,y:474,t:1528143569285};\\\", \\\"{x:391,y:476,t:1528143569303};\\\", \\\"{x:393,y:480,t:1528143569320};\\\", \\\"{x:393,y:481,t:1528143569335};\\\", \\\"{x:393,y:483,t:1528143569352};\\\", \\\"{x:393,y:484,t:1528143569369};\\\", \\\"{x:391,y:487,t:1528143569385};\\\", \\\"{x:391,y:490,t:1528143569403};\\\", \\\"{x:392,y:495,t:1528143569419};\\\", \\\"{x:393,y:497,t:1528143569436};\\\", \\\"{x:394,y:499,t:1528143569452};\\\", \\\"{x:396,y:500,t:1528143569468};\\\", \\\"{x:402,y:506,t:1528143569485};\\\", \\\"{x:403,y:506,t:1528143569509};\\\", \\\"{x:404,y:506,t:1528143569566};\\\", \\\"{x:405,y:507,t:1528143569597};\\\", \\\"{x:405,y:508,t:1528143569604};\\\", \\\"{x:405,y:510,t:1528143569636};\\\", \\\"{x:404,y:512,t:1528143569653};\\\", \\\"{x:404,y:513,t:1528143569701};\\\", \\\"{x:403,y:514,t:1528143569717};\\\", \\\"{x:403,y:515,t:1528143569733};\\\", \\\"{x:402,y:516,t:1528143569757};\\\", \\\"{x:401,y:516,t:1528143569829};\\\", \\\"{x:398,y:516,t:1528143569837};\\\", \\\"{x:394,y:516,t:1528143569853};\\\", \\\"{x:375,y:508,t:1528143569868};\\\", \\\"{x:368,y:504,t:1528143569886};\\\", \\\"{x:362,y:500,t:1528143569903};\\\", \\\"{x:357,y:496,t:1528143569919};\\\", \\\"{x:352,y:492,t:1528143569935};\\\", \\\"{x:349,y:490,t:1528143569953};\\\", \\\"{x:345,y:486,t:1528143569969};\\\", \\\"{x:342,y:483,t:1528143569987};\\\", \\\"{x:343,y:483,t:1528143570037};\\\", \\\"{x:347,y:483,t:1528143570052};\\\", \\\"{x:356,y:480,t:1528143570069};\\\", \\\"{x:361,y:479,t:1528143570086};\\\", \\\"{x:365,y:477,t:1528143570103};\\\", \\\"{x:368,y:476,t:1528143570119};\\\", \\\"{x:370,y:476,t:1528143570135};\\\", \\\"{x:371,y:476,t:1528143570152};\\\", \\\"{x:372,y:475,t:1528143570169};\\\", \\\"{x:372,y:474,t:1528143570186};\\\", \\\"{x:372,y:473,t:1528143570214};\\\", \\\"{x:372,y:471,t:1528143570237};\\\", \\\"{x:372,y:470,t:1528143570253};\\\", \\\"{x:372,y:468,t:1528143570270};\\\", \\\"{x:373,y:466,t:1528143570286};\\\", \\\"{x:374,y:466,t:1528143570302};\\\", \\\"{x:377,y:464,t:1528143570319};\\\", \\\"{x:378,y:464,t:1528143570336};\\\", \\\"{x:381,y:464,t:1528143570541};\\\", \\\"{x:381,y:465,t:1528143570565};\\\", \\\"{x:382,y:468,t:1528143570573};\\\", \\\"{x:386,y:471,t:1528143570586};\\\", \\\"{x:389,y:474,t:1528143570604};\\\", \\\"{x:390,y:476,t:1528143570619};\\\", \\\"{x:393,y:478,t:1528143570636};\\\", \\\"{x:397,y:484,t:1528143570653};\\\", \\\"{x:406,y:496,t:1528143570669};\\\", \\\"{x:410,y:502,t:1528143570686};\\\", \\\"{x:415,y:508,t:1528143570704};\\\", \\\"{x:434,y:536,t:1528143570721};\\\", \\\"{x:473,y:580,t:1528143570737};\\\", \\\"{x:491,y:602,t:1528143570754};\\\", \\\"{x:504,y:619,t:1528143570770};\\\", \\\"{x:526,y:662,t:1528143570787};\\\", \\\"{x:544,y:697,t:1528143570803};\\\", \\\"{x:555,y:717,t:1528143570820};\\\", \\\"{x:560,y:728,t:1528143570837};\\\", \\\"{x:560,y:729,t:1528143570854};\\\", \\\"{x:559,y:729,t:1528143570925};\\\", \\\"{x:556,y:729,t:1528143570937};\\\", \\\"{x:552,y:726,t:1528143570953};\\\", \\\"{x:548,y:725,t:1528143570971};\\\", \\\"{x:544,y:722,t:1528143570987};\\\", \\\"{x:537,y:715,t:1528143571004};\\\", \\\"{x:529,y:708,t:1528143571021};\\\", \\\"{x:522,y:702,t:1528143571037};\\\", \\\"{x:517,y:696,t:1528143571053};\\\", \\\"{x:511,y:690,t:1528143571071};\\\", \\\"{x:509,y:687,t:1528143571087};\\\", \\\"{x:507,y:686,t:1528143571104};\\\", \\\"{x:507,y:684,t:1528143571121};\\\", \\\"{x:507,y:682,t:1528143571138};\\\", \\\"{x:507,y:680,t:1528143571153};\\\", \\\"{x:507,y:676,t:1528143571170};\\\", \\\"{x:506,y:675,t:1528143571187};\\\", \\\"{x:506,y:673,t:1528143571204};\\\", \\\"{x:506,y:672,t:1528143571221};\\\", \\\"{x:506,y:671,t:1528143571237};\\\", \\\"{x:507,y:671,t:1528143571541};\\\", \\\"{x:510,y:671,t:1528143571553};\\\", \\\"{x:515,y:674,t:1528143571570};\\\", \\\"{x:520,y:675,t:1528143571588};\\\", \\\"{x:527,y:678,t:1528143571603};\\\", \\\"{x:535,y:680,t:1528143571620};\\\", \\\"{x:544,y:683,t:1528143571637};\\\", \\\"{x:548,y:684,t:1528143571653};\\\", \\\"{x:551,y:685,t:1528143571670};\\\", \\\"{x:558,y:688,t:1528143571687};\\\", \\\"{x:589,y:711,t:1528143571705};\\\", \\\"{x:621,y:728,t:1528143571720};\\\", \\\"{x:647,y:744,t:1528143571738};\\\", \\\"{x:663,y:752,t:1528143571754};\\\", \\\"{x:673,y:756,t:1528143571770};\\\", \\\"{x:679,y:759,t:1528143571787};\\\", \\\"{x:681,y:761,t:1528143571804};\\\", \\\"{x:687,y:766,t:1528143571820};\\\", \\\"{x:692,y:771,t:1528143571837};\\\", \\\"{x:693,y:773,t:1528143571854};\\\", \\\"{x:694,y:774,t:1528143571870};\\\", \\\"{x:695,y:774,t:1528143571997};\\\", \\\"{x:696,y:774,t:1528143572013};\\\", \\\"{x:697,y:774,t:1528143572038};\\\", \\\"{x:698,y:774,t:1528143572054};\\\", \\\"{x:699,y:774,t:1528143572525};\\\", \\\"{x:699,y:773,t:1528143572538};\\\", \\\"{x:698,y:772,t:1528143572554};\\\", \\\"{x:696,y:771,t:1528143572572};\\\", \\\"{x:695,y:771,t:1528143572588};\\\" ] }, { \\\"rt\\\": 25534, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 119608, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"8182H\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 3, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\", \\\"J\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-06 PM-05 PM-04 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:693,y:770,t:1528143572813};\\\", \\\"{x:694,y:770,t:1528143574182};\\\", \\\"{x:694,y:768,t:1528143574192};\\\", \\\"{x:694,y:766,t:1528143574205};\\\", \\\"{x:694,y:763,t:1528143574223};\\\", \\\"{x:694,y:759,t:1528143574239};\\\", \\\"{x:694,y:756,t:1528143574255};\\\", \\\"{x:694,y:753,t:1528143574272};\\\", \\\"{x:695,y:751,t:1528143574289};\\\", \\\"{x:699,y:745,t:1528143574305};\\\", \\\"{x:703,y:737,t:1528143574322};\\\", \\\"{x:706,y:733,t:1528143574339};\\\", \\\"{x:705,y:733,t:1528143574797};\\\", \\\"{x:707,y:736,t:1528143574902};\\\", \\\"{x:712,y:737,t:1528143574909};\\\", \\\"{x:716,y:739,t:1528143574922};\\\", \\\"{x:724,y:742,t:1528143574939};\\\", \\\"{x:729,y:745,t:1528143574957};\\\", \\\"{x:732,y:745,t:1528143574981};\\\", \\\"{x:734,y:745,t:1528143574996};\\\", \\\"{x:735,y:746,t:1528143575006};\\\", \\\"{x:739,y:748,t:1528143575023};\\\", \\\"{x:742,y:748,t:1528143575039};\\\", \\\"{x:744,y:748,t:1528143575056};\\\", \\\"{x:745,y:748,t:1528143575074};\\\", \\\"{x:746,y:748,t:1528143575109};\\\", \\\"{x:748,y:748,t:1528143575123};\\\", \\\"{x:751,y:748,t:1528143575140};\\\", \\\"{x:753,y:749,t:1528143575246};\\\", \\\"{x:754,y:749,t:1528143575257};\\\", \\\"{x:757,y:750,t:1528143575274};\\\", \\\"{x:759,y:751,t:1528143575290};\\\", \\\"{x:759,y:752,t:1528143575518};\\\", \\\"{x:762,y:752,t:1528143575525};\\\", \\\"{x:773,y:757,t:1528143575541};\\\", \\\"{x:781,y:760,t:1528143575558};\\\", \\\"{x:784,y:760,t:1528143575574};\\\", \\\"{x:785,y:761,t:1528143575591};\\\", \\\"{x:787,y:762,t:1528143576037};\\\", \\\"{x:789,y:763,t:1528143576046};\\\", \\\"{x:792,y:764,t:1528143576058};\\\", \\\"{x:798,y:767,t:1528143576074};\\\", \\\"{x:815,y:774,t:1528143576091};\\\", \\\"{x:860,y:795,t:1528143576108};\\\", \\\"{x:961,y:831,t:1528143576124};\\\", \\\"{x:1106,y:864,t:1528143576141};\\\", \\\"{x:1345,y:890,t:1528143576157};\\\", \\\"{x:1472,y:890,t:1528143576174};\\\", \\\"{x:1591,y:890,t:1528143576191};\\\", \\\"{x:1699,y:890,t:1528143576208};\\\", \\\"{x:1766,y:890,t:1528143576224};\\\", \\\"{x:1786,y:890,t:1528143576241};\\\", \\\"{x:1790,y:891,t:1528143576258};\\\", \\\"{x:1792,y:891,t:1528143576278};\\\", \\\"{x:1794,y:892,t:1528143576291};\\\", \\\"{x:1800,y:894,t:1528143576308};\\\", \\\"{x:1805,y:896,t:1528143576324};\\\", \\\"{x:1819,y:898,t:1528143576340};\\\", \\\"{x:1821,y:898,t:1528143576357};\\\", \\\"{x:1820,y:898,t:1528143576421};\\\", \\\"{x:1817,y:899,t:1528143576428};\\\", \\\"{x:1813,y:899,t:1528143576441};\\\", \\\"{x:1798,y:905,t:1528143576457};\\\", \\\"{x:1781,y:909,t:1528143576475};\\\", \\\"{x:1771,y:913,t:1528143576491};\\\", \\\"{x:1769,y:914,t:1528143576508};\\\", \\\"{x:1763,y:915,t:1528143576525};\\\", \\\"{x:1758,y:916,t:1528143576542};\\\", \\\"{x:1749,y:918,t:1528143576558};\\\", \\\"{x:1729,y:921,t:1528143576575};\\\", \\\"{x:1706,y:924,t:1528143576592};\\\", \\\"{x:1686,y:927,t:1528143576608};\\\", \\\"{x:1678,y:928,t:1528143576625};\\\", \\\"{x:1673,y:929,t:1528143576642};\\\", \\\"{x:1671,y:929,t:1528143576658};\\\", \\\"{x:1669,y:929,t:1528143576725};\\\", \\\"{x:1663,y:929,t:1528143576740};\\\", \\\"{x:1658,y:929,t:1528143576758};\\\", \\\"{x:1653,y:929,t:1528143576774};\\\", \\\"{x:1647,y:929,t:1528143576791};\\\", \\\"{x:1645,y:929,t:1528143576807};\\\", \\\"{x:1644,y:929,t:1528143576825};\\\", \\\"{x:1640,y:927,t:1528143576841};\\\", \\\"{x:1638,y:927,t:1528143576858};\\\", \\\"{x:1636,y:926,t:1528143576875};\\\", \\\"{x:1633,y:924,t:1528143576890};\\\", \\\"{x:1631,y:923,t:1528143576908};\\\", \\\"{x:1630,y:923,t:1528143576934};\\\", \\\"{x:1629,y:922,t:1528143576982};\\\", \\\"{x:1628,y:922,t:1528143577005};\\\", \\\"{x:1627,y:922,t:1528143577037};\\\", \\\"{x:1627,y:921,t:1528143577045};\\\", \\\"{x:1625,y:921,t:1528143577069};\\\", \\\"{x:1624,y:920,t:1528143577110};\\\", \\\"{x:1622,y:920,t:1528143577182};\\\", \\\"{x:1621,y:920,t:1528143577230};\\\", \\\"{x:1620,y:918,t:1528143577293};\\\", \\\"{x:1617,y:917,t:1528143577308};\\\", \\\"{x:1612,y:915,t:1528143577326};\\\", \\\"{x:1607,y:913,t:1528143577342};\\\", \\\"{x:1604,y:913,t:1528143577358};\\\", \\\"{x:1601,y:913,t:1528143577375};\\\", \\\"{x:1602,y:913,t:1528143577614};\\\", \\\"{x:1604,y:913,t:1528143577626};\\\", \\\"{x:1606,y:913,t:1528143577643};\\\", \\\"{x:1607,y:913,t:1528143577660};\\\", \\\"{x:1609,y:913,t:1528143577716};\\\", \\\"{x:1610,y:913,t:1528143577773};\\\", \\\"{x:1611,y:911,t:1528143577780};\\\", \\\"{x:1613,y:910,t:1528143577791};\\\", \\\"{x:1613,y:908,t:1528143577808};\\\", \\\"{x:1615,y:904,t:1528143577825};\\\", \\\"{x:1616,y:902,t:1528143577841};\\\", \\\"{x:1616,y:901,t:1528143577859};\\\", \\\"{x:1616,y:900,t:1528143577874};\\\", \\\"{x:1617,y:898,t:1528143577892};\\\", \\\"{x:1617,y:895,t:1528143577909};\\\", \\\"{x:1617,y:894,t:1528143577925};\\\", \\\"{x:1617,y:892,t:1528143577942};\\\", \\\"{x:1617,y:891,t:1528143577959};\\\", \\\"{x:1617,y:889,t:1528143577981};\\\", \\\"{x:1617,y:888,t:1528143577998};\\\", \\\"{x:1617,y:886,t:1528143578013};\\\", \\\"{x:1617,y:884,t:1528143578026};\\\", \\\"{x:1617,y:879,t:1528143578042};\\\", \\\"{x:1617,y:874,t:1528143578059};\\\", \\\"{x:1617,y:864,t:1528143578076};\\\", \\\"{x:1610,y:839,t:1528143578092};\\\", \\\"{x:1599,y:808,t:1528143578109};\\\", \\\"{x:1597,y:798,t:1528143578126};\\\", \\\"{x:1596,y:789,t:1528143578142};\\\", \\\"{x:1596,y:782,t:1528143578159};\\\", \\\"{x:1596,y:775,t:1528143578176};\\\", \\\"{x:1596,y:770,t:1528143578192};\\\", \\\"{x:1596,y:764,t:1528143578209};\\\", \\\"{x:1596,y:759,t:1528143578226};\\\", \\\"{x:1596,y:753,t:1528143578243};\\\", \\\"{x:1599,y:747,t:1528143578259};\\\", \\\"{x:1599,y:741,t:1528143578276};\\\", \\\"{x:1602,y:736,t:1528143578292};\\\", \\\"{x:1604,y:729,t:1528143578310};\\\", \\\"{x:1606,y:726,t:1528143578326};\\\", \\\"{x:1607,y:724,t:1528143578343};\\\", \\\"{x:1607,y:721,t:1528143578359};\\\", \\\"{x:1609,y:719,t:1528143578376};\\\", \\\"{x:1609,y:718,t:1528143578393};\\\", \\\"{x:1610,y:716,t:1528143578409};\\\", \\\"{x:1610,y:715,t:1528143578427};\\\", \\\"{x:1611,y:715,t:1528143578443};\\\", \\\"{x:1612,y:713,t:1528143578460};\\\", \\\"{x:1612,y:712,t:1528143578478};\\\", \\\"{x:1613,y:711,t:1528143578494};\\\", \\\"{x:1613,y:710,t:1528143578517};\\\", \\\"{x:1613,y:709,t:1528143578527};\\\", \\\"{x:1613,y:708,t:1528143578543};\\\", \\\"{x:1614,y:705,t:1528143578559};\\\", \\\"{x:1615,y:702,t:1528143578576};\\\", \\\"{x:1615,y:700,t:1528143578593};\\\", \\\"{x:1616,y:698,t:1528143578609};\\\", \\\"{x:1617,y:693,t:1528143578626};\\\", \\\"{x:1617,y:689,t:1528143578644};\\\", \\\"{x:1619,y:685,t:1528143578659};\\\", \\\"{x:1620,y:681,t:1528143578677};\\\", \\\"{x:1621,y:676,t:1528143578694};\\\", \\\"{x:1622,y:672,t:1528143578709};\\\", \\\"{x:1623,y:670,t:1528143578727};\\\", \\\"{x:1623,y:669,t:1528143578743};\\\", \\\"{x:1624,y:666,t:1528143578759};\\\", \\\"{x:1624,y:665,t:1528143578776};\\\", \\\"{x:1624,y:663,t:1528143578793};\\\", \\\"{x:1624,y:662,t:1528143578809};\\\", \\\"{x:1625,y:660,t:1528143578826};\\\", \\\"{x:1625,y:658,t:1528143579046};\\\", \\\"{x:1625,y:656,t:1528143579166};\\\", \\\"{x:1625,y:655,t:1528143579176};\\\", \\\"{x:1625,y:654,t:1528143579193};\\\", \\\"{x:1625,y:652,t:1528143579210};\\\", \\\"{x:1625,y:650,t:1528143579230};\\\", \\\"{x:1624,y:650,t:1528143579574};\\\", \\\"{x:1623,y:649,t:1528143579590};\\\", \\\"{x:1622,y:649,t:1528143579654};\\\", \\\"{x:1621,y:648,t:1528143579685};\\\", \\\"{x:1620,y:648,t:1528143579718};\\\", \\\"{x:1620,y:647,t:1528143579733};\\\", \\\"{x:1619,y:647,t:1528143579806};\\\", \\\"{x:1619,y:646,t:1528143579894};\\\", \\\"{x:1618,y:646,t:1528143579925};\\\", \\\"{x:1617,y:646,t:1528143579941};\\\", \\\"{x:1617,y:644,t:1528143579949};\\\", \\\"{x:1616,y:644,t:1528143579960};\\\", \\\"{x:1614,y:640,t:1528143579978};\\\", \\\"{x:1614,y:639,t:1528143579994};\\\", \\\"{x:1612,y:638,t:1528143580011};\\\", \\\"{x:1612,y:637,t:1528143580027};\\\", \\\"{x:1612,y:636,t:1528143580044};\\\", \\\"{x:1611,y:635,t:1528143580445};\\\", \\\"{x:1611,y:633,t:1528143580470};\\\", \\\"{x:1611,y:632,t:1528143580478};\\\", \\\"{x:1611,y:631,t:1528143580495};\\\", \\\"{x:1612,y:628,t:1528143580512};\\\", \\\"{x:1612,y:625,t:1528143580527};\\\", \\\"{x:1612,y:620,t:1528143580544};\\\", \\\"{x:1616,y:612,t:1528143580561};\\\", \\\"{x:1619,y:603,t:1528143580576};\\\", \\\"{x:1628,y:588,t:1528143580593};\\\", \\\"{x:1639,y:571,t:1528143580611};\\\", \\\"{x:1652,y:554,t:1528143580627};\\\", \\\"{x:1663,y:537,t:1528143580644};\\\", \\\"{x:1674,y:523,t:1528143580661};\\\", \\\"{x:1678,y:517,t:1528143580677};\\\", \\\"{x:1681,y:514,t:1528143580694};\\\", \\\"{x:1680,y:514,t:1528143580757};\\\", \\\"{x:1676,y:512,t:1528143580764};\\\", \\\"{x:1674,y:512,t:1528143580778};\\\", \\\"{x:1663,y:512,t:1528143580794};\\\", \\\"{x:1656,y:512,t:1528143580811};\\\", \\\"{x:1651,y:512,t:1528143580828};\\\", \\\"{x:1648,y:512,t:1528143580845};\\\", \\\"{x:1643,y:512,t:1528143580861};\\\", \\\"{x:1639,y:513,t:1528143580877};\\\", \\\"{x:1638,y:515,t:1528143580895};\\\", \\\"{x:1635,y:515,t:1528143580911};\\\", \\\"{x:1632,y:515,t:1528143580928};\\\", \\\"{x:1630,y:515,t:1528143580944};\\\", \\\"{x:1629,y:515,t:1528143581014};\\\", \\\"{x:1628,y:515,t:1528143581045};\\\", \\\"{x:1627,y:515,t:1528143581110};\\\", \\\"{x:1626,y:515,t:1528143581430};\\\", \\\"{x:1626,y:535,t:1528143581445};\\\", \\\"{x:1627,y:537,t:1528143581461};\\\", \\\"{x:1624,y:537,t:1528143581852};\\\", \\\"{x:1608,y:533,t:1528143581862};\\\", \\\"{x:1592,y:533,t:1528143581877};\\\", \\\"{x:1582,y:534,t:1528143581895};\\\", \\\"{x:1571,y:535,t:1528143581912};\\\", \\\"{x:1561,y:536,t:1528143581927};\\\", \\\"{x:1549,y:539,t:1528143581944};\\\", \\\"{x:1534,y:541,t:1528143581962};\\\", \\\"{x:1516,y:546,t:1528143581978};\\\", \\\"{x:1469,y:550,t:1528143581995};\\\", \\\"{x:1366,y:550,t:1528143582012};\\\", \\\"{x:1261,y:550,t:1528143582028};\\\", \\\"{x:1073,y:550,t:1528143582045};\\\", \\\"{x:940,y:550,t:1528143582062};\\\", \\\"{x:818,y:550,t:1528143582077};\\\", \\\"{x:696,y:550,t:1528143582096};\\\", \\\"{x:561,y:550,t:1528143582111};\\\", \\\"{x:422,y:550,t:1528143582129};\\\", \\\"{x:292,y:550,t:1528143582146};\\\", \\\"{x:192,y:550,t:1528143582163};\\\", \\\"{x:134,y:550,t:1528143582178};\\\", \\\"{x:110,y:554,t:1528143582196};\\\", \\\"{x:105,y:555,t:1528143582212};\\\", \\\"{x:105,y:556,t:1528143582253};\\\", \\\"{x:108,y:556,t:1528143582269};\\\", \\\"{x:112,y:556,t:1528143582279};\\\", \\\"{x:133,y:556,t:1528143582296};\\\", \\\"{x:169,y:553,t:1528143582313};\\\", \\\"{x:211,y:547,t:1528143582329};\\\", \\\"{x:243,y:545,t:1528143582346};\\\", \\\"{x:267,y:540,t:1528143582363};\\\", \\\"{x:290,y:538,t:1528143582380};\\\", \\\"{x:318,y:534,t:1528143582396};\\\", \\\"{x:357,y:534,t:1528143582413};\\\", \\\"{x:383,y:533,t:1528143582429};\\\", \\\"{x:398,y:530,t:1528143582446};\\\", \\\"{x:405,y:529,t:1528143582463};\\\", \\\"{x:406,y:529,t:1528143582479};\\\", \\\"{x:407,y:529,t:1528143582605};\\\", \\\"{x:408,y:529,t:1528143582613};\\\", \\\"{x:409,y:529,t:1528143582630};\\\", \\\"{x:410,y:530,t:1528143582645};\\\", \\\"{x:411,y:531,t:1528143582663};\\\", \\\"{x:412,y:533,t:1528143582680};\\\", \\\"{x:413,y:534,t:1528143582695};\\\", \\\"{x:414,y:534,t:1528143582713};\\\", \\\"{x:414,y:535,t:1528143582877};\\\", \\\"{x:413,y:535,t:1528143582957};\\\", \\\"{x:411,y:535,t:1528143582965};\\\", \\\"{x:407,y:534,t:1528143582980};\\\", \\\"{x:394,y:534,t:1528143582996};\\\", \\\"{x:383,y:534,t:1528143583013};\\\", \\\"{x:375,y:534,t:1528143583030};\\\", \\\"{x:366,y:534,t:1528143583048};\\\", \\\"{x:360,y:534,t:1528143583063};\\\", \\\"{x:356,y:534,t:1528143583080};\\\", \\\"{x:355,y:534,t:1528143583230};\\\", \\\"{x:355,y:535,t:1528143583486};\\\", \\\"{x:355,y:536,t:1528143584788};\\\", \\\"{x:356,y:538,t:1528143584798};\\\", \\\"{x:384,y:539,t:1528143584815};\\\", \\\"{x:406,y:539,t:1528143584830};\\\", \\\"{x:419,y:539,t:1528143584848};\\\", \\\"{x:422,y:539,t:1528143584865};\\\", \\\"{x:421,y:539,t:1528143584932};\\\", \\\"{x:417,y:539,t:1528143584948};\\\", \\\"{x:393,y:533,t:1528143584964};\\\", \\\"{x:372,y:531,t:1528143584981};\\\", \\\"{x:350,y:528,t:1528143584999};\\\", \\\"{x:328,y:526,t:1528143585015};\\\", \\\"{x:308,y:521,t:1528143585031};\\\", \\\"{x:295,y:517,t:1528143585048};\\\", \\\"{x:286,y:514,t:1528143585065};\\\", \\\"{x:284,y:512,t:1528143585081};\\\", \\\"{x:284,y:511,t:1528143585101};\\\", \\\"{x:285,y:509,t:1528143585117};\\\", \\\"{x:288,y:508,t:1528143585132};\\\", \\\"{x:298,y:504,t:1528143585148};\\\", \\\"{x:311,y:497,t:1528143585165};\\\", \\\"{x:320,y:491,t:1528143585182};\\\", \\\"{x:330,y:484,t:1528143585201};\\\", \\\"{x:337,y:479,t:1528143585215};\\\", \\\"{x:341,y:477,t:1528143585232};\\\", \\\"{x:344,y:475,t:1528143585248};\\\", \\\"{x:345,y:474,t:1528143585324};\\\", \\\"{x:343,y:473,t:1528143585357};\\\", \\\"{x:341,y:473,t:1528143585364};\\\", \\\"{x:334,y:470,t:1528143585382};\\\", \\\"{x:329,y:469,t:1528143585399};\\\", \\\"{x:328,y:469,t:1528143585415};\\\", \\\"{x:326,y:469,t:1528143585470};\\\", \\\"{x:326,y:470,t:1528143585486};\\\", \\\"{x:326,y:471,t:1528143585501};\\\", \\\"{x:327,y:474,t:1528143585516};\\\", \\\"{x:330,y:475,t:1528143585533};\\\", \\\"{x:333,y:478,t:1528143585548};\\\", \\\"{x:336,y:481,t:1528143585565};\\\", \\\"{x:337,y:482,t:1528143585582};\\\", \\\"{x:330,y:482,t:1528143585629};\\\", \\\"{x:323,y:484,t:1528143585638};\\\", \\\"{x:314,y:485,t:1528143585648};\\\", \\\"{x:294,y:487,t:1528143585665};\\\", \\\"{x:274,y:493,t:1528143585682};\\\", \\\"{x:262,y:500,t:1528143585699};\\\", \\\"{x:256,y:506,t:1528143585715};\\\", \\\"{x:251,y:511,t:1528143585731};\\\", \\\"{x:243,y:518,t:1528143585749};\\\", \\\"{x:240,y:522,t:1528143585765};\\\", \\\"{x:232,y:528,t:1528143585782};\\\", \\\"{x:226,y:532,t:1528143585799};\\\", \\\"{x:218,y:534,t:1528143585815};\\\", \\\"{x:205,y:539,t:1528143585831};\\\", \\\"{x:192,y:542,t:1528143585849};\\\", \\\"{x:187,y:543,t:1528143585866};\\\", \\\"{x:180,y:545,t:1528143585882};\\\", \\\"{x:171,y:546,t:1528143585899};\\\", \\\"{x:160,y:548,t:1528143585915};\\\", \\\"{x:150,y:550,t:1528143585932};\\\", \\\"{x:135,y:552,t:1528143585949};\\\", \\\"{x:128,y:554,t:1528143585966};\\\", \\\"{x:124,y:555,t:1528143585982};\\\", \\\"{x:121,y:556,t:1528143585999};\\\", \\\"{x:124,y:556,t:1528143586182};\\\", \\\"{x:143,y:556,t:1528143586199};\\\", \\\"{x:164,y:555,t:1528143586217};\\\", \\\"{x:188,y:552,t:1528143586233};\\\", \\\"{x:212,y:548,t:1528143586249};\\\", \\\"{x:235,y:546,t:1528143586266};\\\", \\\"{x:262,y:546,t:1528143586282};\\\", \\\"{x:296,y:546,t:1528143586300};\\\", \\\"{x:321,y:546,t:1528143586316};\\\", \\\"{x:342,y:546,t:1528143586332};\\\", \\\"{x:372,y:547,t:1528143586349};\\\", \\\"{x:379,y:550,t:1528143586367};\\\", \\\"{x:382,y:551,t:1528143586382};\\\", \\\"{x:384,y:551,t:1528143586477};\\\", \\\"{x:390,y:552,t:1528143586485};\\\", \\\"{x:400,y:555,t:1528143586501};\\\", \\\"{x:428,y:558,t:1528143586517};\\\", \\\"{x:468,y:561,t:1528143586532};\\\", \\\"{x:492,y:561,t:1528143586549};\\\", \\\"{x:518,y:561,t:1528143586566};\\\", \\\"{x:551,y:561,t:1528143586583};\\\", \\\"{x:585,y:561,t:1528143586599};\\\", \\\"{x:611,y:561,t:1528143586616};\\\", \\\"{x:627,y:561,t:1528143586633};\\\", \\\"{x:635,y:561,t:1528143586649};\\\", \\\"{x:636,y:561,t:1528143586666};\\\", \\\"{x:635,y:561,t:1528143586774};\\\", \\\"{x:632,y:560,t:1528143586783};\\\", \\\"{x:627,y:558,t:1528143586799};\\\", \\\"{x:625,y:557,t:1528143586816};\\\", \\\"{x:623,y:556,t:1528143586833};\\\", \\\"{x:622,y:556,t:1528143586849};\\\", \\\"{x:619,y:554,t:1528143586866};\\\", \\\"{x:614,y:553,t:1528143586883};\\\", \\\"{x:602,y:549,t:1528143586899};\\\", \\\"{x:582,y:545,t:1528143586916};\\\", \\\"{x:538,y:539,t:1528143586933};\\\", \\\"{x:514,y:538,t:1528143586950};\\\", \\\"{x:501,y:538,t:1528143586966};\\\", \\\"{x:493,y:538,t:1528143586984};\\\", \\\"{x:489,y:538,t:1528143587000};\\\", \\\"{x:485,y:538,t:1528143587016};\\\", \\\"{x:480,y:538,t:1528143587033};\\\", \\\"{x:474,y:538,t:1528143587050};\\\", \\\"{x:468,y:539,t:1528143587066};\\\", \\\"{x:461,y:541,t:1528143587083};\\\", \\\"{x:452,y:543,t:1528143587100};\\\", \\\"{x:445,y:544,t:1528143587116};\\\", \\\"{x:432,y:546,t:1528143587132};\\\", \\\"{x:421,y:548,t:1528143587150};\\\", \\\"{x:413,y:549,t:1528143587167};\\\", \\\"{x:405,y:551,t:1528143587183};\\\", \\\"{x:400,y:552,t:1528143587200};\\\", \\\"{x:388,y:552,t:1528143587217};\\\", \\\"{x:379,y:553,t:1528143587233};\\\", \\\"{x:359,y:556,t:1528143587250};\\\", \\\"{x:334,y:558,t:1528143587267};\\\", \\\"{x:294,y:561,t:1528143587285};\\\", \\\"{x:249,y:562,t:1528143587300};\\\", \\\"{x:212,y:562,t:1528143587316};\\\", \\\"{x:167,y:562,t:1528143587333};\\\", \\\"{x:145,y:562,t:1528143587350};\\\", \\\"{x:130,y:562,t:1528143587367};\\\", \\\"{x:125,y:564,t:1528143587383};\\\", \\\"{x:121,y:566,t:1528143587400};\\\", \\\"{x:115,y:567,t:1528143587417};\\\", \\\"{x:118,y:567,t:1528143587533};\\\", \\\"{x:130,y:564,t:1528143587551};\\\", \\\"{x:150,y:558,t:1528143587568};\\\", \\\"{x:171,y:552,t:1528143587583};\\\", \\\"{x:182,y:548,t:1528143587600};\\\", \\\"{x:186,y:547,t:1528143587617};\\\", \\\"{x:188,y:546,t:1528143587633};\\\", \\\"{x:189,y:545,t:1528143587684};\\\", \\\"{x:190,y:544,t:1528143587717};\\\", \\\"{x:190,y:543,t:1528143587741};\\\", \\\"{x:192,y:542,t:1528143587774};\\\", \\\"{x:192,y:541,t:1528143587797};\\\", \\\"{x:192,y:540,t:1528143587804};\\\", \\\"{x:192,y:539,t:1528143587820};\\\", \\\"{x:192,y:538,t:1528143587833};\\\", \\\"{x:192,y:535,t:1528143587850};\\\", \\\"{x:192,y:531,t:1528143587867};\\\", \\\"{x:192,y:526,t:1528143587883};\\\", \\\"{x:192,y:518,t:1528143587901};\\\", \\\"{x:192,y:510,t:1528143587917};\\\", \\\"{x:193,y:508,t:1528143587934};\\\", \\\"{x:196,y:506,t:1528143587950};\\\", \\\"{x:198,y:505,t:1528143587972};\\\", \\\"{x:199,y:505,t:1528143587984};\\\", \\\"{x:209,y:504,t:1528143588000};\\\", \\\"{x:231,y:504,t:1528143588018};\\\", \\\"{x:259,y:504,t:1528143588035};\\\", \\\"{x:293,y:504,t:1528143588051};\\\", \\\"{x:320,y:504,t:1528143588067};\\\", \\\"{x:344,y:504,t:1528143588084};\\\", \\\"{x:365,y:504,t:1528143588101};\\\", \\\"{x:370,y:504,t:1528143588117};\\\", \\\"{x:372,y:504,t:1528143588135};\\\", \\\"{x:377,y:504,t:1528143588152};\\\", \\\"{x:387,y:504,t:1528143588168};\\\", \\\"{x:398,y:504,t:1528143588184};\\\", \\\"{x:409,y:504,t:1528143588200};\\\", \\\"{x:415,y:504,t:1528143588217};\\\", \\\"{x:418,y:504,t:1528143588235};\\\", \\\"{x:420,y:504,t:1528143588341};\\\", \\\"{x:423,y:504,t:1528143588364};\\\", \\\"{x:427,y:506,t:1528143588373};\\\", \\\"{x:433,y:506,t:1528143588384};\\\", \\\"{x:448,y:507,t:1528143588401};\\\", \\\"{x:466,y:507,t:1528143588417};\\\", \\\"{x:488,y:507,t:1528143588434};\\\", \\\"{x:505,y:507,t:1528143588452};\\\", \\\"{x:521,y:507,t:1528143588467};\\\", \\\"{x:532,y:507,t:1528143588484};\\\", \\\"{x:543,y:507,t:1528143588501};\\\", \\\"{x:550,y:507,t:1528143588517};\\\", \\\"{x:555,y:507,t:1528143588534};\\\", \\\"{x:560,y:507,t:1528143588551};\\\", \\\"{x:568,y:507,t:1528143588567};\\\", \\\"{x:583,y:507,t:1528143588584};\\\", \\\"{x:600,y:507,t:1528143588602};\\\", \\\"{x:614,y:507,t:1528143588618};\\\", \\\"{x:624,y:507,t:1528143588634};\\\", \\\"{x:628,y:507,t:1528143588651};\\\", \\\"{x:629,y:507,t:1528143588667};\\\", \\\"{x:628,y:507,t:1528143589014};\\\", \\\"{x:627,y:507,t:1528143589021};\\\", \\\"{x:626,y:507,t:1528143589045};\\\", \\\"{x:625,y:507,t:1528143589053};\\\", \\\"{x:624,y:507,t:1528143589069};\\\", \\\"{x:626,y:508,t:1528143589404};\\\", \\\"{x:631,y:510,t:1528143589419};\\\", \\\"{x:651,y:518,t:1528143589436};\\\", \\\"{x:692,y:532,t:1528143589454};\\\", \\\"{x:746,y:541,t:1528143589469};\\\", \\\"{x:826,y:554,t:1528143589486};\\\", \\\"{x:865,y:554,t:1528143589502};\\\", \\\"{x:886,y:554,t:1528143589518};\\\", \\\"{x:891,y:554,t:1528143589535};\\\", \\\"{x:891,y:553,t:1528143589564};\\\", \\\"{x:891,y:551,t:1528143589572};\\\", \\\"{x:884,y:546,t:1528143589585};\\\", \\\"{x:867,y:538,t:1528143589602};\\\", \\\"{x:852,y:531,t:1528143589619};\\\", \\\"{x:842,y:526,t:1528143589635};\\\", \\\"{x:830,y:520,t:1528143589653};\\\", \\\"{x:827,y:518,t:1528143589668};\\\", \\\"{x:825,y:516,t:1528143589685};\\\", \\\"{x:823,y:513,t:1528143589701};\\\", \\\"{x:821,y:511,t:1528143589718};\\\", \\\"{x:820,y:508,t:1528143589735};\\\", \\\"{x:820,y:507,t:1528143589751};\\\", \\\"{x:820,y:506,t:1528143589768};\\\", \\\"{x:820,y:505,t:1528143589797};\\\", \\\"{x:816,y:506,t:1528143590070};\\\", \\\"{x:795,y:508,t:1528143590085};\\\", \\\"{x:771,y:516,t:1528143590102};\\\", \\\"{x:747,y:526,t:1528143590120};\\\", \\\"{x:725,y:537,t:1528143590134};\\\", \\\"{x:694,y:556,t:1528143590152};\\\", \\\"{x:658,y:577,t:1528143590170};\\\", \\\"{x:612,y:602,t:1528143590186};\\\", \\\"{x:582,y:622,t:1528143590202};\\\", \\\"{x:566,y:631,t:1528143590219};\\\", \\\"{x:559,y:635,t:1528143590235};\\\", \\\"{x:555,y:637,t:1528143590252};\\\", \\\"{x:557,y:637,t:1528143590390};\\\", \\\"{x:571,y:637,t:1528143590402};\\\", \\\"{x:615,y:629,t:1528143590420};\\\", \\\"{x:693,y:614,t:1528143590436};\\\", \\\"{x:799,y:583,t:1528143590453};\\\", \\\"{x:855,y:558,t:1528143590470};\\\", \\\"{x:890,y:539,t:1528143590486};\\\", \\\"{x:905,y:526,t:1528143590503};\\\", \\\"{x:913,y:512,t:1528143590519};\\\", \\\"{x:916,y:507,t:1528143590536};\\\", \\\"{x:916,y:499,t:1528143590553};\\\", \\\"{x:919,y:494,t:1528143590569};\\\", \\\"{x:921,y:488,t:1528143590587};\\\", \\\"{x:922,y:482,t:1528143590603};\\\", \\\"{x:922,y:479,t:1528143590619};\\\", \\\"{x:915,y:477,t:1528143590636};\\\", \\\"{x:896,y:477,t:1528143590652};\\\", \\\"{x:868,y:480,t:1528143590669};\\\", \\\"{x:843,y:487,t:1528143590687};\\\", \\\"{x:827,y:492,t:1528143590703};\\\", \\\"{x:821,y:495,t:1528143590719};\\\", \\\"{x:819,y:496,t:1528143590736};\\\", \\\"{x:818,y:497,t:1528143590773};\\\", \\\"{x:818,y:498,t:1528143590785};\\\", \\\"{x:818,y:500,t:1528143590803};\\\", \\\"{x:818,y:502,t:1528143590819};\\\", \\\"{x:818,y:508,t:1528143590836};\\\", \\\"{x:818,y:509,t:1528143590852};\\\", \\\"{x:819,y:515,t:1528143590869};\\\", \\\"{x:819,y:516,t:1528143590885};\\\", \\\"{x:820,y:516,t:1528143590997};\\\", \\\"{x:821,y:515,t:1528143591013};\\\", \\\"{x:822,y:515,t:1528143591206};\\\", \\\"{x:822,y:516,t:1528143591221};\\\", \\\"{x:822,y:518,t:1528143591332};\\\", \\\"{x:822,y:519,t:1528143591348};\\\", \\\"{x:823,y:519,t:1528143591470};\\\", \\\"{x:825,y:519,t:1528143591485};\\\", \\\"{x:827,y:518,t:1528143591503};\\\", \\\"{x:828,y:518,t:1528143591519};\\\", \\\"{x:828,y:517,t:1528143591536};\\\", \\\"{x:829,y:516,t:1528143591552};\\\", \\\"{x:831,y:515,t:1528143591570};\\\", \\\"{x:832,y:514,t:1528143591597};\\\", \\\"{x:833,y:514,t:1528143591605};\\\", \\\"{x:833,y:513,t:1528143591638};\\\", \\\"{x:833,y:512,t:1528143591669};\\\", \\\"{x:832,y:511,t:1528143591749};\\\", \\\"{x:831,y:511,t:1528143591804};\\\", \\\"{x:831,y:511,t:1528143591812};\\\", \\\"{x:828,y:511,t:1528143591981};\\\", \\\"{x:825,y:513,t:1528143591989};\\\", \\\"{x:821,y:515,t:1528143592003};\\\", \\\"{x:794,y:526,t:1528143592021};\\\", \\\"{x:766,y:541,t:1528143592037};\\\", \\\"{x:721,y:561,t:1528143592054};\\\", \\\"{x:666,y:584,t:1528143592071};\\\", \\\"{x:582,y:611,t:1528143592088};\\\", \\\"{x:513,y:632,t:1528143592104};\\\", \\\"{x:462,y:655,t:1528143592121};\\\", \\\"{x:429,y:675,t:1528143592138};\\\", \\\"{x:415,y:687,t:1528143592153};\\\", \\\"{x:413,y:689,t:1528143592170};\\\", \\\"{x:412,y:690,t:1528143592187};\\\", \\\"{x:412,y:688,t:1528143592405};\\\", \\\"{x:414,y:678,t:1528143592421};\\\", \\\"{x:416,y:672,t:1528143592438};\\\", \\\"{x:418,y:669,t:1528143592455};\\\", \\\"{x:419,y:668,t:1528143592830};\\\", \\\"{x:420,y:665,t:1528143592837};\\\", \\\"{x:420,y:664,t:1528143592855};\\\", \\\"{x:420,y:663,t:1528143592957};\\\", \\\"{x:422,y:663,t:1528143593349};\\\", \\\"{x:431,y:663,t:1528143593357};\\\", \\\"{x:445,y:663,t:1528143593372};\\\", \\\"{x:475,y:661,t:1528143593388};\\\", \\\"{x:518,y:654,t:1528143593405};\\\", \\\"{x:536,y:652,t:1528143593421};\\\", \\\"{x:542,y:650,t:1528143593439};\\\", \\\"{x:542,y:649,t:1528143594021};\\\", \\\"{x:543,y:648,t:1528143594069};\\\", \\\"{x:544,y:648,t:1528143594077};\\\", \\\"{x:546,y:648,t:1528143594088};\\\", \\\"{x:548,y:648,t:1528143594106};\\\", \\\"{x:549,y:649,t:1528143594302};\\\", \\\"{x:552,y:650,t:1528143594310};\\\", \\\"{x:554,y:651,t:1528143594321};\\\", \\\"{x:559,y:651,t:1528143594338};\\\", \\\"{x:561,y:654,t:1528143594355};\\\", \\\"{x:564,y:655,t:1528143594371};\\\", \\\"{x:565,y:655,t:1528143594389};\\\", \\\"{x:566,y:655,t:1528143595174};\\\", \\\"{x:566,y:656,t:1528143595508};\\\", \\\"{x:567,y:657,t:1528143595525};\\\", \\\"{x:568,y:657,t:1528143595540};\\\", \\\"{x:568,y:661,t:1528143595669};\\\", \\\"{x:568,y:665,t:1528143595677};\\\", \\\"{x:565,y:676,t:1528143595690};\\\", \\\"{x:557,y:699,t:1528143595707};\\\", \\\"{x:546,y:726,t:1528143595724};\\\", \\\"{x:532,y:753,t:1528143595740};\\\", \\\"{x:508,y:785,t:1528143595757};\\\", \\\"{x:495,y:799,t:1528143595773};\\\", \\\"{x:488,y:806,t:1528143595791};\\\", \\\"{x:484,y:811,t:1528143595807};\\\", \\\"{x:481,y:814,t:1528143595824};\\\", \\\"{x:478,y:819,t:1528143595841};\\\", \\\"{x:475,y:823,t:1528143595857};\\\", \\\"{x:473,y:825,t:1528143595874};\\\", \\\"{x:473,y:826,t:1528143595893};\\\", \\\"{x:473,y:827,t:1528143595932};\\\", \\\"{x:473,y:828,t:1528143596503};\\\", \\\"{x:473,y:834,t:1528143596510};\\\", \\\"{x:473,y:837,t:1528143596524};\\\", \\\"{x:471,y:841,t:1528143596542};\\\", \\\"{x:470,y:843,t:1528143596557};\\\", \\\"{x:470,y:844,t:1528143596574};\\\", \\\"{x:470,y:845,t:1528143597333};\\\", \\\"{x:471,y:845,t:1528143597350};\\\", \\\"{x:474,y:845,t:1528143597358};\\\", \\\"{x:479,y:843,t:1528143597375};\\\", \\\"{x:483,y:841,t:1528143597391};\\\", \\\"{x:487,y:839,t:1528143597408};\\\", \\\"{x:495,y:834,t:1528143597425};\\\", \\\"{x:501,y:829,t:1528143597442};\\\", \\\"{x:509,y:822,t:1528143597457};\\\", \\\"{x:513,y:815,t:1528143597475};\\\", \\\"{x:518,y:808,t:1528143597492};\\\", \\\"{x:522,y:793,t:1528143597509};\\\", \\\"{x:526,y:783,t:1528143597525};\\\", \\\"{x:528,y:772,t:1528143597542};\\\", \\\"{x:529,y:762,t:1528143597559};\\\", \\\"{x:530,y:758,t:1528143597575};\\\", \\\"{x:531,y:753,t:1528143597592};\\\", \\\"{x:531,y:752,t:1528143597622};\\\", \\\"{x:531,y:747,t:1528143597686};\\\", \\\"{x:531,y:742,t:1528143597693};\\\", \\\"{x:531,y:731,t:1528143597709};\\\", \\\"{x:531,y:725,t:1528143597725};\\\", \\\"{x:531,y:720,t:1528143597742};\\\", \\\"{x:531,y:715,t:1528143597760};\\\", \\\"{x:531,y:711,t:1528143597776};\\\", \\\"{x:531,y:706,t:1528143597792};\\\", \\\"{x:529,y:700,t:1528143597809};\\\", \\\"{x:527,y:695,t:1528143597825};\\\", \\\"{x:526,y:689,t:1528143597842};\\\", \\\"{x:525,y:684,t:1528143597860};\\\", \\\"{x:521,y:676,t:1528143597877};\\\", \\\"{x:519,y:671,t:1528143597892};\\\", \\\"{x:518,y:669,t:1528143597909};\\\", \\\"{x:518,y:668,t:1528143597940};\\\", \\\"{x:517,y:665,t:1528143597956};\\\", \\\"{x:516,y:664,t:1528143597964};\\\", \\\"{x:516,y:663,t:1528143597976};\\\", \\\"{x:516,y:661,t:1528143597991};\\\", \\\"{x:516,y:659,t:1528143598012};\\\", \\\"{x:516,y:663,t:1528143598488};\\\", \\\"{x:516,y:671,t:1528143598496};\\\", \\\"{x:516,y:687,t:1528143598511};\\\", \\\"{x:516,y:711,t:1528143598529};\\\", \\\"{x:517,y:732,t:1528143598546};\\\", \\\"{x:519,y:760,t:1528143598562};\\\", \\\"{x:520,y:787,t:1528143598579};\\\", \\\"{x:522,y:814,t:1528143598596};\\\", \\\"{x:526,y:842,t:1528143598612};\\\", \\\"{x:530,y:873,t:1528143598629};\\\", \\\"{x:536,y:899,t:1528143598646};\\\", \\\"{x:538,y:914,t:1528143598663};\\\", \\\"{x:540,y:922,t:1528143598679};\\\" ] }, { \\\"rt\\\": 65720, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 186617, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"8182H\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -I -12 PM-08 PM-05 PM-K -H -I -03 PM-I -7-I -I -08 AM-I -03 PM-03 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:541,y:916,t:1528143601337};\\\", \\\"{x:552,y:848,t:1528143601349};\\\", \\\"{x:608,y:676,t:1528143601365};\\\", \\\"{x:634,y:579,t:1528143601382};\\\", \\\"{x:636,y:565,t:1528143601401};\\\", \\\"{x:636,y:564,t:1528143601439};\\\", \\\"{x:636,y:562,t:1528143601448};\\\", \\\"{x:636,y:535,t:1528143601466};\\\", \\\"{x:637,y:505,t:1528143601481};\\\", \\\"{x:641,y:494,t:1528143601499};\\\", \\\"{x:641,y:493,t:1528143601515};\\\", \\\"{x:644,y:492,t:1528143601745};\\\", \\\"{x:653,y:487,t:1528143601752};\\\", \\\"{x:660,y:479,t:1528143601766};\\\", \\\"{x:674,y:467,t:1528143601783};\\\", \\\"{x:679,y:466,t:1528143601800};\\\", \\\"{x:684,y:464,t:1528143601816};\\\", \\\"{x:687,y:464,t:1528143601929};\\\", \\\"{x:688,y:464,t:1528143601937};\\\", \\\"{x:690,y:464,t:1528143601948};\\\", \\\"{x:692,y:464,t:1528143601966};\\\", \\\"{x:696,y:465,t:1528143601983};\\\", \\\"{x:698,y:467,t:1528143601999};\\\", \\\"{x:702,y:469,t:1528143602016};\\\", \\\"{x:707,y:481,t:1528143602032};\\\", \\\"{x:711,y:488,t:1528143602049};\\\", \\\"{x:714,y:493,t:1528143602065};\\\", \\\"{x:719,y:502,t:1528143602082};\\\", \\\"{x:731,y:524,t:1528143602099};\\\", \\\"{x:741,y:546,t:1528143602116};\\\", \\\"{x:742,y:557,t:1528143602132};\\\", \\\"{x:742,y:569,t:1528143602149};\\\", \\\"{x:742,y:577,t:1528143602166};\\\", \\\"{x:742,y:585,t:1528143602183};\\\", \\\"{x:742,y:590,t:1528143602198};\\\", \\\"{x:742,y:591,t:1528143602215};\\\", \\\"{x:742,y:593,t:1528143602232};\\\", \\\"{x:741,y:594,t:1528143602249};\\\", \\\"{x:741,y:595,t:1528143602272};\\\", \\\"{x:739,y:596,t:1528143602312};\\\", \\\"{x:738,y:596,t:1528143602337};\\\", \\\"{x:736,y:596,t:1528143603769};\\\", \\\"{x:750,y:605,t:1528143604129};\\\", \\\"{x:812,y:632,t:1528143604137};\\\", \\\"{x:875,y:662,t:1528143604151};\\\", \\\"{x:965,y:696,t:1528143604168};\\\", \\\"{x:1233,y:750,t:1528143604184};\\\", \\\"{x:1452,y:785,t:1528143604200};\\\", \\\"{x:1645,y:812,t:1528143604217};\\\", \\\"{x:1697,y:820,t:1528143604235};\\\", \\\"{x:1697,y:821,t:1528143604729};\\\", \\\"{x:1692,y:823,t:1528143604737};\\\", \\\"{x:1686,y:825,t:1528143604752};\\\", \\\"{x:1677,y:827,t:1528143604768};\\\", \\\"{x:1669,y:827,t:1528143604785};\\\", \\\"{x:1663,y:828,t:1528143604803};\\\", \\\"{x:1658,y:828,t:1528143604820};\\\", \\\"{x:1652,y:828,t:1528143604835};\\\", \\\"{x:1646,y:829,t:1528143604852};\\\", \\\"{x:1638,y:832,t:1528143604869};\\\", \\\"{x:1623,y:833,t:1528143604885};\\\", \\\"{x:1602,y:837,t:1528143604902};\\\", \\\"{x:1581,y:839,t:1528143604919};\\\", \\\"{x:1556,y:845,t:1528143604935};\\\", \\\"{x:1486,y:849,t:1528143604953};\\\", \\\"{x:1449,y:851,t:1528143604968};\\\", \\\"{x:1422,y:851,t:1528143604986};\\\", \\\"{x:1399,y:851,t:1528143605002};\\\", \\\"{x:1382,y:851,t:1528143605019};\\\", \\\"{x:1377,y:851,t:1528143605036};\\\", \\\"{x:1378,y:847,t:1528143605338};\\\", \\\"{x:1389,y:839,t:1528143605353};\\\", \\\"{x:1432,y:808,t:1528143605369};\\\", \\\"{x:1469,y:780,t:1528143605386};\\\", \\\"{x:1514,y:736,t:1528143605402};\\\", \\\"{x:1550,y:711,t:1528143605420};\\\", \\\"{x:1573,y:693,t:1528143605437};\\\", \\\"{x:1592,y:673,t:1528143605453};\\\", \\\"{x:1605,y:655,t:1528143605469};\\\", \\\"{x:1610,y:645,t:1528143605487};\\\", \\\"{x:1610,y:643,t:1528143605793};\\\", \\\"{x:1608,y:642,t:1528143605804};\\\", \\\"{x:1604,y:641,t:1528143605820};\\\", \\\"{x:1600,y:639,t:1528143605835};\\\", \\\"{x:1598,y:638,t:1528143605853};\\\", \\\"{x:1597,y:638,t:1528143605888};\\\", \\\"{x:1595,y:637,t:1528143605912};\\\", \\\"{x:1594,y:636,t:1528143605944};\\\", \\\"{x:1592,y:636,t:1528143605985};\\\", \\\"{x:1592,y:635,t:1528143605992};\\\", \\\"{x:1590,y:634,t:1528143606003};\\\", \\\"{x:1561,y:619,t:1528143606019};\\\", \\\"{x:1503,y:580,t:1528143606036};\\\", \\\"{x:1409,y:519,t:1528143606053};\\\", \\\"{x:1308,y:448,t:1528143606070};\\\", \\\"{x:1222,y:405,t:1528143606086};\\\", \\\"{x:1180,y:386,t:1528143606103};\\\", \\\"{x:1165,y:377,t:1528143606120};\\\", \\\"{x:1161,y:374,t:1528143606136};\\\", \\\"{x:1160,y:373,t:1528143606153};\\\", \\\"{x:1166,y:373,t:1528143606257};\\\", \\\"{x:1179,y:378,t:1528143606270};\\\", \\\"{x:1216,y:393,t:1528143606287};\\\", \\\"{x:1248,y:405,t:1528143606302};\\\", \\\"{x:1283,y:415,t:1528143606319};\\\", \\\"{x:1302,y:420,t:1528143606336};\\\", \\\"{x:1308,y:422,t:1528143606352};\\\", \\\"{x:1310,y:422,t:1528143606370};\\\", \\\"{x:1311,y:423,t:1528143606432};\\\", \\\"{x:1313,y:424,t:1528143606447};\\\", \\\"{x:1314,y:426,t:1528143606456};\\\", \\\"{x:1315,y:426,t:1528143606469};\\\", \\\"{x:1315,y:427,t:1528143606486};\\\", \\\"{x:1315,y:430,t:1528143606617};\\\", \\\"{x:1315,y:432,t:1528143606625};\\\", \\\"{x:1315,y:433,t:1528143606637};\\\", \\\"{x:1315,y:436,t:1528143606654};\\\", \\\"{x:1315,y:437,t:1528143606670};\\\", \\\"{x:1315,y:439,t:1528143606688};\\\", \\\"{x:1315,y:440,t:1528143606704};\\\", \\\"{x:1314,y:442,t:1528143606719};\\\", \\\"{x:1313,y:443,t:1528143606736};\\\", \\\"{x:1311,y:445,t:1528143606754};\\\", \\\"{x:1309,y:446,t:1528143606770};\\\", \\\"{x:1307,y:447,t:1528143606788};\\\", \\\"{x:1305,y:447,t:1528143606804};\\\", \\\"{x:1302,y:447,t:1528143606820};\\\", \\\"{x:1299,y:449,t:1528143606837};\\\", \\\"{x:1298,y:450,t:1528143606854};\\\", \\\"{x:1300,y:450,t:1528143607489};\\\", \\\"{x:1302,y:449,t:1528143607504};\\\", \\\"{x:1303,y:447,t:1528143607521};\\\", \\\"{x:1304,y:446,t:1528143607538};\\\", \\\"{x:1305,y:446,t:1528143607554};\\\", \\\"{x:1306,y:446,t:1528143608313};\\\", \\\"{x:1308,y:445,t:1528143608336};\\\", \\\"{x:1308,y:443,t:1528143608345};\\\", \\\"{x:1309,y:442,t:1528143608356};\\\", \\\"{x:1310,y:441,t:1528143608371};\\\", \\\"{x:1311,y:451,t:1528143622130};\\\", \\\"{x:1320,y:503,t:1528143622137};\\\", \\\"{x:1340,y:580,t:1528143622152};\\\", \\\"{x:1386,y:773,t:1528143622168};\\\", \\\"{x:1417,y:881,t:1528143622186};\\\", \\\"{x:1442,y:972,t:1528143622202};\\\", \\\"{x:1464,y:1047,t:1528143622219};\\\", \\\"{x:1583,y:1089,t:1528143622505};\\\", \\\"{x:1572,y:1081,t:1528143622519};\\\", \\\"{x:1555,y:1068,t:1528143622532};\\\", \\\"{x:1545,y:1058,t:1528143622550};\\\", \\\"{x:1539,y:1049,t:1528143622565};\\\", \\\"{x:1534,y:1039,t:1528143622582};\\\", \\\"{x:1531,y:1033,t:1528143622598};\\\", \\\"{x:1529,y:1025,t:1528143622615};\\\", \\\"{x:1526,y:1010,t:1528143622631};\\\", \\\"{x:1525,y:1002,t:1528143622648};\\\", \\\"{x:1523,y:994,t:1528143622666};\\\", \\\"{x:1522,y:991,t:1528143622683};\\\", \\\"{x:1521,y:989,t:1528143622698};\\\", \\\"{x:1519,y:987,t:1528143622716};\\\", \\\"{x:1518,y:987,t:1528143622744};\\\", \\\"{x:1517,y:987,t:1528143622768};\\\", \\\"{x:1516,y:987,t:1528143622792};\\\", \\\"{x:1515,y:987,t:1528143622993};\\\", \\\"{x:1514,y:987,t:1528143623265};\\\", \\\"{x:1513,y:988,t:1528143623288};\\\", \\\"{x:1513,y:991,t:1528143623300};\\\", \\\"{x:1508,y:1007,t:1528143623316};\\\", \\\"{x:1505,y:1017,t:1528143623333};\\\", \\\"{x:1500,y:1029,t:1528143623350};\\\", \\\"{x:1497,y:1038,t:1528143623366};\\\", \\\"{x:1493,y:1050,t:1528143623382};\\\", \\\"{x:1491,y:1059,t:1528143623399};\\\", \\\"{x:1487,y:1070,t:1528143623416};\\\", \\\"{x:1486,y:1079,t:1528143623432};\\\", \\\"{x:1485,y:1087,t:1528143623449};\\\", \\\"{x:1484,y:1092,t:1528143623463};\\\", \\\"{x:1462,y:1093,t:1528143624017};\\\", \\\"{x:1462,y:1082,t:1528143624033};\\\", \\\"{x:1462,y:1069,t:1528143624050};\\\", \\\"{x:1462,y:1058,t:1528143624067};\\\", \\\"{x:1461,y:1049,t:1528143624083};\\\", \\\"{x:1457,y:1038,t:1528143624101};\\\", \\\"{x:1454,y:1030,t:1528143624117};\\\", \\\"{x:1450,y:1022,t:1528143624134};\\\", \\\"{x:1443,y:1011,t:1528143624150};\\\", \\\"{x:1439,y:1005,t:1528143624167};\\\", \\\"{x:1439,y:1004,t:1528143624184};\\\", \\\"{x:1438,y:1001,t:1528143624785};\\\", \\\"{x:1435,y:1001,t:1528143624801};\\\", \\\"{x:1434,y:1000,t:1528143625329};\\\", \\\"{x:1433,y:997,t:1528143625336};\\\", \\\"{x:1431,y:997,t:1528143625351};\\\", \\\"{x:1430,y:993,t:1528143625369};\\\", \\\"{x:1424,y:984,t:1528143625385};\\\", \\\"{x:1420,y:977,t:1528143625400};\\\", \\\"{x:1416,y:976,t:1528143625417};\\\", \\\"{x:1411,y:974,t:1528143625434};\\\", \\\"{x:1407,y:973,t:1528143625451};\\\", \\\"{x:1403,y:972,t:1528143625468};\\\", \\\"{x:1402,y:972,t:1528143625484};\\\", \\\"{x:1400,y:972,t:1528143625502};\\\", \\\"{x:1398,y:971,t:1528143625518};\\\", \\\"{x:1397,y:971,t:1528143625534};\\\", \\\"{x:1391,y:970,t:1528143625552};\\\", \\\"{x:1375,y:964,t:1528143625568};\\\", \\\"{x:1353,y:959,t:1528143625585};\\\", \\\"{x:1338,y:952,t:1528143625603};\\\", \\\"{x:1327,y:947,t:1528143625619};\\\", \\\"{x:1323,y:945,t:1528143625635};\\\", \\\"{x:1319,y:943,t:1528143625651};\\\", \\\"{x:1317,y:940,t:1528143625668};\\\", \\\"{x:1317,y:939,t:1528143625969};\\\", \\\"{x:1327,y:935,t:1528143625986};\\\", \\\"{x:1338,y:931,t:1528143626002};\\\", \\\"{x:1353,y:923,t:1528143626019};\\\", \\\"{x:1365,y:918,t:1528143626035};\\\", \\\"{x:1372,y:917,t:1528143626052};\\\", \\\"{x:1375,y:916,t:1528143626069};\\\", \\\"{x:1375,y:915,t:1528143626084};\\\", \\\"{x:1372,y:915,t:1528143626385};\\\", \\\"{x:1368,y:915,t:1528143626403};\\\", \\\"{x:1363,y:915,t:1528143626420};\\\", \\\"{x:1360,y:915,t:1528143626436};\\\", \\\"{x:1358,y:915,t:1528143626453};\\\", \\\"{x:1357,y:915,t:1528143626470};\\\", \\\"{x:1357,y:914,t:1528143629321};\\\", \\\"{x:1371,y:904,t:1528143629339};\\\", \\\"{x:1386,y:897,t:1528143629355};\\\", \\\"{x:1399,y:890,t:1528143629371};\\\", \\\"{x:1414,y:885,t:1528143629388};\\\", \\\"{x:1418,y:882,t:1528143629405};\\\", \\\"{x:1432,y:877,t:1528143629421};\\\", \\\"{x:1467,y:875,t:1528143629437};\\\", \\\"{x:1518,y:875,t:1528143629454};\\\", \\\"{x:1576,y:875,t:1528143629471};\\\", \\\"{x:1658,y:873,t:1528143629487};\\\", \\\"{x:1694,y:873,t:1528143629504};\\\", \\\"{x:1723,y:873,t:1528143629520};\\\", \\\"{x:1755,y:876,t:1528143629537};\\\", \\\"{x:1780,y:879,t:1528143629555};\\\", \\\"{x:1806,y:885,t:1528143629571};\\\", \\\"{x:1834,y:892,t:1528143629588};\\\", \\\"{x:1856,y:897,t:1528143629604};\\\", \\\"{x:1872,y:900,t:1528143629621};\\\", \\\"{x:1879,y:903,t:1528143629638};\\\", \\\"{x:1880,y:904,t:1528143629655};\\\", \\\"{x:1881,y:905,t:1528143629670};\\\", \\\"{x:1881,y:906,t:1528143629688};\\\", \\\"{x:1881,y:909,t:1528143629705};\\\", \\\"{x:1880,y:917,t:1528143629721};\\\", \\\"{x:1867,y:930,t:1528143629738};\\\", \\\"{x:1845,y:942,t:1528143629755};\\\", \\\"{x:1818,y:952,t:1528143629771};\\\", \\\"{x:1793,y:959,t:1528143629788};\\\", \\\"{x:1764,y:965,t:1528143629805};\\\", \\\"{x:1752,y:970,t:1528143629822};\\\", \\\"{x:1750,y:970,t:1528143629838};\\\", \\\"{x:1749,y:970,t:1528143629855};\\\", \\\"{x:1747,y:970,t:1528143629871};\\\", \\\"{x:1745,y:968,t:1528143629888};\\\", \\\"{x:1745,y:966,t:1528143629904};\\\", \\\"{x:1743,y:964,t:1528143629921};\\\", \\\"{x:1741,y:959,t:1528143629938};\\\", \\\"{x:1739,y:956,t:1528143629955};\\\", \\\"{x:1735,y:949,t:1528143629972};\\\", \\\"{x:1728,y:942,t:1528143629988};\\\", \\\"{x:1717,y:934,t:1528143630005};\\\", \\\"{x:1706,y:929,t:1528143630022};\\\", \\\"{x:1672,y:916,t:1528143630039};\\\", \\\"{x:1627,y:903,t:1528143630055};\\\", \\\"{x:1593,y:893,t:1528143630072};\\\", \\\"{x:1576,y:889,t:1528143630088};\\\", \\\"{x:1573,y:888,t:1528143630105};\\\", \\\"{x:1572,y:888,t:1528143630345};\\\", \\\"{x:1574,y:888,t:1528143630355};\\\", \\\"{x:1582,y:891,t:1528143630372};\\\", \\\"{x:1590,y:893,t:1528143630389};\\\", \\\"{x:1596,y:894,t:1528143630405};\\\", \\\"{x:1602,y:897,t:1528143630421};\\\", \\\"{x:1605,y:897,t:1528143630439};\\\", \\\"{x:1607,y:898,t:1528143630454};\\\", \\\"{x:1607,y:897,t:1528143630719};\\\", \\\"{x:1604,y:890,t:1528143630728};\\\", \\\"{x:1597,y:880,t:1528143630739};\\\", \\\"{x:1588,y:860,t:1528143630755};\\\", \\\"{x:1568,y:811,t:1528143630771};\\\", \\\"{x:1547,y:724,t:1528143630788};\\\", \\\"{x:1538,y:641,t:1528143630805};\\\", \\\"{x:1530,y:585,t:1528143630821};\\\", \\\"{x:1524,y:554,t:1528143630839};\\\", \\\"{x:1513,y:514,t:1528143630856};\\\", \\\"{x:1506,y:494,t:1528143630872};\\\", \\\"{x:1503,y:486,t:1528143630889};\\\", \\\"{x:1503,y:483,t:1528143630906};\\\", \\\"{x:1503,y:482,t:1528143630922};\\\", \\\"{x:1503,y:481,t:1528143630977};\\\", \\\"{x:1505,y:481,t:1528143630989};\\\", \\\"{x:1512,y:488,t:1528143631007};\\\", \\\"{x:1527,y:509,t:1528143631022};\\\", \\\"{x:1540,y:525,t:1528143631039};\\\", \\\"{x:1553,y:548,t:1528143631056};\\\", \\\"{x:1560,y:557,t:1528143631072};\\\", \\\"{x:1561,y:563,t:1528143631088};\\\", \\\"{x:1563,y:566,t:1528143631106};\\\", \\\"{x:1563,y:568,t:1528143631122};\\\", \\\"{x:1563,y:571,t:1528143631139};\\\", \\\"{x:1561,y:573,t:1528143631156};\\\", \\\"{x:1560,y:574,t:1528143631201};\\\", \\\"{x:1559,y:575,t:1528143631216};\\\", \\\"{x:1558,y:575,t:1528143631232};\\\", \\\"{x:1555,y:577,t:1528143631240};\\\", \\\"{x:1553,y:578,t:1528143631257};\\\", \\\"{x:1548,y:581,t:1528143631273};\\\", \\\"{x:1544,y:582,t:1528143631289};\\\", \\\"{x:1543,y:582,t:1528143631306};\\\", \\\"{x:1542,y:582,t:1528143631385};\\\", \\\"{x:1541,y:582,t:1528143631393};\\\", \\\"{x:1539,y:582,t:1528143631406};\\\", \\\"{x:1537,y:582,t:1528143631505};\\\", \\\"{x:1530,y:582,t:1528143631524};\\\", \\\"{x:1528,y:582,t:1528143631539};\\\", \\\"{x:1527,y:582,t:1528143631556};\\\", \\\"{x:1524,y:582,t:1528143632601};\\\", \\\"{x:1520,y:582,t:1528143632609};\\\", \\\"{x:1516,y:581,t:1528143632624};\\\", \\\"{x:1509,y:576,t:1528143632640};\\\", \\\"{x:1500,y:570,t:1528143632658};\\\", \\\"{x:1492,y:563,t:1528143632674};\\\", \\\"{x:1484,y:556,t:1528143632691};\\\", \\\"{x:1475,y:545,t:1528143632708};\\\", \\\"{x:1462,y:526,t:1528143632725};\\\", \\\"{x:1452,y:508,t:1528143632740};\\\", \\\"{x:1444,y:487,t:1528143632758};\\\", \\\"{x:1434,y:466,t:1528143632774};\\\", \\\"{x:1428,y:448,t:1528143632791};\\\", \\\"{x:1424,y:434,t:1528143632807};\\\", \\\"{x:1415,y:414,t:1528143632824};\\\", \\\"{x:1412,y:402,t:1528143632840};\\\", \\\"{x:1410,y:395,t:1528143632857};\\\", \\\"{x:1409,y:391,t:1528143632874};\\\", \\\"{x:1409,y:389,t:1528143632890};\\\", \\\"{x:1409,y:388,t:1528143633217};\\\", \\\"{x:1409,y:393,t:1528143633609};\\\", \\\"{x:1409,y:410,t:1528143633625};\\\", \\\"{x:1409,y:424,t:1528143633642};\\\", \\\"{x:1406,y:431,t:1528143633658};\\\", \\\"{x:1404,y:440,t:1528143633674};\\\", \\\"{x:1400,y:448,t:1528143633691};\\\", \\\"{x:1396,y:455,t:1528143633709};\\\", \\\"{x:1393,y:461,t:1528143633724};\\\", \\\"{x:1391,y:471,t:1528143633742};\\\", \\\"{x:1388,y:481,t:1528143633759};\\\", \\\"{x:1387,y:499,t:1528143633774};\\\", \\\"{x:1384,y:512,t:1528143633791};\\\", \\\"{x:1384,y:518,t:1528143633809};\\\", \\\"{x:1384,y:519,t:1528143633913};\\\", \\\"{x:1384,y:521,t:1528143633925};\\\", \\\"{x:1392,y:523,t:1528143633942};\\\", \\\"{x:1401,y:526,t:1528143633958};\\\", \\\"{x:1410,y:527,t:1528143633976};\\\", \\\"{x:1414,y:527,t:1528143633991};\\\", \\\"{x:1415,y:528,t:1528143634008};\\\", \\\"{x:1415,y:526,t:1528143634209};\\\", \\\"{x:1415,y:523,t:1528143634225};\\\", \\\"{x:1415,y:520,t:1528143634243};\\\", \\\"{x:1415,y:517,t:1528143634259};\\\", \\\"{x:1415,y:514,t:1528143634276};\\\", \\\"{x:1415,y:512,t:1528143634292};\\\", \\\"{x:1413,y:507,t:1528143634308};\\\", \\\"{x:1407,y:500,t:1528143634326};\\\", \\\"{x:1402,y:493,t:1528143634343};\\\", \\\"{x:1398,y:488,t:1528143634359};\\\", \\\"{x:1395,y:484,t:1528143634375};\\\", \\\"{x:1392,y:480,t:1528143634392};\\\", \\\"{x:1390,y:478,t:1528143634408};\\\", \\\"{x:1388,y:477,t:1528143634425};\\\", \\\"{x:1385,y:475,t:1528143634442};\\\", \\\"{x:1379,y:474,t:1528143634458};\\\", \\\"{x:1369,y:474,t:1528143634475};\\\", \\\"{x:1356,y:474,t:1528143634493};\\\", \\\"{x:1343,y:474,t:1528143634508};\\\", \\\"{x:1324,y:474,t:1528143634526};\\\", \\\"{x:1306,y:474,t:1528143634543};\\\", \\\"{x:1292,y:474,t:1528143634559};\\\", \\\"{x:1285,y:474,t:1528143634576};\\\", \\\"{x:1281,y:474,t:1528143634593};\\\", \\\"{x:1281,y:473,t:1528143634608};\\\", \\\"{x:1280,y:473,t:1528143634673};\\\", \\\"{x:1279,y:473,t:1528143634688};\\\", \\\"{x:1279,y:471,t:1528143634697};\\\", \\\"{x:1279,y:470,t:1528143634712};\\\", \\\"{x:1279,y:467,t:1528143634729};\\\", \\\"{x:1280,y:465,t:1528143634752};\\\", \\\"{x:1280,y:464,t:1528143634761};\\\", \\\"{x:1282,y:463,t:1528143634775};\\\", \\\"{x:1289,y:459,t:1528143634792};\\\", \\\"{x:1291,y:457,t:1528143634809};\\\", \\\"{x:1293,y:457,t:1528143634825};\\\", \\\"{x:1295,y:456,t:1528143634842};\\\", \\\"{x:1296,y:456,t:1528143634872};\\\", \\\"{x:1298,y:456,t:1528143634905};\\\", \\\"{x:1299,y:456,t:1528143634921};\\\", \\\"{x:1301,y:456,t:1528143634944};\\\", \\\"{x:1302,y:456,t:1528143634984};\\\", \\\"{x:1302,y:457,t:1528143635009};\\\", \\\"{x:1303,y:458,t:1528143635025};\\\", \\\"{x:1303,y:460,t:1528143635043};\\\", \\\"{x:1303,y:461,t:1528143635059};\\\", \\\"{x:1303,y:463,t:1528143635076};\\\", \\\"{x:1303,y:466,t:1528143635169};\\\", \\\"{x:1301,y:471,t:1528143635178};\\\", \\\"{x:1294,y:485,t:1528143635191};\\\", \\\"{x:1283,y:501,t:1528143635209};\\\", \\\"{x:1264,y:522,t:1528143635226};\\\", \\\"{x:1240,y:545,t:1528143635241};\\\", \\\"{x:1218,y:571,t:1528143635259};\\\", \\\"{x:1199,y:593,t:1528143635276};\\\", \\\"{x:1179,y:610,t:1528143635292};\\\", \\\"{x:1157,y:629,t:1528143635309};\\\", \\\"{x:1108,y:665,t:1528143635326};\\\", \\\"{x:1070,y:705,t:1528143635342};\\\", \\\"{x:1042,y:742,t:1528143635359};\\\", \\\"{x:1016,y:777,t:1528143635377};\\\", \\\"{x:1002,y:795,t:1528143635392};\\\", \\\"{x:989,y:810,t:1528143635409};\\\", \\\"{x:979,y:829,t:1528143635426};\\\", \\\"{x:970,y:849,t:1528143635442};\\\", \\\"{x:963,y:870,t:1528143635459};\\\", \\\"{x:957,y:892,t:1528143635476};\\\", \\\"{x:950,y:913,t:1528143635493};\\\", \\\"{x:949,y:930,t:1528143635509};\\\", \\\"{x:946,y:940,t:1528143635526};\\\", \\\"{x:946,y:943,t:1528143635542};\\\", \\\"{x:946,y:944,t:1528143635559};\\\", \\\"{x:947,y:944,t:1528143635649};\\\", \\\"{x:954,y:940,t:1528143635659};\\\", \\\"{x:975,y:924,t:1528143635676};\\\", \\\"{x:1006,y:897,t:1528143635693};\\\", \\\"{x:1042,y:865,t:1528143635709};\\\", \\\"{x:1071,y:836,t:1528143635727};\\\", \\\"{x:1104,y:786,t:1528143635743};\\\", \\\"{x:1143,y:721,t:1528143635759};\\\", \\\"{x:1207,y:611,t:1528143635779};\\\", \\\"{x:1240,y:549,t:1528143635793};\\\", \\\"{x:1268,y:502,t:1528143635810};\\\", \\\"{x:1283,y:470,t:1528143635826};\\\", \\\"{x:1292,y:447,t:1528143635844};\\\", \\\"{x:1300,y:434,t:1528143635859};\\\", \\\"{x:1308,y:422,t:1528143635876};\\\", \\\"{x:1312,y:417,t:1528143635893};\\\", \\\"{x:1313,y:413,t:1528143635909};\\\", \\\"{x:1316,y:409,t:1528143635927};\\\", \\\"{x:1316,y:407,t:1528143635943};\\\", \\\"{x:1317,y:406,t:1528143635960};\\\", \\\"{x:1319,y:406,t:1528143636001};\\\", \\\"{x:1321,y:406,t:1528143636016};\\\", \\\"{x:1323,y:407,t:1528143636033};\\\", \\\"{x:1327,y:411,t:1528143636043};\\\", \\\"{x:1331,y:417,t:1528143636061};\\\", \\\"{x:1336,y:426,t:1528143636076};\\\", \\\"{x:1338,y:432,t:1528143636093};\\\", \\\"{x:1340,y:436,t:1528143636111};\\\", \\\"{x:1340,y:439,t:1528143636127};\\\", \\\"{x:1340,y:440,t:1528143636143};\\\", \\\"{x:1340,y:442,t:1528143636160};\\\", \\\"{x:1340,y:443,t:1528143636178};\\\", \\\"{x:1339,y:445,t:1528143636201};\\\", \\\"{x:1336,y:446,t:1528143636216};\\\", \\\"{x:1335,y:446,t:1528143636226};\\\", \\\"{x:1328,y:446,t:1528143636243};\\\", \\\"{x:1321,y:446,t:1528143636260};\\\", \\\"{x:1317,y:446,t:1528143636277};\\\", \\\"{x:1315,y:446,t:1528143636293};\\\", \\\"{x:1313,y:446,t:1528143636310};\\\", \\\"{x:1312,y:446,t:1528143636392};\\\", \\\"{x:1311,y:446,t:1528143636407};\\\", \\\"{x:1311,y:448,t:1528143636448};\\\", \\\"{x:1311,y:449,t:1528143636460};\\\", \\\"{x:1319,y:460,t:1528143636477};\\\", \\\"{x:1331,y:480,t:1528143636493};\\\", \\\"{x:1347,y:511,t:1528143636510};\\\", \\\"{x:1368,y:546,t:1528143636527};\\\", \\\"{x:1388,y:581,t:1528143636543};\\\", \\\"{x:1424,y:637,t:1528143636560};\\\", \\\"{x:1452,y:676,t:1528143636577};\\\", \\\"{x:1474,y:704,t:1528143636593};\\\", \\\"{x:1496,y:730,t:1528143636610};\\\", \\\"{x:1507,y:749,t:1528143636627};\\\", \\\"{x:1520,y:770,t:1528143636643};\\\", \\\"{x:1532,y:795,t:1528143636660};\\\", \\\"{x:1544,y:824,t:1528143636677};\\\", \\\"{x:1558,y:861,t:1528143636694};\\\", \\\"{x:1578,y:909,t:1528143636710};\\\", \\\"{x:1586,y:936,t:1528143636727};\\\", \\\"{x:1593,y:955,t:1528143636743};\\\", \\\"{x:1594,y:963,t:1528143636760};\\\", \\\"{x:1593,y:963,t:1528143636921};\\\", \\\"{x:1590,y:963,t:1528143636929};\\\", \\\"{x:1584,y:961,t:1528143636944};\\\", \\\"{x:1577,y:958,t:1528143636961};\\\", \\\"{x:1570,y:954,t:1528143636976};\\\", \\\"{x:1562,y:950,t:1528143636994};\\\", \\\"{x:1558,y:947,t:1528143637010};\\\", \\\"{x:1557,y:947,t:1528143637027};\\\", \\\"{x:1556,y:947,t:1528143637044};\\\", \\\"{x:1555,y:946,t:1528143637136};\\\", \\\"{x:1554,y:944,t:1528143637144};\\\", \\\"{x:1552,y:941,t:1528143637160};\\\", \\\"{x:1551,y:937,t:1528143637177};\\\", \\\"{x:1548,y:932,t:1528143637194};\\\", \\\"{x:1546,y:926,t:1528143637210};\\\", \\\"{x:1544,y:923,t:1528143637227};\\\", \\\"{x:1542,y:918,t:1528143637244};\\\", \\\"{x:1541,y:918,t:1528143637260};\\\", \\\"{x:1541,y:916,t:1528143637277};\\\", \\\"{x:1541,y:915,t:1528143637295};\\\", \\\"{x:1541,y:913,t:1528143637337};\\\", \\\"{x:1541,y:910,t:1528143637858};\\\", \\\"{x:1540,y:910,t:1528143637865};\\\", \\\"{x:1540,y:909,t:1528143637879};\\\", \\\"{x:1540,y:907,t:1528143637894};\\\", \\\"{x:1539,y:905,t:1528143637911};\\\", \\\"{x:1536,y:899,t:1528143637928};\\\", \\\"{x:1532,y:892,t:1528143637945};\\\", \\\"{x:1521,y:874,t:1528143637961};\\\", \\\"{x:1510,y:849,t:1528143637979};\\\", \\\"{x:1488,y:800,t:1528143637995};\\\", \\\"{x:1459,y:726,t:1528143638012};\\\", \\\"{x:1425,y:651,t:1528143638028};\\\", \\\"{x:1405,y:607,t:1528143638044};\\\", \\\"{x:1397,y:580,t:1528143638062};\\\", \\\"{x:1392,y:555,t:1528143638079};\\\", \\\"{x:1387,y:540,t:1528143638095};\\\", \\\"{x:1386,y:530,t:1528143638111};\\\", \\\"{x:1383,y:516,t:1528143638128};\\\", \\\"{x:1380,y:506,t:1528143638145};\\\", \\\"{x:1376,y:498,t:1528143638161};\\\", \\\"{x:1374,y:493,t:1528143638179};\\\", \\\"{x:1373,y:491,t:1528143638194};\\\", \\\"{x:1370,y:487,t:1528143638211};\\\", \\\"{x:1367,y:484,t:1528143638228};\\\", \\\"{x:1365,y:482,t:1528143638245};\\\", \\\"{x:1359,y:477,t:1528143638261};\\\", \\\"{x:1349,y:472,t:1528143638278};\\\", \\\"{x:1334,y:466,t:1528143638295};\\\", \\\"{x:1323,y:460,t:1528143638312};\\\", \\\"{x:1319,y:458,t:1528143638329};\\\", \\\"{x:1316,y:457,t:1528143638346};\\\", \\\"{x:1316,y:456,t:1528143638362};\\\", \\\"{x:1314,y:454,t:1528143638379};\\\", \\\"{x:1312,y:452,t:1528143638395};\\\", \\\"{x:1311,y:451,t:1528143638412};\\\", \\\"{x:1308,y:450,t:1528143638429};\\\", \\\"{x:1307,y:449,t:1528143638489};\\\", \\\"{x:1307,y:448,t:1528143638505};\\\", \\\"{x:1307,y:447,t:1528143638512};\\\", \\\"{x:1307,y:445,t:1528143638528};\\\", \\\"{x:1308,y:443,t:1528143638545};\\\", \\\"{x:1308,y:440,t:1528143638562};\\\", \\\"{x:1310,y:436,t:1528143638579};\\\", \\\"{x:1311,y:435,t:1528143638595};\\\", \\\"{x:1312,y:433,t:1528143638611};\\\", \\\"{x:1309,y:432,t:1528143638874};\\\", \\\"{x:1301,y:432,t:1528143638881};\\\", \\\"{x:1295,y:432,t:1528143638895};\\\", \\\"{x:1262,y:432,t:1528143638911};\\\", \\\"{x:1235,y:432,t:1528143638928};\\\", \\\"{x:1212,y:432,t:1528143638945};\\\", \\\"{x:1192,y:432,t:1528143638962};\\\", \\\"{x:1177,y:432,t:1528143638979};\\\", \\\"{x:1164,y:432,t:1528143638995};\\\", \\\"{x:1151,y:432,t:1528143639012};\\\", \\\"{x:1117,y:432,t:1528143639028};\\\", \\\"{x:1089,y:432,t:1528143639045};\\\", \\\"{x:1068,y:432,t:1528143639062};\\\", \\\"{x:1060,y:432,t:1528143639078};\\\", \\\"{x:1059,y:432,t:1528143639095};\\\", \\\"{x:1058,y:432,t:1528143639112};\\\", \\\"{x:1057,y:432,t:1528143639144};\\\", \\\"{x:1056,y:433,t:1528143639160};\\\", \\\"{x:1055,y:433,t:1528143639177};\\\", \\\"{x:1055,y:434,t:1528143639185};\\\", \\\"{x:1054,y:434,t:1528143639195};\\\", \\\"{x:1054,y:435,t:1528143639249};\\\", \\\"{x:1054,y:437,t:1528143639263};\\\", \\\"{x:1059,y:440,t:1528143639280};\\\", \\\"{x:1068,y:442,t:1528143639296};\\\", \\\"{x:1081,y:444,t:1528143639313};\\\", \\\"{x:1099,y:446,t:1528143639330};\\\", \\\"{x:1121,y:449,t:1528143639346};\\\", \\\"{x:1150,y:450,t:1528143639363};\\\", \\\"{x:1187,y:450,t:1528143639380};\\\", \\\"{x:1223,y:450,t:1528143639395};\\\", \\\"{x:1255,y:450,t:1528143639412};\\\", \\\"{x:1281,y:450,t:1528143639429};\\\", \\\"{x:1292,y:450,t:1528143639445};\\\", \\\"{x:1295,y:450,t:1528143639462};\\\", \\\"{x:1296,y:450,t:1528143639536};\\\", \\\"{x:1297,y:450,t:1528143639568};\\\", \\\"{x:1299,y:450,t:1528143639579};\\\", \\\"{x:1300,y:450,t:1528143639600};\\\", \\\"{x:1301,y:449,t:1528143639612};\\\", \\\"{x:1303,y:449,t:1528143639640};\\\", \\\"{x:1304,y:448,t:1528143639648};\\\", \\\"{x:1305,y:448,t:1528143639662};\\\", \\\"{x:1312,y:446,t:1528143639680};\\\", \\\"{x:1320,y:445,t:1528143639695};\\\", \\\"{x:1326,y:443,t:1528143639712};\\\", \\\"{x:1327,y:443,t:1528143639729};\\\", \\\"{x:1328,y:443,t:1528143639784};\\\", \\\"{x:1328,y:442,t:1528143639796};\\\", \\\"{x:1329,y:442,t:1528143639824};\\\", \\\"{x:1330,y:442,t:1528143639832};\\\", \\\"{x:1331,y:442,t:1528143639846};\\\", \\\"{x:1332,y:442,t:1528143639862};\\\", \\\"{x:1333,y:442,t:1528143639879};\\\", \\\"{x:1331,y:442,t:1528143640152};\\\", \\\"{x:1328,y:442,t:1528143640163};\\\", \\\"{x:1323,y:442,t:1528143640180};\\\", \\\"{x:1317,y:442,t:1528143640197};\\\", \\\"{x:1314,y:442,t:1528143640213};\\\", \\\"{x:1313,y:442,t:1528143640230};\\\", \\\"{x:1313,y:448,t:1528143642385};\\\", \\\"{x:1310,y:455,t:1528143642400};\\\", \\\"{x:1297,y:475,t:1528143642415};\\\", \\\"{x:1285,y:503,t:1528143642432};\\\", \\\"{x:1261,y:539,t:1528143642449};\\\", \\\"{x:1248,y:557,t:1528143642465};\\\", \\\"{x:1236,y:575,t:1528143642482};\\\", \\\"{x:1225,y:592,t:1528143642499};\\\", \\\"{x:1209,y:617,t:1528143642515};\\\", \\\"{x:1189,y:657,t:1528143642532};\\\", \\\"{x:1171,y:699,t:1528143642549};\\\", \\\"{x:1155,y:739,t:1528143642565};\\\", \\\"{x:1139,y:773,t:1528143642582};\\\", \\\"{x:1130,y:797,t:1528143642599};\\\", \\\"{x:1121,y:816,t:1528143642615};\\\", \\\"{x:1116,y:829,t:1528143642632};\\\", \\\"{x:1105,y:858,t:1528143642648};\\\", \\\"{x:1093,y:879,t:1528143642666};\\\", \\\"{x:1080,y:901,t:1528143642681};\\\", \\\"{x:1060,y:922,t:1528143642699};\\\", \\\"{x:1041,y:938,t:1528143642715};\\\", \\\"{x:1023,y:950,t:1528143642732};\\\", \\\"{x:1019,y:955,t:1528143642748};\\\", \\\"{x:1017,y:957,t:1528143642765};\\\", \\\"{x:1020,y:957,t:1528143642865};\\\", \\\"{x:1029,y:953,t:1528143642882};\\\", \\\"{x:1040,y:946,t:1528143642899};\\\", \\\"{x:1052,y:939,t:1528143642916};\\\", \\\"{x:1063,y:933,t:1528143642932};\\\", \\\"{x:1072,y:926,t:1528143642949};\\\", \\\"{x:1075,y:923,t:1528143642966};\\\", \\\"{x:1077,y:921,t:1528143642982};\\\", \\\"{x:1078,y:920,t:1528143642999};\\\", \\\"{x:1079,y:918,t:1528143643015};\\\", \\\"{x:1080,y:916,t:1528143643032};\\\", \\\"{x:1082,y:915,t:1528143643314};\\\", \\\"{x:1083,y:911,t:1528143643321};\\\", \\\"{x:1085,y:906,t:1528143643333};\\\", \\\"{x:1094,y:890,t:1528143643349};\\\", \\\"{x:1107,y:870,t:1528143643365};\\\", \\\"{x:1124,y:848,t:1528143643383};\\\", \\\"{x:1139,y:827,t:1528143643399};\\\", \\\"{x:1153,y:806,t:1528143643415};\\\", \\\"{x:1174,y:770,t:1528143643432};\\\", \\\"{x:1213,y:697,t:1528143643449};\\\", \\\"{x:1234,y:647,t:1528143643465};\\\", \\\"{x:1254,y:610,t:1528143643483};\\\", \\\"{x:1269,y:585,t:1528143643498};\\\", \\\"{x:1277,y:570,t:1528143643515};\\\", \\\"{x:1281,y:561,t:1528143643532};\\\", \\\"{x:1284,y:553,t:1528143643550};\\\", \\\"{x:1286,y:544,t:1528143643566};\\\", \\\"{x:1288,y:536,t:1528143643583};\\\", \\\"{x:1289,y:532,t:1528143643599};\\\", \\\"{x:1290,y:528,t:1528143643616};\\\", \\\"{x:1293,y:522,t:1528143643632};\\\", \\\"{x:1299,y:514,t:1528143643650};\\\", \\\"{x:1303,y:509,t:1528143643666};\\\", \\\"{x:1307,y:504,t:1528143643683};\\\", \\\"{x:1311,y:497,t:1528143643700};\\\", \\\"{x:1315,y:491,t:1528143643716};\\\", \\\"{x:1320,y:483,t:1528143643733};\\\", \\\"{x:1324,y:477,t:1528143643750};\\\", \\\"{x:1331,y:467,t:1528143643765};\\\", \\\"{x:1333,y:462,t:1528143643782};\\\", \\\"{x:1336,y:457,t:1528143643799};\\\", \\\"{x:1336,y:455,t:1528143643816};\\\", \\\"{x:1336,y:451,t:1528143643832};\\\", \\\"{x:1336,y:450,t:1528143643849};\\\", \\\"{x:1336,y:449,t:1528143643921};\\\", \\\"{x:1335,y:448,t:1528143643936};\\\", \\\"{x:1334,y:448,t:1528143643960};\\\", \\\"{x:1333,y:448,t:1528143643978};\\\", \\\"{x:1332,y:448,t:1528143644017};\\\", \\\"{x:1331,y:447,t:1528143644033};\\\", \\\"{x:1330,y:447,t:1528143644050};\\\", \\\"{x:1329,y:447,t:1528143644072};\\\", \\\"{x:1328,y:447,t:1528143644083};\\\", \\\"{x:1327,y:447,t:1528143644100};\\\", \\\"{x:1326,y:447,t:1528143644116};\\\", \\\"{x:1325,y:447,t:1528143644133};\\\", \\\"{x:1324,y:447,t:1528143644150};\\\", \\\"{x:1323,y:447,t:1528143644167};\\\", \\\"{x:1320,y:447,t:1528143644183};\\\", \\\"{x:1317,y:448,t:1528143644200};\\\", \\\"{x:1316,y:454,t:1528143644217};\\\", \\\"{x:1316,y:458,t:1528143644233};\\\", \\\"{x:1316,y:465,t:1528143644250};\\\", \\\"{x:1317,y:474,t:1528143644267};\\\", \\\"{x:1323,y:487,t:1528143644284};\\\", \\\"{x:1331,y:506,t:1528143644300};\\\", \\\"{x:1345,y:530,t:1528143644317};\\\", \\\"{x:1361,y:566,t:1528143644333};\\\", \\\"{x:1382,y:603,t:1528143644350};\\\", \\\"{x:1403,y:645,t:1528143644367};\\\", \\\"{x:1430,y:692,t:1528143644384};\\\", \\\"{x:1460,y:734,t:1528143644400};\\\", \\\"{x:1495,y:785,t:1528143644417};\\\", \\\"{x:1506,y:804,t:1528143644434};\\\", \\\"{x:1513,y:815,t:1528143644450};\\\", \\\"{x:1518,y:825,t:1528143644467};\\\", \\\"{x:1522,y:835,t:1528143644484};\\\", \\\"{x:1527,y:848,t:1528143644500};\\\", \\\"{x:1532,y:860,t:1528143644517};\\\", \\\"{x:1536,y:868,t:1528143644534};\\\", \\\"{x:1537,y:872,t:1528143644551};\\\", \\\"{x:1537,y:874,t:1528143644567};\\\", \\\"{x:1537,y:877,t:1528143644585};\\\", \\\"{x:1537,y:879,t:1528143644600};\\\", \\\"{x:1537,y:882,t:1528143644616};\\\", \\\"{x:1536,y:885,t:1528143644634};\\\", \\\"{x:1535,y:888,t:1528143644650};\\\", \\\"{x:1534,y:892,t:1528143644667};\\\", \\\"{x:1533,y:894,t:1528143644684};\\\", \\\"{x:1533,y:895,t:1528143644700};\\\", \\\"{x:1532,y:896,t:1528143644717};\\\", \\\"{x:1532,y:897,t:1528143644734};\\\", \\\"{x:1532,y:898,t:1528143644750};\\\", \\\"{x:1532,y:900,t:1528143644767};\\\", \\\"{x:1532,y:901,t:1528143644784};\\\", \\\"{x:1532,y:903,t:1528143644801};\\\", \\\"{x:1532,y:904,t:1528143644833};\\\", \\\"{x:1532,y:905,t:1528143644864};\\\", \\\"{x:1532,y:906,t:1528143644873};\\\", \\\"{x:1533,y:906,t:1528143644884};\\\", \\\"{x:1533,y:907,t:1528143644901};\\\", \\\"{x:1533,y:908,t:1528143644921};\\\", \\\"{x:1534,y:908,t:1528143644937};\\\", \\\"{x:1534,y:909,t:1528143644953};\\\", \\\"{x:1535,y:910,t:1528143644979};\\\", \\\"{x:1535,y:911,t:1528143644984};\\\", \\\"{x:1537,y:912,t:1528143644999};\\\", \\\"{x:1541,y:918,t:1528143645016};\\\", \\\"{x:1546,y:926,t:1528143645033};\\\", \\\"{x:1551,y:930,t:1528143645051};\\\", \\\"{x:1552,y:932,t:1528143645067};\\\", \\\"{x:1553,y:932,t:1528143645521};\\\", \\\"{x:1553,y:930,t:1528143645534};\\\", \\\"{x:1553,y:929,t:1528143645551};\\\", \\\"{x:1554,y:927,t:1528143645568};\\\", \\\"{x:1554,y:926,t:1528143645601};\\\", \\\"{x:1554,y:925,t:1528143645672};\\\", \\\"{x:1554,y:923,t:1528143645684};\\\", \\\"{x:1554,y:922,t:1528143645713};\\\", \\\"{x:1554,y:919,t:1528143645905};\\\", \\\"{x:1554,y:917,t:1528143646153};\\\", \\\"{x:1553,y:917,t:1528143646168};\\\", \\\"{x:1553,y:915,t:1528143646185};\\\", \\\"{x:1552,y:913,t:1528143646202};\\\", \\\"{x:1552,y:912,t:1528143649704};\\\", \\\"{x:1552,y:908,t:1528143649721};\\\", \\\"{x:1551,y:907,t:1528143649738};\\\", \\\"{x:1551,y:906,t:1528143655953};\\\", \\\"{x:1551,y:905,t:1528143655960};\\\", \\\"{x:1552,y:904,t:1528143655993};\\\", \\\"{x:1551,y:901,t:1528143656009};\\\", \\\"{x:1549,y:899,t:1528143656027};\\\", \\\"{x:1543,y:898,t:1528143656042};\\\", \\\"{x:1540,y:896,t:1528143656059};\\\", \\\"{x:1536,y:893,t:1528143656077};\\\", \\\"{x:1535,y:893,t:1528143656092};\\\", \\\"{x:1534,y:889,t:1528143659091};\\\", \\\"{x:1530,y:886,t:1528143659099};\\\", \\\"{x:1527,y:883,t:1528143659114};\\\", \\\"{x:1508,y:869,t:1528143659131};\\\", \\\"{x:1494,y:859,t:1528143659148};\\\", \\\"{x:1481,y:845,t:1528143659165};\\\", \\\"{x:1460,y:818,t:1528143659181};\\\", \\\"{x:1424,y:755,t:1528143659199};\\\", \\\"{x:1403,y:704,t:1528143659214};\\\", \\\"{x:1398,y:646,t:1528143659231};\\\", \\\"{x:1387,y:594,t:1528143659249};\\\", \\\"{x:1356,y:561,t:1528143659264};\\\", \\\"{x:1342,y:548,t:1528143659281};\\\", \\\"{x:1340,y:547,t:1528143659299};\\\", \\\"{x:1339,y:547,t:1528143659314};\\\", \\\"{x:1337,y:547,t:1528143659395};\\\", \\\"{x:1336,y:547,t:1528143659402};\\\", \\\"{x:1333,y:550,t:1528143659414};\\\", \\\"{x:1328,y:562,t:1528143659430};\\\", \\\"{x:1323,y:572,t:1528143659448};\\\", \\\"{x:1318,y:583,t:1528143659465};\\\", \\\"{x:1316,y:590,t:1528143659480};\\\", \\\"{x:1314,y:592,t:1528143659498};\\\", \\\"{x:1313,y:594,t:1528143659514};\\\", \\\"{x:1313,y:595,t:1528143659538};\\\", \\\"{x:1312,y:593,t:1528143660868};\\\", \\\"{x:1311,y:593,t:1528143660883};\\\", \\\"{x:1309,y:591,t:1528143660900};\\\", \\\"{x:1307,y:591,t:1528143660917};\\\", \\\"{x:1305,y:590,t:1528143661004};\\\", \\\"{x:1303,y:589,t:1528143661017};\\\", \\\"{x:1292,y:589,t:1528143661032};\\\", \\\"{x:1277,y:589,t:1528143661049};\\\", \\\"{x:1258,y:589,t:1528143661067};\\\", \\\"{x:1248,y:595,t:1528143661083};\\\", \\\"{x:1249,y:596,t:1528143661100};\\\", \\\"{x:1250,y:596,t:1528143661627};\\\", \\\"{x:1250,y:595,t:1528143661635};\\\", \\\"{x:1250,y:594,t:1528143661649};\\\", \\\"{x:1251,y:594,t:1528143661666};\\\", \\\"{x:1251,y:593,t:1528143661843};\\\", \\\"{x:1244,y:592,t:1528143661851};\\\", \\\"{x:1230,y:591,t:1528143661867};\\\", \\\"{x:1149,y:591,t:1528143661883};\\\", \\\"{x:1065,y:591,t:1528143661901};\\\", \\\"{x:976,y:591,t:1528143661917};\\\", \\\"{x:830,y:591,t:1528143661934};\\\", \\\"{x:672,y:591,t:1528143661952};\\\", \\\"{x:531,y:591,t:1528143661966};\\\", \\\"{x:409,y:591,t:1528143661983};\\\", \\\"{x:321,y:591,t:1528143662000};\\\", \\\"{x:293,y:591,t:1528143662017};\\\", \\\"{x:290,y:591,t:1528143662032};\\\", \\\"{x:293,y:591,t:1528143662114};\\\", \\\"{x:299,y:593,t:1528143662122};\\\", \\\"{x:307,y:593,t:1528143662134};\\\", \\\"{x:342,y:600,t:1528143662149};\\\", \\\"{x:422,y:609,t:1528143662167};\\\", \\\"{x:507,y:616,t:1528143662185};\\\", \\\"{x:588,y:616,t:1528143662200};\\\", \\\"{x:671,y:616,t:1528143662217};\\\", \\\"{x:755,y:616,t:1528143662234};\\\", \\\"{x:778,y:616,t:1528143662250};\\\", \\\"{x:817,y:609,t:1528143662267};\\\", \\\"{x:828,y:606,t:1528143662284};\\\", \\\"{x:829,y:605,t:1528143662300};\\\", \\\"{x:828,y:601,t:1528143662339};\\\", \\\"{x:828,y:598,t:1528143662355};\\\", \\\"{x:828,y:596,t:1528143662367};\\\", \\\"{x:828,y:590,t:1528143662384};\\\", \\\"{x:828,y:581,t:1528143662400};\\\", \\\"{x:829,y:568,t:1528143662417};\\\", \\\"{x:835,y:554,t:1528143662434};\\\", \\\"{x:841,y:542,t:1528143662450};\\\", \\\"{x:844,y:529,t:1528143662467};\\\", \\\"{x:846,y:516,t:1528143662484};\\\", \\\"{x:847,y:499,t:1528143662501};\\\", \\\"{x:847,y:484,t:1528143662517};\\\", \\\"{x:847,y:475,t:1528143662534};\\\", \\\"{x:847,y:469,t:1528143662550};\\\", \\\"{x:847,y:466,t:1528143662567};\\\", \\\"{x:847,y:464,t:1528143662584};\\\", \\\"{x:847,y:463,t:1528143662600};\\\", \\\"{x:846,y:464,t:1528143662723};\\\", \\\"{x:845,y:466,t:1528143662733};\\\", \\\"{x:843,y:470,t:1528143662751};\\\", \\\"{x:840,y:474,t:1528143662767};\\\", \\\"{x:838,y:477,t:1528143662783};\\\", \\\"{x:836,y:479,t:1528143662800};\\\", \\\"{x:835,y:480,t:1528143662817};\\\", \\\"{x:834,y:481,t:1528143662834};\\\", \\\"{x:832,y:483,t:1528143663195};\\\", \\\"{x:821,y:487,t:1528143663203};\\\", \\\"{x:785,y:499,t:1528143663219};\\\", \\\"{x:761,y:505,t:1528143663234};\\\", \\\"{x:674,y:530,t:1528143663252};\\\", \\\"{x:626,y:547,t:1528143663269};\\\", \\\"{x:582,y:564,t:1528143663284};\\\", \\\"{x:559,y:576,t:1528143663302};\\\", \\\"{x:538,y:592,t:1528143663318};\\\", \\\"{x:523,y:603,t:1528143663333};\\\", \\\"{x:507,y:615,t:1528143663352};\\\", \\\"{x:488,y:630,t:1528143663368};\\\", \\\"{x:467,y:650,t:1528143663384};\\\", \\\"{x:450,y:675,t:1528143663402};\\\", \\\"{x:415,y:726,t:1528143663419};\\\", \\\"{x:402,y:749,t:1528143663434};\\\", \\\"{x:392,y:768,t:1528143663451};\\\", \\\"{x:388,y:780,t:1528143663468};\\\", \\\"{x:387,y:782,t:1528143663485};\\\", \\\"{x:387,y:783,t:1528143663571};\\\", \\\"{x:387,y:784,t:1528143664227};\\\", \\\"{x:387,y:782,t:1528143664251};\\\", \\\"{x:386,y:778,t:1528143664269};\\\", \\\"{x:385,y:776,t:1528143664286};\\\", \\\"{x:384,y:773,t:1528143664301};\\\", \\\"{x:383,y:770,t:1528143664318};\\\", \\\"{x:383,y:768,t:1528143664339};\\\", \\\"{x:386,y:766,t:1528143664732};\\\", \\\"{x:394,y:765,t:1528143664738};\\\", \\\"{x:403,y:763,t:1528143664751};\\\", \\\"{x:421,y:761,t:1528143664768};\\\", \\\"{x:438,y:756,t:1528143664785};\\\", \\\"{x:447,y:754,t:1528143664802};\\\", \\\"{x:449,y:752,t:1528143664819};\\\", \\\"{x:449,y:750,t:1528143664859};\\\", \\\"{x:449,y:749,t:1528143664869};\\\", \\\"{x:449,y:747,t:1528143664890};\\\", \\\"{x:449,y:746,t:1528143664901};\\\", \\\"{x:449,y:743,t:1528143664918};\\\", \\\"{x:449,y:739,t:1528143664935};\\\", \\\"{x:449,y:736,t:1528143664952};\\\", \\\"{x:450,y:731,t:1528143664968};\\\", \\\"{x:451,y:726,t:1528143664986};\\\", \\\"{x:451,y:722,t:1528143665003};\\\", \\\"{x:454,y:719,t:1528143665019};\\\", \\\"{x:459,y:714,t:1528143665035};\\\", \\\"{x:467,y:708,t:1528143665051};\\\", \\\"{x:477,y:702,t:1528143665068};\\\", \\\"{x:492,y:692,t:1528143665086};\\\", \\\"{x:503,y:683,t:1528143665102};\\\", \\\"{x:513,y:675,t:1528143665118};\\\", \\\"{x:517,y:671,t:1528143665136};\\\", \\\"{x:518,y:668,t:1528143665153};\\\", \\\"{x:519,y:665,t:1528143665170};\\\", \\\"{x:519,y:664,t:1528143665186};\\\", \\\"{x:520,y:663,t:1528143665394};\\\", \\\"{x:522,y:663,t:1528143665403};\\\", \\\"{x:523,y:663,t:1528143665434};\\\", \\\"{x:524,y:663,t:1528143665442};\\\", \\\"{x:526,y:663,t:1528143665453};\\\", \\\"{x:534,y:670,t:1528143665469};\\\", \\\"{x:551,y:679,t:1528143665486};\\\", \\\"{x:576,y:688,t:1528143665503};\\\", \\\"{x:605,y:699,t:1528143665520};\\\", \\\"{x:636,y:708,t:1528143665536};\\\", \\\"{x:659,y:715,t:1528143665553};\\\", \\\"{x:688,y:726,t:1528143665570};\\\", \\\"{x:705,y:741,t:1528143665586};\\\", \\\"{x:713,y:752,t:1528143665603};\\\", \\\"{x:713,y:755,t:1528143665620};\\\", \\\"{x:713,y:758,t:1528143665636};\\\", \\\"{x:711,y:761,t:1528143665653};\\\", \\\"{x:703,y:765,t:1528143665670};\\\", \\\"{x:691,y:770,t:1528143665686};\\\", \\\"{x:679,y:774,t:1528143665703};\\\", \\\"{x:667,y:777,t:1528143665720};\\\", \\\"{x:654,y:780,t:1528143665736};\\\", \\\"{x:645,y:783,t:1528143665753};\\\", \\\"{x:633,y:784,t:1528143665770};\\\", \\\"{x:630,y:784,t:1528143665786};\\\", \\\"{x:628,y:784,t:1528143665804};\\\", \\\"{x:626,y:784,t:1528143665820};\\\" ] }, { \\\"rt\\\": 8837, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 197115, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"8182H\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:625,y:780,t:1528143668300};\\\", \\\"{x:627,y:769,t:1528143668307};\\\", \\\"{x:631,y:760,t:1528143668322};\\\", \\\"{x:643,y:737,t:1528143668339};\\\", \\\"{x:655,y:721,t:1528143668355};\\\", \\\"{x:670,y:705,t:1528143668372};\\\", \\\"{x:694,y:676,t:1528143668389};\\\", \\\"{x:730,y:653,t:1528143668406};\\\", \\\"{x:790,y:632,t:1528143668422};\\\", \\\"{x:899,y:625,t:1528143668438};\\\", \\\"{x:1051,y:625,t:1528143668456};\\\", \\\"{x:1239,y:674,t:1528143668472};\\\", \\\"{x:1431,y:745,t:1528143668489};\\\", \\\"{x:1583,y:795,t:1528143668506};\\\", \\\"{x:1591,y:797,t:1528143668523};\\\", \\\"{x:1588,y:797,t:1528143669148};\\\", \\\"{x:1587,y:797,t:1528143669156};\\\", \\\"{x:1585,y:797,t:1528143669173};\\\", \\\"{x:1584,y:797,t:1528143669190};\\\", \\\"{x:1581,y:797,t:1528143669259};\\\", \\\"{x:1577,y:797,t:1528143669273};\\\", \\\"{x:1568,y:797,t:1528143669290};\\\", \\\"{x:1560,y:797,t:1528143669307};\\\", \\\"{x:1548,y:796,t:1528143669322};\\\", \\\"{x:1540,y:796,t:1528143669340};\\\", \\\"{x:1536,y:796,t:1528143669356};\\\", \\\"{x:1532,y:796,t:1528143669372};\\\", \\\"{x:1527,y:796,t:1528143669390};\\\", \\\"{x:1522,y:795,t:1528143669406};\\\", \\\"{x:1519,y:795,t:1528143669422};\\\", \\\"{x:1511,y:793,t:1528143669439};\\\", \\\"{x:1505,y:792,t:1528143669457};\\\", \\\"{x:1494,y:789,t:1528143669472};\\\", \\\"{x:1484,y:788,t:1528143669489};\\\", \\\"{x:1470,y:785,t:1528143669506};\\\", \\\"{x:1462,y:782,t:1528143669522};\\\", \\\"{x:1451,y:777,t:1528143669540};\\\", \\\"{x:1445,y:773,t:1528143669557};\\\", \\\"{x:1436,y:766,t:1528143669572};\\\", \\\"{x:1426,y:756,t:1528143669590};\\\", \\\"{x:1361,y:706,t:1528143669607};\\\", \\\"{x:1293,y:649,t:1528143669622};\\\", \\\"{x:1242,y:612,t:1528143669639};\\\", \\\"{x:1202,y:582,t:1528143669656};\\\", \\\"{x:1168,y:558,t:1528143669672};\\\", \\\"{x:1150,y:547,t:1528143669690};\\\", \\\"{x:1139,y:539,t:1528143669707};\\\", \\\"{x:1137,y:537,t:1528143669723};\\\", \\\"{x:1136,y:535,t:1528143669740};\\\", \\\"{x:1136,y:532,t:1528143669757};\\\", \\\"{x:1135,y:522,t:1528143669773};\\\", \\\"{x:1132,y:513,t:1528143669789};\\\", \\\"{x:1131,y:504,t:1528143669807};\\\", \\\"{x:1130,y:498,t:1528143669823};\\\", \\\"{x:1130,y:494,t:1528143669839};\\\", \\\"{x:1129,y:492,t:1528143669856};\\\", \\\"{x:1128,y:490,t:1528143669874};\\\", \\\"{x:1128,y:488,t:1528143669890};\\\", \\\"{x:1128,y:487,t:1528143669907};\\\", \\\"{x:1130,y:487,t:1528143670059};\\\", \\\"{x:1135,y:490,t:1528143670074};\\\", \\\"{x:1148,y:495,t:1528143670090};\\\", \\\"{x:1170,y:500,t:1528143670107};\\\", \\\"{x:1187,y:504,t:1528143670124};\\\", \\\"{x:1200,y:504,t:1528143670140};\\\", \\\"{x:1213,y:504,t:1528143670157};\\\", \\\"{x:1228,y:505,t:1528143670173};\\\", \\\"{x:1246,y:509,t:1528143670190};\\\", \\\"{x:1271,y:511,t:1528143670206};\\\", \\\"{x:1290,y:513,t:1528143670224};\\\", \\\"{x:1304,y:513,t:1528143670239};\\\", \\\"{x:1311,y:513,t:1528143670257};\\\", \\\"{x:1312,y:513,t:1528143670274};\\\", \\\"{x:1307,y:510,t:1528143670556};\\\", \\\"{x:1293,y:505,t:1528143670574};\\\", \\\"{x:1273,y:503,t:1528143670591};\\\", \\\"{x:1254,y:500,t:1528143670607};\\\", \\\"{x:1243,y:500,t:1528143670624};\\\", \\\"{x:1237,y:500,t:1528143670641};\\\", \\\"{x:1236,y:500,t:1528143670657};\\\", \\\"{x:1233,y:500,t:1528143671083};\\\", \\\"{x:1224,y:500,t:1528143671091};\\\", \\\"{x:1199,y:500,t:1528143671107};\\\", \\\"{x:1169,y:500,t:1528143671124};\\\", \\\"{x:1136,y:505,t:1528143671141};\\\", \\\"{x:1108,y:513,t:1528143671158};\\\", \\\"{x:1084,y:515,t:1528143671173};\\\", \\\"{x:1063,y:518,t:1528143671191};\\\", \\\"{x:1045,y:523,t:1528143671208};\\\", \\\"{x:1027,y:529,t:1528143671224};\\\", \\\"{x:1008,y:534,t:1528143671242};\\\", \\\"{x:992,y:541,t:1528143671258};\\\", \\\"{x:936,y:549,t:1528143671276};\\\", \\\"{x:888,y:561,t:1528143671290};\\\", \\\"{x:862,y:564,t:1528143671307};\\\", \\\"{x:826,y:568,t:1528143671324};\\\", \\\"{x:758,y:572,t:1528143671341};\\\", \\\"{x:716,y:579,t:1528143671358};\\\", \\\"{x:659,y:581,t:1528143671375};\\\", \\\"{x:603,y:582,t:1528143671391};\\\", \\\"{x:553,y:582,t:1528143671408};\\\", \\\"{x:518,y:582,t:1528143671424};\\\", \\\"{x:502,y:582,t:1528143671440};\\\", \\\"{x:491,y:582,t:1528143671457};\\\", \\\"{x:488,y:580,t:1528143671474};\\\", \\\"{x:487,y:578,t:1528143671499};\\\", \\\"{x:484,y:574,t:1528143671507};\\\", \\\"{x:456,y:539,t:1528143671525};\\\", \\\"{x:411,y:482,t:1528143671540};\\\", \\\"{x:377,y:453,t:1528143671558};\\\", \\\"{x:360,y:442,t:1528143671574};\\\", \\\"{x:349,y:435,t:1528143671592};\\\", \\\"{x:347,y:433,t:1528143671608};\\\", \\\"{x:347,y:432,t:1528143671624};\\\", \\\"{x:348,y:432,t:1528143671971};\\\", \\\"{x:349,y:432,t:1528143671979};\\\", \\\"{x:352,y:432,t:1528143671992};\\\", \\\"{x:356,y:434,t:1528143672009};\\\", \\\"{x:357,y:434,t:1528143672138};\\\", \\\"{x:358,y:435,t:1528143672170};\\\", \\\"{x:358,y:436,t:1528143672323};\\\", \\\"{x:362,y:438,t:1528143672355};\\\", \\\"{x:366,y:438,t:1528143672363};\\\", \\\"{x:369,y:440,t:1528143672376};\\\", \\\"{x:375,y:442,t:1528143672391};\\\", \\\"{x:385,y:447,t:1528143672410};\\\", \\\"{x:389,y:449,t:1528143672425};\\\", \\\"{x:390,y:449,t:1528143672467};\\\", \\\"{x:391,y:449,t:1528143672499};\\\", \\\"{x:392,y:449,t:1528143672636};\\\", \\\"{x:394,y:451,t:1528143672651};\\\", \\\"{x:396,y:454,t:1528143672659};\\\", \\\"{x:399,y:459,t:1528143672677};\\\", \\\"{x:400,y:461,t:1528143672692};\\\", \\\"{x:401,y:467,t:1528143672709};\\\", \\\"{x:406,y:475,t:1528143672726};\\\", \\\"{x:408,y:481,t:1528143672742};\\\", \\\"{x:409,y:484,t:1528143672758};\\\", \\\"{x:410,y:485,t:1528143672776};\\\", \\\"{x:409,y:486,t:1528143672866};\\\", \\\"{x:407,y:488,t:1528143672875};\\\", \\\"{x:401,y:489,t:1528143672893};\\\", \\\"{x:394,y:490,t:1528143672908};\\\", \\\"{x:388,y:493,t:1528143672925};\\\", \\\"{x:385,y:495,t:1528143672942};\\\", \\\"{x:384,y:495,t:1528143673123};\\\", \\\"{x:384,y:497,t:1528143673139};\\\", \\\"{x:388,y:497,t:1528143673147};\\\", \\\"{x:395,y:497,t:1528143673160};\\\", \\\"{x:437,y:503,t:1528143673176};\\\", \\\"{x:545,y:513,t:1528143673194};\\\", \\\"{x:650,y:513,t:1528143673209};\\\", \\\"{x:734,y:510,t:1528143673226};\\\", \\\"{x:823,y:495,t:1528143673243};\\\", \\\"{x:860,y:491,t:1528143673260};\\\", \\\"{x:867,y:488,t:1528143673276};\\\", \\\"{x:869,y:487,t:1528143673292};\\\", \\\"{x:861,y:484,t:1528143673310};\\\", \\\"{x:847,y:480,t:1528143673325};\\\", \\\"{x:832,y:479,t:1528143673343};\\\", \\\"{x:822,y:479,t:1528143673360};\\\", \\\"{x:816,y:479,t:1528143673376};\\\", \\\"{x:814,y:479,t:1528143673393};\\\", \\\"{x:809,y:479,t:1528143673410};\\\", \\\"{x:808,y:479,t:1528143673426};\\\", \\\"{x:807,y:479,t:1528143673442};\\\", \\\"{x:806,y:479,t:1528143673547};\\\", \\\"{x:801,y:478,t:1528143673591};\\\", \\\"{x:794,y:475,t:1528143673595};\\\", \\\"{x:787,y:475,t:1528143673610};\\\", \\\"{x:755,y:474,t:1528143673626};\\\", \\\"{x:729,y:469,t:1528143673643};\\\", \\\"{x:703,y:467,t:1528143673660};\\\", \\\"{x:686,y:464,t:1528143673677};\\\", \\\"{x:683,y:463,t:1528143673694};\\\", \\\"{x:682,y:462,t:1528143673709};\\\", \\\"{x:682,y:461,t:1528143673726};\\\", \\\"{x:681,y:460,t:1528143673742};\\\", \\\"{x:680,y:457,t:1528143673759};\\\", \\\"{x:679,y:457,t:1528143673778};\\\", \\\"{x:679,y:456,t:1528143673794};\\\", \\\"{x:677,y:456,t:1528143673809};\\\", \\\"{x:671,y:455,t:1528143673826};\\\", \\\"{x:665,y:455,t:1528143673843};\\\", \\\"{x:659,y:455,t:1528143673860};\\\", \\\"{x:651,y:455,t:1528143673876};\\\", \\\"{x:640,y:455,t:1528143673892};\\\", \\\"{x:630,y:455,t:1528143673909};\\\", \\\"{x:625,y:455,t:1528143673927};\\\", \\\"{x:620,y:455,t:1528143673944};\\\", \\\"{x:616,y:455,t:1528143673960};\\\", \\\"{x:614,y:454,t:1528143673976};\\\", \\\"{x:614,y:453,t:1528143674002};\\\", \\\"{x:613,y:453,t:1528143674010};\\\", \\\"{x:612,y:453,t:1528143674034};\\\", \\\"{x:617,y:453,t:1528143674314};\\\", \\\"{x:628,y:453,t:1528143674327};\\\", \\\"{x:660,y:453,t:1528143674343};\\\", \\\"{x:697,y:453,t:1528143674359};\\\", \\\"{x:738,y:456,t:1528143674377};\\\", \\\"{x:761,y:459,t:1528143674394};\\\", \\\"{x:769,y:461,t:1528143674409};\\\", \\\"{x:770,y:461,t:1528143674474};\\\", \\\"{x:773,y:462,t:1528143674490};\\\", \\\"{x:775,y:462,t:1528143674498};\\\", \\\"{x:776,y:462,t:1528143674510};\\\", \\\"{x:776,y:463,t:1528143674526};\\\", \\\"{x:777,y:463,t:1528143674570};\\\", \\\"{x:777,y:464,t:1528143674579};\\\", \\\"{x:778,y:464,t:1528143674594};\\\", \\\"{x:780,y:469,t:1528143674611};\\\", \\\"{x:782,y:471,t:1528143674628};\\\", \\\"{x:786,y:473,t:1528143674644};\\\", \\\"{x:795,y:476,t:1528143674659};\\\", \\\"{x:804,y:476,t:1528143674676};\\\", \\\"{x:812,y:476,t:1528143674693};\\\", \\\"{x:822,y:476,t:1528143674710};\\\", \\\"{x:832,y:476,t:1528143674728};\\\", \\\"{x:842,y:476,t:1528143674744};\\\", \\\"{x:847,y:477,t:1528143674760};\\\", \\\"{x:850,y:479,t:1528143674777};\\\", \\\"{x:851,y:479,t:1528143674794};\\\", \\\"{x:852,y:480,t:1528143674930};\\\", \\\"{x:852,y:480,t:1528143675024};\\\", \\\"{x:849,y:482,t:1528143675187};\\\", \\\"{x:843,y:483,t:1528143675194};\\\", \\\"{x:827,y:487,t:1528143675210};\\\", \\\"{x:805,y:494,t:1528143675228};\\\", \\\"{x:773,y:501,t:1528143675244};\\\", \\\"{x:731,y:513,t:1528143675261};\\\", \\\"{x:670,y:531,t:1528143675278};\\\", \\\"{x:596,y:561,t:1528143675295};\\\", \\\"{x:524,y:594,t:1528143675311};\\\", \\\"{x:484,y:613,t:1528143675328};\\\", \\\"{x:460,y:625,t:1528143675345};\\\", \\\"{x:457,y:630,t:1528143675360};\\\", \\\"{x:457,y:631,t:1528143675377};\\\", \\\"{x:457,y:632,t:1528143675393};\\\", \\\"{x:457,y:633,t:1528143675410};\\\", \\\"{x:458,y:633,t:1528143675427};\\\", \\\"{x:459,y:633,t:1528143675445};\\\", \\\"{x:460,y:633,t:1528143675461};\\\", \\\"{x:464,y:635,t:1528143675478};\\\", \\\"{x:478,y:641,t:1528143675495};\\\", \\\"{x:494,y:648,t:1528143675511};\\\", \\\"{x:509,y:654,t:1528143675528};\\\", \\\"{x:525,y:661,t:1528143675544};\\\", \\\"{x:531,y:664,t:1528143675562};\\\", \\\"{x:533,y:666,t:1528143675578};\\\", \\\"{x:535,y:668,t:1528143675595};\\\", \\\"{x:535,y:669,t:1528143675618};\\\", \\\"{x:535,y:670,t:1528143675628};\\\", \\\"{x:536,y:671,t:1528143675644};\\\", \\\"{x:536,y:672,t:1528143675850};\\\", \\\"{x:536,y:672,t:1528143675870};\\\", \\\"{x:540,y:672,t:1528143675978};\\\", \\\"{x:555,y:672,t:1528143675994};\\\", \\\"{x:569,y:672,t:1528143676011};\\\", \\\"{x:581,y:672,t:1528143676027};\\\", \\\"{x:594,y:674,t:1528143676044};\\\", \\\"{x:608,y:687,t:1528143676061};\\\", \\\"{x:628,y:702,t:1528143676078};\\\", \\\"{x:639,y:714,t:1528143676094};\\\", \\\"{x:655,y:726,t:1528143676112};\\\", \\\"{x:660,y:731,t:1528143676127};\\\", \\\"{x:663,y:732,t:1528143676144};\\\", \\\"{x:670,y:738,t:1528143676161};\\\", \\\"{x:673,y:740,t:1528143676178};\\\" ] }, { \\\"rt\\\": 63919, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 262308, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"8182H\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2.5, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -F -C -C -B -B -C -C -F -10 AM-08 AM-J -11 AM-11 AM-09 AM-11 AM-B -F -10 AM-B -B -02 PM-02 PM-B -12 PM-B -B -M -M -M -X -01 PM-03 PM-X -01 PM-X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:672,y:728,t:1528143679404};\\\", \\\"{x:654,y:693,t:1528143679425};\\\", \\\"{x:651,y:686,t:1528143679430};\\\", \\\"{x:642,y:671,t:1528143679447};\\\", \\\"{x:622,y:637,t:1528143679463};\\\", \\\"{x:605,y:624,t:1528143679480};\\\", \\\"{x:575,y:611,t:1528143679497};\\\", \\\"{x:505,y:578,t:1528143679514};\\\", \\\"{x:418,y:530,t:1528143679531};\\\", \\\"{x:391,y:506,t:1528143679548};\\\", \\\"{x:377,y:491,t:1528143679565};\\\", \\\"{x:366,y:477,t:1528143679581};\\\", \\\"{x:359,y:463,t:1528143679599};\\\", \\\"{x:354,y:448,t:1528143679614};\\\", \\\"{x:353,y:438,t:1528143679631};\\\", \\\"{x:353,y:429,t:1528143679648};\\\", \\\"{x:355,y:416,t:1528143679665};\\\", \\\"{x:363,y:403,t:1528143679681};\\\", \\\"{x:390,y:381,t:1528143679697};\\\", \\\"{x:417,y:368,t:1528143679714};\\\", \\\"{x:447,y:359,t:1528143679731};\\\", \\\"{x:471,y:353,t:1528143679748};\\\", \\\"{x:495,y:351,t:1528143679765};\\\", \\\"{x:518,y:351,t:1528143679780};\\\", \\\"{x:536,y:351,t:1528143679798};\\\", \\\"{x:556,y:353,t:1528143679815};\\\", \\\"{x:568,y:359,t:1528143679831};\\\", \\\"{x:581,y:365,t:1528143679848};\\\", \\\"{x:595,y:374,t:1528143679865};\\\", \\\"{x:603,y:378,t:1528143679881};\\\", \\\"{x:610,y:380,t:1528143679899};\\\", \\\"{x:611,y:380,t:1528143679915};\\\", \\\"{x:611,y:382,t:1528143680011};\\\", \\\"{x:612,y:387,t:1528143680019};\\\", \\\"{x:614,y:392,t:1528143680033};\\\", \\\"{x:621,y:406,t:1528143680048};\\\", \\\"{x:625,y:411,t:1528143680066};\\\", \\\"{x:632,y:417,t:1528143680083};\\\", \\\"{x:636,y:418,t:1528143680098};\\\", \\\"{x:645,y:420,t:1528143680115};\\\", \\\"{x:651,y:420,t:1528143680133};\\\", \\\"{x:655,y:420,t:1528143680148};\\\", \\\"{x:659,y:420,t:1528143680165};\\\", \\\"{x:662,y:420,t:1528143680182};\\\", \\\"{x:667,y:419,t:1528143680198};\\\", \\\"{x:670,y:418,t:1528143680215};\\\", \\\"{x:676,y:417,t:1528143680232};\\\", \\\"{x:677,y:417,t:1528143680248};\\\", \\\"{x:679,y:417,t:1528143680265};\\\", \\\"{x:679,y:416,t:1528143680346};\\\", \\\"{x:679,y:415,t:1528143680362};\\\", \\\"{x:679,y:411,t:1528143680370};\\\", \\\"{x:679,y:408,t:1528143680382};\\\", \\\"{x:679,y:405,t:1528143680398};\\\", \\\"{x:679,y:404,t:1528143680515};\\\", \\\"{x:679,y:409,t:1528143680891};\\\", \\\"{x:679,y:414,t:1528143680899};\\\", \\\"{x:679,y:424,t:1528143680915};\\\", \\\"{x:679,y:430,t:1528143680932};\\\", \\\"{x:679,y:435,t:1528143680951};\\\", \\\"{x:679,y:437,t:1528143680965};\\\", \\\"{x:679,y:439,t:1528143680981};\\\", \\\"{x:679,y:440,t:1528143681130};\\\", \\\"{x:681,y:440,t:1528143682627};\\\", \\\"{x:687,y:448,t:1528143682635};\\\", \\\"{x:698,y:465,t:1528143682652};\\\", \\\"{x:729,y:524,t:1528143682667};\\\", \\\"{x:753,y:558,t:1528143682685};\\\", \\\"{x:772,y:579,t:1528143682701};\\\", \\\"{x:782,y:591,t:1528143682717};\\\", \\\"{x:790,y:602,t:1528143682734};\\\", \\\"{x:801,y:619,t:1528143682749};\\\", \\\"{x:812,y:634,t:1528143682767};\\\", \\\"{x:825,y:653,t:1528143682784};\\\", \\\"{x:834,y:669,t:1528143682799};\\\", \\\"{x:839,y:681,t:1528143682817};\\\", \\\"{x:848,y:699,t:1528143682834};\\\", \\\"{x:859,y:717,t:1528143682850};\\\", \\\"{x:870,y:732,t:1528143682867};\\\", \\\"{x:884,y:748,t:1528143682884};\\\", \\\"{x:892,y:757,t:1528143682900};\\\", \\\"{x:898,y:764,t:1528143682917};\\\", \\\"{x:900,y:767,t:1528143682934};\\\", \\\"{x:901,y:768,t:1528143682950};\\\", \\\"{x:901,y:769,t:1528143682967};\\\", \\\"{x:902,y:769,t:1528143683003};\\\", \\\"{x:904,y:770,t:1528143683018};\\\", \\\"{x:916,y:778,t:1528143683034};\\\", \\\"{x:922,y:782,t:1528143683051};\\\", \\\"{x:932,y:785,t:1528143683067};\\\", \\\"{x:941,y:788,t:1528143683084};\\\", \\\"{x:961,y:791,t:1528143683101};\\\", \\\"{x:983,y:791,t:1528143683118};\\\", \\\"{x:1002,y:792,t:1528143683135};\\\", \\\"{x:1024,y:792,t:1528143683150};\\\", \\\"{x:1045,y:798,t:1528143683167};\\\", \\\"{x:1076,y:802,t:1528143683184};\\\", \\\"{x:1115,y:806,t:1528143683201};\\\", \\\"{x:1154,y:811,t:1528143683217};\\\", \\\"{x:1199,y:812,t:1528143683234};\\\", \\\"{x:1219,y:812,t:1528143683251};\\\", \\\"{x:1228,y:814,t:1528143683267};\\\", \\\"{x:1229,y:814,t:1528143683307};\\\", \\\"{x:1228,y:814,t:1528143683579};\\\", \\\"{x:1228,y:812,t:1528143683587};\\\", \\\"{x:1226,y:810,t:1528143683602};\\\", \\\"{x:1223,y:803,t:1528143683618};\\\", \\\"{x:1218,y:796,t:1528143683635};\\\", \\\"{x:1216,y:791,t:1528143683651};\\\", \\\"{x:1214,y:788,t:1528143683669};\\\", \\\"{x:1213,y:786,t:1528143683685};\\\", \\\"{x:1212,y:785,t:1528143683701};\\\", \\\"{x:1212,y:784,t:1528143683718};\\\", \\\"{x:1211,y:783,t:1528143683733};\\\", \\\"{x:1211,y:782,t:1528143683751};\\\", \\\"{x:1211,y:781,t:1528143683779};\\\", \\\"{x:1210,y:781,t:1528143683801};\\\", \\\"{x:1206,y:780,t:1528143688932};\\\", \\\"{x:1190,y:771,t:1528143688939};\\\", \\\"{x:1123,y:748,t:1528143688956};\\\", \\\"{x:1017,y:718,t:1528143688972};\\\", \\\"{x:910,y:689,t:1528143688989};\\\", \\\"{x:809,y:667,t:1528143689006};\\\", \\\"{x:689,y:647,t:1528143689022};\\\", \\\"{x:574,y:622,t:1528143689038};\\\", \\\"{x:471,y:592,t:1528143689056};\\\", \\\"{x:381,y:559,t:1528143689072};\\\", \\\"{x:309,y:523,t:1528143689088};\\\", \\\"{x:267,y:497,t:1528143689106};\\\", \\\"{x:235,y:475,t:1528143689121};\\\", \\\"{x:228,y:468,t:1528143689140};\\\", \\\"{x:226,y:466,t:1528143689155};\\\", \\\"{x:225,y:465,t:1528143689172};\\\", \\\"{x:233,y:464,t:1528143691429};\\\", \\\"{x:265,y:474,t:1528143691438};\\\", \\\"{x:371,y:506,t:1528143691457};\\\", \\\"{x:623,y:553,t:1528143691474};\\\", \\\"{x:810,y:573,t:1528143691491};\\\", \\\"{x:1012,y:580,t:1528143691508};\\\", \\\"{x:1195,y:580,t:1528143691525};\\\", \\\"{x:1366,y:580,t:1528143691540};\\\", \\\"{x:1488,y:580,t:1528143691557};\\\", \\\"{x:1560,y:580,t:1528143691574};\\\", \\\"{x:1595,y:580,t:1528143691590};\\\", \\\"{x:1606,y:582,t:1528143691607};\\\", \\\"{x:1608,y:582,t:1528143691624};\\\", \\\"{x:1610,y:584,t:1528143691640};\\\", \\\"{x:1612,y:588,t:1528143691657};\\\", \\\"{x:1613,y:591,t:1528143691674};\\\", \\\"{x:1616,y:592,t:1528143691690};\\\", \\\"{x:1622,y:597,t:1528143691707};\\\", \\\"{x:1625,y:600,t:1528143691725};\\\", \\\"{x:1625,y:602,t:1528143691741};\\\", \\\"{x:1625,y:603,t:1528143691758};\\\", \\\"{x:1625,y:605,t:1528143691778};\\\", \\\"{x:1625,y:606,t:1528143691791};\\\", \\\"{x:1620,y:609,t:1528143691808};\\\", \\\"{x:1605,y:612,t:1528143691825};\\\", \\\"{x:1588,y:620,t:1528143691842};\\\", \\\"{x:1571,y:625,t:1528143691858};\\\", \\\"{x:1547,y:632,t:1528143691875};\\\", \\\"{x:1531,y:636,t:1528143691891};\\\", \\\"{x:1501,y:637,t:1528143691908};\\\", \\\"{x:1462,y:637,t:1528143691925};\\\", \\\"{x:1381,y:636,t:1528143691942};\\\", \\\"{x:1286,y:632,t:1528143691957};\\\", \\\"{x:1199,y:635,t:1528143691975};\\\", \\\"{x:1102,y:645,t:1528143691991};\\\", \\\"{x:1035,y:657,t:1528143692008};\\\", \\\"{x:923,y:663,t:1528143692025};\\\", \\\"{x:867,y:671,t:1528143692042};\\\", \\\"{x:850,y:673,t:1528143692057};\\\", \\\"{x:847,y:673,t:1528143692075};\\\", \\\"{x:847,y:675,t:1528143692131};\\\", \\\"{x:851,y:676,t:1528143692141};\\\", \\\"{x:878,y:683,t:1528143692157};\\\", \\\"{x:923,y:689,t:1528143692174};\\\", \\\"{x:998,y:698,t:1528143692191};\\\", \\\"{x:1067,y:698,t:1528143692207};\\\", \\\"{x:1134,y:698,t:1528143692225};\\\", \\\"{x:1182,y:698,t:1528143692241};\\\", \\\"{x:1234,y:698,t:1528143692258};\\\", \\\"{x:1255,y:698,t:1528143692275};\\\", \\\"{x:1270,y:697,t:1528143692291};\\\", \\\"{x:1282,y:695,t:1528143692308};\\\", \\\"{x:1295,y:692,t:1528143692324};\\\", \\\"{x:1305,y:688,t:1528143692342};\\\", \\\"{x:1309,y:685,t:1528143692358};\\\", \\\"{x:1314,y:681,t:1528143692374};\\\", \\\"{x:1318,y:675,t:1528143692392};\\\", \\\"{x:1323,y:668,t:1528143692409};\\\", \\\"{x:1327,y:663,t:1528143692424};\\\", \\\"{x:1331,y:655,t:1528143692442};\\\", \\\"{x:1336,y:647,t:1528143692459};\\\", \\\"{x:1339,y:641,t:1528143692475};\\\", \\\"{x:1342,y:636,t:1528143692492};\\\", \\\"{x:1344,y:630,t:1528143692509};\\\", \\\"{x:1345,y:625,t:1528143692525};\\\", \\\"{x:1346,y:622,t:1528143692542};\\\", \\\"{x:1347,y:618,t:1528143692559};\\\", \\\"{x:1347,y:612,t:1528143692575};\\\", \\\"{x:1347,y:607,t:1528143692592};\\\", \\\"{x:1347,y:599,t:1528143692608};\\\", \\\"{x:1347,y:593,t:1528143692625};\\\", \\\"{x:1347,y:591,t:1528143692642};\\\", \\\"{x:1347,y:588,t:1528143692658};\\\", \\\"{x:1347,y:586,t:1528143692675};\\\", \\\"{x:1347,y:584,t:1528143692692};\\\", \\\"{x:1347,y:582,t:1528143692708};\\\", \\\"{x:1351,y:581,t:1528143692803};\\\", \\\"{x:1365,y:581,t:1528143692810};\\\", \\\"{x:1380,y:581,t:1528143692826};\\\", \\\"{x:1419,y:581,t:1528143692842};\\\", \\\"{x:1470,y:581,t:1528143692859};\\\", \\\"{x:1492,y:581,t:1528143692876};\\\", \\\"{x:1502,y:581,t:1528143692891};\\\", \\\"{x:1503,y:581,t:1528143692986};\\\", \\\"{x:1502,y:579,t:1528143693042};\\\", \\\"{x:1485,y:573,t:1528143693058};\\\", \\\"{x:1462,y:569,t:1528143693076};\\\", \\\"{x:1449,y:569,t:1528143693091};\\\", \\\"{x:1444,y:569,t:1528143693109};\\\", \\\"{x:1442,y:569,t:1528143693126};\\\", \\\"{x:1441,y:571,t:1528143693507};\\\", \\\"{x:1441,y:572,t:1528143693515};\\\", \\\"{x:1441,y:573,t:1528143693525};\\\", \\\"{x:1441,y:574,t:1528143694099};\\\", \\\"{x:1441,y:575,t:1528143694379};\\\", \\\"{x:1442,y:575,t:1528143694394};\\\", \\\"{x:1442,y:576,t:1528143694409};\\\", \\\"{x:1444,y:576,t:1528143694427};\\\", \\\"{x:1445,y:576,t:1528143697123};\\\", \\\"{x:1445,y:580,t:1528143697146};\\\", \\\"{x:1445,y:587,t:1528143697163};\\\", \\\"{x:1445,y:590,t:1528143697179};\\\", \\\"{x:1444,y:593,t:1528143697196};\\\", \\\"{x:1444,y:594,t:1528143697212};\\\", \\\"{x:1443,y:596,t:1528143697323};\\\", \\\"{x:1441,y:603,t:1528143697331};\\\", \\\"{x:1438,y:608,t:1528143697346};\\\", \\\"{x:1432,y:619,t:1528143697362};\\\", \\\"{x:1424,y:630,t:1528143697379};\\\", \\\"{x:1421,y:636,t:1528143697397};\\\", \\\"{x:1418,y:644,t:1528143697413};\\\", \\\"{x:1416,y:650,t:1528143697429};\\\", \\\"{x:1413,y:655,t:1528143697446};\\\", \\\"{x:1412,y:660,t:1528143697462};\\\", \\\"{x:1408,y:669,t:1528143697479};\\\", \\\"{x:1406,y:675,t:1528143697496};\\\", \\\"{x:1403,y:682,t:1528143697512};\\\", \\\"{x:1401,y:686,t:1528143697529};\\\", \\\"{x:1400,y:690,t:1528143697546};\\\", \\\"{x:1398,y:694,t:1528143697563};\\\", \\\"{x:1396,y:699,t:1528143697579};\\\", \\\"{x:1392,y:705,t:1528143697597};\\\", \\\"{x:1389,y:709,t:1528143697613};\\\", \\\"{x:1385,y:714,t:1528143697630};\\\", \\\"{x:1382,y:719,t:1528143697646};\\\", \\\"{x:1376,y:726,t:1528143697663};\\\", \\\"{x:1369,y:736,t:1528143697679};\\\", \\\"{x:1363,y:746,t:1528143697696};\\\", \\\"{x:1357,y:756,t:1528143697712};\\\", \\\"{x:1351,y:767,t:1528143697729};\\\", \\\"{x:1341,y:786,t:1528143697746};\\\", \\\"{x:1334,y:796,t:1528143697762};\\\", \\\"{x:1332,y:802,t:1528143697779};\\\", \\\"{x:1330,y:807,t:1528143697795};\\\", \\\"{x:1328,y:811,t:1528143697813};\\\", \\\"{x:1327,y:816,t:1528143697828};\\\", \\\"{x:1325,y:818,t:1528143697845};\\\", \\\"{x:1324,y:822,t:1528143697863};\\\", \\\"{x:1321,y:825,t:1528143697878};\\\", \\\"{x:1320,y:827,t:1528143697896};\\\", \\\"{x:1319,y:827,t:1528143697913};\\\", \\\"{x:1319,y:829,t:1528143697928};\\\", \\\"{x:1318,y:830,t:1528143697946};\\\", \\\"{x:1317,y:831,t:1528143697970};\\\", \\\"{x:1317,y:833,t:1528143697987};\\\", \\\"{x:1316,y:833,t:1528143697996};\\\", \\\"{x:1314,y:836,t:1528143698013};\\\", \\\"{x:1311,y:839,t:1528143698030};\\\", \\\"{x:1308,y:843,t:1528143698046};\\\", \\\"{x:1306,y:845,t:1528143698063};\\\", \\\"{x:1303,y:849,t:1528143698080};\\\", \\\"{x:1300,y:855,t:1528143698096};\\\", \\\"{x:1297,y:860,t:1528143698113};\\\", \\\"{x:1292,y:868,t:1528143698130};\\\", \\\"{x:1291,y:870,t:1528143698146};\\\", \\\"{x:1288,y:877,t:1528143698163};\\\", \\\"{x:1286,y:880,t:1528143698180};\\\", \\\"{x:1284,y:884,t:1528143698195};\\\", \\\"{x:1283,y:890,t:1528143698213};\\\", \\\"{x:1280,y:897,t:1528143698230};\\\", \\\"{x:1280,y:900,t:1528143698246};\\\", \\\"{x:1279,y:902,t:1528143698263};\\\", \\\"{x:1278,y:903,t:1528143698280};\\\", \\\"{x:1278,y:900,t:1528143699651};\\\", \\\"{x:1279,y:888,t:1528143699665};\\\", \\\"{x:1285,y:861,t:1528143699681};\\\", \\\"{x:1299,y:826,t:1528143699697};\\\", \\\"{x:1318,y:785,t:1528143699714};\\\", \\\"{x:1329,y:763,t:1528143699731};\\\", \\\"{x:1337,y:742,t:1528143699747};\\\", \\\"{x:1339,y:726,t:1528143699764};\\\", \\\"{x:1342,y:710,t:1528143699782};\\\", \\\"{x:1344,y:695,t:1528143699799};\\\", \\\"{x:1349,y:679,t:1528143699814};\\\", \\\"{x:1353,y:665,t:1528143699831};\\\", \\\"{x:1356,y:650,t:1528143699848};\\\", \\\"{x:1361,y:635,t:1528143699865};\\\", \\\"{x:1365,y:620,t:1528143699881};\\\", \\\"{x:1370,y:605,t:1528143699898};\\\", \\\"{x:1375,y:596,t:1528143699914};\\\", \\\"{x:1378,y:589,t:1528143699930};\\\", \\\"{x:1380,y:584,t:1528143699948};\\\", \\\"{x:1387,y:578,t:1528143699963};\\\", \\\"{x:1391,y:572,t:1528143699981};\\\", \\\"{x:1398,y:567,t:1528143699998};\\\", \\\"{x:1409,y:561,t:1528143700014};\\\", \\\"{x:1416,y:559,t:1528143700031};\\\", \\\"{x:1421,y:558,t:1528143700047};\\\", \\\"{x:1427,y:557,t:1528143700064};\\\", \\\"{x:1433,y:557,t:1528143700080};\\\", \\\"{x:1439,y:557,t:1528143700098};\\\", \\\"{x:1441,y:557,t:1528143700114};\\\", \\\"{x:1442,y:557,t:1528143700154};\\\", \\\"{x:1443,y:557,t:1528143700186};\\\", \\\"{x:1444,y:557,t:1528143700203};\\\", \\\"{x:1444,y:558,t:1528143700215};\\\", \\\"{x:1447,y:562,t:1528143700232};\\\", \\\"{x:1447,y:565,t:1528143700249};\\\", \\\"{x:1448,y:569,t:1528143700265};\\\", \\\"{x:1449,y:571,t:1528143700281};\\\", \\\"{x:1449,y:572,t:1528143700298};\\\", \\\"{x:1449,y:573,t:1528143700315};\\\", \\\"{x:1450,y:573,t:1528143700378};\\\", \\\"{x:1450,y:575,t:1528143700531};\\\", \\\"{x:1430,y:586,t:1528143700549};\\\", \\\"{x:1374,y:602,t:1528143700565};\\\", \\\"{x:1297,y:621,t:1528143700582};\\\", \\\"{x:1222,y:643,t:1528143700598};\\\", \\\"{x:1177,y:656,t:1528143700615};\\\", \\\"{x:1164,y:662,t:1528143700632};\\\", \\\"{x:1162,y:663,t:1528143700648};\\\", \\\"{x:1162,y:664,t:1528143700665};\\\", \\\"{x:1165,y:668,t:1528143700681};\\\", \\\"{x:1182,y:673,t:1528143700699};\\\", \\\"{x:1202,y:678,t:1528143700715};\\\", \\\"{x:1233,y:683,t:1528143700732};\\\", \\\"{x:1262,y:684,t:1528143700748};\\\", \\\"{x:1290,y:684,t:1528143700765};\\\", \\\"{x:1311,y:684,t:1528143700783};\\\", \\\"{x:1321,y:684,t:1528143700798};\\\", \\\"{x:1325,y:684,t:1528143700815};\\\", \\\"{x:1329,y:684,t:1528143700832};\\\", \\\"{x:1330,y:683,t:1528143700848};\\\", \\\"{x:1331,y:683,t:1528143700865};\\\", \\\"{x:1334,y:680,t:1528143700882};\\\", \\\"{x:1335,y:678,t:1528143700899};\\\", \\\"{x:1336,y:676,t:1528143700915};\\\", \\\"{x:1337,y:671,t:1528143700933};\\\", \\\"{x:1337,y:668,t:1528143700949};\\\", \\\"{x:1337,y:666,t:1528143700965};\\\", \\\"{x:1337,y:663,t:1528143700982};\\\", \\\"{x:1337,y:660,t:1528143700999};\\\", \\\"{x:1337,y:655,t:1528143701016};\\\", \\\"{x:1338,y:651,t:1528143701033};\\\", \\\"{x:1339,y:649,t:1528143701049};\\\", \\\"{x:1340,y:645,t:1528143701065};\\\", \\\"{x:1341,y:645,t:1528143701082};\\\", \\\"{x:1342,y:645,t:1528143701756};\\\", \\\"{x:1343,y:645,t:1528143701783};\\\", \\\"{x:1344,y:645,t:1528143701802};\\\", \\\"{x:1344,y:647,t:1528143701930};\\\", \\\"{x:1340,y:651,t:1528143701940};\\\", \\\"{x:1337,y:655,t:1528143701949};\\\", \\\"{x:1333,y:660,t:1528143701966};\\\", \\\"{x:1330,y:662,t:1528143701982};\\\", \\\"{x:1328,y:664,t:1528143701999};\\\", \\\"{x:1327,y:664,t:1528143702016};\\\", \\\"{x:1327,y:665,t:1528143702065};\\\", \\\"{x:1325,y:670,t:1528143702082};\\\", \\\"{x:1324,y:679,t:1528143702099};\\\", \\\"{x:1324,y:688,t:1528143702115};\\\", \\\"{x:1323,y:694,t:1528143702132};\\\", \\\"{x:1321,y:699,t:1528143702149};\\\", \\\"{x:1319,y:708,t:1528143702165};\\\", \\\"{x:1319,y:713,t:1528143702182};\\\", \\\"{x:1317,y:721,t:1528143702198};\\\", \\\"{x:1314,y:731,t:1528143702216};\\\", \\\"{x:1309,y:743,t:1528143702233};\\\", \\\"{x:1304,y:756,t:1528143702249};\\\", \\\"{x:1297,y:771,t:1528143702265};\\\", \\\"{x:1293,y:777,t:1528143702283};\\\", \\\"{x:1293,y:781,t:1528143702299};\\\", \\\"{x:1292,y:784,t:1528143702316};\\\", \\\"{x:1290,y:788,t:1528143702333};\\\", \\\"{x:1289,y:792,t:1528143702349};\\\", \\\"{x:1287,y:795,t:1528143702366};\\\", \\\"{x:1285,y:800,t:1528143702383};\\\", \\\"{x:1284,y:803,t:1528143702399};\\\", \\\"{x:1282,y:805,t:1528143702416};\\\", \\\"{x:1280,y:807,t:1528143702433};\\\", \\\"{x:1279,y:808,t:1528143702450};\\\", \\\"{x:1275,y:811,t:1528143702466};\\\", \\\"{x:1270,y:815,t:1528143702482};\\\", \\\"{x:1262,y:819,t:1528143702500};\\\", \\\"{x:1254,y:824,t:1528143702515};\\\", \\\"{x:1247,y:829,t:1528143702533};\\\", \\\"{x:1242,y:832,t:1528143702551};\\\", \\\"{x:1236,y:837,t:1528143702566};\\\", \\\"{x:1233,y:840,t:1528143702583};\\\", \\\"{x:1231,y:843,t:1528143702600};\\\", \\\"{x:1229,y:845,t:1528143702616};\\\", \\\"{x:1227,y:848,t:1528143702633};\\\", \\\"{x:1225,y:853,t:1528143702650};\\\", \\\"{x:1223,y:861,t:1528143702666};\\\", \\\"{x:1222,y:864,t:1528143702683};\\\", \\\"{x:1221,y:868,t:1528143702700};\\\", \\\"{x:1220,y:875,t:1528143702716};\\\", \\\"{x:1219,y:880,t:1528143702733};\\\", \\\"{x:1218,y:882,t:1528143702750};\\\", \\\"{x:1218,y:885,t:1528143702766};\\\", \\\"{x:1217,y:888,t:1528143702783};\\\", \\\"{x:1217,y:891,t:1528143702801};\\\", \\\"{x:1215,y:895,t:1528143702817};\\\", \\\"{x:1215,y:897,t:1528143702833};\\\", \\\"{x:1213,y:902,t:1528143702850};\\\", \\\"{x:1212,y:905,t:1528143702866};\\\", \\\"{x:1211,y:908,t:1528143702883};\\\", \\\"{x:1210,y:910,t:1528143702900};\\\", \\\"{x:1210,y:911,t:1528143702917};\\\", \\\"{x:1208,y:914,t:1528143702933};\\\", \\\"{x:1208,y:915,t:1528143702955};\\\", \\\"{x:1208,y:916,t:1528143702970};\\\", \\\"{x:1208,y:911,t:1528143703932};\\\", \\\"{x:1208,y:906,t:1528143703939};\\\", \\\"{x:1208,y:899,t:1528143703951};\\\", \\\"{x:1205,y:879,t:1528143703967};\\\", \\\"{x:1195,y:850,t:1528143703984};\\\", \\\"{x:1173,y:815,t:1528143704002};\\\", \\\"{x:1161,y:791,t:1528143704017};\\\", \\\"{x:1144,y:756,t:1528143704035};\\\", \\\"{x:1140,y:738,t:1528143704051};\\\", \\\"{x:1140,y:726,t:1528143704067};\\\", \\\"{x:1144,y:720,t:1528143704084};\\\", \\\"{x:1146,y:717,t:1528143704102};\\\", \\\"{x:1148,y:716,t:1528143704117};\\\", \\\"{x:1149,y:716,t:1528143704187};\\\", \\\"{x:1151,y:716,t:1528143704201};\\\", \\\"{x:1160,y:714,t:1528143704219};\\\", \\\"{x:1166,y:714,t:1528143704234};\\\", \\\"{x:1170,y:714,t:1528143704252};\\\", \\\"{x:1172,y:714,t:1528143704268};\\\", \\\"{x:1173,y:714,t:1528143704285};\\\", \\\"{x:1175,y:714,t:1528143704459};\\\", \\\"{x:1177,y:717,t:1528143704475};\\\", \\\"{x:1177,y:719,t:1528143704484};\\\", \\\"{x:1178,y:726,t:1528143704502};\\\", \\\"{x:1179,y:740,t:1528143704519};\\\", \\\"{x:1179,y:759,t:1528143704535};\\\", \\\"{x:1175,y:782,t:1528143704551};\\\", \\\"{x:1169,y:804,t:1528143704569};\\\", \\\"{x:1160,y:825,t:1528143704585};\\\", \\\"{x:1153,y:841,t:1528143704602};\\\", \\\"{x:1147,y:854,t:1528143704619};\\\", \\\"{x:1144,y:862,t:1528143704635};\\\", \\\"{x:1141,y:867,t:1528143704651};\\\", \\\"{x:1139,y:874,t:1528143704668};\\\", \\\"{x:1134,y:883,t:1528143704687};\\\", \\\"{x:1130,y:890,t:1528143704702};\\\", \\\"{x:1126,y:896,t:1528143704719};\\\", \\\"{x:1123,y:900,t:1528143704735};\\\", \\\"{x:1120,y:902,t:1528143704752};\\\", \\\"{x:1115,y:905,t:1528143704768};\\\", \\\"{x:1110,y:907,t:1528143704785};\\\", \\\"{x:1106,y:909,t:1528143704802};\\\", \\\"{x:1096,y:913,t:1528143704819};\\\", \\\"{x:1090,y:915,t:1528143704835};\\\", \\\"{x:1083,y:918,t:1528143704852};\\\", \\\"{x:1074,y:923,t:1528143704868};\\\", \\\"{x:1070,y:925,t:1528143704885};\\\", \\\"{x:1067,y:928,t:1528143704902};\\\", \\\"{x:1072,y:923,t:1528143705203};\\\", \\\"{x:1088,y:904,t:1528143705219};\\\", \\\"{x:1109,y:881,t:1528143705236};\\\", \\\"{x:1134,y:853,t:1528143705252};\\\", \\\"{x:1150,y:831,t:1528143705269};\\\", \\\"{x:1167,y:801,t:1528143705287};\\\", \\\"{x:1177,y:775,t:1528143705302};\\\", \\\"{x:1183,y:746,t:1528143705319};\\\", \\\"{x:1188,y:727,t:1528143705336};\\\", \\\"{x:1189,y:715,t:1528143705352};\\\", \\\"{x:1189,y:711,t:1528143705369};\\\", \\\"{x:1189,y:707,t:1528143705385};\\\", \\\"{x:1189,y:704,t:1528143705403};\\\", \\\"{x:1189,y:703,t:1528143705419};\\\", \\\"{x:1189,y:702,t:1528143705436};\\\", \\\"{x:1188,y:703,t:1528143705651};\\\", \\\"{x:1188,y:704,t:1528143705771};\\\", \\\"{x:1188,y:706,t:1528143705785};\\\", \\\"{x:1191,y:713,t:1528143705802};\\\", \\\"{x:1197,y:721,t:1528143705819};\\\", \\\"{x:1200,y:728,t:1528143705836};\\\", \\\"{x:1203,y:733,t:1528143705852};\\\", \\\"{x:1206,y:738,t:1528143705869};\\\", \\\"{x:1210,y:746,t:1528143705886};\\\", \\\"{x:1211,y:752,t:1528143705903};\\\", \\\"{x:1215,y:758,t:1528143705919};\\\", \\\"{x:1216,y:765,t:1528143705935};\\\", \\\"{x:1219,y:771,t:1528143705952};\\\", \\\"{x:1221,y:779,t:1528143705969};\\\", \\\"{x:1226,y:789,t:1528143705985};\\\", \\\"{x:1228,y:796,t:1528143706002};\\\", \\\"{x:1231,y:801,t:1528143706019};\\\", \\\"{x:1234,y:808,t:1528143706036};\\\", \\\"{x:1236,y:813,t:1528143706052};\\\", \\\"{x:1239,y:821,t:1528143706070};\\\", \\\"{x:1243,y:829,t:1528143706087};\\\", \\\"{x:1246,y:837,t:1528143706102};\\\", \\\"{x:1249,y:844,t:1528143706119};\\\", \\\"{x:1251,y:848,t:1528143706136};\\\", \\\"{x:1252,y:850,t:1528143706152};\\\", \\\"{x:1252,y:852,t:1528143706169};\\\", \\\"{x:1254,y:861,t:1528143706187};\\\", \\\"{x:1256,y:872,t:1528143706202};\\\", \\\"{x:1260,y:886,t:1528143706219};\\\", \\\"{x:1265,y:896,t:1528143706236};\\\", \\\"{x:1270,y:909,t:1528143706252};\\\", \\\"{x:1275,y:919,t:1528143706270};\\\", \\\"{x:1276,y:923,t:1528143706286};\\\", \\\"{x:1279,y:928,t:1528143706302};\\\", \\\"{x:1279,y:930,t:1528143706319};\\\", \\\"{x:1280,y:930,t:1528143706336};\\\", \\\"{x:1280,y:931,t:1528143706387};\\\", \\\"{x:1281,y:932,t:1528143706403};\\\", \\\"{x:1282,y:932,t:1528143706434};\\\", \\\"{x:1282,y:933,t:1528143706450};\\\", \\\"{x:1284,y:933,t:1528143706603};\\\", \\\"{x:1285,y:930,t:1528143706716};\\\", \\\"{x:1286,y:925,t:1528143706723};\\\", \\\"{x:1286,y:924,t:1528143706736};\\\", \\\"{x:1286,y:923,t:1528143706754};\\\", \\\"{x:1287,y:920,t:1528143706770};\\\", \\\"{x:1287,y:919,t:1528143706787};\\\", \\\"{x:1287,y:917,t:1528143706978};\\\", \\\"{x:1285,y:915,t:1528143706986};\\\", \\\"{x:1280,y:910,t:1528143707003};\\\", \\\"{x:1269,y:905,t:1528143707020};\\\", \\\"{x:1256,y:898,t:1528143707036};\\\", \\\"{x:1241,y:888,t:1528143707053};\\\", \\\"{x:1230,y:880,t:1528143707069};\\\", \\\"{x:1225,y:876,t:1528143707086};\\\", \\\"{x:1222,y:869,t:1528143707103};\\\", \\\"{x:1221,y:863,t:1528143707120};\\\", \\\"{x:1221,y:855,t:1528143707136};\\\", \\\"{x:1221,y:846,t:1528143707153};\\\", \\\"{x:1221,y:838,t:1528143707170};\\\", \\\"{x:1221,y:833,t:1528143707186};\\\", \\\"{x:1221,y:830,t:1528143707203};\\\", \\\"{x:1221,y:827,t:1528143707220};\\\", \\\"{x:1221,y:826,t:1528143707236};\\\", \\\"{x:1221,y:824,t:1528143707253};\\\", \\\"{x:1221,y:820,t:1528143707270};\\\", \\\"{x:1221,y:817,t:1528143707287};\\\", \\\"{x:1221,y:813,t:1528143707303};\\\", \\\"{x:1221,y:809,t:1528143707321};\\\", \\\"{x:1221,y:803,t:1528143707336};\\\", \\\"{x:1221,y:798,t:1528143707354};\\\", \\\"{x:1212,y:783,t:1528143707370};\\\", \\\"{x:1208,y:771,t:1528143707387};\\\", \\\"{x:1207,y:768,t:1528143707403};\\\", \\\"{x:1207,y:767,t:1528143707420};\\\", \\\"{x:1207,y:766,t:1528143707437};\\\", \\\"{x:1207,y:765,t:1528143707507};\\\", \\\"{x:1206,y:764,t:1528143707571};\\\", \\\"{x:1206,y:766,t:1528143707739};\\\", \\\"{x:1206,y:767,t:1528143707763};\\\", \\\"{x:1205,y:770,t:1528143707787};\\\", \\\"{x:1201,y:774,t:1528143707805};\\\", \\\"{x:1196,y:779,t:1528143707821};\\\", \\\"{x:1190,y:787,t:1528143707837};\\\", \\\"{x:1184,y:802,t:1528143707855};\\\", \\\"{x:1176,y:818,t:1528143707871};\\\", \\\"{x:1170,y:835,t:1528143707887};\\\", \\\"{x:1163,y:854,t:1528143707904};\\\", \\\"{x:1158,y:872,t:1528143707921};\\\", \\\"{x:1153,y:888,t:1528143707937};\\\", \\\"{x:1150,y:901,t:1528143707955};\\\", \\\"{x:1150,y:906,t:1528143707970};\\\", \\\"{x:1150,y:908,t:1528143707988};\\\", \\\"{x:1150,y:912,t:1528143708004};\\\", \\\"{x:1150,y:913,t:1528143708021};\\\", \\\"{x:1150,y:915,t:1528143708037};\\\", \\\"{x:1150,y:916,t:1528143708055};\\\", \\\"{x:1150,y:918,t:1528143708071};\\\", \\\"{x:1150,y:920,t:1528143708087};\\\", \\\"{x:1149,y:921,t:1528143708105};\\\", \\\"{x:1148,y:921,t:1528143708251};\\\", \\\"{x:1146,y:920,t:1528143708315};\\\", \\\"{x:1146,y:918,t:1528143708322};\\\", \\\"{x:1146,y:915,t:1528143708339};\\\", \\\"{x:1151,y:899,t:1528143708355};\\\", \\\"{x:1159,y:883,t:1528143708372};\\\", \\\"{x:1168,y:864,t:1528143708388};\\\", \\\"{x:1178,y:846,t:1528143708404};\\\", \\\"{x:1187,y:833,t:1528143708421};\\\", \\\"{x:1196,y:820,t:1528143708438};\\\", \\\"{x:1202,y:812,t:1528143708455};\\\", \\\"{x:1206,y:805,t:1528143708472};\\\", \\\"{x:1209,y:799,t:1528143708487};\\\", \\\"{x:1212,y:795,t:1528143708505};\\\", \\\"{x:1213,y:792,t:1528143708522};\\\", \\\"{x:1214,y:791,t:1528143708537};\\\", \\\"{x:1215,y:788,t:1528143708555};\\\", \\\"{x:1215,y:787,t:1528143708571};\\\", \\\"{x:1216,y:785,t:1528143708588};\\\", \\\"{x:1216,y:784,t:1528143708659};\\\", \\\"{x:1219,y:784,t:1528143708851};\\\", \\\"{x:1220,y:786,t:1528143708858};\\\", \\\"{x:1224,y:790,t:1528143708872};\\\", \\\"{x:1228,y:796,t:1528143708888};\\\", \\\"{x:1236,y:805,t:1528143708904};\\\", \\\"{x:1241,y:813,t:1528143708921};\\\", \\\"{x:1254,y:830,t:1528143708937};\\\", \\\"{x:1264,y:843,t:1528143708954};\\\", \\\"{x:1274,y:851,t:1528143708971};\\\", \\\"{x:1282,y:857,t:1528143708988};\\\", \\\"{x:1290,y:867,t:1528143709004};\\\", \\\"{x:1296,y:872,t:1528143709022};\\\", \\\"{x:1299,y:876,t:1528143709038};\\\", \\\"{x:1303,y:883,t:1528143709054};\\\", \\\"{x:1305,y:888,t:1528143709071};\\\", \\\"{x:1307,y:891,t:1528143709088};\\\", \\\"{x:1313,y:897,t:1528143709106};\\\", \\\"{x:1318,y:903,t:1528143709121};\\\", \\\"{x:1321,y:908,t:1528143709139};\\\", \\\"{x:1323,y:911,t:1528143709156};\\\", \\\"{x:1321,y:911,t:1528143709267};\\\", \\\"{x:1314,y:911,t:1528143709275};\\\", \\\"{x:1308,y:912,t:1528143709289};\\\", \\\"{x:1299,y:914,t:1528143709305};\\\", \\\"{x:1292,y:914,t:1528143709321};\\\", \\\"{x:1280,y:914,t:1528143709338};\\\", \\\"{x:1279,y:914,t:1528143709356};\\\", \\\"{x:1278,y:914,t:1528143709372};\\\", \\\"{x:1277,y:914,t:1528143709394};\\\", \\\"{x:1279,y:914,t:1528143709875};\\\", \\\"{x:1281,y:915,t:1528143709899};\\\", \\\"{x:1282,y:916,t:1528143709907};\\\", \\\"{x:1284,y:916,t:1528143709922};\\\", \\\"{x:1286,y:916,t:1528143709939};\\\", \\\"{x:1287,y:916,t:1528143709979};\\\", \\\"{x:1287,y:914,t:1528143709995};\\\", \\\"{x:1287,y:913,t:1528143710005};\\\", \\\"{x:1287,y:911,t:1528143710023};\\\", \\\"{x:1287,y:910,t:1528143710039};\\\", \\\"{x:1287,y:909,t:1528143710059};\\\", \\\"{x:1287,y:908,t:1528143710074};\\\", \\\"{x:1286,y:906,t:1528143710635};\\\", \\\"{x:1286,y:901,t:1528143710642};\\\", \\\"{x:1286,y:899,t:1528143710657};\\\", \\\"{x:1286,y:893,t:1528143710673};\\\", \\\"{x:1286,y:886,t:1528143710689};\\\", \\\"{x:1286,y:877,t:1528143710706};\\\", \\\"{x:1286,y:874,t:1528143710722};\\\", \\\"{x:1286,y:872,t:1528143710740};\\\", \\\"{x:1286,y:871,t:1528143710762};\\\", \\\"{x:1286,y:870,t:1528143710786};\\\", \\\"{x:1286,y:869,t:1528143710803};\\\", \\\"{x:1286,y:868,t:1528143710835};\\\", \\\"{x:1286,y:866,t:1528143710850};\\\", \\\"{x:1286,y:865,t:1528143710858};\\\", \\\"{x:1287,y:863,t:1528143710873};\\\", \\\"{x:1288,y:861,t:1528143710890};\\\", \\\"{x:1291,y:852,t:1528143710906};\\\", \\\"{x:1294,y:845,t:1528143710924};\\\", \\\"{x:1299,y:836,t:1528143710939};\\\", \\\"{x:1305,y:826,t:1528143710957};\\\", \\\"{x:1310,y:817,t:1528143710974};\\\", \\\"{x:1314,y:804,t:1528143710990};\\\", \\\"{x:1319,y:790,t:1528143711007};\\\", \\\"{x:1325,y:781,t:1528143711024};\\\", \\\"{x:1327,y:775,t:1528143711040};\\\", \\\"{x:1327,y:773,t:1528143711057};\\\", \\\"{x:1327,y:772,t:1528143711074};\\\", \\\"{x:1327,y:771,t:1528143711107};\\\", \\\"{x:1327,y:770,t:1528143711124};\\\", \\\"{x:1327,y:769,t:1528143711146};\\\", \\\"{x:1327,y:768,t:1528143711157};\\\", \\\"{x:1327,y:767,t:1528143711174};\\\", \\\"{x:1327,y:764,t:1528143711190};\\\", \\\"{x:1327,y:761,t:1528143711207};\\\", \\\"{x:1328,y:758,t:1528143711224};\\\", \\\"{x:1329,y:753,t:1528143711240};\\\", \\\"{x:1331,y:747,t:1528143711256};\\\", \\\"{x:1331,y:746,t:1528143711274};\\\", \\\"{x:1332,y:744,t:1528143711291};\\\", \\\"{x:1334,y:741,t:1528143711307};\\\", \\\"{x:1334,y:740,t:1528143711324};\\\", \\\"{x:1334,y:739,t:1528143711347};\\\", \\\"{x:1335,y:738,t:1528143711370};\\\", \\\"{x:1335,y:737,t:1528143711378};\\\", \\\"{x:1335,y:736,t:1528143711395};\\\", \\\"{x:1335,y:734,t:1528143711407};\\\", \\\"{x:1335,y:733,t:1528143711424};\\\", \\\"{x:1335,y:732,t:1528143711441};\\\", \\\"{x:1335,y:731,t:1528143711457};\\\", \\\"{x:1336,y:730,t:1528143711474};\\\", \\\"{x:1336,y:729,t:1528143711547};\\\", \\\"{x:1337,y:729,t:1528143711556};\\\", \\\"{x:1337,y:728,t:1528143711573};\\\", \\\"{x:1338,y:727,t:1528143711591};\\\", \\\"{x:1338,y:719,t:1528143711607};\\\", \\\"{x:1339,y:716,t:1528143711624};\\\", \\\"{x:1340,y:713,t:1528143711641};\\\", \\\"{x:1341,y:706,t:1528143711657};\\\", \\\"{x:1342,y:701,t:1528143711674};\\\", \\\"{x:1343,y:695,t:1528143711691};\\\", \\\"{x:1344,y:691,t:1528143711706};\\\", \\\"{x:1344,y:688,t:1528143711723};\\\", \\\"{x:1345,y:686,t:1528143711741};\\\", \\\"{x:1345,y:683,t:1528143711757};\\\", \\\"{x:1345,y:681,t:1528143711774};\\\", \\\"{x:1345,y:676,t:1528143711790};\\\", \\\"{x:1345,y:673,t:1528143711808};\\\", \\\"{x:1346,y:669,t:1528143711823};\\\", \\\"{x:1346,y:663,t:1528143711841};\\\", \\\"{x:1346,y:660,t:1528143711858};\\\", \\\"{x:1346,y:658,t:1528143711874};\\\", \\\"{x:1346,y:652,t:1528143711890};\\\", \\\"{x:1346,y:650,t:1528143711908};\\\", \\\"{x:1346,y:649,t:1528143711924};\\\", \\\"{x:1346,y:648,t:1528143711941};\\\", \\\"{x:1347,y:648,t:1528143711958};\\\", \\\"{x:1348,y:648,t:1528143712162};\\\", \\\"{x:1349,y:648,t:1528143712194};\\\", \\\"{x:1349,y:649,t:1528143712207};\\\", \\\"{x:1349,y:654,t:1528143712225};\\\", \\\"{x:1349,y:656,t:1528143712240};\\\", \\\"{x:1349,y:662,t:1528143712257};\\\", \\\"{x:1348,y:670,t:1528143712274};\\\", \\\"{x:1347,y:675,t:1528143712290};\\\", \\\"{x:1346,y:681,t:1528143712308};\\\", \\\"{x:1343,y:688,t:1528143712324};\\\", \\\"{x:1341,y:696,t:1528143712340};\\\", \\\"{x:1336,y:710,t:1528143712358};\\\", \\\"{x:1332,y:720,t:1528143712375};\\\", \\\"{x:1330,y:731,t:1528143712391};\\\", \\\"{x:1325,y:740,t:1528143712408};\\\", \\\"{x:1323,y:746,t:1528143712424};\\\", \\\"{x:1319,y:756,t:1528143712441};\\\", \\\"{x:1314,y:765,t:1528143712458};\\\", \\\"{x:1307,y:780,t:1528143712475};\\\", \\\"{x:1305,y:787,t:1528143712491};\\\", \\\"{x:1301,y:795,t:1528143712508};\\\", \\\"{x:1297,y:804,t:1528143712525};\\\", \\\"{x:1291,y:814,t:1528143712541};\\\", \\\"{x:1286,y:822,t:1528143712558};\\\", \\\"{x:1282,y:830,t:1528143712575};\\\", \\\"{x:1277,y:835,t:1528143712591};\\\", \\\"{x:1273,y:840,t:1528143712607};\\\", \\\"{x:1269,y:845,t:1528143712624};\\\", \\\"{x:1265,y:849,t:1528143712641};\\\", \\\"{x:1260,y:853,t:1528143712658};\\\", \\\"{x:1254,y:861,t:1528143712675};\\\", \\\"{x:1250,y:865,t:1528143712692};\\\", \\\"{x:1246,y:870,t:1528143712708};\\\", \\\"{x:1239,y:878,t:1528143712725};\\\", \\\"{x:1234,y:884,t:1528143712742};\\\", \\\"{x:1230,y:889,t:1528143712758};\\\", \\\"{x:1228,y:893,t:1528143712775};\\\", \\\"{x:1225,y:895,t:1528143712792};\\\", \\\"{x:1222,y:898,t:1528143712808};\\\", \\\"{x:1221,y:901,t:1528143712825};\\\", \\\"{x:1218,y:905,t:1528143712843};\\\", \\\"{x:1217,y:906,t:1528143712858};\\\", \\\"{x:1215,y:910,t:1528143712875};\\\", \\\"{x:1213,y:914,t:1528143712892};\\\", \\\"{x:1211,y:916,t:1528143712909};\\\", \\\"{x:1211,y:918,t:1528143712924};\\\", \\\"{x:1211,y:919,t:1528143712941};\\\", \\\"{x:1211,y:918,t:1528143713210};\\\", \\\"{x:1211,y:913,t:1528143713226};\\\", \\\"{x:1218,y:899,t:1528143713242};\\\", \\\"{x:1238,y:871,t:1528143713258};\\\", \\\"{x:1253,y:850,t:1528143713275};\\\", \\\"{x:1267,y:832,t:1528143713292};\\\", \\\"{x:1279,y:818,t:1528143713309};\\\", \\\"{x:1288,y:808,t:1528143713325};\\\", \\\"{x:1298,y:799,t:1528143713341};\\\", \\\"{x:1308,y:790,t:1528143713359};\\\", \\\"{x:1320,y:779,t:1528143713375};\\\", \\\"{x:1330,y:766,t:1528143713392};\\\", \\\"{x:1335,y:755,t:1528143713409};\\\", \\\"{x:1341,y:744,t:1528143713425};\\\", \\\"{x:1343,y:735,t:1528143713442};\\\", \\\"{x:1343,y:726,t:1528143713458};\\\", \\\"{x:1344,y:719,t:1528143713475};\\\", \\\"{x:1344,y:714,t:1528143713492};\\\", \\\"{x:1346,y:709,t:1528143713509};\\\", \\\"{x:1347,y:702,t:1528143713526};\\\", \\\"{x:1349,y:691,t:1528143713542};\\\", \\\"{x:1350,y:684,t:1528143713559};\\\", \\\"{x:1350,y:680,t:1528143713576};\\\", \\\"{x:1351,y:677,t:1528143713592};\\\", \\\"{x:1351,y:675,t:1528143713608};\\\", \\\"{x:1353,y:668,t:1528143713626};\\\", \\\"{x:1354,y:664,t:1528143713642};\\\", \\\"{x:1357,y:658,t:1528143713659};\\\", \\\"{x:1358,y:654,t:1528143713676};\\\", \\\"{x:1358,y:651,t:1528143713692};\\\", \\\"{x:1360,y:650,t:1528143713709};\\\", \\\"{x:1360,y:649,t:1528143713730};\\\", \\\"{x:1360,y:651,t:1528143713827};\\\", \\\"{x:1363,y:656,t:1528143713842};\\\", \\\"{x:1371,y:676,t:1528143713859};\\\", \\\"{x:1380,y:693,t:1528143713876};\\\", \\\"{x:1386,y:709,t:1528143713892};\\\", \\\"{x:1393,y:727,t:1528143713909};\\\", \\\"{x:1398,y:745,t:1528143713926};\\\", \\\"{x:1405,y:769,t:1528143713942};\\\", \\\"{x:1417,y:798,t:1528143713959};\\\", \\\"{x:1426,y:819,t:1528143713976};\\\", \\\"{x:1434,y:831,t:1528143713993};\\\", \\\"{x:1442,y:844,t:1528143714008};\\\", \\\"{x:1447,y:856,t:1528143714026};\\\", \\\"{x:1451,y:864,t:1528143714042};\\\", \\\"{x:1456,y:879,t:1528143714059};\\\", \\\"{x:1460,y:892,t:1528143714076};\\\", \\\"{x:1468,y:905,t:1528143714092};\\\", \\\"{x:1474,y:919,t:1528143714109};\\\", \\\"{x:1481,y:929,t:1528143714125};\\\", \\\"{x:1485,y:933,t:1528143714143};\\\", \\\"{x:1487,y:934,t:1528143714159};\\\", \\\"{x:1487,y:935,t:1528143714175};\\\", \\\"{x:1487,y:936,t:1528143714193};\\\", \\\"{x:1484,y:936,t:1528143714323};\\\", \\\"{x:1476,y:929,t:1528143714331};\\\", \\\"{x:1467,y:923,t:1528143714343};\\\", \\\"{x:1449,y:917,t:1528143714360};\\\", \\\"{x:1437,y:907,t:1528143714376};\\\", \\\"{x:1419,y:896,t:1528143714393};\\\", \\\"{x:1412,y:891,t:1528143714409};\\\", \\\"{x:1402,y:883,t:1528143714427};\\\", \\\"{x:1390,y:874,t:1528143714443};\\\", \\\"{x:1384,y:871,t:1528143714460};\\\", \\\"{x:1380,y:869,t:1528143714476};\\\", \\\"{x:1378,y:867,t:1528143714493};\\\", \\\"{x:1376,y:866,t:1528143714510};\\\", \\\"{x:1374,y:865,t:1528143714526};\\\", \\\"{x:1373,y:864,t:1528143714547};\\\", \\\"{x:1373,y:863,t:1528143714563};\\\", \\\"{x:1373,y:861,t:1528143714579};\\\", \\\"{x:1372,y:860,t:1528143714593};\\\", \\\"{x:1372,y:858,t:1528143714610};\\\", \\\"{x:1371,y:857,t:1528143714626};\\\", \\\"{x:1370,y:853,t:1528143714642};\\\", \\\"{x:1370,y:851,t:1528143714660};\\\", \\\"{x:1370,y:847,t:1528143714677};\\\", \\\"{x:1369,y:844,t:1528143714693};\\\", \\\"{x:1365,y:836,t:1528143714710};\\\", \\\"{x:1365,y:828,t:1528143714726};\\\", \\\"{x:1360,y:818,t:1528143714743};\\\", \\\"{x:1355,y:806,t:1528143714761};\\\", \\\"{x:1350,y:794,t:1528143714776};\\\", \\\"{x:1341,y:780,t:1528143714792};\\\", \\\"{x:1336,y:766,t:1528143714809};\\\", \\\"{x:1333,y:755,t:1528143714825};\\\", \\\"{x:1331,y:743,t:1528143714842};\\\", \\\"{x:1331,y:734,t:1528143714860};\\\", \\\"{x:1331,y:720,t:1528143714877};\\\", \\\"{x:1331,y:706,t:1528143714892};\\\", \\\"{x:1331,y:699,t:1528143714910};\\\", \\\"{x:1331,y:697,t:1528143714927};\\\", \\\"{x:1331,y:695,t:1528143714943};\\\", \\\"{x:1331,y:694,t:1528143714959};\\\", \\\"{x:1332,y:694,t:1528143715099};\\\", \\\"{x:1333,y:695,t:1528143715110};\\\", \\\"{x:1335,y:700,t:1528143715127};\\\", \\\"{x:1336,y:702,t:1528143715143};\\\", \\\"{x:1336,y:703,t:1528143715160};\\\", \\\"{x:1338,y:704,t:1528143715177};\\\", \\\"{x:1338,y:705,t:1528143715715};\\\", \\\"{x:1339,y:705,t:1528143715738};\\\", \\\"{x:1340,y:707,t:1528143715762};\\\", \\\"{x:1341,y:709,t:1528143715777};\\\", \\\"{x:1343,y:710,t:1528143715794};\\\", \\\"{x:1344,y:712,t:1528143715810};\\\", \\\"{x:1345,y:713,t:1528143715842};\\\", \\\"{x:1346,y:714,t:1528143715883};\\\", \\\"{x:1346,y:713,t:1528143716275};\\\", \\\"{x:1346,y:712,t:1528143717233};\\\", \\\"{x:1346,y:710,t:1528143717378};\\\", \\\"{x:1346,y:712,t:1528143720510};\\\", \\\"{x:1345,y:718,t:1528143720519};\\\", \\\"{x:1344,y:723,t:1528143720534};\\\", \\\"{x:1344,y:727,t:1528143720550};\\\", \\\"{x:1343,y:731,t:1528143720568};\\\", \\\"{x:1343,y:735,t:1528143720584};\\\", \\\"{x:1343,y:742,t:1528143720600};\\\", \\\"{x:1343,y:748,t:1528143720617};\\\", \\\"{x:1343,y:755,t:1528143720635};\\\", \\\"{x:1343,y:763,t:1528143720652};\\\", \\\"{x:1343,y:771,t:1528143720668};\\\", \\\"{x:1343,y:778,t:1528143720685};\\\", \\\"{x:1343,y:788,t:1528143720701};\\\", \\\"{x:1343,y:795,t:1528143720717};\\\", \\\"{x:1343,y:804,t:1528143720733};\\\", \\\"{x:1343,y:812,t:1528143720751};\\\", \\\"{x:1343,y:821,t:1528143720767};\\\", \\\"{x:1343,y:829,t:1528143720784};\\\", \\\"{x:1343,y:839,t:1528143720801};\\\", \\\"{x:1343,y:849,t:1528143720817};\\\", \\\"{x:1343,y:857,t:1528143720834};\\\", \\\"{x:1343,y:863,t:1528143720851};\\\", \\\"{x:1343,y:872,t:1528143720867};\\\", \\\"{x:1343,y:880,t:1528143720884};\\\", \\\"{x:1345,y:899,t:1528143720902};\\\", \\\"{x:1347,y:909,t:1528143720918};\\\", \\\"{x:1349,y:915,t:1528143720935};\\\", \\\"{x:1349,y:919,t:1528143720951};\\\", \\\"{x:1349,y:922,t:1528143720968};\\\", \\\"{x:1350,y:924,t:1528143720984};\\\", \\\"{x:1350,y:918,t:1528143722142};\\\", \\\"{x:1350,y:910,t:1528143722153};\\\", \\\"{x:1350,y:896,t:1528143722168};\\\", \\\"{x:1349,y:880,t:1528143722185};\\\", \\\"{x:1344,y:859,t:1528143722202};\\\", \\\"{x:1337,y:840,t:1528143722218};\\\", \\\"{x:1331,y:818,t:1528143722235};\\\", \\\"{x:1321,y:800,t:1528143722252};\\\", \\\"{x:1311,y:782,t:1528143722268};\\\", \\\"{x:1300,y:757,t:1528143722285};\\\", \\\"{x:1298,y:744,t:1528143722302};\\\", \\\"{x:1297,y:736,t:1528143722318};\\\", \\\"{x:1297,y:730,t:1528143722335};\\\", \\\"{x:1297,y:727,t:1528143722352};\\\", \\\"{x:1297,y:723,t:1528143722368};\\\", \\\"{x:1297,y:721,t:1528143722385};\\\", \\\"{x:1299,y:718,t:1528143722402};\\\", \\\"{x:1300,y:716,t:1528143722419};\\\", \\\"{x:1306,y:712,t:1528143722436};\\\", \\\"{x:1313,y:708,t:1528143722452};\\\", \\\"{x:1323,y:703,t:1528143722469};\\\", \\\"{x:1327,y:700,t:1528143722485};\\\", \\\"{x:1328,y:699,t:1528143722502};\\\", \\\"{x:1329,y:699,t:1528143722519};\\\", \\\"{x:1331,y:699,t:1528143722678};\\\", \\\"{x:1333,y:702,t:1528143722686};\\\", \\\"{x:1340,y:707,t:1528143722702};\\\", \\\"{x:1348,y:712,t:1528143722719};\\\", \\\"{x:1353,y:716,t:1528143722735};\\\", \\\"{x:1355,y:716,t:1528143722752};\\\", \\\"{x:1353,y:716,t:1528143723070};\\\", \\\"{x:1349,y:715,t:1528143723087};\\\", \\\"{x:1347,y:715,t:1528143723102};\\\", \\\"{x:1346,y:715,t:1528143723286};\\\", \\\"{x:1345,y:716,t:1528143723943};\\\", \\\"{x:1339,y:725,t:1528143723954};\\\", \\\"{x:1327,y:746,t:1528143723971};\\\", \\\"{x:1311,y:762,t:1528143723987};\\\", \\\"{x:1297,y:779,t:1528143724004};\\\", \\\"{x:1287,y:791,t:1528143724021};\\\", \\\"{x:1280,y:801,t:1528143724037};\\\", \\\"{x:1269,y:816,t:1528143724053};\\\", \\\"{x:1265,y:824,t:1528143724071};\\\", \\\"{x:1261,y:833,t:1528143724087};\\\", \\\"{x:1256,y:841,t:1528143724104};\\\", \\\"{x:1254,y:847,t:1528143724120};\\\", \\\"{x:1252,y:851,t:1528143724137};\\\", \\\"{x:1251,y:855,t:1528143724154};\\\", \\\"{x:1250,y:857,t:1528143724171};\\\", \\\"{x:1250,y:858,t:1528143724188};\\\", \\\"{x:1250,y:861,t:1528143724204};\\\", \\\"{x:1249,y:863,t:1528143724221};\\\", \\\"{x:1249,y:864,t:1528143724237};\\\", \\\"{x:1249,y:866,t:1528143724254};\\\", \\\"{x:1248,y:867,t:1528143724271};\\\", \\\"{x:1248,y:869,t:1528143724294};\\\", \\\"{x:1248,y:871,t:1528143724318};\\\", \\\"{x:1248,y:873,t:1528143724326};\\\", \\\"{x:1247,y:873,t:1528143724337};\\\", \\\"{x:1247,y:874,t:1528143724353};\\\", \\\"{x:1247,y:876,t:1528143724371};\\\", \\\"{x:1246,y:879,t:1528143724388};\\\", \\\"{x:1246,y:882,t:1528143724404};\\\", \\\"{x:1246,y:884,t:1528143724420};\\\", \\\"{x:1246,y:889,t:1528143724437};\\\", \\\"{x:1245,y:891,t:1528143724453};\\\", \\\"{x:1245,y:892,t:1528143724477};\\\", \\\"{x:1245,y:893,t:1528143724487};\\\", \\\"{x:1245,y:894,t:1528143724504};\\\", \\\"{x:1244,y:895,t:1528143724520};\\\", \\\"{x:1244,y:896,t:1528143724639};\\\", \\\"{x:1244,y:897,t:1528143724662};\\\", \\\"{x:1244,y:898,t:1528143724694};\\\", \\\"{x:1244,y:899,t:1528143724704};\\\", \\\"{x:1244,y:900,t:1528143724720};\\\", \\\"{x:1244,y:901,t:1528143724737};\\\", \\\"{x:1244,y:902,t:1528143724754};\\\", \\\"{x:1244,y:903,t:1528143724789};\\\", \\\"{x:1245,y:904,t:1528143725038};\\\", \\\"{x:1245,y:905,t:1528143725094};\\\", \\\"{x:1246,y:905,t:1528143725105};\\\", \\\"{x:1247,y:905,t:1528143726119};\\\", \\\"{x:1250,y:898,t:1528143726758};\\\", \\\"{x:1255,y:893,t:1528143726773};\\\", \\\"{x:1269,y:884,t:1528143726789};\\\", \\\"{x:1294,y:871,t:1528143726805};\\\", \\\"{x:1307,y:865,t:1528143726823};\\\", \\\"{x:1318,y:861,t:1528143726839};\\\", \\\"{x:1328,y:859,t:1528143726856};\\\", \\\"{x:1341,y:857,t:1528143726873};\\\", \\\"{x:1350,y:855,t:1528143726893};\\\", \\\"{x:1354,y:854,t:1528143726906};\\\", \\\"{x:1357,y:854,t:1528143726922};\\\", \\\"{x:1359,y:852,t:1528143726939};\\\", \\\"{x:1361,y:852,t:1528143726955};\\\", \\\"{x:1365,y:849,t:1528143726972};\\\", \\\"{x:1378,y:843,t:1528143726988};\\\", \\\"{x:1388,y:840,t:1528143727005};\\\", \\\"{x:1395,y:837,t:1528143727022};\\\", \\\"{x:1399,y:835,t:1528143727039};\\\", \\\"{x:1398,y:835,t:1528143727309};\\\", \\\"{x:1396,y:836,t:1528143727323};\\\", \\\"{x:1391,y:839,t:1528143727339};\\\", \\\"{x:1389,y:840,t:1528143727357};\\\", \\\"{x:1388,y:841,t:1528143727373};\\\", \\\"{x:1387,y:844,t:1528143727550};\\\", \\\"{x:1386,y:847,t:1528143727557};\\\", \\\"{x:1384,y:850,t:1528143727573};\\\", \\\"{x:1382,y:858,t:1528143727590};\\\", \\\"{x:1379,y:864,t:1528143727606};\\\", \\\"{x:1378,y:867,t:1528143727623};\\\", \\\"{x:1376,y:871,t:1528143727640};\\\", \\\"{x:1376,y:873,t:1528143727657};\\\", \\\"{x:1373,y:877,t:1528143727673};\\\", \\\"{x:1373,y:879,t:1528143727690};\\\", \\\"{x:1372,y:880,t:1528143727707};\\\", \\\"{x:1372,y:881,t:1528143727723};\\\", \\\"{x:1370,y:883,t:1528143727740};\\\", \\\"{x:1369,y:884,t:1528143727757};\\\", \\\"{x:1367,y:888,t:1528143727773};\\\", \\\"{x:1365,y:890,t:1528143727790};\\\", \\\"{x:1363,y:892,t:1528143727806};\\\", \\\"{x:1362,y:893,t:1528143727824};\\\", \\\"{x:1361,y:895,t:1528143727839};\\\", \\\"{x:1359,y:897,t:1528143727857};\\\", \\\"{x:1357,y:899,t:1528143727874};\\\", \\\"{x:1355,y:901,t:1528143727890};\\\", \\\"{x:1352,y:903,t:1528143727906};\\\", \\\"{x:1349,y:906,t:1528143727924};\\\", \\\"{x:1347,y:907,t:1528143727940};\\\", \\\"{x:1346,y:909,t:1528143727957};\\\", \\\"{x:1343,y:912,t:1528143727974};\\\", \\\"{x:1342,y:913,t:1528143728006};\\\", \\\"{x:1342,y:912,t:1528143728190};\\\", \\\"{x:1343,y:904,t:1528143728207};\\\", \\\"{x:1344,y:892,t:1528143728224};\\\", \\\"{x:1345,y:886,t:1528143728241};\\\", \\\"{x:1347,y:878,t:1528143728257};\\\", \\\"{x:1349,y:873,t:1528143728273};\\\", \\\"{x:1350,y:870,t:1528143728291};\\\", \\\"{x:1351,y:868,t:1528143728307};\\\", \\\"{x:1351,y:867,t:1528143728323};\\\", \\\"{x:1353,y:863,t:1528143728341};\\\", \\\"{x:1355,y:861,t:1528143728357};\\\", \\\"{x:1360,y:854,t:1528143728374};\\\", \\\"{x:1360,y:851,t:1528143728390};\\\", \\\"{x:1362,y:848,t:1528143728407};\\\", \\\"{x:1365,y:845,t:1528143728424};\\\", \\\"{x:1367,y:843,t:1528143728442};\\\", \\\"{x:1367,y:840,t:1528143728458};\\\", \\\"{x:1369,y:838,t:1528143728474};\\\", \\\"{x:1370,y:836,t:1528143728490};\\\", \\\"{x:1371,y:835,t:1528143728507};\\\", \\\"{x:1373,y:833,t:1528143728523};\\\", \\\"{x:1373,y:832,t:1528143728540};\\\", \\\"{x:1373,y:830,t:1528143728565};\\\", \\\"{x:1374,y:830,t:1528143728847};\\\", \\\"{x:1374,y:829,t:1528143729038};\\\", \\\"{x:1375,y:829,t:1528143729364};\\\", \\\"{x:1375,y:827,t:1528143729374};\\\", \\\"{x:1375,y:824,t:1528143729390};\\\", \\\"{x:1375,y:822,t:1528143729408};\\\", \\\"{x:1375,y:820,t:1528143729424};\\\", \\\"{x:1376,y:823,t:1528143729670};\\\", \\\"{x:1376,y:826,t:1528143729678};\\\", \\\"{x:1376,y:827,t:1528143729691};\\\", \\\"{x:1379,y:833,t:1528143729708};\\\", \\\"{x:1379,y:834,t:1528143729725};\\\", \\\"{x:1381,y:838,t:1528143729742};\\\", \\\"{x:1382,y:839,t:1528143729766};\\\", \\\"{x:1382,y:840,t:1528143729775};\\\", \\\"{x:1383,y:841,t:1528143729791};\\\", \\\"{x:1384,y:844,t:1528143729808};\\\", \\\"{x:1386,y:845,t:1528143729825};\\\", \\\"{x:1386,y:846,t:1528143729842};\\\", \\\"{x:1387,y:847,t:1528143729859};\\\", \\\"{x:1388,y:847,t:1528143729875};\\\", \\\"{x:1390,y:848,t:1528143729892};\\\", \\\"{x:1391,y:849,t:1528143729908};\\\", \\\"{x:1397,y:853,t:1528143729925};\\\", \\\"{x:1400,y:856,t:1528143729942};\\\", \\\"{x:1404,y:859,t:1528143729959};\\\", \\\"{x:1408,y:863,t:1528143729975};\\\", \\\"{x:1411,y:865,t:1528143729992};\\\", \\\"{x:1413,y:866,t:1528143730009};\\\", \\\"{x:1415,y:869,t:1528143730025};\\\", \\\"{x:1416,y:872,t:1528143730042};\\\", \\\"{x:1418,y:877,t:1528143730059};\\\", \\\"{x:1420,y:878,t:1528143730075};\\\", \\\"{x:1422,y:881,t:1528143730092};\\\", \\\"{x:1424,y:884,t:1528143730110};\\\", \\\"{x:1424,y:885,t:1528143730125};\\\", \\\"{x:1425,y:886,t:1528143730142};\\\", \\\"{x:1425,y:888,t:1528143730159};\\\", \\\"{x:1425,y:889,t:1528143730175};\\\", \\\"{x:1426,y:890,t:1528143730193};\\\", \\\"{x:1427,y:892,t:1528143730208};\\\", \\\"{x:1428,y:893,t:1528143730225};\\\", \\\"{x:1432,y:896,t:1528143730242};\\\", \\\"{x:1447,y:902,t:1528143730259};\\\", \\\"{x:1457,y:902,t:1528143730275};\\\", \\\"{x:1467,y:900,t:1528143730291};\\\", \\\"{x:1477,y:892,t:1528143730308};\\\", \\\"{x:1486,y:875,t:1528143730324};\\\", \\\"{x:1487,y:867,t:1528143730342};\\\", \\\"{x:1487,y:857,t:1528143730358};\\\", \\\"{x:1487,y:847,t:1528143730375};\\\", \\\"{x:1485,y:839,t:1528143730391};\\\", \\\"{x:1485,y:833,t:1528143730408};\\\", \\\"{x:1485,y:825,t:1528143730425};\\\", \\\"{x:1485,y:819,t:1528143730441};\\\", \\\"{x:1485,y:814,t:1528143730459};\\\", \\\"{x:1485,y:810,t:1528143730476};\\\", \\\"{x:1485,y:805,t:1528143730492};\\\", \\\"{x:1485,y:803,t:1528143730508};\\\", \\\"{x:1484,y:799,t:1528143730525};\\\", \\\"{x:1484,y:797,t:1528143730542};\\\", \\\"{x:1484,y:795,t:1528143730559};\\\", \\\"{x:1484,y:791,t:1528143730576};\\\", \\\"{x:1484,y:786,t:1528143730592};\\\", \\\"{x:1484,y:784,t:1528143730609};\\\", \\\"{x:1484,y:781,t:1528143730626};\\\", \\\"{x:1484,y:778,t:1528143730642};\\\", \\\"{x:1483,y:776,t:1528143730659};\\\", \\\"{x:1483,y:775,t:1528143730676};\\\", \\\"{x:1482,y:776,t:1528143731014};\\\", \\\"{x:1482,y:779,t:1528143731025};\\\", \\\"{x:1480,y:783,t:1528143731044};\\\", \\\"{x:1480,y:785,t:1528143731118};\\\", \\\"{x:1480,y:787,t:1528143731127};\\\", \\\"{x:1477,y:794,t:1528143731144};\\\", \\\"{x:1475,y:797,t:1528143731158};\\\", \\\"{x:1472,y:803,t:1528143731176};\\\", \\\"{x:1469,y:810,t:1528143731193};\\\", \\\"{x:1465,y:819,t:1528143731209};\\\", \\\"{x:1462,y:827,t:1528143731227};\\\", \\\"{x:1458,y:834,t:1528143731243};\\\", \\\"{x:1454,y:844,t:1528143731259};\\\", \\\"{x:1451,y:852,t:1528143731276};\\\", \\\"{x:1445,y:866,t:1528143731293};\\\", \\\"{x:1444,y:869,t:1528143731309};\\\", \\\"{x:1440,y:878,t:1528143731326};\\\", \\\"{x:1438,y:882,t:1528143731343};\\\", \\\"{x:1435,y:887,t:1528143731360};\\\", \\\"{x:1432,y:892,t:1528143731376};\\\", \\\"{x:1429,y:896,t:1528143731393};\\\", \\\"{x:1426,y:900,t:1528143731410};\\\", \\\"{x:1425,y:904,t:1528143731426};\\\", \\\"{x:1422,y:908,t:1528143731443};\\\", \\\"{x:1421,y:910,t:1528143731460};\\\", \\\"{x:1420,y:912,t:1528143731477};\\\", \\\"{x:1420,y:914,t:1528143731493};\\\", \\\"{x:1419,y:917,t:1528143731510};\\\", \\\"{x:1418,y:918,t:1528143731526};\\\", \\\"{x:1418,y:919,t:1528143731694};\\\", \\\"{x:1417,y:919,t:1528143731710};\\\", \\\"{x:1416,y:916,t:1528143731727};\\\", \\\"{x:1416,y:910,t:1528143731744};\\\", \\\"{x:1416,y:903,t:1528143731760};\\\", \\\"{x:1417,y:896,t:1528143731777};\\\", \\\"{x:1421,y:888,t:1528143731793};\\\", \\\"{x:1427,y:880,t:1528143731810};\\\", \\\"{x:1434,y:872,t:1528143731827};\\\", \\\"{x:1443,y:860,t:1528143731843};\\\", \\\"{x:1452,y:851,t:1528143731861};\\\", \\\"{x:1461,y:838,t:1528143731878};\\\", \\\"{x:1472,y:824,t:1528143731893};\\\", \\\"{x:1483,y:809,t:1528143731910};\\\", \\\"{x:1487,y:800,t:1528143731927};\\\", \\\"{x:1488,y:794,t:1528143731943};\\\", \\\"{x:1490,y:788,t:1528143731960};\\\", \\\"{x:1492,y:783,t:1528143731977};\\\", \\\"{x:1492,y:782,t:1528143731993};\\\", \\\"{x:1494,y:779,t:1528143732010};\\\", \\\"{x:1494,y:778,t:1528143732027};\\\", \\\"{x:1494,y:777,t:1528143732043};\\\", \\\"{x:1494,y:776,t:1528143732061};\\\", \\\"{x:1494,y:775,t:1528143732406};\\\", \\\"{x:1492,y:775,t:1528143732598};\\\", \\\"{x:1492,y:778,t:1528143732758};\\\", \\\"{x:1492,y:781,t:1528143732766};\\\", \\\"{x:1492,y:784,t:1528143732777};\\\", \\\"{x:1492,y:788,t:1528143732794};\\\", \\\"{x:1492,y:789,t:1528143732811};\\\", \\\"{x:1492,y:791,t:1528143732828};\\\", \\\"{x:1492,y:794,t:1528143732844};\\\", \\\"{x:1493,y:799,t:1528143732862};\\\", \\\"{x:1494,y:802,t:1528143732877};\\\", \\\"{x:1495,y:805,t:1528143732894};\\\", \\\"{x:1496,y:808,t:1528143732912};\\\", \\\"{x:1496,y:812,t:1528143732927};\\\", \\\"{x:1498,y:814,t:1528143732944};\\\", \\\"{x:1499,y:819,t:1528143732961};\\\", \\\"{x:1500,y:823,t:1528143732977};\\\", \\\"{x:1502,y:828,t:1528143732994};\\\", \\\"{x:1503,y:834,t:1528143733011};\\\", \\\"{x:1507,y:843,t:1528143733027};\\\", \\\"{x:1520,y:869,t:1528143733045};\\\", \\\"{x:1538,y:896,t:1528143733061};\\\", \\\"{x:1551,y:910,t:1528143733078};\\\", \\\"{x:1557,y:914,t:1528143733095};\\\", \\\"{x:1560,y:917,t:1528143733112};\\\", \\\"{x:1561,y:918,t:1528143733128};\\\", \\\"{x:1563,y:920,t:1528143733144};\\\", \\\"{x:1563,y:921,t:1528143733161};\\\", \\\"{x:1563,y:922,t:1528143733177};\\\", \\\"{x:1564,y:924,t:1528143733194};\\\", \\\"{x:1565,y:924,t:1528143733270};\\\", \\\"{x:1565,y:922,t:1528143733342};\\\", \\\"{x:1561,y:915,t:1528143733350};\\\", \\\"{x:1555,y:906,t:1528143733361};\\\", \\\"{x:1538,y:883,t:1528143733378};\\\", \\\"{x:1521,y:866,t:1528143733394};\\\", \\\"{x:1510,y:855,t:1528143733411};\\\", \\\"{x:1507,y:850,t:1528143733428};\\\", \\\"{x:1503,y:844,t:1528143733444};\\\", \\\"{x:1499,y:833,t:1528143733462};\\\", \\\"{x:1498,y:826,t:1528143733478};\\\", \\\"{x:1497,y:821,t:1528143733495};\\\", \\\"{x:1497,y:815,t:1528143733511};\\\", \\\"{x:1497,y:809,t:1528143733528};\\\", \\\"{x:1497,y:803,t:1528143733545};\\\", \\\"{x:1500,y:797,t:1528143733561};\\\", \\\"{x:1503,y:791,t:1528143733578};\\\", \\\"{x:1504,y:786,t:1528143733595};\\\", \\\"{x:1507,y:783,t:1528143733611};\\\", \\\"{x:1507,y:779,t:1528143733628};\\\", \\\"{x:1508,y:777,t:1528143733645};\\\", \\\"{x:1509,y:775,t:1528143733662};\\\", \\\"{x:1511,y:771,t:1528143733678};\\\", \\\"{x:1512,y:769,t:1528143733695};\\\", \\\"{x:1513,y:765,t:1528143733711};\\\", \\\"{x:1514,y:762,t:1528143733728};\\\", \\\"{x:1515,y:760,t:1528143733745};\\\", \\\"{x:1515,y:759,t:1528143733761};\\\", \\\"{x:1517,y:756,t:1528143733778};\\\", \\\"{x:1517,y:755,t:1528143733795};\\\", \\\"{x:1517,y:752,t:1528143733811};\\\", \\\"{x:1517,y:749,t:1528143733828};\\\", \\\"{x:1517,y:746,t:1528143733845};\\\", \\\"{x:1516,y:742,t:1528143733861};\\\", \\\"{x:1514,y:739,t:1528143733879};\\\", \\\"{x:1513,y:732,t:1528143733895};\\\", \\\"{x:1512,y:729,t:1528143733912};\\\", \\\"{x:1512,y:727,t:1528143733928};\\\", \\\"{x:1512,y:725,t:1528143733945};\\\", \\\"{x:1510,y:722,t:1528143733962};\\\", \\\"{x:1510,y:720,t:1528143733979};\\\", \\\"{x:1509,y:719,t:1528143733995};\\\", \\\"{x:1509,y:718,t:1528143734012};\\\", \\\"{x:1507,y:719,t:1528143734246};\\\", \\\"{x:1501,y:731,t:1528143734262};\\\", \\\"{x:1496,y:743,t:1528143734279};\\\", \\\"{x:1490,y:758,t:1528143734295};\\\", \\\"{x:1483,y:772,t:1528143734312};\\\", \\\"{x:1478,y:784,t:1528143734329};\\\", \\\"{x:1473,y:796,t:1528143734345};\\\", \\\"{x:1469,y:806,t:1528143734362};\\\", \\\"{x:1463,y:819,t:1528143734379};\\\", \\\"{x:1458,y:832,t:1528143734395};\\\", \\\"{x:1450,y:848,t:1528143734412};\\\", \\\"{x:1437,y:869,t:1528143734430};\\\", \\\"{x:1432,y:878,t:1528143734446};\\\", \\\"{x:1428,y:883,t:1528143734462};\\\", \\\"{x:1424,y:888,t:1528143734480};\\\", \\\"{x:1420,y:893,t:1528143734495};\\\", \\\"{x:1417,y:899,t:1528143734512};\\\", \\\"{x:1414,y:904,t:1528143734529};\\\", \\\"{x:1413,y:906,t:1528143734545};\\\", \\\"{x:1410,y:910,t:1528143734562};\\\", \\\"{x:1407,y:912,t:1528143734580};\\\", \\\"{x:1406,y:914,t:1528143734595};\\\", \\\"{x:1406,y:915,t:1528143734612};\\\", \\\"{x:1405,y:917,t:1528143734629};\\\", \\\"{x:1403,y:916,t:1528143734957};\\\", \\\"{x:1403,y:914,t:1528143734973};\\\", \\\"{x:1402,y:912,t:1528143734981};\\\", \\\"{x:1402,y:910,t:1528143734996};\\\", \\\"{x:1402,y:907,t:1528143735012};\\\", \\\"{x:1402,y:903,t:1528143735028};\\\", \\\"{x:1402,y:899,t:1528143735045};\\\", \\\"{x:1402,y:896,t:1528143735062};\\\", \\\"{x:1402,y:891,t:1528143735079};\\\", \\\"{x:1402,y:885,t:1528143735096};\\\", \\\"{x:1405,y:879,t:1528143735112};\\\", \\\"{x:1410,y:867,t:1528143735129};\\\", \\\"{x:1415,y:856,t:1528143735146};\\\", \\\"{x:1416,y:847,t:1528143735161};\\\", \\\"{x:1424,y:834,t:1528143735179};\\\", \\\"{x:1429,y:821,t:1528143735196};\\\", \\\"{x:1435,y:809,t:1528143735211};\\\", \\\"{x:1446,y:791,t:1528143735229};\\\", \\\"{x:1453,y:780,t:1528143735245};\\\", \\\"{x:1462,y:772,t:1528143735261};\\\", \\\"{x:1468,y:766,t:1528143735279};\\\", \\\"{x:1471,y:763,t:1528143735295};\\\", \\\"{x:1476,y:758,t:1528143735313};\\\", \\\"{x:1478,y:755,t:1528143735329};\\\", \\\"{x:1480,y:752,t:1528143735346};\\\", \\\"{x:1481,y:749,t:1528143735363};\\\", \\\"{x:1482,y:748,t:1528143735379};\\\", \\\"{x:1483,y:748,t:1528143735396};\\\", \\\"{x:1483,y:747,t:1528143735581};\\\", \\\"{x:1477,y:746,t:1528143736277};\\\", \\\"{x:1450,y:746,t:1528143736285};\\\", \\\"{x:1420,y:746,t:1528143736297};\\\", \\\"{x:1385,y:746,t:1528143736312};\\\", \\\"{x:1355,y:745,t:1528143736329};\\\", \\\"{x:1331,y:737,t:1528143736347};\\\", \\\"{x:1255,y:680,t:1528143736362};\\\", \\\"{x:1144,y:601,t:1528143736379};\\\", \\\"{x:950,y:521,t:1528143736397};\\\", \\\"{x:801,y:480,t:1528143736413};\\\", \\\"{x:645,y:451,t:1528143736430};\\\", \\\"{x:494,y:416,t:1528143736447};\\\", \\\"{x:347,y:394,t:1528143736464};\\\", \\\"{x:246,y:387,t:1528143736481};\\\", \\\"{x:226,y:387,t:1528143736496};\\\", \\\"{x:224,y:387,t:1528143736514};\\\", \\\"{x:222,y:387,t:1528143736531};\\\", \\\"{x:226,y:387,t:1528143736547};\\\", \\\"{x:235,y:387,t:1528143736564};\\\", \\\"{x:243,y:386,t:1528143736581};\\\", \\\"{x:243,y:387,t:1528143736870};\\\", \\\"{x:243,y:391,t:1528143736881};\\\", \\\"{x:242,y:395,t:1528143736899};\\\", \\\"{x:242,y:398,t:1528143736913};\\\", \\\"{x:241,y:404,t:1528143736931};\\\", \\\"{x:241,y:413,t:1528143736948};\\\", \\\"{x:241,y:428,t:1528143736963};\\\", \\\"{x:247,y:460,t:1528143736981};\\\", \\\"{x:257,y:477,t:1528143736998};\\\", \\\"{x:266,y:488,t:1528143737015};\\\", \\\"{x:272,y:498,t:1528143737031};\\\", \\\"{x:288,y:513,t:1528143737048};\\\", \\\"{x:304,y:527,t:1528143737064};\\\", \\\"{x:320,y:536,t:1528143737081};\\\", \\\"{x:330,y:541,t:1528143737098};\\\", \\\"{x:343,y:546,t:1528143737114};\\\", \\\"{x:349,y:547,t:1528143737130};\\\", \\\"{x:357,y:547,t:1528143737148};\\\", \\\"{x:368,y:547,t:1528143737164};\\\", \\\"{x:375,y:547,t:1528143737181};\\\", \\\"{x:383,y:547,t:1528143737198};\\\", \\\"{x:394,y:544,t:1528143737214};\\\", \\\"{x:404,y:541,t:1528143737231};\\\", \\\"{x:415,y:536,t:1528143737248};\\\", \\\"{x:420,y:534,t:1528143737265};\\\", \\\"{x:423,y:531,t:1528143737280};\\\", \\\"{x:426,y:529,t:1528143737298};\\\", \\\"{x:426,y:525,t:1528143737314};\\\", \\\"{x:427,y:524,t:1528143737331};\\\", \\\"{x:427,y:522,t:1528143737347};\\\", \\\"{x:427,y:519,t:1528143737365};\\\", \\\"{x:427,y:517,t:1528143737381};\\\", \\\"{x:426,y:517,t:1528143737525};\\\", \\\"{x:425,y:517,t:1528143737550};\\\", \\\"{x:424,y:517,t:1528143737565};\\\", \\\"{x:422,y:516,t:1528143737582};\\\", \\\"{x:421,y:516,t:1528143737598};\\\", \\\"{x:420,y:515,t:1528143737670};\\\", \\\"{x:419,y:515,t:1528143737682};\\\", \\\"{x:415,y:515,t:1528143737699};\\\", \\\"{x:407,y:517,t:1528143737715};\\\", \\\"{x:386,y:521,t:1528143737732};\\\", \\\"{x:358,y:524,t:1528143737748};\\\", \\\"{x:315,y:532,t:1528143737764};\\\", \\\"{x:292,y:535,t:1528143737782};\\\", \\\"{x:279,y:536,t:1528143737797};\\\", \\\"{x:276,y:536,t:1528143737814};\\\", \\\"{x:275,y:536,t:1528143737832};\\\", \\\"{x:274,y:536,t:1528143737847};\\\", \\\"{x:272,y:536,t:1528143737886};\\\", \\\"{x:267,y:536,t:1528143737897};\\\", \\\"{x:249,y:536,t:1528143737915};\\\", \\\"{x:227,y:536,t:1528143737932};\\\", \\\"{x:201,y:536,t:1528143737949};\\\", \\\"{x:191,y:536,t:1528143737965};\\\", \\\"{x:186,y:536,t:1528143737982};\\\", \\\"{x:181,y:535,t:1528143737999};\\\", \\\"{x:178,y:534,t:1528143738015};\\\", \\\"{x:176,y:534,t:1528143738032};\\\", \\\"{x:179,y:534,t:1528143738109};\\\", \\\"{x:184,y:534,t:1528143738117};\\\", \\\"{x:189,y:535,t:1528143738132};\\\", \\\"{x:231,y:537,t:1528143738149};\\\", \\\"{x:287,y:537,t:1528143738166};\\\", \\\"{x:346,y:537,t:1528143738182};\\\", \\\"{x:393,y:537,t:1528143738199};\\\", \\\"{x:427,y:534,t:1528143738215};\\\", \\\"{x:456,y:532,t:1528143738232};\\\", \\\"{x:477,y:529,t:1528143738249};\\\", \\\"{x:494,y:528,t:1528143738264};\\\", \\\"{x:512,y:528,t:1528143738283};\\\", \\\"{x:527,y:526,t:1528143738299};\\\", \\\"{x:541,y:524,t:1528143738314};\\\", \\\"{x:552,y:523,t:1528143738331};\\\", \\\"{x:563,y:523,t:1528143738349};\\\", \\\"{x:566,y:523,t:1528143738365};\\\", \\\"{x:567,y:523,t:1528143738429};\\\", \\\"{x:569,y:523,t:1528143738446};\\\", \\\"{x:570,y:523,t:1528143738453};\\\", \\\"{x:573,y:523,t:1528143738465};\\\", \\\"{x:576,y:524,t:1528143738482};\\\", \\\"{x:579,y:524,t:1528143738499};\\\", \\\"{x:580,y:525,t:1528143738565};\\\", \\\"{x:583,y:525,t:1528143738582};\\\", \\\"{x:587,y:526,t:1528143738599};\\\", \\\"{x:590,y:527,t:1528143738615};\\\", \\\"{x:592,y:527,t:1528143738632};\\\", \\\"{x:593,y:527,t:1528143738918};\\\", \\\"{x:596,y:530,t:1528143738932};\\\", \\\"{x:620,y:538,t:1528143738950};\\\", \\\"{x:676,y:552,t:1528143738967};\\\", \\\"{x:734,y:561,t:1528143738982};\\\", \\\"{x:767,y:562,t:1528143738998};\\\", \\\"{x:782,y:562,t:1528143739016};\\\", \\\"{x:796,y:560,t:1528143739032};\\\", \\\"{x:809,y:556,t:1528143739048};\\\", \\\"{x:813,y:555,t:1528143739065};\\\", \\\"{x:814,y:553,t:1528143739082};\\\", \\\"{x:814,y:552,t:1528143739099};\\\", \\\"{x:815,y:550,t:1528143739116};\\\", \\\"{x:815,y:546,t:1528143739133};\\\", \\\"{x:815,y:544,t:1528143739149};\\\", \\\"{x:815,y:542,t:1528143739166};\\\", \\\"{x:814,y:542,t:1528143739181};\\\", \\\"{x:813,y:541,t:1528143739245};\\\", \\\"{x:813,y:539,t:1528143739279};\\\", \\\"{x:814,y:539,t:1528143739284};\\\", \\\"{x:817,y:538,t:1528143739298};\\\", \\\"{x:823,y:534,t:1528143739316};\\\", \\\"{x:826,y:534,t:1528143739333};\\\", \\\"{x:827,y:532,t:1528143739350};\\\", \\\"{x:828,y:532,t:1528143739430};\\\", \\\"{x:829,y:532,t:1528143739438};\\\", \\\"{x:830,y:532,t:1528143739581};\\\", \\\"{x:827,y:529,t:1528143739700};\\\", \\\"{x:798,y:528,t:1528143739717};\\\", \\\"{x:739,y:528,t:1528143739733};\\\", \\\"{x:656,y:528,t:1528143739750};\\\", \\\"{x:575,y:529,t:1528143739766};\\\", \\\"{x:533,y:535,t:1528143739783};\\\", \\\"{x:512,y:538,t:1528143739800};\\\", \\\"{x:510,y:538,t:1528143739816};\\\", \\\"{x:510,y:539,t:1528143739894};\\\", \\\"{x:513,y:539,t:1528143739934};\\\", \\\"{x:519,y:539,t:1528143739950};\\\", \\\"{x:533,y:540,t:1528143739967};\\\", \\\"{x:555,y:540,t:1528143739983};\\\", \\\"{x:577,y:540,t:1528143740000};\\\", \\\"{x:591,y:540,t:1528143740017};\\\", \\\"{x:596,y:540,t:1528143740033};\\\", \\\"{x:598,y:540,t:1528143740050};\\\", \\\"{x:599,y:540,t:1528143740067};\\\", \\\"{x:601,y:540,t:1528143740085};\\\", \\\"{x:603,y:539,t:1528143740100};\\\", \\\"{x:605,y:538,t:1528143740117};\\\", \\\"{x:606,y:537,t:1528143740133};\\\", \\\"{x:608,y:537,t:1528143740150};\\\", \\\"{x:608,y:536,t:1528143740206};\\\", \\\"{x:608,y:535,t:1528143740216};\\\", \\\"{x:608,y:534,t:1528143740234};\\\", \\\"{x:608,y:533,t:1528143740250};\\\", \\\"{x:608,y:532,t:1528143740267};\\\", \\\"{x:608,y:531,t:1528143740284};\\\", \\\"{x:608,y:530,t:1528143740299};\\\", \\\"{x:605,y:530,t:1528143740501};\\\", \\\"{x:597,y:536,t:1528143740517};\\\", \\\"{x:586,y:543,t:1528143740534};\\\", \\\"{x:573,y:551,t:1528143740550};\\\", \\\"{x:564,y:563,t:1528143740567};\\\", \\\"{x:558,y:578,t:1528143740584};\\\", \\\"{x:549,y:597,t:1528143740602};\\\", \\\"{x:544,y:614,t:1528143740616};\\\", \\\"{x:539,y:628,t:1528143740633};\\\", \\\"{x:536,y:634,t:1528143740650};\\\", \\\"{x:532,y:642,t:1528143740666};\\\", \\\"{x:525,y:651,t:1528143740684};\\\", \\\"{x:519,y:662,t:1528143740701};\\\", \\\"{x:516,y:669,t:1528143740718};\\\", \\\"{x:516,y:673,t:1528143740734};\\\", \\\"{x:516,y:678,t:1528143740751};\\\", \\\"{x:515,y:681,t:1528143740767};\\\", \\\"{x:515,y:683,t:1528143740784};\\\", \\\"{x:514,y:684,t:1528143740801};\\\", \\\"{x:514,y:686,t:1528143740817};\\\", \\\"{x:517,y:686,t:1528143741109};\\\", \\\"{x:523,y:686,t:1528143741117};\\\", \\\"{x:559,y:686,t:1528143741134};\\\", \\\"{x:626,y:685,t:1528143741151};\\\", \\\"{x:668,y:685,t:1528143741168};\\\", \\\"{x:689,y:683,t:1528143741184};\\\", \\\"{x:697,y:681,t:1528143741200};\\\", \\\"{x:698,y:680,t:1528143741217};\\\", \\\"{x:699,y:680,t:1528143741236};\\\" ] }, { \\\"rt\\\": 37380, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 301264, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"8182H\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-M -X -G -G -F -F -G -G -C -O -G -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:695,y:675,t:1528143742876};\\\", \\\"{x:690,y:668,t:1528143742885};\\\", \\\"{x:681,y:663,t:1528143742902};\\\", \\\"{x:670,y:656,t:1528143742919};\\\", \\\"{x:657,y:650,t:1528143742935};\\\", \\\"{x:648,y:646,t:1528143742952};\\\", \\\"{x:645,y:645,t:1528143742969};\\\", \\\"{x:644,y:645,t:1528143742985};\\\", \\\"{x:642,y:645,t:1528143743002};\\\", \\\"{x:641,y:645,t:1528143743019};\\\", \\\"{x:640,y:645,t:1528143743086};\\\", \\\"{x:639,y:645,t:1528143743109};\\\", \\\"{x:638,y:645,t:1528143743157};\\\", \\\"{x:637,y:645,t:1528143743238};\\\", \\\"{x:637,y:646,t:1528143743452};\\\", \\\"{x:637,y:647,t:1528143745822};\\\", \\\"{x:638,y:647,t:1528143745837};\\\", \\\"{x:640,y:647,t:1528143745854};\\\", \\\"{x:641,y:647,t:1528143745871};\\\", \\\"{x:642,y:647,t:1528143745901};\\\", \\\"{x:643,y:647,t:1528143745941};\\\", \\\"{x:644,y:647,t:1528143745974};\\\", \\\"{x:644,y:645,t:1528143745988};\\\", \\\"{x:644,y:644,t:1528143746005};\\\", \\\"{x:645,y:644,t:1528143746494};\\\", \\\"{x:645,y:647,t:1528143746506};\\\", \\\"{x:650,y:661,t:1528143746522};\\\", \\\"{x:655,y:672,t:1528143746539};\\\", \\\"{x:657,y:677,t:1528143746556};\\\", \\\"{x:657,y:678,t:1528143746572};\\\", \\\"{x:658,y:679,t:1528143746589};\\\", \\\"{x:659,y:680,t:1528143746605};\\\", \\\"{x:660,y:680,t:1528143746622};\\\", \\\"{x:661,y:681,t:1528143746638};\\\", \\\"{x:664,y:682,t:1528143746656};\\\", \\\"{x:665,y:683,t:1528143746672};\\\", \\\"{x:666,y:683,t:1528143746688};\\\", \\\"{x:667,y:683,t:1528143746706};\\\", \\\"{x:668,y:684,t:1528143746722};\\\", \\\"{x:668,y:685,t:1528143746822};\\\", \\\"{x:668,y:690,t:1528143746838};\\\", \\\"{x:670,y:695,t:1528143746856};\\\", \\\"{x:670,y:697,t:1528143746873};\\\", \\\"{x:670,y:699,t:1528143746889};\\\", \\\"{x:671,y:705,t:1528143746905};\\\", \\\"{x:674,y:711,t:1528143746923};\\\", \\\"{x:679,y:720,t:1528143746939};\\\", \\\"{x:686,y:729,t:1528143746955};\\\", \\\"{x:697,y:742,t:1528143746973};\\\", \\\"{x:716,y:761,t:1528143746989};\\\", \\\"{x:777,y:794,t:1528143747006};\\\", \\\"{x:844,y:815,t:1528143747022};\\\", \\\"{x:923,y:827,t:1528143747039};\\\", \\\"{x:1005,y:837,t:1528143747055};\\\", \\\"{x:1086,y:838,t:1528143747072};\\\", \\\"{x:1178,y:838,t:1528143747088};\\\", \\\"{x:1275,y:838,t:1528143747105};\\\", \\\"{x:1380,y:838,t:1528143747123};\\\", \\\"{x:1455,y:830,t:1528143747139};\\\", \\\"{x:1522,y:821,t:1528143747155};\\\", \\\"{x:1528,y:818,t:1528143747172};\\\", \\\"{x:1533,y:818,t:1528143747188};\\\", \\\"{x:1541,y:818,t:1528143747205};\\\", \\\"{x:1560,y:816,t:1528143747223};\\\", \\\"{x:1586,y:810,t:1528143747238};\\\", \\\"{x:1600,y:807,t:1528143747255};\\\", \\\"{x:1606,y:806,t:1528143747272};\\\", \\\"{x:1607,y:806,t:1528143747288};\\\", \\\"{x:1607,y:804,t:1528143747317};\\\", \\\"{x:1606,y:799,t:1528143747325};\\\", \\\"{x:1598,y:793,t:1528143747339};\\\", \\\"{x:1575,y:779,t:1528143747356};\\\", \\\"{x:1547,y:767,t:1528143747373};\\\", \\\"{x:1544,y:766,t:1528143747390};\\\", \\\"{x:1543,y:766,t:1528143747414};\\\", \\\"{x:1542,y:766,t:1528143747423};\\\", \\\"{x:1540,y:766,t:1528143747440};\\\", \\\"{x:1539,y:766,t:1528143747456};\\\", \\\"{x:1535,y:764,t:1528143747472};\\\", \\\"{x:1533,y:763,t:1528143747490};\\\", \\\"{x:1531,y:763,t:1528143747506};\\\", \\\"{x:1527,y:763,t:1528143747523};\\\", \\\"{x:1521,y:763,t:1528143747540};\\\", \\\"{x:1514,y:764,t:1528143747556};\\\", \\\"{x:1503,y:768,t:1528143747573};\\\", \\\"{x:1492,y:774,t:1528143747590};\\\", \\\"{x:1488,y:777,t:1528143747606};\\\", \\\"{x:1487,y:778,t:1528143747798};\\\", \\\"{x:1485,y:780,t:1528143747809};\\\", \\\"{x:1483,y:782,t:1528143747822};\\\", \\\"{x:1479,y:787,t:1528143747839};\\\", \\\"{x:1478,y:789,t:1528143747856};\\\", \\\"{x:1476,y:793,t:1528143747872};\\\", \\\"{x:1473,y:797,t:1528143747889};\\\", \\\"{x:1472,y:800,t:1528143747907};\\\", \\\"{x:1470,y:802,t:1528143747923};\\\", \\\"{x:1469,y:802,t:1528143747939};\\\", \\\"{x:1469,y:803,t:1528143747957};\\\", \\\"{x:1469,y:804,t:1528143748870};\\\", \\\"{x:1469,y:805,t:1528143748877};\\\", \\\"{x:1469,y:806,t:1528143748891};\\\", \\\"{x:1470,y:808,t:1528143748907};\\\", \\\"{x:1474,y:814,t:1528143748924};\\\", \\\"{x:1481,y:820,t:1528143748940};\\\", \\\"{x:1491,y:829,t:1528143748957};\\\", \\\"{x:1517,y:851,t:1528143748973};\\\", \\\"{x:1533,y:867,t:1528143748991};\\\", \\\"{x:1546,y:881,t:1528143749007};\\\", \\\"{x:1558,y:897,t:1528143749024};\\\", \\\"{x:1573,y:914,t:1528143749041};\\\", \\\"{x:1584,y:930,t:1528143749057};\\\", \\\"{x:1589,y:940,t:1528143749074};\\\", \\\"{x:1596,y:948,t:1528143749091};\\\", \\\"{x:1598,y:952,t:1528143749107};\\\", \\\"{x:1600,y:953,t:1528143749124};\\\", \\\"{x:1598,y:953,t:1528143749230};\\\", \\\"{x:1591,y:953,t:1528143749240};\\\", \\\"{x:1569,y:953,t:1528143749258};\\\", \\\"{x:1555,y:950,t:1528143749274};\\\", \\\"{x:1544,y:948,t:1528143749291};\\\", \\\"{x:1533,y:942,t:1528143749308};\\\", \\\"{x:1528,y:937,t:1528143749324};\\\", \\\"{x:1525,y:933,t:1528143749341};\\\", \\\"{x:1523,y:930,t:1528143749358};\\\", \\\"{x:1523,y:929,t:1528143749374};\\\", \\\"{x:1523,y:927,t:1528143749391};\\\", \\\"{x:1523,y:926,t:1528143749414};\\\", \\\"{x:1523,y:925,t:1528143749424};\\\", \\\"{x:1527,y:920,t:1528143749441};\\\", \\\"{x:1535,y:914,t:1528143749458};\\\", \\\"{x:1548,y:907,t:1528143749474};\\\", \\\"{x:1555,y:903,t:1528143749491};\\\", \\\"{x:1557,y:901,t:1528143749508};\\\", \\\"{x:1557,y:900,t:1528143749524};\\\", \\\"{x:1558,y:899,t:1528143749646};\\\", \\\"{x:1559,y:899,t:1528143749669};\\\", \\\"{x:1559,y:900,t:1528143749677};\\\", \\\"{x:1559,y:902,t:1528143749691};\\\", \\\"{x:1559,y:904,t:1528143749708};\\\", \\\"{x:1559,y:905,t:1528143749725};\\\", \\\"{x:1558,y:907,t:1528143749741};\\\", \\\"{x:1557,y:909,t:1528143749878};\\\", \\\"{x:1556,y:909,t:1528143749893};\\\", \\\"{x:1555,y:910,t:1528143749908};\\\", \\\"{x:1553,y:911,t:1528143749925};\\\", \\\"{x:1551,y:911,t:1528143749941};\\\", \\\"{x:1549,y:911,t:1528143749958};\\\", \\\"{x:1549,y:912,t:1528143750758};\\\", \\\"{x:1549,y:911,t:1528143758966};\\\", \\\"{x:1549,y:910,t:1528143758982};\\\", \\\"{x:1549,y:909,t:1528143759013};\\\", \\\"{x:1549,y:908,t:1528143759398};\\\", \\\"{x:1547,y:908,t:1528143761934};\\\", \\\"{x:1543,y:908,t:1528143761951};\\\", \\\"{x:1535,y:907,t:1528143761966};\\\", \\\"{x:1518,y:903,t:1528143761983};\\\", \\\"{x:1497,y:900,t:1528143762001};\\\", \\\"{x:1459,y:896,t:1528143762017};\\\", \\\"{x:1408,y:886,t:1528143762034};\\\", \\\"{x:1347,y:878,t:1528143762051};\\\", \\\"{x:1292,y:871,t:1528143762067};\\\", \\\"{x:1262,y:869,t:1528143762084};\\\", \\\"{x:1248,y:869,t:1528143762101};\\\", \\\"{x:1239,y:869,t:1528143762117};\\\", \\\"{x:1238,y:869,t:1528143762134};\\\", \\\"{x:1236,y:869,t:1528143762164};\\\", \\\"{x:1231,y:871,t:1528143762172};\\\", \\\"{x:1225,y:873,t:1528143762183};\\\", \\\"{x:1205,y:878,t:1528143762200};\\\", \\\"{x:1187,y:884,t:1528143762217};\\\", \\\"{x:1173,y:889,t:1528143762232};\\\", \\\"{x:1162,y:893,t:1528143762250};\\\", \\\"{x:1152,y:897,t:1528143762266};\\\", \\\"{x:1149,y:898,t:1528143762282};\\\", \\\"{x:1147,y:900,t:1528143762300};\\\", \\\"{x:1146,y:901,t:1528143762332};\\\", \\\"{x:1146,y:902,t:1528143762372};\\\", \\\"{x:1146,y:903,t:1528143762383};\\\", \\\"{x:1147,y:906,t:1528143762400};\\\", \\\"{x:1149,y:909,t:1528143762417};\\\", \\\"{x:1150,y:912,t:1528143762433};\\\", \\\"{x:1151,y:913,t:1528143762450};\\\", \\\"{x:1151,y:914,t:1528143762466};\\\", \\\"{x:1152,y:915,t:1528143762483};\\\", \\\"{x:1153,y:913,t:1528143763213};\\\", \\\"{x:1153,y:905,t:1528143763221};\\\", \\\"{x:1157,y:896,t:1528143763234};\\\", \\\"{x:1158,y:883,t:1528143763251};\\\", \\\"{x:1159,y:865,t:1528143763267};\\\", \\\"{x:1162,y:841,t:1528143763285};\\\", \\\"{x:1170,y:807,t:1528143763302};\\\", \\\"{x:1183,y:786,t:1528143763317};\\\", \\\"{x:1188,y:773,t:1528143763334};\\\", \\\"{x:1202,y:760,t:1528143763351};\\\", \\\"{x:1227,y:721,t:1528143763367};\\\", \\\"{x:1249,y:696,t:1528143763384};\\\", \\\"{x:1263,y:675,t:1528143763401};\\\", \\\"{x:1271,y:661,t:1528143763417};\\\", \\\"{x:1271,y:654,t:1528143763434};\\\", \\\"{x:1271,y:652,t:1528143763451};\\\", \\\"{x:1271,y:651,t:1528143763468};\\\", \\\"{x:1272,y:650,t:1528143763484};\\\", \\\"{x:1276,y:647,t:1528143763501};\\\", \\\"{x:1282,y:643,t:1528143763517};\\\", \\\"{x:1297,y:632,t:1528143763535};\\\", \\\"{x:1316,y:620,t:1528143763551};\\\", \\\"{x:1330,y:610,t:1528143763567};\\\", \\\"{x:1338,y:601,t:1528143763584};\\\", \\\"{x:1342,y:594,t:1528143763602};\\\", \\\"{x:1343,y:589,t:1528143763618};\\\", \\\"{x:1343,y:588,t:1528143763634};\\\", \\\"{x:1343,y:585,t:1528143763652};\\\", \\\"{x:1345,y:580,t:1528143763668};\\\", \\\"{x:1346,y:576,t:1528143763685};\\\", \\\"{x:1351,y:567,t:1528143763701};\\\", \\\"{x:1356,y:557,t:1528143763719};\\\", \\\"{x:1362,y:547,t:1528143763734};\\\", \\\"{x:1365,y:539,t:1528143763751};\\\", \\\"{x:1369,y:533,t:1528143763769};\\\", \\\"{x:1373,y:528,t:1528143763785};\\\", \\\"{x:1375,y:524,t:1528143763801};\\\", \\\"{x:1378,y:521,t:1528143763818};\\\", \\\"{x:1380,y:519,t:1528143763835};\\\", \\\"{x:1382,y:517,t:1528143763852};\\\", \\\"{x:1383,y:516,t:1528143763869};\\\", \\\"{x:1384,y:516,t:1528143763884};\\\", \\\"{x:1387,y:515,t:1528143763902};\\\", \\\"{x:1389,y:515,t:1528143763919};\\\", \\\"{x:1392,y:513,t:1528143763934};\\\", \\\"{x:1393,y:513,t:1528143763981};\\\", \\\"{x:1394,y:513,t:1528143763990};\\\", \\\"{x:1395,y:513,t:1528143764001};\\\", \\\"{x:1403,y:513,t:1528143764019};\\\", \\\"{x:1417,y:513,t:1528143764035};\\\", \\\"{x:1428,y:513,t:1528143764053};\\\", \\\"{x:1435,y:512,t:1528143764069};\\\", \\\"{x:1436,y:512,t:1528143764084};\\\", \\\"{x:1437,y:512,t:1528143764270};\\\", \\\"{x:1437,y:510,t:1528143764286};\\\", \\\"{x:1437,y:509,t:1528143764310};\\\", \\\"{x:1436,y:508,t:1528143764326};\\\", \\\"{x:1435,y:507,t:1528143764336};\\\", \\\"{x:1435,y:506,t:1528143764352};\\\", \\\"{x:1433,y:506,t:1528143764501};\\\", \\\"{x:1430,y:506,t:1528143764566};\\\", \\\"{x:1428,y:506,t:1528143764573};\\\", \\\"{x:1425,y:506,t:1528143764586};\\\", \\\"{x:1420,y:506,t:1528143764602};\\\", \\\"{x:1418,y:506,t:1528143764619};\\\", \\\"{x:1417,y:506,t:1528143764652};\\\", \\\"{x:1416,y:506,t:1528143764668};\\\", \\\"{x:1415,y:506,t:1528143765085};\\\", \\\"{x:1414,y:508,t:1528143765277};\\\", \\\"{x:1413,y:510,t:1528143765285};\\\", \\\"{x:1410,y:514,t:1528143765302};\\\", \\\"{x:1407,y:517,t:1528143765320};\\\", \\\"{x:1403,y:521,t:1528143765336};\\\", \\\"{x:1398,y:527,t:1528143765353};\\\", \\\"{x:1394,y:534,t:1528143765370};\\\", \\\"{x:1391,y:538,t:1528143765386};\\\", \\\"{x:1388,y:542,t:1528143765403};\\\", \\\"{x:1386,y:543,t:1528143765420};\\\", \\\"{x:1386,y:546,t:1528143765436};\\\", \\\"{x:1385,y:546,t:1528143765452};\\\", \\\"{x:1384,y:548,t:1528143765469};\\\", \\\"{x:1382,y:552,t:1528143765486};\\\", \\\"{x:1377,y:560,t:1528143765502};\\\", \\\"{x:1371,y:569,t:1528143765520};\\\", \\\"{x:1364,y:583,t:1528143765535};\\\", \\\"{x:1354,y:598,t:1528143765552};\\\", \\\"{x:1345,y:612,t:1528143765570};\\\", \\\"{x:1337,y:625,t:1528143765587};\\\", \\\"{x:1329,y:644,t:1528143765602};\\\", \\\"{x:1318,y:666,t:1528143765620};\\\", \\\"{x:1315,y:682,t:1528143765637};\\\", \\\"{x:1310,y:694,t:1528143765652};\\\", \\\"{x:1305,y:713,t:1528143765670};\\\", \\\"{x:1301,y:727,t:1528143765687};\\\", \\\"{x:1296,y:743,t:1528143765703};\\\", \\\"{x:1293,y:754,t:1528143765720};\\\", \\\"{x:1288,y:765,t:1528143765736};\\\", \\\"{x:1286,y:773,t:1528143765753};\\\", \\\"{x:1280,y:781,t:1528143765770};\\\", \\\"{x:1274,y:790,t:1528143765787};\\\", \\\"{x:1268,y:801,t:1528143765803};\\\", \\\"{x:1264,y:810,t:1528143765820};\\\", \\\"{x:1258,y:824,t:1528143765837};\\\", \\\"{x:1253,y:836,t:1528143765852};\\\", \\\"{x:1242,y:856,t:1528143765870};\\\", \\\"{x:1238,y:864,t:1528143765887};\\\", \\\"{x:1234,y:869,t:1528143765902};\\\", \\\"{x:1234,y:871,t:1528143765920};\\\", \\\"{x:1233,y:872,t:1528143765937};\\\", \\\"{x:1233,y:874,t:1528143765953};\\\", \\\"{x:1232,y:877,t:1528143765969};\\\", \\\"{x:1231,y:878,t:1528143765987};\\\", \\\"{x:1231,y:879,t:1528143766002};\\\", \\\"{x:1230,y:879,t:1528143766019};\\\", \\\"{x:1230,y:880,t:1528143766035};\\\", \\\"{x:1230,y:881,t:1528143766133};\\\", \\\"{x:1229,y:881,t:1528143766140};\\\", \\\"{x:1228,y:881,t:1528143766153};\\\", \\\"{x:1227,y:882,t:1528143766169};\\\", \\\"{x:1225,y:884,t:1528143766186};\\\", \\\"{x:1223,y:885,t:1528143766203};\\\", \\\"{x:1222,y:887,t:1528143766219};\\\", \\\"{x:1220,y:888,t:1528143766236};\\\", \\\"{x:1219,y:889,t:1528143766253};\\\", \\\"{x:1217,y:891,t:1528143766269};\\\", \\\"{x:1216,y:892,t:1528143766286};\\\", \\\"{x:1214,y:894,t:1528143766303};\\\", \\\"{x:1212,y:897,t:1528143766319};\\\", \\\"{x:1210,y:901,t:1528143766336};\\\", \\\"{x:1208,y:904,t:1528143766353};\\\", \\\"{x:1207,y:906,t:1528143766369};\\\", \\\"{x:1207,y:907,t:1528143766453};\\\", \\\"{x:1207,y:908,t:1528143766517};\\\", \\\"{x:1208,y:908,t:1528143766814};\\\", \\\"{x:1209,y:903,t:1528143766829};\\\", \\\"{x:1213,y:893,t:1528143766837};\\\", \\\"{x:1224,y:876,t:1528143766853};\\\", \\\"{x:1240,y:850,t:1528143766871};\\\", \\\"{x:1263,y:807,t:1528143766887};\\\", \\\"{x:1294,y:753,t:1528143766903};\\\", \\\"{x:1311,y:717,t:1528143766921};\\\", \\\"{x:1325,y:692,t:1528143766937};\\\", \\\"{x:1336,y:673,t:1528143766954};\\\", \\\"{x:1340,y:655,t:1528143766970};\\\", \\\"{x:1344,y:647,t:1528143766987};\\\", \\\"{x:1346,y:642,t:1528143767004};\\\", \\\"{x:1347,y:635,t:1528143767022};\\\", \\\"{x:1347,y:631,t:1528143767037};\\\", \\\"{x:1353,y:613,t:1528143767054};\\\", \\\"{x:1368,y:524,t:1528143767071};\\\", \\\"{x:1377,y:474,t:1528143767088};\\\", \\\"{x:1400,y:438,t:1528143767104};\\\", \\\"{x:1414,y:421,t:1528143767121};\\\", \\\"{x:1417,y:416,t:1528143767138};\\\", \\\"{x:1417,y:415,t:1528143767154};\\\", \\\"{x:1417,y:417,t:1528143767278};\\\", \\\"{x:1417,y:427,t:1528143767288};\\\", \\\"{x:1417,y:452,t:1528143767304};\\\", \\\"{x:1416,y:472,t:1528143767321};\\\", \\\"{x:1416,y:484,t:1528143767338};\\\", \\\"{x:1416,y:488,t:1528143767354};\\\", \\\"{x:1416,y:491,t:1528143767370};\\\", \\\"{x:1416,y:492,t:1528143767388};\\\", \\\"{x:1416,y:493,t:1528143767453};\\\", \\\"{x:1416,y:494,t:1528143767517};\\\", \\\"{x:1415,y:495,t:1528143767525};\\\", \\\"{x:1414,y:499,t:1528143767537};\\\", \\\"{x:1412,y:502,t:1528143767554};\\\", \\\"{x:1410,y:510,t:1528143767572};\\\", \\\"{x:1409,y:519,t:1528143767589};\\\", \\\"{x:1408,y:526,t:1528143767605};\\\", \\\"{x:1407,y:532,t:1528143767620};\\\", \\\"{x:1407,y:537,t:1528143767637};\\\", \\\"{x:1407,y:538,t:1528143767710};\\\", \\\"{x:1409,y:541,t:1528143767733};\\\", \\\"{x:1411,y:542,t:1528143767750};\\\", \\\"{x:1414,y:544,t:1528143767758};\\\", \\\"{x:1416,y:547,t:1528143767770};\\\", \\\"{x:1423,y:551,t:1528143767788};\\\", \\\"{x:1429,y:555,t:1528143767804};\\\", \\\"{x:1434,y:560,t:1528143767821};\\\", \\\"{x:1444,y:577,t:1528143767838};\\\", \\\"{x:1450,y:588,t:1528143767856};\\\", \\\"{x:1458,y:599,t:1528143767871};\\\", \\\"{x:1464,y:610,t:1528143767888};\\\", \\\"{x:1471,y:618,t:1528143767905};\\\", \\\"{x:1476,y:628,t:1528143767920};\\\", \\\"{x:1485,y:640,t:1528143767937};\\\", \\\"{x:1492,y:651,t:1528143767955};\\\", \\\"{x:1497,y:659,t:1528143767971};\\\", \\\"{x:1501,y:665,t:1528143767988};\\\", \\\"{x:1507,y:673,t:1528143768005};\\\", \\\"{x:1513,y:680,t:1528143768022};\\\", \\\"{x:1515,y:684,t:1528143768038};\\\", \\\"{x:1516,y:688,t:1528143768054};\\\", \\\"{x:1519,y:692,t:1528143768072};\\\", \\\"{x:1521,y:693,t:1528143768142};\\\", \\\"{x:1521,y:695,t:1528143768286};\\\", \\\"{x:1523,y:703,t:1528143768294};\\\", \\\"{x:1524,y:714,t:1528143768305};\\\", \\\"{x:1531,y:722,t:1528143768322};\\\", \\\"{x:1535,y:733,t:1528143768337};\\\", \\\"{x:1541,y:740,t:1528143768354};\\\", \\\"{x:1546,y:748,t:1528143768371};\\\", \\\"{x:1551,y:755,t:1528143768387};\\\", \\\"{x:1558,y:765,t:1528143768405};\\\", \\\"{x:1560,y:767,t:1528143768420};\\\", \\\"{x:1562,y:769,t:1528143768437};\\\", \\\"{x:1563,y:771,t:1528143768454};\\\", \\\"{x:1564,y:772,t:1528143768471};\\\", \\\"{x:1569,y:779,t:1528143768488};\\\", \\\"{x:1584,y:797,t:1528143768504};\\\", \\\"{x:1594,y:812,t:1528143768521};\\\", \\\"{x:1606,y:826,t:1528143768538};\\\", \\\"{x:1615,y:839,t:1528143768555};\\\", \\\"{x:1624,y:851,t:1528143768571};\\\", \\\"{x:1629,y:858,t:1528143768588};\\\", \\\"{x:1630,y:861,t:1528143768605};\\\", \\\"{x:1630,y:862,t:1528143768622};\\\", \\\"{x:1631,y:865,t:1528143768638};\\\", \\\"{x:1631,y:866,t:1528143768655};\\\", \\\"{x:1631,y:868,t:1528143768671};\\\", \\\"{x:1631,y:871,t:1528143768749};\\\", \\\"{x:1631,y:872,t:1528143768758};\\\", \\\"{x:1631,y:874,t:1528143768772};\\\", \\\"{x:1627,y:877,t:1528143768789};\\\", \\\"{x:1622,y:882,t:1528143768805};\\\", \\\"{x:1619,y:885,t:1528143768821};\\\", \\\"{x:1619,y:886,t:1528143768839};\\\", \\\"{x:1619,y:888,t:1528143768855};\\\", \\\"{x:1618,y:890,t:1528143768871};\\\", \\\"{x:1618,y:891,t:1528143768889};\\\", \\\"{x:1618,y:893,t:1528143768905};\\\", \\\"{x:1622,y:904,t:1528143768922};\\\", \\\"{x:1625,y:911,t:1528143768939};\\\", \\\"{x:1625,y:913,t:1528143768955};\\\", \\\"{x:1626,y:913,t:1528143768972};\\\", \\\"{x:1626,y:914,t:1528143769022};\\\", \\\"{x:1625,y:912,t:1528143769654};\\\", \\\"{x:1623,y:911,t:1528143769669};\\\", \\\"{x:1622,y:910,t:1528143769677};\\\", \\\"{x:1621,y:910,t:1528143769689};\\\", \\\"{x:1618,y:909,t:1528143769706};\\\", \\\"{x:1616,y:908,t:1528143769723};\\\", \\\"{x:1615,y:907,t:1528143769739};\\\", \\\"{x:1614,y:906,t:1528143769756};\\\", \\\"{x:1612,y:905,t:1528143769781};\\\", \\\"{x:1612,y:904,t:1528143769902};\\\", \\\"{x:1611,y:901,t:1528143769910};\\\", \\\"{x:1610,y:900,t:1528143769923};\\\", \\\"{x:1606,y:895,t:1528143769940};\\\", \\\"{x:1604,y:891,t:1528143769956};\\\", \\\"{x:1598,y:881,t:1528143769973};\\\", \\\"{x:1596,y:878,t:1528143769989};\\\", \\\"{x:1595,y:877,t:1528143770006};\\\", \\\"{x:1593,y:873,t:1528143770023};\\\", \\\"{x:1591,y:870,t:1528143770040};\\\", \\\"{x:1587,y:866,t:1528143770056};\\\", \\\"{x:1585,y:863,t:1528143770073};\\\", \\\"{x:1581,y:858,t:1528143770090};\\\", \\\"{x:1577,y:853,t:1528143770106};\\\", \\\"{x:1573,y:848,t:1528143770123};\\\", \\\"{x:1568,y:839,t:1528143770140};\\\", \\\"{x:1562,y:827,t:1528143770156};\\\", \\\"{x:1549,y:801,t:1528143770173};\\\", \\\"{x:1543,y:783,t:1528143770190};\\\", \\\"{x:1537,y:764,t:1528143770206};\\\", \\\"{x:1530,y:740,t:1528143770223};\\\", \\\"{x:1526,y:721,t:1528143770240};\\\", \\\"{x:1518,y:696,t:1528143770256};\\\", \\\"{x:1499,y:650,t:1528143770274};\\\", \\\"{x:1475,y:607,t:1528143770289};\\\", \\\"{x:1435,y:549,t:1528143770306};\\\", \\\"{x:1412,y:522,t:1528143770322};\\\", \\\"{x:1403,y:511,t:1528143770339};\\\", \\\"{x:1401,y:506,t:1528143770355};\\\", \\\"{x:1399,y:502,t:1528143770372};\\\", \\\"{x:1398,y:499,t:1528143770389};\\\", \\\"{x:1398,y:496,t:1528143770406};\\\", \\\"{x:1398,y:491,t:1528143770422};\\\", \\\"{x:1396,y:488,t:1528143770440};\\\", \\\"{x:1396,y:486,t:1528143770456};\\\", \\\"{x:1396,y:484,t:1528143770473};\\\", \\\"{x:1397,y:487,t:1528143770693};\\\", \\\"{x:1400,y:492,t:1528143770707};\\\", \\\"{x:1404,y:499,t:1528143770723};\\\", \\\"{x:1406,y:501,t:1528143770740};\\\", \\\"{x:1409,y:505,t:1528143770757};\\\", \\\"{x:1410,y:506,t:1528143770773};\\\", \\\"{x:1411,y:507,t:1528143770790};\\\", \\\"{x:1412,y:508,t:1528143770925};\\\", \\\"{x:1412,y:510,t:1528143771069};\\\", \\\"{x:1406,y:513,t:1528143771078};\\\", \\\"{x:1394,y:517,t:1528143771090};\\\", \\\"{x:1363,y:525,t:1528143771107};\\\", \\\"{x:1316,y:537,t:1528143771124};\\\", \\\"{x:1251,y:548,t:1528143771140};\\\", \\\"{x:1183,y:556,t:1528143771157};\\\", \\\"{x:1163,y:561,t:1528143771173};\\\", \\\"{x:1158,y:562,t:1528143771190};\\\", \\\"{x:1156,y:562,t:1528143771207};\\\", \\\"{x:1156,y:561,t:1528143771237};\\\", \\\"{x:1156,y:560,t:1528143771246};\\\", \\\"{x:1163,y:556,t:1528143771257};\\\", \\\"{x:1177,y:552,t:1528143771274};\\\", \\\"{x:1198,y:546,t:1528143771290};\\\", \\\"{x:1218,y:541,t:1528143771306};\\\", \\\"{x:1240,y:533,t:1528143771324};\\\", \\\"{x:1261,y:526,t:1528143771340};\\\", \\\"{x:1292,y:515,t:1528143771357};\\\", \\\"{x:1312,y:507,t:1528143771374};\\\", \\\"{x:1324,y:505,t:1528143771391};\\\", \\\"{x:1330,y:501,t:1528143771407};\\\", \\\"{x:1328,y:501,t:1528143771494};\\\", \\\"{x:1325,y:501,t:1528143771507};\\\", \\\"{x:1317,y:504,t:1528143771524};\\\", \\\"{x:1298,y:510,t:1528143771541};\\\", \\\"{x:1281,y:515,t:1528143771558};\\\", \\\"{x:1262,y:519,t:1528143771575};\\\", \\\"{x:1242,y:521,t:1528143771591};\\\", \\\"{x:1231,y:524,t:1528143771607};\\\", \\\"{x:1228,y:524,t:1528143771624};\\\", \\\"{x:1229,y:524,t:1528143771774};\\\", \\\"{x:1236,y:524,t:1528143771791};\\\", \\\"{x:1248,y:523,t:1528143771807};\\\", \\\"{x:1255,y:522,t:1528143771824};\\\", \\\"{x:1260,y:521,t:1528143771841};\\\", \\\"{x:1262,y:519,t:1528143771858};\\\", \\\"{x:1264,y:519,t:1528143772373};\\\", \\\"{x:1272,y:519,t:1528143772381};\\\", \\\"{x:1279,y:518,t:1528143772390};\\\", \\\"{x:1293,y:514,t:1528143772408};\\\", \\\"{x:1309,y:510,t:1528143772425};\\\", \\\"{x:1318,y:509,t:1528143772441};\\\", \\\"{x:1310,y:509,t:1528143772501};\\\", \\\"{x:1296,y:512,t:1528143772509};\\\", \\\"{x:1249,y:524,t:1528143772526};\\\", \\\"{x:1180,y:544,t:1528143772541};\\\", \\\"{x:1099,y:568,t:1528143772557};\\\", \\\"{x:1016,y:603,t:1528143772575};\\\", \\\"{x:894,y:660,t:1528143772592};\\\", \\\"{x:762,y:717,t:1528143772607};\\\", \\\"{x:615,y:765,t:1528143772625};\\\", \\\"{x:423,y:803,t:1528143772641};\\\", \\\"{x:254,y:826,t:1528143772658};\\\", \\\"{x:82,y:837,t:1528143772675};\\\", \\\"{x:0,y:837,t:1528143772691};\\\", \\\"{x:0,y:836,t:1528143772709};\\\", \\\"{x:0,y:832,t:1528143772725};\\\", \\\"{x:3,y:827,t:1528143772765};\\\", \\\"{x:7,y:823,t:1528143772775};\\\", \\\"{x:13,y:815,t:1528143772791};\\\", \\\"{x:22,y:803,t:1528143772808};\\\", \\\"{x:33,y:791,t:1528143772825};\\\", \\\"{x:49,y:772,t:1528143772841};\\\", \\\"{x:73,y:746,t:1528143772858};\\\", \\\"{x:109,y:716,t:1528143772875};\\\", \\\"{x:160,y:677,t:1528143772891};\\\", \\\"{x:218,y:642,t:1528143772907};\\\", \\\"{x:292,y:594,t:1528143772926};\\\", \\\"{x:329,y:569,t:1528143772941};\\\", \\\"{x:347,y:551,t:1528143772958};\\\", \\\"{x:351,y:543,t:1528143772977};\\\", \\\"{x:353,y:539,t:1528143772993};\\\", \\\"{x:353,y:537,t:1528143773010};\\\", \\\"{x:354,y:535,t:1528143773027};\\\", \\\"{x:354,y:533,t:1528143773043};\\\", \\\"{x:360,y:524,t:1528143773060};\\\", \\\"{x:366,y:517,t:1528143773076};\\\", \\\"{x:373,y:512,t:1528143773093};\\\", \\\"{x:379,y:506,t:1528143773111};\\\", \\\"{x:383,y:503,t:1528143773126};\\\", \\\"{x:384,y:501,t:1528143773144};\\\", \\\"{x:385,y:501,t:1528143773161};\\\", \\\"{x:385,y:500,t:1528143773213};\\\", \\\"{x:386,y:498,t:1528143773227};\\\", \\\"{x:386,y:496,t:1528143773244};\\\", \\\"{x:386,y:494,t:1528143773261};\\\", \\\"{x:386,y:493,t:1528143773276};\\\", \\\"{x:381,y:491,t:1528143773294};\\\", \\\"{x:375,y:489,t:1528143773310};\\\", \\\"{x:372,y:487,t:1528143773327};\\\", \\\"{x:369,y:486,t:1528143773343};\\\", \\\"{x:367,y:486,t:1528143773933};\\\", \\\"{x:368,y:486,t:1528143773949};\\\", \\\"{x:376,y:488,t:1528143773962};\\\", \\\"{x:396,y:491,t:1528143773977};\\\", \\\"{x:417,y:494,t:1528143773994};\\\", \\\"{x:441,y:496,t:1528143774010};\\\", \\\"{x:492,y:504,t:1528143774027};\\\", \\\"{x:671,y:528,t:1528143774044};\\\", \\\"{x:824,y:539,t:1528143774061};\\\", \\\"{x:996,y:539,t:1528143774078};\\\", \\\"{x:1161,y:539,t:1528143774094};\\\", \\\"{x:1317,y:538,t:1528143774111};\\\", \\\"{x:1452,y:523,t:1528143774128};\\\", \\\"{x:1559,y:513,t:1528143774144};\\\", \\\"{x:1614,y:507,t:1528143774161};\\\", \\\"{x:1631,y:507,t:1528143774178};\\\", \\\"{x:1632,y:507,t:1528143774194};\\\", \\\"{x:1630,y:507,t:1528143774270};\\\", \\\"{x:1627,y:507,t:1528143774279};\\\", \\\"{x:1606,y:507,t:1528143774295};\\\", \\\"{x:1575,y:508,t:1528143774312};\\\", \\\"{x:1521,y:513,t:1528143774328};\\\", \\\"{x:1454,y:513,t:1528143774346};\\\", \\\"{x:1380,y:516,t:1528143774361};\\\", \\\"{x:1322,y:525,t:1528143774378};\\\", \\\"{x:1298,y:528,t:1528143774395};\\\", \\\"{x:1291,y:530,t:1528143774412};\\\", \\\"{x:1290,y:530,t:1528143774428};\\\", \\\"{x:1292,y:530,t:1528143774453};\\\", \\\"{x:1299,y:530,t:1528143774462};\\\", \\\"{x:1324,y:530,t:1528143774478};\\\", \\\"{x:1351,y:530,t:1528143774496};\\\", \\\"{x:1392,y:530,t:1528143774513};\\\", \\\"{x:1415,y:530,t:1528143774530};\\\", \\\"{x:1429,y:530,t:1528143774546};\\\", \\\"{x:1432,y:530,t:1528143774563};\\\", \\\"{x:1430,y:530,t:1528143774630};\\\", \\\"{x:1426,y:530,t:1528143774647};\\\", \\\"{x:1424,y:530,t:1528143774663};\\\", \\\"{x:1422,y:530,t:1528143774681};\\\", \\\"{x:1417,y:530,t:1528143774697};\\\", \\\"{x:1413,y:531,t:1528143774714};\\\", \\\"{x:1409,y:532,t:1528143774730};\\\", \\\"{x:1408,y:532,t:1528143774747};\\\", \\\"{x:1405,y:532,t:1528143774764};\\\", \\\"{x:1403,y:532,t:1528143774780};\\\", \\\"{x:1403,y:533,t:1528143774805};\\\", \\\"{x:1404,y:532,t:1528143775078};\\\", \\\"{x:1405,y:530,t:1528143775109};\\\", \\\"{x:1406,y:530,t:1528143775134};\\\", \\\"{x:1406,y:529,t:1528143775149};\\\", \\\"{x:1406,y:528,t:1528143775189};\\\", \\\"{x:1407,y:528,t:1528143775199};\\\", \\\"{x:1405,y:528,t:1528143775302};\\\", \\\"{x:1397,y:528,t:1528143775316};\\\", \\\"{x:1367,y:528,t:1528143775332};\\\", \\\"{x:1313,y:535,t:1528143775349};\\\", \\\"{x:1251,y:545,t:1528143775366};\\\", \\\"{x:1185,y:560,t:1528143775382};\\\", \\\"{x:1102,y:583,t:1528143775398};\\\", \\\"{x:956,y:602,t:1528143775415};\\\", \\\"{x:831,y:621,t:1528143775433};\\\", \\\"{x:692,y:643,t:1528143775450};\\\", \\\"{x:566,y:653,t:1528143775465};\\\", \\\"{x:458,y:655,t:1528143775483};\\\", \\\"{x:396,y:655,t:1528143775500};\\\", \\\"{x:368,y:655,t:1528143775515};\\\", \\\"{x:363,y:655,t:1528143775533};\\\", \\\"{x:364,y:653,t:1528143775565};\\\", \\\"{x:364,y:652,t:1528143775573};\\\", \\\"{x:364,y:651,t:1528143775583};\\\", \\\"{x:366,y:646,t:1528143775600};\\\", \\\"{x:367,y:640,t:1528143775617};\\\", \\\"{x:367,y:631,t:1528143775634};\\\", \\\"{x:367,y:622,t:1528143775650};\\\", \\\"{x:367,y:613,t:1528143775668};\\\", \\\"{x:362,y:606,t:1528143775683};\\\", \\\"{x:353,y:599,t:1528143775696};\\\", \\\"{x:343,y:594,t:1528143775712};\\\", \\\"{x:331,y:589,t:1528143775728};\\\", \\\"{x:322,y:583,t:1528143775745};\\\", \\\"{x:319,y:581,t:1528143775762};\\\", \\\"{x:318,y:580,t:1528143775778};\\\", \\\"{x:319,y:577,t:1528143775796};\\\", \\\"{x:328,y:572,t:1528143775812};\\\", \\\"{x:344,y:563,t:1528143775828};\\\", \\\"{x:364,y:556,t:1528143775845};\\\", \\\"{x:382,y:551,t:1528143775863};\\\", \\\"{x:409,y:547,t:1528143775879};\\\", \\\"{x:436,y:547,t:1528143775895};\\\", \\\"{x:479,y:546,t:1528143775912};\\\", \\\"{x:532,y:546,t:1528143775928};\\\", \\\"{x:577,y:546,t:1528143775945};\\\", \\\"{x:607,y:546,t:1528143775963};\\\", \\\"{x:624,y:546,t:1528143775978};\\\", \\\"{x:627,y:546,t:1528143775996};\\\", \\\"{x:628,y:546,t:1528143776102};\\\", \\\"{x:629,y:546,t:1528143776157};\\\", \\\"{x:630,y:546,t:1528143776165};\\\", \\\"{x:631,y:546,t:1528143776179};\\\", \\\"{x:633,y:543,t:1528143776196};\\\", \\\"{x:634,y:541,t:1528143776212};\\\", \\\"{x:634,y:540,t:1528143776230};\\\", \\\"{x:634,y:539,t:1528143776245};\\\", \\\"{x:634,y:536,t:1528143776263};\\\", \\\"{x:634,y:530,t:1528143776280};\\\", \\\"{x:633,y:522,t:1528143776295};\\\", \\\"{x:629,y:513,t:1528143776312};\\\", \\\"{x:624,y:503,t:1528143776330};\\\", \\\"{x:621,y:495,t:1528143776346};\\\", \\\"{x:621,y:491,t:1528143776362};\\\", \\\"{x:621,y:488,t:1528143776380};\\\", \\\"{x:621,y:484,t:1528143776396};\\\", \\\"{x:622,y:482,t:1528143776412};\\\", \\\"{x:625,y:480,t:1528143776430};\\\", \\\"{x:630,y:478,t:1528143776447};\\\", \\\"{x:634,y:477,t:1528143776462};\\\", \\\"{x:639,y:475,t:1528143776480};\\\", \\\"{x:652,y:475,t:1528143776497};\\\", \\\"{x:661,y:475,t:1528143776513};\\\", \\\"{x:674,y:475,t:1528143776529};\\\", \\\"{x:688,y:475,t:1528143776546};\\\", \\\"{x:695,y:475,t:1528143776563};\\\", \\\"{x:699,y:474,t:1528143776579};\\\", \\\"{x:708,y:474,t:1528143776596};\\\", \\\"{x:744,y:474,t:1528143776616};\\\", \\\"{x:788,y:475,t:1528143776630};\\\", \\\"{x:851,y:480,t:1528143776648};\\\", \\\"{x:918,y:480,t:1528143776663};\\\", \\\"{x:971,y:480,t:1528143776680};\\\", \\\"{x:1004,y:480,t:1528143776697};\\\", \\\"{x:1022,y:480,t:1528143776713};\\\", \\\"{x:1023,y:480,t:1528143776729};\\\", \\\"{x:1022,y:480,t:1528143776772};\\\", \\\"{x:1017,y:478,t:1528143776780};\\\", \\\"{x:1003,y:474,t:1528143776797};\\\", \\\"{x:982,y:470,t:1528143776814};\\\", \\\"{x:956,y:468,t:1528143776829};\\\", \\\"{x:928,y:466,t:1528143776846};\\\", \\\"{x:906,y:466,t:1528143776863};\\\", \\\"{x:890,y:466,t:1528143776880};\\\", \\\"{x:880,y:466,t:1528143776897};\\\", \\\"{x:875,y:466,t:1528143776913};\\\", \\\"{x:873,y:466,t:1528143776929};\\\", \\\"{x:869,y:469,t:1528143776947};\\\", \\\"{x:865,y:472,t:1528143776965};\\\", \\\"{x:860,y:476,t:1528143776982};\\\", \\\"{x:859,y:477,t:1528143777004};\\\", \\\"{x:858,y:478,t:1528143777020};\\\", \\\"{x:857,y:479,t:1528143777036};\\\", \\\"{x:857,y:481,t:1528143777053};\\\", \\\"{x:854,y:483,t:1528143777063};\\\", \\\"{x:852,y:485,t:1528143777080};\\\", \\\"{x:846,y:487,t:1528143777097};\\\", \\\"{x:840,y:490,t:1528143777113};\\\", \\\"{x:836,y:490,t:1528143777129};\\\", \\\"{x:835,y:490,t:1528143777149};\\\", \\\"{x:834,y:490,t:1528143777172};\\\", \\\"{x:833,y:490,t:1528143777213};\\\", \\\"{x:830,y:491,t:1528143777669};\\\", \\\"{x:822,y:498,t:1528143777682};\\\", \\\"{x:790,y:516,t:1528143777698};\\\", \\\"{x:755,y:542,t:1528143777714};\\\", \\\"{x:704,y:570,t:1528143777731};\\\", \\\"{x:643,y:611,t:1528143777748};\\\", \\\"{x:594,y:639,t:1528143777764};\\\", \\\"{x:523,y:681,t:1528143777781};\\\", \\\"{x:493,y:699,t:1528143777798};\\\", \\\"{x:471,y:715,t:1528143777814};\\\", \\\"{x:460,y:726,t:1528143777830};\\\", \\\"{x:455,y:732,t:1528143777847};\\\", \\\"{x:453,y:735,t:1528143777863};\\\", \\\"{x:453,y:736,t:1528143777884};\\\", \\\"{x:452,y:737,t:1528143777897};\\\", \\\"{x:452,y:741,t:1528143777914};\\\", \\\"{x:448,y:745,t:1528143777930};\\\", \\\"{x:446,y:749,t:1528143777948};\\\", \\\"{x:445,y:751,t:1528143777964};\\\", \\\"{x:445,y:749,t:1528143778061};\\\", \\\"{x:445,y:747,t:1528143778069};\\\", \\\"{x:445,y:745,t:1528143778081};\\\", \\\"{x:449,y:738,t:1528143778098};\\\", \\\"{x:453,y:733,t:1528143778115};\\\", \\\"{x:459,y:726,t:1528143778131};\\\", \\\"{x:461,y:722,t:1528143778148};\\\", \\\"{x:463,y:719,t:1528143778165};\\\", \\\"{x:467,y:715,t:1528143778181};\\\", \\\"{x:470,y:712,t:1528143778198};\\\", \\\"{x:474,y:707,t:1528143778214};\\\", \\\"{x:479,y:703,t:1528143778231};\\\", \\\"{x:486,y:697,t:1528143778249};\\\", \\\"{x:490,y:694,t:1528143778264};\\\", \\\"{x:495,y:691,t:1528143778280};\\\", \\\"{x:497,y:690,t:1528143778300};\\\", \\\"{x:497,y:689,t:1528143778317};\\\", \\\"{x:498,y:689,t:1528143778333};\\\", \\\"{x:499,y:688,t:1528143778350};\\\", \\\"{x:500,y:688,t:1528143780127};\\\", \\\"{x:505,y:694,t:1528143780135};\\\", \\\"{x:519,y:710,t:1528143780152};\\\", \\\"{x:534,y:728,t:1528143780169};\\\", \\\"{x:543,y:739,t:1528143780186};\\\", \\\"{x:556,y:757,t:1528143780202};\\\", \\\"{x:575,y:779,t:1528143780219};\\\", \\\"{x:594,y:791,t:1528143780236};\\\", \\\"{x:605,y:799,t:1528143780252};\\\", \\\"{x:610,y:802,t:1528143780269};\\\", \\\"{x:613,y:802,t:1528143780286};\\\", \\\"{x:614,y:802,t:1528143780456};\\\", \\\"{x:615,y:803,t:1528143780976};\\\", \\\"{x:611,y:810,t:1528143780986};\\\", \\\"{x:588,y:828,t:1528143781004};\\\", \\\"{x:559,y:844,t:1528143781025};\\\", \\\"{x:555,y:846,t:1528143781036};\\\", \\\"{x:551,y:846,t:1528143781053};\\\", \\\"{x:550,y:846,t:1528143781070};\\\" ] }, { \\\"rt\\\": 25427, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 327977, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"8182H\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-08 AM-I -B -11 AM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:555,y:771,t:1528143781287};\\\", \\\"{x:556,y:771,t:1528143783298};\\\", \\\"{x:557,y:772,t:1528143783305};\\\", \\\"{x:560,y:776,t:1528143783325};\\\", \\\"{x:563,y:782,t:1528143783339};\\\", \\\"{x:565,y:787,t:1528143783355};\\\", \\\"{x:568,y:797,t:1528143783371};\\\", \\\"{x:569,y:807,t:1528143783389};\\\", \\\"{x:570,y:816,t:1528143783406};\\\", \\\"{x:571,y:819,t:1528143783421};\\\", \\\"{x:572,y:819,t:1528143783456};\\\", \\\"{x:573,y:819,t:1528143783471};\\\", \\\"{x:587,y:813,t:1528143783488};\\\", \\\"{x:605,y:802,t:1528143783506};\\\", \\\"{x:631,y:792,t:1528143783521};\\\", \\\"{x:651,y:783,t:1528143783539};\\\", \\\"{x:654,y:775,t:1528143783555};\\\", \\\"{x:659,y:764,t:1528143784817};\\\", \\\"{x:683,y:742,t:1528143784825};\\\", \\\"{x:717,y:712,t:1528143784840};\\\", \\\"{x:792,y:639,t:1528143784856};\\\", \\\"{x:803,y:627,t:1528143784873};\\\", \\\"{x:804,y:627,t:1528143784890};\\\", \\\"{x:805,y:627,t:1528143784969};\\\", \\\"{x:807,y:627,t:1528143784977};\\\", \\\"{x:808,y:627,t:1528143784989};\\\", \\\"{x:808,y:626,t:1528143786177};\\\", \\\"{x:801,y:622,t:1528143786191};\\\", \\\"{x:787,y:618,t:1528143786208};\\\", \\\"{x:786,y:618,t:1528143786224};\\\", \\\"{x:785,y:617,t:1528143786241};\\\", \\\"{x:786,y:617,t:1528143787561};\\\", \\\"{x:793,y:620,t:1528143787576};\\\", \\\"{x:800,y:624,t:1528143787591};\\\", \\\"{x:805,y:625,t:1528143787608};\\\", \\\"{x:806,y:627,t:1528143787626};\\\", \\\"{x:808,y:627,t:1528143787642};\\\", \\\"{x:810,y:628,t:1528143787659};\\\", \\\"{x:813,y:629,t:1528143787675};\\\", \\\"{x:820,y:632,t:1528143787692};\\\", \\\"{x:832,y:636,t:1528143787709};\\\", \\\"{x:847,y:643,t:1528143787725};\\\", \\\"{x:869,y:654,t:1528143787741};\\\", \\\"{x:894,y:665,t:1528143787759};\\\", \\\"{x:921,y:677,t:1528143787775};\\\", \\\"{x:962,y:693,t:1528143787792};\\\", \\\"{x:972,y:695,t:1528143787809};\\\", \\\"{x:979,y:698,t:1528143787827};\\\", \\\"{x:984,y:699,t:1528143787842};\\\", \\\"{x:992,y:701,t:1528143787859};\\\", \\\"{x:1001,y:703,t:1528143787875};\\\", \\\"{x:1009,y:708,t:1528143787892};\\\", \\\"{x:1023,y:713,t:1528143787909};\\\", \\\"{x:1044,y:720,t:1528143787925};\\\", \\\"{x:1065,y:725,t:1528143787942};\\\", \\\"{x:1080,y:729,t:1528143787960};\\\", \\\"{x:1090,y:733,t:1528143787975};\\\", \\\"{x:1104,y:739,t:1528143787992};\\\", \\\"{x:1117,y:745,t:1528143788009};\\\", \\\"{x:1147,y:757,t:1528143788027};\\\", \\\"{x:1189,y:777,t:1528143788042};\\\", \\\"{x:1219,y:784,t:1528143788059};\\\", \\\"{x:1248,y:794,t:1528143788075};\\\", \\\"{x:1263,y:795,t:1528143788092};\\\", \\\"{x:1268,y:795,t:1528143788108};\\\", \\\"{x:1269,y:795,t:1528143788126};\\\", \\\"{x:1270,y:795,t:1528143788176};\\\", \\\"{x:1270,y:794,t:1528143788297};\\\", \\\"{x:1265,y:789,t:1528143788310};\\\", \\\"{x:1259,y:784,t:1528143788326};\\\", \\\"{x:1258,y:784,t:1528143788345};\\\", \\\"{x:1255,y:784,t:1528143788360};\\\", \\\"{x:1253,y:782,t:1528143788376};\\\", \\\"{x:1250,y:782,t:1528143788393};\\\", \\\"{x:1248,y:781,t:1528143788409};\\\", \\\"{x:1246,y:781,t:1528143788427};\\\", \\\"{x:1243,y:779,t:1528143788443};\\\", \\\"{x:1242,y:778,t:1528143788459};\\\", \\\"{x:1235,y:777,t:1528143788476};\\\", \\\"{x:1230,y:775,t:1528143788493};\\\", \\\"{x:1220,y:774,t:1528143788510};\\\", \\\"{x:1198,y:773,t:1528143788527};\\\", \\\"{x:1184,y:773,t:1528143788542};\\\", \\\"{x:1174,y:773,t:1528143788560};\\\", \\\"{x:1169,y:773,t:1528143788576};\\\", \\\"{x:1168,y:773,t:1528143788601};\\\", \\\"{x:1169,y:774,t:1528143788689};\\\", \\\"{x:1174,y:780,t:1528143788696};\\\", \\\"{x:1179,y:785,t:1528143788710};\\\", \\\"{x:1189,y:792,t:1528143788726};\\\", \\\"{x:1197,y:799,t:1528143788743};\\\", \\\"{x:1202,y:801,t:1528143788760};\\\", \\\"{x:1205,y:803,t:1528143788777};\\\", \\\"{x:1207,y:803,t:1528143788873};\\\", \\\"{x:1208,y:803,t:1528143788961};\\\", \\\"{x:1208,y:799,t:1528143788976};\\\", \\\"{x:1208,y:797,t:1528143788993};\\\", \\\"{x:1208,y:796,t:1528143789041};\\\", \\\"{x:1203,y:799,t:1528143789145};\\\", \\\"{x:1195,y:803,t:1528143789161};\\\", \\\"{x:1160,y:814,t:1528143789177};\\\", \\\"{x:1143,y:816,t:1528143789192};\\\", \\\"{x:1134,y:816,t:1528143789211};\\\", \\\"{x:1131,y:809,t:1528143789227};\\\", \\\"{x:1128,y:790,t:1528143789244};\\\", \\\"{x:1126,y:768,t:1528143789260};\\\", \\\"{x:1126,y:750,t:1528143789276};\\\", \\\"{x:1126,y:739,t:1528143789293};\\\", \\\"{x:1126,y:733,t:1528143789310};\\\", \\\"{x:1126,y:731,t:1528143789327};\\\", \\\"{x:1126,y:728,t:1528143789343};\\\", \\\"{x:1128,y:726,t:1528143789360};\\\", \\\"{x:1129,y:725,t:1528143789376};\\\", \\\"{x:1133,y:725,t:1528143789393};\\\", \\\"{x:1136,y:725,t:1528143789411};\\\", \\\"{x:1139,y:725,t:1528143789427};\\\", \\\"{x:1141,y:725,t:1528143789444};\\\", \\\"{x:1142,y:725,t:1528143789460};\\\", \\\"{x:1146,y:725,t:1528143789476};\\\", \\\"{x:1152,y:725,t:1528143789493};\\\", \\\"{x:1161,y:725,t:1528143789510};\\\", \\\"{x:1171,y:726,t:1528143789526};\\\", \\\"{x:1179,y:726,t:1528143789543};\\\", \\\"{x:1186,y:726,t:1528143789561};\\\", \\\"{x:1187,y:726,t:1528143789578};\\\", \\\"{x:1186,y:726,t:1528143789632};\\\", \\\"{x:1186,y:724,t:1528143789643};\\\", \\\"{x:1184,y:722,t:1528143789661};\\\", \\\"{x:1183,y:721,t:1528143789677};\\\", \\\"{x:1182,y:720,t:1528143789693};\\\", \\\"{x:1182,y:719,t:1528143789768};\\\", \\\"{x:1181,y:718,t:1528143791385};\\\", \\\"{x:1182,y:718,t:1528143791889};\\\", \\\"{x:1184,y:719,t:1528143791904};\\\", \\\"{x:1184,y:728,t:1528143791937};\\\", \\\"{x:1184,y:742,t:1528143791945};\\\", \\\"{x:1175,y:768,t:1528143791962};\\\", \\\"{x:1157,y:797,t:1528143791979};\\\", \\\"{x:1139,y:816,t:1528143791995};\\\", \\\"{x:1121,y:834,t:1528143792012};\\\", \\\"{x:1105,y:849,t:1528143792029};\\\", \\\"{x:1094,y:864,t:1528143792046};\\\", \\\"{x:1083,y:881,t:1528143792063};\\\", \\\"{x:1075,y:901,t:1528143792078};\\\", \\\"{x:1072,y:916,t:1528143792096};\\\", \\\"{x:1069,y:933,t:1528143792114};\\\", \\\"{x:1068,y:940,t:1528143792129};\\\", \\\"{x:1067,y:945,t:1528143792145};\\\", \\\"{x:1067,y:948,t:1528143792163};\\\", \\\"{x:1066,y:949,t:1528143792178};\\\", \\\"{x:1066,y:946,t:1528143792281};\\\", \\\"{x:1066,y:932,t:1528143792295};\\\", \\\"{x:1066,y:872,t:1528143792313};\\\", \\\"{x:1075,y:833,t:1528143792329};\\\", \\\"{x:1085,y:802,t:1528143792345};\\\", \\\"{x:1099,y:776,t:1528143792363};\\\", \\\"{x:1114,y:755,t:1528143792378};\\\", \\\"{x:1125,y:740,t:1528143792395};\\\", \\\"{x:1133,y:728,t:1528143792412};\\\", \\\"{x:1141,y:717,t:1528143792429};\\\", \\\"{x:1144,y:713,t:1528143792445};\\\", \\\"{x:1146,y:708,t:1528143792462};\\\", \\\"{x:1146,y:706,t:1528143792479};\\\", \\\"{x:1148,y:704,t:1528143792496};\\\", \\\"{x:1151,y:701,t:1528143792513};\\\", \\\"{x:1152,y:699,t:1528143792529};\\\", \\\"{x:1154,y:699,t:1528143792546};\\\", \\\"{x:1155,y:699,t:1528143792568};\\\", \\\"{x:1156,y:699,t:1528143792593};\\\", \\\"{x:1157,y:699,t:1528143792608};\\\", \\\"{x:1158,y:699,t:1528143792649};\\\", \\\"{x:1159,y:699,t:1528143792663};\\\", \\\"{x:1161,y:699,t:1528143792680};\\\", \\\"{x:1166,y:699,t:1528143792695};\\\", \\\"{x:1167,y:699,t:1528143792712};\\\", \\\"{x:1168,y:699,t:1528143792969};\\\", \\\"{x:1169,y:699,t:1528143794577};\\\", \\\"{x:1170,y:699,t:1528143794857};\\\", \\\"{x:1171,y:699,t:1528143794889};\\\", \\\"{x:1172,y:699,t:1528143795305};\\\", \\\"{x:1169,y:698,t:1528143795945};\\\", \\\"{x:1167,y:698,t:1528143795952};\\\", \\\"{x:1167,y:697,t:1528143795992};\\\", \\\"{x:1170,y:697,t:1528143796561};\\\", \\\"{x:1171,y:697,t:1528143796568};\\\", \\\"{x:1172,y:698,t:1528143796582};\\\", \\\"{x:1175,y:699,t:1528143796598};\\\", \\\"{x:1179,y:701,t:1528143796616};\\\", \\\"{x:1181,y:701,t:1528143796633};\\\", \\\"{x:1184,y:701,t:1528143796648};\\\", \\\"{x:1186,y:702,t:1528143796665};\\\", \\\"{x:1187,y:703,t:1528143796681};\\\", \\\"{x:1189,y:703,t:1528143796719};\\\", \\\"{x:1192,y:703,t:1528143796732};\\\", \\\"{x:1192,y:702,t:1528143796748};\\\", \\\"{x:1194,y:702,t:1528143796765};\\\", \\\"{x:1194,y:703,t:1528143796799};\\\", \\\"{x:1195,y:706,t:1528143796815};\\\", \\\"{x:1196,y:714,t:1528143796831};\\\", \\\"{x:1196,y:721,t:1528143796848};\\\", \\\"{x:1196,y:729,t:1528143796865};\\\", \\\"{x:1196,y:740,t:1528143796882};\\\", \\\"{x:1196,y:753,t:1528143796898};\\\", \\\"{x:1195,y:764,t:1528143796915};\\\", \\\"{x:1194,y:779,t:1528143796932};\\\", \\\"{x:1194,y:787,t:1528143796949};\\\", \\\"{x:1194,y:788,t:1528143796965};\\\", \\\"{x:1193,y:789,t:1528143797008};\\\", \\\"{x:1192,y:789,t:1528143797016};\\\", \\\"{x:1190,y:789,t:1528143797033};\\\", \\\"{x:1187,y:787,t:1528143797049};\\\", \\\"{x:1187,y:784,t:1528143797066};\\\", \\\"{x:1183,y:779,t:1528143797082};\\\", \\\"{x:1183,y:776,t:1528143797099};\\\", \\\"{x:1180,y:769,t:1528143797115};\\\", \\\"{x:1179,y:759,t:1528143797133};\\\", \\\"{x:1175,y:740,t:1528143797149};\\\", \\\"{x:1175,y:724,t:1528143797166};\\\", \\\"{x:1175,y:707,t:1528143797183};\\\", \\\"{x:1175,y:696,t:1528143797198};\\\", \\\"{x:1178,y:687,t:1528143797216};\\\", \\\"{x:1179,y:682,t:1528143797231};\\\", \\\"{x:1180,y:681,t:1528143797311};\\\", \\\"{x:1180,y:683,t:1528143797328};\\\", \\\"{x:1180,y:690,t:1528143797335};\\\", \\\"{x:1180,y:701,t:1528143797350};\\\", \\\"{x:1178,y:727,t:1528143797365};\\\", \\\"{x:1169,y:759,t:1528143797382};\\\", \\\"{x:1155,y:812,t:1528143797399};\\\", \\\"{x:1138,y:868,t:1528143797416};\\\", \\\"{x:1111,y:957,t:1528143797432};\\\", \\\"{x:1085,y:1020,t:1528143797450};\\\", \\\"{x:1059,y:1081,t:1528143797466};\\\", \\\"{x:1027,y:1093,t:1528143797609};\\\", \\\"{x:1029,y:1075,t:1528143797618};\\\", \\\"{x:1041,y:1033,t:1528143797632};\\\", \\\"{x:1062,y:993,t:1528143797650};\\\", \\\"{x:1082,y:962,t:1528143797666};\\\", \\\"{x:1106,y:933,t:1528143797683};\\\", \\\"{x:1131,y:903,t:1528143797699};\\\", \\\"{x:1152,y:878,t:1528143797716};\\\", \\\"{x:1167,y:856,t:1528143797733};\\\", \\\"{x:1175,y:841,t:1528143797749};\\\", \\\"{x:1180,y:829,t:1528143797766};\\\", \\\"{x:1185,y:817,t:1528143797782};\\\", \\\"{x:1190,y:805,t:1528143797800};\\\", \\\"{x:1196,y:793,t:1528143797816};\\\", \\\"{x:1198,y:786,t:1528143797833};\\\", \\\"{x:1198,y:783,t:1528143797849};\\\", \\\"{x:1199,y:779,t:1528143797866};\\\", \\\"{x:1199,y:775,t:1528143797882};\\\", \\\"{x:1199,y:772,t:1528143797899};\\\", \\\"{x:1199,y:769,t:1528143797916};\\\", \\\"{x:1199,y:766,t:1528143797932};\\\", \\\"{x:1199,y:764,t:1528143797949};\\\", \\\"{x:1199,y:763,t:1528143797965};\\\", \\\"{x:1199,y:762,t:1528143797982};\\\", \\\"{x:1199,y:760,t:1528143798000};\\\", \\\"{x:1199,y:759,t:1528143798016};\\\", \\\"{x:1199,y:756,t:1528143798033};\\\", \\\"{x:1199,y:755,t:1528143798049};\\\", \\\"{x:1199,y:753,t:1528143798066};\\\", \\\"{x:1199,y:750,t:1528143798082};\\\", \\\"{x:1199,y:747,t:1528143798099};\\\", \\\"{x:1199,y:744,t:1528143798116};\\\", \\\"{x:1199,y:743,t:1528143798133};\\\", \\\"{x:1198,y:741,t:1528143798149};\\\", \\\"{x:1198,y:739,t:1528143798166};\\\", \\\"{x:1198,y:737,t:1528143798181};\\\", \\\"{x:1198,y:735,t:1528143798198};\\\", \\\"{x:1198,y:734,t:1528143798216};\\\", \\\"{x:1197,y:733,t:1528143798232};\\\", \\\"{x:1197,y:731,t:1528143798249};\\\", \\\"{x:1196,y:731,t:1528143798265};\\\", \\\"{x:1196,y:730,t:1528143798282};\\\", \\\"{x:1195,y:730,t:1528143798304};\\\", \\\"{x:1194,y:729,t:1528143798337};\\\", \\\"{x:1194,y:728,t:1528143798349};\\\", \\\"{x:1193,y:728,t:1528143798364};\\\", \\\"{x:1192,y:728,t:1528143798384};\\\", \\\"{x:1190,y:727,t:1528143798399};\\\", \\\"{x:1189,y:727,t:1528143798417};\\\", \\\"{x:1187,y:726,t:1528143798449};\\\", \\\"{x:1186,y:726,t:1528143798480};\\\", \\\"{x:1185,y:726,t:1528143798705};\\\", \\\"{x:1190,y:729,t:1528143798714};\\\", \\\"{x:1211,y:735,t:1528143798731};\\\", \\\"{x:1242,y:738,t:1528143798748};\\\", \\\"{x:1272,y:738,t:1528143798764};\\\", \\\"{x:1299,y:738,t:1528143798781};\\\", \\\"{x:1321,y:738,t:1528143798798};\\\", \\\"{x:1330,y:737,t:1528143798813};\\\", \\\"{x:1333,y:734,t:1528143798831};\\\", \\\"{x:1334,y:733,t:1528143798847};\\\", \\\"{x:1336,y:731,t:1528143798864};\\\", \\\"{x:1343,y:730,t:1528143798881};\\\", \\\"{x:1354,y:727,t:1528143798897};\\\", \\\"{x:1361,y:723,t:1528143798914};\\\", \\\"{x:1365,y:722,t:1528143798931};\\\", \\\"{x:1365,y:721,t:1528143798960};\\\", \\\"{x:1365,y:720,t:1528143798968};\\\", \\\"{x:1365,y:719,t:1528143798980};\\\", \\\"{x:1365,y:717,t:1528143799001};\\\", \\\"{x:1365,y:716,t:1528143799013};\\\", \\\"{x:1364,y:715,t:1528143799030};\\\", \\\"{x:1361,y:713,t:1528143799046};\\\", \\\"{x:1359,y:712,t:1528143799064};\\\", \\\"{x:1358,y:712,t:1528143799104};\\\", \\\"{x:1357,y:712,t:1528143799120};\\\", \\\"{x:1355,y:711,t:1528143799129};\\\", \\\"{x:1354,y:711,t:1528143799146};\\\", \\\"{x:1353,y:710,t:1528143799164};\\\", \\\"{x:1351,y:710,t:1528143799179};\\\", \\\"{x:1350,y:710,t:1528143800913};\\\", \\\"{x:1347,y:713,t:1528143801032};\\\", \\\"{x:1341,y:720,t:1528143801042};\\\", \\\"{x:1313,y:733,t:1528143801057};\\\", \\\"{x:1248,y:756,t:1528143801074};\\\", \\\"{x:1150,y:778,t:1528143801091};\\\", \\\"{x:1038,y:796,t:1528143801107};\\\", \\\"{x:944,y:810,t:1528143801124};\\\", \\\"{x:919,y:811,t:1528143801141};\\\", \\\"{x:901,y:811,t:1528143801157};\\\", \\\"{x:892,y:811,t:1528143801174};\\\", \\\"{x:891,y:809,t:1528143801190};\\\", \\\"{x:891,y:808,t:1528143801215};\\\", \\\"{x:891,y:806,t:1528143801223};\\\", \\\"{x:898,y:802,t:1528143801240};\\\", \\\"{x:914,y:795,t:1528143801257};\\\", \\\"{x:942,y:788,t:1528143801274};\\\", \\\"{x:992,y:773,t:1528143801290};\\\", \\\"{x:1058,y:754,t:1528143801307};\\\", \\\"{x:1113,y:741,t:1528143801323};\\\", \\\"{x:1152,y:731,t:1528143801340};\\\", \\\"{x:1166,y:726,t:1528143801358};\\\", \\\"{x:1167,y:726,t:1528143801374};\\\", \\\"{x:1168,y:725,t:1528143801426};\\\", \\\"{x:1168,y:724,t:1528143801481};\\\", \\\"{x:1168,y:723,t:1528143801491};\\\", \\\"{x:1168,y:721,t:1528143801507};\\\", \\\"{x:1169,y:719,t:1528143801523};\\\", \\\"{x:1169,y:720,t:1528143801657};\\\", \\\"{x:1168,y:732,t:1528143801674};\\\", \\\"{x:1168,y:746,t:1528143801690};\\\", \\\"{x:1170,y:760,t:1528143801707};\\\", \\\"{x:1179,y:772,t:1528143801723};\\\", \\\"{x:1193,y:785,t:1528143801740};\\\", \\\"{x:1212,y:799,t:1528143801757};\\\", \\\"{x:1234,y:811,t:1528143801773};\\\", \\\"{x:1257,y:821,t:1528143801790};\\\", \\\"{x:1276,y:829,t:1528143801807};\\\", \\\"{x:1287,y:836,t:1528143801823};\\\", \\\"{x:1292,y:839,t:1528143801839};\\\", \\\"{x:1296,y:843,t:1528143801856};\\\", \\\"{x:1297,y:847,t:1528143801873};\\\", \\\"{x:1299,y:850,t:1528143801889};\\\", \\\"{x:1300,y:853,t:1528143801906};\\\", \\\"{x:1301,y:857,t:1528143801922};\\\", \\\"{x:1303,y:861,t:1528143801940};\\\", \\\"{x:1305,y:869,t:1528143801955};\\\", \\\"{x:1308,y:880,t:1528143801973};\\\", \\\"{x:1310,y:889,t:1528143801989};\\\", \\\"{x:1312,y:898,t:1528143802006};\\\", \\\"{x:1313,y:907,t:1528143802022};\\\", \\\"{x:1314,y:914,t:1528143802039};\\\", \\\"{x:1314,y:919,t:1528143802056};\\\", \\\"{x:1314,y:927,t:1528143802072};\\\", \\\"{x:1314,y:931,t:1528143802089};\\\", \\\"{x:1314,y:933,t:1528143802105};\\\", \\\"{x:1314,y:934,t:1528143802122};\\\", \\\"{x:1314,y:936,t:1528143802139};\\\", \\\"{x:1314,y:937,t:1528143802384};\\\", \\\"{x:1313,y:937,t:1528143802601};\\\", \\\"{x:1312,y:936,t:1528143802608};\\\", \\\"{x:1311,y:935,t:1528143802632};\\\", \\\"{x:1310,y:934,t:1528143802672};\\\", \\\"{x:1310,y:933,t:1528143802889};\\\", \\\"{x:1309,y:932,t:1528143802921};\\\", \\\"{x:1308,y:930,t:1528143802944};\\\", \\\"{x:1306,y:927,t:1528143802961};\\\", \\\"{x:1304,y:925,t:1528143802970};\\\", \\\"{x:1302,y:922,t:1528143802987};\\\", \\\"{x:1301,y:919,t:1528143803004};\\\", \\\"{x:1300,y:915,t:1528143803021};\\\", \\\"{x:1298,y:910,t:1528143803038};\\\", \\\"{x:1298,y:903,t:1528143803053};\\\", \\\"{x:1297,y:894,t:1528143803070};\\\", \\\"{x:1297,y:883,t:1528143803086};\\\", \\\"{x:1297,y:869,t:1528143803103};\\\", \\\"{x:1297,y:856,t:1528143803120};\\\", \\\"{x:1301,y:839,t:1528143803136};\\\", \\\"{x:1317,y:818,t:1528143803153};\\\", \\\"{x:1333,y:809,t:1528143803170};\\\", \\\"{x:1346,y:801,t:1528143803186};\\\", \\\"{x:1357,y:794,t:1528143803203};\\\", \\\"{x:1360,y:792,t:1528143803220};\\\", \\\"{x:1361,y:789,t:1528143803236};\\\", \\\"{x:1361,y:787,t:1528143803253};\\\", \\\"{x:1362,y:785,t:1528143803269};\\\", \\\"{x:1362,y:783,t:1528143803286};\\\", \\\"{x:1362,y:782,t:1528143803329};\\\", \\\"{x:1362,y:781,t:1528143803377};\\\", \\\"{x:1361,y:780,t:1528143803386};\\\", \\\"{x:1360,y:780,t:1528143803402};\\\", \\\"{x:1359,y:780,t:1528143803419};\\\", \\\"{x:1358,y:780,t:1528143803436};\\\", \\\"{x:1357,y:779,t:1528143803452};\\\", \\\"{x:1356,y:779,t:1528143803561};\\\", \\\"{x:1355,y:779,t:1528143803569};\\\", \\\"{x:1352,y:779,t:1528143803585};\\\", \\\"{x:1349,y:781,t:1528143803602};\\\", \\\"{x:1346,y:782,t:1528143803619};\\\", \\\"{x:1343,y:784,t:1528143803635};\\\", \\\"{x:1342,y:785,t:1528143803657};\\\", \\\"{x:1341,y:785,t:1528143803668};\\\", \\\"{x:1340,y:786,t:1528143803685};\\\", \\\"{x:1339,y:787,t:1528143803702};\\\", \\\"{x:1339,y:788,t:1528143803718};\\\", \\\"{x:1338,y:788,t:1528143803735};\\\", \\\"{x:1337,y:788,t:1528143803752};\\\", \\\"{x:1336,y:789,t:1528143803801};\\\", \\\"{x:1330,y:789,t:1528143803818};\\\", \\\"{x:1317,y:788,t:1528143803835};\\\", \\\"{x:1307,y:787,t:1528143803851};\\\", \\\"{x:1293,y:783,t:1528143803868};\\\", \\\"{x:1271,y:771,t:1528143803885};\\\", \\\"{x:1221,y:746,t:1528143803901};\\\", \\\"{x:1188,y:735,t:1528143803918};\\\", \\\"{x:1166,y:731,t:1528143803934};\\\", \\\"{x:1158,y:731,t:1528143803951};\\\", \\\"{x:1143,y:735,t:1528143803968};\\\", \\\"{x:1131,y:738,t:1528143803984};\\\", \\\"{x:1047,y:760,t:1528143804000};\\\", \\\"{x:945,y:772,t:1528143804018};\\\", \\\"{x:833,y:780,t:1528143804034};\\\", \\\"{x:719,y:780,t:1528143804050};\\\", \\\"{x:615,y:775,t:1528143804066};\\\", \\\"{x:526,y:762,t:1528143804083};\\\", \\\"{x:463,y:746,t:1528143804100};\\\", \\\"{x:425,y:731,t:1528143804116};\\\", \\\"{x:395,y:711,t:1528143804134};\\\", \\\"{x:373,y:686,t:1528143804151};\\\", \\\"{x:353,y:663,t:1528143804166};\\\", \\\"{x:319,y:613,t:1528143804184};\\\", \\\"{x:295,y:581,t:1528143804199};\\\", \\\"{x:279,y:558,t:1528143804217};\\\", \\\"{x:272,y:547,t:1528143804239};\\\", \\\"{x:272,y:546,t:1528143804288};\\\", \\\"{x:276,y:542,t:1528143804295};\\\", \\\"{x:282,y:539,t:1528143804305};\\\", \\\"{x:292,y:532,t:1528143804322};\\\", \\\"{x:298,y:529,t:1528143804339};\\\", \\\"{x:318,y:524,t:1528143804355};\\\", \\\"{x:332,y:522,t:1528143804372};\\\", \\\"{x:343,y:522,t:1528143804388};\\\", \\\"{x:354,y:522,t:1528143804406};\\\", \\\"{x:359,y:522,t:1528143804422};\\\", \\\"{x:365,y:525,t:1528143804438};\\\", \\\"{x:370,y:526,t:1528143804456};\\\", \\\"{x:371,y:527,t:1528143804473};\\\", \\\"{x:373,y:527,t:1528143804488};\\\", \\\"{x:374,y:528,t:1528143804506};\\\", \\\"{x:376,y:528,t:1528143804522};\\\", \\\"{x:377,y:528,t:1528143804560};\\\", \\\"{x:377,y:527,t:1528143804584};\\\", \\\"{x:377,y:523,t:1528143804592};\\\", \\\"{x:377,y:519,t:1528143804606};\\\", \\\"{x:379,y:504,t:1528143804623};\\\", \\\"{x:383,y:481,t:1528143804640};\\\", \\\"{x:387,y:468,t:1528143804655};\\\", \\\"{x:389,y:462,t:1528143804673};\\\", \\\"{x:390,y:458,t:1528143804689};\\\", \\\"{x:390,y:456,t:1528143804705};\\\", \\\"{x:391,y:455,t:1528143804722};\\\", \\\"{x:384,y:455,t:1528143804904};\\\", \\\"{x:372,y:455,t:1528143804912};\\\", \\\"{x:357,y:455,t:1528143804922};\\\", \\\"{x:313,y:455,t:1528143804939};\\\", \\\"{x:274,y:455,t:1528143804957};\\\", \\\"{x:249,y:456,t:1528143804973};\\\", \\\"{x:238,y:459,t:1528143804990};\\\", \\\"{x:233,y:460,t:1528143805007};\\\", \\\"{x:232,y:460,t:1528143805064};\\\", \\\"{x:231,y:460,t:1528143805073};\\\", \\\"{x:230,y:460,t:1528143805090};\\\", \\\"{x:229,y:460,t:1528143805106};\\\", \\\"{x:228,y:460,t:1528143805123};\\\", \\\"{x:224,y:458,t:1528143805140};\\\", \\\"{x:222,y:454,t:1528143805157};\\\", \\\"{x:219,y:451,t:1528143805173};\\\", \\\"{x:218,y:449,t:1528143805189};\\\", \\\"{x:216,y:449,t:1528143805207};\\\", \\\"{x:215,y:449,t:1528143805264};\\\", \\\"{x:214,y:449,t:1528143805280};\\\", \\\"{x:213,y:449,t:1528143805296};\\\", \\\"{x:212,y:448,t:1528143805320};\\\", \\\"{x:210,y:448,t:1528143805328};\\\", \\\"{x:209,y:448,t:1528143805344};\\\", \\\"{x:208,y:448,t:1528143805356};\\\", \\\"{x:204,y:448,t:1528143805374};\\\", \\\"{x:200,y:448,t:1528143805390};\\\", \\\"{x:197,y:448,t:1528143805406};\\\", \\\"{x:193,y:448,t:1528143805424};\\\", \\\"{x:193,y:447,t:1528143805440};\\\", \\\"{x:192,y:446,t:1528143805456};\\\", \\\"{x:191,y:446,t:1528143805474};\\\", \\\"{x:189,y:446,t:1528143805489};\\\", \\\"{x:186,y:445,t:1528143805508};\\\", \\\"{x:184,y:445,t:1528143805524};\\\", \\\"{x:183,y:445,t:1528143805539};\\\", \\\"{x:182,y:445,t:1528143805556};\\\", \\\"{x:190,y:450,t:1528143805922};\\\", \\\"{x:239,y:471,t:1528143805941};\\\", \\\"{x:300,y:499,t:1528143805956};\\\", \\\"{x:351,y:518,t:1528143805973};\\\", \\\"{x:382,y:531,t:1528143805991};\\\", \\\"{x:404,y:542,t:1528143806007};\\\", \\\"{x:431,y:563,t:1528143806023};\\\", \\\"{x:454,y:581,t:1528143806040};\\\", \\\"{x:475,y:598,t:1528143806057};\\\", \\\"{x:487,y:610,t:1528143806073};\\\", \\\"{x:490,y:615,t:1528143806090};\\\", \\\"{x:491,y:617,t:1528143806108};\\\", \\\"{x:489,y:620,t:1528143806136};\\\", \\\"{x:488,y:622,t:1528143806143};\\\", \\\"{x:487,y:624,t:1528143806157};\\\", \\\"{x:483,y:633,t:1528143806173};\\\", \\\"{x:478,y:646,t:1528143806191};\\\", \\\"{x:478,y:674,t:1528143806209};\\\", \\\"{x:478,y:682,t:1528143806223};\\\", \\\"{x:482,y:694,t:1528143806240};\\\", \\\"{x:491,y:707,t:1528143806258};\\\", \\\"{x:498,y:716,t:1528143806273};\\\", \\\"{x:502,y:721,t:1528143806291};\\\", \\\"{x:503,y:722,t:1528143806308};\\\", \\\"{x:504,y:722,t:1528143806408};\\\", \\\"{x:504,y:720,t:1528143806426};\\\", \\\"{x:502,y:713,t:1528143806441};\\\", \\\"{x:501,y:704,t:1528143806458};\\\", \\\"{x:499,y:694,t:1528143806475};\\\", \\\"{x:498,y:685,t:1528143806490};\\\", \\\"{x:498,y:680,t:1528143806507};\\\", \\\"{x:498,y:678,t:1528143806524};\\\", \\\"{x:498,y:676,t:1528143806540};\\\", \\\"{x:498,y:678,t:1528143806823};\\\", \\\"{x:501,y:679,t:1528143806840};\\\", \\\"{x:506,y:683,t:1528143806858};\\\", \\\"{x:510,y:684,t:1528143806874};\\\", \\\"{x:514,y:687,t:1528143806891};\\\", \\\"{x:525,y:694,t:1528143806908};\\\", \\\"{x:574,y:725,t:1528143806924};\\\", \\\"{x:635,y:751,t:1528143806940};\\\", \\\"{x:680,y:772,t:1528143806958};\\\", \\\"{x:707,y:785,t:1528143806974};\\\", \\\"{x:726,y:793,t:1528143806990};\\\", \\\"{x:736,y:800,t:1528143807008};\\\", \\\"{x:738,y:803,t:1528143807024};\\\", \\\"{x:746,y:807,t:1528143807040};\\\", \\\"{x:750,y:808,t:1528143807058};\\\" ] }, { \\\"rt\\\": 16706, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 345977, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"8182H\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-D -B -F -02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:741,y:806,t:1528143810632};\\\", \\\"{x:724,y:800,t:1528143810644};\\\", \\\"{x:664,y:774,t:1528143810661};\\\", \\\"{x:600,y:746,t:1528143810678};\\\", \\\"{x:536,y:717,t:1528143810694};\\\", \\\"{x:452,y:687,t:1528143810713};\\\", \\\"{x:324,y:630,t:1528143810728};\\\", \\\"{x:284,y:613,t:1528143810744};\\\", \\\"{x:269,y:608,t:1528143810761};\\\", \\\"{x:266,y:607,t:1528143810777};\\\", \\\"{x:266,y:606,t:1528143810872};\\\", \\\"{x:274,y:599,t:1528143810879};\\\", \\\"{x:298,y:576,t:1528143810894};\\\", \\\"{x:377,y:498,t:1528143810911};\\\", \\\"{x:534,y:397,t:1528143810927};\\\", \\\"{x:673,y:354,t:1528143810945};\\\", \\\"{x:787,y:333,t:1528143810961};\\\", \\\"{x:841,y:324,t:1528143810978};\\\", \\\"{x:852,y:320,t:1528143810993};\\\", \\\"{x:853,y:319,t:1528143811064};\\\", \\\"{x:853,y:318,t:1528143811078};\\\", \\\"{x:853,y:313,t:1528143811095};\\\", \\\"{x:853,y:311,t:1528143811111};\\\", \\\"{x:853,y:309,t:1528143811128};\\\", \\\"{x:853,y:310,t:1528143811191};\\\", \\\"{x:853,y:314,t:1528143811199};\\\", \\\"{x:852,y:322,t:1528143811211};\\\", \\\"{x:849,y:350,t:1528143811227};\\\", \\\"{x:847,y:385,t:1528143811245};\\\", \\\"{x:857,y:452,t:1528143811261};\\\", \\\"{x:909,y:560,t:1528143811278};\\\", \\\"{x:991,y:652,t:1528143811295};\\\", \\\"{x:1127,y:752,t:1528143811311};\\\", \\\"{x:1183,y:777,t:1528143811327};\\\", \\\"{x:1201,y:785,t:1528143811345};\\\", \\\"{x:1204,y:785,t:1528143811367};\\\", \\\"{x:1205,y:785,t:1528143811384};\\\", \\\"{x:1202,y:785,t:1528143811465};\\\", \\\"{x:1199,y:785,t:1528143811478};\\\", \\\"{x:1196,y:785,t:1528143811495};\\\", \\\"{x:1138,y:797,t:1528143811512};\\\", \\\"{x:1082,y:805,t:1528143811527};\\\", \\\"{x:1054,y:806,t:1528143811545};\\\", \\\"{x:1030,y:806,t:1528143811562};\\\", \\\"{x:1005,y:806,t:1528143811578};\\\", \\\"{x:981,y:800,t:1528143811595};\\\", \\\"{x:960,y:794,t:1528143811612};\\\", \\\"{x:943,y:789,t:1528143811628};\\\", \\\"{x:922,y:783,t:1528143811645};\\\", \\\"{x:910,y:780,t:1528143811661};\\\", \\\"{x:907,y:777,t:1528143811677};\\\", \\\"{x:903,y:776,t:1528143811695};\\\", \\\"{x:900,y:774,t:1528143811711};\\\", \\\"{x:899,y:772,t:1528143811728};\\\", \\\"{x:898,y:771,t:1528143811751};\\\", \\\"{x:903,y:768,t:1528143812512};\\\", \\\"{x:928,y:761,t:1528143812529};\\\", \\\"{x:954,y:754,t:1528143812546};\\\", \\\"{x:990,y:749,t:1528143812561};\\\", \\\"{x:1022,y:743,t:1528143812579};\\\", \\\"{x:1060,y:737,t:1528143812596};\\\", \\\"{x:1095,y:732,t:1528143812612};\\\", \\\"{x:1122,y:729,t:1528143812629};\\\", \\\"{x:1151,y:719,t:1528143812646};\\\", \\\"{x:1174,y:713,t:1528143812662};\\\", \\\"{x:1198,y:705,t:1528143812679};\\\", \\\"{x:1229,y:690,t:1528143812695};\\\", \\\"{x:1248,y:686,t:1528143812713};\\\", \\\"{x:1274,y:679,t:1528143812728};\\\", \\\"{x:1318,y:667,t:1528143812745};\\\", \\\"{x:1356,y:660,t:1528143812763};\\\", \\\"{x:1383,y:658,t:1528143812779};\\\", \\\"{x:1407,y:653,t:1528143812796};\\\", \\\"{x:1430,y:653,t:1528143812813};\\\", \\\"{x:1458,y:649,t:1528143812829};\\\", \\\"{x:1473,y:647,t:1528143812846};\\\", \\\"{x:1483,y:644,t:1528143812863};\\\", \\\"{x:1486,y:643,t:1528143812879};\\\", \\\"{x:1487,y:643,t:1528143812896};\\\", \\\"{x:1487,y:642,t:1528143813145};\\\", \\\"{x:1487,y:641,t:1528143813288};\\\", \\\"{x:1487,y:640,t:1528143813295};\\\", \\\"{x:1487,y:636,t:1528143813313};\\\", \\\"{x:1487,y:632,t:1528143813330};\\\", \\\"{x:1489,y:631,t:1528143813346};\\\", \\\"{x:1489,y:629,t:1528143813363};\\\", \\\"{x:1489,y:627,t:1528143813380};\\\", \\\"{x:1489,y:626,t:1528143813522};\\\", \\\"{x:1490,y:625,t:1528143813531};\\\", \\\"{x:1493,y:620,t:1528143813547};\\\", \\\"{x:1495,y:616,t:1528143813562};\\\", \\\"{x:1499,y:610,t:1528143813580};\\\", \\\"{x:1507,y:596,t:1528143813595};\\\", \\\"{x:1517,y:581,t:1528143813613};\\\", \\\"{x:1529,y:557,t:1528143813630};\\\", \\\"{x:1541,y:529,t:1528143813646};\\\", \\\"{x:1547,y:508,t:1528143813663};\\\", \\\"{x:1563,y:481,t:1528143813680};\\\", \\\"{x:1573,y:467,t:1528143813695};\\\", \\\"{x:1585,y:453,t:1528143813713};\\\", \\\"{x:1592,y:445,t:1528143813730};\\\", \\\"{x:1598,y:441,t:1528143813747};\\\", \\\"{x:1601,y:439,t:1528143813763};\\\", \\\"{x:1602,y:439,t:1528143813780};\\\", \\\"{x:1603,y:439,t:1528143813800};\\\", \\\"{x:1604,y:439,t:1528143813813};\\\", \\\"{x:1613,y:441,t:1528143813830};\\\", \\\"{x:1627,y:462,t:1528143813848};\\\", \\\"{x:1645,y:490,t:1528143813863};\\\", \\\"{x:1678,y:558,t:1528143813880};\\\", \\\"{x:1702,y:614,t:1528143813897};\\\", \\\"{x:1722,y:670,t:1528143813914};\\\", \\\"{x:1734,y:717,t:1528143813930};\\\", \\\"{x:1744,y:751,t:1528143813947};\\\", \\\"{x:1749,y:773,t:1528143813966};\\\", \\\"{x:1751,y:797,t:1528143813981};\\\", \\\"{x:1756,y:820,t:1528143813997};\\\", \\\"{x:1758,y:848,t:1528143814013};\\\", \\\"{x:1760,y:872,t:1528143814030};\\\", \\\"{x:1760,y:889,t:1528143814047};\\\", \\\"{x:1760,y:897,t:1528143814063};\\\", \\\"{x:1760,y:898,t:1528143814080};\\\", \\\"{x:1759,y:898,t:1528143814160};\\\", \\\"{x:1754,y:898,t:1528143814168};\\\", \\\"{x:1749,y:898,t:1528143814180};\\\", \\\"{x:1735,y:898,t:1528143814197};\\\", \\\"{x:1720,y:898,t:1528143814214};\\\", \\\"{x:1702,y:896,t:1528143814230};\\\", \\\"{x:1680,y:894,t:1528143814247};\\\", \\\"{x:1649,y:889,t:1528143814264};\\\", \\\"{x:1634,y:884,t:1528143814280};\\\", \\\"{x:1622,y:880,t:1528143814297};\\\", \\\"{x:1614,y:878,t:1528143814314};\\\", \\\"{x:1610,y:877,t:1528143814330};\\\", \\\"{x:1606,y:875,t:1528143814348};\\\", \\\"{x:1601,y:873,t:1528143814364};\\\", \\\"{x:1595,y:871,t:1528143814380};\\\", \\\"{x:1591,y:869,t:1528143814398};\\\", \\\"{x:1580,y:864,t:1528143814415};\\\", \\\"{x:1573,y:862,t:1528143814430};\\\", \\\"{x:1562,y:859,t:1528143814448};\\\", \\\"{x:1549,y:858,t:1528143814465};\\\", \\\"{x:1542,y:856,t:1528143814481};\\\", \\\"{x:1539,y:855,t:1528143814497};\\\", \\\"{x:1536,y:855,t:1528143814515};\\\", \\\"{x:1535,y:854,t:1528143814536};\\\", \\\"{x:1534,y:854,t:1528143814552};\\\", \\\"{x:1533,y:854,t:1528143814564};\\\", \\\"{x:1532,y:854,t:1528143814585};\\\", \\\"{x:1531,y:854,t:1528143814597};\\\", \\\"{x:1529,y:854,t:1528143814615};\\\", \\\"{x:1525,y:854,t:1528143814631};\\\", \\\"{x:1521,y:854,t:1528143814648};\\\", \\\"{x:1515,y:854,t:1528143814664};\\\", \\\"{x:1510,y:854,t:1528143814681};\\\", \\\"{x:1505,y:854,t:1528143814697};\\\", \\\"{x:1503,y:854,t:1528143814714};\\\", \\\"{x:1489,y:854,t:1528143814731};\\\", \\\"{x:1477,y:852,t:1528143814747};\\\", \\\"{x:1470,y:852,t:1528143814764};\\\", \\\"{x:1464,y:851,t:1528143814781};\\\", \\\"{x:1459,y:850,t:1528143814797};\\\", \\\"{x:1453,y:849,t:1528143814815};\\\", \\\"{x:1449,y:848,t:1528143814832};\\\", \\\"{x:1449,y:847,t:1528143814881};\\\", \\\"{x:1448,y:844,t:1528143814905};\\\", \\\"{x:1447,y:839,t:1528143814915};\\\", \\\"{x:1443,y:823,t:1528143814932};\\\", \\\"{x:1435,y:804,t:1528143814948};\\\", \\\"{x:1384,y:757,t:1528143814964};\\\", \\\"{x:1355,y:713,t:1528143814982};\\\", \\\"{x:1354,y:710,t:1528143814999};\\\", \\\"{x:1353,y:710,t:1528143815017};\\\", \\\"{x:1350,y:709,t:1528143815032};\\\", \\\"{x:1334,y:703,t:1528143815050};\\\", \\\"{x:1330,y:702,t:1528143815064};\\\", \\\"{x:1322,y:699,t:1528143815081};\\\", \\\"{x:1318,y:698,t:1528143815098};\\\", \\\"{x:1317,y:696,t:1528143815115};\\\", \\\"{x:1317,y:692,t:1528143815217};\\\", \\\"{x:1320,y:686,t:1528143815231};\\\", \\\"{x:1328,y:674,t:1528143815249};\\\", \\\"{x:1333,y:668,t:1528143815265};\\\", \\\"{x:1340,y:664,t:1528143815282};\\\", \\\"{x:1346,y:659,t:1528143815299};\\\", \\\"{x:1352,y:656,t:1528143815315};\\\", \\\"{x:1357,y:653,t:1528143815332};\\\", \\\"{x:1359,y:649,t:1528143815349};\\\", \\\"{x:1361,y:648,t:1528143815365};\\\", \\\"{x:1361,y:647,t:1528143815617};\\\", \\\"{x:1360,y:647,t:1528143815633};\\\", \\\"{x:1359,y:647,t:1528143815648};\\\", \\\"{x:1358,y:647,t:1528143815665};\\\", \\\"{x:1357,y:646,t:1528143815682};\\\", \\\"{x:1356,y:646,t:1528143815704};\\\", \\\"{x:1353,y:645,t:1528143815715};\\\", \\\"{x:1350,y:645,t:1528143815730};\\\", \\\"{x:1346,y:645,t:1528143815748};\\\", \\\"{x:1344,y:645,t:1528143815765};\\\", \\\"{x:1342,y:645,t:1528143815780};\\\", \\\"{x:1341,y:645,t:1528143816082};\\\", \\\"{x:1341,y:646,t:1528143816289};\\\", \\\"{x:1341,y:649,t:1528143816300};\\\", \\\"{x:1341,y:653,t:1528143816315};\\\", \\\"{x:1341,y:656,t:1528143816333};\\\", \\\"{x:1341,y:658,t:1528143816349};\\\", \\\"{x:1341,y:659,t:1528143816368};\\\", \\\"{x:1341,y:661,t:1528143816384};\\\", \\\"{x:1341,y:663,t:1528143816400};\\\", \\\"{x:1344,y:667,t:1528143816415};\\\", \\\"{x:1346,y:675,t:1528143816432};\\\", \\\"{x:1348,y:677,t:1528143816450};\\\", \\\"{x:1349,y:680,t:1528143816466};\\\", \\\"{x:1351,y:685,t:1528143816482};\\\", \\\"{x:1355,y:693,t:1528143816499};\\\", \\\"{x:1368,y:721,t:1528143816535};\\\", \\\"{x:1377,y:739,t:1528143816549};\\\", \\\"{x:1387,y:757,t:1528143816565};\\\", \\\"{x:1399,y:772,t:1528143816582};\\\", \\\"{x:1408,y:787,t:1528143816598};\\\", \\\"{x:1418,y:801,t:1528143816615};\\\", \\\"{x:1433,y:825,t:1528143816632};\\\", \\\"{x:1443,y:846,t:1528143816649};\\\", \\\"{x:1450,y:874,t:1528143816665};\\\", \\\"{x:1461,y:903,t:1528143816682};\\\", \\\"{x:1490,y:957,t:1528143816699};\\\", \\\"{x:1516,y:1001,t:1528143816715};\\\", \\\"{x:1529,y:1016,t:1528143816732};\\\", \\\"{x:1535,y:1020,t:1528143816749};\\\", \\\"{x:1537,y:1021,t:1528143816766};\\\", \\\"{x:1538,y:1022,t:1528143816782};\\\", \\\"{x:1538,y:1020,t:1528143816920};\\\", \\\"{x:1538,y:1014,t:1528143816932};\\\", \\\"{x:1538,y:1005,t:1528143816950};\\\", \\\"{x:1535,y:992,t:1528143816967};\\\", \\\"{x:1531,y:982,t:1528143816982};\\\", \\\"{x:1529,y:977,t:1528143816999};\\\", \\\"{x:1526,y:969,t:1528143817015};\\\", \\\"{x:1523,y:963,t:1528143817032};\\\", \\\"{x:1522,y:961,t:1528143817048};\\\", \\\"{x:1520,y:955,t:1528143817066};\\\", \\\"{x:1519,y:952,t:1528143817081};\\\", \\\"{x:1518,y:948,t:1528143817099};\\\", \\\"{x:1515,y:943,t:1528143817115};\\\", \\\"{x:1513,y:940,t:1528143817132};\\\", \\\"{x:1507,y:932,t:1528143817168};\\\", \\\"{x:1505,y:931,t:1528143817182};\\\", \\\"{x:1503,y:928,t:1528143817199};\\\", \\\"{x:1502,y:928,t:1528143817216};\\\", \\\"{x:1500,y:927,t:1528143817255};\\\", \\\"{x:1499,y:926,t:1528143817320};\\\", \\\"{x:1499,y:925,t:1528143817336};\\\", \\\"{x:1498,y:925,t:1528143817359};\\\", \\\"{x:1497,y:924,t:1528143817367};\\\", \\\"{x:1497,y:922,t:1528143817391};\\\", \\\"{x:1496,y:922,t:1528143817400};\\\", \\\"{x:1496,y:921,t:1528143817415};\\\", \\\"{x:1495,y:921,t:1528143817465};\\\", \\\"{x:1495,y:920,t:1528143818073};\\\", \\\"{x:1494,y:919,t:1528143818137};\\\", \\\"{x:1493,y:914,t:1528143818152};\\\", \\\"{x:1491,y:912,t:1528143818168};\\\", \\\"{x:1489,y:910,t:1528143818184};\\\", \\\"{x:1487,y:908,t:1528143818201};\\\", \\\"{x:1487,y:907,t:1528143818241};\\\", \\\"{x:1487,y:906,t:1528143819497};\\\", \\\"{x:1485,y:903,t:1528143819504};\\\", \\\"{x:1485,y:902,t:1528143819518};\\\", \\\"{x:1485,y:901,t:1528143819543};\\\", \\\"{x:1484,y:899,t:1528143819624};\\\", \\\"{x:1484,y:898,t:1528143819889};\\\", \\\"{x:1484,y:895,t:1528143819902};\\\", \\\"{x:1480,y:882,t:1528143819919};\\\", \\\"{x:1475,y:870,t:1528143819936};\\\", \\\"{x:1470,y:859,t:1528143819952};\\\", \\\"{x:1458,y:835,t:1528143819968};\\\", \\\"{x:1453,y:825,t:1528143819986};\\\", \\\"{x:1450,y:820,t:1528143820002};\\\", \\\"{x:1449,y:813,t:1528143820018};\\\", \\\"{x:1445,y:803,t:1528143820035};\\\", \\\"{x:1428,y:774,t:1528143820051};\\\", \\\"{x:1418,y:753,t:1528143820068};\\\", \\\"{x:1411,y:743,t:1528143820086};\\\", \\\"{x:1407,y:737,t:1528143820101};\\\", \\\"{x:1398,y:725,t:1528143820118};\\\", \\\"{x:1393,y:715,t:1528143820136};\\\", \\\"{x:1386,y:705,t:1528143820151};\\\", \\\"{x:1370,y:683,t:1528143820168};\\\", \\\"{x:1355,y:670,t:1528143820185};\\\", \\\"{x:1343,y:661,t:1528143820202};\\\", \\\"{x:1335,y:653,t:1528143820218};\\\", \\\"{x:1328,y:647,t:1528143820236};\\\", \\\"{x:1319,y:641,t:1528143820251};\\\", \\\"{x:1317,y:639,t:1528143820268};\\\", \\\"{x:1316,y:638,t:1528143820409};\\\", \\\"{x:1313,y:634,t:1528143820440};\\\", \\\"{x:1311,y:629,t:1528143820452};\\\", \\\"{x:1308,y:625,t:1528143820469};\\\", \\\"{x:1306,y:622,t:1528143820486};\\\", \\\"{x:1299,y:613,t:1528143820503};\\\", \\\"{x:1292,y:600,t:1528143820519};\\\", \\\"{x:1290,y:594,t:1528143820535};\\\", \\\"{x:1284,y:583,t:1528143820552};\\\", \\\"{x:1279,y:574,t:1528143820568};\\\", \\\"{x:1274,y:563,t:1528143820585};\\\", \\\"{x:1269,y:548,t:1528143820603};\\\", \\\"{x:1266,y:535,t:1528143820619};\\\", \\\"{x:1262,y:522,t:1528143820636};\\\", \\\"{x:1258,y:506,t:1528143820653};\\\", \\\"{x:1256,y:496,t:1528143820668};\\\", \\\"{x:1254,y:488,t:1528143820685};\\\", \\\"{x:1253,y:482,t:1528143820703};\\\", \\\"{x:1253,y:475,t:1528143820719};\\\", \\\"{x:1252,y:466,t:1528143820736};\\\", \\\"{x:1252,y:463,t:1528143820752};\\\", \\\"{x:1252,y:462,t:1528143820825};\\\", \\\"{x:1252,y:461,t:1528143820928};\\\", \\\"{x:1248,y:459,t:1528143820936};\\\", \\\"{x:1222,y:452,t:1528143820953};\\\", \\\"{x:1160,y:439,t:1528143820970};\\\", \\\"{x:1072,y:416,t:1528143820985};\\\", \\\"{x:975,y:370,t:1528143821003};\\\", \\\"{x:858,y:308,t:1528143821020};\\\", \\\"{x:749,y:249,t:1528143821035};\\\", \\\"{x:659,y:204,t:1528143821053};\\\", \\\"{x:592,y:182,t:1528143821070};\\\", \\\"{x:532,y:167,t:1528143821085};\\\", \\\"{x:484,y:165,t:1528143821102};\\\", \\\"{x:444,y:165,t:1528143821119};\\\", \\\"{x:402,y:180,t:1528143821136};\\\", \\\"{x:369,y:201,t:1528143821153};\\\", \\\"{x:316,y:246,t:1528143821169};\\\", \\\"{x:283,y:283,t:1528143821186};\\\", \\\"{x:262,y:310,t:1528143821203};\\\", \\\"{x:245,y:333,t:1528143821219};\\\", \\\"{x:231,y:348,t:1528143821236};\\\", \\\"{x:208,y:361,t:1528143821253};\\\", \\\"{x:183,y:369,t:1528143821269};\\\", \\\"{x:163,y:386,t:1528143821287};\\\", \\\"{x:159,y:400,t:1528143821303};\\\", \\\"{x:162,y:421,t:1528143821320};\\\", \\\"{x:207,y:479,t:1528143821337};\\\", \\\"{x:262,y:544,t:1528143821353};\\\", \\\"{x:310,y:600,t:1528143821369};\\\", \\\"{x:384,y:654,t:1528143821403};\\\", \\\"{x:412,y:659,t:1528143821419};\\\", \\\"{x:434,y:660,t:1528143821436};\\\", \\\"{x:441,y:660,t:1528143821453};\\\", \\\"{x:443,y:657,t:1528143821469};\\\", \\\"{x:443,y:646,t:1528143821486};\\\", \\\"{x:441,y:618,t:1528143821503};\\\", \\\"{x:435,y:600,t:1528143821520};\\\", \\\"{x:430,y:584,t:1528143821537};\\\", \\\"{x:422,y:571,t:1528143821554};\\\", \\\"{x:415,y:562,t:1528143821570};\\\", \\\"{x:403,y:550,t:1528143821587};\\\", \\\"{x:398,y:546,t:1528143821603};\\\", \\\"{x:397,y:545,t:1528143821631};\\\", \\\"{x:397,y:544,t:1528143821639};\\\", \\\"{x:397,y:543,t:1528143821655};\\\", \\\"{x:397,y:542,t:1528143821669};\\\", \\\"{x:397,y:541,t:1528143821686};\\\", \\\"{x:397,y:539,t:1528143821703};\\\", \\\"{x:397,y:537,t:1528143821719};\\\", \\\"{x:397,y:536,t:1528143821736};\\\", \\\"{x:397,y:533,t:1528143821754};\\\", \\\"{x:397,y:530,t:1528143821769};\\\", \\\"{x:396,y:526,t:1528143821786};\\\", \\\"{x:396,y:522,t:1528143821803};\\\", \\\"{x:393,y:517,t:1528143821820};\\\", \\\"{x:392,y:514,t:1528143821837};\\\", \\\"{x:392,y:512,t:1528143821854};\\\", \\\"{x:390,y:509,t:1528143821871};\\\", \\\"{x:390,y:507,t:1528143821887};\\\", \\\"{x:389,y:503,t:1528143821904};\\\", \\\"{x:389,y:501,t:1528143821920};\\\", \\\"{x:387,y:497,t:1528143821936};\\\", \\\"{x:386,y:489,t:1528143821954};\\\", \\\"{x:384,y:481,t:1528143821970};\\\", \\\"{x:383,y:478,t:1528143821986};\\\", \\\"{x:382,y:475,t:1528143822003};\\\", \\\"{x:380,y:471,t:1528143822021};\\\", \\\"{x:378,y:468,t:1528143822036};\\\", \\\"{x:375,y:465,t:1528143822053};\\\", \\\"{x:373,y:463,t:1528143822070};\\\", \\\"{x:371,y:462,t:1528143822086};\\\", \\\"{x:359,y:462,t:1528143822103};\\\", \\\"{x:344,y:462,t:1528143822119};\\\", \\\"{x:321,y:469,t:1528143822137};\\\", \\\"{x:295,y:476,t:1528143822154};\\\", \\\"{x:278,y:485,t:1528143822170};\\\", \\\"{x:262,y:492,t:1528143822187};\\\", \\\"{x:251,y:495,t:1528143822203};\\\", \\\"{x:246,y:497,t:1528143822220};\\\", \\\"{x:242,y:499,t:1528143822237};\\\", \\\"{x:235,y:503,t:1528143822254};\\\", \\\"{x:222,y:510,t:1528143822270};\\\", \\\"{x:205,y:519,t:1528143822287};\\\", \\\"{x:194,y:523,t:1528143822303};\\\", \\\"{x:188,y:525,t:1528143822320};\\\", \\\"{x:183,y:527,t:1528143822337};\\\", \\\"{x:180,y:528,t:1528143822353};\\\", \\\"{x:177,y:530,t:1528143822370};\\\", \\\"{x:174,y:533,t:1528143822386};\\\", \\\"{x:170,y:537,t:1528143822403};\\\", \\\"{x:163,y:543,t:1528143822420};\\\", \\\"{x:158,y:547,t:1528143822437};\\\", \\\"{x:152,y:551,t:1528143822453};\\\", \\\"{x:148,y:554,t:1528143822470};\\\", \\\"{x:142,y:561,t:1528143822487};\\\", \\\"{x:139,y:565,t:1528143822503};\\\", \\\"{x:139,y:566,t:1528143822520};\\\", \\\"{x:137,y:571,t:1528143822537};\\\", \\\"{x:137,y:574,t:1528143822553};\\\", \\\"{x:136,y:577,t:1528143822570};\\\", \\\"{x:136,y:581,t:1528143822588};\\\", \\\"{x:136,y:585,t:1528143822604};\\\", \\\"{x:136,y:587,t:1528143822620};\\\", \\\"{x:136,y:589,t:1528143822637};\\\", \\\"{x:137,y:591,t:1528143822653};\\\", \\\"{x:141,y:591,t:1528143822720};\\\", \\\"{x:161,y:591,t:1528143822738};\\\", \\\"{x:190,y:591,t:1528143822754};\\\", \\\"{x:220,y:591,t:1528143822770};\\\", \\\"{x:250,y:591,t:1528143822787};\\\", \\\"{x:279,y:591,t:1528143822804};\\\", \\\"{x:302,y:591,t:1528143822820};\\\", \\\"{x:324,y:591,t:1528143822837};\\\", \\\"{x:338,y:591,t:1528143822853};\\\", \\\"{x:345,y:591,t:1528143822870};\\\", \\\"{x:347,y:591,t:1528143822887};\\\", \\\"{x:350,y:591,t:1528143822903};\\\", \\\"{x:355,y:590,t:1528143822920};\\\", \\\"{x:370,y:586,t:1528143822937};\\\", \\\"{x:386,y:583,t:1528143822954};\\\", \\\"{x:407,y:580,t:1528143822970};\\\", \\\"{x:431,y:576,t:1528143822988};\\\", \\\"{x:451,y:573,t:1528143823004};\\\", \\\"{x:467,y:569,t:1528143823020};\\\", \\\"{x:483,y:565,t:1528143823037};\\\", \\\"{x:495,y:560,t:1528143823054};\\\", \\\"{x:510,y:557,t:1528143823072};\\\", \\\"{x:524,y:553,t:1528143823087};\\\", \\\"{x:532,y:550,t:1528143823104};\\\", \\\"{x:537,y:546,t:1528143823121};\\\", \\\"{x:544,y:544,t:1528143823137};\\\", \\\"{x:554,y:540,t:1528143823154};\\\", \\\"{x:564,y:535,t:1528143823170};\\\", \\\"{x:573,y:532,t:1528143823187};\\\", \\\"{x:585,y:527,t:1528143823204};\\\", \\\"{x:594,y:522,t:1528143823221};\\\", \\\"{x:604,y:517,t:1528143823238};\\\", \\\"{x:611,y:513,t:1528143823254};\\\", \\\"{x:617,y:510,t:1528143823271};\\\", \\\"{x:618,y:510,t:1528143823304};\\\", \\\"{x:621,y:509,t:1528143823323};\\\", \\\"{x:629,y:505,t:1528143823338};\\\", \\\"{x:638,y:504,t:1528143823354};\\\", \\\"{x:647,y:500,t:1528143823371};\\\", \\\"{x:653,y:497,t:1528143823387};\\\", \\\"{x:659,y:495,t:1528143823404};\\\", \\\"{x:664,y:492,t:1528143823420};\\\", \\\"{x:667,y:490,t:1528143823437};\\\", \\\"{x:668,y:489,t:1528143823454};\\\", \\\"{x:670,y:486,t:1528143823471};\\\", \\\"{x:670,y:485,t:1528143823488};\\\", \\\"{x:670,y:482,t:1528143823505};\\\", \\\"{x:670,y:479,t:1528143823522};\\\", \\\"{x:669,y:474,t:1528143823539};\\\", \\\"{x:664,y:470,t:1528143823555};\\\", \\\"{x:661,y:469,t:1528143823572};\\\", \\\"{x:660,y:468,t:1528143823587};\\\", \\\"{x:659,y:468,t:1528143823608};\\\", \\\"{x:658,y:468,t:1528143823621};\\\", \\\"{x:656,y:467,t:1528143823638};\\\", \\\"{x:652,y:465,t:1528143823654};\\\", \\\"{x:644,y:463,t:1528143823673};\\\", \\\"{x:633,y:460,t:1528143823687};\\\", \\\"{x:626,y:458,t:1528143823705};\\\", \\\"{x:618,y:456,t:1528143823721};\\\", \\\"{x:613,y:454,t:1528143823738};\\\", \\\"{x:611,y:453,t:1528143823754};\\\", \\\"{x:610,y:452,t:1528143823771};\\\", \\\"{x:609,y:451,t:1528143823792};\\\", \\\"{x:607,y:453,t:1528143824103};\\\", \\\"{x:602,y:462,t:1528143824112};\\\", \\\"{x:595,y:475,t:1528143824122};\\\", \\\"{x:576,y:503,t:1528143824139};\\\", \\\"{x:556,y:528,t:1528143824155};\\\", \\\"{x:533,y:553,t:1528143824172};\\\", \\\"{x:508,y:575,t:1528143824189};\\\", \\\"{x:491,y:592,t:1528143824205};\\\", \\\"{x:479,y:607,t:1528143824221};\\\", \\\"{x:470,y:625,t:1528143824239};\\\", \\\"{x:454,y:655,t:1528143824256};\\\", \\\"{x:451,y:668,t:1528143824271};\\\", \\\"{x:447,y:677,t:1528143824288};\\\", \\\"{x:446,y:682,t:1528143824305};\\\", \\\"{x:446,y:684,t:1528143824321};\\\", \\\"{x:446,y:683,t:1528143824505};\\\", \\\"{x:446,y:681,t:1528143824522};\\\", \\\"{x:447,y:680,t:1528143824540};\\\", \\\"{x:448,y:679,t:1528143824880};\\\", \\\"{x:450,y:679,t:1528143824888};\\\", \\\"{x:452,y:679,t:1528143824906};\\\", \\\"{x:455,y:679,t:1528143824922};\\\", \\\"{x:458,y:681,t:1528143824938};\\\", \\\"{x:465,y:684,t:1528143824956};\\\", \\\"{x:474,y:689,t:1528143824972};\\\", \\\"{x:491,y:696,t:1528143824988};\\\", \\\"{x:507,y:705,t:1528143825005};\\\", \\\"{x:529,y:716,t:1528143825022};\\\", \\\"{x:556,y:732,t:1528143825039};\\\", \\\"{x:576,y:743,t:1528143825056};\\\", \\\"{x:596,y:757,t:1528143825072};\\\", \\\"{x:602,y:761,t:1528143825088};\\\", \\\"{x:606,y:763,t:1528143825106};\\\", \\\"{x:608,y:765,t:1528143825123};\\\", \\\"{x:610,y:765,t:1528143825152};\\\", \\\"{x:613,y:769,t:1528143825168};\\\", \\\"{x:614,y:773,t:1528143825176};\\\", \\\"{x:615,y:781,t:1528143825189};\\\", \\\"{x:615,y:787,t:1528143825205};\\\", \\\"{x:615,y:789,t:1528143825223};\\\", \\\"{x:613,y:788,t:1528143825336};\\\", \\\"{x:609,y:785,t:1528143825344};\\\", \\\"{x:606,y:783,t:1528143825356};\\\", \\\"{x:600,y:779,t:1528143825372};\\\", \\\"{x:595,y:775,t:1528143825389};\\\", \\\"{x:588,y:771,t:1528143825406};\\\", \\\"{x:584,y:767,t:1528143825422};\\\", \\\"{x:579,y:762,t:1528143825440};\\\", \\\"{x:576,y:760,t:1528143825456};\\\", \\\"{x:574,y:757,t:1528143825472};\\\", \\\"{x:572,y:755,t:1528143825489};\\\", \\\"{x:570,y:750,t:1528143825505};\\\", \\\"{x:568,y:746,t:1528143825523};\\\", \\\"{x:564,y:741,t:1528143825539};\\\", \\\"{x:557,y:732,t:1528143825556};\\\", \\\"{x:551,y:725,t:1528143825572};\\\", \\\"{x:545,y:717,t:1528143825590};\\\", \\\"{x:539,y:707,t:1528143825606};\\\", \\\"{x:534,y:701,t:1528143825622};\\\", \\\"{x:529,y:694,t:1528143825639};\\\", \\\"{x:528,y:693,t:1528143825656};\\\", \\\"{x:526,y:691,t:1528143825672};\\\", \\\"{x:526,y:690,t:1528143825689};\\\", \\\"{x:525,y:688,t:1528143825712};\\\", \\\"{x:524,y:686,t:1528143825722};\\\", \\\"{x:522,y:679,t:1528143825774};\\\", \\\"{x:518,y:676,t:1528143825789};\\\", \\\"{x:518,y:675,t:1528143825807};\\\", \\\"{x:517,y:672,t:1528143825822};\\\", \\\"{x:513,y:670,t:1528143825839};\\\", \\\"{x:512,y:668,t:1528143825856};\\\" ] }, { \\\"rt\\\": 9530, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 356766, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"8182H\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:500,y:656,t:1528143825976};\\\", \\\"{x:499,y:654,t:1528143825989};\\\", \\\"{x:498,y:654,t:1528143826007};\\\", \\\"{x:497,y:650,t:1528143826023};\\\", \\\"{x:495,y:648,t:1528143826039};\\\", \\\"{x:493,y:646,t:1528143826056};\\\", \\\"{x:492,y:644,t:1528143826079};\\\", \\\"{x:492,y:643,t:1528143826090};\\\", \\\"{x:491,y:641,t:1528143826106};\\\", \\\"{x:490,y:641,t:1528143826140};\\\", \\\"{x:490,y:640,t:1528143826711};\\\", \\\"{x:490,y:642,t:1528143826823};\\\", \\\"{x:494,y:642,t:1528143826841};\\\", \\\"{x:495,y:642,t:1528143826857};\\\", \\\"{x:500,y:644,t:1528143826874};\\\", \\\"{x:501,y:644,t:1528143826937};\\\", \\\"{x:502,y:644,t:1528143826944};\\\", \\\"{x:510,y:644,t:1528143826957};\\\", \\\"{x:522,y:644,t:1528143826973};\\\", \\\"{x:537,y:644,t:1528143826991};\\\", \\\"{x:562,y:645,t:1528143827007};\\\", \\\"{x:580,y:643,t:1528143827024};\\\", \\\"{x:586,y:642,t:1528143827041};\\\", \\\"{x:587,y:642,t:1528143827058};\\\", \\\"{x:588,y:642,t:1528143827128};\\\", \\\"{x:590,y:642,t:1528143827144};\\\", \\\"{x:591,y:642,t:1528143827158};\\\", \\\"{x:593,y:642,t:1528143827175};\\\", \\\"{x:594,y:642,t:1528143827192};\\\", \\\"{x:596,y:642,t:1528143827208};\\\", \\\"{x:598,y:639,t:1528143827224};\\\", \\\"{x:598,y:630,t:1528143827241};\\\", \\\"{x:598,y:616,t:1528143827257};\\\", \\\"{x:599,y:606,t:1528143827274};\\\", \\\"{x:600,y:601,t:1528143827291};\\\", \\\"{x:600,y:600,t:1528143827344};\\\", \\\"{x:599,y:597,t:1528143827358};\\\", \\\"{x:597,y:590,t:1528143827375};\\\", \\\"{x:596,y:588,t:1528143827391};\\\", \\\"{x:596,y:582,t:1528143827407};\\\", \\\"{x:594,y:578,t:1528143827425};\\\", \\\"{x:594,y:577,t:1528143827441};\\\", \\\"{x:594,y:576,t:1528143827488};\\\", \\\"{x:595,y:575,t:1528143827567};\\\", \\\"{x:596,y:575,t:1528143827624};\\\", \\\"{x:597,y:575,t:1528143827641};\\\", \\\"{x:599,y:575,t:1528143827663};\\\", \\\"{x:600,y:575,t:1528143827721};\\\", \\\"{x:600,y:577,t:1528143827744};\\\", \\\"{x:600,y:579,t:1528143827761};\\\", \\\"{x:600,y:580,t:1528143827774};\\\", \\\"{x:600,y:581,t:1528143827792};\\\", \\\"{x:603,y:585,t:1528143827807};\\\", \\\"{x:604,y:586,t:1528143827824};\\\", \\\"{x:607,y:588,t:1528143827841};\\\", \\\"{x:609,y:589,t:1528143827858};\\\", \\\"{x:610,y:590,t:1528143827874};\\\", \\\"{x:612,y:592,t:1528143827892};\\\", \\\"{x:612,y:593,t:1528143827907};\\\", \\\"{x:616,y:599,t:1528143827925};\\\", \\\"{x:618,y:605,t:1528143827942};\\\", \\\"{x:625,y:611,t:1528143827958};\\\", \\\"{x:660,y:616,t:1528143827975};\\\", \\\"{x:723,y:630,t:1528143827991};\\\", \\\"{x:748,y:637,t:1528143828008};\\\", \\\"{x:750,y:638,t:1528143828024};\\\", \\\"{x:754,y:641,t:1528143828041};\\\", \\\"{x:773,y:645,t:1528143828059};\\\", \\\"{x:795,y:654,t:1528143828074};\\\", \\\"{x:821,y:665,t:1528143828091};\\\", \\\"{x:849,y:678,t:1528143828108};\\\", \\\"{x:868,y:694,t:1528143828124};\\\", \\\"{x:917,y:755,t:1528143828142};\\\", \\\"{x:976,y:836,t:1528143828158};\\\", \\\"{x:1027,y:903,t:1528143828175};\\\", \\\"{x:1098,y:976,t:1528143828191};\\\", \\\"{x:1138,y:1005,t:1528143828209};\\\", \\\"{x:1165,y:1025,t:1528143828225};\\\", \\\"{x:1183,y:1039,t:1528143828241};\\\", \\\"{x:1193,y:1044,t:1528143828258};\\\", \\\"{x:1198,y:1046,t:1528143828275};\\\", \\\"{x:1200,y:1046,t:1528143828335};\\\", \\\"{x:1207,y:1046,t:1528143828343};\\\", \\\"{x:1218,y:1046,t:1528143828359};\\\", \\\"{x:1269,y:1037,t:1528143828375};\\\", \\\"{x:1331,y:1003,t:1528143828392};\\\", \\\"{x:1391,y:965,t:1528143828408};\\\", \\\"{x:1437,y:924,t:1528143828424};\\\", \\\"{x:1457,y:898,t:1528143828442};\\\", \\\"{x:1461,y:890,t:1528143828458};\\\", \\\"{x:1461,y:889,t:1528143828475};\\\", \\\"{x:1461,y:888,t:1528143828600};\\\", \\\"{x:1461,y:887,t:1528143828609};\\\", \\\"{x:1454,y:886,t:1528143828625};\\\", \\\"{x:1440,y:886,t:1528143828641};\\\", \\\"{x:1427,y:886,t:1528143828659};\\\", \\\"{x:1412,y:888,t:1528143828676};\\\", \\\"{x:1398,y:892,t:1528143828691};\\\", \\\"{x:1393,y:893,t:1528143828709};\\\", \\\"{x:1391,y:893,t:1528143828726};\\\", \\\"{x:1390,y:893,t:1528143828742};\\\", \\\"{x:1389,y:894,t:1528143828768};\\\", \\\"{x:1385,y:896,t:1528143828776};\\\", \\\"{x:1380,y:898,t:1528143828792};\\\", \\\"{x:1370,y:901,t:1528143828809};\\\", \\\"{x:1360,y:902,t:1528143828826};\\\", \\\"{x:1351,y:903,t:1528143828842};\\\", \\\"{x:1340,y:906,t:1528143828859};\\\", \\\"{x:1335,y:906,t:1528143828876};\\\", \\\"{x:1334,y:906,t:1528143828892};\\\", \\\"{x:1334,y:907,t:1528143829112};\\\", \\\"{x:1334,y:908,t:1528143829129};\\\", \\\"{x:1337,y:910,t:1528143829143};\\\", \\\"{x:1340,y:913,t:1528143829160};\\\", \\\"{x:1341,y:914,t:1528143829240};\\\", \\\"{x:1342,y:914,t:1528143829248};\\\", \\\"{x:1343,y:914,t:1528143829264};\\\", \\\"{x:1344,y:914,t:1528143829288};\\\", \\\"{x:1346,y:914,t:1528143829295};\\\", \\\"{x:1346,y:915,t:1528143829311};\\\", \\\"{x:1348,y:915,t:1528143829521};\\\", \\\"{x:1350,y:908,t:1528143829529};\\\", \\\"{x:1350,y:906,t:1528143829544};\\\", \\\"{x:1353,y:897,t:1528143829561};\\\", \\\"{x:1355,y:891,t:1528143829576};\\\", \\\"{x:1357,y:886,t:1528143829594};\\\", \\\"{x:1359,y:881,t:1528143829610};\\\", \\\"{x:1361,y:877,t:1528143829626};\\\", \\\"{x:1362,y:875,t:1528143829643};\\\", \\\"{x:1363,y:872,t:1528143829660};\\\", \\\"{x:1366,y:869,t:1528143829676};\\\", \\\"{x:1368,y:864,t:1528143829692};\\\", \\\"{x:1370,y:862,t:1528143829710};\\\", \\\"{x:1373,y:859,t:1528143829726};\\\", \\\"{x:1373,y:858,t:1528143829743};\\\", \\\"{x:1374,y:855,t:1528143829760};\\\", \\\"{x:1375,y:854,t:1528143829792};\\\", \\\"{x:1376,y:854,t:1528143829824};\\\", \\\"{x:1376,y:852,t:1528143830241};\\\", \\\"{x:1376,y:850,t:1528143830248};\\\", \\\"{x:1376,y:849,t:1528143830259};\\\", \\\"{x:1376,y:848,t:1528143830277};\\\", \\\"{x:1375,y:847,t:1528143832559};\\\", \\\"{x:1375,y:846,t:1528143832608};\\\", \\\"{x:1372,y:843,t:1528143832615};\\\", \\\"{x:1361,y:833,t:1528143832629};\\\", \\\"{x:1330,y:809,t:1528143832645};\\\", \\\"{x:1295,y:782,t:1528143832662};\\\", \\\"{x:1263,y:756,t:1528143832678};\\\", \\\"{x:1228,y:730,t:1528143832695};\\\", \\\"{x:1101,y:650,t:1528143832711};\\\", \\\"{x:921,y:529,t:1528143832729};\\\", \\\"{x:784,y:444,t:1528143832745};\\\", \\\"{x:688,y:406,t:1528143832762};\\\", \\\"{x:603,y:386,t:1528143832779};\\\", \\\"{x:552,y:370,t:1528143832795};\\\", \\\"{x:524,y:365,t:1528143832811};\\\", \\\"{x:507,y:364,t:1528143832828};\\\", \\\"{x:504,y:364,t:1528143832845};\\\", \\\"{x:501,y:364,t:1528143832879};\\\", \\\"{x:492,y:371,t:1528143832895};\\\", \\\"{x:478,y:389,t:1528143832911};\\\", \\\"{x:466,y:409,t:1528143832929};\\\", \\\"{x:456,y:425,t:1528143832945};\\\", \\\"{x:447,y:440,t:1528143832962};\\\", \\\"{x:431,y:457,t:1528143832978};\\\", \\\"{x:419,y:468,t:1528143832996};\\\", \\\"{x:399,y:477,t:1528143833012};\\\", \\\"{x:388,y:483,t:1528143833029};\\\", \\\"{x:382,y:488,t:1528143833045};\\\", \\\"{x:382,y:490,t:1528143833062};\\\", \\\"{x:382,y:491,t:1528143833095};\\\", \\\"{x:381,y:492,t:1528143833111};\\\", \\\"{x:380,y:493,t:1528143833248};\\\", \\\"{x:385,y:493,t:1528143833833};\\\", \\\"{x:408,y:493,t:1528143833847};\\\", \\\"{x:461,y:493,t:1528143833865};\\\", \\\"{x:572,y:493,t:1528143833880};\\\", \\\"{x:645,y:493,t:1528143833896};\\\", \\\"{x:689,y:493,t:1528143833913};\\\", \\\"{x:711,y:493,t:1528143833930};\\\", \\\"{x:718,y:493,t:1528143833946};\\\", \\\"{x:719,y:493,t:1528143834015};\\\", \\\"{x:718,y:493,t:1528143834030};\\\", \\\"{x:711,y:493,t:1528143834047};\\\", \\\"{x:694,y:497,t:1528143834062};\\\", \\\"{x:643,y:503,t:1528143834080};\\\", \\\"{x:592,y:511,t:1528143834097};\\\", \\\"{x:550,y:517,t:1528143834112};\\\", \\\"{x:517,y:522,t:1528143834130};\\\", \\\"{x:486,y:524,t:1528143834147};\\\", \\\"{x:460,y:528,t:1528143834163};\\\", \\\"{x:435,y:532,t:1528143834179};\\\", \\\"{x:419,y:534,t:1528143834196};\\\", \\\"{x:404,y:535,t:1528143834213};\\\", \\\"{x:393,y:537,t:1528143834230};\\\", \\\"{x:384,y:539,t:1528143834246};\\\", \\\"{x:378,y:539,t:1528143834263};\\\", \\\"{x:375,y:540,t:1528143834279};\\\", \\\"{x:375,y:542,t:1528143834385};\\\", \\\"{x:375,y:545,t:1528143834396};\\\", \\\"{x:375,y:549,t:1528143834414};\\\", \\\"{x:375,y:550,t:1528143834429};\\\", \\\"{x:375,y:552,t:1528143834447};\\\", \\\"{x:375,y:553,t:1528143834463};\\\", \\\"{x:375,y:557,t:1528143834480};\\\", \\\"{x:375,y:558,t:1528143834503};\\\", \\\"{x:376,y:559,t:1528143834543};\\\", \\\"{x:376,y:561,t:1528143834783};\\\", \\\"{x:376,y:562,t:1528143834797};\\\", \\\"{x:381,y:569,t:1528143834814};\\\", \\\"{x:390,y:579,t:1528143834830};\\\", \\\"{x:397,y:587,t:1528143834848};\\\", \\\"{x:403,y:595,t:1528143834863};\\\", \\\"{x:406,y:599,t:1528143834880};\\\", \\\"{x:411,y:605,t:1528143834896};\\\", \\\"{x:420,y:619,t:1528143834915};\\\", \\\"{x:428,y:627,t:1528143834931};\\\", \\\"{x:433,y:632,t:1528143834947};\\\", \\\"{x:437,y:635,t:1528143834964};\\\", \\\"{x:439,y:636,t:1528143834981};\\\", \\\"{x:440,y:636,t:1528143835008};\\\", \\\"{x:441,y:636,t:1528143835031};\\\", \\\"{x:442,y:637,t:1528143835047};\\\", \\\"{x:443,y:637,t:1528143835088};\\\", \\\"{x:446,y:639,t:1528143835097};\\\", \\\"{x:450,y:640,t:1528143835114};\\\", \\\"{x:460,y:643,t:1528143835131};\\\", \\\"{x:472,y:648,t:1528143835147};\\\", \\\"{x:486,y:656,t:1528143835164};\\\", \\\"{x:506,y:667,t:1528143835183};\\\", \\\"{x:525,y:677,t:1528143835197};\\\", \\\"{x:540,y:683,t:1528143835214};\\\", \\\"{x:548,y:684,t:1528143835232};\\\", \\\"{x:549,y:685,t:1528143835256};\\\", \\\"{x:552,y:686,t:1528143835607};\\\", \\\"{x:560,y:687,t:1528143835615};\\\", \\\"{x:562,y:688,t:1528143835631};\\\", \\\"{x:576,y:707,t:1528143835647};\\\", \\\"{x:576,y:706,t:1528143835784};\\\", \\\"{x:574,y:704,t:1528143835798};\\\", \\\"{x:572,y:703,t:1528143835814};\\\", \\\"{x:569,y:702,t:1528143835831};\\\", \\\"{x:568,y:701,t:1528143835847};\\\", \\\"{x:568,y:700,t:1528143835976};\\\", \\\"{x:568,y:698,t:1528143835992};\\\", \\\"{x:568,y:696,t:1528143836000};\\\", \\\"{x:568,y:695,t:1528143836016};\\\", \\\"{x:568,y:693,t:1528143836031};\\\", \\\"{x:568,y:690,t:1528143836048};\\\", \\\"{x:568,y:688,t:1528143836065};\\\", \\\"{x:568,y:687,t:1528143836081};\\\", \\\"{x:568,y:686,t:1528143836160};\\\", \\\"{x:568,y:685,t:1528143836167};\\\", \\\"{x:566,y:683,t:1528143836184};\\\", \\\"{x:566,y:681,t:1528143836198};\\\", \\\"{x:565,y:680,t:1528143836215};\\\", \\\"{x:563,y:676,t:1528143836231};\\\", \\\"{x:561,y:674,t:1528143836248};\\\", \\\"{x:560,y:673,t:1528143836265};\\\", \\\"{x:558,y:671,t:1528143836281};\\\", \\\"{x:554,y:669,t:1528143836298};\\\", \\\"{x:548,y:665,t:1528143836315};\\\", \\\"{x:543,y:661,t:1528143836331};\\\", \\\"{x:527,y:655,t:1528143836349};\\\", \\\"{x:506,y:645,t:1528143836365};\\\", \\\"{x:476,y:630,t:1528143836382};\\\", \\\"{x:454,y:621,t:1528143836398};\\\", \\\"{x:434,y:610,t:1528143836416};\\\", \\\"{x:400,y:596,t:1528143836432};\\\", \\\"{x:385,y:593,t:1528143836448};\\\", \\\"{x:377,y:593,t:1528143836465};\\\", \\\"{x:374,y:594,t:1528143836482};\\\" ] }, { \\\"rt\\\": 19480, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 377514, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"8182H\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-X -F -F -F -G -10 AM-10 AM-G \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:360,y:579,t:1528143838152};\\\", \\\"{x:229,y:511,t:1528143838168};\\\", \\\"{x:211,y:509,t:1528143838183};\\\", \\\"{x:223,y:512,t:1528143838669};\\\", \\\"{x:323,y:538,t:1528143838687};\\\", \\\"{x:441,y:563,t:1528143838703};\\\", \\\"{x:579,y:582,t:1528143838720};\\\", \\\"{x:718,y:608,t:1528143838736};\\\", \\\"{x:846,y:646,t:1528143838753};\\\", \\\"{x:1000,y:688,t:1528143838770};\\\", \\\"{x:1162,y:726,t:1528143838786};\\\", \\\"{x:1379,y:754,t:1528143838803};\\\", \\\"{x:1481,y:763,t:1528143838820};\\\", \\\"{x:1548,y:765,t:1528143838838};\\\", \\\"{x:1604,y:765,t:1528143838853};\\\", \\\"{x:1648,y:756,t:1528143838870};\\\", \\\"{x:1678,y:746,t:1528143838887};\\\", \\\"{x:1706,y:731,t:1528143838903};\\\", \\\"{x:1723,y:719,t:1528143838921};\\\", \\\"{x:1733,y:708,t:1528143838937};\\\", \\\"{x:1737,y:696,t:1528143838954};\\\", \\\"{x:1735,y:683,t:1528143838970};\\\", \\\"{x:1714,y:663,t:1528143838988};\\\", \\\"{x:1691,y:647,t:1528143839003};\\\", \\\"{x:1670,y:638,t:1528143839020};\\\", \\\"{x:1648,y:628,t:1528143839037};\\\", \\\"{x:1629,y:623,t:1528143839054};\\\", \\\"{x:1609,y:622,t:1528143839071};\\\", \\\"{x:1588,y:622,t:1528143839088};\\\", \\\"{x:1556,y:622,t:1528143839104};\\\", \\\"{x:1502,y:629,t:1528143839121};\\\", \\\"{x:1447,y:635,t:1528143839137};\\\", \\\"{x:1410,y:642,t:1528143839153};\\\", \\\"{x:1385,y:643,t:1528143839171};\\\", \\\"{x:1341,y:643,t:1528143839187};\\\", \\\"{x:1332,y:643,t:1528143839205};\\\", \\\"{x:1323,y:643,t:1528143839221};\\\", \\\"{x:1319,y:643,t:1528143839237};\\\", \\\"{x:1312,y:643,t:1528143839254};\\\", \\\"{x:1308,y:642,t:1528143839271};\\\", \\\"{x:1307,y:641,t:1528143839341};\\\", \\\"{x:1307,y:640,t:1528143839354};\\\", \\\"{x:1313,y:638,t:1528143839371};\\\", \\\"{x:1334,y:638,t:1528143839388};\\\", \\\"{x:1349,y:638,t:1528143839405};\\\", \\\"{x:1356,y:638,t:1528143839421};\\\", \\\"{x:1358,y:638,t:1528143839438};\\\", \\\"{x:1360,y:638,t:1528143839455};\\\", \\\"{x:1361,y:639,t:1528143839684};\\\", \\\"{x:1360,y:640,t:1528143839748};\\\", \\\"{x:1359,y:641,t:1528143839755};\\\", \\\"{x:1359,y:642,t:1528143839772};\\\", \\\"{x:1357,y:642,t:1528143840044};\\\", \\\"{x:1352,y:643,t:1528143840058};\\\", \\\"{x:1340,y:645,t:1528143840071};\\\", \\\"{x:1331,y:646,t:1528143840088};\\\", \\\"{x:1326,y:646,t:1528143840104};\\\", \\\"{x:1327,y:647,t:1528143840339};\\\", \\\"{x:1329,y:647,t:1528143840354};\\\", \\\"{x:1332,y:648,t:1528143840372};\\\", \\\"{x:1333,y:649,t:1528143840388};\\\", \\\"{x:1334,y:649,t:1528143840405};\\\", \\\"{x:1335,y:649,t:1528143840421};\\\", \\\"{x:1336,y:649,t:1528143840438};\\\", \\\"{x:1337,y:649,t:1528143840475};\\\", \\\"{x:1338,y:649,t:1528143840491};\\\", \\\"{x:1340,y:650,t:1528143840524};\\\", \\\"{x:1343,y:652,t:1528143840540};\\\", \\\"{x:1350,y:653,t:1528143840555};\\\", \\\"{x:1355,y:654,t:1528143840572};\\\", \\\"{x:1374,y:654,t:1528143840589};\\\", \\\"{x:1393,y:654,t:1528143840606};\\\", \\\"{x:1398,y:654,t:1528143840623};\\\", \\\"{x:1396,y:656,t:1528143840684};\\\", \\\"{x:1391,y:657,t:1528143840692};\\\", \\\"{x:1388,y:658,t:1528143840706};\\\", \\\"{x:1385,y:660,t:1528143840723};\\\", \\\"{x:1384,y:660,t:1528143840772};\\\", \\\"{x:1383,y:660,t:1528143840780};\\\", \\\"{x:1382,y:660,t:1528143840804};\\\", \\\"{x:1381,y:660,t:1528143840916};\\\", \\\"{x:1380,y:659,t:1528143840923};\\\", \\\"{x:1378,y:656,t:1528143840939};\\\", \\\"{x:1377,y:652,t:1528143840956};\\\", \\\"{x:1374,y:646,t:1528143840972};\\\", \\\"{x:1371,y:643,t:1528143840990};\\\", \\\"{x:1368,y:640,t:1528143841006};\\\", \\\"{x:1365,y:638,t:1528143841023};\\\", \\\"{x:1362,y:636,t:1528143841039};\\\", \\\"{x:1359,y:634,t:1528143841056};\\\", \\\"{x:1356,y:633,t:1528143841072};\\\", \\\"{x:1354,y:632,t:1528143841090};\\\", \\\"{x:1352,y:631,t:1528143841106};\\\", \\\"{x:1349,y:628,t:1528143841123};\\\", \\\"{x:1348,y:628,t:1528143841141};\\\", \\\"{x:1347,y:627,t:1528143841163};\\\", \\\"{x:1346,y:626,t:1528143841179};\\\", \\\"{x:1342,y:622,t:1528143841204};\\\", \\\"{x:1341,y:619,t:1528143841211};\\\", \\\"{x:1340,y:614,t:1528143841223};\\\", \\\"{x:1337,y:606,t:1528143841240};\\\", \\\"{x:1334,y:603,t:1528143841257};\\\", \\\"{x:1333,y:602,t:1528143841273};\\\", \\\"{x:1333,y:601,t:1528143841289};\\\", \\\"{x:1332,y:600,t:1528143841307};\\\", \\\"{x:1332,y:602,t:1528143841411};\\\", \\\"{x:1332,y:604,t:1528143841422};\\\", \\\"{x:1332,y:613,t:1528143841440};\\\", \\\"{x:1334,y:624,t:1528143841457};\\\", \\\"{x:1337,y:635,t:1528143841473};\\\", \\\"{x:1339,y:641,t:1528143841490};\\\", \\\"{x:1339,y:647,t:1528143841507};\\\", \\\"{x:1339,y:649,t:1528143841523};\\\", \\\"{x:1337,y:649,t:1528143841571};\\\", \\\"{x:1331,y:649,t:1528143841579};\\\", \\\"{x:1326,y:649,t:1528143841589};\\\", \\\"{x:1317,y:638,t:1528143841606};\\\", \\\"{x:1310,y:621,t:1528143841624};\\\", \\\"{x:1311,y:607,t:1528143841640};\\\", \\\"{x:1329,y:582,t:1528143841657};\\\", \\\"{x:1372,y:540,t:1528143841674};\\\", \\\"{x:1398,y:509,t:1528143841690};\\\", \\\"{x:1404,y:495,t:1528143841708};\\\", \\\"{x:1404,y:494,t:1528143841724};\\\", \\\"{x:1404,y:493,t:1528143841741};\\\", \\\"{x:1403,y:493,t:1528143841779};\\\", \\\"{x:1403,y:494,t:1528143841789};\\\", \\\"{x:1404,y:494,t:1528143841807};\\\", \\\"{x:1406,y:495,t:1528143841824};\\\", \\\"{x:1408,y:495,t:1528143841840};\\\", \\\"{x:1413,y:493,t:1528143841857};\\\", \\\"{x:1420,y:479,t:1528143841874};\\\", \\\"{x:1422,y:473,t:1528143841890};\\\", \\\"{x:1428,y:471,t:1528143841906};\\\", \\\"{x:1449,y:471,t:1528143841924};\\\", \\\"{x:1474,y:477,t:1528143841940};\\\", \\\"{x:1491,y:482,t:1528143841956};\\\", \\\"{x:1496,y:482,t:1528143841973};\\\", \\\"{x:1498,y:484,t:1528143841990};\\\", \\\"{x:1498,y:483,t:1528143842187};\\\", \\\"{x:1497,y:483,t:1528143842195};\\\", \\\"{x:1497,y:490,t:1528143842267};\\\", \\\"{x:1498,y:503,t:1528143842274};\\\", \\\"{x:1505,y:528,t:1528143842291};\\\", \\\"{x:1514,y:555,t:1528143842307};\\\", \\\"{x:1518,y:580,t:1528143842323};\\\", \\\"{x:1520,y:609,t:1528143842340};\\\", \\\"{x:1518,y:632,t:1528143842357};\\\", \\\"{x:1510,y:656,t:1528143842374};\\\", \\\"{x:1499,y:680,t:1528143842391};\\\", \\\"{x:1486,y:701,t:1528143842408};\\\", \\\"{x:1469,y:717,t:1528143842424};\\\", \\\"{x:1449,y:730,t:1528143842441};\\\", \\\"{x:1433,y:735,t:1528143842457};\\\", \\\"{x:1423,y:736,t:1528143842474};\\\", \\\"{x:1416,y:736,t:1528143842491};\\\", \\\"{x:1412,y:736,t:1528143842507};\\\", \\\"{x:1407,y:735,t:1528143842524};\\\", \\\"{x:1403,y:733,t:1528143842541};\\\", \\\"{x:1375,y:725,t:1528143842558};\\\", \\\"{x:1353,y:718,t:1528143842574};\\\", \\\"{x:1338,y:718,t:1528143842591};\\\", \\\"{x:1319,y:718,t:1528143842607};\\\", \\\"{x:1305,y:718,t:1528143842625};\\\", \\\"{x:1296,y:720,t:1528143842641};\\\", \\\"{x:1284,y:727,t:1528143842658};\\\", \\\"{x:1272,y:741,t:1528143842676};\\\", \\\"{x:1270,y:750,t:1528143842691};\\\", \\\"{x:1268,y:758,t:1528143842707};\\\", \\\"{x:1267,y:767,t:1528143842725};\\\", \\\"{x:1263,y:778,t:1528143842742};\\\", \\\"{x:1261,y:782,t:1528143842758};\\\", \\\"{x:1258,y:788,t:1528143842775};\\\", \\\"{x:1254,y:794,t:1528143842790};\\\", \\\"{x:1252,y:799,t:1528143842808};\\\", \\\"{x:1250,y:803,t:1528143842825};\\\", \\\"{x:1247,y:810,t:1528143842840};\\\", \\\"{x:1245,y:815,t:1528143842858};\\\", \\\"{x:1242,y:824,t:1528143842875};\\\", \\\"{x:1239,y:829,t:1528143842891};\\\", \\\"{x:1234,y:840,t:1528143842908};\\\", \\\"{x:1234,y:879,t:1528143842925};\\\", \\\"{x:1234,y:927,t:1528143842942};\\\", \\\"{x:1234,y:951,t:1528143842958};\\\", \\\"{x:1234,y:959,t:1528143842975};\\\", \\\"{x:1234,y:962,t:1528143842992};\\\", \\\"{x:1233,y:963,t:1528143843116};\\\", \\\"{x:1230,y:963,t:1528143843125};\\\", \\\"{x:1227,y:961,t:1528143843142};\\\", \\\"{x:1222,y:955,t:1528143843158};\\\", \\\"{x:1216,y:944,t:1528143843175};\\\", \\\"{x:1213,y:940,t:1528143843192};\\\", \\\"{x:1212,y:934,t:1528143843208};\\\", \\\"{x:1209,y:930,t:1528143843225};\\\", \\\"{x:1209,y:926,t:1528143843242};\\\", \\\"{x:1207,y:921,t:1528143843259};\\\", \\\"{x:1206,y:919,t:1528143843275};\\\", \\\"{x:1205,y:918,t:1528143843291};\\\", \\\"{x:1205,y:916,t:1528143843346};\\\", \\\"{x:1205,y:915,t:1528143843358};\\\", \\\"{x:1204,y:913,t:1528143843374};\\\", \\\"{x:1204,y:912,t:1528143843392};\\\", \\\"{x:1205,y:912,t:1528143845788};\\\", \\\"{x:1206,y:912,t:1528143845795};\\\", \\\"{x:1208,y:912,t:1528143845811};\\\", \\\"{x:1209,y:912,t:1528143845827};\\\", \\\"{x:1210,y:912,t:1528143846811};\\\", \\\"{x:1211,y:912,t:1528143846829};\\\", \\\"{x:1212,y:912,t:1528143846844};\\\", \\\"{x:1213,y:913,t:1528143846862};\\\", \\\"{x:1215,y:910,t:1528143849428};\\\", \\\"{x:1218,y:906,t:1528143849435};\\\", \\\"{x:1223,y:901,t:1528143849448};\\\", \\\"{x:1237,y:888,t:1528143849466};\\\", \\\"{x:1249,y:877,t:1528143849481};\\\", \\\"{x:1260,y:868,t:1528143849498};\\\", \\\"{x:1277,y:853,t:1528143849515};\\\", \\\"{x:1291,y:839,t:1528143849531};\\\", \\\"{x:1307,y:822,t:1528143849548};\\\", \\\"{x:1328,y:777,t:1528143849566};\\\", \\\"{x:1357,y:688,t:1528143849582};\\\", \\\"{x:1365,y:575,t:1528143849598};\\\", \\\"{x:1369,y:497,t:1528143849615};\\\", \\\"{x:1375,y:474,t:1528143849632};\\\", \\\"{x:1383,y:464,t:1528143849648};\\\", \\\"{x:1393,y:459,t:1528143849665};\\\", \\\"{x:1402,y:455,t:1528143849682};\\\", \\\"{x:1408,y:452,t:1528143849699};\\\", \\\"{x:1411,y:450,t:1528143849715};\\\", \\\"{x:1412,y:449,t:1528143849731};\\\", \\\"{x:1413,y:448,t:1528143849748};\\\", \\\"{x:1413,y:450,t:1528143849844};\\\", \\\"{x:1413,y:458,t:1528143849851};\\\", \\\"{x:1413,y:469,t:1528143849865};\\\", \\\"{x:1409,y:491,t:1528143849883};\\\", \\\"{x:1404,y:512,t:1528143849899};\\\", \\\"{x:1393,y:538,t:1528143849915};\\\", \\\"{x:1386,y:548,t:1528143849932};\\\", \\\"{x:1381,y:555,t:1528143849947};\\\", \\\"{x:1377,y:562,t:1528143849965};\\\", \\\"{x:1376,y:565,t:1528143849982};\\\", \\\"{x:1376,y:566,t:1528143849998};\\\", \\\"{x:1379,y:563,t:1528143850050};\\\", \\\"{x:1382,y:560,t:1528143850064};\\\", \\\"{x:1387,y:550,t:1528143850082};\\\", \\\"{x:1398,y:532,t:1528143850098};\\\", \\\"{x:1402,y:525,t:1528143850114};\\\", \\\"{x:1405,y:517,t:1528143850132};\\\", \\\"{x:1405,y:513,t:1528143850149};\\\", \\\"{x:1405,y:511,t:1528143850165};\\\", \\\"{x:1406,y:509,t:1528143850182};\\\", \\\"{x:1406,y:508,t:1528143850199};\\\", \\\"{x:1407,y:506,t:1528143850215};\\\", \\\"{x:1408,y:504,t:1528143850232};\\\", \\\"{x:1409,y:503,t:1528143850249};\\\", \\\"{x:1411,y:501,t:1528143850265};\\\", \\\"{x:1412,y:500,t:1528143850282};\\\", \\\"{x:1399,y:500,t:1528143850804};\\\", \\\"{x:1378,y:500,t:1528143850816};\\\", \\\"{x:1308,y:500,t:1528143850833};\\\", \\\"{x:1200,y:500,t:1528143850849};\\\", \\\"{x:1079,y:500,t:1528143850867};\\\", \\\"{x:893,y:500,t:1528143850884};\\\", \\\"{x:785,y:500,t:1528143850898};\\\", \\\"{x:702,y:500,t:1528143850916};\\\", \\\"{x:645,y:494,t:1528143850930};\\\", \\\"{x:432,y:472,t:1528143850947};\\\", \\\"{x:382,y:472,t:1528143850963};\\\", \\\"{x:350,y:472,t:1528143850980};\\\", \\\"{x:297,y:472,t:1528143850996};\\\", \\\"{x:271,y:472,t:1528143851013};\\\", \\\"{x:270,y:474,t:1528143851155};\\\", \\\"{x:273,y:479,t:1528143851164};\\\", \\\"{x:291,y:486,t:1528143851180};\\\", \\\"{x:314,y:493,t:1528143851197};\\\", \\\"{x:338,y:496,t:1528143851214};\\\", \\\"{x:358,y:499,t:1528143851229};\\\", \\\"{x:367,y:502,t:1528143851247};\\\", \\\"{x:372,y:504,t:1528143851265};\\\", \\\"{x:372,y:505,t:1528143851280};\\\", \\\"{x:372,y:503,t:1528143851443};\\\", \\\"{x:372,y:501,t:1528143851452};\\\", \\\"{x:372,y:499,t:1528143851464};\\\", \\\"{x:372,y:495,t:1528143851479};\\\", \\\"{x:372,y:490,t:1528143851496};\\\", \\\"{x:372,y:487,t:1528143851514};\\\", \\\"{x:372,y:483,t:1528143851530};\\\", \\\"{x:372,y:478,t:1528143851547};\\\", \\\"{x:371,y:474,t:1528143851563};\\\", \\\"{x:370,y:470,t:1528143851580};\\\", \\\"{x:367,y:467,t:1528143851597};\\\", \\\"{x:365,y:465,t:1528143851614};\\\", \\\"{x:360,y:462,t:1528143851631};\\\", \\\"{x:357,y:462,t:1528143851647};\\\", \\\"{x:352,y:462,t:1528143851664};\\\", \\\"{x:351,y:462,t:1528143851681};\\\", \\\"{x:350,y:462,t:1528143851706};\\\", \\\"{x:350,y:463,t:1528143851722};\\\", \\\"{x:352,y:464,t:1528143851731};\\\", \\\"{x:354,y:466,t:1528143851747};\\\", \\\"{x:356,y:467,t:1528143851763};\\\", \\\"{x:356,y:468,t:1528143851780};\\\", \\\"{x:356,y:469,t:1528143851797};\\\", \\\"{x:356,y:470,t:1528143851814};\\\", \\\"{x:354,y:473,t:1528143851831};\\\", \\\"{x:348,y:478,t:1528143851846};\\\", \\\"{x:333,y:485,t:1528143851864};\\\", \\\"{x:311,y:491,t:1528143851881};\\\", \\\"{x:288,y:493,t:1528143851896};\\\", \\\"{x:260,y:498,t:1528143851914};\\\", \\\"{x:223,y:503,t:1528143851931};\\\", \\\"{x:206,y:509,t:1528143851947};\\\", \\\"{x:200,y:510,t:1528143851965};\\\", \\\"{x:197,y:512,t:1528143851981};\\\", \\\"{x:197,y:514,t:1528143852051};\\\", \\\"{x:197,y:516,t:1528143852064};\\\", \\\"{x:197,y:523,t:1528143852081};\\\", \\\"{x:193,y:531,t:1528143852098};\\\", \\\"{x:192,y:535,t:1528143852114};\\\", \\\"{x:190,y:542,t:1528143852130};\\\", \\\"{x:190,y:544,t:1528143852147};\\\", \\\"{x:190,y:545,t:1528143852163};\\\", \\\"{x:190,y:546,t:1528143852186};\\\", \\\"{x:190,y:547,t:1528143852197};\\\", \\\"{x:192,y:547,t:1528143852214};\\\", \\\"{x:193,y:547,t:1528143852231};\\\", \\\"{x:195,y:547,t:1528143852259};\\\", \\\"{x:197,y:547,t:1528143852267};\\\", \\\"{x:204,y:547,t:1528143852282};\\\", \\\"{x:226,y:547,t:1528143852298};\\\", \\\"{x:275,y:544,t:1528143852314};\\\", \\\"{x:342,y:544,t:1528143852331};\\\", \\\"{x:431,y:558,t:1528143852349};\\\", \\\"{x:517,y:569,t:1528143852365};\\\", \\\"{x:605,y:576,t:1528143852380};\\\", \\\"{x:664,y:578,t:1528143852397};\\\", \\\"{x:697,y:578,t:1528143852415};\\\", \\\"{x:710,y:578,t:1528143852431};\\\", \\\"{x:712,y:578,t:1528143852447};\\\", \\\"{x:713,y:577,t:1528143852482};\\\", \\\"{x:715,y:576,t:1528143852498};\\\", \\\"{x:722,y:571,t:1528143852514};\\\", \\\"{x:729,y:568,t:1528143852533};\\\", \\\"{x:734,y:564,t:1528143852548};\\\", \\\"{x:736,y:563,t:1528143852564};\\\", \\\"{x:736,y:562,t:1528143852610};\\\", \\\"{x:736,y:561,t:1528143852618};\\\", \\\"{x:736,y:557,t:1528143852630};\\\", \\\"{x:735,y:548,t:1528143852648};\\\", \\\"{x:732,y:539,t:1528143852665};\\\", \\\"{x:724,y:530,t:1528143852681};\\\", \\\"{x:715,y:521,t:1528143852699};\\\", \\\"{x:705,y:509,t:1528143852714};\\\", \\\"{x:696,y:502,t:1528143852731};\\\", \\\"{x:690,y:497,t:1528143852748};\\\", \\\"{x:685,y:493,t:1528143852765};\\\", \\\"{x:680,y:489,t:1528143852781};\\\", \\\"{x:678,y:488,t:1528143852798};\\\", \\\"{x:676,y:487,t:1528143852815};\\\", \\\"{x:673,y:484,t:1528143852831};\\\", \\\"{x:671,y:482,t:1528143852848};\\\", \\\"{x:666,y:481,t:1528143852865};\\\", \\\"{x:655,y:479,t:1528143852881};\\\", \\\"{x:645,y:477,t:1528143852898};\\\", \\\"{x:627,y:476,t:1528143852915};\\\", \\\"{x:614,y:473,t:1528143852933};\\\", \\\"{x:598,y:473,t:1528143852948};\\\", \\\"{x:578,y:473,t:1528143852965};\\\", \\\"{x:556,y:479,t:1528143852982};\\\", \\\"{x:533,y:485,t:1528143852999};\\\", \\\"{x:512,y:492,t:1528143853015};\\\", \\\"{x:495,y:497,t:1528143853033};\\\", \\\"{x:479,y:506,t:1528143853049};\\\", \\\"{x:465,y:513,t:1528143853065};\\\", \\\"{x:452,y:521,t:1528143853082};\\\", \\\"{x:438,y:529,t:1528143853097};\\\", \\\"{x:417,y:540,t:1528143853114};\\\", \\\"{x:407,y:545,t:1528143853132};\\\", \\\"{x:398,y:549,t:1528143853148};\\\", \\\"{x:388,y:552,t:1528143853164};\\\", \\\"{x:384,y:552,t:1528143853182};\\\", \\\"{x:382,y:553,t:1528143853197};\\\", \\\"{x:381,y:554,t:1528143853215};\\\", \\\"{x:379,y:554,t:1528143853231};\\\", \\\"{x:376,y:555,t:1528143853248};\\\", \\\"{x:373,y:556,t:1528143853265};\\\", \\\"{x:368,y:557,t:1528143853281};\\\", \\\"{x:365,y:558,t:1528143853298};\\\", \\\"{x:361,y:559,t:1528143853315};\\\", \\\"{x:360,y:559,t:1528143853371};\\\", \\\"{x:360,y:557,t:1528143853382};\\\", \\\"{x:361,y:552,t:1528143853398};\\\", \\\"{x:362,y:545,t:1528143853415};\\\", \\\"{x:363,y:540,t:1528143853432};\\\", \\\"{x:366,y:535,t:1528143853449};\\\", \\\"{x:367,y:529,t:1528143853464};\\\", \\\"{x:367,y:525,t:1528143853482};\\\", \\\"{x:369,y:518,t:1528143853498};\\\", \\\"{x:370,y:515,t:1528143853515};\\\", \\\"{x:371,y:514,t:1528143853532};\\\", \\\"{x:372,y:510,t:1528143853549};\\\", \\\"{x:373,y:508,t:1528143853565};\\\", \\\"{x:374,y:505,t:1528143853582};\\\", \\\"{x:374,y:501,t:1528143853599};\\\", \\\"{x:376,y:499,t:1528143853614};\\\", \\\"{x:376,y:497,t:1528143853632};\\\", \\\"{x:376,y:493,t:1528143853649};\\\", \\\"{x:378,y:491,t:1528143853664};\\\", \\\"{x:380,y:489,t:1528143853681};\\\", \\\"{x:380,y:486,t:1528143853698};\\\", \\\"{x:380,y:484,t:1528143853716};\\\", \\\"{x:381,y:483,t:1528143853731};\\\", \\\"{x:382,y:481,t:1528143853748};\\\", \\\"{x:386,y:476,t:1528143853766};\\\", \\\"{x:388,y:471,t:1528143853782};\\\", \\\"{x:391,y:468,t:1528143853799};\\\", \\\"{x:391,y:467,t:1528143853815};\\\", \\\"{x:392,y:466,t:1528143853832};\\\", \\\"{x:394,y:465,t:1528143853849};\\\", \\\"{x:403,y:460,t:1528143853866};\\\", \\\"{x:421,y:458,t:1528143853881};\\\", \\\"{x:467,y:457,t:1528143853898};\\\", \\\"{x:506,y:457,t:1528143853917};\\\", \\\"{x:564,y:457,t:1528143853932};\\\", \\\"{x:623,y:457,t:1528143853949};\\\", \\\"{x:698,y:457,t:1528143853966};\\\", \\\"{x:770,y:457,t:1528143853983};\\\", \\\"{x:850,y:464,t:1528143853999};\\\", \\\"{x:919,y:472,t:1528143854016};\\\", \\\"{x:970,y:480,t:1528143854033};\\\", \\\"{x:990,y:482,t:1528143854049};\\\", \\\"{x:995,y:482,t:1528143854065};\\\", \\\"{x:993,y:483,t:1528143854131};\\\", \\\"{x:988,y:483,t:1528143854139};\\\", \\\"{x:981,y:484,t:1528143854149};\\\", \\\"{x:961,y:487,t:1528143854167};\\\", \\\"{x:932,y:491,t:1528143854184};\\\", \\\"{x:904,y:493,t:1528143854199};\\\", \\\"{x:882,y:493,t:1528143854216};\\\", \\\"{x:865,y:493,t:1528143854234};\\\", \\\"{x:853,y:493,t:1528143854249};\\\", \\\"{x:850,y:493,t:1528143854266};\\\", \\\"{x:849,y:493,t:1528143854290};\\\", \\\"{x:848,y:493,t:1528143854459};\\\", \\\"{x:847,y:493,t:1528143854491};\\\", \\\"{x:846,y:493,t:1528143854506};\\\", \\\"{x:845,y:493,t:1528143854762};\\\", \\\"{x:842,y:497,t:1528143854770};\\\", \\\"{x:839,y:500,t:1528143854783};\\\", \\\"{x:829,y:510,t:1528143854800};\\\", \\\"{x:813,y:524,t:1528143854816};\\\", \\\"{x:786,y:543,t:1528143854833};\\\", \\\"{x:753,y:564,t:1528143854850};\\\", \\\"{x:718,y:583,t:1528143854866};\\\", \\\"{x:671,y:605,t:1528143854883};\\\", \\\"{x:639,y:622,t:1528143854900};\\\", \\\"{x:609,y:639,t:1528143854916};\\\", \\\"{x:579,y:658,t:1528143854933};\\\", \\\"{x:558,y:669,t:1528143854951};\\\", \\\"{x:542,y:679,t:1528143854966};\\\", \\\"{x:531,y:685,t:1528143854983};\\\", \\\"{x:526,y:688,t:1528143855000};\\\", \\\"{x:523,y:689,t:1528143855015};\\\", \\\"{x:519,y:691,t:1528143855033};\\\", \\\"{x:512,y:695,t:1528143855050};\\\", \\\"{x:511,y:695,t:1528143855066};\\\", \\\"{x:510,y:695,t:1528143855083};\\\", \\\"{x:509,y:695,t:1528143855099};\\\", \\\"{x:508,y:695,t:1528143855117};\\\", \\\"{x:507,y:695,t:1528143855134};\\\", \\\"{x:506,y:695,t:1528143855149};\\\", \\\"{x:506,y:693,t:1528143855166};\\\", \\\"{x:506,y:689,t:1528143855183};\\\", \\\"{x:506,y:686,t:1528143855199};\\\", \\\"{x:506,y:684,t:1528143855217};\\\", \\\"{x:506,y:682,t:1528143855233};\\\", \\\"{x:506,y:681,t:1528143855249};\\\", \\\"{x:506,y:680,t:1528143855298};\\\", \\\"{x:506,y:679,t:1528143855322};\\\", \\\"{x:505,y:679,t:1528143855395};\\\", \\\"{x:504,y:678,t:1528143855410};\\\", \\\"{x:513,y:684,t:1528143856571};\\\", \\\"{x:523,y:690,t:1528143856584};\\\", \\\"{x:546,y:701,t:1528143856601};\\\", \\\"{x:582,y:712,t:1528143856617};\\\", \\\"{x:629,y:726,t:1528143856634};\\\", \\\"{x:699,y:737,t:1528143856651};\\\", \\\"{x:723,y:743,t:1528143856668};\\\", \\\"{x:741,y:748,t:1528143856684};\\\", \\\"{x:758,y:750,t:1528143856701};\\\", \\\"{x:769,y:752,t:1528143856718};\\\", \\\"{x:779,y:754,t:1528143856734};\\\", \\\"{x:787,y:754,t:1528143856751};\\\", \\\"{x:790,y:754,t:1528143856768};\\\", \\\"{x:789,y:754,t:1528143857067};\\\", \\\"{x:787,y:754,t:1528143857099};\\\", \\\"{x:786,y:754,t:1528143857131};\\\", \\\"{x:785,y:753,t:1528143857163};\\\", \\\"{x:784,y:753,t:1528143857212};\\\", \\\"{x:783,y:750,t:1528143857219};\\\", \\\"{x:782,y:746,t:1528143857235};\\\", \\\"{x:782,y:745,t:1528143857251};\\\", \\\"{x:781,y:745,t:1528143857292};\\\", \\\"{x:781,y:744,t:1528143857419};\\\" ] }, { \\\"rt\\\": 23372, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 402171, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"8182H\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 3, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:780,y:743,t:1528143857535};\\\", \\\"{x:780,y:739,t:1528143857682};\\\", \\\"{x:780,y:736,t:1528143857690};\\\", \\\"{x:780,y:734,t:1528143857702};\\\", \\\"{x:780,y:733,t:1528143857730};\\\", \\\"{x:780,y:732,t:1528143857746};\\\", \\\"{x:780,y:731,t:1528143857762};\\\", \\\"{x:780,y:730,t:1528143857771};\\\", \\\"{x:780,y:728,t:1528143857786};\\\", \\\"{x:782,y:720,t:1528143857802};\\\", \\\"{x:782,y:708,t:1528143857818};\\\", \\\"{x:782,y:694,t:1528143857835};\\\", \\\"{x:778,y:683,t:1528143857852};\\\", \\\"{x:773,y:673,t:1528143857870};\\\", \\\"{x:768,y:661,t:1528143857885};\\\", \\\"{x:764,y:649,t:1528143857902};\\\", \\\"{x:761,y:641,t:1528143857919};\\\", \\\"{x:759,y:633,t:1528143857935};\\\", \\\"{x:755,y:627,t:1528143857952};\\\", \\\"{x:753,y:622,t:1528143857969};\\\", \\\"{x:752,y:611,t:1528143857985};\\\", \\\"{x:751,y:601,t:1528143858003};\\\", \\\"{x:751,y:599,t:1528143858019};\\\", \\\"{x:752,y:599,t:1528143858347};\\\", \\\"{x:753,y:599,t:1528143858354};\\\", \\\"{x:756,y:599,t:1528143858369};\\\", \\\"{x:767,y:602,t:1528143858386};\\\", \\\"{x:785,y:603,t:1528143858403};\\\", \\\"{x:807,y:605,t:1528143858420};\\\", \\\"{x:817,y:608,t:1528143858437};\\\", \\\"{x:820,y:609,t:1528143858453};\\\", \\\"{x:820,y:610,t:1528143858469};\\\", \\\"{x:820,y:611,t:1528143858843};\\\", \\\"{x:819,y:611,t:1528143858859};\\\", \\\"{x:818,y:611,t:1528143858874};\\\", \\\"{x:818,y:613,t:1528143858886};\\\", \\\"{x:820,y:614,t:1528143858903};\\\", \\\"{x:823,y:613,t:1528143861507};\\\", \\\"{x:836,y:605,t:1528143861522};\\\", \\\"{x:859,y:594,t:1528143861539};\\\", \\\"{x:862,y:593,t:1528143861556};\\\", \\\"{x:865,y:593,t:1528143861627};\\\", \\\"{x:873,y:593,t:1528143861639};\\\", \\\"{x:912,y:600,t:1528143861656};\\\", \\\"{x:957,y:606,t:1528143861671};\\\", \\\"{x:1007,y:613,t:1528143861689};\\\", \\\"{x:1043,y:623,t:1528143861705};\\\", \\\"{x:1082,y:633,t:1528143861723};\\\", \\\"{x:1113,y:643,t:1528143861738};\\\", \\\"{x:1126,y:646,t:1528143861755};\\\", \\\"{x:1138,y:650,t:1528143861772};\\\", \\\"{x:1152,y:656,t:1528143861788};\\\", \\\"{x:1167,y:661,t:1528143861805};\\\", \\\"{x:1177,y:666,t:1528143861822};\\\", \\\"{x:1185,y:670,t:1528143861839};\\\", \\\"{x:1191,y:672,t:1528143861855};\\\", \\\"{x:1194,y:674,t:1528143861873};\\\", \\\"{x:1202,y:681,t:1528143861889};\\\", \\\"{x:1222,y:696,t:1528143861906};\\\", \\\"{x:1284,y:728,t:1528143861923};\\\", \\\"{x:1322,y:742,t:1528143861939};\\\", \\\"{x:1349,y:749,t:1528143861955};\\\", \\\"{x:1376,y:757,t:1528143861973};\\\", \\\"{x:1402,y:768,t:1528143861989};\\\", \\\"{x:1418,y:776,t:1528143862006};\\\", \\\"{x:1424,y:779,t:1528143862023};\\\", \\\"{x:1425,y:778,t:1528143863916};\\\", \\\"{x:1425,y:776,t:1528143863924};\\\", \\\"{x:1425,y:774,t:1528143863941};\\\", \\\"{x:1425,y:773,t:1528143863958};\\\", \\\"{x:1425,y:772,t:1528143863974};\\\", \\\"{x:1425,y:771,t:1528143864003};\\\", \\\"{x:1425,y:770,t:1528143864403};\\\", \\\"{x:1425,y:768,t:1528143864419};\\\", \\\"{x:1425,y:764,t:1528143864427};\\\", \\\"{x:1425,y:763,t:1528143864441};\\\", \\\"{x:1425,y:762,t:1528143864458};\\\", \\\"{x:1425,y:761,t:1528143864475};\\\", \\\"{x:1425,y:760,t:1528143864507};\\\", \\\"{x:1425,y:757,t:1528143865131};\\\", \\\"{x:1418,y:755,t:1528143865142};\\\", \\\"{x:1395,y:746,t:1528143865158};\\\", \\\"{x:1374,y:741,t:1528143865175};\\\", \\\"{x:1353,y:735,t:1528143865192};\\\", \\\"{x:1326,y:730,t:1528143865208};\\\", \\\"{x:1305,y:728,t:1528143865225};\\\", \\\"{x:1291,y:725,t:1528143865242};\\\", \\\"{x:1284,y:725,t:1528143865259};\\\", \\\"{x:1283,y:725,t:1528143865332};\\\", \\\"{x:1284,y:725,t:1528143865523};\\\", \\\"{x:1291,y:721,t:1528143865531};\\\", \\\"{x:1304,y:715,t:1528143865542};\\\", \\\"{x:1330,y:702,t:1528143865559};\\\", \\\"{x:1367,y:685,t:1528143865575};\\\", \\\"{x:1394,y:669,t:1528143865592};\\\", \\\"{x:1416,y:656,t:1528143865609};\\\", \\\"{x:1431,y:644,t:1528143865625};\\\", \\\"{x:1445,y:634,t:1528143865642};\\\", \\\"{x:1457,y:608,t:1528143865659};\\\", \\\"{x:1460,y:590,t:1528143865675};\\\", \\\"{x:1460,y:581,t:1528143865692};\\\", \\\"{x:1460,y:575,t:1528143865709};\\\", \\\"{x:1459,y:567,t:1528143865725};\\\", \\\"{x:1457,y:561,t:1528143865742};\\\", \\\"{x:1455,y:554,t:1528143865759};\\\", \\\"{x:1455,y:551,t:1528143865776};\\\", \\\"{x:1455,y:548,t:1528143865793};\\\", \\\"{x:1455,y:546,t:1528143865810};\\\", \\\"{x:1455,y:545,t:1528143865826};\\\", \\\"{x:1456,y:543,t:1528143865842};\\\", \\\"{x:1464,y:543,t:1528143865859};\\\", \\\"{x:1471,y:543,t:1528143865876};\\\", \\\"{x:1488,y:543,t:1528143865892};\\\", \\\"{x:1510,y:548,t:1528143865909};\\\", \\\"{x:1532,y:557,t:1528143865926};\\\", \\\"{x:1557,y:569,t:1528143865942};\\\", \\\"{x:1585,y:585,t:1528143865959};\\\", \\\"{x:1613,y:600,t:1528143865977};\\\", \\\"{x:1632,y:611,t:1528143865992};\\\", \\\"{x:1645,y:620,t:1528143866009};\\\", \\\"{x:1652,y:623,t:1528143866026};\\\", \\\"{x:1654,y:625,t:1528143866043};\\\", \\\"{x:1655,y:627,t:1528143866059};\\\", \\\"{x:1655,y:630,t:1528143866076};\\\", \\\"{x:1656,y:635,t:1528143866092};\\\", \\\"{x:1657,y:639,t:1528143866109};\\\", \\\"{x:1660,y:647,t:1528143866126};\\\", \\\"{x:1661,y:652,t:1528143866143};\\\", \\\"{x:1663,y:657,t:1528143866159};\\\", \\\"{x:1665,y:659,t:1528143866176};\\\", \\\"{x:1665,y:660,t:1528143866193};\\\", \\\"{x:1665,y:662,t:1528143866209};\\\", \\\"{x:1666,y:663,t:1528143866226};\\\", \\\"{x:1666,y:664,t:1528143866323};\\\", \\\"{x:1664,y:664,t:1528143866339};\\\", \\\"{x:1656,y:664,t:1528143866347};\\\", \\\"{x:1645,y:660,t:1528143866359};\\\", \\\"{x:1623,y:655,t:1528143866376};\\\", \\\"{x:1609,y:651,t:1528143866393};\\\", \\\"{x:1595,y:647,t:1528143866409};\\\", \\\"{x:1591,y:645,t:1528143866425};\\\", \\\"{x:1592,y:645,t:1528143866659};\\\", \\\"{x:1594,y:645,t:1528143866676};\\\", \\\"{x:1595,y:646,t:1528143866707};\\\", \\\"{x:1596,y:646,t:1528143866755};\\\", \\\"{x:1597,y:646,t:1528143866763};\\\", \\\"{x:1598,y:646,t:1528143866779};\\\", \\\"{x:1600,y:646,t:1528143866793};\\\", \\\"{x:1602,y:647,t:1528143866810};\\\", \\\"{x:1603,y:647,t:1528143866826};\\\", \\\"{x:1604,y:648,t:1528143866947};\\\", \\\"{x:1605,y:648,t:1528143866971};\\\", \\\"{x:1605,y:652,t:1528143866995};\\\", \\\"{x:1605,y:657,t:1528143867010};\\\", \\\"{x:1604,y:673,t:1528143867026};\\\", \\\"{x:1594,y:688,t:1528143867043};\\\", \\\"{x:1586,y:698,t:1528143867060};\\\", \\\"{x:1581,y:706,t:1528143867077};\\\", \\\"{x:1576,y:717,t:1528143867094};\\\", \\\"{x:1566,y:738,t:1528143867110};\\\", \\\"{x:1554,y:762,t:1528143867127};\\\", \\\"{x:1540,y:787,t:1528143867143};\\\", \\\"{x:1524,y:806,t:1528143867160};\\\", \\\"{x:1514,y:824,t:1528143867178};\\\", \\\"{x:1509,y:835,t:1528143867193};\\\", \\\"{x:1508,y:843,t:1528143867210};\\\", \\\"{x:1508,y:850,t:1528143867227};\\\", \\\"{x:1508,y:856,t:1528143867243};\\\", \\\"{x:1508,y:861,t:1528143867260};\\\", \\\"{x:1508,y:870,t:1528143867277};\\\", \\\"{x:1508,y:880,t:1528143867293};\\\", \\\"{x:1504,y:890,t:1528143867309};\\\", \\\"{x:1502,y:895,t:1528143867326};\\\", \\\"{x:1501,y:897,t:1528143867342};\\\", \\\"{x:1501,y:899,t:1528143867359};\\\", \\\"{x:1500,y:900,t:1528143867376};\\\", \\\"{x:1498,y:901,t:1528143867392};\\\", \\\"{x:1497,y:902,t:1528143867409};\\\", \\\"{x:1496,y:903,t:1528143867426};\\\", \\\"{x:1495,y:903,t:1528143867443};\\\", \\\"{x:1492,y:904,t:1528143867459};\\\", \\\"{x:1489,y:905,t:1528143867477};\\\", \\\"{x:1485,y:906,t:1528143867494};\\\", \\\"{x:1483,y:907,t:1528143867509};\\\", \\\"{x:1482,y:907,t:1528143867527};\\\", \\\"{x:1481,y:907,t:1528143867544};\\\", \\\"{x:1480,y:907,t:1528143867611};\\\", \\\"{x:1479,y:907,t:1528143869548};\\\", \\\"{x:1474,y:901,t:1528143869571};\\\", \\\"{x:1472,y:892,t:1528143869579};\\\", \\\"{x:1464,y:881,t:1528143869595};\\\", \\\"{x:1461,y:875,t:1528143869612};\\\", \\\"{x:1459,y:873,t:1528143869628};\\\", \\\"{x:1456,y:869,t:1528143869645};\\\", \\\"{x:1456,y:867,t:1528143869662};\\\", \\\"{x:1456,y:866,t:1528143869691};\\\", \\\"{x:1456,y:865,t:1528143869707};\\\", \\\"{x:1456,y:864,t:1528143869714};\\\", \\\"{x:1456,y:863,t:1528143869729};\\\", \\\"{x:1456,y:861,t:1528143869745};\\\", \\\"{x:1455,y:859,t:1528143869762};\\\", \\\"{x:1455,y:856,t:1528143869779};\\\", \\\"{x:1454,y:855,t:1528143869796};\\\", \\\"{x:1454,y:853,t:1528143869812};\\\", \\\"{x:1454,y:851,t:1528143869829};\\\", \\\"{x:1454,y:850,t:1528143869846};\\\", \\\"{x:1454,y:848,t:1528143869862};\\\", \\\"{x:1453,y:845,t:1528143869879};\\\", \\\"{x:1453,y:844,t:1528143869895};\\\", \\\"{x:1452,y:840,t:1528143869912};\\\", \\\"{x:1452,y:838,t:1528143869929};\\\", \\\"{x:1452,y:834,t:1528143869945};\\\", \\\"{x:1452,y:831,t:1528143869963};\\\", \\\"{x:1450,y:826,t:1528143869979};\\\", \\\"{x:1450,y:823,t:1528143869995};\\\", \\\"{x:1449,y:819,t:1528143870013};\\\", \\\"{x:1448,y:815,t:1528143870029};\\\", \\\"{x:1445,y:806,t:1528143870045};\\\", \\\"{x:1435,y:783,t:1528143870062};\\\", \\\"{x:1427,y:756,t:1528143870079};\\\", \\\"{x:1420,y:742,t:1528143870096};\\\", \\\"{x:1417,y:735,t:1528143870112};\\\", \\\"{x:1414,y:731,t:1528143870129};\\\", \\\"{x:1410,y:725,t:1528143870147};\\\", \\\"{x:1406,y:718,t:1528143870162};\\\", \\\"{x:1389,y:689,t:1528143870179};\\\", \\\"{x:1381,y:669,t:1528143870196};\\\", \\\"{x:1368,y:648,t:1528143870213};\\\", \\\"{x:1360,y:633,t:1528143870229};\\\", \\\"{x:1356,y:622,t:1528143870246};\\\", \\\"{x:1352,y:616,t:1528143870262};\\\", \\\"{x:1350,y:608,t:1528143870279};\\\", \\\"{x:1348,y:602,t:1528143870295};\\\", \\\"{x:1347,y:599,t:1528143870311};\\\", \\\"{x:1346,y:597,t:1528143870328};\\\", \\\"{x:1346,y:595,t:1528143870345};\\\", \\\"{x:1345,y:594,t:1528143870491};\\\", \\\"{x:1344,y:593,t:1528143870555};\\\", \\\"{x:1343,y:592,t:1528143870571};\\\", \\\"{x:1339,y:585,t:1528143870579};\\\", \\\"{x:1331,y:575,t:1528143870596};\\\", \\\"{x:1312,y:557,t:1528143870613};\\\", \\\"{x:1246,y:498,t:1528143870629};\\\", \\\"{x:1171,y:431,t:1528143870646};\\\", \\\"{x:1131,y:402,t:1528143870664};\\\", \\\"{x:1112,y:388,t:1528143870679};\\\", \\\"{x:1096,y:377,t:1528143870696};\\\", \\\"{x:1081,y:367,t:1528143870714};\\\", \\\"{x:1070,y:356,t:1528143870730};\\\", \\\"{x:1056,y:345,t:1528143870746};\\\", \\\"{x:1033,y:328,t:1528143870763};\\\", \\\"{x:1013,y:321,t:1528143870779};\\\", \\\"{x:989,y:310,t:1528143870796};\\\", \\\"{x:960,y:302,t:1528143870813};\\\", \\\"{x:934,y:294,t:1528143870829};\\\", \\\"{x:898,y:284,t:1528143870846};\\\", \\\"{x:865,y:277,t:1528143870864};\\\", \\\"{x:839,y:273,t:1528143870879};\\\", \\\"{x:804,y:269,t:1528143870896};\\\", \\\"{x:775,y:269,t:1528143870913};\\\", \\\"{x:728,y:284,t:1528143870929};\\\", \\\"{x:687,y:307,t:1528143870946};\\\", \\\"{x:643,y:334,t:1528143870963};\\\", \\\"{x:622,y:351,t:1528143870979};\\\", \\\"{x:610,y:365,t:1528143870996};\\\", \\\"{x:601,y:376,t:1528143871013};\\\", \\\"{x:595,y:383,t:1528143871029};\\\", \\\"{x:593,y:389,t:1528143871046};\\\", \\\"{x:591,y:396,t:1528143871063};\\\", \\\"{x:587,y:411,t:1528143871080};\\\", \\\"{x:582,y:430,t:1528143871096};\\\", \\\"{x:575,y:450,t:1528143871114};\\\", \\\"{x:570,y:467,t:1528143871130};\\\", \\\"{x:566,y:477,t:1528143871146};\\\", \\\"{x:562,y:486,t:1528143871179};\\\", \\\"{x:562,y:488,t:1528143871195};\\\", \\\"{x:562,y:489,t:1528143871212};\\\", \\\"{x:562,y:491,t:1528143871229};\\\", \\\"{x:560,y:495,t:1528143871247};\\\", \\\"{x:556,y:500,t:1528143871262};\\\", \\\"{x:551,y:503,t:1528143871280};\\\", \\\"{x:547,y:505,t:1528143871296};\\\", \\\"{x:540,y:507,t:1528143871313};\\\", \\\"{x:535,y:509,t:1528143871329};\\\", \\\"{x:524,y:510,t:1528143871346};\\\", \\\"{x:513,y:514,t:1528143871362};\\\", \\\"{x:504,y:516,t:1528143871380};\\\", \\\"{x:490,y:519,t:1528143871398};\\\", \\\"{x:479,y:521,t:1528143871413};\\\", \\\"{x:467,y:522,t:1528143871429};\\\", \\\"{x:455,y:524,t:1528143871446};\\\", \\\"{x:430,y:524,t:1528143871463};\\\", \\\"{x:414,y:524,t:1528143871480};\\\", \\\"{x:399,y:524,t:1528143871497};\\\", \\\"{x:384,y:524,t:1528143871515};\\\", \\\"{x:366,y:524,t:1528143871530};\\\", \\\"{x:352,y:524,t:1528143871546};\\\", \\\"{x:349,y:523,t:1528143871562};\\\", \\\"{x:344,y:522,t:1528143871580};\\\", \\\"{x:342,y:521,t:1528143871597};\\\", \\\"{x:340,y:520,t:1528143871614};\\\", \\\"{x:338,y:519,t:1528143871630};\\\", \\\"{x:335,y:518,t:1528143871647};\\\", \\\"{x:334,y:517,t:1528143871662};\\\", \\\"{x:333,y:517,t:1528143871682};\\\", \\\"{x:332,y:516,t:1528143871714};\\\", \\\"{x:329,y:515,t:1528143871730};\\\", \\\"{x:329,y:514,t:1528143871755};\\\", \\\"{x:328,y:513,t:1528143871764};\\\", \\\"{x:327,y:511,t:1528143871786};\\\", \\\"{x:326,y:511,t:1528143871796};\\\", \\\"{x:324,y:509,t:1528143871814};\\\", \\\"{x:320,y:507,t:1528143871829};\\\", \\\"{x:315,y:505,t:1528143871847};\\\", \\\"{x:310,y:504,t:1528143871863};\\\", \\\"{x:304,y:504,t:1528143871880};\\\", \\\"{x:297,y:503,t:1528143871896};\\\", \\\"{x:290,y:503,t:1528143871914};\\\", \\\"{x:284,y:503,t:1528143871929};\\\", \\\"{x:278,y:503,t:1528143871946};\\\", \\\"{x:277,y:503,t:1528143871964};\\\", \\\"{x:275,y:503,t:1528143871980};\\\", \\\"{x:273,y:503,t:1528143871996};\\\", \\\"{x:269,y:505,t:1528143872013};\\\", \\\"{x:263,y:510,t:1528143872031};\\\", \\\"{x:258,y:514,t:1528143872046};\\\", \\\"{x:253,y:519,t:1528143872063};\\\", \\\"{x:249,y:522,t:1528143872081};\\\", \\\"{x:245,y:524,t:1528143872096};\\\", \\\"{x:242,y:528,t:1528143872113};\\\", \\\"{x:236,y:532,t:1528143872130};\\\", \\\"{x:231,y:534,t:1528143872146};\\\", \\\"{x:229,y:535,t:1528143872163};\\\", \\\"{x:226,y:536,t:1528143872180};\\\", \\\"{x:224,y:538,t:1528143872197};\\\", \\\"{x:217,y:543,t:1528143872214};\\\", \\\"{x:206,y:549,t:1528143872231};\\\", \\\"{x:194,y:555,t:1528143872246};\\\", \\\"{x:184,y:561,t:1528143872264};\\\", \\\"{x:174,y:567,t:1528143872280};\\\", \\\"{x:168,y:571,t:1528143872297};\\\", \\\"{x:164,y:573,t:1528143872314};\\\", \\\"{x:164,y:574,t:1528143872331};\\\", \\\"{x:164,y:576,t:1528143872355};\\\", \\\"{x:165,y:577,t:1528143872370};\\\", \\\"{x:168,y:578,t:1528143872386};\\\", \\\"{x:170,y:579,t:1528143872398};\\\", \\\"{x:174,y:579,t:1528143872414};\\\", \\\"{x:178,y:580,t:1528143872431};\\\", \\\"{x:196,y:580,t:1528143872447};\\\", \\\"{x:217,y:575,t:1528143872464};\\\", \\\"{x:239,y:569,t:1528143872481};\\\", \\\"{x:267,y:562,t:1528143872497};\\\", \\\"{x:295,y:556,t:1528143872514};\\\", \\\"{x:319,y:553,t:1528143872531};\\\", \\\"{x:325,y:552,t:1528143872548};\\\", \\\"{x:329,y:552,t:1528143872564};\\\", \\\"{x:333,y:550,t:1528143872580};\\\", \\\"{x:336,y:549,t:1528143872598};\\\", \\\"{x:346,y:547,t:1528143872614};\\\", \\\"{x:361,y:544,t:1528143872631};\\\", \\\"{x:377,y:542,t:1528143872648};\\\", \\\"{x:391,y:542,t:1528143872664};\\\", \\\"{x:406,y:542,t:1528143872681};\\\", \\\"{x:418,y:542,t:1528143872697};\\\", \\\"{x:428,y:542,t:1528143872713};\\\", \\\"{x:438,y:542,t:1528143872731};\\\", \\\"{x:445,y:542,t:1528143872748};\\\", \\\"{x:449,y:542,t:1528143872764};\\\", \\\"{x:457,y:542,t:1528143872781};\\\", \\\"{x:472,y:542,t:1528143872798};\\\", \\\"{x:496,y:545,t:1528143872814};\\\", \\\"{x:520,y:547,t:1528143872831};\\\", \\\"{x:542,y:550,t:1528143872850};\\\", \\\"{x:562,y:550,t:1528143872864};\\\", \\\"{x:577,y:550,t:1528143872881};\\\", \\\"{x:589,y:550,t:1528143872897};\\\", \\\"{x:594,y:550,t:1528143872914};\\\", \\\"{x:605,y:550,t:1528143872930};\\\", \\\"{x:609,y:549,t:1528143872947};\\\", \\\"{x:615,y:546,t:1528143872964};\\\", \\\"{x:620,y:545,t:1528143872980};\\\", \\\"{x:624,y:542,t:1528143872998};\\\", \\\"{x:629,y:537,t:1528143873015};\\\", \\\"{x:637,y:527,t:1528143873031};\\\", \\\"{x:644,y:519,t:1528143873048};\\\", \\\"{x:644,y:516,t:1528143873063};\\\", \\\"{x:644,y:515,t:1528143873080};\\\", \\\"{x:645,y:510,t:1528143873098};\\\", \\\"{x:649,y:498,t:1528143873115};\\\", \\\"{x:652,y:487,t:1528143873130};\\\", \\\"{x:654,y:475,t:1528143873147};\\\", \\\"{x:654,y:471,t:1528143873166};\\\", \\\"{x:654,y:468,t:1528143873182};\\\", \\\"{x:654,y:465,t:1528143873198};\\\", \\\"{x:652,y:463,t:1528143873216};\\\", \\\"{x:651,y:460,t:1528143873231};\\\", \\\"{x:647,y:457,t:1528143873247};\\\", \\\"{x:641,y:455,t:1528143873265};\\\", \\\"{x:633,y:452,t:1528143873282};\\\", \\\"{x:629,y:451,t:1528143873297};\\\", \\\"{x:621,y:449,t:1528143873314};\\\", \\\"{x:614,y:449,t:1528143873331};\\\", \\\"{x:609,y:449,t:1528143873348};\\\", \\\"{x:605,y:449,t:1528143873365};\\\", \\\"{x:603,y:449,t:1528143873380};\\\", \\\"{x:602,y:450,t:1528143873483};\\\", \\\"{x:601,y:453,t:1528143873498};\\\", \\\"{x:585,y:469,t:1528143873520};\\\", \\\"{x:571,y:478,t:1528143873531};\\\", \\\"{x:557,y:485,t:1528143873547};\\\", \\\"{x:543,y:489,t:1528143873565};\\\", \\\"{x:532,y:490,t:1528143873582};\\\", \\\"{x:518,y:490,t:1528143873597};\\\", \\\"{x:503,y:490,t:1528143873615};\\\", \\\"{x:493,y:491,t:1528143873632};\\\", \\\"{x:484,y:491,t:1528143873648};\\\", \\\"{x:470,y:492,t:1528143873664};\\\", \\\"{x:456,y:495,t:1528143873681};\\\", \\\"{x:439,y:498,t:1528143873697};\\\", \\\"{x:414,y:501,t:1528143873715};\\\", \\\"{x:403,y:501,t:1528143873732};\\\", \\\"{x:396,y:501,t:1528143873748};\\\", \\\"{x:391,y:501,t:1528143873765};\\\", \\\"{x:388,y:501,t:1528143873781};\\\", \\\"{x:387,y:501,t:1528143873799};\\\", \\\"{x:387,y:503,t:1528143873948};\\\", \\\"{x:387,y:507,t:1528143873965};\\\", \\\"{x:387,y:511,t:1528143873982};\\\", \\\"{x:387,y:515,t:1528143873998};\\\", \\\"{x:387,y:522,t:1528143874014};\\\", \\\"{x:387,y:526,t:1528143874032};\\\", \\\"{x:387,y:529,t:1528143874048};\\\", \\\"{x:387,y:534,t:1528143874064};\\\", \\\"{x:387,y:537,t:1528143874082};\\\", \\\"{x:387,y:539,t:1528143874099};\\\", \\\"{x:386,y:540,t:1528143874211};\\\", \\\"{x:385,y:540,t:1528143874227};\\\", \\\"{x:384,y:540,t:1528143874235};\\\", \\\"{x:383,y:540,t:1528143874258};\\\", \\\"{x:384,y:540,t:1528143874339};\\\", \\\"{x:386,y:540,t:1528143874349};\\\", \\\"{x:386,y:542,t:1528143874469};\\\", \\\"{x:381,y:548,t:1528143874482};\\\", \\\"{x:364,y:559,t:1528143874499};\\\", \\\"{x:353,y:563,t:1528143874516};\\\", \\\"{x:342,y:565,t:1528143874532};\\\", \\\"{x:333,y:565,t:1528143874548};\\\", \\\"{x:328,y:565,t:1528143874566};\\\", \\\"{x:321,y:565,t:1528143874582};\\\", \\\"{x:317,y:565,t:1528143874599};\\\", \\\"{x:311,y:564,t:1528143874616};\\\", \\\"{x:308,y:563,t:1528143874632};\\\", \\\"{x:306,y:563,t:1528143874649};\\\", \\\"{x:307,y:563,t:1528143874666};\\\", \\\"{x:328,y:563,t:1528143874683};\\\", \\\"{x:332,y:563,t:1528143874699};\\\", \\\"{x:332,y:561,t:1528143874779};\\\", \\\"{x:332,y:560,t:1528143874786};\\\", \\\"{x:331,y:558,t:1528143874799};\\\", \\\"{x:327,y:555,t:1528143874816};\\\", \\\"{x:324,y:552,t:1528143874833};\\\", \\\"{x:319,y:551,t:1528143874849};\\\", \\\"{x:314,y:548,t:1528143874866};\\\", \\\"{x:312,y:547,t:1528143874883};\\\", \\\"{x:310,y:547,t:1528143874899};\\\", \\\"{x:306,y:546,t:1528143874916};\\\", \\\"{x:305,y:546,t:1528143874939};\\\", \\\"{x:304,y:545,t:1528143874950};\\\", \\\"{x:301,y:544,t:1528143874971};\\\", \\\"{x:300,y:544,t:1528143874994};\\\", \\\"{x:299,y:544,t:1528143875003};\\\", \\\"{x:298,y:544,t:1528143875016};\\\", \\\"{x:297,y:542,t:1528143875034};\\\", \\\"{x:295,y:542,t:1528143875050};\\\", \\\"{x:302,y:542,t:1528143875163};\\\", \\\"{x:315,y:542,t:1528143875171};\\\", \\\"{x:328,y:542,t:1528143875183};\\\", \\\"{x:355,y:541,t:1528143875201};\\\", \\\"{x:384,y:541,t:1528143875217};\\\", \\\"{x:406,y:541,t:1528143875233};\\\", \\\"{x:421,y:541,t:1528143875250};\\\", \\\"{x:427,y:541,t:1528143875267};\\\", \\\"{x:429,y:541,t:1528143875379};\\\", \\\"{x:432,y:541,t:1528143875387};\\\", \\\"{x:437,y:541,t:1528143875400};\\\", \\\"{x:448,y:541,t:1528143875418};\\\", \\\"{x:458,y:541,t:1528143875434};\\\", \\\"{x:473,y:541,t:1528143875451};\\\", \\\"{x:480,y:541,t:1528143875467};\\\", \\\"{x:487,y:541,t:1528143875485};\\\", \\\"{x:490,y:541,t:1528143875501};\\\", \\\"{x:492,y:541,t:1528143875517};\\\", \\\"{x:494,y:541,t:1528143875534};\\\", \\\"{x:495,y:541,t:1528143875551};\\\", \\\"{x:501,y:540,t:1528143875568};\\\", \\\"{x:506,y:538,t:1528143875583};\\\", \\\"{x:510,y:538,t:1528143875600};\\\", \\\"{x:515,y:538,t:1528143875617};\\\", \\\"{x:520,y:538,t:1528143875632};\\\", \\\"{x:526,y:538,t:1528143875650};\\\", \\\"{x:532,y:538,t:1528143875665};\\\", \\\"{x:538,y:538,t:1528143875683};\\\", \\\"{x:546,y:538,t:1528143875700};\\\", \\\"{x:553,y:538,t:1528143875716};\\\", \\\"{x:561,y:538,t:1528143875732};\\\", \\\"{x:571,y:538,t:1528143875750};\\\", \\\"{x:583,y:538,t:1528143875767};\\\", \\\"{x:602,y:538,t:1528143875783};\\\", \\\"{x:626,y:538,t:1528143875800};\\\", \\\"{x:655,y:538,t:1528143875817};\\\", \\\"{x:697,y:538,t:1528143875833};\\\", \\\"{x:753,y:538,t:1528143875852};\\\", \\\"{x:784,y:538,t:1528143875866};\\\", \\\"{x:804,y:538,t:1528143875883};\\\", \\\"{x:822,y:538,t:1528143875899};\\\", \\\"{x:834,y:536,t:1528143875917};\\\", \\\"{x:841,y:534,t:1528143875933};\\\", \\\"{x:844,y:532,t:1528143875950};\\\", \\\"{x:845,y:532,t:1528143875967};\\\", \\\"{x:847,y:530,t:1528143875983};\\\", \\\"{x:849,y:524,t:1528143875999};\\\", \\\"{x:852,y:516,t:1528143876016};\\\", \\\"{x:854,y:507,t:1528143876033};\\\", \\\"{x:854,y:498,t:1528143876050};\\\", \\\"{x:854,y:488,t:1528143876066};\\\", \\\"{x:855,y:478,t:1528143876084};\\\", \\\"{x:855,y:471,t:1528143876101};\\\", \\\"{x:855,y:468,t:1528143876116};\\\", \\\"{x:855,y:463,t:1528143876134};\\\", \\\"{x:855,y:459,t:1528143876150};\\\", \\\"{x:854,y:456,t:1528143876167};\\\", \\\"{x:854,y:454,t:1528143876183};\\\", \\\"{x:852,y:452,t:1528143876200};\\\", \\\"{x:850,y:450,t:1528143876226};\\\", \\\"{x:849,y:450,t:1528143876258};\\\", \\\"{x:848,y:450,t:1528143876306};\\\", \\\"{x:847,y:450,t:1528143876317};\\\", \\\"{x:846,y:449,t:1528143876334};\\\", \\\"{x:845,y:449,t:1528143876350};\\\", \\\"{x:842,y:448,t:1528143876366};\\\", \\\"{x:839,y:448,t:1528143876794};\\\", \\\"{x:828,y:448,t:1528143876802};\\\", \\\"{x:816,y:450,t:1528143876817};\\\", \\\"{x:789,y:454,t:1528143876834};\\\", \\\"{x:776,y:454,t:1528143876851};\\\", \\\"{x:771,y:454,t:1528143876868};\\\", \\\"{x:766,y:454,t:1528143876883};\\\", \\\"{x:757,y:452,t:1528143876901};\\\", \\\"{x:744,y:451,t:1528143876917};\\\", \\\"{x:724,y:450,t:1528143876934};\\\", \\\"{x:707,y:447,t:1528143876951};\\\", \\\"{x:692,y:447,t:1528143876968};\\\", \\\"{x:679,y:446,t:1528143876984};\\\", \\\"{x:668,y:446,t:1528143877000};\\\", \\\"{x:654,y:446,t:1528143877017};\\\", \\\"{x:630,y:446,t:1528143877034};\\\", \\\"{x:616,y:446,t:1528143877051};\\\", \\\"{x:610,y:446,t:1528143877068};\\\", \\\"{x:599,y:446,t:1528143877084};\\\", \\\"{x:592,y:446,t:1528143877101};\\\", \\\"{x:589,y:446,t:1528143877118};\\\", \\\"{x:588,y:446,t:1528143877531};\\\", \\\"{x:588,y:450,t:1528143877538};\\\", \\\"{x:588,y:454,t:1528143877551};\\\", \\\"{x:588,y:462,t:1528143877568};\\\", \\\"{x:588,y:470,t:1528143877586};\\\", \\\"{x:588,y:474,t:1528143877601};\\\", \\\"{x:588,y:479,t:1528143877618};\\\", \\\"{x:588,y:480,t:1528143877635};\\\", \\\"{x:587,y:480,t:1528143877683};\\\", \\\"{x:587,y:479,t:1528143877699};\\\", \\\"{x:588,y:478,t:1528143877707};\\\", \\\"{x:589,y:476,t:1528143877718};\\\", \\\"{x:590,y:474,t:1528143877735};\\\", \\\"{x:591,y:472,t:1528143877752};\\\", \\\"{x:591,y:471,t:1528143877769};\\\", \\\"{x:593,y:469,t:1528143877785};\\\", \\\"{x:593,y:467,t:1528143877868};\\\", \\\"{x:595,y:462,t:1528143877886};\\\", \\\"{x:595,y:460,t:1528143877902};\\\", \\\"{x:596,y:458,t:1528143877918};\\\", \\\"{x:597,y:457,t:1528143877935};\\\", \\\"{x:597,y:455,t:1528143878010};\\\", \\\"{x:596,y:458,t:1528143878331};\\\", \\\"{x:590,y:465,t:1528143878340};\\\", \\\"{x:584,y:471,t:1528143878353};\\\", \\\"{x:574,y:484,t:1528143878369};\\\", \\\"{x:565,y:495,t:1528143878384};\\\", \\\"{x:559,y:513,t:1528143878403};\\\", \\\"{x:553,y:526,t:1528143878419};\\\", \\\"{x:550,y:535,t:1528143878435};\\\", \\\"{x:546,y:547,t:1528143878453};\\\", \\\"{x:544,y:554,t:1528143878469};\\\", \\\"{x:540,y:562,t:1528143878484};\\\", \\\"{x:537,y:570,t:1528143878501};\\\", \\\"{x:534,y:576,t:1528143878519};\\\", \\\"{x:527,y:585,t:1528143878535};\\\", \\\"{x:521,y:593,t:1528143878552};\\\", \\\"{x:516,y:608,t:1528143878569};\\\", \\\"{x:506,y:632,t:1528143878585};\\\", \\\"{x:491,y:650,t:1528143878602};\\\", \\\"{x:487,y:655,t:1528143878619};\\\", \\\"{x:485,y:657,t:1528143878635};\\\", \\\"{x:484,y:659,t:1528143878652};\\\", \\\"{x:484,y:660,t:1528143878669};\\\", \\\"{x:483,y:662,t:1528143878685};\\\", \\\"{x:481,y:665,t:1528143878702};\\\", \\\"{x:480,y:669,t:1528143878721};\\\", \\\"{x:479,y:670,t:1528143878736};\\\", \\\"{x:479,y:672,t:1528143878752};\\\", \\\"{x:479,y:673,t:1528143878769};\\\", \\\"{x:479,y:674,t:1528143878827};\\\", \\\"{x:483,y:674,t:1528143878836};\\\", \\\"{x:510,y:662,t:1528143878853};\\\", \\\"{x:562,y:634,t:1528143878869};\\\", \\\"{x:622,y:596,t:1528143878886};\\\", \\\"{x:659,y:572,t:1528143878902};\\\", \\\"{x:674,y:558,t:1528143878918};\\\", \\\"{x:679,y:541,t:1528143878937};\\\", \\\"{x:681,y:522,t:1528143878952};\\\", \\\"{x:681,y:510,t:1528143878968};\\\", \\\"{x:674,y:482,t:1528143878987};\\\", \\\"{x:668,y:459,t:1528143879003};\\\", \\\"{x:666,y:443,t:1528143879019};\\\", \\\"{x:661,y:433,t:1528143879037};\\\", \\\"{x:657,y:426,t:1528143879052};\\\", \\\"{x:655,y:423,t:1528143879069};\\\", \\\"{x:654,y:422,t:1528143879085};\\\", \\\"{x:653,y:422,t:1528143879103};\\\", \\\"{x:652,y:422,t:1528143879119};\\\", \\\"{x:649,y:421,t:1528143879136};\\\", \\\"{x:642,y:421,t:1528143879153};\\\", \\\"{x:629,y:421,t:1528143879169};\\\", \\\"{x:608,y:430,t:1528143879187};\\\", \\\"{x:599,y:437,t:1528143879203};\\\", \\\"{x:590,y:445,t:1528143879219};\\\", \\\"{x:589,y:448,t:1528143879236};\\\", \\\"{x:589,y:449,t:1528143879395};\\\", \\\"{x:589,y:451,t:1528143879468};\\\", \\\"{x:589,y:452,t:1528143879507};\\\", \\\"{x:590,y:452,t:1528143879522};\\\", \\\"{x:591,y:452,t:1528143879546};\\\", \\\"{x:592,y:452,t:1528143879555};\\\", \\\"{x:593,y:453,t:1528143879571};\\\", \\\"{x:594,y:453,t:1528143879594};\\\", \\\"{x:595,y:453,t:1528143879611};\\\", \\\"{x:597,y:454,t:1528143879619};\\\", \\\"{x:598,y:454,t:1528143879643};\\\", \\\"{x:599,y:454,t:1528143879691};\\\", \\\"{x:600,y:454,t:1528143879756};\\\", \\\"{x:601,y:454,t:1528143879785};\\\", \\\"{x:602,y:454,t:1528143879866};\\\", \\\"{x:602,y:454,t:1528143879976};\\\", \\\"{x:601,y:457,t:1528143880034};\\\", \\\"{x:601,y:459,t:1528143880041};\\\", \\\"{x:599,y:460,t:1528143880053};\\\", \\\"{x:599,y:462,t:1528143880070};\\\", \\\"{x:599,y:465,t:1528143880087};\\\", \\\"{x:598,y:466,t:1528143880103};\\\", \\\"{x:597,y:468,t:1528143880120};\\\", \\\"{x:597,y:470,t:1528143880137};\\\", \\\"{x:597,y:472,t:1528143880162};\\\", \\\"{x:597,y:473,t:1528143880170};\\\", \\\"{x:595,y:479,t:1528143880187};\\\", \\\"{x:593,y:489,t:1528143880203};\\\", \\\"{x:588,y:501,t:1528143880220};\\\", \\\"{x:581,y:515,t:1528143880238};\\\", \\\"{x:576,y:527,t:1528143880252};\\\", \\\"{x:573,y:538,t:1528143880270};\\\", \\\"{x:570,y:548,t:1528143880287};\\\", \\\"{x:566,y:559,t:1528143880303};\\\", \\\"{x:559,y:575,t:1528143880320};\\\", \\\"{x:553,y:589,t:1528143880337};\\\", \\\"{x:543,y:607,t:1528143880354};\\\", \\\"{x:535,y:621,t:1528143880370};\\\", \\\"{x:531,y:627,t:1528143880387};\\\", \\\"{x:530,y:628,t:1528143880404};\\\", \\\"{x:530,y:631,t:1528143880420};\\\", \\\"{x:529,y:632,t:1528143880437};\\\", \\\"{x:528,y:635,t:1528143880453};\\\", \\\"{x:528,y:636,t:1528143880471};\\\", \\\"{x:527,y:636,t:1528143880487};\\\", \\\"{x:527,y:638,t:1528143880505};\\\", \\\"{x:527,y:639,t:1528143880520};\\\", \\\"{x:527,y:641,t:1528143880537};\\\", \\\"{x:527,y:645,t:1528143880554};\\\", \\\"{x:527,y:649,t:1528143880570};\\\", \\\"{x:526,y:652,t:1528143880588};\\\", \\\"{x:525,y:657,t:1528143880604};\\\", \\\"{x:524,y:661,t:1528143880620};\\\", \\\"{x:524,y:666,t:1528143880638};\\\", \\\"{x:523,y:670,t:1528143880655};\\\", \\\"{x:523,y:674,t:1528143880670};\\\", \\\"{x:523,y:678,t:1528143880687};\\\", \\\"{x:523,y:680,t:1528143880703};\\\", \\\"{x:523,y:681,t:1528143880721};\\\", \\\"{x:532,y:682,t:1528143881082};\\\", \\\"{x:543,y:682,t:1528143881090};\\\", \\\"{x:554,y:680,t:1528143881104};\\\", \\\"{x:582,y:677,t:1528143881121};\\\", \\\"{x:607,y:672,t:1528143881137};\\\", \\\"{x:637,y:668,t:1528143881154};\\\", \\\"{x:649,y:667,t:1528143881170};\\\", \\\"{x:656,y:664,t:1528143881187};\\\", \\\"{x:661,y:663,t:1528143881205};\\\", \\\"{x:663,y:663,t:1528143881221};\\\", \\\"{x:668,y:661,t:1528143881237};\\\", \\\"{x:671,y:661,t:1528143881254};\\\", \\\"{x:672,y:660,t:1528143881271};\\\", \\\"{x:674,y:660,t:1528143881287};\\\", \\\"{x:675,y:660,t:1528143881347};\\\", \\\"{x:676,y:660,t:1528143881386};\\\", \\\"{x:677,y:660,t:1528143881411};\\\", \\\"{x:677,y:658,t:1528143881459};\\\", \\\"{x:678,y:657,t:1528143881472};\\\", \\\"{x:678,y:655,t:1528143881488};\\\", \\\"{x:678,y:654,t:1528143881504};\\\", \\\"{x:678,y:653,t:1528143881521};\\\", \\\"{x:678,y:652,t:1528143881538};\\\", \\\"{x:678,y:651,t:1528143881554};\\\", \\\"{x:679,y:649,t:1528143881570};\\\", \\\"{x:679,y:648,t:1528143881588};\\\", \\\"{x:680,y:647,t:1528143881604};\\\", \\\"{x:680,y:646,t:1528143881622};\\\", \\\"{x:680,y:645,t:1528143881638};\\\", \\\"{x:680,y:644,t:1528143881654};\\\", \\\"{x:681,y:644,t:1528143881671};\\\", \\\"{x:682,y:642,t:1528143881687};\\\", \\\"{x:683,y:641,t:1528143881705};\\\", \\\"{x:684,y:638,t:1528143881721};\\\", \\\"{x:684,y:637,t:1528143881738};\\\", \\\"{x:685,y:633,t:1528143881754};\\\", \\\"{x:686,y:631,t:1528143881771};\\\", \\\"{x:688,y:627,t:1528143881788};\\\", \\\"{x:688,y:624,t:1528143881804};\\\", \\\"{x:690,y:623,t:1528143881821};\\\", \\\"{x:691,y:622,t:1528143881839};\\\", \\\"{x:693,y:621,t:1528143881855};\\\", \\\"{x:693,y:619,t:1528143881871};\\\", \\\"{x:694,y:617,t:1528143881888};\\\", \\\"{x:695,y:617,t:1528143881905};\\\", \\\"{x:696,y:615,t:1528143881943};\\\", \\\"{x:700,y:614,t:1528143881954};\\\", \\\"{x:707,y:614,t:1528143881971};\\\", \\\"{x:725,y:614,t:1528143881988};\\\", \\\"{x:758,y:614,t:1528143882004};\\\", \\\"{x:817,y:614,t:1528143882021};\\\", \\\"{x:886,y:614,t:1528143882038};\\\", \\\"{x:952,y:601,t:1528143882054};\\\", \\\"{x:973,y:593,t:1528143882071};\\\" ] }, { \\\"rt\\\": 8221, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 411761, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"8182H\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:953,y:577,t:1528143882278};\\\", \\\"{x:951,y:576,t:1528143882288};\\\", \\\"{x:949,y:576,t:1528143882305};\\\", \\\"{x:947,y:576,t:1528143882322};\\\", \\\"{x:946,y:576,t:1528143882345};\\\", \\\"{x:944,y:576,t:1528143882388};\\\", \\\"{x:943,y:576,t:1528143882410};\\\", \\\"{x:941,y:576,t:1528143882442};\\\", \\\"{x:922,y:566,t:1528143882661};\\\", \\\"{x:917,y:562,t:1528143882676};\\\", \\\"{x:916,y:562,t:1528143882689};\\\", \\\"{x:909,y:557,t:1528143882705};\\\", \\\"{x:906,y:555,t:1528143882722};\\\", \\\"{x:905,y:555,t:1528143882739};\\\", \\\"{x:903,y:554,t:1528143882756};\\\", \\\"{x:902,y:554,t:1528143882773};\\\", \\\"{x:898,y:551,t:1528143882789};\\\", \\\"{x:896,y:550,t:1528143882806};\\\", \\\"{x:892,y:549,t:1528143882823};\\\", \\\"{x:889,y:547,t:1528143882839};\\\", \\\"{x:889,y:546,t:1528143882970};\\\", \\\"{x:890,y:545,t:1528143883066};\\\", \\\"{x:891,y:545,t:1528143883099};\\\", \\\"{x:892,y:545,t:1528143883122};\\\", \\\"{x:894,y:545,t:1528143883138};\\\", \\\"{x:902,y:540,t:1528143883157};\\\", \\\"{x:913,y:538,t:1528143883172};\\\", \\\"{x:925,y:536,t:1528143883189};\\\", \\\"{x:951,y:536,t:1528143883207};\\\", \\\"{x:968,y:534,t:1528143883222};\\\", \\\"{x:991,y:530,t:1528143883239};\\\", \\\"{x:1017,y:529,t:1528143883256};\\\", \\\"{x:1043,y:525,t:1528143883272};\\\", \\\"{x:1063,y:524,t:1528143883289};\\\", \\\"{x:1079,y:524,t:1528143883306};\\\", \\\"{x:1085,y:524,t:1528143883323};\\\", \\\"{x:1086,y:524,t:1528143883340};\\\", \\\"{x:1088,y:524,t:1528143883370};\\\", \\\"{x:1089,y:525,t:1528143883378};\\\", \\\"{x:1090,y:525,t:1528143883390};\\\", \\\"{x:1103,y:526,t:1528143883406};\\\", \\\"{x:1129,y:530,t:1528143883422};\\\", \\\"{x:1145,y:533,t:1528143883440};\\\", \\\"{x:1162,y:537,t:1528143883457};\\\", \\\"{x:1168,y:539,t:1528143883472};\\\", \\\"{x:1176,y:540,t:1528143883490};\\\", \\\"{x:1177,y:540,t:1528143883506};\\\", \\\"{x:1178,y:540,t:1528143883531};\\\", \\\"{x:1180,y:538,t:1528143883555};\\\", \\\"{x:1184,y:534,t:1528143883570};\\\", \\\"{x:1184,y:535,t:1528143884075};\\\", \\\"{x:1184,y:538,t:1528143884090};\\\", \\\"{x:1184,y:540,t:1528143884115};\\\", \\\"{x:1187,y:542,t:1528143884131};\\\", \\\"{x:1188,y:543,t:1528143884140};\\\", \\\"{x:1190,y:549,t:1528143884156};\\\", \\\"{x:1192,y:554,t:1528143884173};\\\", \\\"{x:1195,y:561,t:1528143884190};\\\", \\\"{x:1200,y:571,t:1528143884206};\\\", \\\"{x:1207,y:584,t:1528143884224};\\\", \\\"{x:1217,y:600,t:1528143884241};\\\", \\\"{x:1227,y:615,t:1528143884256};\\\", \\\"{x:1233,y:622,t:1528143884273};\\\", \\\"{x:1241,y:632,t:1528143884290};\\\", \\\"{x:1248,y:641,t:1528143884306};\\\", \\\"{x:1260,y:654,t:1528143884323};\\\", \\\"{x:1273,y:669,t:1528143884340};\\\", \\\"{x:1287,y:686,t:1528143884357};\\\", \\\"{x:1303,y:702,t:1528143884373};\\\", \\\"{x:1321,y:720,t:1528143884391};\\\", \\\"{x:1342,y:736,t:1528143884407};\\\", \\\"{x:1366,y:753,t:1528143884424};\\\", \\\"{x:1386,y:764,t:1528143884440};\\\", \\\"{x:1398,y:770,t:1528143884456};\\\", \\\"{x:1406,y:774,t:1528143884473};\\\", \\\"{x:1408,y:774,t:1528143884491};\\\", \\\"{x:1408,y:775,t:1528143884508};\\\", \\\"{x:1409,y:776,t:1528143884651};\\\", \\\"{x:1410,y:776,t:1528143884787};\\\", \\\"{x:1409,y:774,t:1528143884795};\\\", \\\"{x:1406,y:772,t:1528143884808};\\\", \\\"{x:1396,y:770,t:1528143884824};\\\", \\\"{x:1385,y:770,t:1528143884841};\\\", \\\"{x:1374,y:772,t:1528143884858};\\\", \\\"{x:1371,y:772,t:1528143884874};\\\", \\\"{x:1368,y:772,t:1528143884891};\\\", \\\"{x:1365,y:769,t:1528143884939};\\\", \\\"{x:1361,y:762,t:1528143884947};\\\", \\\"{x:1357,y:755,t:1528143884958};\\\", \\\"{x:1347,y:735,t:1528143884974};\\\", \\\"{x:1337,y:712,t:1528143884990};\\\", \\\"{x:1312,y:682,t:1528143885008};\\\", \\\"{x:1291,y:661,t:1528143885024};\\\", \\\"{x:1265,y:650,t:1528143885040};\\\", \\\"{x:1236,y:639,t:1528143885057};\\\", \\\"{x:1221,y:636,t:1528143885074};\\\", \\\"{x:1215,y:636,t:1528143885091};\\\", \\\"{x:1211,y:634,t:1528143885107};\\\", \\\"{x:1209,y:634,t:1528143885125};\\\", \\\"{x:1208,y:633,t:1528143885141};\\\", \\\"{x:1208,y:629,t:1528143885158};\\\", \\\"{x:1208,y:620,t:1528143885174};\\\", \\\"{x:1214,y:606,t:1528143885191};\\\", \\\"{x:1217,y:602,t:1528143885208};\\\", \\\"{x:1220,y:599,t:1528143885225};\\\", \\\"{x:1221,y:599,t:1528143885243};\\\", \\\"{x:1223,y:599,t:1528143885258};\\\", \\\"{x:1224,y:599,t:1528143885275};\\\", \\\"{x:1225,y:599,t:1528143885346};\\\", \\\"{x:1225,y:609,t:1528143885358};\\\", \\\"{x:1216,y:667,t:1528143885375};\\\", \\\"{x:1192,y:730,t:1528143885390};\\\", \\\"{x:1183,y:758,t:1528143885408};\\\", \\\"{x:1174,y:767,t:1528143885424};\\\", \\\"{x:1171,y:770,t:1528143885441};\\\", \\\"{x:1170,y:771,t:1528143885458};\\\", \\\"{x:1170,y:772,t:1528143885475};\\\", \\\"{x:1170,y:773,t:1528143885491};\\\", \\\"{x:1176,y:777,t:1528143885507};\\\", \\\"{x:1189,y:788,t:1528143885525};\\\", \\\"{x:1209,y:806,t:1528143885542};\\\", \\\"{x:1248,y:830,t:1528143885557};\\\", \\\"{x:1291,y:844,t:1528143885574};\\\", \\\"{x:1314,y:856,t:1528143885592};\\\", \\\"{x:1329,y:859,t:1528143885608};\\\", \\\"{x:1340,y:864,t:1528143885624};\\\", \\\"{x:1349,y:865,t:1528143885641};\\\", \\\"{x:1357,y:866,t:1528143885658};\\\", \\\"{x:1361,y:869,t:1528143885674};\\\", \\\"{x:1363,y:872,t:1528143885691};\\\", \\\"{x:1364,y:878,t:1528143885708};\\\", \\\"{x:1367,y:881,t:1528143885725};\\\", \\\"{x:1369,y:883,t:1528143885770};\\\", \\\"{x:1371,y:885,t:1528143885787};\\\", \\\"{x:1373,y:886,t:1528143885795};\\\", \\\"{x:1374,y:886,t:1528143885810};\\\", \\\"{x:1380,y:886,t:1528143885825};\\\", \\\"{x:1390,y:887,t:1528143885841};\\\", \\\"{x:1403,y:887,t:1528143885858};\\\", \\\"{x:1436,y:893,t:1528143885875};\\\", \\\"{x:1463,y:896,t:1528143885892};\\\", \\\"{x:1493,y:900,t:1528143885908};\\\", \\\"{x:1524,y:904,t:1528143885924};\\\", \\\"{x:1547,y:908,t:1528143885942};\\\", \\\"{x:1560,y:910,t:1528143885957};\\\", \\\"{x:1569,y:911,t:1528143885974};\\\", \\\"{x:1573,y:911,t:1528143885991};\\\", \\\"{x:1574,y:912,t:1528143886009};\\\", \\\"{x:1574,y:913,t:1528143886035};\\\", \\\"{x:1573,y:913,t:1528143886180};\\\", \\\"{x:1570,y:913,t:1528143886192};\\\", \\\"{x:1565,y:913,t:1528143886209};\\\", \\\"{x:1558,y:913,t:1528143886225};\\\", \\\"{x:1553,y:913,t:1528143886242};\\\", \\\"{x:1546,y:913,t:1528143886259};\\\", \\\"{x:1544,y:913,t:1528143886275};\\\", \\\"{x:1543,y:912,t:1528143886292};\\\", \\\"{x:1542,y:911,t:1528143886404};\\\", \\\"{x:1543,y:911,t:1528143886772};\\\", \\\"{x:1543,y:910,t:1528143886787};\\\", \\\"{x:1543,y:907,t:1528143886811};\\\", \\\"{x:1543,y:905,t:1528143886826};\\\", \\\"{x:1543,y:899,t:1528143886842};\\\", \\\"{x:1535,y:886,t:1528143886859};\\\", \\\"{x:1529,y:878,t:1528143886876};\\\", \\\"{x:1520,y:865,t:1528143886893};\\\", \\\"{x:1510,y:853,t:1528143886910};\\\", \\\"{x:1501,y:839,t:1528143886926};\\\", \\\"{x:1494,y:828,t:1528143886942};\\\", \\\"{x:1489,y:820,t:1528143886959};\\\", \\\"{x:1483,y:813,t:1528143886975};\\\", \\\"{x:1480,y:810,t:1528143886992};\\\", \\\"{x:1478,y:806,t:1528143887008};\\\", \\\"{x:1478,y:805,t:1528143887026};\\\", \\\"{x:1477,y:803,t:1528143887041};\\\", \\\"{x:1476,y:801,t:1528143887058};\\\", \\\"{x:1475,y:798,t:1528143887076};\\\", \\\"{x:1474,y:796,t:1528143887093};\\\", \\\"{x:1474,y:795,t:1528143887108};\\\", \\\"{x:1474,y:794,t:1528143887125};\\\", \\\"{x:1474,y:793,t:1528143887146};\\\", \\\"{x:1474,y:792,t:1528143887162};\\\", \\\"{x:1474,y:791,t:1528143887175};\\\", \\\"{x:1474,y:790,t:1528143887193};\\\", \\\"{x:1474,y:789,t:1528143887209};\\\", \\\"{x:1474,y:788,t:1528143887226};\\\", \\\"{x:1474,y:787,t:1528143887250};\\\", \\\"{x:1474,y:785,t:1528143887266};\\\", \\\"{x:1475,y:785,t:1528143887276};\\\", \\\"{x:1476,y:784,t:1528143887292};\\\", \\\"{x:1478,y:782,t:1528143887309};\\\", \\\"{x:1478,y:781,t:1528143887328};\\\", \\\"{x:1475,y:778,t:1528143887956};\\\", \\\"{x:1463,y:776,t:1528143887962};\\\", \\\"{x:1450,y:771,t:1528143887976};\\\", \\\"{x:1422,y:765,t:1528143887993};\\\", \\\"{x:1379,y:749,t:1528143888010};\\\", \\\"{x:1272,y:687,t:1528143888027};\\\", \\\"{x:1210,y:655,t:1528143888043};\\\", \\\"{x:1158,y:625,t:1528143888060};\\\", \\\"{x:1112,y:600,t:1528143888077};\\\", \\\"{x:1069,y:581,t:1528143888093};\\\", \\\"{x:1038,y:565,t:1528143888109};\\\", \\\"{x:974,y:544,t:1528143888127};\\\", \\\"{x:904,y:522,t:1528143888144};\\\", \\\"{x:826,y:502,t:1528143888160};\\\", \\\"{x:740,y:477,t:1528143888176};\\\", \\\"{x:618,y:442,t:1528143888193};\\\", \\\"{x:548,y:429,t:1528143888210};\\\", \\\"{x:467,y:418,t:1528143888226};\\\", \\\"{x:393,y:400,t:1528143888243};\\\", \\\"{x:348,y:392,t:1528143888259};\\\", \\\"{x:309,y:392,t:1528143888276};\\\", \\\"{x:281,y:392,t:1528143888294};\\\", \\\"{x:267,y:394,t:1528143888311};\\\", \\\"{x:263,y:396,t:1528143888326};\\\", \\\"{x:260,y:399,t:1528143888344};\\\", \\\"{x:257,y:403,t:1528143888360};\\\", \\\"{x:253,y:411,t:1528143888376};\\\", \\\"{x:248,y:425,t:1528143888394};\\\", \\\"{x:236,y:452,t:1528143888412};\\\", \\\"{x:231,y:469,t:1528143888427};\\\", \\\"{x:226,y:485,t:1528143888443};\\\", \\\"{x:221,y:498,t:1528143888461};\\\", \\\"{x:216,y:510,t:1528143888477};\\\", \\\"{x:211,y:521,t:1528143888493};\\\", \\\"{x:207,y:529,t:1528143888510};\\\", \\\"{x:203,y:536,t:1528143888526};\\\", \\\"{x:197,y:542,t:1528143888544};\\\", \\\"{x:189,y:547,t:1528143888560};\\\", \\\"{x:184,y:548,t:1528143888577};\\\", \\\"{x:181,y:548,t:1528143888593};\\\", \\\"{x:180,y:549,t:1528143888762};\\\", \\\"{x:179,y:549,t:1528143888778};\\\", \\\"{x:177,y:551,t:1528143888794};\\\", \\\"{x:175,y:553,t:1528143888809};\\\", \\\"{x:174,y:554,t:1528143888827};\\\", \\\"{x:173,y:556,t:1528143888843};\\\", \\\"{x:173,y:557,t:1528143888860};\\\", \\\"{x:173,y:559,t:1528143888878};\\\", \\\"{x:173,y:560,t:1528143888893};\\\", \\\"{x:186,y:560,t:1528143888910};\\\", \\\"{x:218,y:560,t:1528143888928};\\\", \\\"{x:282,y:560,t:1528143888944};\\\", \\\"{x:365,y:552,t:1528143888960};\\\", \\\"{x:445,y:543,t:1528143888978};\\\", \\\"{x:504,y:535,t:1528143888994};\\\", \\\"{x:571,y:525,t:1528143889011};\\\", \\\"{x:589,y:523,t:1528143889027};\\\", \\\"{x:599,y:519,t:1528143889044};\\\", \\\"{x:605,y:517,t:1528143889060};\\\", \\\"{x:609,y:517,t:1528143889077};\\\", \\\"{x:620,y:516,t:1528143889095};\\\", \\\"{x:638,y:516,t:1528143889110};\\\", \\\"{x:657,y:516,t:1528143889127};\\\", \\\"{x:672,y:516,t:1528143889145};\\\", \\\"{x:680,y:516,t:1528143889161};\\\", \\\"{x:682,y:516,t:1528143889178};\\\", \\\"{x:680,y:516,t:1528143889283};\\\", \\\"{x:674,y:516,t:1528143889295};\\\", \\\"{x:661,y:518,t:1528143889311};\\\", \\\"{x:646,y:521,t:1528143889327};\\\", \\\"{x:630,y:523,t:1528143889346};\\\", \\\"{x:619,y:525,t:1528143889361};\\\", \\\"{x:615,y:525,t:1528143889378};\\\", \\\"{x:612,y:525,t:1528143889395};\\\", \\\"{x:611,y:525,t:1528143889450};\\\", \\\"{x:610,y:525,t:1528143889482};\\\", \\\"{x:609,y:525,t:1528143889506};\\\", \\\"{x:607,y:527,t:1528143889794};\\\", \\\"{x:595,y:543,t:1528143889812};\\\", \\\"{x:583,y:559,t:1528143889828};\\\", \\\"{x:570,y:571,t:1528143889845};\\\", \\\"{x:561,y:583,t:1528143889862};\\\", \\\"{x:556,y:591,t:1528143889878};\\\", \\\"{x:549,y:602,t:1528143889894};\\\", \\\"{x:539,y:614,t:1528143889911};\\\", \\\"{x:528,y:628,t:1528143889928};\\\", \\\"{x:511,y:646,t:1528143889944};\\\", \\\"{x:495,y:660,t:1528143889961};\\\", \\\"{x:485,y:672,t:1528143889978};\\\", \\\"{x:481,y:677,t:1528143889994};\\\", \\\"{x:481,y:678,t:1528143890155};\\\", \\\"{x:481,y:679,t:1528143890178};\\\", \\\"{x:479,y:679,t:1528143890291};\\\", \\\"{x:478,y:679,t:1528143890537};\\\", \\\"{x:484,y:679,t:1528143890698};\\\", \\\"{x:495,y:680,t:1528143890711};\\\", \\\"{x:521,y:685,t:1528143890728};\\\", \\\"{x:546,y:687,t:1528143890746};\\\", \\\"{x:567,y:689,t:1528143890761};\\\", \\\"{x:587,y:689,t:1528143890778};\\\", \\\"{x:592,y:689,t:1528143890796};\\\", \\\"{x:594,y:689,t:1528143890812};\\\", \\\"{x:596,y:687,t:1528143890829};\\\", \\\"{x:601,y:684,t:1528143890845};\\\", \\\"{x:606,y:682,t:1528143890862};\\\", \\\"{x:611,y:680,t:1528143890879};\\\", \\\"{x:617,y:677,t:1528143890896};\\\", \\\"{x:620,y:676,t:1528143890912};\\\", \\\"{x:621,y:676,t:1528143890929};\\\", \\\"{x:621,y:675,t:1528143890954};\\\", \\\"{x:621,y:674,t:1528143891138};\\\", \\\"{x:620,y:673,t:1528143891171};\\\", \\\"{x:620,y:672,t:1528143891179};\\\", \\\"{x:619,y:672,t:1528143891211};\\\", \\\"{x:618,y:671,t:1528143891234};\\\", \\\"{x:617,y:671,t:1528143891322};\\\" ] }, { \\\"rt\\\": 18702, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 431849, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"8182H\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 2, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-02 PM-X -01 PM-X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:616,y:671,t:1528143891876};\\\", \\\"{x:616,y:670,t:1528143891902};\\\", \\\"{x:615,y:669,t:1528143893555};\\\", \\\"{x:614,y:669,t:1528143893579};\\\", \\\"{x:614,y:668,t:1528143893682};\\\", \\\"{x:613,y:668,t:1528143893931};\\\", \\\"{x:611,y:668,t:1528143894011};\\\", \\\"{x:610,y:666,t:1528143894043};\\\", \\\"{x:609,y:666,t:1528143894050};\\\", \\\"{x:607,y:666,t:1528143894067};\\\", \\\"{x:599,y:660,t:1528143894081};\\\", \\\"{x:541,y:648,t:1528143894099};\\\", \\\"{x:493,y:661,t:1528143894114};\\\", \\\"{x:489,y:663,t:1528143894131};\\\", \\\"{x:487,y:663,t:1528143894707};\\\", \\\"{x:486,y:663,t:1528143894715};\\\", \\\"{x:484,y:663,t:1528143894732};\\\", \\\"{x:485,y:663,t:1528143897162};\\\", \\\"{x:487,y:663,t:1528143897170};\\\", \\\"{x:494,y:663,t:1528143897184};\\\", \\\"{x:513,y:660,t:1528143897200};\\\", \\\"{x:533,y:658,t:1528143897216};\\\", \\\"{x:549,y:654,t:1528143897234};\\\", \\\"{x:557,y:652,t:1528143897249};\\\", \\\"{x:560,y:650,t:1528143897267};\\\", \\\"{x:564,y:649,t:1528143897284};\\\", \\\"{x:565,y:648,t:1528143897300};\\\", \\\"{x:566,y:647,t:1528143897317};\\\", \\\"{x:567,y:645,t:1528143897334};\\\", \\\"{x:569,y:644,t:1528143897350};\\\", \\\"{x:574,y:641,t:1528143897367};\\\", \\\"{x:578,y:640,t:1528143897384};\\\", \\\"{x:582,y:638,t:1528143897400};\\\", \\\"{x:585,y:638,t:1528143897417};\\\", \\\"{x:587,y:637,t:1528143897434};\\\", \\\"{x:591,y:636,t:1528143897450};\\\", \\\"{x:592,y:634,t:1528143897467};\\\", \\\"{x:594,y:633,t:1528143897484};\\\", \\\"{x:595,y:630,t:1528143897500};\\\", \\\"{x:596,y:627,t:1528143897518};\\\", \\\"{x:598,y:623,t:1528143897535};\\\", \\\"{x:601,y:620,t:1528143897550};\\\", \\\"{x:602,y:617,t:1528143897567};\\\", \\\"{x:602,y:614,t:1528143897583};\\\", \\\"{x:600,y:610,t:1528143897601};\\\", \\\"{x:591,y:603,t:1528143897616};\\\", \\\"{x:580,y:592,t:1528143897634};\\\", \\\"{x:572,y:581,t:1528143897650};\\\", \\\"{x:568,y:573,t:1528143897666};\\\", \\\"{x:565,y:568,t:1528143897683};\\\", \\\"{x:560,y:561,t:1528143897701};\\\", \\\"{x:555,y:556,t:1528143897717};\\\", \\\"{x:547,y:551,t:1528143897734};\\\", \\\"{x:543,y:547,t:1528143897751};\\\", \\\"{x:531,y:525,t:1528143897767};\\\", \\\"{x:521,y:492,t:1528143897785};\\\", \\\"{x:505,y:458,t:1528143897801};\\\", \\\"{x:494,y:433,t:1528143897818};\\\", \\\"{x:494,y:429,t:1528143897835};\\\", \\\"{x:494,y:426,t:1528143897850};\\\", \\\"{x:494,y:425,t:1528143897868};\\\", \\\"{x:496,y:421,t:1528143897883};\\\", \\\"{x:503,y:416,t:1528143897901};\\\", \\\"{x:513,y:413,t:1528143897918};\\\", \\\"{x:523,y:410,t:1528143897934};\\\", \\\"{x:535,y:407,t:1528143897950};\\\", \\\"{x:552,y:402,t:1528143897968};\\\", \\\"{x:565,y:400,t:1528143897985};\\\", \\\"{x:573,y:400,t:1528143898001};\\\", \\\"{x:575,y:400,t:1528143898018};\\\", \\\"{x:576,y:400,t:1528143898050};\\\", \\\"{x:585,y:405,t:1528143898069};\\\", \\\"{x:612,y:425,t:1528143898085};\\\", \\\"{x:664,y:457,t:1528143898103};\\\", \\\"{x:727,y:493,t:1528143898118};\\\", \\\"{x:788,y:519,t:1528143898135};\\\", \\\"{x:842,y:537,t:1528143898153};\\\", \\\"{x:883,y:548,t:1528143898168};\\\", \\\"{x:924,y:558,t:1528143898185};\\\", \\\"{x:961,y:564,t:1528143898200};\\\", \\\"{x:1012,y:574,t:1528143898217};\\\", \\\"{x:1042,y:580,t:1528143898235};\\\", \\\"{x:1068,y:583,t:1528143898251};\\\", \\\"{x:1091,y:588,t:1528143898268};\\\", \\\"{x:1117,y:595,t:1528143898284};\\\", \\\"{x:1142,y:604,t:1528143898301};\\\", \\\"{x:1169,y:616,t:1528143898318};\\\", \\\"{x:1216,y:634,t:1528143898336};\\\", \\\"{x:1279,y:660,t:1528143898354};\\\", \\\"{x:1357,y:696,t:1528143898371};\\\", \\\"{x:1442,y:731,t:1528143898389};\\\", \\\"{x:1517,y:765,t:1528143898405};\\\", \\\"{x:1596,y:812,t:1528143898422};\\\", \\\"{x:1623,y:828,t:1528143898438};\\\", \\\"{x:1636,y:843,t:1528143898454};\\\", \\\"{x:1645,y:863,t:1528143898471};\\\", \\\"{x:1648,y:887,t:1528143898487};\\\", \\\"{x:1650,y:911,t:1528143898505};\\\", \\\"{x:1650,y:937,t:1528143898522};\\\", \\\"{x:1640,y:952,t:1528143898537};\\\", \\\"{x:1636,y:958,t:1528143898555};\\\", \\\"{x:1635,y:959,t:1528143898571};\\\", \\\"{x:1633,y:959,t:1528143898614};\\\", \\\"{x:1626,y:959,t:1528143898622};\\\", \\\"{x:1604,y:957,t:1528143898637};\\\", \\\"{x:1578,y:953,t:1528143898655};\\\", \\\"{x:1555,y:948,t:1528143898671};\\\", \\\"{x:1530,y:941,t:1528143898688};\\\", \\\"{x:1510,y:936,t:1528143898705};\\\", \\\"{x:1497,y:930,t:1528143898722};\\\", \\\"{x:1490,y:924,t:1528143898737};\\\", \\\"{x:1483,y:920,t:1528143898754};\\\", \\\"{x:1477,y:916,t:1528143898771};\\\", \\\"{x:1473,y:914,t:1528143898788};\\\", \\\"{x:1466,y:910,t:1528143898805};\\\", \\\"{x:1462,y:909,t:1528143898821};\\\", \\\"{x:1459,y:907,t:1528143898838};\\\", \\\"{x:1462,y:907,t:1528143899334};\\\", \\\"{x:1470,y:910,t:1528143899341};\\\", \\\"{x:1478,y:912,t:1528143899353};\\\", \\\"{x:1497,y:915,t:1528143899370};\\\", \\\"{x:1513,y:919,t:1528143899387};\\\", \\\"{x:1521,y:921,t:1528143899402};\\\", \\\"{x:1523,y:922,t:1528143899420};\\\", \\\"{x:1522,y:922,t:1528143899502};\\\", \\\"{x:1519,y:922,t:1528143899509};\\\", \\\"{x:1516,y:922,t:1528143899520};\\\", \\\"{x:1507,y:922,t:1528143899537};\\\", \\\"{x:1494,y:922,t:1528143899554};\\\", \\\"{x:1484,y:922,t:1528143899570};\\\", \\\"{x:1476,y:922,t:1528143899586};\\\", \\\"{x:1472,y:921,t:1528143899603};\\\", \\\"{x:1472,y:920,t:1528143899654};\\\", \\\"{x:1471,y:919,t:1528143899686};\\\", \\\"{x:1471,y:917,t:1528143899704};\\\", \\\"{x:1471,y:915,t:1528143899721};\\\", \\\"{x:1471,y:914,t:1528143899736};\\\", \\\"{x:1471,y:913,t:1528143899753};\\\", \\\"{x:1471,y:912,t:1528143899770};\\\", \\\"{x:1471,y:910,t:1528143899786};\\\", \\\"{x:1471,y:909,t:1528143899805};\\\", \\\"{x:1471,y:907,t:1528143899821};\\\", \\\"{x:1471,y:906,t:1528143899837};\\\", \\\"{x:1472,y:905,t:1528143899853};\\\", \\\"{x:1472,y:904,t:1528143899870};\\\", \\\"{x:1473,y:903,t:1528143899893};\\\", \\\"{x:1473,y:902,t:1528143900374};\\\", \\\"{x:1474,y:902,t:1528143900386};\\\", \\\"{x:1476,y:902,t:1528143900402};\\\", \\\"{x:1476,y:903,t:1528143900420};\\\", \\\"{x:1477,y:903,t:1528143900437};\\\", \\\"{x:1478,y:903,t:1528143900452};\\\", \\\"{x:1479,y:904,t:1528143900470};\\\", \\\"{x:1480,y:905,t:1528143900518};\\\", \\\"{x:1481,y:905,t:1528143900550};\\\", \\\"{x:1482,y:906,t:1528143900590};\\\", \\\"{x:1482,y:905,t:1528143900766};\\\", \\\"{x:1482,y:902,t:1528143900773};\\\", \\\"{x:1482,y:899,t:1528143900785};\\\", \\\"{x:1482,y:895,t:1528143900802};\\\", \\\"{x:1482,y:889,t:1528143900820};\\\", \\\"{x:1482,y:884,t:1528143900835};\\\", \\\"{x:1482,y:877,t:1528143900853};\\\", \\\"{x:1483,y:872,t:1528143900869};\\\", \\\"{x:1483,y:866,t:1528143900886};\\\", \\\"{x:1485,y:863,t:1528143900902};\\\", \\\"{x:1485,y:858,t:1528143900919};\\\", \\\"{x:1487,y:854,t:1528143900936};\\\", \\\"{x:1487,y:847,t:1528143900952};\\\", \\\"{x:1488,y:842,t:1528143900969};\\\", \\\"{x:1489,y:838,t:1528143900985};\\\", \\\"{x:1490,y:832,t:1528143901002};\\\", \\\"{x:1490,y:829,t:1528143901019};\\\", \\\"{x:1490,y:827,t:1528143901035};\\\", \\\"{x:1490,y:824,t:1528143901052};\\\", \\\"{x:1490,y:819,t:1528143901068};\\\", \\\"{x:1490,y:814,t:1528143901084};\\\", \\\"{x:1490,y:811,t:1528143901102};\\\", \\\"{x:1490,y:807,t:1528143901118};\\\", \\\"{x:1489,y:806,t:1528143901135};\\\", \\\"{x:1488,y:804,t:1528143901152};\\\", \\\"{x:1488,y:803,t:1528143901168};\\\", \\\"{x:1486,y:801,t:1528143901185};\\\", \\\"{x:1485,y:797,t:1528143901202};\\\", \\\"{x:1485,y:796,t:1528143901218};\\\", \\\"{x:1484,y:794,t:1528143901235};\\\", \\\"{x:1483,y:791,t:1528143901252};\\\", \\\"{x:1482,y:790,t:1528143901268};\\\", \\\"{x:1482,y:788,t:1528143901285};\\\", \\\"{x:1482,y:787,t:1528143901302};\\\", \\\"{x:1482,y:786,t:1528143901319};\\\", \\\"{x:1482,y:785,t:1528143901335};\\\", \\\"{x:1482,y:784,t:1528143901353};\\\", \\\"{x:1482,y:783,t:1528143901369};\\\", \\\"{x:1482,y:782,t:1528143901388};\\\", \\\"{x:1482,y:781,t:1528143901417};\\\", \\\"{x:1480,y:780,t:1528143902702};\\\", \\\"{x:1473,y:788,t:1528143902718};\\\", \\\"{x:1469,y:792,t:1528143902734};\\\", \\\"{x:1466,y:794,t:1528143902750};\\\", \\\"{x:1466,y:795,t:1528143902768};\\\", \\\"{x:1465,y:795,t:1528143902784};\\\", \\\"{x:1463,y:797,t:1528143902800};\\\", \\\"{x:1462,y:798,t:1528143902846};\\\", \\\"{x:1459,y:800,t:1528143902854};\\\", \\\"{x:1458,y:804,t:1528143902867};\\\", \\\"{x:1454,y:809,t:1528143902885};\\\", \\\"{x:1448,y:819,t:1528143902901};\\\", \\\"{x:1440,y:831,t:1528143902917};\\\", \\\"{x:1435,y:839,t:1528143902936};\\\", \\\"{x:1431,y:847,t:1528143902950};\\\", \\\"{x:1426,y:858,t:1528143902967};\\\", \\\"{x:1421,y:870,t:1528143902984};\\\", \\\"{x:1414,y:881,t:1528143903000};\\\", \\\"{x:1409,y:890,t:1528143903017};\\\", \\\"{x:1405,y:901,t:1528143903033};\\\", \\\"{x:1402,y:908,t:1528143903050};\\\", \\\"{x:1398,y:916,t:1528143903067};\\\", \\\"{x:1395,y:922,t:1528143903083};\\\", \\\"{x:1393,y:929,t:1528143903100};\\\", \\\"{x:1390,y:937,t:1528143903117};\\\", \\\"{x:1388,y:940,t:1528143903133};\\\", \\\"{x:1388,y:943,t:1528143903151};\\\", \\\"{x:1387,y:944,t:1528143903167};\\\", \\\"{x:1387,y:947,t:1528143903184};\\\", \\\"{x:1387,y:942,t:1528143903310};\\\", \\\"{x:1387,y:936,t:1528143903317};\\\", \\\"{x:1389,y:925,t:1528143903333};\\\", \\\"{x:1398,y:912,t:1528143903351};\\\", \\\"{x:1405,y:899,t:1528143903368};\\\", \\\"{x:1410,y:889,t:1528143903384};\\\", \\\"{x:1414,y:879,t:1528143903400};\\\", \\\"{x:1420,y:868,t:1528143903417};\\\", \\\"{x:1427,y:856,t:1528143903433};\\\", \\\"{x:1435,y:844,t:1528143903450};\\\", \\\"{x:1442,y:832,t:1528143903467};\\\", \\\"{x:1450,y:821,t:1528143903484};\\\", \\\"{x:1456,y:812,t:1528143903500};\\\", \\\"{x:1462,y:804,t:1528143903517};\\\", \\\"{x:1466,y:798,t:1528143903534};\\\", \\\"{x:1470,y:793,t:1528143903551};\\\", \\\"{x:1471,y:791,t:1528143903567};\\\", \\\"{x:1473,y:788,t:1528143903584};\\\", \\\"{x:1475,y:786,t:1528143903601};\\\", \\\"{x:1477,y:783,t:1528143903616};\\\", \\\"{x:1478,y:782,t:1528143903634};\\\", \\\"{x:1478,y:781,t:1528143903651};\\\", \\\"{x:1479,y:780,t:1528143903683};\\\", \\\"{x:1479,y:779,t:1528143903700};\\\", \\\"{x:1480,y:779,t:1528143903716};\\\", \\\"{x:1481,y:781,t:1528143904270};\\\", \\\"{x:1481,y:784,t:1528143904283};\\\", \\\"{x:1484,y:787,t:1528143904300};\\\", \\\"{x:1484,y:790,t:1528143904317};\\\", \\\"{x:1486,y:793,t:1528143904333};\\\", \\\"{x:1487,y:794,t:1528143904358};\\\", \\\"{x:1487,y:795,t:1528143904366};\\\", \\\"{x:1487,y:798,t:1528143904383};\\\", \\\"{x:1488,y:802,t:1528143904399};\\\", \\\"{x:1490,y:805,t:1528143904416};\\\", \\\"{x:1492,y:811,t:1528143904433};\\\", \\\"{x:1495,y:816,t:1528143904449};\\\", \\\"{x:1498,y:820,t:1528143904467};\\\", \\\"{x:1501,y:826,t:1528143904482};\\\", \\\"{x:1505,y:832,t:1528143904500};\\\", \\\"{x:1508,y:836,t:1528143904517};\\\", \\\"{x:1515,y:843,t:1528143904533};\\\", \\\"{x:1520,y:849,t:1528143904549};\\\", \\\"{x:1526,y:859,t:1528143904566};\\\", \\\"{x:1537,y:870,t:1528143904583};\\\", \\\"{x:1548,y:880,t:1528143904600};\\\", \\\"{x:1561,y:887,t:1528143904616};\\\", \\\"{x:1563,y:889,t:1528143904633};\\\", \\\"{x:1565,y:890,t:1528143904650};\\\", \\\"{x:1566,y:891,t:1528143904693};\\\", \\\"{x:1567,y:891,t:1528143904718};\\\", \\\"{x:1567,y:894,t:1528143904734};\\\", \\\"{x:1569,y:896,t:1528143904749};\\\", \\\"{x:1569,y:898,t:1528143904765};\\\", \\\"{x:1569,y:900,t:1528143904798};\\\", \\\"{x:1570,y:900,t:1528143904813};\\\", \\\"{x:1569,y:900,t:1528143904965};\\\", \\\"{x:1559,y:882,t:1528143904983};\\\", \\\"{x:1547,y:862,t:1528143904998};\\\", \\\"{x:1533,y:842,t:1528143905015};\\\", \\\"{x:1520,y:824,t:1528143905033};\\\", \\\"{x:1508,y:806,t:1528143905049};\\\", \\\"{x:1496,y:770,t:1528143905066};\\\", \\\"{x:1487,y:753,t:1528143905083};\\\", \\\"{x:1479,y:738,t:1528143905099};\\\", \\\"{x:1473,y:727,t:1528143905116};\\\", \\\"{x:1471,y:723,t:1528143905134};\\\", \\\"{x:1471,y:722,t:1528143905222};\\\", \\\"{x:1471,y:721,t:1528143905318};\\\", \\\"{x:1471,y:715,t:1528143905334};\\\", \\\"{x:1472,y:710,t:1528143905350};\\\", \\\"{x:1474,y:701,t:1528143905366};\\\", \\\"{x:1475,y:696,t:1528143905381};\\\", \\\"{x:1476,y:688,t:1528143905399};\\\", \\\"{x:1476,y:674,t:1528143905416};\\\", \\\"{x:1476,y:660,t:1528143905432};\\\", \\\"{x:1476,y:653,t:1528143905449};\\\", \\\"{x:1476,y:646,t:1528143905466};\\\", \\\"{x:1478,y:637,t:1528143905482};\\\", \\\"{x:1479,y:632,t:1528143905499};\\\", \\\"{x:1480,y:627,t:1528143905516};\\\", \\\"{x:1480,y:622,t:1528143905532};\\\", \\\"{x:1481,y:619,t:1528143905549};\\\", \\\"{x:1482,y:615,t:1528143905566};\\\", \\\"{x:1482,y:611,t:1528143905582};\\\", \\\"{x:1482,y:606,t:1528143905598};\\\", \\\"{x:1482,y:601,t:1528143905615};\\\", \\\"{x:1482,y:596,t:1528143905631};\\\", \\\"{x:1482,y:591,t:1528143905648};\\\", \\\"{x:1482,y:586,t:1528143905665};\\\", \\\"{x:1482,y:581,t:1528143905681};\\\", \\\"{x:1482,y:575,t:1528143905698};\\\", \\\"{x:1482,y:570,t:1528143905715};\\\", \\\"{x:1482,y:566,t:1528143905731};\\\", \\\"{x:1483,y:560,t:1528143905748};\\\", \\\"{x:1483,y:556,t:1528143905765};\\\", \\\"{x:1483,y:549,t:1528143905781};\\\", \\\"{x:1483,y:541,t:1528143905798};\\\", \\\"{x:1483,y:532,t:1528143905814};\\\", \\\"{x:1483,y:517,t:1528143905831};\\\", \\\"{x:1483,y:502,t:1528143905849};\\\", \\\"{x:1483,y:496,t:1528143905864};\\\", \\\"{x:1483,y:493,t:1528143905882};\\\", \\\"{x:1483,y:491,t:1528143905899};\\\", \\\"{x:1483,y:490,t:1528143906062};\\\", \\\"{x:1482,y:486,t:1528143906070};\\\", \\\"{x:1482,y:479,t:1528143906081};\\\", \\\"{x:1482,y:473,t:1528143906098};\\\", \\\"{x:1481,y:465,t:1528143906115};\\\", \\\"{x:1479,y:459,t:1528143906132};\\\", \\\"{x:1479,y:458,t:1528143906148};\\\", \\\"{x:1479,y:456,t:1528143906165};\\\", \\\"{x:1478,y:454,t:1528143906181};\\\", \\\"{x:1478,y:453,t:1528143906198};\\\", \\\"{x:1478,y:451,t:1528143906215};\\\", \\\"{x:1478,y:450,t:1528143906237};\\\", \\\"{x:1478,y:449,t:1528143906340};\\\", \\\"{x:1479,y:449,t:1528143906444};\\\", \\\"{x:1483,y:449,t:1528143906452};\\\", \\\"{x:1494,y:451,t:1528143906464};\\\", \\\"{x:1500,y:452,t:1528143906480};\\\", \\\"{x:1499,y:458,t:1528143906517};\\\", \\\"{x:1484,y:460,t:1528143906530};\\\", \\\"{x:1433,y:463,t:1528143906547};\\\", \\\"{x:1348,y:455,t:1528143906564};\\\", \\\"{x:1207,y:438,t:1528143906580};\\\", \\\"{x:992,y:405,t:1528143906597};\\\", \\\"{x:840,y:383,t:1528143906614};\\\", \\\"{x:692,y:373,t:1528143906631};\\\", \\\"{x:621,y:376,t:1528143906647};\\\", \\\"{x:600,y:384,t:1528143906665};\\\", \\\"{x:584,y:397,t:1528143906681};\\\", \\\"{x:568,y:426,t:1528143906698};\\\", \\\"{x:544,y:456,t:1528143906716};\\\", \\\"{x:529,y:472,t:1528143906730};\\\", \\\"{x:514,y:485,t:1528143906747};\\\", \\\"{x:507,y:492,t:1528143906761};\\\", \\\"{x:498,y:500,t:1528143906778};\\\", \\\"{x:496,y:501,t:1528143906794};\\\", \\\"{x:498,y:501,t:1528143906852};\\\", \\\"{x:503,y:503,t:1528143906861};\\\", \\\"{x:516,y:506,t:1528143906878};\\\", \\\"{x:528,y:511,t:1528143906894};\\\", \\\"{x:533,y:514,t:1528143906911};\\\", \\\"{x:536,y:517,t:1528143906929};\\\", \\\"{x:536,y:518,t:1528143906944};\\\", \\\"{x:536,y:520,t:1528143906980};\\\", \\\"{x:533,y:521,t:1528143906994};\\\", \\\"{x:516,y:526,t:1528143907012};\\\", \\\"{x:493,y:531,t:1528143907029};\\\", \\\"{x:464,y:535,t:1528143907044};\\\", \\\"{x:414,y:538,t:1528143907062};\\\", \\\"{x:388,y:543,t:1528143907079};\\\", \\\"{x:367,y:547,t:1528143907095};\\\", \\\"{x:351,y:552,t:1528143907111};\\\", \\\"{x:339,y:559,t:1528143907128};\\\", \\\"{x:325,y:570,t:1528143907145};\\\", \\\"{x:309,y:578,t:1528143907161};\\\", \\\"{x:293,y:587,t:1528143907178};\\\", \\\"{x:280,y:592,t:1528143907195};\\\", \\\"{x:270,y:595,t:1528143907211};\\\", \\\"{x:267,y:596,t:1528143907228};\\\", \\\"{x:271,y:592,t:1528143907269};\\\", \\\"{x:278,y:587,t:1528143907279};\\\", \\\"{x:292,y:580,t:1528143907295};\\\", \\\"{x:303,y:573,t:1528143907311};\\\", \\\"{x:317,y:568,t:1528143907328};\\\", \\\"{x:328,y:564,t:1528143907345};\\\", \\\"{x:341,y:560,t:1528143907362};\\\", \\\"{x:348,y:556,t:1528143907378};\\\", \\\"{x:354,y:555,t:1528143907395};\\\", \\\"{x:359,y:552,t:1528143907411};\\\", \\\"{x:363,y:550,t:1528143907428};\\\", \\\"{x:368,y:549,t:1528143907445};\\\", \\\"{x:369,y:549,t:1528143907461};\\\", \\\"{x:370,y:548,t:1528143907479};\\\", \\\"{x:373,y:548,t:1528143907496};\\\", \\\"{x:375,y:547,t:1528143907513};\\\", \\\"{x:381,y:545,t:1528143907528};\\\", \\\"{x:394,y:542,t:1528143907545};\\\", \\\"{x:403,y:540,t:1528143907562};\\\", \\\"{x:412,y:540,t:1528143907578};\\\", \\\"{x:416,y:539,t:1528143907596};\\\", \\\"{x:417,y:539,t:1528143907612};\\\", \\\"{x:414,y:539,t:1528143907686};\\\", \\\"{x:411,y:539,t:1528143907696};\\\", \\\"{x:402,y:539,t:1528143907712};\\\", \\\"{x:394,y:539,t:1528143907729};\\\", \\\"{x:382,y:539,t:1528143907746};\\\", \\\"{x:373,y:539,t:1528143907764};\\\", \\\"{x:363,y:539,t:1528143907778};\\\", \\\"{x:359,y:539,t:1528143907795};\\\", \\\"{x:357,y:539,t:1528143907812};\\\", \\\"{x:358,y:539,t:1528143907965};\\\", \\\"{x:359,y:538,t:1528143907980};\\\", \\\"{x:361,y:538,t:1528143907997};\\\", \\\"{x:364,y:538,t:1528143908012};\\\", \\\"{x:370,y:538,t:1528143908029};\\\", \\\"{x:375,y:539,t:1528143908046};\\\", \\\"{x:377,y:540,t:1528143908062};\\\", \\\"{x:381,y:541,t:1528143908080};\\\", \\\"{x:382,y:541,t:1528143908101};\\\", \\\"{x:383,y:541,t:1528143908112};\\\", \\\"{x:384,y:541,t:1528143908133};\\\", \\\"{x:385,y:541,t:1528143908253};\\\", \\\"{x:385,y:541,t:1528143908356};\\\", \\\"{x:385,y:542,t:1528143908622};\\\", \\\"{x:385,y:543,t:1528143908629};\\\", \\\"{x:383,y:545,t:1528143908646};\\\", \\\"{x:374,y:549,t:1528143908664};\\\", \\\"{x:361,y:553,t:1528143908680};\\\", \\\"{x:352,y:554,t:1528143908696};\\\", \\\"{x:341,y:558,t:1528143908712};\\\", \\\"{x:335,y:559,t:1528143908730};\\\", \\\"{x:330,y:561,t:1528143908746};\\\", \\\"{x:326,y:562,t:1528143908762};\\\", \\\"{x:321,y:564,t:1528143908779};\\\", \\\"{x:314,y:567,t:1528143908796};\\\", \\\"{x:306,y:569,t:1528143908812};\\\", \\\"{x:298,y:571,t:1528143908829};\\\", \\\"{x:292,y:573,t:1528143908846};\\\", \\\"{x:286,y:574,t:1528143908863};\\\", \\\"{x:277,y:575,t:1528143908880};\\\", \\\"{x:271,y:577,t:1528143908898};\\\", \\\"{x:266,y:577,t:1528143908912};\\\", \\\"{x:263,y:578,t:1528143908929};\\\", \\\"{x:259,y:578,t:1528143908946};\\\", \\\"{x:256,y:578,t:1528143908964};\\\", \\\"{x:251,y:581,t:1528143908980};\\\", \\\"{x:249,y:581,t:1528143908996};\\\", \\\"{x:243,y:583,t:1528143909013};\\\", \\\"{x:240,y:583,t:1528143909030};\\\", \\\"{x:237,y:584,t:1528143909046};\\\", \\\"{x:239,y:584,t:1528143909110};\\\", \\\"{x:246,y:584,t:1528143909117};\\\", \\\"{x:257,y:584,t:1528143909130};\\\", \\\"{x:288,y:582,t:1528143909148};\\\", \\\"{x:318,y:582,t:1528143909163};\\\", \\\"{x:346,y:582,t:1528143909180};\\\", \\\"{x:378,y:582,t:1528143909196};\\\", \\\"{x:439,y:582,t:1528143909214};\\\", \\\"{x:470,y:582,t:1528143909230};\\\", \\\"{x:487,y:582,t:1528143909246};\\\", \\\"{x:498,y:580,t:1528143909263};\\\", \\\"{x:503,y:579,t:1528143909281};\\\", \\\"{x:507,y:579,t:1528143909296};\\\", \\\"{x:509,y:579,t:1528143909313};\\\", \\\"{x:514,y:576,t:1528143909330};\\\", \\\"{x:517,y:574,t:1528143909346};\\\", \\\"{x:523,y:570,t:1528143909364};\\\", \\\"{x:530,y:566,t:1528143909380};\\\", \\\"{x:540,y:561,t:1528143909398};\\\", \\\"{x:548,y:557,t:1528143909413};\\\", \\\"{x:551,y:555,t:1528143909430};\\\", \\\"{x:553,y:553,t:1528143909453};\\\", \\\"{x:555,y:552,t:1528143909463};\\\", \\\"{x:559,y:549,t:1528143909480};\\\", \\\"{x:565,y:547,t:1528143909496};\\\", \\\"{x:572,y:544,t:1528143909514};\\\", \\\"{x:582,y:542,t:1528143909530};\\\", \\\"{x:593,y:538,t:1528143909546};\\\", \\\"{x:599,y:538,t:1528143909563};\\\", \\\"{x:603,y:537,t:1528143909580};\\\", \\\"{x:605,y:537,t:1528143909596};\\\", \\\"{x:603,y:537,t:1528143909852};\\\", \\\"{x:600,y:537,t:1528143909863};\\\", \\\"{x:597,y:538,t:1528143909880};\\\", \\\"{x:592,y:542,t:1528143909898};\\\", \\\"{x:582,y:551,t:1528143909913};\\\", \\\"{x:576,y:557,t:1528143909930};\\\", \\\"{x:574,y:562,t:1528143909948};\\\", \\\"{x:571,y:568,t:1528143909963};\\\", \\\"{x:566,y:581,t:1528143909981};\\\", \\\"{x:558,y:594,t:1528143909998};\\\", \\\"{x:553,y:604,t:1528143910013};\\\", \\\"{x:548,y:616,t:1528143910030};\\\", \\\"{x:547,y:620,t:1528143910047};\\\", \\\"{x:546,y:625,t:1528143910063};\\\", \\\"{x:542,y:634,t:1528143910080};\\\", \\\"{x:539,y:642,t:1528143910097};\\\", \\\"{x:536,y:652,t:1528143910115};\\\", \\\"{x:531,y:663,t:1528143910130};\\\", \\\"{x:524,y:672,t:1528143910148};\\\", \\\"{x:523,y:674,t:1528143910165};\\\", \\\"{x:523,y:675,t:1528143910181};\\\", \\\"{x:522,y:679,t:1528143910198};\\\", \\\"{x:521,y:681,t:1528143910217};\\\", \\\"{x:520,y:683,t:1528143910231};\\\", \\\"{x:519,y:685,t:1528143910248};\\\", \\\"{x:518,y:689,t:1528143910265};\\\", \\\"{x:517,y:691,t:1528143910280};\\\", \\\"{x:517,y:692,t:1528143910297};\\\", \\\"{x:516,y:692,t:1528143910315};\\\", \\\"{x:514,y:693,t:1528143910331};\\\", \\\"{x:514,y:694,t:1528143910347};\\\", \\\"{x:512,y:694,t:1528143910365};\\\", \\\"{x:511,y:695,t:1528143910660};\\\", \\\"{x:511,y:696,t:1528143910669};\\\", \\\"{x:511,y:697,t:1528143910681};\\\", \\\"{x:514,y:699,t:1528143910697};\\\", \\\"{x:515,y:699,t:1528143910714};\\\", \\\"{x:524,y:702,t:1528143910731};\\\", \\\"{x:534,y:704,t:1528143910747};\\\", \\\"{x:550,y:706,t:1528143910765};\\\", \\\"{x:566,y:710,t:1528143910781};\\\", \\\"{x:575,y:715,t:1528143910797};\\\", \\\"{x:587,y:719,t:1528143910815};\\\", \\\"{x:597,y:723,t:1528143910831};\\\", \\\"{x:602,y:725,t:1528143910847};\\\", \\\"{x:609,y:727,t:1528143910864};\\\", \\\"{x:615,y:729,t:1528143910882};\\\", \\\"{x:622,y:732,t:1528143910897};\\\", \\\"{x:624,y:732,t:1528143910914};\\\", \\\"{x:629,y:732,t:1528143910931};\\\", \\\"{x:634,y:732,t:1528143910948};\\\", \\\"{x:638,y:732,t:1528143910965};\\\", \\\"{x:640,y:732,t:1528143911086};\\\", \\\"{x:642,y:732,t:1528143911117};\\\", \\\"{x:642,y:730,t:1528143911141};\\\", \\\"{x:643,y:729,t:1528143911182};\\\", \\\"{x:644,y:729,t:1528143911199};\\\", \\\"{x:646,y:728,t:1528143911262};\\\", \\\"{x:647,y:728,t:1528143911277};\\\", \\\"{x:648,y:728,t:1528143911294};\\\", \\\"{x:649,y:728,t:1528143911301};\\\", \\\"{x:650,y:728,t:1528143911317};\\\", \\\"{x:651,y:728,t:1528143911486};\\\", \\\"{x:652,y:728,t:1528143911498};\\\", \\\"{x:654,y:728,t:1528143911515};\\\", \\\"{x:660,y:728,t:1528143911532};\\\", \\\"{x:680,y:729,t:1528143911549};\\\", \\\"{x:692,y:728,t:1528143911565};\\\", \\\"{x:696,y:718,t:1528143911582};\\\", \\\"{x:693,y:706,t:1528143911618};\\\", \\\"{x:692,y:705,t:1528143911631};\\\", \\\"{x:691,y:705,t:1528143911648};\\\", \\\"{x:691,y:704,t:1528143911665};\\\" ] }, { \\\"rt\\\": 39649, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 472707, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"8182H\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"Go up the diagonal line to the right until you find a letter.\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 5639, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"21\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Russia\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 479353, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"8182H\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 15861, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Third\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Biomedical & Health Sciences\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 496239, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"8182H\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" }, { \\\"rt\\\": 1635, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 499196, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"8182H\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"zulu\\\", \\\"condition\\\": \\\"211\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"8182H\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 227, dom: 1136, initialDom: 1213",
  "javascriptErrors": []
}