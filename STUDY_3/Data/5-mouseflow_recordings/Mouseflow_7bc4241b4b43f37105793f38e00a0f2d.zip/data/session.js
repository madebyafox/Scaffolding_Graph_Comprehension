var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "7bc4241b4b43f37105793f38e00a0f2d",
  "created": "2018-05-15T14:05:10.3579942-07:00",
  "lastActivity": "2018-05-15T14:05:49.7239942-07:00",
  "pageViews": [
    {
      "id": "051510749a1726dd0a2d5585a669868b4d3ef05c",
      "startTime": "2018-05-15T14:05:10.3579942-07:00",
      "endTime": "2018-05-15T14:05:49.7239942-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/2",
      "visitTime": 39366,
      "engagementTime": 35012,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 39366,
  "engagementTime": 35012,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.22",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.170 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.170",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=8LGZ4",
    "CONDITION=111",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "7701997c8ef0533cb49874038d8ef689",
  "gdpr": false
}