var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "8e60fd6d5770373c2c88350d8b49bbf1",
  "created": "2018-06-04T12:18:45.486526-07:00",
  "lastActivity": "2018-06-04T12:18:56.5779943-07:00",
  "pageViews": [
    {
      "id": "06044542e8098098f75ce690d823ffbb1df090ef",
      "startTime": "2018-06-04T12:18:45.6698353-07:00",
      "endTime": "2018-06-04T12:18:56.5779943-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/10",
      "visitTime": 11044,
      "engagementTime": 11044,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 11044,
  "engagementTime": 11044,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.37",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=CKDM5",
    "CONDITION=311",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "ffc88f56daf58abd8365d2a6e7b3ee9b",
  "gdpr": false
}