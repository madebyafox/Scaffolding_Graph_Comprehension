var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "c518c44cbeb1523324663912d5bbc6f0",
  "created": "2018-05-18T11:13:55.300226-07:00",
  "lastActivity": "2018-05-18T11:15:15.918226-07:00",
  "pageViews": [
    {
      "id": "05185510fea2f316282803ebb9d084e844905e0a",
      "startTime": "2018-05-18T11:13:55.300226-07:00",
      "endTime": "2018-05-18T11:15:15.918226-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/4",
      "visitTime": 80618,
      "engagementTime": 78018,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 80618,
  "engagementTime": 78018,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.39",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=OY8PV",
    "CONDITION=113",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "7062b14acb69d1fa6d1c77dfa3f552d8",
  "gdpr": false
}