var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "8bcde201309472687ab1024d92f47cfc",
  "created": "2018-06-04T13:24:03.2854111-07:00",
  "lastActivity": "2018-06-04T13:24:47.3616532-07:00",
  "pageViews": [
    {
      "id": "060403272be7e1f758e4851ef3a6144a91e2db0f",
      "startTime": "2018-06-04T13:24:03.2854111-07:00",
      "endTime": "2018-06-04T13:24:47.3616532-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/10",
      "visitTime": 44371,
      "engagementTime": 44170,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 44371,
  "engagementTime": 44170,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.31",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=GD39M",
    "CONDITION=211",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "d4cf5a408bef27fcfbf4faa4a9441b95",
  "gdpr": false
}