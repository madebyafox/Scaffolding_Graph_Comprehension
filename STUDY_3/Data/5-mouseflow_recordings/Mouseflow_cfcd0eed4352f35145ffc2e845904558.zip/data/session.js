var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "cfcd0eed4352f35145ffc2e845904558",
  "created": "2018-06-01T11:12:40.7619108-07:00",
  "lastActivity": "2018-06-01T11:13:13.8039108-07:00",
  "pageViews": [
    {
      "id": "06014064c08a5bd8ff22738c33894f493fd26fc0",
      "startTime": "2018-06-01T11:12:40.7619108-07:00",
      "endTime": "2018-06-01T11:13:13.8039108-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/7",
      "visitTime": 33042,
      "engagementTime": 22164,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 33042,
  "engagementTime": 22164,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.40",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=41Y1H",
    "CONDITION=311",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "defc3dcf63bee3b1981ced8b69bcfef8",
  "gdpr": false
}