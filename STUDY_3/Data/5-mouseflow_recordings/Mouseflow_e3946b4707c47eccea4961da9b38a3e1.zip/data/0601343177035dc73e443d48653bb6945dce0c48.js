var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["0601343177035dc73e443d48653bb6945dce0c48"] = {
  "startTime": "2018-06-01T18:15:34.049082Z",
  "websitePageUrl": "/16",
  "visitTime": 67207,
  "engagementTime": 66832,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "e3946b4707c47eccea4961da9b38a3e1",
    "created": "2018-06-01T18:15:33.84765+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=2ZXKM",
      "CONDITION=311"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "d5353253a67ec440b96a21fa5bc9561a",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/e3946b4707c47eccea4961da9b38a3e1/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 197,
      "e": 197,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 197,
      "e": 197,
      "ty": 2,
      "x": 919,
      "y": 663
    },
    {
      "t": 250,
      "e": 250,
      "ty": 41,
      "x": 9232,
      "y": 37530,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 300,
      "e": 300,
      "ty": 2,
      "x": 853,
      "y": 618
    },
    {
      "t": 400,
      "e": 400,
      "ty": 2,
      "x": 480,
      "y": 392
    },
    {
      "t": 500,
      "e": 500,
      "ty": 2,
      "x": 429,
      "y": 387
    },
    {
      "t": 501,
      "e": 501,
      "ty": 41,
      "x": 37309,
      "y": 20995,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 601,
      "e": 601,
      "ty": 2,
      "x": 435,
      "y": 526
    },
    {
      "t": 780,
      "e": 780,
      "ty": 2,
      "x": 476,
      "y": 588
    },
    {
      "t": 780,
      "e": 780,
      "ty": 41,
      "x": 42592,
      "y": 52804,
      "ta": "#strategyAnswer"
    },
    {
      "t": 917,
      "e": 917,
      "ty": 3,
      "x": 476,
      "y": 588,
      "ta": "#strategyAnswer"
    },
    {
      "t": 917,
      "e": 917,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1045,
      "e": 1045,
      "ty": 4,
      "x": 42592,
      "y": 52804,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1045,
      "e": 1045,
      "ty": 5,
      "x": 476,
      "y": 588,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1400,
      "e": 1400,
      "ty": 2,
      "x": 499,
      "y": 568
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 2,
      "x": 491,
      "y": 525
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 41,
      "x": 44278,
      "y": 1833,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1900,
      "e": 1900,
      "ty": 2,
      "x": 491,
      "y": 522
    },
    {
      "t": 1917,
      "e": 1917,
      "ty": 7,
      "x": 491,
      "y": 516,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2000,
      "e": 2000,
      "ty": 2,
      "x": 491,
      "y": 502
    },
    {
      "t": 2000,
      "e": 2000,
      "ty": 41,
      "x": 44278,
      "y": 17005,
      "ta": "#.strategy > p"
    },
    {
      "t": 2100,
      "e": 2100,
      "ty": 2,
      "x": 495,
      "y": 475
    },
    {
      "t": 2200,
      "e": 2200,
      "ty": 2,
      "x": 500,
      "y": 446
    },
    {
      "t": 2250,
      "e": 2250,
      "ty": 41,
      "x": 45290,
      "y": 24153,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 2300,
      "e": 2300,
      "ty": 2,
      "x": 501,
      "y": 444
    },
    {
      "t": 2401,
      "e": 2401,
      "ty": 2,
      "x": 502,
      "y": 441
    },
    {
      "t": 2500,
      "e": 2500,
      "ty": 41,
      "x": 45515,
      "y": 23987,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 2600,
      "e": 2600,
      "ty": 2,
      "x": 510,
      "y": 421
    },
    {
      "t": 2700,
      "e": 2700,
      "ty": 2,
      "x": 516,
      "y": 403
    },
    {
      "t": 2750,
      "e": 2750,
      "ty": 41,
      "x": 47089,
      "y": 21826,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 2800,
      "e": 2800,
      "ty": 2,
      "x": 516,
      "y": 402
    },
    {
      "t": 2900,
      "e": 2900,
      "ty": 2,
      "x": 554,
      "y": 398
    },
    {
      "t": 3001,
      "e": 3001,
      "ty": 2,
      "x": 1407,
      "y": 468
    },
    {
      "t": 3001,
      "e": 3001,
      "ty": 41,
      "x": 43761,
      "y": 23635,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 3100,
      "e": 3100,
      "ty": 2,
      "x": 1842,
      "y": 384
    },
    {
      "t": 3251,
      "e": 3251,
      "ty": 41,
      "x": 63158,
      "y": 20829,
      "ta": "> div.stimulus"
    },
    {
      "t": 3700,
      "e": 3700,
      "ty": 2,
      "x": 1837,
      "y": 378
    },
    {
      "t": 3750,
      "e": 3750,
      "ty": 41,
      "x": 45523,
      "y": 14969,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 3800,
      "e": 3800,
      "ty": 2,
      "x": 875,
      "y": 417
    },
    {
      "t": 3900,
      "e": 3900,
      "ty": 2,
      "x": 550,
      "y": 433
    },
    {
      "t": 4000,
      "e": 4000,
      "ty": 2,
      "x": 539,
      "y": 442
    },
    {
      "t": 4001,
      "e": 4001,
      "ty": 41,
      "x": 49674,
      "y": 24042,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 4085,
      "e": 4085,
      "ty": 6,
      "x": 518,
      "y": 532,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4100,
      "e": 4100,
      "ty": 2,
      "x": 518,
      "y": 532
    },
    {
      "t": 4200,
      "e": 4200,
      "ty": 2,
      "x": 496,
      "y": 591
    },
    {
      "t": 4251,
      "e": 4251,
      "ty": 41,
      "x": 44841,
      "y": 55231,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4356,
      "e": 4356,
      "ty": 3,
      "x": 496,
      "y": 591,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4485,
      "e": 4485,
      "ty": 4,
      "x": 44841,
      "y": 55231,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4485,
      "e": 4485,
      "ty": 5,
      "x": 496,
      "y": 591,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4750,
      "e": 4750,
      "ty": 41,
      "x": 44728,
      "y": 55231,
      "ta": "#strategyAnswer"
    },
    {
      "t": 4800,
      "e": 4800,
      "ty": 2,
      "x": 495,
      "y": 591
    },
    {
      "t": 5101,
      "e": 5101,
      "ty": 2,
      "x": 498,
      "y": 591
    },
    {
      "t": 5135,
      "e": 5135,
      "ty": 7,
      "x": 770,
      "y": 553,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5200,
      "e": 5200,
      "ty": 2,
      "x": 1065,
      "y": 536
    },
    {
      "t": 5250,
      "e": 5250,
      "ty": 41,
      "x": 62224,
      "y": 31800,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 5300,
      "e": 5300,
      "ty": 2,
      "x": 1919,
      "y": 737
    },
    {
      "t": 5609,
      "e": 5609,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 5801,
      "e": 5801,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 5801,
      "e": 5801,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 5897,
      "e": 5897,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "T"
    },
    {
      "t": 5912,
      "e": 5912,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "T"
    },
    {
      "t": 6009,
      "e": 6009,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 6009,
      "e": 6009,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6096,
      "e": 6096,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 6096,
      "e": 6096,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6112,
      "e": 6112,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The"
    },
    {
      "t": 6168,
      "e": 6168,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 6168,
      "e": 6168,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6192,
      "e": 6192,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The "
    },
    {
      "t": 6289,
      "e": 6289,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 6313,
      "e": 6313,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 6313,
      "e": 6313,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6425,
      "e": 6425,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 6440,
      "e": 6440,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 6440,
      "e": 6440,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6552,
      "e": 6552,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 6552,
      "e": 6552,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6585,
      "e": 6585,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ve"
    },
    {
      "t": 6656,
      "e": 6656,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 6769,
      "e": 6769,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 6769,
      "e": 6769,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 6865,
      "e": 6865,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 7920,
      "e": 7920,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 7920,
      "e": 7920,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 7984,
      "e": 7984,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 7984,
      "e": 7984,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8032,
      "e": 8032,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ts"
    },
    {
      "t": 8088,
      "e": 8088,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 8104,
      "e": 8104,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 8105,
      "e": 8105,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8200,
      "e": 8200,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 8560,
      "e": 8560,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 8560,
      "e": 8560,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8632,
      "e": 8632,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 8633,
      "e": 8633,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 8633,
      "e": 8633,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8720,
      "e": 8720,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 8824,
      "e": 8824,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 8824,
      "e": 8824,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8920,
      "e": 8920,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 8920,
      "e": 8920,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 8960,
      "e": 8960,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 8993,
      "e": 8993,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 8993,
      "e": 8993,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9041,
      "e": 9041,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 9136,
      "e": 9136,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 9136,
      "e": 9136,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9145,
      "e": 9145,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 9281,
      "e": 9281,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 9505,
      "e": 9505,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 9505,
      "e": 9505,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9625,
      "e": 9625,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 9720,
      "e": 9720,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 9720,
      "e": 9720,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9816,
      "e": 9816,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 9816,
      "e": 9816,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9889,
      "e": 9889,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ar"
    },
    {
      "t": 9913,
      "e": 9913,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10025,
      "e": 10025,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 10025,
      "e": 10025,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10128,
      "e": 10128,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 10136,
      "e": 10136,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 10136,
      "e": 10136,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10280,
      "e": 10280,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 10288,
      "e": 10288,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 10288,
      "e": 10288,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10401,
      "e": 10401,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events that start a"
    },
    {
      "t": 10424,
      "e": 10424,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 10488,
      "e": 10488,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 10488,
      "e": 10488,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10602,
      "e": 10602,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events that start at"
    },
    {
      "t": 10633,
      "e": 10633,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 10681,
      "e": 10681,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 10681,
      "e": 10681,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10784,
      "e": 10784,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 11056,
      "e": 11056,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 11057,
      "e": 11057,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11193,
      "e": 11193,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 11193,
      "e": 11193,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11281,
      "e": 11281,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 11344,
      "e": 11344,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 11344,
      "e": 11344,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11393,
      "e": 11393,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 11464,
      "e": 11464,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 11593,
      "e": 11593,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 11728,
      "e": 11728,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 11729,
      "e": 11729,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11841,
      "e": 11841,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||P"
    },
    {
      "t": 11880,
      "e": 11880,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12400,
      "e": 12400,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 12536,
      "e": 12536,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 12536,
      "e": 12536,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12624,
      "e": 12624,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||M"
    },
    {
      "t": 12672,
      "e": 12672,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12729,
      "e": 12729,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12729,
      "e": 12729,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12817,
      "e": 12817,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 13248,
      "e": 13248,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 13248,
      "e": 13248,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13344,
      "e": 13344,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 13400,
      "e": 13400,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 13400,
      "e": 13400,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13520,
      "e": 13520,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 13520,
      "e": 13520,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13568,
      "e": 13568,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||re"
    },
    {
      "t": 13632,
      "e": 13632,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13632,
      "e": 13632,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13672,
      "e": 13672,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 13752,
      "e": 13752,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13809,
      "e": 13809,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 13809,
      "e": 13809,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13865,
      "e": 13865,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 13865,
      "e": 13865,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13905,
      "e": 13905,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||on"
    },
    {
      "t": 13976,
      "e": 13976,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13985,
      "e": 13985,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13985,
      "e": 13985,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14081,
      "e": 14081,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 14144,
      "e": 14144,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 14144,
      "e": 14144,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14224,
      "e": 14224,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 14248,
      "e": 14248,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 14248,
      "e": 14248,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14377,
      "e": 14377,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 14424,
      "e": 14424,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 14424,
      "e": 14424,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14528,
      "e": 14528,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14528,
      "e": 14528,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14544,
      "e": 14544,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 14641,
      "e": 14641,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14840,
      "e": 14840,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 14841,
      "e": 14841,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14913,
      "e": 14913,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 14952,
      "e": 14952,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 14952,
      "e": 14952,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15017,
      "e": 15017,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 15112,
      "e": 15112,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 15113,
      "e": 15113,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15192,
      "e": 15192,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 15480,
      "e": 15480,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 15481,
      "e": 15481,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15553,
      "e": 15553,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 15737,
      "e": 15737,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 15737,
      "e": 15737,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15785,
      "e": 15785,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 15809,
      "e": 15809,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 15810,
      "e": 15810,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15873,
      "e": 15873,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 16002,
      "e": 16002,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events that start at 12 PM are on the diagoo"
    },
    {
      "t": 16024,
      "e": 16024,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 16024,
      "e": 16024,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16097,
      "e": 16097,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 16202,
      "e": 16202,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events that start at 12 PM are on the diagoon"
    },
    {
      "t": 16336,
      "e": 16336,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16384,
      "e": 16384,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events that start at 12 PM are on the diagoo"
    },
    {
      "t": 16704,
      "e": 16704,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 16768,
      "e": 16768,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events that start at 12 PM are on the diago"
    },
    {
      "t": 16952,
      "e": 16952,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 16952,
      "e": 16952,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17040,
      "e": 16952,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 17105,
      "e": 17017,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 17105,
      "e": 17017,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17216,
      "e": 17128,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 17224,
      "e": 17136,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 17224,
      "e": 17136,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17320,
      "e": 17232,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 17361,
      "e": 17273,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 17361,
      "e": 17273,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17472,
      "e": 17384,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18336,
      "e": 18248,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 18337,
      "e": 18249,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18456,
      "e": 18368,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 18456,
      "e": 18368,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18520,
      "e": 18432,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||li"
    },
    {
      "t": 18536,
      "e": 18448,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 18536,
      "e": 18448,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18592,
      "e": 18504,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 18624,
      "e": 18536,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 18624,
      "e": 18536,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18656,
      "e": 18568,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 18704,
      "e": 18616,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 18704,
      "e": 18616,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18712,
      "e": 18624,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18792,
      "e": 18704,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18832,
      "e": 18744,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 18832,
      "e": 18744,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18936,
      "e": 18848,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 18960,
      "e": 18872,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 18960,
      "e": 18872,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19048,
      "e": 18960,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 19072,
      "e": 18984,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 19072,
      "e": 18984,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19152,
      "e": 19064,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 19152,
      "e": 19064,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19200,
      "e": 19112,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||at"
    },
    {
      "t": 19248,
      "e": 19160,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19248,
      "e": 19160,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19304,
      "e": 19216,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 19368,
      "e": 19280,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19416,
      "e": 19328,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 19416,
      "e": 19328,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19505,
      "e": 19417,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 19505,
      "e": 19417,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19552,
      "e": 19464,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 19616,
      "e": 19528,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19624,
      "e": 19536,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 19625,
      "e": 19537,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19752,
      "e": 19664,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 19760,
      "e": 19672,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 19760,
      "e": 19672,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19872,
      "e": 19784,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 19873,
      "e": 19785,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19880,
      "e": 19792,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||er"
    },
    {
      "t": 19992,
      "e": 19904,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20712,
      "e": 20624,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 20712,
      "e": 20624,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20832,
      "e": 20744,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 20833,
      "e": 20745,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 20864,
      "e": 20776,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||se"
    },
    {
      "t": 20952,
      "e": 20864,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "67"
    },
    {
      "t": 20953,
      "e": 20865,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21000,
      "e": 20912,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||c"
    },
    {
      "t": 21064,
      "e": 20976,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21224,
      "e": 21136,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 21224,
      "e": 21136,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21312,
      "e": 21224,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 21313,
      "e": 21225,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21337,
      "e": 21249,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ts"
    },
    {
      "t": 21376,
      "e": 21288,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 21376,
      "e": 21288,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21433,
      "e": 21345,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 21488,
      "e": 21400,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 21488,
      "e": 21400,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 21496,
      "e": 21408,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 21568,
      "e": 21480,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 21856,
      "e": 21768,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 21904,
      "e": 21816,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events that start at 12 PM are on the diagonal line that intersects "
    },
    {
      "t": 21984,
      "e": 21896,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 21984,
      "e": 21896,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22072,
      "e": 21984,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||w"
    },
    {
      "t": 22112,
      "e": 22024,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 22112,
      "e": 22024,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22208,
      "e": 22120,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 22232,
      "e": 22144,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 22232,
      "e": 22144,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22313,
      "e": 22225,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 22336,
      "e": 22248,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 22336,
      "e": 22248,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22424,
      "e": 22336,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 22432,
      "e": 22344,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22433,
      "e": 22345,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22528,
      "e": 22440,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 22528,
      "e": 22440,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22544,
      "e": 22456,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 22600,
      "e": 22512,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 22600,
      "e": 22512,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22608,
      "e": 22520,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 22680,
      "e": 22592,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 22680,
      "e": 22592,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22688,
      "e": 22600,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 22784,
      "e": 22696,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 22784,
      "e": 22696,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 22808,
      "e": 22720,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 22888,
      "e": 22800,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 23040,
      "e": 22952,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 23041,
      "e": 22953,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23120,
      "e": 23032,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 23320,
      "e": 23232,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "189"
    },
    {
      "t": 23320,
      "e": 23232,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23384,
      "e": 23296,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||-"
    },
    {
      "t": 23456,
      "e": 23368,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 23457,
      "e": 23369,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23584,
      "e": 23496,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 23624,
      "e": 23536,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "88"
    },
    {
      "t": 23624,
      "e": 23536,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23736,
      "e": 23648,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||x"
    },
    {
      "t": 23777,
      "e": 23689,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 23777,
      "e": 23689,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23831,
      "e": 23743,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 23888,
      "e": 23800,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 23888,
      "e": 23800,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 23984,
      "e": 23800,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 24024,
      "e": 23840,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "190"
    },
    {
      "t": 24024,
      "e": 23840,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24104,
      "e": 23920,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||."
    },
    {
      "t": 24160,
      "e": 23976,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 24160,
      "e": 23976,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24264,
      "e": 24080,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 24512,
      "e": 24328,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 24720,
      "e": 24536,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 24721,
      "e": 24537,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24792,
      "e": 24608,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||I"
    },
    {
      "t": 24832,
      "e": 24648,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 24904,
      "e": 24720,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "222"
    },
    {
      "t": 24904,
      "e": 24720,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25000,
      "e": 24816,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 25001,
      "e": 24817,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25040,
      "e": 24856,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||'m"
    },
    {
      "t": 25104,
      "e": 24920,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25112,
      "e": 24928,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 25112,
      "e": 24928,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25208,
      "e": 25024,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 25280,
      "e": 25096,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 25281,
      "e": 25097,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25402,
      "e": 25218,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events that start at 12 PM are on the diagonal line that intersects with the x-axis. I'm r"
    },
    {
      "t": 25408,
      "e": 25224,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 25408,
      "e": 25224,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25440,
      "e": 25256,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||re"
    },
    {
      "t": 25447,
      "e": 25263,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 25448,
      "e": 25264,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25512,
      "e": 25328,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 25576,
      "e": 25392,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 25576,
      "e": 25392,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25584,
      "e": 25400,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 25632,
      "e": 25448,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 25712,
      "e": 25528,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 25712,
      "e": 25528,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25808,
      "e": 25624,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 25952,
      "e": 25768,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 25952,
      "e": 25768,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26040,
      "e": 25856,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 26088,
      "e": 25904,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26088,
      "e": 25904,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26200,
      "e": 26016,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 26207,
      "e": 26023,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "74"
    },
    {
      "t": 26207,
      "e": 26023,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26280,
      "e": 26096,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||j"
    },
    {
      "t": 26376,
      "e": 26192,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 26376,
      "e": 26192,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26472,
      "e": 26288,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 26472,
      "e": 26288,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 26472,
      "e": 26288,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26576,
      "e": 26392,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 26576,
      "e": 26392,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26624,
      "e": 26440,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||st"
    },
    {
      "t": 26640,
      "e": 26456,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26640,
      "e": 26456,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26657,
      "e": 26473,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 26728,
      "e": 26544,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 26800,
      "e": 26616,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 26800,
      "e": 26616,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26904,
      "e": 26720,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 26904,
      "e": 26720,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26928,
      "e": 26744,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||tr"
    },
    {
      "t": 26960,
      "e": 26776,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 26961,
      "e": 26777,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27024,
      "e": 26840,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 27064,
      "e": 26880,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27184,
      "e": 27000,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 27184,
      "e": 27000,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27272,
      "e": 27088,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 27272,
      "e": 27088,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27304,
      "e": 27120,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||in"
    },
    {
      "t": 27352,
      "e": 27168,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 27353,
      "e": 27169,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27384,
      "e": 27200,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 27424,
      "e": 27240,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27432,
      "e": 27248,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27432,
      "e": 27248,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27536,
      "e": 27352,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27552,
      "e": 27368,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 27552,
      "e": 27368,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27632,
      "e": 27448,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 27632,
      "e": 27448,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27640,
      "e": 27456,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||to"
    },
    {
      "t": 27728,
      "e": 27544,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27759,
      "e": 27575,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 27760,
      "e": 27576,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27856,
      "e": 27672,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 27944,
      "e": 27760,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 27945,
      "e": 27761,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28064,
      "e": 27880,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 28065,
      "e": 27881,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28096,
      "e": 27912,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||li"
    },
    {
      "t": 28128,
      "e": 27944,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 28128,
      "e": 27944,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28160,
      "e": 27976,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 28232,
      "e": 28048,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 28233,
      "e": 28049,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28239,
      "e": 28055,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 28328,
      "e": 28144,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 28328,
      "e": 28144,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28368,
      "e": 28184,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 28440,
      "e": 28256,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 28464,
      "e": 28280,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 28464,
      "e": 28280,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28552,
      "e": 28368,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 28624,
      "e": 28440,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28625,
      "e": 28441,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28736,
      "e": 28552,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 28752,
      "e": 28568,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 28753,
      "e": 28569,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28864,
      "e": 28680,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 28864,
      "e": 28680,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 28865,
      "e": 28681,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28952,
      "e": 28768,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 28992,
      "e": 28808,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 28992,
      "e": 28808,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29136,
      "e": 28952,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 29144,
      "e": 28960,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 29144,
      "e": 28960,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29248,
      "e": 29064,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 29264,
      "e": 29080,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 29265,
      "e": 29081,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29352,
      "e": 29168,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 29352,
      "e": 29168,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29368,
      "e": 29184,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||he"
    },
    {
      "t": 29448,
      "e": 29264,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29448,
      "e": 29264,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29480,
      "e": 29296,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 29568,
      "e": 29384,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30032,
      "e": 29848,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 30032,
      "e": 29848,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30128,
      "e": 29944,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 30144,
      "e": 29960,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 30144,
      "e": 29960,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30256,
      "e": 30072,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "87"
    },
    {
      "t": 30256,
      "e": 30072,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30280,
      "e": 30096,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ew"
    },
    {
      "t": 30336,
      "e": 30152,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30336,
      "e": 30152,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30384,
      "e": 30200,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 30464,
      "e": 30280,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30479,
      "e": 30295,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 30584,
      "e": 30400,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 30584,
      "e": 30400,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30664,
      "e": 30480,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||K"
    },
    {
      "t": 30680,
      "e": 30496,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30928,
      "e": 30744,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 30928,
      "e": 30744,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31015,
      "e": 30831,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 31023,
      "e": 30839,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 31024,
      "e": 30840,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31096,
      "e": 30912,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 31201,
      "e": 31017,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events that start at 12 PM are on the diagonal line that intersects with the x-axis. I'm really just trying to listen to the new Kan"
    },
    {
      "t": 31240,
      "e": 31056,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 31240,
      "e": 31056,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31384,
      "e": 31200,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 31392,
      "e": 31208,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 31393,
      "e": 31209,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31464,
      "e": 31280,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 31464,
      "e": 31280,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31495,
      "e": 31311,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 31560,
      "e": 31376,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 31576,
      "e": 31392,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 31839,
      "e": 31655,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 31984,
      "e": 31800,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 31985,
      "e": 31801,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32088,
      "e": 31904,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 32231,
      "e": 32047,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 32231,
      "e": 32047,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32312,
      "e": 32128,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l"
    },
    {
      "t": 32432,
      "e": 32248,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 32433,
      "e": 32249,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32560,
      "e": 32376,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 32560,
      "e": 32376,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32584,
      "e": 32400,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||bu"
    },
    {
      "t": 32672,
      "e": 32488,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 32832,
      "e": 32648,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 32832,
      "e": 32648,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32920,
      "e": 32736,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 32960,
      "e": 32776,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 32960,
      "e": 32776,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33064,
      "e": 32880,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 33112,
      "e": 32928,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 33112,
      "e": 32928,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33232,
      "e": 33048,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 33232,
      "e": 33048,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33264,
      "e": 33080,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||bu"
    },
    {
      "t": 33320,
      "e": 33136,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 33320,
      "e": 33136,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33328,
      "e": 33144,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 33392,
      "e": 33208,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33392,
      "e": 33208,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33400,
      "e": 33216,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 33512,
      "e": 33328,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 33512,
      "e": 33328,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33536,
      "e": 33352,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 33552,
      "e": 33368,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 33552,
      "e": 33368,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33632,
      "e": 33448,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||h"
    },
    {
      "t": 33656,
      "e": 33472,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 33656,
      "e": 33472,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33696,
      "e": 33512,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 33752,
      "e": 33568,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 33752,
      "e": 33568,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33760,
      "e": 33576,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 33784,
      "e": 33600,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33784,
      "e": 33600,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33823,
      "e": 33639,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 33935,
      "e": 33751,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33943,
      "e": 33759,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 33944,
      "e": 33760,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34032,
      "e": 33848,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 34032,
      "e": 33848,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34048,
      "e": 33864,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||st"
    },
    {
      "t": 34088,
      "e": 33904,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 34112,
      "e": 33928,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 34112,
      "e": 33928,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34184,
      "e": 34000,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 34240,
      "e": 34056,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 34241,
      "e": 34057,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34312,
      "e": 34128,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 34391,
      "e": 34207,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "70"
    },
    {
      "t": 34392,
      "e": 34208,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34456,
      "e": 34272,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||f"
    },
    {
      "t": 34704,
      "e": 34520,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34744,
      "e": 34521,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events that start at 12 PM are on the diagonal line that intersects with the x-axis. I'm really just trying to listen to the new Kanye album but this stuf"
    },
    {
      "t": 34832,
      "e": 34609,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 34888,
      "e": 34665,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events that start at 12 PM are on the diagonal line that intersects with the x-axis. I'm really just trying to listen to the new Kanye album but this stu"
    },
    {
      "t": 34968,
      "e": 34745,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 34968,
      "e": 34745,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35056,
      "e": 34833,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 35256,
      "e": 35033,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "89"
    },
    {
      "t": 35256,
      "e": 35033,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35328,
      "e": 35105,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||y"
    },
    {
      "t": 35488,
      "e": 35265,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 35488,
      "e": 35265,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35584,
      "e": 35361,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 35703,
      "e": 35480,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 35704,
      "e": 35481,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35792,
      "e": 35569,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 35832,
      "e": 35609,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 35832,
      "e": 35609,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 35912,
      "e": 35689,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s"
    },
    {
      "t": 35944,
      "e": 35721,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 35944,
      "e": 35721,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36015,
      "e": 35792,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 36016,
      "e": 35793,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36031,
      "e": 35808,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| t"
    },
    {
      "t": 36088,
      "e": 35865,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 36089,
      "e": 35866,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36120,
      "e": 35897,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 36191,
      "e": 35968,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 36200,
      "e": 35977,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 36201,
      "e": 35978,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36248,
      "e": 36025,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||k"
    },
    {
      "t": 36392,
      "e": 36169,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 36392,
      "e": 36169,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36480,
      "e": 36257,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 36488,
      "e": 36265,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 36488,
      "e": 36265,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36520,
      "e": 36297,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||n"
    },
    {
      "t": 36528,
      "e": 36305,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 36528,
      "e": 36305,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36624,
      "e": 36401,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 36663,
      "e": 36440,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 36664,
      "e": 36441,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36760,
      "e": 36537,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 36824,
      "e": 36601,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 36824,
      "e": 36601,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 36920,
      "e": 36697,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||m"
    },
    {
      "t": 36936,
      "e": 36713,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 36936,
      "e": 36713,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37024,
      "e": 36801,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 37024,
      "e": 36801,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37039,
      "e": 36816,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e "
    },
    {
      "t": 37112,
      "e": 36889,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 37112,
      "e": 36889,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37120,
      "e": 36897,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 37176,
      "e": 36953,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "85"
    },
    {
      "t": 37176,
      "e": 36953,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37216,
      "e": 36993,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||u"
    },
    {
      "t": 37247,
      "e": 37024,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 37280,
      "e": 37057,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 37280,
      "e": 37057,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 37344,
      "e": 37121,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 37800,
      "e": 37577,
      "ty": 2,
      "x": 1897,
      "y": 727
    },
    {
      "t": 37900,
      "e": 37677,
      "ty": 2,
      "x": 1080,
      "y": 642
    },
    {
      "t": 38000,
      "e": 37777,
      "ty": 2,
      "x": 745,
      "y": 692
    },
    {
      "t": 38000,
      "e": 37777,
      "ty": 41,
      "x": 3725,
      "y": 39335,
      "ta": "> div.stimulus > div:[2]"
    },
    {
      "t": 38100,
      "e": 37877,
      "ty": 2,
      "x": 616,
      "y": 672
    },
    {
      "t": 38200,
      "e": 37977,
      "ty": 2,
      "x": 416,
      "y": 699
    },
    {
      "t": 38250,
      "e": 38027,
      "ty": 41,
      "x": 45596,
      "y": 50636,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 38396,
      "e": 38173,
      "ty": 6,
      "x": 414,
      "y": 688,
      "ta": "#strategyButton"
    },
    {
      "t": 38400,
      "e": 38177,
      "ty": 2,
      "x": 414,
      "y": 688
    },
    {
      "t": 38501,
      "e": 38278,
      "ty": 2,
      "x": 414,
      "y": 682
    },
    {
      "t": 38501,
      "e": 38278,
      "ty": 41,
      "x": 41181,
      "y": 52554,
      "ta": "#strategyButton"
    },
    {
      "t": 38580,
      "e": 38357,
      "ty": 3,
      "x": 414,
      "y": 682,
      "ta": "#strategyButton"
    },
    {
      "t": 38581,
      "e": 38357,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "The events that start at 12 PM are on the diagonal line that intersects with the x-axis. I'm really just trying to listen to the new Kanye album but this study is taking me out"
    },
    {
      "t": 38581,
      "e": 38357,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 38581,
      "e": 38357,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 38684,
      "e": 38460,
      "ty": 4,
      "x": 41181,
      "y": 52554,
      "ta": "#strategyButton"
    },
    {
      "t": 38691,
      "e": 38467,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 38693,
      "e": 38469,
      "ty": 5,
      "x": 414,
      "y": 682,
      "ta": "#strategyButton"
    },
    {
      "t": 38699,
      "e": 38475,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 39200,
      "e": 38976,
      "ty": 2,
      "x": 366,
      "y": 677
    },
    {
      "t": 39250,
      "e": 39026,
      "ty": 41,
      "x": 4132,
      "y": 30246,
      "ta": "html > body"
    },
    {
      "t": 39300,
      "e": 39076,
      "ty": 2,
      "x": 0,
      "y": 401
    },
    {
      "t": 39401,
      "e": 39177,
      "ty": 2,
      "x": 0,
      "y": 382
    },
    {
      "t": 39500,
      "e": 39276,
      "ty": 2,
      "x": 0,
      "y": 377
    },
    {
      "t": 39501,
      "e": 39277,
      "ty": 41,
      "x": 0,
      "y": 20884,
      "ta": "html"
    },
    {
      "t": 39601,
      "e": 39377,
      "ty": 2,
      "x": 10,
      "y": 381
    },
    {
      "t": 39695,
      "e": 39471,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 39700,
      "e": 39476,
      "ty": 2,
      "x": 152,
      "y": 423
    },
    {
      "t": 39751,
      "e": 39527,
      "ty": 41,
      "x": 5613,
      "y": 23433,
      "ta": "html > body"
    },
    {
      "t": 39800,
      "e": 39576,
      "ty": 2,
      "x": 171,
      "y": 431
    },
    {
      "t": 40101,
      "e": 39877,
      "ty": 2,
      "x": 598,
      "y": 517
    },
    {
      "t": 40204,
      "e": 39980,
      "ty": 2,
      "x": 711,
      "y": 517
    },
    {
      "t": 40250,
      "e": 40026,
      "ty": 41,
      "x": 25208,
      "y": 28197,
      "ta": "html > body"
    },
    {
      "t": 40300,
      "e": 40076,
      "ty": 2,
      "x": 814,
      "y": 521
    },
    {
      "t": 40364,
      "e": 40140,
      "ty": 6,
      "x": 889,
      "y": 562,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 40401,
      "e": 40177,
      "ty": 2,
      "x": 909,
      "y": 571
    },
    {
      "t": 40500,
      "e": 40276,
      "ty": 2,
      "x": 913,
      "y": 571
    },
    {
      "t": 40500,
      "e": 40276,
      "ty": 41,
      "x": 22710,
      "y": 53052,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 40564,
      "e": 40340,
      "ty": 3,
      "x": 913,
      "y": 571,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 40564,
      "e": 40340,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 40601,
      "e": 40377,
      "ty": 2,
      "x": 914,
      "y": 571
    },
    {
      "t": 40691,
      "e": 40467,
      "ty": 4,
      "x": 22926,
      "y": 53052,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 40691,
      "e": 40467,
      "ty": 5,
      "x": 914,
      "y": 571,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 40751,
      "e": 40527,
      "ty": 41,
      "x": 22926,
      "y": 53052,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 41131,
      "e": 40907,
      "ty": 7,
      "x": 915,
      "y": 578,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 41198,
      "e": 40974,
      "ty": 6,
      "x": 957,
      "y": 662,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 41200,
      "e": 40976,
      "ty": 2,
      "x": 957,
      "y": 662
    },
    {
      "t": 41214,
      "e": 40990,
      "ty": 7,
      "x": 965,
      "y": 677,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 41214,
      "e": 40990,
      "ty": 6,
      "x": 965,
      "y": 677,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 41251,
      "e": 41027,
      "ty": 41,
      "x": 36632,
      "y": 13901,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 41300,
      "e": 41076,
      "ty": 2,
      "x": 967,
      "y": 683
    },
    {
      "t": 41401,
      "e": 41177,
      "ty": 2,
      "x": 967,
      "y": 680
    },
    {
      "t": 41415,
      "e": 41191,
      "ty": 7,
      "x": 966,
      "y": 670,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 41430,
      "e": 41206,
      "ty": 6,
      "x": 963,
      "y": 663,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 41432,
      "e": 41208,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 41432,
      "e": 41208,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 41500,
      "e": 41276,
      "ty": 2,
      "x": 956,
      "y": 652
    },
    {
      "t": 41500,
      "e": 41276,
      "ty": 41,
      "x": 32010,
      "y": 15603,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 41503,
      "e": 41279,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "49"
    },
    {
      "t": 41504,
      "e": 41280,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 41552,
      "e": 41328,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 41601,
      "e": 41377,
      "ty": 2,
      "x": 956,
      "y": 651
    },
    {
      "t": 41616,
      "e": 41392,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 41700,
      "e": 41476,
      "ty": 2,
      "x": 956,
      "y": 662
    },
    {
      "t": 41731,
      "e": 41507,
      "ty": 7,
      "x": 956,
      "y": 668,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 41751,
      "e": 41527,
      "ty": 41,
      "x": 32010,
      "y": 60602,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 41801,
      "e": 41577,
      "ty": 2,
      "x": 956,
      "y": 669
    },
    {
      "t": 41811,
      "e": 41587,
      "ty": 3,
      "x": 956,
      "y": 669,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 41812,
      "e": 41588,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "21"
    },
    {
      "t": 41812,
      "e": 41588,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 41932,
      "e": 41708,
      "ty": 4,
      "x": 32010,
      "y": 60602,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 41932,
      "e": 41708,
      "ty": 5,
      "x": 956,
      "y": 669,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 42099,
      "e": 41875,
      "ty": 6,
      "x": 956,
      "y": 667,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 42100,
      "e": 41876,
      "ty": 2,
      "x": 956,
      "y": 667
    },
    {
      "t": 42201,
      "e": 41977,
      "ty": 2,
      "x": 957,
      "y": 666
    },
    {
      "t": 42228,
      "e": 42004,
      "ty": 3,
      "x": 957,
      "y": 666,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 42228,
      "e": 42004,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 42251,
      "e": 42027,
      "ty": 41,
      "x": 32226,
      "y": 59293,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 42356,
      "e": 42132,
      "ty": 4,
      "x": 32226,
      "y": 59293,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 42356,
      "e": 42132,
      "ty": 5,
      "x": 957,
      "y": 666,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 42465,
      "e": 42241,
      "ty": 7,
      "x": 936,
      "y": 629,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 42501,
      "e": 42277,
      "ty": 2,
      "x": 903,
      "y": 599
    },
    {
      "t": 42501,
      "e": 42277,
      "ty": 41,
      "x": 20547,
      "y": 11274,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 42601,
      "e": 42377,
      "ty": 2,
      "x": 867,
      "y": 580
    },
    {
      "t": 42751,
      "e": 42527,
      "ty": 41,
      "x": 12760,
      "y": 59897,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 42766,
      "e": 42542,
      "ty": 6,
      "x": 869,
      "y": 570,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 42801,
      "e": 42577,
      "ty": 2,
      "x": 871,
      "y": 565
    },
    {
      "t": 42875,
      "e": 42651,
      "ty": 3,
      "x": 876,
      "y": 560,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 42876,
      "e": 42652,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 42876,
      "e": 42652,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 42901,
      "e": 42677,
      "ty": 2,
      "x": 876,
      "y": 560
    },
    {
      "t": 42995,
      "e": 42771,
      "ty": 4,
      "x": 14707,
      "y": 18724,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 42996,
      "e": 42772,
      "ty": 5,
      "x": 876,
      "y": 560,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 43000,
      "e": 42776,
      "ty": 41,
      "x": 14707,
      "y": 18724,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 43100,
      "e": 42876,
      "ty": 2,
      "x": 882,
      "y": 560
    },
    {
      "t": 43251,
      "e": 43027,
      "ty": 41,
      "x": 16005,
      "y": 18724,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 43640,
      "e": 43416,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "8"
    },
    {
      "t": 43719,
      "e": 43495,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 43784,
      "e": 43560,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 43784,
      "e": 43560,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 43888,
      "e": 43664,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "22"
    },
    {
      "t": 44100,
      "e": 43876,
      "ty": 2,
      "x": 887,
      "y": 557
    },
    {
      "t": 44200,
      "e": 43976,
      "ty": 7,
      "x": 873,
      "y": 553,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 44201,
      "e": 43977,
      "ty": 2,
      "x": 873,
      "y": 553
    },
    {
      "t": 44250,
      "e": 44026,
      "ty": 41,
      "x": 20800,
      "y": 32739,
      "ta": "html > body"
    },
    {
      "t": 44300,
      "e": 44076,
      "ty": 2,
      "x": 655,
      "y": 708
    },
    {
      "t": 44399,
      "e": 44175,
      "ty": 2,
      "x": 687,
      "y": 743
    },
    {
      "t": 44500,
      "e": 44276,
      "ty": 2,
      "x": 793,
      "y": 681
    },
    {
      "t": 44500,
      "e": 44276,
      "ty": 41,
      "x": 27033,
      "y": 37282,
      "ta": "html > body"
    },
    {
      "t": 44600,
      "e": 44376,
      "ty": 2,
      "x": 811,
      "y": 668
    },
    {
      "t": 44612,
      "e": 44388,
      "ty": 6,
      "x": 813,
      "y": 667,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 44701,
      "e": 44477,
      "ty": 2,
      "x": 827,
      "y": 661
    },
    {
      "t": 44750,
      "e": 44526,
      "ty": 41,
      "x": 5623,
      "y": 31207,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 44801,
      "e": 44577,
      "ty": 2,
      "x": 835,
      "y": 657
    },
    {
      "t": 44892,
      "e": 44668,
      "ty": 3,
      "x": 835,
      "y": 657,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 44892,
      "e": 44668,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "22"
    },
    {
      "t": 44892,
      "e": 44668,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 44892,
      "e": 44668,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 44988,
      "e": 44764,
      "ty": 4,
      "x": 5839,
      "y": 31207,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 44988,
      "e": 44764,
      "ty": 5,
      "x": 835,
      "y": 657,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 45000,
      "e": 44776,
      "ty": 41,
      "x": 5839,
      "y": 31207,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 45096,
      "e": 44872,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 45567,
      "e": 45343,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 45567,
      "e": 45343,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 45632,
      "e": 45408,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 45680,
      "e": 45456,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 45680,
      "e": 45456,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 45800,
      "e": 45576,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 45800,
      "e": 45576,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 45840,
      "e": 45616,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 45927,
      "e": 45703,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 46176,
      "e": 45952,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 46292,
      "e": 46068,
      "ty": 7,
      "x": 880,
      "y": 668,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 46301,
      "e": 46077,
      "ty": 2,
      "x": 880,
      "y": 668
    },
    {
      "t": 46302,
      "e": 46078,
      "ty": 6,
      "x": 912,
      "y": 682,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 46401,
      "e": 46177,
      "ty": 2,
      "x": 976,
      "y": 696
    },
    {
      "t": 46500,
      "e": 46276,
      "ty": 41,
      "x": 41271,
      "y": 39718,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 46508,
      "e": 46284,
      "ty": 3,
      "x": 976,
      "y": 696,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 46509,
      "e": 46285,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 46509,
      "e": 46285,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 46509,
      "e": 46285,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 46604,
      "e": 46380,
      "ty": 4,
      "x": 41271,
      "y": 39718,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 46604,
      "e": 46380,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 46605,
      "e": 46381,
      "ty": 5,
      "x": 976,
      "y": 696,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 46605,
      "e": 46381,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 47001,
      "e": 46777,
      "ty": 2,
      "x": 980,
      "y": 697
    },
    {
      "t": 47001,
      "e": 46777,
      "ty": 41,
      "x": 33473,
      "y": 38168,
      "ta": "html > body"
    },
    {
      "t": 47101,
      "e": 46877,
      "ty": 2,
      "x": 921,
      "y": 655
    },
    {
      "t": 47201,
      "e": 46977,
      "ty": 2,
      "x": 900,
      "y": 629
    },
    {
      "t": 47251,
      "e": 47027,
      "ty": 41,
      "x": 30339,
      "y": 34180,
      "ta": "html > body"
    },
    {
      "t": 47301,
      "e": 47077,
      "ty": 2,
      "x": 876,
      "y": 620
    },
    {
      "t": 47401,
      "e": 47177,
      "ty": 2,
      "x": 859,
      "y": 613
    },
    {
      "t": 47501,
      "e": 47277,
      "ty": 2,
      "x": 853,
      "y": 605
    },
    {
      "t": 47503,
      "e": 47279,
      "ty": 41,
      "x": 29099,
      "y": 33072,
      "ta": "html > body"
    },
    {
      "t": 47601,
      "e": 47377,
      "ty": 2,
      "x": 851,
      "y": 600
    },
    {
      "t": 47616,
      "e": 47392,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 47751,
      "e": 47527,
      "ty": 41,
      "x": 7019,
      "y": 32804,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 48001,
      "e": 47777,
      "ty": 2,
      "x": 848,
      "y": 593
    },
    {
      "t": 48001,
      "e": 47777,
      "ty": 41,
      "x": 6307,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-1-6"
    },
    {
      "t": 48101,
      "e": 47877,
      "ty": 2,
      "x": 728,
      "y": 241
    },
    {
      "t": 48201,
      "e": 47977,
      "ty": 2,
      "x": 804,
      "y": 193
    },
    {
      "t": 48250,
      "e": 48026,
      "ty": 41,
      "x": 11054,
      "y": 21064,
      "ta": "#jspsych-survey-multi-choice-0 > p"
    },
    {
      "t": 48300,
      "e": 48076,
      "ty": 2,
      "x": 869,
      "y": 188
    },
    {
      "t": 48401,
      "e": 48177,
      "ty": 2,
      "x": 868,
      "y": 246
    },
    {
      "t": 48501,
      "e": 48277,
      "ty": 2,
      "x": 866,
      "y": 251
    },
    {
      "t": 48501,
      "e": 48277,
      "ty": 41,
      "x": 10579,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 48870,
      "e": 48646,
      "ty": 6,
      "x": 839,
      "y": 263,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 48901,
      "e": 48677,
      "ty": 2,
      "x": 839,
      "y": 263
    },
    {
      "t": 49000,
      "e": 48776,
      "ty": 41,
      "x": 63408,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 49227,
      "e": 49003,
      "ty": 7,
      "x": 839,
      "y": 259,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 49251,
      "e": 49027,
      "ty": 41,
      "x": 4171,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-0-1"
    },
    {
      "t": 49300,
      "e": 49076,
      "ty": 2,
      "x": 839,
      "y": 252
    },
    {
      "t": 49419,
      "e": 49195,
      "ty": 3,
      "x": 839,
      "y": 252,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 49492,
      "e": 49268,
      "ty": 4,
      "x": 4171,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 49492,
      "e": 49268,
      "ty": 5,
      "x": 839,
      "y": 250,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 49501,
      "e": 49277,
      "ty": 2,
      "x": 839,
      "y": 250
    },
    {
      "t": 49501,
      "e": 49277,
      "ty": 41,
      "x": 4171,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 49537,
      "e": 49313,
      "ty": 6,
      "x": 839,
      "y": 244,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 49601,
      "e": 49377,
      "ty": 2,
      "x": 839,
      "y": 244
    },
    {
      "t": 49619,
      "e": 49395,
      "ty": 3,
      "x": 839,
      "y": 244,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 49620,
      "e": 49396,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 49731,
      "e": 49507,
      "ty": 4,
      "x": 63408,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 49731,
      "e": 49507,
      "ty": 5,
      "x": 839,
      "y": 244,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 49732,
      "e": 49508,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 49750,
      "e": 49526,
      "ty": 41,
      "x": 63408,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 49800,
      "e": 49576,
      "ty": 2,
      "x": 833,
      "y": 241
    },
    {
      "t": 49901,
      "e": 49677,
      "ty": 2,
      "x": 828,
      "y": 238
    },
    {
      "t": 50001,
      "e": 49777,
      "ty": 41,
      "x": 7955,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 50001,
      "e": 49777,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 50088,
      "e": 49864,
      "ty": 7,
      "x": 829,
      "y": 245,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 50100,
      "e": 49876,
      "ty": 2,
      "x": 829,
      "y": 245
    },
    {
      "t": 50200,
      "e": 49976,
      "ty": 2,
      "x": 881,
      "y": 328
    },
    {
      "t": 50251,
      "e": 50027,
      "ty": 41,
      "x": 17461,
      "y": 14123,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 50300,
      "e": 50076,
      "ty": 2,
      "x": 897,
      "y": 358
    },
    {
      "t": 50400,
      "e": 50176,
      "ty": 2,
      "x": 897,
      "y": 394
    },
    {
      "t": 50500,
      "e": 50276,
      "ty": 41,
      "x": 17936,
      "y": 10561,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 50700,
      "e": 50476,
      "ty": 2,
      "x": 864,
      "y": 420
    },
    {
      "t": 50750,
      "e": 50526,
      "ty": 41,
      "x": 34623,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 50801,
      "e": 50577,
      "ty": 2,
      "x": 843,
      "y": 426
    },
    {
      "t": 50889,
      "e": 50665,
      "ty": 6,
      "x": 836,
      "y": 436,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 50901,
      "e": 50677,
      "ty": 2,
      "x": 836,
      "y": 436
    },
    {
      "t": 50922,
      "e": 50698,
      "ty": 7,
      "x": 832,
      "y": 455,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 50939,
      "e": 50715,
      "ty": 6,
      "x": 830,
      "y": 464,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 50973,
      "e": 50749,
      "ty": 7,
      "x": 827,
      "y": 478,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 51000,
      "e": 50776,
      "ty": 2,
      "x": 826,
      "y": 483
    },
    {
      "t": 51001,
      "e": 50777,
      "ty": 41,
      "x": 1086,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 51100,
      "e": 50876,
      "ty": 2,
      "x": 824,
      "y": 515
    },
    {
      "t": 51201,
      "e": 50977,
      "ty": 2,
      "x": 825,
      "y": 529
    },
    {
      "t": 51251,
      "e": 51027,
      "ty": 41,
      "x": 4187,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 51300,
      "e": 51076,
      "ty": 6,
      "x": 826,
      "y": 529,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 51300,
      "e": 51076,
      "ty": 2,
      "x": 826,
      "y": 529
    },
    {
      "t": 51400,
      "e": 51176,
      "ty": 2,
      "x": 829,
      "y": 529
    },
    {
      "t": 51500,
      "e": 51276,
      "ty": 41,
      "x": 12996,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 51601,
      "e": 51377,
      "ty": 2,
      "x": 831,
      "y": 529
    },
    {
      "t": 51750,
      "e": 51526,
      "ty": 41,
      "x": 23079,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 51873,
      "e": 51649,
      "ty": 7,
      "x": 833,
      "y": 517,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 51900,
      "e": 51676,
      "ty": 2,
      "x": 833,
      "y": 515
    },
    {
      "t": 52000,
      "e": 51776,
      "ty": 2,
      "x": 833,
      "y": 507
    },
    {
      "t": 52000,
      "e": 51776,
      "ty": 41,
      "x": 10391,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 52023,
      "e": 51799,
      "ty": 6,
      "x": 833,
      "y": 504,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 52101,
      "e": 51877,
      "ty": 2,
      "x": 833,
      "y": 500
    },
    {
      "t": 52200,
      "e": 51976,
      "ty": 2,
      "x": 833,
      "y": 496
    },
    {
      "t": 52212,
      "e": 51988,
      "ty": 3,
      "x": 833,
      "y": 496,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 52212,
      "e": 51988,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 52212,
      "e": 51988,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 52251,
      "e": 52027,
      "ty": 41,
      "x": 33161,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 52340,
      "e": 52116,
      "ty": 4,
      "x": 33161,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 52340,
      "e": 52116,
      "ty": 5,
      "x": 833,
      "y": 496,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 52340,
      "e": 52116,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf",
      "v": "Fourth"
    },
    {
      "t": 52523,
      "e": 52299,
      "ty": 7,
      "x": 839,
      "y": 518,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 52601,
      "e": 52377,
      "ty": 2,
      "x": 886,
      "y": 599
    },
    {
      "t": 52701,
      "e": 52477,
      "ty": 2,
      "x": 898,
      "y": 621
    },
    {
      "t": 52751,
      "e": 52527,
      "ty": 41,
      "x": 18885,
      "y": 37448,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 52801,
      "e": 52577,
      "ty": 2,
      "x": 904,
      "y": 659
    },
    {
      "t": 52900,
      "e": 52676,
      "ty": 2,
      "x": 906,
      "y": 689
    },
    {
      "t": 53001,
      "e": 52676,
      "ty": 41,
      "x": 20072,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 53199,
      "e": 52874,
      "ty": 2,
      "x": 895,
      "y": 709
    },
    {
      "t": 53250,
      "e": 52925,
      "ty": 41,
      "x": 4646,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 53275,
      "e": 52950,
      "ty": 6,
      "x": 835,
      "y": 752,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 53300,
      "e": 52975,
      "ty": 2,
      "x": 833,
      "y": 755
    },
    {
      "t": 53324,
      "e": 52999,
      "ty": 7,
      "x": 833,
      "y": 766,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 53400,
      "e": 53075,
      "ty": 2,
      "x": 833,
      "y": 771
    },
    {
      "t": 53500,
      "e": 53175,
      "ty": 2,
      "x": 836,
      "y": 770
    },
    {
      "t": 53500,
      "e": 53175,
      "ty": 41,
      "x": 3459,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 53508,
      "e": 53183,
      "ty": 6,
      "x": 836,
      "y": 764,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 53601,
      "e": 53276,
      "ty": 2,
      "x": 836,
      "y": 760
    },
    {
      "t": 53700,
      "e": 53375,
      "ty": 2,
      "x": 836,
      "y": 759
    },
    {
      "t": 53725,
      "e": 53400,
      "ty": 7,
      "x": 842,
      "y": 766,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 53750,
      "e": 53425,
      "ty": 41,
      "x": 5358,
      "y": 56172,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 53800,
      "e": 53475,
      "ty": 2,
      "x": 845,
      "y": 779
    },
    {
      "t": 53900,
      "e": 53575,
      "ty": 2,
      "x": 845,
      "y": 786
    },
    {
      "t": 53958,
      "e": 53633,
      "ty": 6,
      "x": 837,
      "y": 787,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 54000,
      "e": 53675,
      "ty": 2,
      "x": 835,
      "y": 787
    },
    {
      "t": 54000,
      "e": 53675,
      "ty": 41,
      "x": 43243,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 54332,
      "e": 54007,
      "ty": 3,
      "x": 835,
      "y": 787,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 54332,
      "e": 54007,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 54332,
      "e": 54007,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 54444,
      "e": 54119,
      "ty": 4,
      "x": 43243,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 54444,
      "e": 54119,
      "ty": 5,
      "x": 835,
      "y": 787,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 54444,
      "e": 54119,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf",
      "v": "Engineering"
    },
    {
      "t": 54675,
      "e": 54350,
      "ty": 7,
      "x": 838,
      "y": 808,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 54675,
      "e": 54350,
      "ty": 6,
      "x": 838,
      "y": 808,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 54691,
      "e": 54366,
      "ty": 7,
      "x": 844,
      "y": 831,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 54700,
      "e": 54375,
      "ty": 2,
      "x": 844,
      "y": 831
    },
    {
      "t": 54750,
      "e": 54425,
      "ty": 41,
      "x": 6307,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 54800,
      "e": 54475,
      "ty": 2,
      "x": 850,
      "y": 868
    },
    {
      "t": 54900,
      "e": 54575,
      "ty": 2,
      "x": 853,
      "y": 896
    },
    {
      "t": 55000,
      "e": 54675,
      "ty": 2,
      "x": 857,
      "y": 924
    },
    {
      "t": 55000,
      "e": 54675,
      "ty": 41,
      "x": 8443,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 55100,
      "e": 54775,
      "ty": 2,
      "x": 857,
      "y": 931
    },
    {
      "t": 55200,
      "e": 54875,
      "ty": 2,
      "x": 848,
      "y": 934
    },
    {
      "t": 55250,
      "e": 54925,
      "ty": 41,
      "x": 29029,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 55399,
      "e": 55074,
      "ty": 2,
      "x": 847,
      "y": 934
    },
    {
      "t": 55501,
      "e": 55176,
      "ty": 41,
      "x": 27937,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 55600,
      "e": 55275,
      "ty": 2,
      "x": 844,
      "y": 935
    },
    {
      "t": 55658,
      "e": 55333,
      "ty": 6,
      "x": 839,
      "y": 937,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 55700,
      "e": 55375,
      "ty": 2,
      "x": 835,
      "y": 937
    },
    {
      "t": 55750,
      "e": 55425,
      "ty": 41,
      "x": 43243,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 55868,
      "e": 55543,
      "ty": 3,
      "x": 835,
      "y": 937,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 55868,
      "e": 55543,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 55869,
      "e": 55544,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 55980,
      "e": 55655,
      "ty": 4,
      "x": 43243,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 55980,
      "e": 55655,
      "ty": 5,
      "x": 835,
      "y": 937,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 55980,
      "e": 55655,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf",
      "v": "Male"
    },
    {
      "t": 56131,
      "e": 55806,
      "ty": 7,
      "x": 844,
      "y": 946,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 56200,
      "e": 55875,
      "ty": 2,
      "x": 855,
      "y": 969
    },
    {
      "t": 56250,
      "e": 55875,
      "ty": 41,
      "x": 42268,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-3-2 > label"
    },
    {
      "t": 56276,
      "e": 55901,
      "ty": 6,
      "x": 885,
      "y": 1014,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 56299,
      "e": 55924,
      "ty": 2,
      "x": 890,
      "y": 1020
    },
    {
      "t": 56400,
      "e": 56025,
      "ty": 2,
      "x": 891,
      "y": 1021
    },
    {
      "t": 56452,
      "e": 56077,
      "ty": 3,
      "x": 891,
      "y": 1021,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 56452,
      "e": 56077,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[0]_mf"
    },
    {
      "t": 56452,
      "e": 56077,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 56501,
      "e": 56126,
      "ty": 41,
      "x": 31736,
      "y": 31774,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 56587,
      "e": 56212,
      "ty": 4,
      "x": 31736,
      "y": 31774,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 56587,
      "e": 56212,
      "ty": 5,
      "x": 891,
      "y": 1021,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 56589,
      "e": 56214,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 56590,
      "e": 56215,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 56591,
      "e": 56216,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 57100,
      "e": 56725,
      "ty": 2,
      "x": 861,
      "y": 859
    },
    {
      "t": 57200,
      "e": 56825,
      "ty": 2,
      "x": 696,
      "y": 174
    },
    {
      "t": 57250,
      "e": 56875,
      "ty": 41,
      "x": 20180,
      "y": 0,
      "ta": "html"
    },
    {
      "t": 57300,
      "e": 56925,
      "ty": 2,
      "x": 570,
      "y": 0
    },
    {
      "t": 57400,
      "e": 57025,
      "ty": 2,
      "x": 583,
      "y": 44
    },
    {
      "t": 57500,
      "e": 57125,
      "ty": 2,
      "x": 790,
      "y": 401
    },
    {
      "t": 57500,
      "e": 57125,
      "ty": 41,
      "x": 26930,
      "y": 21771,
      "ta": "html > body"
    },
    {
      "t": 57600,
      "e": 57225,
      "ty": 2,
      "x": 791,
      "y": 402
    },
    {
      "t": 57683,
      "e": 57308,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 57700,
      "e": 57325,
      "ty": 2,
      "x": 679,
      "y": 223
    },
    {
      "t": 57750,
      "e": 57375,
      "ty": 41,
      "x": 18082,
      "y": 4619,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 57801,
      "e": 57426,
      "ty": 2,
      "x": 661,
      "y": 193
    },
    {
      "t": 57903,
      "e": 57528,
      "ty": 2,
      "x": 702,
      "y": 226
    },
    {
      "t": 58004,
      "e": 57629,
      "ty": 2,
      "x": 904,
      "y": 451
    },
    {
      "t": 58004,
      "e": 57629,
      "ty": 41,
      "x": 30037,
      "y": 55014,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 58103,
      "e": 57728,
      "ty": 2,
      "x": 788,
      "y": 554
    },
    {
      "t": 58204,
      "e": 57829,
      "ty": 2,
      "x": 815,
      "y": 1163
    },
    {
      "t": 58303,
      "e": 57928,
      "ty": 2,
      "x": 1001,
      "y": 1199
    },
    {
      "t": 58403,
      "e": 58028,
      "ty": 2,
      "x": 1029,
      "y": 1129
    },
    {
      "t": 58504,
      "e": 58129,
      "ty": 2,
      "x": 1031,
      "y": 1129
    },
    {
      "t": 58504,
      "e": 58129,
      "ty": 41,
      "x": 35229,
      "y": 62100,
      "ta": "> div.masterdiv"
    },
    {
      "t": 58703,
      "e": 58328,
      "ty": 2,
      "x": 1028,
      "y": 1114
    },
    {
      "t": 58732,
      "e": 58357,
      "ty": 6,
      "x": 1023,
      "y": 1106,
      "ta": "#start"
    },
    {
      "t": 58753,
      "e": 58378,
      "ty": 41,
      "x": 61985,
      "y": 62282,
      "ta": "#start"
    },
    {
      "t": 58803,
      "e": 58428,
      "ty": 2,
      "x": 1022,
      "y": 1104
    },
    {
      "t": 58903,
      "e": 58528,
      "ty": 2,
      "x": 1011,
      "y": 1092
    },
    {
      "t": 59003,
      "e": 58628,
      "ty": 2,
      "x": 1010,
      "y": 1090
    },
    {
      "t": 59004,
      "e": 58629,
      "ty": 41,
      "x": 54885,
      "y": 33369,
      "ta": "#start"
    },
    {
      "t": 59056,
      "e": 58681,
      "ty": 3,
      "x": 1010,
      "y": 1090,
      "ta": "#start"
    },
    {
      "t": 59056,
      "e": 58681,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 59603,
      "e": 59228,
      "ty": 2,
      "x": 1010,
      "y": 1089
    },
    {
      "t": 59754,
      "e": 59379,
      "ty": 41,
      "x": 54885,
      "y": 31442,
      "ta": "#start"
    },
    {
      "t": 62904,
      "e": 62529,
      "ty": 2,
      "x": 1005,
      "y": 1089
    },
    {
      "t": 63004,
      "e": 62629,
      "ty": 2,
      "x": 986,
      "y": 1088
    },
    {
      "t": 63004,
      "e": 62629,
      "ty": 41,
      "x": 41778,
      "y": 29514,
      "ta": "#start"
    },
    {
      "t": 63103,
      "e": 62728,
      "ty": 2,
      "x": 985,
      "y": 1088
    },
    {
      "t": 63254,
      "e": 62879,
      "ty": 41,
      "x": 41232,
      "y": 29514,
      "ta": "#start"
    },
    {
      "t": 64447,
      "e": 64072,
      "ty": 4,
      "x": 41232,
      "y": 29514,
      "ta": "#start"
    },
    {
      "t": 64447,
      "e": 64072,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 64447,
      "e": 64072,
      "ty": 5,
      "x": 985,
      "y": 1088,
      "ta": "#start"
    },
    {
      "t": 64448,
      "e": 64073,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 65203,
      "e": 64828,
      "ty": 2,
      "x": 980,
      "y": 1082
    },
    {
      "t": 65254,
      "e": 64879,
      "ty": 41,
      "x": 30201,
      "y": 55175,
      "ta": "html > body"
    },
    {
      "t": 65304,
      "e": 64929,
      "ty": 2,
      "x": 688,
      "y": 771
    },
    {
      "t": 65404,
      "e": 65029,
      "ty": 2,
      "x": 147,
      "y": 95
    },
    {
      "t": 65480,
      "e": 65105,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 66464,
      "e": 66089,
      "ty": 2,
      "x": 662,
      "y": 587
    },
    {
      "t": 66464,
      "e": 66089,
      "ty": 41,
      "x": 22453,
      "y": 32765,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 66533,
      "e": 66158,
      "ty": 2,
      "x": 220,
      "y": 566
    },
    {
      "t": 66534,
      "e": 66159,
      "ty": 41,
      "x": 7129,
      "y": 32761,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 66603,
      "e": 66228,
      "ty": 2,
      "x": 101,
      "y": 599
    },
    {
      "t": 66704,
      "e": 66329,
      "ty": 2,
      "x": 26,
      "y": 613
    },
    {
      "t": 66754,
      "e": 66379,
      "ty": 41,
      "x": 403,
      "y": 32770,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 66903,
      "e": 66528,
      "ty": 2,
      "x": 28,
      "y": 614
    },
    {
      "t": 67003,
      "e": 66628,
      "ty": 2,
      "x": 160,
      "y": 646
    },
    {
      "t": 67003,
      "e": 66628,
      "ty": 41,
      "x": 5048,
      "y": 32776,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 67104,
      "e": 66729,
      "ty": 2,
      "x": 295,
      "y": 670
    },
    {
      "t": 67203,
      "e": 66828,
      "ty": 2,
      "x": 296,
      "y": 670
    },
    {
      "t": 67207,
      "e": 66832,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 119807, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 119813, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"2ZXKM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 3566, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 124752, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"2ZXKM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 7869, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"xray\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"311\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 133628, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"2ZXKM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 3992, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 138710, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"2ZXKM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 8030, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 147744, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"2ZXKM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 52951, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 202105, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"2ZXKM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"C\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-10 AM-02 PM-06 PM-F -H -D -Z -A -F -G -F -F -H -O -K -K -K -D -J -I -O -A -C -U -U -B -B -G \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1007,y:948,t:1527876542940};\\\", \\\"{x:1231,y:978,t:1527876542957};\\\", \\\"{x:1493,y:980,t:1527876542974};\\\", \\\"{x:1728,y:980,t:1527876542990};\\\", \\\"{x:1919,y:980,t:1527876543007};\\\", \\\"{x:1919,y:977,t:1527876543058};\\\", \\\"{x:1919,y:971,t:1527876543073};\\\", \\\"{x:1919,y:970,t:1527876543090};\\\", \\\"{x:1919,y:969,t:1527876543147};\\\", \\\"{x:1913,y:966,t:1527876543157};\\\", \\\"{x:1891,y:958,t:1527876543174};\\\", \\\"{x:1862,y:951,t:1527876543190};\\\", \\\"{x:1832,y:943,t:1527876543206};\\\", \\\"{x:1801,y:929,t:1527876543225};\\\", \\\"{x:1775,y:919,t:1527876543239};\\\", \\\"{x:1753,y:908,t:1527876543257};\\\", \\\"{x:1730,y:898,t:1527876543274};\\\", \\\"{x:1710,y:890,t:1527876543290};\\\", \\\"{x:1677,y:874,t:1527876543307};\\\", \\\"{x:1653,y:864,t:1527876543323};\\\", \\\"{x:1635,y:857,t:1527876543340};\\\", \\\"{x:1617,y:849,t:1527876543357};\\\", \\\"{x:1606,y:844,t:1527876543374};\\\", \\\"{x:1587,y:836,t:1527876543390};\\\", \\\"{x:1563,y:828,t:1527876543407};\\\", \\\"{x:1534,y:817,t:1527876543424};\\\", \\\"{x:1503,y:807,t:1527876543440};\\\", \\\"{x:1479,y:799,t:1527876543456};\\\", \\\"{x:1454,y:789,t:1527876543473};\\\", \\\"{x:1422,y:774,t:1527876543490};\\\", \\\"{x:1401,y:762,t:1527876543507};\\\", \\\"{x:1379,y:750,t:1527876543523};\\\", \\\"{x:1361,y:738,t:1527876543540};\\\", \\\"{x:1340,y:727,t:1527876543556};\\\", \\\"{x:1322,y:716,t:1527876543573};\\\", \\\"{x:1303,y:706,t:1527876543590};\\\", \\\"{x:1291,y:699,t:1527876543606};\\\", \\\"{x:1278,y:692,t:1527876543624};\\\", \\\"{x:1269,y:686,t:1527876543640};\\\", \\\"{x:1261,y:681,t:1527876543658};\\\", \\\"{x:1258,y:679,t:1527876543674};\\\", \\\"{x:1254,y:677,t:1527876543690};\\\", \\\"{x:1246,y:671,t:1527876543707};\\\", \\\"{x:1245,y:670,t:1527876543724};\\\", \\\"{x:1241,y:667,t:1527876543741};\\\", \\\"{x:1240,y:666,t:1527876543757};\\\", \\\"{x:1236,y:662,t:1527876543774};\\\", \\\"{x:1234,y:661,t:1527876543791};\\\", \\\"{x:1233,y:659,t:1527876543807};\\\", \\\"{x:1232,y:657,t:1527876543824};\\\", \\\"{x:1231,y:656,t:1527876543840};\\\", \\\"{x:1229,y:654,t:1527876543857};\\\", \\\"{x:1229,y:653,t:1527876543874};\\\", \\\"{x:1228,y:650,t:1527876543891};\\\", \\\"{x:1227,y:647,t:1527876543907};\\\", \\\"{x:1226,y:646,t:1527876543924};\\\", \\\"{x:1226,y:644,t:1527876543941};\\\", \\\"{x:1226,y:642,t:1527876543957};\\\", \\\"{x:1226,y:640,t:1527876543974};\\\", \\\"{x:1226,y:637,t:1527876543991};\\\", \\\"{x:1226,y:634,t:1527876544007};\\\", \\\"{x:1226,y:629,t:1527876544026};\\\", \\\"{x:1226,y:624,t:1527876544041};\\\", \\\"{x:1227,y:620,t:1527876544058};\\\", \\\"{x:1228,y:617,t:1527876544074};\\\", \\\"{x:1230,y:614,t:1527876544091};\\\", \\\"{x:1231,y:608,t:1527876544108};\\\", \\\"{x:1235,y:603,t:1527876544124};\\\", \\\"{x:1242,y:596,t:1527876544141};\\\", \\\"{x:1248,y:591,t:1527876544158};\\\", \\\"{x:1256,y:586,t:1527876544174};\\\", \\\"{x:1264,y:581,t:1527876544191};\\\", \\\"{x:1269,y:578,t:1527876544208};\\\", \\\"{x:1271,y:576,t:1527876544224};\\\", \\\"{x:1278,y:573,t:1527876544241};\\\", \\\"{x:1289,y:568,t:1527876544258};\\\", \\\"{x:1302,y:562,t:1527876544274};\\\", \\\"{x:1314,y:557,t:1527876544290};\\\", \\\"{x:1324,y:553,t:1527876544308};\\\", \\\"{x:1327,y:551,t:1527876544324};\\\", \\\"{x:1328,y:551,t:1527876544341};\\\", \\\"{x:1329,y:551,t:1527876544363};\\\", \\\"{x:1330,y:551,t:1527876544374};\\\", \\\"{x:1338,y:549,t:1527876544391};\\\", \\\"{x:1353,y:549,t:1527876544408};\\\", \\\"{x:1368,y:549,t:1527876544425};\\\", \\\"{x:1378,y:549,t:1527876544441};\\\", \\\"{x:1380,y:549,t:1527876544458};\\\", \\\"{x:1381,y:549,t:1527876544659};\\\", \\\"{x:1388,y:549,t:1527876544674};\\\", \\\"{x:1405,y:559,t:1527876544691};\\\", \\\"{x:1417,y:565,t:1527876544716};\\\", \\\"{x:1429,y:566,t:1527876544741};\\\", \\\"{x:1440,y:565,t:1527876544757};\\\", \\\"{x:1449,y:560,t:1527876544774};\\\", \\\"{x:1467,y:549,t:1527876544790};\\\", \\\"{x:1487,y:535,t:1527876544807};\\\", \\\"{x:1510,y:521,t:1527876544824};\\\", \\\"{x:1530,y:513,t:1527876544841};\\\", \\\"{x:1557,y:506,t:1527876544858};\\\", \\\"{x:1575,y:503,t:1527876544874};\\\", \\\"{x:1593,y:501,t:1527876544891};\\\", \\\"{x:1601,y:500,t:1527876544907};\\\", \\\"{x:1603,y:499,t:1527876544924};\\\", \\\"{x:1605,y:499,t:1527876544941};\\\", \\\"{x:1606,y:499,t:1527876544957};\\\", \\\"{x:1609,y:497,t:1527876544975};\\\", \\\"{x:1616,y:491,t:1527876544992};\\\", \\\"{x:1623,y:486,t:1527876545007};\\\", \\\"{x:1625,y:484,t:1527876545025};\\\", \\\"{x:1626,y:481,t:1527876545042};\\\", \\\"{x:1626,y:475,t:1527876545058};\\\", \\\"{x:1626,y:465,t:1527876545074};\\\", \\\"{x:1624,y:454,t:1527876545091};\\\", \\\"{x:1617,y:439,t:1527876545108};\\\", \\\"{x:1611,y:428,t:1527876545127};\\\", \\\"{x:1603,y:420,t:1527876545142};\\\", \\\"{x:1597,y:412,t:1527876545158};\\\", \\\"{x:1591,y:409,t:1527876545174};\\\", \\\"{x:1587,y:405,t:1527876545191};\\\", \\\"{x:1579,y:401,t:1527876545208};\\\", \\\"{x:1572,y:397,t:1527876545224};\\\", \\\"{x:1567,y:396,t:1527876545241};\\\", \\\"{x:1562,y:393,t:1527876545258};\\\", \\\"{x:1558,y:392,t:1527876545274};\\\", \\\"{x:1557,y:392,t:1527876545291};\\\", \\\"{x:1556,y:392,t:1527876545308};\\\", \\\"{x:1555,y:392,t:1527876545324};\\\", \\\"{x:1554,y:392,t:1527876545354};\\\", \\\"{x:1554,y:391,t:1527876545468};\\\", \\\"{x:1554,y:390,t:1527876545475};\\\", \\\"{x:1552,y:381,t:1527876545492};\\\", \\\"{x:1551,y:369,t:1527876545509};\\\", \\\"{x:1551,y:358,t:1527876545525};\\\", \\\"{x:1549,y:346,t:1527876545542};\\\", \\\"{x:1549,y:335,t:1527876545560};\\\", \\\"{x:1549,y:327,t:1527876545575};\\\", \\\"{x:1549,y:318,t:1527876545592};\\\", \\\"{x:1549,y:313,t:1527876545609};\\\", \\\"{x:1549,y:307,t:1527876545624};\\\", \\\"{x:1549,y:299,t:1527876545642};\\\", \\\"{x:1549,y:294,t:1527876545658};\\\", \\\"{x:1549,y:289,t:1527876545675};\\\", \\\"{x:1549,y:285,t:1527876545691};\\\", \\\"{x:1549,y:280,t:1527876545709};\\\", \\\"{x:1549,y:277,t:1527876545725};\\\", \\\"{x:1548,y:275,t:1527876545741};\\\", \\\"{x:1548,y:273,t:1527876545759};\\\", \\\"{x:1548,y:269,t:1527876545775};\\\", \\\"{x:1548,y:267,t:1527876545792};\\\", \\\"{x:1548,y:266,t:1527876545809};\\\", \\\"{x:1547,y:264,t:1527876545826};\\\", \\\"{x:1547,y:263,t:1527876545842};\\\", \\\"{x:1546,y:262,t:1527876545866};\\\", \\\"{x:1543,y:273,t:1527876546229};\\\", \\\"{x:1541,y:291,t:1527876546242};\\\", \\\"{x:1538,y:307,t:1527876546258};\\\", \\\"{x:1535,y:323,t:1527876546275};\\\", \\\"{x:1533,y:337,t:1527876546292};\\\", \\\"{x:1533,y:352,t:1527876546309};\\\", \\\"{x:1533,y:367,t:1527876546326};\\\", \\\"{x:1533,y:381,t:1527876546342};\\\", \\\"{x:1533,y:388,t:1527876546359};\\\", \\\"{x:1533,y:393,t:1527876546376};\\\", \\\"{x:1533,y:398,t:1527876546393};\\\", \\\"{x:1533,y:404,t:1527876546409};\\\", \\\"{x:1533,y:413,t:1527876546426};\\\", \\\"{x:1533,y:431,t:1527876546441};\\\", \\\"{x:1533,y:445,t:1527876546458};\\\", \\\"{x:1533,y:454,t:1527876546475};\\\", \\\"{x:1530,y:464,t:1527876546493};\\\", \\\"{x:1529,y:474,t:1527876546509};\\\", \\\"{x:1528,y:488,t:1527876546525};\\\", \\\"{x:1525,y:504,t:1527876546543};\\\", \\\"{x:1523,y:519,t:1527876546559};\\\", \\\"{x:1520,y:536,t:1527876546575};\\\", \\\"{x:1518,y:554,t:1527876546592};\\\", \\\"{x:1515,y:571,t:1527876546609};\\\", \\\"{x:1512,y:594,t:1527876546626};\\\", \\\"{x:1509,y:610,t:1527876546642};\\\", \\\"{x:1508,y:626,t:1527876546659};\\\", \\\"{x:1505,y:645,t:1527876546675};\\\", \\\"{x:1503,y:660,t:1527876546692};\\\", \\\"{x:1502,y:675,t:1527876546708};\\\", \\\"{x:1499,y:689,t:1527876546725};\\\", \\\"{x:1497,y:701,t:1527876546743};\\\", \\\"{x:1493,y:713,t:1527876546759};\\\", \\\"{x:1489,y:723,t:1527876546776};\\\", \\\"{x:1485,y:731,t:1527876546793};\\\", \\\"{x:1481,y:738,t:1527876546810};\\\", \\\"{x:1478,y:744,t:1527876546826};\\\", \\\"{x:1476,y:749,t:1527876546842};\\\", \\\"{x:1474,y:756,t:1527876546859};\\\", \\\"{x:1470,y:761,t:1527876546875};\\\", \\\"{x:1468,y:764,t:1527876546893};\\\", \\\"{x:1467,y:766,t:1527876546910};\\\", \\\"{x:1466,y:767,t:1527876546926};\\\", \\\"{x:1465,y:769,t:1527876546943};\\\", \\\"{x:1464,y:769,t:1527876546960};\\\", \\\"{x:1464,y:770,t:1527876546976};\\\", \\\"{x:1464,y:771,t:1527876546994};\\\", \\\"{x:1463,y:771,t:1527876549812};\\\", \\\"{x:1463,y:788,t:1527876549829};\\\", \\\"{x:1463,y:797,t:1527876549846};\\\", \\\"{x:1462,y:799,t:1527876549862};\\\", \\\"{x:1461,y:807,t:1527876549878};\\\", \\\"{x:1461,y:811,t:1527876549895};\\\", \\\"{x:1459,y:814,t:1527876549913};\\\", \\\"{x:1458,y:820,t:1527876549928};\\\", \\\"{x:1457,y:824,t:1527876549945};\\\", \\\"{x:1456,y:829,t:1527876549963};\\\", \\\"{x:1455,y:833,t:1527876549978};\\\", \\\"{x:1454,y:836,t:1527876549995};\\\", \\\"{x:1453,y:839,t:1527876550012};\\\", \\\"{x:1450,y:843,t:1527876550028};\\\", \\\"{x:1447,y:848,t:1527876550046};\\\", \\\"{x:1446,y:851,t:1527876550063};\\\", \\\"{x:1443,y:855,t:1527876550079};\\\", \\\"{x:1440,y:859,t:1527876550095};\\\", \\\"{x:1439,y:861,t:1527876550113};\\\", \\\"{x:1438,y:864,t:1527876550129};\\\", \\\"{x:1435,y:867,t:1527876550145};\\\", \\\"{x:1432,y:872,t:1527876550162};\\\", \\\"{x:1428,y:877,t:1527876550182};\\\", \\\"{x:1427,y:879,t:1527876550195};\\\", \\\"{x:1425,y:881,t:1527876550212};\\\", \\\"{x:1424,y:883,t:1527876550229};\\\", \\\"{x:1422,y:884,t:1527876550244};\\\", \\\"{x:1421,y:886,t:1527876550262};\\\", \\\"{x:1420,y:887,t:1527876550279};\\\", \\\"{x:1419,y:889,t:1527876550294};\\\", \\\"{x:1418,y:889,t:1527876550311};\\\", \\\"{x:1418,y:890,t:1527876550330};\\\", \\\"{x:1418,y:891,t:1527876550818};\\\", \\\"{x:1418,y:892,t:1527876550829};\\\", \\\"{x:1418,y:893,t:1527876550846};\\\", \\\"{x:1417,y:895,t:1527876550861};\\\", \\\"{x:1416,y:897,t:1527876550878};\\\", \\\"{x:1416,y:898,t:1527876550898};\\\", \\\"{x:1414,y:901,t:1527876550978};\\\", \\\"{x:1414,y:902,t:1527876550996};\\\", \\\"{x:1414,y:903,t:1527876551011};\\\", \\\"{x:1412,y:904,t:1527876551029};\\\", \\\"{x:1411,y:906,t:1527876551046};\\\", \\\"{x:1410,y:907,t:1527876551063};\\\", \\\"{x:1409,y:908,t:1527876551099};\\\", \\\"{x:1407,y:909,t:1527876551187};\\\", \\\"{x:1406,y:909,t:1527876551347};\\\", \\\"{x:1405,y:909,t:1527876551386};\\\", \\\"{x:1404,y:909,t:1527876551403};\\\", \\\"{x:1403,y:909,t:1527876551413};\\\", \\\"{x:1400,y:908,t:1527876551429};\\\", \\\"{x:1399,y:908,t:1527876551446};\\\", \\\"{x:1398,y:907,t:1527876551463};\\\", \\\"{x:1395,y:906,t:1527876551479};\\\", \\\"{x:1391,y:903,t:1527876551496};\\\", \\\"{x:1386,y:903,t:1527876551513};\\\", \\\"{x:1383,y:901,t:1527876551530};\\\", \\\"{x:1379,y:899,t:1527876551546};\\\", \\\"{x:1378,y:899,t:1527876551562};\\\", \\\"{x:1376,y:898,t:1527876551580};\\\", \\\"{x:1373,y:897,t:1527876551595};\\\", \\\"{x:1372,y:896,t:1527876551613};\\\", \\\"{x:1369,y:896,t:1527876551629};\\\", \\\"{x:1368,y:895,t:1527876551646};\\\", \\\"{x:1367,y:895,t:1527876551663};\\\", \\\"{x:1365,y:895,t:1527876551680};\\\", \\\"{x:1362,y:894,t:1527876551696};\\\", \\\"{x:1360,y:894,t:1527876551715};\\\", \\\"{x:1359,y:893,t:1527876551730};\\\", \\\"{x:1357,y:893,t:1527876551763};\\\", \\\"{x:1356,y:893,t:1527876551803};\\\", \\\"{x:1356,y:892,t:1527876551814};\\\", \\\"{x:1354,y:892,t:1527876551843};\\\", \\\"{x:1353,y:892,t:1527876552219};\\\", \\\"{x:1350,y:892,t:1527876552235};\\\", \\\"{x:1348,y:892,t:1527876552247};\\\", \\\"{x:1347,y:892,t:1527876552262};\\\", \\\"{x:1345,y:892,t:1527876552280};\\\", \\\"{x:1344,y:892,t:1527876552297};\\\", \\\"{x:1342,y:892,t:1527876552314};\\\", \\\"{x:1341,y:892,t:1527876552329};\\\", \\\"{x:1340,y:892,t:1527876552354};\\\", \\\"{x:1339,y:892,t:1527876552370};\\\", \\\"{x:1338,y:892,t:1527876552385};\\\", \\\"{x:1337,y:892,t:1527876552441};\\\", \\\"{x:1336,y:892,t:1527876552449};\\\", \\\"{x:1335,y:892,t:1527876552465};\\\", \\\"{x:1334,y:892,t:1527876552506};\\\", \\\"{x:1333,y:892,t:1527876552562};\\\", \\\"{x:1332,y:892,t:1527876552578};\\\", \\\"{x:1331,y:892,t:1527876552611};\\\", \\\"{x:1330,y:892,t:1527876552627};\\\", \\\"{x:1329,y:892,t:1527876552643};\\\", \\\"{x:1328,y:892,t:1527876552659};\\\", \\\"{x:1327,y:892,t:1527876552674};\\\", \\\"{x:1326,y:892,t:1527876552683};\\\", \\\"{x:1325,y:892,t:1527876552698};\\\", \\\"{x:1322,y:892,t:1527876552714};\\\", \\\"{x:1317,y:892,t:1527876552731};\\\", \\\"{x:1312,y:892,t:1527876552748};\\\", \\\"{x:1306,y:892,t:1527876552764};\\\", \\\"{x:1301,y:892,t:1527876552781};\\\", \\\"{x:1297,y:892,t:1527876552797};\\\", \\\"{x:1292,y:892,t:1527876552814};\\\", \\\"{x:1290,y:892,t:1527876552831};\\\", \\\"{x:1285,y:892,t:1527876552848};\\\", \\\"{x:1281,y:889,t:1527876552864};\\\", \\\"{x:1276,y:886,t:1527876552880};\\\", \\\"{x:1270,y:883,t:1527876552898};\\\", \\\"{x:1268,y:882,t:1527876552914};\\\", \\\"{x:1267,y:880,t:1527876552931};\\\", \\\"{x:1266,y:876,t:1527876552948};\\\", \\\"{x:1265,y:875,t:1527876552964};\\\", \\\"{x:1265,y:872,t:1527876552982};\\\", \\\"{x:1265,y:868,t:1527876552998};\\\", \\\"{x:1265,y:865,t:1527876553014};\\\", \\\"{x:1265,y:863,t:1527876553031};\\\", \\\"{x:1266,y:860,t:1527876553048};\\\", \\\"{x:1268,y:856,t:1527876553063};\\\", \\\"{x:1269,y:855,t:1527876553080};\\\", \\\"{x:1272,y:851,t:1527876553098};\\\", \\\"{x:1272,y:850,t:1527876553113};\\\", \\\"{x:1273,y:849,t:1527876553131};\\\", \\\"{x:1274,y:848,t:1527876553148};\\\", \\\"{x:1274,y:847,t:1527876553170};\\\", \\\"{x:1274,y:846,t:1527876553180};\\\", \\\"{x:1274,y:845,t:1527876553198};\\\", \\\"{x:1275,y:845,t:1527876553214};\\\", \\\"{x:1276,y:843,t:1527876553231};\\\", \\\"{x:1277,y:842,t:1527876553248};\\\", \\\"{x:1278,y:840,t:1527876553264};\\\", \\\"{x:1278,y:839,t:1527876553281};\\\", \\\"{x:1279,y:837,t:1527876553306};\\\", \\\"{x:1280,y:835,t:1527876553350};\\\", \\\"{x:1280,y:834,t:1527876553385};\\\", \\\"{x:1281,y:833,t:1527876553397};\\\", \\\"{x:1281,y:832,t:1527876553465};\\\", \\\"{x:1290,y:828,t:1527876557613};\\\", \\\"{x:1321,y:816,t:1527876557635};\\\", \\\"{x:1341,y:811,t:1527876557650};\\\", \\\"{x:1362,y:805,t:1527876557668};\\\", \\\"{x:1378,y:800,t:1527876557685};\\\", \\\"{x:1387,y:797,t:1527876557701};\\\", \\\"{x:1391,y:795,t:1527876557718};\\\", \\\"{x:1394,y:793,t:1527876557735};\\\", \\\"{x:1398,y:791,t:1527876557751};\\\", \\\"{x:1399,y:790,t:1527876557768};\\\", \\\"{x:1399,y:789,t:1527876557963};\\\", \\\"{x:1399,y:786,t:1527876557971};\\\", \\\"{x:1399,y:785,t:1527876557986};\\\", \\\"{x:1399,y:783,t:1527876558002};\\\", \\\"{x:1397,y:780,t:1527876558018};\\\", \\\"{x:1396,y:779,t:1527876558035};\\\", \\\"{x:1396,y:778,t:1527876558052};\\\", \\\"{x:1395,y:777,t:1527876558068};\\\", \\\"{x:1395,y:776,t:1527876558091};\\\", \\\"{x:1394,y:776,t:1527876558283};\\\", \\\"{x:1392,y:774,t:1527876558291};\\\", \\\"{x:1391,y:773,t:1527876558307};\\\", \\\"{x:1391,y:771,t:1527876558318};\\\", \\\"{x:1390,y:769,t:1527876558336};\\\", \\\"{x:1390,y:768,t:1527876558352};\\\", \\\"{x:1389,y:766,t:1527876558368};\\\", \\\"{x:1389,y:763,t:1527876558386};\\\", \\\"{x:1388,y:761,t:1527876558403};\\\", \\\"{x:1387,y:760,t:1527876558434};\\\", \\\"{x:1386,y:760,t:1527876558735};\\\", \\\"{x:1385,y:760,t:1527876558849};\\\", \\\"{x:1384,y:760,t:1527876558889};\\\", \\\"{x:1383,y:760,t:1527876558930};\\\", \\\"{x:1379,y:760,t:1527876563258};\\\", \\\"{x:1376,y:761,t:1527876563273};\\\", \\\"{x:1370,y:770,t:1527876563292};\\\", \\\"{x:1368,y:774,t:1527876563305};\\\", \\\"{x:1364,y:781,t:1527876563322};\\\", \\\"{x:1362,y:784,t:1527876563339};\\\", \\\"{x:1361,y:788,t:1527876563356};\\\", \\\"{x:1360,y:792,t:1527876563372};\\\", \\\"{x:1358,y:797,t:1527876563389};\\\", \\\"{x:1357,y:803,t:1527876563406};\\\", \\\"{x:1357,y:808,t:1527876563422};\\\", \\\"{x:1356,y:814,t:1527876563439};\\\", \\\"{x:1355,y:820,t:1527876563456};\\\", \\\"{x:1355,y:827,t:1527876563472};\\\", \\\"{x:1355,y:834,t:1527876563490};\\\", \\\"{x:1355,y:839,t:1527876563505};\\\", \\\"{x:1354,y:845,t:1527876563522};\\\", \\\"{x:1353,y:850,t:1527876563539};\\\", \\\"{x:1351,y:854,t:1527876563556};\\\", \\\"{x:1350,y:860,t:1527876563572};\\\", \\\"{x:1348,y:862,t:1527876563589};\\\", \\\"{x:1347,y:862,t:1527876563606};\\\", \\\"{x:1346,y:864,t:1527876563623};\\\", \\\"{x:1345,y:864,t:1527876563650};\\\", \\\"{x:1344,y:864,t:1527876563666};\\\", \\\"{x:1344,y:865,t:1527876563674};\\\", \\\"{x:1342,y:865,t:1527876563690};\\\", \\\"{x:1341,y:865,t:1527876563722};\\\", \\\"{x:1340,y:865,t:1527876563899};\\\", \\\"{x:1338,y:864,t:1527876563907};\\\", \\\"{x:1338,y:863,t:1527876563924};\\\", \\\"{x:1336,y:860,t:1527876563940};\\\", \\\"{x:1334,y:857,t:1527876563956};\\\", \\\"{x:1331,y:853,t:1527876563973};\\\", \\\"{x:1330,y:851,t:1527876563989};\\\", \\\"{x:1328,y:849,t:1527876564006};\\\", \\\"{x:1323,y:845,t:1527876564023};\\\", \\\"{x:1314,y:840,t:1527876564039};\\\", \\\"{x:1294,y:829,t:1527876564056};\\\", \\\"{x:1254,y:825,t:1527876564073};\\\", \\\"{x:1226,y:825,t:1527876564090};\\\", \\\"{x:1193,y:824,t:1527876564106};\\\", \\\"{x:1145,y:816,t:1527876564123};\\\", \\\"{x:1069,y:800,t:1527876564139};\\\", \\\"{x:981,y:777,t:1527876564156};\\\", \\\"{x:881,y:749,t:1527876564173};\\\", \\\"{x:767,y:716,t:1527876564190};\\\", \\\"{x:640,y:678,t:1527876564208};\\\", \\\"{x:501,y:637,t:1527876564223};\\\", \\\"{x:383,y:603,t:1527876564240};\\\", \\\"{x:259,y:572,t:1527876564257};\\\", \\\"{x:105,y:540,t:1527876564273};\\\", \\\"{x:11,y:525,t:1527876564289};\\\", \\\"{x:0,y:513,t:1527876564305};\\\", \\\"{x:0,y:508,t:1527876564323};\\\", \\\"{x:0,y:506,t:1527876564361};\\\", \\\"{x:2,y:506,t:1527876564441};\\\", \\\"{x:10,y:508,t:1527876564456};\\\", \\\"{x:35,y:519,t:1527876564473};\\\", \\\"{x:61,y:531,t:1527876564489};\\\", \\\"{x:110,y:550,t:1527876564507};\\\", \\\"{x:169,y:567,t:1527876564523};\\\", \\\"{x:219,y:583,t:1527876564540};\\\", \\\"{x:246,y:591,t:1527876564557};\\\", \\\"{x:276,y:605,t:1527876564574};\\\", \\\"{x:324,y:627,t:1527876564591};\\\", \\\"{x:361,y:645,t:1527876564607};\\\", \\\"{x:378,y:653,t:1527876564623};\\\", \\\"{x:388,y:658,t:1527876564641};\\\", \\\"{x:394,y:660,t:1527876564657};\\\", \\\"{x:396,y:660,t:1527876564673};\\\", \\\"{x:400,y:660,t:1527876564690};\\\", \\\"{x:407,y:660,t:1527876564707};\\\", \\\"{x:415,y:654,t:1527876564724};\\\", \\\"{x:420,y:646,t:1527876564740};\\\", \\\"{x:423,y:634,t:1527876564757};\\\", \\\"{x:423,y:622,t:1527876564773};\\\", \\\"{x:423,y:616,t:1527876564791};\\\", \\\"{x:423,y:614,t:1527876564807};\\\", \\\"{x:423,y:613,t:1527876564823};\\\", \\\"{x:420,y:607,t:1527876564840};\\\", \\\"{x:417,y:603,t:1527876564857};\\\", \\\"{x:416,y:602,t:1527876564874};\\\", \\\"{x:415,y:602,t:1527876564929};\\\", \\\"{x:413,y:602,t:1527876564940};\\\", \\\"{x:411,y:602,t:1527876564957};\\\", \\\"{x:410,y:602,t:1527876564973};\\\", \\\"{x:409,y:602,t:1527876564990};\\\", \\\"{x:406,y:602,t:1527876565007};\\\", \\\"{x:416,y:602,t:1527876567514};\\\", \\\"{x:462,y:609,t:1527876567527};\\\", \\\"{x:598,y:630,t:1527876567543};\\\", \\\"{x:761,y:652,t:1527876567559};\\\", \\\"{x:1147,y:702,t:1527876567593};\\\", \\\"{x:1388,y:744,t:1527876567609};\\\", \\\"{x:1520,y:782,t:1527876567626};\\\", \\\"{x:1614,y:808,t:1527876567642};\\\", \\\"{x:1649,y:820,t:1527876567659};\\\", \\\"{x:1657,y:823,t:1527876567676};\\\", \\\"{x:1658,y:823,t:1527876567867};\\\", \\\"{x:1662,y:817,t:1527876567877};\\\", \\\"{x:1664,y:808,t:1527876567893};\\\", \\\"{x:1667,y:799,t:1527876567910};\\\", \\\"{x:1667,y:792,t:1527876567927};\\\", \\\"{x:1667,y:788,t:1527876567943};\\\", \\\"{x:1667,y:785,t:1527876567960};\\\", \\\"{x:1667,y:783,t:1527876567977};\\\", \\\"{x:1667,y:782,t:1527876567994};\\\", \\\"{x:1667,y:781,t:1527876568018};\\\", \\\"{x:1667,y:780,t:1527876568026};\\\", \\\"{x:1667,y:778,t:1527876568043};\\\", \\\"{x:1667,y:775,t:1527876568059};\\\", \\\"{x:1666,y:771,t:1527876568076};\\\", \\\"{x:1663,y:768,t:1527876568093};\\\", \\\"{x:1660,y:768,t:1527876568109};\\\", \\\"{x:1660,y:767,t:1527876568126};\\\", \\\"{x:1659,y:767,t:1527876568143};\\\", \\\"{x:1658,y:767,t:1527876568162};\\\", \\\"{x:1657,y:767,t:1527876568434};\\\", \\\"{x:1655,y:767,t:1527876568450};\\\", \\\"{x:1654,y:766,t:1527876568482};\\\", \\\"{x:1652,y:766,t:1527876568575};\\\", \\\"{x:1651,y:765,t:1527876568625};\\\", \\\"{x:1650,y:765,t:1527876571473};\\\", \\\"{x:1644,y:766,t:1527876571485};\\\", \\\"{x:1623,y:767,t:1527876571503};\\\", \\\"{x:1605,y:767,t:1527876571518};\\\", \\\"{x:1579,y:767,t:1527876571535};\\\", \\\"{x:1544,y:767,t:1527876571545};\\\", \\\"{x:1512,y:767,t:1527876571563};\\\", \\\"{x:1486,y:767,t:1527876571579};\\\", \\\"{x:1467,y:767,t:1527876571595};\\\", \\\"{x:1454,y:767,t:1527876571612};\\\", \\\"{x:1448,y:768,t:1527876571633};\\\", \\\"{x:1444,y:770,t:1527876571649};\\\", \\\"{x:1441,y:771,t:1527876571667};\\\", \\\"{x:1438,y:772,t:1527876571683};\\\", \\\"{x:1434,y:773,t:1527876571699};\\\", \\\"{x:1430,y:774,t:1527876571716};\\\", \\\"{x:1423,y:776,t:1527876571733};\\\", \\\"{x:1415,y:777,t:1527876571749};\\\", \\\"{x:1411,y:778,t:1527876571767};\\\", \\\"{x:1408,y:778,t:1527876571784};\\\", \\\"{x:1407,y:778,t:1527876571800};\\\", \\\"{x:1405,y:779,t:1527876571817};\\\", \\\"{x:1403,y:779,t:1527876571834};\\\", \\\"{x:1401,y:779,t:1527876571851};\\\", \\\"{x:1398,y:779,t:1527876571867};\\\", \\\"{x:1396,y:779,t:1527876571884};\\\", \\\"{x:1395,y:779,t:1527876571935};\\\", \\\"{x:1392,y:779,t:1527876571950};\\\", \\\"{x:1391,y:779,t:1527876571968};\\\", \\\"{x:1390,y:779,t:1527876572047};\\\", \\\"{x:1389,y:779,t:1527876572078};\\\", \\\"{x:1388,y:778,t:1527876572094};\\\", \\\"{x:1386,y:778,t:1527876572102};\\\", \\\"{x:1386,y:777,t:1527876572117};\\\", \\\"{x:1383,y:777,t:1527876572134};\\\", \\\"{x:1381,y:775,t:1527876572159};\\\", \\\"{x:1380,y:775,t:1527876572174};\\\", \\\"{x:1379,y:775,t:1527876572223};\\\", \\\"{x:1379,y:774,t:1527876572238};\\\", \\\"{x:1377,y:773,t:1527876572251};\\\", \\\"{x:1376,y:773,t:1527876572383};\\\", \\\"{x:1376,y:772,t:1527876572479};\\\", \\\"{x:1376,y:771,t:1527876572486};\\\", \\\"{x:1376,y:770,t:1527876572502};\\\", \\\"{x:1376,y:769,t:1527876572518};\\\", \\\"{x:1375,y:768,t:1527876572534};\\\", \\\"{x:1375,y:766,t:1527876572791};\\\", \\\"{x:1376,y:766,t:1527876572850};\\\", \\\"{x:1376,y:765,t:1527876572949};\\\", \\\"{x:1377,y:765,t:1527876572965};\\\", \\\"{x:1378,y:765,t:1527876573005};\\\", \\\"{x:1379,y:765,t:1527876573021};\\\", \\\"{x:1380,y:764,t:1527876574573};\\\", \\\"{x:1380,y:752,t:1527876574586};\\\", \\\"{x:1380,y:727,t:1527876574601};\\\", \\\"{x:1382,y:718,t:1527876574619};\\\", \\\"{x:1384,y:703,t:1527876574635};\\\", \\\"{x:1384,y:685,t:1527876574652};\\\", \\\"{x:1384,y:671,t:1527876574668};\\\", \\\"{x:1384,y:653,t:1527876574686};\\\", \\\"{x:1386,y:644,t:1527876574703};\\\", \\\"{x:1389,y:633,t:1527876574718};\\\", \\\"{x:1389,y:627,t:1527876574735};\\\", \\\"{x:1390,y:621,t:1527876574752};\\\", \\\"{x:1392,y:617,t:1527876574769};\\\", \\\"{x:1392,y:616,t:1527876574786};\\\", \\\"{x:1392,y:615,t:1527876574806};\\\", \\\"{x:1392,y:612,t:1527876574854};\\\", \\\"{x:1393,y:609,t:1527876574869};\\\", \\\"{x:1394,y:605,t:1527876574886};\\\", \\\"{x:1396,y:599,t:1527876574903};\\\", \\\"{x:1401,y:591,t:1527876574918};\\\", \\\"{x:1405,y:581,t:1527876574935};\\\", \\\"{x:1409,y:575,t:1527876574953};\\\", \\\"{x:1411,y:571,t:1527876574970};\\\", \\\"{x:1412,y:569,t:1527876574986};\\\", \\\"{x:1413,y:568,t:1527876575004};\\\", \\\"{x:1413,y:567,t:1527876575959};\\\", \\\"{x:1412,y:567,t:1527876575970};\\\", \\\"{x:1405,y:567,t:1527876575989};\\\", \\\"{x:1397,y:568,t:1527876576004};\\\", \\\"{x:1390,y:568,t:1527876576020};\\\", \\\"{x:1386,y:568,t:1527876576036};\\\", \\\"{x:1382,y:568,t:1527876576053};\\\", \\\"{x:1381,y:568,t:1527876576093};\\\", \\\"{x:1380,y:568,t:1527876576109};\\\", \\\"{x:1379,y:568,t:1527876576119};\\\", \\\"{x:1374,y:568,t:1527876576136};\\\", \\\"{x:1371,y:568,t:1527876576154};\\\", \\\"{x:1365,y:568,t:1527876576170};\\\", \\\"{x:1355,y:571,t:1527876576186};\\\", \\\"{x:1338,y:582,t:1527876576204};\\\", \\\"{x:1319,y:603,t:1527876576220};\\\", \\\"{x:1294,y:637,t:1527876576237};\\\", \\\"{x:1266,y:679,t:1527876576253};\\\", \\\"{x:1257,y:692,t:1527876576271};\\\", \\\"{x:1255,y:696,t:1527876576287};\\\", \\\"{x:1257,y:694,t:1527876576422};\\\", \\\"{x:1265,y:685,t:1527876576437};\\\", \\\"{x:1291,y:655,t:1527876576453};\\\", \\\"{x:1297,y:645,t:1527876576471};\\\", \\\"{x:1301,y:637,t:1527876576486};\\\", \\\"{x:1304,y:630,t:1527876576504};\\\", \\\"{x:1305,y:629,t:1527876576521};\\\", \\\"{x:1306,y:627,t:1527876576536};\\\", \\\"{x:1306,y:626,t:1527876576573};\\\", \\\"{x:1308,y:626,t:1527876576767};\\\", \\\"{x:1310,y:627,t:1527876576778};\\\", \\\"{x:1313,y:627,t:1527876576787};\\\", \\\"{x:1315,y:629,t:1527876576803};\\\", \\\"{x:1316,y:629,t:1527876577406};\\\", \\\"{x:1327,y:628,t:1527876577424};\\\", \\\"{x:1341,y:621,t:1527876577438};\\\", \\\"{x:1357,y:617,t:1527876577454};\\\", \\\"{x:1374,y:615,t:1527876577471};\\\", \\\"{x:1386,y:613,t:1527876577488};\\\", \\\"{x:1390,y:613,t:1527876577505};\\\", \\\"{x:1392,y:613,t:1527876577520};\\\", \\\"{x:1394,y:613,t:1527876577537};\\\", \\\"{x:1398,y:613,t:1527876577554};\\\", \\\"{x:1404,y:612,t:1527876577571};\\\", \\\"{x:1411,y:612,t:1527876577587};\\\", \\\"{x:1420,y:612,t:1527876577605};\\\", \\\"{x:1438,y:611,t:1527876577621};\\\", \\\"{x:1450,y:609,t:1527876577638};\\\", \\\"{x:1459,y:608,t:1527876577655};\\\", \\\"{x:1466,y:607,t:1527876577672};\\\", \\\"{x:1473,y:606,t:1527876577688};\\\", \\\"{x:1482,y:603,t:1527876577705};\\\", \\\"{x:1491,y:603,t:1527876577722};\\\", \\\"{x:1499,y:602,t:1527876577738};\\\", \\\"{x:1504,y:602,t:1527876577755};\\\", \\\"{x:1507,y:602,t:1527876577772};\\\", \\\"{x:1508,y:602,t:1527876577788};\\\", \\\"{x:1510,y:602,t:1527876577805};\\\", \\\"{x:1512,y:602,t:1527876577822};\\\", \\\"{x:1514,y:602,t:1527876577838};\\\", \\\"{x:1515,y:602,t:1527876577855};\\\", \\\"{x:1517,y:602,t:1527876577872};\\\", \\\"{x:1519,y:602,t:1527876577888};\\\", \\\"{x:1520,y:602,t:1527876577906};\\\", \\\"{x:1520,y:604,t:1527876577922};\\\", \\\"{x:1520,y:611,t:1527876577938};\\\", \\\"{x:1520,y:615,t:1527876577955};\\\", \\\"{x:1520,y:619,t:1527876577972};\\\", \\\"{x:1519,y:620,t:1527876577988};\\\", \\\"{x:1519,y:622,t:1527876578005};\\\", \\\"{x:1518,y:624,t:1527876578271};\\\", \\\"{x:1514,y:625,t:1527876578291};\\\", \\\"{x:1510,y:627,t:1527876578305};\\\", \\\"{x:1506,y:628,t:1527876578323};\\\", \\\"{x:1504,y:629,t:1527876578338};\\\", \\\"{x:1502,y:630,t:1527876578354};\\\", \\\"{x:1500,y:630,t:1527876578373};\\\", \\\"{x:1499,y:630,t:1527876578470};\\\", \\\"{x:1498,y:630,t:1527876578551};\\\", \\\"{x:1495,y:627,t:1527876578558};\\\", \\\"{x:1494,y:624,t:1527876578572};\\\", \\\"{x:1490,y:615,t:1527876578590};\\\", \\\"{x:1488,y:609,t:1527876578606};\\\", \\\"{x:1488,y:608,t:1527876578623};\\\", \\\"{x:1488,y:610,t:1527876578735};\\\", \\\"{x:1488,y:611,t:1527876578742};\\\", \\\"{x:1490,y:613,t:1527876578756};\\\", \\\"{x:1493,y:618,t:1527876578773};\\\", \\\"{x:1496,y:621,t:1527876578789};\\\", \\\"{x:1499,y:626,t:1527876578806};\\\", \\\"{x:1499,y:627,t:1527876578822};\\\", \\\"{x:1499,y:628,t:1527876579039};\\\", \\\"{x:1501,y:630,t:1527876579056};\\\", \\\"{x:1502,y:630,t:1527876579073};\\\", \\\"{x:1503,y:630,t:1527876579094};\\\", \\\"{x:1504,y:630,t:1527876579118};\\\", \\\"{x:1505,y:630,t:1527876579423};\\\", \\\"{x:1507,y:630,t:1527876579446};\\\", \\\"{x:1508,y:630,t:1527876579462};\\\", \\\"{x:1509,y:630,t:1527876579482};\\\", \\\"{x:1510,y:630,t:1527876579505};\\\", \\\"{x:1511,y:630,t:1527876579597};\\\", \\\"{x:1511,y:628,t:1527876579661};\\\", \\\"{x:1511,y:626,t:1527876579672};\\\", \\\"{x:1510,y:624,t:1527876579691};\\\", \\\"{x:1510,y:622,t:1527876579708};\\\", \\\"{x:1514,y:619,t:1527876580094};\\\", \\\"{x:1521,y:614,t:1527876580108};\\\", \\\"{x:1529,y:604,t:1527876580123};\\\", \\\"{x:1536,y:594,t:1527876580140};\\\", \\\"{x:1544,y:574,t:1527876580157};\\\", \\\"{x:1546,y:567,t:1527876580173};\\\", \\\"{x:1555,y:545,t:1527876580191};\\\", \\\"{x:1558,y:528,t:1527876580207};\\\", \\\"{x:1560,y:514,t:1527876580223};\\\", \\\"{x:1561,y:503,t:1527876580240};\\\", \\\"{x:1561,y:490,t:1527876580257};\\\", \\\"{x:1561,y:485,t:1527876580275};\\\", \\\"{x:1562,y:477,t:1527876580290};\\\", \\\"{x:1562,y:470,t:1527876580307};\\\", \\\"{x:1564,y:467,t:1527876580324};\\\", \\\"{x:1564,y:461,t:1527876580340};\\\", \\\"{x:1565,y:459,t:1527876580358};\\\", \\\"{x:1573,y:453,t:1527876580374};\\\", \\\"{x:1583,y:452,t:1527876580391};\\\", \\\"{x:1586,y:450,t:1527876580407};\\\", \\\"{x:1590,y:449,t:1527876580425};\\\", \\\"{x:1595,y:448,t:1527876580441};\\\", \\\"{x:1600,y:447,t:1527876580458};\\\", \\\"{x:1601,y:447,t:1527876580518};\\\", \\\"{x:1602,y:446,t:1527876580526};\\\", \\\"{x:1603,y:446,t:1527876580540};\\\", \\\"{x:1604,y:446,t:1527876580557};\\\", \\\"{x:1606,y:445,t:1527876580574};\\\", \\\"{x:1608,y:444,t:1527876580598};\\\", \\\"{x:1609,y:443,t:1527876580623};\\\", \\\"{x:1610,y:443,t:1527876580638};\\\", \\\"{x:1611,y:443,t:1527876580646};\\\", \\\"{x:1612,y:442,t:1527876580658};\\\", \\\"{x:1613,y:441,t:1527876580674};\\\", \\\"{x:1614,y:440,t:1527876580691};\\\", \\\"{x:1615,y:440,t:1527876580707};\\\", \\\"{x:1615,y:439,t:1527876580725};\\\", \\\"{x:1616,y:438,t:1527876580742};\\\", \\\"{x:1617,y:437,t:1527876580758};\\\", \\\"{x:1618,y:436,t:1527876580790};\\\", \\\"{x:1618,y:435,t:1527876580830};\\\", \\\"{x:1618,y:434,t:1527876580857};\\\", \\\"{x:1618,y:433,t:1527876580873};\\\", \\\"{x:1619,y:432,t:1527876580890};\\\", \\\"{x:1619,y:431,t:1527876580917};\\\", \\\"{x:1619,y:430,t:1527876580949};\\\", \\\"{x:1619,y:429,t:1527876580997};\\\", \\\"{x:1619,y:428,t:1527876581086};\\\", \\\"{x:1618,y:428,t:1527876581838};\\\", \\\"{x:1615,y:428,t:1527876581845};\\\", \\\"{x:1613,y:428,t:1527876581859};\\\", \\\"{x:1608,y:430,t:1527876581878};\\\", \\\"{x:1598,y:433,t:1527876581891};\\\", \\\"{x:1581,y:435,t:1527876581907};\\\", \\\"{x:1548,y:441,t:1527876581925};\\\", \\\"{x:1530,y:444,t:1527876581941};\\\", \\\"{x:1514,y:446,t:1527876581957};\\\", \\\"{x:1504,y:448,t:1527876581975};\\\", \\\"{x:1499,y:449,t:1527876581991};\\\", \\\"{x:1495,y:449,t:1527876582008};\\\", \\\"{x:1492,y:449,t:1527876582025};\\\", \\\"{x:1486,y:449,t:1527876582042};\\\", \\\"{x:1474,y:449,t:1527876582058};\\\", \\\"{x:1464,y:447,t:1527876582075};\\\", \\\"{x:1453,y:446,t:1527876582092};\\\", \\\"{x:1444,y:446,t:1527876582108};\\\", \\\"{x:1441,y:445,t:1527876582125};\\\", \\\"{x:1437,y:444,t:1527876582141};\\\", \\\"{x:1436,y:444,t:1527876582158};\\\", \\\"{x:1433,y:443,t:1527876582175};\\\", \\\"{x:1426,y:443,t:1527876582192};\\\", \\\"{x:1419,y:440,t:1527876582210};\\\", \\\"{x:1418,y:440,t:1527876582225};\\\", \\\"{x:1417,y:439,t:1527876582241};\\\", \\\"{x:1416,y:439,t:1527876582260};\\\", \\\"{x:1415,y:439,t:1527876582274};\\\", \\\"{x:1415,y:438,t:1527876582317};\\\", \\\"{x:1415,y:437,t:1527876582349};\\\", \\\"{x:1415,y:436,t:1527876582360};\\\", \\\"{x:1414,y:436,t:1527876582375};\\\", \\\"{x:1414,y:435,t:1527876582393};\\\", \\\"{x:1414,y:434,t:1527876582409};\\\", \\\"{x:1414,y:433,t:1527876582425};\\\", \\\"{x:1414,y:431,t:1527876582441};\\\", \\\"{x:1412,y:430,t:1527876583133};\\\", \\\"{x:1410,y:431,t:1527876583142};\\\", \\\"{x:1406,y:435,t:1527876583160};\\\", \\\"{x:1399,y:445,t:1527876583176};\\\", \\\"{x:1388,y:459,t:1527876583192};\\\", \\\"{x:1381,y:473,t:1527876583208};\\\", \\\"{x:1377,y:478,t:1527876583226};\\\", \\\"{x:1375,y:481,t:1527876583242};\\\", \\\"{x:1373,y:482,t:1527876583258};\\\", \\\"{x:1372,y:483,t:1527876583276};\\\", \\\"{x:1369,y:484,t:1527876583293};\\\", \\\"{x:1365,y:486,t:1527876583309};\\\", \\\"{x:1362,y:487,t:1527876583326};\\\", \\\"{x:1357,y:488,t:1527876583342};\\\", \\\"{x:1354,y:488,t:1527876583359};\\\", \\\"{x:1347,y:488,t:1527876583376};\\\", \\\"{x:1340,y:488,t:1527876583393};\\\", \\\"{x:1334,y:488,t:1527876583409};\\\", \\\"{x:1331,y:488,t:1527876583427};\\\", \\\"{x:1328,y:488,t:1527876583443};\\\", \\\"{x:1324,y:490,t:1527876583459};\\\", \\\"{x:1319,y:492,t:1527876583476};\\\", \\\"{x:1312,y:494,t:1527876583496};\\\", \\\"{x:1311,y:495,t:1527876583525};\\\", \\\"{x:1309,y:496,t:1527876583543};\\\", \\\"{x:1309,y:497,t:1527876583901};\\\", \\\"{x:1309,y:501,t:1527876583911};\\\", \\\"{x:1309,y:509,t:1527876583926};\\\", \\\"{x:1309,y:519,t:1527876583943};\\\", \\\"{x:1309,y:529,t:1527876583960};\\\", \\\"{x:1309,y:537,t:1527876583975};\\\", \\\"{x:1309,y:545,t:1527876583992};\\\", \\\"{x:1309,y:553,t:1527876584010};\\\", \\\"{x:1309,y:563,t:1527876584027};\\\", \\\"{x:1309,y:571,t:1527876584043};\\\", \\\"{x:1309,y:578,t:1527876584060};\\\", \\\"{x:1308,y:583,t:1527876584076};\\\", \\\"{x:1306,y:588,t:1527876584093};\\\", \\\"{x:1305,y:590,t:1527876584110};\\\", \\\"{x:1305,y:591,t:1527876584134};\\\", \\\"{x:1305,y:592,t:1527876584144};\\\", \\\"{x:1304,y:594,t:1527876584160};\\\", \\\"{x:1304,y:596,t:1527876584178};\\\", \\\"{x:1304,y:599,t:1527876584193};\\\", \\\"{x:1304,y:602,t:1527876584210};\\\", \\\"{x:1304,y:605,t:1527876584228};\\\", \\\"{x:1304,y:609,t:1527876584244};\\\", \\\"{x:1304,y:613,t:1527876584260};\\\", \\\"{x:1305,y:617,t:1527876584278};\\\", \\\"{x:1306,y:619,t:1527876584293};\\\", \\\"{x:1306,y:620,t:1527876584310};\\\", \\\"{x:1307,y:622,t:1527876584328};\\\", \\\"{x:1308,y:624,t:1527876584343};\\\", \\\"{x:1309,y:624,t:1527876584360};\\\", \\\"{x:1309,y:625,t:1527876584378};\\\", \\\"{x:1310,y:626,t:1527876584397};\\\", \\\"{x:1312,y:630,t:1527876584410};\\\", \\\"{x:1313,y:631,t:1527876584427};\\\", \\\"{x:1313,y:632,t:1527876584444};\\\", \\\"{x:1313,y:633,t:1527876584460};\\\", \\\"{x:1314,y:634,t:1527876584525};\\\", \\\"{x:1314,y:635,t:1527876584727};\\\", \\\"{x:1314,y:643,t:1527876584747};\\\", \\\"{x:1314,y:653,t:1527876584760};\\\", \\\"{x:1314,y:668,t:1527876584776};\\\", \\\"{x:1314,y:687,t:1527876584793};\\\", \\\"{x:1314,y:704,t:1527876584810};\\\", \\\"{x:1314,y:719,t:1527876584826};\\\", \\\"{x:1316,y:730,t:1527876584843};\\\", \\\"{x:1317,y:743,t:1527876584860};\\\", \\\"{x:1319,y:757,t:1527876584877};\\\", \\\"{x:1319,y:767,t:1527876584894};\\\", \\\"{x:1322,y:781,t:1527876584910};\\\", \\\"{x:1322,y:786,t:1527876584927};\\\", \\\"{x:1322,y:789,t:1527876584944};\\\", \\\"{x:1322,y:792,t:1527876584960};\\\", \\\"{x:1322,y:793,t:1527876584997};\\\", \\\"{x:1322,y:794,t:1527876585013};\\\", \\\"{x:1322,y:795,t:1527876585027};\\\", \\\"{x:1322,y:796,t:1527876585045};\\\", \\\"{x:1320,y:797,t:1527876585061};\\\", \\\"{x:1315,y:799,t:1527876585077};\\\", \\\"{x:1312,y:801,t:1527876585094};\\\", \\\"{x:1307,y:802,t:1527876585111};\\\", \\\"{x:1304,y:802,t:1527876585127};\\\", \\\"{x:1302,y:803,t:1527876585144};\\\", \\\"{x:1300,y:804,t:1527876585161};\\\", \\\"{x:1299,y:805,t:1527876585178};\\\", \\\"{x:1297,y:806,t:1527876585194};\\\", \\\"{x:1297,y:807,t:1527876585222};\\\", \\\"{x:1296,y:809,t:1527876585238};\\\", \\\"{x:1296,y:810,t:1527876585246};\\\", \\\"{x:1295,y:813,t:1527876585262};\\\", \\\"{x:1294,y:814,t:1527876585278};\\\", \\\"{x:1294,y:817,t:1527876585295};\\\", \\\"{x:1293,y:818,t:1527876585422};\\\", \\\"{x:1292,y:819,t:1527876585438};\\\", \\\"{x:1292,y:820,t:1527876585446};\\\", \\\"{x:1291,y:820,t:1527876585460};\\\", \\\"{x:1291,y:821,t:1527876585478};\\\", \\\"{x:1290,y:822,t:1527876585493};\\\", \\\"{x:1289,y:823,t:1527876585549};\\\", \\\"{x:1289,y:824,t:1527876585565};\\\", \\\"{x:1288,y:825,t:1527876585581};\\\", \\\"{x:1287,y:827,t:1527876585613};\\\", \\\"{x:1287,y:828,t:1527876585654};\\\", \\\"{x:1287,y:829,t:1527876585670};\\\", \\\"{x:1286,y:830,t:1527876585681};\\\", \\\"{x:1285,y:832,t:1527876585694};\\\", \\\"{x:1285,y:833,t:1527876585717};\\\", \\\"{x:1284,y:833,t:1527876585728};\\\", \\\"{x:1284,y:834,t:1527876585750};\\\", \\\"{x:1284,y:835,t:1527876585768};\\\", \\\"{x:1284,y:836,t:1527876585778};\\\", \\\"{x:1283,y:837,t:1527876585926};\\\", \\\"{x:1279,y:838,t:1527876585933};\\\", \\\"{x:1273,y:841,t:1527876585945};\\\", \\\"{x:1256,y:846,t:1527876585961};\\\", \\\"{x:1235,y:853,t:1527876585978};\\\", \\\"{x:1217,y:858,t:1527876585995};\\\", \\\"{x:1208,y:862,t:1527876586011};\\\", \\\"{x:1205,y:863,t:1527876586028};\\\", \\\"{x:1204,y:863,t:1527876586158};\\\", \\\"{x:1202,y:863,t:1527876586165};\\\", \\\"{x:1198,y:863,t:1527876586178};\\\", \\\"{x:1194,y:863,t:1527876586195};\\\", \\\"{x:1193,y:863,t:1527876586211};\\\", \\\"{x:1192,y:861,t:1527876586229};\\\", \\\"{x:1191,y:858,t:1527876586245};\\\", \\\"{x:1190,y:854,t:1527876586261};\\\", \\\"{x:1190,y:851,t:1527876586278};\\\", \\\"{x:1190,y:849,t:1527876586295};\\\", \\\"{x:1190,y:848,t:1527876586312};\\\", \\\"{x:1190,y:846,t:1527876586327};\\\", \\\"{x:1191,y:845,t:1527876586345};\\\", \\\"{x:1194,y:844,t:1527876586362};\\\", \\\"{x:1196,y:844,t:1527876586378};\\\", \\\"{x:1198,y:842,t:1527876586395};\\\", \\\"{x:1199,y:842,t:1527876586437};\\\", \\\"{x:1200,y:842,t:1527876586445};\\\", \\\"{x:1201,y:841,t:1527876586462};\\\", \\\"{x:1202,y:841,t:1527876586478};\\\", \\\"{x:1203,y:841,t:1527876586606};\\\", \\\"{x:1203,y:840,t:1527876586614};\\\", \\\"{x:1204,y:839,t:1527876586628};\\\", \\\"{x:1205,y:838,t:1527876586646};\\\", \\\"{x:1206,y:836,t:1527876586662};\\\", \\\"{x:1208,y:833,t:1527876586679};\\\", \\\"{x:1209,y:832,t:1527876586700};\\\", \\\"{x:1210,y:831,t:1527876586711};\\\", \\\"{x:1210,y:830,t:1527876586728};\\\", \\\"{x:1211,y:830,t:1527876586829};\\\", \\\"{x:1194,y:830,t:1527876587550};\\\", \\\"{x:1159,y:821,t:1527876587561};\\\", \\\"{x:1054,y:792,t:1527876587579};\\\", \\\"{x:935,y:757,t:1527876587596};\\\", \\\"{x:793,y:711,t:1527876587612};\\\", \\\"{x:551,y:628,t:1527876587630};\\\", \\\"{x:380,y:576,t:1527876587648};\\\", \\\"{x:213,y:515,t:1527876587662};\\\", \\\"{x:69,y:476,t:1527876587679};\\\", \\\"{x:0,y:449,t:1527876587695};\\\", \\\"{x:0,y:433,t:1527876587713};\\\", \\\"{x:0,y:431,t:1527876587729};\\\", \\\"{x:0,y:430,t:1527876587745};\\\", \\\"{x:2,y:430,t:1527876587813};\\\", \\\"{x:26,y:441,t:1527876587830};\\\", \\\"{x:79,y:477,t:1527876587846};\\\", \\\"{x:168,y:540,t:1527876587863};\\\", \\\"{x:265,y:611,t:1527876587879};\\\", \\\"{x:336,y:650,t:1527876587896};\\\", \\\"{x:380,y:678,t:1527876587914};\\\", \\\"{x:422,y:713,t:1527876587930};\\\", \\\"{x:469,y:759,t:1527876587946};\\\", \\\"{x:510,y:806,t:1527876587963};\\\", \\\"{x:525,y:820,t:1527876587979};\\\", \\\"{x:527,y:822,t:1527876587995};\\\", \\\"{x:527,y:815,t:1527876588029};\\\", \\\"{x:527,y:804,t:1527876588037};\\\", \\\"{x:523,y:791,t:1527876588046};\\\", \\\"{x:517,y:772,t:1527876588063};\\\", \\\"{x:508,y:754,t:1527876588080};\\\", \\\"{x:496,y:742,t:1527876588096};\\\", \\\"{x:482,y:733,t:1527876588113};\\\", \\\"{x:472,y:729,t:1527876588130};\\\", \\\"{x:462,y:728,t:1527876588146};\\\", \\\"{x:444,y:722,t:1527876588163};\\\", \\\"{x:416,y:718,t:1527876588180};\\\", \\\"{x:384,y:709,t:1527876588196};\\\", \\\"{x:325,y:676,t:1527876588214};\\\", \\\"{x:298,y:658,t:1527876588230};\\\", \\\"{x:283,y:645,t:1527876588247};\\\", \\\"{x:276,y:636,t:1527876588262};\\\", \\\"{x:274,y:632,t:1527876588280};\\\", \\\"{x:271,y:628,t:1527876588297};\\\", \\\"{x:270,y:626,t:1527876588313};\\\", \\\"{x:268,y:624,t:1527876588330};\\\", \\\"{x:265,y:620,t:1527876588346};\\\", \\\"{x:253,y:610,t:1527876588363};\\\", \\\"{x:227,y:596,t:1527876588379};\\\", \\\"{x:204,y:587,t:1527876588396};\\\", \\\"{x:198,y:586,t:1527876588413};\\\", \\\"{x:197,y:586,t:1527876588430};\\\", \\\"{x:194,y:586,t:1527876588447};\\\", \\\"{x:188,y:586,t:1527876588464};\\\", \\\"{x:180,y:585,t:1527876588480};\\\", \\\"{x:178,y:584,t:1527876588497};\\\", \\\"{x:176,y:583,t:1527876588513};\\\", \\\"{x:175,y:582,t:1527876588531};\\\", \\\"{x:173,y:581,t:1527876588547};\\\", \\\"{x:172,y:580,t:1527876588565};\\\", \\\"{x:171,y:580,t:1527876588580};\\\", \\\"{x:170,y:579,t:1527876588598};\\\", \\\"{x:170,y:576,t:1527876588613};\\\", \\\"{x:169,y:574,t:1527876588630};\\\", \\\"{x:169,y:569,t:1527876588647};\\\", \\\"{x:169,y:567,t:1527876588663};\\\", \\\"{x:169,y:564,t:1527876588680};\\\", \\\"{x:170,y:560,t:1527876588697};\\\", \\\"{x:172,y:556,t:1527876588713};\\\", \\\"{x:174,y:553,t:1527876588730};\\\", \\\"{x:175,y:550,t:1527876588746};\\\", \\\"{x:177,y:547,t:1527876588763};\\\", \\\"{x:178,y:547,t:1527876589077};\\\", \\\"{x:181,y:547,t:1527876589085};\\\", \\\"{x:188,y:547,t:1527876589097};\\\", \\\"{x:204,y:549,t:1527876589114};\\\", \\\"{x:229,y:555,t:1527876589130};\\\", \\\"{x:296,y:576,t:1527876589147};\\\", \\\"{x:426,y:610,t:1527876589164};\\\", \\\"{x:583,y:654,t:1527876589181};\\\", \\\"{x:896,y:726,t:1527876589197};\\\", \\\"{x:1113,y:768,t:1527876589214};\\\", \\\"{x:1317,y:821,t:1527876589230};\\\", \\\"{x:1496,y:873,t:1527876589247};\\\", \\\"{x:1634,y:908,t:1527876589265};\\\", \\\"{x:1720,y:934,t:1527876589281};\\\", \\\"{x:1746,y:942,t:1527876589297};\\\", \\\"{x:1747,y:942,t:1527876589314};\\\", \\\"{x:1748,y:942,t:1527876589350};\\\", \\\"{x:1748,y:939,t:1527876589364};\\\", \\\"{x:1744,y:936,t:1527876589381};\\\", \\\"{x:1736,y:932,t:1527876589398};\\\", \\\"{x:1713,y:924,t:1527876589414};\\\", \\\"{x:1677,y:909,t:1527876589431};\\\", \\\"{x:1635,y:898,t:1527876589447};\\\", \\\"{x:1604,y:889,t:1527876589464};\\\", \\\"{x:1576,y:883,t:1527876589481};\\\", \\\"{x:1544,y:877,t:1527876589497};\\\", \\\"{x:1508,y:873,t:1527876589514};\\\", \\\"{x:1479,y:869,t:1527876589531};\\\", \\\"{x:1456,y:865,t:1527876589547};\\\", \\\"{x:1435,y:863,t:1527876589564};\\\", \\\"{x:1414,y:859,t:1527876589581};\\\", \\\"{x:1411,y:858,t:1527876589597};\\\", \\\"{x:1411,y:857,t:1527876589750};\\\", \\\"{x:1414,y:856,t:1527876589765};\\\", \\\"{x:1428,y:850,t:1527876589782};\\\", \\\"{x:1444,y:847,t:1527876589798};\\\", \\\"{x:1462,y:839,t:1527876589814};\\\", \\\"{x:1481,y:830,t:1527876589836};\\\", \\\"{x:1493,y:824,t:1527876589849};\\\", \\\"{x:1498,y:822,t:1527876589864};\\\", \\\"{x:1503,y:820,t:1527876589881};\\\", \\\"{x:1506,y:820,t:1527876589898};\\\", \\\"{x:1503,y:820,t:1527876590070};\\\", \\\"{x:1499,y:821,t:1527876590081};\\\", \\\"{x:1491,y:824,t:1527876590098};\\\", \\\"{x:1487,y:825,t:1527876590115};\\\", \\\"{x:1485,y:826,t:1527876590134};\\\", \\\"{x:1482,y:828,t:1527876590148};\\\", \\\"{x:1479,y:828,t:1527876590164};\\\", \\\"{x:1485,y:827,t:1527876591758};\\\", \\\"{x:1501,y:820,t:1527876591768};\\\", \\\"{x:1541,y:806,t:1527876591782};\\\", \\\"{x:1576,y:794,t:1527876591799};\\\", \\\"{x:1613,y:789,t:1527876591815};\\\", \\\"{x:1639,y:786,t:1527876591832};\\\", \\\"{x:1657,y:783,t:1527876591849};\\\", \\\"{x:1667,y:783,t:1527876591866};\\\", \\\"{x:1673,y:783,t:1527876591882};\\\", \\\"{x:1676,y:783,t:1527876591899};\\\", \\\"{x:1682,y:783,t:1527876591916};\\\", \\\"{x:1688,y:785,t:1527876591932};\\\", \\\"{x:1702,y:791,t:1527876591949};\\\", \\\"{x:1711,y:795,t:1527876591966};\\\", \\\"{x:1713,y:797,t:1527876591982};\\\", \\\"{x:1713,y:798,t:1527876591999};\\\", \\\"{x:1713,y:804,t:1527876592017};\\\", \\\"{x:1713,y:812,t:1527876592034};\\\", \\\"{x:1710,y:821,t:1527876592050};\\\", \\\"{x:1704,y:830,t:1527876592067};\\\", \\\"{x:1701,y:832,t:1527876592084};\\\", \\\"{x:1698,y:833,t:1527876592099};\\\", \\\"{x:1697,y:834,t:1527876592116};\\\", \\\"{x:1694,y:835,t:1527876592133};\\\", \\\"{x:1692,y:835,t:1527876592149};\\\", \\\"{x:1690,y:837,t:1527876592166};\\\", \\\"{x:1687,y:837,t:1527876592183};\\\", \\\"{x:1686,y:837,t:1527876592199};\\\", \\\"{x:1684,y:837,t:1527876592216};\\\", \\\"{x:1683,y:836,t:1527876592233};\\\", \\\"{x:1681,y:836,t:1527876592249};\\\", \\\"{x:1680,y:835,t:1527876592279};\\\", \\\"{x:1680,y:832,t:1527876592598};\\\", \\\"{x:1679,y:830,t:1527876592605};\\\", \\\"{x:1679,y:827,t:1527876592616};\\\", \\\"{x:1676,y:818,t:1527876592635};\\\", \\\"{x:1675,y:810,t:1527876592650};\\\", \\\"{x:1674,y:804,t:1527876592666};\\\", \\\"{x:1672,y:802,t:1527876592683};\\\", \\\"{x:1672,y:801,t:1527876592918};\\\", \\\"{x:1667,y:795,t:1527876592933};\\\", \\\"{x:1662,y:790,t:1527876592950};\\\", \\\"{x:1659,y:786,t:1527876592967};\\\", \\\"{x:1658,y:784,t:1527876592983};\\\", \\\"{x:1657,y:782,t:1527876593000};\\\", \\\"{x:1656,y:781,t:1527876593018};\\\", \\\"{x:1656,y:780,t:1527876593135};\\\", \\\"{x:1656,y:777,t:1527876593206};\\\", \\\"{x:1656,y:776,t:1527876593218};\\\", \\\"{x:1654,y:772,t:1527876593233};\\\", \\\"{x:1653,y:770,t:1527876593251};\\\", \\\"{x:1651,y:766,t:1527876593269};\\\", \\\"{x:1650,y:764,t:1527876593284};\\\", \\\"{x:1649,y:762,t:1527876593300};\\\", \\\"{x:1646,y:762,t:1527876593702};\\\", \\\"{x:1538,y:770,t:1527876593734};\\\", \\\"{x:1443,y:787,t:1527876593751};\\\", \\\"{x:1344,y:809,t:1527876593767};\\\", \\\"{x:1217,y:847,t:1527876593784};\\\", \\\"{x:1088,y:875,t:1527876593801};\\\", \\\"{x:966,y:893,t:1527876593817};\\\", \\\"{x:845,y:904,t:1527876593834};\\\", \\\"{x:719,y:912,t:1527876593851};\\\", \\\"{x:612,y:922,t:1527876593867};\\\", \\\"{x:528,y:935,t:1527876593884};\\\", \\\"{x:448,y:947,t:1527876593901};\\\", \\\"{x:427,y:951,t:1527876593917};\\\", \\\"{x:426,y:952,t:1527876593934};\\\", \\\"{x:425,y:953,t:1527876593951};\\\", \\\"{x:423,y:953,t:1527876593968};\\\", \\\"{x:422,y:955,t:1527876593984};\\\", \\\"{x:420,y:956,t:1527876594002};\\\", \\\"{x:419,y:957,t:1527876594017};\\\", \\\"{x:420,y:957,t:1527876594070};\\\", \\\"{x:430,y:957,t:1527876594085};\\\", \\\"{x:457,y:946,t:1527876594101};\\\", \\\"{x:464,y:940,t:1527876594118};\\\", \\\"{x:469,y:933,t:1527876594134};\\\", \\\"{x:476,y:924,t:1527876594152};\\\", \\\"{x:481,y:914,t:1527876594169};\\\", \\\"{x:484,y:900,t:1527876594185};\\\", \\\"{x:487,y:883,t:1527876594202};\\\", \\\"{x:490,y:864,t:1527876594218};\\\", \\\"{x:491,y:846,t:1527876594235};\\\", \\\"{x:491,y:827,t:1527876594252};\\\", \\\"{x:491,y:813,t:1527876594268};\\\", \\\"{x:490,y:800,t:1527876594284};\\\", \\\"{x:488,y:783,t:1527876594301};\\\", \\\"{x:488,y:779,t:1527876594318};\\\", \\\"{x:488,y:777,t:1527876594334};\\\", \\\"{x:488,y:776,t:1527876594486};\\\", \\\"{x:495,y:771,t:1527876594503};\\\", \\\"{x:505,y:765,t:1527876594518};\\\", \\\"{x:512,y:761,t:1527876594534};\\\", \\\"{x:516,y:756,t:1527876594551};\\\", \\\"{x:521,y:751,t:1527876594568};\\\", \\\"{x:523,y:749,t:1527876594585};\\\", \\\"{x:524,y:748,t:1527876594600};\\\", \\\"{x:524,y:747,t:1527876594618};\\\", \\\"{x:529,y:744,t:1527876595134};\\\", \\\"{x:541,y:736,t:1527876595141};\\\", \\\"{x:556,y:729,t:1527876595152};\\\", \\\"{x:576,y:716,t:1527876595168};\\\", \\\"{x:595,y:704,t:1527876595185};\\\", \\\"{x:616,y:685,t:1527876595203};\\\", \\\"{x:646,y:661,t:1527876595219};\\\", \\\"{x:708,y:617,t:1527876595239};\\\", \\\"{x:720,y:610,t:1527876595252};\\\", \\\"{x:739,y:599,t:1527876595268};\\\", \\\"{x:779,y:575,t:1527876595285};\\\", \\\"{x:800,y:563,t:1527876595302};\\\", \\\"{x:809,y:557,t:1527876595318};\\\", \\\"{x:812,y:555,t:1527876595335};\\\", \\\"{x:813,y:554,t:1527876595372};\\\", \\\"{x:813,y:553,t:1527876595385};\\\", \\\"{x:813,y:552,t:1527876595402};\\\", \\\"{x:813,y:551,t:1527876595420};\\\", \\\"{x:813,y:550,t:1527876595435};\\\" ] }, { \\\"rt\\\": 44865, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 248186, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"2ZXKM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-D -D -D -X -D -D -E -K -K -2-C -A -Z -Z -F -U -B -B -G -G -G -K -K -E -E -E -E -H -O -I -I -J -D -D -X \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:812,y:550,t:1527876596532};\\\", \\\"{x:810,y:550,t:1527876596540};\\\", \\\"{x:808,y:550,t:1527876596557};\\\", \\\"{x:805,y:551,t:1527876596749};\\\", \\\"{x:804,y:553,t:1527876596757};\\\", \\\"{x:803,y:555,t:1527876596772};\\\", \\\"{x:802,y:556,t:1527876596789};\\\", \\\"{x:801,y:558,t:1527876596803};\\\", \\\"{x:800,y:559,t:1527876596820};\\\", \\\"{x:798,y:561,t:1527876596836};\\\", \\\"{x:797,y:563,t:1527876596853};\\\", \\\"{x:797,y:564,t:1527876597165};\\\", \\\"{x:804,y:567,t:1527876597174};\\\", \\\"{x:816,y:573,t:1527876597189};\\\", \\\"{x:857,y:590,t:1527876597204};\\\", \\\"{x:922,y:613,t:1527876597221};\\\", \\\"{x:1039,y:648,t:1527876597236};\\\", \\\"{x:1094,y:661,t:1527876597253};\\\", \\\"{x:1133,y:672,t:1527876597270};\\\", \\\"{x:1186,y:688,t:1527876597287};\\\", \\\"{x:1232,y:696,t:1527876597303};\\\", \\\"{x:1255,y:700,t:1527876597320};\\\", \\\"{x:1269,y:702,t:1527876597337};\\\", \\\"{x:1276,y:702,t:1527876597353};\\\", \\\"{x:1279,y:703,t:1527876597370};\\\", \\\"{x:1280,y:703,t:1527876597387};\\\", \\\"{x:1281,y:704,t:1527876597403};\\\", \\\"{x:1283,y:704,t:1527876597589};\\\", \\\"{x:1284,y:703,t:1527876597621};\\\", \\\"{x:1285,y:703,t:1527876597653};\\\", \\\"{x:1286,y:703,t:1527876597661};\\\", \\\"{x:1287,y:703,t:1527876597685};\\\", \\\"{x:1289,y:703,t:1527876597701};\\\", \\\"{x:1290,y:703,t:1527876597733};\\\", \\\"{x:1292,y:703,t:1527876597782};\\\", \\\"{x:1293,y:703,t:1527876598093};\\\", \\\"{x:1295,y:703,t:1527876598104};\\\", \\\"{x:1297,y:703,t:1527876598122};\\\", \\\"{x:1303,y:703,t:1527876598138};\\\", \\\"{x:1312,y:705,t:1527876598155};\\\", \\\"{x:1327,y:710,t:1527876598172};\\\", \\\"{x:1346,y:715,t:1527876598188};\\\", \\\"{x:1380,y:724,t:1527876598205};\\\", \\\"{x:1401,y:731,t:1527876598222};\\\", \\\"{x:1422,y:738,t:1527876598237};\\\", \\\"{x:1442,y:744,t:1527876598254};\\\", \\\"{x:1460,y:749,t:1527876598272};\\\", \\\"{x:1472,y:754,t:1527876598288};\\\", \\\"{x:1486,y:760,t:1527876598304};\\\", \\\"{x:1496,y:765,t:1527876598322};\\\", \\\"{x:1502,y:768,t:1527876598338};\\\", \\\"{x:1504,y:768,t:1527876598355};\\\", \\\"{x:1504,y:769,t:1527876598372};\\\", \\\"{x:1503,y:769,t:1527876598493};\\\", \\\"{x:1498,y:769,t:1527876598504};\\\", \\\"{x:1487,y:767,t:1527876598521};\\\", \\\"{x:1477,y:766,t:1527876598538};\\\", \\\"{x:1470,y:765,t:1527876598554};\\\", \\\"{x:1467,y:765,t:1527876598571};\\\", \\\"{x:1465,y:764,t:1527876598588};\\\", \\\"{x:1463,y:763,t:1527876598604};\\\", \\\"{x:1461,y:762,t:1527876598798};\\\", \\\"{x:1457,y:758,t:1527876598805};\\\", \\\"{x:1450,y:743,t:1527876598822};\\\", \\\"{x:1442,y:724,t:1527876598839};\\\", \\\"{x:1436,y:701,t:1527876598855};\\\", \\\"{x:1424,y:677,t:1527876598872};\\\", \\\"{x:1419,y:659,t:1527876598889};\\\", \\\"{x:1418,y:644,t:1527876598905};\\\", \\\"{x:1417,y:624,t:1527876598921};\\\", \\\"{x:1414,y:614,t:1527876598938};\\\", \\\"{x:1414,y:612,t:1527876598955};\\\", \\\"{x:1414,y:611,t:1527876598971};\\\", \\\"{x:1411,y:609,t:1527876598988};\\\", \\\"{x:1408,y:608,t:1527876599004};\\\", \\\"{x:1405,y:608,t:1527876599021};\\\", \\\"{x:1401,y:608,t:1527876599038};\\\", \\\"{x:1388,y:615,t:1527876599055};\\\", \\\"{x:1358,y:631,t:1527876599072};\\\", \\\"{x:1331,y:651,t:1527876599088};\\\", \\\"{x:1315,y:676,t:1527876599105};\\\", \\\"{x:1307,y:702,t:1527876599121};\\\", \\\"{x:1301,y:730,t:1527876599138};\\\", \\\"{x:1299,y:757,t:1527876599155};\\\", \\\"{x:1299,y:784,t:1527876599171};\\\", \\\"{x:1299,y:817,t:1527876599189};\\\", \\\"{x:1299,y:848,t:1527876599205};\\\", \\\"{x:1295,y:882,t:1527876599222};\\\", \\\"{x:1290,y:909,t:1527876599239};\\\", \\\"{x:1290,y:924,t:1527876599255};\\\", \\\"{x:1290,y:929,t:1527876599271};\\\", \\\"{x:1290,y:924,t:1527876599341};\\\", \\\"{x:1290,y:919,t:1527876599355};\\\", \\\"{x:1290,y:910,t:1527876599372};\\\", \\\"{x:1290,y:901,t:1527876599389};\\\", \\\"{x:1295,y:882,t:1527876599406};\\\", \\\"{x:1303,y:866,t:1527876599422};\\\", \\\"{x:1314,y:847,t:1527876599439};\\\", \\\"{x:1331,y:823,t:1527876599455};\\\", \\\"{x:1350,y:802,t:1527876599472};\\\", \\\"{x:1371,y:786,t:1527876599488};\\\", \\\"{x:1392,y:778,t:1527876599505};\\\", \\\"{x:1419,y:769,t:1527876599522};\\\", \\\"{x:1440,y:765,t:1527876599538};\\\", \\\"{x:1454,y:765,t:1527876599555};\\\", \\\"{x:1463,y:765,t:1527876599572};\\\", \\\"{x:1469,y:765,t:1527876599588};\\\", \\\"{x:1473,y:765,t:1527876599605};\\\", \\\"{x:1476,y:765,t:1527876599622};\\\", \\\"{x:1482,y:765,t:1527876599638};\\\", \\\"{x:1487,y:765,t:1527876599655};\\\", \\\"{x:1490,y:765,t:1527876599672};\\\", \\\"{x:1495,y:765,t:1527876599688};\\\", \\\"{x:1498,y:765,t:1527876599705};\\\", \\\"{x:1503,y:764,t:1527876599722};\\\", \\\"{x:1506,y:763,t:1527876599738};\\\", \\\"{x:1514,y:762,t:1527876599755};\\\", \\\"{x:1531,y:759,t:1527876599772};\\\", \\\"{x:1539,y:757,t:1527876599788};\\\", \\\"{x:1548,y:754,t:1527876599805};\\\", \\\"{x:1559,y:747,t:1527876599823};\\\", \\\"{x:1563,y:742,t:1527876599838};\\\", \\\"{x:1566,y:736,t:1527876599855};\\\", \\\"{x:1566,y:729,t:1527876599873};\\\", \\\"{x:1566,y:718,t:1527876599888};\\\", \\\"{x:1566,y:707,t:1527876599905};\\\", \\\"{x:1566,y:698,t:1527876599923};\\\", \\\"{x:1565,y:692,t:1527876599938};\\\", \\\"{x:1563,y:684,t:1527876599956};\\\", \\\"{x:1562,y:680,t:1527876599972};\\\", \\\"{x:1562,y:678,t:1527876599990};\\\", \\\"{x:1562,y:675,t:1527876600006};\\\", \\\"{x:1562,y:671,t:1527876600190};\\\", \\\"{x:1569,y:652,t:1527876600206};\\\", \\\"{x:1574,y:626,t:1527876600222};\\\", \\\"{x:1579,y:601,t:1527876600239};\\\", \\\"{x:1583,y:574,t:1527876600255};\\\", \\\"{x:1589,y:546,t:1527876600273};\\\", \\\"{x:1596,y:530,t:1527876600290};\\\", \\\"{x:1601,y:521,t:1527876600305};\\\", \\\"{x:1607,y:510,t:1527876600322};\\\", \\\"{x:1610,y:505,t:1527876600339};\\\", \\\"{x:1610,y:502,t:1527876600355};\\\", \\\"{x:1610,y:496,t:1527876600372};\\\", \\\"{x:1610,y:491,t:1527876600390};\\\", \\\"{x:1610,y:487,t:1527876600406};\\\", \\\"{x:1609,y:482,t:1527876600423};\\\", \\\"{x:1608,y:477,t:1527876600439};\\\", \\\"{x:1607,y:470,t:1527876600457};\\\", \\\"{x:1604,y:464,t:1527876600473};\\\", \\\"{x:1603,y:457,t:1527876600489};\\\", \\\"{x:1599,y:451,t:1527876600507};\\\", \\\"{x:1599,y:445,t:1527876600522};\\\", \\\"{x:1597,y:440,t:1527876600540};\\\", \\\"{x:1597,y:434,t:1527876600556};\\\", \\\"{x:1597,y:431,t:1527876600573};\\\", \\\"{x:1597,y:429,t:1527876600590};\\\", \\\"{x:1597,y:426,t:1527876600607};\\\", \\\"{x:1597,y:422,t:1527876600623};\\\", \\\"{x:1597,y:419,t:1527876600639};\\\", \\\"{x:1598,y:414,t:1527876600657};\\\", \\\"{x:1600,y:412,t:1527876600673};\\\", \\\"{x:1602,y:411,t:1527876600690};\\\", \\\"{x:1604,y:411,t:1527876600706};\\\", \\\"{x:1607,y:411,t:1527876600722};\\\", \\\"{x:1609,y:411,t:1527876600741};\\\", \\\"{x:1611,y:413,t:1527876600757};\\\", \\\"{x:1613,y:417,t:1527876600773};\\\", \\\"{x:1614,y:422,t:1527876600789};\\\", \\\"{x:1614,y:426,t:1527876600815};\\\", \\\"{x:1615,y:433,t:1527876600839};\\\", \\\"{x:1615,y:435,t:1527876600856};\\\", \\\"{x:1617,y:438,t:1527876600870};\\\", \\\"{x:1616,y:438,t:1527876601278};\\\", \\\"{x:1616,y:436,t:1527876601566};\\\", \\\"{x:1616,y:435,t:1527876601593};\\\", \\\"{x:1615,y:434,t:1527876602733};\\\", \\\"{x:1614,y:434,t:1527876602744};\\\", \\\"{x:1611,y:435,t:1527876602763};\\\", \\\"{x:1608,y:436,t:1527876602777};\\\", \\\"{x:1600,y:439,t:1527876602791};\\\", \\\"{x:1592,y:439,t:1527876602808};\\\", \\\"{x:1585,y:441,t:1527876602825};\\\", \\\"{x:1569,y:443,t:1527876602842};\\\", \\\"{x:1541,y:445,t:1527876602859};\\\", \\\"{x:1502,y:445,t:1527876602874};\\\", \\\"{x:1455,y:445,t:1527876602891};\\\", \\\"{x:1393,y:445,t:1527876602908};\\\", \\\"{x:1378,y:445,t:1527876602924};\\\", \\\"{x:1375,y:445,t:1527876602942};\\\", \\\"{x:1374,y:445,t:1527876602973};\\\", \\\"{x:1374,y:442,t:1527876602989};\\\", \\\"{x:1374,y:438,t:1527876602997};\\\", \\\"{x:1374,y:435,t:1527876603008};\\\", \\\"{x:1380,y:422,t:1527876603024};\\\", \\\"{x:1398,y:405,t:1527876603041};\\\", \\\"{x:1415,y:387,t:1527876603058};\\\", \\\"{x:1432,y:364,t:1527876603075};\\\", \\\"{x:1446,y:342,t:1527876603091};\\\", \\\"{x:1502,y:292,t:1527876603109};\\\", \\\"{x:1531,y:271,t:1527876603125};\\\", \\\"{x:1540,y:263,t:1527876603141};\\\", \\\"{x:1542,y:258,t:1527876603159};\\\", \\\"{x:1542,y:255,t:1527876603175};\\\", \\\"{x:1542,y:254,t:1527876603192};\\\", \\\"{x:1541,y:252,t:1527876603208};\\\", \\\"{x:1535,y:249,t:1527876603224};\\\", \\\"{x:1522,y:235,t:1527876603241};\\\", \\\"{x:1507,y:222,t:1527876603258};\\\", \\\"{x:1501,y:215,t:1527876603275};\\\", \\\"{x:1496,y:206,t:1527876603292};\\\", \\\"{x:1493,y:200,t:1527876603308};\\\", \\\"{x:1488,y:194,t:1527876603325};\\\", \\\"{x:1482,y:189,t:1527876603341};\\\", \\\"{x:1473,y:182,t:1527876603358};\\\", \\\"{x:1470,y:180,t:1527876603376};\\\", \\\"{x:1470,y:178,t:1527876603391};\\\", \\\"{x:1470,y:176,t:1527876603408};\\\", \\\"{x:1470,y:174,t:1527876603426};\\\", \\\"{x:1470,y:173,t:1527876603442};\\\", \\\"{x:1472,y:172,t:1527876603458};\\\", \\\"{x:1475,y:171,t:1527876603476};\\\", \\\"{x:1478,y:170,t:1527876603492};\\\", \\\"{x:1479,y:169,t:1527876603510};\\\", \\\"{x:1481,y:169,t:1527876603529};\\\", \\\"{x:1482,y:168,t:1527876603541};\\\", \\\"{x:1483,y:167,t:1527876603653};\\\", \\\"{x:1484,y:166,t:1527876603741};\\\", \\\"{x:1484,y:168,t:1527876604486};\\\", \\\"{x:1483,y:170,t:1527876604496};\\\", \\\"{x:1472,y:177,t:1527876604510};\\\", \\\"{x:1452,y:185,t:1527876604526};\\\", \\\"{x:1413,y:199,t:1527876604543};\\\", \\\"{x:1336,y:219,t:1527876604559};\\\", \\\"{x:1249,y:244,t:1527876604577};\\\", \\\"{x:1152,y:276,t:1527876604593};\\\", \\\"{x:1034,y:320,t:1527876604609};\\\", \\\"{x:899,y:356,t:1527876604626};\\\", \\\"{x:760,y:380,t:1527876604643};\\\", \\\"{x:637,y:388,t:1527876604659};\\\", \\\"{x:483,y:408,t:1527876604677};\\\", \\\"{x:433,y:415,t:1527876604692};\\\", \\\"{x:408,y:419,t:1527876604710};\\\", \\\"{x:399,y:422,t:1527876604727};\\\", \\\"{x:394,y:425,t:1527876604743};\\\", \\\"{x:390,y:429,t:1527876604759};\\\", \\\"{x:388,y:430,t:1527876604776};\\\", \\\"{x:388,y:432,t:1527876604792};\\\", \\\"{x:388,y:434,t:1527876604809};\\\", \\\"{x:387,y:438,t:1527876604826};\\\", \\\"{x:386,y:441,t:1527876604843};\\\", \\\"{x:384,y:445,t:1527876604859};\\\", \\\"{x:382,y:450,t:1527876604876};\\\", \\\"{x:380,y:455,t:1527876604893};\\\", \\\"{x:377,y:461,t:1527876604910};\\\", \\\"{x:374,y:467,t:1527876604927};\\\", \\\"{x:373,y:467,t:1527876604957};\\\", \\\"{x:373,y:468,t:1527876604964};\\\", \\\"{x:373,y:470,t:1527876604981};\\\", \\\"{x:372,y:472,t:1527876604994};\\\", \\\"{x:371,y:473,t:1527876605009};\\\", \\\"{x:370,y:475,t:1527876605027};\\\", \\\"{x:369,y:479,t:1527876605043};\\\", \\\"{x:367,y:482,t:1527876605060};\\\", \\\"{x:367,y:483,t:1527876605093};\\\", \\\"{x:367,y:485,t:1527876605110};\\\", \\\"{x:367,y:489,t:1527876605127};\\\", \\\"{x:367,y:491,t:1527876605143};\\\", \\\"{x:367,y:497,t:1527876605160};\\\", \\\"{x:367,y:504,t:1527876605177};\\\", \\\"{x:373,y:521,t:1527876605194};\\\", \\\"{x:377,y:538,t:1527876605210};\\\", \\\"{x:382,y:550,t:1527876605228};\\\", \\\"{x:385,y:560,t:1527876605244};\\\", \\\"{x:388,y:569,t:1527876605259};\\\", \\\"{x:391,y:578,t:1527876605277};\\\", \\\"{x:392,y:583,t:1527876605294};\\\", \\\"{x:392,y:585,t:1527876605310};\\\", \\\"{x:393,y:586,t:1527876605326};\\\", \\\"{x:394,y:587,t:1527876605343};\\\", \\\"{x:395,y:589,t:1527876605360};\\\", \\\"{x:397,y:589,t:1527876605380};\\\", \\\"{x:399,y:589,t:1527876605393};\\\", \\\"{x:406,y:589,t:1527876605410};\\\", \\\"{x:414,y:589,t:1527876605426};\\\", \\\"{x:427,y:588,t:1527876605444};\\\", \\\"{x:464,y:582,t:1527876605460};\\\", \\\"{x:491,y:581,t:1527876605476};\\\", \\\"{x:518,y:580,t:1527876605495};\\\", \\\"{x:548,y:580,t:1527876605509};\\\", \\\"{x:572,y:578,t:1527876605527};\\\", \\\"{x:591,y:576,t:1527876605543};\\\", \\\"{x:602,y:575,t:1527876605560};\\\", \\\"{x:611,y:573,t:1527876605576};\\\", \\\"{x:614,y:572,t:1527876605595};\\\", \\\"{x:616,y:572,t:1527876605610};\\\", \\\"{x:616,y:571,t:1527876605790};\\\", \\\"{x:617,y:571,t:1527876605797};\\\", \\\"{x:618,y:571,t:1527876605813};\\\", \\\"{x:619,y:571,t:1527876605853};\\\", \\\"{x:619,y:570,t:1527876605860};\\\", \\\"{x:620,y:570,t:1527876605877};\\\", \\\"{x:621,y:569,t:1527876605894};\\\", \\\"{x:623,y:570,t:1527876606221};\\\", \\\"{x:623,y:571,t:1527876606229};\\\", \\\"{x:624,y:573,t:1527876606246};\\\", \\\"{x:626,y:575,t:1527876606261};\\\", \\\"{x:627,y:576,t:1527876606292};\\\", \\\"{x:628,y:576,t:1527876606300};\\\", \\\"{x:629,y:576,t:1527876606310};\\\", \\\"{x:632,y:576,t:1527876606328};\\\", \\\"{x:636,y:576,t:1527876606344};\\\", \\\"{x:643,y:576,t:1527876606360};\\\", \\\"{x:647,y:575,t:1527876606377};\\\", \\\"{x:655,y:572,t:1527876606395};\\\", \\\"{x:660,y:570,t:1527876606410};\\\", \\\"{x:665,y:568,t:1527876606427};\\\", \\\"{x:671,y:566,t:1527876606445};\\\", \\\"{x:675,y:564,t:1527876606460};\\\", \\\"{x:684,y:562,t:1527876606477};\\\", \\\"{x:705,y:556,t:1527876606494};\\\", \\\"{x:742,y:545,t:1527876606512};\\\", \\\"{x:811,y:526,t:1527876606528};\\\", \\\"{x:900,y:501,t:1527876606545};\\\", \\\"{x:1013,y:470,t:1527876606560};\\\", \\\"{x:1138,y:434,t:1527876606578};\\\", \\\"{x:1276,y:395,t:1527876606594};\\\", \\\"{x:1418,y:369,t:1527876606611};\\\", \\\"{x:1551,y:350,t:1527876606628};\\\", \\\"{x:1697,y:329,t:1527876606644};\\\", \\\"{x:1749,y:324,t:1527876606661};\\\", \\\"{x:1775,y:324,t:1527876606678};\\\", \\\"{x:1786,y:324,t:1527876606694};\\\", \\\"{x:1788,y:324,t:1527876606711};\\\", \\\"{x:1786,y:324,t:1527876606861};\\\", \\\"{x:1776,y:319,t:1527876606878};\\\", \\\"{x:1771,y:318,t:1527876606894};\\\", \\\"{x:1766,y:317,t:1527876606912};\\\", \\\"{x:1753,y:314,t:1527876606928};\\\", \\\"{x:1738,y:311,t:1527876606945};\\\", \\\"{x:1715,y:306,t:1527876606961};\\\", \\\"{x:1693,y:298,t:1527876606978};\\\", \\\"{x:1662,y:289,t:1527876606994};\\\", \\\"{x:1617,y:276,t:1527876607012};\\\", \\\"{x:1569,y:261,t:1527876607028};\\\", \\\"{x:1518,y:239,t:1527876607044};\\\", \\\"{x:1501,y:234,t:1527876607061};\\\", \\\"{x:1495,y:232,t:1527876607077};\\\", \\\"{x:1493,y:231,t:1527876607095};\\\", \\\"{x:1492,y:231,t:1527876607112};\\\", \\\"{x:1491,y:231,t:1527876607876};\\\", \\\"{x:1491,y:235,t:1527876607884};\\\", \\\"{x:1491,y:241,t:1527876607895};\\\", \\\"{x:1491,y:250,t:1527876607911};\\\", \\\"{x:1491,y:262,t:1527876607929};\\\", \\\"{x:1491,y:271,t:1527876607945};\\\", \\\"{x:1491,y:286,t:1527876607961};\\\", \\\"{x:1491,y:307,t:1527876607978};\\\", \\\"{x:1493,y:330,t:1527876607996};\\\", \\\"{x:1497,y:363,t:1527876608011};\\\", \\\"{x:1504,y:414,t:1527876608029};\\\", \\\"{x:1512,y:462,t:1527876608045};\\\", \\\"{x:1516,y:509,t:1527876608062};\\\", \\\"{x:1523,y:557,t:1527876608078};\\\", \\\"{x:1528,y:591,t:1527876608095};\\\", \\\"{x:1529,y:620,t:1527876608113};\\\", \\\"{x:1531,y:648,t:1527876608129};\\\", \\\"{x:1534,y:681,t:1527876608146};\\\", \\\"{x:1536,y:713,t:1527876608163};\\\", \\\"{x:1537,y:740,t:1527876608178};\\\", \\\"{x:1539,y:763,t:1527876608196};\\\", \\\"{x:1542,y:789,t:1527876608212};\\\", \\\"{x:1542,y:798,t:1527876608228};\\\", \\\"{x:1542,y:802,t:1527876608246};\\\", \\\"{x:1542,y:804,t:1527876608263};\\\", \\\"{x:1542,y:807,t:1527876608278};\\\", \\\"{x:1542,y:809,t:1527876608295};\\\", \\\"{x:1542,y:810,t:1527876608312};\\\", \\\"{x:1542,y:811,t:1527876608340};\\\", \\\"{x:1542,y:812,t:1527876608550};\\\", \\\"{x:1542,y:813,t:1527876608565};\\\", \\\"{x:1542,y:814,t:1527876608581};\\\", \\\"{x:1542,y:815,t:1527876608597};\\\", \\\"{x:1541,y:816,t:1527876608613};\\\", \\\"{x:1541,y:817,t:1527876608630};\\\", \\\"{x:1541,y:819,t:1527876608646};\\\", \\\"{x:1541,y:820,t:1527876608663};\\\", \\\"{x:1540,y:821,t:1527876608680};\\\", \\\"{x:1539,y:822,t:1527876608696};\\\", \\\"{x:1539,y:823,t:1527876608717};\\\", \\\"{x:1539,y:824,t:1527876608742};\\\", \\\"{x:1538,y:824,t:1527876608749};\\\", \\\"{x:1538,y:825,t:1527876608854};\\\", \\\"{x:1537,y:826,t:1527876609382};\\\", \\\"{x:1535,y:827,t:1527876609397};\\\", \\\"{x:1529,y:829,t:1527876609413};\\\", \\\"{x:1526,y:830,t:1527876609430};\\\", \\\"{x:1520,y:832,t:1527876609447};\\\", \\\"{x:1518,y:832,t:1527876609464};\\\", \\\"{x:1517,y:833,t:1527876609480};\\\", \\\"{x:1515,y:834,t:1527876609497};\\\", \\\"{x:1514,y:835,t:1527876609514};\\\", \\\"{x:1512,y:835,t:1527876609530};\\\", \\\"{x:1511,y:836,t:1527876609547};\\\", \\\"{x:1511,y:837,t:1527876609589};\\\", \\\"{x:1515,y:835,t:1527876609662};\\\", \\\"{x:1530,y:809,t:1527876609669};\\\", \\\"{x:1547,y:779,t:1527876609679};\\\", \\\"{x:1570,y:712,t:1527876609697};\\\", \\\"{x:1589,y:653,t:1527876609713};\\\", \\\"{x:1607,y:596,t:1527876609730};\\\", \\\"{x:1625,y:540,t:1527876609746};\\\", \\\"{x:1640,y:507,t:1527876609764};\\\", \\\"{x:1661,y:465,t:1527876609780};\\\", \\\"{x:1670,y:444,t:1527876609796};\\\", \\\"{x:1676,y:429,t:1527876609813};\\\", \\\"{x:1677,y:425,t:1527876609831};\\\", \\\"{x:1677,y:420,t:1527876609847};\\\", \\\"{x:1677,y:413,t:1527876609863};\\\", \\\"{x:1677,y:410,t:1527876609880};\\\", \\\"{x:1675,y:411,t:1527876609958};\\\", \\\"{x:1671,y:417,t:1527876609965};\\\", \\\"{x:1662,y:427,t:1527876609981};\\\", \\\"{x:1650,y:437,t:1527876609997};\\\", \\\"{x:1637,y:448,t:1527876610014};\\\", \\\"{x:1624,y:460,t:1527876610031};\\\", \\\"{x:1617,y:467,t:1527876610047};\\\", \\\"{x:1615,y:468,t:1527876610064};\\\", \\\"{x:1613,y:468,t:1527876610109};\\\", \\\"{x:1610,y:466,t:1527876610117};\\\", \\\"{x:1608,y:463,t:1527876610131};\\\", \\\"{x:1601,y:450,t:1527876610147};\\\", \\\"{x:1591,y:439,t:1527876610164};\\\", \\\"{x:1584,y:428,t:1527876610180};\\\", \\\"{x:1583,y:427,t:1527876610197};\\\", \\\"{x:1583,y:425,t:1527876610285};\\\", \\\"{x:1583,y:423,t:1527876610298};\\\", \\\"{x:1583,y:420,t:1527876610314};\\\", \\\"{x:1585,y:416,t:1527876610331};\\\", \\\"{x:1590,y:415,t:1527876610348};\\\", \\\"{x:1593,y:413,t:1527876610364};\\\", \\\"{x:1595,y:413,t:1527876610381};\\\", \\\"{x:1596,y:413,t:1527876610405};\\\", \\\"{x:1597,y:413,t:1527876610429};\\\", \\\"{x:1598,y:413,t:1527876610461};\\\", \\\"{x:1598,y:414,t:1527876610469};\\\", \\\"{x:1598,y:416,t:1527876610481};\\\", \\\"{x:1598,y:418,t:1527876610498};\\\", \\\"{x:1598,y:420,t:1527876610514};\\\", \\\"{x:1598,y:423,t:1527876610531};\\\", \\\"{x:1598,y:424,t:1527876610548};\\\", \\\"{x:1598,y:425,t:1527876610564};\\\", \\\"{x:1599,y:425,t:1527876610662};\\\", \\\"{x:1601,y:425,t:1527876610669};\\\", \\\"{x:1602,y:425,t:1527876610681};\\\", \\\"{x:1605,y:425,t:1527876610698};\\\", \\\"{x:1608,y:425,t:1527876610715};\\\", \\\"{x:1611,y:425,t:1527876610735};\\\", \\\"{x:1612,y:425,t:1527876610748};\\\", \\\"{x:1611,y:424,t:1527876614511};\\\", \\\"{x:1609,y:424,t:1527876614521};\\\", \\\"{x:1608,y:424,t:1527876614536};\\\", \\\"{x:1606,y:423,t:1527876614551};\\\", \\\"{x:1605,y:423,t:1527876614572};\\\", \\\"{x:1604,y:423,t:1527876614636};\\\", \\\"{x:1601,y:423,t:1527876614652};\\\", \\\"{x:1598,y:423,t:1527876614668};\\\", \\\"{x:1590,y:423,t:1527876614684};\\\", \\\"{x:1576,y:428,t:1527876614701};\\\", \\\"{x:1568,y:433,t:1527876614718};\\\", \\\"{x:1557,y:442,t:1527876614734};\\\", \\\"{x:1548,y:452,t:1527876614751};\\\", \\\"{x:1542,y:462,t:1527876614768};\\\", \\\"{x:1539,y:472,t:1527876614785};\\\", \\\"{x:1536,y:484,t:1527876614801};\\\", \\\"{x:1536,y:489,t:1527876614818};\\\", \\\"{x:1537,y:493,t:1527876614834};\\\", \\\"{x:1538,y:496,t:1527876614851};\\\", \\\"{x:1539,y:497,t:1527876614869};\\\", \\\"{x:1543,y:499,t:1527876614884};\\\", \\\"{x:1550,y:503,t:1527876614901};\\\", \\\"{x:1556,y:506,t:1527876614918};\\\", \\\"{x:1566,y:515,t:1527876614934};\\\", \\\"{x:1574,y:526,t:1527876614951};\\\", \\\"{x:1579,y:535,t:1527876614969};\\\", \\\"{x:1581,y:540,t:1527876614985};\\\", \\\"{x:1584,y:544,t:1527876615001};\\\", \\\"{x:1584,y:545,t:1527876615037};\\\", \\\"{x:1586,y:548,t:1527876615053};\\\", \\\"{x:1591,y:553,t:1527876615069};\\\", \\\"{x:1600,y:558,t:1527876615085};\\\", \\\"{x:1604,y:561,t:1527876615101};\\\", \\\"{x:1608,y:563,t:1527876615118};\\\", \\\"{x:1612,y:565,t:1527876615138};\\\", \\\"{x:1614,y:566,t:1527876615151};\\\", \\\"{x:1616,y:566,t:1527876615252};\\\", \\\"{x:1616,y:567,t:1527876615268};\\\", \\\"{x:1616,y:572,t:1527876615941};\\\", \\\"{x:1613,y:578,t:1527876615952};\\\", \\\"{x:1604,y:591,t:1527876615968};\\\", \\\"{x:1597,y:601,t:1527876615985};\\\", \\\"{x:1591,y:609,t:1527876616001};\\\", \\\"{x:1588,y:615,t:1527876616019};\\\", \\\"{x:1585,y:619,t:1527876616035};\\\", \\\"{x:1583,y:622,t:1527876616052};\\\", \\\"{x:1581,y:625,t:1527876616068};\\\", \\\"{x:1575,y:631,t:1527876616084};\\\", \\\"{x:1571,y:635,t:1527876616102};\\\", \\\"{x:1565,y:640,t:1527876616119};\\\", \\\"{x:1563,y:641,t:1527876616135};\\\", \\\"{x:1561,y:642,t:1527876616173};\\\", \\\"{x:1560,y:642,t:1527876616196};\\\", \\\"{x:1559,y:642,t:1527876616204};\\\", \\\"{x:1556,y:641,t:1527876616219};\\\", \\\"{x:1546,y:637,t:1527876616235};\\\", \\\"{x:1536,y:631,t:1527876616252};\\\", \\\"{x:1525,y:625,t:1527876616268};\\\", \\\"{x:1523,y:622,t:1527876616285};\\\", \\\"{x:1521,y:620,t:1527876616302};\\\", \\\"{x:1520,y:619,t:1527876616320};\\\", \\\"{x:1519,y:618,t:1527876616341};\\\", \\\"{x:1519,y:619,t:1527876616685};\\\", \\\"{x:1519,y:620,t:1527876616703};\\\", \\\"{x:1518,y:621,t:1527876616733};\\\", \\\"{x:1517,y:621,t:1527876616814};\\\", \\\"{x:1517,y:623,t:1527876616845};\\\", \\\"{x:1516,y:624,t:1527876617093};\\\", \\\"{x:1516,y:625,t:1527876617107};\\\", \\\"{x:1515,y:627,t:1527876617119};\\\", \\\"{x:1514,y:630,t:1527876617139};\\\", \\\"{x:1513,y:631,t:1527876617156};\\\", \\\"{x:1513,y:632,t:1527876617171};\\\", \\\"{x:1512,y:634,t:1527876617773};\\\", \\\"{x:1508,y:634,t:1527876617788};\\\", \\\"{x:1483,y:632,t:1527876617804};\\\", \\\"{x:1458,y:630,t:1527876617820};\\\", \\\"{x:1393,y:622,t:1527876617836};\\\", \\\"{x:1263,y:622,t:1527876617853};\\\", \\\"{x:1116,y:618,t:1527876617870};\\\", \\\"{x:949,y:607,t:1527876617887};\\\", \\\"{x:797,y:607,t:1527876617902};\\\", \\\"{x:663,y:612,t:1527876617921};\\\", \\\"{x:548,y:637,t:1527876617938};\\\", \\\"{x:466,y:656,t:1527876617954};\\\", \\\"{x:428,y:663,t:1527876617969};\\\", \\\"{x:418,y:665,t:1527876617986};\\\", \\\"{x:420,y:665,t:1527876618084};\\\", \\\"{x:423,y:665,t:1527876618091};\\\", \\\"{x:426,y:664,t:1527876618103};\\\", \\\"{x:434,y:659,t:1527876618120};\\\", \\\"{x:444,y:653,t:1527876618137};\\\", \\\"{x:453,y:647,t:1527876618154};\\\", \\\"{x:458,y:643,t:1527876618170};\\\", \\\"{x:463,y:640,t:1527876618187};\\\", \\\"{x:468,y:637,t:1527876618203};\\\", \\\"{x:469,y:636,t:1527876618220};\\\", \\\"{x:475,y:634,t:1527876618236};\\\", \\\"{x:479,y:632,t:1527876618254};\\\", \\\"{x:481,y:630,t:1527876618270};\\\", \\\"{x:480,y:630,t:1527876618357};\\\", \\\"{x:475,y:633,t:1527876618370};\\\", \\\"{x:471,y:635,t:1527876618387};\\\", \\\"{x:466,y:636,t:1527876618404};\\\", \\\"{x:455,y:638,t:1527876618421};\\\", \\\"{x:451,y:639,t:1527876618437};\\\", \\\"{x:450,y:639,t:1527876618454};\\\", \\\"{x:451,y:639,t:1527876618877};\\\", \\\"{x:458,y:639,t:1527876618888};\\\", \\\"{x:477,y:641,t:1527876618904};\\\", \\\"{x:489,y:643,t:1527876618921};\\\", \\\"{x:493,y:644,t:1527876618937};\\\", \\\"{x:493,y:645,t:1527876618997};\\\", \\\"{x:489,y:647,t:1527876619005};\\\", \\\"{x:476,y:648,t:1527876619021};\\\", \\\"{x:468,y:648,t:1527876619038};\\\", \\\"{x:458,y:648,t:1527876619054};\\\", \\\"{x:444,y:645,t:1527876619071};\\\", \\\"{x:435,y:641,t:1527876619088};\\\", \\\"{x:434,y:641,t:1527876619104};\\\", \\\"{x:432,y:640,t:1527876619121};\\\", \\\"{x:431,y:640,t:1527876619139};\\\", \\\"{x:428,y:638,t:1527876619154};\\\", \\\"{x:423,y:637,t:1527876619171};\\\", \\\"{x:417,y:635,t:1527876619190};\\\", \\\"{x:411,y:632,t:1527876619204};\\\", \\\"{x:399,y:627,t:1527876619221};\\\", \\\"{x:387,y:622,t:1527876619238};\\\", \\\"{x:378,y:619,t:1527876619254};\\\", \\\"{x:375,y:619,t:1527876619271};\\\", \\\"{x:373,y:619,t:1527876619287};\\\", \\\"{x:372,y:619,t:1527876619303};\\\", \\\"{x:371,y:618,t:1527876619321};\\\", \\\"{x:370,y:618,t:1527876619338};\\\", \\\"{x:369,y:618,t:1527876619364};\\\", \\\"{x:369,y:619,t:1527876619437};\\\", \\\"{x:369,y:620,t:1527876619444};\\\", \\\"{x:371,y:624,t:1527876619455};\\\", \\\"{x:373,y:627,t:1527876619471};\\\", \\\"{x:374,y:629,t:1527876619489};\\\", \\\"{x:375,y:630,t:1527876619504};\\\", \\\"{x:376,y:630,t:1527876619521};\\\", \\\"{x:376,y:631,t:1527876619563};\\\", \\\"{x:378,y:631,t:1527876619812};\\\", \\\"{x:382,y:631,t:1527876619821};\\\", \\\"{x:388,y:635,t:1527876619838};\\\", \\\"{x:394,y:639,t:1527876619855};\\\", \\\"{x:399,y:642,t:1527876619872};\\\", \\\"{x:408,y:644,t:1527876619888};\\\", \\\"{x:424,y:650,t:1527876619905};\\\", \\\"{x:446,y:658,t:1527876619921};\\\", \\\"{x:494,y:672,t:1527876619938};\\\", \\\"{x:588,y:696,t:1527876619955};\\\", \\\"{x:744,y:742,t:1527876619972};\\\", \\\"{x:851,y:773,t:1527876619988};\\\", \\\"{x:943,y:798,t:1527876620005};\\\", \\\"{x:1016,y:815,t:1527876620022};\\\", \\\"{x:1059,y:822,t:1527876620038};\\\", \\\"{x:1077,y:826,t:1527876620055};\\\", \\\"{x:1080,y:826,t:1527876620072};\\\", \\\"{x:1082,y:826,t:1527876620166};\\\", \\\"{x:1085,y:827,t:1527876620173};\\\", \\\"{x:1094,y:830,t:1527876620190};\\\", \\\"{x:1096,y:831,t:1527876620205};\\\", \\\"{x:1101,y:834,t:1527876620222};\\\", \\\"{x:1113,y:840,t:1527876620240};\\\", \\\"{x:1127,y:846,t:1527876620255};\\\", \\\"{x:1140,y:851,t:1527876620273};\\\", \\\"{x:1153,y:852,t:1527876620290};\\\", \\\"{x:1170,y:856,t:1527876620306};\\\", \\\"{x:1193,y:858,t:1527876620323};\\\", \\\"{x:1224,y:863,t:1527876620339};\\\", \\\"{x:1280,y:878,t:1527876620357};\\\", \\\"{x:1300,y:888,t:1527876620373};\\\", \\\"{x:1312,y:890,t:1527876620389};\\\", \\\"{x:1314,y:891,t:1527876620407};\\\", \\\"{x:1315,y:891,t:1527876620422};\\\", \\\"{x:1316,y:891,t:1527876620461};\\\", \\\"{x:1318,y:891,t:1527876620473};\\\", \\\"{x:1319,y:891,t:1527876620490};\\\", \\\"{x:1317,y:885,t:1527876620542};\\\", \\\"{x:1284,y:867,t:1527876620557};\\\", \\\"{x:1259,y:852,t:1527876620573};\\\", \\\"{x:1201,y:821,t:1527876620589};\\\", \\\"{x:1172,y:809,t:1527876620607};\\\", \\\"{x:1143,y:797,t:1527876620623};\\\", \\\"{x:1124,y:789,t:1527876620639};\\\", \\\"{x:1120,y:787,t:1527876620657};\\\", \\\"{x:1118,y:787,t:1527876620673};\\\", \\\"{x:1118,y:790,t:1527876620749};\\\", \\\"{x:1119,y:791,t:1527876620756};\\\", \\\"{x:1121,y:795,t:1527876620773};\\\", \\\"{x:1124,y:799,t:1527876620789};\\\", \\\"{x:1133,y:806,t:1527876620807};\\\", \\\"{x:1140,y:811,t:1527876620824};\\\", \\\"{x:1148,y:815,t:1527876620839};\\\", \\\"{x:1161,y:824,t:1527876620856};\\\", \\\"{x:1174,y:833,t:1527876620873};\\\", \\\"{x:1191,y:843,t:1527876620889};\\\", \\\"{x:1198,y:848,t:1527876620907};\\\", \\\"{x:1204,y:852,t:1527876620923};\\\", \\\"{x:1206,y:853,t:1527876620940};\\\", \\\"{x:1207,y:853,t:1527876620974};\\\", \\\"{x:1208,y:852,t:1527876621053};\\\", \\\"{x:1208,y:849,t:1527876621061};\\\", \\\"{x:1208,y:847,t:1527876621074};\\\", \\\"{x:1208,y:834,t:1527876621089};\\\", \\\"{x:1206,y:826,t:1527876621105};\\\", \\\"{x:1205,y:823,t:1527876621123};\\\", \\\"{x:1205,y:821,t:1527876621140};\\\", \\\"{x:1205,y:820,t:1527876621157};\\\", \\\"{x:1205,y:821,t:1527876621397};\\\", \\\"{x:1205,y:822,t:1527876621413};\\\", \\\"{x:1205,y:823,t:1527876621717};\\\", \\\"{x:1205,y:824,t:1527876621725};\\\", \\\"{x:1205,y:826,t:1527876621741};\\\", \\\"{x:1205,y:828,t:1527876621758};\\\", \\\"{x:1205,y:829,t:1527876621780};\\\", \\\"{x:1204,y:829,t:1527876621869};\\\", \\\"{x:1207,y:829,t:1527876622181};\\\", \\\"{x:1208,y:829,t:1527876622192};\\\", \\\"{x:1209,y:829,t:1527876622212};\\\", \\\"{x:1210,y:831,t:1527876622240};\\\", \\\"{x:1211,y:831,t:1527876622292};\\\", \\\"{x:1212,y:831,t:1527876622485};\\\", \\\"{x:1214,y:831,t:1527876622525};\\\", \\\"{x:1219,y:831,t:1527876622541};\\\", \\\"{x:1221,y:831,t:1527876622557};\\\", \\\"{x:1223,y:831,t:1527876622573};\\\", \\\"{x:1228,y:831,t:1527876622589};\\\", \\\"{x:1231,y:831,t:1527876622607};\\\", \\\"{x:1233,y:831,t:1527876622624};\\\", \\\"{x:1235,y:831,t:1527876622640};\\\", \\\"{x:1236,y:831,t:1527876622657};\\\", \\\"{x:1238,y:831,t:1527876622674};\\\", \\\"{x:1241,y:831,t:1527876622765};\\\", \\\"{x:1243,y:831,t:1527876622774};\\\", \\\"{x:1249,y:830,t:1527876622790};\\\", \\\"{x:1256,y:828,t:1527876622808};\\\", \\\"{x:1260,y:827,t:1527876622824};\\\", \\\"{x:1263,y:826,t:1527876622840};\\\", \\\"{x:1265,y:826,t:1527876622858};\\\", \\\"{x:1266,y:826,t:1527876622885};\\\", \\\"{x:1267,y:826,t:1527876622900};\\\", \\\"{x:1268,y:826,t:1527876622933};\\\", \\\"{x:1271,y:826,t:1527876623068};\\\", \\\"{x:1273,y:826,t:1527876623076};\\\", \\\"{x:1275,y:826,t:1527876623091};\\\", \\\"{x:1280,y:826,t:1527876623107};\\\", \\\"{x:1281,y:828,t:1527876623123};\\\", \\\"{x:1282,y:828,t:1527876623422};\\\", \\\"{x:1289,y:836,t:1527876623431};\\\", \\\"{x:1306,y:850,t:1527876623441};\\\", \\\"{x:1336,y:877,t:1527876623458};\\\", \\\"{x:1357,y:895,t:1527876623474};\\\", \\\"{x:1381,y:910,t:1527876623491};\\\", \\\"{x:1403,y:927,t:1527876623507};\\\", \\\"{x:1403,y:928,t:1527876623524};\\\", \\\"{x:1400,y:928,t:1527876623669};\\\", \\\"{x:1394,y:926,t:1527876623676};\\\", \\\"{x:1385,y:922,t:1527876623691};\\\", \\\"{x:1367,y:912,t:1527876623708};\\\", \\\"{x:1354,y:906,t:1527876623725};\\\", \\\"{x:1340,y:898,t:1527876623741};\\\", \\\"{x:1337,y:896,t:1527876623759};\\\", \\\"{x:1337,y:895,t:1527876624037};\\\", \\\"{x:1337,y:894,t:1527876624069};\\\", \\\"{x:1338,y:893,t:1527876624084};\\\", \\\"{x:1340,y:893,t:1527876624133};\\\", \\\"{x:1341,y:893,t:1527876624293};\\\", \\\"{x:1343,y:894,t:1527876624376};\\\", \\\"{x:1344,y:894,t:1527876624412};\\\", \\\"{x:1344,y:895,t:1527876624444};\\\", \\\"{x:1345,y:895,t:1527876624460};\\\", \\\"{x:1346,y:895,t:1527876624475};\\\", \\\"{x:1347,y:896,t:1527876624492};\\\", \\\"{x:1347,y:897,t:1527876624589};\\\", \\\"{x:1347,y:896,t:1527876624812};\\\", \\\"{x:1347,y:893,t:1527876624825};\\\", \\\"{x:1348,y:883,t:1527876624844};\\\", \\\"{x:1350,y:868,t:1527876624859};\\\", \\\"{x:1351,y:853,t:1527876624875};\\\", \\\"{x:1353,y:832,t:1527876624892};\\\", \\\"{x:1355,y:819,t:1527876624909};\\\", \\\"{x:1357,y:813,t:1527876624925};\\\", \\\"{x:1357,y:808,t:1527876624942};\\\", \\\"{x:1359,y:804,t:1527876624959};\\\", \\\"{x:1361,y:801,t:1527876624975};\\\", \\\"{x:1361,y:798,t:1527876624992};\\\", \\\"{x:1363,y:795,t:1527876625009};\\\", \\\"{x:1364,y:793,t:1527876625026};\\\", \\\"{x:1365,y:790,t:1527876625042};\\\", \\\"{x:1366,y:788,t:1527876625059};\\\", \\\"{x:1367,y:787,t:1527876625076};\\\", \\\"{x:1367,y:785,t:1527876625125};\\\", \\\"{x:1370,y:783,t:1527876625133};\\\", \\\"{x:1370,y:782,t:1527876625142};\\\", \\\"{x:1371,y:780,t:1527876625159};\\\", \\\"{x:1372,y:777,t:1527876625177};\\\", \\\"{x:1374,y:776,t:1527876625193};\\\", \\\"{x:1374,y:774,t:1527876625210};\\\", \\\"{x:1375,y:771,t:1527876625226};\\\", \\\"{x:1375,y:770,t:1527876625242};\\\", \\\"{x:1376,y:769,t:1527876625260};\\\", \\\"{x:1376,y:768,t:1527876625276};\\\", \\\"{x:1377,y:768,t:1527876625300};\\\", \\\"{x:1377,y:767,t:1527876625312};\\\", \\\"{x:1377,y:765,t:1527876625326};\\\", \\\"{x:1377,y:764,t:1527876625342};\\\", \\\"{x:1377,y:763,t:1527876625359};\\\", \\\"{x:1378,y:763,t:1527876625375};\\\", \\\"{x:1378,y:764,t:1527876625653};\\\", \\\"{x:1379,y:765,t:1527876625660};\\\", \\\"{x:1380,y:767,t:1527876625676};\\\", \\\"{x:1388,y:777,t:1527876625709};\\\", \\\"{x:1393,y:783,t:1527876625726};\\\", \\\"{x:1398,y:789,t:1527876625743};\\\", \\\"{x:1403,y:796,t:1527876625759};\\\", \\\"{x:1410,y:803,t:1527876625776};\\\", \\\"{x:1415,y:809,t:1527876625793};\\\", \\\"{x:1419,y:815,t:1527876625809};\\\", \\\"{x:1423,y:821,t:1527876625826};\\\", \\\"{x:1426,y:826,t:1527876625843};\\\", \\\"{x:1431,y:830,t:1527876625860};\\\", \\\"{x:1435,y:833,t:1527876625876};\\\", \\\"{x:1438,y:835,t:1527876625894};\\\", \\\"{x:1441,y:835,t:1527876625910};\\\", \\\"{x:1443,y:837,t:1527876625926};\\\", \\\"{x:1445,y:838,t:1527876625943};\\\", \\\"{x:1447,y:839,t:1527876625960};\\\", \\\"{x:1449,y:840,t:1527876625976};\\\", \\\"{x:1453,y:840,t:1527876625993};\\\", \\\"{x:1457,y:840,t:1527876626010};\\\", \\\"{x:1462,y:840,t:1527876626026};\\\", \\\"{x:1468,y:840,t:1527876626043};\\\", \\\"{x:1478,y:838,t:1527876626060};\\\", \\\"{x:1485,y:836,t:1527876626076};\\\", \\\"{x:1487,y:835,t:1527876626093};\\\", \\\"{x:1489,y:835,t:1527876626110};\\\", \\\"{x:1491,y:835,t:1527876626126};\\\", \\\"{x:1492,y:834,t:1527876626148};\\\", \\\"{x:1492,y:833,t:1527876626160};\\\", \\\"{x:1493,y:833,t:1527876626178};\\\", \\\"{x:1494,y:833,t:1527876626194};\\\", \\\"{x:1492,y:833,t:1527876626348};\\\", \\\"{x:1490,y:833,t:1527876626360};\\\", \\\"{x:1485,y:833,t:1527876626379};\\\", \\\"{x:1482,y:833,t:1527876626393};\\\", \\\"{x:1481,y:833,t:1527876626410};\\\", \\\"{x:1480,y:833,t:1527876626435};\\\", \\\"{x:1479,y:833,t:1527876626476};\\\", \\\"{x:1480,y:832,t:1527876626701};\\\", \\\"{x:1486,y:830,t:1527876626710};\\\", \\\"{x:1498,y:828,t:1527876626730};\\\", \\\"{x:1512,y:828,t:1527876626743};\\\", \\\"{x:1522,y:828,t:1527876626759};\\\", \\\"{x:1527,y:828,t:1527876626777};\\\", \\\"{x:1530,y:828,t:1527876626794};\\\", \\\"{x:1535,y:829,t:1527876626810};\\\", \\\"{x:1547,y:832,t:1527876626827};\\\", \\\"{x:1570,y:836,t:1527876626844};\\\", \\\"{x:1587,y:839,t:1527876626860};\\\", \\\"{x:1605,y:840,t:1527876626877};\\\", \\\"{x:1616,y:840,t:1527876626894};\\\", \\\"{x:1624,y:841,t:1527876626910};\\\", \\\"{x:1628,y:841,t:1527876626927};\\\", \\\"{x:1632,y:841,t:1527876626945};\\\", \\\"{x:1634,y:841,t:1527876626960};\\\", \\\"{x:1635,y:841,t:1527876626977};\\\", \\\"{x:1637,y:840,t:1527876626995};\\\", \\\"{x:1639,y:839,t:1527876627021};\\\", \\\"{x:1640,y:839,t:1527876627051};\\\", \\\"{x:1640,y:838,t:1527876627060};\\\", \\\"{x:1641,y:838,t:1527876627077};\\\", \\\"{x:1641,y:837,t:1527876627094};\\\", \\\"{x:1643,y:836,t:1527876627110};\\\", \\\"{x:1645,y:835,t:1527876627127};\\\", \\\"{x:1650,y:835,t:1527876627144};\\\", \\\"{x:1654,y:833,t:1527876627161};\\\", \\\"{x:1657,y:833,t:1527876627178};\\\", \\\"{x:1657,y:832,t:1527876627195};\\\", \\\"{x:1658,y:832,t:1527876627211};\\\", \\\"{x:1660,y:832,t:1527876627244};\\\", \\\"{x:1661,y:832,t:1527876627261};\\\", \\\"{x:1664,y:832,t:1527876627277};\\\", \\\"{x:1668,y:832,t:1527876627294};\\\", \\\"{x:1670,y:832,t:1527876627312};\\\", \\\"{x:1672,y:832,t:1527876627328};\\\", \\\"{x:1673,y:832,t:1527876627437};\\\", \\\"{x:1674,y:832,t:1527876627534};\\\", \\\"{x:1675,y:832,t:1527876627545};\\\", \\\"{x:1676,y:832,t:1527876627565};\\\", \\\"{x:1677,y:832,t:1527876627577};\\\", \\\"{x:1679,y:832,t:1527876627594};\\\", \\\"{x:1681,y:830,t:1527876627611};\\\", \\\"{x:1682,y:830,t:1527876627627};\\\", \\\"{x:1683,y:829,t:1527876627933};\\\", \\\"{x:1683,y:828,t:1527876627945};\\\", \\\"{x:1679,y:821,t:1527876627963};\\\", \\\"{x:1675,y:811,t:1527876627978};\\\", \\\"{x:1670,y:799,t:1527876627994};\\\", \\\"{x:1664,y:787,t:1527876628011};\\\", \\\"{x:1660,y:777,t:1527876628028};\\\", \\\"{x:1659,y:775,t:1527876628044};\\\", \\\"{x:1658,y:774,t:1527876628062};\\\", \\\"{x:1656,y:769,t:1527876628078};\\\", \\\"{x:1656,y:768,t:1527876628095};\\\", \\\"{x:1656,y:767,t:1527876628111};\\\", \\\"{x:1655,y:766,t:1527876628237};\\\", \\\"{x:1654,y:766,t:1527876628245};\\\", \\\"{x:1653,y:766,t:1527876628261};\\\", \\\"{x:1649,y:766,t:1527876628282};\\\", \\\"{x:1645,y:765,t:1527876628295};\\\", \\\"{x:1641,y:765,t:1527876628328};\\\", \\\"{x:1639,y:765,t:1527876628345};\\\", \\\"{x:1638,y:765,t:1527876628361};\\\", \\\"{x:1637,y:765,t:1527876628378};\\\", \\\"{x:1636,y:765,t:1527876628395};\\\", \\\"{x:1636,y:764,t:1527876628573};\\\", \\\"{x:1638,y:763,t:1527876628596};\\\", \\\"{x:1639,y:763,t:1527876628621};\\\", \\\"{x:1640,y:762,t:1527876628629};\\\", \\\"{x:1641,y:761,t:1527876628646};\\\", \\\"{x:1643,y:761,t:1527876628666};\\\", \\\"{x:1644,y:761,t:1527876628678};\\\", \\\"{x:1645,y:761,t:1527876628695};\\\", \\\"{x:1647,y:760,t:1527876628712};\\\", \\\"{x:1648,y:759,t:1527876628747};\\\", \\\"{x:1646,y:758,t:1527876629085};\\\", \\\"{x:1643,y:756,t:1527876629102};\\\", \\\"{x:1641,y:755,t:1527876629112};\\\", \\\"{x:1631,y:747,t:1527876629129};\\\", \\\"{x:1619,y:738,t:1527876629145};\\\", \\\"{x:1595,y:717,t:1527876629162};\\\", \\\"{x:1577,y:696,t:1527876629179};\\\", \\\"{x:1541,y:659,t:1527876629196};\\\", \\\"{x:1496,y:608,t:1527876629212};\\\", \\\"{x:1488,y:596,t:1527876629229};\\\", \\\"{x:1486,y:595,t:1527876629245};\\\", \\\"{x:1486,y:594,t:1527876629341};\\\", \\\"{x:1487,y:594,t:1527876629349};\\\", \\\"{x:1490,y:592,t:1527876629363};\\\", \\\"{x:1493,y:593,t:1527876629380};\\\", \\\"{x:1497,y:598,t:1527876629396};\\\", \\\"{x:1505,y:615,t:1527876629412};\\\", \\\"{x:1510,y:630,t:1527876629430};\\\", \\\"{x:1513,y:643,t:1527876629446};\\\", \\\"{x:1513,y:649,t:1527876629462};\\\", \\\"{x:1513,y:650,t:1527876629480};\\\", \\\"{x:1514,y:650,t:1527876629669};\\\", \\\"{x:1516,y:649,t:1527876629685};\\\", \\\"{x:1516,y:647,t:1527876629697};\\\", \\\"{x:1516,y:645,t:1527876629713};\\\", \\\"{x:1516,y:644,t:1527876629729};\\\", \\\"{x:1517,y:644,t:1527876629746};\\\", \\\"{x:1517,y:643,t:1527876629861};\\\", \\\"{x:1517,y:642,t:1527876629868};\\\", \\\"{x:1517,y:641,t:1527876629891};\\\", \\\"{x:1517,y:640,t:1527876629907};\\\", \\\"{x:1517,y:639,t:1527876629915};\\\", \\\"{x:1517,y:638,t:1527876629932};\\\", \\\"{x:1517,y:637,t:1527876630076};\\\", \\\"{x:1517,y:636,t:1527876630084};\\\", \\\"{x:1517,y:635,t:1527876630097};\\\", \\\"{x:1517,y:633,t:1527876630113};\\\", \\\"{x:1517,y:632,t:1527876630129};\\\", \\\"{x:1517,y:631,t:1527876630853};\\\", \\\"{x:1516,y:631,t:1527876630884};\\\", \\\"{x:1515,y:631,t:1527876630897};\\\", \\\"{x:1514,y:631,t:1527876630988};\\\", \\\"{x:1516,y:630,t:1527876631244};\\\", \\\"{x:1519,y:627,t:1527876631252};\\\", \\\"{x:1525,y:622,t:1527876631267};\\\", \\\"{x:1538,y:615,t:1527876631280};\\\", \\\"{x:1553,y:606,t:1527876631297};\\\", \\\"{x:1565,y:600,t:1527876631315};\\\", \\\"{x:1574,y:594,t:1527876631331};\\\", \\\"{x:1581,y:586,t:1527876631347};\\\", \\\"{x:1597,y:576,t:1527876631363};\\\", \\\"{x:1614,y:568,t:1527876631381};\\\", \\\"{x:1634,y:559,t:1527876631397};\\\", \\\"{x:1651,y:552,t:1527876631414};\\\", \\\"{x:1657,y:549,t:1527876631431};\\\", \\\"{x:1659,y:548,t:1527876631447};\\\", \\\"{x:1661,y:547,t:1527876631464};\\\", \\\"{x:1662,y:547,t:1527876631499};\\\", \\\"{x:1662,y:546,t:1527876631514};\\\", \\\"{x:1657,y:547,t:1527876631596};\\\", \\\"{x:1650,y:548,t:1527876631604};\\\", \\\"{x:1644,y:549,t:1527876631615};\\\", \\\"{x:1633,y:553,t:1527876631635};\\\", \\\"{x:1623,y:557,t:1527876631651};\\\", \\\"{x:1611,y:561,t:1527876631669};\\\", \\\"{x:1605,y:562,t:1527876631686};\\\", \\\"{x:1602,y:564,t:1527876631701};\\\", \\\"{x:1602,y:566,t:1527876631823};\\\", \\\"{x:1603,y:566,t:1527876631855};\\\", \\\"{x:1604,y:566,t:1527876631869};\\\", \\\"{x:1605,y:566,t:1527876631885};\\\", \\\"{x:1606,y:566,t:1527876631901};\\\", \\\"{x:1607,y:565,t:1527876631919};\\\", \\\"{x:1609,y:565,t:1527876631937};\\\", \\\"{x:1611,y:564,t:1527876631952};\\\", \\\"{x:1614,y:564,t:1527876631967};\\\", \\\"{x:1617,y:562,t:1527876631985};\\\", \\\"{x:1619,y:561,t:1527876632002};\\\", \\\"{x:1620,y:561,t:1527876632019};\\\", \\\"{x:1621,y:561,t:1527876632035};\\\", \\\"{x:1618,y:561,t:1527876632332};\\\", \\\"{x:1609,y:562,t:1527876632352};\\\", \\\"{x:1605,y:562,t:1527876632368};\\\", \\\"{x:1604,y:562,t:1527876632384};\\\", \\\"{x:1603,y:562,t:1527876632402};\\\", \\\"{x:1602,y:562,t:1527876632418};\\\", \\\"{x:1600,y:562,t:1527876632435};\\\", \\\"{x:1597,y:563,t:1527876632451};\\\", \\\"{x:1593,y:563,t:1527876632469};\\\", \\\"{x:1583,y:563,t:1527876632485};\\\", \\\"{x:1570,y:563,t:1527876632501};\\\", \\\"{x:1550,y:562,t:1527876632519};\\\", \\\"{x:1526,y:559,t:1527876632535};\\\", \\\"{x:1468,y:545,t:1527876632551};\\\", \\\"{x:1407,y:529,t:1527876632569};\\\", \\\"{x:1362,y:515,t:1527876632585};\\\", \\\"{x:1337,y:508,t:1527876632603};\\\", \\\"{x:1325,y:504,t:1527876632619};\\\", \\\"{x:1319,y:504,t:1527876632635};\\\", \\\"{x:1314,y:504,t:1527876632652};\\\", \\\"{x:1311,y:504,t:1527876632670};\\\", \\\"{x:1310,y:504,t:1527876632685};\\\", \\\"{x:1308,y:505,t:1527876632702};\\\", \\\"{x:1306,y:505,t:1527876632720};\\\", \\\"{x:1305,y:506,t:1527876632736};\\\", \\\"{x:1303,y:509,t:1527876632752};\\\", \\\"{x:1300,y:515,t:1527876632769};\\\", \\\"{x:1296,y:523,t:1527876632785};\\\", \\\"{x:1295,y:528,t:1527876632802};\\\", \\\"{x:1295,y:532,t:1527876632819};\\\", \\\"{x:1300,y:535,t:1527876632836};\\\", \\\"{x:1309,y:535,t:1527876632852};\\\", \\\"{x:1318,y:535,t:1527876632869};\\\", \\\"{x:1329,y:535,t:1527876632886};\\\", \\\"{x:1337,y:535,t:1527876632902};\\\", \\\"{x:1346,y:535,t:1527876632920};\\\", \\\"{x:1351,y:535,t:1527876632936};\\\", \\\"{x:1356,y:535,t:1527876632952};\\\", \\\"{x:1359,y:535,t:1527876632969};\\\", \\\"{x:1363,y:536,t:1527876632987};\\\", \\\"{x:1366,y:536,t:1527876633002};\\\", \\\"{x:1368,y:537,t:1527876633019};\\\", \\\"{x:1369,y:538,t:1527876633037};\\\", \\\"{x:1371,y:540,t:1527876633056};\\\", \\\"{x:1373,y:542,t:1527876633068};\\\", \\\"{x:1376,y:551,t:1527876633086};\\\", \\\"{x:1383,y:565,t:1527876633102};\\\", \\\"{x:1388,y:574,t:1527876633119};\\\", \\\"{x:1390,y:575,t:1527876633136};\\\", \\\"{x:1391,y:575,t:1527876633175};\\\", \\\"{x:1392,y:575,t:1527876633199};\\\", \\\"{x:1393,y:575,t:1527876633207};\\\", \\\"{x:1395,y:576,t:1527876633231};\\\", \\\"{x:1396,y:576,t:1527876633239};\\\", \\\"{x:1397,y:576,t:1527876633252};\\\", \\\"{x:1402,y:576,t:1527876633269};\\\", \\\"{x:1407,y:576,t:1527876633286};\\\", \\\"{x:1410,y:576,t:1527876633303};\\\", \\\"{x:1414,y:576,t:1527876633319};\\\", \\\"{x:1419,y:577,t:1527876633336};\\\", \\\"{x:1421,y:578,t:1527876633353};\\\", \\\"{x:1422,y:578,t:1527876633369};\\\", \\\"{x:1425,y:578,t:1527876633386};\\\", \\\"{x:1424,y:578,t:1527876633897};\\\", \\\"{x:1423,y:578,t:1527876633904};\\\", \\\"{x:1423,y:577,t:1527876633920};\\\", \\\"{x:1423,y:574,t:1527876633937};\\\", \\\"{x:1423,y:572,t:1527876633954};\\\", \\\"{x:1423,y:571,t:1527876633977};\\\", \\\"{x:1423,y:569,t:1527876634089};\\\", \\\"{x:1422,y:568,t:1527876634169};\\\", \\\"{x:1421,y:567,t:1527876634192};\\\", \\\"{x:1420,y:566,t:1527876634208};\\\", \\\"{x:1419,y:565,t:1527876634236};\\\", \\\"{x:1419,y:564,t:1527876634253};\\\", \\\"{x:1418,y:564,t:1527876634617};\\\", \\\"{x:1412,y:564,t:1527876634623};\\\", \\\"{x:1402,y:571,t:1527876634639};\\\", \\\"{x:1379,y:589,t:1527876634653};\\\", \\\"{x:1362,y:600,t:1527876634670};\\\", \\\"{x:1346,y:613,t:1527876634687};\\\", \\\"{x:1337,y:619,t:1527876634703};\\\", \\\"{x:1330,y:626,t:1527876634719};\\\", \\\"{x:1327,y:629,t:1527876634737};\\\", \\\"{x:1325,y:630,t:1527876634754};\\\", \\\"{x:1325,y:631,t:1527876635009};\\\", \\\"{x:1324,y:631,t:1527876635021};\\\", \\\"{x:1323,y:632,t:1527876635080};\\\", \\\"{x:1321,y:632,t:1527876635113};\\\", \\\"{x:1320,y:632,t:1527876635136};\\\", \\\"{x:1319,y:633,t:1527876635196};\\\", \\\"{x:1318,y:633,t:1527876635279};\\\", \\\"{x:1317,y:633,t:1527876635384};\\\", \\\"{x:1317,y:632,t:1527876635608};\\\", \\\"{x:1317,y:626,t:1527876635622};\\\", \\\"{x:1317,y:607,t:1527876635640};\\\", \\\"{x:1315,y:585,t:1527876635654};\\\", \\\"{x:1312,y:564,t:1527876635671};\\\", \\\"{x:1312,y:556,t:1527876635687};\\\", \\\"{x:1312,y:551,t:1527876635705};\\\", \\\"{x:1312,y:548,t:1527876635721};\\\", \\\"{x:1312,y:546,t:1527876635740};\\\", \\\"{x:1312,y:545,t:1527876635754};\\\", \\\"{x:1312,y:543,t:1527876635784};\\\", \\\"{x:1312,y:542,t:1527876635808};\\\", \\\"{x:1312,y:540,t:1527876635832};\\\", \\\"{x:1312,y:539,t:1527876635848};\\\", \\\"{x:1312,y:537,t:1527876635864};\\\", \\\"{x:1312,y:535,t:1527876635872};\\\", \\\"{x:1312,y:530,t:1527876635888};\\\", \\\"{x:1312,y:525,t:1527876635904};\\\", \\\"{x:1313,y:515,t:1527876635922};\\\", \\\"{x:1313,y:505,t:1527876635939};\\\", \\\"{x:1313,y:498,t:1527876635958};\\\", \\\"{x:1313,y:491,t:1527876635971};\\\", \\\"{x:1313,y:487,t:1527876635989};\\\", \\\"{x:1313,y:483,t:1527876636005};\\\", \\\"{x:1313,y:481,t:1527876636021};\\\", \\\"{x:1313,y:480,t:1527876636038};\\\", \\\"{x:1314,y:479,t:1527876636063};\\\", \\\"{x:1315,y:478,t:1527876636095};\\\", \\\"{x:1316,y:478,t:1527876636216};\\\", \\\"{x:1316,y:480,t:1527876636232};\\\", \\\"{x:1316,y:481,t:1527876636247};\\\", \\\"{x:1316,y:483,t:1527876636264};\\\", \\\"{x:1316,y:484,t:1527876636280};\\\", \\\"{x:1316,y:486,t:1527876636288};\\\", \\\"{x:1316,y:487,t:1527876636305};\\\", \\\"{x:1316,y:489,t:1527876636322};\\\", \\\"{x:1316,y:490,t:1527876636338};\\\", \\\"{x:1316,y:491,t:1527876636359};\\\", \\\"{x:1315,y:491,t:1527876636576};\\\", \\\"{x:1317,y:491,t:1527876636713};\\\", \\\"{x:1324,y:487,t:1527876636726};\\\", \\\"{x:1343,y:479,t:1527876636739};\\\", \\\"{x:1372,y:466,t:1527876636755};\\\", \\\"{x:1394,y:461,t:1527876636772};\\\", \\\"{x:1406,y:456,t:1527876636789};\\\", \\\"{x:1409,y:456,t:1527876636805};\\\", \\\"{x:1410,y:456,t:1527876636822};\\\", \\\"{x:1410,y:455,t:1527876636903};\\\", \\\"{x:1410,y:454,t:1527876636919};\\\", \\\"{x:1410,y:453,t:1527876636928};\\\", \\\"{x:1410,y:452,t:1527876636951};\\\", \\\"{x:1410,y:451,t:1527876636959};\\\", \\\"{x:1410,y:449,t:1527876636972};\\\", \\\"{x:1410,y:447,t:1527876636990};\\\", \\\"{x:1409,y:444,t:1527876637005};\\\", \\\"{x:1409,y:441,t:1527876637023};\\\", \\\"{x:1409,y:437,t:1527876637039};\\\", \\\"{x:1409,y:434,t:1527876637055};\\\", \\\"{x:1409,y:433,t:1527876637072};\\\", \\\"{x:1409,y:431,t:1527876637092};\\\", \\\"{x:1411,y:429,t:1527876637105};\\\", \\\"{x:1412,y:428,t:1527876637122};\\\", \\\"{x:1413,y:427,t:1527876637139};\\\", \\\"{x:1414,y:427,t:1527876637159};\\\", \\\"{x:1428,y:423,t:1527876637721};\\\", \\\"{x:1548,y:378,t:1527876637740};\\\", \\\"{x:1685,y:368,t:1527876637756};\\\", \\\"{x:1782,y:368,t:1527876637774};\\\", \\\"{x:1828,y:368,t:1527876637789};\\\", \\\"{x:1851,y:371,t:1527876637806};\\\", \\\"{x:1862,y:375,t:1527876637824};\\\", \\\"{x:1863,y:375,t:1527876637936};\\\", \\\"{x:1862,y:377,t:1527876637944};\\\", \\\"{x:1855,y:378,t:1527876637956};\\\", \\\"{x:1836,y:387,t:1527876637974};\\\", \\\"{x:1815,y:396,t:1527876637990};\\\", \\\"{x:1793,y:407,t:1527876638007};\\\", \\\"{x:1761,y:423,t:1527876638024};\\\", \\\"{x:1740,y:430,t:1527876638040};\\\", \\\"{x:1722,y:436,t:1527876638057};\\\", \\\"{x:1708,y:441,t:1527876638073};\\\", \\\"{x:1691,y:446,t:1527876638090};\\\", \\\"{x:1677,y:448,t:1527876638106};\\\", \\\"{x:1671,y:448,t:1527876638123};\\\", \\\"{x:1668,y:448,t:1527876638140};\\\", \\\"{x:1664,y:447,t:1527876638156};\\\", \\\"{x:1657,y:444,t:1527876638173};\\\", \\\"{x:1654,y:443,t:1527876638191};\\\", \\\"{x:1650,y:442,t:1527876638206};\\\", \\\"{x:1649,y:440,t:1527876638224};\\\", \\\"{x:1648,y:440,t:1527876638240};\\\", \\\"{x:1646,y:440,t:1527876638257};\\\", \\\"{x:1642,y:438,t:1527876638273};\\\", \\\"{x:1640,y:437,t:1527876638291};\\\", \\\"{x:1637,y:436,t:1527876638307};\\\", \\\"{x:1632,y:434,t:1527876638323};\\\", \\\"{x:1628,y:433,t:1527876638341};\\\", \\\"{x:1624,y:433,t:1527876638356};\\\", \\\"{x:1621,y:433,t:1527876638374};\\\", \\\"{x:1619,y:433,t:1527876638395};\\\", \\\"{x:1618,y:433,t:1527876638406};\\\", \\\"{x:1617,y:433,t:1527876638439};\\\", \\\"{x:1616,y:433,t:1527876638744};\\\", \\\"{x:1616,y:424,t:1527876638761};\\\", \\\"{x:1616,y:408,t:1527876638774};\\\", \\\"{x:1612,y:335,t:1527876638790};\\\", \\\"{x:1590,y:231,t:1527876638807};\\\", \\\"{x:1578,y:198,t:1527876638823};\\\", \\\"{x:1569,y:185,t:1527876638840};\\\", \\\"{x:1568,y:183,t:1527876638857};\\\", \\\"{x:1567,y:183,t:1527876638879};\\\", \\\"{x:1566,y:183,t:1527876638928};\\\", \\\"{x:1565,y:183,t:1527876638984};\\\", \\\"{x:1562,y:183,t:1527876638992};\\\", \\\"{x:1550,y:183,t:1527876639008};\\\", \\\"{x:1537,y:181,t:1527876639024};\\\", \\\"{x:1530,y:180,t:1527876639040};\\\", \\\"{x:1526,y:178,t:1527876639058};\\\", \\\"{x:1524,y:178,t:1527876639075};\\\", \\\"{x:1523,y:177,t:1527876639091};\\\", \\\"{x:1519,y:176,t:1527876639108};\\\", \\\"{x:1511,y:171,t:1527876639124};\\\", \\\"{x:1503,y:167,t:1527876639141};\\\", \\\"{x:1502,y:166,t:1527876639158};\\\", \\\"{x:1501,y:166,t:1527876639184};\\\", \\\"{x:1499,y:166,t:1527876639240};\\\", \\\"{x:1499,y:165,t:1527876639258};\\\", \\\"{x:1498,y:164,t:1527876639275};\\\", \\\"{x:1496,y:164,t:1527876639401};\\\", \\\"{x:1493,y:165,t:1527876639408};\\\", \\\"{x:1490,y:166,t:1527876639424};\\\", \\\"{x:1488,y:166,t:1527876639441};\\\", \\\"{x:1487,y:166,t:1527876639458};\\\", \\\"{x:1486,y:166,t:1527876639475};\\\", \\\"{x:1485,y:166,t:1527876639527};\\\", \\\"{x:1484,y:166,t:1527876639879};\\\", \\\"{x:1476,y:169,t:1527876639892};\\\", \\\"{x:1455,y:180,t:1527876639908};\\\", \\\"{x:1413,y:206,t:1527876639924};\\\", \\\"{x:1347,y:269,t:1527876639941};\\\", \\\"{x:1228,y:372,t:1527876639958};\\\", \\\"{x:1085,y:490,t:1527876639974};\\\", \\\"{x:892,y:652,t:1527876639990};\\\", \\\"{x:786,y:731,t:1527876640008};\\\", \\\"{x:714,y:778,t:1527876640024};\\\", \\\"{x:657,y:809,t:1527876640041};\\\", \\\"{x:622,y:827,t:1527876640058};\\\", \\\"{x:612,y:832,t:1527876640074};\\\", \\\"{x:603,y:836,t:1527876640091};\\\", \\\"{x:597,y:839,t:1527876640107};\\\", \\\"{x:587,y:844,t:1527876640124};\\\", \\\"{x:575,y:849,t:1527876640141};\\\", \\\"{x:560,y:852,t:1527876640158};\\\", \\\"{x:549,y:852,t:1527876640174};\\\", \\\"{x:540,y:845,t:1527876640191};\\\", \\\"{x:529,y:827,t:1527876640208};\\\", \\\"{x:519,y:807,t:1527876640225};\\\", \\\"{x:513,y:793,t:1527876640241};\\\", \\\"{x:508,y:782,t:1527876640258};\\\", \\\"{x:507,y:777,t:1527876640275};\\\", \\\"{x:505,y:775,t:1527876640291};\\\", \\\"{x:504,y:773,t:1527876640308};\\\", \\\"{x:504,y:771,t:1527876640503};\\\", \\\"{x:504,y:767,t:1527876640511};\\\", \\\"{x:504,y:762,t:1527876640525};\\\", \\\"{x:506,y:757,t:1527876640541};\\\", \\\"{x:508,y:753,t:1527876640558};\\\", \\\"{x:516,y:748,t:1527876640575};\\\", \\\"{x:518,y:747,t:1527876640591};\\\", \\\"{x:518,y:750,t:1527876641287};\\\", \\\"{x:518,y:764,t:1527876641294};\\\", \\\"{x:513,y:786,t:1527876641309};\\\", \\\"{x:494,y:863,t:1527876641325};\\\", \\\"{x:471,y:991,t:1527876641341};\\\", \\\"{x:438,y:1199,t:1527876641359};\\\", \\\"{x:422,y:1199,t:1527876641375};\\\", \\\"{x:462,y:1199,t:1527876641392};\\\", \\\"{x:545,y:1199,t:1527876641409};\\\", \\\"{x:652,y:1199,t:1527876641425};\\\", \\\"{x:778,y:1199,t:1527876641442};\\\", \\\"{x:908,y:1199,t:1527876641459};\\\", \\\"{x:1030,y:1199,t:1527876641476};\\\", \\\"{x:1152,y:1199,t:1527876641492};\\\", \\\"{x:1258,y:1199,t:1527876641509};\\\", \\\"{x:1347,y:1184,t:1527876641525};\\\", \\\"{x:1432,y:1135,t:1527876641542};\\\", \\\"{x:1539,y:1038,t:1527876641559};\\\", \\\"{x:1586,y:978,t:1527876641576};\\\", \\\"{x:1624,y:915,t:1527876641592};\\\", \\\"{x:1656,y:850,t:1527876641609};\\\", \\\"{x:1685,y:761,t:1527876641626};\\\", \\\"{x:1706,y:676,t:1527876641642};\\\", \\\"{x:1708,y:589,t:1527876641659};\\\", \\\"{x:1699,y:501,t:1527876641676};\\\", \\\"{x:1672,y:412,t:1527876641692};\\\", \\\"{x:1612,y:326,t:1527876641709};\\\", \\\"{x:1546,y:256,t:1527876641726};\\\", \\\"{x:1472,y:196,t:1527876641742};\\\", \\\"{x:1343,y:119,t:1527876641759};\\\", \\\"{x:1247,y:81,t:1527876641776};\\\", \\\"{x:1145,y:36,t:1527876641792};\\\", \\\"{x:1040,y:0,t:1527876641810};\\\", \\\"{x:944,y:0,t:1527876641826};\\\", \\\"{x:842,y:0,t:1527876641842};\\\", \\\"{x:761,y:0,t:1527876641861};\\\", \\\"{x:698,y:0,t:1527876641876};\\\", \\\"{x:652,y:0,t:1527876641892};\\\", \\\"{x:627,y:8,t:1527876641909};\\\", \\\"{x:615,y:13,t:1527876641926};\\\", \\\"{x:608,y:17,t:1527876641942};\\\" ] }, { \\\"rt\\\": 27016, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 276449, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"2ZXKM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 2.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"Z\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-G -C -C -A -Z -Z -Z -Z -A -C -F -F -F -H -H -I -J -D -U \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:568,y:157,t:1527876642088};\\\", \\\"{x:568,y:182,t:1527876642095};\\\", \\\"{x:568,y:214,t:1527876642114};\\\", \\\"{x:568,y:224,t:1527876642126};\\\", \\\"{x:578,y:259,t:1527876642142};\\\", \\\"{x:589,y:284,t:1527876642159};\\\", \\\"{x:602,y:306,t:1527876642176};\\\", \\\"{x:612,y:321,t:1527876642193};\\\", \\\"{x:620,y:328,t:1527876642209};\\\", \\\"{x:623,y:331,t:1527876642226};\\\", \\\"{x:625,y:332,t:1527876642243};\\\", \\\"{x:626,y:333,t:1527876642276};\\\", \\\"{x:626,y:351,t:1527876642471};\\\", \\\"{x:617,y:375,t:1527876642479};\\\", \\\"{x:606,y:408,t:1527876642493};\\\", \\\"{x:575,y:468,t:1527876642511};\\\", \\\"{x:540,y:525,t:1527876642526};\\\", \\\"{x:513,y:567,t:1527876642544};\\\", \\\"{x:509,y:579,t:1527876642561};\\\", \\\"{x:509,y:587,t:1527876642576};\\\", \\\"{x:509,y:594,t:1527876642643};\\\", \\\"{x:511,y:594,t:1527876642679};\\\", \\\"{x:514,y:593,t:1527876642695};\\\", \\\"{x:515,y:592,t:1527876642710};\\\", \\\"{x:522,y:582,t:1527876642726};\\\", \\\"{x:545,y:550,t:1527876642744};\\\", \\\"{x:575,y:508,t:1527876642761};\\\", \\\"{x:604,y:468,t:1527876642778};\\\", \\\"{x:642,y:415,t:1527876642794};\\\", \\\"{x:688,y:350,t:1527876642810};\\\", \\\"{x:729,y:301,t:1527876642827};\\\", \\\"{x:786,y:242,t:1527876642843};\\\", \\\"{x:848,y:193,t:1527876642860};\\\", \\\"{x:924,y:140,t:1527876642877};\\\", \\\"{x:988,y:97,t:1527876642895};\\\", \\\"{x:1030,y:66,t:1527876642910};\\\", \\\"{x:1062,y:45,t:1527876642927};\\\", \\\"{x:1065,y:42,t:1527876642944};\\\", \\\"{x:1066,y:41,t:1527876642960};\\\", \\\"{x:1067,y:39,t:1527876642978};\\\", \\\"{x:1067,y:35,t:1527876642995};\\\", \\\"{x:1067,y:31,t:1527876643010};\\\", \\\"{x:1065,y:28,t:1527876643027};\\\", \\\"{x:1059,y:25,t:1527876643045};\\\", \\\"{x:1050,y:25,t:1527876643061};\\\", \\\"{x:1032,y:25,t:1527876643077};\\\", \\\"{x:1013,y:25,t:1527876643094};\\\", \\\"{x:975,y:25,t:1527876643111};\\\", \\\"{x:934,y:25,t:1527876643128};\\\", \\\"{x:886,y:25,t:1527876643144};\\\", \\\"{x:855,y:25,t:1527876643161};\\\", \\\"{x:820,y:23,t:1527876643177};\\\", \\\"{x:781,y:19,t:1527876643194};\\\", \\\"{x:751,y:19,t:1527876643211};\\\", \\\"{x:719,y:19,t:1527876643228};\\\", \\\"{x:656,y:23,t:1527876643244};\\\", \\\"{x:571,y:44,t:1527876643261};\\\", \\\"{x:474,y:86,t:1527876643278};\\\", \\\"{x:377,y:135,t:1527876643294};\\\", \\\"{x:277,y:199,t:1527876643311};\\\", \\\"{x:250,y:222,t:1527876643328};\\\", \\\"{x:243,y:235,t:1527876643344};\\\", \\\"{x:237,y:246,t:1527876643361};\\\", \\\"{x:234,y:259,t:1527876643378};\\\", \\\"{x:230,y:269,t:1527876643396};\\\", \\\"{x:229,y:284,t:1527876643411};\\\", \\\"{x:229,y:305,t:1527876643428};\\\", \\\"{x:229,y:327,t:1527876643445};\\\", \\\"{x:231,y:340,t:1527876643461};\\\", \\\"{x:236,y:353,t:1527876643478};\\\", \\\"{x:244,y:368,t:1527876643495};\\\", \\\"{x:245,y:372,t:1527876643512};\\\", \\\"{x:249,y:377,t:1527876643528};\\\", \\\"{x:249,y:378,t:1527876643545};\\\", \\\"{x:250,y:379,t:1527876643562};\\\", \\\"{x:250,y:374,t:1527876643856};\\\", \\\"{x:250,y:364,t:1527876643863};\\\", \\\"{x:247,y:341,t:1527876643880};\\\", \\\"{x:245,y:313,t:1527876643896};\\\", \\\"{x:245,y:288,t:1527876643912};\\\", \\\"{x:271,y:249,t:1527876643929};\\\", \\\"{x:366,y:206,t:1527876643947};\\\", \\\"{x:595,y:174,t:1527876643962};\\\", \\\"{x:970,y:174,t:1527876643980};\\\", \\\"{x:1449,y:228,t:1527876643997};\\\", \\\"{x:1915,y:299,t:1527876644014};\\\", \\\"{x:1919,y:367,t:1527876644029};\\\", \\\"{x:1919,y:415,t:1527876644044};\\\", \\\"{x:1919,y:450,t:1527876644061};\\\", \\\"{x:1919,y:463,t:1527876644078};\\\", \\\"{x:1919,y:464,t:1527876644096};\\\", \\\"{x:1919,y:465,t:1527876644112};\\\", \\\"{x:1905,y:468,t:1527876644129};\\\", \\\"{x:1806,y:481,t:1527876644145};\\\", \\\"{x:1670,y:500,t:1527876644162};\\\", \\\"{x:1545,y:519,t:1527876644178};\\\", \\\"{x:1438,y:543,t:1527876644195};\\\", \\\"{x:1333,y:570,t:1527876644212};\\\", \\\"{x:1247,y:581,t:1527876644229};\\\", \\\"{x:1197,y:588,t:1527876644245};\\\", \\\"{x:1172,y:594,t:1527876644261};\\\", \\\"{x:1155,y:598,t:1527876644279};\\\", \\\"{x:1149,y:600,t:1527876644295};\\\", \\\"{x:1146,y:600,t:1527876644311};\\\", \\\"{x:1149,y:600,t:1527876644472};\\\", \\\"{x:1151,y:599,t:1527876644480};\\\", \\\"{x:1153,y:598,t:1527876644495};\\\", \\\"{x:1161,y:594,t:1527876644512};\\\", \\\"{x:1165,y:592,t:1527876644529};\\\", \\\"{x:1167,y:591,t:1527876644545};\\\", \\\"{x:1175,y:591,t:1527876644921};\\\", \\\"{x:1190,y:600,t:1527876644929};\\\", \\\"{x:1237,y:621,t:1527876644946};\\\", \\\"{x:1297,y:645,t:1527876644963};\\\", \\\"{x:1383,y:666,t:1527876644979};\\\", \\\"{x:1457,y:686,t:1527876644996};\\\", \\\"{x:1541,y:712,t:1527876645012};\\\", \\\"{x:1599,y:727,t:1527876645029};\\\", \\\"{x:1636,y:738,t:1527876645046};\\\", \\\"{x:1653,y:746,t:1527876645063};\\\", \\\"{x:1655,y:747,t:1527876645079};\\\", \\\"{x:1651,y:747,t:1527876645305};\\\", \\\"{x:1646,y:746,t:1527876645313};\\\", \\\"{x:1636,y:745,t:1527876645330};\\\", \\\"{x:1626,y:745,t:1527876645346};\\\", \\\"{x:1619,y:744,t:1527876645362};\\\", \\\"{x:1613,y:742,t:1527876645379};\\\", \\\"{x:1610,y:742,t:1527876645396};\\\", \\\"{x:1607,y:741,t:1527876645412};\\\", \\\"{x:1604,y:740,t:1527876645429};\\\", \\\"{x:1603,y:739,t:1527876645446};\\\", \\\"{x:1600,y:737,t:1527876645463};\\\", \\\"{x:1598,y:735,t:1527876645479};\\\", \\\"{x:1594,y:731,t:1527876645495};\\\", \\\"{x:1590,y:728,t:1527876645513};\\\", \\\"{x:1587,y:726,t:1527876645529};\\\", \\\"{x:1582,y:723,t:1527876645545};\\\", \\\"{x:1571,y:715,t:1527876645563};\\\", \\\"{x:1559,y:708,t:1527876645580};\\\", \\\"{x:1547,y:702,t:1527876645596};\\\", \\\"{x:1535,y:696,t:1527876645613};\\\", \\\"{x:1527,y:690,t:1527876645630};\\\", \\\"{x:1519,y:688,t:1527876645646};\\\", \\\"{x:1511,y:684,t:1527876645662};\\\", \\\"{x:1501,y:680,t:1527876645680};\\\", \\\"{x:1494,y:676,t:1527876645695};\\\", \\\"{x:1483,y:671,t:1527876645713};\\\", \\\"{x:1471,y:666,t:1527876645730};\\\", \\\"{x:1465,y:664,t:1527876645746};\\\", \\\"{x:1457,y:662,t:1527876645763};\\\", \\\"{x:1453,y:660,t:1527876645780};\\\", \\\"{x:1451,y:660,t:1527876645797};\\\", \\\"{x:1450,y:659,t:1527876645813};\\\", \\\"{x:1449,y:659,t:1527876645830};\\\", \\\"{x:1448,y:659,t:1527876645896};\\\", \\\"{x:1447,y:659,t:1527876645913};\\\", \\\"{x:1446,y:659,t:1527876645930};\\\", \\\"{x:1445,y:660,t:1527876645946};\\\", \\\"{x:1444,y:661,t:1527876645968};\\\", \\\"{x:1443,y:662,t:1527876645984};\\\", \\\"{x:1442,y:662,t:1527876645997};\\\", \\\"{x:1441,y:664,t:1527876646013};\\\", \\\"{x:1440,y:665,t:1527876646030};\\\", \\\"{x:1440,y:667,t:1527876646048};\\\", \\\"{x:1439,y:667,t:1527876646063};\\\", \\\"{x:1438,y:669,t:1527876646079};\\\", \\\"{x:1438,y:670,t:1527876646097};\\\", \\\"{x:1436,y:671,t:1527876646112};\\\", \\\"{x:1436,y:672,t:1527876646130};\\\", \\\"{x:1435,y:672,t:1527876646146};\\\", \\\"{x:1435,y:674,t:1527876646162};\\\", \\\"{x:1433,y:674,t:1527876646191};\\\", \\\"{x:1431,y:676,t:1527876646247};\\\", \\\"{x:1429,y:676,t:1527876646262};\\\", \\\"{x:1423,y:679,t:1527876646279};\\\", \\\"{x:1418,y:682,t:1527876646296};\\\", \\\"{x:1413,y:683,t:1527876646312};\\\", \\\"{x:1407,y:687,t:1527876646329};\\\", \\\"{x:1402,y:690,t:1527876646347};\\\", \\\"{x:1398,y:693,t:1527876646363};\\\", \\\"{x:1395,y:695,t:1527876646379};\\\", \\\"{x:1391,y:699,t:1527876646397};\\\", \\\"{x:1383,y:706,t:1527876646413};\\\", \\\"{x:1371,y:719,t:1527876646430};\\\", \\\"{x:1359,y:733,t:1527876646446};\\\", \\\"{x:1343,y:755,t:1527876646464};\\\", \\\"{x:1334,y:768,t:1527876646480};\\\", \\\"{x:1325,y:776,t:1527876646497};\\\", \\\"{x:1313,y:786,t:1527876646514};\\\", \\\"{x:1294,y:796,t:1527876646529};\\\", \\\"{x:1279,y:802,t:1527876646547};\\\", \\\"{x:1266,y:806,t:1527876646564};\\\", \\\"{x:1257,y:808,t:1527876646580};\\\", \\\"{x:1249,y:812,t:1527876646596};\\\", \\\"{x:1245,y:815,t:1527876646614};\\\", \\\"{x:1244,y:816,t:1527876646630};\\\", \\\"{x:1242,y:817,t:1527876646712};\\\", \\\"{x:1241,y:817,t:1527876646720};\\\", \\\"{x:1238,y:817,t:1527876646730};\\\", \\\"{x:1236,y:817,t:1527876646747};\\\", \\\"{x:1234,y:817,t:1527876646764};\\\", \\\"{x:1233,y:817,t:1527876646784};\\\", \\\"{x:1232,y:817,t:1527876646816};\\\", \\\"{x:1231,y:818,t:1527876646840};\\\", \\\"{x:1230,y:818,t:1527876646863};\\\", \\\"{x:1229,y:819,t:1527876646881};\\\", \\\"{x:1228,y:821,t:1527876646897};\\\", \\\"{x:1227,y:822,t:1527876646914};\\\", \\\"{x:1226,y:823,t:1527876646931};\\\", \\\"{x:1225,y:824,t:1527876646968};\\\", \\\"{x:1224,y:824,t:1527876647024};\\\", \\\"{x:1222,y:824,t:1527876647056};\\\", \\\"{x:1221,y:824,t:1527876647096};\\\", \\\"{x:1220,y:824,t:1527876647119};\\\", \\\"{x:1219,y:824,t:1527876647135};\\\", \\\"{x:1219,y:825,t:1527876647160};\\\", \\\"{x:1218,y:825,t:1527876647238};\\\", \\\"{x:1215,y:825,t:1527876647246};\\\", \\\"{x:1206,y:825,t:1527876647264};\\\", \\\"{x:1200,y:825,t:1527876647281};\\\", \\\"{x:1196,y:825,t:1527876647295};\\\", \\\"{x:1195,y:825,t:1527876647312};\\\", \\\"{x:1194,y:825,t:1527876647329};\\\", \\\"{x:1194,y:826,t:1527876647503};\\\", \\\"{x:1195,y:828,t:1527876647513};\\\", \\\"{x:1203,y:831,t:1527876647529};\\\", \\\"{x:1208,y:833,t:1527876647546};\\\", \\\"{x:1211,y:834,t:1527876647564};\\\", \\\"{x:1212,y:835,t:1527876647579};\\\", \\\"{x:1213,y:835,t:1527876648328};\\\", \\\"{x:1220,y:840,t:1527876648348};\\\", \\\"{x:1231,y:842,t:1527876648364};\\\", \\\"{x:1242,y:844,t:1527876648382};\\\", \\\"{x:1252,y:848,t:1527876648397};\\\", \\\"{x:1263,y:848,t:1527876648414};\\\", \\\"{x:1271,y:848,t:1527876648431};\\\", \\\"{x:1274,y:848,t:1527876648448};\\\", \\\"{x:1277,y:848,t:1527876648464};\\\", \\\"{x:1280,y:848,t:1527876648481};\\\", \\\"{x:1282,y:848,t:1527876648498};\\\", \\\"{x:1284,y:848,t:1527876648515};\\\", \\\"{x:1285,y:848,t:1527876648532};\\\", \\\"{x:1287,y:848,t:1527876648548};\\\", \\\"{x:1289,y:848,t:1527876648564};\\\", \\\"{x:1289,y:846,t:1527876648632};\\\", \\\"{x:1285,y:843,t:1527876648649};\\\", \\\"{x:1282,y:839,t:1527876648664};\\\", \\\"{x:1280,y:837,t:1527876648681};\\\", \\\"{x:1280,y:836,t:1527876648728};\\\", \\\"{x:1280,y:835,t:1527876648752};\\\", \\\"{x:1281,y:834,t:1527876649184};\\\", \\\"{x:1283,y:834,t:1527876649199};\\\", \\\"{x:1296,y:842,t:1527876649218};\\\", \\\"{x:1305,y:848,t:1527876649231};\\\", \\\"{x:1310,y:850,t:1527876649248};\\\", \\\"{x:1313,y:853,t:1527876649265};\\\", \\\"{x:1318,y:857,t:1527876649281};\\\", \\\"{x:1322,y:861,t:1527876649299};\\\", \\\"{x:1327,y:864,t:1527876649315};\\\", \\\"{x:1331,y:867,t:1527876649331};\\\", \\\"{x:1334,y:870,t:1527876649349};\\\", \\\"{x:1335,y:871,t:1527876649365};\\\", \\\"{x:1336,y:871,t:1527876649391};\\\", \\\"{x:1337,y:872,t:1527876649415};\\\", \\\"{x:1339,y:874,t:1527876649433};\\\", \\\"{x:1343,y:877,t:1527876649449};\\\", \\\"{x:1349,y:882,t:1527876649466};\\\", \\\"{x:1352,y:883,t:1527876649483};\\\", \\\"{x:1354,y:885,t:1527876649499};\\\", \\\"{x:1354,y:886,t:1527876649515};\\\", \\\"{x:1355,y:887,t:1527876649533};\\\", \\\"{x:1357,y:891,t:1527876649548};\\\", \\\"{x:1361,y:895,t:1527876649565};\\\", \\\"{x:1364,y:899,t:1527876649583};\\\", \\\"{x:1367,y:903,t:1527876649599};\\\", \\\"{x:1367,y:904,t:1527876649704};\\\", \\\"{x:1364,y:904,t:1527876649719};\\\", \\\"{x:1361,y:903,t:1527876649733};\\\", \\\"{x:1357,y:903,t:1527876649749};\\\", \\\"{x:1355,y:902,t:1527876649766};\\\", \\\"{x:1354,y:902,t:1527876649783};\\\", \\\"{x:1354,y:901,t:1527876649799};\\\", \\\"{x:1353,y:901,t:1527876649864};\\\", \\\"{x:1352,y:901,t:1527876649872};\\\", \\\"{x:1351,y:901,t:1527876649883};\\\", \\\"{x:1345,y:899,t:1527876650720};\\\", \\\"{x:1301,y:881,t:1527876650750};\\\", \\\"{x:1200,y:839,t:1527876650767};\\\", \\\"{x:1102,y:799,t:1527876650783};\\\", \\\"{x:983,y:746,t:1527876650799};\\\", \\\"{x:845,y:687,t:1527876650817};\\\", \\\"{x:708,y:633,t:1527876650835};\\\", \\\"{x:582,y:588,t:1527876650851};\\\", \\\"{x:483,y:560,t:1527876650867};\\\", \\\"{x:429,y:544,t:1527876650883};\\\", \\\"{x:397,y:536,t:1527876650900};\\\", \\\"{x:385,y:533,t:1527876650916};\\\", \\\"{x:382,y:532,t:1527876650933};\\\", \\\"{x:380,y:531,t:1527876650949};\\\", \\\"{x:379,y:531,t:1527876651015};\\\", \\\"{x:376,y:533,t:1527876651023};\\\", \\\"{x:373,y:533,t:1527876651033};\\\", \\\"{x:367,y:537,t:1527876651050};\\\", \\\"{x:358,y:540,t:1527876651066};\\\", \\\"{x:345,y:543,t:1527876651084};\\\", \\\"{x:329,y:547,t:1527876651100};\\\", \\\"{x:318,y:549,t:1527876651117};\\\", \\\"{x:305,y:549,t:1527876651133};\\\", \\\"{x:300,y:549,t:1527876651150};\\\", \\\"{x:293,y:550,t:1527876651167};\\\", \\\"{x:292,y:551,t:1527876651184};\\\", \\\"{x:291,y:551,t:1527876651201};\\\", \\\"{x:287,y:554,t:1527876651217};\\\", \\\"{x:282,y:557,t:1527876651234};\\\", \\\"{x:272,y:563,t:1527876651253};\\\", \\\"{x:264,y:567,t:1527876651266};\\\", \\\"{x:259,y:568,t:1527876651283};\\\", \\\"{x:256,y:569,t:1527876651301};\\\", \\\"{x:254,y:570,t:1527876651317};\\\", \\\"{x:250,y:571,t:1527876651333};\\\", \\\"{x:246,y:572,t:1527876651351};\\\", \\\"{x:243,y:572,t:1527876651367};\\\", \\\"{x:240,y:574,t:1527876651384};\\\", \\\"{x:237,y:575,t:1527876651400};\\\", \\\"{x:233,y:576,t:1527876651416};\\\", \\\"{x:228,y:578,t:1527876651434};\\\", \\\"{x:226,y:578,t:1527876651450};\\\", \\\"{x:224,y:579,t:1527876651467};\\\", \\\"{x:220,y:580,t:1527876651484};\\\", \\\"{x:214,y:582,t:1527876651501};\\\", \\\"{x:208,y:583,t:1527876651516};\\\", \\\"{x:201,y:583,t:1527876651533};\\\", \\\"{x:196,y:584,t:1527876651550};\\\", \\\"{x:192,y:585,t:1527876651567};\\\", \\\"{x:190,y:586,t:1527876651584};\\\", \\\"{x:188,y:586,t:1527876651615};\\\", \\\"{x:187,y:586,t:1527876651631};\\\", \\\"{x:184,y:586,t:1527876651638};\\\", \\\"{x:183,y:586,t:1527876651651};\\\", \\\"{x:180,y:587,t:1527876651667};\\\", \\\"{x:178,y:588,t:1527876651683};\\\", \\\"{x:177,y:589,t:1527876651752};\\\", \\\"{x:179,y:589,t:1527876651975};\\\", \\\"{x:180,y:589,t:1527876651991};\\\", \\\"{x:181,y:589,t:1527876652000};\\\", \\\"{x:183,y:588,t:1527876652017};\\\", \\\"{x:184,y:587,t:1527876652034};\\\", \\\"{x:187,y:587,t:1527876652051};\\\", \\\"{x:192,y:586,t:1527876652067};\\\", \\\"{x:206,y:586,t:1527876652085};\\\", \\\"{x:233,y:587,t:1527876652100};\\\", \\\"{x:293,y:602,t:1527876652119};\\\", \\\"{x:491,y:632,t:1527876652135};\\\", \\\"{x:562,y:642,t:1527876652151};\\\", \\\"{x:722,y:664,t:1527876652169};\\\", \\\"{x:825,y:684,t:1527876652185};\\\", \\\"{x:933,y:713,t:1527876652201};\\\", \\\"{x:1073,y:749,t:1527876652218};\\\", \\\"{x:1228,y:794,t:1527876652234};\\\", \\\"{x:1374,y:833,t:1527876652252};\\\", \\\"{x:1492,y:858,t:1527876652267};\\\", \\\"{x:1573,y:869,t:1527876652285};\\\", \\\"{x:1610,y:872,t:1527876652301};\\\", \\\"{x:1622,y:872,t:1527876652318};\\\", \\\"{x:1624,y:872,t:1527876652335};\\\", \\\"{x:1624,y:868,t:1527876652351};\\\", \\\"{x:1612,y:853,t:1527876652368};\\\", \\\"{x:1597,y:842,t:1527876652385};\\\", \\\"{x:1593,y:841,t:1527876652402};\\\", \\\"{x:1588,y:840,t:1527876652418};\\\", \\\"{x:1577,y:838,t:1527876652435};\\\", \\\"{x:1558,y:838,t:1527876652452};\\\", \\\"{x:1535,y:838,t:1527876652468};\\\", \\\"{x:1503,y:845,t:1527876652485};\\\", \\\"{x:1464,y:855,t:1527876652502};\\\", \\\"{x:1428,y:866,t:1527876652519};\\\", \\\"{x:1381,y:879,t:1527876652535};\\\", \\\"{x:1357,y:886,t:1527876652552};\\\", \\\"{x:1335,y:892,t:1527876652569};\\\", \\\"{x:1318,y:895,t:1527876652586};\\\", \\\"{x:1309,y:895,t:1527876652602};\\\", \\\"{x:1306,y:895,t:1527876652619};\\\", \\\"{x:1305,y:895,t:1527876652696};\\\", \\\"{x:1307,y:895,t:1527876652720};\\\", \\\"{x:1309,y:895,t:1527876652736};\\\", \\\"{x:1314,y:895,t:1527876652754};\\\", \\\"{x:1321,y:895,t:1527876652770};\\\", \\\"{x:1328,y:895,t:1527876652786};\\\", \\\"{x:1329,y:895,t:1527876652803};\\\", \\\"{x:1330,y:895,t:1527876652823};\\\", \\\"{x:1331,y:895,t:1527876652840};\\\", \\\"{x:1333,y:895,t:1527876652856};\\\", \\\"{x:1335,y:895,t:1527876652870};\\\", \\\"{x:1337,y:895,t:1527876652886};\\\", \\\"{x:1339,y:896,t:1527876652903};\\\", \\\"{x:1341,y:897,t:1527876652921};\\\", \\\"{x:1342,y:897,t:1527876653193};\\\", \\\"{x:1343,y:897,t:1527876653204};\\\", \\\"{x:1345,y:897,t:1527876653219};\\\", \\\"{x:1347,y:897,t:1527876653236};\\\", \\\"{x:1350,y:897,t:1527876653251};\\\", \\\"{x:1351,y:896,t:1527876653268};\\\", \\\"{x:1352,y:896,t:1527876653295};\\\", \\\"{x:1352,y:895,t:1527876653640};\\\", \\\"{x:1352,y:894,t:1527876653653};\\\", \\\"{x:1352,y:891,t:1527876653671};\\\", \\\"{x:1350,y:886,t:1527876653685};\\\", \\\"{x:1347,y:881,t:1527876653702};\\\", \\\"{x:1343,y:877,t:1527876653718};\\\", \\\"{x:1342,y:876,t:1527876653742};\\\", \\\"{x:1340,y:876,t:1527876653767};\\\", \\\"{x:1338,y:876,t:1527876653783};\\\", \\\"{x:1336,y:876,t:1527876653791};\\\", \\\"{x:1334,y:875,t:1527876653803};\\\", \\\"{x:1331,y:873,t:1527876653819};\\\", \\\"{x:1326,y:872,t:1527876653836};\\\", \\\"{x:1322,y:871,t:1527876653853};\\\", \\\"{x:1318,y:870,t:1527876653869};\\\", \\\"{x:1314,y:868,t:1527876653885};\\\", \\\"{x:1308,y:865,t:1527876653903};\\\", \\\"{x:1307,y:864,t:1527876653919};\\\", \\\"{x:1303,y:862,t:1527876653936};\\\", \\\"{x:1296,y:856,t:1527876653953};\\\", \\\"{x:1291,y:852,t:1527876653969};\\\", \\\"{x:1285,y:845,t:1527876653986};\\\", \\\"{x:1283,y:844,t:1527876654003};\\\", \\\"{x:1283,y:843,t:1527876654019};\\\", \\\"{x:1283,y:842,t:1527876654056};\\\", \\\"{x:1283,y:841,t:1527876654087};\\\", \\\"{x:1282,y:841,t:1527876654344};\\\", \\\"{x:1282,y:840,t:1527876654359};\\\", \\\"{x:1282,y:839,t:1527876654384};\\\", \\\"{x:1281,y:836,t:1527876654391};\\\", \\\"{x:1277,y:834,t:1527876655027};\\\", \\\"{x:1271,y:834,t:1527876655036};\\\", \\\"{x:1266,y:834,t:1527876655053};\\\", \\\"{x:1262,y:834,t:1527876655070};\\\", \\\"{x:1247,y:834,t:1527876655087};\\\", \\\"{x:1238,y:831,t:1527876655102};\\\", \\\"{x:1234,y:831,t:1527876655120};\\\", \\\"{x:1230,y:830,t:1527876655137};\\\", \\\"{x:1226,y:829,t:1527876655153};\\\", \\\"{x:1222,y:829,t:1527876655170};\\\", \\\"{x:1219,y:829,t:1527876655188};\\\", \\\"{x:1219,y:828,t:1527876655204};\\\", \\\"{x:1225,y:824,t:1527876655658};\\\", \\\"{x:1239,y:818,t:1527876655671};\\\", \\\"{x:1248,y:814,t:1527876655687};\\\", \\\"{x:1264,y:808,t:1527876655703};\\\", \\\"{x:1283,y:801,t:1527876655721};\\\", \\\"{x:1304,y:791,t:1527876655737};\\\", \\\"{x:1314,y:785,t:1527876655754};\\\", \\\"{x:1320,y:781,t:1527876655771};\\\", \\\"{x:1324,y:778,t:1527876655787};\\\", \\\"{x:1325,y:777,t:1527876655804};\\\", \\\"{x:1327,y:777,t:1527876655821};\\\", \\\"{x:1329,y:775,t:1527876655837};\\\", \\\"{x:1331,y:775,t:1527876655853};\\\", \\\"{x:1332,y:775,t:1527876655871};\\\", \\\"{x:1333,y:774,t:1527876655887};\\\", \\\"{x:1335,y:774,t:1527876655904};\\\", \\\"{x:1336,y:774,t:1527876655921};\\\", \\\"{x:1341,y:772,t:1527876655938};\\\", \\\"{x:1345,y:771,t:1527876655954};\\\", \\\"{x:1357,y:770,t:1527876655971};\\\", \\\"{x:1367,y:769,t:1527876655988};\\\", \\\"{x:1371,y:769,t:1527876656004};\\\", \\\"{x:1374,y:769,t:1527876656021};\\\", \\\"{x:1377,y:769,t:1527876656037};\\\", \\\"{x:1378,y:768,t:1527876656056};\\\", \\\"{x:1384,y:766,t:1527876656071};\\\", \\\"{x:1386,y:766,t:1527876656087};\\\", \\\"{x:1388,y:765,t:1527876656104};\\\", \\\"{x:1390,y:764,t:1527876656134};\\\", \\\"{x:1391,y:764,t:1527876656159};\\\", \\\"{x:1391,y:762,t:1527876656288};\\\", \\\"{x:1391,y:760,t:1527876656304};\\\", \\\"{x:1390,y:759,t:1527876656320};\\\", \\\"{x:1390,y:758,t:1527876656338};\\\", \\\"{x:1389,y:757,t:1527876656354};\\\", \\\"{x:1387,y:757,t:1527876656371};\\\", \\\"{x:1386,y:757,t:1527876656711};\\\", \\\"{x:1385,y:757,t:1527876656721};\\\", \\\"{x:1384,y:757,t:1527876656738};\\\", \\\"{x:1383,y:757,t:1527876656792};\\\", \\\"{x:1382,y:757,t:1527876656805};\\\", \\\"{x:1380,y:757,t:1527876656822};\\\", \\\"{x:1379,y:757,t:1527876656840};\\\", \\\"{x:1378,y:758,t:1527876656860};\\\", \\\"{x:1377,y:758,t:1527876656888};\\\", \\\"{x:1367,y:758,t:1527876657200};\\\", \\\"{x:1338,y:756,t:1527876657208};\\\", \\\"{x:1294,y:749,t:1527876657221};\\\", \\\"{x:1158,y:728,t:1527876657238};\\\", \\\"{x:872,y:652,t:1527876657254};\\\", \\\"{x:666,y:601,t:1527876657272};\\\", \\\"{x:483,y:572,t:1527876657289};\\\", \\\"{x:341,y:550,t:1527876657304};\\\", \\\"{x:250,y:537,t:1527876657322};\\\", \\\"{x:204,y:529,t:1527876657338};\\\", \\\"{x:186,y:524,t:1527876657354};\\\", \\\"{x:184,y:523,t:1527876657371};\\\", \\\"{x:186,y:525,t:1527876657503};\\\", \\\"{x:197,y:529,t:1527876657511};\\\", \\\"{x:218,y:536,t:1527876657521};\\\", \\\"{x:287,y:567,t:1527876657540};\\\", \\\"{x:368,y:605,t:1527876657557};\\\", \\\"{x:440,y:643,t:1527876657573};\\\", \\\"{x:495,y:673,t:1527876657590};\\\", \\\"{x:519,y:685,t:1527876657607};\\\", \\\"{x:525,y:689,t:1527876657622};\\\", \\\"{x:526,y:689,t:1527876657639};\\\", \\\"{x:527,y:686,t:1527876657729};\\\", \\\"{x:522,y:676,t:1527876657739};\\\", \\\"{x:504,y:648,t:1527876657755};\\\", \\\"{x:489,y:624,t:1527876657772};\\\", \\\"{x:485,y:618,t:1527876657788};\\\", \\\"{x:481,y:613,t:1527876657806};\\\", \\\"{x:479,y:611,t:1527876657822};\\\", \\\"{x:477,y:611,t:1527876657839};\\\", \\\"{x:476,y:611,t:1527876657919};\\\", \\\"{x:474,y:611,t:1527876657927};\\\", \\\"{x:473,y:611,t:1527876657951};\\\", \\\"{x:470,y:611,t:1527876657967};\\\", \\\"{x:466,y:611,t:1527876657975};\\\", \\\"{x:462,y:611,t:1527876657989};\\\", \\\"{x:457,y:611,t:1527876658005};\\\", \\\"{x:450,y:611,t:1527876658023};\\\", \\\"{x:446,y:609,t:1527876658040};\\\", \\\"{x:443,y:608,t:1527876658056};\\\", \\\"{x:441,y:607,t:1527876658073};\\\", \\\"{x:438,y:606,t:1527876658089};\\\", \\\"{x:434,y:604,t:1527876658106};\\\", \\\"{x:430,y:602,t:1527876658123};\\\", \\\"{x:429,y:601,t:1527876658139};\\\", \\\"{x:428,y:601,t:1527876658156};\\\", \\\"{x:426,y:601,t:1527876658760};\\\", \\\"{x:422,y:600,t:1527876658773};\\\", \\\"{x:416,y:596,t:1527876658791};\\\", \\\"{x:411,y:594,t:1527876658806};\\\", \\\"{x:410,y:593,t:1527876658822};\\\", \\\"{x:409,y:593,t:1527876658895};\\\", \\\"{x:407,y:593,t:1527876658907};\\\", \\\"{x:404,y:593,t:1527876658922};\\\", \\\"{x:402,y:594,t:1527876659310};\\\", \\\"{x:401,y:594,t:1527876659322};\\\", \\\"{x:400,y:594,t:1527876659340};\\\", \\\"{x:396,y:597,t:1527876659357};\\\", \\\"{x:392,y:597,t:1527876659373};\\\", \\\"{x:388,y:598,t:1527876659390};\\\", \\\"{x:387,y:599,t:1527876659407};\\\", \\\"{x:390,y:599,t:1527876659534};\\\", \\\"{x:402,y:599,t:1527876659543};\\\", \\\"{x:423,y:599,t:1527876659557};\\\", \\\"{x:503,y:599,t:1527876659574};\\\", \\\"{x:623,y:599,t:1527876659590};\\\", \\\"{x:833,y:599,t:1527876659607};\\\", \\\"{x:971,y:599,t:1527876659624};\\\", \\\"{x:1090,y:599,t:1527876659639};\\\", \\\"{x:1196,y:599,t:1527876659657};\\\", \\\"{x:1279,y:599,t:1527876659674};\\\", \\\"{x:1359,y:599,t:1527876659690};\\\", \\\"{x:1418,y:599,t:1527876659707};\\\", \\\"{x:1435,y:599,t:1527876659724};\\\", \\\"{x:1441,y:598,t:1527876659741};\\\", \\\"{x:1442,y:597,t:1527876659757};\\\", \\\"{x:1444,y:599,t:1527876659832};\\\", \\\"{x:1444,y:601,t:1527876659841};\\\", \\\"{x:1444,y:604,t:1527876659859};\\\", \\\"{x:1444,y:605,t:1527876659875};\\\", \\\"{x:1444,y:607,t:1527876659891};\\\", \\\"{x:1444,y:608,t:1527876659920};\\\", \\\"{x:1439,y:602,t:1527876660134};\\\", \\\"{x:1431,y:594,t:1527876660143};\\\", \\\"{x:1412,y:583,t:1527876660158};\\\", \\\"{x:1405,y:579,t:1527876660175};\\\", \\\"{x:1402,y:578,t:1527876660192};\\\", \\\"{x:1400,y:576,t:1527876660208};\\\", \\\"{x:1399,y:575,t:1527876660238};\\\", \\\"{x:1398,y:574,t:1527876660247};\\\", \\\"{x:1397,y:573,t:1527876660263};\\\", \\\"{x:1396,y:573,t:1527876660276};\\\", \\\"{x:1396,y:572,t:1527876660293};\\\", \\\"{x:1396,y:571,t:1527876660310};\\\", \\\"{x:1396,y:570,t:1527876660326};\\\", \\\"{x:1396,y:569,t:1527876660343};\\\", \\\"{x:1396,y:567,t:1527876660360};\\\", \\\"{x:1398,y:566,t:1527876660377};\\\", \\\"{x:1399,y:566,t:1527876660393};\\\", \\\"{x:1402,y:566,t:1527876660410};\\\", \\\"{x:1403,y:566,t:1527876660427};\\\", \\\"{x:1405,y:566,t:1527876660444};\\\", \\\"{x:1406,y:566,t:1527876660461};\\\", \\\"{x:1407,y:567,t:1527876660477};\\\", \\\"{x:1408,y:569,t:1527876660544};\\\", \\\"{x:1409,y:570,t:1527876660807};\\\", \\\"{x:1410,y:572,t:1527876660815};\\\", \\\"{x:1410,y:573,t:1527876660828};\\\", \\\"{x:1410,y:574,t:1527876660968};\\\", \\\"{x:1409,y:576,t:1527876660980};\\\", \\\"{x:1408,y:578,t:1527876660997};\\\", \\\"{x:1408,y:579,t:1527876661014};\\\", \\\"{x:1407,y:580,t:1527876661029};\\\", \\\"{x:1407,y:577,t:1527876661128};\\\", \\\"{x:1405,y:571,t:1527876661135};\\\", \\\"{x:1405,y:568,t:1527876661146};\\\", \\\"{x:1404,y:564,t:1527876661163};\\\", \\\"{x:1404,y:562,t:1527876661180};\\\", \\\"{x:1404,y:561,t:1527876661197};\\\", \\\"{x:1403,y:560,t:1527876661214};\\\", \\\"{x:1404,y:559,t:1527876661464};\\\", \\\"{x:1406,y:558,t:1527876661481};\\\", \\\"{x:1407,y:557,t:1527876661816};\\\", \\\"{x:1408,y:556,t:1527876661911};\\\", \\\"{x:1408,y:555,t:1527876662040};\\\", \\\"{x:1410,y:555,t:1527876662096};\\\", \\\"{x:1411,y:555,t:1527876662111};\\\", \\\"{x:1412,y:555,t:1527876662120};\\\", \\\"{x:1413,y:556,t:1527876662135};\\\", \\\"{x:1414,y:556,t:1527876662248};\\\", \\\"{x:1414,y:557,t:1527876662256};\\\", \\\"{x:1414,y:558,t:1527876662268};\\\", \\\"{x:1414,y:561,t:1527876662283};\\\", \\\"{x:1414,y:563,t:1527876662544};\\\", \\\"{x:1414,y:564,t:1527876662559};\\\", \\\"{x:1413,y:565,t:1527876662576};\\\", \\\"{x:1376,y:625,t:1527876663743};\\\", \\\"{x:1324,y:716,t:1527876663760};\\\", \\\"{x:1264,y:799,t:1527876663777};\\\", \\\"{x:1208,y:875,t:1527876663794};\\\", \\\"{x:1180,y:914,t:1527876663810};\\\", \\\"{x:1178,y:923,t:1527876663827};\\\", \\\"{x:1178,y:925,t:1527876663844};\\\", \\\"{x:1177,y:926,t:1527876663968};\\\", \\\"{x:1176,y:926,t:1527876663977};\\\", \\\"{x:1176,y:909,t:1527876663994};\\\", \\\"{x:1176,y:890,t:1527876664010};\\\", \\\"{x:1176,y:868,t:1527876664027};\\\", \\\"{x:1176,y:848,t:1527876664044};\\\", \\\"{x:1176,y:826,t:1527876664061};\\\", \\\"{x:1176,y:803,t:1527876664077};\\\", \\\"{x:1179,y:763,t:1527876664094};\\\", \\\"{x:1193,y:706,t:1527876664111};\\\", \\\"{x:1212,y:595,t:1527876664127};\\\", \\\"{x:1221,y:531,t:1527876664145};\\\", \\\"{x:1224,y:498,t:1527876664160};\\\", \\\"{x:1226,y:487,t:1527876664177};\\\", \\\"{x:1226,y:484,t:1527876664194};\\\", \\\"{x:1226,y:483,t:1527876664211};\\\", \\\"{x:1227,y:482,t:1527876664228};\\\", \\\"{x:1227,y:481,t:1527876664256};\\\", \\\"{x:1227,y:479,t:1527876664263};\\\", \\\"{x:1229,y:475,t:1527876664278};\\\", \\\"{x:1236,y:468,t:1527876664294};\\\", \\\"{x:1244,y:461,t:1527876664310};\\\", \\\"{x:1245,y:461,t:1527876664327};\\\", \\\"{x:1246,y:461,t:1527876664344};\\\", \\\"{x:1252,y:463,t:1527876664361};\\\", \\\"{x:1260,y:474,t:1527876664377};\\\", \\\"{x:1264,y:481,t:1527876664394};\\\", \\\"{x:1265,y:489,t:1527876664411};\\\", \\\"{x:1270,y:498,t:1527876664427};\\\", \\\"{x:1274,y:505,t:1527876664444};\\\", \\\"{x:1278,y:510,t:1527876664461};\\\", \\\"{x:1280,y:513,t:1527876664477};\\\", \\\"{x:1281,y:514,t:1527876664494};\\\", \\\"{x:1282,y:514,t:1527876664528};\\\", \\\"{x:1285,y:514,t:1527876664544};\\\", \\\"{x:1291,y:514,t:1527876664562};\\\", \\\"{x:1297,y:514,t:1527876664577};\\\", \\\"{x:1302,y:512,t:1527876664594};\\\", \\\"{x:1306,y:510,t:1527876664612};\\\", \\\"{x:1307,y:509,t:1527876664680};\\\", \\\"{x:1308,y:509,t:1527876664695};\\\", \\\"{x:1309,y:509,t:1527876664712};\\\", \\\"{x:1310,y:507,t:1527876664912};\\\", \\\"{x:1311,y:506,t:1527876664928};\\\", \\\"{x:1311,y:504,t:1527876664945};\\\", \\\"{x:1311,y:502,t:1527876664962};\\\", \\\"{x:1311,y:501,t:1527876664981};\\\", \\\"{x:1311,y:500,t:1527876664994};\\\", \\\"{x:1312,y:499,t:1527876665014};\\\", \\\"{x:1312,y:498,t:1527876665030};\\\", \\\"{x:1312,y:497,t:1527876665045};\\\", \\\"{x:1312,y:496,t:1527876665063};\\\", \\\"{x:1312,y:495,t:1527876665134};\\\", \\\"{x:1313,y:493,t:1527876665144};\\\", \\\"{x:1322,y:482,t:1527876665162};\\\", \\\"{x:1334,y:469,t:1527876665178};\\\", \\\"{x:1348,y:457,t:1527876665195};\\\", \\\"{x:1360,y:447,t:1527876665211};\\\", \\\"{x:1372,y:441,t:1527876665228};\\\", \\\"{x:1383,y:436,t:1527876665245};\\\", \\\"{x:1389,y:434,t:1527876665261};\\\", \\\"{x:1392,y:433,t:1527876665278};\\\", \\\"{x:1397,y:432,t:1527876665294};\\\", \\\"{x:1398,y:431,t:1527876665319};\\\", \\\"{x:1400,y:431,t:1527876665512};\\\", \\\"{x:1408,y:428,t:1527876665528};\\\", \\\"{x:1412,y:428,t:1527876665546};\\\", \\\"{x:1418,y:427,t:1527876665562};\\\", \\\"{x:1423,y:427,t:1527876665578};\\\", \\\"{x:1424,y:427,t:1527876665595};\\\", \\\"{x:1425,y:428,t:1527876665612};\\\", \\\"{x:1425,y:429,t:1527876665628};\\\", \\\"{x:1425,y:432,t:1527876665645};\\\", \\\"{x:1427,y:435,t:1527876665662};\\\", \\\"{x:1427,y:436,t:1527876665678};\\\", \\\"{x:1428,y:438,t:1527876665696};\\\", \\\"{x:1428,y:439,t:1527876665752};\\\", \\\"{x:1428,y:440,t:1527876665928};\\\", \\\"{x:1426,y:440,t:1527876665944};\\\", \\\"{x:1423,y:440,t:1527876665951};\\\", \\\"{x:1421,y:440,t:1527876665962};\\\", \\\"{x:1419,y:440,t:1527876665979};\\\", \\\"{x:1426,y:438,t:1527876666103};\\\", \\\"{x:1437,y:436,t:1527876666112};\\\", \\\"{x:1458,y:430,t:1527876666129};\\\", \\\"{x:1481,y:421,t:1527876666145};\\\", \\\"{x:1505,y:417,t:1527876666162};\\\", \\\"{x:1525,y:414,t:1527876666179};\\\", \\\"{x:1539,y:414,t:1527876666195};\\\", \\\"{x:1544,y:414,t:1527876666212};\\\", \\\"{x:1550,y:414,t:1527876666229};\\\", \\\"{x:1554,y:414,t:1527876666245};\\\", \\\"{x:1556,y:414,t:1527876666262};\\\", \\\"{x:1557,y:414,t:1527876666278};\\\", \\\"{x:1558,y:414,t:1527876666302};\\\", \\\"{x:1559,y:414,t:1527876666312};\\\", \\\"{x:1563,y:414,t:1527876666329};\\\", \\\"{x:1568,y:417,t:1527876666345};\\\", \\\"{x:1575,y:422,t:1527876666362};\\\", \\\"{x:1581,y:425,t:1527876666379};\\\", \\\"{x:1585,y:427,t:1527876666396};\\\", \\\"{x:1589,y:429,t:1527876666412};\\\", \\\"{x:1592,y:429,t:1527876666430};\\\", \\\"{x:1594,y:430,t:1527876666447};\\\", \\\"{x:1597,y:430,t:1527876666462};\\\", \\\"{x:1600,y:430,t:1527876666479};\\\", \\\"{x:1601,y:430,t:1527876666496};\\\", \\\"{x:1602,y:430,t:1527876666520};\\\", \\\"{x:1603,y:430,t:1527876666529};\\\", \\\"{x:1604,y:430,t:1527876666547};\\\", \\\"{x:1605,y:430,t:1527876666563};\\\", \\\"{x:1606,y:430,t:1527876666580};\\\", \\\"{x:1607,y:430,t:1527876666598};\\\", \\\"{x:1608,y:430,t:1527876666622};\\\", \\\"{x:1609,y:430,t:1527876666639};\\\", \\\"{x:1610,y:430,t:1527876666686};\\\", \\\"{x:1611,y:430,t:1527876666718};\\\", \\\"{x:1612,y:430,t:1527876666750};\\\", \\\"{x:1613,y:431,t:1527876666848};\\\", \\\"{x:1614,y:431,t:1527876666887};\\\", \\\"{x:1614,y:433,t:1527876667016};\\\", \\\"{x:1614,y:437,t:1527876667032};\\\", \\\"{x:1614,y:454,t:1527876667046};\\\", \\\"{x:1606,y:495,t:1527876667062};\\\", \\\"{x:1596,y:538,t:1527876667079};\\\", \\\"{x:1580,y:594,t:1527876667096};\\\", \\\"{x:1563,y:652,t:1527876667113};\\\", \\\"{x:1542,y:702,t:1527876667129};\\\", \\\"{x:1534,y:727,t:1527876667146};\\\", \\\"{x:1533,y:740,t:1527876667163};\\\", \\\"{x:1531,y:746,t:1527876667179};\\\", \\\"{x:1531,y:750,t:1527876667196};\\\", \\\"{x:1527,y:756,t:1527876667214};\\\", \\\"{x:1526,y:759,t:1527876667229};\\\", \\\"{x:1523,y:766,t:1527876667246};\\\", \\\"{x:1521,y:776,t:1527876667263};\\\", \\\"{x:1516,y:786,t:1527876667280};\\\", \\\"{x:1514,y:792,t:1527876667296};\\\", \\\"{x:1510,y:796,t:1527876667313};\\\", \\\"{x:1509,y:797,t:1527876667330};\\\", \\\"{x:1500,y:804,t:1527876667346};\\\", \\\"{x:1485,y:815,t:1527876667363};\\\", \\\"{x:1474,y:823,t:1527876667379};\\\", \\\"{x:1467,y:828,t:1527876667395};\\\", \\\"{x:1465,y:830,t:1527876667413};\\\", \\\"{x:1465,y:831,t:1527876667430};\\\", \\\"{x:1464,y:831,t:1527876667445};\\\", \\\"{x:1464,y:832,t:1527876667599};\\\", \\\"{x:1467,y:832,t:1527876667615};\\\", \\\"{x:1469,y:832,t:1527876667631};\\\", \\\"{x:1471,y:832,t:1527876667646};\\\", \\\"{x:1475,y:831,t:1527876667663};\\\", \\\"{x:1477,y:830,t:1527876667685};\\\", \\\"{x:1478,y:829,t:1527876667696};\\\", \\\"{x:1480,y:829,t:1527876667798};\\\", \\\"{x:1481,y:829,t:1527876667823};\\\", \\\"{x:1482,y:829,t:1527876667863};\\\", \\\"{x:1483,y:830,t:1527876667880};\\\", \\\"{x:1487,y:829,t:1527876667978};\\\", \\\"{x:1495,y:822,t:1527876667997};\\\", \\\"{x:1512,y:808,t:1527876668013};\\\", \\\"{x:1547,y:785,t:1527876668030};\\\", \\\"{x:1582,y:769,t:1527876668047};\\\", \\\"{x:1591,y:767,t:1527876668064};\\\", \\\"{x:1598,y:764,t:1527876668080};\\\", \\\"{x:1601,y:764,t:1527876668097};\\\", \\\"{x:1609,y:760,t:1527876668114};\\\", \\\"{x:1612,y:760,t:1527876668130};\\\", \\\"{x:1615,y:759,t:1527876668147};\\\", \\\"{x:1620,y:759,t:1527876668164};\\\", \\\"{x:1623,y:758,t:1527876668180};\\\", \\\"{x:1628,y:756,t:1527876668197};\\\", \\\"{x:1633,y:755,t:1527876668214};\\\", \\\"{x:1634,y:755,t:1527876668238};\\\", \\\"{x:1635,y:754,t:1527876668334};\\\", \\\"{x:1633,y:754,t:1527876668463};\\\", \\\"{x:1596,y:755,t:1527876668481};\\\", \\\"{x:1504,y:755,t:1527876668498};\\\", \\\"{x:1365,y:747,t:1527876668514};\\\", \\\"{x:1160,y:717,t:1527876668531};\\\", \\\"{x:911,y:675,t:1527876668548};\\\", \\\"{x:660,y:639,t:1527876668566};\\\", \\\"{x:471,y:630,t:1527876668581};\\\", \\\"{x:362,y:633,t:1527876668597};\\\", \\\"{x:316,y:646,t:1527876668614};\\\", \\\"{x:314,y:648,t:1527876668630};\\\", \\\"{x:314,y:653,t:1527876668663};\\\", \\\"{x:329,y:675,t:1527876668682};\\\", \\\"{x:356,y:708,t:1527876668697};\\\", \\\"{x:376,y:727,t:1527876668714};\\\", \\\"{x:395,y:741,t:1527876668731};\\\", \\\"{x:414,y:747,t:1527876668747};\\\", \\\"{x:435,y:752,t:1527876668764};\\\", \\\"{x:452,y:752,t:1527876668782};\\\", \\\"{x:465,y:752,t:1527876668797};\\\", \\\"{x:500,y:748,t:1527876668814};\\\", \\\"{x:528,y:744,t:1527876668830};\\\", \\\"{x:543,y:742,t:1527876668847};\\\", \\\"{x:546,y:741,t:1527876668864};\\\", \\\"{x:547,y:743,t:1527876669254};\\\", \\\"{x:547,y:745,t:1527876669264};\\\", \\\"{x:546,y:748,t:1527876669281};\\\", \\\"{x:546,y:752,t:1527876669298};\\\", \\\"{x:545,y:754,t:1527876669314};\\\", \\\"{x:544,y:755,t:1527876669331};\\\", \\\"{x:543,y:756,t:1527876669407};\\\", \\\"{x:544,y:754,t:1527876669431};\\\", \\\"{x:554,y:742,t:1527876669449};\\\", \\\"{x:565,y:723,t:1527876669466};\\\", \\\"{x:582,y:696,t:1527876669481};\\\", \\\"{x:610,y:654,t:1527876669498};\\\", \\\"{x:642,y:609,t:1527876669515};\\\", \\\"{x:682,y:562,t:1527876669531};\\\", \\\"{x:726,y:526,t:1527876669548};\\\", \\\"{x:771,y:496,t:1527876669565};\\\", \\\"{x:825,y:465,t:1527876669581};\\\", \\\"{x:866,y:439,t:1527876669598};\\\", \\\"{x:920,y:415,t:1527876669614};\\\", \\\"{x:941,y:408,t:1527876669631};\\\", \\\"{x:949,y:405,t:1527876669648};\\\", \\\"{x:956,y:402,t:1527876669665};\\\", \\\"{x:958,y:401,t:1527876669681};\\\", \\\"{x:959,y:400,t:1527876669726};\\\", \\\"{x:959,y:399,t:1527876669734};\\\", \\\"{x:957,y:396,t:1527876669748};\\\", \\\"{x:942,y:388,t:1527876669765};\\\", \\\"{x:924,y:380,t:1527876669781};\\\", \\\"{x:901,y:370,t:1527876669798};\\\", \\\"{x:843,y:345,t:1527876669815};\\\", \\\"{x:764,y:313,t:1527876669831};\\\", \\\"{x:679,y:278,t:1527876669848};\\\", \\\"{x:599,y:245,t:1527876669865};\\\", \\\"{x:533,y:215,t:1527876669882};\\\", \\\"{x:478,y:195,t:1527876669898};\\\", \\\"{x:426,y:181,t:1527876669915};\\\", \\\"{x:387,y:171,t:1527876669932};\\\", \\\"{x:370,y:167,t:1527876669948};\\\", \\\"{x:361,y:167,t:1527876669965};\\\", \\\"{x:358,y:167,t:1527876669982};\\\", \\\"{x:354,y:167,t:1527876669999};\\\" ] }, { \\\"rt\\\": 20963, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 298663, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"2ZXKM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -A -A -Z -Z -U -U -B -B -B -G -G -F -F -K -H -H -I -J -D -D -D -X \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:354,y:168,t:1527876670551};\\\", \\\"{x:365,y:179,t:1527876670565};\\\", \\\"{x:452,y:257,t:1527876670583};\\\", \\\"{x:515,y:309,t:1527876670601};\\\", \\\"{x:605,y:379,t:1527876670615};\\\", \\\"{x:705,y:449,t:1527876670632};\\\", \\\"{x:803,y:522,t:1527876670650};\\\", \\\"{x:897,y:586,t:1527876670665};\\\", \\\"{x:996,y:643,t:1527876670682};\\\", \\\"{x:1087,y:677,t:1527876670753};\\\", \\\"{x:1087,y:675,t:1527876670790};\\\", \\\"{x:1081,y:666,t:1527876670799};\\\", \\\"{x:1057,y:645,t:1527876670816};\\\", \\\"{x:1017,y:626,t:1527876670832};\\\", \\\"{x:987,y:621,t:1527876670849};\\\", \\\"{x:955,y:620,t:1527876670866};\\\", \\\"{x:919,y:623,t:1527876670883};\\\", \\\"{x:863,y:639,t:1527876670900};\\\", \\\"{x:810,y:655,t:1527876670916};\\\", \\\"{x:767,y:668,t:1527876670932};\\\", \\\"{x:739,y:676,t:1527876670949};\\\", \\\"{x:720,y:682,t:1527876670966};\\\", \\\"{x:712,y:684,t:1527876670982};\\\", \\\"{x:708,y:685,t:1527876670999};\\\", \\\"{x:706,y:686,t:1527876671016};\\\", \\\"{x:705,y:686,t:1527876671033};\\\", \\\"{x:704,y:686,t:1527876671049};\\\", \\\"{x:702,y:687,t:1527876671067};\\\", \\\"{x:702,y:681,t:1527876671297};\\\", \\\"{x:710,y:660,t:1527876671316};\\\", \\\"{x:725,y:634,t:1527876671333};\\\", \\\"{x:764,y:598,t:1527876671349};\\\", \\\"{x:911,y:538,t:1527876671367};\\\", \\\"{x:1069,y:512,t:1527876671383};\\\", \\\"{x:1241,y:507,t:1527876671399};\\\", \\\"{x:1385,y:507,t:1527876671416};\\\", \\\"{x:1504,y:507,t:1527876671433};\\\", \\\"{x:1623,y:507,t:1527876671450};\\\", \\\"{x:1718,y:507,t:1527876671467};\\\", \\\"{x:1768,y:507,t:1527876671483};\\\", \\\"{x:1791,y:507,t:1527876671499};\\\", \\\"{x:1797,y:504,t:1527876671516};\\\", \\\"{x:1798,y:504,t:1527876671575};\\\", \\\"{x:1794,y:509,t:1527876671582};\\\", \\\"{x:1761,y:559,t:1527876671600};\\\", \\\"{x:1721,y:623,t:1527876671617};\\\", \\\"{x:1688,y:673,t:1527876671633};\\\", \\\"{x:1662,y:707,t:1527876671650};\\\", \\\"{x:1647,y:725,t:1527876671666};\\\", \\\"{x:1642,y:728,t:1527876671683};\\\", \\\"{x:1640,y:728,t:1527876671700};\\\", \\\"{x:1636,y:728,t:1527876671716};\\\", \\\"{x:1628,y:728,t:1527876671734};\\\", \\\"{x:1604,y:735,t:1527876671751};\\\", \\\"{x:1568,y:745,t:1527876671766};\\\", \\\"{x:1514,y:755,t:1527876671784};\\\", \\\"{x:1470,y:760,t:1527876671800};\\\", \\\"{x:1427,y:762,t:1527876671817};\\\", \\\"{x:1388,y:762,t:1527876671833};\\\", \\\"{x:1345,y:761,t:1527876671851};\\\", \\\"{x:1313,y:757,t:1527876671866};\\\", \\\"{x:1291,y:754,t:1527876671883};\\\", \\\"{x:1278,y:752,t:1527876671901};\\\", \\\"{x:1263,y:752,t:1527876671916};\\\", \\\"{x:1249,y:752,t:1527876671933};\\\", \\\"{x:1234,y:758,t:1527876671951};\\\", \\\"{x:1222,y:771,t:1527876671967};\\\", \\\"{x:1210,y:791,t:1527876671984};\\\", \\\"{x:1200,y:808,t:1527876672001};\\\", \\\"{x:1192,y:821,t:1527876672017};\\\", \\\"{x:1186,y:831,t:1527876672034};\\\", \\\"{x:1182,y:839,t:1527876672050};\\\", \\\"{x:1182,y:842,t:1527876672067};\\\", \\\"{x:1182,y:844,t:1527876672083};\\\", \\\"{x:1182,y:846,t:1527876672143};\\\", \\\"{x:1182,y:848,t:1527876672151};\\\", \\\"{x:1182,y:851,t:1527876672167};\\\", \\\"{x:1182,y:853,t:1527876672184};\\\", \\\"{x:1182,y:855,t:1527876672201};\\\", \\\"{x:1183,y:856,t:1527876672217};\\\", \\\"{x:1184,y:858,t:1527876672233};\\\", \\\"{x:1185,y:858,t:1527876672263};\\\", \\\"{x:1186,y:859,t:1527876672279};\\\", \\\"{x:1188,y:860,t:1527876672295};\\\", \\\"{x:1190,y:861,t:1527876672304};\\\", \\\"{x:1192,y:862,t:1527876672320};\\\", \\\"{x:1193,y:862,t:1527876672334};\\\", \\\"{x:1196,y:862,t:1527876672351};\\\", \\\"{x:1198,y:862,t:1527876672368};\\\", \\\"{x:1199,y:862,t:1527876672384};\\\", \\\"{x:1200,y:862,t:1527876672401};\\\", \\\"{x:1202,y:862,t:1527876672418};\\\", \\\"{x:1203,y:862,t:1527876672434};\\\", \\\"{x:1206,y:861,t:1527876672451};\\\", \\\"{x:1208,y:859,t:1527876672468};\\\", \\\"{x:1208,y:858,t:1527876672484};\\\", \\\"{x:1208,y:856,t:1527876672501};\\\", \\\"{x:1208,y:855,t:1527876672517};\\\", \\\"{x:1208,y:849,t:1527876672535};\\\", \\\"{x:1208,y:848,t:1527876672551};\\\", \\\"{x:1208,y:838,t:1527876672567};\\\", \\\"{x:1209,y:833,t:1527876672585};\\\", \\\"{x:1210,y:831,t:1527876672614};\\\", \\\"{x:1210,y:830,t:1527876672634};\\\", \\\"{x:1212,y:828,t:1527876672703};\\\", \\\"{x:1214,y:828,t:1527876672718};\\\", \\\"{x:1218,y:828,t:1527876672734};\\\", \\\"{x:1222,y:828,t:1527876672752};\\\", \\\"{x:1227,y:830,t:1527876672768};\\\", \\\"{x:1230,y:833,t:1527876672784};\\\", \\\"{x:1238,y:837,t:1527876672800};\\\", \\\"{x:1248,y:843,t:1527876672818};\\\", \\\"{x:1251,y:844,t:1527876672834};\\\", \\\"{x:1251,y:845,t:1527876672850};\\\", \\\"{x:1252,y:845,t:1527876672870};\\\", \\\"{x:1254,y:845,t:1527876672887};\\\", \\\"{x:1257,y:844,t:1527876672901};\\\", \\\"{x:1260,y:844,t:1527876672918};\\\", \\\"{x:1262,y:843,t:1527876672934};\\\", \\\"{x:1266,y:843,t:1527876672951};\\\", \\\"{x:1268,y:842,t:1527876672967};\\\", \\\"{x:1269,y:841,t:1527876672985};\\\", \\\"{x:1271,y:841,t:1527876673002};\\\", \\\"{x:1272,y:840,t:1527876673018};\\\", \\\"{x:1274,y:840,t:1527876673035};\\\", \\\"{x:1275,y:839,t:1527876673051};\\\", \\\"{x:1279,y:837,t:1527876673067};\\\", \\\"{x:1283,y:836,t:1527876673084};\\\", \\\"{x:1284,y:836,t:1527876673101};\\\", \\\"{x:1285,y:835,t:1527876673151};\\\", \\\"{x:1286,y:834,t:1527876673175};\\\", \\\"{x:1287,y:834,t:1527876673190};\\\", \\\"{x:1288,y:833,t:1527876673311};\\\", \\\"{x:1289,y:832,t:1527876673359};\\\", \\\"{x:1289,y:830,t:1527876673369};\\\", \\\"{x:1289,y:827,t:1527876673385};\\\", \\\"{x:1289,y:824,t:1527876673402};\\\", \\\"{x:1289,y:821,t:1527876673419};\\\", \\\"{x:1289,y:820,t:1527876673435};\\\", \\\"{x:1288,y:820,t:1527876673648};\\\", \\\"{x:1287,y:820,t:1527876673664};\\\", \\\"{x:1286,y:821,t:1527876673671};\\\", \\\"{x:1285,y:821,t:1527876673685};\\\", \\\"{x:1278,y:825,t:1527876673705};\\\", \\\"{x:1272,y:828,t:1527876673736};\\\", \\\"{x:1271,y:829,t:1527876673751};\\\", \\\"{x:1270,y:829,t:1527876673768};\\\", \\\"{x:1270,y:830,t:1527876673785};\\\", \\\"{x:1270,y:831,t:1527876673943};\\\", \\\"{x:1272,y:831,t:1527876673951};\\\", \\\"{x:1274,y:831,t:1527876673968};\\\", \\\"{x:1277,y:832,t:1527876673986};\\\", \\\"{x:1278,y:832,t:1527876674001};\\\", \\\"{x:1281,y:833,t:1527876674018};\\\", \\\"{x:1283,y:834,t:1527876674038};\\\", \\\"{x:1284,y:835,t:1527876674055};\\\", \\\"{x:1285,y:835,t:1527876674078};\\\", \\\"{x:1286,y:835,t:1527876674111};\\\", \\\"{x:1287,y:835,t:1527876674158};\\\", \\\"{x:1288,y:836,t:1527876674168};\\\", \\\"{x:1290,y:836,t:1527876674185};\\\", \\\"{x:1294,y:838,t:1527876674202};\\\", \\\"{x:1299,y:841,t:1527876674219};\\\", \\\"{x:1306,y:844,t:1527876674235};\\\", \\\"{x:1310,y:847,t:1527876674253};\\\", \\\"{x:1314,y:851,t:1527876674268};\\\", \\\"{x:1317,y:853,t:1527876674286};\\\", \\\"{x:1318,y:854,t:1527876674302};\\\", \\\"{x:1320,y:854,t:1527876674318};\\\", \\\"{x:1322,y:857,t:1527876674335};\\\", \\\"{x:1327,y:862,t:1527876674352};\\\", \\\"{x:1333,y:867,t:1527876674368};\\\", \\\"{x:1338,y:872,t:1527876674385};\\\", \\\"{x:1343,y:877,t:1527876674403};\\\", \\\"{x:1346,y:881,t:1527876674418};\\\", \\\"{x:1347,y:883,t:1527876674435};\\\", \\\"{x:1348,y:884,t:1527876674453};\\\", \\\"{x:1349,y:885,t:1527876674468};\\\", \\\"{x:1349,y:886,t:1527876674487};\\\", \\\"{x:1349,y:887,t:1527876674527};\\\", \\\"{x:1349,y:889,t:1527876674535};\\\", \\\"{x:1349,y:890,t:1527876674553};\\\", \\\"{x:1351,y:893,t:1527876674572};\\\", \\\"{x:1352,y:893,t:1527876674586};\\\", \\\"{x:1352,y:894,t:1527876674602};\\\", \\\"{x:1355,y:892,t:1527876674914};\\\", \\\"{x:1368,y:883,t:1527876674935};\\\", \\\"{x:1394,y:863,t:1527876674952};\\\", \\\"{x:1421,y:843,t:1527876674970};\\\", \\\"{x:1439,y:834,t:1527876674985};\\\", \\\"{x:1455,y:828,t:1527876675002};\\\", \\\"{x:1466,y:824,t:1527876675019};\\\", \\\"{x:1469,y:823,t:1527876675035};\\\", \\\"{x:1470,y:823,t:1527876675062};\\\", \\\"{x:1471,y:823,t:1527876675078};\\\", \\\"{x:1473,y:822,t:1527876675094};\\\", \\\"{x:1475,y:822,t:1527876675119};\\\", \\\"{x:1475,y:821,t:1527876675126};\\\", \\\"{x:1476,y:821,t:1527876675142};\\\", \\\"{x:1477,y:821,t:1527876675158};\\\", \\\"{x:1479,y:821,t:1527876675304};\\\", \\\"{x:1480,y:821,t:1527876675319};\\\", \\\"{x:1480,y:823,t:1527876675336};\\\", \\\"{x:1482,y:825,t:1527876675353};\\\", \\\"{x:1484,y:826,t:1527876675767};\\\", \\\"{x:1486,y:826,t:1527876675778};\\\", \\\"{x:1490,y:826,t:1527876675786};\\\", \\\"{x:1500,y:822,t:1527876675803};\\\", \\\"{x:1512,y:816,t:1527876675819};\\\", \\\"{x:1527,y:808,t:1527876675836};\\\", \\\"{x:1541,y:800,t:1527876675853};\\\", \\\"{x:1557,y:793,t:1527876675870};\\\", \\\"{x:1568,y:789,t:1527876675886};\\\", \\\"{x:1576,y:785,t:1527876675904};\\\", \\\"{x:1582,y:783,t:1527876675921};\\\", \\\"{x:1585,y:782,t:1527876675936};\\\", \\\"{x:1586,y:782,t:1527876675953};\\\", \\\"{x:1589,y:782,t:1527876675970};\\\", \\\"{x:1595,y:782,t:1527876675987};\\\", \\\"{x:1602,y:782,t:1527876676003};\\\", \\\"{x:1613,y:782,t:1527876676021};\\\", \\\"{x:1625,y:786,t:1527876676036};\\\", \\\"{x:1633,y:788,t:1527876676054};\\\", \\\"{x:1636,y:789,t:1527876676070};\\\", \\\"{x:1637,y:790,t:1527876676086};\\\", \\\"{x:1638,y:790,t:1527876676104};\\\", \\\"{x:1640,y:791,t:1527876676121};\\\", \\\"{x:1642,y:793,t:1527876676137};\\\", \\\"{x:1647,y:797,t:1527876676154};\\\", \\\"{x:1655,y:801,t:1527876676171};\\\", \\\"{x:1663,y:804,t:1527876676187};\\\", \\\"{x:1668,y:806,t:1527876676203};\\\", \\\"{x:1672,y:807,t:1527876676220};\\\", \\\"{x:1673,y:808,t:1527876676237};\\\", \\\"{x:1674,y:808,t:1527876676253};\\\", \\\"{x:1682,y:809,t:1527876676271};\\\", \\\"{x:1686,y:809,t:1527876676287};\\\", \\\"{x:1690,y:810,t:1527876676303};\\\", \\\"{x:1690,y:811,t:1527876676321};\\\", \\\"{x:1691,y:811,t:1527876676337};\\\", \\\"{x:1692,y:811,t:1527876676400};\\\", \\\"{x:1692,y:812,t:1527876676440};\\\", \\\"{x:1691,y:813,t:1527876676455};\\\", \\\"{x:1689,y:814,t:1527876676479};\\\", \\\"{x:1688,y:816,t:1527876676487};\\\", \\\"{x:1687,y:818,t:1527876676503};\\\", \\\"{x:1685,y:821,t:1527876676520};\\\", \\\"{x:1684,y:824,t:1527876676537};\\\", \\\"{x:1682,y:827,t:1527876676555};\\\", \\\"{x:1679,y:832,t:1527876676570};\\\", \\\"{x:1677,y:833,t:1527876676587};\\\", \\\"{x:1677,y:834,t:1527876676614};\\\", \\\"{x:1678,y:835,t:1527876676871};\\\", \\\"{x:1679,y:835,t:1527876677339};\\\", \\\"{x:1680,y:835,t:1527876677372};\\\", \\\"{x:1681,y:835,t:1527876677398};\\\", \\\"{x:1681,y:834,t:1527876677414};\\\", \\\"{x:1681,y:833,t:1527876677639};\\\", \\\"{x:1680,y:830,t:1527876677839};\\\", \\\"{x:1678,y:823,t:1527876677857};\\\", \\\"{x:1677,y:817,t:1527876677872};\\\", \\\"{x:1675,y:813,t:1527876677888};\\\", \\\"{x:1673,y:806,t:1527876677905};\\\", \\\"{x:1671,y:801,t:1527876677921};\\\", \\\"{x:1670,y:798,t:1527876677938};\\\", \\\"{x:1669,y:796,t:1527876677955};\\\", \\\"{x:1666,y:789,t:1527876677971};\\\", \\\"{x:1664,y:786,t:1527876677988};\\\", \\\"{x:1663,y:782,t:1527876678005};\\\", \\\"{x:1662,y:779,t:1527876678022};\\\", \\\"{x:1662,y:778,t:1527876678191};\\\", \\\"{x:1660,y:777,t:1527876678205};\\\", \\\"{x:1656,y:774,t:1527876678221};\\\", \\\"{x:1649,y:768,t:1527876678240};\\\", \\\"{x:1645,y:764,t:1527876678255};\\\", \\\"{x:1642,y:762,t:1527876678271};\\\", \\\"{x:1640,y:760,t:1527876678607};\\\", \\\"{x:1640,y:759,t:1527876678704};\\\", \\\"{x:1641,y:759,t:1527876678775};\\\", \\\"{x:1642,y:760,t:1527876678790};\\\", \\\"{x:1642,y:761,t:1527876678806};\\\", \\\"{x:1642,y:763,t:1527876678826};\\\", \\\"{x:1642,y:764,t:1527876678839};\\\", \\\"{x:1642,y:766,t:1527876678856};\\\", \\\"{x:1642,y:768,t:1527876678872};\\\", \\\"{x:1642,y:771,t:1527876678890};\\\", \\\"{x:1642,y:774,t:1527876678905};\\\", \\\"{x:1641,y:777,t:1527876678923};\\\", \\\"{x:1636,y:777,t:1527876679104};\\\", \\\"{x:1627,y:777,t:1527876679111};\\\", \\\"{x:1612,y:781,t:1527876679124};\\\", \\\"{x:1567,y:787,t:1527876679139};\\\", \\\"{x:1532,y:790,t:1527876679156};\\\", \\\"{x:1503,y:790,t:1527876679172};\\\", \\\"{x:1470,y:790,t:1527876679190};\\\", \\\"{x:1418,y:786,t:1527876679206};\\\", \\\"{x:1400,y:783,t:1527876679222};\\\", \\\"{x:1382,y:780,t:1527876679239};\\\", \\\"{x:1364,y:776,t:1527876679256};\\\", \\\"{x:1349,y:773,t:1527876679273};\\\", \\\"{x:1346,y:772,t:1527876679289};\\\", \\\"{x:1348,y:772,t:1527876679431};\\\", \\\"{x:1349,y:772,t:1527876679439};\\\", \\\"{x:1354,y:769,t:1527876679457};\\\", \\\"{x:1365,y:767,t:1527876679474};\\\", \\\"{x:1372,y:764,t:1527876679489};\\\", \\\"{x:1373,y:763,t:1527876679507};\\\", \\\"{x:1379,y:763,t:1527876679527};\\\", \\\"{x:1383,y:760,t:1527876679539};\\\", \\\"{x:1384,y:760,t:1527876679558};\\\", \\\"{x:1385,y:760,t:1527876679573};\\\", \\\"{x:1386,y:760,t:1527876679597};\\\", \\\"{x:1387,y:760,t:1527876679679};\\\", \\\"{x:1387,y:761,t:1527876679694};\\\", \\\"{x:1387,y:762,t:1527876679711};\\\", \\\"{x:1387,y:763,t:1527876679777};\\\", \\\"{x:1387,y:765,t:1527876679807};\\\", \\\"{x:1388,y:765,t:1527876679958};\\\", \\\"{x:1391,y:762,t:1527876679973};\\\", \\\"{x:1400,y:750,t:1527876679990};\\\", \\\"{x:1424,y:716,t:1527876680006};\\\", \\\"{x:1435,y:697,t:1527876680024};\\\", \\\"{x:1447,y:683,t:1527876680039};\\\", \\\"{x:1452,y:678,t:1527876680057};\\\", \\\"{x:1457,y:675,t:1527876680074};\\\", \\\"{x:1463,y:671,t:1527876680089};\\\", \\\"{x:1468,y:666,t:1527876680107};\\\", \\\"{x:1474,y:661,t:1527876680124};\\\", \\\"{x:1480,y:656,t:1527876680139};\\\", \\\"{x:1486,y:651,t:1527876680157};\\\", \\\"{x:1489,y:648,t:1527876680173};\\\", \\\"{x:1492,y:646,t:1527876680190};\\\", \\\"{x:1498,y:641,t:1527876680206};\\\", \\\"{x:1499,y:640,t:1527876680223};\\\", \\\"{x:1500,y:640,t:1527876680278};\\\", \\\"{x:1500,y:639,t:1527876680289};\\\", \\\"{x:1504,y:639,t:1527876680306};\\\", \\\"{x:1506,y:637,t:1527876680323};\\\", \\\"{x:1507,y:637,t:1527876680340};\\\", \\\"{x:1508,y:637,t:1527876680375};\\\", \\\"{x:1509,y:636,t:1527876680424};\\\", \\\"{x:1510,y:635,t:1527876680441};\\\", \\\"{x:1512,y:634,t:1527876680460};\\\", \\\"{x:1513,y:633,t:1527876680473};\\\", \\\"{x:1514,y:633,t:1527876680490};\\\", \\\"{x:1515,y:632,t:1527876680508};\\\", \\\"{x:1516,y:632,t:1527876680542};\\\", \\\"{x:1513,y:632,t:1527876680999};\\\", \\\"{x:1507,y:632,t:1527876681011};\\\", \\\"{x:1494,y:632,t:1527876681024};\\\", \\\"{x:1477,y:632,t:1527876681040};\\\", \\\"{x:1461,y:632,t:1527876681057};\\\", \\\"{x:1449,y:629,t:1527876681073};\\\", \\\"{x:1441,y:626,t:1527876681091};\\\", \\\"{x:1436,y:623,t:1527876681107};\\\", \\\"{x:1432,y:619,t:1527876681124};\\\", \\\"{x:1428,y:616,t:1527876681141};\\\", \\\"{x:1427,y:613,t:1527876681158};\\\", \\\"{x:1427,y:612,t:1527876681173};\\\", \\\"{x:1427,y:606,t:1527876681190};\\\", \\\"{x:1427,y:601,t:1527876681207};\\\", \\\"{x:1427,y:599,t:1527876681225};\\\", \\\"{x:1427,y:597,t:1527876681240};\\\", \\\"{x:1427,y:596,t:1527876681258};\\\", \\\"{x:1427,y:594,t:1527876681274};\\\", \\\"{x:1428,y:591,t:1527876681290};\\\", \\\"{x:1428,y:590,t:1527876681307};\\\", \\\"{x:1428,y:584,t:1527876681324};\\\", \\\"{x:1426,y:580,t:1527876681341};\\\", \\\"{x:1422,y:575,t:1527876681358};\\\", \\\"{x:1416,y:569,t:1527876681374};\\\", \\\"{x:1415,y:567,t:1527876681392};\\\", \\\"{x:1413,y:566,t:1527876681408};\\\", \\\"{x:1411,y:564,t:1527876681424};\\\", \\\"{x:1409,y:563,t:1527876681440};\\\", \\\"{x:1406,y:560,t:1527876681458};\\\", \\\"{x:1404,y:559,t:1527876681474};\\\", \\\"{x:1404,y:558,t:1527876681491};\\\", \\\"{x:1404,y:557,t:1527876681647};\\\", \\\"{x:1405,y:557,t:1527876681670};\\\", \\\"{x:1405,y:558,t:1527876681726};\\\", \\\"{x:1405,y:559,t:1527876681741};\\\", \\\"{x:1405,y:561,t:1527876681757};\\\", \\\"{x:1405,y:563,t:1527876681775};\\\", \\\"{x:1405,y:564,t:1527876681792};\\\", \\\"{x:1405,y:565,t:1527876681808};\\\", \\\"{x:1405,y:566,t:1527876681838};\\\", \\\"{x:1405,y:567,t:1527876681871};\\\", \\\"{x:1405,y:568,t:1527876681911};\\\", \\\"{x:1406,y:569,t:1527876681927};\\\", \\\"{x:1406,y:570,t:1527876682007};\\\", \\\"{x:1407,y:570,t:1527876682015};\\\", \\\"{x:1408,y:570,t:1527876682026};\\\", \\\"{x:1409,y:571,t:1527876682088};\\\", \\\"{x:1411,y:572,t:1527876682111};\\\", \\\"{x:1412,y:572,t:1527876682264};\\\", \\\"{x:1413,y:572,t:1527876682275};\\\", \\\"{x:1414,y:572,t:1527876682302};\\\", \\\"{x:1415,y:572,t:1527876682335};\\\", \\\"{x:1416,y:572,t:1527876682350};\\\", \\\"{x:1417,y:572,t:1527876682365};\\\", \\\"{x:1418,y:572,t:1527876682406};\\\", \\\"{x:1419,y:572,t:1527876682502};\\\", \\\"{x:1420,y:571,t:1527876682526};\\\", \\\"{x:1422,y:570,t:1527876682661};\\\", \\\"{x:1421,y:569,t:1527876682782};\\\", \\\"{x:1421,y:568,t:1527876682791};\\\", \\\"{x:1417,y:568,t:1527876682810};\\\", \\\"{x:1413,y:568,t:1527876682825};\\\", \\\"{x:1403,y:568,t:1527876682843};\\\", \\\"{x:1384,y:568,t:1527876682859};\\\", \\\"{x:1359,y:570,t:1527876682875};\\\", \\\"{x:1304,y:586,t:1527876682891};\\\", \\\"{x:1221,y:608,t:1527876682909};\\\", \\\"{x:1111,y:635,t:1527876682926};\\\", \\\"{x:947,y:665,t:1527876682942};\\\", \\\"{x:845,y:679,t:1527876682958};\\\", \\\"{x:737,y:695,t:1527876682975};\\\", \\\"{x:624,y:705,t:1527876682993};\\\", \\\"{x:529,y:719,t:1527876683008};\\\", \\\"{x:452,y:730,t:1527876683026};\\\", \\\"{x:413,y:734,t:1527876683042};\\\", \\\"{x:395,y:734,t:1527876683058};\\\", \\\"{x:389,y:734,t:1527876683075};\\\", \\\"{x:387,y:733,t:1527876683092};\\\", \\\"{x:386,y:726,t:1527876683109};\\\", \\\"{x:386,y:716,t:1527876683125};\\\", \\\"{x:389,y:692,t:1527876683142};\\\", \\\"{x:394,y:676,t:1527876683159};\\\", \\\"{x:402,y:660,t:1527876683175};\\\", \\\"{x:413,y:642,t:1527876683194};\\\", \\\"{x:424,y:625,t:1527876683210};\\\", \\\"{x:432,y:618,t:1527876683225};\\\", \\\"{x:439,y:614,t:1527876683243};\\\", \\\"{x:441,y:612,t:1527876683259};\\\", \\\"{x:443,y:612,t:1527876683275};\\\", \\\"{x:445,y:610,t:1527876683303};\\\", \\\"{x:447,y:610,t:1527876683310};\\\", \\\"{x:449,y:610,t:1527876683326};\\\", \\\"{x:459,y:606,t:1527876683342};\\\", \\\"{x:461,y:605,t:1527876683359};\\\", \\\"{x:458,y:608,t:1527876683462};\\\", \\\"{x:452,y:613,t:1527876683476};\\\", \\\"{x:442,y:621,t:1527876683493};\\\", \\\"{x:432,y:627,t:1527876683509};\\\", \\\"{x:423,y:633,t:1527876683525};\\\", \\\"{x:434,y:630,t:1527876683582};\\\", \\\"{x:453,y:622,t:1527876683592};\\\", \\\"{x:476,y:612,t:1527876683610};\\\", \\\"{x:486,y:608,t:1527876683626};\\\", \\\"{x:502,y:605,t:1527876683643};\\\", \\\"{x:517,y:603,t:1527876683659};\\\", \\\"{x:530,y:601,t:1527876683675};\\\", \\\"{x:544,y:601,t:1527876683692};\\\", \\\"{x:557,y:601,t:1527876683709};\\\", \\\"{x:566,y:601,t:1527876683726};\\\", \\\"{x:579,y:599,t:1527876683743};\\\", \\\"{x:583,y:599,t:1527876683759};\\\", \\\"{x:586,y:599,t:1527876683776};\\\", \\\"{x:590,y:600,t:1527876683792};\\\", \\\"{x:595,y:601,t:1527876683809};\\\", \\\"{x:602,y:604,t:1527876683827};\\\", \\\"{x:605,y:604,t:1527876683843};\\\", \\\"{x:608,y:604,t:1527876683859};\\\", \\\"{x:611,y:605,t:1527876683876};\\\", \\\"{x:612,y:605,t:1527876683892};\\\", \\\"{x:613,y:605,t:1527876683909};\\\", \\\"{x:616,y:605,t:1527876683976};\\\", \\\"{x:616,y:605,t:1527876684097};\\\", \\\"{x:618,y:605,t:1527876684398};\\\", \\\"{x:630,y:605,t:1527876684411};\\\", \\\"{x:694,y:611,t:1527876684427};\\\", \\\"{x:799,y:611,t:1527876684444};\\\", \\\"{x:889,y:612,t:1527876684459};\\\", \\\"{x:983,y:624,t:1527876684476};\\\", \\\"{x:1033,y:631,t:1527876684494};\\\", \\\"{x:1063,y:639,t:1527876684509};\\\", \\\"{x:1085,y:642,t:1527876684526};\\\", \\\"{x:1087,y:642,t:1527876684543};\\\", \\\"{x:1088,y:642,t:1527876684614};\\\", \\\"{x:1089,y:639,t:1527876684626};\\\", \\\"{x:1092,y:633,t:1527876684644};\\\", \\\"{x:1095,y:621,t:1527876684660};\\\", \\\"{x:1101,y:612,t:1527876684677};\\\", \\\"{x:1112,y:602,t:1527876684693};\\\", \\\"{x:1126,y:591,t:1527876684710};\\\", \\\"{x:1144,y:575,t:1527876684726};\\\", \\\"{x:1150,y:565,t:1527876684743};\\\", \\\"{x:1153,y:561,t:1527876684760};\\\", \\\"{x:1153,y:558,t:1527876684777};\\\", \\\"{x:1153,y:557,t:1527876684793};\\\", \\\"{x:1153,y:556,t:1527876684810};\\\", \\\"{x:1154,y:555,t:1527876684827};\\\", \\\"{x:1155,y:552,t:1527876684844};\\\", \\\"{x:1156,y:548,t:1527876684860};\\\", \\\"{x:1160,y:543,t:1527876684877};\\\", \\\"{x:1165,y:534,t:1527876684893};\\\", \\\"{x:1170,y:529,t:1527876684910};\\\", \\\"{x:1188,y:521,t:1527876684927};\\\", \\\"{x:1203,y:518,t:1527876684943};\\\", \\\"{x:1225,y:510,t:1527876684959};\\\", \\\"{x:1237,y:508,t:1527876684976};\\\", \\\"{x:1250,y:504,t:1527876684994};\\\", \\\"{x:1259,y:504,t:1527876685009};\\\", \\\"{x:1261,y:503,t:1527876685027};\\\", \\\"{x:1262,y:503,t:1527876685150};\\\", \\\"{x:1263,y:502,t:1527876685174};\\\", \\\"{x:1268,y:502,t:1527876685182};\\\", \\\"{x:1271,y:500,t:1527876685193};\\\", \\\"{x:1280,y:498,t:1527876685209};\\\", \\\"{x:1287,y:495,t:1527876685226};\\\", \\\"{x:1292,y:494,t:1527876685243};\\\", \\\"{x:1300,y:492,t:1527876685260};\\\", \\\"{x:1309,y:489,t:1527876685276};\\\", \\\"{x:1314,y:488,t:1527876685294};\\\", \\\"{x:1315,y:488,t:1527876685606};\\\", \\\"{x:1315,y:489,t:1527876685654};\\\", \\\"{x:1315,y:490,t:1527876685662};\\\", \\\"{x:1315,y:491,t:1527876685711};\\\", \\\"{x:1315,y:492,t:1527876685758};\\\", \\\"{x:1315,y:493,t:1527876685798};\\\", \\\"{x:1314,y:494,t:1527876685862};\\\", \\\"{x:1314,y:495,t:1527876685878};\\\", \\\"{x:1313,y:495,t:1527876685894};\\\", \\\"{x:1312,y:496,t:1527876685912};\\\", \\\"{x:1315,y:494,t:1527876686262};\\\", \\\"{x:1320,y:484,t:1527876686278};\\\", \\\"{x:1331,y:470,t:1527876686295};\\\", \\\"{x:1340,y:457,t:1527876686311};\\\", \\\"{x:1351,y:444,t:1527876686328};\\\", \\\"{x:1359,y:437,t:1527876686345};\\\", \\\"{x:1366,y:431,t:1527876686361};\\\", \\\"{x:1375,y:426,t:1527876686379};\\\", \\\"{x:1381,y:423,t:1527876686395};\\\", \\\"{x:1383,y:422,t:1527876686411};\\\", \\\"{x:1384,y:421,t:1527876686428};\\\", \\\"{x:1385,y:420,t:1527876686446};\\\", \\\"{x:1386,y:420,t:1527876686550};\\\", \\\"{x:1387,y:421,t:1527876686562};\\\", \\\"{x:1388,y:423,t:1527876686579};\\\", \\\"{x:1389,y:425,t:1527876686594};\\\", \\\"{x:1391,y:427,t:1527876686611};\\\", \\\"{x:1392,y:429,t:1527876686628};\\\", \\\"{x:1393,y:431,t:1527876686645};\\\", \\\"{x:1396,y:432,t:1527876686662};\\\", \\\"{x:1398,y:432,t:1527876686678};\\\", \\\"{x:1400,y:432,t:1527876686695};\\\", \\\"{x:1406,y:432,t:1527876686711};\\\", \\\"{x:1411,y:432,t:1527876686731};\\\", \\\"{x:1412,y:432,t:1527876686745};\\\", \\\"{x:1413,y:432,t:1527876687333};\\\", \\\"{x:1414,y:432,t:1527876687345};\\\", \\\"{x:1419,y:432,t:1527876687361};\\\", \\\"{x:1423,y:428,t:1527876687379};\\\", \\\"{x:1430,y:420,t:1527876687395};\\\", \\\"{x:1451,y:407,t:1527876687413};\\\", \\\"{x:1478,y:398,t:1527876687428};\\\", \\\"{x:1507,y:388,t:1527876687446};\\\", \\\"{x:1524,y:383,t:1527876687462};\\\", \\\"{x:1531,y:383,t:1527876687478};\\\", \\\"{x:1533,y:383,t:1527876687496};\\\", \\\"{x:1539,y:383,t:1527876687513};\\\", \\\"{x:1550,y:383,t:1527876687529};\\\", \\\"{x:1560,y:383,t:1527876687546};\\\", \\\"{x:1570,y:386,t:1527876687562};\\\", \\\"{x:1575,y:390,t:1527876687579};\\\", \\\"{x:1578,y:393,t:1527876687596};\\\", \\\"{x:1582,y:400,t:1527876687612};\\\", \\\"{x:1583,y:405,t:1527876687629};\\\", \\\"{x:1584,y:409,t:1527876687645};\\\", \\\"{x:1585,y:413,t:1527876687663};\\\", \\\"{x:1585,y:415,t:1527876687679};\\\", \\\"{x:1587,y:421,t:1527876687695};\\\", \\\"{x:1588,y:423,t:1527876687712};\\\", \\\"{x:1589,y:423,t:1527876687758};\\\", \\\"{x:1592,y:423,t:1527876687766};\\\", \\\"{x:1594,y:423,t:1527876687780};\\\", \\\"{x:1600,y:423,t:1527876687796};\\\", \\\"{x:1604,y:423,t:1527876687812};\\\", \\\"{x:1606,y:423,t:1527876687829};\\\", \\\"{x:1607,y:422,t:1527876687846};\\\", \\\"{x:1608,y:422,t:1527876687863};\\\", \\\"{x:1609,y:422,t:1527876687880};\\\", \\\"{x:1610,y:422,t:1527876687902};\\\", \\\"{x:1611,y:422,t:1527876687926};\\\", \\\"{x:1612,y:422,t:1527876687943};\\\", \\\"{x:1613,y:422,t:1527876688023};\\\", \\\"{x:1613,y:423,t:1527876688039};\\\", \\\"{x:1613,y:424,t:1527876688047};\\\", \\\"{x:1613,y:426,t:1527876688065};\\\", \\\"{x:1613,y:427,t:1527876688079};\\\", \\\"{x:1613,y:428,t:1527876688096};\\\", \\\"{x:1613,y:429,t:1527876688113};\\\", \\\"{x:1611,y:424,t:1527876688519};\\\", \\\"{x:1602,y:412,t:1527876688530};\\\", \\\"{x:1570,y:369,t:1527876688547};\\\", \\\"{x:1539,y:327,t:1527876688563};\\\", \\\"{x:1509,y:291,t:1527876688580};\\\", \\\"{x:1468,y:258,t:1527876688597};\\\", \\\"{x:1423,y:220,t:1527876688614};\\\", \\\"{x:1413,y:210,t:1527876688630};\\\", \\\"{x:1412,y:210,t:1527876688647};\\\", \\\"{x:1411,y:208,t:1527876688798};\\\", \\\"{x:1414,y:206,t:1527876688814};\\\", \\\"{x:1434,y:204,t:1527876688830};\\\", \\\"{x:1454,y:203,t:1527876688847};\\\", \\\"{x:1468,y:201,t:1527876688863};\\\", \\\"{x:1479,y:199,t:1527876688881};\\\", \\\"{x:1484,y:197,t:1527876688897};\\\", \\\"{x:1488,y:195,t:1527876688914};\\\", \\\"{x:1490,y:194,t:1527876688930};\\\", \\\"{x:1493,y:192,t:1527876688946};\\\", \\\"{x:1498,y:190,t:1527876688964};\\\", \\\"{x:1500,y:188,t:1527876688980};\\\", \\\"{x:1499,y:186,t:1527876689094};\\\", \\\"{x:1497,y:185,t:1527876689102};\\\", \\\"{x:1495,y:182,t:1527876689114};\\\", \\\"{x:1490,y:179,t:1527876689131};\\\", \\\"{x:1485,y:175,t:1527876689147};\\\", \\\"{x:1481,y:172,t:1527876689164};\\\", \\\"{x:1478,y:169,t:1527876689181};\\\", \\\"{x:1475,y:166,t:1527876689197};\\\", \\\"{x:1472,y:160,t:1527876689214};\\\", \\\"{x:1470,y:158,t:1527876689230};\\\", \\\"{x:1469,y:157,t:1527876689254};\\\", \\\"{x:1469,y:156,t:1527876689334};\\\", \\\"{x:1469,y:155,t:1527876689366};\\\", \\\"{x:1470,y:155,t:1527876689406};\\\", \\\"{x:1471,y:155,t:1527876689462};\\\", \\\"{x:1471,y:156,t:1527876689478};\\\", \\\"{x:1471,y:157,t:1527876689494};\\\", \\\"{x:1472,y:157,t:1527876689501};\\\", \\\"{x:1472,y:159,t:1527876689534};\\\", \\\"{x:1473,y:159,t:1527876689566};\\\", \\\"{x:1474,y:159,t:1527876689581};\\\", \\\"{x:1474,y:160,t:1527876689614};\\\", \\\"{x:1474,y:161,t:1527876689638};\\\", \\\"{x:1475,y:162,t:1527876689648};\\\", \\\"{x:1475,y:164,t:1527876689664};\\\", \\\"{x:1476,y:165,t:1527876689687};\\\", \\\"{x:1477,y:165,t:1527876689698};\\\", \\\"{x:1477,y:167,t:1527876690286};\\\", \\\"{x:1477,y:168,t:1527876690303};\\\", \\\"{x:1477,y:170,t:1527876690315};\\\", \\\"{x:1477,y:178,t:1527876690332};\\\", \\\"{x:1459,y:203,t:1527876690348};\\\", \\\"{x:1400,y:274,t:1527876690364};\\\", \\\"{x:1238,y:460,t:1527876690382};\\\", \\\"{x:1084,y:596,t:1527876690398};\\\", \\\"{x:930,y:722,t:1527876690414};\\\", \\\"{x:800,y:810,t:1527876690432};\\\", \\\"{x:691,y:873,t:1527876690448};\\\", \\\"{x:620,y:914,t:1527876690465};\\\", \\\"{x:579,y:937,t:1527876690482};\\\", \\\"{x:556,y:950,t:1527876690498};\\\", \\\"{x:542,y:957,t:1527876690515};\\\", \\\"{x:534,y:962,t:1527876690531};\\\", \\\"{x:532,y:963,t:1527876690548};\\\", \\\"{x:530,y:963,t:1527876690565};\\\", \\\"{x:530,y:958,t:1527876690623};\\\", \\\"{x:530,y:948,t:1527876690631};\\\", \\\"{x:529,y:937,t:1527876690648};\\\", \\\"{x:529,y:928,t:1527876690665};\\\", \\\"{x:529,y:915,t:1527876690682};\\\", \\\"{x:529,y:898,t:1527876690698};\\\", \\\"{x:529,y:879,t:1527876690715};\\\", \\\"{x:529,y:864,t:1527876690732};\\\", \\\"{x:529,y:849,t:1527876690749};\\\", \\\"{x:528,y:841,t:1527876690765};\\\", \\\"{x:526,y:833,t:1527876690781};\\\", \\\"{x:526,y:828,t:1527876690798};\\\", \\\"{x:526,y:826,t:1527876690815};\\\", \\\"{x:526,y:825,t:1527876690831};\\\", \\\"{x:525,y:824,t:1527876690849};\\\", \\\"{x:525,y:823,t:1527876690865};\\\", \\\"{x:525,y:815,t:1527876690882};\\\", \\\"{x:525,y:809,t:1527876690899};\\\", \\\"{x:524,y:804,t:1527876690915};\\\", \\\"{x:524,y:803,t:1527876690931};\\\", \\\"{x:523,y:802,t:1527876690949};\\\", \\\"{x:523,y:800,t:1527876690990};\\\", \\\"{x:523,y:797,t:1527876690998};\\\", \\\"{x:523,y:791,t:1527876691015};\\\", \\\"{x:523,y:783,t:1527876691031};\\\", \\\"{x:523,y:775,t:1527876691049};\\\", \\\"{x:524,y:772,t:1527876691065};\\\", \\\"{x:524,y:771,t:1527876691083};\\\", \\\"{x:525,y:769,t:1527876691125};\\\", \\\"{x:525,y:768,t:1527876691134};\\\", \\\"{x:526,y:768,t:1527876691148};\\\", \\\"{x:527,y:765,t:1527876691166};\\\", \\\"{x:527,y:764,t:1527876691390};\\\", \\\"{x:517,y:764,t:1527876691819};\\\", \\\"{x:509,y:764,t:1527876691827};\\\", \\\"{x:494,y:764,t:1527876691838};\\\", \\\"{x:462,y:764,t:1527876691854};\\\", \\\"{x:404,y:756,t:1527876691871};\\\", \\\"{x:322,y:741,t:1527876691887};\\\", \\\"{x:236,y:730,t:1527876691904};\\\", \\\"{x:148,y:719,t:1527876691920};\\\", \\\"{x:76,y:701,t:1527876691938};\\\", \\\"{x:31,y:688,t:1527876691953};\\\", \\\"{x:0,y:676,t:1527876691971};\\\", \\\"{x:0,y:674,t:1527876691987};\\\", \\\"{x:0,y:670,t:1527876692003};\\\", \\\"{x:0,y:664,t:1527876692020};\\\", \\\"{x:0,y:658,t:1527876692037};\\\", \\\"{x:0,y:649,t:1527876692054};\\\", \\\"{x:0,y:641,t:1527876692070};\\\", \\\"{x:0,y:626,t:1527876692087};\\\", \\\"{x:15,y:606,t:1527876692104};\\\", \\\"{x:42,y:589,t:1527876692120};\\\", \\\"{x:74,y:573,t:1527876692137};\\\", \\\"{x:133,y:549,t:1527876692154};\\\", \\\"{x:184,y:546,t:1527876692170};\\\", \\\"{x:255,y:549,t:1527876692188};\\\", \\\"{x:329,y:557,t:1527876692205};\\\", \\\"{x:412,y:580,t:1527876692221};\\\", \\\"{x:498,y:601,t:1527876692237};\\\", \\\"{x:586,y:626,t:1527876692254};\\\", \\\"{x:648,y:645,t:1527876692270};\\\", \\\"{x:686,y:659,t:1527876692287};\\\", \\\"{x:708,y:669,t:1527876692304};\\\", \\\"{x:719,y:676,t:1527876692320};\\\", \\\"{x:722,y:682,t:1527876692347};\\\", \\\"{x:722,y:684,t:1527876692354};\\\", \\\"{x:722,y:689,t:1527876692370};\\\", \\\"{x:712,y:693,t:1527876692387};\\\", \\\"{x:702,y:697,t:1527876692404};\\\", \\\"{x:686,y:702,t:1527876692420};\\\", \\\"{x:665,y:709,t:1527876692437};\\\" ] }, { \\\"rt\\\": 30495, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 330390, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"2ZXKM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-G -A -A -A -I -O -O -O -O -O \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:341,y:1199,t:1527876692542};\\\", \\\"{x:385,y:1199,t:1527876692569};\\\", \\\"{x:434,y:1199,t:1527876692571};\\\", \\\"{x:576,y:1199,t:1527876692587};\\\", \\\"{x:763,y:1199,t:1527876692604};\\\", \\\"{x:947,y:1199,t:1527876692621};\\\", \\\"{x:1125,y:1199,t:1527876692637};\\\", \\\"{x:1297,y:1199,t:1527876692654};\\\", \\\"{x:1535,y:1199,t:1527876692685};\\\", \\\"{x:1615,y:1199,t:1527876692704};\\\", \\\"{x:1654,y:1192,t:1527876692722};\\\", \\\"{x:1677,y:1181,t:1527876692737};\\\", \\\"{x:1683,y:1171,t:1527876692753};\\\", \\\"{x:1683,y:1158,t:1527876692771};\\\", \\\"{x:1680,y:1137,t:1527876692787};\\\", \\\"{x:1663,y:1112,t:1527876692804};\\\", \\\"{x:1638,y:1086,t:1527876692821};\\\", \\\"{x:1597,y:1053,t:1527876692838};\\\", \\\"{x:1538,y:1008,t:1527876692854};\\\", \\\"{x:1454,y:946,t:1527876692871};\\\", \\\"{x:1362,y:878,t:1527876692888};\\\", \\\"{x:1267,y:812,t:1527876692904};\\\", \\\"{x:1181,y:755,t:1527876692921};\\\", \\\"{x:1065,y:677,t:1527876692938};\\\", \\\"{x:1006,y:638,t:1527876692954};\\\", \\\"{x:955,y:608,t:1527876692971};\\\", \\\"{x:924,y:590,t:1527876692988};\\\", \\\"{x:910,y:579,t:1527876693004};\\\", \\\"{x:907,y:575,t:1527876693021};\\\", \\\"{x:904,y:572,t:1527876693038};\\\", \\\"{x:892,y:564,t:1527876693099};\\\", \\\"{x:886,y:561,t:1527876693107};\\\", \\\"{x:879,y:560,t:1527876693121};\\\", \\\"{x:843,y:556,t:1527876693138};\\\", \\\"{x:812,y:552,t:1527876693155};\\\", \\\"{x:785,y:552,t:1527876693171};\\\", \\\"{x:741,y:552,t:1527876693188};\\\", \\\"{x:699,y:552,t:1527876693204};\\\", \\\"{x:672,y:552,t:1527876693221};\\\", \\\"{x:654,y:552,t:1527876693238};\\\", \\\"{x:643,y:553,t:1527876693254};\\\", \\\"{x:640,y:554,t:1527876693271};\\\", \\\"{x:636,y:556,t:1527876693288};\\\", \\\"{x:630,y:563,t:1527876693305};\\\", \\\"{x:627,y:573,t:1527876693321};\\\", \\\"{x:619,y:591,t:1527876693338};\\\", \\\"{x:615,y:597,t:1527876693355};\\\", \\\"{x:614,y:603,t:1527876693372};\\\", \\\"{x:611,y:607,t:1527876693388};\\\", \\\"{x:611,y:610,t:1527876693405};\\\", \\\"{x:611,y:613,t:1527876693421};\\\", \\\"{x:611,y:614,t:1527876693442};\\\", \\\"{x:610,y:615,t:1527876693474};\\\", \\\"{x:609,y:614,t:1527876694324};\\\", \\\"{x:608,y:613,t:1527876694339};\\\", \\\"{x:606,y:611,t:1527876694356};\\\", \\\"{x:605,y:611,t:1527876694373};\\\", \\\"{x:605,y:610,t:1527876694395};\\\", \\\"{x:604,y:609,t:1527876694443};\\\", \\\"{x:603,y:608,t:1527876694467};\\\", \\\"{x:602,y:608,t:1527876694507};\\\", \\\"{x:601,y:607,t:1527876694556};\\\", \\\"{x:600,y:606,t:1527876694595};\\\", \\\"{x:600,y:604,t:1527876695627};\\\", \\\"{x:603,y:599,t:1527876695641};\\\", \\\"{x:614,y:593,t:1527876695658};\\\", \\\"{x:621,y:590,t:1527876695673};\\\", \\\"{x:626,y:588,t:1527876695690};\\\", \\\"{x:627,y:587,t:1527876697228};\\\", \\\"{x:633,y:586,t:1527876697243};\\\", \\\"{x:695,y:586,t:1527876697258};\\\", \\\"{x:899,y:615,t:1527876697274};\\\", \\\"{x:1081,y:640,t:1527876697291};\\\", \\\"{x:1302,y:673,t:1527876697308};\\\", \\\"{x:1512,y:703,t:1527876697324};\\\", \\\"{x:1670,y:727,t:1527876697342};\\\", \\\"{x:1785,y:747,t:1527876697358};\\\", \\\"{x:1831,y:756,t:1527876697374};\\\", \\\"{x:1838,y:757,t:1527876697391};\\\", \\\"{x:1839,y:758,t:1527876697409};\\\", \\\"{x:1825,y:760,t:1527876697424};\\\", \\\"{x:1791,y:760,t:1527876697442};\\\", \\\"{x:1710,y:760,t:1527876697458};\\\", \\\"{x:1652,y:760,t:1527876697476};\\\", \\\"{x:1588,y:760,t:1527876697492};\\\", \\\"{x:1524,y:760,t:1527876697508};\\\", \\\"{x:1479,y:766,t:1527876697525};\\\", \\\"{x:1439,y:778,t:1527876697542};\\\", \\\"{x:1408,y:792,t:1527876697558};\\\", \\\"{x:1381,y:811,t:1527876697575};\\\", \\\"{x:1359,y:825,t:1527876697591};\\\", \\\"{x:1348,y:834,t:1527876697608};\\\", \\\"{x:1341,y:838,t:1527876697625};\\\", \\\"{x:1339,y:839,t:1527876697642};\\\", \\\"{x:1339,y:840,t:1527876697658};\\\", \\\"{x:1337,y:840,t:1527876697826};\\\", \\\"{x:1333,y:840,t:1527876697842};\\\", \\\"{x:1327,y:839,t:1527876697859};\\\", \\\"{x:1315,y:838,t:1527876697876};\\\", \\\"{x:1301,y:836,t:1527876697894};\\\", \\\"{x:1297,y:835,t:1527876697909};\\\", \\\"{x:1293,y:834,t:1527876697926};\\\", \\\"{x:1291,y:833,t:1527876697944};\\\", \\\"{x:1291,y:832,t:1527876697979};\\\", \\\"{x:1289,y:831,t:1527876698154};\\\", \\\"{x:1287,y:830,t:1527876698162};\\\", \\\"{x:1286,y:828,t:1527876698178};\\\", \\\"{x:1281,y:825,t:1527876698194};\\\", \\\"{x:1279,y:825,t:1527876698207};\\\", \\\"{x:1274,y:824,t:1527876698225};\\\", \\\"{x:1272,y:823,t:1527876698241};\\\", \\\"{x:1273,y:823,t:1527876698507};\\\", \\\"{x:1273,y:824,t:1527876698514};\\\", \\\"{x:1274,y:824,t:1527876698526};\\\", \\\"{x:1274,y:825,t:1527876698555};\\\", \\\"{x:1275,y:826,t:1527876698571};\\\", \\\"{x:1275,y:827,t:1527876698595};\\\", \\\"{x:1276,y:829,t:1527876698613};\\\", \\\"{x:1279,y:826,t:1527876703323};\\\", \\\"{x:1281,y:820,t:1527876703335};\\\", \\\"{x:1287,y:812,t:1527876703349};\\\", \\\"{x:1293,y:804,t:1527876703366};\\\", \\\"{x:1305,y:792,t:1527876703380};\\\", \\\"{x:1314,y:783,t:1527876703397};\\\", \\\"{x:1330,y:772,t:1527876703413};\\\", \\\"{x:1352,y:758,t:1527876703430};\\\", \\\"{x:1380,y:740,t:1527876703446};\\\", \\\"{x:1402,y:723,t:1527876703462};\\\", \\\"{x:1421,y:706,t:1527876703479};\\\", \\\"{x:1443,y:687,t:1527876703497};\\\", \\\"{x:1472,y:662,t:1527876703512};\\\", \\\"{x:1498,y:641,t:1527876703530};\\\", \\\"{x:1530,y:613,t:1527876703546};\\\", \\\"{x:1541,y:604,t:1527876703562};\\\", \\\"{x:1549,y:597,t:1527876703580};\\\", \\\"{x:1551,y:595,t:1527876703597};\\\", \\\"{x:1553,y:593,t:1527876703613};\\\", \\\"{x:1553,y:592,t:1527876703634};\\\", \\\"{x:1554,y:590,t:1527876703650};\\\", \\\"{x:1554,y:589,t:1527876703795};\\\", \\\"{x:1554,y:585,t:1527876703803};\\\", \\\"{x:1558,y:579,t:1527876703814};\\\", \\\"{x:1563,y:569,t:1527876703830};\\\", \\\"{x:1568,y:559,t:1527876703847};\\\", \\\"{x:1574,y:549,t:1527876703864};\\\", \\\"{x:1575,y:546,t:1527876703879};\\\", \\\"{x:1575,y:545,t:1527876703939};\\\", \\\"{x:1573,y:545,t:1527876703946};\\\", \\\"{x:1563,y:544,t:1527876703964};\\\", \\\"{x:1547,y:539,t:1527876703980};\\\", \\\"{x:1524,y:531,t:1527876703997};\\\", \\\"{x:1496,y:528,t:1527876704014};\\\", \\\"{x:1467,y:523,t:1527876704030};\\\", \\\"{x:1440,y:519,t:1527876704047};\\\", \\\"{x:1415,y:519,t:1527876704064};\\\", \\\"{x:1391,y:519,t:1527876704080};\\\", \\\"{x:1373,y:519,t:1527876704097};\\\", \\\"{x:1363,y:519,t:1527876704114};\\\", \\\"{x:1360,y:519,t:1527876704130};\\\", \\\"{x:1358,y:519,t:1527876704147};\\\", \\\"{x:1357,y:519,t:1527876704164};\\\", \\\"{x:1354,y:519,t:1527876704180};\\\", \\\"{x:1350,y:519,t:1527876704197};\\\", \\\"{x:1345,y:519,t:1527876704213};\\\", \\\"{x:1342,y:518,t:1527876704230};\\\", \\\"{x:1340,y:517,t:1527876704283};\\\", \\\"{x:1339,y:516,t:1527876704297};\\\", \\\"{x:1334,y:511,t:1527876704314};\\\", \\\"{x:1316,y:504,t:1527876704331};\\\", \\\"{x:1303,y:500,t:1527876704349};\\\", \\\"{x:1296,y:500,t:1527876704364};\\\", \\\"{x:1293,y:500,t:1527876704381};\\\", \\\"{x:1293,y:498,t:1527876704508};\\\", \\\"{x:1297,y:497,t:1527876704515};\\\", \\\"{x:1303,y:496,t:1527876704531};\\\", \\\"{x:1307,y:494,t:1527876704548};\\\", \\\"{x:1309,y:494,t:1527876704569};\\\", \\\"{x:1312,y:494,t:1527876704581};\\\", \\\"{x:1314,y:494,t:1527876704602};\\\", \\\"{x:1315,y:494,t:1527876704618};\\\", \\\"{x:1316,y:494,t:1527876704631};\\\", \\\"{x:1317,y:494,t:1527876704698};\\\", \\\"{x:1317,y:495,t:1527876704722};\\\", \\\"{x:1317,y:502,t:1527876714653};\\\", \\\"{x:1317,y:540,t:1527876714671};\\\", \\\"{x:1317,y:580,t:1527876714688};\\\", \\\"{x:1317,y:617,t:1527876714705};\\\", \\\"{x:1313,y:665,t:1527876714722};\\\", \\\"{x:1313,y:683,t:1527876714739};\\\", \\\"{x:1313,y:694,t:1527876714755};\\\", \\\"{x:1313,y:700,t:1527876714772};\\\", \\\"{x:1313,y:702,t:1527876714789};\\\", \\\"{x:1313,y:700,t:1527876714938};\\\", \\\"{x:1313,y:694,t:1527876714946};\\\", \\\"{x:1312,y:686,t:1527876714955};\\\", \\\"{x:1312,y:669,t:1527876714972};\\\", \\\"{x:1311,y:654,t:1527876714989};\\\", \\\"{x:1309,y:644,t:1527876715006};\\\", \\\"{x:1309,y:635,t:1527876715022};\\\", \\\"{x:1309,y:631,t:1527876715040};\\\", \\\"{x:1309,y:627,t:1527876715055};\\\", \\\"{x:1309,y:622,t:1527876715073};\\\", \\\"{x:1309,y:620,t:1527876715089};\\\", \\\"{x:1309,y:619,t:1527876715106};\\\", \\\"{x:1309,y:618,t:1527876715138};\\\", \\\"{x:1309,y:617,t:1527876715146};\\\", \\\"{x:1309,y:616,t:1527876715162};\\\", \\\"{x:1309,y:615,t:1527876715178};\\\", \\\"{x:1310,y:612,t:1527876715189};\\\", \\\"{x:1311,y:610,t:1527876715206};\\\", \\\"{x:1311,y:611,t:1527876715323};\\\", \\\"{x:1311,y:617,t:1527876715339};\\\", \\\"{x:1311,y:620,t:1527876715357};\\\", \\\"{x:1311,y:624,t:1527876715373};\\\", \\\"{x:1311,y:626,t:1527876715393};\\\", \\\"{x:1311,y:627,t:1527876715406};\\\", \\\"{x:1311,y:628,t:1527876717538};\\\", \\\"{x:1305,y:631,t:1527876717547};\\\", \\\"{x:1293,y:631,t:1527876717555};\\\", \\\"{x:1270,y:631,t:1527876717572};\\\", \\\"{x:1243,y:631,t:1527876717591};\\\", \\\"{x:1216,y:631,t:1527876717608};\\\", \\\"{x:1195,y:631,t:1527876717624};\\\", \\\"{x:1182,y:631,t:1527876717641};\\\", \\\"{x:1165,y:631,t:1527876717657};\\\", \\\"{x:1152,y:634,t:1527876717674};\\\", \\\"{x:1135,y:636,t:1527876717691};\\\", \\\"{x:1108,y:642,t:1527876717708};\\\", \\\"{x:1069,y:647,t:1527876717724};\\\", \\\"{x:1011,y:655,t:1527876717741};\\\", \\\"{x:925,y:667,t:1527876717759};\\\", \\\"{x:815,y:675,t:1527876717774};\\\", \\\"{x:682,y:675,t:1527876717792};\\\", \\\"{x:544,y:675,t:1527876717808};\\\", \\\"{x:417,y:675,t:1527876717825};\\\", \\\"{x:306,y:675,t:1527876717841};\\\", \\\"{x:208,y:675,t:1527876717858};\\\", \\\"{x:183,y:675,t:1527876717875};\\\", \\\"{x:176,y:675,t:1527876717891};\\\", \\\"{x:181,y:673,t:1527876718194};\\\", \\\"{x:185,y:672,t:1527876718210};\\\", \\\"{x:196,y:669,t:1527876718225};\\\", \\\"{x:212,y:667,t:1527876718241};\\\", \\\"{x:234,y:665,t:1527876718257};\\\", \\\"{x:251,y:664,t:1527876718274};\\\", \\\"{x:266,y:664,t:1527876718291};\\\", \\\"{x:281,y:664,t:1527876718308};\\\", \\\"{x:289,y:664,t:1527876718325};\\\", \\\"{x:299,y:664,t:1527876718341};\\\", \\\"{x:310,y:664,t:1527876718358};\\\", \\\"{x:316,y:664,t:1527876718375};\\\", \\\"{x:324,y:664,t:1527876718391};\\\", \\\"{x:328,y:664,t:1527876718408};\\\", \\\"{x:334,y:664,t:1527876718425};\\\", \\\"{x:338,y:664,t:1527876718441};\\\", \\\"{x:342,y:664,t:1527876718458};\\\", \\\"{x:345,y:664,t:1527876718475};\\\", \\\"{x:347,y:664,t:1527876718491};\\\", \\\"{x:349,y:664,t:1527876718508};\\\", \\\"{x:350,y:664,t:1527876718529};\\\", \\\"{x:351,y:664,t:1527876720386};\\\", \\\"{x:353,y:664,t:1527876720402};\\\", \\\"{x:357,y:665,t:1527876720409};\\\", \\\"{x:364,y:666,t:1527876720426};\\\", \\\"{x:371,y:667,t:1527876720443};\\\", \\\"{x:376,y:668,t:1527876720461};\\\", \\\"{x:377,y:668,t:1527876720476};\\\", \\\"{x:378,y:669,t:1527876720493};\\\", \\\"{x:379,y:669,t:1527876720522};\\\", \\\"{x:380,y:669,t:1527876720530};\\\", \\\"{x:381,y:669,t:1527876720543};\\\", \\\"{x:384,y:671,t:1527876720561};\\\", \\\"{x:385,y:671,t:1527876720577};\\\", \\\"{x:386,y:672,t:1527876720593};\\\", \\\"{x:387,y:672,t:1527876720602};\\\", \\\"{x:389,y:672,t:1527876720649};\\\", \\\"{x:390,y:673,t:1527876720658};\\\", \\\"{x:391,y:673,t:1527876720668};\\\", \\\"{x:393,y:673,t:1527876720694};\\\", \\\"{x:397,y:675,t:1527876720710};\\\", \\\"{x:400,y:675,t:1527876720727};\\\", \\\"{x:402,y:675,t:1527876720743};\\\", \\\"{x:405,y:675,t:1527876720760};\\\", \\\"{x:409,y:675,t:1527876720777};\\\", \\\"{x:411,y:675,t:1527876720793};\\\", \\\"{x:412,y:675,t:1527876720841};\\\", \\\"{x:413,y:674,t:1527876720865};\\\", \\\"{x:413,y:673,t:1527876720877};\\\", \\\"{x:414,y:672,t:1527876720893};\\\", \\\"{x:416,y:669,t:1527876720911};\\\", \\\"{x:419,y:666,t:1527876720927};\\\", \\\"{x:424,y:660,t:1527876720944};\\\", \\\"{x:434,y:654,t:1527876720960};\\\", \\\"{x:456,y:645,t:1527876720977};\\\", \\\"{x:483,y:641,t:1527876720993};\\\", \\\"{x:526,y:635,t:1527876721010};\\\", \\\"{x:588,y:625,t:1527876721027};\\\", \\\"{x:657,y:616,t:1527876721044};\\\", \\\"{x:727,y:606,t:1527876721061};\\\", \\\"{x:767,y:599,t:1527876721077};\\\", \\\"{x:791,y:596,t:1527876721093};\\\", \\\"{x:797,y:595,t:1527876721109};\\\", \\\"{x:798,y:595,t:1527876721169};\\\", \\\"{x:798,y:594,t:1527876721193};\\\", \\\"{x:806,y:588,t:1527876721210};\\\", \\\"{x:824,y:574,t:1527876721227};\\\", \\\"{x:834,y:569,t:1527876721244};\\\", \\\"{x:847,y:562,t:1527876721260};\\\", \\\"{x:855,y:559,t:1527876721277};\\\", \\\"{x:857,y:558,t:1527876721294};\\\", \\\"{x:855,y:558,t:1527876721650};\\\", \\\"{x:852,y:558,t:1527876721660};\\\", \\\"{x:849,y:560,t:1527876721677};\\\", \\\"{x:848,y:560,t:1527876721714};\\\", \\\"{x:847,y:560,t:1527876721738};\\\", \\\"{x:846,y:560,t:1527876721753};\\\", \\\"{x:846,y:561,t:1527876721761};\\\", \\\"{x:845,y:561,t:1527876721777};\\\", \\\"{x:843,y:562,t:1527876721794};\\\", \\\"{x:842,y:563,t:1527876721826};\\\", \\\"{x:841,y:563,t:1527876721945};\\\", \\\"{x:840,y:564,t:1527876721961};\\\", \\\"{x:839,y:566,t:1527876721977};\\\", \\\"{x:839,y:566,t:1527876721995};\\\", \\\"{x:838,y:567,t:1527876722065};\\\", \\\"{x:837,y:568,t:1527876722097};\\\", \\\"{x:836,y:570,t:1527876722138};\\\", \\\"{x:835,y:570,t:1527876722289};\\\", \\\"{x:833,y:572,t:1527876722306};\\\", \\\"{x:833,y:574,t:1527876722313};\\\", \\\"{x:832,y:575,t:1527876722328};\\\", \\\"{x:818,y:596,t:1527876722346};\\\", \\\"{x:807,y:608,t:1527876722361};\\\", \\\"{x:728,y:695,t:1527876722378};\\\", \\\"{x:653,y:764,t:1527876722394};\\\", \\\"{x:592,y:806,t:1527876722411};\\\", \\\"{x:565,y:826,t:1527876722428};\\\", \\\"{x:553,y:833,t:1527876722445};\\\", \\\"{x:548,y:835,t:1527876722461};\\\", \\\"{x:547,y:836,t:1527876722478};\\\", \\\"{x:545,y:836,t:1527876722498};\\\", \\\"{x:541,y:836,t:1527876722511};\\\", \\\"{x:526,y:839,t:1527876722528};\\\", \\\"{x:509,y:839,t:1527876722545};\\\", \\\"{x:490,y:839,t:1527876722561};\\\", \\\"{x:487,y:837,t:1527876722578};\\\", \\\"{x:483,y:833,t:1527876722596};\\\", \\\"{x:481,y:831,t:1527876722611};\\\", \\\"{x:481,y:827,t:1527876722628};\\\", \\\"{x:481,y:824,t:1527876722645};\\\", \\\"{x:481,y:818,t:1527876722661};\\\", \\\"{x:481,y:814,t:1527876722678};\\\", \\\"{x:483,y:809,t:1527876722695};\\\", \\\"{x:486,y:802,t:1527876722711};\\\", \\\"{x:488,y:798,t:1527876722728};\\\", \\\"{x:494,y:790,t:1527876722746};\\\", \\\"{x:495,y:788,t:1527876722761};\\\", \\\"{x:503,y:780,t:1527876722780};\\\", \\\"{x:508,y:773,t:1527876722795};\\\", \\\"{x:515,y:766,t:1527876722811};\\\", \\\"{x:520,y:762,t:1527876722828};\\\", \\\"{x:521,y:761,t:1527876722846};\\\", \\\"{x:521,y:764,t:1527876723467};\\\", \\\"{x:521,y:772,t:1527876723479};\\\", \\\"{x:521,y:796,t:1527876723496};\\\", \\\"{x:523,y:845,t:1527876723512};\\\", \\\"{x:604,y:1005,t:1527876723530};\\\", \\\"{x:666,y:1061,t:1527876723545};\\\", \\\"{x:960,y:1188,t:1527876723562};\\\", \\\"{x:1239,y:1199,t:1527876723579};\\\", \\\"{x:1563,y:1199,t:1527876723595};\\\", \\\"{x:1881,y:1199,t:1527876723612};\\\", \\\"{x:1919,y:1199,t:1527876723630};\\\", \\\"{x:1919,y:1164,t:1527876723645};\\\", \\\"{x:1919,y:1100,t:1527876723662};\\\", \\\"{x:1919,y:1028,t:1527876723679};\\\", \\\"{x:1919,y:948,t:1527876723695};\\\", \\\"{x:1919,y:882,t:1527876723712};\\\", \\\"{x:1919,y:822,t:1527876723729};\\\", \\\"{x:1919,y:788,t:1527876723745};\\\", \\\"{x:1899,y:734,t:1527876723762};\\\", \\\"{x:1818,y:660,t:1527876723779};\\\", \\\"{x:1671,y:546,t:1527876723795};\\\", \\\"{x:1493,y:418,t:1527876723812};\\\", \\\"{x:1307,y:311,t:1527876723829};\\\", \\\"{x:1128,y:237,t:1527876723847};\\\", \\\"{x:938,y:159,t:1527876723862};\\\", \\\"{x:733,y:86,t:1527876723879};\\\", \\\"{x:532,y:31,t:1527876723896};\\\", \\\"{x:344,y:0,t:1527876723912};\\\", \\\"{x:96,y:0,t:1527876723930};\\\", \\\"{x:0,y:0,t:1527876723946};\\\", \\\"{x:59,y:0,t:1527876724090};\\\", \\\"{x:117,y:1,t:1527876724097};\\\", \\\"{x:187,y:3,t:1527876724112};\\\", \\\"{x:298,y:3,t:1527876724129};\\\", \\\"{x:362,y:3,t:1527876724146};\\\", \\\"{x:425,y:17,t:1527876724163};\\\" ] }, { \\\"rt\\\": 47623, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 379242, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"2ZXKM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"C\\\", \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -I -I -J -M -M -B -B -B -B -F -F -H -02 PM-12 PM-11 AM-08 AM-03 PM-X -12 PM-12 PM-01 PM-02 PM-03 PM-04 PM-03 PM-11 AM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:722,y:101,t:1527876724272};\\\", \\\"{x:724,y:102,t:1527876724554};\\\", \\\"{x:727,y:106,t:1527876724564};\\\", \\\"{x:748,y:124,t:1527876724579};\\\", \\\"{x:792,y:161,t:1527876724596};\\\", \\\"{x:865,y:234,t:1527876724613};\\\", \\\"{x:934,y:334,t:1527876724630};\\\", \\\"{x:983,y:460,t:1527876724647};\\\", \\\"{x:1015,y:582,t:1527876724664};\\\", \\\"{x:1038,y:675,t:1527876724681};\\\", \\\"{x:1046,y:713,t:1527876724697};\\\", \\\"{x:1048,y:727,t:1527876724713};\\\", \\\"{x:1048,y:728,t:1527876724730};\\\", \\\"{x:1048,y:729,t:1527876724769};\\\", \\\"{x:1001,y:713,t:1527876724852};\\\", \\\"{x:985,y:705,t:1527876724865};\\\", \\\"{x:940,y:683,t:1527876724881};\\\", \\\"{x:901,y:660,t:1527876724896};\\\", \\\"{x:880,y:647,t:1527876724913};\\\", \\\"{x:875,y:641,t:1527876724930};\\\", \\\"{x:874,y:637,t:1527876724946};\\\", \\\"{x:885,y:627,t:1527876724964};\\\", \\\"{x:916,y:603,t:1527876724980};\\\", \\\"{x:983,y:561,t:1527876724997};\\\", \\\"{x:1073,y:523,t:1527876725013};\\\", \\\"{x:1159,y:500,t:1527876725030};\\\", \\\"{x:1250,y:477,t:1527876725047};\\\", \\\"{x:1330,y:466,t:1527876725063};\\\", \\\"{x:1384,y:459,t:1527876725080};\\\", \\\"{x:1446,y:459,t:1527876725097};\\\", \\\"{x:1477,y:459,t:1527876725113};\\\", \\\"{x:1500,y:459,t:1527876725130};\\\", \\\"{x:1519,y:459,t:1527876725148};\\\", \\\"{x:1531,y:459,t:1527876725164};\\\", \\\"{x:1535,y:459,t:1527876725180};\\\", \\\"{x:1536,y:459,t:1527876725197};\\\", \\\"{x:1538,y:463,t:1527876725213};\\\", \\\"{x:1540,y:472,t:1527876725230};\\\", \\\"{x:1542,y:490,t:1527876725247};\\\", \\\"{x:1545,y:506,t:1527876725263};\\\", \\\"{x:1550,y:523,t:1527876725280};\\\", \\\"{x:1553,y:552,t:1527876725297};\\\", \\\"{x:1553,y:577,t:1527876725314};\\\", \\\"{x:1540,y:607,t:1527876725330};\\\", \\\"{x:1527,y:642,t:1527876725347};\\\", \\\"{x:1515,y:677,t:1527876725363};\\\", \\\"{x:1507,y:698,t:1527876725380};\\\", \\\"{x:1502,y:709,t:1527876725397};\\\", \\\"{x:1500,y:713,t:1527876725413};\\\", \\\"{x:1498,y:716,t:1527876725431};\\\", \\\"{x:1496,y:716,t:1527876725447};\\\", \\\"{x:1494,y:717,t:1527876725463};\\\", \\\"{x:1489,y:720,t:1527876725480};\\\", \\\"{x:1473,y:730,t:1527876725498};\\\", \\\"{x:1454,y:739,t:1527876725513};\\\", \\\"{x:1437,y:747,t:1527876725530};\\\", \\\"{x:1420,y:751,t:1527876725547};\\\", \\\"{x:1400,y:754,t:1527876725564};\\\", \\\"{x:1379,y:754,t:1527876725580};\\\", \\\"{x:1355,y:754,t:1527876725597};\\\", \\\"{x:1331,y:754,t:1527876725615};\\\", \\\"{x:1309,y:754,t:1527876725630};\\\", \\\"{x:1290,y:754,t:1527876725647};\\\", \\\"{x:1274,y:754,t:1527876725663};\\\", \\\"{x:1261,y:754,t:1527876725680};\\\", \\\"{x:1245,y:754,t:1527876725698};\\\", \\\"{x:1236,y:754,t:1527876725714};\\\", \\\"{x:1228,y:754,t:1527876725731};\\\", \\\"{x:1224,y:754,t:1527876725748};\\\", \\\"{x:1219,y:754,t:1527876725764};\\\", \\\"{x:1215,y:756,t:1527876725780};\\\", \\\"{x:1213,y:757,t:1527876725797};\\\", \\\"{x:1211,y:757,t:1527876725814};\\\", \\\"{x:1210,y:759,t:1527876725831};\\\", \\\"{x:1208,y:759,t:1527876725847};\\\", \\\"{x:1207,y:760,t:1527876725865};\\\", \\\"{x:1205,y:761,t:1527876725880};\\\", \\\"{x:1200,y:764,t:1527876725898};\\\", \\\"{x:1198,y:766,t:1527876725914};\\\", \\\"{x:1196,y:767,t:1527876725930};\\\", \\\"{x:1192,y:769,t:1527876725947};\\\", \\\"{x:1190,y:770,t:1527876725964};\\\", \\\"{x:1187,y:771,t:1527876725980};\\\", \\\"{x:1186,y:771,t:1527876725997};\\\", \\\"{x:1184,y:771,t:1527876726014};\\\", \\\"{x:1183,y:771,t:1527876726031};\\\", \\\"{x:1180,y:771,t:1527876726047};\\\", \\\"{x:1178,y:771,t:1527876726064};\\\", \\\"{x:1172,y:773,t:1527876726081};\\\", \\\"{x:1170,y:773,t:1527876726097};\\\", \\\"{x:1170,y:772,t:1527876726393};\\\", \\\"{x:1171,y:772,t:1527876726434};\\\", \\\"{x:1173,y:771,t:1527876726448};\\\", \\\"{x:1175,y:770,t:1527876726466};\\\", \\\"{x:1178,y:770,t:1527876726482};\\\", \\\"{x:1179,y:770,t:1527876726514};\\\", \\\"{x:1180,y:769,t:1527876726521};\\\", \\\"{x:1181,y:769,t:1527876726555};\\\", \\\"{x:1182,y:769,t:1527876726810};\\\", \\\"{x:1183,y:768,t:1527876726818};\\\", \\\"{x:1185,y:767,t:1527876726849};\\\", \\\"{x:1186,y:766,t:1527876726873};\\\", \\\"{x:1186,y:765,t:1527876727090};\\\", \\\"{x:1186,y:763,t:1527876727098};\\\", \\\"{x:1186,y:762,t:1527876727114};\\\", \\\"{x:1186,y:761,t:1527876727131};\\\", \\\"{x:1185,y:761,t:1527876727233};\\\", \\\"{x:1183,y:761,t:1527876727305};\\\", \\\"{x:1182,y:761,t:1527876727378};\\\", \\\"{x:1180,y:762,t:1527876727633};\\\", \\\"{x:1179,y:762,t:1527876727673};\\\", \\\"{x:1178,y:760,t:1527876728217};\\\", \\\"{x:1178,y:755,t:1527876728233};\\\", \\\"{x:1169,y:725,t:1527876728249};\\\", \\\"{x:1167,y:716,t:1527876728265};\\\", \\\"{x:1167,y:714,t:1527876728283};\\\", \\\"{x:1167,y:713,t:1527876728299};\\\", \\\"{x:1167,y:709,t:1527876728316};\\\", \\\"{x:1167,y:706,t:1527876728332};\\\", \\\"{x:1167,y:699,t:1527876728350};\\\", \\\"{x:1167,y:693,t:1527876728365};\\\", \\\"{x:1167,y:690,t:1527876728382};\\\", \\\"{x:1167,y:689,t:1527876728399};\\\", \\\"{x:1167,y:691,t:1527876728506};\\\", \\\"{x:1167,y:694,t:1527876728515};\\\", \\\"{x:1167,y:703,t:1527876728532};\\\", \\\"{x:1167,y:713,t:1527876728549};\\\", \\\"{x:1169,y:723,t:1527876728565};\\\", \\\"{x:1170,y:728,t:1527876728582};\\\", \\\"{x:1173,y:733,t:1527876728599};\\\", \\\"{x:1174,y:735,t:1527876728617};\\\", \\\"{x:1175,y:737,t:1527876728633};\\\", \\\"{x:1176,y:741,t:1527876728650};\\\", \\\"{x:1178,y:743,t:1527876728666};\\\", \\\"{x:1181,y:750,t:1527876728682};\\\", \\\"{x:1183,y:753,t:1527876728700};\\\", \\\"{x:1184,y:755,t:1527876728716};\\\", \\\"{x:1185,y:757,t:1527876728733};\\\", \\\"{x:1185,y:758,t:1527876728750};\\\", \\\"{x:1187,y:761,t:1527876728766};\\\", \\\"{x:1188,y:763,t:1527876728782};\\\", \\\"{x:1188,y:764,t:1527876728801};\\\", \\\"{x:1189,y:765,t:1527876728817};\\\", \\\"{x:1189,y:766,t:1527876728832};\\\", \\\"{x:1189,y:767,t:1527876728849};\\\", \\\"{x:1189,y:769,t:1527876728905};\\\", \\\"{x:1189,y:770,t:1527876728921};\\\", \\\"{x:1189,y:772,t:1527876728932};\\\", \\\"{x:1190,y:774,t:1527876728949};\\\", \\\"{x:1191,y:780,t:1527876728966};\\\", \\\"{x:1195,y:791,t:1527876728983};\\\", \\\"{x:1197,y:798,t:1527876729000};\\\", \\\"{x:1199,y:803,t:1527876729017};\\\", \\\"{x:1200,y:807,t:1527876729033};\\\", \\\"{x:1201,y:809,t:1527876729050};\\\", \\\"{x:1203,y:815,t:1527876729066};\\\", \\\"{x:1206,y:821,t:1527876729083};\\\", \\\"{x:1209,y:826,t:1527876729100};\\\", \\\"{x:1211,y:829,t:1527876729117};\\\", \\\"{x:1212,y:830,t:1527876729149};\\\", \\\"{x:1213,y:830,t:1527876729186};\\\", \\\"{x:1214,y:830,t:1527876729355};\\\", \\\"{x:1216,y:830,t:1527876729467};\\\", \\\"{x:1217,y:830,t:1527876729491};\\\", \\\"{x:1219,y:830,t:1527876729500};\\\", \\\"{x:1225,y:834,t:1527876729518};\\\", \\\"{x:1245,y:845,t:1527876729534};\\\", \\\"{x:1274,y:862,t:1527876729550};\\\", \\\"{x:1310,y:878,t:1527876729567};\\\", \\\"{x:1349,y:894,t:1527876729585};\\\", \\\"{x:1380,y:902,t:1527876729600};\\\", \\\"{x:1404,y:908,t:1527876729618};\\\", \\\"{x:1426,y:910,t:1527876729635};\\\", \\\"{x:1430,y:910,t:1527876729650};\\\", \\\"{x:1431,y:910,t:1527876729730};\\\", \\\"{x:1432,y:910,t:1527876729779};\\\", \\\"{x:1432,y:909,t:1527876729810};\\\", \\\"{x:1431,y:908,t:1527876729835};\\\", \\\"{x:1430,y:908,t:1527876729866};\\\", \\\"{x:1430,y:907,t:1527876729892};\\\", \\\"{x:1428,y:906,t:1527876729906};\\\", \\\"{x:1427,y:905,t:1527876729930};\\\", \\\"{x:1426,y:905,t:1527876729938};\\\", \\\"{x:1423,y:904,t:1527876729951};\\\", \\\"{x:1417,y:902,t:1527876729967};\\\", \\\"{x:1415,y:901,t:1527876729984};\\\", \\\"{x:1411,y:899,t:1527876730001};\\\", \\\"{x:1409,y:898,t:1527876730017};\\\", \\\"{x:1407,y:897,t:1527876730035};\\\", \\\"{x:1404,y:897,t:1527876730051};\\\", \\\"{x:1401,y:894,t:1527876730067};\\\", \\\"{x:1399,y:892,t:1527876730085};\\\", \\\"{x:1398,y:892,t:1527876730102};\\\", \\\"{x:1397,y:892,t:1527876730251};\\\", \\\"{x:1396,y:892,t:1527876730268};\\\", \\\"{x:1394,y:892,t:1527876730284};\\\", \\\"{x:1393,y:892,t:1527876730306};\\\", \\\"{x:1392,y:892,t:1527876730318};\\\", \\\"{x:1391,y:893,t:1527876730334};\\\", \\\"{x:1390,y:893,t:1527876730369};\\\", \\\"{x:1389,y:893,t:1527876730384};\\\", \\\"{x:1387,y:893,t:1527876730400};\\\", \\\"{x:1387,y:894,t:1527876730434};\\\", \\\"{x:1386,y:895,t:1527876730450};\\\", \\\"{x:1385,y:895,t:1527876730468};\\\", \\\"{x:1384,y:896,t:1527876730484};\\\", \\\"{x:1383,y:896,t:1527876730513};\\\", \\\"{x:1382,y:896,t:1527876730521};\\\", \\\"{x:1381,y:897,t:1527876730533};\\\", \\\"{x:1381,y:898,t:1527876730550};\\\", \\\"{x:1380,y:898,t:1527876730569};\\\", \\\"{x:1379,y:898,t:1527876730810};\\\", \\\"{x:1378,y:898,t:1527876730817};\\\", \\\"{x:1375,y:897,t:1527876730835};\\\", \\\"{x:1372,y:894,t:1527876730851};\\\", \\\"{x:1371,y:893,t:1527876730970};\\\", \\\"{x:1371,y:889,t:1527876730985};\\\", \\\"{x:1367,y:879,t:1527876731000};\\\", \\\"{x:1357,y:843,t:1527876731017};\\\", \\\"{x:1349,y:813,t:1527876731035};\\\", \\\"{x:1336,y:781,t:1527876731050};\\\", \\\"{x:1325,y:757,t:1527876731067};\\\", \\\"{x:1320,y:741,t:1527876731084};\\\", \\\"{x:1318,y:727,t:1527876731100};\\\", \\\"{x:1314,y:715,t:1527876731118};\\\", \\\"{x:1314,y:709,t:1527876731135};\\\", \\\"{x:1314,y:704,t:1527876731151};\\\", \\\"{x:1314,y:702,t:1527876731167};\\\", \\\"{x:1314,y:701,t:1527876731185};\\\", \\\"{x:1315,y:700,t:1527876731257};\\\", \\\"{x:1317,y:701,t:1527876731267};\\\", \\\"{x:1320,y:705,t:1527876731284};\\\", \\\"{x:1322,y:708,t:1527876731301};\\\", \\\"{x:1322,y:713,t:1527876731318};\\\", \\\"{x:1324,y:719,t:1527876731334};\\\", \\\"{x:1327,y:728,t:1527876731351};\\\", \\\"{x:1329,y:736,t:1527876731367};\\\", \\\"{x:1331,y:740,t:1527876731385};\\\", \\\"{x:1331,y:742,t:1527876731401};\\\", \\\"{x:1332,y:743,t:1527876731418};\\\", \\\"{x:1333,y:744,t:1527876731434};\\\", \\\"{x:1334,y:745,t:1527876731452};\\\", \\\"{x:1336,y:745,t:1527876731467};\\\", \\\"{x:1337,y:746,t:1527876731485};\\\", \\\"{x:1337,y:747,t:1527876731502};\\\", \\\"{x:1339,y:748,t:1527876731517};\\\", \\\"{x:1344,y:752,t:1527876731535};\\\", \\\"{x:1347,y:755,t:1527876731552};\\\", \\\"{x:1350,y:759,t:1527876731568};\\\", \\\"{x:1352,y:762,t:1527876731584};\\\", \\\"{x:1355,y:765,t:1527876731601};\\\", \\\"{x:1356,y:766,t:1527876731641};\\\", \\\"{x:1354,y:766,t:1527876731825};\\\", \\\"{x:1352,y:766,t:1527876731834};\\\", \\\"{x:1349,y:765,t:1527876731851};\\\", \\\"{x:1348,y:764,t:1527876731868};\\\", \\\"{x:1347,y:763,t:1527876731885};\\\", \\\"{x:1347,y:761,t:1527876732145};\\\", \\\"{x:1347,y:758,t:1527876732153};\\\", \\\"{x:1347,y:755,t:1527876732169};\\\", \\\"{x:1347,y:746,t:1527876732184};\\\", \\\"{x:1345,y:725,t:1527876732202};\\\", \\\"{x:1343,y:713,t:1527876732218};\\\", \\\"{x:1342,y:707,t:1527876732234};\\\", \\\"{x:1341,y:704,t:1527876732252};\\\", \\\"{x:1341,y:702,t:1527876732269};\\\", \\\"{x:1341,y:701,t:1527876732286};\\\", \\\"{x:1341,y:700,t:1527876732302};\\\", \\\"{x:1341,y:698,t:1527876732318};\\\", \\\"{x:1341,y:697,t:1527876732336};\\\", \\\"{x:1341,y:695,t:1527876732352};\\\", \\\"{x:1341,y:694,t:1527876732369};\\\", \\\"{x:1341,y:692,t:1527876732386};\\\", \\\"{x:1342,y:692,t:1527876732473};\\\", \\\"{x:1342,y:691,t:1527876732486};\\\", \\\"{x:1343,y:691,t:1527876732514};\\\", \\\"{x:1343,y:693,t:1527876732706};\\\", \\\"{x:1342,y:695,t:1527876732719};\\\", \\\"{x:1341,y:696,t:1527876732736};\\\", \\\"{x:1336,y:698,t:1527876732751};\\\", \\\"{x:1332,y:699,t:1527876732769};\\\", \\\"{x:1318,y:699,t:1527876732786};\\\", \\\"{x:1287,y:689,t:1527876732803};\\\", \\\"{x:1229,y:663,t:1527876732818};\\\", \\\"{x:1133,y:623,t:1527876732836};\\\", \\\"{x:1015,y:575,t:1527876732853};\\\", \\\"{x:872,y:520,t:1527876732869};\\\", \\\"{x:722,y:471,t:1527876732886};\\\", \\\"{x:589,y:426,t:1527876732903};\\\", \\\"{x:478,y:395,t:1527876732919};\\\", \\\"{x:395,y:371,t:1527876732936};\\\", \\\"{x:341,y:355,t:1527876732953};\\\", \\\"{x:319,y:349,t:1527876732969};\\\", \\\"{x:308,y:346,t:1527876732985};\\\", \\\"{x:308,y:350,t:1527876733073};\\\", \\\"{x:308,y:356,t:1527876733086};\\\", \\\"{x:309,y:367,t:1527876733103};\\\", \\\"{x:321,y:388,t:1527876733119};\\\", \\\"{x:336,y:407,t:1527876733136};\\\", \\\"{x:357,y:424,t:1527876733152};\\\", \\\"{x:382,y:438,t:1527876733169};\\\", \\\"{x:462,y:474,t:1527876733186};\\\", \\\"{x:534,y:494,t:1527876733204};\\\", \\\"{x:612,y:507,t:1527876733220};\\\", \\\"{x:753,y:523,t:1527876733253};\\\", \\\"{x:783,y:523,t:1527876733264};\\\", \\\"{x:842,y:523,t:1527876733280};\\\", \\\"{x:956,y:523,t:1527876733297};\\\", \\\"{x:1014,y:523,t:1527876733315};\\\", \\\"{x:1059,y:523,t:1527876733331};\\\", \\\"{x:1100,y:519,t:1527876733347};\\\", \\\"{x:1149,y:516,t:1527876733365};\\\", \\\"{x:1207,y:511,t:1527876733380};\\\", \\\"{x:1278,y:504,t:1527876733398};\\\", \\\"{x:1321,y:497,t:1527876733415};\\\", \\\"{x:1346,y:494,t:1527876733431};\\\", \\\"{x:1354,y:490,t:1527876733448};\\\", \\\"{x:1355,y:489,t:1527876733466};\\\", \\\"{x:1353,y:488,t:1527876733578};\\\", \\\"{x:1343,y:482,t:1527876733586};\\\", \\\"{x:1338,y:480,t:1527876733598};\\\", \\\"{x:1325,y:475,t:1527876733616};\\\", \\\"{x:1315,y:472,t:1527876733631};\\\", \\\"{x:1301,y:469,t:1527876733648};\\\", \\\"{x:1290,y:466,t:1527876733665};\\\", \\\"{x:1282,y:463,t:1527876733681};\\\", \\\"{x:1279,y:463,t:1527876733698};\\\", \\\"{x:1277,y:463,t:1527876733770};\\\", \\\"{x:1277,y:466,t:1527876733781};\\\", \\\"{x:1277,y:481,t:1527876733798};\\\", \\\"{x:1278,y:500,t:1527876733815};\\\", \\\"{x:1285,y:524,t:1527876733831};\\\", \\\"{x:1292,y:549,t:1527876733848};\\\", \\\"{x:1304,y:581,t:1527876733865};\\\", \\\"{x:1318,y:614,t:1527876733881};\\\", \\\"{x:1342,y:668,t:1527876733898};\\\", \\\"{x:1355,y:687,t:1527876733915};\\\", \\\"{x:1365,y:701,t:1527876733931};\\\", \\\"{x:1370,y:708,t:1527876733948};\\\", \\\"{x:1376,y:715,t:1527876733965};\\\", \\\"{x:1384,y:724,t:1527876733981};\\\", \\\"{x:1394,y:735,t:1527876733998};\\\", \\\"{x:1413,y:751,t:1527876734015};\\\", \\\"{x:1437,y:769,t:1527876734031};\\\", \\\"{x:1459,y:782,t:1527876734048};\\\", \\\"{x:1485,y:793,t:1527876734064};\\\", \\\"{x:1505,y:806,t:1527876734081};\\\", \\\"{x:1518,y:816,t:1527876734098};\\\", \\\"{x:1522,y:820,t:1527876734114};\\\", \\\"{x:1522,y:825,t:1527876734131};\\\", \\\"{x:1522,y:833,t:1527876734148};\\\", \\\"{x:1522,y:847,t:1527876734165};\\\", \\\"{x:1516,y:865,t:1527876734181};\\\", \\\"{x:1515,y:871,t:1527876734198};\\\", \\\"{x:1512,y:876,t:1527876734214};\\\", \\\"{x:1511,y:880,t:1527876734231};\\\", \\\"{x:1510,y:881,t:1527876734297};\\\", \\\"{x:1509,y:881,t:1527876734315};\\\", \\\"{x:1507,y:880,t:1527876734331};\\\", \\\"{x:1505,y:878,t:1527876734348};\\\", \\\"{x:1501,y:873,t:1527876734365};\\\", \\\"{x:1492,y:862,t:1527876734381};\\\", \\\"{x:1481,y:854,t:1527876734398};\\\", \\\"{x:1476,y:850,t:1527876734415};\\\", \\\"{x:1473,y:848,t:1527876734431};\\\", \\\"{x:1472,y:848,t:1527876734448};\\\", \\\"{x:1472,y:847,t:1527876734464};\\\", \\\"{x:1471,y:847,t:1527876734481};\\\", \\\"{x:1470,y:845,t:1527876734497};\\\", \\\"{x:1470,y:843,t:1527876734515};\\\", \\\"{x:1469,y:841,t:1527876734530};\\\", \\\"{x:1468,y:836,t:1527876734547};\\\", \\\"{x:1467,y:834,t:1527876734565};\\\", \\\"{x:1467,y:832,t:1527876734609};\\\", \\\"{x:1468,y:832,t:1527876734785};\\\", \\\"{x:1469,y:832,t:1527876734798};\\\", \\\"{x:1470,y:834,t:1527876734814};\\\", \\\"{x:1470,y:837,t:1527876734830};\\\", \\\"{x:1470,y:840,t:1527876734848};\\\", \\\"{x:1470,y:844,t:1527876734865};\\\", \\\"{x:1470,y:849,t:1527876734881};\\\", \\\"{x:1466,y:862,t:1527876734897};\\\", \\\"{x:1463,y:871,t:1527876734914};\\\", \\\"{x:1457,y:888,t:1527876734931};\\\", \\\"{x:1450,y:906,t:1527876734947};\\\", \\\"{x:1448,y:918,t:1527876734964};\\\", \\\"{x:1445,y:924,t:1527876734981};\\\", \\\"{x:1444,y:929,t:1527876734998};\\\", \\\"{x:1444,y:930,t:1527876735015};\\\", \\\"{x:1443,y:933,t:1527876735031};\\\", \\\"{x:1442,y:934,t:1527876735048};\\\", \\\"{x:1441,y:936,t:1527876735065};\\\", \\\"{x:1441,y:939,t:1527876735081};\\\", \\\"{x:1436,y:945,t:1527876735097};\\\", \\\"{x:1432,y:948,t:1527876735114};\\\", \\\"{x:1429,y:951,t:1527876735130};\\\", \\\"{x:1429,y:952,t:1527876735147};\\\", \\\"{x:1428,y:953,t:1527876735177};\\\", \\\"{x:1428,y:954,t:1527876735209};\\\", \\\"{x:1427,y:955,t:1527876735225};\\\", \\\"{x:1427,y:956,t:1527876735249};\\\", \\\"{x:1427,y:957,t:1527876735265};\\\", \\\"{x:1427,y:959,t:1527876735288};\\\", \\\"{x:1429,y:960,t:1527876735298};\\\", \\\"{x:1434,y:962,t:1527876735314};\\\", \\\"{x:1443,y:962,t:1527876735331};\\\", \\\"{x:1459,y:962,t:1527876735348};\\\", \\\"{x:1481,y:962,t:1527876735364};\\\", \\\"{x:1500,y:962,t:1527876735381};\\\", \\\"{x:1512,y:962,t:1527876735398};\\\", \\\"{x:1525,y:962,t:1527876735414};\\\", \\\"{x:1533,y:962,t:1527876735431};\\\", \\\"{x:1539,y:962,t:1527876735448};\\\", \\\"{x:1544,y:962,t:1527876735465};\\\", \\\"{x:1547,y:961,t:1527876735481};\\\", \\\"{x:1557,y:957,t:1527876735497};\\\", \\\"{x:1566,y:952,t:1527876735514};\\\", \\\"{x:1575,y:946,t:1527876735531};\\\", \\\"{x:1587,y:935,t:1527876735548};\\\", \\\"{x:1597,y:923,t:1527876735565};\\\", \\\"{x:1607,y:907,t:1527876735581};\\\", \\\"{x:1616,y:888,t:1527876735598};\\\", \\\"{x:1626,y:865,t:1527876735614};\\\", \\\"{x:1635,y:843,t:1527876735630};\\\", \\\"{x:1641,y:823,t:1527876735647};\\\", \\\"{x:1644,y:804,t:1527876735665};\\\", \\\"{x:1647,y:782,t:1527876735680};\\\", \\\"{x:1649,y:751,t:1527876735697};\\\", \\\"{x:1652,y:744,t:1527876735715};\\\", \\\"{x:1652,y:737,t:1527876735731};\\\", \\\"{x:1652,y:730,t:1527876735748};\\\", \\\"{x:1652,y:722,t:1527876735764};\\\", \\\"{x:1650,y:711,t:1527876735781};\\\", \\\"{x:1646,y:698,t:1527876735797};\\\", \\\"{x:1640,y:685,t:1527876735815};\\\", \\\"{x:1634,y:668,t:1527876735830};\\\", \\\"{x:1624,y:648,t:1527876735847};\\\", \\\"{x:1613,y:620,t:1527876735865};\\\", \\\"{x:1601,y:601,t:1527876735880};\\\", \\\"{x:1599,y:598,t:1527876735898};\\\", \\\"{x:1598,y:597,t:1527876735914};\\\", \\\"{x:1597,y:597,t:1527876736001};\\\", \\\"{x:1595,y:597,t:1527876736015};\\\", \\\"{x:1591,y:601,t:1527876736031};\\\", \\\"{x:1585,y:615,t:1527876736048};\\\", \\\"{x:1579,y:630,t:1527876736065};\\\", \\\"{x:1571,y:646,t:1527876736081};\\\", \\\"{x:1570,y:651,t:1527876736098};\\\", \\\"{x:1568,y:652,t:1527876736114};\\\", \\\"{x:1568,y:653,t:1527876736131};\\\", \\\"{x:1568,y:654,t:1527876736169};\\\", \\\"{x:1568,y:656,t:1527876736180};\\\", \\\"{x:1566,y:663,t:1527876736198};\\\", \\\"{x:1562,y:676,t:1527876736215};\\\", \\\"{x:1557,y:692,t:1527876736230};\\\", \\\"{x:1548,y:712,t:1527876736247};\\\", \\\"{x:1540,y:729,t:1527876736264};\\\", \\\"{x:1533,y:747,t:1527876736280};\\\", \\\"{x:1524,y:766,t:1527876736297};\\\", \\\"{x:1521,y:776,t:1527876736314};\\\", \\\"{x:1516,y:787,t:1527876736330};\\\", \\\"{x:1511,y:797,t:1527876736347};\\\", \\\"{x:1505,y:809,t:1527876736365};\\\", \\\"{x:1500,y:822,t:1527876736381};\\\", \\\"{x:1496,y:838,t:1527876736398};\\\", \\\"{x:1491,y:852,t:1527876736415};\\\", \\\"{x:1488,y:866,t:1527876736430};\\\", \\\"{x:1486,y:876,t:1527876736447};\\\", \\\"{x:1483,y:886,t:1527876736465};\\\", \\\"{x:1481,y:890,t:1527876736481};\\\", \\\"{x:1480,y:895,t:1527876736497};\\\", \\\"{x:1478,y:899,t:1527876736514};\\\", \\\"{x:1477,y:904,t:1527876736531};\\\", \\\"{x:1473,y:912,t:1527876736547};\\\", \\\"{x:1469,y:920,t:1527876736565};\\\", \\\"{x:1466,y:931,t:1527876736581};\\\", \\\"{x:1462,y:939,t:1527876736598};\\\", \\\"{x:1459,y:945,t:1527876736614};\\\", \\\"{x:1456,y:951,t:1527876736631};\\\", \\\"{x:1455,y:955,t:1527876736648};\\\", \\\"{x:1455,y:956,t:1527876736664};\\\", \\\"{x:1454,y:958,t:1527876736681};\\\", \\\"{x:1454,y:960,t:1527876736698};\\\", \\\"{x:1452,y:962,t:1527876736715};\\\", \\\"{x:1452,y:964,t:1527876736731};\\\", \\\"{x:1452,y:965,t:1527876736748};\\\", \\\"{x:1451,y:966,t:1527876736765};\\\", \\\"{x:1451,y:967,t:1527876736810};\\\", \\\"{x:1452,y:968,t:1527876736874};\\\", \\\"{x:1456,y:968,t:1527876736882};\\\", \\\"{x:1473,y:968,t:1527876736898};\\\", \\\"{x:1489,y:968,t:1527876736915};\\\", \\\"{x:1497,y:968,t:1527876736932};\\\", \\\"{x:1501,y:968,t:1527876736948};\\\", \\\"{x:1504,y:968,t:1527876736965};\\\", \\\"{x:1506,y:968,t:1527876736981};\\\", \\\"{x:1507,y:968,t:1527876737169};\\\", \\\"{x:1507,y:969,t:1527876737185};\\\", \\\"{x:1505,y:970,t:1527876737209};\\\", \\\"{x:1504,y:970,t:1527876737225};\\\", \\\"{x:1500,y:971,t:1527876737241};\\\", \\\"{x:1497,y:972,t:1527876737249};\\\", \\\"{x:1492,y:973,t:1527876737265};\\\", \\\"{x:1489,y:975,t:1527876737280};\\\", \\\"{x:1488,y:975,t:1527876737305};\\\", \\\"{x:1489,y:975,t:1527876737721};\\\", \\\"{x:1491,y:975,t:1527876737731};\\\", \\\"{x:1492,y:975,t:1527876737748};\\\", \\\"{x:1492,y:974,t:1527876737765};\\\", \\\"{x:1494,y:974,t:1527876737782};\\\", \\\"{x:1494,y:973,t:1527876737797};\\\", \\\"{x:1495,y:973,t:1527876737815};\\\", \\\"{x:1495,y:972,t:1527876737889};\\\", \\\"{x:1497,y:972,t:1527876737913};\\\", \\\"{x:1498,y:971,t:1527876737945};\\\", \\\"{x:1500,y:970,t:1527876737969};\\\", \\\"{x:1502,y:969,t:1527876738009};\\\", \\\"{x:1503,y:969,t:1527876738016};\\\", \\\"{x:1504,y:969,t:1527876738057};\\\", \\\"{x:1505,y:969,t:1527876738065};\\\", \\\"{x:1506,y:969,t:1527876738081};\\\", \\\"{x:1507,y:969,t:1527876738345};\\\", \\\"{x:1508,y:969,t:1527876738601};\\\", \\\"{x:1508,y:968,t:1527876738615};\\\", \\\"{x:1509,y:968,t:1527876738690};\\\", \\\"{x:1511,y:967,t:1527876738706};\\\", \\\"{x:1513,y:967,t:1527876738745};\\\", \\\"{x:1516,y:966,t:1527876738753};\\\", \\\"{x:1518,y:966,t:1527876738765};\\\", \\\"{x:1530,y:965,t:1527876738782};\\\", \\\"{x:1539,y:964,t:1527876738798};\\\", \\\"{x:1547,y:962,t:1527876738815};\\\", \\\"{x:1551,y:962,t:1527876738831};\\\", \\\"{x:1553,y:962,t:1527876738848};\\\", \\\"{x:1554,y:962,t:1527876738865};\\\", \\\"{x:1551,y:962,t:1527876740492};\\\", \\\"{x:1546,y:962,t:1527876740498};\\\", \\\"{x:1512,y:963,t:1527876740516};\\\", \\\"{x:1450,y:971,t:1527876740533};\\\", \\\"{x:1366,y:975,t:1527876740549};\\\", \\\"{x:1277,y:975,t:1527876740565};\\\", \\\"{x:1177,y:975,t:1527876740583};\\\", \\\"{x:1072,y:975,t:1527876740598};\\\", \\\"{x:975,y:975,t:1527876740616};\\\", \\\"{x:868,y:949,t:1527876740632};\\\", \\\"{x:765,y:917,t:1527876740648};\\\", \\\"{x:673,y:869,t:1527876740666};\\\", \\\"{x:576,y:795,t:1527876740682};\\\", \\\"{x:553,y:763,t:1527876740699};\\\", \\\"{x:548,y:747,t:1527876740717};\\\", \\\"{x:546,y:731,t:1527876740732};\\\", \\\"{x:546,y:709,t:1527876740748};\\\", \\\"{x:550,y:694,t:1527876740768};\\\", \\\"{x:558,y:682,t:1527876740785};\\\", \\\"{x:565,y:670,t:1527876740801};\\\", \\\"{x:573,y:654,t:1527876740818};\\\", \\\"{x:581,y:638,t:1527876740833};\\\", \\\"{x:586,y:625,t:1527876740852};\\\", \\\"{x:589,y:617,t:1527876740867};\\\", \\\"{x:590,y:612,t:1527876740876};\\\", \\\"{x:590,y:608,t:1527876740893};\\\", \\\"{x:590,y:600,t:1527876740910};\\\", \\\"{x:590,y:594,t:1527876740926};\\\", \\\"{x:587,y:585,t:1527876740944};\\\", \\\"{x:584,y:580,t:1527876740960};\\\", \\\"{x:584,y:578,t:1527876740976};\\\", \\\"{x:583,y:577,t:1527876741009};\\\", \\\"{x:583,y:574,t:1527876741073};\\\", \\\"{x:584,y:572,t:1527876741081};\\\", \\\"{x:585,y:569,t:1527876741093};\\\", \\\"{x:587,y:565,t:1527876741109};\\\", \\\"{x:588,y:565,t:1527876741219};\\\", \\\"{x:590,y:564,t:1527876741234};\\\", \\\"{x:594,y:562,t:1527876741245};\\\", \\\"{x:599,y:560,t:1527876741260};\\\", \\\"{x:601,y:558,t:1527876741277};\\\", \\\"{x:607,y:553,t:1527876741294};\\\", \\\"{x:616,y:547,t:1527876741310};\\\", \\\"{x:627,y:538,t:1527876741327};\\\", \\\"{x:636,y:532,t:1527876741343};\\\", \\\"{x:640,y:528,t:1527876741360};\\\", \\\"{x:648,y:523,t:1527876741377};\\\", \\\"{x:652,y:520,t:1527876741392};\\\", \\\"{x:654,y:518,t:1527876741410};\\\", \\\"{x:656,y:516,t:1527876741427};\\\", \\\"{x:656,y:515,t:1527876741505};\\\", \\\"{x:649,y:516,t:1527876741513};\\\", \\\"{x:638,y:518,t:1527876741527};\\\", \\\"{x:585,y:532,t:1527876741544};\\\", \\\"{x:526,y:540,t:1527876741560};\\\", \\\"{x:427,y:545,t:1527876741578};\\\", \\\"{x:374,y:545,t:1527876741593};\\\", \\\"{x:343,y:545,t:1527876741610};\\\", \\\"{x:320,y:545,t:1527876741627};\\\", \\\"{x:304,y:545,t:1527876741643};\\\", \\\"{x:300,y:545,t:1527876741660};\\\", \\\"{x:299,y:545,t:1527876741677};\\\", \\\"{x:295,y:545,t:1527876741977};\\\", \\\"{x:279,y:545,t:1527876741993};\\\", \\\"{x:253,y:545,t:1527876742012};\\\", \\\"{x:233,y:545,t:1527876742026};\\\", \\\"{x:210,y:545,t:1527876742044};\\\", \\\"{x:179,y:549,t:1527876742061};\\\", \\\"{x:148,y:555,t:1527876742077};\\\", \\\"{x:132,y:559,t:1527876742094};\\\", \\\"{x:125,y:563,t:1527876742111};\\\", \\\"{x:122,y:565,t:1527876742127};\\\", \\\"{x:120,y:569,t:1527876742144};\\\", \\\"{x:119,y:581,t:1527876742161};\\\", \\\"{x:119,y:592,t:1527876742177};\\\", \\\"{x:128,y:605,t:1527876742194};\\\", \\\"{x:133,y:612,t:1527876742210};\\\", \\\"{x:138,y:618,t:1527876742227};\\\", \\\"{x:144,y:621,t:1527876742244};\\\", \\\"{x:152,y:622,t:1527876742261};\\\", \\\"{x:165,y:622,t:1527876742277};\\\", \\\"{x:174,y:622,t:1527876742294};\\\", \\\"{x:186,y:624,t:1527876742311};\\\", \\\"{x:189,y:624,t:1527876742326};\\\", \\\"{x:193,y:624,t:1527876742344};\\\", \\\"{x:195,y:624,t:1527876742360};\\\", \\\"{x:196,y:624,t:1527876742377};\\\", \\\"{x:199,y:624,t:1527876742393};\\\", \\\"{x:211,y:619,t:1527876742411};\\\", \\\"{x:229,y:613,t:1527876742427};\\\", \\\"{x:250,y:607,t:1527876742444};\\\", \\\"{x:273,y:602,t:1527876742461};\\\", \\\"{x:296,y:596,t:1527876742478};\\\", \\\"{x:315,y:595,t:1527876742494};\\\", \\\"{x:332,y:593,t:1527876742511};\\\", \\\"{x:342,y:593,t:1527876742528};\\\", \\\"{x:351,y:592,t:1527876742544};\\\", \\\"{x:359,y:590,t:1527876742561};\\\", \\\"{x:363,y:588,t:1527876742577};\\\", \\\"{x:367,y:587,t:1527876742593};\\\", \\\"{x:371,y:585,t:1527876742610};\\\", \\\"{x:376,y:584,t:1527876742629};\\\", \\\"{x:380,y:584,t:1527876742644};\\\", \\\"{x:383,y:583,t:1527876742661};\\\", \\\"{x:386,y:583,t:1527876742678};\\\", \\\"{x:391,y:583,t:1527876742694};\\\", \\\"{x:394,y:583,t:1527876742711};\\\", \\\"{x:397,y:583,t:1527876742728};\\\", \\\"{x:398,y:583,t:1527876742744};\\\", \\\"{x:400,y:583,t:1527876742761};\\\", \\\"{x:401,y:583,t:1527876742785};\\\", \\\"{x:402,y:583,t:1527876742802};\\\", \\\"{x:403,y:583,t:1527876742818};\\\", \\\"{x:405,y:582,t:1527876742841};\\\", \\\"{x:405,y:581,t:1527876742849};\\\", \\\"{x:405,y:580,t:1527876742865};\\\", \\\"{x:405,y:579,t:1527876742878};\\\", \\\"{x:407,y:577,t:1527876742894};\\\", \\\"{x:409,y:574,t:1527876742911};\\\", \\\"{x:411,y:572,t:1527876742928};\\\", \\\"{x:418,y:567,t:1527876742946};\\\", \\\"{x:423,y:563,t:1527876742961};\\\", \\\"{x:432,y:558,t:1527876742978};\\\", \\\"{x:439,y:554,t:1527876742995};\\\", \\\"{x:450,y:549,t:1527876743010};\\\", \\\"{x:463,y:544,t:1527876743027};\\\", \\\"{x:480,y:539,t:1527876743045};\\\", \\\"{x:496,y:534,t:1527876743061};\\\", \\\"{x:514,y:531,t:1527876743079};\\\", \\\"{x:536,y:528,t:1527876743095};\\\", \\\"{x:558,y:528,t:1527876743110};\\\", \\\"{x:579,y:528,t:1527876743128};\\\", \\\"{x:610,y:529,t:1527876743145};\\\", \\\"{x:631,y:535,t:1527876743161};\\\", \\\"{x:656,y:538,t:1527876743179};\\\", \\\"{x:683,y:545,t:1527876743195};\\\", \\\"{x:706,y:549,t:1527876743211};\\\", \\\"{x:722,y:553,t:1527876743227};\\\", \\\"{x:731,y:554,t:1527876743246};\\\", \\\"{x:738,y:556,t:1527876743261};\\\", \\\"{x:743,y:558,t:1527876743278};\\\", \\\"{x:750,y:561,t:1527876743295};\\\", \\\"{x:762,y:566,t:1527876743316};\\\", \\\"{x:772,y:570,t:1527876743328};\\\", \\\"{x:774,y:571,t:1527876743345};\\\", \\\"{x:775,y:572,t:1527876743368};\\\", \\\"{x:775,y:573,t:1527876743401};\\\", \\\"{x:775,y:576,t:1527876743411};\\\", \\\"{x:775,y:581,t:1527876743428};\\\", \\\"{x:772,y:586,t:1527876743445};\\\", \\\"{x:763,y:595,t:1527876743462};\\\", \\\"{x:747,y:604,t:1527876743479};\\\", \\\"{x:722,y:615,t:1527876743495};\\\", \\\"{x:690,y:628,t:1527876743512};\\\", \\\"{x:663,y:636,t:1527876743529};\\\", \\\"{x:622,y:642,t:1527876743545};\\\", \\\"{x:595,y:642,t:1527876743561};\\\", \\\"{x:570,y:641,t:1527876743578};\\\", \\\"{x:547,y:639,t:1527876743595};\\\", \\\"{x:526,y:634,t:1527876743612};\\\", \\\"{x:513,y:633,t:1527876743628};\\\", \\\"{x:507,y:633,t:1527876743645};\\\", \\\"{x:505,y:633,t:1527876743662};\\\", \\\"{x:513,y:633,t:1527876743770};\\\", \\\"{x:527,y:635,t:1527876743778};\\\", \\\"{x:559,y:637,t:1527876743795};\\\", \\\"{x:592,y:637,t:1527876743812};\\\", \\\"{x:624,y:637,t:1527876743829};\\\", \\\"{x:643,y:637,t:1527876743845};\\\", \\\"{x:649,y:637,t:1527876743862};\\\", \\\"{x:651,y:637,t:1527876743879};\\\", \\\"{x:649,y:637,t:1527876744033};\\\", \\\"{x:645,y:637,t:1527876744045};\\\", \\\"{x:628,y:629,t:1527876744063};\\\", \\\"{x:619,y:623,t:1527876744079};\\\", \\\"{x:606,y:612,t:1527876744095};\\\", \\\"{x:596,y:603,t:1527876744111};\\\", \\\"{x:594,y:603,t:1527876744128};\\\", \\\"{x:594,y:602,t:1527876744145};\\\", \\\"{x:594,y:601,t:1527876744337};\\\", \\\"{x:597,y:604,t:1527876744353};\\\", \\\"{x:602,y:607,t:1527876744362};\\\", \\\"{x:606,y:612,t:1527876744378};\\\", \\\"{x:608,y:615,t:1527876744393};\\\", \\\"{x:608,y:615,t:1527876744396};\\\", \\\"{x:608,y:617,t:1527876744412};\\\", \\\"{x:609,y:617,t:1527876744429};\\\", \\\"{x:610,y:618,t:1527876744465};\\\", \\\"{x:612,y:618,t:1527876744692};\\\", \\\"{x:621,y:618,t:1527876744698};\\\", \\\"{x:670,y:612,t:1527876744713};\\\", \\\"{x:739,y:605,t:1527876744730};\\\", \\\"{x:817,y:605,t:1527876744746};\\\", \\\"{x:911,y:605,t:1527876744763};\\\", \\\"{x:1005,y:605,t:1527876744779};\\\", \\\"{x:1089,y:605,t:1527876744796};\\\", \\\"{x:1200,y:605,t:1527876744813};\\\", \\\"{x:1305,y:593,t:1527876744829};\\\", \\\"{x:1379,y:584,t:1527876744846};\\\", \\\"{x:1396,y:583,t:1527876744862};\\\", \\\"{x:1394,y:584,t:1527876744897};\\\", \\\"{x:1386,y:588,t:1527876744912};\\\", \\\"{x:1337,y:604,t:1527876744929};\\\", \\\"{x:1279,y:617,t:1527876744945};\\\", \\\"{x:1197,y:627,t:1527876744962};\\\", \\\"{x:1116,y:628,t:1527876744979};\\\", \\\"{x:1041,y:622,t:1527876744995};\\\", \\\"{x:980,y:614,t:1527876745012};\\\", \\\"{x:937,y:611,t:1527876745030};\\\", \\\"{x:905,y:611,t:1527876745045};\\\", \\\"{x:887,y:611,t:1527876745063};\\\", \\\"{x:878,y:609,t:1527876745080};\\\", \\\"{x:872,y:608,t:1527876745095};\\\", \\\"{x:870,y:606,t:1527876745113};\\\", \\\"{x:866,y:606,t:1527876745129};\\\", \\\"{x:857,y:606,t:1527876745146};\\\", \\\"{x:851,y:607,t:1527876745163};\\\", \\\"{x:844,y:608,t:1527876745181};\\\", \\\"{x:831,y:611,t:1527876745196};\\\", \\\"{x:811,y:613,t:1527876745213};\\\", \\\"{x:784,y:620,t:1527876745230};\\\", \\\"{x:746,y:626,t:1527876745246};\\\", \\\"{x:695,y:634,t:1527876745264};\\\", \\\"{x:658,y:641,t:1527876745280};\\\", \\\"{x:637,y:643,t:1527876745296};\\\", \\\"{x:631,y:643,t:1527876745313};\\\", \\\"{x:630,y:643,t:1527876745330};\\\", \\\"{x:629,y:643,t:1527876745346};\\\", \\\"{x:628,y:643,t:1527876745363};\\\", \\\"{x:627,y:642,t:1527876745380};\\\", \\\"{x:626,y:640,t:1527876745396};\\\", \\\"{x:624,y:636,t:1527876745413};\\\", \\\"{x:622,y:633,t:1527876745429};\\\", \\\"{x:620,y:632,t:1527876745446};\\\", \\\"{x:620,y:630,t:1527876745466};\\\", \\\"{x:623,y:629,t:1527876745480};\\\", \\\"{x:641,y:623,t:1527876745497};\\\", \\\"{x:644,y:621,t:1527876745513};\\\", \\\"{x:646,y:621,t:1527876745530};\\\", \\\"{x:645,y:621,t:1527876745688};\\\", \\\"{x:643,y:621,t:1527876745697};\\\", \\\"{x:636,y:622,t:1527876745712};\\\", \\\"{x:622,y:622,t:1527876745729};\\\", \\\"{x:613,y:622,t:1527876745747};\\\", \\\"{x:610,y:622,t:1527876745763};\\\", \\\"{x:609,y:622,t:1527876745780};\\\", \\\"{x:614,y:623,t:1527876746490};\\\", \\\"{x:635,y:632,t:1527876746498};\\\", \\\"{x:702,y:654,t:1527876746514};\\\", \\\"{x:779,y:672,t:1527876746531};\\\", \\\"{x:866,y:687,t:1527876746547};\\\", \\\"{x:975,y:689,t:1527876746565};\\\", \\\"{x:1094,y:689,t:1527876746582};\\\", \\\"{x:1210,y:689,t:1527876746597};\\\", \\\"{x:1307,y:689,t:1527876746614};\\\", \\\"{x:1389,y:682,t:1527876746631};\\\", \\\"{x:1443,y:675,t:1527876746647};\\\", \\\"{x:1488,y:667,t:1527876746665};\\\", \\\"{x:1548,y:647,t:1527876746681};\\\", \\\"{x:1585,y:635,t:1527876746697};\\\", \\\"{x:1618,y:622,t:1527876746714};\\\", \\\"{x:1654,y:605,t:1527876746731};\\\", \\\"{x:1712,y:581,t:1527876746747};\\\", \\\"{x:1778,y:564,t:1527876746764};\\\", \\\"{x:1823,y:556,t:1527876746781};\\\", \\\"{x:1839,y:553,t:1527876746798};\\\", \\\"{x:1839,y:552,t:1527876746814};\\\", \\\"{x:1838,y:552,t:1527876746979};\\\", \\\"{x:1835,y:552,t:1527876746986};\\\", \\\"{x:1832,y:552,t:1527876746997};\\\", \\\"{x:1818,y:552,t:1527876747015};\\\", \\\"{x:1795,y:555,t:1527876747032};\\\", \\\"{x:1776,y:558,t:1527876747048};\\\", \\\"{x:1754,y:564,t:1527876747064};\\\", \\\"{x:1690,y:590,t:1527876747082};\\\", \\\"{x:1655,y:609,t:1527876747098};\\\", \\\"{x:1619,y:632,t:1527876747114};\\\", \\\"{x:1590,y:647,t:1527876747131};\\\", \\\"{x:1574,y:655,t:1527876747147};\\\", \\\"{x:1562,y:659,t:1527876747164};\\\", \\\"{x:1549,y:661,t:1527876747181};\\\", \\\"{x:1539,y:662,t:1527876747197};\\\", \\\"{x:1537,y:662,t:1527876747214};\\\", \\\"{x:1536,y:662,t:1527876747281};\\\", \\\"{x:1533,y:661,t:1527876747298};\\\", \\\"{x:1531,y:661,t:1527876747322};\\\", \\\"{x:1527,y:661,t:1527876747332};\\\", \\\"{x:1509,y:672,t:1527876747348};\\\", \\\"{x:1473,y:704,t:1527876747365};\\\", \\\"{x:1438,y:733,t:1527876747381};\\\", \\\"{x:1420,y:749,t:1527876747399};\\\", \\\"{x:1412,y:758,t:1527876747414};\\\", \\\"{x:1408,y:762,t:1527876747431};\\\", \\\"{x:1407,y:767,t:1527876747448};\\\", \\\"{x:1405,y:778,t:1527876747464};\\\", \\\"{x:1398,y:805,t:1527876747482};\\\", \\\"{x:1389,y:825,t:1527876747497};\\\", \\\"{x:1376,y:845,t:1527876747515};\\\", \\\"{x:1368,y:861,t:1527876747531};\\\", \\\"{x:1362,y:872,t:1527876747549};\\\", \\\"{x:1358,y:878,t:1527876747564};\\\", \\\"{x:1357,y:880,t:1527876747582};\\\", \\\"{x:1354,y:884,t:1527876747599};\\\", \\\"{x:1350,y:888,t:1527876747615};\\\", \\\"{x:1340,y:893,t:1527876747632};\\\", \\\"{x:1323,y:904,t:1527876747648};\\\", \\\"{x:1294,y:925,t:1527876747665};\\\", \\\"{x:1254,y:958,t:1527876747682};\\\", \\\"{x:1236,y:976,t:1527876747698};\\\", \\\"{x:1225,y:985,t:1527876747714};\\\", \\\"{x:1222,y:988,t:1527876747731};\\\", \\\"{x:1221,y:989,t:1527876747748};\\\", \\\"{x:1227,y:986,t:1527876747866};\\\", \\\"{x:1237,y:980,t:1527876747882};\\\", \\\"{x:1245,y:972,t:1527876747898};\\\", \\\"{x:1250,y:967,t:1527876747915};\\\", \\\"{x:1253,y:962,t:1527876747932};\\\", \\\"{x:1256,y:959,t:1527876747949};\\\", \\\"{x:1258,y:957,t:1527876747964};\\\", \\\"{x:1258,y:956,t:1527876747981};\\\", \\\"{x:1259,y:955,t:1527876748002};\\\", \\\"{x:1260,y:954,t:1527876748018};\\\", \\\"{x:1262,y:953,t:1527876748034};\\\", \\\"{x:1263,y:953,t:1527876748049};\\\", \\\"{x:1265,y:952,t:1527876748065};\\\", \\\"{x:1268,y:952,t:1527876748082};\\\", \\\"{x:1271,y:952,t:1527876748099};\\\", \\\"{x:1275,y:952,t:1527876748116};\\\", \\\"{x:1282,y:952,t:1527876748131};\\\", \\\"{x:1289,y:953,t:1527876748148};\\\", \\\"{x:1290,y:953,t:1527876748166};\\\", \\\"{x:1290,y:954,t:1527876748182};\\\", \\\"{x:1292,y:954,t:1527876748199};\\\", \\\"{x:1294,y:955,t:1527876748259};\\\", \\\"{x:1294,y:956,t:1527876748282};\\\", \\\"{x:1295,y:956,t:1527876748298};\\\", \\\"{x:1296,y:956,t:1527876748322};\\\", \\\"{x:1296,y:957,t:1527876748332};\\\", \\\"{x:1298,y:957,t:1527876748348};\\\", \\\"{x:1300,y:960,t:1527876748366};\\\", \\\"{x:1302,y:961,t:1527876748382};\\\", \\\"{x:1302,y:962,t:1527876748399};\\\", \\\"{x:1303,y:962,t:1527876748426};\\\", \\\"{x:1305,y:962,t:1527876748482};\\\", \\\"{x:1309,y:962,t:1527876748499};\\\", \\\"{x:1316,y:955,t:1527876748516};\\\", \\\"{x:1329,y:947,t:1527876748532};\\\", \\\"{x:1337,y:943,t:1527876748548};\\\", \\\"{x:1342,y:939,t:1527876748566};\\\", \\\"{x:1343,y:939,t:1527876748582};\\\", \\\"{x:1345,y:939,t:1527876748599};\\\", \\\"{x:1346,y:939,t:1527876748616};\\\", \\\"{x:1347,y:939,t:1527876748632};\\\", \\\"{x:1348,y:939,t:1527876748690};\\\", \\\"{x:1349,y:939,t:1527876748698};\\\", \\\"{x:1351,y:939,t:1527876748715};\\\", \\\"{x:1352,y:939,t:1527876748731};\\\", \\\"{x:1354,y:940,t:1527876748748};\\\", \\\"{x:1355,y:941,t:1527876748765};\\\", \\\"{x:1355,y:942,t:1527876748801};\\\", \\\"{x:1355,y:943,t:1527876748815};\\\", \\\"{x:1356,y:944,t:1527876748831};\\\", \\\"{x:1356,y:947,t:1527876748848};\\\", \\\"{x:1358,y:950,t:1527876748866};\\\", \\\"{x:1358,y:952,t:1527876748882};\\\", \\\"{x:1358,y:953,t:1527876748898};\\\", \\\"{x:1358,y:957,t:1527876749459};\\\", \\\"{x:1355,y:961,t:1527876749466};\\\", \\\"{x:1353,y:964,t:1527876749483};\\\", \\\"{x:1355,y:962,t:1527876749803};\\\", \\\"{x:1357,y:959,t:1527876749816};\\\", \\\"{x:1364,y:951,t:1527876749833};\\\", \\\"{x:1370,y:941,t:1527876749849};\\\", \\\"{x:1376,y:930,t:1527876749866};\\\", \\\"{x:1384,y:919,t:1527876749883};\\\", \\\"{x:1391,y:911,t:1527876749900};\\\", \\\"{x:1394,y:909,t:1527876749916};\\\", \\\"{x:1397,y:908,t:1527876749933};\\\", \\\"{x:1398,y:907,t:1527876749962};\\\", \\\"{x:1399,y:907,t:1527876749970};\\\", \\\"{x:1400,y:907,t:1527876750009};\\\", \\\"{x:1402,y:907,t:1527876750042};\\\", \\\"{x:1403,y:907,t:1527876750049};\\\", \\\"{x:1406,y:907,t:1527876750066};\\\", \\\"{x:1409,y:908,t:1527876750082};\\\", \\\"{x:1410,y:909,t:1527876750099};\\\", \\\"{x:1413,y:912,t:1527876750116};\\\", \\\"{x:1414,y:913,t:1527876750132};\\\", \\\"{x:1416,y:915,t:1527876750150};\\\", \\\"{x:1417,y:915,t:1527876750164};\\\", \\\"{x:1418,y:916,t:1527876750182};\\\", \\\"{x:1419,y:917,t:1527876750201};\\\", \\\"{x:1420,y:918,t:1527876750232};\\\", \\\"{x:1420,y:919,t:1527876750273};\\\", \\\"{x:1420,y:920,t:1527876750282};\\\", \\\"{x:1421,y:921,t:1527876750313};\\\", \\\"{x:1421,y:922,t:1527876750353};\\\", \\\"{x:1421,y:923,t:1527876750385};\\\", \\\"{x:1421,y:924,t:1527876750399};\\\", \\\"{x:1421,y:925,t:1527876750417};\\\", \\\"{x:1421,y:926,t:1527876750441};\\\", \\\"{x:1421,y:927,t:1527876750449};\\\", \\\"{x:1421,y:928,t:1527876750465};\\\", \\\"{x:1421,y:929,t:1527876750483};\\\", \\\"{x:1421,y:930,t:1527876750505};\\\", \\\"{x:1421,y:931,t:1527876750553};\\\", \\\"{x:1421,y:932,t:1527876750578};\\\", \\\"{x:1421,y:933,t:1527876750593};\\\", \\\"{x:1421,y:934,t:1527876750609};\\\", \\\"{x:1421,y:935,t:1527876750649};\\\", \\\"{x:1421,y:936,t:1527876750666};\\\", \\\"{x:1421,y:937,t:1527876750682};\\\", \\\"{x:1421,y:938,t:1527876750705};\\\", \\\"{x:1421,y:939,t:1527876750716};\\\", \\\"{x:1421,y:940,t:1527876750732};\\\", \\\"{x:1421,y:941,t:1527876750753};\\\", \\\"{x:1421,y:942,t:1527876750767};\\\", \\\"{x:1421,y:943,t:1527876750782};\\\", \\\"{x:1421,y:946,t:1527876750799};\\\", \\\"{x:1421,y:948,t:1527876750816};\\\", \\\"{x:1421,y:953,t:1527876750832};\\\", \\\"{x:1421,y:957,t:1527876750849};\\\", \\\"{x:1420,y:961,t:1527876750867};\\\", \\\"{x:1419,y:962,t:1527876750882};\\\", \\\"{x:1419,y:964,t:1527876750900};\\\", \\\"{x:1419,y:965,t:1527876750917};\\\", \\\"{x:1419,y:966,t:1527876750932};\\\", \\\"{x:1419,y:967,t:1527876750949};\\\", \\\"{x:1418,y:968,t:1527876751170};\\\", \\\"{x:1418,y:967,t:1527876751209};\\\", \\\"{x:1418,y:965,t:1527876751217};\\\", \\\"{x:1418,y:963,t:1527876751233};\\\", \\\"{x:1418,y:948,t:1527876751249};\\\", \\\"{x:1418,y:935,t:1527876751267};\\\", \\\"{x:1421,y:921,t:1527876751282};\\\", \\\"{x:1425,y:910,t:1527876751300};\\\", \\\"{x:1430,y:905,t:1527876751316};\\\", \\\"{x:1436,y:899,t:1527876751333};\\\", \\\"{x:1441,y:895,t:1527876751349};\\\", \\\"{x:1443,y:893,t:1527876751366};\\\", \\\"{x:1447,y:891,t:1527876751384};\\\", \\\"{x:1449,y:890,t:1527876751399};\\\", \\\"{x:1450,y:890,t:1527876751416};\\\", \\\"{x:1452,y:890,t:1527876751433};\\\", \\\"{x:1456,y:890,t:1527876751449};\\\", \\\"{x:1463,y:890,t:1527876751466};\\\", \\\"{x:1471,y:892,t:1527876751483};\\\", \\\"{x:1474,y:895,t:1527876751500};\\\", \\\"{x:1475,y:899,t:1527876751516};\\\", \\\"{x:1476,y:904,t:1527876751533};\\\", \\\"{x:1477,y:911,t:1527876751550};\\\", \\\"{x:1479,y:918,t:1527876751566};\\\", \\\"{x:1479,y:921,t:1527876751583};\\\", \\\"{x:1479,y:922,t:1527876751600};\\\", \\\"{x:1479,y:925,t:1527876751616};\\\", \\\"{x:1479,y:929,t:1527876751633};\\\", \\\"{x:1479,y:932,t:1527876751649};\\\", \\\"{x:1479,y:936,t:1527876751667};\\\", \\\"{x:1481,y:940,t:1527876751683};\\\", \\\"{x:1481,y:943,t:1527876751699};\\\", \\\"{x:1481,y:945,t:1527876751716};\\\", \\\"{x:1481,y:946,t:1527876751737};\\\", \\\"{x:1481,y:948,t:1527876751757};\\\", \\\"{x:1482,y:949,t:1527876751773};\\\", \\\"{x:1482,y:951,t:1527876751797};\\\", \\\"{x:1482,y:952,t:1527876751813};\\\", \\\"{x:1482,y:954,t:1527876751829};\\\", \\\"{x:1483,y:955,t:1527876751845};\\\", \\\"{x:1483,y:957,t:1527876751853};\\\", \\\"{x:1483,y:958,t:1527876751871};\\\", \\\"{x:1484,y:960,t:1527876751887};\\\", \\\"{x:1484,y:962,t:1527876751909};\\\", \\\"{x:1485,y:962,t:1527876751920};\\\", \\\"{x:1486,y:964,t:1527876751937};\\\", \\\"{x:1486,y:965,t:1527876751953};\\\", \\\"{x:1486,y:960,t:1527876752062};\\\", \\\"{x:1487,y:956,t:1527876752070};\\\", \\\"{x:1489,y:946,t:1527876752088};\\\", \\\"{x:1491,y:932,t:1527876752103};\\\", \\\"{x:1493,y:926,t:1527876752120};\\\", \\\"{x:1495,y:921,t:1527876752137};\\\", \\\"{x:1497,y:919,t:1527876752153};\\\", \\\"{x:1498,y:917,t:1527876752169};\\\", \\\"{x:1499,y:917,t:1527876752188};\\\", \\\"{x:1499,y:916,t:1527876752212};\\\", \\\"{x:1500,y:913,t:1527876752229};\\\", \\\"{x:1501,y:913,t:1527876752236};\\\", \\\"{x:1502,y:912,t:1527876752254};\\\", \\\"{x:1505,y:909,t:1527876752270};\\\", \\\"{x:1508,y:907,t:1527876752286};\\\", \\\"{x:1510,y:906,t:1527876752304};\\\", \\\"{x:1511,y:906,t:1527876752320};\\\", \\\"{x:1512,y:906,t:1527876752337};\\\", \\\"{x:1513,y:906,t:1527876752354};\\\", \\\"{x:1514,y:906,t:1527876752389};\\\", \\\"{x:1516,y:906,t:1527876752413};\\\", \\\"{x:1517,y:906,t:1527876752420};\\\", \\\"{x:1521,y:907,t:1527876752436};\\\", \\\"{x:1529,y:909,t:1527876752454};\\\", \\\"{x:1536,y:915,t:1527876752469};\\\", \\\"{x:1546,y:920,t:1527876752487};\\\", \\\"{x:1553,y:926,t:1527876752504};\\\", \\\"{x:1558,y:930,t:1527876752520};\\\", \\\"{x:1563,y:934,t:1527876752537};\\\", \\\"{x:1566,y:939,t:1527876752553};\\\", \\\"{x:1570,y:944,t:1527876752570};\\\", \\\"{x:1574,y:950,t:1527876752587};\\\", \\\"{x:1576,y:953,t:1527876752604};\\\", \\\"{x:1577,y:955,t:1527876752620};\\\", \\\"{x:1578,y:958,t:1527876752637};\\\", \\\"{x:1578,y:959,t:1527876752654};\\\", \\\"{x:1578,y:960,t:1527876752685};\\\", \\\"{x:1579,y:961,t:1527876752709};\\\", \\\"{x:1579,y:962,t:1527876752750};\\\", \\\"{x:1579,y:963,t:1527876752757};\\\", \\\"{x:1579,y:964,t:1527876752770};\\\", \\\"{x:1579,y:965,t:1527876752805};\\\", \\\"{x:1579,y:967,t:1527876752821};\\\", \\\"{x:1579,y:968,t:1527876752837};\\\", \\\"{x:1579,y:969,t:1527876752854};\\\", \\\"{x:1579,y:970,t:1527876752871};\\\", \\\"{x:1577,y:970,t:1527876755421};\\\", \\\"{x:1576,y:971,t:1527876755453};\\\", \\\"{x:1572,y:972,t:1527876755461};\\\", \\\"{x:1568,y:973,t:1527876755472};\\\", \\\"{x:1565,y:974,t:1527876755488};\\\", \\\"{x:1564,y:974,t:1527876755508};\\\", \\\"{x:1562,y:975,t:1527876755522};\\\", \\\"{x:1559,y:975,t:1527876755538};\\\", \\\"{x:1558,y:975,t:1527876755555};\\\", \\\"{x:1557,y:975,t:1527876755572};\\\", \\\"{x:1555,y:972,t:1527876755806};\\\", \\\"{x:1550,y:965,t:1527876755823};\\\", \\\"{x:1543,y:952,t:1527876755838};\\\", \\\"{x:1533,y:936,t:1527876755856};\\\", \\\"{x:1524,y:917,t:1527876755873};\\\", \\\"{x:1509,y:889,t:1527876755888};\\\", \\\"{x:1496,y:864,t:1527876755906};\\\", \\\"{x:1488,y:846,t:1527876755923};\\\", \\\"{x:1485,y:832,t:1527876755939};\\\", \\\"{x:1480,y:810,t:1527876755956};\\\", \\\"{x:1468,y:775,t:1527876755973};\\\", \\\"{x:1466,y:766,t:1527876755989};\\\", \\\"{x:1462,y:751,t:1527876756006};\\\", \\\"{x:1460,y:746,t:1527876756023};\\\", \\\"{x:1459,y:743,t:1527876756039};\\\", \\\"{x:1458,y:739,t:1527876756055};\\\", \\\"{x:1457,y:739,t:1527876756072};\\\", \\\"{x:1457,y:738,t:1527876756148};\\\", \\\"{x:1457,y:735,t:1527876756157};\\\", \\\"{x:1457,y:731,t:1527876756172};\\\", \\\"{x:1452,y:719,t:1527876756188};\\\", \\\"{x:1447,y:703,t:1527876756205};\\\", \\\"{x:1443,y:695,t:1527876756222};\\\", \\\"{x:1441,y:690,t:1527876756238};\\\", \\\"{x:1439,y:686,t:1527876756255};\\\", \\\"{x:1439,y:683,t:1527876756272};\\\", \\\"{x:1439,y:681,t:1527876756288};\\\", \\\"{x:1438,y:680,t:1527876756308};\\\", \\\"{x:1438,y:679,t:1527876756348};\\\", \\\"{x:1438,y:678,t:1527876756357};\\\", \\\"{x:1438,y:677,t:1527876756372};\\\", \\\"{x:1438,y:675,t:1527876756388};\\\", \\\"{x:1437,y:674,t:1527876756437};\\\", \\\"{x:1433,y:675,t:1527876756445};\\\", \\\"{x:1425,y:680,t:1527876756456};\\\", \\\"{x:1413,y:696,t:1527876756473};\\\", \\\"{x:1387,y:733,t:1527876756490};\\\", \\\"{x:1349,y:784,t:1527876756505};\\\", \\\"{x:1313,y:832,t:1527876756522};\\\", \\\"{x:1292,y:861,t:1527876756538};\\\", \\\"{x:1282,y:873,t:1527876756555};\\\", \\\"{x:1279,y:881,t:1527876756572};\\\", \\\"{x:1274,y:886,t:1527876756588};\\\", \\\"{x:1271,y:888,t:1527876756605};\\\", \\\"{x:1270,y:888,t:1527876756622};\\\", \\\"{x:1269,y:890,t:1527876756639};\\\", \\\"{x:1268,y:894,t:1527876756655};\\\", \\\"{x:1267,y:901,t:1527876756672};\\\", \\\"{x:1267,y:907,t:1527876756689};\\\", \\\"{x:1266,y:912,t:1527876756705};\\\", \\\"{x:1266,y:913,t:1527876756722};\\\", \\\"{x:1266,y:914,t:1527876756739};\\\", \\\"{x:1266,y:916,t:1527876756772};\\\", \\\"{x:1264,y:921,t:1527876756788};\\\", \\\"{x:1262,y:926,t:1527876756805};\\\", \\\"{x:1258,y:937,t:1527876756822};\\\", \\\"{x:1257,y:941,t:1527876756839};\\\", \\\"{x:1256,y:942,t:1527876756854};\\\", \\\"{x:1255,y:945,t:1527876756872};\\\", \\\"{x:1254,y:947,t:1527876756889};\\\", \\\"{x:1251,y:953,t:1527876756905};\\\", \\\"{x:1249,y:957,t:1527876756922};\\\", \\\"{x:1248,y:959,t:1527876756939};\\\", \\\"{x:1248,y:960,t:1527876756957};\\\", \\\"{x:1248,y:961,t:1527876757029};\\\", \\\"{x:1249,y:961,t:1527876757085};\\\", \\\"{x:1251,y:961,t:1527876757093};\\\", \\\"{x:1255,y:961,t:1527876757106};\\\", \\\"{x:1263,y:961,t:1527876757122};\\\", \\\"{x:1269,y:961,t:1527876757139};\\\", \\\"{x:1275,y:961,t:1527876757156};\\\", \\\"{x:1278,y:961,t:1527876757173};\\\", \\\"{x:1282,y:961,t:1527876757189};\\\", \\\"{x:1285,y:961,t:1527876757207};\\\", \\\"{x:1287,y:961,t:1527876757222};\\\", \\\"{x:1289,y:961,t:1527876757239};\\\", \\\"{x:1294,y:963,t:1527876757256};\\\", \\\"{x:1298,y:967,t:1527876757273};\\\", \\\"{x:1300,y:968,t:1527876757289};\\\", \\\"{x:1302,y:968,t:1527876757307};\\\", \\\"{x:1306,y:969,t:1527876757534};\\\", \\\"{x:1316,y:969,t:1527876757541};\\\", \\\"{x:1323,y:969,t:1527876757556};\\\", \\\"{x:1346,y:969,t:1527876757573};\\\", \\\"{x:1353,y:967,t:1527876757590};\\\", \\\"{x:1354,y:967,t:1527876757606};\\\", \\\"{x:1355,y:967,t:1527876757686};\\\", \\\"{x:1354,y:967,t:1527876758044};\\\", \\\"{x:1355,y:967,t:1527876758373};\\\", \\\"{x:1356,y:966,t:1527876758396};\\\", \\\"{x:1357,y:966,t:1527876758652};\\\", \\\"{x:1361,y:966,t:1527876758661};\\\", \\\"{x:1364,y:966,t:1527876758673};\\\", \\\"{x:1369,y:966,t:1527876758690};\\\", \\\"{x:1376,y:966,t:1527876758706};\\\", \\\"{x:1381,y:966,t:1527876758722};\\\", \\\"{x:1385,y:966,t:1527876758739};\\\", \\\"{x:1386,y:966,t:1527876758756};\\\", \\\"{x:1387,y:966,t:1527876758804};\\\", \\\"{x:1388,y:966,t:1527876758893};\\\", \\\"{x:1389,y:966,t:1527876758908};\\\", \\\"{x:1390,y:966,t:1527876758924};\\\", \\\"{x:1391,y:966,t:1527876758940};\\\", \\\"{x:1393,y:966,t:1527876758956};\\\", \\\"{x:1396,y:966,t:1527876758973};\\\", \\\"{x:1397,y:966,t:1527876759020};\\\", \\\"{x:1399,y:965,t:1527876759037};\\\", \\\"{x:1400,y:965,t:1527876759061};\\\", \\\"{x:1401,y:965,t:1527876759076};\\\", \\\"{x:1402,y:964,t:1527876759100};\\\", \\\"{x:1403,y:964,t:1527876759140};\\\", \\\"{x:1404,y:964,t:1527876759164};\\\", \\\"{x:1404,y:963,t:1527876760036};\\\", \\\"{x:1395,y:963,t:1527876760044};\\\", \\\"{x:1383,y:963,t:1527876760057};\\\", \\\"{x:1361,y:966,t:1527876760074};\\\", \\\"{x:1346,y:969,t:1527876760090};\\\", \\\"{x:1334,y:969,t:1527876760107};\\\", \\\"{x:1325,y:969,t:1527876760123};\\\", \\\"{x:1322,y:969,t:1527876760140};\\\", \\\"{x:1321,y:969,t:1527876760157};\\\", \\\"{x:1320,y:969,t:1527876760180};\\\", \\\"{x:1319,y:969,t:1527876760190};\\\", \\\"{x:1310,y:968,t:1527876760207};\\\", \\\"{x:1302,y:967,t:1527876760223};\\\", \\\"{x:1297,y:967,t:1527876760240};\\\", \\\"{x:1294,y:967,t:1527876760257};\\\", \\\"{x:1286,y:966,t:1527876760273};\\\", \\\"{x:1278,y:964,t:1527876760290};\\\", \\\"{x:1269,y:964,t:1527876760307};\\\", \\\"{x:1253,y:963,t:1527876760324};\\\", \\\"{x:1242,y:962,t:1527876760340};\\\", \\\"{x:1235,y:960,t:1527876760357};\\\", \\\"{x:1234,y:960,t:1527876760374};\\\", \\\"{x:1233,y:960,t:1527876760389};\\\", \\\"{x:1233,y:959,t:1527876760740};\\\", \\\"{x:1238,y:959,t:1527876760756};\\\", \\\"{x:1241,y:958,t:1527876760774};\\\", \\\"{x:1244,y:958,t:1527876760790};\\\", \\\"{x:1246,y:958,t:1527876760807};\\\", \\\"{x:1250,y:958,t:1527876760824};\\\", \\\"{x:1254,y:956,t:1527876760840};\\\", \\\"{x:1258,y:955,t:1527876760857};\\\", \\\"{x:1262,y:955,t:1527876760874};\\\", \\\"{x:1262,y:954,t:1527876760890};\\\", \\\"{x:1265,y:953,t:1527876760907};\\\", \\\"{x:1267,y:950,t:1527876760924};\\\", \\\"{x:1272,y:945,t:1527876760940};\\\", \\\"{x:1282,y:933,t:1527876760957};\\\", \\\"{x:1299,y:909,t:1527876760974};\\\", \\\"{x:1319,y:882,t:1527876760990};\\\", \\\"{x:1345,y:843,t:1527876761007};\\\", \\\"{x:1382,y:785,t:1527876761024};\\\", \\\"{x:1427,y:710,t:1527876761040};\\\", \\\"{x:1471,y:637,t:1527876761057};\\\", \\\"{x:1499,y:573,t:1527876761074};\\\", \\\"{x:1522,y:526,t:1527876761090};\\\", \\\"{x:1531,y:506,t:1527876761107};\\\", \\\"{x:1537,y:497,t:1527876761124};\\\", \\\"{x:1538,y:494,t:1527876761140};\\\", \\\"{x:1538,y:501,t:1527876761212};\\\", \\\"{x:1536,y:514,t:1527876761224};\\\", \\\"{x:1523,y:548,t:1527876761241};\\\", \\\"{x:1505,y:587,t:1527876761257};\\\", \\\"{x:1480,y:630,t:1527876761274};\\\", \\\"{x:1446,y:685,t:1527876761291};\\\", \\\"{x:1405,y:744,t:1527876761307};\\\", \\\"{x:1352,y:822,t:1527876761324};\\\", \\\"{x:1329,y:861,t:1527876761341};\\\", \\\"{x:1311,y:884,t:1527876761357};\\\", \\\"{x:1296,y:905,t:1527876761374};\\\", \\\"{x:1286,y:920,t:1527876761391};\\\", \\\"{x:1279,y:933,t:1527876761406};\\\", \\\"{x:1274,y:943,t:1527876761424};\\\", \\\"{x:1271,y:948,t:1527876761441};\\\", \\\"{x:1270,y:953,t:1527876761457};\\\", \\\"{x:1267,y:958,t:1527876761474};\\\", \\\"{x:1267,y:960,t:1527876761491};\\\", \\\"{x:1264,y:962,t:1527876761507};\\\", \\\"{x:1260,y:964,t:1527876761524};\\\", \\\"{x:1253,y:967,t:1527876761540};\\\", \\\"{x:1248,y:968,t:1527876761557};\\\", \\\"{x:1239,y:971,t:1527876761574};\\\", \\\"{x:1236,y:972,t:1527876761591};\\\", \\\"{x:1241,y:971,t:1527876761716};\\\", \\\"{x:1250,y:970,t:1527876761724};\\\", \\\"{x:1267,y:968,t:1527876761741};\\\", \\\"{x:1283,y:965,t:1527876761757};\\\", \\\"{x:1298,y:964,t:1527876761774};\\\", \\\"{x:1314,y:961,t:1527876761791};\\\", \\\"{x:1331,y:959,t:1527876761806};\\\", \\\"{x:1340,y:959,t:1527876761824};\\\", \\\"{x:1341,y:959,t:1527876761841};\\\", \\\"{x:1341,y:958,t:1527876761868};\\\", \\\"{x:1338,y:958,t:1527876761916};\\\", \\\"{x:1335,y:958,t:1527876761924};\\\", \\\"{x:1326,y:961,t:1527876761940};\\\", \\\"{x:1320,y:964,t:1527876761958};\\\", \\\"{x:1317,y:965,t:1527876761974};\\\", \\\"{x:1314,y:965,t:1527876761991};\\\", \\\"{x:1313,y:965,t:1527876762008};\\\", \\\"{x:1310,y:965,t:1527876762023};\\\", \\\"{x:1308,y:965,t:1527876762041};\\\", \\\"{x:1304,y:965,t:1527876762057};\\\", \\\"{x:1301,y:965,t:1527876762074};\\\", \\\"{x:1296,y:965,t:1527876762091};\\\", \\\"{x:1290,y:965,t:1527876762107};\\\", \\\"{x:1288,y:965,t:1527876762156};\\\", \\\"{x:1286,y:964,t:1527876762164};\\\", \\\"{x:1284,y:963,t:1527876762173};\\\", \\\"{x:1279,y:961,t:1527876762191};\\\", \\\"{x:1278,y:960,t:1527876762208};\\\", \\\"{x:1277,y:960,t:1527876762224};\\\", \\\"{x:1278,y:960,t:1527876762324};\\\", \\\"{x:1283,y:960,t:1527876762341};\\\", \\\"{x:1297,y:961,t:1527876762357};\\\", \\\"{x:1316,y:962,t:1527876762374};\\\", \\\"{x:1337,y:962,t:1527876762391};\\\", \\\"{x:1345,y:962,t:1527876762408};\\\", \\\"{x:1349,y:962,t:1527876762424};\\\", \\\"{x:1351,y:962,t:1527876762441};\\\", \\\"{x:1354,y:962,t:1527876762458};\\\", \\\"{x:1355,y:962,t:1527876762941};\\\", \\\"{x:1357,y:962,t:1527876762958};\\\", \\\"{x:1361,y:962,t:1527876762975};\\\", \\\"{x:1363,y:962,t:1527876762991};\\\", \\\"{x:1364,y:962,t:1527876763012};\\\", \\\"{x:1365,y:962,t:1527876763025};\\\", \\\"{x:1366,y:962,t:1527876763041};\\\", \\\"{x:1367,y:962,t:1527876763059};\\\", \\\"{x:1368,y:962,t:1527876763076};\\\", \\\"{x:1369,y:962,t:1527876763091};\\\", \\\"{x:1373,y:962,t:1527876763107};\\\", \\\"{x:1376,y:962,t:1527876763125};\\\", \\\"{x:1382,y:962,t:1527876763140};\\\", \\\"{x:1388,y:962,t:1527876763157};\\\", \\\"{x:1392,y:962,t:1527876763175};\\\", \\\"{x:1395,y:962,t:1527876763191};\\\", \\\"{x:1401,y:962,t:1527876763208};\\\", \\\"{x:1407,y:961,t:1527876763225};\\\", \\\"{x:1413,y:960,t:1527876763241};\\\", \\\"{x:1419,y:960,t:1527876763258};\\\", \\\"{x:1423,y:957,t:1527876763275};\\\", \\\"{x:1425,y:957,t:1527876763291};\\\", \\\"{x:1429,y:957,t:1527876763308};\\\", \\\"{x:1430,y:957,t:1527876763325};\\\", \\\"{x:1431,y:957,t:1527876763340};\\\", \\\"{x:1432,y:957,t:1527876763358};\\\", \\\"{x:1433,y:957,t:1527876763375};\\\", \\\"{x:1434,y:956,t:1527876763390};\\\", \\\"{x:1434,y:957,t:1527876763797};\\\", \\\"{x:1434,y:959,t:1527876763820};\\\", \\\"{x:1433,y:959,t:1527876763828};\\\", \\\"{x:1433,y:960,t:1527876763844};\\\", \\\"{x:1432,y:960,t:1527876763859};\\\", \\\"{x:1431,y:961,t:1527876763875};\\\", \\\"{x:1431,y:962,t:1527876763892};\\\", \\\"{x:1431,y:963,t:1527876763916};\\\", \\\"{x:1431,y:965,t:1527876763956};\\\", \\\"{x:1430,y:966,t:1527876763971};\\\", \\\"{x:1430,y:967,t:1527876764100};\\\", \\\"{x:1429,y:967,t:1527876764108};\\\", \\\"{x:1426,y:969,t:1527876764125};\\\", \\\"{x:1425,y:970,t:1527876764142};\\\", \\\"{x:1423,y:970,t:1527876764158};\\\", \\\"{x:1422,y:970,t:1527876764175};\\\", \\\"{x:1421,y:971,t:1527876764192};\\\", \\\"{x:1424,y:971,t:1527876764380};\\\", \\\"{x:1426,y:970,t:1527876764392};\\\", \\\"{x:1438,y:964,t:1527876764408};\\\", \\\"{x:1449,y:957,t:1527876764425};\\\", \\\"{x:1456,y:950,t:1527876764442};\\\", \\\"{x:1461,y:947,t:1527876764459};\\\", \\\"{x:1466,y:944,t:1527876764475};\\\", \\\"{x:1483,y:940,t:1527876764492};\\\", \\\"{x:1488,y:937,t:1527876764509};\\\", \\\"{x:1489,y:937,t:1527876764525};\\\", \\\"{x:1490,y:937,t:1527876764612};\\\", \\\"{x:1491,y:938,t:1527876764625};\\\", \\\"{x:1491,y:940,t:1527876764642};\\\", \\\"{x:1491,y:944,t:1527876764659};\\\", \\\"{x:1491,y:946,t:1527876764675};\\\", \\\"{x:1491,y:948,t:1527876764691};\\\", \\\"{x:1491,y:949,t:1527876764709};\\\", \\\"{x:1491,y:951,t:1527876764725};\\\", \\\"{x:1491,y:954,t:1527876764742};\\\", \\\"{x:1491,y:956,t:1527876764759};\\\", \\\"{x:1491,y:958,t:1527876764775};\\\", \\\"{x:1490,y:959,t:1527876764792};\\\", \\\"{x:1490,y:961,t:1527876764809};\\\", \\\"{x:1490,y:962,t:1527876764825};\\\", \\\"{x:1489,y:963,t:1527876764842};\\\", \\\"{x:1488,y:966,t:1527876764859};\\\", \\\"{x:1488,y:970,t:1527876764875};\\\", \\\"{x:1486,y:973,t:1527876764892};\\\", \\\"{x:1485,y:974,t:1527876764910};\\\", \\\"{x:1484,y:977,t:1527876764925};\\\", \\\"{x:1483,y:978,t:1527876764942};\\\", \\\"{x:1482,y:979,t:1527876764959};\\\", \\\"{x:1482,y:980,t:1527876764975};\\\", \\\"{x:1480,y:979,t:1527876765772};\\\", \\\"{x:1480,y:977,t:1527876765780};\\\", \\\"{x:1479,y:975,t:1527876765792};\\\", \\\"{x:1478,y:974,t:1527876765809};\\\", \\\"{x:1478,y:973,t:1527876765826};\\\", \\\"{x:1478,y:972,t:1527876765842};\\\", \\\"{x:1478,y:971,t:1527876765859};\\\", \\\"{x:1478,y:970,t:1527876765917};\\\", \\\"{x:1478,y:969,t:1527876765926};\\\", \\\"{x:1478,y:968,t:1527876765943};\\\", \\\"{x:1478,y:966,t:1527876765965};\\\", \\\"{x:1479,y:964,t:1527876765980};\\\", \\\"{x:1479,y:963,t:1527876765996};\\\", \\\"{x:1480,y:962,t:1527876766010};\\\", \\\"{x:1481,y:960,t:1527876766026};\\\", \\\"{x:1482,y:958,t:1527876766043};\\\", \\\"{x:1484,y:956,t:1527876766059};\\\", \\\"{x:1486,y:953,t:1527876766076};\\\", \\\"{x:1488,y:952,t:1527876766094};\\\", \\\"{x:1491,y:949,t:1527876766109};\\\", \\\"{x:1492,y:949,t:1527876766126};\\\", \\\"{x:1494,y:947,t:1527876766142};\\\", \\\"{x:1495,y:946,t:1527876766159};\\\", \\\"{x:1498,y:945,t:1527876766176};\\\", \\\"{x:1504,y:943,t:1527876766193};\\\", \\\"{x:1507,y:942,t:1527876766209};\\\", \\\"{x:1510,y:941,t:1527876766226};\\\", \\\"{x:1511,y:941,t:1527876766243};\\\", \\\"{x:1512,y:941,t:1527876766259};\\\", \\\"{x:1515,y:941,t:1527876766276};\\\", \\\"{x:1516,y:941,t:1527876766293};\\\", \\\"{x:1517,y:941,t:1527876766309};\\\", \\\"{x:1518,y:941,t:1527876766326};\\\", \\\"{x:1519,y:942,t:1527876766343};\\\", \\\"{x:1520,y:944,t:1527876766359};\\\", \\\"{x:1522,y:947,t:1527876766376};\\\", \\\"{x:1523,y:950,t:1527876766393};\\\", \\\"{x:1523,y:953,t:1527876766409};\\\", \\\"{x:1526,y:956,t:1527876766426};\\\", \\\"{x:1526,y:958,t:1527876766443};\\\", \\\"{x:1529,y:961,t:1527876766459};\\\", \\\"{x:1532,y:966,t:1527876766476};\\\", \\\"{x:1534,y:967,t:1527876766493};\\\", \\\"{x:1537,y:968,t:1527876766509};\\\", \\\"{x:1538,y:969,t:1527876766526};\\\", \\\"{x:1539,y:969,t:1527876766547};\\\", \\\"{x:1540,y:970,t:1527876766559};\\\", \\\"{x:1542,y:971,t:1527876766580};\\\", \\\"{x:1543,y:970,t:1527876766812};\\\", \\\"{x:1544,y:965,t:1527876766826};\\\", \\\"{x:1547,y:954,t:1527876766843};\\\", \\\"{x:1548,y:948,t:1527876766860};\\\", \\\"{x:1552,y:941,t:1527876766875};\\\", \\\"{x:1553,y:941,t:1527876766893};\\\", \\\"{x:1554,y:940,t:1527876766910};\\\", \\\"{x:1555,y:938,t:1527876766926};\\\", \\\"{x:1556,y:938,t:1527876766948};\\\", \\\"{x:1558,y:937,t:1527876766960};\\\", \\\"{x:1562,y:936,t:1527876766976};\\\", \\\"{x:1570,y:933,t:1527876766994};\\\", \\\"{x:1575,y:930,t:1527876767010};\\\", \\\"{x:1580,y:929,t:1527876767027};\\\", \\\"{x:1586,y:927,t:1527876767043};\\\", \\\"{x:1588,y:926,t:1527876767060};\\\", \\\"{x:1590,y:926,t:1527876767076};\\\", \\\"{x:1591,y:926,t:1527876767157};\\\", \\\"{x:1593,y:926,t:1527876767197};\\\", \\\"{x:1594,y:927,t:1527876767211};\\\", \\\"{x:1598,y:931,t:1527876767227};\\\", \\\"{x:1601,y:935,t:1527876767245};\\\", \\\"{x:1605,y:939,t:1527876767261};\\\", \\\"{x:1606,y:942,t:1527876767277};\\\", \\\"{x:1608,y:944,t:1527876767296};\\\", \\\"{x:1611,y:949,t:1527876767310};\\\", \\\"{x:1614,y:954,t:1527876767327};\\\", \\\"{x:1616,y:959,t:1527876767345};\\\", \\\"{x:1618,y:961,t:1527876767361};\\\", \\\"{x:1619,y:963,t:1527876767377};\\\", \\\"{x:1620,y:964,t:1527876767394};\\\", \\\"{x:1620,y:965,t:1527876767421};\\\", \\\"{x:1620,y:966,t:1527876767445};\\\", \\\"{x:1620,y:967,t:1527876768413};\\\", \\\"{x:1618,y:968,t:1527876768429};\\\", \\\"{x:1616,y:968,t:1527876768444};\\\", \\\"{x:1611,y:969,t:1527876768461};\\\", \\\"{x:1598,y:970,t:1527876768478};\\\", \\\"{x:1578,y:972,t:1527876768496};\\\", \\\"{x:1542,y:977,t:1527876768511};\\\", \\\"{x:1503,y:977,t:1527876768527};\\\", \\\"{x:1458,y:977,t:1527876768544};\\\", \\\"{x:1394,y:977,t:1527876768560};\\\", \\\"{x:1298,y:970,t:1527876768578};\\\", \\\"{x:1169,y:938,t:1527876768595};\\\", \\\"{x:992,y:891,t:1527876768610};\\\", \\\"{x:807,y:838,t:1527876768627};\\\", \\\"{x:510,y:767,t:1527876768644};\\\", \\\"{x:326,y:714,t:1527876768660};\\\", \\\"{x:161,y:674,t:1527876768678};\\\", \\\"{x:25,y:633,t:1527876768694};\\\", \\\"{x:0,y:597,t:1527876768711};\\\", \\\"{x:0,y:566,t:1527876768728};\\\", \\\"{x:0,y:543,t:1527876768745};\\\", \\\"{x:0,y:533,t:1527876768761};\\\", \\\"{x:0,y:529,t:1527876768778};\\\", \\\"{x:1,y:527,t:1527876768794};\\\", \\\"{x:15,y:527,t:1527876768811};\\\", \\\"{x:38,y:533,t:1527876768827};\\\", \\\"{x:95,y:546,t:1527876768844};\\\", \\\"{x:124,y:554,t:1527876768860};\\\", \\\"{x:151,y:564,t:1527876768878};\\\", \\\"{x:208,y:579,t:1527876768901};\\\", \\\"{x:259,y:595,t:1527876768918};\\\", \\\"{x:298,y:606,t:1527876768935};\\\", \\\"{x:327,y:610,t:1527876768952};\\\", \\\"{x:349,y:613,t:1527876768969};\\\", \\\"{x:372,y:618,t:1527876768986};\\\", \\\"{x:392,y:623,t:1527876769002};\\\", \\\"{x:402,y:626,t:1527876769019};\\\", \\\"{x:406,y:626,t:1527876769036};\\\", \\\"{x:408,y:626,t:1527876769051};\\\", \\\"{x:412,y:627,t:1527876769068};\\\", \\\"{x:426,y:632,t:1527876769086};\\\", \\\"{x:446,y:639,t:1527876769103};\\\", \\\"{x:467,y:643,t:1527876769119};\\\", \\\"{x:477,y:643,t:1527876769135};\\\", \\\"{x:480,y:643,t:1527876769152};\\\", \\\"{x:482,y:643,t:1527876769196};\\\", \\\"{x:484,y:640,t:1527876769204};\\\", \\\"{x:485,y:638,t:1527876769220};\\\", \\\"{x:492,y:627,t:1527876769237};\\\", \\\"{x:496,y:622,t:1527876769252};\\\", \\\"{x:499,y:620,t:1527876769270};\\\", \\\"{x:501,y:618,t:1527876769285};\\\", \\\"{x:504,y:617,t:1527876769302};\\\", \\\"{x:510,y:616,t:1527876769319};\\\", \\\"{x:526,y:612,t:1527876769337};\\\", \\\"{x:553,y:605,t:1527876769352};\\\", \\\"{x:581,y:596,t:1527876769370};\\\", \\\"{x:606,y:588,t:1527876769387};\\\", \\\"{x:621,y:582,t:1527876769403};\\\", \\\"{x:624,y:580,t:1527876769420};\\\", \\\"{x:625,y:579,t:1527876769436};\\\", \\\"{x:623,y:579,t:1527876769533};\\\", \\\"{x:616,y:578,t:1527876769542};\\\", \\\"{x:605,y:577,t:1527876769553};\\\", \\\"{x:584,y:574,t:1527876769570};\\\", \\\"{x:561,y:571,t:1527876769586};\\\", \\\"{x:532,y:568,t:1527876769602};\\\", \\\"{x:501,y:563,t:1527876769620};\\\", \\\"{x:454,y:556,t:1527876769637};\\\", \\\"{x:409,y:555,t:1527876769653};\\\", \\\"{x:362,y:555,t:1527876769669};\\\", \\\"{x:336,y:555,t:1527876769686};\\\", \\\"{x:332,y:554,t:1527876769702};\\\", \\\"{x:331,y:554,t:1527876769756};\\\", \\\"{x:331,y:556,t:1527876769770};\\\", \\\"{x:330,y:565,t:1527876769787};\\\", \\\"{x:328,y:570,t:1527876769803};\\\", \\\"{x:326,y:573,t:1527876769819};\\\", \\\"{x:324,y:576,t:1527876769836};\\\", \\\"{x:323,y:579,t:1527876769852};\\\", \\\"{x:323,y:581,t:1527876769869};\\\", \\\"{x:321,y:583,t:1527876769887};\\\", \\\"{x:320,y:585,t:1527876769903};\\\", \\\"{x:318,y:586,t:1527876769919};\\\", \\\"{x:310,y:589,t:1527876769937};\\\", \\\"{x:300,y:590,t:1527876769954};\\\", \\\"{x:287,y:591,t:1527876769969};\\\", \\\"{x:277,y:593,t:1527876769986};\\\", \\\"{x:272,y:594,t:1527876770004};\\\", \\\"{x:269,y:595,t:1527876770019};\\\", \\\"{x:258,y:596,t:1527876770036};\\\", \\\"{x:247,y:596,t:1527876770053};\\\", \\\"{x:223,y:588,t:1527876770071};\\\", \\\"{x:209,y:586,t:1527876770086};\\\", \\\"{x:187,y:582,t:1527876770103};\\\", \\\"{x:180,y:581,t:1527876770119};\\\", \\\"{x:181,y:581,t:1527876770565};\\\", \\\"{x:185,y:581,t:1527876770573};\\\", \\\"{x:195,y:588,t:1527876770588};\\\", \\\"{x:228,y:607,t:1527876770604};\\\", \\\"{x:299,y:640,t:1527876770620};\\\", \\\"{x:349,y:654,t:1527876770638};\\\", \\\"{x:382,y:663,t:1527876770654};\\\", \\\"{x:398,y:668,t:1527876770671};\\\", \\\"{x:407,y:671,t:1527876770687};\\\", \\\"{x:413,y:673,t:1527876770703};\\\", \\\"{x:418,y:673,t:1527876770720};\\\", \\\"{x:425,y:676,t:1527876770737};\\\", \\\"{x:427,y:676,t:1527876770753};\\\", \\\"{x:432,y:677,t:1527876770771};\\\", \\\"{x:440,y:682,t:1527876770787};\\\", \\\"{x:453,y:689,t:1527876770803};\\\", \\\"{x:467,y:696,t:1527876770820};\\\", \\\"{x:471,y:700,t:1527876770837};\\\", \\\"{x:482,y:710,t:1527876770854};\\\", \\\"{x:495,y:725,t:1527876770871};\\\", \\\"{x:506,y:744,t:1527876770887};\\\", \\\"{x:513,y:753,t:1527876770903};\\\", \\\"{x:514,y:755,t:1527876770921};\\\", \\\"{x:515,y:754,t:1527876771164};\\\", \\\"{x:515,y:753,t:1527876771172};\\\", \\\"{x:516,y:752,t:1527876771187};\\\", \\\"{x:516,y:749,t:1527876771204};\\\", \\\"{x:517,y:748,t:1527876771220};\\\", \\\"{x:517,y:747,t:1527876771237};\\\", \\\"{x:518,y:746,t:1527876771255};\\\", \\\"{x:518,y:745,t:1527876771270};\\\", \\\"{x:518,y:743,t:1527876771287};\\\", \\\"{x:518,y:742,t:1527876771308};\\\", \\\"{x:518,y:741,t:1527876771320};\\\", \\\"{x:518,y:739,t:1527876771337};\\\", \\\"{x:518,y:737,t:1527876771355};\\\", \\\"{x:518,y:736,t:1527876771370};\\\", \\\"{x:519,y:735,t:1527876771764};\\\", \\\"{x:520,y:735,t:1527876771771};\\\", \\\"{x:521,y:735,t:1527876771787};\\\", \\\"{x:525,y:733,t:1527876771805};\\\", \\\"{x:526,y:735,t:1527876771821};\\\", \\\"{x:526,y:735,t:1527876771913};\\\", \\\"{x:532,y:739,t:1527876772412};\\\", \\\"{x:549,y:745,t:1527876772421};\\\", \\\"{x:610,y:762,t:1527876772438};\\\", \\\"{x:697,y:777,t:1527876772454};\\\", \\\"{x:784,y:784,t:1527876772471};\\\", \\\"{x:882,y:784,t:1527876772489};\\\", \\\"{x:988,y:765,t:1527876772505};\\\", \\\"{x:1090,y:720,t:1527876772522};\\\", \\\"{x:1187,y:634,t:1527876772539};\\\", \\\"{x:1260,y:534,t:1527876772555};\\\", \\\"{x:1314,y:428,t:1527876772571};\\\", \\\"{x:1329,y:311,t:1527876772588};\\\", \\\"{x:1315,y:230,t:1527876772606};\\\", \\\"{x:1250,y:110,t:1527876772621};\\\", \\\"{x:1123,y:0,t:1527876772639};\\\", \\\"{x:912,y:0,t:1527876772655};\\\", \\\"{x:628,y:0,t:1527876772671};\\\", \\\"{x:289,y:0,t:1527876772688};\\\", \\\"{x:0,y:0,t:1527876772705};\\\", \\\"{x:0,y:2,t:1527876772812};\\\", \\\"{x:0,y:7,t:1527876772821};\\\", \\\"{x:0,y:16,t:1527876772839};\\\", \\\"{x:0,y:27,t:1527876772855};\\\", \\\"{x:0,y:42,t:1527876772871};\\\", \\\"{x:5,y:55,t:1527876772888};\\\", \\\"{x:15,y:67,t:1527876772905};\\\", \\\"{x:34,y:86,t:1527876772922};\\\", \\\"{x:72,y:114,t:1527876772939};\\\", \\\"{x:139,y:160,t:1527876772955};\\\", \\\"{x:279,y:243,t:1527876772972};\\\", \\\"{x:389,y:291,t:1527876772989};\\\" ] }, { \\\"rt\\\": 12606, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 393047, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"2ZXKM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 3.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"I\\\", \\\"B\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -J -J \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:647,y:342,t:1527876773096};\\\", \\\"{x:654,y:338,t:1527876773123};\\\", \\\"{x:655,y:337,t:1527876773139};\\\", \\\"{x:657,y:336,t:1527876773155};\\\", \\\"{x:658,y:335,t:1527876773172};\\\", \\\"{x:659,y:332,t:1527876773191};\\\", \\\"{x:659,y:326,t:1527876773206};\\\", \\\"{x:659,y:313,t:1527876773222};\\\", \\\"{x:659,y:298,t:1527876773238};\\\", \\\"{x:656,y:286,t:1527876773255};\\\", \\\"{x:652,y:276,t:1527876773272};\\\", \\\"{x:650,y:267,t:1527876773289};\\\", \\\"{x:647,y:262,t:1527876773305};\\\", \\\"{x:646,y:260,t:1527876773323};\\\", \\\"{x:648,y:276,t:1527876773404};\\\", \\\"{x:658,y:314,t:1527876773412};\\\", \\\"{x:676,y:370,t:1527876773422};\\\", \\\"{x:700,y:472,t:1527876773440};\\\", \\\"{x:709,y:555,t:1527876773456};\\\", \\\"{x:714,y:591,t:1527876773472};\\\", \\\"{x:718,y:608,t:1527876773490};\\\", \\\"{x:718,y:613,t:1527876773505};\\\", \\\"{x:718,y:614,t:1527876773548};\\\", \\\"{x:718,y:615,t:1527876773564};\\\", \\\"{x:718,y:616,t:1527876773572};\\\", \\\"{x:715,y:617,t:1527876773589};\\\", \\\"{x:709,y:617,t:1527876773605};\\\", \\\"{x:704,y:617,t:1527876773623};\\\", \\\"{x:636,y:584,t:1527876773694};\\\", \\\"{x:627,y:579,t:1527876773705};\\\", \\\"{x:615,y:572,t:1527876773723};\\\", \\\"{x:601,y:564,t:1527876773739};\\\", \\\"{x:599,y:564,t:1527876773756};\\\", \\\"{x:597,y:562,t:1527876773773};\\\", \\\"{x:596,y:562,t:1527876773796};\\\", \\\"{x:595,y:561,t:1527876773860};\\\", \\\"{x:593,y:561,t:1527876774253};\\\", \\\"{x:590,y:561,t:1527876774260};\\\", \\\"{x:586,y:561,t:1527876774274};\\\", \\\"{x:571,y:559,t:1527876774291};\\\", \\\"{x:554,y:558,t:1527876774307};\\\", \\\"{x:533,y:558,t:1527876774324};\\\", \\\"{x:498,y:556,t:1527876774340};\\\", \\\"{x:476,y:552,t:1527876774358};\\\", \\\"{x:457,y:550,t:1527876774373};\\\", \\\"{x:445,y:548,t:1527876774389};\\\", \\\"{x:437,y:546,t:1527876774405};\\\", \\\"{x:429,y:546,t:1527876774423};\\\", \\\"{x:427,y:546,t:1527876774439};\\\", \\\"{x:426,y:546,t:1527876774456};\\\", \\\"{x:426,y:545,t:1527876774693};\\\", \\\"{x:426,y:544,t:1527876774797};\\\", \\\"{x:426,y:542,t:1527876774806};\\\", \\\"{x:426,y:538,t:1527876774822};\\\", \\\"{x:426,y:537,t:1527876774838};\\\", \\\"{x:426,y:535,t:1527876774856};\\\", \\\"{x:426,y:533,t:1527876774872};\\\", \\\"{x:427,y:532,t:1527876774893};\\\", \\\"{x:427,y:531,t:1527876774933};\\\", \\\"{x:428,y:530,t:1527876774948};\\\", \\\"{x:429,y:530,t:1527876774955};\\\", \\\"{x:437,y:526,t:1527876774971};\\\", \\\"{x:453,y:525,t:1527876774987};\\\", \\\"{x:475,y:525,t:1527876775005};\\\", \\\"{x:498,y:525,t:1527876775022};\\\", \\\"{x:523,y:527,t:1527876775039};\\\", \\\"{x:542,y:529,t:1527876775054};\\\", \\\"{x:557,y:533,t:1527876775073};\\\", \\\"{x:564,y:534,t:1527876775090};\\\", \\\"{x:565,y:534,t:1527876775107};\\\", \\\"{x:569,y:535,t:1527876775291};\\\", \\\"{x:599,y:547,t:1527876775308};\\\", \\\"{x:672,y:571,t:1527876775324};\\\", \\\"{x:782,y:599,t:1527876775341};\\\", \\\"{x:911,y:633,t:1527876775357};\\\", \\\"{x:1058,y:675,t:1527876775373};\\\", \\\"{x:1221,y:721,t:1527876775391};\\\", \\\"{x:1363,y:776,t:1527876775407};\\\", \\\"{x:1465,y:819,t:1527876775424};\\\", \\\"{x:1505,y:838,t:1527876775440};\\\", \\\"{x:1514,y:846,t:1527876775457};\\\", \\\"{x:1516,y:848,t:1527876775473};\\\", \\\"{x:1517,y:848,t:1527876775491};\\\", \\\"{x:1516,y:849,t:1527876775539};\\\", \\\"{x:1513,y:849,t:1527876775548};\\\", \\\"{x:1508,y:847,t:1527876775558};\\\", \\\"{x:1491,y:841,t:1527876775574};\\\", \\\"{x:1466,y:835,t:1527876775591};\\\", \\\"{x:1438,y:830,t:1527876775607};\\\", \\\"{x:1399,y:822,t:1527876775625};\\\", \\\"{x:1374,y:815,t:1527876775640};\\\", \\\"{x:1342,y:805,t:1527876775657};\\\", \\\"{x:1320,y:798,t:1527876775674};\\\", \\\"{x:1304,y:794,t:1527876775691};\\\", \\\"{x:1295,y:792,t:1527876775708};\\\", \\\"{x:1290,y:792,t:1527876775724};\\\", \\\"{x:1287,y:791,t:1527876775740};\\\", \\\"{x:1286,y:791,t:1527876775757};\\\", \\\"{x:1284,y:791,t:1527876775775};\\\", \\\"{x:1280,y:791,t:1527876775791};\\\", \\\"{x:1273,y:791,t:1527876775807};\\\", \\\"{x:1266,y:791,t:1527876775824};\\\", \\\"{x:1255,y:791,t:1527876775841};\\\", \\\"{x:1244,y:791,t:1527876775858};\\\", \\\"{x:1233,y:791,t:1527876775874};\\\", \\\"{x:1222,y:791,t:1527876775891};\\\", \\\"{x:1202,y:790,t:1527876775908};\\\", \\\"{x:1175,y:790,t:1527876775924};\\\", \\\"{x:1168,y:803,t:1527876775940};\\\", \\\"{x:1168,y:829,t:1527876775958};\\\", \\\"{x:1171,y:857,t:1527876775974};\\\", \\\"{x:1182,y:877,t:1527876775991};\\\", \\\"{x:1191,y:888,t:1527876776007};\\\", \\\"{x:1199,y:894,t:1527876776025};\\\", \\\"{x:1200,y:895,t:1527876776041};\\\", \\\"{x:1201,y:895,t:1527876776058};\\\", \\\"{x:1202,y:895,t:1527876776109};\\\", \\\"{x:1204,y:895,t:1527876776124};\\\", \\\"{x:1208,y:886,t:1527876776142};\\\", \\\"{x:1210,y:876,t:1527876776157};\\\", \\\"{x:1212,y:865,t:1527876776175};\\\", \\\"{x:1212,y:859,t:1527876776191};\\\", \\\"{x:1212,y:856,t:1527876776208};\\\", \\\"{x:1212,y:852,t:1527876776224};\\\", \\\"{x:1212,y:850,t:1527876776242};\\\", \\\"{x:1212,y:846,t:1527876776258};\\\", \\\"{x:1212,y:845,t:1527876776274};\\\", \\\"{x:1212,y:843,t:1527876776292};\\\", \\\"{x:1212,y:841,t:1527876776420};\\\", \\\"{x:1212,y:839,t:1527876776428};\\\", \\\"{x:1212,y:838,t:1527876776442};\\\", \\\"{x:1212,y:835,t:1527876776459};\\\", \\\"{x:1207,y:834,t:1527876777255};\\\", \\\"{x:1199,y:834,t:1527876777260};\\\", \\\"{x:1178,y:832,t:1527876777276};\\\", \\\"{x:1151,y:826,t:1527876777293};\\\", \\\"{x:1121,y:818,t:1527876777309};\\\", \\\"{x:1071,y:804,t:1527876777325};\\\", \\\"{x:1012,y:788,t:1527876777342};\\\", \\\"{x:945,y:768,t:1527876777359};\\\", \\\"{x:882,y:751,t:1527876777376};\\\", \\\"{x:801,y:729,t:1527876777392};\\\", \\\"{x:729,y:705,t:1527876777409};\\\", \\\"{x:657,y:687,t:1527876777425};\\\", \\\"{x:588,y:669,t:1527876777442};\\\", \\\"{x:527,y:652,t:1527876777458};\\\", \\\"{x:471,y:646,t:1527876777476};\\\", \\\"{x:444,y:641,t:1527876777493};\\\", \\\"{x:418,y:638,t:1527876777509};\\\", \\\"{x:393,y:634,t:1527876777526};\\\", \\\"{x:363,y:628,t:1527876777542};\\\", \\\"{x:335,y:621,t:1527876777559};\\\", \\\"{x:314,y:614,t:1527876777576};\\\", \\\"{x:293,y:609,t:1527876777593};\\\", \\\"{x:275,y:603,t:1527876777609};\\\", \\\"{x:257,y:595,t:1527876777626};\\\", \\\"{x:232,y:584,t:1527876777643};\\\", \\\"{x:194,y:572,t:1527876777660};\\\", \\\"{x:172,y:564,t:1527876777675};\\\", \\\"{x:157,y:558,t:1527876777693};\\\", \\\"{x:152,y:555,t:1527876777711};\\\", \\\"{x:150,y:555,t:1527876777725};\\\", \\\"{x:150,y:554,t:1527876777852};\\\", \\\"{x:151,y:553,t:1527876777860};\\\", \\\"{x:156,y:552,t:1527876777876};\\\", \\\"{x:160,y:549,t:1527876777893};\\\", \\\"{x:170,y:548,t:1527876777909};\\\", \\\"{x:191,y:548,t:1527876777925};\\\", \\\"{x:222,y:548,t:1527876777943};\\\", \\\"{x:264,y:548,t:1527876777960};\\\", \\\"{x:317,y:548,t:1527876777976};\\\", \\\"{x:381,y:548,t:1527876777993};\\\", \\\"{x:428,y:548,t:1527876778010};\\\", \\\"{x:458,y:546,t:1527876778027};\\\", \\\"{x:476,y:543,t:1527876778043};\\\", \\\"{x:482,y:542,t:1527876778060};\\\", \\\"{x:483,y:543,t:1527876778244};\\\", \\\"{x:483,y:551,t:1527876778260};\\\", \\\"{x:483,y:558,t:1527876778277};\\\", \\\"{x:484,y:563,t:1527876778294};\\\", \\\"{x:484,y:567,t:1527876778310};\\\", \\\"{x:487,y:571,t:1527876778327};\\\", \\\"{x:488,y:575,t:1527876778344};\\\", \\\"{x:489,y:575,t:1527876778359};\\\", \\\"{x:489,y:576,t:1527876778377};\\\", \\\"{x:492,y:579,t:1527876778780};\\\", \\\"{x:500,y:582,t:1527876778795};\\\", \\\"{x:523,y:589,t:1527876778811};\\\", \\\"{x:552,y:594,t:1527876778827};\\\", \\\"{x:646,y:609,t:1527876778844};\\\", \\\"{x:731,y:630,t:1527876778860};\\\", \\\"{x:817,y:652,t:1527876778877};\\\", \\\"{x:891,y:680,t:1527876778893};\\\", \\\"{x:971,y:716,t:1527876778910};\\\", \\\"{x:1057,y:753,t:1527876778927};\\\", \\\"{x:1128,y:784,t:1527876778943};\\\", \\\"{x:1181,y:807,t:1527876778960};\\\", \\\"{x:1214,y:822,t:1527876778976};\\\", \\\"{x:1228,y:828,t:1527876778994};\\\", \\\"{x:1229,y:830,t:1527876779011};\\\", \\\"{x:1228,y:831,t:1527876779044};\\\", \\\"{x:1219,y:831,t:1527876779061};\\\", \\\"{x:1203,y:831,t:1527876779077};\\\", \\\"{x:1173,y:831,t:1527876779093};\\\", \\\"{x:1112,y:831,t:1527876779111};\\\", \\\"{x:1001,y:831,t:1527876779127};\\\", \\\"{x:870,y:826,t:1527876779144};\\\", \\\"{x:710,y:804,t:1527876779160};\\\", \\\"{x:558,y:782,t:1527876779178};\\\", \\\"{x:455,y:768,t:1527876779194};\\\", \\\"{x:402,y:760,t:1527876779210};\\\", \\\"{x:386,y:758,t:1527876779228};\\\", \\\"{x:386,y:757,t:1527876779317};\\\", \\\"{x:386,y:755,t:1527876779340};\\\", \\\"{x:386,y:753,t:1527876779348};\\\", \\\"{x:390,y:750,t:1527876779361};\\\", \\\"{x:402,y:739,t:1527876779378};\\\", \\\"{x:415,y:734,t:1527876779394};\\\", \\\"{x:426,y:730,t:1527876779412};\\\", \\\"{x:447,y:725,t:1527876779429};\\\", \\\"{x:452,y:724,t:1527876779445};\\\", \\\"{x:453,y:724,t:1527876779468};\\\", \\\"{x:454,y:725,t:1527876779533};\\\", \\\"{x:453,y:727,t:1527876779548};\\\", \\\"{x:451,y:728,t:1527876779561};\\\", \\\"{x:443,y:729,t:1527876779578};\\\", \\\"{x:434,y:729,t:1527876779593};\\\", \\\"{x:428,y:729,t:1527876779611};\\\", \\\"{x:421,y:727,t:1527876779628};\\\", \\\"{x:418,y:726,t:1527876779644};\\\", \\\"{x:414,y:726,t:1527876779660};\\\", \\\"{x:407,y:726,t:1527876779677};\\\", \\\"{x:399,y:726,t:1527876779693};\\\", \\\"{x:390,y:724,t:1527876779710};\\\", \\\"{x:375,y:718,t:1527876779727};\\\", \\\"{x:364,y:714,t:1527876779743};\\\", \\\"{x:353,y:710,t:1527876779760};\\\", \\\"{x:343,y:704,t:1527876779778};\\\", \\\"{x:330,y:697,t:1527876779794};\\\", \\\"{x:320,y:690,t:1527876779811};\\\", \\\"{x:305,y:677,t:1527876779828};\\\", \\\"{x:301,y:672,t:1527876779843};\\\", \\\"{x:297,y:666,t:1527876779861};\\\", \\\"{x:293,y:661,t:1527876779877};\\\", \\\"{x:291,y:657,t:1527876779895};\\\", \\\"{x:289,y:654,t:1527876779910};\\\", \\\"{x:286,y:650,t:1527876779928};\\\", \\\"{x:282,y:645,t:1527876779944};\\\", \\\"{x:278,y:642,t:1527876779961};\\\", \\\"{x:276,y:639,t:1527876779977};\\\", \\\"{x:274,y:638,t:1527876779995};\\\", \\\"{x:274,y:636,t:1527876780011};\\\", \\\"{x:268,y:627,t:1527876780028};\\\", \\\"{x:261,y:617,t:1527876780044};\\\", \\\"{x:253,y:610,t:1527876780060};\\\", \\\"{x:247,y:604,t:1527876780078};\\\", \\\"{x:244,y:600,t:1527876780096};\\\", \\\"{x:243,y:600,t:1527876780111};\\\", \\\"{x:242,y:598,t:1527876780128};\\\", \\\"{x:236,y:596,t:1527876780145};\\\", \\\"{x:224,y:592,t:1527876780161};\\\", \\\"{x:215,y:588,t:1527876780177};\\\", \\\"{x:213,y:587,t:1527876780194};\\\", \\\"{x:210,y:584,t:1527876780211};\\\", \\\"{x:199,y:571,t:1527876780228};\\\", \\\"{x:194,y:561,t:1527876780245};\\\", \\\"{x:191,y:552,t:1527876780261};\\\", \\\"{x:188,y:546,t:1527876780278};\\\", \\\"{x:187,y:541,t:1527876780295};\\\", \\\"{x:187,y:537,t:1527876780311};\\\", \\\"{x:184,y:530,t:1527876780328};\\\", \\\"{x:184,y:526,t:1527876780345};\\\", \\\"{x:183,y:519,t:1527876780362};\\\", \\\"{x:182,y:513,t:1527876780378};\\\", \\\"{x:176,y:507,t:1527876780395};\\\", \\\"{x:165,y:498,t:1527876780412};\\\", \\\"{x:161,y:496,t:1527876780428};\\\", \\\"{x:160,y:495,t:1527876780445};\\\", \\\"{x:159,y:495,t:1527876780694};\\\", \\\"{x:158,y:495,t:1527876780712};\\\", \\\"{x:156,y:496,t:1527876780729};\\\", \\\"{x:155,y:498,t:1527876780744};\\\", \\\"{x:155,y:503,t:1527876780761};\\\", \\\"{x:154,y:513,t:1527876780779};\\\", \\\"{x:152,y:524,t:1527876780795};\\\", \\\"{x:151,y:528,t:1527876780812};\\\", \\\"{x:151,y:529,t:1527876780829};\\\", \\\"{x:151,y:530,t:1527876781149};\\\", \\\"{x:152,y:533,t:1527876782052};\\\", \\\"{x:154,y:539,t:1527876782063};\\\", \\\"{x:157,y:546,t:1527876782080};\\\", \\\"{x:159,y:550,t:1527876782096};\\\", \\\"{x:161,y:555,t:1527876782113};\\\", \\\"{x:163,y:558,t:1527876782130};\\\", \\\"{x:163,y:559,t:1527876782146};\\\", \\\"{x:163,y:560,t:1527876782163};\\\", \\\"{x:165,y:564,t:1527876782179};\\\", \\\"{x:172,y:582,t:1527876782196};\\\", \\\"{x:179,y:597,t:1527876782213};\\\", \\\"{x:183,y:609,t:1527876782230};\\\", \\\"{x:186,y:616,t:1527876782246};\\\", \\\"{x:187,y:619,t:1527876782262};\\\", \\\"{x:187,y:620,t:1527876782280};\\\", \\\"{x:188,y:621,t:1527876782299};\\\", \\\"{x:189,y:623,t:1527876782312};\\\", \\\"{x:191,y:625,t:1527876782329};\\\", \\\"{x:195,y:628,t:1527876782346};\\\", \\\"{x:202,y:630,t:1527876782362};\\\", \\\"{x:215,y:633,t:1527876782380};\\\", \\\"{x:232,y:633,t:1527876782396};\\\", \\\"{x:263,y:633,t:1527876782412};\\\", \\\"{x:300,y:633,t:1527876782430};\\\", \\\"{x:335,y:630,t:1527876782446};\\\", \\\"{x:365,y:627,t:1527876782463};\\\", \\\"{x:392,y:623,t:1527876782480};\\\", \\\"{x:405,y:621,t:1527876782496};\\\", \\\"{x:408,y:621,t:1527876782512};\\\", \\\"{x:410,y:619,t:1527876782684};\\\", \\\"{x:411,y:618,t:1527876782697};\\\", \\\"{x:418,y:615,t:1527876782714};\\\", \\\"{x:428,y:610,t:1527876782730};\\\", \\\"{x:448,y:604,t:1527876782746};\\\", \\\"{x:485,y:599,t:1527876782763};\\\", \\\"{x:548,y:590,t:1527876782780};\\\", \\\"{x:580,y:581,t:1527876782796};\\\", \\\"{x:602,y:574,t:1527876782813};\\\", \\\"{x:615,y:568,t:1527876782829};\\\", \\\"{x:624,y:568,t:1527876782847};\\\", \\\"{x:628,y:568,t:1527876782864};\\\", \\\"{x:630,y:568,t:1527876782879};\\\", \\\"{x:632,y:568,t:1527876782897};\\\", \\\"{x:636,y:568,t:1527876782914};\\\", \\\"{x:651,y:569,t:1527876782931};\\\", \\\"{x:682,y:569,t:1527876782947};\\\", \\\"{x:714,y:569,t:1527876782964};\\\", \\\"{x:750,y:569,t:1527876782980};\\\", \\\"{x:775,y:569,t:1527876782997};\\\", \\\"{x:798,y:569,t:1527876783014};\\\", \\\"{x:814,y:569,t:1527876783029};\\\", \\\"{x:827,y:569,t:1527876783047};\\\", \\\"{x:832,y:569,t:1527876783064};\\\", \\\"{x:834,y:569,t:1527876783080};\\\", \\\"{x:835,y:572,t:1527876783140};\\\", \\\"{x:836,y:575,t:1527876783148};\\\", \\\"{x:838,y:582,t:1527876783163};\\\", \\\"{x:838,y:587,t:1527876783179};\\\", \\\"{x:838,y:589,t:1527876783196};\\\", \\\"{x:838,y:590,t:1527876783214};\\\", \\\"{x:838,y:592,t:1527876783229};\\\", \\\"{x:838,y:593,t:1527876783828};\\\", \\\"{x:837,y:593,t:1527876783835};\\\", \\\"{x:836,y:591,t:1527876783859};\\\", \\\"{x:835,y:590,t:1527876783875};\\\", \\\"{x:835,y:589,t:1527876783883};\\\", \\\"{x:835,y:588,t:1527876783896};\\\", \\\"{x:833,y:584,t:1527876784163};\\\", \\\"{x:833,y:580,t:1527876784181};\\\", \\\"{x:831,y:577,t:1527876784198};\\\", \\\"{x:830,y:575,t:1527876784214};\\\", \\\"{x:830,y:574,t:1527876784231};\\\", \\\"{x:829,y:573,t:1527876784248};\\\", \\\"{x:828,y:573,t:1527876784485};\\\", \\\"{x:819,y:575,t:1527876784499};\\\", \\\"{x:786,y:591,t:1527876784514};\\\", \\\"{x:747,y:600,t:1527876784531};\\\", \\\"{x:702,y:614,t:1527876784548};\\\", \\\"{x:686,y:620,t:1527876784565};\\\", \\\"{x:678,y:624,t:1527876784581};\\\", \\\"{x:670,y:631,t:1527876784598};\\\", \\\"{x:664,y:635,t:1527876784615};\\\", \\\"{x:653,y:644,t:1527876784632};\\\", \\\"{x:637,y:656,t:1527876784648};\\\", \\\"{x:620,y:667,t:1527876784664};\\\", \\\"{x:602,y:680,t:1527876784681};\\\", \\\"{x:586,y:689,t:1527876784698};\\\", \\\"{x:579,y:693,t:1527876784714};\\\", \\\"{x:573,y:698,t:1527876784732};\\\", \\\"{x:567,y:702,t:1527876784747};\\\", \\\"{x:563,y:706,t:1527876784765};\\\", \\\"{x:558,y:710,t:1527876784781};\\\", \\\"{x:551,y:713,t:1527876784798};\\\", \\\"{x:544,y:716,t:1527876784814};\\\", \\\"{x:539,y:718,t:1527876784832};\\\", \\\"{x:531,y:722,t:1527876784848};\\\", \\\"{x:523,y:723,t:1527876784865};\\\", \\\"{x:513,y:726,t:1527876784882};\\\", \\\"{x:504,y:727,t:1527876784898};\\\", \\\"{x:497,y:728,t:1527876784915};\\\", \\\"{x:487,y:730,t:1527876784932};\\\", \\\"{x:480,y:731,t:1527876784948};\\\", \\\"{x:473,y:731,t:1527876784965};\\\", \\\"{x:465,y:733,t:1527876784982};\\\", \\\"{x:457,y:735,t:1527876784998};\\\", \\\"{x:447,y:735,t:1527876785015};\\\", \\\"{x:439,y:736,t:1527876785033};\\\", \\\"{x:433,y:737,t:1527876785048};\\\", \\\"{x:427,y:739,t:1527876785065};\\\", \\\"{x:418,y:740,t:1527876785082};\\\", \\\"{x:410,y:740,t:1527876785099};\\\", \\\"{x:406,y:740,t:1527876785116};\\\", \\\"{x:405,y:740,t:1527876785132};\\\", \\\"{x:406,y:740,t:1527876785364};\\\", \\\"{x:413,y:740,t:1527876785372};\\\", \\\"{x:422,y:740,t:1527876785382};\\\", \\\"{x:445,y:741,t:1527876785400};\\\", \\\"{x:470,y:744,t:1527876785415};\\\", \\\"{x:486,y:745,t:1527876785432};\\\", \\\"{x:493,y:745,t:1527876785449};\\\", \\\"{x:494,y:745,t:1527876785465};\\\", \\\"{x:495,y:745,t:1527876785524};\\\", \\\"{x:496,y:745,t:1527876785531};\\\", \\\"{x:498,y:745,t:1527876785555};\\\", \\\"{x:499,y:745,t:1527876785566};\\\", \\\"{x:500,y:745,t:1527876785588};\\\" ] }, { \\\"rt\\\": 48198, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 442481, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"2ZXKM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 8.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"C\\\", \\\"X\\\", \\\"O\\\", \\\"H\\\", \\\"Z\\\", \\\"N\\\", \\\"D\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -B -B -12 PM-12 PM-B -B -B -10 AM-O -3-4-5\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:502,y:743,t:1527876787420};\\\", \\\"{x:504,y:741,t:1527876787435};\\\", \\\"{x:507,y:735,t:1527876787451};\\\", \\\"{x:513,y:729,t:1527876787467};\\\", \\\"{x:515,y:725,t:1527876787485};\\\", \\\"{x:517,y:722,t:1527876787501};\\\", \\\"{x:521,y:718,t:1527876787518};\\\", \\\"{x:526,y:712,t:1527876787535};\\\", \\\"{x:533,y:703,t:1527876787550};\\\", \\\"{x:540,y:691,t:1527876787567};\\\", \\\"{x:547,y:682,t:1527876787584};\\\", \\\"{x:551,y:672,t:1527876787600};\\\", \\\"{x:557,y:655,t:1527876787616};\\\", \\\"{x:563,y:633,t:1527876787634};\\\", \\\"{x:567,y:623,t:1527876787651};\\\", \\\"{x:570,y:616,t:1527876787666};\\\", \\\"{x:579,y:601,t:1527876787683};\\\", \\\"{x:583,y:595,t:1527876787701};\\\", \\\"{x:586,y:592,t:1527876787718};\\\", \\\"{x:588,y:590,t:1527876787734};\\\", \\\"{x:588,y:588,t:1527876787940};\\\", \\\"{x:585,y:587,t:1527876787951};\\\", \\\"{x:578,y:585,t:1527876787967};\\\", \\\"{x:571,y:584,t:1527876787984};\\\", \\\"{x:559,y:580,t:1527876788001};\\\", \\\"{x:542,y:575,t:1527876788017};\\\", \\\"{x:521,y:569,t:1527876788034};\\\", \\\"{x:498,y:565,t:1527876788052};\\\", \\\"{x:488,y:562,t:1527876788068};\\\", \\\"{x:484,y:561,t:1527876788084};\\\", \\\"{x:483,y:561,t:1527876788604};\\\", \\\"{x:483,y:560,t:1527876788617};\\\", \\\"{x:490,y:560,t:1527876788633};\\\", \\\"{x:499,y:560,t:1527876788650};\\\", \\\"{x:505,y:560,t:1527876788668};\\\", \\\"{x:509,y:560,t:1527876788683};\\\", \\\"{x:517,y:559,t:1527876788700};\\\", \\\"{x:525,y:556,t:1527876788718};\\\", \\\"{x:539,y:554,t:1527876788735};\\\", \\\"{x:556,y:551,t:1527876788750};\\\", \\\"{x:577,y:544,t:1527876788768};\\\", \\\"{x:600,y:536,t:1527876788785};\\\", \\\"{x:621,y:531,t:1527876788802};\\\", \\\"{x:634,y:524,t:1527876788818};\\\", \\\"{x:636,y:523,t:1527876788835};\\\", \\\"{x:641,y:520,t:1527876788851};\\\", \\\"{x:646,y:518,t:1527876788867};\\\", \\\"{x:651,y:515,t:1527876788886};\\\", \\\"{x:656,y:513,t:1527876788901};\\\", \\\"{x:661,y:511,t:1527876788918};\\\", \\\"{x:663,y:509,t:1527876788935};\\\", \\\"{x:664,y:508,t:1527876789245};\\\", \\\"{x:664,y:506,t:1527876789251};\\\", \\\"{x:664,y:504,t:1527876789268};\\\", \\\"{x:666,y:502,t:1527876789285};\\\", \\\"{x:667,y:502,t:1527876789302};\\\", \\\"{x:669,y:500,t:1527876789318};\\\", \\\"{x:670,y:499,t:1527876789335};\\\", \\\"{x:671,y:498,t:1527876789352};\\\", \\\"{x:674,y:497,t:1527876789368};\\\", \\\"{x:679,y:494,t:1527876789385};\\\", \\\"{x:688,y:489,t:1527876789402};\\\", \\\"{x:701,y:484,t:1527876789419};\\\", \\\"{x:717,y:481,t:1527876789435};\\\", \\\"{x:751,y:475,t:1527876789451};\\\", \\\"{x:792,y:469,t:1527876789469};\\\", \\\"{x:880,y:460,t:1527876789485};\\\", \\\"{x:985,y:460,t:1527876789502};\\\", \\\"{x:1107,y:460,t:1527876789519};\\\", \\\"{x:1252,y:465,t:1527876789535};\\\", \\\"{x:1423,y:487,t:1527876789552};\\\", \\\"{x:1567,y:507,t:1527876789569};\\\", \\\"{x:1677,y:517,t:1527876789585};\\\", \\\"{x:1770,y:525,t:1527876789602};\\\", \\\"{x:1823,y:525,t:1527876789619};\\\", \\\"{x:1847,y:526,t:1527876789634};\\\", \\\"{x:1852,y:526,t:1527876789652};\\\", \\\"{x:1853,y:527,t:1527876789764};\\\", \\\"{x:1853,y:528,t:1527876789780};\\\", \\\"{x:1853,y:530,t:1527876789788};\\\", \\\"{x:1850,y:530,t:1527876789803};\\\", \\\"{x:1843,y:535,t:1527876789820};\\\", \\\"{x:1821,y:543,t:1527876789836};\\\", \\\"{x:1796,y:548,t:1527876789852};\\\", \\\"{x:1769,y:549,t:1527876789869};\\\", \\\"{x:1744,y:549,t:1527876789886};\\\", \\\"{x:1721,y:546,t:1527876789903};\\\", \\\"{x:1698,y:543,t:1527876789920};\\\", \\\"{x:1680,y:541,t:1527876789936};\\\", \\\"{x:1667,y:540,t:1527876789953};\\\", \\\"{x:1658,y:537,t:1527876789969};\\\", \\\"{x:1648,y:536,t:1527876789987};\\\", \\\"{x:1639,y:535,t:1527876790002};\\\", \\\"{x:1629,y:533,t:1527876790020};\\\", \\\"{x:1617,y:532,t:1527876790037};\\\", \\\"{x:1613,y:532,t:1527876790052};\\\", \\\"{x:1609,y:531,t:1527876790070};\\\", \\\"{x:1607,y:531,t:1527876790086};\\\", \\\"{x:1605,y:530,t:1527876790102};\\\", \\\"{x:1603,y:530,t:1527876790120};\\\", \\\"{x:1601,y:530,t:1527876790136};\\\", \\\"{x:1599,y:530,t:1527876790152};\\\", \\\"{x:1597,y:530,t:1527876790169};\\\", \\\"{x:1593,y:530,t:1527876790186};\\\", \\\"{x:1588,y:530,t:1527876790202};\\\", \\\"{x:1583,y:530,t:1527876790219};\\\", \\\"{x:1575,y:530,t:1527876790236};\\\", \\\"{x:1570,y:529,t:1527876790253};\\\", \\\"{x:1567,y:528,t:1527876790269};\\\", \\\"{x:1564,y:528,t:1527876790286};\\\", \\\"{x:1562,y:528,t:1527876790303};\\\", \\\"{x:1559,y:528,t:1527876790320};\\\", \\\"{x:1556,y:528,t:1527876790336};\\\", \\\"{x:1554,y:528,t:1527876790353};\\\", \\\"{x:1552,y:528,t:1527876790370};\\\", \\\"{x:1549,y:528,t:1527876790387};\\\", \\\"{x:1543,y:529,t:1527876790404};\\\", \\\"{x:1539,y:529,t:1527876790420};\\\", \\\"{x:1537,y:530,t:1527876790437};\\\", \\\"{x:1535,y:530,t:1527876790454};\\\", \\\"{x:1534,y:530,t:1527876790470};\\\", \\\"{x:1533,y:530,t:1527876790487};\\\", \\\"{x:1532,y:530,t:1527876790504};\\\", \\\"{x:1531,y:530,t:1527876790519};\\\", \\\"{x:1528,y:531,t:1527876790537};\\\", \\\"{x:1526,y:531,t:1527876790554};\\\", \\\"{x:1523,y:532,t:1527876790570};\\\", \\\"{x:1522,y:533,t:1527876790587};\\\", \\\"{x:1520,y:533,t:1527876790604};\\\", \\\"{x:1519,y:533,t:1527876790620};\\\", \\\"{x:1518,y:533,t:1527876790636};\\\", \\\"{x:1516,y:534,t:1527876790654};\\\", \\\"{x:1515,y:534,t:1527876790669};\\\", \\\"{x:1513,y:536,t:1527876790687};\\\", \\\"{x:1510,y:537,t:1527876790704};\\\", \\\"{x:1508,y:538,t:1527876790719};\\\", \\\"{x:1506,y:539,t:1527876790737};\\\", \\\"{x:1504,y:540,t:1527876790754};\\\", \\\"{x:1501,y:542,t:1527876790769};\\\", \\\"{x:1498,y:544,t:1527876790786};\\\", \\\"{x:1492,y:548,t:1527876790803};\\\", \\\"{x:1485,y:555,t:1527876790820};\\\", \\\"{x:1481,y:558,t:1527876790837};\\\", \\\"{x:1478,y:562,t:1527876790854};\\\", \\\"{x:1475,y:564,t:1527876790870};\\\", \\\"{x:1470,y:568,t:1527876790887};\\\", \\\"{x:1465,y:572,t:1527876790903};\\\", \\\"{x:1459,y:577,t:1527876790920};\\\", \\\"{x:1455,y:581,t:1527876790936};\\\", \\\"{x:1449,y:588,t:1527876790953};\\\", \\\"{x:1444,y:595,t:1527876790970};\\\", \\\"{x:1441,y:601,t:1527876790986};\\\", \\\"{x:1436,y:609,t:1527876791003};\\\", \\\"{x:1428,y:622,t:1527876791020};\\\", \\\"{x:1423,y:631,t:1527876791036};\\\", \\\"{x:1418,y:642,t:1527876791054};\\\", \\\"{x:1414,y:651,t:1527876791070};\\\", \\\"{x:1408,y:661,t:1527876791086};\\\", \\\"{x:1405,y:669,t:1527876791104};\\\", \\\"{x:1400,y:676,t:1527876791121};\\\", \\\"{x:1398,y:682,t:1527876791136};\\\", \\\"{x:1396,y:686,t:1527876791152};\\\", \\\"{x:1395,y:691,t:1527876791170};\\\", \\\"{x:1393,y:694,t:1527876791187};\\\", \\\"{x:1390,y:700,t:1527876791203};\\\", \\\"{x:1385,y:711,t:1527876791220};\\\", \\\"{x:1383,y:717,t:1527876791237};\\\", \\\"{x:1381,y:722,t:1527876791253};\\\", \\\"{x:1378,y:727,t:1527876791270};\\\", \\\"{x:1376,y:731,t:1527876791287};\\\", \\\"{x:1374,y:737,t:1527876791303};\\\", \\\"{x:1372,y:740,t:1527876791320};\\\", \\\"{x:1369,y:744,t:1527876791337};\\\", \\\"{x:1368,y:747,t:1527876791353};\\\", \\\"{x:1367,y:749,t:1527876791370};\\\", \\\"{x:1364,y:753,t:1527876791387};\\\", \\\"{x:1361,y:757,t:1527876791404};\\\", \\\"{x:1359,y:759,t:1527876791420};\\\", \\\"{x:1358,y:761,t:1527876791437};\\\", \\\"{x:1357,y:762,t:1527876791453};\\\", \\\"{x:1356,y:763,t:1527876791470};\\\", \\\"{x:1356,y:764,t:1527876791508};\\\", \\\"{x:1354,y:765,t:1527876792245};\\\", \\\"{x:1353,y:765,t:1527876792263};\\\", \\\"{x:1352,y:765,t:1527876792339};\\\", \\\"{x:1350,y:766,t:1527876792354};\\\", \\\"{x:1349,y:768,t:1527876792371};\\\", \\\"{x:1347,y:769,t:1527876792388};\\\", \\\"{x:1346,y:769,t:1527876792404};\\\", \\\"{x:1344,y:770,t:1527876792422};\\\", \\\"{x:1343,y:771,t:1527876792452};\\\", \\\"{x:1342,y:772,t:1527876792493};\\\", \\\"{x:1341,y:772,t:1527876792508};\\\", \\\"{x:1341,y:770,t:1527876792899};\\\", \\\"{x:1341,y:769,t:1527876792908};\\\", \\\"{x:1341,y:768,t:1527876792921};\\\", \\\"{x:1341,y:766,t:1527876792938};\\\", \\\"{x:1342,y:765,t:1527876792955};\\\", \\\"{x:1343,y:764,t:1527876792972};\\\", \\\"{x:1343,y:762,t:1527876792988};\\\", \\\"{x:1343,y:760,t:1527876793005};\\\", \\\"{x:1343,y:759,t:1527876793036};\\\", \\\"{x:1344,y:759,t:1527876793084};\\\", \\\"{x:1343,y:760,t:1527876793413};\\\", \\\"{x:1343,y:761,t:1527876793422};\\\", \\\"{x:1342,y:762,t:1527876793439};\\\", \\\"{x:1342,y:764,t:1527876793455};\\\", \\\"{x:1340,y:766,t:1527876793473};\\\", \\\"{x:1340,y:767,t:1527876793491};\\\", \\\"{x:1339,y:768,t:1527876793508};\\\", \\\"{x:1339,y:769,t:1527876793539};\\\", \\\"{x:1339,y:770,t:1527876793555};\\\", \\\"{x:1337,y:771,t:1527876793571};\\\", \\\"{x:1337,y:770,t:1527876793973};\\\", \\\"{x:1338,y:769,t:1527876793989};\\\", \\\"{x:1340,y:767,t:1527876794006};\\\", \\\"{x:1340,y:766,t:1527876794036};\\\", \\\"{x:1341,y:765,t:1527876794060};\\\", \\\"{x:1342,y:764,t:1527876794085};\\\", \\\"{x:1343,y:764,t:1527876794106};\\\", \\\"{x:1344,y:763,t:1527876794157};\\\", \\\"{x:1344,y:762,t:1527876794172};\\\", \\\"{x:1345,y:762,t:1527876794189};\\\", \\\"{x:1346,y:762,t:1527876794206};\\\", \\\"{x:1346,y:763,t:1527876794780};\\\", \\\"{x:1346,y:765,t:1527876794790};\\\", \\\"{x:1346,y:769,t:1527876794808};\\\", \\\"{x:1345,y:773,t:1527876794824};\\\", \\\"{x:1345,y:780,t:1527876794840};\\\", \\\"{x:1344,y:787,t:1527876794857};\\\", \\\"{x:1344,y:795,t:1527876794873};\\\", \\\"{x:1342,y:806,t:1527876794889};\\\", \\\"{x:1342,y:817,t:1527876794906};\\\", \\\"{x:1342,y:825,t:1527876794924};\\\", \\\"{x:1343,y:834,t:1527876794940};\\\", \\\"{x:1345,y:843,t:1527876794956};\\\", \\\"{x:1346,y:846,t:1527876794973};\\\", \\\"{x:1346,y:849,t:1527876794990};\\\", \\\"{x:1347,y:854,t:1527876795007};\\\", \\\"{x:1348,y:860,t:1527876795024};\\\", \\\"{x:1350,y:870,t:1527876795040};\\\", \\\"{x:1351,y:881,t:1527876795057};\\\", \\\"{x:1352,y:890,t:1527876795074};\\\", \\\"{x:1355,y:897,t:1527876795090};\\\", \\\"{x:1356,y:903,t:1527876795107};\\\", \\\"{x:1358,y:908,t:1527876795124};\\\", \\\"{x:1359,y:915,t:1527876795140};\\\", \\\"{x:1359,y:919,t:1527876795156};\\\", \\\"{x:1359,y:925,t:1527876795173};\\\", \\\"{x:1359,y:930,t:1527876795191};\\\", \\\"{x:1362,y:939,t:1527876795207};\\\", \\\"{x:1362,y:943,t:1527876795224};\\\", \\\"{x:1363,y:949,t:1527876795241};\\\", \\\"{x:1364,y:955,t:1527876795257};\\\", \\\"{x:1364,y:961,t:1527876795274};\\\", \\\"{x:1364,y:968,t:1527876795291};\\\", \\\"{x:1364,y:975,t:1527876795307};\\\", \\\"{x:1364,y:984,t:1527876795324};\\\", \\\"{x:1364,y:988,t:1527876795341};\\\", \\\"{x:1364,y:990,t:1527876795356};\\\", \\\"{x:1364,y:991,t:1527876795374};\\\", \\\"{x:1364,y:989,t:1527876795540};\\\", \\\"{x:1364,y:985,t:1527876795557};\\\", \\\"{x:1363,y:977,t:1527876795574};\\\", \\\"{x:1360,y:969,t:1527876795591};\\\", \\\"{x:1358,y:963,t:1527876795608};\\\", \\\"{x:1358,y:956,t:1527876795624};\\\", \\\"{x:1357,y:951,t:1527876795641};\\\", \\\"{x:1356,y:947,t:1527876795658};\\\", \\\"{x:1356,y:941,t:1527876795674};\\\", \\\"{x:1354,y:935,t:1527876795690};\\\", \\\"{x:1354,y:928,t:1527876795707};\\\", \\\"{x:1352,y:917,t:1527876795724};\\\", \\\"{x:1352,y:912,t:1527876795741};\\\", \\\"{x:1350,y:905,t:1527876795758};\\\", \\\"{x:1349,y:896,t:1527876795774};\\\", \\\"{x:1348,y:891,t:1527876795791};\\\", \\\"{x:1346,y:888,t:1527876795808};\\\", \\\"{x:1345,y:884,t:1527876795824};\\\", \\\"{x:1345,y:883,t:1527876795844};\\\", \\\"{x:1345,y:882,t:1527876795858};\\\", \\\"{x:1344,y:880,t:1527876795874};\\\", \\\"{x:1342,y:875,t:1527876795891};\\\", \\\"{x:1341,y:872,t:1527876795908};\\\", \\\"{x:1339,y:870,t:1527876795924};\\\", \\\"{x:1338,y:866,t:1527876795940};\\\", \\\"{x:1337,y:863,t:1527876795957};\\\", \\\"{x:1335,y:859,t:1527876795973};\\\", \\\"{x:1333,y:853,t:1527876795990};\\\", \\\"{x:1331,y:849,t:1527876796007};\\\", \\\"{x:1329,y:843,t:1527876796024};\\\", \\\"{x:1327,y:836,t:1527876796040};\\\", \\\"{x:1325,y:831,t:1527876796057};\\\", \\\"{x:1323,y:824,t:1527876796074};\\\", \\\"{x:1321,y:817,t:1527876796090};\\\", \\\"{x:1318,y:813,t:1527876796108};\\\", \\\"{x:1318,y:811,t:1527876796124};\\\", \\\"{x:1317,y:811,t:1527876796140};\\\", \\\"{x:1317,y:810,t:1527876796158};\\\", \\\"{x:1316,y:810,t:1527876796175};\\\", \\\"{x:1315,y:810,t:1527876796191};\\\", \\\"{x:1313,y:809,t:1527876796208};\\\", \\\"{x:1309,y:809,t:1527876796225};\\\", \\\"{x:1303,y:809,t:1527876796241};\\\", \\\"{x:1297,y:808,t:1527876796257};\\\", \\\"{x:1284,y:807,t:1527876796274};\\\", \\\"{x:1270,y:804,t:1527876796291};\\\", \\\"{x:1253,y:802,t:1527876796307};\\\", \\\"{x:1241,y:800,t:1527876796324};\\\", \\\"{x:1239,y:800,t:1527876796341};\\\", \\\"{x:1236,y:800,t:1527876796358};\\\", \\\"{x:1234,y:800,t:1527876796375};\\\", \\\"{x:1233,y:799,t:1527876796391};\\\", \\\"{x:1232,y:796,t:1527876796556};\\\", \\\"{x:1232,y:789,t:1527876796574};\\\", \\\"{x:1236,y:783,t:1527876796591};\\\", \\\"{x:1242,y:776,t:1527876796607};\\\", \\\"{x:1247,y:771,t:1527876796625};\\\", \\\"{x:1253,y:767,t:1527876796641};\\\", \\\"{x:1258,y:763,t:1527876796659};\\\", \\\"{x:1266,y:759,t:1527876796675};\\\", \\\"{x:1277,y:755,t:1527876796692};\\\", \\\"{x:1285,y:753,t:1527876796709};\\\", \\\"{x:1293,y:749,t:1527876796725};\\\", \\\"{x:1300,y:747,t:1527876796742};\\\", \\\"{x:1310,y:747,t:1527876796757};\\\", \\\"{x:1319,y:746,t:1527876796774};\\\", \\\"{x:1330,y:746,t:1527876796791};\\\", \\\"{x:1346,y:746,t:1527876796808};\\\", \\\"{x:1354,y:747,t:1527876796825};\\\", \\\"{x:1359,y:747,t:1527876796841};\\\", \\\"{x:1362,y:747,t:1527876796858};\\\", \\\"{x:1364,y:747,t:1527876796875};\\\", \\\"{x:1365,y:747,t:1527876796891};\\\", \\\"{x:1365,y:748,t:1527876797037};\\\", \\\"{x:1365,y:751,t:1527876797060};\\\", \\\"{x:1365,y:753,t:1527876797075};\\\", \\\"{x:1363,y:756,t:1527876797092};\\\", \\\"{x:1362,y:758,t:1527876797109};\\\", \\\"{x:1361,y:759,t:1527876797125};\\\", \\\"{x:1360,y:759,t:1527876797142};\\\", \\\"{x:1359,y:760,t:1527876797397};\\\", \\\"{x:1358,y:760,t:1527876797409};\\\", \\\"{x:1354,y:761,t:1527876797426};\\\", \\\"{x:1351,y:763,t:1527876797442};\\\", \\\"{x:1348,y:763,t:1527876797459};\\\", \\\"{x:1345,y:764,t:1527876797476};\\\", \\\"{x:1344,y:765,t:1527876797491};\\\", \\\"{x:1343,y:765,t:1527876797509};\\\", \\\"{x:1342,y:765,t:1527876797526};\\\", \\\"{x:1341,y:766,t:1527876797542};\\\", \\\"{x:1341,y:764,t:1527876797781};\\\", \\\"{x:1341,y:763,t:1527876797793};\\\", \\\"{x:1341,y:761,t:1527876797809};\\\", \\\"{x:1341,y:760,t:1527876797826};\\\", \\\"{x:1341,y:758,t:1527876797843};\\\", \\\"{x:1341,y:757,t:1527876797860};\\\", \\\"{x:1342,y:757,t:1527876798252};\\\", \\\"{x:1343,y:757,t:1527876798268};\\\", \\\"{x:1344,y:757,t:1527876798284};\\\", \\\"{x:1345,y:757,t:1527876798356};\\\", \\\"{x:1346,y:757,t:1527876798372};\\\", \\\"{x:1347,y:757,t:1527876798388};\\\", \\\"{x:1348,y:757,t:1527876798412};\\\", \\\"{x:1349,y:757,t:1527876798426};\\\", \\\"{x:1350,y:757,t:1527876798443};\\\", \\\"{x:1351,y:757,t:1527876798467};\\\", \\\"{x:1353,y:757,t:1527876798516};\\\", \\\"{x:1354,y:757,t:1527876798531};\\\", \\\"{x:1355,y:758,t:1527876798542};\\\", \\\"{x:1357,y:758,t:1527876798559};\\\", \\\"{x:1360,y:758,t:1527876798576};\\\", \\\"{x:1361,y:758,t:1527876798595};\\\", \\\"{x:1362,y:758,t:1527876798610};\\\", \\\"{x:1363,y:758,t:1527876798636};\\\", \\\"{x:1365,y:758,t:1527876798652};\\\", \\\"{x:1366,y:758,t:1527876798676};\\\", \\\"{x:1368,y:758,t:1527876798693};\\\", \\\"{x:1370,y:759,t:1527876798709};\\\", \\\"{x:1371,y:759,t:1527876798727};\\\", \\\"{x:1374,y:759,t:1527876798743};\\\", \\\"{x:1375,y:759,t:1527876798763};\\\", \\\"{x:1376,y:759,t:1527876799060};\\\", \\\"{x:1378,y:759,t:1527876799076};\\\", \\\"{x:1381,y:759,t:1527876799094};\\\", \\\"{x:1383,y:759,t:1527876799109};\\\", \\\"{x:1385,y:761,t:1527876799126};\\\", \\\"{x:1389,y:762,t:1527876799143};\\\", \\\"{x:1391,y:762,t:1527876799159};\\\", \\\"{x:1393,y:764,t:1527876799176};\\\", \\\"{x:1394,y:764,t:1527876799203};\\\", \\\"{x:1394,y:765,t:1527876799829};\\\", \\\"{x:1392,y:766,t:1527876799868};\\\", \\\"{x:1390,y:767,t:1527876800084};\\\", \\\"{x:1389,y:767,t:1527876800094};\\\", \\\"{x:1386,y:768,t:1527876800111};\\\", \\\"{x:1383,y:768,t:1527876800128};\\\", \\\"{x:1381,y:769,t:1527876800144};\\\", \\\"{x:1379,y:769,t:1527876800161};\\\", \\\"{x:1377,y:769,t:1527876800178};\\\", \\\"{x:1376,y:769,t:1527876800195};\\\", \\\"{x:1375,y:769,t:1527876800211};\\\", \\\"{x:1369,y:771,t:1527876800876};\\\", \\\"{x:1362,y:772,t:1527876800895};\\\", \\\"{x:1356,y:773,t:1527876800912};\\\", \\\"{x:1350,y:775,t:1527876800928};\\\", \\\"{x:1345,y:775,t:1527876800945};\\\", \\\"{x:1341,y:775,t:1527876800962};\\\", \\\"{x:1337,y:775,t:1527876800978};\\\", \\\"{x:1336,y:776,t:1527876800995};\\\", \\\"{x:1335,y:776,t:1527876801012};\\\", \\\"{x:1335,y:777,t:1527876801365};\\\", \\\"{x:1335,y:780,t:1527876801379};\\\", \\\"{x:1329,y:787,t:1527876801395};\\\", \\\"{x:1320,y:797,t:1527876801412};\\\", \\\"{x:1316,y:803,t:1527876801428};\\\", \\\"{x:1311,y:812,t:1527876801445};\\\", \\\"{x:1305,y:825,t:1527876801462};\\\", \\\"{x:1300,y:838,t:1527876801479};\\\", \\\"{x:1294,y:850,t:1527876801496};\\\", \\\"{x:1291,y:863,t:1527876801512};\\\", \\\"{x:1289,y:870,t:1527876801529};\\\", \\\"{x:1286,y:879,t:1527876801545};\\\", \\\"{x:1286,y:885,t:1527876801562};\\\", \\\"{x:1284,y:895,t:1527876801578};\\\", \\\"{x:1280,y:907,t:1527876801595};\\\", \\\"{x:1271,y:929,t:1527876801611};\\\", \\\"{x:1265,y:942,t:1527876801629};\\\", \\\"{x:1256,y:957,t:1527876801645};\\\", \\\"{x:1251,y:964,t:1527876801662};\\\", \\\"{x:1245,y:972,t:1527876801679};\\\", \\\"{x:1242,y:980,t:1527876801696};\\\", \\\"{x:1240,y:983,t:1527876801712};\\\", \\\"{x:1237,y:986,t:1527876801729};\\\", \\\"{x:1236,y:989,t:1527876801746};\\\", \\\"{x:1233,y:992,t:1527876801762};\\\", \\\"{x:1230,y:995,t:1527876801779};\\\", \\\"{x:1228,y:995,t:1527876801796};\\\", \\\"{x:1227,y:996,t:1527876801820};\\\", \\\"{x:1226,y:995,t:1527876802259};\\\", \\\"{x:1225,y:993,t:1527876802268};\\\", \\\"{x:1224,y:992,t:1527876802278};\\\", \\\"{x:1222,y:990,t:1527876802295};\\\", \\\"{x:1219,y:986,t:1527876802312};\\\", \\\"{x:1217,y:986,t:1527876802330};\\\", \\\"{x:1216,y:985,t:1527876802345};\\\", \\\"{x:1215,y:983,t:1527876802451};\\\", \\\"{x:1215,y:980,t:1527876802463};\\\", \\\"{x:1212,y:975,t:1527876802479};\\\", \\\"{x:1210,y:969,t:1527876802496};\\\", \\\"{x:1209,y:966,t:1527876802513};\\\", \\\"{x:1206,y:962,t:1527876802528};\\\", \\\"{x:1206,y:961,t:1527876802545};\\\", \\\"{x:1205,y:960,t:1527876802563};\\\", \\\"{x:1204,y:958,t:1527876802579};\\\", \\\"{x:1200,y:957,t:1527876802596};\\\", \\\"{x:1197,y:957,t:1527876802613};\\\", \\\"{x:1188,y:956,t:1527876802629};\\\", \\\"{x:1174,y:954,t:1527876802646};\\\", \\\"{x:1152,y:951,t:1527876802663};\\\", \\\"{x:1126,y:945,t:1527876802680};\\\", \\\"{x:1101,y:938,t:1527876802696};\\\", \\\"{x:1074,y:930,t:1527876802713};\\\", \\\"{x:1042,y:921,t:1527876802731};\\\", \\\"{x:1005,y:910,t:1527876802746};\\\", \\\"{x:969,y:901,t:1527876802763};\\\", \\\"{x:919,y:885,t:1527876802780};\\\", \\\"{x:896,y:876,t:1527876802796};\\\", \\\"{x:876,y:867,t:1527876802813};\\\", \\\"{x:855,y:856,t:1527876802829};\\\", \\\"{x:830,y:842,t:1527876802846};\\\", \\\"{x:809,y:827,t:1527876802863};\\\", \\\"{x:786,y:812,t:1527876802880};\\\", \\\"{x:761,y:791,t:1527876802897};\\\", \\\"{x:743,y:772,t:1527876802913};\\\", \\\"{x:730,y:752,t:1527876802931};\\\", \\\"{x:716,y:733,t:1527876802947};\\\", \\\"{x:706,y:714,t:1527876802963};\\\", \\\"{x:693,y:690,t:1527876802979};\\\", \\\"{x:688,y:681,t:1527876802996};\\\", \\\"{x:683,y:674,t:1527876803012};\\\", \\\"{x:681,y:669,t:1527876803029};\\\", \\\"{x:679,y:662,t:1527876803047};\\\", \\\"{x:676,y:655,t:1527876803063};\\\", \\\"{x:673,y:647,t:1527876803080};\\\", \\\"{x:671,y:641,t:1527876803096};\\\", \\\"{x:668,y:636,t:1527876803112};\\\", \\\"{x:663,y:630,t:1527876803130};\\\", \\\"{x:658,y:624,t:1527876803146};\\\", \\\"{x:652,y:620,t:1527876803162};\\\", \\\"{x:648,y:617,t:1527876803178};\\\", \\\"{x:644,y:612,t:1527876803194};\\\", \\\"{x:640,y:604,t:1527876803211};\\\", \\\"{x:639,y:600,t:1527876803229};\\\", \\\"{x:636,y:592,t:1527876803247};\\\", \\\"{x:635,y:586,t:1527876803263};\\\", \\\"{x:633,y:580,t:1527876803279};\\\", \\\"{x:631,y:572,t:1527876803296};\\\", \\\"{x:631,y:568,t:1527876803313};\\\", \\\"{x:631,y:563,t:1527876803330};\\\", \\\"{x:631,y:560,t:1527876803346};\\\", \\\"{x:631,y:558,t:1527876803363};\\\", \\\"{x:631,y:556,t:1527876804628};\\\", \\\"{x:634,y:551,t:1527876804637};\\\", \\\"{x:637,y:549,t:1527876804649};\\\", \\\"{x:642,y:547,t:1527876804665};\\\", \\\"{x:644,y:543,t:1527876804682};\\\", \\\"{x:645,y:541,t:1527876804697};\\\", \\\"{x:646,y:538,t:1527876804714};\\\", \\\"{x:646,y:537,t:1527876804747};\\\", \\\"{x:649,y:537,t:1527876808179};\\\", \\\"{x:663,y:539,t:1527876808188};\\\", \\\"{x:727,y:556,t:1527876808205};\\\", \\\"{x:812,y:575,t:1527876808223};\\\", \\\"{x:900,y:596,t:1527876808238};\\\", \\\"{x:1014,y:618,t:1527876808262};\\\", \\\"{x:1082,y:632,t:1527876808279};\\\", \\\"{x:1167,y:651,t:1527876808294};\\\", \\\"{x:1257,y:670,t:1527876808312};\\\", \\\"{x:1339,y:686,t:1527876808328};\\\", \\\"{x:1399,y:700,t:1527876808344};\\\", \\\"{x:1430,y:710,t:1527876808362};\\\", \\\"{x:1451,y:714,t:1527876808379};\\\", \\\"{x:1462,y:717,t:1527876808395};\\\", \\\"{x:1477,y:724,t:1527876808412};\\\", \\\"{x:1483,y:726,t:1527876808429};\\\", \\\"{x:1485,y:727,t:1527876808444};\\\", \\\"{x:1485,y:728,t:1527876808611};\\\", \\\"{x:1503,y:739,t:1527876808628};\\\", \\\"{x:1529,y:757,t:1527876808644};\\\", \\\"{x:1563,y:775,t:1527876808662};\\\", \\\"{x:1592,y:787,t:1527876808679};\\\", \\\"{x:1610,y:798,t:1527876808694};\\\", \\\"{x:1618,y:803,t:1527876808711};\\\", \\\"{x:1620,y:805,t:1527876808728};\\\", \\\"{x:1617,y:805,t:1527876808843};\\\", \\\"{x:1615,y:805,t:1527876808851};\\\", \\\"{x:1612,y:804,t:1527876808862};\\\", \\\"{x:1606,y:801,t:1527876808877};\\\", \\\"{x:1599,y:799,t:1527876808894};\\\", \\\"{x:1591,y:796,t:1527876808912};\\\", \\\"{x:1585,y:795,t:1527876808928};\\\", \\\"{x:1574,y:792,t:1527876808944};\\\", \\\"{x:1564,y:788,t:1527876808962};\\\", \\\"{x:1554,y:786,t:1527876808978};\\\", \\\"{x:1538,y:781,t:1527876808995};\\\", \\\"{x:1525,y:778,t:1527876809010};\\\", \\\"{x:1524,y:777,t:1527876809027};\\\", \\\"{x:1523,y:777,t:1527876809045};\\\", \\\"{x:1522,y:775,t:1527876809091};\\\", \\\"{x:1519,y:771,t:1527876809099};\\\", \\\"{x:1518,y:767,t:1527876809110};\\\", \\\"{x:1508,y:754,t:1527876809128};\\\", \\\"{x:1499,y:737,t:1527876809145};\\\", \\\"{x:1494,y:725,t:1527876809161};\\\", \\\"{x:1494,y:720,t:1527876809178};\\\", \\\"{x:1491,y:712,t:1527876809194};\\\", \\\"{x:1490,y:707,t:1527876809210};\\\", \\\"{x:1490,y:702,t:1527876809227};\\\", \\\"{x:1490,y:700,t:1527876809245};\\\", \\\"{x:1490,y:699,t:1527876809260};\\\", \\\"{x:1487,y:696,t:1527876809466};\\\", \\\"{x:1487,y:694,t:1527876809477};\\\", \\\"{x:1483,y:689,t:1527876809494};\\\", \\\"{x:1482,y:689,t:1527876809510};\\\", \\\"{x:1480,y:689,t:1527876809546};\\\", \\\"{x:1477,y:689,t:1527876809561};\\\", \\\"{x:1469,y:689,t:1527876809578};\\\", \\\"{x:1446,y:698,t:1527876809595};\\\", \\\"{x:1436,y:702,t:1527876809610};\\\", \\\"{x:1425,y:706,t:1527876809627};\\\", \\\"{x:1419,y:709,t:1527876809643};\\\", \\\"{x:1411,y:715,t:1527876809660};\\\", \\\"{x:1404,y:723,t:1527876809678};\\\", \\\"{x:1398,y:731,t:1527876809693};\\\", \\\"{x:1392,y:741,t:1527876809711};\\\", \\\"{x:1388,y:750,t:1527876809727};\\\", \\\"{x:1380,y:762,t:1527876809744};\\\", \\\"{x:1373,y:773,t:1527876809761};\\\", \\\"{x:1367,y:782,t:1527876809778};\\\", \\\"{x:1360,y:790,t:1527876809794};\\\", \\\"{x:1350,y:805,t:1527876809811};\\\", \\\"{x:1342,y:812,t:1527876809827};\\\", \\\"{x:1331,y:821,t:1527876809843};\\\", \\\"{x:1315,y:830,t:1527876809860};\\\", \\\"{x:1294,y:838,t:1527876809877};\\\", \\\"{x:1271,y:844,t:1527876809894};\\\", \\\"{x:1252,y:848,t:1527876809911};\\\", \\\"{x:1238,y:850,t:1527876809927};\\\", \\\"{x:1224,y:852,t:1527876809944};\\\", \\\"{x:1208,y:854,t:1527876809960};\\\", \\\"{x:1194,y:858,t:1527876809977};\\\", \\\"{x:1180,y:860,t:1527876809994};\\\", \\\"{x:1157,y:864,t:1527876810011};\\\", \\\"{x:1147,y:865,t:1527876810027};\\\", \\\"{x:1141,y:867,t:1527876810044};\\\", \\\"{x:1138,y:867,t:1527876810060};\\\", \\\"{x:1137,y:867,t:1527876810107};\\\", \\\"{x:1134,y:867,t:1527876810114};\\\", \\\"{x:1130,y:867,t:1527876810126};\\\", \\\"{x:1119,y:865,t:1527876810144};\\\", \\\"{x:1106,y:861,t:1527876810161};\\\", \\\"{x:1093,y:852,t:1527876810177};\\\", \\\"{x:1086,y:843,t:1527876810194};\\\", \\\"{x:1082,y:829,t:1527876810211};\\\", \\\"{x:1079,y:815,t:1527876810227};\\\", \\\"{x:1075,y:798,t:1527876810244};\\\", \\\"{x:1072,y:784,t:1527876810260};\\\", \\\"{x:1069,y:773,t:1527876810276};\\\", \\\"{x:1063,y:759,t:1527876810294};\\\", \\\"{x:1062,y:746,t:1527876810311};\\\", \\\"{x:1059,y:732,t:1527876810326};\\\", \\\"{x:1057,y:721,t:1527876810344};\\\", \\\"{x:1057,y:714,t:1527876810361};\\\", \\\"{x:1057,y:710,t:1527876810377};\\\", \\\"{x:1057,y:704,t:1527876810394};\\\", \\\"{x:1057,y:697,t:1527876810411};\\\", \\\"{x:1055,y:691,t:1527876810426};\\\", \\\"{x:1055,y:684,t:1527876810443};\\\", \\\"{x:1055,y:674,t:1527876810460};\\\", \\\"{x:1055,y:662,t:1527876810476};\\\", \\\"{x:1058,y:647,t:1527876810493};\\\", \\\"{x:1062,y:633,t:1527876810510};\\\", \\\"{x:1071,y:615,t:1527876810527};\\\", \\\"{x:1075,y:598,t:1527876810543};\\\", \\\"{x:1080,y:581,t:1527876810559};\\\", \\\"{x:1087,y:559,t:1527876810576};\\\", \\\"{x:1090,y:522,t:1527876810594};\\\", \\\"{x:1097,y:484,t:1527876810609};\\\", \\\"{x:1101,y:446,t:1527876810626};\\\", \\\"{x:1104,y:428,t:1527876810643};\\\", \\\"{x:1105,y:418,t:1527876810659};\\\", \\\"{x:1106,y:412,t:1527876810677};\\\", \\\"{x:1107,y:405,t:1527876810693};\\\", \\\"{x:1108,y:400,t:1527876810709};\\\", \\\"{x:1109,y:398,t:1527876810726};\\\", \\\"{x:1110,y:395,t:1527876810743};\\\", \\\"{x:1111,y:395,t:1527876810819};\\\", \\\"{x:1112,y:398,t:1527876810826};\\\", \\\"{x:1117,y:406,t:1527876810843};\\\", \\\"{x:1120,y:411,t:1527876810859};\\\", \\\"{x:1123,y:414,t:1527876810877};\\\", \\\"{x:1132,y:418,t:1527876810893};\\\", \\\"{x:1141,y:423,t:1527876810910};\\\", \\\"{x:1153,y:428,t:1527876810927};\\\", \\\"{x:1169,y:437,t:1527876810944};\\\", \\\"{x:1183,y:446,t:1527876810960};\\\", \\\"{x:1191,y:451,t:1527876810977};\\\", \\\"{x:1199,y:458,t:1527876810993};\\\", \\\"{x:1206,y:462,t:1527876811010};\\\", \\\"{x:1213,y:465,t:1527876811027};\\\", \\\"{x:1220,y:466,t:1527876811043};\\\", \\\"{x:1226,y:466,t:1527876811060};\\\", \\\"{x:1230,y:466,t:1527876811077};\\\", \\\"{x:1234,y:466,t:1527876811092};\\\", \\\"{x:1238,y:466,t:1527876811109};\\\", \\\"{x:1245,y:466,t:1527876811126};\\\", \\\"{x:1258,y:466,t:1527876811143};\\\", \\\"{x:1269,y:466,t:1527876811160};\\\", \\\"{x:1281,y:466,t:1527876811177};\\\", \\\"{x:1294,y:466,t:1527876811192};\\\", \\\"{x:1309,y:469,t:1527876811210};\\\", \\\"{x:1340,y:474,t:1527876811227};\\\", \\\"{x:1363,y:475,t:1527876811243};\\\", \\\"{x:1387,y:475,t:1527876811259};\\\", \\\"{x:1405,y:475,t:1527876811276};\\\", \\\"{x:1420,y:477,t:1527876811292};\\\", \\\"{x:1435,y:481,t:1527876811309};\\\", \\\"{x:1446,y:486,t:1527876811327};\\\", \\\"{x:1456,y:492,t:1527876811342};\\\", \\\"{x:1465,y:499,t:1527876811359};\\\", \\\"{x:1473,y:505,t:1527876811376};\\\", \\\"{x:1476,y:507,t:1527876811393};\\\", \\\"{x:1478,y:508,t:1527876811409};\\\", \\\"{x:1480,y:508,t:1527876811563};\\\", \\\"{x:1482,y:508,t:1527876811576};\\\", \\\"{x:1484,y:508,t:1527876811592};\\\", \\\"{x:1485,y:507,t:1527876811610};\\\", \\\"{x:1491,y:506,t:1527876811625};\\\", \\\"{x:1514,y:503,t:1527876811642};\\\", \\\"{x:1541,y:501,t:1527876811660};\\\", \\\"{x:1567,y:501,t:1527876811675};\\\", \\\"{x:1588,y:501,t:1527876811693};\\\", \\\"{x:1601,y:501,t:1527876811710};\\\", \\\"{x:1607,y:501,t:1527876811725};\\\", \\\"{x:1608,y:501,t:1527876811747};\\\", \\\"{x:1607,y:501,t:1527876811887};\\\", \\\"{x:1601,y:501,t:1527876811897};\\\", \\\"{x:1583,y:508,t:1527876811913};\\\", \\\"{x:1558,y:515,t:1527876811930};\\\", \\\"{x:1519,y:521,t:1527876811948};\\\", \\\"{x:1471,y:529,t:1527876811963};\\\", \\\"{x:1425,y:530,t:1527876811980};\\\", \\\"{x:1401,y:530,t:1527876811997};\\\", \\\"{x:1387,y:530,t:1527876812014};\\\", \\\"{x:1380,y:530,t:1527876812030};\\\", \\\"{x:1383,y:530,t:1527876812207};\\\", \\\"{x:1389,y:527,t:1527876812214};\\\", \\\"{x:1394,y:524,t:1527876812230};\\\", \\\"{x:1407,y:517,t:1527876812247};\\\", \\\"{x:1415,y:511,t:1527876812263};\\\", \\\"{x:1420,y:507,t:1527876812280};\\\", \\\"{x:1423,y:502,t:1527876812297};\\\", \\\"{x:1424,y:500,t:1527876812313};\\\", \\\"{x:1427,y:495,t:1527876812330};\\\", \\\"{x:1428,y:494,t:1527876812346};\\\", \\\"{x:1430,y:492,t:1527876812362};\\\", \\\"{x:1430,y:494,t:1527876812495};\\\", \\\"{x:1430,y:496,t:1527876812511};\\\", \\\"{x:1429,y:497,t:1527876812519};\\\", \\\"{x:1426,y:499,t:1527876812530};\\\", \\\"{x:1423,y:503,t:1527876812546};\\\", \\\"{x:1421,y:507,t:1527876812563};\\\", \\\"{x:1421,y:508,t:1527876812580};\\\", \\\"{x:1420,y:508,t:1527876812624};\\\", \\\"{x:1419,y:509,t:1527876812639};\\\", \\\"{x:1419,y:510,t:1527876812655};\\\", \\\"{x:1419,y:511,t:1527876812664};\\\", \\\"{x:1418,y:513,t:1527876812679};\\\", \\\"{x:1418,y:514,t:1527876812695};\\\", \\\"{x:1417,y:516,t:1527876812714};\\\", \\\"{x:1416,y:518,t:1527876812730};\\\", \\\"{x:1416,y:521,t:1527876812746};\\\", \\\"{x:1415,y:525,t:1527876812763};\\\", \\\"{x:1413,y:531,t:1527876812780};\\\", \\\"{x:1412,y:538,t:1527876812796};\\\", \\\"{x:1410,y:543,t:1527876812813};\\\", \\\"{x:1409,y:549,t:1527876812829};\\\", \\\"{x:1408,y:554,t:1527876812846};\\\", \\\"{x:1406,y:560,t:1527876812863};\\\", \\\"{x:1406,y:564,t:1527876812879};\\\", \\\"{x:1405,y:570,t:1527876812896};\\\", \\\"{x:1404,y:576,t:1527876812913};\\\", \\\"{x:1403,y:583,t:1527876812929};\\\", \\\"{x:1402,y:592,t:1527876812946};\\\", \\\"{x:1401,y:595,t:1527876812963};\\\", \\\"{x:1401,y:599,t:1527876812979};\\\", \\\"{x:1401,y:603,t:1527876812996};\\\", \\\"{x:1401,y:608,t:1527876813013};\\\", \\\"{x:1401,y:612,t:1527876813029};\\\", \\\"{x:1401,y:615,t:1527876813046};\\\", \\\"{x:1401,y:618,t:1527876813063};\\\", \\\"{x:1401,y:620,t:1527876813103};\\\", \\\"{x:1401,y:621,t:1527876813152};\\\", \\\"{x:1401,y:623,t:1527876813175};\\\", \\\"{x:1401,y:624,t:1527876813191};\\\", \\\"{x:1401,y:626,t:1527876813207};\\\", \\\"{x:1401,y:627,t:1527876813223};\\\", \\\"{x:1401,y:629,t:1527876813239};\\\", \\\"{x:1401,y:631,t:1527876813255};\\\", \\\"{x:1401,y:632,t:1527876813263};\\\", \\\"{x:1401,y:636,t:1527876813279};\\\", \\\"{x:1401,y:637,t:1527876813296};\\\", \\\"{x:1401,y:641,t:1527876813312};\\\", \\\"{x:1401,y:644,t:1527876813329};\\\", \\\"{x:1401,y:648,t:1527876813346};\\\", \\\"{x:1401,y:651,t:1527876813361};\\\", \\\"{x:1401,y:652,t:1527876813383};\\\", \\\"{x:1401,y:653,t:1527876813396};\\\", \\\"{x:1401,y:654,t:1527876813412};\\\", \\\"{x:1401,y:656,t:1527876813429};\\\", \\\"{x:1401,y:657,t:1527876813446};\\\", \\\"{x:1401,y:658,t:1527876813462};\\\", \\\"{x:1401,y:661,t:1527876813479};\\\", \\\"{x:1401,y:663,t:1527876813496};\\\", \\\"{x:1401,y:666,t:1527876813512};\\\", \\\"{x:1401,y:668,t:1527876813529};\\\", \\\"{x:1401,y:672,t:1527876813546};\\\", \\\"{x:1401,y:675,t:1527876813562};\\\", \\\"{x:1401,y:679,t:1527876813579};\\\", \\\"{x:1401,y:681,t:1527876813596};\\\", \\\"{x:1401,y:685,t:1527876813612};\\\", \\\"{x:1401,y:687,t:1527876813629};\\\", \\\"{x:1401,y:689,t:1527876813646};\\\", \\\"{x:1401,y:690,t:1527876813662};\\\", \\\"{x:1400,y:691,t:1527876813679};\\\", \\\"{x:1400,y:692,t:1527876813695};\\\", \\\"{x:1400,y:693,t:1527876814031};\\\", \\\"{x:1400,y:695,t:1527876814045};\\\", \\\"{x:1400,y:699,t:1527876814062};\\\", \\\"{x:1400,y:706,t:1527876814079};\\\", \\\"{x:1400,y:707,t:1527876814095};\\\", \\\"{x:1400,y:710,t:1527876814112};\\\", \\\"{x:1400,y:714,t:1527876814128};\\\", \\\"{x:1400,y:720,t:1527876814145};\\\", \\\"{x:1400,y:725,t:1527876814162};\\\", \\\"{x:1400,y:729,t:1527876814179};\\\", \\\"{x:1400,y:734,t:1527876814195};\\\", \\\"{x:1400,y:738,t:1527876814213};\\\", \\\"{x:1400,y:741,t:1527876814228};\\\", \\\"{x:1400,y:745,t:1527876814245};\\\", \\\"{x:1399,y:748,t:1527876814262};\\\", \\\"{x:1399,y:753,t:1527876814278};\\\", \\\"{x:1399,y:762,t:1527876814295};\\\", \\\"{x:1397,y:769,t:1527876814311};\\\", \\\"{x:1395,y:780,t:1527876814328};\\\", \\\"{x:1391,y:793,t:1527876814345};\\\", \\\"{x:1388,y:806,t:1527876814362};\\\", \\\"{x:1386,y:812,t:1527876814379};\\\", \\\"{x:1385,y:815,t:1527876814395};\\\", \\\"{x:1385,y:816,t:1527876814412};\\\", \\\"{x:1384,y:818,t:1527876814511};\\\", \\\"{x:1382,y:820,t:1527876814528};\\\", \\\"{x:1376,y:824,t:1527876814545};\\\", \\\"{x:1364,y:834,t:1527876814562};\\\", \\\"{x:1334,y:846,t:1527876814578};\\\", \\\"{x:1288,y:861,t:1527876814595};\\\", \\\"{x:1252,y:872,t:1527876814612};\\\", \\\"{x:1228,y:874,t:1527876814629};\\\", \\\"{x:1203,y:874,t:1527876814646};\\\", \\\"{x:1150,y:870,t:1527876814661};\\\", \\\"{x:1037,y:842,t:1527876814678};\\\", \\\"{x:773,y:835,t:1527876814695};\\\", \\\"{x:579,y:841,t:1527876814711};\\\", \\\"{x:433,y:841,t:1527876814728};\\\", \\\"{x:394,y:833,t:1527876814745};\\\", \\\"{x:394,y:832,t:1527876814799};\\\", \\\"{x:393,y:831,t:1527876814811};\\\", \\\"{x:390,y:821,t:1527876814828};\\\", \\\"{x:385,y:798,t:1527876814844};\\\", \\\"{x:378,y:777,t:1527876814861};\\\", \\\"{x:372,y:756,t:1527876814878};\\\", \\\"{x:363,y:728,t:1527876814895};\\\", \\\"{x:353,y:713,t:1527876814911};\\\", \\\"{x:344,y:697,t:1527876814928};\\\", \\\"{x:334,y:683,t:1527876814945};\\\", \\\"{x:318,y:665,t:1527876814961};\\\", \\\"{x:300,y:651,t:1527876814978};\\\", \\\"{x:290,y:646,t:1527876814988};\\\", \\\"{x:275,y:639,t:1527876815004};\\\", \\\"{x:266,y:635,t:1527876815021};\\\", \\\"{x:261,y:634,t:1527876815038};\\\", \\\"{x:257,y:634,t:1527876815060};\\\", \\\"{x:253,y:634,t:1527876815077};\\\", \\\"{x:245,y:634,t:1527876815092};\\\", \\\"{x:235,y:632,t:1527876815110};\\\", \\\"{x:219,y:627,t:1527876815128};\\\", \\\"{x:197,y:621,t:1527876815143};\\\", \\\"{x:159,y:610,t:1527876815160};\\\", \\\"{x:126,y:598,t:1527876815178};\\\", \\\"{x:86,y:583,t:1527876815193};\\\", \\\"{x:46,y:572,t:1527876815211};\\\", \\\"{x:31,y:567,t:1527876815227};\\\", \\\"{x:22,y:567,t:1527876815243};\\\", \\\"{x:18,y:567,t:1527876815260};\\\", \\\"{x:15,y:567,t:1527876815277};\\\", \\\"{x:13,y:568,t:1527876815293};\\\", \\\"{x:12,y:568,t:1527876815310};\\\", \\\"{x:8,y:571,t:1527876815327};\\\", \\\"{x:3,y:574,t:1527876815343};\\\", \\\"{x:1,y:579,t:1527876815360};\\\", \\\"{x:1,y:585,t:1527876815376};\\\", \\\"{x:4,y:596,t:1527876815393};\\\", \\\"{x:8,y:605,t:1527876815410};\\\", \\\"{x:11,y:612,t:1527876815427};\\\", \\\"{x:14,y:618,t:1527876815443};\\\", \\\"{x:19,y:627,t:1527876815460};\\\", \\\"{x:21,y:633,t:1527876815477};\\\", \\\"{x:27,y:640,t:1527876815493};\\\", \\\"{x:32,y:644,t:1527876815510};\\\", \\\"{x:39,y:646,t:1527876815527};\\\", \\\"{x:45,y:646,t:1527876815544};\\\", \\\"{x:55,y:646,t:1527876815561};\\\", \\\"{x:71,y:646,t:1527876815577};\\\", \\\"{x:89,y:641,t:1527876815593};\\\", \\\"{x:101,y:637,t:1527876815610};\\\", \\\"{x:112,y:632,t:1527876815627};\\\", \\\"{x:121,y:629,t:1527876815644};\\\", \\\"{x:125,y:628,t:1527876815660};\\\", \\\"{x:129,y:627,t:1527876815677};\\\", \\\"{x:135,y:627,t:1527876815694};\\\", \\\"{x:139,y:626,t:1527876815710};\\\", \\\"{x:146,y:624,t:1527876815727};\\\", \\\"{x:152,y:622,t:1527876815744};\\\", \\\"{x:156,y:622,t:1527876815760};\\\", \\\"{x:164,y:619,t:1527876815777};\\\", \\\"{x:174,y:618,t:1527876815794};\\\", \\\"{x:187,y:618,t:1527876815810};\\\", \\\"{x:204,y:617,t:1527876815827};\\\", \\\"{x:232,y:613,t:1527876815844};\\\", \\\"{x:265,y:608,t:1527876815860};\\\", \\\"{x:302,y:602,t:1527876815878};\\\", \\\"{x:328,y:600,t:1527876815895};\\\", \\\"{x:346,y:597,t:1527876815910};\\\", \\\"{x:366,y:597,t:1527876815927};\\\", \\\"{x:376,y:596,t:1527876815944};\\\", \\\"{x:383,y:595,t:1527876815960};\\\", \\\"{x:389,y:594,t:1527876815977};\\\", \\\"{x:395,y:593,t:1527876815995};\\\", \\\"{x:401,y:592,t:1527876816011};\\\", \\\"{x:405,y:590,t:1527876816027};\\\", \\\"{x:409,y:588,t:1527876816045};\\\", \\\"{x:412,y:587,t:1527876816060};\\\", \\\"{x:414,y:587,t:1527876816077};\\\", \\\"{x:416,y:585,t:1527876816094};\\\", \\\"{x:415,y:585,t:1527876816279};\\\", \\\"{x:414,y:585,t:1527876816471};\\\", \\\"{x:413,y:584,t:1527876816478};\\\", \\\"{x:411,y:584,t:1527876816494};\\\", \\\"{x:406,y:584,t:1527876816511};\\\", \\\"{x:402,y:586,t:1527876817079};\\\", \\\"{x:397,y:599,t:1527876817095};\\\", \\\"{x:392,y:609,t:1527876817111};\\\", \\\"{x:390,y:615,t:1527876817128};\\\", \\\"{x:389,y:619,t:1527876817144};\\\", \\\"{x:388,y:624,t:1527876817161};\\\", \\\"{x:388,y:626,t:1527876817178};\\\", \\\"{x:388,y:627,t:1527876817247};\\\", \\\"{x:392,y:627,t:1527876817263};\\\", \\\"{x:400,y:627,t:1527876817279};\\\", \\\"{x:433,y:624,t:1527876817294};\\\", \\\"{x:511,y:618,t:1527876817311};\\\", \\\"{x:564,y:618,t:1527876817328};\\\", \\\"{x:614,y:618,t:1527876817346};\\\", \\\"{x:642,y:617,t:1527876817362};\\\", \\\"{x:656,y:617,t:1527876817378};\\\", \\\"{x:661,y:617,t:1527876817395};\\\", \\\"{x:663,y:616,t:1527876817412};\\\", \\\"{x:663,y:614,t:1527876817504};\\\", \\\"{x:661,y:613,t:1527876817512};\\\", \\\"{x:659,y:611,t:1527876817528};\\\", \\\"{x:658,y:608,t:1527876817545};\\\", \\\"{x:657,y:607,t:1527876817562};\\\", \\\"{x:655,y:606,t:1527876817578};\\\", \\\"{x:649,y:603,t:1527876817595};\\\", \\\"{x:641,y:600,t:1527876817612};\\\", \\\"{x:624,y:595,t:1527876817628};\\\", \\\"{x:595,y:593,t:1527876817645};\\\", \\\"{x:557,y:590,t:1527876817662};\\\", \\\"{x:499,y:586,t:1527876817678};\\\", \\\"{x:388,y:586,t:1527876817695};\\\", \\\"{x:324,y:586,t:1527876817712};\\\", \\\"{x:283,y:583,t:1527876817729};\\\", \\\"{x:260,y:581,t:1527876817745};\\\", \\\"{x:243,y:580,t:1527876817762};\\\", \\\"{x:231,y:577,t:1527876817779};\\\", \\\"{x:229,y:577,t:1527876817795};\\\", \\\"{x:229,y:580,t:1527876817812};\\\", \\\"{x:229,y:581,t:1527876817895};\\\", \\\"{x:229,y:583,t:1527876817912};\\\", \\\"{x:227,y:586,t:1527876817929};\\\", \\\"{x:222,y:590,t:1527876817945};\\\", \\\"{x:219,y:592,t:1527876817962};\\\", \\\"{x:217,y:594,t:1527876817979};\\\", \\\"{x:216,y:595,t:1527876817995};\\\", \\\"{x:211,y:599,t:1527876818012};\\\", \\\"{x:207,y:602,t:1527876818030};\\\", \\\"{x:204,y:609,t:1527876818045};\\\", \\\"{x:200,y:616,t:1527876818062};\\\", \\\"{x:199,y:621,t:1527876818078};\\\", \\\"{x:199,y:622,t:1527876818119};\\\", \\\"{x:201,y:624,t:1527876818135};\\\", \\\"{x:201,y:625,t:1527876818146};\\\", \\\"{x:208,y:625,t:1527876818162};\\\", \\\"{x:218,y:625,t:1527876818179};\\\", \\\"{x:230,y:625,t:1527876818196};\\\", \\\"{x:257,y:615,t:1527876818212};\\\", \\\"{x:295,y:601,t:1527876818229};\\\", \\\"{x:322,y:589,t:1527876818247};\\\", \\\"{x:336,y:585,t:1527876818262};\\\", \\\"{x:348,y:584,t:1527876818279};\\\", \\\"{x:356,y:584,t:1527876818296};\\\", \\\"{x:360,y:584,t:1527876818312};\\\", \\\"{x:361,y:584,t:1527876818329};\\\", \\\"{x:362,y:584,t:1527876818346};\\\", \\\"{x:363,y:584,t:1527876818463};\\\", \\\"{x:364,y:584,t:1527876818479};\\\", \\\"{x:370,y:584,t:1527876818496};\\\", \\\"{x:377,y:582,t:1527876818512};\\\", \\\"{x:390,y:576,t:1527876818529};\\\", \\\"{x:401,y:570,t:1527876818546};\\\", \\\"{x:415,y:562,t:1527876818562};\\\", \\\"{x:420,y:557,t:1527876818579};\\\", \\\"{x:421,y:555,t:1527876818597};\\\", \\\"{x:422,y:551,t:1527876818613};\\\", \\\"{x:423,y:550,t:1527876818629};\\\", \\\"{x:423,y:549,t:1527876818647};\\\", \\\"{x:423,y:548,t:1527876818775};\\\", \\\"{x:423,y:547,t:1527876818782};\\\", \\\"{x:422,y:547,t:1527876818796};\\\", \\\"{x:419,y:545,t:1527876818813};\\\", \\\"{x:416,y:543,t:1527876818830};\\\", \\\"{x:413,y:542,t:1527876818846};\\\", \\\"{x:412,y:542,t:1527876818863};\\\", \\\"{x:412,y:542,t:1527876819776};\\\", \\\"{x:410,y:542,t:1527876820071};\\\", \\\"{x:407,y:547,t:1527876820081};\\\", \\\"{x:401,y:563,t:1527876820099};\\\", \\\"{x:397,y:576,t:1527876820114};\\\", \\\"{x:393,y:589,t:1527876820130};\\\", \\\"{x:392,y:597,t:1527876820147};\\\", \\\"{x:391,y:602,t:1527876820164};\\\", \\\"{x:390,y:603,t:1527876820181};\\\", \\\"{x:388,y:605,t:1527876820197};\\\", \\\"{x:386,y:608,t:1527876820214};\\\", \\\"{x:382,y:612,t:1527876820230};\\\", \\\"{x:368,y:619,t:1527876820247};\\\", \\\"{x:351,y:623,t:1527876820264};\\\", \\\"{x:327,y:625,t:1527876820280};\\\", \\\"{x:304,y:625,t:1527876820297};\\\", \\\"{x:276,y:625,t:1527876820314};\\\", \\\"{x:251,y:625,t:1527876820332};\\\", \\\"{x:240,y:625,t:1527876820347};\\\", \\\"{x:239,y:625,t:1527876820364};\\\", \\\"{x:238,y:625,t:1527876820407};\\\", \\\"{x:237,y:624,t:1527876820415};\\\", \\\"{x:229,y:619,t:1527876820431};\\\", \\\"{x:219,y:612,t:1527876820447};\\\", \\\"{x:211,y:606,t:1527876820464};\\\", \\\"{x:205,y:600,t:1527876820482};\\\", \\\"{x:198,y:592,t:1527876820498};\\\", \\\"{x:194,y:588,t:1527876820514};\\\", \\\"{x:191,y:583,t:1527876820532};\\\", \\\"{x:190,y:580,t:1527876820547};\\\", \\\"{x:188,y:578,t:1527876820564};\\\", \\\"{x:187,y:577,t:1527876820581};\\\", \\\"{x:188,y:577,t:1527876821199};\\\", \\\"{x:196,y:577,t:1527876821215};\\\", \\\"{x:202,y:579,t:1527876821231};\\\", \\\"{x:207,y:581,t:1527876821248};\\\", \\\"{x:211,y:582,t:1527876821265};\\\", \\\"{x:215,y:584,t:1527876821281};\\\", \\\"{x:222,y:585,t:1527876821298};\\\", \\\"{x:227,y:587,t:1527876821315};\\\", \\\"{x:231,y:588,t:1527876821331};\\\", \\\"{x:238,y:590,t:1527876821348};\\\", \\\"{x:247,y:592,t:1527876821365};\\\", \\\"{x:254,y:594,t:1527876821382};\\\", \\\"{x:261,y:597,t:1527876821398};\\\", \\\"{x:270,y:598,t:1527876821415};\\\", \\\"{x:274,y:599,t:1527876821431};\\\", \\\"{x:276,y:600,t:1527876821448};\\\", \\\"{x:278,y:600,t:1527876821465};\\\", \\\"{x:281,y:601,t:1527876821481};\\\", \\\"{x:285,y:601,t:1527876821498};\\\", \\\"{x:287,y:602,t:1527876821516};\\\", \\\"{x:289,y:602,t:1527876821532};\\\", \\\"{x:290,y:602,t:1527876821548};\\\", \\\"{x:292,y:602,t:1527876821565};\\\", \\\"{x:294,y:602,t:1527876821582};\\\", \\\"{x:295,y:602,t:1527876821599};\\\", \\\"{x:298,y:602,t:1527876821615};\\\", \\\"{x:301,y:603,t:1527876821633};\\\", \\\"{x:305,y:603,t:1527876821648};\\\", \\\"{x:311,y:603,t:1527876821665};\\\", \\\"{x:315,y:603,t:1527876821682};\\\", \\\"{x:318,y:603,t:1527876821698};\\\", \\\"{x:319,y:603,t:1527876821715};\\\", \\\"{x:321,y:603,t:1527876821735};\\\", \\\"{x:322,y:604,t:1527876821748};\\\", \\\"{x:324,y:604,t:1527876821767};\\\", \\\"{x:326,y:605,t:1527876821782};\\\", \\\"{x:330,y:605,t:1527876821798};\\\", \\\"{x:342,y:609,t:1527876821815};\\\", \\\"{x:348,y:611,t:1527876821832};\\\", \\\"{x:352,y:612,t:1527876821848};\\\", \\\"{x:356,y:612,t:1527876821866};\\\", \\\"{x:364,y:612,t:1527876821883};\\\", \\\"{x:379,y:612,t:1527876821899};\\\", \\\"{x:393,y:611,t:1527876821915};\\\", \\\"{x:411,y:609,t:1527876821932};\\\", \\\"{x:428,y:606,t:1527876821948};\\\", \\\"{x:447,y:603,t:1527876821965};\\\", \\\"{x:470,y:600,t:1527876821982};\\\", \\\"{x:486,y:598,t:1527876821998};\\\", \\\"{x:503,y:598,t:1527876822015};\\\", \\\"{x:513,y:598,t:1527876822032};\\\", \\\"{x:522,y:598,t:1527876822048};\\\", \\\"{x:535,y:598,t:1527876822065};\\\", \\\"{x:545,y:598,t:1527876822082};\\\", \\\"{x:558,y:598,t:1527876822099};\\\", \\\"{x:573,y:595,t:1527876822115};\\\", \\\"{x:584,y:594,t:1527876822133};\\\", \\\"{x:590,y:593,t:1527876822150};\\\", \\\"{x:598,y:591,t:1527876822165};\\\", \\\"{x:606,y:590,t:1527876822182};\\\", \\\"{x:612,y:590,t:1527876822199};\\\", \\\"{x:617,y:589,t:1527876822216};\\\", \\\"{x:624,y:587,t:1527876822232};\\\", \\\"{x:633,y:585,t:1527876822250};\\\", \\\"{x:641,y:583,t:1527876822265};\\\", \\\"{x:644,y:582,t:1527876822283};\\\", \\\"{x:646,y:582,t:1527876822299};\\\", \\\"{x:647,y:581,t:1527876822399};\\\", \\\"{x:647,y:579,t:1527876822415};\\\", \\\"{x:647,y:578,t:1527876823103};\\\", \\\"{x:646,y:577,t:1527876823116};\\\", \\\"{x:641,y:574,t:1527876823133};\\\", \\\"{x:638,y:572,t:1527876823149};\\\", \\\"{x:633,y:570,t:1527876823166};\\\", \\\"{x:618,y:562,t:1527876823183};\\\", \\\"{x:612,y:559,t:1527876823200};\\\", \\\"{x:610,y:557,t:1527876823217};\\\", \\\"{x:609,y:556,t:1527876823233};\\\", \\\"{x:609,y:559,t:1527876823583};\\\", \\\"{x:610,y:563,t:1527876823600};\\\", \\\"{x:610,y:568,t:1527876823617};\\\", \\\"{x:610,y:571,t:1527876823633};\\\", \\\"{x:610,y:573,t:1527876823650};\\\", \\\"{x:610,y:574,t:1527876823666};\\\", \\\"{x:610,y:576,t:1527876823703};\\\", \\\"{x:611,y:577,t:1527876823718};\\\", \\\"{x:612,y:578,t:1527876823791};\\\", \\\"{x:615,y:578,t:1527876823999};\\\", \\\"{x:619,y:577,t:1527876824007};\\\", \\\"{x:623,y:576,t:1527876824017};\\\", \\\"{x:630,y:575,t:1527876824033};\\\", \\\"{x:640,y:574,t:1527876824050};\\\", \\\"{x:659,y:569,t:1527876824068};\\\", \\\"{x:690,y:559,t:1527876824084};\\\", \\\"{x:739,y:550,t:1527876824101};\\\", \\\"{x:777,y:546,t:1527876824118};\\\", \\\"{x:806,y:546,t:1527876824133};\\\", \\\"{x:827,y:546,t:1527876824150};\\\", \\\"{x:840,y:546,t:1527876824166};\\\", \\\"{x:840,y:545,t:1527876824287};\\\", \\\"{x:839,y:545,t:1527876824300};\\\", \\\"{x:837,y:545,t:1527876824317};\\\", \\\"{x:836,y:544,t:1527876824334};\\\", \\\"{x:833,y:542,t:1527876824350};\\\", \\\"{x:830,y:542,t:1527876824535};\\\", \\\"{x:830,y:547,t:1527876824551};\\\", \\\"{x:829,y:554,t:1527876824567};\\\", \\\"{x:828,y:563,t:1527876824584};\\\", \\\"{x:826,y:573,t:1527876824601};\\\", \\\"{x:826,y:583,t:1527876824617};\\\", \\\"{x:826,y:588,t:1527876824634};\\\", \\\"{x:826,y:589,t:1527876824651};\\\", \\\"{x:827,y:587,t:1527876824830};\\\", \\\"{x:827,y:585,t:1527876824839};\\\", \\\"{x:828,y:582,t:1527876824851};\\\", \\\"{x:829,y:580,t:1527876824867};\\\", \\\"{x:829,y:579,t:1527876824885};\\\", \\\"{x:828,y:579,t:1527876825567};\\\", \\\"{x:827,y:579,t:1527876825582};\\\", \\\"{x:826,y:579,t:1527876825606};\\\", \\\"{x:824,y:580,t:1527876825618};\\\", \\\"{x:823,y:581,t:1527876825636};\\\", \\\"{x:818,y:583,t:1527876825651};\\\", \\\"{x:804,y:588,t:1527876825668};\\\", \\\"{x:780,y:592,t:1527876825685};\\\", \\\"{x:756,y:596,t:1527876825702};\\\", \\\"{x:727,y:596,t:1527876825718};\\\", \\\"{x:663,y:596,t:1527876825734};\\\", \\\"{x:628,y:596,t:1527876825751};\\\", \\\"{x:598,y:591,t:1527876825768};\\\", \\\"{x:569,y:585,t:1527876825785};\\\", \\\"{x:545,y:584,t:1527876825801};\\\", \\\"{x:532,y:584,t:1527876825818};\\\", \\\"{x:527,y:584,t:1527876825835};\\\", \\\"{x:524,y:583,t:1527876825851};\\\", \\\"{x:519,y:582,t:1527876825868};\\\", \\\"{x:515,y:581,t:1527876825885};\\\", \\\"{x:511,y:579,t:1527876825902};\\\", \\\"{x:507,y:577,t:1527876825918};\\\", \\\"{x:499,y:575,t:1527876825935};\\\", \\\"{x:493,y:572,t:1527876825951};\\\", \\\"{x:482,y:568,t:1527876825968};\\\", \\\"{x:471,y:566,t:1527876825985};\\\", \\\"{x:459,y:562,t:1527876826003};\\\", \\\"{x:444,y:558,t:1527876826018};\\\", \\\"{x:428,y:557,t:1527876826035};\\\", \\\"{x:413,y:557,t:1527876826053};\\\", \\\"{x:398,y:557,t:1527876826068};\\\", \\\"{x:385,y:558,t:1527876826085};\\\", \\\"{x:375,y:559,t:1527876826102};\\\", \\\"{x:373,y:560,t:1527876826118};\\\", \\\"{x:371,y:561,t:1527876826135};\\\", \\\"{x:369,y:562,t:1527876826152};\\\", \\\"{x:368,y:563,t:1527876826169};\\\", \\\"{x:366,y:563,t:1527876826186};\\\", \\\"{x:362,y:567,t:1527876826202};\\\", \\\"{x:358,y:571,t:1527876826219};\\\", \\\"{x:351,y:577,t:1527876826236};\\\", \\\"{x:345,y:579,t:1527876826252};\\\", \\\"{x:339,y:582,t:1527876826268};\\\", \\\"{x:326,y:584,t:1527876826285};\\\", \\\"{x:301,y:587,t:1527876826302};\\\", \\\"{x:279,y:588,t:1527876826318};\\\", \\\"{x:246,y:588,t:1527876826335};\\\", \\\"{x:222,y:588,t:1527876826352};\\\", \\\"{x:202,y:588,t:1527876826368};\\\", \\\"{x:187,y:589,t:1527876826386};\\\", \\\"{x:179,y:591,t:1527876826402};\\\", \\\"{x:175,y:592,t:1527876826419};\\\", \\\"{x:172,y:592,t:1527876826435};\\\", \\\"{x:171,y:592,t:1527876826452};\\\", \\\"{x:172,y:592,t:1527876826646};\\\", \\\"{x:182,y:592,t:1527876826655};\\\", \\\"{x:197,y:592,t:1527876826669};\\\", \\\"{x:220,y:590,t:1527876826685};\\\", \\\"{x:259,y:589,t:1527876826702};\\\", \\\"{x:324,y:589,t:1527876826719};\\\", \\\"{x:363,y:589,t:1527876826735};\\\", \\\"{x:414,y:587,t:1527876826753};\\\", \\\"{x:464,y:580,t:1527876826770};\\\", \\\"{x:504,y:573,t:1527876826787};\\\", \\\"{x:526,y:565,t:1527876826802};\\\", \\\"{x:537,y:560,t:1527876826820};\\\", \\\"{x:547,y:555,t:1527876826836};\\\", \\\"{x:548,y:555,t:1527876826852};\\\", \\\"{x:549,y:554,t:1527876826879};\\\", \\\"{x:551,y:551,t:1527876826895};\\\", \\\"{x:553,y:549,t:1527876826903};\\\", \\\"{x:553,y:547,t:1527876826918};\\\", \\\"{x:554,y:545,t:1527876826936};\\\", \\\"{x:555,y:543,t:1527876826953};\\\", \\\"{x:555,y:542,t:1527876826969};\\\", \\\"{x:556,y:540,t:1527876826985};\\\", \\\"{x:556,y:539,t:1527876827003};\\\", \\\"{x:556,y:538,t:1527876827019};\\\", \\\"{x:556,y:539,t:1527876827143};\\\", \\\"{x:557,y:544,t:1527876827152};\\\", \\\"{x:559,y:553,t:1527876827169};\\\", \\\"{x:561,y:565,t:1527876827186};\\\", \\\"{x:563,y:579,t:1527876827202};\\\", \\\"{x:566,y:591,t:1527876827219};\\\", \\\"{x:567,y:605,t:1527876827237};\\\", \\\"{x:567,y:613,t:1527876827254};\\\", \\\"{x:567,y:623,t:1527876827269};\\\", \\\"{x:567,y:641,t:1527876827287};\\\", \\\"{x:566,y:647,t:1527876827302};\\\", \\\"{x:560,y:660,t:1527876827319};\\\", \\\"{x:552,y:670,t:1527876827336};\\\", \\\"{x:546,y:677,t:1527876827354};\\\", \\\"{x:536,y:684,t:1527876827369};\\\", \\\"{x:531,y:686,t:1527876827386};\\\", \\\"{x:530,y:686,t:1527876827403};\\\", \\\"{x:535,y:685,t:1527876827462};\\\", \\\"{x:542,y:679,t:1527876827470};\\\", \\\"{x:557,y:669,t:1527876827486};\\\", \\\"{x:575,y:656,t:1527876827502};\\\", \\\"{x:596,y:637,t:1527876827519};\\\", \\\"{x:616,y:614,t:1527876827536};\\\", \\\"{x:624,y:601,t:1527876827554};\\\", \\\"{x:626,y:595,t:1527876827570};\\\", \\\"{x:627,y:593,t:1527876827587};\\\", \\\"{x:627,y:594,t:1527876827767};\\\", \\\"{x:627,y:595,t:1527876827774};\\\", \\\"{x:626,y:600,t:1527876827786};\\\", \\\"{x:625,y:601,t:1527876827804};\\\", \\\"{x:625,y:602,t:1527876827820};\\\", \\\"{x:625,y:603,t:1527876827863};\\\", \\\"{x:624,y:604,t:1527876827879};\\\", \\\"{x:624,y:605,t:1527876827886};\\\", \\\"{x:623,y:606,t:1527876827904};\\\", \\\"{x:623,y:609,t:1527876827921};\\\", \\\"{x:621,y:612,t:1527876827936};\\\", \\\"{x:620,y:612,t:1527876827953};\\\", \\\"{x:621,y:613,t:1527876829455};\\\", \\\"{x:634,y:613,t:1527876829471};\\\", \\\"{x:654,y:611,t:1527876829488};\\\", \\\"{x:669,y:609,t:1527876829505};\\\", \\\"{x:683,y:606,t:1527876829521};\\\", \\\"{x:689,y:606,t:1527876829538};\\\", \\\"{x:695,y:606,t:1527876829554};\\\", \\\"{x:707,y:605,t:1527876829572};\\\", \\\"{x:720,y:604,t:1527876829588};\\\", \\\"{x:739,y:601,t:1527876829605};\\\", \\\"{x:760,y:601,t:1527876829621};\\\", \\\"{x:796,y:601,t:1527876829638};\\\", \\\"{x:816,y:603,t:1527876829654};\\\", \\\"{x:834,y:605,t:1527876829672};\\\", \\\"{x:848,y:607,t:1527876829688};\\\", \\\"{x:853,y:607,t:1527876829704};\\\", \\\"{x:856,y:607,t:1527876829721};\\\", \\\"{x:857,y:607,t:1527876829742};\\\", \\\"{x:858,y:607,t:1527876829754};\\\", \\\"{x:856,y:608,t:1527876829870};\\\", \\\"{x:855,y:608,t:1527876829879};\\\", \\\"{x:854,y:609,t:1527876829889};\\\", \\\"{x:852,y:610,t:1527876829906};\\\", \\\"{x:851,y:611,t:1527876829922};\\\", \\\"{x:849,y:611,t:1527876829938};\\\", \\\"{x:848,y:611,t:1527876829955};\\\", \\\"{x:846,y:611,t:1527876830918};\\\", \\\"{x:838,y:613,t:1527876830926};\\\", \\\"{x:826,y:613,t:1527876830940};\\\", \\\"{x:794,y:613,t:1527876830956};\\\", \\\"{x:746,y:606,t:1527876830973};\\\", \\\"{x:681,y:593,t:1527876830989};\\\", \\\"{x:585,y:573,t:1527876831005};\\\", \\\"{x:439,y:548,t:1527876831022};\\\", \\\"{x:385,y:540,t:1527876831040};\\\", \\\"{x:354,y:535,t:1527876831056};\\\", \\\"{x:331,y:535,t:1527876831073};\\\", \\\"{x:318,y:535,t:1527876831089};\\\", \\\"{x:316,y:535,t:1527876831105};\\\", \\\"{x:315,y:535,t:1527876831122};\\\", \\\"{x:313,y:536,t:1527876831198};\\\", \\\"{x:311,y:538,t:1527876831230};\\\", \\\"{x:311,y:540,t:1527876831246};\\\", \\\"{x:311,y:541,t:1527876831256};\\\", \\\"{x:309,y:547,t:1527876831272};\\\", \\\"{x:308,y:550,t:1527876831290};\\\", \\\"{x:308,y:554,t:1527876831306};\\\", \\\"{x:308,y:557,t:1527876831322};\\\", \\\"{x:307,y:561,t:1527876831340};\\\", \\\"{x:307,y:566,t:1527876831357};\\\", \\\"{x:307,y:568,t:1527876831373};\\\", \\\"{x:307,y:569,t:1527876831390};\\\", \\\"{x:307,y:571,t:1527876831422};\\\", \\\"{x:311,y:571,t:1527876831439};\\\", \\\"{x:319,y:571,t:1527876831457};\\\", \\\"{x:328,y:571,t:1527876831472};\\\", \\\"{x:339,y:569,t:1527876831490};\\\", \\\"{x:349,y:566,t:1527876831506};\\\", \\\"{x:352,y:565,t:1527876831522};\\\", \\\"{x:355,y:564,t:1527876831540};\\\", \\\"{x:356,y:564,t:1527876831559};\\\", \\\"{x:354,y:567,t:1527876831718};\\\", \\\"{x:342,y:575,t:1527876831726};\\\", \\\"{x:332,y:582,t:1527876831740};\\\", \\\"{x:309,y:595,t:1527876831756};\\\", \\\"{x:287,y:605,t:1527876831774};\\\", \\\"{x:263,y:615,t:1527876831790};\\\", \\\"{x:239,y:621,t:1527876831806};\\\", \\\"{x:229,y:623,t:1527876831823};\\\", \\\"{x:221,y:627,t:1527876831840};\\\", \\\"{x:216,y:627,t:1527876831856};\\\", \\\"{x:208,y:627,t:1527876831874};\\\", \\\"{x:199,y:627,t:1527876831889};\\\", \\\"{x:190,y:626,t:1527876831907};\\\", \\\"{x:183,y:624,t:1527876831923};\\\", \\\"{x:182,y:624,t:1527876831939};\\\", \\\"{x:181,y:624,t:1527876832134};\\\", \\\"{x:181,y:625,t:1527876832142};\\\", \\\"{x:179,y:627,t:1527876832156};\\\", \\\"{x:176,y:633,t:1527876832173};\\\", \\\"{x:172,y:638,t:1527876832191};\\\", \\\"{x:170,y:642,t:1527876832206};\\\", \\\"{x:168,y:645,t:1527876832224};\\\", \\\"{x:168,y:647,t:1527876832240};\\\", \\\"{x:178,y:646,t:1527876832830};\\\", \\\"{x:190,y:642,t:1527876832841};\\\", \\\"{x:220,y:635,t:1527876832858};\\\", \\\"{x:259,y:630,t:1527876832875};\\\", \\\"{x:291,y:626,t:1527876832891};\\\", \\\"{x:313,y:622,t:1527876832907};\\\", \\\"{x:335,y:617,t:1527876832923};\\\", \\\"{x:349,y:616,t:1527876832941};\\\", \\\"{x:365,y:613,t:1527876832957};\\\", \\\"{x:383,y:611,t:1527876832974};\\\", \\\"{x:395,y:610,t:1527876832991};\\\", \\\"{x:409,y:607,t:1527876833008};\\\", \\\"{x:423,y:606,t:1527876833025};\\\", \\\"{x:438,y:603,t:1527876833041};\\\", \\\"{x:455,y:601,t:1527876833058};\\\", \\\"{x:470,y:601,t:1527876833075};\\\", \\\"{x:486,y:601,t:1527876833091};\\\", \\\"{x:504,y:600,t:1527876833108};\\\", \\\"{x:523,y:595,t:1527876833125};\\\", \\\"{x:539,y:593,t:1527876833141};\\\", \\\"{x:554,y:589,t:1527876833158};\\\", \\\"{x:567,y:587,t:1527876833174};\\\", \\\"{x:572,y:585,t:1527876833191};\\\", \\\"{x:574,y:584,t:1527876833207};\\\", \\\"{x:575,y:584,t:1527876833224};\\\", \\\"{x:576,y:584,t:1527876833241};\\\", \\\"{x:577,y:583,t:1527876833257};\\\", \\\"{x:578,y:581,t:1527876833275};\\\", \\\"{x:578,y:580,t:1527876833382};\\\", \\\"{x:578,y:576,t:1527876833391};\\\", \\\"{x:571,y:570,t:1527876833407};\\\", \\\"{x:564,y:564,t:1527876833425};\\\", \\\"{x:561,y:562,t:1527876833441};\\\", \\\"{x:558,y:559,t:1527876833457};\\\", \\\"{x:552,y:556,t:1527876833474};\\\", \\\"{x:537,y:554,t:1527876833491};\\\", \\\"{x:512,y:551,t:1527876833508};\\\", \\\"{x:493,y:549,t:1527876833525};\\\", \\\"{x:480,y:546,t:1527876833541};\\\", \\\"{x:472,y:546,t:1527876833557};\\\", \\\"{x:461,y:546,t:1527876833574};\\\", \\\"{x:459,y:546,t:1527876833591};\\\", \\\"{x:458,y:546,t:1527876833608};\\\", \\\"{x:457,y:546,t:1527876833624};\\\", \\\"{x:456,y:546,t:1527876833654};\\\", \\\"{x:455,y:546,t:1527876833662};\\\", \\\"{x:453,y:546,t:1527876833674};\\\", \\\"{x:444,y:546,t:1527876833691};\\\", \\\"{x:427,y:544,t:1527876833707};\\\", \\\"{x:412,y:542,t:1527876833725};\\\", \\\"{x:402,y:540,t:1527876833741};\\\", \\\"{x:400,y:539,t:1527876833757};\\\", \\\"{x:398,y:538,t:1527876833775};\\\", \\\"{x:397,y:539,t:1527876833823};\\\", \\\"{x:395,y:544,t:1527876833830};\\\", \\\"{x:393,y:550,t:1527876833842};\\\", \\\"{x:388,y:563,t:1527876833859};\\\", \\\"{x:384,y:571,t:1527876833875};\\\", \\\"{x:382,y:584,t:1527876833891};\\\", \\\"{x:382,y:606,t:1527876833908};\\\", \\\"{x:387,y:631,t:1527876833925};\\\", \\\"{x:396,y:648,t:1527876833943};\\\", \\\"{x:398,y:653,t:1527876833959};\\\", \\\"{x:399,y:655,t:1527876833974};\\\", \\\"{x:399,y:656,t:1527876834334};\\\", \\\"{x:399,y:656,t:1527876834362};\\\", \\\"{x:400,y:663,t:1527876834598};\\\", \\\"{x:407,y:670,t:1527876834609};\\\", \\\"{x:425,y:683,t:1527876834626};\\\", \\\"{x:440,y:694,t:1527876834642};\\\", \\\"{x:450,y:702,t:1527876834658};\\\", \\\"{x:456,y:706,t:1527876834675};\\\", \\\"{x:461,y:709,t:1527876834693};\\\", \\\"{x:461,y:710,t:1527876834709};\\\", \\\"{x:463,y:712,t:1527876834847};\\\", \\\"{x:467,y:718,t:1527876834858};\\\", \\\"{x:483,y:735,t:1527876834876};\\\", \\\"{x:494,y:748,t:1527876834892};\\\", \\\"{x:498,y:753,t:1527876834909};\\\", \\\"{x:500,y:752,t:1527876835375};\\\", \\\"{x:501,y:752,t:1527876835382};\\\", \\\"{x:502,y:751,t:1527876835392};\\\", \\\"{x:507,y:749,t:1527876835410};\\\", \\\"{x:512,y:747,t:1527876835426};\\\", \\\"{x:523,y:742,t:1527876835443};\\\", \\\"{x:533,y:737,t:1527876835460};\\\", \\\"{x:548,y:732,t:1527876835475};\\\", \\\"{x:569,y:726,t:1527876835493};\\\", \\\"{x:607,y:719,t:1527876835510};\\\", \\\"{x:672,y:709,t:1527876835525};\\\", \\\"{x:807,y:698,t:1527876835542};\\\", \\\"{x:891,y:698,t:1527876835560};\\\", \\\"{x:982,y:698,t:1527876835577};\\\", \\\"{x:1079,y:698,t:1527876835592};\\\", \\\"{x:1185,y:698,t:1527876835609};\\\", \\\"{x:1287,y:698,t:1527876835626};\\\", \\\"{x:1415,y:694,t:1527876835643};\\\", \\\"{x:1554,y:694,t:1527876835659};\\\", \\\"{x:1687,y:694,t:1527876835677};\\\", \\\"{x:1795,y:694,t:1527876835693};\\\", \\\"{x:1856,y:694,t:1527876835710};\\\", \\\"{x:1885,y:694,t:1527876835726};\\\", \\\"{x:1886,y:693,t:1527876835815};\\\", \\\"{x:1881,y:690,t:1527876835831};\\\", \\\"{x:1872,y:686,t:1527876835842};\\\", \\\"{x:1838,y:679,t:1527876835860};\\\", \\\"{x:1785,y:671,t:1527876835876};\\\", \\\"{x:1707,y:660,t:1527876835892};\\\", \\\"{x:1624,y:649,t:1527876835910};\\\", \\\"{x:1475,y:629,t:1527876835926};\\\", \\\"{x:1384,y:618,t:1527876835943};\\\", \\\"{x:1297,y:600,t:1527876835959};\\\", \\\"{x:1247,y:594,t:1527876835976};\\\", \\\"{x:1202,y:586,t:1527876835993};\\\", \\\"{x:1173,y:582,t:1527876836010};\\\", \\\"{x:1145,y:579,t:1527876836027};\\\", \\\"{x:1126,y:579,t:1527876836043};\\\", \\\"{x:1112,y:579,t:1527876836060};\\\", \\\"{x:1101,y:578,t:1527876836077};\\\", \\\"{x:1095,y:578,t:1527876836094};\\\", \\\"{x:1086,y:578,t:1527876836109};\\\", \\\"{x:1074,y:578,t:1527876836127};\\\", \\\"{x:1070,y:578,t:1527876836144};\\\", \\\"{x:1067,y:578,t:1527876836159};\\\", \\\"{x:1065,y:578,t:1527876836177};\\\", \\\"{x:1064,y:578,t:1527876836193};\\\" ] }, { \\\"rt\\\": 18614, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 462289, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"2ZXKM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -B -B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1057,y:578,t:1527876836654};\\\", \\\"{x:1049,y:578,t:1527876836662};\\\", \\\"{x:1038,y:581,t:1527876836677};\\\", \\\"{x:1012,y:583,t:1527876836694};\\\", \\\"{x:971,y:588,t:1527876836710};\\\", \\\"{x:939,y:588,t:1527876836727};\\\", \\\"{x:832,y:576,t:1527876836788};\\\", \\\"{x:827,y:576,t:1527876836793};\\\", \\\"{x:814,y:574,t:1527876836811};\\\", \\\"{x:803,y:573,t:1527876836827};\\\", \\\"{x:793,y:571,t:1527876836843};\\\", \\\"{x:787,y:570,t:1527876836861};\\\", \\\"{x:779,y:569,t:1527876836878};\\\", \\\"{x:773,y:568,t:1527876836893};\\\", \\\"{x:756,y:567,t:1527876836910};\\\", \\\"{x:748,y:567,t:1527876836928};\\\", \\\"{x:736,y:566,t:1527876836943};\\\", \\\"{x:723,y:566,t:1527876836961};\\\", \\\"{x:716,y:566,t:1527876836978};\\\", \\\"{x:712,y:566,t:1527876836994};\\\", \\\"{x:709,y:566,t:1527876837010};\\\", \\\"{x:708,y:566,t:1527876837027};\\\", \\\"{x:706,y:566,t:1527876837046};\\\", \\\"{x:705,y:566,t:1527876837061};\\\", \\\"{x:703,y:566,t:1527876837077};\\\", \\\"{x:701,y:566,t:1527876837094};\\\", \\\"{x:697,y:566,t:1527876837111};\\\", \\\"{x:696,y:566,t:1527876837128};\\\", \\\"{x:695,y:565,t:1527876837143};\\\", \\\"{x:693,y:564,t:1527876837161};\\\", \\\"{x:692,y:564,t:1527876837182};\\\", \\\"{x:691,y:564,t:1527876837194};\\\", \\\"{x:690,y:564,t:1527876837211};\\\", \\\"{x:689,y:564,t:1527876837270};\\\", \\\"{x:687,y:564,t:1527876837383};\\\", \\\"{x:686,y:564,t:1527876837398};\\\", \\\"{x:684,y:564,t:1527876837410};\\\", \\\"{x:683,y:564,t:1527876837428};\\\", \\\"{x:682,y:564,t:1527876837444};\\\", \\\"{x:681,y:564,t:1527876837982};\\\", \\\"{x:681,y:563,t:1527876837998};\\\", \\\"{x:681,y:562,t:1527876838030};\\\", \\\"{x:682,y:562,t:1527876838054};\\\", \\\"{x:683,y:562,t:1527876838086};\\\", \\\"{x:684,y:561,t:1527876838095};\\\", \\\"{x:686,y:560,t:1527876838111};\\\", \\\"{x:689,y:559,t:1527876838128};\\\", \\\"{x:693,y:558,t:1527876838144};\\\", \\\"{x:696,y:556,t:1527876838161};\\\", \\\"{x:700,y:556,t:1527876838178};\\\", \\\"{x:702,y:556,t:1527876838194};\\\", \\\"{x:707,y:556,t:1527876838212};\\\", \\\"{x:711,y:556,t:1527876838229};\\\", \\\"{x:723,y:558,t:1527876838244};\\\", \\\"{x:759,y:563,t:1527876838262};\\\", \\\"{x:893,y:580,t:1527876838278};\\\", \\\"{x:1029,y:600,t:1527876838295};\\\", \\\"{x:1169,y:617,t:1527876838312};\\\", \\\"{x:1293,y:644,t:1527876838328};\\\", \\\"{x:1386,y:667,t:1527876838344};\\\", \\\"{x:1442,y:683,t:1527876838362};\\\", \\\"{x:1461,y:689,t:1527876838378};\\\", \\\"{x:1463,y:690,t:1527876838395};\\\", \\\"{x:1463,y:691,t:1527876838430};\\\", \\\"{x:1463,y:694,t:1527876838447};\\\", \\\"{x:1462,y:695,t:1527876838462};\\\", \\\"{x:1459,y:705,t:1527876838478};\\\", \\\"{x:1458,y:710,t:1527876838495};\\\", \\\"{x:1457,y:716,t:1527876838511};\\\", \\\"{x:1453,y:722,t:1527876838529};\\\", \\\"{x:1447,y:729,t:1527876838545};\\\", \\\"{x:1442,y:734,t:1527876838562};\\\", \\\"{x:1437,y:738,t:1527876838578};\\\", \\\"{x:1433,y:745,t:1527876838596};\\\", \\\"{x:1430,y:751,t:1527876838612};\\\", \\\"{x:1429,y:753,t:1527876838629};\\\", \\\"{x:1427,y:754,t:1527876838645};\\\", \\\"{x:1426,y:755,t:1527876838661};\\\", \\\"{x:1424,y:757,t:1527876838678};\\\", \\\"{x:1421,y:757,t:1527876838696};\\\", \\\"{x:1415,y:757,t:1527876838711};\\\", \\\"{x:1402,y:757,t:1527876838729};\\\", \\\"{x:1390,y:757,t:1527876838746};\\\", \\\"{x:1382,y:756,t:1527876838762};\\\", \\\"{x:1377,y:755,t:1527876838779};\\\", \\\"{x:1373,y:755,t:1527876838796};\\\", \\\"{x:1371,y:755,t:1527876838812};\\\", \\\"{x:1369,y:755,t:1527876838829};\\\", \\\"{x:1368,y:755,t:1527876838846};\\\", \\\"{x:1366,y:755,t:1527876838862};\\\", \\\"{x:1362,y:755,t:1527876838879};\\\", \\\"{x:1359,y:755,t:1527876838896};\\\", \\\"{x:1357,y:755,t:1527876838911};\\\", \\\"{x:1355,y:756,t:1527876838928};\\\", \\\"{x:1354,y:756,t:1527876838958};\\\", \\\"{x:1353,y:756,t:1527876838966};\\\", \\\"{x:1352,y:756,t:1527876838982};\\\", \\\"{x:1351,y:756,t:1527876838995};\\\", \\\"{x:1349,y:756,t:1527876839012};\\\", \\\"{x:1348,y:756,t:1527876839030};\\\", \\\"{x:1347,y:756,t:1527876839046};\\\", \\\"{x:1346,y:756,t:1527876839063};\\\", \\\"{x:1345,y:757,t:1527876839110};\\\", \\\"{x:1344,y:757,t:1527876839159};\\\", \\\"{x:1344,y:758,t:1527876839166};\\\", \\\"{x:1343,y:758,t:1527876839190};\\\", \\\"{x:1342,y:759,t:1527876839198};\\\", \\\"{x:1341,y:759,t:1527876839214};\\\", \\\"{x:1341,y:760,t:1527876839239};\\\", \\\"{x:1343,y:760,t:1527876839479};\\\", \\\"{x:1345,y:758,t:1527876839495};\\\", \\\"{x:1348,y:756,t:1527876839514};\\\", \\\"{x:1351,y:752,t:1527876839530};\\\", \\\"{x:1355,y:746,t:1527876839546};\\\", \\\"{x:1357,y:741,t:1527876839563};\\\", \\\"{x:1364,y:732,t:1527876839580};\\\", \\\"{x:1371,y:725,t:1527876839596};\\\", \\\"{x:1380,y:716,t:1527876839612};\\\", \\\"{x:1391,y:706,t:1527876839630};\\\", \\\"{x:1402,y:699,t:1527876839645};\\\", \\\"{x:1419,y:684,t:1527876839663};\\\", \\\"{x:1434,y:674,t:1527876839679};\\\", \\\"{x:1441,y:666,t:1527876839696};\\\", \\\"{x:1455,y:655,t:1527876839713};\\\", \\\"{x:1463,y:648,t:1527876839730};\\\", \\\"{x:1471,y:642,t:1527876839746};\\\", \\\"{x:1476,y:636,t:1527876839762};\\\", \\\"{x:1482,y:627,t:1527876839780};\\\", \\\"{x:1485,y:623,t:1527876839796};\\\", \\\"{x:1488,y:619,t:1527876839813};\\\", \\\"{x:1491,y:613,t:1527876839830};\\\", \\\"{x:1495,y:609,t:1527876839846};\\\", \\\"{x:1502,y:598,t:1527876839862};\\\", \\\"{x:1508,y:591,t:1527876839880};\\\", \\\"{x:1512,y:586,t:1527876839896};\\\", \\\"{x:1517,y:578,t:1527876839913};\\\", \\\"{x:1520,y:574,t:1527876839930};\\\", \\\"{x:1525,y:568,t:1527876839946};\\\", \\\"{x:1528,y:564,t:1527876839962};\\\", \\\"{x:1530,y:561,t:1527876839979};\\\", \\\"{x:1532,y:560,t:1527876839997};\\\", \\\"{x:1533,y:559,t:1527876840013};\\\", \\\"{x:1534,y:558,t:1527876840038};\\\", \\\"{x:1528,y:560,t:1527876841495};\\\", \\\"{x:1519,y:564,t:1527876841502};\\\", \\\"{x:1509,y:566,t:1527876841514};\\\", \\\"{x:1492,y:572,t:1527876841530};\\\", \\\"{x:1479,y:575,t:1527876841548};\\\", \\\"{x:1464,y:577,t:1527876841564};\\\", \\\"{x:1450,y:579,t:1527876841581};\\\", \\\"{x:1444,y:580,t:1527876841598};\\\", \\\"{x:1438,y:581,t:1527876841614};\\\", \\\"{x:1432,y:584,t:1527876841631};\\\", \\\"{x:1425,y:588,t:1527876841648};\\\", \\\"{x:1414,y:597,t:1527876841664};\\\", \\\"{x:1400,y:603,t:1527876841681};\\\", \\\"{x:1382,y:614,t:1527876841698};\\\", \\\"{x:1364,y:626,t:1527876841714};\\\", \\\"{x:1348,y:643,t:1527876841730};\\\", \\\"{x:1321,y:675,t:1527876841748};\\\", \\\"{x:1285,y:738,t:1527876841764};\\\", \\\"{x:1228,y:821,t:1527876841781};\\\", \\\"{x:1168,y:902,t:1527876841797};\\\", \\\"{x:1125,y:964,t:1527876841813};\\\", \\\"{x:1097,y:1002,t:1527876841830};\\\", \\\"{x:1093,y:1006,t:1527876841848};\\\", \\\"{x:1092,y:1007,t:1527876841870};\\\", \\\"{x:1092,y:1003,t:1527876841966};\\\", \\\"{x:1096,y:993,t:1527876841980};\\\", \\\"{x:1107,y:970,t:1527876841998};\\\", \\\"{x:1130,y:926,t:1527876842014};\\\", \\\"{x:1141,y:902,t:1527876842031};\\\", \\\"{x:1149,y:883,t:1527876842048};\\\", \\\"{x:1154,y:870,t:1527876842065};\\\", \\\"{x:1158,y:864,t:1527876842080};\\\", \\\"{x:1158,y:862,t:1527876842098};\\\", \\\"{x:1158,y:865,t:1527876842311};\\\", \\\"{x:1158,y:869,t:1527876842318};\\\", \\\"{x:1158,y:871,t:1527876842331};\\\", \\\"{x:1158,y:877,t:1527876842348};\\\", \\\"{x:1158,y:883,t:1527876842365};\\\", \\\"{x:1158,y:889,t:1527876842382};\\\", \\\"{x:1158,y:894,t:1527876842398};\\\", \\\"{x:1158,y:896,t:1527876842414};\\\", \\\"{x:1158,y:897,t:1527876842432};\\\", \\\"{x:1158,y:898,t:1527876842448};\\\", \\\"{x:1158,y:899,t:1527876842542};\\\", \\\"{x:1158,y:900,t:1527876842550};\\\", \\\"{x:1158,y:901,t:1527876842564};\\\", \\\"{x:1158,y:904,t:1527876842581};\\\", \\\"{x:1158,y:907,t:1527876842598};\\\", \\\"{x:1157,y:911,t:1527876842615};\\\", \\\"{x:1157,y:914,t:1527876842632};\\\", \\\"{x:1157,y:917,t:1527876842647};\\\", \\\"{x:1157,y:919,t:1527876842665};\\\", \\\"{x:1157,y:921,t:1527876842681};\\\", \\\"{x:1157,y:922,t:1527876842697};\\\", \\\"{x:1157,y:924,t:1527876842715};\\\", \\\"{x:1157,y:925,t:1527876842742};\\\", \\\"{x:1156,y:925,t:1527876842766};\\\", \\\"{x:1156,y:926,t:1527876842782};\\\", \\\"{x:1156,y:925,t:1527876843382};\\\", \\\"{x:1158,y:920,t:1527876843399};\\\", \\\"{x:1161,y:916,t:1527876843416};\\\", \\\"{x:1163,y:914,t:1527876843432};\\\", \\\"{x:1166,y:911,t:1527876843449};\\\", \\\"{x:1168,y:909,t:1527876843466};\\\", \\\"{x:1173,y:905,t:1527876843482};\\\", \\\"{x:1180,y:899,t:1527876843499};\\\", \\\"{x:1192,y:891,t:1527876843516};\\\", \\\"{x:1202,y:884,t:1527876843532};\\\", \\\"{x:1212,y:877,t:1527876843549};\\\", \\\"{x:1223,y:866,t:1527876843566};\\\", \\\"{x:1236,y:855,t:1527876843581};\\\", \\\"{x:1255,y:839,t:1527876843599};\\\", \\\"{x:1262,y:833,t:1527876843616};\\\", \\\"{x:1271,y:824,t:1527876843632};\\\", \\\"{x:1280,y:818,t:1527876843649};\\\", \\\"{x:1286,y:814,t:1527876843665};\\\", \\\"{x:1290,y:810,t:1527876843682};\\\", \\\"{x:1294,y:807,t:1527876843699};\\\", \\\"{x:1297,y:804,t:1527876843716};\\\", \\\"{x:1301,y:801,t:1527876843731};\\\", \\\"{x:1303,y:799,t:1527876843749};\\\", \\\"{x:1305,y:798,t:1527876843766};\\\", \\\"{x:1305,y:797,t:1527876843783};\\\", \\\"{x:1306,y:796,t:1527876844182};\\\", \\\"{x:1309,y:794,t:1527876844199};\\\", \\\"{x:1310,y:793,t:1527876844215};\\\", \\\"{x:1311,y:792,t:1527876844233};\\\", \\\"{x:1312,y:792,t:1527876844254};\\\", \\\"{x:1313,y:791,t:1527876844294};\\\", \\\"{x:1314,y:791,t:1527876844318};\\\", \\\"{x:1315,y:790,t:1527876844333};\\\", \\\"{x:1315,y:789,t:1527876844350};\\\", \\\"{x:1317,y:788,t:1527876844366};\\\", \\\"{x:1318,y:788,t:1527876844383};\\\", \\\"{x:1318,y:787,t:1527876844400};\\\", \\\"{x:1319,y:787,t:1527876844416};\\\", \\\"{x:1320,y:786,t:1527876844433};\\\", \\\"{x:1321,y:785,t:1527876844462};\\\", \\\"{x:1322,y:785,t:1527876844478};\\\", \\\"{x:1323,y:784,t:1527876844486};\\\", \\\"{x:1324,y:782,t:1527876844910};\\\", \\\"{x:1325,y:781,t:1527876844934};\\\", \\\"{x:1322,y:781,t:1527876847254};\\\", \\\"{x:1317,y:782,t:1527876847268};\\\", \\\"{x:1302,y:786,t:1527876847285};\\\", \\\"{x:1285,y:787,t:1527876847302};\\\", \\\"{x:1283,y:788,t:1527876847318};\\\", \\\"{x:1281,y:788,t:1527876848126};\\\", \\\"{x:1276,y:789,t:1527876848136};\\\", \\\"{x:1261,y:791,t:1527876848152};\\\", \\\"{x:1241,y:792,t:1527876848169};\\\", \\\"{x:1218,y:792,t:1527876848186};\\\", \\\"{x:1200,y:792,t:1527876848202};\\\", \\\"{x:1187,y:792,t:1527876848219};\\\", \\\"{x:1182,y:792,t:1527876848236};\\\", \\\"{x:1182,y:791,t:1527876848462};\\\", \\\"{x:1182,y:790,t:1527876848470};\\\", \\\"{x:1182,y:789,t:1527876848486};\\\", \\\"{x:1182,y:787,t:1527876848503};\\\", \\\"{x:1182,y:786,t:1527876848519};\\\", \\\"{x:1183,y:785,t:1527876848536};\\\", \\\"{x:1183,y:784,t:1527876848623};\\\", \\\"{x:1183,y:783,t:1527876848638};\\\", \\\"{x:1183,y:782,t:1527876848670};\\\", \\\"{x:1183,y:780,t:1527876848686};\\\", \\\"{x:1183,y:778,t:1527876849518};\\\", \\\"{x:1183,y:777,t:1527876849526};\\\", \\\"{x:1183,y:776,t:1527876849537};\\\", \\\"{x:1183,y:775,t:1527876849558};\\\", \\\"{x:1184,y:773,t:1527876849570};\\\", \\\"{x:1179,y:772,t:1527876852551};\\\", \\\"{x:1164,y:772,t:1527876852557};\\\", \\\"{x:1147,y:772,t:1527876852572};\\\", \\\"{x:1094,y:765,t:1527876852589};\\\", \\\"{x:996,y:747,t:1527876852605};\\\", \\\"{x:867,y:716,t:1527876852622};\\\", \\\"{x:797,y:695,t:1527876852640};\\\", \\\"{x:747,y:681,t:1527876852655};\\\", \\\"{x:712,y:674,t:1527876852672};\\\", \\\"{x:686,y:671,t:1527876852689};\\\", \\\"{x:674,y:670,t:1527876852705};\\\", \\\"{x:668,y:667,t:1527876852722};\\\", \\\"{x:661,y:667,t:1527876852739};\\\", \\\"{x:650,y:665,t:1527876852756};\\\", \\\"{x:636,y:663,t:1527876852772};\\\", \\\"{x:618,y:660,t:1527876852790};\\\", \\\"{x:585,y:655,t:1527876852806};\\\", \\\"{x:555,y:650,t:1527876852822};\\\", \\\"{x:521,y:645,t:1527876852839};\\\", \\\"{x:481,y:638,t:1527876852856};\\\", \\\"{x:434,y:634,t:1527876852872};\\\", \\\"{x:398,y:629,t:1527876852889};\\\", \\\"{x:368,y:624,t:1527876852906};\\\", \\\"{x:351,y:622,t:1527876852923};\\\", \\\"{x:347,y:622,t:1527876852940};\\\", \\\"{x:346,y:622,t:1527876852957};\\\", \\\"{x:345,y:621,t:1527876852998};\\\", \\\"{x:344,y:621,t:1527876853022};\\\", \\\"{x:339,y:621,t:1527876853030};\\\", \\\"{x:335,y:621,t:1527876853040};\\\", \\\"{x:322,y:621,t:1527876853058};\\\", \\\"{x:310,y:621,t:1527876853073};\\\", \\\"{x:298,y:619,t:1527876853090};\\\", \\\"{x:294,y:619,t:1527876853108};\\\", \\\"{x:292,y:618,t:1527876853124};\\\", \\\"{x:290,y:618,t:1527876853140};\\\", \\\"{x:284,y:616,t:1527876853158};\\\", \\\"{x:276,y:615,t:1527876853173};\\\", \\\"{x:261,y:613,t:1527876853190};\\\", \\\"{x:255,y:612,t:1527876853208};\\\", \\\"{x:247,y:612,t:1527876853223};\\\", \\\"{x:236,y:612,t:1527876853240};\\\", \\\"{x:221,y:610,t:1527876853257};\\\", \\\"{x:206,y:604,t:1527876853273};\\\", \\\"{x:188,y:594,t:1527876853290};\\\", \\\"{x:172,y:583,t:1527876853308};\\\", \\\"{x:155,y:570,t:1527876853323};\\\", \\\"{x:148,y:558,t:1527876853341};\\\", \\\"{x:143,y:551,t:1527876853358};\\\", \\\"{x:141,y:544,t:1527876853373};\\\", \\\"{x:132,y:521,t:1527876853390};\\\", \\\"{x:128,y:504,t:1527876853407};\\\", \\\"{x:124,y:488,t:1527876853424};\\\", \\\"{x:123,y:478,t:1527876853440};\\\", \\\"{x:123,y:472,t:1527876853457};\\\", \\\"{x:123,y:468,t:1527876853474};\\\", \\\"{x:125,y:464,t:1527876853490};\\\", \\\"{x:130,y:462,t:1527876853507};\\\", \\\"{x:135,y:460,t:1527876853524};\\\", \\\"{x:140,y:460,t:1527876853540};\\\", \\\"{x:142,y:460,t:1527876853557};\\\", \\\"{x:143,y:460,t:1527876853574};\\\", \\\"{x:144,y:460,t:1527876853590};\\\", \\\"{x:145,y:461,t:1527876853607};\\\", \\\"{x:148,y:466,t:1527876853624};\\\", \\\"{x:148,y:470,t:1527876853640};\\\", \\\"{x:149,y:475,t:1527876853657};\\\", \\\"{x:152,y:479,t:1527876853674};\\\", \\\"{x:155,y:482,t:1527876853691};\\\", \\\"{x:155,y:484,t:1527876853726};\\\", \\\"{x:155,y:485,t:1527876853758};\\\", \\\"{x:155,y:487,t:1527876853782};\\\", \\\"{x:155,y:488,t:1527876853871};\\\", \\\"{x:155,y:489,t:1527876853886};\\\", \\\"{x:156,y:490,t:1527876853894};\\\", \\\"{x:156,y:491,t:1527876853907};\\\", \\\"{x:158,y:493,t:1527876853924};\\\", \\\"{x:159,y:493,t:1527876853941};\\\", \\\"{x:159,y:494,t:1527876854094};\\\", \\\"{x:159,y:494,t:1527876854145};\\\", \\\"{x:159,y:495,t:1527876854230};\\\", \\\"{x:159,y:497,t:1527876854242};\\\", \\\"{x:169,y:508,t:1527876854258};\\\", \\\"{x:188,y:523,t:1527876854274};\\\", \\\"{x:234,y:559,t:1527876854291};\\\", \\\"{x:282,y:594,t:1527876854308};\\\", \\\"{x:337,y:636,t:1527876854325};\\\", \\\"{x:379,y:665,t:1527876854342};\\\", \\\"{x:400,y:680,t:1527876854358};\\\", \\\"{x:407,y:685,t:1527876854375};\\\", \\\"{x:414,y:691,t:1527876854392};\\\", \\\"{x:427,y:702,t:1527876854408};\\\", \\\"{x:454,y:724,t:1527876854425};\\\", \\\"{x:477,y:742,t:1527876854441};\\\", \\\"{x:488,y:750,t:1527876854458};\\\", \\\"{x:496,y:755,t:1527876854474};\\\", \\\"{x:498,y:757,t:1527876854492};\\\", \\\"{x:498,y:756,t:1527876854694};\\\", \\\"{x:498,y:753,t:1527876854708};\\\", \\\"{x:500,y:751,t:1527876855861};\\\", \\\"{x:501,y:751,t:1527876855876};\\\", \\\"{x:505,y:751,t:1527876855892};\\\", \\\"{x:508,y:751,t:1527876855909};\\\", \\\"{x:512,y:751,t:1527876855926};\\\", \\\"{x:515,y:751,t:1527876855943};\\\", \\\"{x:520,y:752,t:1527876855961};\\\", \\\"{x:540,y:758,t:1527876855976};\\\", \\\"{x:588,y:778,t:1527876855992};\\\", \\\"{x:715,y:831,t:1527876856009};\\\", \\\"{x:902,y:905,t:1527876856027};\\\" ] }, { \\\"rt\\\": 13027, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 476519, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"2ZXKM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-M -02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1919,y:1195,t:1527876856148};\\\", \\\"{x:1919,y:1162,t:1527876856179};\\\", \\\"{x:1919,y:1156,t:1527876856192};\\\", \\\"{x:1919,y:1153,t:1527876856209};\\\", \\\"{x:1919,y:1152,t:1527876856226};\\\", \\\"{x:1919,y:1151,t:1527876856326};\\\", \\\"{x:1919,y:1147,t:1527876856342};\\\", \\\"{x:1919,y:1144,t:1527876856360};\\\", \\\"{x:1919,y:1142,t:1527876856376};\\\", \\\"{x:1919,y:1134,t:1527876856393};\\\", \\\"{x:1919,y:1118,t:1527876856409};\\\", \\\"{x:1919,y:1090,t:1527876856427};\\\", \\\"{x:1919,y:1067,t:1527876856443};\\\", \\\"{x:1919,y:1049,t:1527876856459};\\\", \\\"{x:1903,y:1020,t:1527876856476};\\\", \\\"{x:1846,y:976,t:1527876856494};\\\", \\\"{x:1734,y:919,t:1527876856510};\\\", \\\"{x:1520,y:845,t:1527876856526};\\\", \\\"{x:1346,y:791,t:1527876856544};\\\", \\\"{x:1142,y:742,t:1527876856559};\\\", \\\"{x:920,y:693,t:1527876856577};\\\", \\\"{x:693,y:651,t:1527876856593};\\\", \\\"{x:460,y:616,t:1527876856609};\\\", \\\"{x:289,y:589,t:1527876856626};\\\", \\\"{x:178,y:573,t:1527876856643};\\\", \\\"{x:112,y:565,t:1527876856711};\\\", \\\"{x:117,y:565,t:1527876856798};\\\", \\\"{x:133,y:568,t:1527876856810};\\\", \\\"{x:190,y:579,t:1527876856827};\\\", \\\"{x:270,y:588,t:1527876856843};\\\", \\\"{x:365,y:590,t:1527876856860};\\\", \\\"{x:477,y:598,t:1527876856876};\\\", \\\"{x:596,y:600,t:1527876856893};\\\", \\\"{x:751,y:600,t:1527876856910};\\\", \\\"{x:826,y:600,t:1527876856926};\\\", \\\"{x:893,y:600,t:1527876856943};\\\", \\\"{x:979,y:600,t:1527876856961};\\\", \\\"{x:1080,y:597,t:1527876856976};\\\", \\\"{x:1187,y:589,t:1527876856993};\\\", \\\"{x:1231,y:589,t:1527876857011};\\\", \\\"{x:1251,y:589,t:1527876857027};\\\", \\\"{x:1259,y:589,t:1527876857043};\\\", \\\"{x:1260,y:589,t:1527876857060};\\\", \\\"{x:1260,y:588,t:1527876857117};\\\", \\\"{x:1248,y:585,t:1527876857126};\\\", \\\"{x:1220,y:581,t:1527876857143};\\\", \\\"{x:1167,y:565,t:1527876857160};\\\", \\\"{x:1098,y:548,t:1527876857176};\\\", \\\"{x:992,y:530,t:1527876857193};\\\", \\\"{x:853,y:511,t:1527876857211};\\\", \\\"{x:696,y:489,t:1527876857227};\\\", \\\"{x:560,y:470,t:1527876857244};\\\", \\\"{x:441,y:453,t:1527876857260};\\\", \\\"{x:357,y:440,t:1527876857276};\\\", \\\"{x:324,y:434,t:1527876857293};\\\", \\\"{x:318,y:434,t:1527876857310};\\\", \\\"{x:321,y:434,t:1527876857414};\\\", \\\"{x:332,y:440,t:1527876857428};\\\", \\\"{x:368,y:454,t:1527876857443};\\\", \\\"{x:421,y:472,t:1527876857461};\\\", \\\"{x:466,y:485,t:1527876857477};\\\", \\\"{x:498,y:495,t:1527876857494};\\\", \\\"{x:532,y:502,t:1527876857511};\\\", \\\"{x:567,y:511,t:1527876857528};\\\", \\\"{x:592,y:517,t:1527876857543};\\\", \\\"{x:607,y:520,t:1527876857561};\\\", \\\"{x:612,y:521,t:1527876857577};\\\", \\\"{x:614,y:521,t:1527876857593};\\\", \\\"{x:610,y:520,t:1527876857686};\\\", \\\"{x:606,y:518,t:1527876857693};\\\", \\\"{x:596,y:513,t:1527876857711};\\\", \\\"{x:584,y:506,t:1527876857728};\\\", \\\"{x:574,y:501,t:1527876857743};\\\", \\\"{x:572,y:500,t:1527876857760};\\\", \\\"{x:570,y:500,t:1527876857777};\\\", \\\"{x:570,y:499,t:1527876857794};\\\", \\\"{x:574,y:496,t:1527876857811};\\\", \\\"{x:616,y:488,t:1527876857828};\\\", \\\"{x:684,y:475,t:1527876857845};\\\", \\\"{x:775,y:464,t:1527876857861};\\\", \\\"{x:900,y:445,t:1527876857877};\\\", \\\"{x:1140,y:430,t:1527876857894};\\\", \\\"{x:1301,y:419,t:1527876857910};\\\", \\\"{x:1454,y:417,t:1527876857927};\\\", \\\"{x:1595,y:417,t:1527876857944};\\\", \\\"{x:1719,y:417,t:1527876857960};\\\", \\\"{x:1785,y:421,t:1527876857977};\\\", \\\"{x:1793,y:424,t:1527876857994};\\\", \\\"{x:1794,y:424,t:1527876858011};\\\", \\\"{x:1790,y:429,t:1527876858027};\\\", \\\"{x:1776,y:445,t:1527876858044};\\\", \\\"{x:1747,y:474,t:1527876858061};\\\", \\\"{x:1703,y:522,t:1527876858077};\\\", \\\"{x:1643,y:596,t:1527876858093};\\\", \\\"{x:1623,y:627,t:1527876858110};\\\", \\\"{x:1615,y:642,t:1527876858127};\\\", \\\"{x:1610,y:648,t:1527876858144};\\\", \\\"{x:1610,y:651,t:1527876858161};\\\", \\\"{x:1609,y:653,t:1527876858178};\\\", \\\"{x:1607,y:658,t:1527876858194};\\\", \\\"{x:1606,y:660,t:1527876858212};\\\", \\\"{x:1602,y:667,t:1527876858228};\\\", \\\"{x:1598,y:673,t:1527876858244};\\\", \\\"{x:1596,y:676,t:1527876858261};\\\", \\\"{x:1589,y:681,t:1527876858277};\\\", \\\"{x:1581,y:685,t:1527876858295};\\\", \\\"{x:1577,y:685,t:1527876858311};\\\", \\\"{x:1574,y:685,t:1527876858327};\\\", \\\"{x:1570,y:685,t:1527876858345};\\\", \\\"{x:1565,y:685,t:1527876858361};\\\", \\\"{x:1559,y:685,t:1527876858378};\\\", \\\"{x:1546,y:679,t:1527876858395};\\\", \\\"{x:1534,y:674,t:1527876858411};\\\", \\\"{x:1525,y:669,t:1527876858428};\\\", \\\"{x:1518,y:668,t:1527876858444};\\\", \\\"{x:1513,y:664,t:1527876858462};\\\", \\\"{x:1508,y:661,t:1527876858477};\\\", \\\"{x:1506,y:660,t:1527876858494};\\\", \\\"{x:1503,y:658,t:1527876858511};\\\", \\\"{x:1502,y:657,t:1527876858527};\\\", \\\"{x:1501,y:657,t:1527876858545};\\\", \\\"{x:1500,y:657,t:1527876858562};\\\", \\\"{x:1499,y:655,t:1527876858578};\\\", \\\"{x:1498,y:655,t:1527876858595};\\\", \\\"{x:1496,y:654,t:1527876858612};\\\", \\\"{x:1496,y:652,t:1527876858628};\\\", \\\"{x:1495,y:652,t:1527876858645};\\\", \\\"{x:1495,y:651,t:1527876858661};\\\", \\\"{x:1493,y:649,t:1527876858677};\\\", \\\"{x:1492,y:648,t:1527876858718};\\\", \\\"{x:1491,y:648,t:1527876858728};\\\", \\\"{x:1485,y:650,t:1527876858744};\\\", \\\"{x:1476,y:660,t:1527876858761};\\\", \\\"{x:1464,y:676,t:1527876858778};\\\", \\\"{x:1454,y:691,t:1527876858794};\\\", \\\"{x:1444,y:699,t:1527876858811};\\\", \\\"{x:1435,y:706,t:1527876858828};\\\", \\\"{x:1433,y:708,t:1527876858845};\\\", \\\"{x:1430,y:710,t:1527876858862};\\\", \\\"{x:1429,y:710,t:1527876858879};\\\", \\\"{x:1425,y:710,t:1527876858974};\\\", \\\"{x:1417,y:710,t:1527876858982};\\\", \\\"{x:1407,y:710,t:1527876858994};\\\", \\\"{x:1383,y:715,t:1527876859011};\\\", \\\"{x:1361,y:717,t:1527876859028};\\\", \\\"{x:1339,y:725,t:1527876859044};\\\", \\\"{x:1321,y:730,t:1527876859062};\\\", \\\"{x:1301,y:736,t:1527876859078};\\\", \\\"{x:1285,y:742,t:1527876859094};\\\", \\\"{x:1275,y:746,t:1527876859111};\\\", \\\"{x:1261,y:752,t:1527876859128};\\\", \\\"{x:1249,y:758,t:1527876859145};\\\", \\\"{x:1241,y:762,t:1527876859161};\\\", \\\"{x:1233,y:768,t:1527876859179};\\\", \\\"{x:1227,y:772,t:1527876859195};\\\", \\\"{x:1220,y:776,t:1527876859212};\\\", \\\"{x:1218,y:778,t:1527876859228};\\\", \\\"{x:1216,y:779,t:1527876859245};\\\", \\\"{x:1214,y:779,t:1527876859334};\\\", \\\"{x:1213,y:779,t:1527876859382};\\\", \\\"{x:1211,y:779,t:1527876859406};\\\", \\\"{x:1210,y:779,t:1527876859422};\\\", \\\"{x:1209,y:778,t:1527876859429};\\\", \\\"{x:1208,y:778,t:1527876859445};\\\", \\\"{x:1208,y:777,t:1527876859934};\\\", \\\"{x:1209,y:772,t:1527876859945};\\\", \\\"{x:1217,y:763,t:1527876859962};\\\", \\\"{x:1223,y:758,t:1527876859979};\\\", \\\"{x:1225,y:757,t:1527876859996};\\\", \\\"{x:1225,y:756,t:1527876860126};\\\", \\\"{x:1226,y:753,t:1527876860134};\\\", \\\"{x:1242,y:739,t:1527876860146};\\\", \\\"{x:1287,y:709,t:1527876860162};\\\", \\\"{x:1319,y:684,t:1527876860179};\\\", \\\"{x:1345,y:659,t:1527876860195};\\\", \\\"{x:1368,y:640,t:1527876860212};\\\", \\\"{x:1387,y:630,t:1527876860230};\\\", \\\"{x:1400,y:626,t:1527876860245};\\\", \\\"{x:1407,y:626,t:1527876860262};\\\", \\\"{x:1411,y:626,t:1527876860280};\\\", \\\"{x:1415,y:626,t:1527876860295};\\\", \\\"{x:1419,y:626,t:1527876860312};\\\", \\\"{x:1422,y:627,t:1527876860329};\\\", \\\"{x:1423,y:628,t:1527876860345};\\\", \\\"{x:1423,y:631,t:1527876860362};\\\", \\\"{x:1414,y:659,t:1527876860380};\\\", \\\"{x:1388,y:720,t:1527876860396};\\\", \\\"{x:1358,y:781,t:1527876860413};\\\", \\\"{x:1346,y:808,t:1527876860429};\\\", \\\"{x:1338,y:824,t:1527876860446};\\\", \\\"{x:1337,y:833,t:1527876860462};\\\", \\\"{x:1337,y:836,t:1527876860480};\\\", \\\"{x:1338,y:842,t:1527876860496};\\\", \\\"{x:1339,y:845,t:1527876860512};\\\", \\\"{x:1342,y:848,t:1527876860530};\\\", \\\"{x:1344,y:849,t:1527876860546};\\\", \\\"{x:1349,y:849,t:1527876860563};\\\", \\\"{x:1358,y:849,t:1527876860580};\\\", \\\"{x:1364,y:849,t:1527876860596};\\\", \\\"{x:1367,y:849,t:1527876860612};\\\", \\\"{x:1368,y:849,t:1527876860629};\\\", \\\"{x:1369,y:849,t:1527876860646};\\\", \\\"{x:1372,y:850,t:1527876860662};\\\", \\\"{x:1376,y:856,t:1527876860679};\\\", \\\"{x:1380,y:871,t:1527876860696};\\\", \\\"{x:1383,y:886,t:1527876860713};\\\", \\\"{x:1389,y:901,t:1527876860730};\\\", \\\"{x:1393,y:909,t:1527876860746};\\\", \\\"{x:1396,y:917,t:1527876860763};\\\", \\\"{x:1399,y:921,t:1527876860780};\\\", \\\"{x:1402,y:924,t:1527876860796};\\\", \\\"{x:1409,y:928,t:1527876860812};\\\", \\\"{x:1420,y:930,t:1527876860829};\\\", \\\"{x:1437,y:935,t:1527876860846};\\\", \\\"{x:1444,y:938,t:1527876860862};\\\", \\\"{x:1449,y:940,t:1527876860880};\\\", \\\"{x:1452,y:942,t:1527876860897};\\\", \\\"{x:1454,y:942,t:1527876860912};\\\", \\\"{x:1455,y:943,t:1527876860957};\\\", \\\"{x:1456,y:944,t:1527876860966};\\\", \\\"{x:1456,y:945,t:1527876860979};\\\", \\\"{x:1458,y:949,t:1527876860996};\\\", \\\"{x:1461,y:954,t:1527876861013};\\\", \\\"{x:1462,y:955,t:1527876861029};\\\", \\\"{x:1462,y:958,t:1527876861117};\\\", \\\"{x:1462,y:961,t:1527876861129};\\\", \\\"{x:1462,y:965,t:1527876861147};\\\", \\\"{x:1462,y:968,t:1527876861164};\\\", \\\"{x:1462,y:971,t:1527876861179};\\\", \\\"{x:1462,y:975,t:1527876861197};\\\", \\\"{x:1462,y:976,t:1527876861213};\\\", \\\"{x:1462,y:978,t:1527876861302};\\\", \\\"{x:1462,y:980,t:1527876861314};\\\", \\\"{x:1463,y:982,t:1527876861329};\\\", \\\"{x:1464,y:982,t:1527876861347};\\\", \\\"{x:1465,y:980,t:1527876861502};\\\", \\\"{x:1465,y:979,t:1527876861514};\\\", \\\"{x:1466,y:977,t:1527876861530};\\\", \\\"{x:1466,y:975,t:1527876861546};\\\", \\\"{x:1467,y:973,t:1527876861563};\\\", \\\"{x:1468,y:972,t:1527876861580};\\\", \\\"{x:1468,y:971,t:1527876861596};\\\", \\\"{x:1468,y:969,t:1527876861614};\\\", \\\"{x:1468,y:968,t:1527876861646};\\\", \\\"{x:1469,y:966,t:1527876861653};\\\", \\\"{x:1470,y:966,t:1527876861669};\\\", \\\"{x:1471,y:965,t:1527876861681};\\\", \\\"{x:1471,y:963,t:1527876861697};\\\", \\\"{x:1474,y:961,t:1527876861713};\\\", \\\"{x:1475,y:960,t:1527876861730};\\\", \\\"{x:1475,y:959,t:1527876862430};\\\", \\\"{x:1470,y:957,t:1527876864254};\\\", \\\"{x:1440,y:951,t:1527876864265};\\\", \\\"{x:1322,y:922,t:1527876864282};\\\", \\\"{x:1156,y:868,t:1527876864299};\\\", \\\"{x:964,y:799,t:1527876864315};\\\", \\\"{x:748,y:729,t:1527876864333};\\\", \\\"{x:565,y:664,t:1527876864349};\\\", \\\"{x:392,y:587,t:1527876864366};\\\", \\\"{x:369,y:573,t:1527876864382};\\\", \\\"{x:368,y:572,t:1527876864462};\\\", \\\"{x:369,y:571,t:1527876864470};\\\", \\\"{x:370,y:568,t:1527876864482};\\\", \\\"{x:373,y:562,t:1527876864500};\\\", \\\"{x:377,y:555,t:1527876864516};\\\", \\\"{x:379,y:551,t:1527876864532};\\\", \\\"{x:380,y:549,t:1527876864550};\\\", \\\"{x:381,y:549,t:1527876864566};\\\", \\\"{x:383,y:549,t:1527876864582};\\\", \\\"{x:385,y:549,t:1527876864600};\\\", \\\"{x:386,y:549,t:1527876864615};\\\", \\\"{x:387,y:549,t:1527876864632};\\\", \\\"{x:388,y:549,t:1527876864654};\\\", \\\"{x:390,y:549,t:1527876864734};\\\", \\\"{x:400,y:549,t:1527876864750};\\\", \\\"{x:422,y:551,t:1527876864766};\\\", \\\"{x:450,y:551,t:1527876864782};\\\", \\\"{x:489,y:551,t:1527876864800};\\\", \\\"{x:537,y:551,t:1527876864816};\\\", \\\"{x:576,y:551,t:1527876864833};\\\", \\\"{x:603,y:551,t:1527876864850};\\\", \\\"{x:640,y:551,t:1527876864899};\\\", \\\"{x:643,y:551,t:1527876864916};\\\", \\\"{x:643,y:550,t:1527876864958};\\\", \\\"{x:644,y:550,t:1527876864967};\\\", \\\"{x:644,y:547,t:1527876864982};\\\", \\\"{x:644,y:545,t:1527876865000};\\\", \\\"{x:644,y:543,t:1527876865016};\\\", \\\"{x:644,y:542,t:1527876865033};\\\", \\\"{x:642,y:538,t:1527876865050};\\\", \\\"{x:639,y:537,t:1527876865067};\\\", \\\"{x:635,y:534,t:1527876865083};\\\", \\\"{x:632,y:534,t:1527876865100};\\\", \\\"{x:630,y:533,t:1527876865117};\\\", \\\"{x:628,y:531,t:1527876865133};\\\", \\\"{x:626,y:530,t:1527876865150};\\\", \\\"{x:624,y:530,t:1527876865182};\\\", \\\"{x:624,y:529,t:1527876865198};\\\", \\\"{x:624,y:528,t:1527876865206};\\\", \\\"{x:622,y:524,t:1527876865217};\\\", \\\"{x:620,y:517,t:1527876865234};\\\", \\\"{x:616,y:506,t:1527876865250};\\\", \\\"{x:615,y:499,t:1527876865267};\\\", \\\"{x:611,y:487,t:1527876865284};\\\", \\\"{x:610,y:483,t:1527876865300};\\\", \\\"{x:609,y:482,t:1527876865317};\\\", \\\"{x:607,y:483,t:1527876865550};\\\", \\\"{x:606,y:489,t:1527876865567};\\\", \\\"{x:605,y:494,t:1527876865584};\\\", \\\"{x:604,y:498,t:1527876865600};\\\", \\\"{x:604,y:499,t:1527876865622};\\\", \\\"{x:603,y:503,t:1527876865989};\\\", \\\"{x:599,y:515,t:1527876866000};\\\", \\\"{x:592,y:536,t:1527876866017};\\\", \\\"{x:583,y:557,t:1527876866034};\\\", \\\"{x:574,y:576,t:1527876866051};\\\", \\\"{x:566,y:592,t:1527876866067};\\\", \\\"{x:559,y:609,t:1527876866084};\\\", \\\"{x:553,y:625,t:1527876866101};\\\", \\\"{x:546,y:647,t:1527876866118};\\\", \\\"{x:545,y:658,t:1527876866134};\\\", \\\"{x:544,y:667,t:1527876866150};\\\", \\\"{x:544,y:671,t:1527876866167};\\\", \\\"{x:543,y:674,t:1527876866184};\\\", \\\"{x:543,y:676,t:1527876866206};\\\", \\\"{x:543,y:677,t:1527876866217};\\\", \\\"{x:543,y:680,t:1527876866234};\\\", \\\"{x:543,y:684,t:1527876866250};\\\", \\\"{x:544,y:690,t:1527876866268};\\\", \\\"{x:544,y:695,t:1527876866284};\\\", \\\"{x:545,y:699,t:1527876866300};\\\", \\\"{x:546,y:710,t:1527876866318};\\\", \\\"{x:546,y:714,t:1527876866333};\\\", \\\"{x:548,y:716,t:1527876866351};\\\", \\\"{x:550,y:719,t:1527876866368};\\\", \\\"{x:553,y:725,t:1527876866384};\\\", \\\"{x:557,y:734,t:1527876866401};\\\", \\\"{x:561,y:741,t:1527876866418};\\\", \\\"{x:563,y:747,t:1527876866435};\\\", \\\"{x:564,y:749,t:1527876866451};\\\", \\\"{x:564,y:748,t:1527876866926};\\\", \\\"{x:563,y:746,t:1527876866934};\\\", \\\"{x:560,y:743,t:1527876866952};\\\", \\\"{x:560,y:742,t:1527876866967};\\\", \\\"{x:559,y:740,t:1527876866985};\\\", \\\"{x:558,y:740,t:1527876867910};\\\", \\\"{x:557,y:739,t:1527876867925};\\\" ] }, { \\\"rt\\\": 13643, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 491395, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"2ZXKM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:557,y:735,t:1527876870408};\\\", \\\"{x:557,y:732,t:1527876870438};\\\", \\\"{x:557,y:731,t:1527876870454};\\\", \\\"{x:557,y:729,t:1527876870471};\\\", \\\"{x:557,y:728,t:1527876870502};\\\", \\\"{x:558,y:727,t:1527876870504};\\\", \\\"{x:558,y:726,t:1527876870525};\\\", \\\"{x:558,y:725,t:1527876870542};\\\", \\\"{x:558,y:724,t:1527876870565};\\\", \\\"{x:558,y:723,t:1527876870622};\\\", \\\"{x:558,y:722,t:1527876870678};\\\", \\\"{x:558,y:721,t:1527876870702};\\\", \\\"{x:558,y:720,t:1527876870710};\\\", \\\"{x:559,y:719,t:1527876870766};\\\", \\\"{x:559,y:713,t:1527876870891};\\\", \\\"{x:559,y:711,t:1527876870907};\\\", \\\"{x:557,y:700,t:1527876870921};\\\", \\\"{x:549,y:686,t:1527876870938};\\\", \\\"{x:532,y:661,t:1527876870954};\\\", \\\"{x:513,y:638,t:1527876870970};\\\", \\\"{x:496,y:621,t:1527876870989};\\\", \\\"{x:490,y:615,t:1527876871005};\\\", \\\"{x:489,y:613,t:1527876871021};\\\", \\\"{x:486,y:608,t:1527876871037};\\\", \\\"{x:481,y:600,t:1527876871055};\\\", \\\"{x:474,y:589,t:1527876871072};\\\", \\\"{x:466,y:575,t:1527876871088};\\\", \\\"{x:459,y:566,t:1527876871105};\\\", \\\"{x:450,y:553,t:1527876871121};\\\", \\\"{x:442,y:541,t:1527876871138};\\\", \\\"{x:441,y:540,t:1527876871155};\\\", \\\"{x:441,y:539,t:1527876873977};\\\", \\\"{x:446,y:534,t:1527876873993};\\\", \\\"{x:449,y:531,t:1527876874011};\\\", \\\"{x:456,y:527,t:1527876874027};\\\", \\\"{x:463,y:525,t:1527876874044};\\\", \\\"{x:466,y:523,t:1527876874061};\\\", \\\"{x:470,y:520,t:1527876874078};\\\", \\\"{x:472,y:520,t:1527876874094};\\\", \\\"{x:473,y:520,t:1527876874111};\\\", \\\"{x:477,y:516,t:1527876874128};\\\", \\\"{x:483,y:508,t:1527876874144};\\\", \\\"{x:489,y:501,t:1527876874160};\\\", \\\"{x:502,y:488,t:1527876874178};\\\", \\\"{x:514,y:476,t:1527876874194};\\\", \\\"{x:530,y:465,t:1527876874210};\\\", \\\"{x:551,y:454,t:1527876874227};\\\", \\\"{x:588,y:440,t:1527876874243};\\\", \\\"{x:665,y:422,t:1527876874261};\\\", \\\"{x:776,y:406,t:1527876874278};\\\", \\\"{x:927,y:395,t:1527876874294};\\\", \\\"{x:1076,y:395,t:1527876874311};\\\", \\\"{x:1227,y:403,t:1527876874328};\\\", \\\"{x:1360,y:422,t:1527876874345};\\\", \\\"{x:1457,y:437,t:1527876874361};\\\", \\\"{x:1524,y:447,t:1527876874378};\\\", \\\"{x:1533,y:451,t:1527876874394};\\\", \\\"{x:1534,y:452,t:1527876874411};\\\", \\\"{x:1533,y:460,t:1527876874428};\\\", \\\"{x:1518,y:481,t:1527876874445};\\\", \\\"{x:1475,y:524,t:1527876874461};\\\", \\\"{x:1406,y:583,t:1527876874478};\\\", \\\"{x:1311,y:655,t:1527876874494};\\\", \\\"{x:1208,y:729,t:1527876874510};\\\", \\\"{x:1113,y:797,t:1527876874528};\\\", \\\"{x:1045,y:834,t:1527876874545};\\\", \\\"{x:1005,y:848,t:1527876874560};\\\", \\\"{x:959,y:856,t:1527876874577};\\\", \\\"{x:936,y:860,t:1527876874594};\\\", \\\"{x:926,y:860,t:1527876874610};\\\", \\\"{x:922,y:860,t:1527876874627};\\\", \\\"{x:921,y:858,t:1527876874673};\\\", \\\"{x:921,y:851,t:1527876874681};\\\", \\\"{x:923,y:843,t:1527876874695};\\\", \\\"{x:928,y:824,t:1527876874711};\\\", \\\"{x:934,y:803,t:1527876874727};\\\", \\\"{x:940,y:785,t:1527876874744};\\\", \\\"{x:944,y:769,t:1527876874761};\\\", \\\"{x:954,y:747,t:1527876874778};\\\", \\\"{x:959,y:739,t:1527876874795};\\\", \\\"{x:963,y:733,t:1527876874812};\\\", \\\"{x:965,y:730,t:1527876874828};\\\", \\\"{x:973,y:724,t:1527876874844};\\\", \\\"{x:988,y:715,t:1527876874862};\\\", \\\"{x:1017,y:703,t:1527876874878};\\\", \\\"{x:1072,y:690,t:1527876874895};\\\", \\\"{x:1107,y:682,t:1527876874912};\\\", \\\"{x:1132,y:678,t:1527876874928};\\\", \\\"{x:1147,y:673,t:1527876874945};\\\", \\\"{x:1164,y:668,t:1527876874961};\\\", \\\"{x:1181,y:665,t:1527876874977};\\\", \\\"{x:1191,y:662,t:1527876874994};\\\", \\\"{x:1205,y:661,t:1527876875011};\\\", \\\"{x:1213,y:658,t:1527876875027};\\\", \\\"{x:1215,y:658,t:1527876875044};\\\", \\\"{x:1216,y:658,t:1527876875074};\\\", \\\"{x:1216,y:659,t:1527876875138};\\\", \\\"{x:1216,y:662,t:1527876875145};\\\", \\\"{x:1214,y:667,t:1527876875161};\\\", \\\"{x:1212,y:673,t:1527876875178};\\\", \\\"{x:1211,y:676,t:1527876875195};\\\", \\\"{x:1210,y:678,t:1527876875211};\\\", \\\"{x:1210,y:679,t:1527876875228};\\\", \\\"{x:1210,y:681,t:1527876875245};\\\", \\\"{x:1210,y:683,t:1527876875338};\\\", \\\"{x:1210,y:684,t:1527876875386};\\\", \\\"{x:1210,y:686,t:1527876875394};\\\", \\\"{x:1210,y:688,t:1527876875442};\\\", \\\"{x:1213,y:688,t:1527876875449};\\\", \\\"{x:1220,y:688,t:1527876875462};\\\", \\\"{x:1245,y:688,t:1527876875479};\\\", \\\"{x:1279,y:684,t:1527876875495};\\\", \\\"{x:1317,y:672,t:1527876875512};\\\", \\\"{x:1347,y:664,t:1527876875529};\\\", \\\"{x:1380,y:659,t:1527876875544};\\\", \\\"{x:1420,y:657,t:1527876875561};\\\", \\\"{x:1437,y:657,t:1527876875579};\\\", \\\"{x:1443,y:656,t:1527876875595};\\\", \\\"{x:1443,y:657,t:1527876875690};\\\", \\\"{x:1443,y:658,t:1527876875697};\\\", \\\"{x:1440,y:664,t:1527876875712};\\\", \\\"{x:1422,y:686,t:1527876875728};\\\", \\\"{x:1378,y:730,t:1527876875745};\\\", \\\"{x:1346,y:761,t:1527876875762};\\\", \\\"{x:1325,y:784,t:1527876875779};\\\", \\\"{x:1312,y:799,t:1527876875796};\\\", \\\"{x:1305,y:811,t:1527876875812};\\\", \\\"{x:1300,y:820,t:1527876875829};\\\", \\\"{x:1298,y:825,t:1527876875846};\\\", \\\"{x:1298,y:833,t:1527876875862};\\\", \\\"{x:1298,y:840,t:1527876875879};\\\", \\\"{x:1298,y:849,t:1527876875896};\\\", \\\"{x:1298,y:853,t:1527876875911};\\\", \\\"{x:1302,y:861,t:1527876875929};\\\", \\\"{x:1309,y:878,t:1527876875945};\\\", \\\"{x:1320,y:893,t:1527876875962};\\\", \\\"{x:1330,y:907,t:1527876875979};\\\", \\\"{x:1342,y:919,t:1527876875996};\\\", \\\"{x:1346,y:924,t:1527876876012};\\\", \\\"{x:1350,y:928,t:1527876876029};\\\", \\\"{x:1356,y:937,t:1527876876046};\\\", \\\"{x:1360,y:946,t:1527876876063};\\\", \\\"{x:1363,y:951,t:1527876876078};\\\", \\\"{x:1366,y:956,t:1527876876095};\\\", \\\"{x:1367,y:958,t:1527876876113};\\\", \\\"{x:1367,y:960,t:1527876876130};\\\", \\\"{x:1367,y:961,t:1527876876161};\\\", \\\"{x:1367,y:963,t:1527876876185};\\\", \\\"{x:1365,y:965,t:1527876876313};\\\", \\\"{x:1363,y:965,t:1527876876337};\\\", \\\"{x:1362,y:965,t:1527876876346};\\\", \\\"{x:1361,y:965,t:1527876876363};\\\", \\\"{x:1358,y:967,t:1527876876379};\\\", \\\"{x:1357,y:967,t:1527876876401};\\\", \\\"{x:1356,y:967,t:1527876876450};\\\", \\\"{x:1355,y:967,t:1527876876466};\\\", \\\"{x:1355,y:966,t:1527876876834};\\\", \\\"{x:1355,y:965,t:1527876876845};\\\", \\\"{x:1355,y:963,t:1527876876863};\\\", \\\"{x:1356,y:961,t:1527876876880};\\\", \\\"{x:1356,y:960,t:1527876876896};\\\", \\\"{x:1356,y:959,t:1527876876937};\\\", \\\"{x:1356,y:958,t:1527876876953};\\\", \\\"{x:1357,y:957,t:1527876876963};\\\", \\\"{x:1357,y:956,t:1527876876986};\\\", \\\"{x:1358,y:955,t:1527876876997};\\\", \\\"{x:1358,y:954,t:1527876877013};\\\", \\\"{x:1359,y:951,t:1527876877030};\\\", \\\"{x:1359,y:949,t:1527876877047};\\\", \\\"{x:1360,y:948,t:1527876877063};\\\", \\\"{x:1361,y:947,t:1527876877080};\\\", \\\"{x:1361,y:946,t:1527876877096};\\\", \\\"{x:1362,y:945,t:1527876877113};\\\", \\\"{x:1363,y:941,t:1527876877129};\\\", \\\"{x:1365,y:938,t:1527876877147};\\\", \\\"{x:1366,y:937,t:1527876877163};\\\", \\\"{x:1366,y:936,t:1527876877180};\\\", \\\"{x:1367,y:935,t:1527876877197};\\\", \\\"{x:1367,y:934,t:1527876877233};\\\", \\\"{x:1368,y:932,t:1527876877249};\\\", \\\"{x:1366,y:931,t:1527876877610};\\\", \\\"{x:1363,y:931,t:1527876877618};\\\", \\\"{x:1360,y:931,t:1527876877630};\\\", \\\"{x:1352,y:929,t:1527876877647};\\\", \\\"{x:1339,y:927,t:1527876877663};\\\", \\\"{x:1325,y:922,t:1527876877680};\\\", \\\"{x:1302,y:915,t:1527876877696};\\\", \\\"{x:1220,y:891,t:1527876877713};\\\", \\\"{x:1131,y:864,t:1527876877729};\\\", \\\"{x:1026,y:831,t:1527876877747};\\\", \\\"{x:896,y:777,t:1527876877763};\\\", \\\"{x:768,y:728,t:1527876877780};\\\", \\\"{x:679,y:691,t:1527876877796};\\\", \\\"{x:627,y:669,t:1527876877814};\\\", \\\"{x:601,y:654,t:1527876877830};\\\", \\\"{x:593,y:648,t:1527876877847};\\\", \\\"{x:590,y:646,t:1527876877864};\\\", \\\"{x:587,y:642,t:1527876877897};\\\", \\\"{x:578,y:631,t:1527876877914};\\\", \\\"{x:571,y:622,t:1527876877931};\\\", \\\"{x:566,y:618,t:1527876877946};\\\", \\\"{x:562,y:615,t:1527876877963};\\\", \\\"{x:558,y:612,t:1527876877981};\\\", \\\"{x:558,y:611,t:1527876877998};\\\", \\\"{x:558,y:610,t:1527876878014};\\\", \\\"{x:556,y:609,t:1527876878030};\\\", \\\"{x:553,y:605,t:1527876878047};\\\", \\\"{x:542,y:595,t:1527876878064};\\\", \\\"{x:523,y:586,t:1527876878081};\\\", \\\"{x:506,y:579,t:1527876878097};\\\", \\\"{x:478,y:572,t:1527876878114};\\\", \\\"{x:468,y:570,t:1527876878131};\\\", \\\"{x:467,y:570,t:1527876878147};\\\", \\\"{x:466,y:570,t:1527876878169};\\\", \\\"{x:463,y:569,t:1527876878193};\\\", \\\"{x:458,y:568,t:1527876878201};\\\", \\\"{x:451,y:565,t:1527876878214};\\\", \\\"{x:436,y:563,t:1527876878231};\\\", \\\"{x:424,y:563,t:1527876878248};\\\", \\\"{x:413,y:563,t:1527876878263};\\\", \\\"{x:400,y:565,t:1527876878281};\\\", \\\"{x:391,y:567,t:1527876878298};\\\", \\\"{x:389,y:569,t:1527876878314};\\\", \\\"{x:388,y:569,t:1527876878331};\\\", \\\"{x:387,y:566,t:1527876878538};\\\", \\\"{x:387,y:563,t:1527876878548};\\\", \\\"{x:387,y:561,t:1527876878566};\\\", \\\"{x:387,y:559,t:1527876878581};\\\", \\\"{x:387,y:558,t:1527876878609};\\\", \\\"{x:387,y:557,t:1527876878641};\\\", \\\"{x:387,y:556,t:1527876878769};\\\", \\\"{x:387,y:555,t:1527876878781};\\\", \\\"{x:387,y:551,t:1527876878798};\\\", \\\"{x:387,y:550,t:1527876878815};\\\", \\\"{x:387,y:549,t:1527876878833};\\\", \\\"{x:387,y:547,t:1527876878857};\\\", \\\"{x:387,y:546,t:1527876878873};\\\", \\\"{x:387,y:544,t:1527876878914};\\\", \\\"{x:386,y:543,t:1527876880410};\\\", \\\"{x:385,y:543,t:1527876880417};\\\", \\\"{x:383,y:548,t:1527876880433};\\\", \\\"{x:381,y:552,t:1527876880450};\\\", \\\"{x:381,y:553,t:1527876880466};\\\", \\\"{x:381,y:554,t:1527876880553};\\\", \\\"{x:381,y:556,t:1527876880569};\\\", \\\"{x:381,y:558,t:1527876880583};\\\", \\\"{x:383,y:559,t:1527876880599};\\\", \\\"{x:384,y:561,t:1527876880616};\\\", \\\"{x:391,y:563,t:1527876880634};\\\", \\\"{x:396,y:565,t:1527876880649};\\\", \\\"{x:402,y:566,t:1527876880666};\\\", \\\"{x:406,y:567,t:1527876880683};\\\", \\\"{x:407,y:568,t:1527876880699};\\\", \\\"{x:408,y:568,t:1527876880716};\\\", \\\"{x:409,y:568,t:1527876880732};\\\", \\\"{x:409,y:569,t:1527876880749};\\\", \\\"{x:410,y:569,t:1527876880765};\\\", \\\"{x:413,y:570,t:1527876880783};\\\", \\\"{x:414,y:571,t:1527876880817};\\\", \\\"{x:420,y:571,t:1527876881137};\\\", \\\"{x:443,y:572,t:1527876881150};\\\", \\\"{x:489,y:574,t:1527876881165};\\\", \\\"{x:523,y:580,t:1527876881183};\\\", \\\"{x:563,y:587,t:1527876881199};\\\", \\\"{x:585,y:590,t:1527876881216};\\\", \\\"{x:597,y:592,t:1527876881233};\\\", \\\"{x:598,y:592,t:1527876881337};\\\", \\\"{x:600,y:592,t:1527876881349};\\\", \\\"{x:601,y:592,t:1527876881366};\\\", \\\"{x:602,y:592,t:1527876881382};\\\", \\\"{x:603,y:592,t:1527876881399};\\\", \\\"{x:605,y:592,t:1527876881416};\\\", \\\"{x:610,y:592,t:1527876881433};\\\", \\\"{x:616,y:592,t:1527876881450};\\\", \\\"{x:621,y:591,t:1527876881467};\\\", \\\"{x:626,y:590,t:1527876881482};\\\", \\\"{x:628,y:590,t:1527876881500};\\\", \\\"{x:630,y:589,t:1527876881517};\\\", \\\"{x:633,y:589,t:1527876881533};\\\", \\\"{x:625,y:591,t:1527876881602};\\\", \\\"{x:573,y:610,t:1527876881618};\\\", \\\"{x:486,y:629,t:1527876881634};\\\", \\\"{x:382,y:635,t:1527876881650};\\\", \\\"{x:301,y:635,t:1527876881666};\\\", \\\"{x:229,y:626,t:1527876881684};\\\", \\\"{x:189,y:619,t:1527876881700};\\\", \\\"{x:177,y:616,t:1527876881717};\\\", \\\"{x:174,y:614,t:1527876881734};\\\", \\\"{x:173,y:613,t:1527876881897};\\\", \\\"{x:176,y:608,t:1527876881905};\\\", \\\"{x:180,y:604,t:1527876881917};\\\", \\\"{x:185,y:589,t:1527876881934};\\\", \\\"{x:187,y:575,t:1527876881950};\\\", \\\"{x:187,y:570,t:1527876881967};\\\", \\\"{x:188,y:564,t:1527876881984};\\\", \\\"{x:188,y:563,t:1527876882001};\\\", \\\"{x:189,y:563,t:1527876882073};\\\", \\\"{x:190,y:563,t:1527876882083};\\\", \\\"{x:190,y:577,t:1527876882100};\\\", \\\"{x:190,y:590,t:1527876882117};\\\", \\\"{x:190,y:600,t:1527876882135};\\\", \\\"{x:193,y:611,t:1527876882151};\\\", \\\"{x:194,y:624,t:1527876882167};\\\", \\\"{x:201,y:639,t:1527876882184};\\\", \\\"{x:208,y:649,t:1527876882201};\\\", \\\"{x:209,y:650,t:1527876882217};\\\", \\\"{x:213,y:650,t:1527876882233};\\\", \\\"{x:223,y:650,t:1527876882251};\\\", \\\"{x:239,y:640,t:1527876882267};\\\", \\\"{x:258,y:631,t:1527876882284};\\\", \\\"{x:278,y:625,t:1527876882301};\\\", \\\"{x:305,y:621,t:1527876882317};\\\", \\\"{x:324,y:620,t:1527876882333};\\\", \\\"{x:336,y:620,t:1527876882351};\\\", \\\"{x:340,y:619,t:1527876882367};\\\", \\\"{x:344,y:618,t:1527876882384};\\\", \\\"{x:350,y:616,t:1527876882401};\\\", \\\"{x:351,y:615,t:1527876882417};\\\", \\\"{x:352,y:615,t:1527876882665};\\\", \\\"{x:353,y:615,t:1527876882673};\\\", \\\"{x:354,y:615,t:1527876882688};\\\", \\\"{x:355,y:615,t:1527876882841};\\\", \\\"{x:356,y:615,t:1527876882849};\\\", \\\"{x:358,y:613,t:1527876882867};\\\", \\\"{x:359,y:613,t:1527876882889};\\\", \\\"{x:360,y:613,t:1527876882900};\\\", \\\"{x:361,y:612,t:1527876882917};\\\", \\\"{x:367,y:612,t:1527876882934};\\\", \\\"{x:372,y:612,t:1527876882950};\\\", \\\"{x:378,y:612,t:1527876882968};\\\", \\\"{x:382,y:612,t:1527876882984};\\\", \\\"{x:389,y:611,t:1527876883001};\\\", \\\"{x:392,y:610,t:1527876883018};\\\", \\\"{x:393,y:610,t:1527876883401};\\\", \\\"{x:396,y:622,t:1527876883418};\\\", \\\"{x:403,y:644,t:1527876883436};\\\", \\\"{x:415,y:671,t:1527876883452};\\\", \\\"{x:433,y:694,t:1527876883468};\\\", \\\"{x:445,y:705,t:1527876883484};\\\", \\\"{x:453,y:710,t:1527876883502};\\\", \\\"{x:458,y:713,t:1527876883517};\\\", \\\"{x:460,y:714,t:1527876883535};\\\", \\\"{x:461,y:714,t:1527876883552};\\\", \\\"{x:462,y:714,t:1527876883593};\\\", \\\"{x:464,y:714,t:1527876883601};\\\", \\\"{x:467,y:714,t:1527876883618};\\\", \\\"{x:470,y:714,t:1527876883635};\\\", \\\"{x:471,y:714,t:1527876883652};\\\", \\\"{x:473,y:714,t:1527876883745};\\\", \\\"{x:474,y:717,t:1527876883753};\\\", \\\"{x:475,y:722,t:1527876883768};\\\", \\\"{x:481,y:734,t:1527876883785};\\\", \\\"{x:484,y:738,t:1527876883802};\\\", \\\"{x:485,y:739,t:1527876883849};\\\", \\\"{x:482,y:736,t:1527876884449};\\\", \\\"{x:479,y:730,t:1527876884457};\\\", \\\"{x:474,y:722,t:1527876884469};\\\", \\\"{x:461,y:706,t:1527876884485};\\\", \\\"{x:432,y:680,t:1527876884502};\\\", \\\"{x:388,y:639,t:1527876884519};\\\", \\\"{x:341,y:600,t:1527876884535};\\\", \\\"{x:289,y:555,t:1527876884552};\\\", \\\"{x:197,y:476,t:1527876884569};\\\", \\\"{x:123,y:418,t:1527876884585};\\\", \\\"{x:44,y:354,t:1527876884602};\\\", \\\"{x:0,y:304,t:1527876884619};\\\", \\\"{x:0,y:276,t:1527876884635};\\\", \\\"{x:0,y:254,t:1527876884651};\\\", \\\"{x:0,y:242,t:1527876884669};\\\", \\\"{x:0,y:239,t:1527876884686};\\\", \\\"{x:0,y:238,t:1527876884702};\\\", \\\"{x:0,y:239,t:1527876884897};\\\", \\\"{x:10,y:248,t:1527876884904};\\\", \\\"{x:41,y:270,t:1527876884919};\\\", \\\"{x:120,y:329,t:1527876884935};\\\", \\\"{x:220,y:398,t:1527876884952};\\\", \\\"{x:435,y:539,t:1527876884969};\\\", \\\"{x:583,y:629,t:1527876884986};\\\", \\\"{x:736,y:705,t:1527876885003};\\\", \\\"{x:914,y:776,t:1527876885019};\\\", \\\"{x:1094,y:856,t:1527876885036};\\\", \\\"{x:1270,y:930,t:1527876885053};\\\", \\\"{x:1447,y:1019,t:1527876885069};\\\", \\\"{x:1576,y:1073,t:1527876885086};\\\", \\\"{x:1648,y:1107,t:1527876885102};\\\", \\\"{x:1684,y:1122,t:1527876885119};\\\", \\\"{x:1696,y:1127,t:1527876885136};\\\" ] }, { \\\"rt\\\": 9311, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 501931, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"2ZXKM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-O -B -10 AM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1395,y:752,t:1527876885276};\\\", \\\"{x:1203,y:639,t:1527876885304};\\\", \\\"{x:1074,y:583,t:1527876885320};\\\", \\\"{x:969,y:542,t:1527876885336};\\\", \\\"{x:893,y:518,t:1527876885352};\\\", \\\"{x:888,y:517,t:1527876885373};\\\", \\\"{x:862,y:498,t:1527876885726};\\\", \\\"{x:850,y:494,t:1527876885740};\\\", \\\"{x:848,y:494,t:1527876885753};\\\", \\\"{x:842,y:493,t:1527876885770};\\\", \\\"{x:832,y:493,t:1527876885787};\\\", \\\"{x:823,y:493,t:1527876885803};\\\", \\\"{x:817,y:494,t:1527876885820};\\\", \\\"{x:812,y:495,t:1527876885837};\\\", \\\"{x:809,y:498,t:1527876885852};\\\", \\\"{x:806,y:506,t:1527876885870};\\\", \\\"{x:803,y:519,t:1527876885888};\\\", \\\"{x:802,y:531,t:1527876885904};\\\", \\\"{x:801,y:545,t:1527876885921};\\\", \\\"{x:801,y:554,t:1527876885936};\\\", \\\"{x:801,y:557,t:1527876885953};\\\", \\\"{x:801,y:559,t:1527876885970};\\\", \\\"{x:801,y:560,t:1527876886048};\\\", \\\"{x:798,y:555,t:1527876886385};\\\", \\\"{x:791,y:543,t:1527876886403};\\\", \\\"{x:787,y:538,t:1527876886420};\\\", \\\"{x:786,y:536,t:1527876886437};\\\", \\\"{x:785,y:535,t:1527876886455};\\\", \\\"{x:784,y:533,t:1527876886471};\\\", \\\"{x:790,y:533,t:1527876886609};\\\", \\\"{x:806,y:538,t:1527876886620};\\\", \\\"{x:857,y:556,t:1527876886637};\\\", \\\"{x:913,y:572,t:1527876886654};\\\", \\\"{x:960,y:584,t:1527876886671};\\\", \\\"{x:1000,y:591,t:1527876886687};\\\", \\\"{x:1029,y:592,t:1527876886704};\\\", \\\"{x:1065,y:592,t:1527876886720};\\\", \\\"{x:1082,y:596,t:1527876886737};\\\", \\\"{x:1097,y:601,t:1527876886754};\\\", \\\"{x:1105,y:607,t:1527876886771};\\\", \\\"{x:1112,y:615,t:1527876886787};\\\", \\\"{x:1118,y:621,t:1527876886804};\\\", \\\"{x:1121,y:626,t:1527876886821};\\\", \\\"{x:1122,y:628,t:1527876886837};\\\", \\\"{x:1125,y:630,t:1527876886854};\\\", \\\"{x:1133,y:638,t:1527876886871};\\\", \\\"{x:1154,y:654,t:1527876886888};\\\", \\\"{x:1193,y:677,t:1527876886904};\\\", \\\"{x:1269,y:718,t:1527876886921};\\\", \\\"{x:1307,y:732,t:1527876886938};\\\", \\\"{x:1335,y:737,t:1527876886954};\\\", \\\"{x:1369,y:742,t:1527876886971};\\\", \\\"{x:1419,y:750,t:1527876886988};\\\", \\\"{x:1486,y:758,t:1527876887004};\\\", \\\"{x:1535,y:767,t:1527876887021};\\\", \\\"{x:1550,y:767,t:1527876887038};\\\", \\\"{x:1557,y:764,t:1527876887054};\\\", \\\"{x:1559,y:764,t:1527876887071};\\\", \\\"{x:1559,y:763,t:1527876887089};\\\", \\\"{x:1559,y:762,t:1527876887104};\\\", \\\"{x:1535,y:751,t:1527876887121};\\\", \\\"{x:1510,y:745,t:1527876887138};\\\", \\\"{x:1481,y:740,t:1527876887155};\\\", \\\"{x:1459,y:739,t:1527876887171};\\\", \\\"{x:1446,y:739,t:1527876887188};\\\", \\\"{x:1430,y:744,t:1527876887204};\\\", \\\"{x:1419,y:747,t:1527876887221};\\\", \\\"{x:1413,y:750,t:1527876887238};\\\", \\\"{x:1411,y:750,t:1527876887254};\\\", \\\"{x:1409,y:750,t:1527876887361};\\\", \\\"{x:1407,y:745,t:1527876887371};\\\", \\\"{x:1401,y:731,t:1527876887388};\\\", \\\"{x:1393,y:718,t:1527876887403};\\\", \\\"{x:1386,y:711,t:1527876887421};\\\", \\\"{x:1384,y:709,t:1527876887438};\\\", \\\"{x:1380,y:709,t:1527876887521};\\\", \\\"{x:1365,y:725,t:1527876887537};\\\", \\\"{x:1350,y:748,t:1527876887555};\\\", \\\"{x:1334,y:770,t:1527876887571};\\\", \\\"{x:1318,y:792,t:1527876887588};\\\", \\\"{x:1305,y:809,t:1527876887605};\\\", \\\"{x:1295,y:826,t:1527876887621};\\\", \\\"{x:1288,y:840,t:1527876887638};\\\", \\\"{x:1283,y:856,t:1527876887655};\\\", \\\"{x:1275,y:875,t:1527876887671};\\\", \\\"{x:1272,y:888,t:1527876887688};\\\", \\\"{x:1264,y:903,t:1527876887704};\\\", \\\"{x:1259,y:912,t:1527876887721};\\\", \\\"{x:1256,y:917,t:1527876887738};\\\", \\\"{x:1254,y:920,t:1527876887754};\\\", \\\"{x:1253,y:922,t:1527876887771};\\\", \\\"{x:1252,y:922,t:1527876887788};\\\", \\\"{x:1251,y:924,t:1527876887805};\\\", \\\"{x:1249,y:927,t:1527876887821};\\\", \\\"{x:1248,y:930,t:1527876887838};\\\", \\\"{x:1246,y:932,t:1527876887855};\\\", \\\"{x:1243,y:935,t:1527876887870};\\\", \\\"{x:1240,y:938,t:1527876887888};\\\", \\\"{x:1237,y:941,t:1527876887905};\\\", \\\"{x:1233,y:944,t:1527876887921};\\\", \\\"{x:1223,y:954,t:1527876887938};\\\", \\\"{x:1201,y:971,t:1527876887955};\\\", \\\"{x:1172,y:992,t:1527876887971};\\\", \\\"{x:1139,y:1011,t:1527876887988};\\\", \\\"{x:1113,y:1028,t:1527876888005};\\\", \\\"{x:1096,y:1036,t:1527876888021};\\\", \\\"{x:1088,y:1040,t:1527876888038};\\\", \\\"{x:1083,y:1042,t:1527876888055};\\\", \\\"{x:1083,y:1040,t:1527876888257};\\\", \\\"{x:1085,y:1037,t:1527876888272};\\\", \\\"{x:1089,y:1032,t:1527876888287};\\\", \\\"{x:1093,y:1025,t:1527876888305};\\\", \\\"{x:1096,y:1021,t:1527876888322};\\\", \\\"{x:1097,y:1017,t:1527876888338};\\\", \\\"{x:1099,y:1014,t:1527876888355};\\\", \\\"{x:1100,y:1012,t:1527876888372};\\\", \\\"{x:1103,y:1007,t:1527876888388};\\\", \\\"{x:1104,y:1005,t:1527876888405};\\\", \\\"{x:1105,y:999,t:1527876888422};\\\", \\\"{x:1106,y:994,t:1527876888438};\\\", \\\"{x:1108,y:991,t:1527876888455};\\\", \\\"{x:1108,y:986,t:1527876888472};\\\", \\\"{x:1110,y:983,t:1527876888488};\\\", \\\"{x:1111,y:981,t:1527876888505};\\\", \\\"{x:1111,y:980,t:1527876888529};\\\", \\\"{x:1111,y:979,t:1527876888537};\\\", \\\"{x:1112,y:977,t:1527876888555};\\\", \\\"{x:1114,y:974,t:1527876888571};\\\", \\\"{x:1114,y:973,t:1527876888589};\\\", \\\"{x:1114,y:971,t:1527876888605};\\\", \\\"{x:1114,y:968,t:1527876888622};\\\", \\\"{x:1114,y:964,t:1527876888638};\\\", \\\"{x:1115,y:960,t:1527876888655};\\\", \\\"{x:1115,y:958,t:1527876888672};\\\", \\\"{x:1115,y:956,t:1527876888689};\\\", \\\"{x:1115,y:955,t:1527876888712};\\\", \\\"{x:1117,y:951,t:1527876889521};\\\", \\\"{x:1117,y:944,t:1527876889529};\\\", \\\"{x:1118,y:941,t:1527876889539};\\\", \\\"{x:1119,y:932,t:1527876889556};\\\", \\\"{x:1120,y:923,t:1527876889572};\\\", \\\"{x:1121,y:920,t:1527876889589};\\\", \\\"{x:1121,y:918,t:1527876889606};\\\", \\\"{x:1121,y:917,t:1527876889622};\\\", \\\"{x:1121,y:916,t:1527876889657};\\\", \\\"{x:1119,y:914,t:1527876889761};\\\", \\\"{x:1118,y:912,t:1527876889773};\\\", \\\"{x:1112,y:903,t:1527876889789};\\\", \\\"{x:1099,y:889,t:1527876889806};\\\", \\\"{x:1081,y:875,t:1527876889823};\\\", \\\"{x:1057,y:858,t:1527876889839};\\\", \\\"{x:1036,y:845,t:1527876889856};\\\", \\\"{x:980,y:812,t:1527876889873};\\\", \\\"{x:932,y:788,t:1527876889889};\\\", \\\"{x:889,y:764,t:1527876889905};\\\", \\\"{x:848,y:741,t:1527876889923};\\\", \\\"{x:813,y:722,t:1527876889939};\\\", \\\"{x:778,y:700,t:1527876889956};\\\", \\\"{x:751,y:688,t:1527876889973};\\\", \\\"{x:725,y:679,t:1527876889989};\\\", \\\"{x:708,y:677,t:1527876890006};\\\", \\\"{x:699,y:676,t:1527876890023};\\\", \\\"{x:697,y:676,t:1527876890039};\\\", \\\"{x:696,y:676,t:1527876890056};\\\", \\\"{x:684,y:674,t:1527876890073};\\\", \\\"{x:669,y:671,t:1527876890089};\\\", \\\"{x:650,y:670,t:1527876890106};\\\", \\\"{x:630,y:669,t:1527876890123};\\\", \\\"{x:609,y:666,t:1527876890139};\\\", \\\"{x:591,y:664,t:1527876890156};\\\", \\\"{x:573,y:660,t:1527876890174};\\\", \\\"{x:561,y:658,t:1527876890189};\\\", \\\"{x:543,y:658,t:1527876890206};\\\", \\\"{x:516,y:656,t:1527876890223};\\\", \\\"{x:485,y:656,t:1527876890240};\\\", \\\"{x:459,y:656,t:1527876890256};\\\", \\\"{x:442,y:656,t:1527876890273};\\\", \\\"{x:437,y:656,t:1527876890290};\\\", \\\"{x:434,y:656,t:1527876890307};\\\", \\\"{x:431,y:656,t:1527876890324};\\\", \\\"{x:427,y:656,t:1527876890340};\\\", \\\"{x:424,y:656,t:1527876890356};\\\", \\\"{x:421,y:656,t:1527876890374};\\\", \\\"{x:420,y:656,t:1527876890393};\\\", \\\"{x:419,y:660,t:1527876890672};\\\", \\\"{x:419,y:667,t:1527876890680};\\\", \\\"{x:419,y:675,t:1527876890691};\\\", \\\"{x:425,y:695,t:1527876890707};\\\", \\\"{x:430,y:713,t:1527876890724};\\\", \\\"{x:436,y:732,t:1527876890740};\\\", \\\"{x:440,y:745,t:1527876890757};\\\", \\\"{x:440,y:752,t:1527876890774};\\\", \\\"{x:440,y:756,t:1527876890791};\\\", \\\"{x:440,y:759,t:1527876890807};\\\", \\\"{x:440,y:761,t:1527876890825};\\\", \\\"{x:440,y:762,t:1527876890841};\\\", \\\"{x:440,y:764,t:1527876890857};\\\", \\\"{x:440,y:757,t:1527876890945};\\\", \\\"{x:441,y:748,t:1527876890957};\\\", \\\"{x:444,y:726,t:1527876890974};\\\", \\\"{x:444,y:711,t:1527876890991};\\\", \\\"{x:444,y:695,t:1527876891007};\\\", \\\"{x:444,y:678,t:1527876891024};\\\", \\\"{x:443,y:658,t:1527876891041};\\\", \\\"{x:442,y:655,t:1527876891057};\\\", \\\"{x:441,y:653,t:1527876891074};\\\", \\\"{x:440,y:651,t:1527876891091};\\\", \\\"{x:440,y:650,t:1527876891169};\\\", \\\"{x:442,y:645,t:1527876891177};\\\", \\\"{x:446,y:638,t:1527876891191};\\\", \\\"{x:457,y:620,t:1527876891208};\\\", \\\"{x:469,y:601,t:1527876891224};\\\", \\\"{x:489,y:576,t:1527876891241};\\\", \\\"{x:507,y:562,t:1527876891258};\\\", \\\"{x:527,y:549,t:1527876891275};\\\", \\\"{x:538,y:544,t:1527876891291};\\\", \\\"{x:530,y:544,t:1527876891361};\\\", \\\"{x:517,y:540,t:1527876891374};\\\", \\\"{x:491,y:538,t:1527876891392};\\\", \\\"{x:465,y:538,t:1527876891408};\\\", \\\"{x:438,y:536,t:1527876891424};\\\", \\\"{x:382,y:530,t:1527876891441};\\\", \\\"{x:338,y:525,t:1527876891457};\\\", \\\"{x:310,y:522,t:1527876891475};\\\", \\\"{x:295,y:521,t:1527876891492};\\\", \\\"{x:290,y:521,t:1527876891508};\\\", \\\"{x:289,y:521,t:1527876891524};\\\", \\\"{x:287,y:522,t:1527876891570};\\\", \\\"{x:285,y:524,t:1527876891584};\\\", \\\"{x:284,y:525,t:1527876891593};\\\", \\\"{x:282,y:527,t:1527876891608};\\\", \\\"{x:278,y:531,t:1527876891624};\\\", \\\"{x:275,y:538,t:1527876891641};\\\", \\\"{x:271,y:543,t:1527876891659};\\\", \\\"{x:270,y:547,t:1527876891675};\\\", \\\"{x:267,y:550,t:1527876891691};\\\", \\\"{x:266,y:555,t:1527876891708};\\\", \\\"{x:264,y:557,t:1527876891726};\\\", \\\"{x:263,y:562,t:1527876891741};\\\", \\\"{x:261,y:565,t:1527876891758};\\\", \\\"{x:260,y:571,t:1527876891775};\\\", \\\"{x:259,y:577,t:1527876891791};\\\", \\\"{x:259,y:580,t:1527876891808};\\\", \\\"{x:259,y:586,t:1527876891825};\\\", \\\"{x:263,y:591,t:1527876891841};\\\", \\\"{x:271,y:594,t:1527876891858};\\\", \\\"{x:286,y:597,t:1527876891875};\\\", \\\"{x:310,y:600,t:1527876891891};\\\", \\\"{x:329,y:603,t:1527876891909};\\\", \\\"{x:342,y:605,t:1527876891925};\\\", \\\"{x:354,y:608,t:1527876891941};\\\", \\\"{x:369,y:610,t:1527876891958};\\\", \\\"{x:386,y:613,t:1527876891975};\\\", \\\"{x:398,y:614,t:1527876891991};\\\", \\\"{x:407,y:615,t:1527876892008};\\\", \\\"{x:414,y:616,t:1527876892024};\\\", \\\"{x:419,y:616,t:1527876892042};\\\", \\\"{x:429,y:616,t:1527876892059};\\\", \\\"{x:444,y:618,t:1527876892075};\\\", \\\"{x:459,y:619,t:1527876892091};\\\", \\\"{x:476,y:619,t:1527876892108};\\\", \\\"{x:493,y:619,t:1527876892125};\\\", \\\"{x:509,y:619,t:1527876892143};\\\", \\\"{x:524,y:616,t:1527876892158};\\\", \\\"{x:540,y:612,t:1527876892175};\\\", \\\"{x:555,y:609,t:1527876892192};\\\", \\\"{x:563,y:607,t:1527876892208};\\\", \\\"{x:567,y:606,t:1527876892225};\\\", \\\"{x:568,y:606,t:1527876892242};\\\", \\\"{x:571,y:605,t:1527876892258};\\\", \\\"{x:573,y:603,t:1527876892275};\\\", \\\"{x:574,y:602,t:1527876892292};\\\", \\\"{x:579,y:600,t:1527876892309};\\\", \\\"{x:581,y:599,t:1527876892325};\\\", \\\"{x:585,y:598,t:1527876892342};\\\", \\\"{x:588,y:596,t:1527876892358};\\\", \\\"{x:596,y:595,t:1527876892375};\\\", \\\"{x:612,y:592,t:1527876892392};\\\", \\\"{x:636,y:590,t:1527876892408};\\\", \\\"{x:668,y:584,t:1527876892424};\\\", \\\"{x:688,y:581,t:1527876892442};\\\", \\\"{x:708,y:579,t:1527876892458};\\\", \\\"{x:730,y:578,t:1527876892475};\\\", \\\"{x:749,y:574,t:1527876892492};\\\", \\\"{x:755,y:574,t:1527876892508};\\\", \\\"{x:761,y:573,t:1527876892525};\\\", \\\"{x:771,y:573,t:1527876892542};\\\", \\\"{x:779,y:573,t:1527876892559};\\\", \\\"{x:788,y:573,t:1527876892575};\\\", \\\"{x:791,y:573,t:1527876892592};\\\", \\\"{x:792,y:573,t:1527876892608};\\\", \\\"{x:791,y:575,t:1527876892649};\\\", \\\"{x:783,y:580,t:1527876892659};\\\", \\\"{x:766,y:586,t:1527876892675};\\\", \\\"{x:733,y:590,t:1527876892692};\\\", \\\"{x:711,y:590,t:1527876892710};\\\", \\\"{x:707,y:590,t:1527876892725};\\\", \\\"{x:706,y:589,t:1527876892742};\\\", \\\"{x:706,y:583,t:1527876892759};\\\", \\\"{x:711,y:573,t:1527876892776};\\\", \\\"{x:726,y:562,t:1527876892793};\\\", \\\"{x:745,y:550,t:1527876892809};\\\", \\\"{x:763,y:543,t:1527876892826};\\\", \\\"{x:778,y:540,t:1527876892842};\\\", \\\"{x:790,y:536,t:1527876892859};\\\", \\\"{x:796,y:535,t:1527876892875};\\\", \\\"{x:800,y:532,t:1527876892892};\\\", \\\"{x:801,y:532,t:1527876892910};\\\", \\\"{x:802,y:532,t:1527876892925};\\\", \\\"{x:803,y:532,t:1527876892942};\\\", \\\"{x:804,y:532,t:1527876892985};\\\", \\\"{x:805,y:532,t:1527876893009};\\\", \\\"{x:806,y:534,t:1527876893026};\\\", \\\"{x:807,y:536,t:1527876893042};\\\", \\\"{x:813,y:539,t:1527876893059};\\\", \\\"{x:816,y:540,t:1527876893076};\\\", \\\"{x:819,y:540,t:1527876893092};\\\", \\\"{x:820,y:540,t:1527876893109};\\\", \\\"{x:822,y:540,t:1527876893125};\\\", \\\"{x:823,y:540,t:1527876893143};\\\", \\\"{x:824,y:542,t:1527876893409};\\\", \\\"{x:824,y:547,t:1527876893426};\\\", \\\"{x:824,y:548,t:1527876893443};\\\", \\\"{x:825,y:548,t:1527876893521};\\\", \\\"{x:826,y:548,t:1527876893529};\\\", \\\"{x:828,y:548,t:1527876893543};\\\", \\\"{x:832,y:547,t:1527876893560};\\\", \\\"{x:834,y:546,t:1527876893577};\\\", \\\"{x:836,y:545,t:1527876893593};\\\", \\\"{x:832,y:545,t:1527876893921};\\\", \\\"{x:822,y:550,t:1527876893928};\\\", \\\"{x:810,y:557,t:1527876893943};\\\", \\\"{x:793,y:566,t:1527876893960};\\\", \\\"{x:778,y:572,t:1527876893976};\\\", \\\"{x:763,y:579,t:1527876893993};\\\", \\\"{x:748,y:586,t:1527876894010};\\\", \\\"{x:730,y:593,t:1527876894026};\\\", \\\"{x:703,y:608,t:1527876894044};\\\", \\\"{x:667,y:631,t:1527876894060};\\\", \\\"{x:643,y:645,t:1527876894076};\\\", \\\"{x:630,y:654,t:1527876894093};\\\", \\\"{x:621,y:658,t:1527876894110};\\\", \\\"{x:619,y:660,t:1527876894126};\\\", \\\"{x:617,y:661,t:1527876894143};\\\", \\\"{x:615,y:662,t:1527876894160};\\\", \\\"{x:612,y:666,t:1527876894176};\\\", \\\"{x:605,y:673,t:1527876894193};\\\", \\\"{x:595,y:683,t:1527876894210};\\\", \\\"{x:588,y:690,t:1527876894227};\\\", \\\"{x:580,y:694,t:1527876894243};\\\", \\\"{x:571,y:701,t:1527876894260};\\\", \\\"{x:563,y:706,t:1527876894276};\\\", \\\"{x:554,y:712,t:1527876894294};\\\", \\\"{x:542,y:720,t:1527876894310};\\\", \\\"{x:534,y:726,t:1527876894327};\\\", \\\"{x:530,y:729,t:1527876894343};\\\", \\\"{x:528,y:731,t:1527876894360};\\\", \\\"{x:529,y:731,t:1527876894625};\\\", \\\"{x:538,y:727,t:1527876894633};\\\", \\\"{x:551,y:722,t:1527876894643};\\\", \\\"{x:610,y:714,t:1527876894660};\\\", \\\"{x:720,y:714,t:1527876894677};\\\", \\\"{x:859,y:714,t:1527876894694};\\\", \\\"{x:1001,y:717,t:1527876894711};\\\", \\\"{x:1120,y:736,t:1527876894727};\\\", \\\"{x:1217,y:750,t:1527876894743};\\\", \\\"{x:1286,y:758,t:1527876894760};\\\", \\\"{x:1321,y:765,t:1527876894777};\\\", \\\"{x:1322,y:765,t:1527876894794};\\\", \\\"{x:1322,y:766,t:1527876894841};\\\", \\\"{x:1322,y:764,t:1527876895577};\\\", \\\"{x:1314,y:757,t:1527876895585};\\\", \\\"{x:1302,y:751,t:1527876895594};\\\", \\\"{x:1257,y:721,t:1527876895611};\\\", \\\"{x:1182,y:671,t:1527876895628};\\\", \\\"{x:1084,y:600,t:1527876895644};\\\", \\\"{x:962,y:513,t:1527876895661};\\\", \\\"{x:832,y:420,t:1527876895677};\\\" ] }, { \\\"rt\\\": 12743, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 515868, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"2ZXKM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-N -02 PM-M \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:584,y:247,t:1527876895779};\\\", \\\"{x:585,y:248,t:1527876895937};\\\", \\\"{x:593,y:257,t:1527876895945};\\\", \\\"{x:615,y:278,t:1527876895961};\\\", \\\"{x:636,y:293,t:1527876895978};\\\", \\\"{x:655,y:304,t:1527876895995};\\\", \\\"{x:671,y:313,t:1527876896011};\\\", \\\"{x:682,y:319,t:1527876896028};\\\", \\\"{x:690,y:323,t:1527876896045};\\\", \\\"{x:695,y:328,t:1527876896061};\\\", \\\"{x:700,y:335,t:1527876896078};\\\", \\\"{x:703,y:344,t:1527876896095};\\\", \\\"{x:707,y:365,t:1527876896111};\\\", \\\"{x:708,y:397,t:1527876896128};\\\", \\\"{x:702,y:456,t:1527876896145};\\\", \\\"{x:682,y:507,t:1527876896162};\\\", \\\"{x:661,y:552,t:1527876896179};\\\", \\\"{x:621,y:615,t:1527876896260};\\\", \\\"{x:622,y:615,t:1527876896569};\\\", \\\"{x:629,y:613,t:1527876896578};\\\", \\\"{x:644,y:603,t:1527876896596};\\\", \\\"{x:658,y:597,t:1527876896613};\\\", \\\"{x:670,y:593,t:1527876896629};\\\", \\\"{x:681,y:591,t:1527876896645};\\\", \\\"{x:689,y:588,t:1527876896663};\\\", \\\"{x:693,y:587,t:1527876896678};\\\", \\\"{x:699,y:583,t:1527876896695};\\\", \\\"{x:704,y:579,t:1527876896712};\\\", \\\"{x:706,y:577,t:1527876896728};\\\", \\\"{x:708,y:573,t:1527876896745};\\\", \\\"{x:708,y:567,t:1527876896762};\\\", \\\"{x:708,y:559,t:1527876896780};\\\", \\\"{x:707,y:550,t:1527876896796};\\\", \\\"{x:701,y:540,t:1527876896813};\\\", \\\"{x:694,y:533,t:1527876896829};\\\", \\\"{x:679,y:522,t:1527876896845};\\\", \\\"{x:660,y:509,t:1527876896863};\\\", \\\"{x:640,y:498,t:1527876896879};\\\", \\\"{x:622,y:494,t:1527876896895};\\\", \\\"{x:613,y:492,t:1527876896912};\\\", \\\"{x:610,y:492,t:1527876896928};\\\", \\\"{x:608,y:491,t:1527876896953};\\\", \\\"{x:607,y:491,t:1527876896976};\\\", \\\"{x:605,y:490,t:1527876897008};\\\", \\\"{x:604,y:490,t:1527876897033};\\\", \\\"{x:603,y:489,t:1527876897045};\\\", \\\"{x:601,y:489,t:1527876897065};\\\", \\\"{x:600,y:489,t:1527876897097};\\\", \\\"{x:598,y:489,t:1527876897569};\\\", \\\"{x:596,y:489,t:1527876897581};\\\", \\\"{x:591,y:489,t:1527876897598};\\\", \\\"{x:589,y:489,t:1527876897613};\\\", \\\"{x:587,y:489,t:1527876897630};\\\", \\\"{x:584,y:488,t:1527876897647};\\\", \\\"{x:583,y:488,t:1527876897663};\\\", \\\"{x:582,y:488,t:1527876897689};\\\", \\\"{x:581,y:487,t:1527876897841};\\\", \\\"{x:581,y:486,t:1527876897849};\\\", \\\"{x:584,y:483,t:1527876897864};\\\", \\\"{x:601,y:474,t:1527876897880};\\\", \\\"{x:623,y:465,t:1527876897896};\\\", \\\"{x:653,y:457,t:1527876897913};\\\", \\\"{x:711,y:444,t:1527876897930};\\\", \\\"{x:780,y:435,t:1527876897946};\\\", \\\"{x:880,y:421,t:1527876897963};\\\", \\\"{x:983,y:415,t:1527876897979};\\\", \\\"{x:1083,y:415,t:1527876897996};\\\", \\\"{x:1191,y:415,t:1527876898013};\\\", \\\"{x:1293,y:426,t:1527876898029};\\\", \\\"{x:1371,y:437,t:1527876898046};\\\", \\\"{x:1422,y:445,t:1527876898064};\\\", \\\"{x:1467,y:450,t:1527876898080};\\\", \\\"{x:1492,y:454,t:1527876898096};\\\", \\\"{x:1504,y:458,t:1527876898112};\\\", \\\"{x:1504,y:459,t:1527876898129};\\\", \\\"{x:1504,y:460,t:1527876898147};\\\", \\\"{x:1504,y:461,t:1527876898164};\\\", \\\"{x:1504,y:464,t:1527876898180};\\\", \\\"{x:1504,y:468,t:1527876898197};\\\", \\\"{x:1504,y:469,t:1527876898214};\\\", \\\"{x:1504,y:470,t:1527876898241};\\\", \\\"{x:1504,y:471,t:1527876898248};\\\", \\\"{x:1503,y:471,t:1527876898265};\\\", \\\"{x:1501,y:471,t:1527876898281};\\\", \\\"{x:1498,y:473,t:1527876898296};\\\", \\\"{x:1494,y:475,t:1527876898313};\\\", \\\"{x:1492,y:476,t:1527876898330};\\\", \\\"{x:1490,y:479,t:1527876898346};\\\", \\\"{x:1489,y:482,t:1527876898364};\\\", \\\"{x:1488,y:486,t:1527876898380};\\\", \\\"{x:1488,y:491,t:1527876898396};\\\", \\\"{x:1485,y:496,t:1527876898414};\\\", \\\"{x:1484,y:503,t:1527876898430};\\\", \\\"{x:1482,y:510,t:1527876898447};\\\", \\\"{x:1482,y:516,t:1527876898464};\\\", \\\"{x:1481,y:524,t:1527876898479};\\\", \\\"{x:1480,y:531,t:1527876898496};\\\", \\\"{x:1478,y:544,t:1527876898513};\\\", \\\"{x:1476,y:551,t:1527876898529};\\\", \\\"{x:1475,y:555,t:1527876898547};\\\", \\\"{x:1473,y:559,t:1527876898564};\\\", \\\"{x:1472,y:562,t:1527876898579};\\\", \\\"{x:1472,y:564,t:1527876898596};\\\", \\\"{x:1470,y:568,t:1527876898614};\\\", \\\"{x:1470,y:569,t:1527876898633};\\\", \\\"{x:1470,y:570,t:1527876898647};\\\", \\\"{x:1468,y:574,t:1527876899009};\\\", \\\"{x:1463,y:583,t:1527876899016};\\\", \\\"{x:1456,y:593,t:1527876899031};\\\", \\\"{x:1440,y:620,t:1527876899046};\\\", \\\"{x:1428,y:642,t:1527876899063};\\\", \\\"{x:1413,y:671,t:1527876899080};\\\", \\\"{x:1411,y:680,t:1527876899097};\\\", \\\"{x:1403,y:695,t:1527876899114};\\\", \\\"{x:1402,y:700,t:1527876899130};\\\", \\\"{x:1402,y:703,t:1527876899147};\\\", \\\"{x:1402,y:707,t:1527876899164};\\\", \\\"{x:1400,y:710,t:1527876899180};\\\", \\\"{x:1400,y:711,t:1527876899197};\\\", \\\"{x:1399,y:714,t:1527876899214};\\\", \\\"{x:1398,y:720,t:1527876899230};\\\", \\\"{x:1395,y:726,t:1527876899248};\\\", \\\"{x:1395,y:733,t:1527876899264};\\\", \\\"{x:1394,y:738,t:1527876899280};\\\", \\\"{x:1394,y:744,t:1527876899297};\\\", \\\"{x:1394,y:748,t:1527876899313};\\\", \\\"{x:1394,y:751,t:1527876899330};\\\", \\\"{x:1394,y:752,t:1527876899347};\\\", \\\"{x:1394,y:754,t:1527876899364};\\\", \\\"{x:1396,y:756,t:1527876899380};\\\", \\\"{x:1398,y:758,t:1527876899398};\\\", \\\"{x:1401,y:761,t:1527876899413};\\\", \\\"{x:1403,y:763,t:1527876899430};\\\", \\\"{x:1408,y:767,t:1527876899447};\\\", \\\"{x:1418,y:775,t:1527876899464};\\\", \\\"{x:1429,y:786,t:1527876899481};\\\", \\\"{x:1452,y:803,t:1527876899496};\\\", \\\"{x:1470,y:815,t:1527876899514};\\\", \\\"{x:1488,y:829,t:1527876899530};\\\", \\\"{x:1503,y:840,t:1527876899547};\\\", \\\"{x:1515,y:850,t:1527876899564};\\\", \\\"{x:1531,y:861,t:1527876899580};\\\", \\\"{x:1546,y:871,t:1527876899598};\\\", \\\"{x:1561,y:878,t:1527876899613};\\\", \\\"{x:1568,y:880,t:1527876899631};\\\", \\\"{x:1569,y:881,t:1527876899647};\\\", \\\"{x:1571,y:882,t:1527876899664};\\\", \\\"{x:1573,y:882,t:1527876899680};\\\", \\\"{x:1574,y:883,t:1527876899697};\\\", \\\"{x:1576,y:883,t:1527876899714};\\\", \\\"{x:1578,y:883,t:1527876899730};\\\", \\\"{x:1581,y:883,t:1527876899747};\\\", \\\"{x:1585,y:880,t:1527876899763};\\\", \\\"{x:1588,y:877,t:1527876899780};\\\", \\\"{x:1590,y:871,t:1527876899798};\\\", \\\"{x:1591,y:865,t:1527876899813};\\\", \\\"{x:1592,y:858,t:1527876899830};\\\", \\\"{x:1593,y:852,t:1527876899847};\\\", \\\"{x:1594,y:848,t:1527876899863};\\\", \\\"{x:1594,y:842,t:1527876899880};\\\", \\\"{x:1594,y:841,t:1527876899897};\\\", \\\"{x:1594,y:839,t:1527876899914};\\\", \\\"{x:1594,y:838,t:1527876899930};\\\", \\\"{x:1595,y:837,t:1527876899953};\\\", \\\"{x:1596,y:837,t:1527876899964};\\\", \\\"{x:1596,y:835,t:1527876899981};\\\", \\\"{x:1596,y:833,t:1527876899997};\\\", \\\"{x:1596,y:829,t:1527876900014};\\\", \\\"{x:1596,y:826,t:1527876900031};\\\", \\\"{x:1597,y:821,t:1527876900047};\\\", \\\"{x:1598,y:808,t:1527876900065};\\\", \\\"{x:1598,y:794,t:1527876900080};\\\", \\\"{x:1598,y:780,t:1527876900097};\\\", \\\"{x:1598,y:766,t:1527876900114};\\\", \\\"{x:1598,y:755,t:1527876900130};\\\", \\\"{x:1598,y:747,t:1527876900147};\\\", \\\"{x:1598,y:741,t:1527876900164};\\\", \\\"{x:1598,y:734,t:1527876900180};\\\", \\\"{x:1598,y:728,t:1527876900198};\\\", \\\"{x:1598,y:724,t:1527876900214};\\\", \\\"{x:1598,y:718,t:1527876900230};\\\", \\\"{x:1598,y:713,t:1527876900247};\\\", \\\"{x:1598,y:706,t:1527876900264};\\\", \\\"{x:1598,y:705,t:1527876900281};\\\", \\\"{x:1599,y:704,t:1527876900425};\\\", \\\"{x:1605,y:706,t:1527876900433};\\\", \\\"{x:1609,y:712,t:1527876900447};\\\", \\\"{x:1619,y:726,t:1527876900464};\\\", \\\"{x:1627,y:740,t:1527876900482};\\\", \\\"{x:1635,y:754,t:1527876900497};\\\", \\\"{x:1641,y:763,t:1527876900515};\\\", \\\"{x:1649,y:774,t:1527876900532};\\\", \\\"{x:1652,y:780,t:1527876900548};\\\", \\\"{x:1653,y:781,t:1527876900564};\\\", \\\"{x:1654,y:782,t:1527876900581};\\\", \\\"{x:1654,y:783,t:1527876900597};\\\", \\\"{x:1656,y:786,t:1527876900614};\\\", \\\"{x:1659,y:789,t:1527876900632};\\\", \\\"{x:1660,y:791,t:1527876900647};\\\", \\\"{x:1662,y:794,t:1527876900664};\\\", \\\"{x:1663,y:796,t:1527876900681};\\\", \\\"{x:1664,y:798,t:1527876900698};\\\", \\\"{x:1665,y:800,t:1527876900714};\\\", \\\"{x:1668,y:806,t:1527876900732};\\\", \\\"{x:1673,y:814,t:1527876900748};\\\", \\\"{x:1682,y:828,t:1527876900765};\\\", \\\"{x:1690,y:836,t:1527876900782};\\\", \\\"{x:1693,y:843,t:1527876900797};\\\", \\\"{x:1698,y:848,t:1527876900814};\\\", \\\"{x:1700,y:852,t:1527876900832};\\\", \\\"{x:1702,y:855,t:1527876900848};\\\", \\\"{x:1703,y:857,t:1527876900864};\\\", \\\"{x:1703,y:859,t:1527876900881};\\\", \\\"{x:1703,y:861,t:1527876900898};\\\", \\\"{x:1704,y:863,t:1527876900914};\\\", \\\"{x:1706,y:866,t:1527876900932};\\\", \\\"{x:1707,y:868,t:1527876900948};\\\", \\\"{x:1707,y:870,t:1527876900964};\\\", \\\"{x:1708,y:872,t:1527876900985};\\\", \\\"{x:1709,y:872,t:1527876900998};\\\", \\\"{x:1709,y:873,t:1527876901017};\\\", \\\"{x:1709,y:871,t:1527876901529};\\\", \\\"{x:1708,y:869,t:1527876901536};\\\", \\\"{x:1704,y:862,t:1527876901548};\\\", \\\"{x:1698,y:855,t:1527876901565};\\\", \\\"{x:1690,y:848,t:1527876901581};\\\", \\\"{x:1686,y:842,t:1527876901599};\\\", \\\"{x:1681,y:838,t:1527876901615};\\\", \\\"{x:1676,y:834,t:1527876901632};\\\", \\\"{x:1671,y:830,t:1527876901649};\\\", \\\"{x:1669,y:824,t:1527876901664};\\\", \\\"{x:1667,y:820,t:1527876901682};\\\", \\\"{x:1663,y:814,t:1527876901699};\\\", \\\"{x:1661,y:809,t:1527876901715};\\\", \\\"{x:1659,y:804,t:1527876901732};\\\", \\\"{x:1655,y:798,t:1527876901749};\\\", \\\"{x:1653,y:795,t:1527876901765};\\\", \\\"{x:1651,y:791,t:1527876901782};\\\", \\\"{x:1649,y:786,t:1527876901798};\\\", \\\"{x:1647,y:782,t:1527876901814};\\\", \\\"{x:1646,y:777,t:1527876901832};\\\", \\\"{x:1642,y:768,t:1527876901848};\\\", \\\"{x:1639,y:762,t:1527876901865};\\\", \\\"{x:1638,y:759,t:1527876901882};\\\", \\\"{x:1637,y:757,t:1527876901899};\\\", \\\"{x:1636,y:753,t:1527876901916};\\\", \\\"{x:1635,y:750,t:1527876901932};\\\", \\\"{x:1634,y:744,t:1527876901949};\\\", \\\"{x:1632,y:739,t:1527876901966};\\\", \\\"{x:1632,y:736,t:1527876901981};\\\", \\\"{x:1631,y:735,t:1527876901998};\\\", \\\"{x:1631,y:733,t:1527876902016};\\\", \\\"{x:1631,y:732,t:1527876902032};\\\", \\\"{x:1631,y:729,t:1527876902048};\\\", \\\"{x:1629,y:726,t:1527876902066};\\\", \\\"{x:1629,y:723,t:1527876902082};\\\", \\\"{x:1629,y:721,t:1527876902099};\\\", \\\"{x:1628,y:720,t:1527876902201};\\\", \\\"{x:1626,y:720,t:1527876902224};\\\", \\\"{x:1625,y:721,t:1527876902232};\\\", \\\"{x:1622,y:729,t:1527876902248};\\\", \\\"{x:1619,y:736,t:1527876902265};\\\", \\\"{x:1613,y:748,t:1527876902281};\\\", \\\"{x:1607,y:759,t:1527876902299};\\\", \\\"{x:1604,y:768,t:1527876902316};\\\", \\\"{x:1601,y:776,t:1527876902331};\\\", \\\"{x:1597,y:784,t:1527876902348};\\\", \\\"{x:1593,y:792,t:1527876902365};\\\", \\\"{x:1590,y:799,t:1527876902381};\\\", \\\"{x:1589,y:804,t:1527876902398};\\\", \\\"{x:1587,y:808,t:1527876902415};\\\", \\\"{x:1585,y:813,t:1527876902431};\\\", \\\"{x:1584,y:819,t:1527876902449};\\\", \\\"{x:1580,y:824,t:1527876902465};\\\", \\\"{x:1577,y:831,t:1527876902483};\\\", \\\"{x:1573,y:839,t:1527876902498};\\\", \\\"{x:1571,y:847,t:1527876902516};\\\", \\\"{x:1567,y:856,t:1527876902533};\\\", \\\"{x:1562,y:865,t:1527876902549};\\\", \\\"{x:1557,y:877,t:1527876902565};\\\", \\\"{x:1551,y:888,t:1527876902582};\\\", \\\"{x:1544,y:899,t:1527876902599};\\\", \\\"{x:1538,y:909,t:1527876902616};\\\", \\\"{x:1530,y:923,t:1527876902633};\\\", \\\"{x:1525,y:930,t:1527876902649};\\\", \\\"{x:1521,y:937,t:1527876902666};\\\", \\\"{x:1516,y:943,t:1527876902683};\\\", \\\"{x:1512,y:948,t:1527876902699};\\\", \\\"{x:1509,y:952,t:1527876902715};\\\", \\\"{x:1505,y:956,t:1527876902733};\\\", \\\"{x:1504,y:958,t:1527876902748};\\\", \\\"{x:1503,y:960,t:1527876902766};\\\", \\\"{x:1501,y:962,t:1527876902783};\\\", \\\"{x:1500,y:962,t:1527876902799};\\\", \\\"{x:1500,y:963,t:1527876902815};\\\", \\\"{x:1497,y:966,t:1527876902833};\\\", \\\"{x:1497,y:967,t:1527876902849};\\\", \\\"{x:1495,y:968,t:1527876902866};\\\", \\\"{x:1495,y:969,t:1527876902883};\\\", \\\"{x:1494,y:969,t:1527876902899};\\\", \\\"{x:1492,y:970,t:1527876902916};\\\", \\\"{x:1491,y:971,t:1527876902937};\\\", \\\"{x:1491,y:972,t:1527876902949};\\\", \\\"{x:1489,y:972,t:1527876902965};\\\", \\\"{x:1488,y:972,t:1527876902985};\\\", \\\"{x:1488,y:973,t:1527876903033};\\\", \\\"{x:1487,y:973,t:1527876903049};\\\", \\\"{x:1486,y:973,t:1527876903393};\\\", \\\"{x:1484,y:973,t:1527876903401};\\\", \\\"{x:1483,y:973,t:1527876903416};\\\", \\\"{x:1482,y:972,t:1527876903432};\\\", \\\"{x:1480,y:971,t:1527876903450};\\\", \\\"{x:1479,y:970,t:1527876903466};\\\", \\\"{x:1479,y:969,t:1527876903482};\\\", \\\"{x:1479,y:968,t:1527876903505};\\\", \\\"{x:1478,y:965,t:1527876903516};\\\", \\\"{x:1477,y:963,t:1527876903545};\\\", \\\"{x:1476,y:962,t:1527876903577};\\\", \\\"{x:1476,y:961,t:1527876903609};\\\", \\\"{x:1475,y:960,t:1527876903617};\\\", \\\"{x:1475,y:959,t:1527876903641};\\\", \\\"{x:1475,y:958,t:1527876903650};\\\", \\\"{x:1475,y:957,t:1527876903665};\\\", \\\"{x:1473,y:955,t:1527876903683};\\\", \\\"{x:1473,y:953,t:1527876903737};\\\", \\\"{x:1472,y:953,t:1527876903873};\\\", \\\"{x:1470,y:952,t:1527876903883};\\\", \\\"{x:1460,y:941,t:1527876903899};\\\", \\\"{x:1438,y:922,t:1527876903917};\\\", \\\"{x:1379,y:879,t:1527876903932};\\\", \\\"{x:1282,y:815,t:1527876903949};\\\", \\\"{x:1138,y:737,t:1527876903966};\\\", \\\"{x:963,y:676,t:1527876903982};\\\", \\\"{x:789,y:628,t:1527876903999};\\\", \\\"{x:521,y:549,t:1527876904017};\\\", \\\"{x:349,y:495,t:1527876904034};\\\", \\\"{x:194,y:448,t:1527876904051};\\\", \\\"{x:91,y:416,t:1527876904068};\\\", \\\"{x:62,y:408,t:1527876904084};\\\", \\\"{x:58,y:406,t:1527876904101};\\\", \\\"{x:68,y:406,t:1527876904161};\\\", \\\"{x:92,y:406,t:1527876904168};\\\", \\\"{x:173,y:406,t:1527876904184};\\\", \\\"{x:223,y:406,t:1527876904201};\\\", \\\"{x:245,y:404,t:1527876904217};\\\", \\\"{x:262,y:404,t:1527876904234};\\\", \\\"{x:298,y:408,t:1527876904252};\\\", \\\"{x:349,y:426,t:1527876904268};\\\", \\\"{x:384,y:438,t:1527876904284};\\\", \\\"{x:406,y:448,t:1527876904302};\\\", \\\"{x:429,y:457,t:1527876904319};\\\", \\\"{x:450,y:468,t:1527876904335};\\\", \\\"{x:468,y:478,t:1527876904352};\\\", \\\"{x:486,y:487,t:1527876904369};\\\", \\\"{x:492,y:489,t:1527876904384};\\\", \\\"{x:499,y:490,t:1527876904402};\\\", \\\"{x:508,y:495,t:1527876904418};\\\", \\\"{x:517,y:501,t:1527876904434};\\\", \\\"{x:539,y:510,t:1527876904452};\\\", \\\"{x:549,y:516,t:1527876904469};\\\", \\\"{x:560,y:519,t:1527876904485};\\\", \\\"{x:568,y:521,t:1527876904501};\\\", \\\"{x:576,y:523,t:1527876904519};\\\", \\\"{x:586,y:527,t:1527876904535};\\\", \\\"{x:596,y:529,t:1527876904551};\\\", \\\"{x:616,y:532,t:1527876904569};\\\", \\\"{x:632,y:537,t:1527876904584};\\\", \\\"{x:651,y:542,t:1527876904601};\\\", \\\"{x:669,y:546,t:1527876904618};\\\", \\\"{x:691,y:549,t:1527876904635};\\\", \\\"{x:711,y:549,t:1527876904652};\\\", \\\"{x:727,y:549,t:1527876904669};\\\", \\\"{x:747,y:549,t:1527876904685};\\\", \\\"{x:769,y:549,t:1527876904702};\\\", \\\"{x:788,y:549,t:1527876904719};\\\", \\\"{x:807,y:549,t:1527876904735};\\\", \\\"{x:827,y:549,t:1527876904751};\\\", \\\"{x:837,y:546,t:1527876904769};\\\", \\\"{x:838,y:546,t:1527876904785};\\\", \\\"{x:839,y:545,t:1527876904864};\\\", \\\"{x:840,y:544,t:1527876904872};\\\", \\\"{x:840,y:543,t:1527876904905};\\\", \\\"{x:840,y:542,t:1527876904920};\\\", \\\"{x:840,y:540,t:1527876904935};\\\", \\\"{x:840,y:537,t:1527876904951};\\\", \\\"{x:841,y:521,t:1527876904969};\\\", \\\"{x:843,y:502,t:1527876904985};\\\", \\\"{x:845,y:491,t:1527876905002};\\\", \\\"{x:846,y:484,t:1527876905019};\\\", \\\"{x:846,y:482,t:1527876905036};\\\", \\\"{x:847,y:482,t:1527876905265};\\\", \\\"{x:847,y:483,t:1527876905272};\\\", \\\"{x:847,y:484,t:1527876905285};\\\", \\\"{x:847,y:486,t:1527876905302};\\\", \\\"{x:847,y:487,t:1527876905337};\\\", \\\"{x:847,y:489,t:1527876905360};\\\", \\\"{x:847,y:490,t:1527876905392};\\\", \\\"{x:847,y:492,t:1527876905402};\\\", \\\"{x:847,y:494,t:1527876905418};\\\", \\\"{x:845,y:500,t:1527876905436};\\\", \\\"{x:842,y:506,t:1527876905452};\\\", \\\"{x:841,y:508,t:1527876905468};\\\", \\\"{x:840,y:510,t:1527876905485};\\\", \\\"{x:839,y:511,t:1527876905503};\\\", \\\"{x:839,y:512,t:1527876905519};\\\", \\\"{x:838,y:512,t:1527876905535};\\\", \\\"{x:838,y:513,t:1527876905553};\\\", \\\"{x:837,y:514,t:1527876905568};\\\", \\\"{x:836,y:514,t:1527876905592};\\\", \\\"{x:835,y:515,t:1527876905603};\\\", \\\"{x:835,y:515,t:1527876905713};\\\", \\\"{x:834,y:515,t:1527876905920};\\\", \\\"{x:831,y:514,t:1527876905935};\\\", \\\"{x:823,y:510,t:1527876905953};\\\", \\\"{x:819,y:509,t:1527876905969};\\\", \\\"{x:815,y:507,t:1527876905986};\\\", \\\"{x:815,y:506,t:1527876906002};\\\", \\\"{x:814,y:506,t:1527876906081};\\\", \\\"{x:814,y:505,t:1527876906120};\\\", \\\"{x:815,y:505,t:1527876906136};\\\", \\\"{x:816,y:504,t:1527876906152};\\\", \\\"{x:817,y:503,t:1527876906217};\\\", \\\"{x:819,y:503,t:1527876906224};\\\", \\\"{x:821,y:502,t:1527876906249};\\\", \\\"{x:822,y:502,t:1527876906265};\\\", \\\"{x:823,y:502,t:1527876906272};\\\", \\\"{x:824,y:502,t:1527876906287};\\\", \\\"{x:825,y:501,t:1527876906303};\\\", \\\"{x:826,y:501,t:1527876906320};\\\", \\\"{x:837,y:498,t:1527876906336};\\\", \\\"{x:843,y:495,t:1527876906353};\\\", \\\"{x:846,y:495,t:1527876906370};\\\", \\\"{x:847,y:494,t:1527876906387};\\\", \\\"{x:848,y:494,t:1527876906404};\\\", \\\"{x:847,y:494,t:1527876906641};\\\", \\\"{x:846,y:494,t:1527876906654};\\\", \\\"{x:844,y:494,t:1527876906670};\\\", \\\"{x:840,y:496,t:1527876906687};\\\", \\\"{x:834,y:496,t:1527876906703};\\\", \\\"{x:831,y:498,t:1527876906720};\\\", \\\"{x:827,y:501,t:1527876906737};\\\", \\\"{x:825,y:501,t:1527876906754};\\\", \\\"{x:824,y:501,t:1527876906770};\\\", \\\"{x:823,y:501,t:1527876906787};\\\", \\\"{x:821,y:501,t:1527876906880};\\\", \\\"{x:817,y:501,t:1527876906888};\\\", \\\"{x:811,y:501,t:1527876906904};\\\", \\\"{x:796,y:505,t:1527876906920};\\\", \\\"{x:768,y:509,t:1527876906936};\\\", \\\"{x:742,y:511,t:1527876906954};\\\", \\\"{x:721,y:515,t:1527876906972};\\\", \\\"{x:711,y:516,t:1527876906986};\\\", \\\"{x:707,y:517,t:1527876907004};\\\", \\\"{x:706,y:517,t:1527876907025};\\\", \\\"{x:705,y:517,t:1527876907073};\\\", \\\"{x:704,y:517,t:1527876907087};\\\", \\\"{x:700,y:517,t:1527876907104};\\\", \\\"{x:687,y:517,t:1527876907120};\\\", \\\"{x:675,y:512,t:1527876907136};\\\", \\\"{x:662,y:505,t:1527876907153};\\\", \\\"{x:652,y:500,t:1527876907171};\\\", \\\"{x:645,y:498,t:1527876907187};\\\", \\\"{x:639,y:494,t:1527876907204};\\\", \\\"{x:634,y:493,t:1527876907220};\\\", \\\"{x:633,y:492,t:1527876907237};\\\", \\\"{x:630,y:491,t:1527876907253};\\\", \\\"{x:629,y:491,t:1527876907271};\\\", \\\"{x:626,y:490,t:1527876907287};\\\", \\\"{x:625,y:489,t:1527876907303};\\\", \\\"{x:624,y:489,t:1527876907321};\\\", \\\"{x:623,y:489,t:1527876907344};\\\", \\\"{x:622,y:489,t:1527876907385};\\\", \\\"{x:621,y:489,t:1527876907393};\\\", \\\"{x:619,y:490,t:1527876907409};\\\", \\\"{x:617,y:491,t:1527876907421};\\\", \\\"{x:614,y:492,t:1527876907438};\\\", \\\"{x:612,y:493,t:1527876907454};\\\", \\\"{x:610,y:493,t:1527876907471};\\\", \\\"{x:609,y:495,t:1527876907488};\\\", \\\"{x:608,y:496,t:1527876907849};\\\", \\\"{x:603,y:510,t:1527876907856};\\\", \\\"{x:596,y:528,t:1527876907871};\\\", \\\"{x:582,y:559,t:1527876907888};\\\", \\\"{x:566,y:590,t:1527876907905};\\\", \\\"{x:556,y:607,t:1527876907921};\\\", \\\"{x:551,y:624,t:1527876907938};\\\", \\\"{x:545,y:649,t:1527876907955};\\\", \\\"{x:538,y:672,t:1527876907971};\\\", \\\"{x:534,y:689,t:1527876907988};\\\", \\\"{x:532,y:697,t:1527876908005};\\\", \\\"{x:531,y:699,t:1527876908021};\\\", \\\"{x:531,y:700,t:1527876908038};\\\", \\\"{x:531,y:702,t:1527876908201};\\\", \\\"{x:531,y:706,t:1527876908208};\\\", \\\"{x:531,y:710,t:1527876908220};\\\", \\\"{x:534,y:719,t:1527876908236};\\\", \\\"{x:536,y:728,t:1527876908255};\\\", \\\"{x:538,y:735,t:1527876908270};\\\", \\\"{x:538,y:736,t:1527876908287};\\\" ] }, { \\\"rt\\\": 5844, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 522905, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"2ZXKM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-03 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:541,y:736,t:1527876910416};\\\", \\\"{x:556,y:736,t:1527876910424};\\\", \\\"{x:569,y:736,t:1527876910440};\\\", \\\"{x:620,y:738,t:1527876910457};\\\", \\\"{x:680,y:723,t:1527876910473};\\\", \\\"{x:778,y:708,t:1527876910490};\\\", \\\"{x:876,y:702,t:1527876910506};\\\", \\\"{x:973,y:702,t:1527876910522};\\\", \\\"{x:1078,y:702,t:1527876910540};\\\", \\\"{x:1175,y:702,t:1527876910556};\\\", \\\"{x:1257,y:698,t:1527876910573};\\\", \\\"{x:1296,y:694,t:1527876910590};\\\", \\\"{x:1306,y:692,t:1527876910607};\\\", \\\"{x:1307,y:691,t:1527876910624};\\\", \\\"{x:1308,y:691,t:1527876910769};\\\", \\\"{x:1310,y:691,t:1527876910777};\\\", \\\"{x:1310,y:689,t:1527876910790};\\\", \\\"{x:1315,y:683,t:1527876910807};\\\", \\\"{x:1321,y:674,t:1527876910823};\\\", \\\"{x:1328,y:665,t:1527876910839};\\\", \\\"{x:1336,y:655,t:1527876910857};\\\", \\\"{x:1357,y:643,t:1527876910873};\\\", \\\"{x:1398,y:621,t:1527876910890};\\\", \\\"{x:1466,y:592,t:1527876910907};\\\", \\\"{x:1526,y:571,t:1527876910923};\\\", \\\"{x:1554,y:569,t:1527876910940};\\\", \\\"{x:1565,y:566,t:1527876910957};\\\", \\\"{x:1568,y:566,t:1527876910973};\\\", \\\"{x:1568,y:565,t:1527876911161};\\\", \\\"{x:1565,y:565,t:1527876911174};\\\", \\\"{x:1554,y:565,t:1527876911190};\\\", \\\"{x:1538,y:573,t:1527876911207};\\\", \\\"{x:1520,y:581,t:1527876911224};\\\", \\\"{x:1499,y:591,t:1527876911239};\\\", \\\"{x:1477,y:609,t:1527876911256};\\\", \\\"{x:1470,y:622,t:1527876911273};\\\", \\\"{x:1466,y:633,t:1527876911289};\\\", \\\"{x:1466,y:638,t:1527876911307};\\\", \\\"{x:1466,y:643,t:1527876911323};\\\", \\\"{x:1464,y:651,t:1527876911340};\\\", \\\"{x:1462,y:661,t:1527876911357};\\\", \\\"{x:1460,y:675,t:1527876911373};\\\", \\\"{x:1454,y:691,t:1527876911389};\\\", \\\"{x:1448,y:706,t:1527876911407};\\\", \\\"{x:1446,y:711,t:1527876911424};\\\", \\\"{x:1443,y:717,t:1527876911439};\\\", \\\"{x:1439,y:730,t:1527876911457};\\\", \\\"{x:1437,y:740,t:1527876911474};\\\", \\\"{x:1434,y:757,t:1527876911490};\\\", \\\"{x:1433,y:773,t:1527876911507};\\\", \\\"{x:1433,y:790,t:1527876911524};\\\", \\\"{x:1433,y:805,t:1527876911540};\\\", \\\"{x:1433,y:819,t:1527876911557};\\\", \\\"{x:1435,y:832,t:1527876911574};\\\", \\\"{x:1435,y:838,t:1527876911591};\\\", \\\"{x:1438,y:848,t:1527876911607};\\\", \\\"{x:1439,y:860,t:1527876911624};\\\", \\\"{x:1447,y:882,t:1527876911641};\\\", \\\"{x:1451,y:897,t:1527876911657};\\\", \\\"{x:1455,y:907,t:1527876911674};\\\", \\\"{x:1456,y:912,t:1527876911691};\\\", \\\"{x:1457,y:915,t:1527876911707};\\\", \\\"{x:1458,y:917,t:1527876911724};\\\", \\\"{x:1458,y:918,t:1527876911741};\\\", \\\"{x:1459,y:921,t:1527876911757};\\\", \\\"{x:1459,y:923,t:1527876911774};\\\", \\\"{x:1459,y:924,t:1527876911791};\\\", \\\"{x:1461,y:928,t:1527876911806};\\\", \\\"{x:1461,y:930,t:1527876911824};\\\", \\\"{x:1463,y:934,t:1527876911840};\\\", \\\"{x:1463,y:935,t:1527876911857};\\\", \\\"{x:1465,y:937,t:1527876911873};\\\", \\\"{x:1465,y:940,t:1527876911891};\\\", \\\"{x:1466,y:943,t:1527876911907};\\\", \\\"{x:1468,y:946,t:1527876911924};\\\", \\\"{x:1469,y:948,t:1527876911941};\\\", \\\"{x:1471,y:950,t:1527876911957};\\\", \\\"{x:1474,y:954,t:1527876911973};\\\", \\\"{x:1477,y:958,t:1527876911991};\\\", \\\"{x:1478,y:960,t:1527876912007};\\\", \\\"{x:1481,y:962,t:1527876912024};\\\", \\\"{x:1484,y:965,t:1527876912041};\\\", \\\"{x:1486,y:967,t:1527876912057};\\\", \\\"{x:1488,y:968,t:1527876912074};\\\", \\\"{x:1490,y:969,t:1527876912091};\\\", \\\"{x:1493,y:970,t:1527876912106};\\\", \\\"{x:1494,y:971,t:1527876912124};\\\", \\\"{x:1498,y:971,t:1527876912140};\\\", \\\"{x:1507,y:972,t:1527876912157};\\\", \\\"{x:1519,y:972,t:1527876912174};\\\", \\\"{x:1529,y:972,t:1527876912191};\\\", \\\"{x:1536,y:972,t:1527876912208};\\\", \\\"{x:1544,y:972,t:1527876912224};\\\", \\\"{x:1550,y:972,t:1527876912241};\\\", \\\"{x:1553,y:972,t:1527876912257};\\\", \\\"{x:1554,y:971,t:1527876912274};\\\", \\\"{x:1554,y:968,t:1527876912705};\\\", \\\"{x:1554,y:967,t:1527876912720};\\\", \\\"{x:1554,y:965,t:1527876912889};\\\", \\\"{x:1554,y:964,t:1527876913113};\\\", \\\"{x:1554,y:963,t:1527876913125};\\\", \\\"{x:1554,y:962,t:1527876913141};\\\", \\\"{x:1554,y:960,t:1527876913159};\\\", \\\"{x:1552,y:958,t:1527876913175};\\\", \\\"{x:1550,y:957,t:1527876913191};\\\", \\\"{x:1549,y:957,t:1527876913209};\\\", \\\"{x:1548,y:956,t:1527876913225};\\\", \\\"{x:1546,y:954,t:1527876913409};\\\", \\\"{x:1530,y:945,t:1527876913424};\\\", \\\"{x:1506,y:934,t:1527876913442};\\\", \\\"{x:1449,y:905,t:1527876913458};\\\", \\\"{x:1314,y:839,t:1527876913475};\\\", \\\"{x:1134,y:756,t:1527876913492};\\\", \\\"{x:955,y:676,t:1527876913508};\\\", \\\"{x:788,y:619,t:1527876913526};\\\", \\\"{x:664,y:588,t:1527876913543};\\\", \\\"{x:560,y:561,t:1527876913558};\\\", \\\"{x:479,y:535,t:1527876913576};\\\", \\\"{x:442,y:527,t:1527876913592};\\\", \\\"{x:432,y:526,t:1527876913609};\\\", \\\"{x:434,y:526,t:1527876913689};\\\", \\\"{x:438,y:530,t:1527876913696};\\\", \\\"{x:440,y:533,t:1527876913709};\\\", \\\"{x:441,y:537,t:1527876913726};\\\", \\\"{x:441,y:544,t:1527876913742};\\\", \\\"{x:443,y:554,t:1527876913759};\\\", \\\"{x:445,y:568,t:1527876913777};\\\", \\\"{x:449,y:587,t:1527876913792};\\\", \\\"{x:451,y:607,t:1527876913809};\\\", \\\"{x:455,y:614,t:1527876913826};\\\", \\\"{x:461,y:622,t:1527876913842};\\\", \\\"{x:468,y:625,t:1527876913859};\\\", \\\"{x:475,y:627,t:1527876913875};\\\", \\\"{x:488,y:628,t:1527876913893};\\\", \\\"{x:500,y:630,t:1527876913910};\\\", \\\"{x:511,y:630,t:1527876913926};\\\", \\\"{x:520,y:630,t:1527876913942};\\\", \\\"{x:532,y:626,t:1527876913959};\\\", \\\"{x:547,y:620,t:1527876913975};\\\", \\\"{x:559,y:616,t:1527876913991};\\\", \\\"{x:575,y:611,t:1527876914009};\\\", \\\"{x:584,y:606,t:1527876914026};\\\", \\\"{x:589,y:605,t:1527876914042};\\\", \\\"{x:590,y:604,t:1527876914059};\\\", \\\"{x:591,y:603,t:1527876914080};\\\", \\\"{x:592,y:602,t:1527876914096};\\\", \\\"{x:593,y:602,t:1527876914112};\\\", \\\"{x:594,y:601,t:1527876914128};\\\", \\\"{x:594,y:600,t:1527876914145};\\\", \\\"{x:595,y:599,t:1527876914159};\\\", \\\"{x:596,y:599,t:1527876914176};\\\", \\\"{x:596,y:597,t:1527876914192};\\\", \\\"{x:596,y:596,t:1527876914210};\\\", \\\"{x:596,y:594,t:1527876914232};\\\", \\\"{x:597,y:594,t:1527876914243};\\\", \\\"{x:597,y:593,t:1527876914260};\\\", \\\"{x:597,y:592,t:1527876914276};\\\", \\\"{x:599,y:590,t:1527876914320};\\\", \\\"{x:599,y:589,t:1527876914360};\\\", \\\"{x:600,y:588,t:1527876914376};\\\", \\\"{x:602,y:585,t:1527876914392};\\\", \\\"{x:603,y:583,t:1527876914410};\\\", \\\"{x:605,y:582,t:1527876914560};\\\", \\\"{x:606,y:582,t:1527876914576};\\\", \\\"{x:607,y:582,t:1527876914593};\\\", \\\"{x:607,y:582,t:1527876914668};\\\", \\\"{x:608,y:589,t:1527876914888};\\\", \\\"{x:608,y:601,t:1527876914897};\\\", \\\"{x:608,y:613,t:1527876914910};\\\", \\\"{x:607,y:638,t:1527876914927};\\\", \\\"{x:600,y:660,t:1527876914943};\\\", \\\"{x:596,y:673,t:1527876914960};\\\", \\\"{x:592,y:687,t:1527876914977};\\\", \\\"{x:591,y:696,t:1527876914993};\\\", \\\"{x:591,y:707,t:1527876915010};\\\", \\\"{x:591,y:716,t:1527876915028};\\\", \\\"{x:591,y:724,t:1527876915043};\\\", \\\"{x:591,y:729,t:1527876915060};\\\", \\\"{x:591,y:731,t:1527876915077};\\\", \\\"{x:590,y:732,t:1527876915169};\\\", \\\"{x:589,y:733,t:1527876915177};\\\", \\\"{x:588,y:733,t:1527876915194};\\\", \\\"{x:585,y:733,t:1527876915210};\\\", \\\"{x:579,y:733,t:1527876915227};\\\", \\\"{x:572,y:733,t:1527876915244};\\\", \\\"{x:562,y:733,t:1527876915260};\\\", \\\"{x:555,y:733,t:1527876915277};\\\", \\\"{x:550,y:733,t:1527876915294};\\\", \\\"{x:547,y:735,t:1527876915310};\\\", \\\"{x:543,y:736,t:1527876915327};\\\", \\\"{x:538,y:737,t:1527876915344};\\\", \\\"{x:535,y:738,t:1527876915361};\\\" ] }, { \\\"rt\\\": 16230, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 540358, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"2ZXKM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:554,y:603,t:1527876917244};\\\", \\\"{x:554,y:599,t:1527876917263};\\\", \\\"{x:555,y:595,t:1527876917278};\\\", \\\"{x:557,y:589,t:1527876917295};\\\", \\\"{x:559,y:575,t:1527876917313};\\\", \\\"{x:562,y:568,t:1527876917329};\\\", \\\"{x:568,y:553,t:1527876917345};\\\", \\\"{x:573,y:541,t:1527876917362};\\\", \\\"{x:579,y:534,t:1527876917379};\\\", \\\"{x:584,y:525,t:1527876917395};\\\", \\\"{x:588,y:521,t:1527876917412};\\\", \\\"{x:591,y:517,t:1527876917428};\\\", \\\"{x:594,y:513,t:1527876917445};\\\", \\\"{x:597,y:510,t:1527876917462};\\\", \\\"{x:601,y:506,t:1527876917478};\\\", \\\"{x:603,y:505,t:1527876917495};\\\", \\\"{x:606,y:503,t:1527876917512};\\\", \\\"{x:608,y:501,t:1527876917528};\\\", \\\"{x:608,y:500,t:1527876917546};\\\", \\\"{x:609,y:500,t:1527876917562};\\\", \\\"{x:609,y:499,t:1527876917579};\\\", \\\"{x:611,y:498,t:1527876917595};\\\", \\\"{x:613,y:496,t:1527876917612};\\\", \\\"{x:614,y:494,t:1527876917629};\\\", \\\"{x:617,y:491,t:1527876917645};\\\", \\\"{x:620,y:486,t:1527876917662};\\\", \\\"{x:623,y:483,t:1527876917679};\\\", \\\"{x:631,y:477,t:1527876917696};\\\", \\\"{x:639,y:471,t:1527876917712};\\\", \\\"{x:650,y:466,t:1527876917729};\\\", \\\"{x:663,y:458,t:1527876917745};\\\", \\\"{x:675,y:452,t:1527876917762};\\\", \\\"{x:682,y:448,t:1527876917779};\\\", \\\"{x:687,y:445,t:1527876917795};\\\", \\\"{x:688,y:444,t:1527876917812};\\\", \\\"{x:690,y:444,t:1527876917829};\\\", \\\"{x:690,y:443,t:1527876917960};\\\", \\\"{x:690,y:442,t:1527876917968};\\\", \\\"{x:689,y:441,t:1527876917979};\\\", \\\"{x:684,y:439,t:1527876917996};\\\", \\\"{x:676,y:438,t:1527876918012};\\\", \\\"{x:668,y:437,t:1527876918029};\\\", \\\"{x:661,y:437,t:1527876918046};\\\", \\\"{x:651,y:437,t:1527876918062};\\\", \\\"{x:633,y:440,t:1527876918079};\\\", \\\"{x:593,y:458,t:1527876918096};\\\", \\\"{x:551,y:483,t:1527876918112};\\\", \\\"{x:499,y:513,t:1527876918129};\\\", \\\"{x:456,y:537,t:1527876918147};\\\", \\\"{x:431,y:551,t:1527876918163};\\\", \\\"{x:425,y:556,t:1527876918179};\\\", \\\"{x:421,y:558,t:1527876918196};\\\", \\\"{x:420,y:558,t:1527876919384};\\\", \\\"{x:422,y:551,t:1527876919400};\\\", \\\"{x:425,y:543,t:1527876919414};\\\", \\\"{x:438,y:521,t:1527876919431};\\\", \\\"{x:456,y:489,t:1527876919447};\\\", \\\"{x:488,y:437,t:1527876919460};\\\", \\\"{x:526,y:372,t:1527876919477};\\\", \\\"{x:573,y:287,t:1527876919493};\\\", \\\"{x:645,y:182,t:1527876919510};\\\", \\\"{x:705,y:96,t:1527876919527};\\\", \\\"{x:749,y:29,t:1527876919543};\\\", \\\"{x:777,y:0,t:1527876919560};\\\", \\\"{x:779,y:0,t:1527876919577};\\\", \\\"{x:781,y:0,t:1527876919593};\\\", \\\"{x:780,y:0,t:1527876919616};\\\", \\\"{x:777,y:0,t:1527876919626};\\\", \\\"{x:767,y:0,t:1527876919643};\\\", \\\"{x:755,y:0,t:1527876919660};\\\", \\\"{x:735,y:0,t:1527876919676};\\\", \\\"{x:695,y:0,t:1527876919693};\\\", \\\"{x:632,y:0,t:1527876919709};\\\", \\\"{x:546,y:0,t:1527876919726};\\\", \\\"{x:442,y:0,t:1527876919742};\\\", \\\"{x:327,y:0,t:1527876919759};\\\", \\\"{x:174,y:0,t:1527876919776};\\\", \\\"{x:79,y:0,t:1527876919792};\\\", \\\"{x:4,y:0,t:1527876919809};\\\", \\\"{x:0,y:0,t:1527876919825};\\\", \\\"{x:9,y:6,t:1527876920056};\\\", \\\"{x:23,y:19,t:1527876920064};\\\", \\\"{x:55,y:45,t:1527876920075};\\\", \\\"{x:152,y:111,t:1527876920092};\\\", \\\"{x:257,y:183,t:1527876920109};\\\", \\\"{x:357,y:254,t:1527876920125};\\\", \\\"{x:454,y:317,t:1527876920142};\\\", \\\"{x:532,y:372,t:1527876920159};\\\", \\\"{x:602,y:419,t:1527876920175};\\\", \\\"{x:704,y:488,t:1527876920192};\\\", \\\"{x:754,y:519,t:1527876920209};\\\", \\\"{x:785,y:541,t:1527876920226};\\\", \\\"{x:803,y:553,t:1527876920247};\\\", \\\"{x:812,y:561,t:1527876920264};\\\", \\\"{x:812,y:564,t:1527876920384};\\\", \\\"{x:812,y:568,t:1527876920398};\\\", \\\"{x:804,y:583,t:1527876920414};\\\", \\\"{x:795,y:600,t:1527876920430};\\\", \\\"{x:788,y:619,t:1527876920447};\\\", \\\"{x:780,y:646,t:1527876920465};\\\", \\\"{x:777,y:655,t:1527876920481};\\\", \\\"{x:774,y:663,t:1527876920498};\\\", \\\"{x:771,y:667,t:1527876920514};\\\", \\\"{x:767,y:672,t:1527876920531};\\\", \\\"{x:764,y:676,t:1527876920548};\\\", \\\"{x:759,y:680,t:1527876920564};\\\", \\\"{x:756,y:682,t:1527876920581};\\\", \\\"{x:752,y:684,t:1527876920598};\\\", \\\"{x:750,y:685,t:1527876920614};\\\", \\\"{x:748,y:685,t:1527876920631};\\\", \\\"{x:740,y:686,t:1527876920647};\\\", \\\"{x:719,y:679,t:1527876920664};\\\", \\\"{x:670,y:652,t:1527876920681};\\\", \\\"{x:599,y:615,t:1527876920698};\\\", \\\"{x:548,y:595,t:1527876920715};\\\", \\\"{x:519,y:589,t:1527876920731};\\\", \\\"{x:509,y:588,t:1527876920748};\\\", \\\"{x:503,y:587,t:1527876920764};\\\", \\\"{x:495,y:585,t:1527876920781};\\\", \\\"{x:494,y:585,t:1527876920798};\\\", \\\"{x:494,y:584,t:1527876921065};\\\", \\\"{x:495,y:581,t:1527876921081};\\\", \\\"{x:503,y:575,t:1527876921098};\\\", \\\"{x:512,y:567,t:1527876921114};\\\", \\\"{x:522,y:561,t:1527876921131};\\\", \\\"{x:530,y:556,t:1527876921148};\\\", \\\"{x:536,y:554,t:1527876921165};\\\", \\\"{x:537,y:553,t:1527876921181};\\\", \\\"{x:538,y:551,t:1527876921198};\\\", \\\"{x:539,y:550,t:1527876921377};\\\", \\\"{x:541,y:550,t:1527876921392};\\\", \\\"{x:546,y:550,t:1527876921400};\\\", \\\"{x:551,y:550,t:1527876921415};\\\", \\\"{x:570,y:552,t:1527876921432};\\\", \\\"{x:590,y:556,t:1527876921448};\\\", \\\"{x:612,y:558,t:1527876921465};\\\", \\\"{x:631,y:561,t:1527876921482};\\\", \\\"{x:651,y:563,t:1527876921499};\\\", \\\"{x:661,y:564,t:1527876921515};\\\", \\\"{x:665,y:566,t:1527876921532};\\\", \\\"{x:669,y:567,t:1527876921548};\\\", \\\"{x:670,y:568,t:1527876921565};\\\", \\\"{x:671,y:568,t:1527876921582};\\\", \\\"{x:673,y:568,t:1527876921598};\\\", \\\"{x:675,y:570,t:1527876921615};\\\", \\\"{x:683,y:573,t:1527876921632};\\\", \\\"{x:691,y:576,t:1527876921648};\\\", \\\"{x:701,y:580,t:1527876921665};\\\", \\\"{x:712,y:584,t:1527876921682};\\\", \\\"{x:725,y:588,t:1527876921699};\\\", \\\"{x:736,y:590,t:1527876921715};\\\", \\\"{x:744,y:592,t:1527876921732};\\\", \\\"{x:752,y:593,t:1527876921749};\\\", \\\"{x:757,y:596,t:1527876921765};\\\", \\\"{x:761,y:597,t:1527876921782};\\\", \\\"{x:769,y:598,t:1527876921799};\\\", \\\"{x:777,y:601,t:1527876921815};\\\", \\\"{x:787,y:604,t:1527876921832};\\\", \\\"{x:792,y:605,t:1527876921849};\\\", \\\"{x:797,y:606,t:1527876921865};\\\", \\\"{x:804,y:607,t:1527876921882};\\\", \\\"{x:808,y:609,t:1527876921899};\\\", \\\"{x:815,y:610,t:1527876921915};\\\", \\\"{x:819,y:613,t:1527876921932};\\\", \\\"{x:825,y:613,t:1527876921949};\\\", \\\"{x:831,y:614,t:1527876921965};\\\", \\\"{x:836,y:615,t:1527876921983};\\\", \\\"{x:838,y:616,t:1527876921999};\\\", \\\"{x:841,y:616,t:1527876922015};\\\", \\\"{x:846,y:617,t:1527876922031};\\\", \\\"{x:848,y:618,t:1527876922056};\\\", \\\"{x:850,y:618,t:1527876922066};\\\", \\\"{x:852,y:618,t:1527876922083};\\\", \\\"{x:854,y:618,t:1527876922099};\\\", \\\"{x:855,y:619,t:1527876922116};\\\", \\\"{x:858,y:619,t:1527876922132};\\\", \\\"{x:861,y:620,t:1527876922149};\\\", \\\"{x:864,y:620,t:1527876922166};\\\", \\\"{x:869,y:621,t:1527876922182};\\\", \\\"{x:873,y:621,t:1527876922199};\\\", \\\"{x:877,y:623,t:1527876922216};\\\", \\\"{x:880,y:623,t:1527876922232};\\\", \\\"{x:884,y:623,t:1527876922249};\\\", \\\"{x:887,y:624,t:1527876922266};\\\", \\\"{x:894,y:624,t:1527876922282};\\\", \\\"{x:898,y:624,t:1527876922298};\\\", \\\"{x:906,y:624,t:1527876922316};\\\", \\\"{x:911,y:624,t:1527876922332};\\\", \\\"{x:913,y:624,t:1527876922349};\\\", \\\"{x:915,y:624,t:1527876922366};\\\", \\\"{x:916,y:624,t:1527876922382};\\\", \\\"{x:919,y:625,t:1527876922399};\\\", \\\"{x:923,y:627,t:1527876922416};\\\", \\\"{x:926,y:628,t:1527876922432};\\\", \\\"{x:929,y:628,t:1527876922449};\\\", \\\"{x:933,y:628,t:1527876922466};\\\", \\\"{x:941,y:630,t:1527876922482};\\\", \\\"{x:950,y:631,t:1527876922499};\\\", \\\"{x:960,y:633,t:1527876922516};\\\", \\\"{x:968,y:634,t:1527876922532};\\\", \\\"{x:978,y:635,t:1527876922549};\\\", \\\"{x:993,y:641,t:1527876922566};\\\", \\\"{x:1004,y:642,t:1527876922582};\\\", \\\"{x:1017,y:645,t:1527876922599};\\\", \\\"{x:1034,y:647,t:1527876922616};\\\", \\\"{x:1042,y:651,t:1527876922633};\\\", \\\"{x:1054,y:654,t:1527876922649};\\\", \\\"{x:1065,y:657,t:1527876922666};\\\", \\\"{x:1078,y:661,t:1527876922683};\\\", \\\"{x:1090,y:665,t:1527876922699};\\\", \\\"{x:1102,y:667,t:1527876922716};\\\", \\\"{x:1112,y:671,t:1527876922733};\\\", \\\"{x:1121,y:675,t:1527876922749};\\\", \\\"{x:1129,y:676,t:1527876922766};\\\", \\\"{x:1142,y:680,t:1527876922783};\\\", \\\"{x:1162,y:688,t:1527876922799};\\\", \\\"{x:1193,y:700,t:1527876922816};\\\", \\\"{x:1213,y:706,t:1527876922833};\\\", \\\"{x:1234,y:713,t:1527876922849};\\\", \\\"{x:1252,y:718,t:1527876922866};\\\", \\\"{x:1273,y:723,t:1527876922884};\\\", \\\"{x:1291,y:729,t:1527876922899};\\\", \\\"{x:1306,y:732,t:1527876922916};\\\", \\\"{x:1312,y:734,t:1527876922933};\\\", \\\"{x:1313,y:734,t:1527876922949};\\\", \\\"{x:1315,y:734,t:1527876923056};\\\", \\\"{x:1316,y:735,t:1527876923066};\\\", \\\"{x:1320,y:737,t:1527876923083};\\\", \\\"{x:1321,y:738,t:1527876923099};\\\", \\\"{x:1322,y:738,t:1527876923116};\\\", \\\"{x:1326,y:742,t:1527876923133};\\\", \\\"{x:1328,y:748,t:1527876923149};\\\", \\\"{x:1332,y:756,t:1527876923166};\\\", \\\"{x:1334,y:762,t:1527876923183};\\\", \\\"{x:1336,y:771,t:1527876923200};\\\", \\\"{x:1337,y:776,t:1527876923216};\\\", \\\"{x:1339,y:781,t:1527876923233};\\\", \\\"{x:1340,y:788,t:1527876923250};\\\", \\\"{x:1345,y:798,t:1527876923267};\\\", \\\"{x:1350,y:807,t:1527876923283};\\\", \\\"{x:1356,y:818,t:1527876923300};\\\", \\\"{x:1358,y:823,t:1527876923317};\\\", \\\"{x:1360,y:828,t:1527876923333};\\\", \\\"{x:1361,y:829,t:1527876923350};\\\", \\\"{x:1362,y:831,t:1527876923366};\\\", \\\"{x:1362,y:832,t:1527876923383};\\\", \\\"{x:1362,y:835,t:1527876923400};\\\", \\\"{x:1362,y:838,t:1527876923416};\\\", \\\"{x:1364,y:843,t:1527876923433};\\\", \\\"{x:1365,y:846,t:1527876923451};\\\", \\\"{x:1365,y:847,t:1527876923467};\\\", \\\"{x:1365,y:848,t:1527876923484};\\\", \\\"{x:1365,y:849,t:1527876923500};\\\", \\\"{x:1366,y:850,t:1527876923516};\\\", \\\"{x:1366,y:853,t:1527876923533};\\\", \\\"{x:1367,y:854,t:1527876923550};\\\", \\\"{x:1368,y:859,t:1527876923566};\\\", \\\"{x:1369,y:862,t:1527876923583};\\\", \\\"{x:1371,y:867,t:1527876923600};\\\", \\\"{x:1371,y:870,t:1527876923616};\\\", \\\"{x:1372,y:873,t:1527876923634};\\\", \\\"{x:1372,y:878,t:1527876923651};\\\", \\\"{x:1372,y:884,t:1527876923667};\\\", \\\"{x:1373,y:887,t:1527876923683};\\\", \\\"{x:1374,y:891,t:1527876923700};\\\", \\\"{x:1374,y:892,t:1527876923717};\\\", \\\"{x:1374,y:895,t:1527876923734};\\\", \\\"{x:1374,y:898,t:1527876923750};\\\", \\\"{x:1374,y:904,t:1527876923766};\\\", \\\"{x:1374,y:909,t:1527876923783};\\\", \\\"{x:1375,y:914,t:1527876923800};\\\", \\\"{x:1376,y:917,t:1527876923817};\\\", \\\"{x:1377,y:921,t:1527876923833};\\\", \\\"{x:1377,y:924,t:1527876923851};\\\", \\\"{x:1377,y:927,t:1527876923867};\\\", \\\"{x:1378,y:927,t:1527876923883};\\\", \\\"{x:1378,y:929,t:1527876923900};\\\", \\\"{x:1378,y:930,t:1527876923919};\\\", \\\"{x:1379,y:931,t:1527876923935};\\\", \\\"{x:1379,y:932,t:1527876923950};\\\", \\\"{x:1380,y:932,t:1527876923967};\\\", \\\"{x:1380,y:933,t:1527876924104};\\\", \\\"{x:1381,y:933,t:1527876924118};\\\", \\\"{x:1383,y:933,t:1527876924133};\\\", \\\"{x:1384,y:933,t:1527876924150};\\\", \\\"{x:1386,y:933,t:1527876924168};\\\", \\\"{x:1388,y:933,t:1527876924183};\\\", \\\"{x:1390,y:932,t:1527876924201};\\\", \\\"{x:1393,y:932,t:1527876924217};\\\", \\\"{x:1394,y:932,t:1527876924233};\\\", \\\"{x:1395,y:932,t:1527876924251};\\\", \\\"{x:1397,y:931,t:1527876924267};\\\", \\\"{x:1400,y:930,t:1527876924283};\\\", \\\"{x:1401,y:929,t:1527876924300};\\\", \\\"{x:1404,y:929,t:1527876924317};\\\", \\\"{x:1407,y:928,t:1527876924334};\\\", \\\"{x:1411,y:928,t:1527876924350};\\\", \\\"{x:1414,y:926,t:1527876924367};\\\", \\\"{x:1417,y:925,t:1527876924384};\\\", \\\"{x:1418,y:924,t:1527876924400};\\\", \\\"{x:1420,y:923,t:1527876924425};\\\", \\\"{x:1420,y:922,t:1527876924456};\\\", \\\"{x:1421,y:922,t:1527876924488};\\\", \\\"{x:1423,y:922,t:1527876924704};\\\", \\\"{x:1425,y:922,t:1527876924720};\\\", \\\"{x:1427,y:922,t:1527876924735};\\\", \\\"{x:1431,y:924,t:1527876924750};\\\", \\\"{x:1436,y:927,t:1527876924768};\\\", \\\"{x:1442,y:932,t:1527876924785};\\\", \\\"{x:1444,y:933,t:1527876924800};\\\", \\\"{x:1445,y:933,t:1527876924889};\\\", \\\"{x:1446,y:933,t:1527876924905};\\\", \\\"{x:1447,y:933,t:1527876924917};\\\", \\\"{x:1448,y:933,t:1527876924936};\\\", \\\"{x:1448,y:934,t:1527876925176};\\\", \\\"{x:1448,y:935,t:1527876925184};\\\", \\\"{x:1449,y:936,t:1527876925201};\\\", \\\"{x:1449,y:938,t:1527876925217};\\\", \\\"{x:1449,y:939,t:1527876925235};\\\", \\\"{x:1449,y:940,t:1527876925392};\\\", \\\"{x:1449,y:941,t:1527876925401};\\\", \\\"{x:1449,y:942,t:1527876925417};\\\", \\\"{x:1449,y:944,t:1527876925434};\\\", \\\"{x:1449,y:946,t:1527876925451};\\\", \\\"{x:1449,y:949,t:1527876925468};\\\", \\\"{x:1449,y:951,t:1527876925484};\\\", \\\"{x:1449,y:952,t:1527876925501};\\\", \\\"{x:1449,y:953,t:1527876925528};\\\", \\\"{x:1449,y:954,t:1527876925536};\\\", \\\"{x:1449,y:955,t:1527876925551};\\\", \\\"{x:1449,y:956,t:1527876925575};\\\", \\\"{x:1450,y:958,t:1527876925600};\\\", \\\"{x:1450,y:959,t:1527876925616};\\\", \\\"{x:1451,y:959,t:1527876925632};\\\", \\\"{x:1452,y:960,t:1527876925640};\\\", \\\"{x:1454,y:961,t:1527876925651};\\\", \\\"{x:1455,y:962,t:1527876925668};\\\", \\\"{x:1460,y:962,t:1527876925684};\\\", \\\"{x:1463,y:963,t:1527876925701};\\\", \\\"{x:1469,y:965,t:1527876925718};\\\", \\\"{x:1472,y:966,t:1527876925734};\\\", \\\"{x:1474,y:967,t:1527876925752};\\\", \\\"{x:1476,y:968,t:1527876925767};\\\", \\\"{x:1478,y:969,t:1527876925848};\\\", \\\"{x:1478,y:968,t:1527876926072};\\\", \\\"{x:1478,y:965,t:1527876926085};\\\", \\\"{x:1478,y:957,t:1527876926101};\\\", \\\"{x:1478,y:949,t:1527876926118};\\\", \\\"{x:1478,y:943,t:1527876926136};\\\", \\\"{x:1478,y:938,t:1527876926151};\\\", \\\"{x:1478,y:934,t:1527876926167};\\\", \\\"{x:1478,y:933,t:1527876926185};\\\", \\\"{x:1478,y:931,t:1527876926201};\\\", \\\"{x:1477,y:928,t:1527876926219};\\\", \\\"{x:1477,y:926,t:1527876926236};\\\", \\\"{x:1477,y:924,t:1527876926251};\\\", \\\"{x:1477,y:923,t:1527876926268};\\\", \\\"{x:1476,y:921,t:1527876926285};\\\", \\\"{x:1476,y:919,t:1527876926302};\\\", \\\"{x:1476,y:917,t:1527876926318};\\\", \\\"{x:1476,y:915,t:1527876926336};\\\", \\\"{x:1476,y:911,t:1527876926351};\\\", \\\"{x:1476,y:905,t:1527876926367};\\\", \\\"{x:1476,y:900,t:1527876926385};\\\", \\\"{x:1476,y:897,t:1527876926401};\\\", \\\"{x:1476,y:893,t:1527876926419};\\\", \\\"{x:1476,y:887,t:1527876926435};\\\", \\\"{x:1476,y:883,t:1527876926451};\\\", \\\"{x:1476,y:879,t:1527876926468};\\\", \\\"{x:1475,y:877,t:1527876926486};\\\", \\\"{x:1475,y:875,t:1527876926502};\\\", \\\"{x:1475,y:872,t:1527876926518};\\\", \\\"{x:1475,y:870,t:1527876926535};\\\", \\\"{x:1474,y:868,t:1527876926551};\\\", \\\"{x:1474,y:867,t:1527876926584};\\\", \\\"{x:1473,y:867,t:1527876926600};\\\", \\\"{x:1473,y:866,t:1527876927152};\\\", \\\"{x:1473,y:864,t:1527876927169};\\\", \\\"{x:1473,y:863,t:1527876927185};\\\", \\\"{x:1473,y:861,t:1527876927224};\\\", \\\"{x:1473,y:860,t:1527876927256};\\\", \\\"{x:1473,y:858,t:1527876927304};\\\", \\\"{x:1473,y:860,t:1527876927576};\\\", \\\"{x:1473,y:862,t:1527876927585};\\\", \\\"{x:1473,y:867,t:1527876927602};\\\", \\\"{x:1473,y:877,t:1527876927619};\\\", \\\"{x:1476,y:892,t:1527876927635};\\\", \\\"{x:1480,y:909,t:1527876927653};\\\", \\\"{x:1485,y:925,t:1527876927669};\\\", \\\"{x:1489,y:937,t:1527876927685};\\\", \\\"{x:1490,y:943,t:1527876927702};\\\", \\\"{x:1492,y:948,t:1527876927719};\\\", \\\"{x:1492,y:951,t:1527876927736};\\\", \\\"{x:1493,y:953,t:1527876927752};\\\", \\\"{x:1493,y:956,t:1527876927769};\\\", \\\"{x:1493,y:959,t:1527876927786};\\\", \\\"{x:1493,y:960,t:1527876927802};\\\", \\\"{x:1493,y:959,t:1527876927960};\\\", \\\"{x:1493,y:957,t:1527876927969};\\\", \\\"{x:1491,y:954,t:1527876927987};\\\", \\\"{x:1490,y:951,t:1527876928003};\\\", \\\"{x:1490,y:947,t:1527876928019};\\\", \\\"{x:1489,y:944,t:1527876928036};\\\", \\\"{x:1489,y:939,t:1527876928053};\\\", \\\"{x:1489,y:932,t:1527876928069};\\\", \\\"{x:1489,y:928,t:1527876928087};\\\", \\\"{x:1489,y:923,t:1527876928102};\\\", \\\"{x:1489,y:917,t:1527876928119};\\\", \\\"{x:1489,y:906,t:1527876928136};\\\", \\\"{x:1489,y:900,t:1527876928153};\\\", \\\"{x:1489,y:896,t:1527876928169};\\\", \\\"{x:1489,y:890,t:1527876928187};\\\", \\\"{x:1489,y:887,t:1527876928202};\\\", \\\"{x:1489,y:886,t:1527876928220};\\\", \\\"{x:1488,y:885,t:1527876928236};\\\", \\\"{x:1486,y:885,t:1527876928312};\\\", \\\"{x:1483,y:885,t:1527876928320};\\\", \\\"{x:1477,y:885,t:1527876928335};\\\", \\\"{x:1469,y:887,t:1527876928353};\\\", \\\"{x:1460,y:890,t:1527876928370};\\\", \\\"{x:1446,y:894,t:1527876928386};\\\", \\\"{x:1425,y:898,t:1527876928403};\\\", \\\"{x:1396,y:899,t:1527876928419};\\\", \\\"{x:1358,y:899,t:1527876928436};\\\", \\\"{x:1294,y:899,t:1527876928453};\\\", \\\"{x:1215,y:894,t:1527876928469};\\\", \\\"{x:1102,y:863,t:1527876928487};\\\", \\\"{x:966,y:825,t:1527876928504};\\\", \\\"{x:793,y:780,t:1527876928519};\\\", \\\"{x:606,y:752,t:1527876928536};\\\", \\\"{x:500,y:739,t:1527876928554};\\\", \\\"{x:414,y:725,t:1527876928570};\\\", \\\"{x:339,y:715,t:1527876928586};\\\", \\\"{x:312,y:708,t:1527876928603};\\\", \\\"{x:290,y:704,t:1527876928620};\\\", \\\"{x:284,y:704,t:1527876928637};\\\", \\\"{x:283,y:704,t:1527876928654};\\\", \\\"{x:288,y:706,t:1527876928704};\\\", \\\"{x:294,y:709,t:1527876928720};\\\", \\\"{x:297,y:710,t:1527876928737};\\\", \\\"{x:298,y:710,t:1527876928754};\\\", \\\"{x:299,y:710,t:1527876928776};\\\", \\\"{x:299,y:707,t:1527876928787};\\\", \\\"{x:299,y:696,t:1527876928805};\\\", \\\"{x:299,y:688,t:1527876928820};\\\", \\\"{x:299,y:679,t:1527876928838};\\\", \\\"{x:302,y:673,t:1527876928854};\\\", \\\"{x:307,y:664,t:1527876928871};\\\", \\\"{x:310,y:660,t:1527876928888};\\\", \\\"{x:312,y:654,t:1527876928904};\\\", \\\"{x:316,y:649,t:1527876928922};\\\", \\\"{x:322,y:643,t:1527876928938};\\\", \\\"{x:332,y:633,t:1527876928954};\\\", \\\"{x:346,y:624,t:1527876928972};\\\", \\\"{x:360,y:616,t:1527876928987};\\\", \\\"{x:374,y:609,t:1527876929005};\\\", \\\"{x:387,y:602,t:1527876929022};\\\", \\\"{x:403,y:592,t:1527876929039};\\\", \\\"{x:416,y:586,t:1527876929054};\\\", \\\"{x:426,y:581,t:1527876929071};\\\", \\\"{x:441,y:578,t:1527876929088};\\\", \\\"{x:449,y:578,t:1527876929104};\\\", \\\"{x:463,y:578,t:1527876929122};\\\", \\\"{x:485,y:578,t:1527876929137};\\\", \\\"{x:508,y:578,t:1527876929154};\\\", \\\"{x:531,y:578,t:1527876929171};\\\", \\\"{x:558,y:578,t:1527876929188};\\\", \\\"{x:578,y:578,t:1527876929204};\\\", \\\"{x:586,y:578,t:1527876929221};\\\", \\\"{x:590,y:578,t:1527876929239};\\\", \\\"{x:593,y:578,t:1527876929254};\\\", \\\"{x:595,y:578,t:1527876929271};\\\", \\\"{x:599,y:580,t:1527876929288};\\\", \\\"{x:601,y:580,t:1527876929305};\\\", \\\"{x:605,y:580,t:1527876929321};\\\", \\\"{x:608,y:579,t:1527876929339};\\\", \\\"{x:611,y:578,t:1527876929354};\\\", \\\"{x:613,y:577,t:1527876929372};\\\", \\\"{x:615,y:575,t:1527876929388};\\\", \\\"{x:617,y:571,t:1527876929405};\\\", \\\"{x:618,y:567,t:1527876929422};\\\", \\\"{x:618,y:564,t:1527876929438};\\\", \\\"{x:619,y:563,t:1527876929456};\\\", \\\"{x:619,y:564,t:1527876929632};\\\", \\\"{x:619,y:566,t:1527876929640};\\\", \\\"{x:619,y:568,t:1527876929654};\\\", \\\"{x:616,y:574,t:1527876929672};\\\", \\\"{x:611,y:583,t:1527876929689};\\\", \\\"{x:608,y:587,t:1527876929705};\\\", \\\"{x:605,y:591,t:1527876929722};\\\", \\\"{x:603,y:593,t:1527876929739};\\\", \\\"{x:602,y:595,t:1527876929755};\\\", \\\"{x:600,y:601,t:1527876931877};\\\", \\\"{x:589,y:613,t:1527876931886};\\\", \\\"{x:574,y:625,t:1527876931896};\\\", \\\"{x:549,y:641,t:1527876931911};\\\", \\\"{x:524,y:649,t:1527876931928};\\\", \\\"{x:484,y:660,t:1527876931945};\\\", \\\"{x:445,y:664,t:1527876931961};\\\", \\\"{x:419,y:669,t:1527876931979};\\\", \\\"{x:410,y:669,t:1527876931995};\\\", \\\"{x:406,y:669,t:1527876932011};\\\", \\\"{x:403,y:669,t:1527876932028};\\\", \\\"{x:400,y:669,t:1527876932045};\\\", \\\"{x:405,y:671,t:1527876932149};\\\", \\\"{x:412,y:676,t:1527876932162};\\\", \\\"{x:420,y:684,t:1527876932178};\\\", \\\"{x:430,y:698,t:1527876932195};\\\", \\\"{x:442,y:713,t:1527876932212};\\\", \\\"{x:447,y:721,t:1527876932228};\\\", \\\"{x:450,y:724,t:1527876932245};\\\", \\\"{x:453,y:725,t:1527876932276};\\\", \\\"{x:456,y:726,t:1527876932284};\\\", \\\"{x:462,y:727,t:1527876932295};\\\", \\\"{x:477,y:729,t:1527876932313};\\\", \\\"{x:486,y:731,t:1527876932328};\\\", \\\"{x:493,y:732,t:1527876932345};\\\", \\\"{x:499,y:735,t:1527876932363};\\\", \\\"{x:501,y:736,t:1527876932378};\\\", \\\"{x:504,y:737,t:1527876932395};\\\", \\\"{x:505,y:737,t:1527876932412};\\\", \\\"{x:506,y:737,t:1527876932493};\\\", \\\"{x:506,y:738,t:1527876932500};\\\", \\\"{x:507,y:738,t:1527876932513};\\\", \\\"{x:509,y:740,t:1527876932529};\\\", \\\"{x:511,y:743,t:1527876932546};\\\", \\\"{x:513,y:745,t:1527876932562};\\\", \\\"{x:513,y:746,t:1527876932588};\\\", \\\"{x:513,y:744,t:1527876933445};\\\", \\\"{x:510,y:740,t:1527876933452};\\\", \\\"{x:506,y:733,t:1527876933462};\\\", \\\"{x:493,y:718,t:1527876933479};\\\", \\\"{x:473,y:700,t:1527876933497};\\\", \\\"{x:445,y:678,t:1527876933513};\\\", \\\"{x:406,y:654,t:1527876933529};\\\", \\\"{x:370,y:629,t:1527876933546};\\\", \\\"{x:329,y:605,t:1527876933563};\\\", \\\"{x:264,y:569,t:1527876933580};\\\", \\\"{x:186,y:518,t:1527876933597};\\\", \\\"{x:54,y:415,t:1527876933612};\\\", \\\"{x:0,y:338,t:1527876933629};\\\", \\\"{x:0,y:247,t:1527876933646};\\\", \\\"{x:0,y:151,t:1527876933663};\\\", \\\"{x:0,y:22,t:1527876933680};\\\", \\\"{x:0,y:0,t:1527876933696};\\\", \\\"{x:12,y:0,t:1527876934047};\\\", \\\"{x:95,y:34,t:1527876934063};\\\", \\\"{x:225,y:97,t:1527876934080};\\\", \\\"{x:373,y:180,t:1527876934096};\\\" ] }, { \\\"rt\\\": 38490, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 580061, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"2ZXKM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"The events that start at 12 PM are on the diagonal line that intersects with the x-axis. I'm really just trying to listen to the new Kanye album but this study is taking me out\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 6910, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"22\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"USA\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 587972, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"2ZXKM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 8976, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Fourth\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Engineering\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Male\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 597958, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"2ZXKM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 6767, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 605815, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"2ZXKM\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"2ZXKM\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 230, dom: 786, initialDom: 902",
  "javascriptErrors": []
}