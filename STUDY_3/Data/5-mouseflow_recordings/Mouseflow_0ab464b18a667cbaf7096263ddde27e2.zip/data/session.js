var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "0ab464b18a667cbaf7096263ddde27e2",
  "created": "2018-05-19T13:04:17.4773426-07:00",
  "lastActivity": "2018-05-19T13:04:47.4613426-07:00",
  "pageViews": [
    {
      "id": "05191744949066f1671ded1b5b085ea8d963d86a",
      "startTime": "2018-05-19T13:04:17.4773426-07:00",
      "endTime": "2018-05-19T13:04:47.4613426-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/13",
      "visitTime": 29984,
      "engagementTime": 16190,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 29984,
  "engagementTime": 16190,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.22",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0",
  "browser": "Firefox",
  "browserVersion": "59.0",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=93YLJ",
    "CONDITION=113"
  ],
  "watched": false,
  "starred": true,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "20efd6a44ccd1fae3bad8daa1cd1a327",
  "gdpr": false
}