var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "9a2bc69376137a12fce326a0fc35936d",
  "created": "2018-06-04T12:12:39.9149223-07:00",
  "lastActivity": "2018-06-04T12:12:56.6887314-07:00",
  "pageViews": [
    {
      "id": "06043931e0ed5ee0f264593653f560f3e21cc306",
      "startTime": "2018-06-04T12:12:40.0698486-07:00",
      "endTime": "2018-06-04T12:12:56.6887314-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/1",
      "visitTime": 17036,
      "engagementTime": 17036,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 17036,
  "engagementTime": 17036,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.22",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=S6D2F",
    "CONDITION=311",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "8dfaeb99e37c27652de0d481bd7328aa",
  "gdpr": false
}