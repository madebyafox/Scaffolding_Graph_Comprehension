var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["0522416403ab2a17f0232b9d93bb8a54044b31dc"] = {
  "startTime": "2018-05-22T22:12:41.6290808Z",
  "websitePageUrl": "/",
  "visitTime": 75254,
  "engagementTime": 60754,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1094,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "bafd868e0a0ed027a543373b0859820b",
    "created": "2018-05-22T22:12:41.6290808+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "43f33844b9e4b9351e6cb47056930258",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/bafd868e0a0ed027a543373b0859820b/play"
  },
  "events": [
    {
      "t": 101,
      "e": 101,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 252,
      "e": 252,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 1404,
      "e": 1404,
      "ty": 2,
      "x": 576,
      "y": 27
    },
    {
      "t": 1500,
      "e": 1500,
      "ty": 2,
      "x": 793,
      "y": 455
    },
    {
      "t": 1500,
      "e": 1500,
      "ty": 41,
      "x": 23674,
      "y": 25271,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 1600,
      "e": 1600,
      "ty": 2,
      "x": 956,
      "y": 706
    },
    {
      "t": 1700,
      "e": 1700,
      "ty": 2,
      "x": 970,
      "y": 752
    },
    {
      "t": 1751,
      "e": 1751,
      "ty": 41,
      "x": 31975,
      "y": 49437,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 1800,
      "e": 1800,
      "ty": 2,
      "x": 884,
      "y": 733
    },
    {
      "t": 1900,
      "e": 1900,
      "ty": 2,
      "x": 779,
      "y": 705
    },
    {
      "t": 2000,
      "e": 2000,
      "ty": 2,
      "x": 777,
      "y": 704
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 41,
      "x": 22800,
      "y": 45669,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 2200,
      "e": 2200,
      "ty": 2,
      "x": 786,
      "y": 699
    },
    {
      "t": 2250,
      "e": 2250,
      "ty": 41,
      "x": 23401,
      "y": 45178,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 2300,
      "e": 2300,
      "ty": 2,
      "x": 790,
      "y": 697
    },
    {
      "t": 2401,
      "e": 2401,
      "ty": 2,
      "x": 791,
      "y": 696
    },
    {
      "t": 2501,
      "e": 2501,
      "ty": 41,
      "x": 23565,
      "y": 45014,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 2700,
      "e": 2700,
      "ty": 2,
      "x": 792,
      "y": 692
    },
    {
      "t": 2751,
      "e": 2751,
      "ty": 41,
      "x": 23783,
      "y": 44522,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 2801,
      "e": 2801,
      "ty": 2,
      "x": 799,
      "y": 683
    },
    {
      "t": 2900,
      "e": 2900,
      "ty": 2,
      "x": 805,
      "y": 674
    },
    {
      "t": 3001,
      "e": 3001,
      "ty": 2,
      "x": 813,
      "y": 664
    },
    {
      "t": 3001,
      "e": 3001,
      "ty": 41,
      "x": 24766,
      "y": 42392,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 3100,
      "e": 3100,
      "ty": 2,
      "x": 813,
      "y": 663
    },
    {
      "t": 3251,
      "e": 3251,
      "ty": 41,
      "x": 24766,
      "y": 42311,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 5100,
      "e": 5100,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 5201,
      "e": 5201,
      "ty": 2,
      "x": 813,
      "y": 729
    },
    {
      "t": 5251,
      "e": 5251,
      "ty": 41,
      "x": 24766,
      "y": 43375,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 6251,
      "e": 6251,
      "ty": 41,
      "x": 23346,
      "y": 42065,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 6301,
      "e": 6301,
      "ty": 2,
      "x": 746,
      "y": 695
    },
    {
      "t": 6501,
      "e": 6501,
      "ty": 41,
      "x": 21107,
      "y": 40590,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 7900,
      "e": 7900,
      "ty": 2,
      "x": 756,
      "y": 697
    },
    {
      "t": 8001,
      "e": 8001,
      "ty": 41,
      "x": 21653,
      "y": 40754,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 9607,
      "e": 9607,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 10001,
      "e": 10001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10752,
      "e": 10752,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 14500,
      "e": 13001,
      "ty": 2,
      "x": 757,
      "y": 697
    },
    {
      "t": 14501,
      "e": 13002,
      "ty": 41,
      "x": 22805,
      "y": 11241,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 15001,
      "e": 13502,
      "ty": 2,
      "x": 753,
      "y": 694
    },
    {
      "t": 15002,
      "e": 13503,
      "ty": 41,
      "x": 22608,
      "y": 9837,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 19001,
      "e": 17502,
      "ty": 2,
      "x": 752,
      "y": 694
    },
    {
      "t": 19002,
      "e": 17503,
      "ty": 41,
      "x": 22559,
      "y": 9837,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 20001,
      "e": 18502,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 33001,
      "e": 22503,
      "ty": 2,
      "x": 751,
      "y": 694
    },
    {
      "t": 33001,
      "e": 22503,
      "ty": 41,
      "x": 22509,
      "y": 9837,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 33500,
      "e": 23002,
      "ty": 2,
      "x": 751,
      "y": 692
    },
    {
      "t": 33501,
      "e": 23003,
      "ty": 41,
      "x": 22509,
      "y": 8901,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 33601,
      "e": 23103,
      "ty": 2,
      "x": 740,
      "y": 676
    },
    {
      "t": 33701,
      "e": 23203,
      "ty": 2,
      "x": 740,
      "y": 675
    },
    {
      "t": 33751,
      "e": 23253,
      "ty": 41,
      "x": 21968,
      "y": 943,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 34751,
      "e": 24253,
      "ty": 41,
      "x": 21919,
      "y": 475,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 34800,
      "e": 24302,
      "ty": 2,
      "x": 736,
      "y": 676
    },
    {
      "t": 34901,
      "e": 24403,
      "ty": 2,
      "x": 734,
      "y": 680
    },
    {
      "t": 35001,
      "e": 24503,
      "ty": 41,
      "x": 21673,
      "y": 3284,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 40001,
      "e": 29503,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40252,
      "e": 29503,
      "ty": 41,
      "x": 21673,
      "y": 1411,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 40301,
      "e": 29552,
      "ty": 2,
      "x": 734,
      "y": 666
    },
    {
      "t": 40401,
      "e": 29652,
      "ty": 2,
      "x": 734,
      "y": 663
    },
    {
      "t": 40501,
      "e": 29752,
      "ty": 2,
      "x": 737,
      "y": 666
    },
    {
      "t": 40501,
      "e": 29752,
      "ty": 41,
      "x": 21821,
      "y": 37790,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 40700,
      "e": 29951,
      "ty": 2,
      "x": 739,
      "y": 667
    },
    {
      "t": 40752,
      "e": 30003,
      "ty": 41,
      "x": 22165,
      "y": 38204,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 40801,
      "e": 30052,
      "ty": 2,
      "x": 745,
      "y": 671
    },
    {
      "t": 41001,
      "e": 30252,
      "ty": 2,
      "x": 749,
      "y": 684
    },
    {
      "t": 41002,
      "e": 30253,
      "ty": 41,
      "x": 22411,
      "y": 5156,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 41101,
      "e": 30352,
      "ty": 2,
      "x": 750,
      "y": 693
    },
    {
      "t": 41251,
      "e": 30502,
      "ty": 41,
      "x": 22460,
      "y": 9369,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 42800,
      "e": 32051,
      "ty": 2,
      "x": 757,
      "y": 706
    },
    {
      "t": 42900,
      "e": 32151,
      "ty": 2,
      "x": 784,
      "y": 773
    },
    {
      "t": 43000,
      "e": 32251,
      "ty": 2,
      "x": 812,
      "y": 888
    },
    {
      "t": 43001,
      "e": 32252,
      "ty": 41,
      "x": 25510,
      "y": 60774,
      "ta": "> div.masterdiv > div:[2] > div"
    },
    {
      "t": 43100,
      "e": 32351,
      "ty": 2,
      "x": 820,
      "y": 987
    },
    {
      "t": 43251,
      "e": 32502,
      "ty": 41,
      "x": 25904,
      "y": 59462,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 43300,
      "e": 32551,
      "ty": 2,
      "x": 826,
      "y": 950
    },
    {
      "t": 43400,
      "e": 32651,
      "ty": 2,
      "x": 821,
      "y": 924
    },
    {
      "t": 43500,
      "e": 32751,
      "ty": 2,
      "x": 812,
      "y": 922
    },
    {
      "t": 43500,
      "e": 32751,
      "ty": 41,
      "x": 28057,
      "y": 36095,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 43599,
      "e": 32850,
      "ty": 3,
      "x": 810,
      "y": 922,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 43600,
      "e": 32851,
      "ty": 2,
      "x": 810,
      "y": 922
    },
    {
      "t": 43644,
      "e": 32895,
      "ty": 4,
      "x": 21503,
      "y": 36095,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 43644,
      "e": 32895,
      "ty": 5,
      "x": 810,
      "y": 922,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 43646,
      "e": 32897,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 43648,
      "e": 32899,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 43751,
      "e": 33002,
      "ty": 41,
      "x": 47717,
      "y": 49202,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 43800,
      "e": 33051,
      "ty": 2,
      "x": 873,
      "y": 975
    },
    {
      "t": 43862,
      "e": 33113,
      "ty": 6,
      "x": 988,
      "y": 1088,
      "ta": "#start"
    },
    {
      "t": 43896,
      "e": 33147,
      "ty": 7,
      "x": 1007,
      "y": 1109,
      "ta": "#start"
    },
    {
      "t": 43901,
      "e": 33152,
      "ty": 2,
      "x": 1007,
      "y": 1109
    },
    {
      "t": 44001,
      "e": 33252,
      "ty": 2,
      "x": 1025,
      "y": 1121
    },
    {
      "t": 44001,
      "e": 33252,
      "ty": 41,
      "x": 63428,
      "y": 26764,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 44097,
      "e": 33348,
      "ty": 6,
      "x": 1016,
      "y": 1104,
      "ta": "#start"
    },
    {
      "t": 44101,
      "e": 33352,
      "ty": 2,
      "x": 1016,
      "y": 1104
    },
    {
      "t": 44201,
      "e": 33452,
      "ty": 2,
      "x": 994,
      "y": 1092
    },
    {
      "t": 44250,
      "e": 33501,
      "ty": 41,
      "x": 45601,
      "y": 37224,
      "ta": "#start"
    },
    {
      "t": 44300,
      "e": 33551,
      "ty": 2,
      "x": 993,
      "y": 1092
    },
    {
      "t": 44356,
      "e": 33607,
      "ty": 3,
      "x": 992,
      "y": 1091,
      "ta": "#start"
    },
    {
      "t": 44356,
      "e": 33607,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 44356,
      "e": 33607,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 44400,
      "e": 33651,
      "ty": 2,
      "x": 992,
      "y": 1091
    },
    {
      "t": 44428,
      "e": 33679,
      "ty": 4,
      "x": 44509,
      "y": 35297,
      "ta": "#start"
    },
    {
      "t": 44430,
      "e": 33681,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 44431,
      "e": 33682,
      "ty": 5,
      "x": 991,
      "y": 1091,
      "ta": "#start"
    },
    {
      "t": 44431,
      "e": 33682,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 44501,
      "e": 33752,
      "ty": 2,
      "x": 991,
      "y": 1090
    },
    {
      "t": 44501,
      "e": 33752,
      "ty": 41,
      "x": 33852,
      "y": 59939,
      "ta": "html > body"
    },
    {
      "t": 44601,
      "e": 33852,
      "ty": 2,
      "x": 991,
      "y": 1080
    },
    {
      "t": 44700,
      "e": 33951,
      "ty": 2,
      "x": 1055,
      "y": 1024
    },
    {
      "t": 44751,
      "e": 34002,
      "ty": 41,
      "x": 36641,
      "y": 55452,
      "ta": "html > body"
    },
    {
      "t": 44801,
      "e": 34052,
      "ty": 2,
      "x": 1079,
      "y": 1001
    },
    {
      "t": 44901,
      "e": 34152,
      "ty": 2,
      "x": 1083,
      "y": 993
    },
    {
      "t": 45001,
      "e": 34252,
      "ty": 2,
      "x": 1084,
      "y": 993
    },
    {
      "t": 45001,
      "e": 34252,
      "ty": 41,
      "x": 37054,
      "y": 54566,
      "ta": "html > body"
    },
    {
      "t": 45433,
      "e": 34684,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 46200,
      "e": 35451,
      "ty": 2,
      "x": 1075,
      "y": 931
    },
    {
      "t": 46250,
      "e": 35501,
      "ty": 41,
      "x": 36331,
      "y": 47032,
      "ta": "html > body"
    },
    {
      "t": 46299,
      "e": 35550,
      "ty": 6,
      "x": 1013,
      "y": 687,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 46301,
      "e": 35552,
      "ty": 2,
      "x": 1013,
      "y": 687
    },
    {
      "t": 46314,
      "e": 35565,
      "ty": 7,
      "x": 1005,
      "y": 641,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 46332,
      "e": 35583,
      "ty": 6,
      "x": 999,
      "y": 600,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 46348,
      "e": 35599,
      "ty": 7,
      "x": 993,
      "y": 575,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 46401,
      "e": 35652,
      "ty": 2,
      "x": 981,
      "y": 510
    },
    {
      "t": 46501,
      "e": 35752,
      "ty": 2,
      "x": 978,
      "y": 505
    },
    {
      "t": 46501,
      "e": 35752,
      "ty": 41,
      "x": 35149,
      "y": 48127,
      "ta": "#jspsych-survey-text-preamble"
    },
    {
      "t": 46600,
      "e": 35851,
      "ty": 2,
      "x": 1000,
      "y": 578
    },
    {
      "t": 46700,
      "e": 35951,
      "ty": 6,
      "x": 1002,
      "y": 586,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 46701,
      "e": 35952,
      "ty": 2,
      "x": 1002,
      "y": 586
    },
    {
      "t": 46750,
      "e": 36001,
      "ty": 41,
      "x": 42608,
      "y": 37448,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 46780,
      "e": 36031,
      "ty": 7,
      "x": 1007,
      "y": 613,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 46800,
      "e": 36051,
      "ty": 2,
      "x": 1007,
      "y": 614
    },
    {
      "t": 46877,
      "e": 36128,
      "ty": 3,
      "x": 1007,
      "y": 614,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 46965,
      "e": 36216,
      "ty": 4,
      "x": 43041,
      "y": 64830,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 46965,
      "e": 36216,
      "ty": 5,
      "x": 1007,
      "y": 614,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 47001,
      "e": 36252,
      "ty": 41,
      "x": 43041,
      "y": 64830,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 47048,
      "e": 36299,
      "ty": 6,
      "x": 1008,
      "y": 604,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 47101,
      "e": 36352,
      "ty": 2,
      "x": 1009,
      "y": 600
    },
    {
      "t": 47201,
      "e": 36452,
      "ty": 2,
      "x": 1009,
      "y": 599
    },
    {
      "t": 47230,
      "e": 36481,
      "ty": 3,
      "x": 1009,
      "y": 599,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 47231,
      "e": 36482,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 47250,
      "e": 36501,
      "ty": 41,
      "x": 43473,
      "y": 40569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 47292,
      "e": 36543,
      "ty": 4,
      "x": 43473,
      "y": 40569,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 47292,
      "e": 36543,
      "ty": 5,
      "x": 1009,
      "y": 599,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 49249,
      "e": 38500,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "73"
    },
    {
      "t": 49251,
      "e": 38502,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 49344,
      "e": 38595,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "78"
    },
    {
      "t": 49344,
      "e": 38595,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 49385,
      "e": 38636,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "in"
    },
    {
      "t": 49440,
      "e": 38691,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "68"
    },
    {
      "t": 49440,
      "e": 38691,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 49464,
      "e": 38715,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "ind"
    },
    {
      "t": 49552,
      "e": 38803,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "73"
    },
    {
      "t": 49552,
      "e": 38803,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 49568,
      "e": 38819,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "indi"
    },
    {
      "t": 49640,
      "e": 38891,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||"
    },
    {
      "t": 49672,
      "e": 38923,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "65"
    },
    {
      "t": 49672,
      "e": 38923,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 49784,
      "e": 39035,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "+||a"
    },
    {
      "t": 50001,
      "e": 39252,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 50150,
      "e": 39401,
      "ty": 7,
      "x": 1115,
      "y": 571,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 50201,
      "e": 39452,
      "ty": 2,
      "x": 1190,
      "y": 579
    },
    {
      "t": 50251,
      "e": 39502,
      "ty": 41,
      "x": 40774,
      "y": 31742,
      "ta": "html > body"
    },
    {
      "t": 50301,
      "e": 39552,
      "ty": 2,
      "x": 977,
      "y": 472
    },
    {
      "t": 50400,
      "e": 39651,
      "ty": 2,
      "x": 858,
      "y": 546
    },
    {
      "t": 50500,
      "e": 39751,
      "ty": 2,
      "x": 825,
      "y": 650
    },
    {
      "t": 50501,
      "e": 39752,
      "ty": 41,
      "x": 3676,
      "y": 39789,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 50584,
      "e": 39835,
      "ty": 6,
      "x": 831,
      "y": 680,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50601,
      "e": 39852,
      "ty": 2,
      "x": 831,
      "y": 680
    },
    {
      "t": 50700,
      "e": 39951,
      "ty": 2,
      "x": 839,
      "y": 695
    },
    {
      "t": 50751,
      "e": 40002,
      "ty": 41,
      "x": 6704,
      "y": 49931,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50821,
      "e": 40072,
      "ty": 3,
      "x": 839,
      "y": 695,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50822,
      "e": 40073,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "india"
    },
    {
      "t": 50822,
      "e": 40073,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 50823,
      "e": 40074,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50892,
      "e": 40143,
      "ty": 4,
      "x": 6704,
      "y": 49931,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 50892,
      "e": 40143,
      "ty": 5,
      "x": 839,
      "y": 695,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 51085,
      "e": 40336,
      "ty": 7,
      "x": 918,
      "y": 677,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 51101,
      "e": 40352,
      "ty": 2,
      "x": 918,
      "y": 677
    },
    {
      "t": 51201,
      "e": 40452,
      "ty": 2,
      "x": 970,
      "y": 670
    },
    {
      "t": 51251,
      "e": 40502,
      "ty": 41,
      "x": 36552,
      "y": 38757,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 51301,
      "e": 40552,
      "ty": 2,
      "x": 984,
      "y": 670
    },
    {
      "t": 51501,
      "e": 40752,
      "ty": 41,
      "x": 38066,
      "y": 38757,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 52073,
      "e": 41324,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "97"
    },
    {
      "t": 52073,
      "e": 41324,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 52128,
      "e": 41379,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "1"
    },
    {
      "t": 52200,
      "e": 41451,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "97"
    },
    {
      "t": 52200,
      "e": 41451,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 52297,
      "e": 41548,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11"
    },
    {
      "t": 52313,
      "e": 41564,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "101"
    },
    {
      "t": 52313,
      "e": 41564,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 52416,
      "e": 41667,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 52700,
      "e": 41951,
      "ty": 2,
      "x": 1020,
      "y": 667
    },
    {
      "t": 52751,
      "e": 42002,
      "ty": 41,
      "x": 50175,
      "y": 31687,
      "ta": "html > body"
    },
    {
      "t": 52801,
      "e": 42052,
      "ty": 2,
      "x": 1517,
      "y": 574
    },
    {
      "t": 52901,
      "e": 42152,
      "ty": 2,
      "x": 1209,
      "y": 484
    },
    {
      "t": 53001,
      "e": 42252,
      "ty": 2,
      "x": 1024,
      "y": 758
    },
    {
      "t": 53001,
      "e": 42252,
      "ty": 41,
      "x": 34988,
      "y": 41547,
      "ta": "html > body"
    },
    {
      "t": 53101,
      "e": 42352,
      "ty": 2,
      "x": 887,
      "y": 863
    },
    {
      "t": 53201,
      "e": 42452,
      "ty": 2,
      "x": 884,
      "y": 823
    },
    {
      "t": 53251,
      "e": 42502,
      "ty": 41,
      "x": 30615,
      "y": 42655,
      "ta": "html > body"
    },
    {
      "t": 53301,
      "e": 42552,
      "ty": 2,
      "x": 914,
      "y": 755
    },
    {
      "t": 53371,
      "e": 42622,
      "ty": 6,
      "x": 925,
      "y": 738,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 53401,
      "e": 42652,
      "ty": 2,
      "x": 929,
      "y": 734
    },
    {
      "t": 53501,
      "e": 42752,
      "ty": 2,
      "x": 934,
      "y": 729
    },
    {
      "t": 53501,
      "e": 42752,
      "ty": 41,
      "x": 19625,
      "y": 41704,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 53549,
      "e": 42800,
      "ty": 3,
      "x": 934,
      "y": 729,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 53550,
      "e": 42801,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "11*"
    },
    {
      "t": 53550,
      "e": 42801,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 53550,
      "e": 42801,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 53604,
      "e": 42855,
      "ty": 4,
      "x": 19625,
      "y": 41704,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 53605,
      "e": 42856,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 53607,
      "e": 42858,
      "ty": 5,
      "x": 934,
      "y": 729,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 53607,
      "e": 42858,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 54601,
      "e": 43852,
      "ty": 2,
      "x": 936,
      "y": 727
    },
    {
      "t": 54720,
      "e": 43971,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 54751,
      "e": 44002,
      "ty": 6,
      "x": 936,
      "y": 727,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 54751,
      "e": 44002,
      "ty": 41,
      "x": 30600,
      "y": 36,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 55201,
      "e": 44452,
      "ty": 2,
      "x": 936,
      "y": 728
    },
    {
      "t": 55251,
      "e": 44502,
      "ty": 41,
      "x": 30600,
      "y": 16420,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 55301,
      "e": 44552,
      "ty": 2,
      "x": 936,
      "y": 735
    },
    {
      "t": 55501,
      "e": 44752,
      "ty": 2,
      "x": 935,
      "y": 738
    },
    {
      "t": 55501,
      "e": 44752,
      "ty": 41,
      "x": 30549,
      "y": 25782,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 55601,
      "e": 44852,
      "ty": 2,
      "x": 935,
      "y": 739
    },
    {
      "t": 55751,
      "e": 45002,
      "ty": 41,
      "x": 30549,
      "y": 28122,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 59998,
      "e": 49249,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 60356,
      "e": 49607,
      "ty": 7,
      "x": 918,
      "y": 759,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[3]"
    },
    {
      "t": 60357,
      "e": 49608,
      "ty": 6,
      "x": 918,
      "y": 759,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 60398,
      "e": 49649,
      "ty": 2,
      "x": 917,
      "y": 782
    },
    {
      "t": 60406,
      "e": 49657,
      "ty": 7,
      "x": 916,
      "y": 797,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[4]"
    },
    {
      "t": 60499,
      "e": 49750,
      "ty": 2,
      "x": 929,
      "y": 886
    },
    {
      "t": 60499,
      "e": 49750,
      "ty": 41,
      "x": 31266,
      "y": 52607,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 60598,
      "e": 49849,
      "ty": 2,
      "x": 937,
      "y": 973
    },
    {
      "t": 60698,
      "e": 49949,
      "ty": 2,
      "x": 939,
      "y": 1009
    },
    {
      "t": 60748,
      "e": 49999,
      "ty": 41,
      "x": 31808,
      "y": 62302,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 60798,
      "e": 50049,
      "ty": 2,
      "x": 940,
      "y": 1033
    },
    {
      "t": 60898,
      "e": 50149,
      "ty": 2,
      "x": 943,
      "y": 1042
    },
    {
      "t": 60998,
      "e": 50249,
      "ty": 2,
      "x": 943,
      "y": 1048
    },
    {
      "t": 60999,
      "e": 50250,
      "ty": 41,
      "x": 31955,
      "y": 63825,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 61098,
      "e": 50349,
      "ty": 2,
      "x": 945,
      "y": 1059
    },
    {
      "t": 61199,
      "e": 50450,
      "ty": 2,
      "x": 947,
      "y": 1062
    },
    {
      "t": 61249,
      "e": 50500,
      "ty": 41,
      "x": 32152,
      "y": 64794,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 61298,
      "e": 50549,
      "ty": 2,
      "x": 949,
      "y": 1063
    },
    {
      "t": 61341,
      "e": 50592,
      "ty": 6,
      "x": 953,
      "y": 1075,
      "ta": "#start"
    },
    {
      "t": 61398,
      "e": 50649,
      "ty": 2,
      "x": 956,
      "y": 1081
    },
    {
      "t": 61498,
      "e": 50749,
      "ty": 2,
      "x": 959,
      "y": 1087
    },
    {
      "t": 61498,
      "e": 50749,
      "ty": 41,
      "x": 27033,
      "y": 27587,
      "ta": "#start"
    },
    {
      "t": 61898,
      "e": 51149,
      "ty": 2,
      "x": 960,
      "y": 1087
    },
    {
      "t": 61999,
      "e": 51250,
      "ty": 2,
      "x": 961,
      "y": 1087
    },
    {
      "t": 61999,
      "e": 51250,
      "ty": 41,
      "x": 28125,
      "y": 27587,
      "ta": "#start"
    },
    {
      "t": 62198,
      "e": 51449,
      "ty": 2,
      "x": 962,
      "y": 1088
    },
    {
      "t": 62248,
      "e": 51499,
      "ty": 41,
      "x": 28671,
      "y": 29514,
      "ta": "#start"
    },
    {
      "t": 62699,
      "e": 51950,
      "ty": 3,
      "x": 962,
      "y": 1088,
      "ta": "#start"
    },
    {
      "t": 62700,
      "e": 51951,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 62809,
      "e": 52060,
      "ty": 4,
      "x": 28671,
      "y": 29514,
      "ta": "#start"
    },
    {
      "t": 62810,
      "e": 52061,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 62810,
      "e": 52061,
      "ty": 5,
      "x": 962,
      "y": 1088,
      "ta": "#start"
    },
    {
      "t": 62811,
      "e": 52062,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 62898,
      "e": 52149,
      "ty": 2,
      "x": 963,
      "y": 1089
    },
    {
      "t": 62998,
      "e": 52249,
      "ty": 2,
      "x": 964,
      "y": 1089
    },
    {
      "t": 62998,
      "e": 52249,
      "ty": 41,
      "x": 32922,
      "y": 59884,
      "ta": "html > body"
    },
    {
      "t": 63097,
      "e": 52348,
      "ty": 2,
      "x": 964,
      "y": 1070
    },
    {
      "t": 63198,
      "e": 52449,
      "ty": 2,
      "x": 964,
      "y": 954
    },
    {
      "t": 63248,
      "e": 52499,
      "ty": 41,
      "x": 32922,
      "y": 48361,
      "ta": "html > body"
    },
    {
      "t": 63297,
      "e": 52548,
      "ty": 2,
      "x": 962,
      "y": 841
    },
    {
      "t": 63398,
      "e": 52649,
      "ty": 2,
      "x": 961,
      "y": 837
    },
    {
      "t": 63497,
      "e": 52748,
      "ty": 41,
      "x": 32819,
      "y": 45924,
      "ta": "html > body"
    },
    {
      "t": 63812,
      "e": 53063,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 69998,
      "e": 57748,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 72248,
      "e": 57748,
      "ty": 41,
      "x": 33083,
      "y": 53693,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 72298,
      "e": 57798,
      "ty": 2,
      "x": 966,
      "y": 837
    },
    {
      "t": 74248,
      "e": 59748,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 75254,
      "e": 60754,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":60,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":61,\"previousSibling\":{\"id\":60},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":62,\"textContent\":\" \",\"previousSibling\":{\"id\":61},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":63,\"textContent\":\" \",\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":64,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":63},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":65,\"textContent\":\" \",\"previousSibling\":{\"id\":64},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":66,\"previousSibling\":{\"id\":65},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":67,\"textContent\":\" \",\"previousSibling\":{\"id\":66},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":68,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":67},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":69,\"previousSibling\":{\"id\":68},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":70,\"textContent\":\" \",\"previousSibling\":{\"id\":69},\"parentNode\":{\"id\":60}},{\"nodeType\":1,\"id\":71,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":70},\"parentNode\":{\"id\":60}},{\"nodeType\":8,\"id\":72,\"previousSibling\":{\"id\":71},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":73,\"textContent\":\" \",\"previousSibling\":{\"id\":72},\"parentNode\":{\"id\":60}},{\"nodeType\":3,\"id\":74,\"textContent\":\" \",\"parentNode\":{\"id\":64}},{\"nodeType\":1,\"id\":75,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":74},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":76,\"textContent\":\" \",\"previousSibling\":{\"id\":75},\"parentNode\":{\"id\":64}},{\"nodeType\":3,\"id\":77,\"textContent\":\" \",\"parentNode\":{\"id\":75}},{\"nodeType\":1,\"id\":78,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":77},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":79,\"textContent\":\" \",\"previousSibling\":{\"id\":78},\"parentNode\":{\"id\":75}},{\"nodeType\":3,\"id\":80,\"textContent\":\"UNIVERSITY OF CALIFORNIA, SAN DIEGO CONSENT TO ACT AS A RESEARCH SUBJECT\",\"parentNode\":{\"id\":78}},{\"nodeType\":3,\"id\":81,\"textContent\":\" \",\"parentNode\":{\"id\":68}},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":81},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":83,\"textContent\":\" \",\"previousSibling\":{\"id\":82},\"parentNode\":{\"id\":68}},{\"nodeType\":3,\"id\":84,\"textContent\":\" \",\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":85,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":84},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":86,\"textContent\":\" \",\"previousSibling\":{\"id\":85},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":87,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":86},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":88,\"textContent\":\" \",\"previousSibling\":{\"id\":87},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":89,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":88},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":90,\"textContent\":\" \",\"previousSibling\":{\"id\":89},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":91,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":90},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":92,\"textContent\":\" \",\"previousSibling\":{\"id\":91},\"parentNode\":{\"id\":82}},{\"nodeType\":8,\"id\":93,\"previousSibling\":{\"id\":92},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":94,\"textContent\":\" \",\"previousSibling\":{\"id\":93},\"parentNode\":{\"id\":82}},{\"nodeType\":1,\"id\":95,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control-group centered\"},\"previousSibling\":{\"id\":94},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":96,\"textContent\":\" \",\"previousSibling\":{\"id\":95},\"parentNode\":{\"id\":82}},{\"nodeType\":3,\"id\":97,\"textContent\":\" You are being invited to participate in a research study titled Learning Diagrams: Evaluating Learning With External Representations. This study is being done by Amy Fox and Dr. Jim Hollan from the University of California - San Diego (UCSD). You were selected to participate in this study because we think you might use graphs and diagrams in your work and educational activities.\",\"parentNode\":{\"id\":85}},{\"nodeType\":3,\"id\":98,\"textContent\":\" The purpose of this research study is to understand how humans try to make sense of charts, diagrams and graphs that are unconventional and that we may not have seen before. If you agree to take part in this study, you will be asked to read a series of instructions and answer a series of questions. The entire study should take no more than 60 minutes to complete. The researchers expect there will be no direct benefit to you from this research, other than any enjoyment you might have in contributing to research. We hope that you will find the questions interesting, though at times you may feel bored. The investigator(s), however, may learn more about how different types of instructions trigger different levels of understanding when using graphs. There are minimal risks associated with this research study, including a loss of confidentiality of your participation. The researchers are taking all required steps to protect your confidentiality, including storing all of your responses to questions in a secure, encrypted database separate from any information that can personally identify you. The only records containing your name and other personally identifying information are those stored in the system through which you signed up to participate in the study. These records will never be connected with the data we collect from you today. Research records will be kept confidential to the extent allowed by law and may be reviewed by the UCSD Institutional Review Board.\",\"parentNode\":{\"id\":87}},{\"nodeType\":3,\"id\":99,\"textContent\":\" Your participation in this study is completely voluntary and you can withdraw at any time by notifying the researcher that you wish to end your participation. Choosing not to participate or withdrawing will result in no penalty or loss of benefits to which you are entitled. You are free to skip any questions that you choose. If you have questions about this project or if you have a research-related problem, you may contact the researcher(s), Amy Fox: 919 886 4455: a2fox@ucsd.edu, and Jim Hollan: hollan@ucsd.edu. If you have any questions concerning your rights as a research subject, you may contact the UCSD Human Research Protections Program Office at 858-246-HRPP (858-246-4777). \",\"parentNode\":{\"id\":89}},{\"nodeType\":3,\"id\":100,\"textContent\":\" By clicking “I agree” below you are indicating that: you are at least 18 years old, have read this consent form, and agree to participate in this research study. If you do not wish to participate in the study, please notify the researcher now.\",\"parentNode\":{\"id\":91}},{\"nodeType\":3,\"id\":101,\"textContent\":\" \",\"parentNode\":{\"id\":95}},{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"centered control control-checkbox\"},\"previousSibling\":{\"id\":101},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":103,\"textContent\":\" \",\"previousSibling\":{\"id\":102},\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":104,\"textContent\":\" I agree to take part in this study. \",\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":105,\"tagName\":\"INPUT\",\"attributes\":{\"id\":\"consent_checkbox\",\"type\":\"checkbox\"},\"previousSibling\":{\"id\":104},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":106,\"textContent\":\" \",\"previousSibling\":{\"id\":105},\"parentNode\":{\"id\":102}},{\"nodeType\":1,\"id\":107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"},\"previousSibling\":{\"id\":106},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":108,\"textContent\":\" \",\"previousSibling\":{\"id\":107},\"parentNode\":{\"id\":102}},{\"nodeType\":3,\"id\":109,\"textContent\":\" \",\"parentNode\":{\"id\":71}},{\"nodeType\":1,\"id\":110,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":109},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":111,\"textContent\":\" \",\"previousSibling\":{\"id\":110},\"parentNode\":{\"id\":71}},{\"nodeType\":3,\"id\":112,\"textContent\":\"START\",\"parentNode\":{\"id\":110}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":60},{\"id\":63},{\"id\":64},{\"id\":74},{\"id\":75},{\"id\":77},{\"id\":78},{\"id\":80},{\"id\":79},{\"id\":76},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":81},{\"id\":82},{\"id\":84},{\"id\":85},{\"id\":97},{\"id\":86},{\"id\":87},{\"id\":98},{\"id\":88},{\"id\":89},{\"id\":99},{\"id\":90},{\"id\":91},{\"id\":100},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":101},{\"id\":102},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":103},{\"id\":96},{\"id\":83},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":109},{\"id\":110},{\"id\":112},{\"id\":111},{\"id\":72},{\"id\":73},{\"id\":61},{\"id\":62}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":115,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":114},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":117,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":113}},{\"nodeType\":3,\"id\":118,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":117}},{\"nodeType\":1,\"id\":119,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":114}},{\"nodeType\":1,\"id\":120,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":114}},{\"nodeType\":3,\"id\":121,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":119}},{\"nodeType\":1,\"id\":122,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":115}},{\"nodeType\":1,\"id\":123,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":122},\"parentNode\":{\"id\":115}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":122}},{\"nodeType\":3,\"id\":125,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":113},{\"id\":117},{\"id\":118},{\"id\":114},{\"id\":119},{\"id\":121},{\"id\":120},{\"id\":115},{\"id\":122},{\"id\":124},{\"id\":123},{\"id\":116},{\"id\":125}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":126,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":127,\"textContent\":\" \",\"previousSibling\":{\"id\":126},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":128,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":127},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":129,\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":130,\"textContent\":\" \",\"previousSibling\":{\"id\":129},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":126}},{\"nodeType\":3,\"id\":132,\"textContent\":\" \",\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":133,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":134,\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":135,\"textContent\":\" \",\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":136,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \",\"previousSibling\":{\"id\":136},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":138,\"previousSibling\":{\"id\":137},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \",\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":128}},{\"nodeType\":1,\"id\":140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":128}},{\"nodeType\":8,\"id\":141,\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":142,\"textContent\":\" \",\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"parentNode\":{\"id\":133}},{\"nodeType\":1,\"id\":144,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":133}},{\"nodeType\":3,\"id\":146,\"textContent\":\" \",\"parentNode\":{\"id\":144}},{\"nodeType\":1,\"id\":147,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":144}},{\"nodeType\":3,\"id\":149,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":147}},{\"nodeType\":3,\"id\":150,\"textContent\":\" \",\"parentNode\":{\"id\":136}},{\"nodeType\":1,\"id\":151,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"previousSibling\":{\"id\":151},\"parentNode\":{\"id\":136}},{\"nodeType\":8,\"id\":153,\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":136}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \",\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":156,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":155},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":157,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":159,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":161,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":160},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":162,\"textContent\":\" \",\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":151}},{\"nodeType\":1,\"id\":163,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":151}},{\"nodeType\":3,\"id\":165,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":156}},{\"nodeType\":1,\"id\":166,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":167,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":156}},{\"nodeType\":3,\"id\":168,\"textContent\":\"all\",\"parentNode\":{\"id\":166}},{\"nodeType\":3,\"id\":169,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":170,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":171,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":172,\"textContent\":\" \",\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":173,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":174,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":173},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":175,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":174},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":176,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":176},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":170}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":170}},{\"nodeType\":3,\"id\":181,\"textContent\":\" \",\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":182,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":183,\"textContent\":\" \",\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":184,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":171}},{\"nodeType\":3,\"id\":185,\"textContent\":\" \",\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":171}},{\"nodeType\":1,\"id\":186,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":182}},{\"nodeType\":3,\"id\":187,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":184}},{\"nodeType\":3,\"id\":188,\"textContent\":\" \",\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":189,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":173}},{\"nodeType\":3,\"id\":190,\"textContent\":\" \",\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":173}},{\"nodeType\":1,\"id\":191,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":189}},{\"nodeType\":3,\"id\":192,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":191}},{\"nodeType\":3,\"id\":193,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":194,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":193},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \",\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":196,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":197,\"textContent\":\" \",\"previousSibling\":{\"id\":196},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":198,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":194}},{\"nodeType\":3,\"id\":199,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":196}},{\"nodeType\":3,\"id\":200,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":201,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":202,\"textContent\":\" \",\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":203,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":201}},{\"nodeType\":3,\"id\":204,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":203}},{\"nodeType\":1,\"id\":205,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"previousSibling\":{\"id\":205},\"parentNode\":{\"id\":159}},{\"nodeType\":3,\"id\":207,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":205}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \\t\",\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":209,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":208},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":210,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":209},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":211,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":210},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":212},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":213},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":161}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":161}},{\"nodeType\":1,\"id\":217,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":218,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":219,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":209}},{\"nodeType\":3,\"id\":221,\"textContent\":\"carefully\",\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":222,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":223,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":222},\"parentNode\":{\"id\":211}},{\"nodeType\":1,\"id\":224,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":213}},{\"nodeType\":3,\"id\":225,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":213}},{\"nodeType\":1,\"id\":226,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":226},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":228,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":163}},{\"nodeType\":3,\"id\":229,\"textContent\":\" \\t\",\"parentNode\":{\"id\":140}},{\"nodeType\":1,\"id\":230,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":229},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":231,\"textContent\":\" \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":140}},{\"nodeType\":3,\"id\":232,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":230}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":126},{\"id\":131},{\"id\":127},{\"id\":128},{\"id\":132},{\"id\":133},{\"id\":143},{\"id\":144},{\"id\":146},{\"id\":147},{\"id\":149},{\"id\":148},{\"id\":145},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":150},{\"id\":151},{\"id\":155},{\"id\":156},{\"id\":165},{\"id\":166},{\"id\":168},{\"id\":167},{\"id\":157},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":181},{\"id\":182},{\"id\":186},{\"id\":183},{\"id\":184},{\"id\":187},{\"id\":185},{\"id\":172},{\"id\":173},{\"id\":188},{\"id\":189},{\"id\":191},{\"id\":192},{\"id\":190},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":193},{\"id\":194},{\"id\":198},{\"id\":195},{\"id\":196},{\"id\":199},{\"id\":197},{\"id\":178},{\"id\":179},{\"id\":200},{\"id\":201},{\"id\":203},{\"id\":204},{\"id\":202},{\"id\":180},{\"id\":158},{\"id\":159},{\"id\":205},{\"id\":207},{\"id\":206},{\"id\":160},{\"id\":161},{\"id\":208},{\"id\":209},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":221},{\"id\":220},{\"id\":210},{\"id\":211},{\"id\":222},{\"id\":223},{\"id\":212},{\"id\":213},{\"id\":224},{\"id\":225},{\"id\":214},{\"id\":215},{\"id\":226},{\"id\":227},{\"id\":216},{\"id\":162},{\"id\":163},{\"id\":228},{\"id\":164},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":229},{\"id\":230},{\"id\":232},{\"id\":231},{\"id\":141},{\"id\":142},{\"id\":129},{\"id\":130}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":233,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":234,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":233},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":235,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":234}}],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":233},{\"id\":234},{\"id\":235}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 120, dom: 883, initialDom: 887",
  "javascriptErrors": []
}