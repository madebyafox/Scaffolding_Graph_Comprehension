var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "7b9ab4dcea5a8ef96da28ece63bfc57b",
  "created": "2018-05-22T13:02:55.8034479-07:00",
  "lastActivity": "2018-05-22T13:05:54.5891829-07:00",
  "pageViews": [
    {
      "id": "0522554234426a94a0559d51524459b3063bf174",
      "startTime": "2018-05-22T13:02:55.8034479-07:00",
      "endTime": "2018-05-22T13:05:54.5891829-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 178829,
      "engagementTime": 66925,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 178829,
  "engagementTime": 66925,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.22",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "2ebe6cfc9dc845fe53c032036e89cceb",
  "gdpr": false
}