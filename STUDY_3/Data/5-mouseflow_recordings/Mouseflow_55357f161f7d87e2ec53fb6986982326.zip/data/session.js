var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "55357f161f7d87e2ec53fb6986982326",
  "created": "2018-05-21T09:16:11.9988683-07:00",
  "lastActivity": "2018-05-21T09:17:10.5718683-07:00",
  "pageViews": [
    {
      "id": "052112592145c08ce3f95029d5b29d3741f329ab",
      "startTime": "2018-05-21T09:16:11.9988683-07:00",
      "endTime": "2018-05-21T09:17:10.5718683-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/15",
      "visitTime": 58573,
      "engagementTime": 58556,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 58573,
  "engagementTime": 58556,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.47",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=UQWX4",
    "CONDITION=111",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "846eea1bfc74e36c8d220c526cab8df6",
  "gdpr": false
}