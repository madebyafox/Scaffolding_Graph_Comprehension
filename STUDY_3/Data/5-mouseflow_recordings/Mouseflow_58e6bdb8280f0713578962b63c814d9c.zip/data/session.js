var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "58e6bdb8280f0713578962b63c814d9c",
  "created": "2018-05-25T10:14:42.2954805-07:00",
  "lastActivity": "2018-05-25T10:15:32.3174805-07:00",
  "pageViews": [
    {
      "id": "05254292bb09b9c7caf1b78eaa5e601c880925e1",
      "startTime": "2018-05-25T10:14:42.2954805-07:00",
      "endTime": "2018-05-25T10:15:32.3174805-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/13",
      "visitTime": 50022,
      "engagementTime": 36587,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 50022,
  "engagementTime": 36587,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.36",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=CE2FW",
    "CONDITION=115"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "7fec90d0a8656bb7182d474e2e1f99bf",
  "gdpr": false
}