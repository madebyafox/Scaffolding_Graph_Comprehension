var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "4b061eaada57005ad8587ef2eb9cdd18",
  "created": "2018-05-21T09:09:19.6431613-07:00",
  "lastActivity": "2018-05-21T09:11:14.8399972-07:00",
  "pageViews": [
    {
      "id": "052119643766faf73cfed1b7f446ccfe422a1edb",
      "startTime": "2018-05-21T09:09:19.8649972-07:00",
      "endTime": "2018-05-21T09:11:14.8399972-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/4",
      "visitTime": 114975,
      "engagementTime": 114975,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 114975,
  "engagementTime": 114975,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=781AU",
    "CONDITION=111",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "edba5ebe4f4202e2f4714546442b497f",
  "gdpr": false
}