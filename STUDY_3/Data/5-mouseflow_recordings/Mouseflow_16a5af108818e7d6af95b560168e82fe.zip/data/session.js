var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "16a5af108818e7d6af95b560168e82fe",
  "created": "2018-05-18T11:12:26.771879-07:00",
  "lastActivity": "2018-05-18T11:12:53.7664966-07:00",
  "pageViews": [
    {
      "id": "051827296ac797ae4264c3fa142a87f44b24f746",
      "startTime": "2018-05-18T11:12:27.3374966-07:00",
      "endTime": "2018-05-18T11:12:53.7664966-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/2",
      "visitTime": 26429,
      "engagementTime": 26429,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 26429,
  "engagementTime": 26429,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.51",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=T2OHS",
    "CONDITION=113",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "40ff86bc2026230a4bbb9f6b681c15ff",
  "gdpr": false
}