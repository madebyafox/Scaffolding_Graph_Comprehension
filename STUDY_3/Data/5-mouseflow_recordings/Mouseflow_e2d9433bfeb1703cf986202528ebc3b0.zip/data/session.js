var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "e2d9433bfeb1703cf986202528ebc3b0",
  "created": "2018-05-22T14:08:16.049236-07:00",
  "lastActivity": "2018-05-22T14:08:58.063236-07:00",
  "pageViews": [
    {
      "id": "05221612f58102d9cd1f12829e880c35821c12ae",
      "startTime": "2018-05-22T14:08:16.049236-07:00",
      "endTime": "2018-05-22T14:08:58.063236-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/2",
      "visitTime": 42014,
      "engagementTime": 32377,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 42014,
  "engagementTime": 32377,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.23",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=JSK2P",
    "CONDITION=121"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "8e5b7fc48d3e64b96989b2857b992e9c",
  "gdpr": false
}