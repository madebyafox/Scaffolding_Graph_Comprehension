var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "c32febcccfab67adf255f89561f55e16",
  "created": "2018-05-21T10:09:53.9018056-07:00",
  "lastActivity": "2018-05-21T10:10:11.0478056-07:00",
  "pageViews": [
    {
      "id": "052154058bed7c94970295adfccff39c22893fba",
      "startTime": "2018-05-21T10:09:53.9018056-07:00",
      "endTime": "2018-05-21T10:10:11.0478056-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/3",
      "visitTime": 17146,
      "engagementTime": 15911,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 17146,
  "engagementTime": 15911,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=DKL3R",
    "CONDITION=121"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "36997480eb48dbcebdea7fc9e65bf5f3",
  "gdpr": false
}