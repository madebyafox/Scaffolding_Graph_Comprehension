var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "95d4b9aae05de4eef1a71fb22d5b246d",
  "created": "2018-05-22T16:13:29.0990808-07:00",
  "lastActivity": "2018-05-22T16:13:36.7335695-07:00",
  "pageViews": [
    {
      "id": "052229529d8e2a944ac820109d1ccb1e0405282c",
      "startTime": "2018-05-22T16:13:29.0990808-07:00",
      "endTime": "2018-05-22T16:13:36.7335695-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/12",
      "visitTime": 7752,
      "engagementTime": 7697,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 7752,
  "engagementTime": 7697,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.22",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=OU2PE",
    "CONDITION=115",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "331e67e0157f4e2ed87f1a221f045846",
  "gdpr": false
}