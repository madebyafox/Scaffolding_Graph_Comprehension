var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["05183926cf8e15128548a01cf5186d8953eacc7b"] = {
  "startTime": "2018-05-18T18:18:39.2162539Z",
  "websitePageUrl": "/15",
  "visitTime": 99861,
  "engagementTime": 81276,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "d7732f86265224a0fecaed81137c5545",
    "created": "2018-05-18T18:18:39.2162539+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/15",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=HWJDK",
      "CONDITION=113",
      "ORTH_CORRECT=1"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "97aa356c202140a2170608f34a4612ac",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/d7732f86265224a0fecaed81137c5545/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 203,
      "e": 203,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 203,
      "e": 203,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 1201,
      "e": 1201,
      "ty": 2,
      "x": 519,
      "y": 729
    },
    {
      "t": 1251,
      "e": 1251,
      "ty": 41,
      "x": 38122,
      "y": 40052,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1301,
      "e": 1301,
      "ty": 2,
      "x": 606,
      "y": 731
    },
    {
      "t": 1401,
      "e": 1401,
      "ty": 2,
      "x": 636,
      "y": 731
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 2,
      "x": 658,
      "y": 735
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 41,
      "x": 43779,
      "y": 40273,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1600,
      "e": 1600,
      "ty": 2,
      "x": 664,
      "y": 735
    },
    {
      "t": 1751,
      "e": 1751,
      "ty": 41,
      "x": 44183,
      "y": 40273,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 6201,
      "e": 6201,
      "ty": 2,
      "x": 686,
      "y": 735
    },
    {
      "t": 6251,
      "e": 6251,
      "ty": 41,
      "x": 56981,
      "y": 41714,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 6301,
      "e": 6301,
      "ty": 2,
      "x": 1241,
      "y": 836
    },
    {
      "t": 6401,
      "e": 6401,
      "ty": 2,
      "x": 1451,
      "y": 959
    },
    {
      "t": 6501,
      "e": 6501,
      "ty": 2,
      "x": 1472,
      "y": 979
    },
    {
      "t": 6501,
      "e": 6501,
      "ty": 41,
      "x": 34599,
      "y": 60234,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6601,
      "e": 6601,
      "ty": 2,
      "x": 1465,
      "y": 982
    },
    {
      "t": 6701,
      "e": 6701,
      "ty": 2,
      "x": 1436,
      "y": 979
    },
    {
      "t": 6752,
      "e": 6752,
      "ty": 41,
      "x": 32062,
      "y": 60234,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 6801,
      "e": 6801,
      "ty": 2,
      "x": 1435,
      "y": 982
    },
    {
      "t": 6901,
      "e": 6901,
      "ty": 2,
      "x": 1468,
      "y": 996
    },
    {
      "t": 7001,
      "e": 7001,
      "ty": 2,
      "x": 1491,
      "y": 984
    },
    {
      "t": 7002,
      "e": 7002,
      "ty": 41,
      "x": 48145,
      "y": 16639,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[13] > text"
    },
    {
      "t": 7101,
      "e": 7101,
      "ty": 2,
      "x": 1496,
      "y": 977
    },
    {
      "t": 7202,
      "e": 7202,
      "ty": 2,
      "x": 1485,
      "y": 970
    },
    {
      "t": 7252,
      "e": 7252,
      "ty": 41,
      "x": 35515,
      "y": 59590,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7301,
      "e": 7301,
      "ty": 2,
      "x": 1484,
      "y": 970
    },
    {
      "t": 7501,
      "e": 7501,
      "ty": 41,
      "x": 35445,
      "y": 59590,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7601,
      "e": 7601,
      "ty": 2,
      "x": 1483,
      "y": 969
    },
    {
      "t": 7752,
      "e": 7752,
      "ty": 41,
      "x": 35374,
      "y": 59518,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 7801,
      "e": 7801,
      "ty": 2,
      "x": 1481,
      "y": 967
    },
    {
      "t": 10000,
      "e": 10000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 18501,
      "e": 12801,
      "ty": 2,
      "x": 952,
      "y": 941
    },
    {
      "t": 18501,
      "e": 12801,
      "ty": 41,
      "x": 63581,
      "y": 51685,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 18600,
      "e": 12900,
      "ty": 2,
      "x": 187,
      "y": 820
    },
    {
      "t": 18701,
      "e": 13001,
      "ty": 2,
      "x": 184,
      "y": 797
    },
    {
      "t": 18750,
      "e": 13050,
      "ty": 41,
      "x": 16030,
      "y": 39442,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 18764,
      "e": 13064,
      "ty": 6,
      "x": 301,
      "y": 661,
      "ta": "#bigset.midpoint > ul > li:[18]"
    },
    {
      "t": 18781,
      "e": 13081,
      "ty": 7,
      "x": 382,
      "y": 604,
      "ta": "#bigset.midpoint > ul > li:[18]"
    },
    {
      "t": 18781,
      "e": 13081,
      "ty": 6,
      "x": 382,
      "y": 604,
      "ta": "#bigset.midpoint > ul > li:[10]"
    },
    {
      "t": 18797,
      "e": 13097,
      "ty": 7,
      "x": 479,
      "y": 557,
      "ta": "#bigset.midpoint > ul > li:[10]"
    },
    {
      "t": 18797,
      "e": 13097,
      "ty": 6,
      "x": 479,
      "y": 557,
      "ta": "#bigset.midpoint > ul > li:[6]"
    },
    {
      "t": 18801,
      "e": 13101,
      "ty": 2,
      "x": 479,
      "y": 557
    },
    {
      "t": 18814,
      "e": 13114,
      "ty": 7,
      "x": 640,
      "y": 487,
      "ta": "#bigset.midpoint > ul > li:[6]"
    },
    {
      "t": 18901,
      "e": 13201,
      "ty": 2,
      "x": 782,
      "y": 424
    },
    {
      "t": 19001,
      "e": 13301,
      "ty": 41,
      "x": 52401,
      "y": 1749,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 19001,
      "e": 13301,
      "ty": 2,
      "x": 786,
      "y": 406
    },
    {
      "t": 19101,
      "e": 13401,
      "ty": 2,
      "x": 685,
      "y": 465
    },
    {
      "t": 19148,
      "e": 13448,
      "ty": 6,
      "x": 647,
      "y": 511,
      "ta": "#bigset.midpoint > ul > li:[3]"
    },
    {
      "t": 19201,
      "e": 13501,
      "ty": 2,
      "x": 643,
      "y": 514
    },
    {
      "t": 19251,
      "e": 13551,
      "ty": 41,
      "x": 64543,
      "y": 35467,
      "ta": "#bigset.midpoint > ul > li:[3] > label"
    },
    {
      "t": 19301,
      "e": 13601,
      "ty": 2,
      "x": 639,
      "y": 517
    },
    {
      "t": 19401,
      "e": 13701,
      "ty": 2,
      "x": 636,
      "y": 517
    },
    {
      "t": 19501,
      "e": 13801,
      "ty": 2,
      "x": 627,
      "y": 517
    },
    {
      "t": 19501,
      "e": 13801,
      "ty": 41,
      "x": 41319,
      "y": 38445,
      "ta": "#bigset.midpoint > ul > li:[3] > label"
    },
    {
      "t": 19601,
      "e": 13901,
      "ty": 2,
      "x": 622,
      "y": 517
    },
    {
      "t": 19701,
      "e": 14001,
      "ty": 2,
      "x": 612,
      "y": 516
    },
    {
      "t": 19711,
      "e": 14011,
      "ty": 3,
      "x": 612,
      "y": 516,
      "ta": "#bigset.midpoint > ul > li:[3] > label > div"
    },
    {
      "t": 19750,
      "e": 14050,
      "ty": 41,
      "x": 38297,
      "y": 29183,
      "ta": "#bigset.midpoint > ul > li:[3] > label > div"
    },
    {
      "t": 19798,
      "e": 14098,
      "ty": 4,
      "x": 38297,
      "y": 29183,
      "ta": "#bigset.midpoint > ul > li:[3] > label > div"
    },
    {
      "t": 19799,
      "e": 14099,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[3] > label > input"
    },
    {
      "t": 19801,
      "e": 14101,
      "ty": 5,
      "x": 612,
      "y": 516,
      "ta": "#bigset.midpoint > ul > li:[3] > label > input"
    },
    {
      "t": 19801,
      "e": 14101,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[3] > label > input",
      "v": "E"
    },
    {
      "t": 19848,
      "e": 14148,
      "ty": 7,
      "x": 683,
      "y": 551,
      "ta": "#bigset.midpoint > ul > li:[3]"
    },
    {
      "t": 19848,
      "e": 14148,
      "ty": 6,
      "x": 683,
      "y": 551,
      "ta": "#bigset.midpoint > ul > li:[7]"
    },
    {
      "t": 19865,
      "e": 14165,
      "ty": 7,
      "x": 807,
      "y": 583,
      "ta": "#bigset.midpoint > ul > li:[7]"
    },
    {
      "t": 19865,
      "e": 14165,
      "ty": 6,
      "x": 807,
      "y": 583,
      "ta": "#bigset.midpoint > ul > li:[12]"
    },
    {
      "t": 19883,
      "e": 14183,
      "ty": 7,
      "x": 986,
      "y": 630,
      "ta": "#bigset.midpoint > ul > li:[12]"
    },
    {
      "t": 19901,
      "e": 14201,
      "ty": 2,
      "x": 1171,
      "y": 685
    },
    {
      "t": 20001,
      "e": 14301,
      "ty": 2,
      "x": 1807,
      "y": 911
    },
    {
      "t": 20001,
      "e": 14301,
      "ty": 41,
      "x": 58206,
      "y": 55364,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 20101,
      "e": 14401,
      "ty": 2,
      "x": 1772,
      "y": 951
    },
    {
      "t": 20201,
      "e": 14501,
      "ty": 2,
      "x": 1540,
      "y": 967
    },
    {
      "t": 20251,
      "e": 14551,
      "ty": 41,
      "x": 36502,
      "y": 59303,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 20301,
      "e": 14601,
      "ty": 2,
      "x": 1497,
      "y": 966
    },
    {
      "t": 20401,
      "e": 14701,
      "ty": 2,
      "x": 1580,
      "y": 970
    },
    {
      "t": 20501,
      "e": 14801,
      "ty": 2,
      "x": 1608,
      "y": 971
    },
    {
      "t": 20501,
      "e": 14801,
      "ty": 41,
      "x": 44183,
      "y": 59661,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 20601,
      "e": 14901,
      "ty": 2,
      "x": 1599,
      "y": 972
    },
    {
      "t": 20701,
      "e": 15001,
      "ty": 2,
      "x": 1554,
      "y": 975
    },
    {
      "t": 20751,
      "e": 15051,
      "ty": 41,
      "x": 40378,
      "y": 59948,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 20800,
      "e": 15100,
      "ty": 2,
      "x": 1552,
      "y": 975
    },
    {
      "t": 20901,
      "e": 15201,
      "ty": 2,
      "x": 1532,
      "y": 970
    },
    {
      "t": 21001,
      "e": 15301,
      "ty": 2,
      "x": 1493,
      "y": 981
    },
    {
      "t": 21001,
      "e": 15301,
      "ty": 41,
      "x": 51385,
      "y": 4351,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[13] > text"
    },
    {
      "t": 21100,
      "e": 15400,
      "ty": 2,
      "x": 1479,
      "y": 985
    },
    {
      "t": 21201,
      "e": 15501,
      "ty": 2,
      "x": 1504,
      "y": 986
    },
    {
      "t": 21251,
      "e": 15551,
      "ty": 41,
      "x": 30864,
      "y": 33023,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[15] > text"
    },
    {
      "t": 21301,
      "e": 15601,
      "ty": 2,
      "x": 1554,
      "y": 991
    },
    {
      "t": 21501,
      "e": 15801,
      "ty": 41,
      "x": 42205,
      "y": 45311,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > g:[15] > text"
    },
    {
      "t": 21601,
      "e": 15901,
      "ty": 2,
      "x": 1570,
      "y": 991
    },
    {
      "t": 21701,
      "e": 16001,
      "ty": 2,
      "x": 1583,
      "y": 986
    },
    {
      "t": 21751,
      "e": 16051,
      "ty": 41,
      "x": 42703,
      "y": 60521,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 21801,
      "e": 16101,
      "ty": 2,
      "x": 1595,
      "y": 975
    },
    {
      "t": 21901,
      "e": 16201,
      "ty": 2,
      "x": 1598,
      "y": 968
    },
    {
      "t": 22000,
      "e": 16300,
      "ty": 2,
      "x": 1546,
      "y": 965
    },
    {
      "t": 22001,
      "e": 16301,
      "ty": 41,
      "x": 39814,
      "y": 59232,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 22100,
      "e": 16400,
      "ty": 2,
      "x": 1525,
      "y": 970
    },
    {
      "t": 22201,
      "e": 16501,
      "ty": 2,
      "x": 1521,
      "y": 970
    },
    {
      "t": 22301,
      "e": 16601,
      "ty": 2,
      "x": 1501,
      "y": 968
    },
    {
      "t": 22401,
      "e": 16701,
      "ty": 2,
      "x": 1496,
      "y": 967
    },
    {
      "t": 22501,
      "e": 16801,
      "ty": 41,
      "x": 36290,
      "y": 59375,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 22701,
      "e": 17001,
      "ty": 2,
      "x": 1487,
      "y": 964
    },
    {
      "t": 22751,
      "e": 17051,
      "ty": 41,
      "x": 33218,
      "y": 5957,
      "ta": "> div.stimulus > div:[2] > svg > g > g:[3] > path"
    },
    {
      "t": 22901,
      "e": 17201,
      "ty": 2,
      "x": 1479,
      "y": 962
    },
    {
      "t": 23001,
      "e": 17301,
      "ty": 41,
      "x": 35092,
      "y": 59017,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 23101,
      "e": 17401,
      "ty": 2,
      "x": 1478,
      "y": 962
    },
    {
      "t": 23251,
      "e": 17551,
      "ty": 41,
      "x": 34740,
      "y": 58945,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 23301,
      "e": 17601,
      "ty": 2,
      "x": 1470,
      "y": 959
    },
    {
      "t": 23501,
      "e": 17801,
      "ty": 41,
      "x": 34458,
      "y": 58802,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 30001,
      "e": 22801,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 31399,
      "e": 22801,
      "ty": 2,
      "x": 992,
      "y": 632
    },
    {
      "t": 31405,
      "e": 22807,
      "ty": 6,
      "x": 929,
      "y": 590,
      "ta": "#bigset.midpoint > ul > li:[12]"
    },
    {
      "t": 31421,
      "e": 22823,
      "ty": 7,
      "x": 893,
      "y": 557,
      "ta": "#bigset.midpoint > ul > li:[12]"
    },
    {
      "t": 31421,
      "e": 22823,
      "ty": 6,
      "x": 893,
      "y": 557,
      "ta": "#bigset.midpoint > ul > li:[8]"
    },
    {
      "t": 31452,
      "e": 22854,
      "ty": 7,
      "x": 883,
      "y": 537,
      "ta": "#bigset.midpoint > ul > li:[8]"
    },
    {
      "t": 31469,
      "e": 22871,
      "ty": 6,
      "x": 880,
      "y": 528,
      "ta": "#bigset.midpoint > ul > li:[4]"
    },
    {
      "t": 31499,
      "e": 22901,
      "ty": 2,
      "x": 876,
      "y": 521
    },
    {
      "t": 31499,
      "e": 22901,
      "ty": 41,
      "x": 43929,
      "y": 43485,
      "ta": "#bigset.midpoint > ul > li:[4]"
    },
    {
      "t": 31539,
      "e": 22941,
      "ty": 7,
      "x": 847,
      "y": 498,
      "ta": "#bigset.midpoint > ul > li:[4]"
    },
    {
      "t": 31589,
      "e": 22991,
      "ty": 6,
      "x": 800,
      "y": 513,
      "ta": "#bigset.midpoint > ul > li:[4]"
    },
    {
      "t": 31599,
      "e": 23001,
      "ty": 2,
      "x": 800,
      "y": 513
    },
    {
      "t": 31605,
      "e": 23007,
      "ty": 7,
      "x": 791,
      "y": 534,
      "ta": "#bigset.midpoint > ul > li:[4]"
    },
    {
      "t": 31623,
      "e": 23025,
      "ty": 6,
      "x": 787,
      "y": 551,
      "ta": "#bigset.midpoint > ul > li:[8]"
    },
    {
      "t": 31673,
      "e": 23075,
      "ty": 7,
      "x": 801,
      "y": 570,
      "ta": "#bigset.midpoint > ul > li:[8]"
    },
    {
      "t": 31699,
      "e": 23101,
      "ty": 2,
      "x": 815,
      "y": 572
    },
    {
      "t": 31750,
      "e": 23152,
      "ty": 41,
      "x": 55364,
      "y": 38063,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 31789,
      "e": 23191,
      "ty": 6,
      "x": 838,
      "y": 565,
      "ta": "#bigset.midpoint > ul > li:[8]"
    },
    {
      "t": 31800,
      "e": 23202,
      "ty": 2,
      "x": 838,
      "y": 565
    },
    {
      "t": 31899,
      "e": 23301,
      "ty": 2,
      "x": 844,
      "y": 547
    },
    {
      "t": 31940,
      "e": 23342,
      "ty": 7,
      "x": 848,
      "y": 535,
      "ta": "#bigset.midpoint > ul > li:[8]"
    },
    {
      "t": 31956,
      "e": 23358,
      "ty": 6,
      "x": 848,
      "y": 531,
      "ta": "#bigset.midpoint > ul > li:[4]"
    },
    {
      "t": 31999,
      "e": 23401,
      "ty": 2,
      "x": 848,
      "y": 528
    },
    {
      "t": 31999,
      "e": 23401,
      "ty": 41,
      "x": 35795,
      "y": 58776,
      "ta": "#bigset.midpoint > ul > li:[4]"
    },
    {
      "t": 32100,
      "e": 23502,
      "ty": 2,
      "x": 848,
      "y": 525
    },
    {
      "t": 32180,
      "e": 23582,
      "ty": 3,
      "x": 846,
      "y": 523,
      "ta": "#bigset.midpoint > ul > li:[4] > label > div"
    },
    {
      "t": 32180,
      "e": 23582,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[3] > label > input"
    },
    {
      "t": 32199,
      "e": 23601,
      "ty": 2,
      "x": 846,
      "y": 523
    },
    {
      "t": 32249,
      "e": 23651,
      "ty": 41,
      "x": 63999,
      "y": 52120,
      "ta": "#bigset.midpoint > ul > li:[4] > label > div"
    },
    {
      "t": 32268,
      "e": 23670,
      "ty": 4,
      "x": 63999,
      "y": 52120,
      "ta": "#bigset.midpoint > ul > li:[4] > label > div"
    },
    {
      "t": 32268,
      "e": 23670,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[4] > label > input"
    },
    {
      "t": 32271,
      "e": 23673,
      "ty": 5,
      "x": 846,
      "y": 523,
      "ta": "#bigset.midpoint > ul > li:[4] > label > input"
    },
    {
      "t": 32271,
      "e": 23673,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[4] > label > input",
      "v": "F"
    },
    {
      "t": 32340,
      "e": 23742,
      "ty": 7,
      "x": 864,
      "y": 536,
      "ta": "#bigset.midpoint > ul > li:[4]"
    },
    {
      "t": 32356,
      "e": 23758,
      "ty": 6,
      "x": 950,
      "y": 593,
      "ta": "#bigset.midpoint > ul > li:[12]"
    },
    {
      "t": 32373,
      "e": 23775,
      "ty": 7,
      "x": 1025,
      "y": 645,
      "ta": "#bigset.midpoint > ul > li:[12]"
    },
    {
      "t": 32399,
      "e": 23801,
      "ty": 2,
      "x": 1153,
      "y": 714
    },
    {
      "t": 32499,
      "e": 23901,
      "ty": 2,
      "x": 1577,
      "y": 956
    },
    {
      "t": 32499,
      "e": 23901,
      "ty": 41,
      "x": 41998,
      "y": 58587,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 32600,
      "e": 24002,
      "ty": 2,
      "x": 1586,
      "y": 973
    },
    {
      "t": 32699,
      "e": 24101,
      "ty": 2,
      "x": 1511,
      "y": 977
    },
    {
      "t": 32750,
      "e": 24152,
      "ty": 41,
      "x": 36713,
      "y": 59948,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 32799,
      "e": 24201,
      "ty": 2,
      "x": 1501,
      "y": 974
    },
    {
      "t": 32899,
      "e": 24301,
      "ty": 2,
      "x": 1501,
      "y": 966
    },
    {
      "t": 32999,
      "e": 24401,
      "ty": 2,
      "x": 1494,
      "y": 961
    },
    {
      "t": 32999,
      "e": 24401,
      "ty": 41,
      "x": 36149,
      "y": 58945,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 33099,
      "e": 24501,
      "ty": 2,
      "x": 1493,
      "y": 961
    },
    {
      "t": 33199,
      "e": 24601,
      "ty": 2,
      "x": 1487,
      "y": 961
    },
    {
      "t": 33249,
      "e": 24651,
      "ty": 41,
      "x": 35656,
      "y": 58945,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 33398,
      "e": 24800,
      "ty": 2,
      "x": 1479,
      "y": 961
    },
    {
      "t": 33499,
      "e": 24901,
      "ty": 2,
      "x": 1477,
      "y": 961
    },
    {
      "t": 33499,
      "e": 24901,
      "ty": 41,
      "x": 34952,
      "y": 58945,
      "ta": "> div.stimulus > div:[2] > svg"
    },
    {
      "t": 39999,
      "e": 29901,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 42899,
      "e": 29901,
      "ty": 2,
      "x": 1391,
      "y": 919
    },
    {
      "t": 42949,
      "e": 29951,
      "ty": 6,
      "x": 625,
      "y": 633,
      "ta": "#bigset.midpoint > ul > li:[15]"
    },
    {
      "t": 42982,
      "e": 29984,
      "ty": 7,
      "x": 467,
      "y": 605,
      "ta": "#bigset.midpoint > ul > li:[15]"
    },
    {
      "t": 42982,
      "e": 29984,
      "ty": 6,
      "x": 467,
      "y": 605,
      "ta": "#bigset.midpoint > ul > li:[10]"
    },
    {
      "t": 42999,
      "e": 30001,
      "ty": 2,
      "x": 467,
      "y": 605
    },
    {
      "t": 42999,
      "e": 30001,
      "ty": 41,
      "x": 56184,
      "y": 60961,
      "ta": "#bigset.midpoint > ul > li:[10]"
    },
    {
      "t": 43066,
      "e": 30068,
      "ty": 7,
      "x": 410,
      "y": 612,
      "ta": "#bigset.midpoint > ul > li:[10]"
    },
    {
      "t": 43082,
      "e": 30084,
      "ty": 6,
      "x": 400,
      "y": 645,
      "ta": "#bigset.midpoint > ul > li:[14]"
    },
    {
      "t": 43098,
      "e": 30100,
      "ty": 2,
      "x": 400,
      "y": 645
    },
    {
      "t": 43099,
      "e": 30101,
      "ty": 7,
      "x": 395,
      "y": 669,
      "ta": "#bigset.midpoint > ul > li:[14]"
    },
    {
      "t": 43099,
      "e": 30101,
      "ty": 6,
      "x": 395,
      "y": 669,
      "ta": "#bigset.midpoint > ul > li:[18]"
    },
    {
      "t": 43166,
      "e": 30168,
      "ty": 7,
      "x": 402,
      "y": 702,
      "ta": "#bigset.midpoint > ul > li:[18]"
    },
    {
      "t": 43199,
      "e": 30201,
      "ty": 2,
      "x": 421,
      "y": 729
    },
    {
      "t": 43249,
      "e": 30251,
      "ty": 41,
      "x": 17085,
      "y": 51711,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 43299,
      "e": 30301,
      "ty": 2,
      "x": 542,
      "y": 840
    },
    {
      "t": 43399,
      "e": 30401,
      "ty": 2,
      "x": 591,
      "y": 835
    },
    {
      "t": 43498,
      "e": 30500,
      "ty": 2,
      "x": 556,
      "y": 720
    },
    {
      "t": 43499,
      "e": 30501,
      "ty": 41,
      "x": 61556,
      "y": 12390,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 43598,
      "e": 30600,
      "ty": 2,
      "x": 545,
      "y": 713
    },
    {
      "t": 43633,
      "e": 30635,
      "ty": 6,
      "x": 543,
      "y": 737,
      "ta": "#start"
    },
    {
      "t": 43699,
      "e": 30701,
      "ty": 7,
      "x": 531,
      "y": 769,
      "ta": "#start"
    },
    {
      "t": 43699,
      "e": 30701,
      "ty": 2,
      "x": 531,
      "y": 769
    },
    {
      "t": 43749,
      "e": 30751,
      "ty": 41,
      "x": 49853,
      "y": 44502,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 43860,
      "e": 30862,
      "ty": 3,
      "x": 531,
      "y": 769,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 43860,
      "e": 30862,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#bigset.midpoint > ul > li:[4] > label > input"
    },
    {
      "t": 43948,
      "e": 30950,
      "ty": 4,
      "x": 49853,
      "y": 44502,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 43948,
      "e": 30950,
      "ty": 5,
      "x": 531,
      "y": 769,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 44085,
      "e": 31087,
      "ty": 6,
      "x": 531,
      "y": 768,
      "ta": "#start"
    },
    {
      "t": 44099,
      "e": 31101,
      "ty": 2,
      "x": 531,
      "y": 768
    },
    {
      "t": 44199,
      "e": 31201,
      "ty": 2,
      "x": 533,
      "y": 753
    },
    {
      "t": 44249,
      "e": 31251,
      "ty": 41,
      "x": 50516,
      "y": 15239,
      "ta": "#start"
    },
    {
      "t": 44292,
      "e": 31294,
      "ty": 3,
      "x": 537,
      "y": 742,
      "ta": "#start"
    },
    {
      "t": 44293,
      "e": 31295,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 44299,
      "e": 31301,
      "ty": 2,
      "x": 537,
      "y": 742
    },
    {
      "t": 44379,
      "e": 31381,
      "ty": 4,
      "x": 50516,
      "y": 15239,
      "ta": "#start"
    },
    {
      "t": 44388,
      "e": 31390,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 44390,
      "e": 31392,
      "ty": 5,
      "x": 537,
      "y": 742,
      "ta": "#start"
    },
    {
      "t": 44395,
      "e": 31397,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 45393,
      "e": 32395,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 45998,
      "e": 33000,
      "ty": 2,
      "x": 616,
      "y": 721
    },
    {
      "t": 45999,
      "e": 33001,
      "ty": 41,
      "x": 20938,
      "y": 39498,
      "ta": "html > body"
    },
    {
      "t": 46099,
      "e": 33101,
      "ty": 2,
      "x": 878,
      "y": 625
    },
    {
      "t": 46199,
      "e": 33201,
      "ty": 2,
      "x": 879,
      "y": 624
    },
    {
      "t": 46249,
      "e": 33251,
      "ty": 41,
      "x": 15788,
      "y": 49151,
      "ta": "#jspsych-survey-text-1 > p"
    },
    {
      "t": 46298,
      "e": 33300,
      "ty": 2,
      "x": 890,
      "y": 601
    },
    {
      "t": 46398,
      "e": 33400,
      "ty": 2,
      "x": 900,
      "y": 576
    },
    {
      "t": 46400,
      "e": 33402,
      "ty": 6,
      "x": 902,
      "y": 573,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 46499,
      "e": 33501,
      "ty": 2,
      "x": 902,
      "y": 572
    },
    {
      "t": 46499,
      "e": 33501,
      "ty": 41,
      "x": 20330,
      "y": 56172,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 46599,
      "e": 33601,
      "ty": 2,
      "x": 908,
      "y": 560
    },
    {
      "t": 46652,
      "e": 33654,
      "ty": 3,
      "x": 908,
      "y": 560,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 46652,
      "e": 33654,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 46739,
      "e": 33741,
      "ty": 4,
      "x": 21628,
      "y": 18724,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 46739,
      "e": 33741,
      "ty": 5,
      "x": 908,
      "y": 560,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 46749,
      "e": 33751,
      "ty": 41,
      "x": 21628,
      "y": 18724,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 46799,
      "e": 33801,
      "ty": 2,
      "x": 913,
      "y": 560
    },
    {
      "t": 46898,
      "e": 33900,
      "ty": 2,
      "x": 914,
      "y": 560
    },
    {
      "t": 46999,
      "e": 34001,
      "ty": 41,
      "x": 22926,
      "y": 18724,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 47280,
      "e": 34282,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "97"
    },
    {
      "t": 47280,
      "e": 34282,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 47376,
      "e": 34378,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "1"
    },
    {
      "t": 47512,
      "e": 34514,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "105"
    },
    {
      "t": 47512,
      "e": 34514,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 47584,
      "e": 34586,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 48119,
      "e": 35121,
      "ty": 7,
      "x": 918,
      "y": 582,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 48199,
      "e": 35201,
      "ty": 2,
      "x": 922,
      "y": 630
    },
    {
      "t": 48249,
      "e": 35251,
      "ty": 41,
      "x": 23359,
      "y": 64125,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 48253,
      "e": 35255,
      "ty": 6,
      "x": 911,
      "y": 693,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 48299,
      "e": 35301,
      "ty": 2,
      "x": 907,
      "y": 698
    },
    {
      "t": 48399,
      "e": 35401,
      "ty": 2,
      "x": 908,
      "y": 699
    },
    {
      "t": 48436,
      "e": 35438,
      "ty": 7,
      "x": 912,
      "y": 669,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 48453,
      "e": 35455,
      "ty": 6,
      "x": 913,
      "y": 667,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 48499,
      "e": 35501,
      "ty": 2,
      "x": 913,
      "y": 665
    },
    {
      "t": 48499,
      "e": 35501,
      "ty": 41,
      "x": 22710,
      "y": 56172,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 48599,
      "e": 35601,
      "ty": 2,
      "x": 916,
      "y": 654
    },
    {
      "t": 48698,
      "e": 35700,
      "ty": 2,
      "x": 916,
      "y": 653
    },
    {
      "t": 48749,
      "e": 35751,
      "ty": 41,
      "x": 23359,
      "y": 18724,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 49340,
      "e": 36342,
      "ty": 3,
      "x": 916,
      "y": 653,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 49341,
      "e": 36343,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "19"
    },
    {
      "t": 49341,
      "e": 36343,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 49341,
      "e": 36343,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 49435,
      "e": 36437,
      "ty": 4,
      "x": 23359,
      "y": 18724,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 49435,
      "e": 36437,
      "ty": 5,
      "x": 916,
      "y": 653,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 49999,
      "e": 37001,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 56881,
      "e": 41437,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 56976,
      "e": 41532,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "67"
    },
    {
      "t": 56977,
      "e": 41533,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 57072,
      "e": 41628,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "C"
    },
    {
      "t": 57177,
      "e": 41733,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 57177,
      "e": 41733,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 57272,
      "e": 41828,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "CA"
    },
    {
      "t": 57360,
      "e": 41916,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "CA"
    },
    {
      "t": 60896,
      "e": 45452,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 60983,
      "e": 45539,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "C"
    },
    {
      "t": 61071,
      "e": 45627,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 61144,
      "e": 45700,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 61936,
      "e": 46492,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 62073,
      "e": 46629,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 62073,
      "e": 46629,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 62144,
      "e": 46700,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 62320,
      "e": 46876,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 62321,
      "e": 46877,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 62399,
      "e": 46955,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 62423,
      "e": 46979,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 63549,
      "e": 48105,
      "ty": 7,
      "x": 936,
      "y": 688,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 63549,
      "e": 48105,
      "ty": 6,
      "x": 936,
      "y": 688,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 63566,
      "e": 48122,
      "ty": 7,
      "x": 955,
      "y": 716,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 63599,
      "e": 48155,
      "ty": 2,
      "x": 966,
      "y": 731
    },
    {
      "t": 63698,
      "e": 48254,
      "ty": 2,
      "x": 979,
      "y": 736
    },
    {
      "t": 63749,
      "e": 48305,
      "ty": 41,
      "x": 33439,
      "y": 38999,
      "ta": "html > body"
    },
    {
      "t": 63749,
      "e": 48305,
      "ty": 6,
      "x": 979,
      "y": 700,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 63782,
      "e": 48338,
      "ty": 7,
      "x": 974,
      "y": 675,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 63798,
      "e": 48354,
      "ty": 2,
      "x": 974,
      "y": 675
    },
    {
      "t": 63899,
      "e": 48455,
      "ty": 2,
      "x": 973,
      "y": 672
    },
    {
      "t": 63967,
      "e": 48523,
      "ty": 6,
      "x": 972,
      "y": 676,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 63998,
      "e": 48554,
      "ty": 2,
      "x": 970,
      "y": 682
    },
    {
      "t": 63998,
      "e": 48554,
      "ty": 41,
      "x": 38179,
      "y": 11915,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 64098,
      "e": 48654,
      "ty": 2,
      "x": 969,
      "y": 687
    },
    {
      "t": 64249,
      "e": 48805,
      "ty": 41,
      "x": 37663,
      "y": 21845,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 64715,
      "e": 49271,
      "ty": 3,
      "x": 969,
      "y": 687,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 64716,
      "e": 49272,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "US"
    },
    {
      "t": 64716,
      "e": 49272,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 64716,
      "e": 49272,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 64900,
      "e": 49456,
      "ty": 4,
      "x": 37663,
      "y": 21845,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 64902,
      "e": 49458,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 64903,
      "e": 49459,
      "ty": 5,
      "x": 969,
      "y": 687,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 64903,
      "e": 49459,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 65920,
      "e": 50476,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 66698,
      "e": 51254,
      "ty": 2,
      "x": 1080,
      "y": 512
    },
    {
      "t": 66749,
      "e": 51305,
      "ty": 41,
      "x": 38122,
      "y": 23765,
      "ta": "html > body"
    },
    {
      "t": 66799,
      "e": 51355,
      "ty": 2,
      "x": 1100,
      "y": 365
    },
    {
      "t": 66899,
      "e": 51455,
      "ty": 2,
      "x": 1012,
      "y": 273
    },
    {
      "t": 66999,
      "e": 51555,
      "ty": 2,
      "x": 918,
      "y": 234
    },
    {
      "t": 66999,
      "e": 51555,
      "ty": 41,
      "x": 22920,
      "y": 21064,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 67099,
      "e": 51655,
      "ty": 2,
      "x": 901,
      "y": 232
    },
    {
      "t": 67198,
      "e": 51754,
      "ty": 2,
      "x": 869,
      "y": 236
    },
    {
      "t": 67249,
      "e": 51805,
      "ty": 41,
      "x": 23401,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 67299,
      "e": 51855,
      "ty": 2,
      "x": 844,
      "y": 237
    },
    {
      "t": 67499,
      "e": 52055,
      "ty": 2,
      "x": 840,
      "y": 237
    },
    {
      "t": 67500,
      "e": 52056,
      "ty": 41,
      "x": 15213,
      "y": 26214,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 67549,
      "e": 52105,
      "ty": 6,
      "x": 838,
      "y": 237,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 67599,
      "e": 52155,
      "ty": 2,
      "x": 836,
      "y": 237
    },
    {
      "t": 67699,
      "e": 52255,
      "ty": 2,
      "x": 835,
      "y": 237
    },
    {
      "t": 67749,
      "e": 52305,
      "ty": 41,
      "x": 43243,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 67861,
      "e": 52417,
      "ty": 3,
      "x": 835,
      "y": 237,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 67862,
      "e": 52418,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 67941,
      "e": 52497,
      "ty": 4,
      "x": 43243,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 67941,
      "e": 52497,
      "ty": 5,
      "x": 835,
      "y": 237,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 67942,
      "e": 52498,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 68399,
      "e": 52955,
      "ty": 2,
      "x": 833,
      "y": 241
    },
    {
      "t": 68404,
      "e": 52960,
      "ty": 7,
      "x": 833,
      "y": 246,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 68498,
      "e": 53054,
      "ty": 2,
      "x": 833,
      "y": 252
    },
    {
      "t": 68499,
      "e": 53055,
      "ty": 41,
      "x": 2747,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 68599,
      "e": 53155,
      "ty": 2,
      "x": 849,
      "y": 274
    },
    {
      "t": 68698,
      "e": 53254,
      "ty": 2,
      "x": 897,
      "y": 325
    },
    {
      "t": 68749,
      "e": 53305,
      "ty": 41,
      "x": 18885,
      "y": 51491,
      "ta": "#jspsych-survey-multi-choice-option-0-3"
    },
    {
      "t": 68799,
      "e": 53355,
      "ty": 2,
      "x": 910,
      "y": 368
    },
    {
      "t": 68899,
      "e": 53455,
      "ty": 2,
      "x": 913,
      "y": 389
    },
    {
      "t": 68999,
      "e": 53555,
      "ty": 2,
      "x": 842,
      "y": 412
    },
    {
      "t": 68999,
      "e": 53555,
      "ty": 41,
      "x": 24088,
      "y": 22937,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 69003,
      "e": 53559,
      "ty": 6,
      "x": 830,
      "y": 417,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 69020,
      "e": 53576,
      "ty": 7,
      "x": 816,
      "y": 427,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 69099,
      "e": 53655,
      "ty": 2,
      "x": 806,
      "y": 446
    },
    {
      "t": 69199,
      "e": 53755,
      "ty": 2,
      "x": 807,
      "y": 466
    },
    {
      "t": 69249,
      "e": 53805,
      "ty": 41,
      "x": 27619,
      "y": 25538,
      "ta": "html > body"
    },
    {
      "t": 69288,
      "e": 53805,
      "ty": 6,
      "x": 833,
      "y": 470,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 69298,
      "e": 53815,
      "ty": 2,
      "x": 833,
      "y": 470
    },
    {
      "t": 69338,
      "e": 53855,
      "ty": 7,
      "x": 840,
      "y": 467,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 69399,
      "e": 53916,
      "ty": 2,
      "x": 841,
      "y": 463
    },
    {
      "t": 69499,
      "e": 54016,
      "ty": 2,
      "x": 844,
      "y": 450
    },
    {
      "t": 69500,
      "e": 54017,
      "ty": 41,
      "x": 18034,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 69599,
      "e": 54116,
      "ty": 2,
      "x": 844,
      "y": 447
    },
    {
      "t": 69699,
      "e": 54216,
      "ty": 2,
      "x": 844,
      "y": 446
    },
    {
      "t": 69749,
      "e": 54266,
      "ty": 41,
      "x": 18034,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 69799,
      "e": 54316,
      "ty": 2,
      "x": 844,
      "y": 442
    },
    {
      "t": 69838,
      "e": 54355,
      "ty": 6,
      "x": 838,
      "y": 439,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 69888,
      "e": 54405,
      "ty": 7,
      "x": 824,
      "y": 436,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 69899,
      "e": 54416,
      "ty": 2,
      "x": 824,
      "y": 436
    },
    {
      "t": 69999,
      "e": 54516,
      "ty": 41,
      "x": 2059,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 70038,
      "e": 54555,
      "ty": 6,
      "x": 827,
      "y": 436,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 70099,
      "e": 54616,
      "ty": 2,
      "x": 831,
      "y": 437
    },
    {
      "t": 70249,
      "e": 54766,
      "ty": 41,
      "x": 23079,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 70325,
      "e": 54842,
      "ty": 3,
      "x": 831,
      "y": 437,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 70325,
      "e": 54842,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 70327,
      "e": 54844,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 70435,
      "e": 54952,
      "ty": 4,
      "x": 23079,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 70435,
      "e": 54952,
      "ty": 5,
      "x": 831,
      "y": 437,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 70435,
      "e": 54952,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf",
      "v": "Second"
    },
    {
      "t": 70672,
      "e": 55189,
      "ty": 7,
      "x": 834,
      "y": 456,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 70699,
      "e": 55216,
      "ty": 2,
      "x": 839,
      "y": 486
    },
    {
      "t": 70749,
      "e": 55266,
      "ty": 41,
      "x": 64107,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-1-6 > label"
    },
    {
      "t": 70798,
      "e": 55315,
      "ty": 2,
      "x": 946,
      "y": 648
    },
    {
      "t": 70899,
      "e": 55416,
      "ty": 2,
      "x": 926,
      "y": 676
    },
    {
      "t": 70998,
      "e": 55515,
      "ty": 2,
      "x": 845,
      "y": 702
    },
    {
      "t": 70999,
      "e": 55516,
      "ty": 41,
      "x": 5941,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 71072,
      "e": 55589,
      "ty": 6,
      "x": 839,
      "y": 725,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 71099,
      "e": 55616,
      "ty": 2,
      "x": 839,
      "y": 731
    },
    {
      "t": 71121,
      "e": 55638,
      "ty": 7,
      "x": 838,
      "y": 742,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 71172,
      "e": 55689,
      "ty": 6,
      "x": 838,
      "y": 759,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 71189,
      "e": 55706,
      "ty": 7,
      "x": 838,
      "y": 765,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 71198,
      "e": 55715,
      "ty": 2,
      "x": 838,
      "y": 765
    },
    {
      "t": 71238,
      "e": 55755,
      "ty": 6,
      "x": 838,
      "y": 781,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 71249,
      "e": 55766,
      "ty": 41,
      "x": 58367,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 71299,
      "e": 55816,
      "ty": 2,
      "x": 838,
      "y": 788
    },
    {
      "t": 71338,
      "e": 55855,
      "ty": 7,
      "x": 838,
      "y": 797,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 71399,
      "e": 55916,
      "ty": 2,
      "x": 836,
      "y": 805
    },
    {
      "t": 71406,
      "e": 55917,
      "ty": 6,
      "x": 835,
      "y": 810,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 71455,
      "e": 55966,
      "ty": 7,
      "x": 830,
      "y": 822,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 71499,
      "e": 56010,
      "ty": 2,
      "x": 829,
      "y": 828
    },
    {
      "t": 71499,
      "e": 56010,
      "ty": 41,
      "x": 1798,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 71599,
      "e": 56110,
      "ty": 2,
      "x": 828,
      "y": 830
    },
    {
      "t": 71698,
      "e": 56209,
      "ty": 2,
      "x": 840,
      "y": 824
    },
    {
      "t": 71749,
      "e": 56260,
      "ty": 41,
      "x": 18048,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 71798,
      "e": 56309,
      "ty": 2,
      "x": 871,
      "y": 802
    },
    {
      "t": 71899,
      "e": 56410,
      "ty": 2,
      "x": 988,
      "y": 774
    },
    {
      "t": 71999,
      "e": 56510,
      "ty": 2,
      "x": 1034,
      "y": 761
    },
    {
      "t": 71999,
      "e": 56510,
      "ty": 41,
      "x": 50450,
      "y": 37448,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 72099,
      "e": 56610,
      "ty": 2,
      "x": 1016,
      "y": 716
    },
    {
      "t": 72199,
      "e": 56710,
      "ty": 2,
      "x": 1012,
      "y": 713
    },
    {
      "t": 72249,
      "e": 56760,
      "ty": 41,
      "x": 43990,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 72299,
      "e": 56810,
      "ty": 2,
      "x": 957,
      "y": 698
    },
    {
      "t": 72399,
      "e": 56910,
      "ty": 2,
      "x": 942,
      "y": 683
    },
    {
      "t": 72498,
      "e": 57009,
      "ty": 2,
      "x": 967,
      "y": 652
    },
    {
      "t": 72499,
      "e": 57010,
      "ty": 41,
      "x": 34549,
      "y": 10019,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 72599,
      "e": 57110,
      "ty": 2,
      "x": 1003,
      "y": 646
    },
    {
      "t": 72699,
      "e": 57210,
      "ty": 2,
      "x": 1016,
      "y": 643
    },
    {
      "t": 72749,
      "e": 57260,
      "ty": 41,
      "x": 50212,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 72799,
      "e": 57310,
      "ty": 2,
      "x": 1060,
      "y": 639
    },
    {
      "t": 72899,
      "e": 57410,
      "ty": 2,
      "x": 1075,
      "y": 635
    },
    {
      "t": 72999,
      "e": 57510,
      "ty": 41,
      "x": 60180,
      "y": 46810,
      "ta": "#jspsych-survey-multi-choice-2 > p"
    },
    {
      "t": 73099,
      "e": 57610,
      "ty": 2,
      "x": 1075,
      "y": 640
    },
    {
      "t": 73199,
      "e": 57710,
      "ty": 2,
      "x": 1084,
      "y": 678
    },
    {
      "t": 73249,
      "e": 57760,
      "ty": 41,
      "x": 64214,
      "y": 23405,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 73299,
      "e": 57810,
      "ty": 2,
      "x": 1095,
      "y": 710
    },
    {
      "t": 73399,
      "e": 57910,
      "ty": 2,
      "x": 1089,
      "y": 719
    },
    {
      "t": 73499,
      "e": 58010,
      "ty": 2,
      "x": 1059,
      "y": 721
    },
    {
      "t": 73500,
      "e": 58011,
      "ty": 41,
      "x": 59628,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 73599,
      "e": 58110,
      "ty": 2,
      "x": 1016,
      "y": 717
    },
    {
      "t": 73699,
      "e": 58210,
      "ty": 2,
      "x": 983,
      "y": 716
    },
    {
      "t": 73749,
      "e": 58260,
      "ty": 41,
      "x": 36447,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 73799,
      "e": 58310,
      "ty": 2,
      "x": 959,
      "y": 715
    },
    {
      "t": 73899,
      "e": 58410,
      "ty": 2,
      "x": 944,
      "y": 720
    },
    {
      "t": 73999,
      "e": 58510,
      "ty": 2,
      "x": 964,
      "y": 724
    },
    {
      "t": 73999,
      "e": 58510,
      "ty": 41,
      "x": 35785,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 74099,
      "e": 58610,
      "ty": 2,
      "x": 1069,
      "y": 729
    },
    {
      "t": 74199,
      "e": 58710,
      "ty": 2,
      "x": 1068,
      "y": 733
    },
    {
      "t": 74249,
      "e": 58760,
      "ty": 41,
      "x": 51162,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 74298,
      "e": 58809,
      "ty": 2,
      "x": 983,
      "y": 746
    },
    {
      "t": 74399,
      "e": 58910,
      "ty": 2,
      "x": 915,
      "y": 746
    },
    {
      "t": 74499,
      "e": 59010,
      "ty": 2,
      "x": 874,
      "y": 746
    },
    {
      "t": 74499,
      "e": 59010,
      "ty": 41,
      "x": 12478,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-3"
    },
    {
      "t": 74598,
      "e": 59109,
      "ty": 2,
      "x": 859,
      "y": 749
    },
    {
      "t": 74699,
      "e": 59210,
      "ty": 2,
      "x": 849,
      "y": 761
    },
    {
      "t": 74749,
      "e": 59260,
      "ty": 41,
      "x": 10672,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 74799,
      "e": 59310,
      "ty": 2,
      "x": 845,
      "y": 775
    },
    {
      "t": 74899,
      "e": 59410,
      "ty": 2,
      "x": 844,
      "y": 777
    },
    {
      "t": 74999,
      "e": 59510,
      "ty": 2,
      "x": 883,
      "y": 783
    },
    {
      "t": 74999,
      "e": 59510,
      "ty": 41,
      "x": 34473,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 75099,
      "e": 59610,
      "ty": 2,
      "x": 896,
      "y": 782
    },
    {
      "t": 75199,
      "e": 59710,
      "ty": 2,
      "x": 923,
      "y": 777
    },
    {
      "t": 75249,
      "e": 59710,
      "ty": 41,
      "x": 26717,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 75299,
      "e": 59760,
      "ty": 2,
      "x": 948,
      "y": 772
    },
    {
      "t": 75399,
      "e": 59860,
      "ty": 2,
      "x": 949,
      "y": 772
    },
    {
      "t": 75499,
      "e": 59960,
      "ty": 2,
      "x": 920,
      "y": 778
    },
    {
      "t": 75499,
      "e": 59960,
      "ty": 41,
      "x": 55186,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 75599,
      "e": 60060,
      "ty": 2,
      "x": 888,
      "y": 788
    },
    {
      "t": 75699,
      "e": 60160,
      "ty": 2,
      "x": 862,
      "y": 802
    },
    {
      "t": 75749,
      "e": 60210,
      "ty": 41,
      "x": 5358,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 75799,
      "e": 60260,
      "ty": 2,
      "x": 837,
      "y": 806
    },
    {
      "t": 75899,
      "e": 60360,
      "ty": 2,
      "x": 823,
      "y": 807
    },
    {
      "t": 75999,
      "e": 60460,
      "ty": 2,
      "x": 819,
      "y": 811
    },
    {
      "t": 76000,
      "e": 60461,
      "ty": 41,
      "x": 27928,
      "y": 44484,
      "ta": "html > body"
    },
    {
      "t": 76060,
      "e": 60521,
      "ty": 6,
      "x": 830,
      "y": 818,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 76093,
      "e": 60554,
      "ty": 7,
      "x": 839,
      "y": 821,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 76099,
      "e": 60560,
      "ty": 2,
      "x": 839,
      "y": 821
    },
    {
      "t": 76200,
      "e": 60661,
      "ty": 2,
      "x": 847,
      "y": 824
    },
    {
      "t": 76249,
      "e": 60710,
      "ty": 41,
      "x": 15097,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 76299,
      "e": 60760,
      "ty": 2,
      "x": 848,
      "y": 826
    },
    {
      "t": 76399,
      "e": 60860,
      "ty": 2,
      "x": 848,
      "y": 836
    },
    {
      "t": 76499,
      "e": 60960,
      "ty": 2,
      "x": 848,
      "y": 845
    },
    {
      "t": 76499,
      "e": 60960,
      "ty": 41,
      "x": 18725,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 76599,
      "e": 61060,
      "ty": 2,
      "x": 846,
      "y": 850
    },
    {
      "t": 76699,
      "e": 61160,
      "ty": 2,
      "x": 840,
      "y": 850
    },
    {
      "t": 76749,
      "e": 61210,
      "ty": 41,
      "x": 12384,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 76799,
      "e": 61260,
      "ty": 2,
      "x": 838,
      "y": 850
    },
    {
      "t": 76999,
      "e": 61460,
      "ty": 2,
      "x": 837,
      "y": 850
    },
    {
      "t": 77000,
      "e": 61461,
      "ty": 41,
      "x": 10975,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 77077,
      "e": 61538,
      "ty": 6,
      "x": 837,
      "y": 848,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 77099,
      "e": 61560,
      "ty": 2,
      "x": 837,
      "y": 847
    },
    {
      "t": 77199,
      "e": 61660,
      "ty": 2,
      "x": 837,
      "y": 846
    },
    {
      "t": 77249,
      "e": 61710,
      "ty": 41,
      "x": 53325,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 77299,
      "e": 61760,
      "ty": 2,
      "x": 837,
      "y": 840
    },
    {
      "t": 77499,
      "e": 61960,
      "ty": 2,
      "x": 836,
      "y": 837
    },
    {
      "t": 77499,
      "e": 61960,
      "ty": 41,
      "x": 48284,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 77669,
      "e": 62130,
      "ty": 7,
      "x": 836,
      "y": 834,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 77699,
      "e": 62160,
      "ty": 2,
      "x": 837,
      "y": 829
    },
    {
      "t": 77749,
      "e": 62210,
      "ty": 41,
      "x": 3934,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-2-5"
    },
    {
      "t": 77800,
      "e": 62261,
      "ty": 2,
      "x": 838,
      "y": 826
    },
    {
      "t": 77900,
      "e": 62361,
      "ty": 2,
      "x": 838,
      "y": 823
    },
    {
      "t": 77932,
      "e": 62393,
      "ty": 6,
      "x": 837,
      "y": 820,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 77999,
      "e": 62460,
      "ty": 2,
      "x": 837,
      "y": 820
    },
    {
      "t": 78000,
      "e": 62461,
      "ty": 41,
      "x": 53325,
      "y": 60493,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 78199,
      "e": 62660,
      "ty": 2,
      "x": 834,
      "y": 817
    },
    {
      "t": 78249,
      "e": 62710,
      "ty": 41,
      "x": 38202,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 78499,
      "e": 62960,
      "ty": 2,
      "x": 832,
      "y": 816
    },
    {
      "t": 78499,
      "e": 62960,
      "ty": 41,
      "x": 28120,
      "y": 40329,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 78599,
      "e": 63060,
      "ty": 2,
      "x": 831,
      "y": 815
    },
    {
      "t": 78693,
      "e": 63154,
      "ty": 3,
      "x": 831,
      "y": 815,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 78695,
      "e": 63156,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 78695,
      "e": 63156,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 78749,
      "e": 63210,
      "ty": 41,
      "x": 23079,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 78827,
      "e": 63288,
      "ty": 4,
      "x": 23079,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 78827,
      "e": 63288,
      "ty": 5,
      "x": 831,
      "y": 815,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 78828,
      "e": 63289,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf",
      "v": "Humanities"
    },
    {
      "t": 79079,
      "e": 63540,
      "ty": 7,
      "x": 851,
      "y": 815,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 79099,
      "e": 63560,
      "ty": 2,
      "x": 874,
      "y": 815
    },
    {
      "t": 79199,
      "e": 63660,
      "ty": 2,
      "x": 947,
      "y": 839
    },
    {
      "t": 79249,
      "e": 63710,
      "ty": 41,
      "x": 30040,
      "y": 46810,
      "ta": "#jspsych-survey-multi-choice-option-2-6"
    },
    {
      "t": 79299,
      "e": 63760,
      "ty": 2,
      "x": 936,
      "y": 877
    },
    {
      "t": 79400,
      "e": 63861,
      "ty": 2,
      "x": 884,
      "y": 931
    },
    {
      "t": 79499,
      "e": 63960,
      "ty": 2,
      "x": 862,
      "y": 935
    },
    {
      "t": 79500,
      "e": 63961,
      "ty": 41,
      "x": 44321,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 79599,
      "e": 64060,
      "ty": 2,
      "x": 822,
      "y": 943
    },
    {
      "t": 79699,
      "e": 64160,
      "ty": 2,
      "x": 820,
      "y": 943
    },
    {
      "t": 79749,
      "e": 64210,
      "ty": 41,
      "x": 27825,
      "y": 52350,
      "ta": "html > body"
    },
    {
      "t": 79799,
      "e": 64260,
      "ty": 2,
      "x": 812,
      "y": 969
    },
    {
      "t": 79899,
      "e": 64360,
      "ty": 2,
      "x": 812,
      "y": 973
    },
    {
      "t": 79978,
      "e": 64439,
      "ty": 6,
      "x": 829,
      "y": 962,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 79999,
      "e": 64460,
      "ty": 2,
      "x": 832,
      "y": 961
    },
    {
      "t": 80000,
      "e": 64461,
      "ty": 41,
      "x": 28120,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 80099,
      "e": 64560,
      "ty": 2,
      "x": 836,
      "y": 960
    },
    {
      "t": 80200,
      "e": 64661,
      "ty": 2,
      "x": 837,
      "y": 959
    },
    {
      "t": 80244,
      "e": 64705,
      "ty": 3,
      "x": 837,
      "y": 959,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 80246,
      "e": 64707,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 80246,
      "e": 64707,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 80249,
      "e": 64710,
      "ty": 41,
      "x": 53325,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 80339,
      "e": 64800,
      "ty": 4,
      "x": 53325,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 80339,
      "e": 64800,
      "ty": 5,
      "x": 837,
      "y": 959,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 80340,
      "e": 64801,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 80484,
      "e": 64945,
      "ty": 7,
      "x": 841,
      "y": 961,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 80499,
      "e": 64960,
      "ty": 2,
      "x": 842,
      "y": 964
    },
    {
      "t": 80499,
      "e": 64960,
      "ty": 41,
      "x": 16646,
      "y": 36044,
      "ta": "#jspsych-survey-multi-choice-option-3-1 > label"
    },
    {
      "t": 80597,
      "e": 65058,
      "ty": 6,
      "x": 866,
      "y": 1007,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 80598,
      "e": 65059,
      "ty": 2,
      "x": 866,
      "y": 1007
    },
    {
      "t": 80700,
      "e": 65161,
      "ty": 2,
      "x": 868,
      "y": 1018
    },
    {
      "t": 80750,
      "e": 65211,
      "ty": 41,
      "x": 20913,
      "y": 31774,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 80799,
      "e": 65260,
      "ty": 2,
      "x": 873,
      "y": 1026
    },
    {
      "t": 80899,
      "e": 65360,
      "ty": 2,
      "x": 873,
      "y": 1028
    },
    {
      "t": 80909,
      "e": 65370,
      "ty": 3,
      "x": 873,
      "y": 1028,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 80910,
      "e": 65371,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 80911,
      "e": 65372,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 80979,
      "e": 65440,
      "ty": 4,
      "x": 22459,
      "y": 45675,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 80979,
      "e": 65440,
      "ty": 5,
      "x": 873,
      "y": 1028,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 80981,
      "e": 65442,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 80983,
      "e": 65444,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 80983,
      "e": 65444,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 80999,
      "e": 65460,
      "ty": 41,
      "x": 29788,
      "y": 56505,
      "ta": "html > body"
    },
    {
      "t": 81699,
      "e": 66160,
      "ty": 2,
      "x": 877,
      "y": 1027
    },
    {
      "t": 81749,
      "e": 66210,
      "ty": 41,
      "x": 29995,
      "y": 56228,
      "ta": "html > body"
    },
    {
      "t": 81799,
      "e": 66260,
      "ty": 2,
      "x": 880,
      "y": 1018
    },
    {
      "t": 81899,
      "e": 66360,
      "ty": 2,
      "x": 886,
      "y": 1000
    },
    {
      "t": 81998,
      "e": 66459,
      "ty": 2,
      "x": 899,
      "y": 957
    },
    {
      "t": 81999,
      "e": 66460,
      "ty": 41,
      "x": 30684,
      "y": 52572,
      "ta": "html > body"
    },
    {
      "t": 82098,
      "e": 66559,
      "ty": 2,
      "x": 936,
      "y": 863
    },
    {
      "t": 82199,
      "e": 66660,
      "ty": 2,
      "x": 1088,
      "y": 644
    },
    {
      "t": 82249,
      "e": 66710,
      "ty": 41,
      "x": 42048,
      "y": 26646,
      "ta": "html > body"
    },
    {
      "t": 82299,
      "e": 66760,
      "ty": 2,
      "x": 1358,
      "y": 364
    },
    {
      "t": 82332,
      "e": 66793,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 82400,
      "e": 66861,
      "ty": 2,
      "x": 1394,
      "y": 337
    },
    {
      "t": 82499,
      "e": 66960,
      "ty": 41,
      "x": 54143,
      "y": 5887,
      "ta": "> div.masterdiv > div:[2] > div > p"
    },
    {
      "t": 83099,
      "e": 67560,
      "ty": 2,
      "x": 945,
      "y": 610
    },
    {
      "t": 83200,
      "e": 67661,
      "ty": 2,
      "x": 873,
      "y": 695
    },
    {
      "t": 83250,
      "e": 67711,
      "ty": 41,
      "x": 28364,
      "y": 41261,
      "ta": "> div.masterdiv > div:[2] > div > p:[4]"
    },
    {
      "t": 83300,
      "e": 67761,
      "ty": 2,
      "x": 881,
      "y": 824
    },
    {
      "t": 83399,
      "e": 67860,
      "ty": 2,
      "x": 951,
      "y": 922
    },
    {
      "t": 83499,
      "e": 67960,
      "ty": 2,
      "x": 1053,
      "y": 953
    },
    {
      "t": 83500,
      "e": 67961,
      "ty": 41,
      "x": 37367,
      "y": 57246,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 83600,
      "e": 68061,
      "ty": 2,
      "x": 1057,
      "y": 954
    },
    {
      "t": 83750,
      "e": 68211,
      "ty": 41,
      "x": 37564,
      "y": 57316,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 89999,
      "e": 73211,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 91796,
      "e": 73211,
      "ty": 2,
      "x": 1050,
      "y": 954
    },
    {
      "t": 91896,
      "e": 73311,
      "ty": 2,
      "x": 1039,
      "y": 954
    },
    {
      "t": 91996,
      "e": 73411,
      "ty": 2,
      "x": 1024,
      "y": 957
    },
    {
      "t": 91997,
      "e": 73412,
      "ty": 41,
      "x": 35940,
      "y": 57523,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 92097,
      "e": 73512,
      "ty": 2,
      "x": 951,
      "y": 975
    },
    {
      "t": 92196,
      "e": 73611,
      "ty": 2,
      "x": 927,
      "y": 987
    },
    {
      "t": 92247,
      "e": 73662,
      "ty": 41,
      "x": 30627,
      "y": 60778,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 92297,
      "e": 73712,
      "ty": 2,
      "x": 906,
      "y": 1026
    },
    {
      "t": 92396,
      "e": 73811,
      "ty": 2,
      "x": 907,
      "y": 1059
    },
    {
      "t": 92494,
      "e": 73909,
      "ty": 6,
      "x": 940,
      "y": 1072,
      "ta": "#start"
    },
    {
      "t": 92496,
      "e": 73911,
      "ty": 2,
      "x": 940,
      "y": 1072
    },
    {
      "t": 92496,
      "e": 73911,
      "ty": 41,
      "x": 16656,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 92596,
      "e": 74011,
      "ty": 2,
      "x": 1000,
      "y": 1095
    },
    {
      "t": 92697,
      "e": 74112,
      "ty": 2,
      "x": 1006,
      "y": 1100
    },
    {
      "t": 92746,
      "e": 74161,
      "ty": 41,
      "x": 52701,
      "y": 52644,
      "ta": "#start"
    },
    {
      "t": 92787,
      "e": 74202,
      "ty": 7,
      "x": 1006,
      "y": 1107,
      "ta": "#start"
    },
    {
      "t": 92796,
      "e": 74211,
      "ty": 2,
      "x": 1006,
      "y": 1107
    },
    {
      "t": 92896,
      "e": 74311,
      "ty": 2,
      "x": 1003,
      "y": 1108
    },
    {
      "t": 92996,
      "e": 74411,
      "ty": 2,
      "x": 997,
      "y": 1108
    },
    {
      "t": 92997,
      "e": 74412,
      "ty": 41,
      "x": 50321,
      "y": 19562,
      "ta": "> div.masterdiv > div:[3]"
    },
    {
      "t": 93010,
      "e": 74425,
      "ty": 6,
      "x": 995,
      "y": 1105,
      "ta": "#start"
    },
    {
      "t": 93096,
      "e": 74511,
      "ty": 2,
      "x": 988,
      "y": 1098
    },
    {
      "t": 93197,
      "e": 74612,
      "ty": 2,
      "x": 985,
      "y": 1094
    },
    {
      "t": 93246,
      "e": 74661,
      "ty": 41,
      "x": 40140,
      "y": 35297,
      "ta": "#start"
    },
    {
      "t": 93296,
      "e": 74711,
      "ty": 2,
      "x": 982,
      "y": 1088
    },
    {
      "t": 93497,
      "e": 74912,
      "ty": 41,
      "x": 39594,
      "y": 29514,
      "ta": "#start"
    },
    {
      "t": 97323,
      "e": 78738,
      "ty": 3,
      "x": 982,
      "y": 1088,
      "ta": "#start"
    },
    {
      "t": 97324,
      "e": 78739,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 97457,
      "e": 78872,
      "ty": 4,
      "x": 39594,
      "y": 29514,
      "ta": "#start"
    },
    {
      "t": 97457,
      "e": 78872,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 97458,
      "e": 78873,
      "ty": 5,
      "x": 982,
      "y": 1088,
      "ta": "#start"
    },
    {
      "t": 97459,
      "e": 78874,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 98491,
      "e": 79906,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 99861,
      "e": 81276,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"nodeType\":3,\"id\":2593,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"full\\\"; } else if (axis == 2){ axis = \\\"partial\\\"; } else if (axis ==3){ axis = \\\"diagonal\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2590},{\"id\":2591},{\"nodeType\":3,\"id\":2594,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2592}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2595,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2596,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2595},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2597,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2596},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2598,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2597},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2596}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":2596}},{\"nodeType\":3,\"id\":2601,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2597}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2597}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":3,\"id\":2605,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2598}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2595},{\"id\":2596},{\"id\":2599},{\"id\":2601},{\"id\":2600},{\"id\":2597},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2598},{\"id\":2605}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2606,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2607,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2606}},{\"nodeType\":1,\"id\":2608,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2607},\"parentNode\":{\"id\":2606}},{\"nodeType\":1,\"id\":2609,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2608},\"parentNode\":{\"id\":2606}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2609},\"parentNode\":{\"id\":2606}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2606}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2606}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2608}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2608}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2608}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2615},\"parentNode\":{\"id\":2608}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2608}},{\"nodeType\":3,\"id\":2618,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2621,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":3,\"id\":2622,\"textContent\":\"English\",\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2615}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2632,\"textContent\":\"*\",\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2634,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2635,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2634},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2635},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2609}},{\"nodeType\":3,\"id\":2641,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2633}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2633}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2634}},{\"nodeType\":1,\"id\":2644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":3,\"id\":2645,\"textContent\":\"First\",\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2635}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2664,\"textContent\":\"*\",\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2610}},{\"nodeType\":1,\"id\":2666,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2610}},{\"nodeType\":1,\"id\":2667,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2666},\"parentNode\":{\"id\":2610}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2667},\"parentNode\":{\"id\":2610}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2610}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2610}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2610}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2610}},{\"nodeType\":3,\"id\":2673,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2665}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2665}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2666}},{\"nodeType\":1,\"id\":2676,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":3,\"id\":2677,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2667}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2696,\"textContent\":\"*\",\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2698,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2699,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2698},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2699},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2701,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2697}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2697}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2698}},{\"nodeType\":1,\"id\":2704,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":3,\"id\":2705,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2699}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2712,\"textContent\":\"*\",\"parentNode\":{\"id\":2702}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2606},{\"id\":2607},{\"id\":2608},{\"id\":2613},{\"id\":2618},{\"id\":2619},{\"id\":2632},{\"id\":2614},{\"id\":2620},{\"id\":2621},{\"id\":2622},{\"id\":2615},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2616},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2617},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2609},{\"id\":2633},{\"id\":2641},{\"id\":2642},{\"id\":2664},{\"id\":2634},{\"id\":2643},{\"id\":2644},{\"id\":2645},{\"id\":2635},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2636},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2637},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2638},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2639},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2640},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2610},{\"id\":2665},{\"id\":2673},{\"id\":2674},{\"id\":2696},{\"id\":2666},{\"id\":2675},{\"id\":2676},{\"id\":2677},{\"id\":2667},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2668},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2669},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2670},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2671},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2672},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2611},{\"id\":2697},{\"id\":2701},{\"id\":2702},{\"id\":2712},{\"id\":2698},{\"id\":2703},{\"id\":2704},{\"id\":2705},{\"id\":2699},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2700},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2612}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2713,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2714,\"textContent\":\" \",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2715,\"textContent\":\" \",\"parentNode\":{\"id\":2713}},{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2715},\"parentNode\":{\"id\":2713}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":2713}},{\"nodeType\":1,\"id\":2718,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2717},\"parentNode\":{\"id\":2713}},{\"nodeType\":3,\"id\":2719,\"textContent\":\" \",\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2713}},{\"nodeType\":1,\"id\":2720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2713}},{\"nodeType\":3,\"id\":2721,\"textContent\":\" \",\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2713}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2728,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2729,\"textContent\":\" \",\"parentNode\":{\"id\":2718}},{\"nodeType\":1,\"id\":2730,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2718}},{\"nodeType\":3,\"id\":2731,\"textContent\":\" \",\"previousSibling\":{\"id\":2730},\"parentNode\":{\"id\":2718}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2730}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2730}},{\"nodeType\":1,\"id\":2734,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2730}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"previousSibling\":{\"id\":2734},\"parentNode\":{\"id\":2730}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2730}},{\"nodeType\":3,\"id\":2737,\"textContent\":\" \",\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2730}},{\"nodeType\":1,\"id\":2738,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2730}},{\"nodeType\":3,\"id\":2739,\"textContent\":\" \",\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2730}},{\"nodeType\":1,\"id\":2740,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2730}},{\"nodeType\":3,\"id\":2741,\"textContent\":\" \",\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2730}},{\"nodeType\":1,\"id\":2742,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2730}},{\"nodeType\":3,\"id\":2743,\"textContent\":\" \",\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2730}},{\"nodeType\":3,\"id\":2744,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2745,\"textContent\":\" \",\"parentNode\":{\"id\":2734}},{\"nodeType\":1,\"id\":2746,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2734}},{\"nodeType\":3,\"id\":2747,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2746},\"parentNode\":{\"id\":2734}},{\"nodeType\":3,\"id\":2748,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2746}},{\"nodeType\":3,\"id\":2749,\"textContent\":\" \",\"parentNode\":{\"id\":2736}},{\"nodeType\":1,\"id\":2750,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2751,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2750},\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2752,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2750}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2738}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2738}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":3,\"id\":2756,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2740}},{\"nodeType\":3,\"id\":2757,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2742}},{\"nodeType\":3,\"id\":2758,\"textContent\":\" \",\"parentNode\":{\"id\":2720}},{\"nodeType\":1,\"id\":2759,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2758},\"parentNode\":{\"id\":2720}},{\"nodeType\":3,\"id\":2760,\"textContent\":\" \",\"previousSibling\":{\"id\":2759},\"parentNode\":{\"id\":2720}},{\"nodeType\":3,\"id\":2761,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2759}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2713},{\"id\":2715},{\"id\":2716},{\"id\":2722},{\"id\":2723},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2727},{\"id\":2724},{\"id\":2717},{\"id\":2718},{\"id\":2729},{\"id\":2730},{\"id\":2732},{\"id\":2733},{\"id\":2744},{\"id\":2734},{\"id\":2745},{\"id\":2746},{\"id\":2748},{\"id\":2747},{\"id\":2735},{\"id\":2736},{\"id\":2749},{\"id\":2750},{\"id\":2752},{\"id\":2751},{\"id\":2737},{\"id\":2738},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2739},{\"id\":2740},{\"id\":2756},{\"id\":2741},{\"id\":2742},{\"id\":2757},{\"id\":2743},{\"id\":2731},{\"id\":2719},{\"id\":2720},{\"id\":2758},{\"id\":2759},{\"id\":2761},{\"id\":2760},{\"id\":2721},{\"id\":2714}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2762,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2763,\"textContent\":\"[ { \\\"rt\\\": 49768, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 32, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 49775, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"HWJDK\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"men\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 72875, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 123743, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"HWJDK\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"men\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 8629, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"MEN\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"113\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 133378, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"HWJDK\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"men\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 10595, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 145307, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"HWJDK\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"men\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 15552, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 161863, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"HWJDK\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"men\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 15980, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 179205, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"HWJDK\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"men\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"diagonal\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-11 AM-A -A -11 AM-11 AM-A -A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:989,y:718,t:1526667057295};\\\", \\\"{x:1009,y:722,t:1526667057305};\\\", \\\"{x:1054,y:724,t:1526667057316};\\\", \\\"{x:1184,y:724,t:1526667057333};\\\", \\\"{x:1259,y:733,t:1526667057350};\\\", \\\"{x:1341,y:741,t:1526667057367};\\\", \\\"{x:1411,y:762,t:1526667057383};\\\", \\\"{x:1469,y:779,t:1526667057401};\\\", \\\"{x:1499,y:793,t:1526667057416};\\\", \\\"{x:1530,y:816,t:1526667057433};\\\", \\\"{x:1547,y:835,t:1526667057451};\\\", \\\"{x:1558,y:858,t:1526667057466};\\\", \\\"{x:1567,y:881,t:1526667057483};\\\", \\\"{x:1567,y:904,t:1526667057500};\\\", \\\"{x:1564,y:918,t:1526667057517};\\\", \\\"{x:1543,y:933,t:1526667057534};\\\", \\\"{x:1528,y:937,t:1526667057551};\\\", \\\"{x:1512,y:946,t:1526667057567};\\\", \\\"{x:1497,y:961,t:1526667057583};\\\", \\\"{x:1479,y:976,t:1526667057601};\\\", \\\"{x:1458,y:991,t:1526667057617};\\\", \\\"{x:1439,y:1004,t:1526667057634};\\\", \\\"{x:1417,y:1009,t:1526667057650};\\\", \\\"{x:1400,y:1015,t:1526667057667};\\\", \\\"{x:1390,y:1021,t:1526667057683};\\\", \\\"{x:1381,y:1022,t:1526667057700};\\\", \\\"{x:1376,y:1022,t:1526667057716};\\\", \\\"{x:1359,y:1014,t:1526667057733};\\\", \\\"{x:1347,y:1005,t:1526667057750};\\\", \\\"{x:1328,y:997,t:1526667057766};\\\", \\\"{x:1312,y:989,t:1526667057784};\\\", \\\"{x:1300,y:983,t:1526667057801};\\\", \\\"{x:1298,y:983,t:1526667057816};\\\", \\\"{x:1297,y:983,t:1526667057917};\\\", \\\"{x:1295,y:982,t:1526667057956};\\\", \\\"{x:1294,y:982,t:1526667057968};\\\", \\\"{x:1292,y:982,t:1526667057983};\\\", \\\"{x:1289,y:981,t:1526667058001};\\\", \\\"{x:1285,y:981,t:1526667058018};\\\", \\\"{x:1279,y:978,t:1526667058034};\\\", \\\"{x:1275,y:976,t:1526667058051};\\\", \\\"{x:1274,y:975,t:1526667058067};\\\", \\\"{x:1274,y:974,t:1526667058101};\\\", \\\"{x:1274,y:972,t:1526667058118};\\\", \\\"{x:1274,y:968,t:1526667058134};\\\", \\\"{x:1274,y:967,t:1526667058157};\\\", \\\"{x:1276,y:966,t:1526667058167};\\\", \\\"{x:1277,y:965,t:1526667058230};\\\", \\\"{x:1277,y:962,t:1526667058254};\\\", \\\"{x:1280,y:957,t:1526667058269};\\\", \\\"{x:1281,y:954,t:1526667058286};\\\", \\\"{x:1282,y:949,t:1526667058302};\\\", \\\"{x:1284,y:946,t:1526667058318};\\\", \\\"{x:1285,y:942,t:1526667058335};\\\", \\\"{x:1285,y:940,t:1526667058352};\\\", \\\"{x:1285,y:936,t:1526667058368};\\\", \\\"{x:1286,y:933,t:1526667058385};\\\", \\\"{x:1288,y:924,t:1526667058402};\\\", \\\"{x:1289,y:919,t:1526667058418};\\\", \\\"{x:1290,y:912,t:1526667058435};\\\", \\\"{x:1290,y:909,t:1526667058451};\\\", \\\"{x:1290,y:901,t:1526667058469};\\\", \\\"{x:1290,y:894,t:1526667058485};\\\", \\\"{x:1290,y:888,t:1526667058501};\\\", \\\"{x:1290,y:881,t:1526667058518};\\\", \\\"{x:1292,y:875,t:1526667058535};\\\", \\\"{x:1292,y:872,t:1526667058551};\\\", \\\"{x:1292,y:867,t:1526667058568};\\\", \\\"{x:1292,y:860,t:1526667058585};\\\", \\\"{x:1292,y:856,t:1526667058600};\\\", \\\"{x:1292,y:851,t:1526667058617};\\\", \\\"{x:1292,y:844,t:1526667058635};\\\", \\\"{x:1291,y:839,t:1526667058650};\\\", \\\"{x:1291,y:837,t:1526667058668};\\\", \\\"{x:1291,y:836,t:1526667058684};\\\", \\\"{x:1291,y:834,t:1526667058742};\\\", \\\"{x:1289,y:832,t:1526667058758};\\\", \\\"{x:1288,y:829,t:1526667058773};\\\", \\\"{x:1287,y:829,t:1526667058785};\\\", \\\"{x:1286,y:828,t:1526667058804};\\\", \\\"{x:1284,y:827,t:1526667058834};\\\", \\\"{x:1283,y:827,t:1526667059406};\\\", \\\"{x:1281,y:827,t:1526667059419};\\\", \\\"{x:1280,y:829,t:1526667059435};\\\", \\\"{x:1279,y:829,t:1526667059869};\\\", \\\"{x:1279,y:824,t:1526667059886};\\\", \\\"{x:1279,y:811,t:1526667059902};\\\", \\\"{x:1278,y:803,t:1526667059920};\\\", \\\"{x:1278,y:798,t:1526667059936};\\\", \\\"{x:1276,y:795,t:1526667059952};\\\", \\\"{x:1276,y:791,t:1526667059969};\\\", \\\"{x:1276,y:785,t:1526667059986};\\\", \\\"{x:1276,y:780,t:1526667060002};\\\", \\\"{x:1276,y:776,t:1526667060019};\\\", \\\"{x:1276,y:770,t:1526667060036};\\\", \\\"{x:1276,y:761,t:1526667060052};\\\", \\\"{x:1278,y:753,t:1526667060069};\\\", \\\"{x:1280,y:743,t:1526667060085};\\\", \\\"{x:1283,y:733,t:1526667060102};\\\", \\\"{x:1287,y:718,t:1526667060119};\\\", \\\"{x:1289,y:706,t:1526667060136};\\\", \\\"{x:1292,y:697,t:1526667060152};\\\", \\\"{x:1293,y:688,t:1526667060169};\\\", \\\"{x:1293,y:684,t:1526667060186};\\\", \\\"{x:1294,y:677,t:1526667060202};\\\", \\\"{x:1294,y:659,t:1526667060219};\\\", \\\"{x:1298,y:649,t:1526667060237};\\\", \\\"{x:1298,y:638,t:1526667060253};\\\", \\\"{x:1299,y:618,t:1526667060269};\\\", \\\"{x:1299,y:608,t:1526667060286};\\\", \\\"{x:1296,y:594,t:1526667060302};\\\", \\\"{x:1294,y:588,t:1526667060319};\\\", \\\"{x:1292,y:582,t:1526667060336};\\\", \\\"{x:1288,y:575,t:1526667060353};\\\", \\\"{x:1282,y:568,t:1526667060368};\\\", \\\"{x:1270,y:562,t:1526667060386};\\\", \\\"{x:1254,y:558,t:1526667060403};\\\", \\\"{x:1232,y:555,t:1526667060419};\\\", \\\"{x:1206,y:551,t:1526667060437};\\\", \\\"{x:1186,y:549,t:1526667060453};\\\", \\\"{x:1107,y:549,t:1526667060469};\\\", \\\"{x:1035,y:549,t:1526667060486};\\\", \\\"{x:968,y:540,t:1526667060503};\\\", \\\"{x:920,y:533,t:1526667060520};\\\", \\\"{x:869,y:521,t:1526667060535};\\\", \\\"{x:836,y:519,t:1526667060553};\\\", \\\"{x:806,y:519,t:1526667060569};\\\", \\\"{x:770,y:513,t:1526667060586};\\\", \\\"{x:750,y:513,t:1526667060603};\\\", \\\"{x:716,y:507,t:1526667060619};\\\", \\\"{x:651,y:500,t:1526667060637};\\\", \\\"{x:623,y:493,t:1526667060652};\\\", \\\"{x:597,y:488,t:1526667060669};\\\", \\\"{x:555,y:488,t:1526667060686};\\\", \\\"{x:521,y:486,t:1526667060703};\\\", \\\"{x:481,y:486,t:1526667060720};\\\", \\\"{x:463,y:490,t:1526667060736};\\\", \\\"{x:445,y:499,t:1526667060754};\\\", \\\"{x:435,y:505,t:1526667060769};\\\", \\\"{x:418,y:510,t:1526667060788};\\\", \\\"{x:400,y:517,t:1526667060804};\\\", \\\"{x:373,y:528,t:1526667060821};\\\", \\\"{x:356,y:534,t:1526667060836};\\\", \\\"{x:343,y:539,t:1526667060854};\\\", \\\"{x:325,y:543,t:1526667060869};\\\", \\\"{x:310,y:549,t:1526667060887};\\\", \\\"{x:296,y:557,t:1526667060904};\\\", \\\"{x:292,y:563,t:1526667060919};\\\", \\\"{x:289,y:567,t:1526667060936};\\\", \\\"{x:289,y:568,t:1526667060953};\\\", \\\"{x:291,y:568,t:1526667061021};\\\", \\\"{x:303,y:559,t:1526667061037};\\\", \\\"{x:315,y:552,t:1526667061054};\\\", \\\"{x:326,y:544,t:1526667061070};\\\", \\\"{x:338,y:538,t:1526667061086};\\\", \\\"{x:345,y:538,t:1526667061104};\\\", \\\"{x:348,y:537,t:1526667061120};\\\", \\\"{x:348,y:536,t:1526667061136};\\\", \\\"{x:350,y:535,t:1526667061181};\\\", \\\"{x:351,y:533,t:1526667061197};\\\", \\\"{x:351,y:532,t:1526667061205};\\\", \\\"{x:353,y:531,t:1526667061221};\\\", \\\"{x:353,y:530,t:1526667061237};\\\", \\\"{x:356,y:528,t:1526667061254};\\\", \\\"{x:357,y:526,t:1526667061270};\\\", \\\"{x:360,y:526,t:1526667061286};\\\", \\\"{x:362,y:526,t:1526667061304};\\\", \\\"{x:366,y:526,t:1526667061366};\\\", \\\"{x:367,y:525,t:1526667061382};\\\", \\\"{x:369,y:525,t:1526667061390};\\\", \\\"{x:370,y:524,t:1526667061404};\\\", \\\"{x:381,y:522,t:1526667061422};\\\", \\\"{x:386,y:522,t:1526667061437};\\\", \\\"{x:388,y:521,t:1526667061454};\\\", \\\"{x:389,y:520,t:1526667061470};\\\", \\\"{x:391,y:520,t:1526667061508};\\\", \\\"{x:392,y:519,t:1526667061520};\\\", \\\"{x:394,y:519,t:1526667061537};\\\", \\\"{x:396,y:518,t:1526667061553};\\\", \\\"{x:399,y:518,t:1526667061570};\\\", \\\"{x:399,y:517,t:1526667061822};\\\", \\\"{x:397,y:517,t:1526667061860};\\\", \\\"{x:396,y:517,t:1526667061871};\\\", \\\"{x:395,y:517,t:1526667061886};\\\", \\\"{x:395,y:518,t:1526667062549};\\\", \\\"{x:399,y:518,t:1526667062557};\\\", \\\"{x:414,y:520,t:1526667062572};\\\", \\\"{x:444,y:522,t:1526667062588};\\\", \\\"{x:572,y:522,t:1526667062605};\\\", \\\"{x:680,y:522,t:1526667062622};\\\", \\\"{x:791,y:522,t:1526667062639};\\\", \\\"{x:883,y:538,t:1526667062655};\\\", \\\"{x:979,y:559,t:1526667062671};\\\", \\\"{x:1064,y:580,t:1526667062689};\\\", \\\"{x:1126,y:599,t:1526667062704};\\\", \\\"{x:1171,y:612,t:1526667062721};\\\", \\\"{x:1187,y:623,t:1526667062739};\\\", \\\"{x:1200,y:634,t:1526667062755};\\\", \\\"{x:1203,y:643,t:1526667062772};\\\", \\\"{x:1203,y:666,t:1526667062788};\\\", \\\"{x:1203,y:685,t:1526667062805};\\\", \\\"{x:1203,y:704,t:1526667062822};\\\", \\\"{x:1198,y:723,t:1526667062839};\\\", \\\"{x:1188,y:742,t:1526667062855};\\\", \\\"{x:1177,y:759,t:1526667062872};\\\", \\\"{x:1168,y:778,t:1526667062888};\\\", \\\"{x:1161,y:793,t:1526667062906};\\\", \\\"{x:1157,y:807,t:1526667062922};\\\", \\\"{x:1157,y:815,t:1526667062939};\\\", \\\"{x:1156,y:819,t:1526667062955};\\\", \\\"{x:1156,y:820,t:1526667062973};\\\", \\\"{x:1155,y:820,t:1526667062996};\\\", \\\"{x:1155,y:819,t:1526667063021};\\\", \\\"{x:1155,y:809,t:1526667063029};\\\", \\\"{x:1156,y:801,t:1526667063040};\\\", \\\"{x:1164,y:774,t:1526667063057};\\\", \\\"{x:1172,y:744,t:1526667063073};\\\", \\\"{x:1188,y:710,t:1526667063090};\\\", \\\"{x:1199,y:688,t:1526667063106};\\\", \\\"{x:1208,y:677,t:1526667063123};\\\", \\\"{x:1216,y:665,t:1526667063140};\\\", \\\"{x:1221,y:656,t:1526667063157};\\\", \\\"{x:1222,y:653,t:1526667063173};\\\", \\\"{x:1223,y:651,t:1526667063189};\\\", \\\"{x:1223,y:649,t:1526667063207};\\\", \\\"{x:1225,y:644,t:1526667063223};\\\", \\\"{x:1226,y:638,t:1526667063240};\\\", \\\"{x:1230,y:631,t:1526667063257};\\\", \\\"{x:1234,y:619,t:1526667063273};\\\", \\\"{x:1240,y:606,t:1526667063291};\\\", \\\"{x:1246,y:597,t:1526667063307};\\\", \\\"{x:1253,y:587,t:1526667063323};\\\", \\\"{x:1260,y:576,t:1526667063341};\\\", \\\"{x:1264,y:569,t:1526667063357};\\\", \\\"{x:1271,y:560,t:1526667063374};\\\", \\\"{x:1277,y:550,t:1526667063391};\\\", \\\"{x:1283,y:543,t:1526667063407};\\\", \\\"{x:1286,y:537,t:1526667063423};\\\", \\\"{x:1288,y:533,t:1526667063441};\\\", \\\"{x:1288,y:535,t:1526667063574};\\\", \\\"{x:1278,y:549,t:1526667063591};\\\", \\\"{x:1272,y:560,t:1526667063608};\\\", \\\"{x:1263,y:571,t:1526667063625};\\\", \\\"{x:1256,y:583,t:1526667063642};\\\", \\\"{x:1245,y:599,t:1526667063659};\\\", \\\"{x:1230,y:619,t:1526667063675};\\\", \\\"{x:1219,y:639,t:1526667063692};\\\", \\\"{x:1204,y:669,t:1526667063709};\\\", \\\"{x:1192,y:689,t:1526667063725};\\\", \\\"{x:1184,y:705,t:1526667063742};\\\", \\\"{x:1181,y:722,t:1526667063759};\\\", \\\"{x:1178,y:739,t:1526667063776};\\\", \\\"{x:1176,y:754,t:1526667063792};\\\", \\\"{x:1180,y:775,t:1526667063809};\\\", \\\"{x:1190,y:797,t:1526667063826};\\\", \\\"{x:1200,y:817,t:1526667063843};\\\", \\\"{x:1215,y:838,t:1526667063859};\\\", \\\"{x:1227,y:853,t:1526667063876};\\\", \\\"{x:1256,y:899,t:1526667063893};\\\", \\\"{x:1274,y:926,t:1526667063909};\\\", \\\"{x:1287,y:949,t:1526667063927};\\\", \\\"{x:1299,y:969,t:1526667063943};\\\", \\\"{x:1310,y:982,t:1526667063960};\\\", \\\"{x:1316,y:988,t:1526667063976};\\\", \\\"{x:1321,y:991,t:1526667063993};\\\", \\\"{x:1322,y:992,t:1526667064010};\\\", \\\"{x:1323,y:993,t:1526667064078};\\\", \\\"{x:1323,y:994,t:1526667064181};\\\", \\\"{x:1320,y:994,t:1526667064194};\\\", \\\"{x:1312,y:990,t:1526667064210};\\\", \\\"{x:1307,y:984,t:1526667064227};\\\", \\\"{x:1304,y:984,t:1526667064244};\\\", \\\"{x:1304,y:983,t:1526667064366};\\\", \\\"{x:1304,y:982,t:1526667064382};\\\", \\\"{x:1304,y:978,t:1526667064397};\\\", \\\"{x:1304,y:977,t:1526667064411};\\\", \\\"{x:1304,y:970,t:1526667064428};\\\", \\\"{x:1300,y:955,t:1526667064444};\\\", \\\"{x:1298,y:953,t:1526667064460};\\\", \\\"{x:1295,y:952,t:1526667064478};\\\", \\\"{x:1287,y:951,t:1526667064494};\\\", \\\"{x:1275,y:951,t:1526667064512};\\\", \\\"{x:1264,y:951,t:1526667064528};\\\", \\\"{x:1255,y:951,t:1526667064545};\\\", \\\"{x:1251,y:951,t:1526667064562};\\\", \\\"{x:1250,y:952,t:1526667064578};\\\", \\\"{x:1250,y:953,t:1526667064677};\\\", \\\"{x:1251,y:954,t:1526667064684};\\\", \\\"{x:1254,y:956,t:1526667064696};\\\", \\\"{x:1259,y:960,t:1526667064712};\\\", \\\"{x:1269,y:965,t:1526667064729};\\\", \\\"{x:1274,y:967,t:1526667064746};\\\", \\\"{x:1281,y:968,t:1526667064762};\\\", \\\"{x:1285,y:969,t:1526667064779};\\\", \\\"{x:1284,y:969,t:1526667065022};\\\", \\\"{x:1283,y:969,t:1526667065038};\\\", \\\"{x:1281,y:969,t:1526667065062};\\\", \\\"{x:1280,y:969,t:1526667065103};\\\", \\\"{x:1278,y:969,t:1526667065182};\\\", \\\"{x:1274,y:969,t:1526667065198};\\\", \\\"{x:1272,y:969,t:1526667065222};\\\", \\\"{x:1271,y:968,t:1526667065750};\\\", \\\"{x:1270,y:966,t:1526667065767};\\\", \\\"{x:1269,y:963,t:1526667065783};\\\", \\\"{x:1268,y:962,t:1526667065800};\\\", \\\"{x:1268,y:957,t:1526667065816};\\\", \\\"{x:1268,y:944,t:1526667065834};\\\", \\\"{x:1268,y:922,t:1526667065850};\\\", \\\"{x:1268,y:912,t:1526667065866};\\\", \\\"{x:1268,y:905,t:1526667065883};\\\", \\\"{x:1266,y:897,t:1526667065901};\\\", \\\"{x:1266,y:891,t:1526667065917};\\\", \\\"{x:1265,y:887,t:1526667065934};\\\", \\\"{x:1265,y:880,t:1526667065951};\\\", \\\"{x:1265,y:872,t:1526667065967};\\\", \\\"{x:1267,y:859,t:1526667065983};\\\", \\\"{x:1273,y:839,t:1526667066001};\\\", \\\"{x:1277,y:826,t:1526667066018};\\\", \\\"{x:1279,y:820,t:1526667066035};\\\", \\\"{x:1281,y:817,t:1526667066050};\\\", \\\"{x:1280,y:815,t:1526667066149};\\\", \\\"{x:1275,y:815,t:1526667066157};\\\", \\\"{x:1267,y:815,t:1526667066167};\\\", \\\"{x:1240,y:815,t:1526667066184};\\\", \\\"{x:1189,y:815,t:1526667066201};\\\", \\\"{x:1092,y:813,t:1526667066218};\\\", \\\"{x:984,y:797,t:1526667066234};\\\", \\\"{x:853,y:776,t:1526667066251};\\\", \\\"{x:729,y:762,t:1526667066267};\\\", \\\"{x:629,y:746,t:1526667066284};\\\", \\\"{x:532,y:728,t:1526667066302};\\\", \\\"{x:512,y:723,t:1526667066318};\\\", \\\"{x:494,y:723,t:1526667066334};\\\", \\\"{x:475,y:723,t:1526667066358};\\\", \\\"{x:464,y:725,t:1526667066374};\\\", \\\"{x:463,y:727,t:1526667066391};\\\", \\\"{x:458,y:728,t:1526667066408};\\\", \\\"{x:453,y:728,t:1526667066425};\\\", \\\"{x:449,y:728,t:1526667066441};\\\", \\\"{x:448,y:728,t:1526667066458};\\\", \\\"{x:450,y:727,t:1526667066509};\\\", \\\"{x:466,y:721,t:1526667066525};\\\", \\\"{x:490,y:715,t:1526667066540};\\\", \\\"{x:504,y:711,t:1526667066557};\\\", \\\"{x:517,y:711,t:1526667066574};\\\", \\\"{x:521,y:711,t:1526667066591};\\\", \\\"{x:522,y:711,t:1526667066608};\\\" ] }, { \\\"rt\\\": 14347, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 194826, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"HWJDK\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"men\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"diagonal\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-D -D -E -E -04 PM-04 PM-04 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:528,y:711,t:1526667071602};\\\", \\\"{x:530,y:711,t:1526667071612};\\\", \\\"{x:549,y:709,t:1526667071627};\\\", \\\"{x:573,y:709,t:1526667071645};\\\", \\\"{x:597,y:709,t:1526667071662};\\\", \\\"{x:620,y:709,t:1526667071677};\\\", \\\"{x:643,y:712,t:1526667071693};\\\", \\\"{x:663,y:716,t:1526667071710};\\\", \\\"{x:683,y:722,t:1526667071727};\\\", \\\"{x:702,y:724,t:1526667071742};\\\", \\\"{x:716,y:727,t:1526667071760};\\\", \\\"{x:732,y:730,t:1526667071777};\\\", \\\"{x:747,y:732,t:1526667071793};\\\", \\\"{x:763,y:734,t:1526667071810};\\\", \\\"{x:784,y:737,t:1526667071826};\\\", \\\"{x:795,y:739,t:1526667071843};\\\", \\\"{x:802,y:739,t:1526667071860};\\\", \\\"{x:805,y:739,t:1526667071876};\\\", \\\"{x:806,y:739,t:1526667071894};\\\", \\\"{x:807,y:739,t:1526667071988};\\\", \\\"{x:810,y:740,t:1526667071995};\\\", \\\"{x:814,y:742,t:1526667072009};\\\", \\\"{x:830,y:752,t:1526667072026};\\\", \\\"{x:840,y:753,t:1526667072043};\\\", \\\"{x:842,y:753,t:1526667072059};\\\", \\\"{x:842,y:755,t:1526667072395};\\\", \\\"{x:845,y:757,t:1526667072411};\\\", \\\"{x:847,y:759,t:1526667072451};\\\", \\\"{x:848,y:759,t:1526667072491};\\\", \\\"{x:849,y:759,t:1526667072507};\\\", \\\"{x:851,y:758,t:1526667072515};\\\", \\\"{x:852,y:757,t:1526667072531};\\\", \\\"{x:853,y:757,t:1526667072544};\\\", \\\"{x:855,y:755,t:1526667072561};\\\", \\\"{x:859,y:753,t:1526667072577};\\\", \\\"{x:862,y:752,t:1526667072594};\\\", \\\"{x:869,y:748,t:1526667072611};\\\", \\\"{x:875,y:747,t:1526667072627};\\\", \\\"{x:882,y:745,t:1526667072644};\\\", \\\"{x:887,y:743,t:1526667072661};\\\", \\\"{x:891,y:742,t:1526667072677};\\\", \\\"{x:895,y:742,t:1526667072694};\\\", \\\"{x:897,y:741,t:1526667072711};\\\", \\\"{x:898,y:741,t:1526667072731};\\\", \\\"{x:898,y:740,t:1526667072754};\\\", \\\"{x:906,y:740,t:1526667073347};\\\", \\\"{x:915,y:739,t:1526667073361};\\\", \\\"{x:932,y:739,t:1526667073378};\\\", \\\"{x:962,y:739,t:1526667073395};\\\", \\\"{x:978,y:739,t:1526667073411};\\\", \\\"{x:1000,y:741,t:1526667073429};\\\", \\\"{x:1018,y:744,t:1526667073445};\\\", \\\"{x:1024,y:748,t:1526667073461};\\\", \\\"{x:1034,y:751,t:1526667073478};\\\", \\\"{x:1049,y:755,t:1526667073495};\\\", \\\"{x:1067,y:758,t:1526667073511};\\\", \\\"{x:1085,y:762,t:1526667073527};\\\", \\\"{x:1100,y:767,t:1526667073545};\\\", \\\"{x:1125,y:771,t:1526667073562};\\\", \\\"{x:1151,y:774,t:1526667073578};\\\", \\\"{x:1231,y:788,t:1526667073595};\\\", \\\"{x:1282,y:802,t:1526667073612};\\\", \\\"{x:1332,y:810,t:1526667073628};\\\", \\\"{x:1388,y:818,t:1526667073645};\\\", \\\"{x:1415,y:824,t:1526667073661};\\\", \\\"{x:1445,y:828,t:1526667073678};\\\", \\\"{x:1470,y:834,t:1526667073695};\\\", \\\"{x:1498,y:840,t:1526667073712};\\\", \\\"{x:1508,y:845,t:1526667073728};\\\", \\\"{x:1524,y:847,t:1526667073746};\\\", \\\"{x:1537,y:848,t:1526667073762};\\\", \\\"{x:1555,y:848,t:1526667073778};\\\", \\\"{x:1572,y:848,t:1526667073795};\\\", \\\"{x:1588,y:839,t:1526667073812};\\\", \\\"{x:1604,y:824,t:1526667073828};\\\", \\\"{x:1618,y:807,t:1526667073845};\\\", \\\"{x:1622,y:791,t:1526667073862};\\\", \\\"{x:1626,y:771,t:1526667073878};\\\", \\\"{x:1628,y:752,t:1526667073895};\\\", \\\"{x:1629,y:741,t:1526667073913};\\\", \\\"{x:1631,y:728,t:1526667073929};\\\", \\\"{x:1631,y:710,t:1526667073945};\\\", \\\"{x:1631,y:691,t:1526667073962};\\\", \\\"{x:1631,y:671,t:1526667073978};\\\", \\\"{x:1630,y:648,t:1526667073995};\\\", \\\"{x:1629,y:637,t:1526667074012};\\\", \\\"{x:1628,y:630,t:1526667074028};\\\", \\\"{x:1626,y:624,t:1526667074046};\\\", \\\"{x:1624,y:621,t:1526667074062};\\\", \\\"{x:1623,y:616,t:1526667074078};\\\", \\\"{x:1622,y:611,t:1526667074095};\\\", \\\"{x:1619,y:604,t:1526667074113};\\\", \\\"{x:1618,y:595,t:1526667074129};\\\", \\\"{x:1618,y:585,t:1526667074145};\\\", \\\"{x:1618,y:574,t:1526667074162};\\\", \\\"{x:1620,y:565,t:1526667074179};\\\", \\\"{x:1629,y:553,t:1526667074195};\\\", \\\"{x:1639,y:542,t:1526667074212};\\\", \\\"{x:1651,y:536,t:1526667074229};\\\", \\\"{x:1672,y:531,t:1526667074245};\\\", \\\"{x:1698,y:528,t:1526667074262};\\\", \\\"{x:1730,y:528,t:1526667074279};\\\", \\\"{x:1772,y:526,t:1526667074295};\\\", \\\"{x:1793,y:527,t:1526667074312};\\\", \\\"{x:1821,y:530,t:1526667074329};\\\", \\\"{x:1836,y:535,t:1526667074346};\\\", \\\"{x:1845,y:535,t:1526667074363};\\\", \\\"{x:1843,y:535,t:1526667074413};\\\", \\\"{x:1835,y:531,t:1526667074429};\\\", \\\"{x:1822,y:526,t:1526667074445};\\\", \\\"{x:1804,y:516,t:1526667074462};\\\", \\\"{x:1784,y:504,t:1526667074479};\\\", \\\"{x:1761,y:490,t:1526667074496};\\\", \\\"{x:1741,y:480,t:1526667074512};\\\", \\\"{x:1713,y:469,t:1526667074529};\\\", \\\"{x:1693,y:461,t:1526667074546};\\\", \\\"{x:1676,y:454,t:1526667074562};\\\", \\\"{x:1659,y:448,t:1526667074579};\\\", \\\"{x:1649,y:446,t:1526667074596};\\\", \\\"{x:1647,y:445,t:1526667074612};\\\", \\\"{x:1645,y:443,t:1526667074630};\\\", \\\"{x:1644,y:443,t:1526667074755};\\\", \\\"{x:1643,y:443,t:1526667074771};\\\", \\\"{x:1643,y:442,t:1526667074787};\\\", \\\"{x:1642,y:441,t:1526667074796};\\\", \\\"{x:1637,y:439,t:1526667074812};\\\", \\\"{x:1633,y:437,t:1526667074829};\\\", \\\"{x:1628,y:434,t:1526667074846};\\\", \\\"{x:1625,y:433,t:1526667074862};\\\", \\\"{x:1624,y:432,t:1526667075115};\\\", \\\"{x:1623,y:431,t:1526667075139};\\\", \\\"{x:1622,y:431,t:1526667075147};\\\", \\\"{x:1620,y:431,t:1526667075166};\\\", \\\"{x:1620,y:430,t:1526667075195};\\\", \\\"{x:1619,y:430,t:1526667075250};\\\", \\\"{x:1617,y:430,t:1526667075266};\\\", \\\"{x:1615,y:430,t:1526667075279};\\\", \\\"{x:1614,y:429,t:1526667075296};\\\", \\\"{x:1612,y:429,t:1526667075313};\\\", \\\"{x:1610,y:429,t:1526667075330};\\\", \\\"{x:1609,y:428,t:1526667075387};\\\", \\\"{x:1608,y:428,t:1526667075749};\\\", \\\"{x:1607,y:433,t:1526667075763};\\\", \\\"{x:1606,y:440,t:1526667075781};\\\", \\\"{x:1605,y:446,t:1526667075798};\\\", \\\"{x:1605,y:450,t:1526667075814};\\\", \\\"{x:1605,y:458,t:1526667075830};\\\", \\\"{x:1604,y:467,t:1526667075848};\\\", \\\"{x:1604,y:476,t:1526667075863};\\\", \\\"{x:1604,y:487,t:1526667075880};\\\", \\\"{x:1602,y:493,t:1526667075897};\\\", \\\"{x:1602,y:501,t:1526667075914};\\\", \\\"{x:1602,y:511,t:1526667075930};\\\", \\\"{x:1600,y:525,t:1526667075947};\\\", \\\"{x:1600,y:537,t:1526667075963};\\\", \\\"{x:1598,y:541,t:1526667075980};\\\", \\\"{x:1598,y:550,t:1526667075997};\\\", \\\"{x:1599,y:555,t:1526667076013};\\\", \\\"{x:1600,y:559,t:1526667076030};\\\", \\\"{x:1600,y:562,t:1526667076047};\\\", \\\"{x:1601,y:563,t:1526667076063};\\\", \\\"{x:1601,y:565,t:1526667076099};\\\", \\\"{x:1603,y:568,t:1526667076114};\\\", \\\"{x:1605,y:575,t:1526667076131};\\\", \\\"{x:1611,y:587,t:1526667076147};\\\", \\\"{x:1613,y:590,t:1526667076164};\\\", \\\"{x:1616,y:594,t:1526667076180};\\\", \\\"{x:1617,y:596,t:1526667076197};\\\", \\\"{x:1618,y:596,t:1526667076214};\\\", \\\"{x:1620,y:596,t:1526667076235};\\\", \\\"{x:1621,y:596,t:1526667076267};\\\", \\\"{x:1622,y:596,t:1526667076283};\\\", \\\"{x:1623,y:596,t:1526667076299};\\\", \\\"{x:1624,y:596,t:1526667076314};\\\", \\\"{x:1626,y:595,t:1526667076330};\\\", \\\"{x:1626,y:589,t:1526667076348};\\\", \\\"{x:1626,y:585,t:1526667076364};\\\", \\\"{x:1626,y:584,t:1526667076381};\\\", \\\"{x:1626,y:582,t:1526667076403};\\\", \\\"{x:1626,y:581,t:1526667076427};\\\", \\\"{x:1626,y:579,t:1526667076443};\\\", \\\"{x:1626,y:577,t:1526667076451};\\\", \\\"{x:1626,y:575,t:1526667076465};\\\", \\\"{x:1624,y:571,t:1526667076480};\\\", \\\"{x:1622,y:570,t:1526667076498};\\\", \\\"{x:1621,y:570,t:1526667076523};\\\", \\\"{x:1620,y:570,t:1526667076683};\\\", \\\"{x:1619,y:576,t:1526667076698};\\\", \\\"{x:1615,y:592,t:1526667076714};\\\", \\\"{x:1610,y:628,t:1526667076731};\\\", \\\"{x:1609,y:638,t:1526667076747};\\\", \\\"{x:1609,y:642,t:1526667076765};\\\", \\\"{x:1609,y:644,t:1526667076782};\\\", \\\"{x:1608,y:645,t:1526667076798};\\\", \\\"{x:1608,y:651,t:1526667076814};\\\", \\\"{x:1607,y:656,t:1526667076831};\\\", \\\"{x:1607,y:661,t:1526667076848};\\\", \\\"{x:1607,y:669,t:1526667076865};\\\", \\\"{x:1607,y:676,t:1526667076882};\\\", \\\"{x:1607,y:683,t:1526667076897};\\\", \\\"{x:1607,y:688,t:1526667076915};\\\", \\\"{x:1607,y:697,t:1526667076931};\\\", \\\"{x:1607,y:703,t:1526667076947};\\\", \\\"{x:1608,y:709,t:1526667076965};\\\", \\\"{x:1608,y:717,t:1526667076982};\\\", \\\"{x:1610,y:728,t:1526667076998};\\\", \\\"{x:1611,y:737,t:1526667077015};\\\", \\\"{x:1613,y:748,t:1526667077032};\\\", \\\"{x:1615,y:757,t:1526667077048};\\\", \\\"{x:1616,y:764,t:1526667077064};\\\", \\\"{x:1616,y:775,t:1526667077081};\\\", \\\"{x:1618,y:791,t:1526667077098};\\\", \\\"{x:1620,y:806,t:1526667077114};\\\", \\\"{x:1620,y:825,t:1526667077131};\\\", \\\"{x:1620,y:841,t:1526667077149};\\\", \\\"{x:1618,y:851,t:1526667077165};\\\", \\\"{x:1618,y:873,t:1526667077181};\\\", \\\"{x:1618,y:896,t:1526667077199};\\\", \\\"{x:1614,y:920,t:1526667077214};\\\", \\\"{x:1614,y:930,t:1526667077231};\\\", \\\"{x:1614,y:940,t:1526667077248};\\\", \\\"{x:1614,y:945,t:1526667077264};\\\", \\\"{x:1613,y:947,t:1526667077281};\\\", \\\"{x:1612,y:947,t:1526667077371};\\\", \\\"{x:1610,y:945,t:1526667077381};\\\", \\\"{x:1606,y:937,t:1526667077398};\\\", \\\"{x:1603,y:931,t:1526667077414};\\\", \\\"{x:1597,y:922,t:1526667077430};\\\", \\\"{x:1586,y:907,t:1526667077448};\\\", \\\"{x:1570,y:889,t:1526667077464};\\\", \\\"{x:1550,y:868,t:1526667077481};\\\", \\\"{x:1538,y:853,t:1526667077498};\\\", \\\"{x:1532,y:848,t:1526667077514};\\\", \\\"{x:1530,y:847,t:1526667077531};\\\", \\\"{x:1529,y:846,t:1526667077579};\\\", \\\"{x:1531,y:839,t:1526667077587};\\\", \\\"{x:1536,y:832,t:1526667077598};\\\", \\\"{x:1555,y:806,t:1526667077615};\\\", \\\"{x:1596,y:772,t:1526667077631};\\\", \\\"{x:1636,y:743,t:1526667077648};\\\", \\\"{x:1673,y:719,t:1526667077666};\\\", \\\"{x:1728,y:687,t:1526667077681};\\\", \\\"{x:1785,y:636,t:1526667077698};\\\", \\\"{x:1809,y:608,t:1526667077714};\\\", \\\"{x:1821,y:590,t:1526667077731};\\\", \\\"{x:1828,y:566,t:1526667077749};\\\", \\\"{x:1832,y:538,t:1526667077765};\\\", \\\"{x:1826,y:507,t:1526667077781};\\\", \\\"{x:1811,y:475,t:1526667077799};\\\", \\\"{x:1776,y:434,t:1526667077816};\\\", \\\"{x:1751,y:410,t:1526667077832};\\\", \\\"{x:1734,y:398,t:1526667077848};\\\", \\\"{x:1705,y:388,t:1526667077865};\\\", \\\"{x:1683,y:381,t:1526667077881};\\\", \\\"{x:1666,y:380,t:1526667077898};\\\", \\\"{x:1652,y:380,t:1526667077915};\\\", \\\"{x:1648,y:381,t:1526667077931};\\\", \\\"{x:1645,y:386,t:1526667077949};\\\", \\\"{x:1645,y:399,t:1526667077965};\\\", \\\"{x:1645,y:414,t:1526667077983};\\\", \\\"{x:1648,y:433,t:1526667077998};\\\", \\\"{x:1648,y:441,t:1526667078015};\\\", \\\"{x:1649,y:445,t:1526667078032};\\\", \\\"{x:1650,y:447,t:1526667078048};\\\", \\\"{x:1649,y:447,t:1526667078116};\\\", \\\"{x:1644,y:446,t:1526667078133};\\\", \\\"{x:1639,y:443,t:1526667078149};\\\", \\\"{x:1631,y:442,t:1526667078166};\\\", \\\"{x:1626,y:439,t:1526667078182};\\\", \\\"{x:1625,y:438,t:1526667078199};\\\", \\\"{x:1624,y:438,t:1526667078291};\\\", \\\"{x:1623,y:438,t:1526667078331};\\\", \\\"{x:1621,y:435,t:1526667078349};\\\", \\\"{x:1617,y:434,t:1526667078366};\\\", \\\"{x:1616,y:432,t:1526667078382};\\\", \\\"{x:1614,y:432,t:1526667078398};\\\", \\\"{x:1613,y:430,t:1526667078415};\\\", \\\"{x:1612,y:430,t:1526667078433};\\\", \\\"{x:1612,y:433,t:1526667079211};\\\", \\\"{x:1614,y:440,t:1526667079220};\\\", \\\"{x:1614,y:444,t:1526667079232};\\\", \\\"{x:1615,y:455,t:1526667079250};\\\", \\\"{x:1618,y:468,t:1526667079267};\\\", \\\"{x:1621,y:477,t:1526667079283};\\\", \\\"{x:1621,y:485,t:1526667079300};\\\", \\\"{x:1622,y:491,t:1526667079317};\\\", \\\"{x:1622,y:499,t:1526667079334};\\\", \\\"{x:1622,y:504,t:1526667079350};\\\", \\\"{x:1622,y:510,t:1526667079367};\\\", \\\"{x:1621,y:517,t:1526667079384};\\\", \\\"{x:1619,y:525,t:1526667079399};\\\", \\\"{x:1617,y:531,t:1526667079417};\\\", \\\"{x:1617,y:538,t:1526667079434};\\\", \\\"{x:1617,y:547,t:1526667079449};\\\", \\\"{x:1617,y:552,t:1526667079467};\\\", \\\"{x:1617,y:554,t:1526667079483};\\\", \\\"{x:1617,y:562,t:1526667079499};\\\", \\\"{x:1617,y:575,t:1526667079516};\\\", \\\"{x:1617,y:580,t:1526667079533};\\\", \\\"{x:1617,y:588,t:1526667079549};\\\", \\\"{x:1616,y:592,t:1526667079566};\\\", \\\"{x:1611,y:596,t:1526667079582};\\\", \\\"{x:1611,y:599,t:1526667079599};\\\", \\\"{x:1611,y:604,t:1526667079616};\\\", \\\"{x:1611,y:605,t:1526667079633};\\\", \\\"{x:1611,y:610,t:1526667079649};\\\", \\\"{x:1611,y:619,t:1526667079666};\\\", \\\"{x:1611,y:625,t:1526667079683};\\\", \\\"{x:1611,y:630,t:1526667079700};\\\", \\\"{x:1611,y:637,t:1526667079716};\\\", \\\"{x:1612,y:646,t:1526667079733};\\\", \\\"{x:1613,y:650,t:1526667079750};\\\", \\\"{x:1614,y:652,t:1526667079766};\\\", \\\"{x:1614,y:656,t:1526667079783};\\\", \\\"{x:1615,y:661,t:1526667079800};\\\", \\\"{x:1615,y:667,t:1526667079816};\\\", \\\"{x:1615,y:673,t:1526667079833};\\\", \\\"{x:1615,y:686,t:1526667079850};\\\", \\\"{x:1615,y:689,t:1526667079866};\\\", \\\"{x:1615,y:692,t:1526667079883};\\\", \\\"{x:1615,y:693,t:1526667079900};\\\", \\\"{x:1615,y:695,t:1526667079916};\\\", \\\"{x:1615,y:698,t:1526667079933};\\\", \\\"{x:1615,y:702,t:1526667079950};\\\", \\\"{x:1614,y:707,t:1526667079965};\\\", \\\"{x:1614,y:713,t:1526667079983};\\\", \\\"{x:1613,y:717,t:1526667080000};\\\", \\\"{x:1611,y:722,t:1526667080016};\\\", \\\"{x:1609,y:728,t:1526667080033};\\\", \\\"{x:1606,y:735,t:1526667080050};\\\", \\\"{x:1605,y:739,t:1526667080066};\\\", \\\"{x:1605,y:743,t:1526667080083};\\\", \\\"{x:1605,y:747,t:1526667080100};\\\", \\\"{x:1603,y:753,t:1526667080116};\\\", \\\"{x:1603,y:758,t:1526667080132};\\\", \\\"{x:1603,y:762,t:1526667080150};\\\", \\\"{x:1603,y:766,t:1526667080167};\\\", \\\"{x:1603,y:771,t:1526667080183};\\\", \\\"{x:1603,y:777,t:1526667080200};\\\", \\\"{x:1605,y:780,t:1526667080217};\\\", \\\"{x:1607,y:786,t:1526667080233};\\\", \\\"{x:1609,y:793,t:1526667080250};\\\", \\\"{x:1611,y:798,t:1526667080266};\\\", \\\"{x:1613,y:802,t:1526667080283};\\\", \\\"{x:1614,y:806,t:1526667080300};\\\", \\\"{x:1615,y:810,t:1526667080317};\\\", \\\"{x:1615,y:814,t:1526667080333};\\\", \\\"{x:1616,y:818,t:1526667080350};\\\", \\\"{x:1616,y:822,t:1526667080367};\\\", \\\"{x:1616,y:823,t:1526667080383};\\\", \\\"{x:1616,y:826,t:1526667080400};\\\", \\\"{x:1616,y:829,t:1526667080417};\\\", \\\"{x:1616,y:833,t:1526667080434};\\\", \\\"{x:1615,y:839,t:1526667080451};\\\", \\\"{x:1611,y:844,t:1526667080467};\\\", \\\"{x:1607,y:851,t:1526667080483};\\\", \\\"{x:1605,y:861,t:1526667080500};\\\", \\\"{x:1605,y:869,t:1526667080517};\\\", \\\"{x:1603,y:878,t:1526667080533};\\\", \\\"{x:1603,y:886,t:1526667080550};\\\", \\\"{x:1601,y:893,t:1526667080567};\\\", \\\"{x:1601,y:898,t:1526667080584};\\\", \\\"{x:1601,y:904,t:1526667080600};\\\", \\\"{x:1601,y:910,t:1526667080617};\\\", \\\"{x:1600,y:919,t:1526667080634};\\\", \\\"{x:1598,y:925,t:1526667080651};\\\", \\\"{x:1597,y:930,t:1526667080667};\\\", \\\"{x:1595,y:939,t:1526667080684};\\\", \\\"{x:1594,y:947,t:1526667080701};\\\", \\\"{x:1593,y:954,t:1526667080717};\\\", \\\"{x:1592,y:958,t:1526667080734};\\\", \\\"{x:1591,y:967,t:1526667080750};\\\", \\\"{x:1591,y:970,t:1526667080767};\\\", \\\"{x:1591,y:972,t:1526667080784};\\\", \\\"{x:1591,y:973,t:1526667080800};\\\", \\\"{x:1591,y:976,t:1526667080817};\\\", \\\"{x:1592,y:978,t:1526667080834};\\\", \\\"{x:1595,y:981,t:1526667080850};\\\", \\\"{x:1598,y:983,t:1526667080867};\\\", \\\"{x:1608,y:985,t:1526667080884};\\\", \\\"{x:1613,y:985,t:1526667080900};\\\", \\\"{x:1620,y:986,t:1526667080917};\\\", \\\"{x:1628,y:987,t:1526667080934};\\\", \\\"{x:1635,y:987,t:1526667080950};\\\", \\\"{x:1639,y:987,t:1526667080968};\\\", \\\"{x:1638,y:986,t:1526667081140};\\\", \\\"{x:1635,y:986,t:1526667081151};\\\", \\\"{x:1632,y:985,t:1526667081167};\\\", \\\"{x:1630,y:985,t:1526667081185};\\\", \\\"{x:1627,y:983,t:1526667081202};\\\", \\\"{x:1624,y:982,t:1526667081218};\\\", \\\"{x:1623,y:982,t:1526667081291};\\\", \\\"{x:1620,y:981,t:1526667081307};\\\", \\\"{x:1619,y:980,t:1526667081317};\\\", \\\"{x:1616,y:978,t:1526667081335};\\\", \\\"{x:1614,y:978,t:1526667081352};\\\", \\\"{x:1613,y:978,t:1526667081396};\\\", \\\"{x:1612,y:977,t:1526667081411};\\\", \\\"{x:1611,y:976,t:1526667081419};\\\", \\\"{x:1610,y:976,t:1526667081442};\\\", \\\"{x:1609,y:974,t:1526667081556};\\\", \\\"{x:1609,y:973,t:1526667081603};\\\", \\\"{x:1609,y:971,t:1526667081772};\\\", \\\"{x:1610,y:971,t:1526667081785};\\\", \\\"{x:1612,y:968,t:1526667081802};\\\", \\\"{x:1616,y:963,t:1526667081818};\\\", \\\"{x:1617,y:962,t:1526667081834};\\\", \\\"{x:1618,y:961,t:1526667081851};\\\", \\\"{x:1618,y:952,t:1526667081868};\\\", \\\"{x:1608,y:937,t:1526667081885};\\\", \\\"{x:1593,y:913,t:1526667081901};\\\", \\\"{x:1557,y:876,t:1526667081918};\\\", \\\"{x:1488,y:831,t:1526667081935};\\\", \\\"{x:1414,y:790,t:1526667081951};\\\", \\\"{x:1311,y:741,t:1526667081969};\\\", \\\"{x:1213,y:707,t:1526667081985};\\\", \\\"{x:1141,y:683,t:1526667082001};\\\", \\\"{x:1073,y:662,t:1526667082018};\\\", \\\"{x:1058,y:651,t:1526667082035};\\\", \\\"{x:1042,y:645,t:1526667082051};\\\", \\\"{x:1028,y:639,t:1526667082068};\\\", \\\"{x:1012,y:629,t:1526667082085};\\\", \\\"{x:997,y:619,t:1526667082101};\\\", \\\"{x:963,y:597,t:1526667082118};\\\", \\\"{x:919,y:581,t:1526667082135};\\\", \\\"{x:860,y:563,t:1526667082152};\\\", \\\"{x:770,y:534,t:1526667082169};\\\", \\\"{x:676,y:506,t:1526667082186};\\\", \\\"{x:612,y:496,t:1526667082202};\\\", \\\"{x:559,y:486,t:1526667082218};\\\", \\\"{x:539,y:484,t:1526667082235};\\\", \\\"{x:519,y:484,t:1526667082252};\\\", \\\"{x:493,y:486,t:1526667082268};\\\", \\\"{x:475,y:494,t:1526667082285};\\\", \\\"{x:459,y:506,t:1526667082303};\\\", \\\"{x:442,y:527,t:1526667082318};\\\", \\\"{x:423,y:549,t:1526667082336};\\\", \\\"{x:419,y:552,t:1526667082352};\\\", \\\"{x:410,y:562,t:1526667082368};\\\", \\\"{x:393,y:572,t:1526667082385};\\\", \\\"{x:378,y:580,t:1526667082403};\\\", \\\"{x:368,y:580,t:1526667082419};\\\", \\\"{x:343,y:580,t:1526667082435};\\\", \\\"{x:296,y:566,t:1526667082452};\\\", \\\"{x:244,y:555,t:1526667082468};\\\", \\\"{x:214,y:549,t:1526667082485};\\\", \\\"{x:191,y:549,t:1526667082502};\\\", \\\"{x:171,y:549,t:1526667082519};\\\", \\\"{x:164,y:552,t:1526667082536};\\\", \\\"{x:161,y:555,t:1526667082552};\\\", \\\"{x:160,y:557,t:1526667082569};\\\", \\\"{x:159,y:561,t:1526667082584};\\\", \\\"{x:156,y:573,t:1526667082602};\\\", \\\"{x:151,y:580,t:1526667082619};\\\", \\\"{x:143,y:595,t:1526667082636};\\\", \\\"{x:138,y:605,t:1526667082652};\\\", \\\"{x:138,y:618,t:1526667082670};\\\", \\\"{x:135,y:628,t:1526667082685};\\\", \\\"{x:135,y:632,t:1526667082702};\\\", \\\"{x:134,y:637,t:1526667082719};\\\", \\\"{x:133,y:641,t:1526667082735};\\\", \\\"{x:133,y:646,t:1526667082752};\\\", \\\"{x:133,y:655,t:1526667082770};\\\", \\\"{x:135,y:658,t:1526667082785};\\\", \\\"{x:140,y:662,t:1526667082802};\\\", \\\"{x:145,y:664,t:1526667082819};\\\", \\\"{x:147,y:665,t:1526667082835};\\\", \\\"{x:148,y:665,t:1526667082852};\\\", \\\"{x:150,y:665,t:1526667082931};\\\", \\\"{x:150,y:663,t:1526667082939};\\\", \\\"{x:150,y:662,t:1526667082952};\\\", \\\"{x:151,y:659,t:1526667082969};\\\", \\\"{x:152,y:659,t:1526667082985};\\\", \\\"{x:152,y:658,t:1526667083002};\\\", \\\"{x:152,y:656,t:1526667083018};\\\", \\\"{x:152,y:655,t:1526667083035};\\\", \\\"{x:152,y:653,t:1526667083052};\\\", \\\"{x:152,y:650,t:1526667083069};\\\", \\\"{x:152,y:647,t:1526667083085};\\\", \\\"{x:152,y:644,t:1526667083103};\\\", \\\"{x:152,y:640,t:1526667083119};\\\", \\\"{x:152,y:636,t:1526667083136};\\\", \\\"{x:152,y:635,t:1526667083152};\\\", \\\"{x:152,y:632,t:1526667083169};\\\", \\\"{x:152,y:631,t:1526667083194};\\\", \\\"{x:151,y:630,t:1526667083202};\\\", \\\"{x:152,y:630,t:1526667083683};\\\", \\\"{x:153,y:630,t:1526667083691};\\\", \\\"{x:157,y:630,t:1526667083703};\\\", \\\"{x:171,y:630,t:1526667083720};\\\", \\\"{x:193,y:630,t:1526667083737};\\\", \\\"{x:218,y:630,t:1526667083753};\\\", \\\"{x:243,y:630,t:1526667083769};\\\", \\\"{x:296,y:632,t:1526667083787};\\\", \\\"{x:325,y:635,t:1526667083803};\\\", \\\"{x:377,y:643,t:1526667083819};\\\", \\\"{x:418,y:647,t:1526667083836};\\\", \\\"{x:461,y:650,t:1526667083853};\\\", \\\"{x:489,y:650,t:1526667083869};\\\", \\\"{x:516,y:650,t:1526667083887};\\\", \\\"{x:536,y:653,t:1526667083904};\\\", \\\"{x:552,y:656,t:1526667083919};\\\", \\\"{x:569,y:658,t:1526667083936};\\\", \\\"{x:586,y:661,t:1526667083953};\\\", \\\"{x:604,y:663,t:1526667083969};\\\", \\\"{x:620,y:671,t:1526667083986};\\\", \\\"{x:640,y:677,t:1526667084003};\\\", \\\"{x:657,y:682,t:1526667084020};\\\", \\\"{x:667,y:686,t:1526667084036};\\\", \\\"{x:675,y:690,t:1526667084053};\\\", \\\"{x:675,y:691,t:1526667084069};\\\", \\\"{x:676,y:693,t:1526667084147};\\\", \\\"{x:673,y:700,t:1526667084155};\\\", \\\"{x:668,y:705,t:1526667084170};\\\", \\\"{x:661,y:714,t:1526667084187};\\\", \\\"{x:657,y:715,t:1526667084202};\\\", \\\"{x:651,y:718,t:1526667084219};\\\", \\\"{x:639,y:718,t:1526667084236};\\\", \\\"{x:636,y:718,t:1526667084253};\\\", \\\"{x:622,y:718,t:1526667084269};\\\", \\\"{x:599,y:716,t:1526667084286};\\\", \\\"{x:584,y:711,t:1526667084303};\\\", \\\"{x:565,y:704,t:1526667084319};\\\", \\\"{x:553,y:704,t:1526667084337};\\\", \\\"{x:550,y:701,t:1526667084352};\\\", \\\"{x:548,y:701,t:1526667084370};\\\", \\\"{x:547,y:701,t:1526667084387};\\\", \\\"{x:546,y:701,t:1526667084410};\\\", \\\"{x:546,y:702,t:1526667084531};\\\", \\\"{x:546,y:703,t:1526667084546};\\\", \\\"{x:545,y:704,t:1526667084570};\\\", \\\"{x:544,y:705,t:1526667084588};\\\", \\\"{x:546,y:704,t:1526667085139};\\\", \\\"{x:553,y:701,t:1526667085155};\\\", \\\"{x:555,y:700,t:1526667085170};\\\", \\\"{x:560,y:699,t:1526667085188};\\\", \\\"{x:568,y:698,t:1526667085204};\\\", \\\"{x:576,y:695,t:1526667085221};\\\", \\\"{x:583,y:692,t:1526667085237};\\\", \\\"{x:601,y:691,t:1526667085254};\\\", \\\"{x:613,y:684,t:1526667085271};\\\", \\\"{x:629,y:679,t:1526667085287};\\\", \\\"{x:650,y:674,t:1526667085304};\\\", \\\"{x:678,y:674,t:1526667085321};\\\", \\\"{x:707,y:674,t:1526667085337};\\\", \\\"{x:733,y:674,t:1526667085354};\\\", \\\"{x:753,y:674,t:1526667085371};\\\", \\\"{x:772,y:674,t:1526667085387};\\\", \\\"{x:782,y:674,t:1526667085404};\\\", \\\"{x:791,y:676,t:1526667085422};\\\", \\\"{x:808,y:677,t:1526667085437};\\\", \\\"{x:820,y:678,t:1526667085454};\\\", \\\"{x:829,y:680,t:1526667085471};\\\", \\\"{x:841,y:681,t:1526667085488};\\\", \\\"{x:859,y:681,t:1526667085504};\\\", \\\"{x:882,y:681,t:1526667085521};\\\", \\\"{x:910,y:681,t:1526667085538};\\\", \\\"{x:937,y:680,t:1526667085554};\\\", \\\"{x:958,y:679,t:1526667085571};\\\", \\\"{x:985,y:679,t:1526667085587};\\\", \\\"{x:1007,y:680,t:1526667085604};\\\", \\\"{x:1018,y:680,t:1526667085622};\\\", \\\"{x:1019,y:680,t:1526667085637};\\\", \\\"{x:1022,y:680,t:1526667085655};\\\" ] }, { \\\"rt\\\": 20703, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 216809, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"HWJDK\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"men\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"diagonal\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -C -10 AM-11 AM-11 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:998,y:671,t:1526667086037};\\\", \\\"{x:987,y:668,t:1526667086054};\\\", \\\"{x:979,y:665,t:1526667086071};\\\", \\\"{x:976,y:665,t:1526667086088};\\\", \\\"{x:970,y:667,t:1526667086634};\\\", \\\"{x:964,y:674,t:1526667086643};\\\", \\\"{x:954,y:685,t:1526667086655};\\\", \\\"{x:932,y:715,t:1526667086672};\\\", \\\"{x:911,y:735,t:1526667086687};\\\", \\\"{x:898,y:751,t:1526667086705};\\\", \\\"{x:892,y:758,t:1526667086722};\\\", \\\"{x:896,y:758,t:1526667089428};\\\", \\\"{x:937,y:758,t:1526667089441};\\\", \\\"{x:1034,y:758,t:1526667089459};\\\", \\\"{x:1130,y:760,t:1526667089474};\\\", \\\"{x:1174,y:760,t:1526667089492};\\\", \\\"{x:1203,y:760,t:1526667089508};\\\", \\\"{x:1229,y:766,t:1526667089525};\\\", \\\"{x:1238,y:767,t:1526667089542};\\\", \\\"{x:1240,y:769,t:1526667089558};\\\", \\\"{x:1240,y:771,t:1526667089587};\\\", \\\"{x:1239,y:774,t:1526667089596};\\\", \\\"{x:1238,y:775,t:1526667089607};\\\", \\\"{x:1234,y:779,t:1526667089624};\\\", \\\"{x:1225,y:788,t:1526667089641};\\\", \\\"{x:1213,y:803,t:1526667089658};\\\", \\\"{x:1191,y:830,t:1526667089675};\\\", \\\"{x:1184,y:846,t:1526667089691};\\\", \\\"{x:1180,y:853,t:1526667089707};\\\", \\\"{x:1180,y:854,t:1526667089724};\\\", \\\"{x:1180,y:856,t:1526667089786};\\\", \\\"{x:1185,y:858,t:1526667089795};\\\", \\\"{x:1188,y:859,t:1526667089808};\\\", \\\"{x:1200,y:860,t:1526667089824};\\\", \\\"{x:1210,y:860,t:1526667089842};\\\", \\\"{x:1221,y:860,t:1526667089858};\\\", \\\"{x:1227,y:860,t:1526667089874};\\\", \\\"{x:1227,y:859,t:1526667089948};\\\", \\\"{x:1226,y:859,t:1526667089958};\\\", \\\"{x:1225,y:858,t:1526667089975};\\\", \\\"{x:1223,y:857,t:1526667089992};\\\", \\\"{x:1219,y:854,t:1526667090009};\\\", \\\"{x:1214,y:850,t:1526667090024};\\\", \\\"{x:1212,y:849,t:1526667090042};\\\", \\\"{x:1212,y:848,t:1526667090083};\\\", \\\"{x:1211,y:848,t:1526667090098};\\\", \\\"{x:1211,y:847,t:1526667090123};\\\", \\\"{x:1211,y:845,t:1526667090155};\\\", \\\"{x:1210,y:844,t:1526667090179};\\\", \\\"{x:1209,y:843,t:1526667090192};\\\", \\\"{x:1209,y:840,t:1526667090209};\\\", \\\"{x:1207,y:838,t:1526667090226};\\\", \\\"{x:1207,y:837,t:1526667090242};\\\", \\\"{x:1206,y:836,t:1526667090259};\\\", \\\"{x:1206,y:835,t:1526667090418};\\\", \\\"{x:1207,y:832,t:1526667090425};\\\", \\\"{x:1207,y:830,t:1526667090441};\\\", \\\"{x:1211,y:821,t:1526667090458};\\\", \\\"{x:1212,y:820,t:1526667090476};\\\", \\\"{x:1213,y:820,t:1526667090587};\\\", \\\"{x:1213,y:826,t:1526667090597};\\\", \\\"{x:1213,y:835,t:1526667090608};\\\", \\\"{x:1213,y:848,t:1526667090625};\\\", \\\"{x:1212,y:865,t:1526667090642};\\\", \\\"{x:1208,y:884,t:1526667090658};\\\", \\\"{x:1204,y:890,t:1526667090676};\\\", \\\"{x:1204,y:897,t:1526667090692};\\\", \\\"{x:1204,y:906,t:1526667090708};\\\", \\\"{x:1205,y:913,t:1526667090726};\\\", \\\"{x:1205,y:919,t:1526667090742};\\\", \\\"{x:1205,y:921,t:1526667090758};\\\", \\\"{x:1205,y:923,t:1526667090775};\\\", \\\"{x:1205,y:926,t:1526667090793};\\\", \\\"{x:1205,y:929,t:1526667090809};\\\", \\\"{x:1206,y:934,t:1526667090825};\\\", \\\"{x:1207,y:942,t:1526667090842};\\\", \\\"{x:1207,y:946,t:1526667090858};\\\", \\\"{x:1207,y:949,t:1526667090876};\\\", \\\"{x:1207,y:951,t:1526667090899};\\\", \\\"{x:1207,y:952,t:1526667090914};\\\", \\\"{x:1206,y:954,t:1526667090930};\\\", \\\"{x:1206,y:955,t:1526667090962};\\\", \\\"{x:1206,y:957,t:1526667090978};\\\", \\\"{x:1205,y:958,t:1526667090992};\\\", \\\"{x:1204,y:960,t:1526667091026};\\\", \\\"{x:1204,y:961,t:1526667091058};\\\", \\\"{x:1204,y:962,t:1526667091075};\\\", \\\"{x:1204,y:963,t:1526667091093};\\\", \\\"{x:1204,y:964,t:1526667091109};\\\", \\\"{x:1204,y:966,t:1526667091171};\\\", \\\"{x:1204,y:967,t:1526667091178};\\\", \\\"{x:1204,y:968,t:1526667091193};\\\", \\\"{x:1205,y:968,t:1526667091209};\\\", \\\"{x:1205,y:969,t:1526667091226};\\\", \\\"{x:1206,y:969,t:1526667091243};\\\", \\\"{x:1208,y:970,t:1526667091282};\\\", \\\"{x:1211,y:970,t:1526667091571};\\\", \\\"{x:1212,y:969,t:1526667091579};\\\", \\\"{x:1214,y:967,t:1526667091594};\\\", \\\"{x:1218,y:964,t:1526667091611};\\\", \\\"{x:1220,y:962,t:1526667091627};\\\", \\\"{x:1224,y:962,t:1526667093308};\\\", \\\"{x:1226,y:962,t:1526667093315};\\\", \\\"{x:1226,y:961,t:1526667093329};\\\", \\\"{x:1237,y:961,t:1526667093344};\\\", \\\"{x:1245,y:961,t:1526667093361};\\\", \\\"{x:1253,y:961,t:1526667093378};\\\", \\\"{x:1265,y:961,t:1526667093395};\\\", \\\"{x:1273,y:961,t:1526667093411};\\\", \\\"{x:1281,y:961,t:1526667093428};\\\", \\\"{x:1287,y:961,t:1526667093445};\\\", \\\"{x:1294,y:961,t:1526667093461};\\\", \\\"{x:1301,y:961,t:1526667093478};\\\", \\\"{x:1308,y:962,t:1526667093495};\\\", \\\"{x:1305,y:961,t:1526667093643};\\\", \\\"{x:1301,y:960,t:1526667093651};\\\", \\\"{x:1295,y:960,t:1526667093661};\\\", \\\"{x:1285,y:959,t:1526667093678};\\\", \\\"{x:1277,y:959,t:1526667093695};\\\", \\\"{x:1272,y:957,t:1526667093711};\\\", \\\"{x:1271,y:956,t:1526667093728};\\\", \\\"{x:1270,y:956,t:1526667093843};\\\", \\\"{x:1271,y:956,t:1526667093971};\\\", \\\"{x:1272,y:957,t:1526667093978};\\\", \\\"{x:1278,y:958,t:1526667093996};\\\", \\\"{x:1281,y:959,t:1526667094013};\\\", \\\"{x:1282,y:959,t:1526667094028};\\\", \\\"{x:1283,y:959,t:1526667094045};\\\", \\\"{x:1284,y:959,t:1526667094147};\\\", \\\"{x:1284,y:960,t:1526667094162};\\\", \\\"{x:1287,y:961,t:1526667094179};\\\", \\\"{x:1286,y:961,t:1526667094571};\\\", \\\"{x:1280,y:961,t:1526667094578};\\\", \\\"{x:1275,y:961,t:1526667094596};\\\", \\\"{x:1266,y:961,t:1526667094613};\\\", \\\"{x:1262,y:963,t:1526667094629};\\\", \\\"{x:1260,y:964,t:1526667094645};\\\", \\\"{x:1259,y:964,t:1526667094763};\\\", \\\"{x:1259,y:961,t:1526667094956};\\\", \\\"{x:1260,y:955,t:1526667094963};\\\", \\\"{x:1261,y:946,t:1526667094979};\\\", \\\"{x:1264,y:940,t:1526667094996};\\\", \\\"{x:1264,y:939,t:1526667095011};\\\", \\\"{x:1265,y:937,t:1526667095029};\\\", \\\"{x:1267,y:937,t:1526667095045};\\\", \\\"{x:1268,y:937,t:1526667095062};\\\", \\\"{x:1271,y:937,t:1526667095078};\\\", \\\"{x:1276,y:937,t:1526667095095};\\\", \\\"{x:1278,y:937,t:1526667095114};\\\", \\\"{x:1279,y:937,t:1526667095178};\\\", \\\"{x:1280,y:941,t:1526667095196};\\\", \\\"{x:1282,y:950,t:1526667095213};\\\", \\\"{x:1285,y:961,t:1526667095228};\\\", \\\"{x:1288,y:968,t:1526667095246};\\\", \\\"{x:1289,y:971,t:1526667095263};\\\", \\\"{x:1290,y:976,t:1526667095279};\\\", \\\"{x:1290,y:978,t:1526667095295};\\\", \\\"{x:1290,y:980,t:1526667095313};\\\", \\\"{x:1290,y:981,t:1526667095539};\\\", \\\"{x:1289,y:980,t:1526667095548};\\\", \\\"{x:1285,y:973,t:1526667095563};\\\", \\\"{x:1282,y:968,t:1526667095580};\\\", \\\"{x:1281,y:965,t:1526667095595};\\\", \\\"{x:1280,y:963,t:1526667095612};\\\", \\\"{x:1278,y:960,t:1526667095754};\\\", \\\"{x:1276,y:958,t:1526667095763};\\\", \\\"{x:1267,y:944,t:1526667095779};\\\", \\\"{x:1250,y:928,t:1526667095797};\\\", \\\"{x:1221,y:906,t:1526667095813};\\\", \\\"{x:1166,y:877,t:1526667095830};\\\", \\\"{x:1104,y:848,t:1526667095846};\\\", \\\"{x:987,y:810,t:1526667095863};\\\", \\\"{x:866,y:779,t:1526667095879};\\\", \\\"{x:748,y:750,t:1526667095896};\\\", \\\"{x:629,y:718,t:1526667095912};\\\", \\\"{x:461,y:678,t:1526667095930};\\\", \\\"{x:351,y:647,t:1526667095946};\\\", \\\"{x:240,y:616,t:1526667095963};\\\", \\\"{x:195,y:602,t:1526667095980};\\\", \\\"{x:172,y:594,t:1526667096012};\\\", \\\"{x:170,y:594,t:1526667096029};\\\", \\\"{x:168,y:593,t:1526667096047};\\\", \\\"{x:168,y:590,t:1526667096129};\\\", \\\"{x:169,y:574,t:1526667096147};\\\", \\\"{x:177,y:535,t:1526667096163};\\\", \\\"{x:183,y:515,t:1526667096180};\\\", \\\"{x:190,y:501,t:1526667096197};\\\", \\\"{x:202,y:494,t:1526667096213};\\\", \\\"{x:218,y:489,t:1526667096230};\\\", \\\"{x:232,y:489,t:1526667096246};\\\", \\\"{x:248,y:489,t:1526667096264};\\\", \\\"{x:264,y:489,t:1526667096279};\\\", \\\"{x:267,y:489,t:1526667096297};\\\", \\\"{x:279,y:489,t:1526667096313};\\\", \\\"{x:281,y:489,t:1526667096330};\\\", \\\"{x:284,y:489,t:1526667096347};\\\", \\\"{x:285,y:489,t:1526667096363};\\\", \\\"{x:287,y:489,t:1526667096427};\\\", \\\"{x:291,y:492,t:1526667096442};\\\", \\\"{x:296,y:498,t:1526667096450};\\\", \\\"{x:306,y:501,t:1526667096464};\\\", \\\"{x:319,y:513,t:1526667096482};\\\", \\\"{x:340,y:522,t:1526667096497};\\\", \\\"{x:380,y:530,t:1526667096515};\\\", \\\"{x:396,y:533,t:1526667096530};\\\", \\\"{x:398,y:533,t:1526667096546};\\\", \\\"{x:399,y:534,t:1526667096578};\\\", \\\"{x:396,y:534,t:1526667096657};\\\", \\\"{x:394,y:533,t:1526667096665};\\\", \\\"{x:392,y:532,t:1526667096681};\\\", \\\"{x:391,y:532,t:1526667096697};\\\", \\\"{x:394,y:532,t:1526667096859};\\\", \\\"{x:398,y:530,t:1526667096867};\\\", \\\"{x:400,y:529,t:1526667096880};\\\", \\\"{x:404,y:528,t:1526667096896};\\\", \\\"{x:408,y:526,t:1526667096913};\\\", \\\"{x:409,y:525,t:1526667097170};\\\", \\\"{x:407,y:524,t:1526667097187};\\\", \\\"{x:405,y:523,t:1526667097198};\\\", \\\"{x:401,y:522,t:1526667097214};\\\", \\\"{x:398,y:522,t:1526667097231};\\\", \\\"{x:396,y:522,t:1526667097248};\\\", \\\"{x:395,y:522,t:1526667097467};\\\", \\\"{x:393,y:522,t:1526667097482};\\\", \\\"{x:390,y:522,t:1526667097498};\\\", \\\"{x:388,y:522,t:1526667097514};\\\", \\\"{x:387,y:522,t:1526667097619};\\\", \\\"{x:386,y:522,t:1526667105307};\\\", \\\"{x:386,y:525,t:1526667105321};\\\", \\\"{x:387,y:536,t:1526667105338};\\\", \\\"{x:396,y:555,t:1526667105354};\\\", \\\"{x:403,y:563,t:1526667105369};\\\", \\\"{x:408,y:570,t:1526667105387};\\\", \\\"{x:413,y:576,t:1526667105404};\\\", \\\"{x:417,y:580,t:1526667105421};\\\", \\\"{x:423,y:592,t:1526667105437};\\\", \\\"{x:438,y:610,t:1526667105454};\\\", \\\"{x:457,y:643,t:1526667105472};\\\", \\\"{x:471,y:667,t:1526667105487};\\\", \\\"{x:481,y:683,t:1526667105504};\\\", \\\"{x:487,y:693,t:1526667105521};\\\", \\\"{x:490,y:697,t:1526667105537};\\\", \\\"{x:491,y:699,t:1526667105554};\\\", \\\"{x:491,y:700,t:1526667105609};\\\", \\\"{x:491,y:703,t:1526667105627};\\\", \\\"{x:491,y:706,t:1526667105638};\\\", \\\"{x:491,y:712,t:1526667105654};\\\", \\\"{x:493,y:716,t:1526667105670};\\\", \\\"{x:493,y:717,t:1526667105697};\\\" ] }, { \\\"rt\\\": 73800, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 291852, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"HWJDK\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"men\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"diagonal\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-04 PM-04 PM-04 PM-04 PM-04 PM-04 PM-05 PM-04:30-03 PM-02:30-04 PM-04 PM-04 PM-03:30-03 PM-02:30-K -K -K -U -02 PM-02 PM-02 PM-02:30-03 PM-02 PM-H -H -H -02 PM-12:30-12:30\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:496,y:717,t:1526667108962};\\\", \\\"{x:516,y:717,t:1526667108981};\\\", \\\"{x:523,y:717,t:1526667108993};\\\", \\\"{x:558,y:725,t:1526667109010};\\\", \\\"{x:581,y:732,t:1526667109028};\\\", \\\"{x:605,y:738,t:1526667109044};\\\", \\\"{x:620,y:742,t:1526667109057};\\\", \\\"{x:626,y:746,t:1526667109074};\\\", \\\"{x:635,y:746,t:1526667109090};\\\", \\\"{x:641,y:746,t:1526667109107};\\\", \\\"{x:645,y:747,t:1526667109124};\\\", \\\"{x:650,y:749,t:1526667109140};\\\", \\\"{x:656,y:749,t:1526667109157};\\\", \\\"{x:664,y:752,t:1526667109174};\\\", \\\"{x:672,y:753,t:1526667109190};\\\", \\\"{x:688,y:758,t:1526667109207};\\\", \\\"{x:703,y:759,t:1526667109224};\\\", \\\"{x:721,y:760,t:1526667109240};\\\", \\\"{x:734,y:761,t:1526667109257};\\\", \\\"{x:753,y:761,t:1526667109274};\\\", \\\"{x:762,y:763,t:1526667109290};\\\", \\\"{x:768,y:763,t:1526667109307};\\\", \\\"{x:773,y:763,t:1526667109324};\\\", \\\"{x:776,y:763,t:1526667109340};\\\", \\\"{x:780,y:763,t:1526667109357};\\\", \\\"{x:781,y:763,t:1526667109378};\\\", \\\"{x:782,y:763,t:1526667109390};\\\", \\\"{x:783,y:763,t:1526667109407};\\\", \\\"{x:784,y:763,t:1526667110067};\\\", \\\"{x:793,y:764,t:1526667110074};\\\", \\\"{x:823,y:764,t:1526667110091};\\\", \\\"{x:858,y:765,t:1526667110108};\\\", \\\"{x:903,y:769,t:1526667110124};\\\", \\\"{x:981,y:771,t:1526667110142};\\\", \\\"{x:1057,y:768,t:1526667110159};\\\", \\\"{x:1138,y:768,t:1526667110175};\\\", \\\"{x:1188,y:768,t:1526667110192};\\\", \\\"{x:1230,y:768,t:1526667110209};\\\", \\\"{x:1258,y:769,t:1526667110224};\\\", \\\"{x:1294,y:769,t:1526667110242};\\\", \\\"{x:1326,y:769,t:1526667110258};\\\", \\\"{x:1344,y:769,t:1526667110275};\\\", \\\"{x:1364,y:771,t:1526667110292};\\\", \\\"{x:1388,y:774,t:1526667110309};\\\", \\\"{x:1408,y:777,t:1526667110325};\\\", \\\"{x:1430,y:780,t:1526667110342};\\\", \\\"{x:1454,y:785,t:1526667110358};\\\", \\\"{x:1468,y:793,t:1526667110374};\\\", \\\"{x:1485,y:806,t:1526667110391};\\\", \\\"{x:1498,y:824,t:1526667110408};\\\", \\\"{x:1521,y:850,t:1526667110424};\\\", \\\"{x:1542,y:884,t:1526667110441};\\\", \\\"{x:1566,y:915,t:1526667110458};\\\", \\\"{x:1579,y:933,t:1526667110475};\\\", \\\"{x:1594,y:951,t:1526667110491};\\\", \\\"{x:1602,y:964,t:1526667110508};\\\", \\\"{x:1612,y:976,t:1526667110525};\\\", \\\"{x:1619,y:983,t:1526667110542};\\\", \\\"{x:1621,y:987,t:1526667110558};\\\", \\\"{x:1623,y:989,t:1526667110576};\\\", \\\"{x:1624,y:992,t:1526667110591};\\\", \\\"{x:1626,y:994,t:1526667110608};\\\", \\\"{x:1626,y:997,t:1526667110626};\\\", \\\"{x:1627,y:998,t:1526667110641};\\\", \\\"{x:1627,y:1000,t:1526667110715};\\\", \\\"{x:1627,y:1001,t:1526667110725};\\\", \\\"{x:1627,y:1003,t:1526667110741};\\\", \\\"{x:1627,y:1004,t:1526667110875};\\\", \\\"{x:1626,y:1006,t:1526667110892};\\\", \\\"{x:1625,y:1007,t:1526667110914};\\\", \\\"{x:1624,y:1007,t:1526667110954};\\\", \\\"{x:1623,y:1007,t:1526667110962};\\\", \\\"{x:1622,y:1007,t:1526667111019};\\\", \\\"{x:1620,y:1006,t:1526667111026};\\\", \\\"{x:1619,y:1003,t:1526667111042};\\\", \\\"{x:1619,y:1001,t:1526667111058};\\\", \\\"{x:1618,y:996,t:1526667111075};\\\", \\\"{x:1617,y:989,t:1526667111092};\\\", \\\"{x:1616,y:984,t:1526667111108};\\\", \\\"{x:1615,y:979,t:1526667111125};\\\", \\\"{x:1615,y:976,t:1526667111143};\\\", \\\"{x:1615,y:974,t:1526667111159};\\\", \\\"{x:1615,y:973,t:1526667111175};\\\", \\\"{x:1615,y:972,t:1526667111194};\\\", \\\"{x:1615,y:971,t:1526667111209};\\\", \\\"{x:1614,y:972,t:1526667113442};\\\", \\\"{x:1612,y:977,t:1526667113461};\\\", \\\"{x:1611,y:980,t:1526667113478};\\\", \\\"{x:1609,y:982,t:1526667113494};\\\", \\\"{x:1609,y:984,t:1526667113510};\\\", \\\"{x:1610,y:984,t:1526667113891};\\\", \\\"{x:1612,y:982,t:1526667113899};\\\", \\\"{x:1613,y:980,t:1526667113911};\\\", \\\"{x:1615,y:977,t:1526667113928};\\\", \\\"{x:1616,y:975,t:1526667113945};\\\", \\\"{x:1616,y:974,t:1526667114203};\\\", \\\"{x:1616,y:972,t:1526667114442};\\\", \\\"{x:1616,y:971,t:1526667114467};\\\", \\\"{x:1616,y:969,t:1526667114482};\\\", \\\"{x:1618,y:967,t:1526667114495};\\\", \\\"{x:1618,y:965,t:1526667114511};\\\", \\\"{x:1618,y:964,t:1526667114528};\\\", \\\"{x:1618,y:962,t:1526667114545};\\\", \\\"{x:1618,y:961,t:1526667114562};\\\", \\\"{x:1618,y:958,t:1526667114579};\\\", \\\"{x:1618,y:955,t:1526667114594};\\\", \\\"{x:1616,y:952,t:1526667114612};\\\", \\\"{x:1615,y:947,t:1526667114627};\\\", \\\"{x:1614,y:942,t:1526667114644};\\\", \\\"{x:1612,y:935,t:1526667114661};\\\", \\\"{x:1611,y:928,t:1526667114677};\\\", \\\"{x:1611,y:922,t:1526667114695};\\\", \\\"{x:1608,y:918,t:1526667114711};\\\", \\\"{x:1606,y:912,t:1526667114727};\\\", \\\"{x:1603,y:899,t:1526667114744};\\\", \\\"{x:1603,y:894,t:1526667114762};\\\", \\\"{x:1602,y:888,t:1526667114778};\\\", \\\"{x:1602,y:885,t:1526667114794};\\\", \\\"{x:1602,y:888,t:1526667114899};\\\", \\\"{x:1602,y:893,t:1526667114912};\\\", \\\"{x:1602,y:910,t:1526667114929};\\\", \\\"{x:1602,y:921,t:1526667114946};\\\", \\\"{x:1606,y:944,t:1526667114962};\\\", \\\"{x:1611,y:956,t:1526667114979};\\\", \\\"{x:1615,y:963,t:1526667114995};\\\", \\\"{x:1619,y:968,t:1526667115013};\\\", \\\"{x:1619,y:971,t:1526667115029};\\\", \\\"{x:1619,y:972,t:1526667115045};\\\", \\\"{x:1620,y:972,t:1526667115267};\\\", \\\"{x:1620,y:973,t:1526667115290};\\\", \\\"{x:1620,y:975,t:1526667115811};\\\", \\\"{x:1620,y:976,t:1526667115818};\\\", \\\"{x:1620,y:978,t:1526667115850};\\\", \\\"{x:1619,y:979,t:1526667115863};\\\", \\\"{x:1619,y:980,t:1526667115890};\\\", \\\"{x:1619,y:982,t:1526667116371};\\\", \\\"{x:1619,y:983,t:1526667116380};\\\", \\\"{x:1619,y:985,t:1526667116396};\\\", \\\"{x:1618,y:986,t:1526667116413};\\\", \\\"{x:1618,y:988,t:1526667116434};\\\", \\\"{x:1616,y:988,t:1526667116651};\\\", \\\"{x:1615,y:988,t:1526667116819};\\\", \\\"{x:1614,y:987,t:1526667116834};\\\", \\\"{x:1614,y:986,t:1526667116847};\\\", \\\"{x:1614,y:982,t:1526667116863};\\\", \\\"{x:1614,y:981,t:1526667116880};\\\", \\\"{x:1614,y:979,t:1526667116897};\\\", \\\"{x:1613,y:977,t:1526667116913};\\\", \\\"{x:1612,y:975,t:1526667116930};\\\", \\\"{x:1612,y:974,t:1526667116971};\\\", \\\"{x:1612,y:973,t:1526667116980};\\\", \\\"{x:1612,y:972,t:1526667116996};\\\", \\\"{x:1612,y:969,t:1526667117012};\\\", \\\"{x:1612,y:966,t:1526667117029};\\\", \\\"{x:1612,y:962,t:1526667117046};\\\", \\\"{x:1612,y:959,t:1526667117063};\\\", \\\"{x:1611,y:955,t:1526667117079};\\\", \\\"{x:1611,y:951,t:1526667117097};\\\", \\\"{x:1611,y:947,t:1526667117113};\\\", \\\"{x:1611,y:937,t:1526667117130};\\\", \\\"{x:1611,y:932,t:1526667117147};\\\", \\\"{x:1613,y:924,t:1526667117162};\\\", \\\"{x:1614,y:917,t:1526667117180};\\\", \\\"{x:1614,y:911,t:1526667117197};\\\", \\\"{x:1616,y:903,t:1526667117214};\\\", \\\"{x:1617,y:894,t:1526667117229};\\\", \\\"{x:1619,y:878,t:1526667117246};\\\", \\\"{x:1619,y:871,t:1526667117264};\\\", \\\"{x:1622,y:863,t:1526667117279};\\\", \\\"{x:1622,y:860,t:1526667117296};\\\", \\\"{x:1623,y:854,t:1526667117314};\\\", \\\"{x:1625,y:848,t:1526667117330};\\\", \\\"{x:1625,y:844,t:1526667117347};\\\", \\\"{x:1625,y:836,t:1526667117364};\\\", \\\"{x:1626,y:827,t:1526667117379};\\\", \\\"{x:1626,y:824,t:1526667117397};\\\", \\\"{x:1626,y:821,t:1526667117413};\\\", \\\"{x:1626,y:817,t:1526667117430};\\\", \\\"{x:1625,y:811,t:1526667117447};\\\", \\\"{x:1622,y:803,t:1526667117463};\\\", \\\"{x:1621,y:797,t:1526667117480};\\\", \\\"{x:1617,y:790,t:1526667117497};\\\", \\\"{x:1612,y:777,t:1526667117514};\\\", \\\"{x:1611,y:768,t:1526667117529};\\\", \\\"{x:1608,y:758,t:1526667117546};\\\", \\\"{x:1606,y:748,t:1526667117564};\\\", \\\"{x:1603,y:737,t:1526667117580};\\\", \\\"{x:1603,y:726,t:1526667117596};\\\", \\\"{x:1603,y:714,t:1526667117614};\\\", \\\"{x:1603,y:699,t:1526667117629};\\\", \\\"{x:1606,y:683,t:1526667117646};\\\", \\\"{x:1611,y:667,t:1526667117664};\\\", \\\"{x:1617,y:651,t:1526667117681};\\\", \\\"{x:1621,y:640,t:1526667117696};\\\", \\\"{x:1625,y:626,t:1526667117714};\\\", \\\"{x:1629,y:618,t:1526667117730};\\\", \\\"{x:1629,y:614,t:1526667117746};\\\", \\\"{x:1629,y:606,t:1526667117764};\\\", \\\"{x:1630,y:599,t:1526667117783};\\\", \\\"{x:1630,y:593,t:1526667117797};\\\", \\\"{x:1630,y:580,t:1526667117814};\\\", \\\"{x:1630,y:570,t:1526667117830};\\\", \\\"{x:1630,y:564,t:1526667117847};\\\", \\\"{x:1629,y:554,t:1526667117863};\\\", \\\"{x:1624,y:539,t:1526667117880};\\\", \\\"{x:1621,y:526,t:1526667117896};\\\", \\\"{x:1614,y:508,t:1526667117913};\\\", \\\"{x:1613,y:501,t:1526667117931};\\\", \\\"{x:1612,y:493,t:1526667117946};\\\", \\\"{x:1610,y:487,t:1526667117964};\\\", \\\"{x:1610,y:481,t:1526667117981};\\\", \\\"{x:1610,y:471,t:1526667117997};\\\", \\\"{x:1609,y:466,t:1526667118013};\\\", \\\"{x:1608,y:462,t:1526667118031};\\\", \\\"{x:1608,y:460,t:1526667118047};\\\", \\\"{x:1608,y:457,t:1526667118063};\\\", \\\"{x:1608,y:454,t:1526667118080};\\\", \\\"{x:1609,y:450,t:1526667118097};\\\", \\\"{x:1609,y:445,t:1526667118114};\\\", \\\"{x:1609,y:443,t:1526667118131};\\\", \\\"{x:1609,y:440,t:1526667118146};\\\", \\\"{x:1609,y:438,t:1526667118163};\\\", \\\"{x:1609,y:437,t:1526667118182};\\\", \\\"{x:1608,y:436,t:1526667118202};\\\", \\\"{x:1607,y:436,t:1526667118218};\\\", \\\"{x:1605,y:436,t:1526667118230};\\\", \\\"{x:1599,y:436,t:1526667118248};\\\", \\\"{x:1591,y:440,t:1526667118263};\\\", \\\"{x:1582,y:443,t:1526667118280};\\\", \\\"{x:1565,y:451,t:1526667118297};\\\", \\\"{x:1544,y:459,t:1526667118313};\\\", \\\"{x:1524,y:469,t:1526667118330};\\\", \\\"{x:1494,y:478,t:1526667118347};\\\", \\\"{x:1473,y:490,t:1526667118364};\\\", \\\"{x:1439,y:502,t:1526667118380};\\\", \\\"{x:1410,y:514,t:1526667118398};\\\", \\\"{x:1370,y:521,t:1526667118413};\\\", \\\"{x:1306,y:529,t:1526667118430};\\\", \\\"{x:1252,y:534,t:1526667118448};\\\", \\\"{x:1196,y:534,t:1526667118464};\\\", \\\"{x:1152,y:537,t:1526667118481};\\\", \\\"{x:1082,y:544,t:1526667118498};\\\", \\\"{x:1046,y:556,t:1526667118514};\\\", \\\"{x:1011,y:568,t:1526667118531};\\\", \\\"{x:977,y:579,t:1526667118548};\\\", \\\"{x:952,y:588,t:1526667118563};\\\", \\\"{x:921,y:606,t:1526667118581};\\\", \\\"{x:903,y:616,t:1526667118598};\\\", \\\"{x:885,y:622,t:1526667118614};\\\", \\\"{x:870,y:628,t:1526667118631};\\\", \\\"{x:849,y:632,t:1526667118648};\\\", \\\"{x:831,y:635,t:1526667118664};\\\", \\\"{x:804,y:637,t:1526667118681};\\\", \\\"{x:780,y:635,t:1526667118698};\\\", \\\"{x:755,y:630,t:1526667118714};\\\", \\\"{x:728,y:624,t:1526667118731};\\\", \\\"{x:709,y:618,t:1526667118748};\\\", \\\"{x:681,y:611,t:1526667118766};\\\", \\\"{x:656,y:604,t:1526667118782};\\\", \\\"{x:616,y:591,t:1526667118799};\\\", \\\"{x:579,y:579,t:1526667118815};\\\", \\\"{x:563,y:573,t:1526667118832};\\\", \\\"{x:557,y:568,t:1526667118849};\\\", \\\"{x:533,y:566,t:1526667118866};\\\", \\\"{x:527,y:564,t:1526667118881};\\\", \\\"{x:526,y:564,t:1526667118898};\\\", \\\"{x:525,y:564,t:1526667118915};\\\", \\\"{x:528,y:564,t:1526667118987};\\\", \\\"{x:532,y:564,t:1526667118998};\\\", \\\"{x:542,y:566,t:1526667119015};\\\", \\\"{x:557,y:570,t:1526667119032};\\\", \\\"{x:572,y:571,t:1526667119049};\\\", \\\"{x:598,y:571,t:1526667119066};\\\", \\\"{x:611,y:571,t:1526667119082};\\\", \\\"{x:629,y:571,t:1526667119098};\\\", \\\"{x:645,y:571,t:1526667119115};\\\", \\\"{x:657,y:571,t:1526667119131};\\\", \\\"{x:662,y:570,t:1526667119148};\\\", \\\"{x:663,y:570,t:1526667119165};\\\", \\\"{x:661,y:569,t:1526667119194};\\\", \\\"{x:656,y:566,t:1526667119202};\\\", \\\"{x:648,y:562,t:1526667119216};\\\", \\\"{x:623,y:557,t:1526667119233};\\\", \\\"{x:593,y:554,t:1526667119249};\\\", \\\"{x:545,y:554,t:1526667119265};\\\", \\\"{x:434,y:554,t:1526667119281};\\\", \\\"{x:399,y:555,t:1526667119298};\\\", \\\"{x:365,y:560,t:1526667119316};\\\", \\\"{x:329,y:560,t:1526667119332};\\\", \\\"{x:309,y:560,t:1526667119348};\\\", \\\"{x:300,y:560,t:1526667119365};\\\", \\\"{x:299,y:560,t:1526667119382};\\\", \\\"{x:298,y:560,t:1526667119554};\\\", \\\"{x:299,y:560,t:1526667119566};\\\", \\\"{x:304,y:560,t:1526667119583};\\\", \\\"{x:303,y:557,t:1526667119618};\\\", \\\"{x:300,y:557,t:1526667119633};\\\", \\\"{x:272,y:557,t:1526667119652};\\\", \\\"{x:244,y:564,t:1526667119666};\\\", \\\"{x:226,y:570,t:1526667119682};\\\", \\\"{x:216,y:572,t:1526667119699};\\\", \\\"{x:204,y:580,t:1526667119716};\\\", \\\"{x:184,y:585,t:1526667119733};\\\", \\\"{x:171,y:589,t:1526667119750};\\\", \\\"{x:159,y:594,t:1526667119765};\\\", \\\"{x:155,y:596,t:1526667119782};\\\", \\\"{x:153,y:597,t:1526667119799};\\\", \\\"{x:153,y:598,t:1526667119816};\\\", \\\"{x:152,y:599,t:1526667119833};\\\", \\\"{x:151,y:605,t:1526667119849};\\\", \\\"{x:151,y:615,t:1526667119865};\\\", \\\"{x:151,y:622,t:1526667119883};\\\", \\\"{x:150,y:626,t:1526667119900};\\\", \\\"{x:150,y:628,t:1526667119916};\\\", \\\"{x:149,y:631,t:1526667119932};\\\", \\\"{x:149,y:634,t:1526667119950};\\\", \\\"{x:148,y:635,t:1526667119965};\\\", \\\"{x:148,y:636,t:1526667120049};\\\", \\\"{x:152,y:636,t:1526667120066};\\\", \\\"{x:164,y:636,t:1526667120082};\\\", \\\"{x:169,y:636,t:1526667120100};\\\", \\\"{x:171,y:636,t:1526667120116};\\\", \\\"{x:175,y:635,t:1526667120754};\\\", \\\"{x:181,y:635,t:1526667120766};\\\", \\\"{x:203,y:634,t:1526667120785};\\\", \\\"{x:226,y:633,t:1526667120799};\\\", \\\"{x:252,y:631,t:1526667120816};\\\", \\\"{x:273,y:629,t:1526667120833};\\\", \\\"{x:283,y:626,t:1526667120849};\\\", \\\"{x:292,y:625,t:1526667120866};\\\", \\\"{x:300,y:621,t:1526667120883};\\\", \\\"{x:313,y:617,t:1526667120900};\\\", \\\"{x:324,y:614,t:1526667120917};\\\", \\\"{x:333,y:611,t:1526667120934};\\\", \\\"{x:342,y:608,t:1526667120949};\\\", \\\"{x:349,y:605,t:1526667120966};\\\", \\\"{x:351,y:603,t:1526667120984};\\\", \\\"{x:353,y:602,t:1526667121000};\\\", \\\"{x:361,y:599,t:1526667121016};\\\", \\\"{x:378,y:592,t:1526667121034};\\\", \\\"{x:389,y:587,t:1526667121051};\\\", \\\"{x:427,y:581,t:1526667121067};\\\", \\\"{x:457,y:576,t:1526667121083};\\\", \\\"{x:465,y:576,t:1526667121100};\\\", \\\"{x:493,y:576,t:1526667121117};\\\", \\\"{x:521,y:575,t:1526667121133};\\\", \\\"{x:527,y:575,t:1526667121151};\\\", \\\"{x:545,y:575,t:1526667121166};\\\", \\\"{x:560,y:575,t:1526667121184};\\\", \\\"{x:570,y:575,t:1526667121201};\\\", \\\"{x:581,y:575,t:1526667121217};\\\", \\\"{x:596,y:575,t:1526667121234};\\\", \\\"{x:604,y:573,t:1526667121251};\\\", \\\"{x:609,y:572,t:1526667121267};\\\", \\\"{x:613,y:571,t:1526667121283};\\\", \\\"{x:617,y:571,t:1526667121301};\\\", \\\"{x:623,y:571,t:1526667121316};\\\", \\\"{x:633,y:568,t:1526667121334};\\\", \\\"{x:651,y:567,t:1526667121351};\\\", \\\"{x:667,y:563,t:1526667121367};\\\", \\\"{x:679,y:563,t:1526667121383};\\\", \\\"{x:688,y:561,t:1526667121401};\\\", \\\"{x:725,y:561,t:1526667121417};\\\", \\\"{x:757,y:561,t:1526667121433};\\\", \\\"{x:810,y:561,t:1526667121450};\\\", \\\"{x:843,y:561,t:1526667121468};\\\", \\\"{x:874,y:559,t:1526667121484};\\\", \\\"{x:887,y:557,t:1526667121500};\\\", \\\"{x:888,y:557,t:1526667121518};\\\", \\\"{x:889,y:557,t:1526667121533};\\\", \\\"{x:890,y:556,t:1526667121570};\\\", \\\"{x:890,y:554,t:1526667121583};\\\", \\\"{x:887,y:551,t:1526667121601};\\\", \\\"{x:878,y:545,t:1526667121618};\\\", \\\"{x:870,y:542,t:1526667121635};\\\", \\\"{x:860,y:537,t:1526667121651};\\\", \\\"{x:855,y:536,t:1526667121667};\\\", \\\"{x:851,y:533,t:1526667121683};\\\", \\\"{x:849,y:533,t:1526667121701};\\\", \\\"{x:846,y:538,t:1526667121746};\\\", \\\"{x:846,y:548,t:1526667121754};\\\", \\\"{x:841,y:555,t:1526667121768};\\\", \\\"{x:834,y:571,t:1526667121785};\\\", \\\"{x:827,y:584,t:1526667121801};\\\", \\\"{x:821,y:600,t:1526667121817};\\\", \\\"{x:819,y:610,t:1526667121834};\\\", \\\"{x:819,y:615,t:1526667121851};\\\", \\\"{x:819,y:616,t:1526667121868};\\\", \\\"{x:821,y:616,t:1526667122018};\\\", \\\"{x:824,y:613,t:1526667122033};\\\", \\\"{x:829,y:609,t:1526667122051};\\\", \\\"{x:830,y:609,t:1526667122068};\\\", \\\"{x:832,y:606,t:1526667122085};\\\", \\\"{x:832,y:605,t:1526667122101};\\\", \\\"{x:832,y:603,t:1526667122179};\\\", \\\"{x:832,y:602,t:1526667122225};\\\", \\\"{x:832,y:601,t:1526667122858};\\\", \\\"{x:826,y:604,t:1526667122868};\\\", \\\"{x:810,y:618,t:1526667122887};\\\", \\\"{x:800,y:629,t:1526667122901};\\\", \\\"{x:791,y:646,t:1526667122919};\\\", \\\"{x:783,y:662,t:1526667122934};\\\", \\\"{x:777,y:675,t:1526667122951};\\\", \\\"{x:775,y:686,t:1526667122969};\\\", \\\"{x:774,y:696,t:1526667122984};\\\", \\\"{x:769,y:720,t:1526667123001};\\\", \\\"{x:769,y:734,t:1526667123019};\\\", \\\"{x:768,y:753,t:1526667123034};\\\", \\\"{x:768,y:775,t:1526667123051};\\\", \\\"{x:770,y:791,t:1526667123069};\\\", \\\"{x:770,y:802,t:1526667123085};\\\", \\\"{x:771,y:807,t:1526667123101};\\\", \\\"{x:770,y:813,t:1526667123118};\\\", \\\"{x:767,y:819,t:1526667123135};\\\", \\\"{x:765,y:822,t:1526667123152};\\\", \\\"{x:763,y:824,t:1526667123168};\\\", \\\"{x:759,y:827,t:1526667123185};\\\", \\\"{x:749,y:830,t:1526667123202};\\\", \\\"{x:739,y:831,t:1526667123219};\\\", \\\"{x:733,y:833,t:1526667123236};\\\", \\\"{x:729,y:833,t:1526667123258};\\\", \\\"{x:727,y:834,t:1526667123269};\\\", \\\"{x:722,y:834,t:1526667123286};\\\", \\\"{x:718,y:835,t:1526667123302};\\\", \\\"{x:712,y:835,t:1526667123319};\\\", \\\"{x:711,y:835,t:1526667123335};\\\", \\\"{x:710,y:835,t:1526667130647};\\\", \\\"{x:714,y:838,t:1526667130655};\\\", \\\"{x:749,y:838,t:1526667130671};\\\", \\\"{x:828,y:840,t:1526667130688};\\\", \\\"{x:910,y:847,t:1526667130704};\\\", \\\"{x:975,y:849,t:1526667130721};\\\", \\\"{x:1056,y:854,t:1526667130739};\\\", \\\"{x:1156,y:866,t:1526667130755};\\\", \\\"{x:1236,y:875,t:1526667130771};\\\", \\\"{x:1297,y:882,t:1526667130789};\\\", \\\"{x:1375,y:884,t:1526667130806};\\\", \\\"{x:1442,y:885,t:1526667130822};\\\", \\\"{x:1518,y:885,t:1526667130839};\\\", \\\"{x:1568,y:885,t:1526667130855};\\\", \\\"{x:1624,y:885,t:1526667130871};\\\", \\\"{x:1669,y:885,t:1526667130888};\\\", \\\"{x:1725,y:885,t:1526667130906};\\\", \\\"{x:1797,y:887,t:1526667130922};\\\", \\\"{x:1883,y:895,t:1526667130939};\\\", \\\"{x:1914,y:895,t:1526667130956};\\\", \\\"{x:1919,y:898,t:1526667130971};\\\", \\\"{x:1914,y:899,t:1526667131087};\\\", \\\"{x:1908,y:900,t:1526667131094};\\\", \\\"{x:1902,y:905,t:1526667131105};\\\", \\\"{x:1885,y:911,t:1526667131122};\\\", \\\"{x:1883,y:914,t:1526667131139};\\\", \\\"{x:1874,y:922,t:1526667131155};\\\", \\\"{x:1864,y:928,t:1526667131172};\\\", \\\"{x:1852,y:936,t:1526667131189};\\\", \\\"{x:1840,y:942,t:1526667131205};\\\", \\\"{x:1826,y:949,t:1526667131222};\\\", \\\"{x:1814,y:954,t:1526667131239};\\\", \\\"{x:1801,y:957,t:1526667131255};\\\", \\\"{x:1783,y:959,t:1526667131272};\\\", \\\"{x:1764,y:959,t:1526667131289};\\\", \\\"{x:1760,y:959,t:1526667131305};\\\", \\\"{x:1751,y:961,t:1526667131322};\\\", \\\"{x:1744,y:961,t:1526667131339};\\\", \\\"{x:1738,y:961,t:1526667131356};\\\", \\\"{x:1732,y:961,t:1526667131372};\\\", \\\"{x:1724,y:961,t:1526667131389};\\\", \\\"{x:1711,y:961,t:1526667131406};\\\", \\\"{x:1709,y:961,t:1526667131423};\\\", \\\"{x:1701,y:961,t:1526667131439};\\\", \\\"{x:1699,y:961,t:1526667131456};\\\", \\\"{x:1697,y:961,t:1526667131472};\\\", \\\"{x:1695,y:961,t:1526667131489};\\\", \\\"{x:1694,y:963,t:1526667131584};\\\", \\\"{x:1693,y:964,t:1526667131591};\\\", \\\"{x:1692,y:967,t:1526667131607};\\\", \\\"{x:1690,y:968,t:1526667131623};\\\", \\\"{x:1690,y:971,t:1526667131640};\\\", \\\"{x:1690,y:972,t:1526667131656};\\\", \\\"{x:1689,y:973,t:1526667131736};\\\", \\\"{x:1688,y:973,t:1526667131743};\\\", \\\"{x:1687,y:974,t:1526667131757};\\\", \\\"{x:1686,y:974,t:1526667131773};\\\", \\\"{x:1685,y:974,t:1526667131815};\\\", \\\"{x:1684,y:974,t:1526667131839};\\\", \\\"{x:1683,y:974,t:1526667131856};\\\", \\\"{x:1681,y:974,t:1526667131874};\\\", \\\"{x:1679,y:974,t:1526667131890};\\\", \\\"{x:1678,y:974,t:1526667131911};\\\", \\\"{x:1677,y:974,t:1526667131923};\\\", \\\"{x:1676,y:974,t:1526667131939};\\\", \\\"{x:1675,y:974,t:1526667131967};\\\", \\\"{x:1674,y:972,t:1526667132120};\\\", \\\"{x:1674,y:971,t:1526667132135};\\\", \\\"{x:1674,y:969,t:1526667132151};\\\", \\\"{x:1674,y:968,t:1526667132159};\\\", \\\"{x:1674,y:966,t:1526667132174};\\\", \\\"{x:1674,y:965,t:1526667132190};\\\", \\\"{x:1674,y:963,t:1526667132207};\\\", \\\"{x:1674,y:962,t:1526667132320};\\\", \\\"{x:1675,y:961,t:1526667132335};\\\", \\\"{x:1676,y:961,t:1526667132343};\\\", \\\"{x:1678,y:959,t:1526667132357};\\\", \\\"{x:1681,y:958,t:1526667132373};\\\", \\\"{x:1682,y:958,t:1526667133119};\\\", \\\"{x:1680,y:958,t:1526667133135};\\\", \\\"{x:1679,y:958,t:1526667133143};\\\", \\\"{x:1678,y:958,t:1526667133158};\\\", \\\"{x:1672,y:959,t:1526667133174};\\\", \\\"{x:1668,y:959,t:1526667133190};\\\", \\\"{x:1666,y:960,t:1526667133207};\\\", \\\"{x:1665,y:960,t:1526667133224};\\\", \\\"{x:1664,y:961,t:1526667133240};\\\", \\\"{x:1663,y:962,t:1526667133257};\\\", \\\"{x:1662,y:963,t:1526667133274};\\\", \\\"{x:1660,y:963,t:1526667133290};\\\", \\\"{x:1658,y:964,t:1526667133307};\\\", \\\"{x:1656,y:965,t:1526667133324};\\\", \\\"{x:1655,y:966,t:1526667133340};\\\", \\\"{x:1653,y:967,t:1526667133357};\\\", \\\"{x:1651,y:967,t:1526667133375};\\\", \\\"{x:1650,y:968,t:1526667133390};\\\", \\\"{x:1649,y:968,t:1526667133408};\\\", \\\"{x:1648,y:969,t:1526667133425};\\\", \\\"{x:1647,y:969,t:1526667133464};\\\", \\\"{x:1646,y:969,t:1526667133479};\\\", \\\"{x:1644,y:969,t:1526667133490};\\\", \\\"{x:1643,y:969,t:1526667133507};\\\", \\\"{x:1639,y:969,t:1526667133525};\\\", \\\"{x:1632,y:969,t:1526667133540};\\\", \\\"{x:1628,y:969,t:1526667133558};\\\", \\\"{x:1620,y:969,t:1526667133574};\\\", \\\"{x:1616,y:968,t:1526667133591};\\\", \\\"{x:1613,y:967,t:1526667133607};\\\", \\\"{x:1610,y:966,t:1526667133624};\\\", \\\"{x:1607,y:965,t:1526667133641};\\\", \\\"{x:1606,y:964,t:1526667133658};\\\", \\\"{x:1605,y:963,t:1526667133799};\\\", \\\"{x:1604,y:963,t:1526667133807};\\\", \\\"{x:1603,y:963,t:1526667133839};\\\", \\\"{x:1603,y:962,t:1526667133872};\\\", \\\"{x:1604,y:960,t:1526667133888};\\\", \\\"{x:1605,y:959,t:1526667133903};\\\", \\\"{x:1607,y:957,t:1526667133911};\\\", \\\"{x:1609,y:957,t:1526667133925};\\\", \\\"{x:1614,y:956,t:1526667133942};\\\", \\\"{x:1617,y:956,t:1526667133958};\\\", \\\"{x:1618,y:956,t:1526667133975};\\\", \\\"{x:1619,y:956,t:1526667133992};\\\", \\\"{x:1620,y:956,t:1526667134008};\\\", \\\"{x:1622,y:956,t:1526667134039};\\\", \\\"{x:1621,y:956,t:1526667134311};\\\", \\\"{x:1621,y:957,t:1526667134325};\\\", \\\"{x:1620,y:957,t:1526667134551};\\\", \\\"{x:1618,y:958,t:1526667134574};\\\", \\\"{x:1616,y:958,t:1526667135079};\\\", \\\"{x:1615,y:958,t:1526667135119};\\\", \\\"{x:1614,y:958,t:1526667135152};\\\", \\\"{x:1613,y:958,t:1526667135159};\\\", \\\"{x:1612,y:958,t:1526667135191};\\\", \\\"{x:1610,y:958,t:1526667139328};\\\", \\\"{x:1588,y:963,t:1526667139345};\\\", \\\"{x:1558,y:968,t:1526667139363};\\\", \\\"{x:1540,y:972,t:1526667139381};\\\", \\\"{x:1525,y:973,t:1526667139395};\\\", \\\"{x:1508,y:973,t:1526667139412};\\\", \\\"{x:1502,y:973,t:1526667139429};\\\", \\\"{x:1503,y:972,t:1526667139679};\\\", \\\"{x:1510,y:971,t:1526667139696};\\\", \\\"{x:1518,y:971,t:1526667139712};\\\", \\\"{x:1527,y:969,t:1526667139729};\\\", \\\"{x:1537,y:969,t:1526667139746};\\\", \\\"{x:1541,y:969,t:1526667139761};\\\", \\\"{x:1545,y:969,t:1526667139780};\\\", \\\"{x:1547,y:969,t:1526667139796};\\\", \\\"{x:1549,y:970,t:1526667139815};\\\", \\\"{x:1550,y:970,t:1526667139830};\\\", \\\"{x:1558,y:970,t:1526667139846};\\\", \\\"{x:1562,y:970,t:1526667139862};\\\", \\\"{x:1569,y:970,t:1526667139879};\\\", \\\"{x:1570,y:970,t:1526667139896};\\\", \\\"{x:1571,y:970,t:1526667140069};\\\", \\\"{x:1570,y:970,t:1526667140094};\\\", \\\"{x:1570,y:969,t:1526667140102};\\\", \\\"{x:1569,y:969,t:1526667140112};\\\", \\\"{x:1568,y:968,t:1526667140129};\\\", \\\"{x:1567,y:968,t:1526667140145};\\\", \\\"{x:1565,y:968,t:1526667140162};\\\", \\\"{x:1564,y:968,t:1526667140182};\\\", \\\"{x:1563,y:968,t:1526667140254};\\\", \\\"{x:1560,y:968,t:1526667140591};\\\", \\\"{x:1557,y:968,t:1526667140598};\\\", \\\"{x:1553,y:968,t:1526667140612};\\\", \\\"{x:1546,y:968,t:1526667140630};\\\", \\\"{x:1540,y:968,t:1526667140646};\\\", \\\"{x:1533,y:968,t:1526667140662};\\\", \\\"{x:1532,y:968,t:1526667140679};\\\", \\\"{x:1531,y:968,t:1526667140695};\\\", \\\"{x:1530,y:968,t:1526667140713};\\\", \\\"{x:1529,y:968,t:1526667140729};\\\", \\\"{x:1528,y:968,t:1526667140759};\\\", \\\"{x:1526,y:968,t:1526667140766};\\\", \\\"{x:1524,y:968,t:1526667140779};\\\", \\\"{x:1522,y:968,t:1526667140796};\\\", \\\"{x:1519,y:968,t:1526667140813};\\\", \\\"{x:1517,y:968,t:1526667140829};\\\", \\\"{x:1516,y:967,t:1526667140847};\\\", \\\"{x:1514,y:967,t:1526667140911};\\\", \\\"{x:1513,y:967,t:1526667140927};\\\", \\\"{x:1511,y:967,t:1526667140935};\\\", \\\"{x:1509,y:967,t:1526667140967};\\\", \\\"{x:1510,y:967,t:1526667141279};\\\", \\\"{x:1518,y:967,t:1526667141297};\\\", \\\"{x:1529,y:967,t:1526667141314};\\\", \\\"{x:1550,y:967,t:1526667141329};\\\", \\\"{x:1570,y:967,t:1526667141347};\\\", \\\"{x:1587,y:967,t:1526667141364};\\\", \\\"{x:1599,y:970,t:1526667141380};\\\", \\\"{x:1605,y:972,t:1526667141397};\\\", \\\"{x:1607,y:972,t:1526667141413};\\\", \\\"{x:1608,y:972,t:1526667141454};\\\", \\\"{x:1610,y:974,t:1526667141463};\\\", \\\"{x:1612,y:974,t:1526667141479};\\\", \\\"{x:1614,y:974,t:1526667141502};\\\", \\\"{x:1615,y:974,t:1526667141518};\\\", \\\"{x:1616,y:973,t:1526667141760};\\\", \\\"{x:1616,y:972,t:1526667141766};\\\", \\\"{x:1616,y:970,t:1526667141783};\\\", \\\"{x:1616,y:969,t:1526667141796};\\\", \\\"{x:1617,y:968,t:1526667141814};\\\", \\\"{x:1617,y:967,t:1526667141830};\\\", \\\"{x:1617,y:968,t:1526667143848};\\\", \\\"{x:1617,y:970,t:1526667143862};\\\", \\\"{x:1618,y:971,t:1526667143870};\\\", \\\"{x:1618,y:972,t:1526667144183};\\\", \\\"{x:1612,y:972,t:1526667144199};\\\", \\\"{x:1603,y:972,t:1526667144217};\\\", \\\"{x:1600,y:972,t:1526667144232};\\\", \\\"{x:1598,y:972,t:1526667144249};\\\", \\\"{x:1599,y:972,t:1526667144543};\\\", \\\"{x:1600,y:972,t:1526667144559};\\\", \\\"{x:1601,y:972,t:1526667144566};\\\", \\\"{x:1602,y:972,t:1526667144671};\\\", \\\"{x:1604,y:972,t:1526667144682};\\\", \\\"{x:1605,y:972,t:1526667144699};\\\", \\\"{x:1611,y:972,t:1526667144716};\\\", \\\"{x:1615,y:972,t:1526667144734};\\\", \\\"{x:1617,y:974,t:1526667144750};\\\", \\\"{x:1617,y:976,t:1526667151568};\\\", \\\"{x:1615,y:977,t:1526667151578};\\\", \\\"{x:1614,y:977,t:1526667151587};\\\", \\\"{x:1613,y:978,t:1526667151604};\\\", \\\"{x:1613,y:977,t:1526667151678};\\\", \\\"{x:1613,y:976,t:1526667151687};\\\", \\\"{x:1613,y:975,t:1526667151704};\\\", \\\"{x:1613,y:972,t:1526667151721};\\\", \\\"{x:1613,y:970,t:1526667152062};\\\", \\\"{x:1613,y:969,t:1526667152071};\\\", \\\"{x:1613,y:968,t:1526667152088};\\\", \\\"{x:1613,y:967,t:1526667152104};\\\", \\\"{x:1613,y:965,t:1526667152121};\\\", \\\"{x:1613,y:964,t:1526667152138};\\\", \\\"{x:1613,y:963,t:1526667152158};\\\", \\\"{x:1613,y:962,t:1526667152271};\\\", \\\"{x:1612,y:962,t:1526667154671};\\\", \\\"{x:1611,y:962,t:1526667154678};\\\", \\\"{x:1609,y:962,t:1526667154690};\\\", \\\"{x:1606,y:962,t:1526667154706};\\\", \\\"{x:1604,y:962,t:1526667154723};\\\", \\\"{x:1603,y:962,t:1526667154741};\\\", \\\"{x:1602,y:962,t:1526667154831};\\\", \\\"{x:1601,y:962,t:1526667154841};\\\", \\\"{x:1600,y:962,t:1526667154856};\\\", \\\"{x:1597,y:962,t:1526667154874};\\\", \\\"{x:1595,y:962,t:1526667154890};\\\", \\\"{x:1594,y:962,t:1526667154910};\\\", \\\"{x:1593,y:962,t:1526667154924};\\\", \\\"{x:1589,y:963,t:1526667154941};\\\", \\\"{x:1586,y:963,t:1526667154957};\\\", \\\"{x:1584,y:963,t:1526667154973};\\\", \\\"{x:1581,y:963,t:1526667154991};\\\", \\\"{x:1580,y:963,t:1526667155007};\\\", \\\"{x:1578,y:963,t:1526667155023};\\\", \\\"{x:1577,y:963,t:1526667155040};\\\", \\\"{x:1576,y:963,t:1526667155057};\\\", \\\"{x:1573,y:963,t:1526667155074};\\\", \\\"{x:1572,y:963,t:1526667155090};\\\", \\\"{x:1570,y:963,t:1526667155106};\\\", \\\"{x:1568,y:963,t:1526667155123};\\\", \\\"{x:1565,y:963,t:1526667155140};\\\", \\\"{x:1564,y:963,t:1526667155191};\\\", \\\"{x:1563,y:963,t:1526667155231};\\\", \\\"{x:1562,y:963,t:1526667155241};\\\", \\\"{x:1560,y:963,t:1526667155258};\\\", \\\"{x:1558,y:963,t:1526667155274};\\\", \\\"{x:1554,y:963,t:1526667155290};\\\", \\\"{x:1551,y:963,t:1526667155307};\\\", \\\"{x:1550,y:963,t:1526667155324};\\\", \\\"{x:1549,y:964,t:1526667155341};\\\", \\\"{x:1546,y:964,t:1526667155359};\\\", \\\"{x:1544,y:964,t:1526667155374};\\\", \\\"{x:1542,y:964,t:1526667155390};\\\", \\\"{x:1537,y:964,t:1526667155407};\\\", \\\"{x:1536,y:964,t:1526667155423};\\\", \\\"{x:1534,y:964,t:1526667155441};\\\", \\\"{x:1533,y:964,t:1526667155458};\\\", \\\"{x:1532,y:964,t:1526667155473};\\\", \\\"{x:1531,y:964,t:1526667155490};\\\", \\\"{x:1529,y:964,t:1526667155507};\\\", \\\"{x:1527,y:964,t:1526667155524};\\\", \\\"{x:1526,y:964,t:1526667155541};\\\", \\\"{x:1523,y:964,t:1526667155558};\\\", \\\"{x:1522,y:964,t:1526667155573};\\\", \\\"{x:1520,y:964,t:1526667155591};\\\", \\\"{x:1519,y:964,t:1526667155607};\\\", \\\"{x:1518,y:964,t:1526667155639};\\\", \\\"{x:1516,y:964,t:1526667155679};\\\", \\\"{x:1514,y:964,t:1526667155695};\\\", \\\"{x:1513,y:964,t:1526667158070};\\\", \\\"{x:1512,y:958,t:1526667158078};\\\", \\\"{x:1512,y:956,t:1526667158093};\\\", \\\"{x:1511,y:937,t:1526667158109};\\\", \\\"{x:1511,y:915,t:1526667158125};\\\", \\\"{x:1508,y:889,t:1526667158142};\\\", \\\"{x:1508,y:868,t:1526667158159};\\\", \\\"{x:1508,y:854,t:1526667158175};\\\", \\\"{x:1508,y:841,t:1526667158192};\\\", \\\"{x:1508,y:828,t:1526667158209};\\\", \\\"{x:1507,y:813,t:1526667158225};\\\", \\\"{x:1504,y:795,t:1526667158242};\\\", \\\"{x:1501,y:763,t:1526667158259};\\\", \\\"{x:1500,y:742,t:1526667158276};\\\", \\\"{x:1500,y:729,t:1526667158293};\\\", \\\"{x:1498,y:713,t:1526667158310};\\\", \\\"{x:1498,y:698,t:1526667158326};\\\", \\\"{x:1498,y:672,t:1526667158342};\\\", \\\"{x:1498,y:657,t:1526667158360};\\\", \\\"{x:1498,y:646,t:1526667158375};\\\", \\\"{x:1498,y:632,t:1526667158392};\\\", \\\"{x:1497,y:618,t:1526667158409};\\\", \\\"{x:1497,y:608,t:1526667158425};\\\", \\\"{x:1497,y:604,t:1526667158442};\\\", \\\"{x:1497,y:600,t:1526667158459};\\\", \\\"{x:1497,y:598,t:1526667158475};\\\", \\\"{x:1497,y:600,t:1526667158607};\\\", \\\"{x:1498,y:603,t:1526667158615};\\\", \\\"{x:1503,y:609,t:1526667158627};\\\", \\\"{x:1510,y:619,t:1526667158642};\\\", \\\"{x:1514,y:624,t:1526667158660};\\\", \\\"{x:1516,y:627,t:1526667158679};\\\", \\\"{x:1517,y:628,t:1526667158692};\\\", \\\"{x:1518,y:629,t:1526667158709};\\\", \\\"{x:1519,y:630,t:1526667158749};\\\", \\\"{x:1520,y:632,t:1526667158766};\\\", \\\"{x:1520,y:633,t:1526667158781};\\\", \\\"{x:1521,y:634,t:1526667158792};\\\", \\\"{x:1520,y:634,t:1526667159103};\\\", \\\"{x:1519,y:634,t:1526667159591};\\\", \\\"{x:1518,y:634,t:1526667159607};\\\", \\\"{x:1516,y:631,t:1526667159627};\\\", \\\"{x:1513,y:630,t:1526667159644};\\\", \\\"{x:1512,y:628,t:1526667159661};\\\", \\\"{x:1511,y:627,t:1526667159678};\\\", \\\"{x:1510,y:627,t:1526667159703};\\\", \\\"{x:1509,y:628,t:1526667160359};\\\", \\\"{x:1509,y:633,t:1526667160367};\\\", \\\"{x:1509,y:637,t:1526667160378};\\\", \\\"{x:1506,y:649,t:1526667160395};\\\", \\\"{x:1506,y:660,t:1526667160411};\\\", \\\"{x:1508,y:674,t:1526667160428};\\\", \\\"{x:1511,y:695,t:1526667160445};\\\", \\\"{x:1512,y:712,t:1526667160460};\\\", \\\"{x:1513,y:736,t:1526667160478};\\\", \\\"{x:1517,y:768,t:1526667160495};\\\", \\\"{x:1517,y:784,t:1526667160511};\\\", \\\"{x:1517,y:797,t:1526667160528};\\\", \\\"{x:1517,y:812,t:1526667160545};\\\", \\\"{x:1514,y:828,t:1526667160560};\\\", \\\"{x:1514,y:836,t:1526667160578};\\\", \\\"{x:1513,y:846,t:1526667160595};\\\", \\\"{x:1510,y:858,t:1526667160610};\\\", \\\"{x:1509,y:869,t:1526667160627};\\\", \\\"{x:1505,y:881,t:1526667160645};\\\", \\\"{x:1501,y:896,t:1526667160661};\\\", \\\"{x:1496,y:906,t:1526667160678};\\\", \\\"{x:1493,y:915,t:1526667160694};\\\", \\\"{x:1490,y:922,t:1526667160710};\\\", \\\"{x:1489,y:925,t:1526667160727};\\\", \\\"{x:1488,y:929,t:1526667160744};\\\", \\\"{x:1487,y:933,t:1526667160760};\\\", \\\"{x:1486,y:935,t:1526667160778};\\\", \\\"{x:1485,y:939,t:1526667160795};\\\", \\\"{x:1484,y:942,t:1526667160811};\\\", \\\"{x:1484,y:944,t:1526667160828};\\\", \\\"{x:1483,y:948,t:1526667160845};\\\", \\\"{x:1483,y:950,t:1526667160861};\\\", \\\"{x:1480,y:955,t:1526667160878};\\\", \\\"{x:1478,y:958,t:1526667160895};\\\", \\\"{x:1477,y:960,t:1526667160912};\\\", \\\"{x:1476,y:961,t:1526667160928};\\\", \\\"{x:1476,y:962,t:1526667160999};\\\", \\\"{x:1476,y:961,t:1526667161078};\\\", \\\"{x:1477,y:944,t:1526667161095};\\\", \\\"{x:1480,y:922,t:1526667161112};\\\", \\\"{x:1483,y:897,t:1526667161128};\\\", \\\"{x:1484,y:883,t:1526667161145};\\\", \\\"{x:1484,y:862,t:1526667161161};\\\", \\\"{x:1484,y:841,t:1526667161177};\\\", \\\"{x:1484,y:828,t:1526667161195};\\\", \\\"{x:1484,y:810,t:1526667161212};\\\", \\\"{x:1485,y:791,t:1526667161228};\\\", \\\"{x:1486,y:775,t:1526667161245};\\\", \\\"{x:1489,y:758,t:1526667161261};\\\", \\\"{x:1489,y:742,t:1526667161278};\\\", \\\"{x:1490,y:740,t:1526667161295};\\\", \\\"{x:1489,y:741,t:1526667161359};\\\", \\\"{x:1488,y:755,t:1526667161366};\\\", \\\"{x:1488,y:781,t:1526667161382};\\\", \\\"{x:1488,y:850,t:1526667161395};\\\", \\\"{x:1488,y:912,t:1526667161411};\\\", \\\"{x:1483,y:956,t:1526667161428};\\\", \\\"{x:1481,y:983,t:1526667161444};\\\", \\\"{x:1481,y:1002,t:1526667161462};\\\", \\\"{x:1482,y:1013,t:1526667161478};\\\", \\\"{x:1483,y:1020,t:1526667161494};\\\", \\\"{x:1485,y:1025,t:1526667161511};\\\", \\\"{x:1485,y:1030,t:1526667161528};\\\", \\\"{x:1485,y:1032,t:1526667161544};\\\", \\\"{x:1486,y:1033,t:1526667161561};\\\", \\\"{x:1486,y:1030,t:1526667161655};\\\", \\\"{x:1485,y:1023,t:1526667161663};\\\", \\\"{x:1481,y:1015,t:1526667161678};\\\", \\\"{x:1479,y:1005,t:1526667161695};\\\", \\\"{x:1476,y:998,t:1526667161712};\\\", \\\"{x:1471,y:994,t:1526667161729};\\\", \\\"{x:1468,y:987,t:1526667161744};\\\", \\\"{x:1468,y:985,t:1526667161761};\\\", \\\"{x:1468,y:981,t:1526667161779};\\\", \\\"{x:1467,y:977,t:1526667161795};\\\", \\\"{x:1467,y:974,t:1526667161811};\\\", \\\"{x:1468,y:971,t:1526667161828};\\\", \\\"{x:1468,y:970,t:1526667161854};\\\", \\\"{x:1468,y:969,t:1526667161895};\\\", \\\"{x:1468,y:967,t:1526667161912};\\\", \\\"{x:1469,y:966,t:1526667162031};\\\", \\\"{x:1470,y:964,t:1526667162046};\\\", \\\"{x:1474,y:962,t:1526667162062};\\\", \\\"{x:1480,y:959,t:1526667162078};\\\", \\\"{x:1482,y:959,t:1526667162095};\\\", \\\"{x:1482,y:958,t:1526667162112};\\\", \\\"{x:1483,y:958,t:1526667163159};\\\", \\\"{x:1483,y:961,t:1526667163167};\\\", \\\"{x:1482,y:963,t:1526667163182};\\\", \\\"{x:1481,y:963,t:1526667163197};\\\", \\\"{x:1483,y:963,t:1526667163503};\\\", \\\"{x:1486,y:963,t:1526667163513};\\\", \\\"{x:1495,y:963,t:1526667163530};\\\", \\\"{x:1503,y:963,t:1526667163547};\\\", \\\"{x:1510,y:963,t:1526667163562};\\\", \\\"{x:1515,y:963,t:1526667163581};\\\", \\\"{x:1521,y:963,t:1526667163597};\\\", \\\"{x:1525,y:963,t:1526667163612};\\\", \\\"{x:1530,y:963,t:1526667163630};\\\", \\\"{x:1540,y:963,t:1526667163646};\\\", \\\"{x:1549,y:963,t:1526667163664};\\\", \\\"{x:1551,y:963,t:1526667163680};\\\", \\\"{x:1554,y:964,t:1526667163697};\\\", \\\"{x:1555,y:964,t:1526667163894};\\\", \\\"{x:1559,y:964,t:1526667163902};\\\", \\\"{x:1563,y:964,t:1526667163913};\\\", \\\"{x:1573,y:964,t:1526667163929};\\\", \\\"{x:1584,y:964,t:1526667163947};\\\", \\\"{x:1597,y:964,t:1526667163964};\\\", \\\"{x:1612,y:964,t:1526667163980};\\\", \\\"{x:1617,y:964,t:1526667163997};\\\", \\\"{x:1625,y:964,t:1526667164014};\\\", \\\"{x:1631,y:964,t:1526667164030};\\\", \\\"{x:1633,y:964,t:1526667164046};\\\", \\\"{x:1631,y:964,t:1526667164167};\\\", \\\"{x:1622,y:961,t:1526667164180};\\\", \\\"{x:1602,y:950,t:1526667164196};\\\", \\\"{x:1570,y:937,t:1526667164213};\\\", \\\"{x:1467,y:897,t:1526667164229};\\\", \\\"{x:1374,y:862,t:1526667164247};\\\", \\\"{x:1251,y:817,t:1526667164263};\\\", \\\"{x:1177,y:792,t:1526667164280};\\\", \\\"{x:1048,y:738,t:1526667164297};\\\", \\\"{x:919,y:707,t:1526667164313};\\\", \\\"{x:817,y:680,t:1526667164330};\\\", \\\"{x:751,y:663,t:1526667164346};\\\", \\\"{x:731,y:662,t:1526667164363};\\\", \\\"{x:729,y:662,t:1526667164380};\\\", \\\"{x:727,y:662,t:1526667164396};\\\", \\\"{x:726,y:664,t:1526667164422};\\\", \\\"{x:726,y:670,t:1526667164430};\\\", \\\"{x:735,y:683,t:1526667164446};\\\", \\\"{x:743,y:687,t:1526667164463};\\\", \\\"{x:753,y:688,t:1526667164480};\\\", \\\"{x:771,y:686,t:1526667164496};\\\", \\\"{x:792,y:679,t:1526667164514};\\\", \\\"{x:811,y:673,t:1526667164531};\\\", \\\"{x:827,y:663,t:1526667164547};\\\", \\\"{x:838,y:656,t:1526667164564};\\\", \\\"{x:847,y:651,t:1526667164581};\\\", \\\"{x:851,y:648,t:1526667164596};\\\", \\\"{x:856,y:644,t:1526667164614};\\\", \\\"{x:858,y:638,t:1526667164631};\\\", \\\"{x:858,y:634,t:1526667164647};\\\", \\\"{x:858,y:630,t:1526667164664};\\\", \\\"{x:858,y:627,t:1526667164681};\\\", \\\"{x:858,y:622,t:1526667164697};\\\", \\\"{x:860,y:613,t:1526667164713};\\\", \\\"{x:860,y:606,t:1526667164732};\\\", \\\"{x:860,y:602,t:1526667164747};\\\", \\\"{x:858,y:596,t:1526667164763};\\\", \\\"{x:854,y:593,t:1526667164777};\\\", \\\"{x:853,y:592,t:1526667164793};\\\", \\\"{x:851,y:590,t:1526667164810};\\\", \\\"{x:848,y:590,t:1526667164827};\\\", \\\"{x:844,y:588,t:1526667164844};\\\", \\\"{x:843,y:588,t:1526667164860};\\\", \\\"{x:841,y:588,t:1526667164877};\\\", \\\"{x:840,y:588,t:1526667164893};\\\", \\\"{x:838,y:588,t:1526667164966};\\\", \\\"{x:837,y:588,t:1526667164982};\\\", \\\"{x:835,y:588,t:1526667165006};\\\", \\\"{x:834,y:588,t:1526667165014};\\\", \\\"{x:833,y:588,t:1526667165028};\\\", \\\"{x:833,y:590,t:1526667165044};\\\", \\\"{x:832,y:591,t:1526667165078};\\\", \\\"{x:828,y:592,t:1526667165429};\\\", \\\"{x:815,y:597,t:1526667165438};\\\", \\\"{x:810,y:600,t:1526667165451};\\\", \\\"{x:757,y:605,t:1526667165467};\\\", \\\"{x:670,y:610,t:1526667165484};\\\", \\\"{x:570,y:610,t:1526667165500};\\\", \\\"{x:461,y:610,t:1526667165518};\\\", \\\"{x:416,y:610,t:1526667165533};\\\", \\\"{x:378,y:613,t:1526667165550};\\\", \\\"{x:363,y:613,t:1526667165567};\\\", \\\"{x:354,y:615,t:1526667165583};\\\", \\\"{x:351,y:616,t:1526667165601};\\\", \\\"{x:349,y:617,t:1526667165617};\\\", \\\"{x:342,y:623,t:1526667165634};\\\", \\\"{x:330,y:630,t:1526667165650};\\\", \\\"{x:314,y:635,t:1526667165668};\\\", \\\"{x:297,y:638,t:1526667165683};\\\", \\\"{x:288,y:639,t:1526667165700};\\\", \\\"{x:263,y:639,t:1526667165718};\\\", \\\"{x:234,y:639,t:1526667165734};\\\", \\\"{x:212,y:639,t:1526667165750};\\\", \\\"{x:199,y:640,t:1526667165767};\\\", \\\"{x:187,y:639,t:1526667165784};\\\", \\\"{x:179,y:638,t:1526667165800};\\\", \\\"{x:176,y:637,t:1526667165817};\\\", \\\"{x:174,y:637,t:1526667165833};\\\", \\\"{x:171,y:637,t:1526667166015};\\\", \\\"{x:167,y:637,t:1526667166022};\\\", \\\"{x:165,y:637,t:1526667166033};\\\", \\\"{x:160,y:637,t:1526667166050};\\\", \\\"{x:159,y:637,t:1526667166068};\\\", \\\"{x:159,y:636,t:1526667166398};\\\", \\\"{x:160,y:634,t:1526667166405};\\\", \\\"{x:166,y:632,t:1526667166417};\\\", \\\"{x:179,y:628,t:1526667166435};\\\", \\\"{x:194,y:623,t:1526667166451};\\\", \\\"{x:218,y:610,t:1526667166468};\\\", \\\"{x:248,y:595,t:1526667166485};\\\", \\\"{x:333,y:567,t:1526667166503};\\\", \\\"{x:362,y:555,t:1526667166518};\\\", \\\"{x:481,y:535,t:1526667166535};\\\", \\\"{x:550,y:526,t:1526667166552};\\\", \\\"{x:606,y:518,t:1526667166567};\\\", \\\"{x:640,y:517,t:1526667166584};\\\", \\\"{x:658,y:516,t:1526667166601};\\\", \\\"{x:666,y:516,t:1526667166617};\\\", \\\"{x:668,y:516,t:1526667166634};\\\", \\\"{x:670,y:518,t:1526667166694};\\\", \\\"{x:673,y:528,t:1526667166702};\\\", \\\"{x:681,y:553,t:1526667166719};\\\", \\\"{x:687,y:577,t:1526667166734};\\\", \\\"{x:690,y:587,t:1526667166752};\\\", \\\"{x:690,y:594,t:1526667166769};\\\", \\\"{x:690,y:597,t:1526667166785};\\\", \\\"{x:690,y:601,t:1526667166801};\\\", \\\"{x:686,y:603,t:1526667166818};\\\", \\\"{x:675,y:604,t:1526667166834};\\\", \\\"{x:666,y:605,t:1526667166851};\\\", \\\"{x:647,y:609,t:1526667166868};\\\", \\\"{x:627,y:609,t:1526667166884};\\\", \\\"{x:601,y:609,t:1526667166901};\\\", \\\"{x:587,y:608,t:1526667166917};\\\", \\\"{x:578,y:606,t:1526667166935};\\\", \\\"{x:573,y:603,t:1526667166951};\\\", \\\"{x:572,y:603,t:1526667166969};\\\", \\\"{x:571,y:603,t:1526667166985};\\\", \\\"{x:571,y:602,t:1526667167095};\\\", \\\"{x:575,y:600,t:1526667167110};\\\", \\\"{x:580,y:599,t:1526667167118};\\\", \\\"{x:586,y:599,t:1526667167135};\\\", \\\"{x:596,y:598,t:1526667167151};\\\", \\\"{x:600,y:596,t:1526667167169};\\\", \\\"{x:602,y:596,t:1526667167185};\\\", \\\"{x:603,y:596,t:1526667167201};\\\", \\\"{x:605,y:596,t:1526667167238};\\\", \\\"{x:609,y:596,t:1526667167251};\\\", \\\"{x:615,y:598,t:1526667167268};\\\", \\\"{x:622,y:600,t:1526667167286};\\\", \\\"{x:624,y:600,t:1526667167998};\\\", \\\"{x:630,y:602,t:1526667168006};\\\", \\\"{x:633,y:606,t:1526667168019};\\\", \\\"{x:658,y:613,t:1526667168038};\\\", \\\"{x:698,y:625,t:1526667168053};\\\", \\\"{x:775,y:641,t:1526667168069};\\\", \\\"{x:952,y:672,t:1526667168086};\\\", \\\"{x:1075,y:695,t:1526667168103};\\\", \\\"{x:1209,y:723,t:1526667168119};\\\", \\\"{x:1341,y:755,t:1526667168135};\\\", \\\"{x:1479,y:791,t:1526667168152};\\\", \\\"{x:1595,y:825,t:1526667168169};\\\", \\\"{x:1675,y:847,t:1526667168185};\\\", \\\"{x:1707,y:862,t:1526667168203};\\\", \\\"{x:1721,y:872,t:1526667168219};\\\", \\\"{x:1727,y:880,t:1526667168236};\\\", \\\"{x:1727,y:884,t:1526667168252};\\\", \\\"{x:1727,y:892,t:1526667168269};\\\", \\\"{x:1722,y:903,t:1526667168286};\\\", \\\"{x:1714,y:915,t:1526667168303};\\\", \\\"{x:1702,y:929,t:1526667168320};\\\", \\\"{x:1688,y:941,t:1526667168336};\\\", \\\"{x:1677,y:948,t:1526667168352};\\\", \\\"{x:1667,y:956,t:1526667168369};\\\", \\\"{x:1657,y:960,t:1526667168386};\\\", \\\"{x:1648,y:960,t:1526667168403};\\\", \\\"{x:1636,y:960,t:1526667168419};\\\", \\\"{x:1618,y:957,t:1526667168436};\\\", \\\"{x:1595,y:948,t:1526667168453};\\\", \\\"{x:1564,y:936,t:1526667168470};\\\", \\\"{x:1555,y:934,t:1526667168486};\\\", \\\"{x:1543,y:930,t:1526667168502};\\\", \\\"{x:1536,y:929,t:1526667168520};\\\", \\\"{x:1533,y:929,t:1526667168535};\\\", \\\"{x:1528,y:927,t:1526667168552};\\\", \\\"{x:1526,y:927,t:1526667168574};\\\", \\\"{x:1524,y:927,t:1526667168590};\\\", \\\"{x:1521,y:927,t:1526667168606};\\\", \\\"{x:1519,y:927,t:1526667168619};\\\", \\\"{x:1515,y:928,t:1526667168637};\\\", \\\"{x:1512,y:930,t:1526667168653};\\\", \\\"{x:1508,y:932,t:1526667168670};\\\", \\\"{x:1505,y:935,t:1526667168685};\\\", \\\"{x:1505,y:936,t:1526667168702};\\\", \\\"{x:1505,y:937,t:1526667168719};\\\", \\\"{x:1501,y:941,t:1526667168736};\\\", \\\"{x:1498,y:944,t:1526667168753};\\\", \\\"{x:1495,y:946,t:1526667168770};\\\", \\\"{x:1493,y:948,t:1526667168787};\\\", \\\"{x:1492,y:949,t:1526667168802};\\\", \\\"{x:1491,y:951,t:1526667168822};\\\", \\\"{x:1491,y:952,t:1526667168894};\\\", \\\"{x:1489,y:953,t:1526667168904};\\\", \\\"{x:1488,y:955,t:1526667168920};\\\", \\\"{x:1486,y:956,t:1526667168937};\\\", \\\"{x:1485,y:958,t:1526667168952};\\\", \\\"{x:1484,y:959,t:1526667168973};\\\", \\\"{x:1483,y:959,t:1526667168986};\\\", \\\"{x:1482,y:961,t:1526667169014};\\\", \\\"{x:1482,y:962,t:1526667169046};\\\", \\\"{x:1482,y:963,t:1526667169061};\\\", \\\"{x:1482,y:964,t:1526667169223};\\\", \\\"{x:1481,y:964,t:1526667169237};\\\", \\\"{x:1481,y:965,t:1526667169254};\\\", \\\"{x:1480,y:965,t:1526667169271};\\\", \\\"{x:1478,y:965,t:1526667171207};\\\", \\\"{x:1474,y:965,t:1526667171223};\\\", \\\"{x:1469,y:967,t:1526667171238};\\\", \\\"{x:1461,y:967,t:1526667171255};\\\", \\\"{x:1457,y:967,t:1526667171272};\\\", \\\"{x:1450,y:967,t:1526667171289};\\\", \\\"{x:1446,y:966,t:1526667171305};\\\", \\\"{x:1444,y:966,t:1526667171322};\\\", \\\"{x:1439,y:966,t:1526667171339};\\\", \\\"{x:1434,y:964,t:1526667171355};\\\", \\\"{x:1426,y:964,t:1526667171372};\\\", \\\"{x:1420,y:964,t:1526667171390};\\\", \\\"{x:1418,y:964,t:1526667171405};\\\", \\\"{x:1412,y:963,t:1526667171422};\\\", \\\"{x:1411,y:963,t:1526667171503};\\\", \\\"{x:1411,y:960,t:1526667171511};\\\", \\\"{x:1409,y:953,t:1526667171523};\\\", \\\"{x:1409,y:944,t:1526667171540};\\\", \\\"{x:1407,y:919,t:1526667171555};\\\", \\\"{x:1406,y:891,t:1526667171571};\\\", \\\"{x:1406,y:854,t:1526667171589};\\\", \\\"{x:1399,y:788,t:1526667171606};\\\", \\\"{x:1399,y:766,t:1526667171622};\\\", \\\"{x:1400,y:737,t:1526667171639};\\\", \\\"{x:1403,y:722,t:1526667171656};\\\", \\\"{x:1403,y:718,t:1526667171671};\\\", \\\"{x:1407,y:703,t:1526667171689};\\\", \\\"{x:1412,y:682,t:1526667171706};\\\", \\\"{x:1416,y:671,t:1526667171722};\\\", \\\"{x:1417,y:660,t:1526667171738};\\\", \\\"{x:1418,y:649,t:1526667171755};\\\", \\\"{x:1418,y:643,t:1526667171771};\\\", \\\"{x:1420,y:634,t:1526667171789};\\\", \\\"{x:1422,y:619,t:1526667171806};\\\", \\\"{x:1424,y:615,t:1526667171821};\\\", \\\"{x:1426,y:611,t:1526667171839};\\\", \\\"{x:1426,y:608,t:1526667171856};\\\", \\\"{x:1426,y:605,t:1526667171872};\\\", \\\"{x:1427,y:604,t:1526667171888};\\\", \\\"{x:1428,y:596,t:1526667171906};\\\", \\\"{x:1429,y:589,t:1526667171922};\\\", \\\"{x:1429,y:584,t:1526667171939};\\\", \\\"{x:1429,y:577,t:1526667171956};\\\", \\\"{x:1428,y:573,t:1526667171972};\\\", \\\"{x:1426,y:569,t:1526667171989};\\\", \\\"{x:1417,y:562,t:1526667172006};\\\", \\\"{x:1411,y:557,t:1526667172023};\\\", \\\"{x:1408,y:555,t:1526667172039};\\\", \\\"{x:1407,y:554,t:1526667172055};\\\", \\\"{x:1407,y:557,t:1526667172263};\\\", \\\"{x:1407,y:558,t:1526667172273};\\\", \\\"{x:1407,y:560,t:1526667172289};\\\", \\\"{x:1408,y:561,t:1526667172306};\\\", \\\"{x:1411,y:567,t:1526667177022};\\\", \\\"{x:1422,y:597,t:1526667177044};\\\", \\\"{x:1432,y:619,t:1526667177060};\\\", \\\"{x:1443,y:641,t:1526667177076};\\\", \\\"{x:1453,y:654,t:1526667177093};\\\", \\\"{x:1456,y:668,t:1526667177110};\\\", \\\"{x:1458,y:676,t:1526667177126};\\\", \\\"{x:1459,y:692,t:1526667177143};\\\", \\\"{x:1458,y:711,t:1526667177160};\\\", \\\"{x:1455,y:729,t:1526667177176};\\\", \\\"{x:1450,y:746,t:1526667177194};\\\", \\\"{x:1445,y:763,t:1526667177210};\\\", \\\"{x:1442,y:782,t:1526667177226};\\\", \\\"{x:1440,y:801,t:1526667177243};\\\", \\\"{x:1440,y:813,t:1526667177261};\\\", \\\"{x:1440,y:825,t:1526667177277};\\\", \\\"{x:1439,y:837,t:1526667177293};\\\", \\\"{x:1438,y:853,t:1526667177310};\\\", \\\"{x:1438,y:866,t:1526667177327};\\\", \\\"{x:1439,y:875,t:1526667177343};\\\", \\\"{x:1442,y:883,t:1526667177360};\\\", \\\"{x:1448,y:889,t:1526667177377};\\\", \\\"{x:1457,y:898,t:1526667177393};\\\", \\\"{x:1463,y:904,t:1526667177410};\\\", \\\"{x:1473,y:912,t:1526667177427};\\\", \\\"{x:1486,y:924,t:1526667177442};\\\", \\\"{x:1491,y:930,t:1526667177460};\\\", \\\"{x:1506,y:942,t:1526667177477};\\\", \\\"{x:1520,y:956,t:1526667177493};\\\", \\\"{x:1536,y:970,t:1526667177510};\\\", \\\"{x:1538,y:970,t:1526667177527};\\\", \\\"{x:1535,y:973,t:1526667177599};\\\", \\\"{x:1527,y:973,t:1526667177610};\\\", \\\"{x:1513,y:974,t:1526667177627};\\\", \\\"{x:1505,y:974,t:1526667177643};\\\", \\\"{x:1496,y:974,t:1526667177660};\\\", \\\"{x:1489,y:976,t:1526667177677};\\\", \\\"{x:1485,y:976,t:1526667177694};\\\", \\\"{x:1483,y:976,t:1526667177710};\\\", \\\"{x:1481,y:976,t:1526667177791};\\\", \\\"{x:1479,y:976,t:1526667177797};\\\", \\\"{x:1476,y:976,t:1526667177810};\\\", \\\"{x:1468,y:973,t:1526667177826};\\\", \\\"{x:1451,y:968,t:1526667177844};\\\", \\\"{x:1434,y:963,t:1526667177860};\\\", \\\"{x:1425,y:962,t:1526667177877};\\\", \\\"{x:1417,y:959,t:1526667177893};\\\", \\\"{x:1412,y:958,t:1526667177910};\\\", \\\"{x:1410,y:957,t:1526667177927};\\\", \\\"{x:1409,y:957,t:1526667177944};\\\", \\\"{x:1408,y:957,t:1526667177960};\\\", \\\"{x:1407,y:957,t:1526667177982};\\\", \\\"{x:1406,y:957,t:1526667177994};\\\", \\\"{x:1404,y:957,t:1526667178010};\\\", \\\"{x:1401,y:957,t:1526667178027};\\\", \\\"{x:1400,y:957,t:1526667178044};\\\", \\\"{x:1398,y:957,t:1526667178060};\\\", \\\"{x:1397,y:957,t:1526667178077};\\\", \\\"{x:1396,y:959,t:1526667178093};\\\", \\\"{x:1395,y:960,t:1526667178110};\\\", \\\"{x:1393,y:963,t:1526667178128};\\\", \\\"{x:1389,y:965,t:1526667178145};\\\", \\\"{x:1386,y:966,t:1526667178161};\\\", \\\"{x:1384,y:967,t:1526667178177};\\\", \\\"{x:1383,y:968,t:1526667178194};\\\", \\\"{x:1382,y:969,t:1526667178239};\\\", \\\"{x:1381,y:969,t:1526667178310};\\\", \\\"{x:1381,y:968,t:1526667178487};\\\", \\\"{x:1381,y:967,t:1526667178502};\\\", \\\"{x:1382,y:966,t:1526667178518};\\\", \\\"{x:1384,y:965,t:1526667178535};\\\", \\\"{x:1386,y:964,t:1526667178551};\\\", \\\"{x:1387,y:964,t:1526667178561};\\\", \\\"{x:1389,y:962,t:1526667178578};\\\", \\\"{x:1391,y:961,t:1526667178595};\\\", \\\"{x:1392,y:959,t:1526667178612};\\\", \\\"{x:1396,y:957,t:1526667178629};\\\", \\\"{x:1400,y:954,t:1526667178645};\\\", \\\"{x:1405,y:944,t:1526667178662};\\\", \\\"{x:1410,y:928,t:1526667178679};\\\", \\\"{x:1413,y:923,t:1526667178694};\\\", \\\"{x:1414,y:916,t:1526667178712};\\\", \\\"{x:1414,y:909,t:1526667178729};\\\", \\\"{x:1414,y:899,t:1526667178744};\\\", \\\"{x:1409,y:880,t:1526667178761};\\\", \\\"{x:1400,y:867,t:1526667178781};\\\", \\\"{x:1395,y:856,t:1526667178794};\\\", \\\"{x:1390,y:842,t:1526667178811};\\\", \\\"{x:1388,y:832,t:1526667178828};\\\", \\\"{x:1384,y:817,t:1526667178844};\\\", \\\"{x:1383,y:807,t:1526667178861};\\\", \\\"{x:1383,y:793,t:1526667178877};\\\", \\\"{x:1383,y:791,t:1526667178894};\\\", \\\"{x:1383,y:789,t:1526667178910};\\\", \\\"{x:1383,y:787,t:1526667178928};\\\", \\\"{x:1383,y:785,t:1526667178949};\\\", \\\"{x:1384,y:783,t:1526667178961};\\\", \\\"{x:1385,y:781,t:1526667178989};\\\", \\\"{x:1385,y:780,t:1526667179103};\\\", \\\"{x:1385,y:782,t:1526667179111};\\\", \\\"{x:1385,y:794,t:1526667179128};\\\", \\\"{x:1383,y:811,t:1526667179145};\\\", \\\"{x:1381,y:829,t:1526667179161};\\\", \\\"{x:1381,y:842,t:1526667179179};\\\", \\\"{x:1381,y:857,t:1526667179195};\\\", \\\"{x:1381,y:871,t:1526667179212};\\\", \\\"{x:1381,y:883,t:1526667179228};\\\", \\\"{x:1381,y:893,t:1526667179246};\\\", \\\"{x:1380,y:899,t:1526667179262};\\\", \\\"{x:1378,y:907,t:1526667179279};\\\", \\\"{x:1376,y:915,t:1526667179296};\\\", \\\"{x:1373,y:928,t:1526667179311};\\\", \\\"{x:1370,y:940,t:1526667179328};\\\", \\\"{x:1369,y:942,t:1526667179345};\\\", \\\"{x:1367,y:947,t:1526667179361};\\\", \\\"{x:1367,y:950,t:1526667179379};\\\", \\\"{x:1367,y:953,t:1526667179395};\\\", \\\"{x:1366,y:957,t:1526667179412};\\\", \\\"{x:1365,y:961,t:1526667179429};\\\", \\\"{x:1365,y:965,t:1526667179445};\\\", \\\"{x:1365,y:968,t:1526667179462};\\\", \\\"{x:1365,y:969,t:1526667179509};\\\", \\\"{x:1366,y:971,t:1526667179525};\\\", \\\"{x:1367,y:971,t:1526667179541};\\\", \\\"{x:1369,y:971,t:1526667179549};\\\", \\\"{x:1370,y:971,t:1526667179562};\\\", \\\"{x:1374,y:971,t:1526667179578};\\\", \\\"{x:1376,y:971,t:1526667179595};\\\", \\\"{x:1377,y:971,t:1526667179669};\\\", \\\"{x:1378,y:971,t:1526667179685};\\\", \\\"{x:1380,y:970,t:1526667179702};\\\", \\\"{x:1381,y:966,t:1526667181063};\\\", \\\"{x:1349,y:947,t:1526667181080};\\\", \\\"{x:1262,y:920,t:1526667181096};\\\", \\\"{x:1177,y:884,t:1526667181113};\\\", \\\"{x:1053,y:854,t:1526667181129};\\\", \\\"{x:923,y:818,t:1526667181146};\\\", \\\"{x:796,y:780,t:1526667181163};\\\", \\\"{x:705,y:757,t:1526667181181};\\\", \\\"{x:654,y:743,t:1526667181196};\\\", \\\"{x:626,y:731,t:1526667181213};\\\", \\\"{x:619,y:724,t:1526667181229};\\\", \\\"{x:619,y:722,t:1526667181253};\\\", \\\"{x:619,y:720,t:1526667181269};\\\", \\\"{x:618,y:719,t:1526667181293};\\\", \\\"{x:617,y:714,t:1526667181301};\\\", \\\"{x:614,y:708,t:1526667181313};\\\", \\\"{x:603,y:699,t:1526667181330};\\\", \\\"{x:593,y:696,t:1526667181346};\\\", \\\"{x:588,y:695,t:1526667181363};\\\", \\\"{x:586,y:695,t:1526667181414};\\\", \\\"{x:583,y:695,t:1526667181430};\\\", \\\"{x:578,y:697,t:1526667181446};\\\", \\\"{x:566,y:704,t:1526667181463};\\\", \\\"{x:557,y:708,t:1526667181480};\\\", \\\"{x:549,y:711,t:1526667181496};\\\", \\\"{x:544,y:712,t:1526667181512};\\\", \\\"{x:541,y:713,t:1526667181530};\\\", \\\"{x:538,y:715,t:1526667181544};\\\", \\\"{x:534,y:717,t:1526667181559};\\\", \\\"{x:531,y:718,t:1526667181576};\\\", \\\"{x:528,y:720,t:1526667181594};\\\", \\\"{x:527,y:720,t:1526667181637};\\\" ] }, { \\\"rt\\\": 43930, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 337389, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"HWJDK\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"men\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"diagonal\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -A -11:30-I -I -12 PM-12 PM-12:30-01 PM-02 PM-03 PM-04 PM-05 PM-05:30-06:30-06:30-06:30-F -12:30-01 PM-02:30-K \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:529,y:720,t:1526667184079};\\\", \\\"{x:542,y:720,t:1526667184086};\\\", \\\"{x:561,y:721,t:1526667184098};\\\", \\\"{x:602,y:721,t:1526667184116};\\\", \\\"{x:645,y:721,t:1526667184132};\\\", \\\"{x:674,y:725,t:1526667184148};\\\", \\\"{x:703,y:731,t:1526667184164};\\\", \\\"{x:740,y:737,t:1526667184182};\\\", \\\"{x:761,y:740,t:1526667184199};\\\", \\\"{x:779,y:743,t:1526667184215};\\\", \\\"{x:787,y:746,t:1526667184232};\\\", \\\"{x:788,y:746,t:1526667184253};\\\", \\\"{x:796,y:746,t:1526667193580};\\\", \\\"{x:805,y:746,t:1526667193588};\\\", \\\"{x:822,y:746,t:1526667193602};\\\", \\\"{x:848,y:746,t:1526667193618};\\\", \\\"{x:924,y:740,t:1526667193635};\\\", \\\"{x:999,y:740,t:1526667193652};\\\", \\\"{x:1066,y:740,t:1526667193669};\\\", \\\"{x:1109,y:740,t:1526667193685};\\\", \\\"{x:1168,y:747,t:1526667193702};\\\", \\\"{x:1222,y:750,t:1526667193719};\\\", \\\"{x:1272,y:758,t:1526667193736};\\\", \\\"{x:1312,y:763,t:1526667193753};\\\", \\\"{x:1344,y:766,t:1526667193769};\\\", \\\"{x:1364,y:766,t:1526667193786};\\\", \\\"{x:1387,y:766,t:1526667193802};\\\", \\\"{x:1409,y:763,t:1526667193819};\\\", \\\"{x:1440,y:758,t:1526667193836};\\\", \\\"{x:1463,y:756,t:1526667193852};\\\", \\\"{x:1485,y:750,t:1526667193868};\\\", \\\"{x:1504,y:745,t:1526667193886};\\\", \\\"{x:1522,y:738,t:1526667193903};\\\", \\\"{x:1541,y:729,t:1526667193919};\\\", \\\"{x:1554,y:725,t:1526667193936};\\\", \\\"{x:1565,y:715,t:1526667193953};\\\", \\\"{x:1580,y:704,t:1526667193968};\\\", \\\"{x:1600,y:696,t:1526667193986};\\\", \\\"{x:1626,y:684,t:1526667194003};\\\", \\\"{x:1650,y:672,t:1526667194019};\\\", \\\"{x:1673,y:656,t:1526667194035};\\\", \\\"{x:1686,y:646,t:1526667194052};\\\", \\\"{x:1693,y:638,t:1526667194068};\\\", \\\"{x:1700,y:629,t:1526667194085};\\\", \\\"{x:1705,y:619,t:1526667194102};\\\", \\\"{x:1707,y:611,t:1526667194119};\\\", \\\"{x:1709,y:602,t:1526667194136};\\\", \\\"{x:1711,y:593,t:1526667194153};\\\", \\\"{x:1711,y:589,t:1526667194169};\\\", \\\"{x:1711,y:581,t:1526667194186};\\\", \\\"{x:1708,y:572,t:1526667194203};\\\", \\\"{x:1700,y:563,t:1526667194219};\\\", \\\"{x:1683,y:553,t:1526667194236};\\\", \\\"{x:1669,y:547,t:1526667194253};\\\", \\\"{x:1657,y:545,t:1526667194268};\\\", \\\"{x:1653,y:541,t:1526667194286};\\\", \\\"{x:1638,y:538,t:1526667194303};\\\", \\\"{x:1617,y:537,t:1526667194319};\\\", \\\"{x:1598,y:533,t:1526667194336};\\\", \\\"{x:1584,y:533,t:1526667194353};\\\", \\\"{x:1571,y:535,t:1526667194369};\\\", \\\"{x:1562,y:538,t:1526667194386};\\\", \\\"{x:1556,y:544,t:1526667194403};\\\", \\\"{x:1546,y:563,t:1526667194419};\\\", \\\"{x:1538,y:580,t:1526667194436};\\\", \\\"{x:1530,y:605,t:1526667194452};\\\", \\\"{x:1527,y:629,t:1526667194469};\\\", \\\"{x:1523,y:653,t:1526667194486};\\\", \\\"{x:1518,y:676,t:1526667194503};\\\", \\\"{x:1511,y:692,t:1526667194520};\\\", \\\"{x:1510,y:704,t:1526667194536};\\\", \\\"{x:1505,y:719,t:1526667194553};\\\", \\\"{x:1500,y:732,t:1526667194570};\\\", \\\"{x:1494,y:747,t:1526667194586};\\\", \\\"{x:1492,y:750,t:1526667194603};\\\", \\\"{x:1481,y:765,t:1526667194620};\\\", \\\"{x:1473,y:777,t:1526667194636};\\\", \\\"{x:1464,y:788,t:1526667194652};\\\", \\\"{x:1452,y:800,t:1526667194670};\\\", \\\"{x:1443,y:811,t:1526667194686};\\\", \\\"{x:1433,y:820,t:1526667194703};\\\", \\\"{x:1424,y:827,t:1526667194719};\\\", \\\"{x:1414,y:836,t:1526667194736};\\\", \\\"{x:1406,y:843,t:1526667194753};\\\", \\\"{x:1397,y:850,t:1526667194770};\\\", \\\"{x:1385,y:856,t:1526667194786};\\\", \\\"{x:1373,y:861,t:1526667194803};\\\", \\\"{x:1363,y:867,t:1526667194821};\\\", \\\"{x:1355,y:869,t:1526667194835};\\\", \\\"{x:1353,y:869,t:1526667194852};\\\", \\\"{x:1343,y:870,t:1526667194869};\\\", \\\"{x:1326,y:870,t:1526667194885};\\\", \\\"{x:1315,y:870,t:1526667194903};\\\", \\\"{x:1302,y:870,t:1526667194919};\\\", \\\"{x:1289,y:870,t:1526667194935};\\\", \\\"{x:1279,y:870,t:1526667194952};\\\", \\\"{x:1272,y:863,t:1526667194969};\\\", \\\"{x:1262,y:850,t:1526667194986};\\\", \\\"{x:1256,y:827,t:1526667195002};\\\", \\\"{x:1243,y:795,t:1526667195018};\\\", \\\"{x:1236,y:772,t:1526667195035};\\\", \\\"{x:1233,y:751,t:1526667195052};\\\", \\\"{x:1232,y:732,t:1526667195070};\\\", \\\"{x:1231,y:715,t:1526667195086};\\\", \\\"{x:1231,y:699,t:1526667195103};\\\", \\\"{x:1231,y:684,t:1526667195119};\\\", \\\"{x:1232,y:669,t:1526667195136};\\\", \\\"{x:1237,y:654,t:1526667195152};\\\", \\\"{x:1245,y:636,t:1526667195169};\\\", \\\"{x:1253,y:622,t:1526667195186};\\\", \\\"{x:1259,y:613,t:1526667195203};\\\", \\\"{x:1268,y:602,t:1526667195219};\\\", \\\"{x:1273,y:596,t:1526667195237};\\\", \\\"{x:1281,y:585,t:1526667195253};\\\", \\\"{x:1287,y:576,t:1526667195269};\\\", \\\"{x:1294,y:561,t:1526667195286};\\\", \\\"{x:1302,y:550,t:1526667195303};\\\", \\\"{x:1309,y:540,t:1526667195319};\\\", \\\"{x:1316,y:530,t:1526667195336};\\\", \\\"{x:1323,y:525,t:1526667195353};\\\", \\\"{x:1326,y:519,t:1526667195370};\\\", \\\"{x:1327,y:517,t:1526667195387};\\\", \\\"{x:1326,y:516,t:1526667195557};\\\", \\\"{x:1324,y:514,t:1526667195571};\\\", \\\"{x:1322,y:513,t:1526667195587};\\\", \\\"{x:1322,y:512,t:1526667195603};\\\", \\\"{x:1320,y:510,t:1526667195788};\\\", \\\"{x:1319,y:507,t:1526667195804};\\\", \\\"{x:1318,y:505,t:1526667195820};\\\", \\\"{x:1317,y:503,t:1526667195837};\\\", \\\"{x:1317,y:502,t:1526667195854};\\\", \\\"{x:1316,y:501,t:1526667195873};\\\", \\\"{x:1316,y:500,t:1526667196148};\\\", \\\"{x:1315,y:498,t:1526667196156};\\\", \\\"{x:1315,y:497,t:1526667196396};\\\", \\\"{x:1315,y:496,t:1526667196411};\\\", \\\"{x:1314,y:498,t:1526667197284};\\\", \\\"{x:1313,y:504,t:1526667197294};\\\", \\\"{x:1312,y:507,t:1526667197304};\\\", \\\"{x:1311,y:510,t:1526667197320};\\\", \\\"{x:1311,y:513,t:1526667197337};\\\", \\\"{x:1311,y:514,t:1526667197353};\\\", \\\"{x:1311,y:517,t:1526667197395};\\\", \\\"{x:1310,y:518,t:1526667197419};\\\", \\\"{x:1308,y:520,t:1526667197435};\\\", \\\"{x:1308,y:521,t:1526667197443};\\\", \\\"{x:1307,y:523,t:1526667197453};\\\", \\\"{x:1307,y:529,t:1526667197470};\\\", \\\"{x:1304,y:540,t:1526667197488};\\\", \\\"{x:1303,y:550,t:1526667197503};\\\", \\\"{x:1303,y:561,t:1526667197521};\\\", \\\"{x:1303,y:574,t:1526667197538};\\\", \\\"{x:1303,y:584,t:1526667197553};\\\", \\\"{x:1303,y:590,t:1526667197570};\\\", \\\"{x:1303,y:598,t:1526667197587};\\\", \\\"{x:1303,y:605,t:1526667197604};\\\", \\\"{x:1303,y:611,t:1526667197622};\\\", \\\"{x:1303,y:623,t:1526667197638};\\\", \\\"{x:1303,y:634,t:1526667197655};\\\", \\\"{x:1303,y:648,t:1526667197670};\\\", \\\"{x:1303,y:660,t:1526667197688};\\\", \\\"{x:1303,y:671,t:1526667197705};\\\", \\\"{x:1303,y:686,t:1526667197721};\\\", \\\"{x:1302,y:701,t:1526667197738};\\\", \\\"{x:1300,y:714,t:1526667197754};\\\", \\\"{x:1300,y:724,t:1526667197771};\\\", \\\"{x:1298,y:744,t:1526667197788};\\\", \\\"{x:1295,y:755,t:1526667197805};\\\", \\\"{x:1294,y:768,t:1526667197822};\\\", \\\"{x:1293,y:778,t:1526667197838};\\\", \\\"{x:1290,y:795,t:1526667197855};\\\", \\\"{x:1289,y:806,t:1526667197871};\\\", \\\"{x:1288,y:816,t:1526667197887};\\\", \\\"{x:1285,y:828,t:1526667197905};\\\", \\\"{x:1285,y:835,t:1526667197921};\\\", \\\"{x:1284,y:849,t:1526667197938};\\\", \\\"{x:1284,y:871,t:1526667197955};\\\", \\\"{x:1284,y:886,t:1526667197971};\\\", \\\"{x:1283,y:901,t:1526667197987};\\\", \\\"{x:1283,y:908,t:1526667198004};\\\", \\\"{x:1285,y:915,t:1526667198021};\\\", \\\"{x:1287,y:921,t:1526667198037};\\\", \\\"{x:1288,y:922,t:1526667198055};\\\", \\\"{x:1290,y:927,t:1526667198071};\\\", \\\"{x:1292,y:929,t:1526667198088};\\\", \\\"{x:1293,y:931,t:1526667198105};\\\", \\\"{x:1295,y:932,t:1526667198124};\\\", \\\"{x:1295,y:933,t:1526667198137};\\\", \\\"{x:1296,y:938,t:1526667198155};\\\", \\\"{x:1301,y:944,t:1526667198171};\\\", \\\"{x:1308,y:958,t:1526667198187};\\\", \\\"{x:1315,y:967,t:1526667198205};\\\", \\\"{x:1319,y:972,t:1526667198222};\\\", \\\"{x:1323,y:975,t:1526667198237};\\\", \\\"{x:1323,y:976,t:1526667198255};\\\", \\\"{x:1323,y:977,t:1526667198468};\\\", \\\"{x:1322,y:978,t:1526667198476};\\\", \\\"{x:1320,y:979,t:1526667198488};\\\", \\\"{x:1319,y:980,t:1526667198505};\\\", \\\"{x:1315,y:982,t:1526667198522};\\\", \\\"{x:1312,y:982,t:1526667198537};\\\", \\\"{x:1309,y:982,t:1526667198555};\\\", \\\"{x:1308,y:982,t:1526667198572};\\\", \\\"{x:1311,y:981,t:1526667198836};\\\", \\\"{x:1313,y:980,t:1526667198844};\\\", \\\"{x:1315,y:979,t:1526667198854};\\\", \\\"{x:1318,y:978,t:1526667198872};\\\", \\\"{x:1319,y:977,t:1526667198889};\\\", \\\"{x:1320,y:975,t:1526667199228};\\\", \\\"{x:1320,y:969,t:1526667199239};\\\", \\\"{x:1319,y:953,t:1526667199255};\\\", \\\"{x:1316,y:942,t:1526667199272};\\\", \\\"{x:1313,y:922,t:1526667199289};\\\", \\\"{x:1309,y:902,t:1526667199305};\\\", \\\"{x:1302,y:876,t:1526667199322};\\\", \\\"{x:1296,y:853,t:1526667199339};\\\", \\\"{x:1292,y:827,t:1526667199355};\\\", \\\"{x:1290,y:801,t:1526667199371};\\\", \\\"{x:1290,y:788,t:1526667199389};\\\", \\\"{x:1290,y:768,t:1526667199405};\\\", \\\"{x:1290,y:748,t:1526667199422};\\\", \\\"{x:1291,y:728,t:1526667199439};\\\", \\\"{x:1293,y:713,t:1526667199455};\\\", \\\"{x:1297,y:691,t:1526667199472};\\\", \\\"{x:1301,y:674,t:1526667199489};\\\", \\\"{x:1309,y:658,t:1526667199505};\\\", \\\"{x:1319,y:639,t:1526667199522};\\\", \\\"{x:1325,y:629,t:1526667199539};\\\", \\\"{x:1338,y:612,t:1526667199555};\\\", \\\"{x:1344,y:600,t:1526667199572};\\\", \\\"{x:1349,y:590,t:1526667199589};\\\", \\\"{x:1352,y:581,t:1526667199606};\\\", \\\"{x:1354,y:577,t:1526667199622};\\\", \\\"{x:1355,y:568,t:1526667199639};\\\", \\\"{x:1355,y:561,t:1526667199656};\\\", \\\"{x:1355,y:553,t:1526667199672};\\\", \\\"{x:1351,y:545,t:1526667199689};\\\", \\\"{x:1346,y:536,t:1526667199706};\\\", \\\"{x:1339,y:529,t:1526667199722};\\\", \\\"{x:1331,y:523,t:1526667199739};\\\", \\\"{x:1329,y:523,t:1526667199756};\\\", \\\"{x:1327,y:522,t:1526667199836};\\\", \\\"{x:1326,y:521,t:1526667199900};\\\", \\\"{x:1326,y:518,t:1526667199907};\\\", \\\"{x:1325,y:513,t:1526667199922};\\\", \\\"{x:1322,y:503,t:1526667199939};\\\", \\\"{x:1320,y:496,t:1526667199956};\\\", \\\"{x:1320,y:495,t:1526667199972};\\\", \\\"{x:1320,y:494,t:1526667199996};\\\", \\\"{x:1319,y:494,t:1526667200227};\\\", \\\"{x:1318,y:494,t:1526667200239};\\\", \\\"{x:1317,y:496,t:1526667200256};\\\", \\\"{x:1317,y:498,t:1526667200273};\\\", \\\"{x:1315,y:500,t:1526667200289};\\\", \\\"{x:1315,y:499,t:1526667200482};\\\", \\\"{x:1315,y:504,t:1526667201533};\\\", \\\"{x:1315,y:519,t:1526667201540};\\\", \\\"{x:1323,y:550,t:1526667201557};\\\", \\\"{x:1329,y:585,t:1526667201573};\\\", \\\"{x:1343,y:637,t:1526667201590};\\\", \\\"{x:1362,y:701,t:1526667201608};\\\", \\\"{x:1388,y:772,t:1526667201623};\\\", \\\"{x:1404,y:830,t:1526667201640};\\\", \\\"{x:1414,y:879,t:1526667201657};\\\", \\\"{x:1415,y:899,t:1526667201673};\\\", \\\"{x:1416,y:920,t:1526667201690};\\\", \\\"{x:1416,y:942,t:1526667201708};\\\", \\\"{x:1412,y:954,t:1526667201723};\\\", \\\"{x:1406,y:964,t:1526667201740};\\\", \\\"{x:1400,y:971,t:1526667201757};\\\", \\\"{x:1389,y:984,t:1526667201773};\\\", \\\"{x:1376,y:996,t:1526667201790};\\\", \\\"{x:1362,y:1006,t:1526667201807};\\\", \\\"{x:1354,y:1011,t:1526667201823};\\\", \\\"{x:1345,y:1014,t:1526667201840};\\\", \\\"{x:1333,y:1013,t:1526667201857};\\\", \\\"{x:1332,y:1011,t:1526667201873};\\\", \\\"{x:1331,y:1009,t:1526667201915};\\\", \\\"{x:1331,y:1006,t:1526667201931};\\\", \\\"{x:1332,y:1004,t:1526667201940};\\\", \\\"{x:1340,y:998,t:1526667201956};\\\", \\\"{x:1349,y:991,t:1526667201973};\\\", \\\"{x:1356,y:986,t:1526667201989};\\\", \\\"{x:1361,y:984,t:1526667202006};\\\", \\\"{x:1362,y:983,t:1526667202023};\\\", \\\"{x:1361,y:981,t:1526667202180};\\\", \\\"{x:1359,y:981,t:1526667202190};\\\", \\\"{x:1358,y:981,t:1526667202235};\\\", \\\"{x:1356,y:981,t:1526667202251};\\\", \\\"{x:1354,y:981,t:1526667202260};\\\", \\\"{x:1353,y:981,t:1526667202274};\\\", \\\"{x:1348,y:982,t:1526667202290};\\\", \\\"{x:1344,y:984,t:1526667202307};\\\", \\\"{x:1343,y:984,t:1526667202323};\\\", \\\"{x:1343,y:985,t:1526667202339};\\\", \\\"{x:1342,y:985,t:1526667202460};\\\", \\\"{x:1341,y:985,t:1526667202475};\\\", \\\"{x:1341,y:986,t:1526667202620};\\\", \\\"{x:1341,y:987,t:1526667202636};\\\", \\\"{x:1340,y:987,t:1526667202651};\\\", \\\"{x:1337,y:987,t:1526667202659};\\\", \\\"{x:1335,y:987,t:1526667202674};\\\", \\\"{x:1331,y:987,t:1526667202690};\\\", \\\"{x:1327,y:988,t:1526667202708};\\\", \\\"{x:1328,y:988,t:1526667202906};\\\", \\\"{x:1331,y:988,t:1526667202924};\\\", \\\"{x:1336,y:988,t:1526667202941};\\\", \\\"{x:1339,y:987,t:1526667202956};\\\", \\\"{x:1340,y:986,t:1526667203027};\\\", \\\"{x:1341,y:986,t:1526667203308};\\\", \\\"{x:1345,y:986,t:1526667203325};\\\", \\\"{x:1354,y:986,t:1526667203341};\\\", \\\"{x:1362,y:986,t:1526667203358};\\\", \\\"{x:1366,y:986,t:1526667203374};\\\", \\\"{x:1369,y:986,t:1526667203391};\\\", \\\"{x:1370,y:986,t:1526667203444};\\\", \\\"{x:1371,y:986,t:1526667203459};\\\", \\\"{x:1372,y:986,t:1526667203474};\\\", \\\"{x:1374,y:986,t:1526667203491};\\\", \\\"{x:1375,y:986,t:1526667203508};\\\", \\\"{x:1376,y:985,t:1526667203524};\\\", \\\"{x:1376,y:984,t:1526667203541};\\\", \\\"{x:1376,y:983,t:1526667203579};\\\", \\\"{x:1376,y:982,t:1526667203591};\\\", \\\"{x:1378,y:981,t:1526667203608};\\\", \\\"{x:1378,y:979,t:1526667203624};\\\", \\\"{x:1379,y:976,t:1526667203641};\\\", \\\"{x:1379,y:974,t:1526667203658};\\\", \\\"{x:1380,y:973,t:1526667203844};\\\", \\\"{x:1381,y:973,t:1526667203858};\\\", \\\"{x:1384,y:973,t:1526667203875};\\\", \\\"{x:1387,y:975,t:1526667203892};\\\", \\\"{x:1394,y:979,t:1526667203907};\\\", \\\"{x:1396,y:980,t:1526667203925};\\\", \\\"{x:1399,y:981,t:1526667203941};\\\", \\\"{x:1403,y:983,t:1526667203958};\\\", \\\"{x:1408,y:985,t:1526667203975};\\\", \\\"{x:1412,y:986,t:1526667203991};\\\", \\\"{x:1418,y:989,t:1526667204008};\\\", \\\"{x:1423,y:990,t:1526667204025};\\\", \\\"{x:1425,y:990,t:1526667204041};\\\", \\\"{x:1426,y:990,t:1526667204058};\\\", \\\"{x:1427,y:990,t:1526667204132};\\\", \\\"{x:1428,y:990,t:1526667204164};\\\", \\\"{x:1429,y:990,t:1526667204204};\\\", \\\"{x:1430,y:990,t:1526667204220};\\\", \\\"{x:1432,y:990,t:1526667204228};\\\", \\\"{x:1433,y:990,t:1526667204241};\\\", \\\"{x:1439,y:990,t:1526667204259};\\\", \\\"{x:1444,y:990,t:1526667204275};\\\", \\\"{x:1447,y:990,t:1526667204291};\\\", \\\"{x:1449,y:990,t:1526667204309};\\\", \\\"{x:1450,y:990,t:1526667204347};\\\", \\\"{x:1451,y:989,t:1526667204358};\\\", \\\"{x:1451,y:988,t:1526667204375};\\\", \\\"{x:1451,y:987,t:1526667204391};\\\", \\\"{x:1453,y:984,t:1526667204408};\\\", \\\"{x:1453,y:982,t:1526667204425};\\\", \\\"{x:1453,y:980,t:1526667204442};\\\", \\\"{x:1454,y:978,t:1526667204458};\\\", \\\"{x:1454,y:977,t:1526667204475};\\\", \\\"{x:1456,y:977,t:1526667204732};\\\", \\\"{x:1457,y:977,t:1526667204763};\\\", \\\"{x:1459,y:978,t:1526667204787};\\\", \\\"{x:1460,y:978,t:1526667204796};\\\", \\\"{x:1462,y:978,t:1526667204809};\\\", \\\"{x:1465,y:978,t:1526667204825};\\\", \\\"{x:1470,y:978,t:1526667204841};\\\", \\\"{x:1480,y:978,t:1526667204857};\\\", \\\"{x:1500,y:980,t:1526667204874};\\\", \\\"{x:1506,y:980,t:1526667204892};\\\", \\\"{x:1511,y:980,t:1526667204907};\\\", \\\"{x:1512,y:980,t:1526667204924};\\\", \\\"{x:1514,y:980,t:1526667205308};\\\", \\\"{x:1519,y:980,t:1526667205325};\\\", \\\"{x:1525,y:980,t:1526667205342};\\\", \\\"{x:1532,y:980,t:1526667205359};\\\", \\\"{x:1537,y:980,t:1526667205374};\\\", \\\"{x:1542,y:980,t:1526667205392};\\\", \\\"{x:1546,y:980,t:1526667205409};\\\", \\\"{x:1549,y:980,t:1526667205425};\\\", \\\"{x:1550,y:981,t:1526667205442};\\\", \\\"{x:1553,y:981,t:1526667205459};\\\", \\\"{x:1556,y:981,t:1526667205475};\\\", \\\"{x:1562,y:981,t:1526667205492};\\\", \\\"{x:1568,y:981,t:1526667205509};\\\", \\\"{x:1569,y:981,t:1526667205526};\\\", \\\"{x:1570,y:981,t:1526667205622};\\\", \\\"{x:1572,y:981,t:1526667205628};\\\", \\\"{x:1574,y:981,t:1526667205667};\\\", \\\"{x:1575,y:981,t:1526667205675};\\\", \\\"{x:1576,y:981,t:1526667205692};\\\", \\\"{x:1577,y:981,t:1526667205709};\\\", \\\"{x:1578,y:981,t:1526667205755};\\\", \\\"{x:1579,y:981,t:1526667205852};\\\", \\\"{x:1581,y:980,t:1526667205932};\\\", \\\"{x:1583,y:980,t:1526667205948};\\\", \\\"{x:1585,y:980,t:1526667205960};\\\", \\\"{x:1592,y:980,t:1526667205976};\\\", \\\"{x:1599,y:980,t:1526667205993};\\\", \\\"{x:1610,y:981,t:1526667206009};\\\", \\\"{x:1619,y:981,t:1526667206027};\\\", \\\"{x:1626,y:981,t:1526667206042};\\\", \\\"{x:1632,y:981,t:1526667206060};\\\", \\\"{x:1635,y:981,t:1526667206075};\\\", \\\"{x:1636,y:981,t:1526667206108};\\\", \\\"{x:1637,y:981,t:1526667206131};\\\", \\\"{x:1638,y:981,t:1526667206164};\\\", \\\"{x:1639,y:981,t:1526667206176};\\\", \\\"{x:1640,y:981,t:1526667206192};\\\", \\\"{x:1642,y:981,t:1526667206209};\\\", \\\"{x:1647,y:981,t:1526667206226};\\\", \\\"{x:1650,y:981,t:1526667206242};\\\", \\\"{x:1652,y:981,t:1526667206259};\\\", \\\"{x:1655,y:980,t:1526667206532};\\\", \\\"{x:1657,y:978,t:1526667206542};\\\", \\\"{x:1665,y:976,t:1526667206559};\\\", \\\"{x:1676,y:973,t:1526667206576};\\\", \\\"{x:1682,y:971,t:1526667206593};\\\", \\\"{x:1685,y:970,t:1526667206610};\\\", \\\"{x:1686,y:970,t:1526667206626};\\\", \\\"{x:1688,y:970,t:1526667206643};\\\", \\\"{x:1690,y:970,t:1526667206659};\\\", \\\"{x:1695,y:970,t:1526667206676};\\\", \\\"{x:1698,y:970,t:1526667206693};\\\", \\\"{x:1705,y:969,t:1526667206710};\\\", \\\"{x:1709,y:969,t:1526667206726};\\\", \\\"{x:1710,y:969,t:1526667206743};\\\", \\\"{x:1712,y:968,t:1526667206760};\\\", \\\"{x:1714,y:968,t:1526667206777};\\\", \\\"{x:1715,y:968,t:1526667206794};\\\", \\\"{x:1718,y:968,t:1526667207035};\\\", \\\"{x:1719,y:968,t:1526667207042};\\\", \\\"{x:1722,y:968,t:1526667207058};\\\", \\\"{x:1728,y:968,t:1526667207076};\\\", \\\"{x:1740,y:968,t:1526667207093};\\\", \\\"{x:1747,y:968,t:1526667207109};\\\", \\\"{x:1754,y:969,t:1526667207126};\\\", \\\"{x:1755,y:969,t:1526667207143};\\\", \\\"{x:1759,y:969,t:1526667207160};\\\", \\\"{x:1762,y:969,t:1526667207176};\\\", \\\"{x:1765,y:969,t:1526667207193};\\\", \\\"{x:1766,y:969,t:1526667207218};\\\", \\\"{x:1768,y:969,t:1526667207235};\\\", \\\"{x:1769,y:969,t:1526667207243};\\\", \\\"{x:1774,y:969,t:1526667207259};\\\", \\\"{x:1781,y:969,t:1526667207276};\\\", \\\"{x:1785,y:969,t:1526667207293};\\\", \\\"{x:1788,y:969,t:1526667207310};\\\", \\\"{x:1790,y:969,t:1526667207326};\\\", \\\"{x:1791,y:969,t:1526667207476};\\\", \\\"{x:1787,y:969,t:1526667207494};\\\", \\\"{x:1787,y:968,t:1526667207511};\\\", \\\"{x:1785,y:968,t:1526667207527};\\\", \\\"{x:1784,y:968,t:1526667207543};\\\", \\\"{x:1782,y:968,t:1526667207561};\\\", \\\"{x:1779,y:968,t:1526667207577};\\\", \\\"{x:1778,y:968,t:1526667207593};\\\", \\\"{x:1779,y:968,t:1526667208003};\\\", \\\"{x:1780,y:968,t:1526667208012};\\\", \\\"{x:1781,y:968,t:1526667208027};\\\", \\\"{x:1780,y:968,t:1526667209740};\\\", \\\"{x:1774,y:968,t:1526667209747};\\\", \\\"{x:1762,y:968,t:1526667209762};\\\", \\\"{x:1717,y:957,t:1526667209778};\\\", \\\"{x:1651,y:932,t:1526667209795};\\\", \\\"{x:1532,y:884,t:1526667209811};\\\", \\\"{x:1481,y:857,t:1526667209827};\\\", \\\"{x:1438,y:818,t:1526667209844};\\\", \\\"{x:1406,y:795,t:1526667209862};\\\", \\\"{x:1395,y:781,t:1526667209878};\\\", \\\"{x:1380,y:762,t:1526667209895};\\\", \\\"{x:1367,y:744,t:1526667209913};\\\", \\\"{x:1354,y:721,t:1526667209929};\\\", \\\"{x:1339,y:700,t:1526667209944};\\\", \\\"{x:1328,y:680,t:1526667209962};\\\", \\\"{x:1321,y:662,t:1526667209978};\\\", \\\"{x:1317,y:641,t:1526667209995};\\\", \\\"{x:1316,y:608,t:1526667210011};\\\", \\\"{x:1318,y:593,t:1526667210028};\\\", \\\"{x:1320,y:573,t:1526667210045};\\\", \\\"{x:1322,y:561,t:1526667210061};\\\", \\\"{x:1322,y:539,t:1526667210078};\\\", \\\"{x:1322,y:525,t:1526667210094};\\\", \\\"{x:1324,y:515,t:1526667210111};\\\", \\\"{x:1330,y:500,t:1526667210128};\\\", \\\"{x:1333,y:492,t:1526667210145};\\\", \\\"{x:1335,y:484,t:1526667210162};\\\", \\\"{x:1336,y:475,t:1526667210178};\\\", \\\"{x:1337,y:471,t:1526667210195};\\\", \\\"{x:1337,y:469,t:1526667210212};\\\", \\\"{x:1335,y:472,t:1526667210332};\\\", \\\"{x:1333,y:475,t:1526667210345};\\\", \\\"{x:1329,y:485,t:1526667210361};\\\", \\\"{x:1326,y:492,t:1526667210378};\\\", \\\"{x:1322,y:502,t:1526667210396};\\\", \\\"{x:1318,y:510,t:1526667210412};\\\", \\\"{x:1316,y:518,t:1526667210429};\\\", \\\"{x:1313,y:527,t:1526667210444};\\\", \\\"{x:1311,y:537,t:1526667210461};\\\", \\\"{x:1311,y:551,t:1526667210478};\\\", \\\"{x:1309,y:568,t:1526667210496};\\\", \\\"{x:1309,y:581,t:1526667210512};\\\", \\\"{x:1309,y:593,t:1526667210529};\\\", \\\"{x:1309,y:604,t:1526667210545};\\\", \\\"{x:1309,y:616,t:1526667210562};\\\", \\\"{x:1309,y:625,t:1526667210578};\\\", \\\"{x:1309,y:639,t:1526667210596};\\\", \\\"{x:1309,y:647,t:1526667210611};\\\", \\\"{x:1309,y:658,t:1526667210629};\\\", \\\"{x:1309,y:671,t:1526667210646};\\\", \\\"{x:1308,y:679,t:1526667210661};\\\", \\\"{x:1305,y:692,t:1526667210678};\\\", \\\"{x:1304,y:699,t:1526667210695};\\\", \\\"{x:1304,y:703,t:1526667210711};\\\", \\\"{x:1304,y:709,t:1526667210729};\\\", \\\"{x:1304,y:716,t:1526667210745};\\\", \\\"{x:1304,y:725,t:1526667210761};\\\", \\\"{x:1304,y:733,t:1526667210778};\\\", \\\"{x:1304,y:747,t:1526667210796};\\\", \\\"{x:1304,y:755,t:1526667210812};\\\", \\\"{x:1304,y:764,t:1526667210828};\\\", \\\"{x:1304,y:779,t:1526667210846};\\\", \\\"{x:1305,y:787,t:1526667210861};\\\", \\\"{x:1306,y:794,t:1526667210878};\\\", \\\"{x:1306,y:804,t:1526667210895};\\\", \\\"{x:1306,y:818,t:1526667210912};\\\", \\\"{x:1306,y:832,t:1526667210928};\\\", \\\"{x:1307,y:847,t:1526667210946};\\\", \\\"{x:1307,y:857,t:1526667210961};\\\", \\\"{x:1307,y:867,t:1526667210979};\\\", \\\"{x:1306,y:884,t:1526667210995};\\\", \\\"{x:1304,y:894,t:1526667211012};\\\", \\\"{x:1303,y:905,t:1526667211028};\\\", \\\"{x:1300,y:913,t:1526667211046};\\\", \\\"{x:1299,y:922,t:1526667211062};\\\", \\\"{x:1299,y:932,t:1526667211079};\\\", \\\"{x:1296,y:941,t:1526667211095};\\\", \\\"{x:1296,y:944,t:1526667211112};\\\", \\\"{x:1296,y:946,t:1526667211128};\\\", \\\"{x:1296,y:952,t:1526667211146};\\\", \\\"{x:1296,y:955,t:1526667211161};\\\", \\\"{x:1296,y:956,t:1526667211179};\\\", \\\"{x:1297,y:957,t:1526667211195};\\\", \\\"{x:1297,y:960,t:1526667211212};\\\", \\\"{x:1300,y:965,t:1526667211228};\\\", \\\"{x:1300,y:969,t:1526667211245};\\\", \\\"{x:1302,y:974,t:1526667211262};\\\", \\\"{x:1302,y:976,t:1526667211279};\\\", \\\"{x:1303,y:976,t:1526667211295};\\\", \\\"{x:1304,y:977,t:1526667211436};\\\", \\\"{x:1304,y:978,t:1526667211446};\\\", \\\"{x:1305,y:980,t:1526667211462};\\\", \\\"{x:1307,y:983,t:1526667211479};\\\", \\\"{x:1308,y:983,t:1526667211496};\\\", \\\"{x:1308,y:985,t:1526667211539};\\\", \\\"{x:1309,y:985,t:1526667211603};\\\", \\\"{x:1310,y:985,t:1526667211612};\\\", \\\"{x:1312,y:984,t:1526667211629};\\\", \\\"{x:1313,y:982,t:1526667211645};\\\", \\\"{x:1314,y:982,t:1526667211662};\\\", \\\"{x:1314,y:981,t:1526667211764};\\\", \\\"{x:1316,y:980,t:1526667211779};\\\", \\\"{x:1316,y:979,t:1526667211836};\\\", \\\"{x:1321,y:978,t:1526667217859};\\\", \\\"{x:1324,y:978,t:1526667217867};\\\", \\\"{x:1326,y:978,t:1526667217882};\\\", \\\"{x:1333,y:975,t:1526667217898};\\\", \\\"{x:1351,y:975,t:1526667217915};\\\", \\\"{x:1363,y:975,t:1526667217933};\\\", \\\"{x:1381,y:975,t:1526667217948};\\\", \\\"{x:1400,y:975,t:1526667217966};\\\", \\\"{x:1415,y:974,t:1526667217982};\\\", \\\"{x:1432,y:971,t:1526667217999};\\\", \\\"{x:1453,y:968,t:1526667218016};\\\", \\\"{x:1464,y:963,t:1526667218033};\\\", \\\"{x:1478,y:959,t:1526667218049};\\\", \\\"{x:1482,y:958,t:1526667218066};\\\", \\\"{x:1485,y:958,t:1526667218251};\\\", \\\"{x:1486,y:958,t:1526667218266};\\\", \\\"{x:1490,y:958,t:1526667218283};\\\", \\\"{x:1493,y:958,t:1526667218299};\\\", \\\"{x:1494,y:958,t:1526667218316};\\\", \\\"{x:1494,y:959,t:1526667218364};\\\", \\\"{x:1497,y:961,t:1526667218371};\\\", \\\"{x:1498,y:963,t:1526667218383};\\\", \\\"{x:1502,y:969,t:1526667218400};\\\", \\\"{x:1507,y:977,t:1526667218416};\\\", \\\"{x:1511,y:981,t:1526667218433};\\\", \\\"{x:1512,y:983,t:1526667218449};\\\", \\\"{x:1513,y:983,t:1526667218666};\\\", \\\"{x:1515,y:981,t:1526667218682};\\\", \\\"{x:1516,y:978,t:1526667218699};\\\", \\\"{x:1517,y:977,t:1526667218722};\\\", \\\"{x:1516,y:977,t:1526667218980};\\\", \\\"{x:1514,y:977,t:1526667219002};\\\", \\\"{x:1511,y:977,t:1526667219017};\\\", \\\"{x:1510,y:977,t:1526667219084};\\\", \\\"{x:1511,y:976,t:1526667220644};\\\", \\\"{x:1511,y:974,t:1526667220724};\\\", \\\"{x:1513,y:971,t:1526667220755};\\\", \\\"{x:1513,y:970,t:1526667220771};\\\", \\\"{x:1513,y:969,t:1526667220784};\\\", \\\"{x:1513,y:968,t:1526667220800};\\\", \\\"{x:1513,y:966,t:1526667220817};\\\", \\\"{x:1513,y:965,t:1526667220834};\\\", \\\"{x:1513,y:962,t:1526667220852};\\\", \\\"{x:1514,y:957,t:1526667220867};\\\", \\\"{x:1514,y:951,t:1526667220883};\\\", \\\"{x:1514,y:948,t:1526667220901};\\\", \\\"{x:1516,y:942,t:1526667220917};\\\", \\\"{x:1516,y:932,t:1526667220934};\\\", \\\"{x:1516,y:917,t:1526667220951};\\\", \\\"{x:1516,y:903,t:1526667220968};\\\", \\\"{x:1516,y:892,t:1526667220984};\\\", \\\"{x:1516,y:882,t:1526667221001};\\\", \\\"{x:1516,y:874,t:1526667221017};\\\", \\\"{x:1516,y:866,t:1526667221034};\\\", \\\"{x:1516,y:860,t:1526667221051};\\\", \\\"{x:1515,y:852,t:1526667221067};\\\", \\\"{x:1515,y:846,t:1526667221084};\\\", \\\"{x:1513,y:837,t:1526667221101};\\\", \\\"{x:1513,y:823,t:1526667221118};\\\", \\\"{x:1513,y:806,t:1526667221134};\\\", \\\"{x:1512,y:792,t:1526667221150};\\\", \\\"{x:1512,y:779,t:1526667221168};\\\", \\\"{x:1512,y:766,t:1526667221184};\\\", \\\"{x:1513,y:751,t:1526667221201};\\\", \\\"{x:1515,y:742,t:1526667221218};\\\", \\\"{x:1517,y:730,t:1526667221234};\\\", \\\"{x:1518,y:719,t:1526667221251};\\\", \\\"{x:1519,y:709,t:1526667221267};\\\", \\\"{x:1522,y:696,t:1526667221284};\\\", \\\"{x:1522,y:685,t:1526667221301};\\\", \\\"{x:1523,y:676,t:1526667221318};\\\", \\\"{x:1524,y:666,t:1526667221334};\\\", \\\"{x:1524,y:658,t:1526667221351};\\\", \\\"{x:1525,y:651,t:1526667221368};\\\", \\\"{x:1526,y:647,t:1526667221385};\\\", \\\"{x:1526,y:643,t:1526667221401};\\\", \\\"{x:1526,y:641,t:1526667221418};\\\", \\\"{x:1526,y:639,t:1526667221435};\\\", \\\"{x:1526,y:638,t:1526667221459};\\\", \\\"{x:1526,y:637,t:1526667221467};\\\", \\\"{x:1526,y:635,t:1526667221485};\\\", \\\"{x:1526,y:634,t:1526667221500};\\\", \\\"{x:1526,y:633,t:1526667221517};\\\", \\\"{x:1526,y:632,t:1526667221534};\\\", \\\"{x:1526,y:631,t:1526667221550};\\\", \\\"{x:1526,y:630,t:1526667221570};\\\", \\\"{x:1526,y:628,t:1526667221594};\\\", \\\"{x:1526,y:627,t:1526667221602};\\\", \\\"{x:1526,y:626,t:1526667221619};\\\", \\\"{x:1526,y:625,t:1526667221634};\\\", \\\"{x:1525,y:625,t:1526667221707};\\\", \\\"{x:1524,y:624,t:1526667222555};\\\", \\\"{x:1521,y:622,t:1526667222569};\\\", \\\"{x:1521,y:619,t:1526667222585};\\\", \\\"{x:1519,y:618,t:1526667222602};\\\", \\\"{x:1517,y:618,t:1526667222668};\\\", \\\"{x:1504,y:622,t:1526667222686};\\\", \\\"{x:1479,y:628,t:1526667222702};\\\", \\\"{x:1448,y:634,t:1526667222719};\\\", \\\"{x:1409,y:636,t:1526667222735};\\\", \\\"{x:1323,y:636,t:1526667222752};\\\", \\\"{x:1198,y:640,t:1526667222769};\\\", \\\"{x:1065,y:640,t:1526667222785};\\\", \\\"{x:969,y:631,t:1526667222802};\\\", \\\"{x:759,y:597,t:1526667222821};\\\", \\\"{x:640,y:576,t:1526667222835};\\\", \\\"{x:522,y:553,t:1526667222851};\\\", \\\"{x:393,y:523,t:1526667222879};\\\", \\\"{x:336,y:512,t:1526667222896};\\\", \\\"{x:317,y:509,t:1526667222911};\\\", \\\"{x:306,y:509,t:1526667222928};\\\", \\\"{x:303,y:509,t:1526667222945};\\\", \\\"{x:295,y:510,t:1526667222961};\\\", \\\"{x:286,y:517,t:1526667222978};\\\", \\\"{x:274,y:524,t:1526667222995};\\\", \\\"{x:265,y:534,t:1526667223012};\\\", \\\"{x:255,y:551,t:1526667223028};\\\", \\\"{x:249,y:563,t:1526667223046};\\\", \\\"{x:244,y:576,t:1526667223061};\\\", \\\"{x:241,y:582,t:1526667223078};\\\", \\\"{x:241,y:586,t:1526667223095};\\\", \\\"{x:241,y:588,t:1526667223122};\\\", \\\"{x:241,y:590,t:1526667223138};\\\", \\\"{x:242,y:593,t:1526667223146};\\\", \\\"{x:243,y:593,t:1526667223161};\\\", \\\"{x:250,y:597,t:1526667223178};\\\", \\\"{x:262,y:601,t:1526667223195};\\\", \\\"{x:282,y:605,t:1526667223212};\\\", \\\"{x:296,y:610,t:1526667223228};\\\", \\\"{x:305,y:611,t:1526667223245};\\\", \\\"{x:312,y:612,t:1526667223262};\\\", \\\"{x:316,y:612,t:1526667223278};\\\", \\\"{x:323,y:612,t:1526667223296};\\\", \\\"{x:338,y:612,t:1526667223312};\\\", \\\"{x:349,y:612,t:1526667223328};\\\", \\\"{x:356,y:612,t:1526667223345};\\\", \\\"{x:359,y:612,t:1526667223363};\\\", \\\"{x:360,y:612,t:1526667223435};\\\", \\\"{x:363,y:612,t:1526667223446};\\\", \\\"{x:365,y:612,t:1526667223462};\\\", \\\"{x:366,y:612,t:1526667223479};\\\", \\\"{x:367,y:612,t:1526667223515};\\\", \\\"{x:372,y:614,t:1526667223931};\\\", \\\"{x:377,y:614,t:1526667223946};\\\", \\\"{x:391,y:615,t:1526667223962};\\\", \\\"{x:393,y:615,t:1526667223979};\\\", \\\"{x:394,y:615,t:1526667223995};\\\", \\\"{x:395,y:618,t:1526667224347};\\\", \\\"{x:401,y:633,t:1526667224363};\\\", \\\"{x:413,y:652,t:1526667224379};\\\", \\\"{x:420,y:670,t:1526667224396};\\\", \\\"{x:431,y:689,t:1526667224412};\\\", \\\"{x:440,y:699,t:1526667224429};\\\", \\\"{x:447,y:704,t:1526667224446};\\\", \\\"{x:451,y:707,t:1526667224463};\\\", \\\"{x:453,y:709,t:1526667224479};\\\", \\\"{x:453,y:710,t:1526667224531};\\\", \\\"{x:454,y:712,t:1526667224547};\\\", \\\"{x:455,y:713,t:1526667224570};\\\", \\\"{x:456,y:715,t:1526667224595};\\\", \\\"{x:457,y:715,t:1526667224614};\\\", \\\"{x:457,y:716,t:1526667224629};\\\", \\\"{x:458,y:716,t:1526667224646};\\\", \\\"{x:458,y:717,t:1526667224682};\\\", \\\"{x:460,y:717,t:1526667224696};\\\", \\\"{x:461,y:718,t:1526667224713};\\\", \\\"{x:466,y:721,t:1526667224730};\\\", \\\"{x:471,y:724,t:1526667224747};\\\", \\\"{x:472,y:724,t:1526667224763};\\\", \\\"{x:474,y:725,t:1526667224780};\\\", \\\"{x:475,y:725,t:1526667224797};\\\", \\\"{x:478,y:728,t:1526667224867};\\\", \\\"{x:480,y:728,t:1526667224879};\\\", \\\"{x:483,y:730,t:1526667224897};\\\", \\\"{x:485,y:730,t:1526667224913};\\\", \\\"{x:486,y:731,t:1526667224930};\\\", \\\"{x:488,y:732,t:1526667224946};\\\" ] }, { \\\"rt\\\": 9777, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 348396, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"HWJDK\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"men\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"diagonal\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-G -6-E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:495,y:732,t:1526667229963};\\\", \\\"{x:513,y:736,t:1526667229983};\\\", \\\"{x:547,y:741,t:1526667230001};\\\", \\\"{x:582,y:746,t:1526667230017};\\\", \\\"{x:633,y:750,t:1526667230033};\\\", \\\"{x:715,y:759,t:1526667230050};\\\", \\\"{x:744,y:763,t:1526667230067};\\\", \\\"{x:768,y:763,t:1526667230085};\\\", \\\"{x:784,y:763,t:1526667230100};\\\", \\\"{x:788,y:762,t:1526667230118};\\\", \\\"{x:790,y:762,t:1526667230134};\\\", \\\"{x:791,y:761,t:1526667230178};\\\", \\\"{x:792,y:761,t:1526667230596};\\\", \\\"{x:792,y:760,t:1526667230603};\\\", \\\"{x:794,y:759,t:1526667230619};\\\", \\\"{x:797,y:758,t:1526667230636};\\\", \\\"{x:798,y:756,t:1526667230652};\\\", \\\"{x:799,y:755,t:1526667230669};\\\", \\\"{x:806,y:755,t:1526667231188};\\\", \\\"{x:839,y:755,t:1526667231204};\\\", \\\"{x:919,y:755,t:1526667231220};\\\", \\\"{x:1014,y:753,t:1526667231237};\\\", \\\"{x:1109,y:751,t:1526667231254};\\\", \\\"{x:1218,y:741,t:1526667231271};\\\", \\\"{x:1321,y:729,t:1526667231287};\\\", \\\"{x:1413,y:711,t:1526667231304};\\\", \\\"{x:1448,y:697,t:1526667231321};\\\", \\\"{x:1477,y:685,t:1526667231337};\\\", \\\"{x:1485,y:678,t:1526667231354};\\\", \\\"{x:1489,y:674,t:1526667231371};\\\", \\\"{x:1490,y:671,t:1526667231388};\\\", \\\"{x:1490,y:661,t:1526667231404};\\\", \\\"{x:1483,y:648,t:1526667231422};\\\", \\\"{x:1472,y:627,t:1526667231437};\\\", \\\"{x:1458,y:603,t:1526667231454};\\\", \\\"{x:1437,y:573,t:1526667231471};\\\", \\\"{x:1410,y:549,t:1526667231488};\\\", \\\"{x:1374,y:526,t:1526667231505};\\\", \\\"{x:1350,y:518,t:1526667231521};\\\", \\\"{x:1335,y:518,t:1526667231538};\\\", \\\"{x:1322,y:518,t:1526667231554};\\\", \\\"{x:1295,y:522,t:1526667231571};\\\", \\\"{x:1282,y:527,t:1526667231588};\\\", \\\"{x:1268,y:534,t:1526667231605};\\\", \\\"{x:1259,y:540,t:1526667231621};\\\", \\\"{x:1253,y:549,t:1526667231638};\\\", \\\"{x:1249,y:557,t:1526667231655};\\\", \\\"{x:1246,y:566,t:1526667231671};\\\", \\\"{x:1245,y:576,t:1526667231688};\\\", \\\"{x:1245,y:586,t:1526667231705};\\\", \\\"{x:1245,y:593,t:1526667231720};\\\", \\\"{x:1245,y:598,t:1526667231738};\\\", \\\"{x:1246,y:599,t:1526667231778};\\\", \\\"{x:1247,y:600,t:1526667231795};\\\", \\\"{x:1249,y:601,t:1526667231805};\\\", \\\"{x:1257,y:603,t:1526667231822};\\\", \\\"{x:1271,y:605,t:1526667231837};\\\", \\\"{x:1287,y:605,t:1526667231854};\\\", \\\"{x:1309,y:604,t:1526667231872};\\\", \\\"{x:1334,y:597,t:1526667231888};\\\", \\\"{x:1365,y:592,t:1526667231905};\\\", \\\"{x:1398,y:587,t:1526667231922};\\\", \\\"{x:1435,y:580,t:1526667231938};\\\", \\\"{x:1457,y:575,t:1526667231955};\\\", \\\"{x:1466,y:575,t:1526667231972};\\\", \\\"{x:1468,y:575,t:1526667231988};\\\", \\\"{x:1469,y:574,t:1526667232035};\\\", \\\"{x:1465,y:572,t:1526667232051};\\\", \\\"{x:1455,y:567,t:1526667232059};\\\", \\\"{x:1440,y:566,t:1526667232073};\\\", \\\"{x:1391,y:560,t:1526667232089};\\\", \\\"{x:1283,y:558,t:1526667232108};\\\", \\\"{x:1154,y:550,t:1526667232122};\\\", \\\"{x:927,y:548,t:1526667232139};\\\", \\\"{x:772,y:549,t:1526667232155};\\\", \\\"{x:697,y:546,t:1526667232169};\\\", \\\"{x:538,y:537,t:1526667232185};\\\", \\\"{x:356,y:525,t:1526667232203};\\\", \\\"{x:275,y:525,t:1526667232218};\\\", \\\"{x:248,y:525,t:1526667232236};\\\", \\\"{x:238,y:525,t:1526667232252};\\\", \\\"{x:234,y:525,t:1526667232269};\\\", \\\"{x:234,y:526,t:1526667232290};\\\", \\\"{x:234,y:528,t:1526667232302};\\\", \\\"{x:234,y:534,t:1526667232319};\\\", \\\"{x:234,y:537,t:1526667232335};\\\", \\\"{x:234,y:543,t:1526667232353};\\\", \\\"{x:232,y:550,t:1526667232369};\\\", \\\"{x:232,y:559,t:1526667232387};\\\", \\\"{x:232,y:562,t:1526667232402};\\\", \\\"{x:232,y:563,t:1526667232420};\\\", \\\"{x:232,y:566,t:1526667232442};\\\", \\\"{x:239,y:566,t:1526667232458};\\\", \\\"{x:248,y:566,t:1526667232469};\\\", \\\"{x:263,y:560,t:1526667232486};\\\", \\\"{x:283,y:552,t:1526667232503};\\\", \\\"{x:299,y:545,t:1526667232519};\\\", \\\"{x:317,y:538,t:1526667232536};\\\", \\\"{x:338,y:534,t:1526667232553};\\\", \\\"{x:380,y:531,t:1526667232569};\\\", \\\"{x:481,y:521,t:1526667232586};\\\", \\\"{x:550,y:514,t:1526667232603};\\\", \\\"{x:568,y:514,t:1526667232620};\\\", \\\"{x:587,y:511,t:1526667232635};\\\", \\\"{x:603,y:505,t:1526667232653};\\\", \\\"{x:606,y:504,t:1526667232670};\\\", \\\"{x:608,y:503,t:1526667232685};\\\", \\\"{x:613,y:503,t:1526667233170};\\\", \\\"{x:631,y:506,t:1526667233186};\\\", \\\"{x:667,y:512,t:1526667233204};\\\", \\\"{x:695,y:514,t:1526667233220};\\\", \\\"{x:706,y:516,t:1526667233237};\\\", \\\"{x:718,y:518,t:1526667233254};\\\", \\\"{x:736,y:524,t:1526667233269};\\\", \\\"{x:747,y:527,t:1526667233287};\\\", \\\"{x:750,y:528,t:1526667233303};\\\", \\\"{x:752,y:530,t:1526667233320};\\\", \\\"{x:752,y:531,t:1526667233419};\\\", \\\"{x:752,y:532,t:1526667233435};\\\", \\\"{x:752,y:533,t:1526667233443};\\\", \\\"{x:752,y:534,t:1526667233482};\\\", \\\"{x:753,y:534,t:1526667233490};\\\", \\\"{x:753,y:536,t:1526667233504};\\\", \\\"{x:759,y:536,t:1526667233521};\\\", \\\"{x:766,y:537,t:1526667233537};\\\", \\\"{x:781,y:538,t:1526667233554};\\\", \\\"{x:807,y:543,t:1526667233571};\\\", \\\"{x:827,y:543,t:1526667233588};\\\", \\\"{x:842,y:544,t:1526667233604};\\\", \\\"{x:852,y:544,t:1526667233620};\\\", \\\"{x:860,y:544,t:1526667233636};\\\", \\\"{x:861,y:543,t:1526667233787};\\\", \\\"{x:854,y:539,t:1526667233804};\\\", \\\"{x:840,y:537,t:1526667233822};\\\", \\\"{x:818,y:537,t:1526667233837};\\\", \\\"{x:808,y:537,t:1526667233854};\\\", \\\"{x:804,y:537,t:1526667233871};\\\", \\\"{x:802,y:538,t:1526667233887};\\\", \\\"{x:801,y:539,t:1526667234027};\\\", \\\"{x:804,y:539,t:1526667234037};\\\", \\\"{x:807,y:541,t:1526667234054};\\\", \\\"{x:808,y:543,t:1526667234075};\\\", \\\"{x:809,y:543,t:1526667234090};\\\", \\\"{x:810,y:544,t:1526667234106};\\\", \\\"{x:811,y:544,t:1526667234121};\\\", \\\"{x:811,y:545,t:1526667234138};\\\", \\\"{x:812,y:545,t:1526667234154};\\\", \\\"{x:814,y:545,t:1526667234171};\\\", \\\"{x:815,y:545,t:1526667234195};\\\", \\\"{x:816,y:545,t:1526667234204};\\\", \\\"{x:818,y:546,t:1526667234221};\\\", \\\"{x:821,y:548,t:1526667234238};\\\", \\\"{x:823,y:549,t:1526667234254};\\\", \\\"{x:825,y:549,t:1526667234272};\\\", \\\"{x:829,y:552,t:1526667234339};\\\", \\\"{x:830,y:552,t:1526667234354};\\\", \\\"{x:832,y:552,t:1526667234371};\\\", \\\"{x:831,y:553,t:1526667234931};\\\", \\\"{x:823,y:557,t:1526667234940};\\\", \\\"{x:807,y:566,t:1526667234954};\\\", \\\"{x:790,y:578,t:1526667234972};\\\", \\\"{x:773,y:589,t:1526667234988};\\\", \\\"{x:751,y:603,t:1526667235005};\\\", \\\"{x:728,y:619,t:1526667235022};\\\", \\\"{x:711,y:635,t:1526667235039};\\\", \\\"{x:697,y:649,t:1526667235054};\\\", \\\"{x:676,y:671,t:1526667235072};\\\", \\\"{x:659,y:689,t:1526667235088};\\\", \\\"{x:639,y:706,t:1526667235105};\\\", \\\"{x:623,y:722,t:1526667235122};\\\", \\\"{x:604,y:734,t:1526667235138};\\\", \\\"{x:587,y:751,t:1526667235155};\\\", \\\"{x:578,y:756,t:1526667235172};\\\", \\\"{x:570,y:759,t:1526667235188};\\\", \\\"{x:561,y:763,t:1526667235205};\\\", \\\"{x:557,y:765,t:1526667235222};\\\", \\\"{x:554,y:765,t:1526667235238};\\\", \\\"{x:553,y:765,t:1526667235255};\\\", \\\"{x:550,y:761,t:1526667235291};\\\", \\\"{x:548,y:757,t:1526667235306};\\\", \\\"{x:546,y:750,t:1526667235323};\\\", \\\"{x:536,y:734,t:1526667235339};\\\", \\\"{x:526,y:730,t:1526667235355};\\\", \\\"{x:519,y:724,t:1526667235371};\\\", \\\"{x:517,y:724,t:1526667235389};\\\", \\\"{x:515,y:724,t:1526667235404};\\\", \\\"{x:514,y:724,t:1526667235422};\\\", \\\"{x:513,y:724,t:1526667235643};\\\", \\\"{x:513,y:725,t:1526667235683};\\\", \\\"{x:513,y:726,t:1526667235724};\\\", \\\"{x:513,y:727,t:1526667235739};\\\", \\\"{x:512,y:728,t:1526667235756};\\\", \\\"{x:511,y:730,t:1526667235772};\\\", \\\"{x:510,y:732,t:1526667235789};\\\", \\\"{x:510,y:734,t:1526667235835};\\\", \\\"{x:510,y:735,t:1526667235842};\\\", \\\"{x:510,y:736,t:1526667235858};\\\", \\\"{x:513,y:737,t:1526667235872};\\\", \\\"{x:522,y:736,t:1526667235889};\\\", \\\"{x:546,y:725,t:1526667235906};\\\", \\\"{x:562,y:711,t:1526667235923};\\\", \\\"{x:606,y:687,t:1526667235939};\\\", \\\"{x:630,y:667,t:1526667235956};\\\", \\\"{x:650,y:647,t:1526667235972};\\\", \\\"{x:665,y:631,t:1526667235989};\\\", \\\"{x:676,y:619,t:1526667236005};\\\", \\\"{x:681,y:610,t:1526667236021};\\\", \\\"{x:682,y:607,t:1526667236039};\\\", \\\"{x:682,y:606,t:1526667236056};\\\", \\\"{x:683,y:605,t:1526667236073};\\\", \\\"{x:684,y:604,t:1526667236098};\\\", \\\"{x:684,y:603,t:1526667236105};\\\", \\\"{x:688,y:600,t:1526667236122};\\\", \\\"{x:692,y:596,t:1526667236139};\\\", \\\"{x:694,y:595,t:1526667236156};\\\", \\\"{x:700,y:593,t:1526667236174};\\\", \\\"{x:710,y:592,t:1526667236188};\\\", \\\"{x:725,y:587,t:1526667236207};\\\", \\\"{x:746,y:581,t:1526667236223};\\\", \\\"{x:767,y:577,t:1526667236238};\\\", \\\"{x:783,y:572,t:1526667236256};\\\", \\\"{x:786,y:570,t:1526667236273};\\\", \\\"{x:790,y:568,t:1526667236289};\\\", \\\"{x:790,y:567,t:1526667236347};\\\", \\\"{x:792,y:566,t:1526667236379};\\\", \\\"{x:792,y:564,t:1526667236395};\\\", \\\"{x:792,y:562,t:1526667236412};\\\", \\\"{x:793,y:560,t:1526667236426};\\\", \\\"{x:794,y:557,t:1526667236440};\\\", \\\"{x:797,y:553,t:1526667236456};\\\", \\\"{x:803,y:545,t:1526667236473};\\\", \\\"{x:805,y:544,t:1526667236489};\\\", \\\"{x:812,y:539,t:1526667236506};\\\", \\\"{x:813,y:539,t:1526667236523};\\\", \\\"{x:814,y:538,t:1526667236540};\\\", \\\"{x:816,y:537,t:1526667236556};\\\", \\\"{x:818,y:536,t:1526667236611};\\\", \\\"{x:819,y:536,t:1526667236626};\\\", \\\"{x:819,y:535,t:1526667236640};\\\", \\\"{x:820,y:535,t:1526667236779};\\\", \\\"{x:822,y:535,t:1526667236803};\\\", \\\"{x:825,y:535,t:1526667236827};\\\", \\\"{x:822,y:536,t:1526667237138};\\\", \\\"{x:815,y:544,t:1526667237156};\\\", \\\"{x:802,y:554,t:1526667237173};\\\", \\\"{x:781,y:573,t:1526667237190};\\\", \\\"{x:760,y:593,t:1526667237206};\\\", \\\"{x:744,y:606,t:1526667237223};\\\", \\\"{x:731,y:619,t:1526667237239};\\\", \\\"{x:711,y:630,t:1526667237257};\\\", \\\"{x:675,y:652,t:1526667237274};\\\", \\\"{x:651,y:665,t:1526667237290};\\\", \\\"{x:629,y:679,t:1526667237307};\\\", \\\"{x:612,y:689,t:1526667237323};\\\", \\\"{x:597,y:701,t:1526667237340};\\\", \\\"{x:577,y:711,t:1526667237357};\\\", \\\"{x:559,y:724,t:1526667237375};\\\", \\\"{x:542,y:732,t:1526667237390};\\\", \\\"{x:527,y:736,t:1526667237407};\\\", \\\"{x:516,y:744,t:1526667237423};\\\", \\\"{x:510,y:747,t:1526667237440};\\\", \\\"{x:504,y:748,t:1526667237456};\\\", \\\"{x:492,y:750,t:1526667237474};\\\", \\\"{x:489,y:751,t:1526667237490};\\\", \\\"{x:488,y:751,t:1526667237506};\\\", \\\"{x:487,y:751,t:1526667237523};\\\", \\\"{x:486,y:751,t:1526667237571};\\\", \\\"{x:485,y:751,t:1526667237651};\\\", \\\"{x:483,y:751,t:1526667237667};\\\", \\\"{x:481,y:752,t:1526667237674};\\\", \\\"{x:479,y:753,t:1526667237689};\\\", \\\"{x:475,y:755,t:1526667237707};\\\", \\\"{x:468,y:757,t:1526667237723};\\\", \\\"{x:466,y:759,t:1526667237740};\\\", \\\"{x:464,y:761,t:1526667237756};\\\", \\\"{x:463,y:761,t:1526667237774};\\\", \\\"{x:462,y:763,t:1526667237791};\\\", \\\"{x:460,y:764,t:1526667237807};\\\", \\\"{x:460,y:766,t:1526667237826};\\\", \\\"{x:459,y:767,t:1526667237840};\\\", \\\"{x:459,y:769,t:1526667237899};\\\", \\\"{x:459,y:771,t:1526667237915};\\\", \\\"{x:459,y:772,t:1526667237924};\\\", \\\"{x:460,y:773,t:1526667237979};\\\", \\\"{x:461,y:772,t:1526667237991};\\\", \\\"{x:462,y:769,t:1526667238008};\\\", \\\"{x:470,y:759,t:1526667238024};\\\", \\\"{x:480,y:748,t:1526667238042};\\\", \\\"{x:489,y:735,t:1526667238059};\\\", \\\"{x:493,y:730,t:1526667238074};\\\", \\\"{x:494,y:728,t:1526667238090};\\\" ] }, { \\\"rt\\\": 30695, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 380422, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"HWJDK\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"men\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"diagonal\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:494,y:727,t:1526667247716};\\\", \\\"{x:504,y:726,t:1526667247728};\\\", \\\"{x:534,y:732,t:1526667247744};\\\", \\\"{x:608,y:739,t:1526667247762};\\\", \\\"{x:697,y:751,t:1526667247778};\\\", \\\"{x:842,y:757,t:1526667247793};\\\", \\\"{x:931,y:759,t:1526667247810};\\\", \\\"{x:1012,y:759,t:1526667247832};\\\", \\\"{x:1057,y:760,t:1526667247848};\\\", \\\"{x:1092,y:760,t:1526667247865};\\\", \\\"{x:1119,y:759,t:1526667247882};\\\", \\\"{x:1128,y:757,t:1526667247898};\\\", \\\"{x:1134,y:755,t:1526667247915};\\\", \\\"{x:1138,y:754,t:1526667247932};\\\", \\\"{x:1143,y:751,t:1526667247948};\\\", \\\"{x:1145,y:750,t:1526667247965};\\\", \\\"{x:1146,y:750,t:1526667247995};\\\", \\\"{x:1148,y:750,t:1526667248027};\\\", \\\"{x:1153,y:751,t:1526667248034};\\\", \\\"{x:1156,y:755,t:1526667248049};\\\", \\\"{x:1164,y:760,t:1526667248065};\\\", \\\"{x:1173,y:771,t:1526667248082};\\\", \\\"{x:1176,y:774,t:1526667248100};\\\", \\\"{x:1176,y:780,t:1526667248116};\\\", \\\"{x:1178,y:795,t:1526667248132};\\\", \\\"{x:1181,y:808,t:1526667248150};\\\", \\\"{x:1181,y:815,t:1526667248165};\\\", \\\"{x:1181,y:816,t:1526667248182};\\\", \\\"{x:1181,y:818,t:1526667248199};\\\", \\\"{x:1181,y:819,t:1526667248216};\\\", \\\"{x:1181,y:820,t:1526667248232};\\\", \\\"{x:1181,y:821,t:1526667248249};\\\", \\\"{x:1179,y:823,t:1526667248306};\\\", \\\"{x:1176,y:823,t:1526667248321};\\\", \\\"{x:1173,y:827,t:1526667248332};\\\", \\\"{x:1170,y:831,t:1526667248349};\\\", \\\"{x:1168,y:833,t:1526667248366};\\\", \\\"{x:1166,y:834,t:1526667248383};\\\", \\\"{x:1166,y:836,t:1526667248399};\\\", \\\"{x:1164,y:836,t:1526667248433};\\\", \\\"{x:1163,y:838,t:1526667248449};\\\", \\\"{x:1161,y:840,t:1526667248466};\\\", \\\"{x:1158,y:843,t:1526667248482};\\\", \\\"{x:1158,y:844,t:1526667248499};\\\", \\\"{x:1156,y:844,t:1526667248516};\\\", \\\"{x:1155,y:844,t:1526667248546};\\\", \\\"{x:1154,y:844,t:1526667248553};\\\", \\\"{x:1153,y:844,t:1526667248566};\\\", \\\"{x:1152,y:844,t:1526667248582};\\\", \\\"{x:1150,y:844,t:1526667248599};\\\", \\\"{x:1147,y:844,t:1526667248616};\\\", \\\"{x:1145,y:844,t:1526667248633};\\\", \\\"{x:1143,y:843,t:1526667248649};\\\", \\\"{x:1140,y:843,t:1526667248714};\\\", \\\"{x:1139,y:843,t:1526667248738};\\\", \\\"{x:1139,y:842,t:1526667248749};\\\", \\\"{x:1138,y:841,t:1526667248810};\\\", \\\"{x:1138,y:839,t:1526667248826};\\\", \\\"{x:1138,y:838,t:1526667248842};\\\", \\\"{x:1138,y:836,t:1526667248858};\\\", \\\"{x:1138,y:834,t:1526667248874};\\\", \\\"{x:1138,y:833,t:1526667248883};\\\", \\\"{x:1139,y:832,t:1526667248899};\\\", \\\"{x:1142,y:829,t:1526667248916};\\\", \\\"{x:1143,y:829,t:1526667248933};\\\", \\\"{x:1147,y:827,t:1526667248949};\\\", \\\"{x:1150,y:821,t:1526667256488};\\\", \\\"{x:1158,y:805,t:1526667256505};\\\", \\\"{x:1171,y:790,t:1526667256522};\\\", \\\"{x:1188,y:770,t:1526667256538};\\\", \\\"{x:1203,y:753,t:1526667256555};\\\", \\\"{x:1207,y:745,t:1526667256572};\\\", \\\"{x:1219,y:722,t:1526667256588};\\\", \\\"{x:1242,y:659,t:1526667256605};\\\", \\\"{x:1255,y:634,t:1526667256622};\\\", \\\"{x:1262,y:620,t:1526667256638};\\\", \\\"{x:1268,y:605,t:1526667256655};\\\", \\\"{x:1273,y:593,t:1526667256672};\\\", \\\"{x:1274,y:590,t:1526667256688};\\\", \\\"{x:1275,y:587,t:1526667256705};\\\", \\\"{x:1276,y:587,t:1526667256722};\\\", \\\"{x:1276,y:586,t:1526667256739};\\\", \\\"{x:1276,y:583,t:1526667256784};\\\", \\\"{x:1276,y:580,t:1526667256801};\\\", \\\"{x:1276,y:579,t:1526667256817};\\\", \\\"{x:1276,y:578,t:1526667256824};\\\", \\\"{x:1276,y:577,t:1526667256839};\\\", \\\"{x:1274,y:577,t:1526667256896};\\\", \\\"{x:1272,y:581,t:1526667256905};\\\", \\\"{x:1264,y:599,t:1526667256922};\\\", \\\"{x:1259,y:615,t:1526667256939};\\\", \\\"{x:1256,y:630,t:1526667256955};\\\", \\\"{x:1254,y:642,t:1526667256973};\\\", \\\"{x:1252,y:648,t:1526667256989};\\\", \\\"{x:1251,y:651,t:1526667257005};\\\", \\\"{x:1251,y:652,t:1526667257022};\\\", \\\"{x:1250,y:653,t:1526667257056};\\\", \\\"{x:1248,y:649,t:1526667257209};\\\", \\\"{x:1248,y:647,t:1526667257222};\\\", \\\"{x:1246,y:641,t:1526667257239};\\\", \\\"{x:1246,y:639,t:1526667257431};\\\", \\\"{x:1246,y:637,t:1526667257447};\\\", \\\"{x:1246,y:636,t:1526667257455};\\\", \\\"{x:1247,y:632,t:1526667257472};\\\", \\\"{x:1249,y:628,t:1526667257488};\\\", \\\"{x:1249,y:627,t:1526667257592};\\\", \\\"{x:1248,y:627,t:1526667267087};\\\", \\\"{x:1238,y:628,t:1526667267098};\\\", \\\"{x:1215,y:639,t:1526667267114};\\\", \\\"{x:1186,y:646,t:1526667267130};\\\", \\\"{x:1156,y:662,t:1526667267148};\\\", \\\"{x:1103,y:670,t:1526667267164};\\\", \\\"{x:1050,y:676,t:1526667267181};\\\", \\\"{x:1018,y:677,t:1526667267197};\\\", \\\"{x:968,y:677,t:1526667267214};\\\", \\\"{x:920,y:677,t:1526667267231};\\\", \\\"{x:845,y:677,t:1526667267248};\\\", \\\"{x:817,y:683,t:1526667267264};\\\", \\\"{x:809,y:683,t:1526667267281};\\\", \\\"{x:808,y:683,t:1526667267298};\\\", \\\"{x:805,y:683,t:1526667267314};\\\", \\\"{x:801,y:683,t:1526667267331};\\\", \\\"{x:795,y:682,t:1526667267348};\\\", \\\"{x:782,y:677,t:1526667267365};\\\", \\\"{x:755,y:670,t:1526667267381};\\\", \\\"{x:709,y:653,t:1526667267398};\\\", \\\"{x:647,y:630,t:1526667267416};\\\", \\\"{x:558,y:603,t:1526667267431};\\\", \\\"{x:440,y:586,t:1526667267448};\\\", \\\"{x:430,y:579,t:1526667267463};\\\", \\\"{x:388,y:571,t:1526667267479};\\\", \\\"{x:358,y:562,t:1526667267496};\\\", \\\"{x:353,y:561,t:1526667267512};\\\", \\\"{x:351,y:561,t:1526667267529};\\\", \\\"{x:352,y:561,t:1526667267567};\\\", \\\"{x:362,y:563,t:1526667267580};\\\", \\\"{x:393,y:568,t:1526667267596};\\\", \\\"{x:413,y:568,t:1526667267612};\\\", \\\"{x:451,y:565,t:1526667267630};\\\", \\\"{x:476,y:562,t:1526667267646};\\\", \\\"{x:531,y:558,t:1526667267663};\\\", \\\"{x:599,y:552,t:1526667267679};\\\", \\\"{x:620,y:548,t:1526667267696};\\\", \\\"{x:631,y:546,t:1526667267712};\\\", \\\"{x:635,y:544,t:1526667267729};\\\", \\\"{x:636,y:544,t:1526667267746};\\\", \\\"{x:637,y:543,t:1526667267762};\\\", \\\"{x:639,y:543,t:1526667267783};\\\", \\\"{x:641,y:541,t:1526667267800};\\\", \\\"{x:643,y:538,t:1526667267813};\\\", \\\"{x:647,y:535,t:1526667267830};\\\", \\\"{x:666,y:527,t:1526667267846};\\\", \\\"{x:694,y:519,t:1526667267864};\\\", \\\"{x:719,y:511,t:1526667267879};\\\", \\\"{x:755,y:502,t:1526667267897};\\\", \\\"{x:769,y:497,t:1526667267913};\\\", \\\"{x:782,y:497,t:1526667267929};\\\", \\\"{x:803,y:497,t:1526667267946};\\\", \\\"{x:819,y:497,t:1526667267963};\\\", \\\"{x:828,y:497,t:1526667267980};\\\", \\\"{x:831,y:497,t:1526667267995};\\\", \\\"{x:832,y:498,t:1526667268152};\\\", \\\"{x:832,y:500,t:1526667268163};\\\", \\\"{x:833,y:502,t:1526667268180};\\\", \\\"{x:834,y:503,t:1526667268439};\\\", \\\"{x:832,y:506,t:1526667268447};\\\", \\\"{x:809,y:516,t:1526667268463};\\\", \\\"{x:781,y:529,t:1526667268480};\\\", \\\"{x:735,y:546,t:1526667268496};\\\", \\\"{x:699,y:559,t:1526667268513};\\\", \\\"{x:676,y:565,t:1526667268530};\\\", \\\"{x:659,y:570,t:1526667268546};\\\", \\\"{x:636,y:574,t:1526667268564};\\\", \\\"{x:613,y:578,t:1526667268580};\\\", \\\"{x:581,y:580,t:1526667268597};\\\", \\\"{x:549,y:582,t:1526667268614};\\\", \\\"{x:517,y:582,t:1526667268630};\\\", \\\"{x:491,y:584,t:1526667268647};\\\", \\\"{x:453,y:586,t:1526667268663};\\\", \\\"{x:429,y:587,t:1526667268680};\\\", \\\"{x:410,y:590,t:1526667268696};\\\", \\\"{x:397,y:591,t:1526667268713};\\\", \\\"{x:382,y:592,t:1526667268730};\\\", \\\"{x:373,y:592,t:1526667268747};\\\", \\\"{x:364,y:592,t:1526667268763};\\\", \\\"{x:345,y:592,t:1526667268779};\\\", \\\"{x:324,y:592,t:1526667268797};\\\", \\\"{x:305,y:598,t:1526667268815};\\\", \\\"{x:289,y:602,t:1526667268831};\\\", \\\"{x:277,y:606,t:1526667268846};\\\", \\\"{x:263,y:611,t:1526667268864};\\\", \\\"{x:252,y:612,t:1526667268879};\\\", \\\"{x:242,y:613,t:1526667268896};\\\", \\\"{x:234,y:616,t:1526667268914};\\\", \\\"{x:227,y:617,t:1526667268930};\\\", \\\"{x:218,y:619,t:1526667268946};\\\", \\\"{x:206,y:620,t:1526667268963};\\\", \\\"{x:190,y:620,t:1526667268979};\\\", \\\"{x:172,y:617,t:1526667268997};\\\", \\\"{x:152,y:610,t:1526667269014};\\\", \\\"{x:137,y:603,t:1526667269031};\\\", \\\"{x:128,y:597,t:1526667269047};\\\", \\\"{x:125,y:593,t:1526667269064};\\\", \\\"{x:124,y:589,t:1526667269081};\\\", \\\"{x:124,y:586,t:1526667269097};\\\", \\\"{x:127,y:582,t:1526667269114};\\\", \\\"{x:131,y:577,t:1526667269131};\\\", \\\"{x:134,y:574,t:1526667269147};\\\", \\\"{x:136,y:571,t:1526667269164};\\\", \\\"{x:140,y:567,t:1526667269181};\\\", \\\"{x:142,y:563,t:1526667269196};\\\", \\\"{x:145,y:558,t:1526667269214};\\\", \\\"{x:150,y:551,t:1526667269231};\\\", \\\"{x:157,y:544,t:1526667269247};\\\", \\\"{x:161,y:541,t:1526667269264};\\\", \\\"{x:162,y:539,t:1526667269281};\\\", \\\"{x:164,y:536,t:1526667269298};\\\", \\\"{x:168,y:536,t:1526667269583};\\\", \\\"{x:176,y:536,t:1526667269598};\\\", \\\"{x:187,y:541,t:1526667269613};\\\", \\\"{x:212,y:553,t:1526667269631};\\\", \\\"{x:266,y:575,t:1526667269647};\\\", \\\"{x:309,y:590,t:1526667269665};\\\", \\\"{x:337,y:607,t:1526667269681};\\\", \\\"{x:364,y:622,t:1526667269697};\\\", \\\"{x:379,y:632,t:1526667269714};\\\", \\\"{x:388,y:640,t:1526667269731};\\\", \\\"{x:393,y:645,t:1526667269748};\\\", \\\"{x:395,y:650,t:1526667269764};\\\", \\\"{x:398,y:657,t:1526667269780};\\\", \\\"{x:402,y:666,t:1526667269798};\\\", \\\"{x:412,y:680,t:1526667269814};\\\", \\\"{x:426,y:699,t:1526667269831};\\\", \\\"{x:442,y:728,t:1526667269847};\\\", \\\"{x:448,y:741,t:1526667269864};\\\", \\\"{x:457,y:757,t:1526667269882};\\\", \\\"{x:461,y:766,t:1526667269898};\\\", \\\"{x:462,y:767,t:1526667269913};\\\", \\\"{x:464,y:767,t:1526667269992};\\\", \\\"{x:465,y:766,t:1526667270000};\\\", \\\"{x:466,y:764,t:1526667270016};\\\", \\\"{x:468,y:762,t:1526667270031};\\\", \\\"{x:470,y:760,t:1526667270047};\\\", \\\"{x:473,y:754,t:1526667270065};\\\", \\\"{x:477,y:748,t:1526667270081};\\\", \\\"{x:477,y:746,t:1526667270097};\\\", \\\"{x:480,y:742,t:1526667270114};\\\", \\\"{x:480,y:741,t:1526667270132};\\\", \\\"{x:480,y:740,t:1526667270148};\\\", \\\"{x:480,y:738,t:1526667270164};\\\", \\\"{x:481,y:735,t:1526667270180};\\\", \\\"{x:482,y:734,t:1526667270198};\\\", \\\"{x:482,y:733,t:1526667270214};\\\" ] }, { \\\"rt\\\": 59202, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 440872, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"HWJDK\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"men\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"diagonal\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-B -07 PM-03 PM-O -O -03 PM-12:30-12 PM-12 PM-12:30-02 PM-03 PM-03 PM-03 PM-03 PM-03 PM-03 PM-X -B -I -I -B -J -J -B -F -E -E -11 AM-11 AM-12 PM-01 PM-02 PM-03 PM-05 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:483,y:733,t:1526667275240};\\\", \\\"{x:507,y:735,t:1526667275267};\\\", \\\"{x:578,y:738,t:1526667275279};\\\", \\\"{x:658,y:748,t:1526667275296};\\\", \\\"{x:765,y:759,t:1526667275318};\\\", \\\"{x:884,y:776,t:1526667275334};\\\", \\\"{x:1076,y:780,t:1526667275351};\\\", \\\"{x:1198,y:780,t:1526667275367};\\\", \\\"{x:1304,y:779,t:1526667275384};\\\", \\\"{x:1398,y:752,t:1526667275401};\\\", \\\"{x:1466,y:724,t:1526667275417};\\\", \\\"{x:1502,y:693,t:1526667275434};\\\", \\\"{x:1518,y:666,t:1526667275451};\\\", \\\"{x:1522,y:637,t:1526667275468};\\\", \\\"{x:1522,y:614,t:1526667275484};\\\", \\\"{x:1522,y:598,t:1526667275502};\\\", \\\"{x:1523,y:581,t:1526667275518};\\\", \\\"{x:1528,y:564,t:1526667275534};\\\", \\\"{x:1534,y:535,t:1526667275551};\\\", \\\"{x:1537,y:514,t:1526667275568};\\\", \\\"{x:1533,y:492,t:1526667275584};\\\", \\\"{x:1526,y:466,t:1526667275602};\\\", \\\"{x:1511,y:454,t:1526667275619};\\\", \\\"{x:1497,y:443,t:1526667275634};\\\", \\\"{x:1476,y:435,t:1526667275651};\\\", \\\"{x:1458,y:435,t:1526667275669};\\\", \\\"{x:1448,y:436,t:1526667275685};\\\", \\\"{x:1440,y:447,t:1526667275701};\\\", \\\"{x:1427,y:460,t:1526667275718};\\\", \\\"{x:1415,y:474,t:1526667275734};\\\", \\\"{x:1402,y:491,t:1526667275752};\\\", \\\"{x:1394,y:500,t:1526667275768};\\\", \\\"{x:1390,y:507,t:1526667275785};\\\", \\\"{x:1386,y:513,t:1526667275802};\\\", \\\"{x:1383,y:520,t:1526667275818};\\\", \\\"{x:1382,y:523,t:1526667275835};\\\", \\\"{x:1381,y:523,t:1526667275856};\\\", \\\"{x:1379,y:523,t:1526667275872};\\\", \\\"{x:1376,y:523,t:1526667275885};\\\", \\\"{x:1372,y:523,t:1526667275902};\\\", \\\"{x:1367,y:522,t:1526667275919};\\\", \\\"{x:1358,y:517,t:1526667275935};\\\", \\\"{x:1345,y:515,t:1526667275952};\\\", \\\"{x:1342,y:515,t:1526667275968};\\\", \\\"{x:1341,y:514,t:1526667276049};\\\", \\\"{x:1339,y:513,t:1526667276072};\\\", \\\"{x:1338,y:512,t:1526667276096};\\\", \\\"{x:1335,y:510,t:1526667276136};\\\", \\\"{x:1335,y:509,t:1526667276151};\\\", \\\"{x:1334,y:509,t:1526667276168};\\\", \\\"{x:1332,y:507,t:1526667276186};\\\", \\\"{x:1330,y:507,t:1526667276232};\\\", \\\"{x:1329,y:506,t:1526667276240};\\\", \\\"{x:1328,y:506,t:1526667276256};\\\", \\\"{x:1328,y:505,t:1526667276272};\\\", \\\"{x:1327,y:505,t:1526667276286};\\\", \\\"{x:1326,y:505,t:1526667276303};\\\", \\\"{x:1325,y:505,t:1526667276753};\\\", \\\"{x:1325,y:504,t:1526667276776};\\\", \\\"{x:1324,y:504,t:1526667276817};\\\", \\\"{x:1324,y:503,t:1526667276856};\\\", \\\"{x:1324,y:502,t:1526667276880};\\\", \\\"{x:1323,y:500,t:1526667276912};\\\", \\\"{x:1322,y:499,t:1526667276928};\\\", \\\"{x:1322,y:498,t:1526667276944};\\\", \\\"{x:1322,y:497,t:1526667276968};\\\", \\\"{x:1322,y:495,t:1526667276986};\\\", \\\"{x:1322,y:494,t:1526667277016};\\\", \\\"{x:1322,y:492,t:1526667277079};\\\", \\\"{x:1322,y:491,t:1526667277087};\\\", \\\"{x:1322,y:490,t:1526667277111};\\\", \\\"{x:1323,y:489,t:1526667277119};\\\", \\\"{x:1324,y:488,t:1526667277135};\\\", \\\"{x:1325,y:488,t:1526667277152};\\\", \\\"{x:1326,y:488,t:1526667277175};\\\", \\\"{x:1328,y:488,t:1526667277192};\\\", \\\"{x:1329,y:487,t:1526667277203};\\\", \\\"{x:1330,y:487,t:1526667277218};\\\", \\\"{x:1331,y:487,t:1526667277235};\\\", \\\"{x:1332,y:486,t:1526667277321};\\\", \\\"{x:1327,y:486,t:1526667277336};\\\", \\\"{x:1323,y:490,t:1526667277352};\\\", \\\"{x:1317,y:493,t:1526667277369};\\\", \\\"{x:1312,y:496,t:1526667277385};\\\", \\\"{x:1310,y:496,t:1526667277403};\\\", \\\"{x:1309,y:497,t:1526667277419};\\\", \\\"{x:1309,y:500,t:1526667280553};\\\", \\\"{x:1315,y:527,t:1526667280570};\\\", \\\"{x:1317,y:545,t:1526667280587};\\\", \\\"{x:1321,y:560,t:1526667280604};\\\", \\\"{x:1322,y:566,t:1526667280621};\\\", \\\"{x:1326,y:578,t:1526667280637};\\\", \\\"{x:1328,y:594,t:1526667280653};\\\", \\\"{x:1334,y:615,t:1526667280671};\\\", \\\"{x:1336,y:637,t:1526667280687};\\\", \\\"{x:1337,y:669,t:1526667280703};\\\", \\\"{x:1341,y:694,t:1526667280721};\\\", \\\"{x:1349,y:725,t:1526667280736};\\\", \\\"{x:1356,y:755,t:1526667280753};\\\", \\\"{x:1359,y:763,t:1526667280771};\\\", \\\"{x:1359,y:764,t:1526667280794};\\\", \\\"{x:1359,y:765,t:1526667280840};\\\", \\\"{x:1359,y:767,t:1526667280853};\\\", \\\"{x:1359,y:769,t:1526667280871};\\\", \\\"{x:1359,y:773,t:1526667280887};\\\", \\\"{x:1359,y:774,t:1526667281023};\\\", \\\"{x:1358,y:773,t:1526667281037};\\\", \\\"{x:1355,y:770,t:1526667281053};\\\", \\\"{x:1353,y:768,t:1526667281070};\\\", \\\"{x:1351,y:767,t:1526667281424};\\\", \\\"{x:1349,y:766,t:1526667281437};\\\", \\\"{x:1348,y:765,t:1526667281453};\\\", \\\"{x:1346,y:765,t:1526667281470};\\\", \\\"{x:1344,y:760,t:1526667296720};\\\", \\\"{x:1338,y:750,t:1526667296729};\\\", \\\"{x:1333,y:736,t:1526667296744};\\\", \\\"{x:1331,y:732,t:1526667296760};\\\", \\\"{x:1331,y:731,t:1526667296777};\\\", \\\"{x:1334,y:732,t:1526667297056};\\\", \\\"{x:1342,y:737,t:1526667297064};\\\", \\\"{x:1351,y:744,t:1526667297077};\\\", \\\"{x:1382,y:763,t:1526667297095};\\\", \\\"{x:1440,y:798,t:1526667297112};\\\", \\\"{x:1509,y:827,t:1526667297127};\\\", \\\"{x:1600,y:864,t:1526667297144};\\\", \\\"{x:1675,y:900,t:1526667297162};\\\", \\\"{x:1746,y:941,t:1526667297177};\\\", \\\"{x:1813,y:987,t:1526667297194};\\\", \\\"{x:1854,y:1024,t:1526667297212};\\\", \\\"{x:1882,y:1051,t:1526667297227};\\\", \\\"{x:1892,y:1066,t:1526667297245};\\\", \\\"{x:1894,y:1072,t:1526667297261};\\\", \\\"{x:1894,y:1076,t:1526667297278};\\\", \\\"{x:1894,y:1078,t:1526667297294};\\\", \\\"{x:1868,y:1079,t:1526667297311};\\\", \\\"{x:1810,y:1062,t:1526667297328};\\\", \\\"{x:1764,y:1045,t:1526667297344};\\\", \\\"{x:1736,y:1035,t:1526667297361};\\\", \\\"{x:1705,y:1028,t:1526667297377};\\\", \\\"{x:1691,y:1026,t:1526667297394};\\\", \\\"{x:1689,y:1025,t:1526667297488};\\\", \\\"{x:1686,y:1021,t:1526667297495};\\\", \\\"{x:1679,y:1012,t:1526667297511};\\\", \\\"{x:1673,y:1001,t:1526667297526};\\\", \\\"{x:1661,y:989,t:1526667297544};\\\", \\\"{x:1639,y:974,t:1526667297561};\\\", \\\"{x:1612,y:963,t:1526667297577};\\\", \\\"{x:1600,y:957,t:1526667297594};\\\", \\\"{x:1597,y:956,t:1526667297611};\\\", \\\"{x:1596,y:956,t:1526667297628};\\\", \\\"{x:1595,y:956,t:1526667297688};\\\", \\\"{x:1595,y:959,t:1526667297711};\\\", \\\"{x:1594,y:964,t:1526667297727};\\\", \\\"{x:1591,y:972,t:1526667297744};\\\", \\\"{x:1586,y:976,t:1526667297761};\\\", \\\"{x:1578,y:981,t:1526667297778};\\\", \\\"{x:1569,y:981,t:1526667297794};\\\", \\\"{x:1561,y:981,t:1526667297812};\\\", \\\"{x:1550,y:981,t:1526667297828};\\\", \\\"{x:1545,y:981,t:1526667297844};\\\", \\\"{x:1543,y:980,t:1526667297861};\\\", \\\"{x:1538,y:979,t:1526667297880};\\\", \\\"{x:1537,y:979,t:1526667297894};\\\", \\\"{x:1535,y:975,t:1526667297911};\\\", \\\"{x:1534,y:969,t:1526667297929};\\\", \\\"{x:1532,y:961,t:1526667297944};\\\", \\\"{x:1530,y:949,t:1526667297961};\\\", \\\"{x:1530,y:933,t:1526667297978};\\\", \\\"{x:1532,y:917,t:1526667297995};\\\", \\\"{x:1535,y:902,t:1526667298011};\\\", \\\"{x:1538,y:888,t:1526667298029};\\\", \\\"{x:1540,y:871,t:1526667298044};\\\", \\\"{x:1540,y:853,t:1526667298061};\\\", \\\"{x:1540,y:844,t:1526667298079};\\\", \\\"{x:1540,y:839,t:1526667298095};\\\", \\\"{x:1540,y:825,t:1526667298111};\\\", \\\"{x:1539,y:814,t:1526667298128};\\\", \\\"{x:1538,y:809,t:1526667298144};\\\", \\\"{x:1535,y:801,t:1526667298162};\\\", \\\"{x:1531,y:791,t:1526667298179};\\\", \\\"{x:1526,y:778,t:1526667298195};\\\", \\\"{x:1523,y:769,t:1526667298211};\\\", \\\"{x:1520,y:762,t:1526667298229};\\\", \\\"{x:1518,y:757,t:1526667298245};\\\", \\\"{x:1518,y:756,t:1526667298261};\\\", \\\"{x:1517,y:755,t:1526667298278};\\\", \\\"{x:1517,y:754,t:1526667298294};\\\", \\\"{x:1516,y:753,t:1526667298312};\\\", \\\"{x:1514,y:751,t:1526667298328};\\\", \\\"{x:1514,y:750,t:1526667298344};\\\", \\\"{x:1512,y:747,t:1526667298361};\\\", \\\"{x:1511,y:746,t:1526667298378};\\\", \\\"{x:1510,y:743,t:1526667298396};\\\", \\\"{x:1510,y:741,t:1526667298412};\\\", \\\"{x:1510,y:737,t:1526667298429};\\\", \\\"{x:1510,y:734,t:1526667298445};\\\", \\\"{x:1510,y:730,t:1526667298462};\\\", \\\"{x:1510,y:723,t:1526667298478};\\\", \\\"{x:1511,y:718,t:1526667298496};\\\", \\\"{x:1511,y:717,t:1526667298511};\\\", \\\"{x:1511,y:716,t:1526667298529};\\\", \\\"{x:1512,y:715,t:1526667298545};\\\", \\\"{x:1513,y:713,t:1526667298568};\\\", \\\"{x:1514,y:711,t:1526667298584};\\\", \\\"{x:1515,y:710,t:1526667298596};\\\", \\\"{x:1518,y:707,t:1526667298611};\\\", \\\"{x:1520,y:702,t:1526667298628};\\\", \\\"{x:1521,y:701,t:1526667298645};\\\", \\\"{x:1522,y:699,t:1526667298661};\\\", \\\"{x:1522,y:698,t:1526667298678};\\\", \\\"{x:1522,y:696,t:1526667298694};\\\", \\\"{x:1524,y:691,t:1526667298711};\\\", \\\"{x:1524,y:689,t:1526667298728};\\\", \\\"{x:1526,y:681,t:1526667298745};\\\", \\\"{x:1529,y:675,t:1526667298761};\\\", \\\"{x:1530,y:667,t:1526667298779};\\\", \\\"{x:1530,y:660,t:1526667298796};\\\", \\\"{x:1530,y:655,t:1526667298812};\\\", \\\"{x:1531,y:653,t:1526667298829};\\\", \\\"{x:1531,y:652,t:1526667298845};\\\", \\\"{x:1531,y:649,t:1526667298862};\\\", \\\"{x:1531,y:643,t:1526667298879};\\\", \\\"{x:1531,y:637,t:1526667298895};\\\", \\\"{x:1531,y:634,t:1526667298911};\\\", \\\"{x:1531,y:631,t:1526667298928};\\\", \\\"{x:1531,y:624,t:1526667298946};\\\", \\\"{x:1531,y:619,t:1526667298962};\\\", \\\"{x:1529,y:610,t:1526667298978};\\\", \\\"{x:1528,y:607,t:1526667298996};\\\", \\\"{x:1527,y:605,t:1526667299011};\\\", \\\"{x:1526,y:602,t:1526667299029};\\\", \\\"{x:1524,y:598,t:1526667299045};\\\", \\\"{x:1522,y:592,t:1526667299062};\\\", \\\"{x:1519,y:583,t:1526667299078};\\\", \\\"{x:1509,y:568,t:1526667299095};\\\", \\\"{x:1502,y:560,t:1526667299112};\\\", \\\"{x:1499,y:556,t:1526667299129};\\\", \\\"{x:1497,y:554,t:1526667299146};\\\", \\\"{x:1496,y:552,t:1526667299162};\\\", \\\"{x:1495,y:551,t:1526667299178};\\\", \\\"{x:1493,y:548,t:1526667299195};\\\", \\\"{x:1490,y:545,t:1526667299211};\\\", \\\"{x:1490,y:541,t:1526667299229};\\\", \\\"{x:1488,y:539,t:1526667299245};\\\", \\\"{x:1488,y:534,t:1526667299261};\\\", \\\"{x:1488,y:528,t:1526667299278};\\\", \\\"{x:1488,y:520,t:1526667299295};\\\", \\\"{x:1489,y:515,t:1526667299312};\\\", \\\"{x:1490,y:509,t:1526667299329};\\\", \\\"{x:1492,y:506,t:1526667299345};\\\", \\\"{x:1492,y:504,t:1526667299363};\\\", \\\"{x:1493,y:501,t:1526667299378};\\\", \\\"{x:1494,y:501,t:1526667299395};\\\", \\\"{x:1495,y:501,t:1526667299423};\\\", \\\"{x:1496,y:501,t:1526667299430};\\\", \\\"{x:1501,y:505,t:1526667299445};\\\", \\\"{x:1517,y:534,t:1526667299462};\\\", \\\"{x:1541,y:594,t:1526667299478};\\\", \\\"{x:1574,y:729,t:1526667299494};\\\", \\\"{x:1583,y:820,t:1526667299512};\\\", \\\"{x:1589,y:878,t:1526667299528};\\\", \\\"{x:1589,y:923,t:1526667299545};\\\", \\\"{x:1589,y:947,t:1526667299562};\\\", \\\"{x:1589,y:961,t:1526667299577};\\\", \\\"{x:1588,y:979,t:1526667299595};\\\", \\\"{x:1586,y:988,t:1526667299612};\\\", \\\"{x:1584,y:994,t:1526667299628};\\\", \\\"{x:1582,y:1002,t:1526667299645};\\\", \\\"{x:1577,y:1009,t:1526667299662};\\\", \\\"{x:1569,y:1015,t:1526667299677};\\\", \\\"{x:1551,y:1024,t:1526667299694};\\\", \\\"{x:1538,y:1028,t:1526667299712};\\\", \\\"{x:1532,y:1028,t:1526667299728};\\\", \\\"{x:1526,y:1028,t:1526667299745};\\\", \\\"{x:1520,y:1028,t:1526667299761};\\\", \\\"{x:1519,y:1025,t:1526667299778};\\\", \\\"{x:1517,y:1021,t:1526667299795};\\\", \\\"{x:1517,y:1017,t:1526667299812};\\\", \\\"{x:1517,y:1008,t:1526667299828};\\\", \\\"{x:1522,y:998,t:1526667299845};\\\", \\\"{x:1534,y:988,t:1526667299863};\\\", \\\"{x:1548,y:982,t:1526667299878};\\\", \\\"{x:1567,y:976,t:1526667299895};\\\", \\\"{x:1574,y:975,t:1526667299913};\\\", \\\"{x:1578,y:972,t:1526667299928};\\\", \\\"{x:1578,y:970,t:1526667299984};\\\", \\\"{x:1578,y:969,t:1526667300000};\\\", \\\"{x:1577,y:969,t:1526667300013};\\\", \\\"{x:1575,y:968,t:1526667300029};\\\", \\\"{x:1573,y:966,t:1526667300045};\\\", \\\"{x:1570,y:965,t:1526667300063};\\\", \\\"{x:1565,y:963,t:1526667300078};\\\", \\\"{x:1562,y:962,t:1526667300095};\\\", \\\"{x:1562,y:961,t:1526667300112};\\\", \\\"{x:1558,y:960,t:1526667300129};\\\", \\\"{x:1551,y:961,t:1526667300145};\\\", \\\"{x:1542,y:965,t:1526667300162};\\\", \\\"{x:1526,y:969,t:1526667300179};\\\", \\\"{x:1506,y:975,t:1526667300195};\\\", \\\"{x:1489,y:976,t:1526667300212};\\\", \\\"{x:1471,y:976,t:1526667300229};\\\", \\\"{x:1450,y:976,t:1526667300245};\\\", \\\"{x:1421,y:972,t:1526667300262};\\\", \\\"{x:1391,y:969,t:1526667300279};\\\", \\\"{x:1382,y:968,t:1526667300296};\\\", \\\"{x:1374,y:964,t:1526667300313};\\\", \\\"{x:1368,y:962,t:1526667300329};\\\", \\\"{x:1363,y:957,t:1526667300345};\\\", \\\"{x:1358,y:949,t:1526667300362};\\\", \\\"{x:1350,y:935,t:1526667300380};\\\", \\\"{x:1348,y:919,t:1526667300395};\\\", \\\"{x:1343,y:892,t:1526667300413};\\\", \\\"{x:1339,y:869,t:1526667300429};\\\", \\\"{x:1339,y:852,t:1526667300445};\\\", \\\"{x:1339,y:829,t:1526667300463};\\\", \\\"{x:1339,y:815,t:1526667300479};\\\", \\\"{x:1339,y:812,t:1526667300495};\\\", \\\"{x:1339,y:810,t:1526667300512};\\\", \\\"{x:1339,y:806,t:1526667300529};\\\", \\\"{x:1339,y:804,t:1526667300631};\\\", \\\"{x:1340,y:802,t:1526667300645};\\\", \\\"{x:1341,y:799,t:1526667300662};\\\", \\\"{x:1344,y:792,t:1526667300679};\\\", \\\"{x:1349,y:778,t:1526667300695};\\\", \\\"{x:1353,y:766,t:1526667300713};\\\", \\\"{x:1354,y:764,t:1526667300729};\\\", \\\"{x:1354,y:763,t:1526667300746};\\\", \\\"{x:1354,y:762,t:1526667300763};\\\", \\\"{x:1354,y:761,t:1526667300779};\\\", \\\"{x:1354,y:759,t:1526667300796};\\\", \\\"{x:1354,y:758,t:1526667300813};\\\", \\\"{x:1354,y:757,t:1526667300829};\\\", \\\"{x:1354,y:760,t:1526667300944};\\\", \\\"{x:1354,y:768,t:1526667300952};\\\", \\\"{x:1354,y:778,t:1526667300963};\\\", \\\"{x:1354,y:797,t:1526667300979};\\\", \\\"{x:1354,y:815,t:1526667300996};\\\", \\\"{x:1354,y:826,t:1526667301012};\\\", \\\"{x:1357,y:838,t:1526667301029};\\\", \\\"{x:1357,y:846,t:1526667301047};\\\", \\\"{x:1358,y:855,t:1526667301063};\\\", \\\"{x:1361,y:866,t:1526667301080};\\\", \\\"{x:1361,y:869,t:1526667301096};\\\", \\\"{x:1361,y:877,t:1526667301113};\\\", \\\"{x:1361,y:887,t:1526667301129};\\\", \\\"{x:1361,y:892,t:1526667301146};\\\", \\\"{x:1361,y:897,t:1526667301163};\\\", \\\"{x:1361,y:901,t:1526667301179};\\\", \\\"{x:1359,y:909,t:1526667301197};\\\", \\\"{x:1357,y:911,t:1526667301212};\\\", \\\"{x:1356,y:913,t:1526667301228};\\\", \\\"{x:1356,y:912,t:1526667301286};\\\", \\\"{x:1356,y:905,t:1526667301296};\\\", \\\"{x:1356,y:883,t:1526667301312};\\\", \\\"{x:1360,y:854,t:1526667301329};\\\", \\\"{x:1365,y:822,t:1526667301346};\\\", \\\"{x:1367,y:805,t:1526667301362};\\\", \\\"{x:1370,y:794,t:1526667301379};\\\", \\\"{x:1372,y:782,t:1526667301397};\\\", \\\"{x:1372,y:773,t:1526667301412};\\\", \\\"{x:1372,y:771,t:1526667301429};\\\", \\\"{x:1372,y:767,t:1526667301447};\\\", \\\"{x:1370,y:764,t:1526667301462};\\\", \\\"{x:1368,y:763,t:1526667301536};\\\", \\\"{x:1365,y:763,t:1526667301546};\\\", \\\"{x:1360,y:771,t:1526667301563};\\\", \\\"{x:1356,y:786,t:1526667301580};\\\", \\\"{x:1352,y:798,t:1526667301596};\\\", \\\"{x:1348,y:812,t:1526667301613};\\\", \\\"{x:1348,y:828,t:1526667301630};\\\", \\\"{x:1348,y:845,t:1526667301648};\\\", \\\"{x:1348,y:858,t:1526667301663};\\\", \\\"{x:1354,y:874,t:1526667301680};\\\", \\\"{x:1360,y:890,t:1526667301697};\\\", \\\"{x:1365,y:904,t:1526667301714};\\\", \\\"{x:1368,y:915,t:1526667301729};\\\", \\\"{x:1369,y:924,t:1526667301746};\\\", \\\"{x:1371,y:929,t:1526667301763};\\\", \\\"{x:1371,y:933,t:1526667301779};\\\", \\\"{x:1371,y:938,t:1526667301796};\\\", \\\"{x:1369,y:946,t:1526667301812};\\\", \\\"{x:1366,y:951,t:1526667301829};\\\", \\\"{x:1362,y:955,t:1526667301846};\\\", \\\"{x:1349,y:966,t:1526667301863};\\\", \\\"{x:1344,y:971,t:1526667301879};\\\", \\\"{x:1340,y:976,t:1526667301896};\\\", \\\"{x:1337,y:980,t:1526667301913};\\\", \\\"{x:1338,y:980,t:1526667302168};\\\", \\\"{x:1341,y:980,t:1526667302179};\\\", \\\"{x:1345,y:980,t:1526667302197};\\\", \\\"{x:1350,y:980,t:1526667302213};\\\", \\\"{x:1355,y:980,t:1526667302230};\\\", \\\"{x:1358,y:980,t:1526667302247};\\\", \\\"{x:1359,y:979,t:1526667302265};\\\", \\\"{x:1361,y:979,t:1526667302303};\\\", \\\"{x:1362,y:979,t:1526667302314};\\\", \\\"{x:1365,y:977,t:1526667302330};\\\", \\\"{x:1373,y:977,t:1526667302347};\\\", \\\"{x:1382,y:977,t:1526667302364};\\\", \\\"{x:1395,y:977,t:1526667302380};\\\", \\\"{x:1400,y:977,t:1526667302396};\\\", \\\"{x:1404,y:977,t:1526667302414};\\\", \\\"{x:1406,y:977,t:1526667302429};\\\", \\\"{x:1407,y:977,t:1526667302447};\\\", \\\"{x:1409,y:977,t:1526667302464};\\\", \\\"{x:1412,y:977,t:1526667302479};\\\", \\\"{x:1416,y:977,t:1526667302497};\\\", \\\"{x:1420,y:977,t:1526667302514};\\\", \\\"{x:1424,y:977,t:1526667302530};\\\", \\\"{x:1425,y:977,t:1526667302568};\\\", \\\"{x:1429,y:977,t:1526667302793};\\\", \\\"{x:1436,y:978,t:1526667302799};\\\", \\\"{x:1443,y:978,t:1526667302814};\\\", \\\"{x:1459,y:978,t:1526667302831};\\\", \\\"{x:1466,y:978,t:1526667302847};\\\", \\\"{x:1473,y:978,t:1526667302863};\\\", \\\"{x:1474,y:979,t:1526667302968};\\\", \\\"{x:1475,y:979,t:1526667302981};\\\", \\\"{x:1477,y:980,t:1526667302996};\\\", \\\"{x:1480,y:980,t:1526667303120};\\\", \\\"{x:1481,y:980,t:1526667303130};\\\", \\\"{x:1489,y:980,t:1526667303146};\\\", \\\"{x:1509,y:981,t:1526667303164};\\\", \\\"{x:1528,y:983,t:1526667303181};\\\", \\\"{x:1546,y:983,t:1526667303196};\\\", \\\"{x:1555,y:983,t:1526667303214};\\\", \\\"{x:1560,y:983,t:1526667303230};\\\", \\\"{x:1561,y:983,t:1526667303246};\\\", \\\"{x:1558,y:982,t:1526667303464};\\\", \\\"{x:1548,y:978,t:1526667303481};\\\", \\\"{x:1540,y:975,t:1526667303498};\\\", \\\"{x:1536,y:973,t:1526667303513};\\\", \\\"{x:1535,y:972,t:1526667303608};\\\", \\\"{x:1535,y:971,t:1526667303624};\\\", \\\"{x:1536,y:970,t:1526667303631};\\\", \\\"{x:1542,y:967,t:1526667303647};\\\", \\\"{x:1549,y:964,t:1526667303663};\\\", \\\"{x:1554,y:959,t:1526667303681};\\\", \\\"{x:1558,y:956,t:1526667303698};\\\", \\\"{x:1561,y:955,t:1526667303713};\\\", \\\"{x:1563,y:953,t:1526667303731};\\\", \\\"{x:1564,y:953,t:1526667303747};\\\", \\\"{x:1565,y:951,t:1526667303764};\\\", \\\"{x:1565,y:948,t:1526667303780};\\\", \\\"{x:1566,y:942,t:1526667303798};\\\", \\\"{x:1567,y:934,t:1526667303814};\\\", \\\"{x:1569,y:924,t:1526667303831};\\\", \\\"{x:1569,y:914,t:1526667303847};\\\", \\\"{x:1569,y:909,t:1526667303864};\\\", \\\"{x:1569,y:903,t:1526667303881};\\\", \\\"{x:1569,y:896,t:1526667303897};\\\", \\\"{x:1569,y:890,t:1526667303915};\\\", \\\"{x:1569,y:887,t:1526667303931};\\\", \\\"{x:1569,y:882,t:1526667303948};\\\", \\\"{x:1567,y:876,t:1526667303963};\\\", \\\"{x:1566,y:872,t:1526667303980};\\\", \\\"{x:1562,y:866,t:1526667303997};\\\", \\\"{x:1559,y:861,t:1526667304013};\\\", \\\"{x:1556,y:854,t:1526667304030};\\\", \\\"{x:1554,y:847,t:1526667304046};\\\", \\\"{x:1552,y:842,t:1526667304063};\\\", \\\"{x:1551,y:839,t:1526667304081};\\\", \\\"{x:1546,y:830,t:1526667304097};\\\", \\\"{x:1545,y:825,t:1526667304113};\\\", \\\"{x:1543,y:820,t:1526667304130};\\\", \\\"{x:1542,y:815,t:1526667304147};\\\", \\\"{x:1540,y:813,t:1526667304163};\\\", \\\"{x:1540,y:810,t:1526667304181};\\\", \\\"{x:1540,y:805,t:1526667304197};\\\", \\\"{x:1540,y:801,t:1526667304214};\\\", \\\"{x:1539,y:796,t:1526667304230};\\\", \\\"{x:1539,y:790,t:1526667304247};\\\", \\\"{x:1539,y:787,t:1526667304264};\\\", \\\"{x:1539,y:784,t:1526667304281};\\\", \\\"{x:1539,y:780,t:1526667304298};\\\", \\\"{x:1539,y:777,t:1526667304314};\\\", \\\"{x:1539,y:772,t:1526667304331};\\\", \\\"{x:1540,y:765,t:1526667304347};\\\", \\\"{x:1540,y:764,t:1526667304365};\\\", \\\"{x:1540,y:761,t:1526667304380};\\\", \\\"{x:1540,y:758,t:1526667304398};\\\", \\\"{x:1540,y:756,t:1526667304415};\\\", \\\"{x:1540,y:754,t:1526667304431};\\\", \\\"{x:1540,y:746,t:1526667304447};\\\", \\\"{x:1540,y:742,t:1526667304465};\\\", \\\"{x:1540,y:736,t:1526667304481};\\\", \\\"{x:1540,y:731,t:1526667304498};\\\", \\\"{x:1540,y:724,t:1526667304514};\\\", \\\"{x:1540,y:721,t:1526667304530};\\\", \\\"{x:1541,y:714,t:1526667304547};\\\", \\\"{x:1541,y:708,t:1526667304564};\\\", \\\"{x:1541,y:702,t:1526667304580};\\\", \\\"{x:1541,y:694,t:1526667304597};\\\", \\\"{x:1541,y:693,t:1526667304614};\\\", \\\"{x:1541,y:690,t:1526667304630};\\\", \\\"{x:1541,y:689,t:1526667304647};\\\", \\\"{x:1541,y:687,t:1526667304664};\\\", \\\"{x:1541,y:685,t:1526667304681};\\\", \\\"{x:1541,y:683,t:1526667304697};\\\", \\\"{x:1541,y:680,t:1526667304715};\\\", \\\"{x:1541,y:677,t:1526667304730};\\\", \\\"{x:1541,y:674,t:1526667304747};\\\", \\\"{x:1541,y:672,t:1526667304765};\\\", \\\"{x:1539,y:667,t:1526667304780};\\\", \\\"{x:1539,y:663,t:1526667304797};\\\", \\\"{x:1537,y:659,t:1526667304814};\\\", \\\"{x:1536,y:654,t:1526667304831};\\\", \\\"{x:1533,y:646,t:1526667304847};\\\", \\\"{x:1532,y:642,t:1526667304864};\\\", \\\"{x:1532,y:641,t:1526667304881};\\\", \\\"{x:1532,y:642,t:1526667304983};\\\", \\\"{x:1534,y:648,t:1526667304998};\\\", \\\"{x:1537,y:659,t:1526667305015};\\\", \\\"{x:1540,y:672,t:1526667305031};\\\", \\\"{x:1545,y:685,t:1526667305048};\\\", \\\"{x:1545,y:691,t:1526667305065};\\\", \\\"{x:1546,y:698,t:1526667305081};\\\", \\\"{x:1546,y:704,t:1526667305098};\\\", \\\"{x:1546,y:709,t:1526667305115};\\\", \\\"{x:1546,y:716,t:1526667305132};\\\", \\\"{x:1546,y:727,t:1526667305148};\\\", \\\"{x:1545,y:741,t:1526667305165};\\\", \\\"{x:1542,y:761,t:1526667305182};\\\", \\\"{x:1537,y:776,t:1526667305198};\\\", \\\"{x:1534,y:788,t:1526667305214};\\\", \\\"{x:1530,y:808,t:1526667305231};\\\", \\\"{x:1527,y:824,t:1526667305248};\\\", \\\"{x:1526,y:846,t:1526667305265};\\\", \\\"{x:1525,y:857,t:1526667305282};\\\", \\\"{x:1525,y:863,t:1526667305298};\\\", \\\"{x:1526,y:870,t:1526667305314};\\\", \\\"{x:1526,y:872,t:1526667305332};\\\", \\\"{x:1530,y:880,t:1526667305347};\\\", \\\"{x:1531,y:884,t:1526667305364};\\\", \\\"{x:1535,y:891,t:1526667305382};\\\", \\\"{x:1535,y:895,t:1526667305397};\\\", \\\"{x:1536,y:900,t:1526667305414};\\\", \\\"{x:1536,y:916,t:1526667305430};\\\", \\\"{x:1537,y:925,t:1526667305447};\\\", \\\"{x:1541,y:934,t:1526667305464};\\\", \\\"{x:1541,y:938,t:1526667305481};\\\", \\\"{x:1542,y:939,t:1526667305497};\\\", \\\"{x:1542,y:941,t:1526667305514};\\\", \\\"{x:1542,y:942,t:1526667305535};\\\", \\\"{x:1542,y:944,t:1526667305547};\\\", \\\"{x:1542,y:948,t:1526667305564};\\\", \\\"{x:1542,y:953,t:1526667305582};\\\", \\\"{x:1544,y:969,t:1526667305597};\\\", \\\"{x:1547,y:976,t:1526667305615};\\\", \\\"{x:1549,y:981,t:1526667305632};\\\", \\\"{x:1549,y:982,t:1526667305648};\\\", \\\"{x:1551,y:984,t:1526667306599};\\\", \\\"{x:1552,y:984,t:1526667306615};\\\", \\\"{x:1553,y:984,t:1526667306632};\\\", \\\"{x:1554,y:984,t:1526667306672};\\\", \\\"{x:1555,y:984,t:1526667306704};\\\", \\\"{x:1555,y:983,t:1526667306919};\\\", \\\"{x:1552,y:977,t:1526667306932};\\\", \\\"{x:1548,y:970,t:1526667306949};\\\", \\\"{x:1545,y:968,t:1526667306966};\\\", \\\"{x:1544,y:966,t:1526667306982};\\\", \\\"{x:1543,y:966,t:1526667306999};\\\", \\\"{x:1544,y:966,t:1526667307591};\\\", \\\"{x:1545,y:966,t:1526667307599};\\\", \\\"{x:1548,y:966,t:1526667307616};\\\", \\\"{x:1549,y:965,t:1526667307633};\\\", \\\"{x:1549,y:964,t:1526667309861};\\\", \\\"{x:1550,y:963,t:1526667309894};\\\", \\\"{x:1551,y:963,t:1526667309909};\\\", \\\"{x:1552,y:963,t:1526667309925};\\\", \\\"{x:1553,y:961,t:1526667309934};\\\", \\\"{x:1554,y:961,t:1526667309957};\\\", \\\"{x:1554,y:960,t:1526667310421};\\\", \\\"{x:1554,y:959,t:1526667310461};\\\", \\\"{x:1554,y:958,t:1526667310493};\\\", \\\"{x:1554,y:957,t:1526667310533};\\\", \\\"{x:1554,y:956,t:1526667310548};\\\", \\\"{x:1554,y:955,t:1526667310565};\\\", \\\"{x:1555,y:954,t:1526667310597};\\\", \\\"{x:1556,y:952,t:1526667310622};\\\", \\\"{x:1556,y:951,t:1526667310670};\\\", \\\"{x:1557,y:950,t:1526667310686};\\\", \\\"{x:1557,y:949,t:1526667310717};\\\", \\\"{x:1558,y:949,t:1526667310732};\\\", \\\"{x:1558,y:948,t:1526667310765};\\\", \\\"{x:1558,y:947,t:1526667310782};\\\", \\\"{x:1559,y:947,t:1526667310966};\\\", \\\"{x:1560,y:946,t:1526667310982};\\\", \\\"{x:1560,y:945,t:1526667311462};\\\", \\\"{x:1557,y:941,t:1526667311469};\\\", \\\"{x:1549,y:935,t:1526667311482};\\\", \\\"{x:1526,y:913,t:1526667311498};\\\", \\\"{x:1506,y:890,t:1526667311514};\\\", \\\"{x:1498,y:875,t:1526667311531};\\\", \\\"{x:1490,y:865,t:1526667311548};\\\", \\\"{x:1484,y:854,t:1526667311564};\\\", \\\"{x:1479,y:842,t:1526667311581};\\\", \\\"{x:1477,y:832,t:1526667311599};\\\", \\\"{x:1469,y:818,t:1526667311615};\\\", \\\"{x:1459,y:803,t:1526667311631};\\\", \\\"{x:1444,y:792,t:1526667311648};\\\", \\\"{x:1417,y:777,t:1526667311665};\\\", \\\"{x:1402,y:767,t:1526667311682};\\\", \\\"{x:1394,y:761,t:1526667311698};\\\", \\\"{x:1390,y:760,t:1526667311715};\\\", \\\"{x:1386,y:759,t:1526667311732};\\\", \\\"{x:1382,y:758,t:1526667311748};\\\", \\\"{x:1381,y:758,t:1526667311789};\\\", \\\"{x:1378,y:758,t:1526667311799};\\\", \\\"{x:1369,y:758,t:1526667311816};\\\", \\\"{x:1358,y:758,t:1526667311831};\\\", \\\"{x:1343,y:758,t:1526667311848};\\\", \\\"{x:1338,y:758,t:1526667311865};\\\", \\\"{x:1337,y:758,t:1526667311881};\\\", \\\"{x:1339,y:764,t:1526667311972};\\\", \\\"{x:1340,y:767,t:1526667311981};\\\", \\\"{x:1349,y:778,t:1526667311999};\\\", \\\"{x:1355,y:784,t:1526667312015};\\\", \\\"{x:1356,y:786,t:1526667312032};\\\", \\\"{x:1356,y:784,t:1526667312245};\\\", \\\"{x:1356,y:782,t:1526667312253};\\\", \\\"{x:1355,y:779,t:1526667312266};\\\", \\\"{x:1352,y:774,t:1526667312281};\\\", \\\"{x:1351,y:767,t:1526667312299};\\\", \\\"{x:1349,y:763,t:1526667312316};\\\", \\\"{x:1349,y:762,t:1526667312332};\\\", \\\"{x:1348,y:761,t:1526667312348};\\\", \\\"{x:1346,y:761,t:1526667312501};\\\", \\\"{x:1345,y:759,t:1526667312515};\\\", \\\"{x:1344,y:759,t:1526667312532};\\\", \\\"{x:1344,y:758,t:1526667312550};\\\", \\\"{x:1342,y:758,t:1526667312622};\\\", \\\"{x:1341,y:758,t:1526667312633};\\\", \\\"{x:1328,y:759,t:1526667312649};\\\", \\\"{x:1307,y:760,t:1526667312665};\\\", \\\"{x:1274,y:760,t:1526667312682};\\\", \\\"{x:1251,y:760,t:1526667312698};\\\", \\\"{x:1221,y:755,t:1526667312715};\\\", \\\"{x:1194,y:747,t:1526667312732};\\\", \\\"{x:1183,y:747,t:1526667312748};\\\", \\\"{x:1180,y:747,t:1526667312765};\\\", \\\"{x:1179,y:747,t:1526667312782};\\\", \\\"{x:1178,y:747,t:1526667312798};\\\", \\\"{x:1178,y:748,t:1526667312829};\\\", \\\"{x:1178,y:749,t:1526667312837};\\\", \\\"{x:1177,y:751,t:1526667312868};\\\", \\\"{x:1176,y:751,t:1526667312882};\\\", \\\"{x:1176,y:753,t:1526667312898};\\\", \\\"{x:1176,y:754,t:1526667312916};\\\", \\\"{x:1178,y:756,t:1526667312932};\\\", \\\"{x:1179,y:757,t:1526667312948};\\\", \\\"{x:1180,y:761,t:1526667312966};\\\", \\\"{x:1181,y:764,t:1526667312998};\\\", \\\"{x:1182,y:768,t:1526667313016};\\\", \\\"{x:1182,y:769,t:1526667313033};\\\", \\\"{x:1183,y:771,t:1526667313374};\\\", \\\"{x:1191,y:772,t:1526667313382};\\\", \\\"{x:1207,y:781,t:1526667313399};\\\", \\\"{x:1231,y:786,t:1526667313416};\\\", \\\"{x:1266,y:789,t:1526667313433};\\\", \\\"{x:1300,y:789,t:1526667313450};\\\", \\\"{x:1319,y:789,t:1526667313465};\\\", \\\"{x:1327,y:789,t:1526667313483};\\\", \\\"{x:1329,y:789,t:1526667313500};\\\", \\\"{x:1330,y:788,t:1526667313515};\\\", \\\"{x:1330,y:787,t:1526667313653};\\\", \\\"{x:1330,y:783,t:1526667313666};\\\", \\\"{x:1332,y:775,t:1526667313683};\\\", \\\"{x:1334,y:770,t:1526667313700};\\\", \\\"{x:1337,y:766,t:1526667313716};\\\", \\\"{x:1339,y:764,t:1526667313732};\\\", \\\"{x:1342,y:764,t:1526667313749};\\\", \\\"{x:1336,y:764,t:1526667313878};\\\", \\\"{x:1332,y:765,t:1526667313885};\\\", \\\"{x:1327,y:767,t:1526667313900};\\\", \\\"{x:1314,y:772,t:1526667313916};\\\", \\\"{x:1305,y:781,t:1526667313933};\\\", \\\"{x:1295,y:789,t:1526667313950};\\\", \\\"{x:1287,y:800,t:1526667313966};\\\", \\\"{x:1280,y:810,t:1526667313983};\\\", \\\"{x:1275,y:818,t:1526667314000};\\\", \\\"{x:1271,y:822,t:1526667314016};\\\", \\\"{x:1268,y:825,t:1526667314033};\\\", \\\"{x:1263,y:826,t:1526667314050};\\\", \\\"{x:1256,y:827,t:1526667314066};\\\", \\\"{x:1253,y:827,t:1526667314083};\\\", \\\"{x:1251,y:827,t:1526667314100};\\\", \\\"{x:1247,y:827,t:1526667314116};\\\", \\\"{x:1238,y:827,t:1526667314133};\\\", \\\"{x:1234,y:828,t:1526667314149};\\\", \\\"{x:1232,y:829,t:1526667314166};\\\", \\\"{x:1229,y:831,t:1526667314183};\\\", \\\"{x:1223,y:831,t:1526667314200};\\\", \\\"{x:1221,y:832,t:1526667314217};\\\", \\\"{x:1216,y:833,t:1526667314234};\\\", \\\"{x:1215,y:833,t:1526667314249};\\\", \\\"{x:1213,y:833,t:1526667314267};\\\", \\\"{x:1210,y:833,t:1526667314283};\\\", \\\"{x:1209,y:833,t:1526667314300};\\\", \\\"{x:1202,y:832,t:1526667314317};\\\", \\\"{x:1200,y:832,t:1526667314333};\\\", \\\"{x:1199,y:832,t:1526667314349};\\\", \\\"{x:1197,y:832,t:1526667314367};\\\", \\\"{x:1202,y:831,t:1526667314661};\\\", \\\"{x:1211,y:827,t:1526667314669};\\\", \\\"{x:1219,y:825,t:1526667314684};\\\", \\\"{x:1242,y:814,t:1526667314700};\\\", \\\"{x:1273,y:804,t:1526667314717};\\\", \\\"{x:1286,y:799,t:1526667314732};\\\", \\\"{x:1293,y:798,t:1526667314750};\\\", \\\"{x:1297,y:796,t:1526667314767};\\\", \\\"{x:1297,y:795,t:1526667314783};\\\", \\\"{x:1299,y:795,t:1526667314800};\\\", \\\"{x:1299,y:794,t:1526667314817};\\\", \\\"{x:1305,y:788,t:1526667314834};\\\", \\\"{x:1314,y:771,t:1526667314850};\\\", \\\"{x:1326,y:741,t:1526667314867};\\\", \\\"{x:1333,y:719,t:1526667314883};\\\", \\\"{x:1336,y:706,t:1526667314900};\\\", \\\"{x:1342,y:672,t:1526667314917};\\\", \\\"{x:1347,y:646,t:1526667314933};\\\", \\\"{x:1352,y:625,t:1526667314949};\\\", \\\"{x:1359,y:600,t:1526667314966};\\\", \\\"{x:1364,y:579,t:1526667314983};\\\", \\\"{x:1366,y:561,t:1526667314999};\\\", \\\"{x:1367,y:551,t:1526667315016};\\\", \\\"{x:1369,y:545,t:1526667315033};\\\", \\\"{x:1369,y:540,t:1526667315049};\\\", \\\"{x:1369,y:537,t:1526667315066};\\\", \\\"{x:1366,y:532,t:1526667315082};\\\", \\\"{x:1362,y:527,t:1526667315099};\\\", \\\"{x:1348,y:522,t:1526667315116};\\\", \\\"{x:1337,y:521,t:1526667315133};\\\", \\\"{x:1329,y:521,t:1526667315150};\\\", \\\"{x:1315,y:525,t:1526667315167};\\\", \\\"{x:1310,y:527,t:1526667315183};\\\", \\\"{x:1309,y:527,t:1526667315253};\\\", \\\"{x:1309,y:525,t:1526667315267};\\\", \\\"{x:1308,y:517,t:1526667315285};\\\", \\\"{x:1307,y:509,t:1526667315300};\\\", \\\"{x:1307,y:496,t:1526667315317};\\\", \\\"{x:1307,y:493,t:1526667315334};\\\", \\\"{x:1307,y:491,t:1526667315350};\\\", \\\"{x:1307,y:490,t:1526667315367};\\\", \\\"{x:1307,y:489,t:1526667315444};\\\", \\\"{x:1307,y:488,t:1526667315460};\\\", \\\"{x:1307,y:487,t:1526667315468};\\\", \\\"{x:1307,y:485,t:1526667315484};\\\", \\\"{x:1307,y:484,t:1526667315499};\\\", \\\"{x:1310,y:481,t:1526667315516};\\\", \\\"{x:1315,y:480,t:1526667315533};\\\", \\\"{x:1318,y:480,t:1526667315550};\\\", \\\"{x:1328,y:480,t:1526667315567};\\\", \\\"{x:1341,y:484,t:1526667315584};\\\", \\\"{x:1355,y:491,t:1526667315599};\\\", \\\"{x:1359,y:495,t:1526667315617};\\\", \\\"{x:1361,y:498,t:1526667315634};\\\", \\\"{x:1365,y:507,t:1526667315650};\\\", \\\"{x:1369,y:519,t:1526667315666};\\\", \\\"{x:1372,y:536,t:1526667315684};\\\", \\\"{x:1378,y:557,t:1526667315700};\\\", \\\"{x:1380,y:587,t:1526667315717};\\\", \\\"{x:1381,y:615,t:1526667315734};\\\", \\\"{x:1381,y:648,t:1526667315750};\\\", \\\"{x:1381,y:670,t:1526667315767};\\\", \\\"{x:1379,y:688,t:1526667315784};\\\", \\\"{x:1377,y:703,t:1526667315800};\\\", \\\"{x:1372,y:719,t:1526667315817};\\\", \\\"{x:1366,y:735,t:1526667315834};\\\", \\\"{x:1358,y:751,t:1526667315851};\\\", \\\"{x:1352,y:766,t:1526667315867};\\\", \\\"{x:1348,y:773,t:1526667315885};\\\", \\\"{x:1344,y:781,t:1526667315901};\\\", \\\"{x:1342,y:785,t:1526667315916};\\\", \\\"{x:1340,y:787,t:1526667315934};\\\", \\\"{x:1339,y:788,t:1526667315951};\\\", \\\"{x:1339,y:789,t:1526667315967};\\\", \\\"{x:1339,y:790,t:1526667315984};\\\", \\\"{x:1338,y:790,t:1526667316005};\\\", \\\"{x:1338,y:783,t:1526667316061};\\\", \\\"{x:1341,y:773,t:1526667316069};\\\", \\\"{x:1341,y:762,t:1526667316084};\\\", \\\"{x:1342,y:741,t:1526667316100};\\\", \\\"{x:1348,y:714,t:1526667316117};\\\", \\\"{x:1349,y:700,t:1526667316134};\\\", \\\"{x:1351,y:689,t:1526667316151};\\\", \\\"{x:1351,y:679,t:1526667316167};\\\", \\\"{x:1351,y:672,t:1526667316184};\\\", \\\"{x:1351,y:668,t:1526667316201};\\\", \\\"{x:1348,y:661,t:1526667316217};\\\", \\\"{x:1348,y:655,t:1526667316234};\\\", \\\"{x:1346,y:644,t:1526667316251};\\\", \\\"{x:1338,y:626,t:1526667316267};\\\", \\\"{x:1329,y:610,t:1526667316284};\\\", \\\"{x:1311,y:588,t:1526667316301};\\\", \\\"{x:1300,y:577,t:1526667316317};\\\", \\\"{x:1289,y:569,t:1526667316334};\\\", \\\"{x:1284,y:566,t:1526667316351};\\\", \\\"{x:1281,y:565,t:1526667316367};\\\", \\\"{x:1280,y:565,t:1526667316384};\\\", \\\"{x:1279,y:564,t:1526667317661};\\\", \\\"{x:1278,y:564,t:1526667320685};\\\", \\\"{x:1278,y:568,t:1526667320702};\\\", \\\"{x:1277,y:569,t:1526667320733};\\\", \\\"{x:1279,y:569,t:1526667320974};\\\", \\\"{x:1279,y:568,t:1526667320989};\\\", \\\"{x:1280,y:567,t:1526667321003};\\\", \\\"{x:1280,y:566,t:1526667321277};\\\", \\\"{x:1282,y:565,t:1526667322036};\\\", \\\"{x:1282,y:566,t:1526667322052};\\\", \\\"{x:1284,y:578,t:1526667322070};\\\", \\\"{x:1287,y:589,t:1526667322085};\\\", \\\"{x:1288,y:593,t:1526667322103};\\\", \\\"{x:1289,y:597,t:1526667322119};\\\", \\\"{x:1290,y:603,t:1526667322135};\\\", \\\"{x:1291,y:613,t:1526667322153};\\\", \\\"{x:1292,y:622,t:1526667322170};\\\", \\\"{x:1295,y:635,t:1526667322186};\\\", \\\"{x:1296,y:646,t:1526667322203};\\\", \\\"{x:1297,y:656,t:1526667322220};\\\", \\\"{x:1297,y:662,t:1526667322235};\\\", \\\"{x:1297,y:682,t:1526667322252};\\\", \\\"{x:1297,y:693,t:1526667322270};\\\", \\\"{x:1297,y:700,t:1526667322286};\\\", \\\"{x:1297,y:706,t:1526667322302};\\\", \\\"{x:1298,y:712,t:1526667322319};\\\", \\\"{x:1298,y:719,t:1526667322336};\\\", \\\"{x:1298,y:727,t:1526667322352};\\\", \\\"{x:1298,y:733,t:1526667322370};\\\", \\\"{x:1298,y:738,t:1526667322386};\\\", \\\"{x:1296,y:746,t:1526667322403};\\\", \\\"{x:1296,y:748,t:1526667322419};\\\", \\\"{x:1295,y:754,t:1526667322436};\\\", \\\"{x:1295,y:764,t:1526667322453};\\\", \\\"{x:1295,y:776,t:1526667322470};\\\", \\\"{x:1295,y:785,t:1526667322486};\\\", \\\"{x:1295,y:793,t:1526667322503};\\\", \\\"{x:1295,y:803,t:1526667322519};\\\", \\\"{x:1295,y:812,t:1526667322536};\\\", \\\"{x:1295,y:825,t:1526667322553};\\\", \\\"{x:1296,y:838,t:1526667322570};\\\", \\\"{x:1298,y:848,t:1526667322587};\\\", \\\"{x:1300,y:861,t:1526667322603};\\\", \\\"{x:1302,y:876,t:1526667322620};\\\", \\\"{x:1306,y:894,t:1526667322637};\\\", \\\"{x:1307,y:904,t:1526667322653};\\\", \\\"{x:1307,y:917,t:1526667322670};\\\", \\\"{x:1310,y:932,t:1526667322687};\\\", \\\"{x:1310,y:943,t:1526667322703};\\\", \\\"{x:1310,y:955,t:1526667322720};\\\", \\\"{x:1310,y:965,t:1526667322737};\\\", \\\"{x:1310,y:977,t:1526667322753};\\\", \\\"{x:1310,y:989,t:1526667322770};\\\", \\\"{x:1310,y:991,t:1526667322787};\\\", \\\"{x:1309,y:993,t:1526667322803};\\\", \\\"{x:1308,y:993,t:1526667322820};\\\", \\\"{x:1307,y:993,t:1526667322901};\\\", \\\"{x:1305,y:993,t:1526667322957};\\\", \\\"{x:1302,y:991,t:1526667322970};\\\", \\\"{x:1297,y:986,t:1526667322988};\\\", \\\"{x:1289,y:979,t:1526667323004};\\\", \\\"{x:1280,y:972,t:1526667323020};\\\", \\\"{x:1271,y:966,t:1526667323037};\\\", \\\"{x:1271,y:967,t:1526667323206};\\\", \\\"{x:1271,y:968,t:1526667323220};\\\", \\\"{x:1278,y:977,t:1526667323237};\\\", \\\"{x:1284,y:981,t:1526667323253};\\\", \\\"{x:1289,y:982,t:1526667323270};\\\", \\\"{x:1299,y:989,t:1526667323287};\\\", \\\"{x:1309,y:990,t:1526667323304};\\\", \\\"{x:1317,y:991,t:1526667323321};\\\", \\\"{x:1325,y:992,t:1526667323337};\\\", \\\"{x:1330,y:994,t:1526667323353};\\\", \\\"{x:1333,y:994,t:1526667323370};\\\", \\\"{x:1334,y:994,t:1526667323390};\\\", \\\"{x:1336,y:994,t:1526667323404};\\\", \\\"{x:1337,y:994,t:1526667323444};\\\", \\\"{x:1339,y:994,t:1526667323461};\\\", \\\"{x:1339,y:993,t:1526667323470};\\\", \\\"{x:1343,y:991,t:1526667323487};\\\", \\\"{x:1344,y:990,t:1526667323504};\\\", \\\"{x:1346,y:989,t:1526667323520};\\\", \\\"{x:1347,y:989,t:1526667323589};\\\", \\\"{x:1349,y:989,t:1526667323604};\\\", \\\"{x:1352,y:989,t:1526667323620};\\\", \\\"{x:1355,y:989,t:1526667323637};\\\", \\\"{x:1360,y:989,t:1526667323654};\\\", \\\"{x:1367,y:991,t:1526667323670};\\\", \\\"{x:1370,y:992,t:1526667323688};\\\", \\\"{x:1374,y:993,t:1526667323704};\\\", \\\"{x:1377,y:993,t:1526667323720};\\\", \\\"{x:1383,y:993,t:1526667323737};\\\", \\\"{x:1389,y:993,t:1526667323754};\\\", \\\"{x:1398,y:993,t:1526667323770};\\\", \\\"{x:1406,y:993,t:1526667323787};\\\", \\\"{x:1415,y:993,t:1526667323804};\\\", \\\"{x:1420,y:993,t:1526667323820};\\\", \\\"{x:1426,y:993,t:1526667323836};\\\", \\\"{x:1427,y:993,t:1526667323854};\\\", \\\"{x:1427,y:992,t:1526667323893};\\\", \\\"{x:1427,y:991,t:1526667323904};\\\", \\\"{x:1427,y:989,t:1526667323920};\\\", \\\"{x:1429,y:986,t:1526667323937};\\\", \\\"{x:1431,y:984,t:1526667323954};\\\", \\\"{x:1431,y:983,t:1526667324085};\\\", \\\"{x:1432,y:983,t:1526667324093};\\\", \\\"{x:1434,y:984,t:1526667324104};\\\", \\\"{x:1438,y:987,t:1526667324121};\\\", \\\"{x:1445,y:991,t:1526667324137};\\\", \\\"{x:1450,y:994,t:1526667324154};\\\", \\\"{x:1456,y:996,t:1526667324170};\\\", \\\"{x:1459,y:996,t:1526667324187};\\\", \\\"{x:1460,y:996,t:1526667324204};\\\", \\\"{x:1463,y:997,t:1526667324221};\\\", \\\"{x:1465,y:997,t:1526667324244};\\\", \\\"{x:1467,y:997,t:1526667324254};\\\", \\\"{x:1470,y:997,t:1526667324270};\\\", \\\"{x:1472,y:997,t:1526667324287};\\\", \\\"{x:1474,y:997,t:1526667324305};\\\", \\\"{x:1475,y:997,t:1526667324325};\\\", \\\"{x:1476,y:995,t:1526667324341};\\\", \\\"{x:1477,y:994,t:1526667324354};\\\", \\\"{x:1477,y:993,t:1526667324373};\\\", \\\"{x:1478,y:992,t:1526667324390};\\\", \\\"{x:1480,y:990,t:1526667324404};\\\", \\\"{x:1482,y:990,t:1526667324597};\\\", \\\"{x:1484,y:990,t:1526667324613};\\\", \\\"{x:1487,y:990,t:1526667324621};\\\", \\\"{x:1492,y:990,t:1526667324637};\\\", \\\"{x:1495,y:990,t:1526667324654};\\\", \\\"{x:1498,y:990,t:1526667324671};\\\", \\\"{x:1501,y:990,t:1526667324687};\\\", \\\"{x:1503,y:990,t:1526667324704};\\\", \\\"{x:1510,y:989,t:1526667324721};\\\", \\\"{x:1515,y:986,t:1526667324737};\\\", \\\"{x:1520,y:985,t:1526667324754};\\\", \\\"{x:1521,y:984,t:1526667324772};\\\", \\\"{x:1524,y:981,t:1526667324787};\\\", \\\"{x:1526,y:980,t:1526667324804};\\\", \\\"{x:1529,y:978,t:1526667324821};\\\", \\\"{x:1531,y:978,t:1526667324909};\\\", \\\"{x:1533,y:978,t:1526667324922};\\\", \\\"{x:1534,y:978,t:1526667324948};\\\", \\\"{x:1536,y:978,t:1526667324965};\\\", \\\"{x:1537,y:978,t:1526667324981};\\\", \\\"{x:1541,y:980,t:1526667324989};\\\", \\\"{x:1544,y:982,t:1526667325004};\\\", \\\"{x:1559,y:995,t:1526667325020};\\\", \\\"{x:1571,y:1001,t:1526667325038};\\\", \\\"{x:1581,y:1007,t:1526667325053};\\\", \\\"{x:1594,y:1010,t:1526667325070};\\\", \\\"{x:1602,y:1011,t:1526667325088};\\\", \\\"{x:1605,y:1011,t:1526667325104};\\\", \\\"{x:1606,y:1011,t:1526667325121};\\\", \\\"{x:1607,y:1011,t:1526667325138};\\\", \\\"{x:1609,y:1011,t:1526667325156};\\\", \\\"{x:1611,y:1011,t:1526667325205};\\\", \\\"{x:1614,y:1011,t:1526667325221};\\\", \\\"{x:1616,y:1010,t:1526667325244};\\\", \\\"{x:1617,y:1009,t:1526667325254};\\\", \\\"{x:1618,y:1007,t:1526667325271};\\\", \\\"{x:1619,y:1006,t:1526667325288};\\\", \\\"{x:1620,y:1005,t:1526667325304};\\\", \\\"{x:1622,y:1004,t:1526667325332};\\\", \\\"{x:1623,y:1003,t:1526667325339};\\\", \\\"{x:1624,y:1002,t:1526667325356};\\\", \\\"{x:1624,y:1001,t:1526667325371};\\\", \\\"{x:1625,y:1001,t:1526667325395};\\\", \\\"{x:1625,y:1000,t:1526667325412};\\\", \\\"{x:1627,y:1000,t:1526667325436};\\\", \\\"{x:1631,y:1000,t:1526667325452};\\\", \\\"{x:1636,y:1002,t:1526667325460};\\\", \\\"{x:1641,y:1006,t:1526667325470};\\\", \\\"{x:1649,y:1012,t:1526667325487};\\\", \\\"{x:1661,y:1015,t:1526667325503};\\\", \\\"{x:1675,y:1018,t:1526667325521};\\\", \\\"{x:1687,y:1018,t:1526667325537};\\\", \\\"{x:1694,y:1018,t:1526667325554};\\\", \\\"{x:1697,y:1018,t:1526667325570};\\\", \\\"{x:1699,y:1018,t:1526667325587};\\\", \\\"{x:1700,y:1018,t:1526667325604};\\\", \\\"{x:1702,y:1018,t:1526667325620};\\\", \\\"{x:1703,y:1016,t:1526667325638};\\\", \\\"{x:1705,y:1011,t:1526667325654};\\\", \\\"{x:1708,y:1003,t:1526667325671};\\\", \\\"{x:1708,y:999,t:1526667325687};\\\", \\\"{x:1708,y:996,t:1526667325703};\\\", \\\"{x:1708,y:994,t:1526667325757};\\\", \\\"{x:1708,y:993,t:1526667325772};\\\", \\\"{x:1695,y:987,t:1526667325789};\\\", \\\"{x:1693,y:984,t:1526667325804};\\\", \\\"{x:1692,y:984,t:1526667325821};\\\", \\\"{x:1689,y:984,t:1526667326253};\\\", \\\"{x:1688,y:984,t:1526667326277};\\\", \\\"{x:1685,y:984,t:1526667326742};\\\", \\\"{x:1681,y:985,t:1526667326756};\\\", \\\"{x:1677,y:985,t:1526667326773};\\\", \\\"{x:1676,y:985,t:1526667329333};\\\", \\\"{x:1667,y:984,t:1526667329341};\\\", \\\"{x:1636,y:950,t:1526667329357};\\\", \\\"{x:1557,y:893,t:1526667329373};\\\", \\\"{x:1467,y:837,t:1526667329390};\\\", \\\"{x:1355,y:775,t:1526667329406};\\\", \\\"{x:1233,y:722,t:1526667329422};\\\", \\\"{x:1113,y:676,t:1526667329438};\\\", \\\"{x:992,y:629,t:1526667329456};\\\", \\\"{x:857,y:590,t:1526667329472};\\\", \\\"{x:743,y:555,t:1526667329489};\\\", \\\"{x:657,y:542,t:1526667329507};\\\", \\\"{x:576,y:526,t:1526667329526};\\\", \\\"{x:556,y:523,t:1526667329543};\\\", \\\"{x:533,y:523,t:1526667329559};\\\", \\\"{x:511,y:523,t:1526667329578};\\\", \\\"{x:499,y:523,t:1526667329593};\\\", \\\"{x:483,y:522,t:1526667329610};\\\", \\\"{x:466,y:520,t:1526667329628};\\\", \\\"{x:463,y:524,t:1526667329644};\\\", \\\"{x:463,y:532,t:1526667329661};\\\", \\\"{x:474,y:536,t:1526667329678};\\\", \\\"{x:507,y:540,t:1526667329694};\\\", \\\"{x:537,y:540,t:1526667329710};\\\", \\\"{x:552,y:544,t:1526667329728};\\\", \\\"{x:576,y:543,t:1526667329744};\\\", \\\"{x:599,y:542,t:1526667329761};\\\", \\\"{x:613,y:538,t:1526667329778};\\\", \\\"{x:618,y:537,t:1526667329794};\\\", \\\"{x:621,y:536,t:1526667329811};\\\", \\\"{x:621,y:534,t:1526667329835};\\\", \\\"{x:621,y:533,t:1526667329845};\\\", \\\"{x:621,y:532,t:1526667329860};\\\", \\\"{x:621,y:530,t:1526667329877};\\\", \\\"{x:621,y:528,t:1526667329895};\\\", \\\"{x:621,y:524,t:1526667329911};\\\", \\\"{x:619,y:515,t:1526667329929};\\\", \\\"{x:613,y:506,t:1526667329945};\\\", \\\"{x:609,y:502,t:1526667329961};\\\", \\\"{x:608,y:501,t:1526667329978};\\\", \\\"{x:608,y:501,t:1526667330142};\\\", \\\"{x:608,y:509,t:1526667330219};\\\", \\\"{x:606,y:519,t:1526667330228};\\\", \\\"{x:602,y:546,t:1526667330245};\\\", \\\"{x:598,y:583,t:1526667330262};\\\", \\\"{x:583,y:628,t:1526667330278};\\\", \\\"{x:577,y:656,t:1526667330295};\\\", \\\"{x:570,y:674,t:1526667330311};\\\", \\\"{x:567,y:689,t:1526667330328};\\\", \\\"{x:565,y:693,t:1526667330344};\\\", \\\"{x:565,y:694,t:1526667330361};\\\", \\\"{x:564,y:697,t:1526667330378};\\\", \\\"{x:561,y:700,t:1526667330395};\\\", \\\"{x:560,y:703,t:1526667330411};\\\", \\\"{x:555,y:708,t:1526667330428};\\\", \\\"{x:551,y:710,t:1526667330445};\\\", \\\"{x:550,y:710,t:1526667330460};\\\", \\\"{x:548,y:710,t:1526667330477};\\\", \\\"{x:546,y:710,t:1526667330494};\\\", \\\"{x:543,y:710,t:1526667330511};\\\", \\\"{x:538,y:710,t:1526667330528};\\\", \\\"{x:533,y:710,t:1526667330544};\\\", \\\"{x:524,y:713,t:1526667330561};\\\", \\\"{x:522,y:715,t:1526667330578};\\\", \\\"{x:520,y:717,t:1526667330594};\\\", \\\"{x:519,y:717,t:1526667330611};\\\", \\\"{x:517,y:722,t:1526667330628};\\\", \\\"{x:517,y:723,t:1526667330644};\\\", \\\"{x:517,y:725,t:1526667330662};\\\", \\\"{x:517,y:726,t:1526667330679};\\\", \\\"{x:516,y:726,t:1526667330831};\\\", \\\"{x:515,y:726,t:1526667330845};\\\", \\\"{x:514,y:726,t:1526667331004};\\\", \\\"{x:513,y:726,t:1526667331027};\\\", \\\"{x:512,y:726,t:1526667331044};\\\", \\\"{x:511,y:726,t:1526667331117};\\\" ] }, { \\\"rt\\\": 64610, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 507127, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"HWJDK\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"men\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"diagonal\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"I\\\", \\\"M\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -I -09 AM-09 AM-09:30-10 AM-10:30-11 AM-12 PM-12:30-12:30-M -B -B -I -J -J -I -I -I -E -11 AM-11 AM-12 PM-01 PM-02 PM-03 PM-04 PM-05 PM-04 PM-05 PM-B -B -I -I -I -I -09:30-10 AM-12:30-M -M -M -M -M \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:515,y:726,t:1526667333092};\\\", \\\"{x:529,y:724,t:1526667333099};\\\", \\\"{x:542,y:724,t:1526667333114};\\\", \\\"{x:560,y:722,t:1526667333130};\\\", \\\"{x:594,y:722,t:1526667333147};\\\", \\\"{x:625,y:729,t:1526667333164};\\\", \\\"{x:638,y:732,t:1526667333180};\\\", \\\"{x:647,y:736,t:1526667333196};\\\", \\\"{x:651,y:740,t:1526667333214};\\\", \\\"{x:652,y:740,t:1526667333230};\\\", \\\"{x:653,y:741,t:1526667333247};\\\", \\\"{x:653,y:742,t:1526667333275};\\\", \\\"{x:654,y:742,t:1526667333283};\\\", \\\"{x:655,y:743,t:1526667333297};\\\", \\\"{x:661,y:745,t:1526667333314};\\\", \\\"{x:673,y:746,t:1526667333331};\\\", \\\"{x:689,y:752,t:1526667333346};\\\", \\\"{x:705,y:759,t:1526667333364};\\\", \\\"{x:712,y:764,t:1526667333381};\\\", \\\"{x:712,y:766,t:1526667333612};\\\", \\\"{x:713,y:766,t:1526667333700};\\\", \\\"{x:714,y:766,t:1526667333716};\\\", \\\"{x:717,y:766,t:1526667333730};\\\", \\\"{x:721,y:766,t:1526667333748};\\\", \\\"{x:722,y:766,t:1526667333764};\\\", \\\"{x:727,y:766,t:1526667333781};\\\", \\\"{x:731,y:765,t:1526667333798};\\\", \\\"{x:733,y:764,t:1526667333814};\\\", \\\"{x:735,y:764,t:1526667333831};\\\", \\\"{x:738,y:764,t:1526667333848};\\\", \\\"{x:746,y:764,t:1526667333864};\\\", \\\"{x:759,y:764,t:1526667333881};\\\", \\\"{x:775,y:764,t:1526667333898};\\\", \\\"{x:787,y:764,t:1526667333914};\\\", \\\"{x:806,y:764,t:1526667333930};\\\", \\\"{x:822,y:761,t:1526667333947};\\\", \\\"{x:825,y:761,t:1526667333963};\\\", \\\"{x:827,y:760,t:1526667333981};\\\", \\\"{x:828,y:760,t:1526667337347};\\\", \\\"{x:834,y:756,t:1526667337355};\\\", \\\"{x:848,y:751,t:1526667337367};\\\", \\\"{x:886,y:739,t:1526667337383};\\\", \\\"{x:925,y:729,t:1526667337400};\\\", \\\"{x:971,y:720,t:1526667337417};\\\", \\\"{x:998,y:717,t:1526667337434};\\\", \\\"{x:1020,y:710,t:1526667337450};\\\", \\\"{x:1044,y:707,t:1526667337467};\\\", \\\"{x:1045,y:707,t:1526667337483};\\\", \\\"{x:1053,y:707,t:1526667337500};\\\", \\\"{x:1054,y:707,t:1526667337517};\\\", \\\"{x:1056,y:706,t:1526667337572};\\\", \\\"{x:1058,y:705,t:1526667337585};\\\", \\\"{x:1067,y:703,t:1526667337600};\\\", \\\"{x:1074,y:701,t:1526667337616};\\\", \\\"{x:1082,y:699,t:1526667337634};\\\", \\\"{x:1087,y:698,t:1526667337650};\\\", \\\"{x:1089,y:698,t:1526667337668};\\\", \\\"{x:1089,y:697,t:1526667337755};\\\", \\\"{x:1089,y:695,t:1526667337771};\\\", \\\"{x:1088,y:695,t:1526667337784};\\\", \\\"{x:1087,y:694,t:1526667337800};\\\", \\\"{x:1086,y:694,t:1526667337817};\\\", \\\"{x:1085,y:694,t:1526667337834};\\\", \\\"{x:1082,y:694,t:1526667337850};\\\", \\\"{x:1076,y:694,t:1526667337867};\\\", \\\"{x:1074,y:695,t:1526667337883};\\\", \\\"{x:1070,y:697,t:1526667337900};\\\", \\\"{x:1066,y:700,t:1526667337917};\\\", \\\"{x:1062,y:703,t:1526667337933};\\\", \\\"{x:1056,y:705,t:1526667337950};\\\", \\\"{x:1053,y:706,t:1526667337967};\\\", \\\"{x:1052,y:707,t:1526667338300};\\\", \\\"{x:1050,y:707,t:1526667338307};\\\", \\\"{x:1050,y:708,t:1526667338317};\\\", \\\"{x:1048,y:708,t:1526667338334};\\\", \\\"{x:1047,y:708,t:1526667338412};\\\", \\\"{x:1045,y:708,t:1526667338428};\\\", \\\"{x:1043,y:708,t:1526667338451};\\\", \\\"{x:1042,y:709,t:1526667338500};\\\", \\\"{x:1040,y:709,t:1526667338507};\\\", \\\"{x:1039,y:710,t:1526667338518};\\\", \\\"{x:1037,y:711,t:1526667338534};\\\", \\\"{x:1035,y:713,t:1526667338551};\\\", \\\"{x:1034,y:713,t:1526667338587};\\\", \\\"{x:1032,y:713,t:1526667338619};\\\", \\\"{x:1031,y:713,t:1526667338635};\\\", \\\"{x:1029,y:713,t:1526667338651};\\\", \\\"{x:1028,y:713,t:1526667338675};\\\", \\\"{x:1026,y:713,t:1526667338684};\\\", \\\"{x:1025,y:714,t:1526667338700};\\\", \\\"{x:1022,y:715,t:1526667338718};\\\", \\\"{x:1019,y:715,t:1526667338734};\\\", \\\"{x:1017,y:717,t:1526667338751};\\\", \\\"{x:1016,y:717,t:1526667338768};\\\", \\\"{x:1015,y:717,t:1526667338916};\\\", \\\"{x:1012,y:717,t:1526667338924};\\\", \\\"{x:1008,y:717,t:1526667338935};\\\", \\\"{x:1004,y:718,t:1526667338951};\\\", \\\"{x:1002,y:718,t:1526667338968};\\\", \\\"{x:998,y:720,t:1526667338984};\\\", \\\"{x:997,y:720,t:1526667339001};\\\", \\\"{x:996,y:720,t:1526667339018};\\\", \\\"{x:994,y:720,t:1526667339035};\\\", \\\"{x:991,y:720,t:1526667339051};\\\", \\\"{x:988,y:720,t:1526667339068};\\\", \\\"{x:986,y:720,t:1526667339085};\\\", \\\"{x:985,y:720,t:1526667339100};\\\", \\\"{x:983,y:720,t:1526667339117};\\\", \\\"{x:981,y:720,t:1526667339135};\\\", \\\"{x:976,y:720,t:1526667339151};\\\", \\\"{x:974,y:720,t:1526667339167};\\\", \\\"{x:973,y:720,t:1526667339184};\\\", \\\"{x:972,y:720,t:1526667339200};\\\", \\\"{x:971,y:720,t:1526667339219};\\\", \\\"{x:969,y:720,t:1526667339252};\\\", \\\"{x:967,y:720,t:1526667339268};\\\", \\\"{x:964,y:720,t:1526667339291};\\\", \\\"{x:962,y:721,t:1526667339301};\\\", \\\"{x:960,y:721,t:1526667339318};\\\", \\\"{x:956,y:723,t:1526667339335};\\\", \\\"{x:948,y:725,t:1526667339351};\\\", \\\"{x:939,y:730,t:1526667339368};\\\", \\\"{x:933,y:734,t:1526667339385};\\\", \\\"{x:927,y:737,t:1526667339401};\\\", \\\"{x:925,y:738,t:1526667339418};\\\", \\\"{x:924,y:738,t:1526667339891};\\\", \\\"{x:925,y:741,t:1526667339902};\\\", \\\"{x:964,y:745,t:1526667339919};\\\", \\\"{x:1043,y:747,t:1526667339935};\\\", \\\"{x:1135,y:749,t:1526667339952};\\\", \\\"{x:1220,y:756,t:1526667339969};\\\", \\\"{x:1315,y:770,t:1526667339985};\\\", \\\"{x:1358,y:782,t:1526667340002};\\\", \\\"{x:1387,y:785,t:1526667340019};\\\", \\\"{x:1397,y:786,t:1526667340035};\\\", \\\"{x:1399,y:788,t:1526667340052};\\\", \\\"{x:1399,y:789,t:1526667340116};\\\", \\\"{x:1400,y:789,t:1526667340123};\\\", \\\"{x:1394,y:788,t:1526667340187};\\\", \\\"{x:1387,y:783,t:1526667340202};\\\", \\\"{x:1365,y:773,t:1526667340219};\\\", \\\"{x:1348,y:770,t:1526667340235};\\\", \\\"{x:1329,y:778,t:1526667340253};\\\", \\\"{x:1313,y:797,t:1526667340269};\\\", \\\"{x:1303,y:814,t:1526667340285};\\\", \\\"{x:1291,y:826,t:1526667340302};\\\", \\\"{x:1283,y:832,t:1526667340319};\\\", \\\"{x:1278,y:833,t:1526667340336};\\\", \\\"{x:1274,y:836,t:1526667340352};\\\", \\\"{x:1273,y:837,t:1526667340369};\\\", \\\"{x:1272,y:838,t:1526667340386};\\\", \\\"{x:1271,y:838,t:1526667340403};\\\", \\\"{x:1271,y:839,t:1526667340419};\\\", \\\"{x:1265,y:840,t:1526667340435};\\\", \\\"{x:1259,y:842,t:1526667340452};\\\", \\\"{x:1252,y:842,t:1526667340469};\\\", \\\"{x:1241,y:842,t:1526667340486};\\\", \\\"{x:1230,y:842,t:1526667340502};\\\", \\\"{x:1221,y:841,t:1526667340519};\\\", \\\"{x:1210,y:838,t:1526667340536};\\\", \\\"{x:1205,y:837,t:1526667340552};\\\", \\\"{x:1199,y:836,t:1526667340569};\\\", \\\"{x:1196,y:836,t:1526667340586};\\\", \\\"{x:1201,y:834,t:1526667340700};\\\", \\\"{x:1203,y:832,t:1526667340707};\\\", \\\"{x:1207,y:832,t:1526667340719};\\\", \\\"{x:1213,y:829,t:1526667340737};\\\", \\\"{x:1218,y:828,t:1526667340752};\\\", \\\"{x:1220,y:828,t:1526667340769};\\\", \\\"{x:1220,y:825,t:1526667342636};\\\", \\\"{x:1217,y:819,t:1526667342643};\\\", \\\"{x:1208,y:810,t:1526667342654};\\\", \\\"{x:1188,y:793,t:1526667342670};\\\", \\\"{x:1167,y:775,t:1526667342687};\\\", \\\"{x:1161,y:767,t:1526667342704};\\\", \\\"{x:1159,y:764,t:1526667342721};\\\", \\\"{x:1157,y:762,t:1526667342737};\\\", \\\"{x:1157,y:760,t:1526667342755};\\\", \\\"{x:1157,y:758,t:1526667342772};\\\", \\\"{x:1156,y:756,t:1526667342787};\\\", \\\"{x:1156,y:755,t:1526667342804};\\\", \\\"{x:1156,y:754,t:1526667342884};\\\", \\\"{x:1158,y:754,t:1526667342891};\\\", \\\"{x:1160,y:754,t:1526667342904};\\\", \\\"{x:1166,y:756,t:1526667342921};\\\", \\\"{x:1169,y:756,t:1526667342937};\\\", \\\"{x:1169,y:757,t:1526667342954};\\\", \\\"{x:1170,y:757,t:1526667342971};\\\", \\\"{x:1172,y:757,t:1526667343060};\\\", \\\"{x:1173,y:758,t:1526667343075};\\\", \\\"{x:1174,y:759,t:1526667343180};\\\", \\\"{x:1175,y:759,t:1526667343187};\\\", \\\"{x:1177,y:761,t:1526667343205};\\\", \\\"{x:1178,y:763,t:1526667345691};\\\", \\\"{x:1178,y:771,t:1526667345706};\\\", \\\"{x:1178,y:789,t:1526667345723};\\\", \\\"{x:1179,y:798,t:1526667345739};\\\", \\\"{x:1180,y:807,t:1526667345756};\\\", \\\"{x:1180,y:812,t:1526667345773};\\\", \\\"{x:1180,y:816,t:1526667345789};\\\", \\\"{x:1180,y:822,t:1526667345806};\\\", \\\"{x:1178,y:831,t:1526667345823};\\\", \\\"{x:1177,y:839,t:1526667345839};\\\", \\\"{x:1174,y:848,t:1526667345856};\\\", \\\"{x:1173,y:859,t:1526667345873};\\\", \\\"{x:1172,y:867,t:1526667345889};\\\", \\\"{x:1169,y:875,t:1526667345906};\\\", \\\"{x:1165,y:884,t:1526667345923};\\\", \\\"{x:1162,y:894,t:1526667345940};\\\", \\\"{x:1158,y:902,t:1526667345956};\\\", \\\"{x:1155,y:917,t:1526667345973};\\\", \\\"{x:1155,y:933,t:1526667345990};\\\", \\\"{x:1155,y:952,t:1526667346006};\\\", \\\"{x:1153,y:970,t:1526667346023};\\\", \\\"{x:1151,y:984,t:1526667346040};\\\", \\\"{x:1150,y:993,t:1526667346056};\\\", \\\"{x:1150,y:1000,t:1526667346073};\\\", \\\"{x:1150,y:1003,t:1526667346090};\\\", \\\"{x:1150,y:1005,t:1526667346106};\\\", \\\"{x:1150,y:1006,t:1526667346156};\\\", \\\"{x:1153,y:1006,t:1526667346171};\\\", \\\"{x:1154,y:1006,t:1526667346179};\\\", \\\"{x:1156,y:1004,t:1526667346190};\\\", \\\"{x:1159,y:1001,t:1526667346206};\\\", \\\"{x:1165,y:997,t:1526667346224};\\\", \\\"{x:1168,y:992,t:1526667346240};\\\", \\\"{x:1172,y:987,t:1526667346256};\\\", \\\"{x:1175,y:982,t:1526667346273};\\\", \\\"{x:1178,y:976,t:1526667346290};\\\", \\\"{x:1182,y:971,t:1526667346306};\\\", \\\"{x:1187,y:966,t:1526667346323};\\\", \\\"{x:1189,y:965,t:1526667346340};\\\", \\\"{x:1190,y:965,t:1526667346356};\\\", \\\"{x:1190,y:964,t:1526667346467};\\\", \\\"{x:1191,y:964,t:1526667346556};\\\", \\\"{x:1191,y:965,t:1526667346571};\\\", \\\"{x:1191,y:968,t:1526667346579};\\\", \\\"{x:1193,y:970,t:1526667346590};\\\", \\\"{x:1197,y:975,t:1526667346607};\\\", \\\"{x:1201,y:979,t:1526667346623};\\\", \\\"{x:1214,y:983,t:1526667346640};\\\", \\\"{x:1221,y:985,t:1526667346657};\\\", \\\"{x:1229,y:986,t:1526667346673};\\\", \\\"{x:1235,y:986,t:1526667346690};\\\", \\\"{x:1238,y:986,t:1526667346708};\\\", \\\"{x:1239,y:986,t:1526667346723};\\\", \\\"{x:1240,y:986,t:1526667346747};\\\", \\\"{x:1241,y:986,t:1526667346757};\\\", \\\"{x:1241,y:983,t:1526667346773};\\\", \\\"{x:1242,y:979,t:1526667346790};\\\", \\\"{x:1243,y:976,t:1526667346807};\\\", \\\"{x:1243,y:974,t:1526667346824};\\\", \\\"{x:1244,y:972,t:1526667346840};\\\", \\\"{x:1245,y:971,t:1526667346857};\\\", \\\"{x:1246,y:970,t:1526667346875};\\\", \\\"{x:1249,y:972,t:1526667346995};\\\", \\\"{x:1252,y:974,t:1526667347007};\\\", \\\"{x:1257,y:979,t:1526667347025};\\\", \\\"{x:1266,y:983,t:1526667347040};\\\", \\\"{x:1271,y:986,t:1526667347057};\\\", \\\"{x:1278,y:987,t:1526667347074};\\\", \\\"{x:1283,y:988,t:1526667347090};\\\", \\\"{x:1289,y:988,t:1526667347107};\\\", \\\"{x:1290,y:988,t:1526667347124};\\\", \\\"{x:1296,y:988,t:1526667347140};\\\", \\\"{x:1301,y:988,t:1526667347157};\\\", \\\"{x:1304,y:987,t:1526667347175};\\\", \\\"{x:1307,y:984,t:1526667347191};\\\", \\\"{x:1308,y:984,t:1526667347207};\\\", \\\"{x:1310,y:981,t:1526667347235};\\\", \\\"{x:1311,y:981,t:1526667347283};\\\", \\\"{x:1312,y:981,t:1526667347428};\\\", \\\"{x:1313,y:981,t:1526667347440};\\\", \\\"{x:1320,y:981,t:1526667347457};\\\", \\\"{x:1331,y:983,t:1526667347475};\\\", \\\"{x:1338,y:984,t:1526667347491};\\\", \\\"{x:1344,y:984,t:1526667347507};\\\", \\\"{x:1348,y:984,t:1526667347525};\\\", \\\"{x:1352,y:984,t:1526667347541};\\\", \\\"{x:1356,y:984,t:1526667347557};\\\", \\\"{x:1358,y:984,t:1526667347574};\\\", \\\"{x:1361,y:983,t:1526667347591};\\\", \\\"{x:1364,y:983,t:1526667347608};\\\", \\\"{x:1369,y:982,t:1526667347624};\\\", \\\"{x:1373,y:979,t:1526667347641};\\\", \\\"{x:1374,y:979,t:1526667347657};\\\", \\\"{x:1374,y:978,t:1526667347731};\\\", \\\"{x:1375,y:978,t:1526667347755};\\\", \\\"{x:1376,y:978,t:1526667347771};\\\", \\\"{x:1377,y:977,t:1526667347779};\\\", \\\"{x:1380,y:976,t:1526667347791};\\\", \\\"{x:1381,y:975,t:1526667347808};\\\", \\\"{x:1384,y:974,t:1526667347825};\\\", \\\"{x:1384,y:973,t:1526667347972};\\\", \\\"{x:1384,y:972,t:1526667347988};\\\", \\\"{x:1383,y:971,t:1526667348003};\\\", \\\"{x:1381,y:969,t:1526667348027};\\\", \\\"{x:1381,y:967,t:1526667348041};\\\", \\\"{x:1379,y:964,t:1526667348059};\\\", \\\"{x:1377,y:962,t:1526667348075};\\\", \\\"{x:1377,y:956,t:1526667348091};\\\", \\\"{x:1376,y:950,t:1526667348108};\\\", \\\"{x:1374,y:943,t:1526667348124};\\\", \\\"{x:1373,y:932,t:1526667348141};\\\", \\\"{x:1373,y:922,t:1526667348158};\\\", \\\"{x:1372,y:919,t:1526667348174};\\\", \\\"{x:1372,y:915,t:1526667348192};\\\", \\\"{x:1372,y:913,t:1526667348208};\\\", \\\"{x:1372,y:909,t:1526667348224};\\\", \\\"{x:1372,y:906,t:1526667348241};\\\", \\\"{x:1372,y:905,t:1526667348259};\\\", \\\"{x:1372,y:902,t:1526667348274};\\\", \\\"{x:1373,y:900,t:1526667348291};\\\", \\\"{x:1374,y:895,t:1526667348308};\\\", \\\"{x:1374,y:894,t:1526667348324};\\\", \\\"{x:1374,y:892,t:1526667348341};\\\", \\\"{x:1374,y:890,t:1526667348358};\\\", \\\"{x:1375,y:887,t:1526667348374};\\\", \\\"{x:1375,y:884,t:1526667348392};\\\", \\\"{x:1376,y:882,t:1526667348408};\\\", \\\"{x:1377,y:881,t:1526667348425};\\\", \\\"{x:1378,y:878,t:1526667348441};\\\", \\\"{x:1380,y:873,t:1526667348458};\\\", \\\"{x:1381,y:870,t:1526667348475};\\\", \\\"{x:1383,y:867,t:1526667348491};\\\", \\\"{x:1383,y:863,t:1526667348508};\\\", \\\"{x:1384,y:857,t:1526667348525};\\\", \\\"{x:1385,y:853,t:1526667348541};\\\", \\\"{x:1385,y:847,t:1526667348558};\\\", \\\"{x:1386,y:836,t:1526667348575};\\\", \\\"{x:1386,y:816,t:1526667348591};\\\", \\\"{x:1386,y:797,t:1526667348608};\\\", \\\"{x:1386,y:790,t:1526667348625};\\\", \\\"{x:1385,y:786,t:1526667348641};\\\", \\\"{x:1385,y:782,t:1526667348658};\\\", \\\"{x:1383,y:774,t:1526667348674};\\\", \\\"{x:1379,y:771,t:1526667350003};\\\", \\\"{x:1372,y:770,t:1526667350011};\\\", \\\"{x:1370,y:769,t:1526667350026};\\\", \\\"{x:1363,y:769,t:1526667350043};\\\", \\\"{x:1349,y:769,t:1526667350059};\\\", \\\"{x:1344,y:767,t:1526667350076};\\\", \\\"{x:1342,y:767,t:1526667350093};\\\", \\\"{x:1340,y:767,t:1526667350109};\\\", \\\"{x:1342,y:765,t:1526667350435};\\\", \\\"{x:1344,y:763,t:1526667350443};\\\", \\\"{x:1347,y:759,t:1526667350459};\\\", \\\"{x:1348,y:759,t:1526667350476};\\\", \\\"{x:1348,y:758,t:1526667350493};\\\", \\\"{x:1347,y:758,t:1526667351339};\\\", \\\"{x:1341,y:758,t:1526667351347};\\\", \\\"{x:1326,y:758,t:1526667351360};\\\", \\\"{x:1276,y:758,t:1526667351377};\\\", \\\"{x:1228,y:764,t:1526667351393};\\\", \\\"{x:1199,y:768,t:1526667351411};\\\", \\\"{x:1167,y:770,t:1526667351427};\\\", \\\"{x:1159,y:770,t:1526667351443};\\\", \\\"{x:1158,y:770,t:1526667351460};\\\", \\\"{x:1158,y:771,t:1526667351579};\\\", \\\"{x:1158,y:772,t:1526667351593};\\\", \\\"{x:1158,y:773,t:1526667351610};\\\", \\\"{x:1163,y:775,t:1526667351626};\\\", \\\"{x:1166,y:775,t:1526667351643};\\\", \\\"{x:1173,y:774,t:1526667351661};\\\", \\\"{x:1175,y:772,t:1526667351678};\\\", \\\"{x:1176,y:772,t:1526667351693};\\\", \\\"{x:1179,y:771,t:1526667351710};\\\", \\\"{x:1184,y:769,t:1526667351727};\\\", \\\"{x:1187,y:768,t:1526667351744};\\\", \\\"{x:1191,y:768,t:1526667351761};\\\", \\\"{x:1193,y:768,t:1526667351778};\\\", \\\"{x:1193,y:767,t:1526667351875};\\\", \\\"{x:1193,y:766,t:1526667351883};\\\", \\\"{x:1193,y:764,t:1526667351899};\\\", \\\"{x:1192,y:764,t:1526667351910};\\\", \\\"{x:1189,y:761,t:1526667351928};\\\", \\\"{x:1184,y:758,t:1526667351944};\\\", \\\"{x:1183,y:758,t:1526667351960};\\\", \\\"{x:1182,y:758,t:1526667351978};\\\", \\\"{x:1182,y:766,t:1526667354347};\\\", \\\"{x:1185,y:776,t:1526667354363};\\\", \\\"{x:1194,y:815,t:1526667354379};\\\", \\\"{x:1200,y:826,t:1526667354396};\\\", \\\"{x:1202,y:832,t:1526667354412};\\\", \\\"{x:1204,y:832,t:1526667354683};\\\", \\\"{x:1205,y:832,t:1526667354699};\\\", \\\"{x:1206,y:831,t:1526667354712};\\\", \\\"{x:1207,y:830,t:1526667354860};\\\", \\\"{x:1210,y:829,t:1526667354867};\\\", \\\"{x:1211,y:829,t:1526667354880};\\\", \\\"{x:1213,y:829,t:1526667354907};\\\", \\\"{x:1214,y:829,t:1526667354915};\\\", \\\"{x:1214,y:827,t:1526667356659};\\\", \\\"{x:1213,y:823,t:1526667356667};\\\", \\\"{x:1210,y:816,t:1526667356680};\\\", \\\"{x:1208,y:805,t:1526667356698};\\\", \\\"{x:1202,y:793,t:1526667356715};\\\", \\\"{x:1198,y:788,t:1526667356731};\\\", \\\"{x:1195,y:780,t:1526667356747};\\\", \\\"{x:1194,y:778,t:1526667356765};\\\", \\\"{x:1194,y:775,t:1526667356781};\\\", \\\"{x:1193,y:771,t:1526667356797};\\\", \\\"{x:1192,y:767,t:1526667356814};\\\", \\\"{x:1192,y:764,t:1526667356831};\\\", \\\"{x:1191,y:757,t:1526667356848};\\\", \\\"{x:1189,y:753,t:1526667356864};\\\", \\\"{x:1189,y:750,t:1526667356881};\\\", \\\"{x:1188,y:748,t:1526667356897};\\\", \\\"{x:1187,y:746,t:1526667356915};\\\", \\\"{x:1186,y:743,t:1526667356931};\\\", \\\"{x:1185,y:740,t:1526667356947};\\\", \\\"{x:1185,y:736,t:1526667356964};\\\", \\\"{x:1184,y:734,t:1526667356982};\\\", \\\"{x:1182,y:728,t:1526667356997};\\\", \\\"{x:1182,y:726,t:1526667357014};\\\", \\\"{x:1181,y:726,t:1526667357035};\\\", \\\"{x:1181,y:731,t:1526667357643};\\\", \\\"{x:1181,y:733,t:1526667357650};\\\", \\\"{x:1181,y:738,t:1526667357664};\\\", \\\"{x:1180,y:740,t:1526667357681};\\\", \\\"{x:1179,y:745,t:1526667357698};\\\", \\\"{x:1178,y:746,t:1526667357715};\\\", \\\"{x:1178,y:747,t:1526667357732};\\\", \\\"{x:1178,y:748,t:1526667357748};\\\", \\\"{x:1178,y:749,t:1526667358051};\\\", \\\"{x:1178,y:750,t:1526667358065};\\\", \\\"{x:1177,y:751,t:1526667358082};\\\", \\\"{x:1177,y:752,t:1526667358098};\\\", \\\"{x:1177,y:753,t:1526667358116};\\\", \\\"{x:1177,y:754,t:1526667358132};\\\", \\\"{x:1176,y:755,t:1526667358195};\\\", \\\"{x:1176,y:758,t:1526667358363};\\\", \\\"{x:1176,y:760,t:1526667358371};\\\", \\\"{x:1176,y:761,t:1526667358383};\\\", \\\"{x:1176,y:767,t:1526667358399};\\\", \\\"{x:1177,y:769,t:1526667358415};\\\", \\\"{x:1177,y:768,t:1526667358739};\\\", \\\"{x:1177,y:767,t:1526667358749};\\\", \\\"{x:1177,y:766,t:1526667358765};\\\", \\\"{x:1178,y:765,t:1526667358835};\\\", \\\"{x:1180,y:762,t:1526667359219};\\\", \\\"{x:1183,y:759,t:1526667359232};\\\", \\\"{x:1188,y:751,t:1526667359250};\\\", \\\"{x:1192,y:746,t:1526667359266};\\\", \\\"{x:1195,y:741,t:1526667359283};\\\", \\\"{x:1203,y:734,t:1526667359300};\\\", \\\"{x:1210,y:726,t:1526667359315};\\\", \\\"{x:1217,y:717,t:1526667359332};\\\", \\\"{x:1222,y:711,t:1526667359350};\\\", \\\"{x:1225,y:706,t:1526667359367};\\\", \\\"{x:1231,y:697,t:1526667359382};\\\", \\\"{x:1234,y:693,t:1526667359399};\\\", \\\"{x:1237,y:689,t:1526667359416};\\\", \\\"{x:1243,y:679,t:1526667359432};\\\", \\\"{x:1253,y:654,t:1526667359450};\\\", \\\"{x:1258,y:639,t:1526667359467};\\\", \\\"{x:1260,y:632,t:1526667359482};\\\", \\\"{x:1263,y:629,t:1526667359500};\\\", \\\"{x:1264,y:625,t:1526667359517};\\\", \\\"{x:1265,y:622,t:1526667359532};\\\", \\\"{x:1267,y:618,t:1526667359549};\\\", \\\"{x:1269,y:612,t:1526667359566};\\\", \\\"{x:1270,y:610,t:1526667359583};\\\", \\\"{x:1271,y:608,t:1526667359600};\\\", \\\"{x:1274,y:604,t:1526667359616};\\\", \\\"{x:1275,y:601,t:1526667359632};\\\", \\\"{x:1275,y:597,t:1526667359650};\\\", \\\"{x:1275,y:593,t:1526667359667};\\\", \\\"{x:1275,y:591,t:1526667359755};\\\", \\\"{x:1275,y:590,t:1526667359767};\\\", \\\"{x:1275,y:588,t:1526667359783};\\\", \\\"{x:1275,y:585,t:1526667359799};\\\", \\\"{x:1275,y:581,t:1526667359817};\\\", \\\"{x:1277,y:577,t:1526667359834};\\\", \\\"{x:1278,y:572,t:1526667359850};\\\", \\\"{x:1280,y:566,t:1526667359867};\\\", \\\"{x:1281,y:564,t:1526667359883};\\\", \\\"{x:1282,y:561,t:1526667359900};\\\", \\\"{x:1284,y:559,t:1526667359917};\\\", \\\"{x:1284,y:558,t:1526667360419};\\\", \\\"{x:1284,y:559,t:1526667360578};\\\", \\\"{x:1284,y:562,t:1526667360586};\\\", \\\"{x:1284,y:563,t:1526667360600};\\\", \\\"{x:1284,y:570,t:1526667360616};\\\", \\\"{x:1283,y:573,t:1526667360633};\\\", \\\"{x:1283,y:574,t:1526667360651};\\\", \\\"{x:1283,y:576,t:1526667360667};\\\", \\\"{x:1283,y:578,t:1526667360683};\\\", \\\"{x:1283,y:579,t:1526667360700};\\\", \\\"{x:1283,y:582,t:1526667360716};\\\", \\\"{x:1283,y:584,t:1526667360734};\\\", \\\"{x:1283,y:586,t:1526667360750};\\\", \\\"{x:1284,y:590,t:1526667360768};\\\", \\\"{x:1284,y:593,t:1526667360784};\\\", \\\"{x:1284,y:598,t:1526667360801};\\\", \\\"{x:1285,y:603,t:1526667360818};\\\", \\\"{x:1286,y:608,t:1526667360833};\\\", \\\"{x:1286,y:615,t:1526667360851};\\\", \\\"{x:1288,y:621,t:1526667360867};\\\", \\\"{x:1288,y:626,t:1526667360883};\\\", \\\"{x:1288,y:630,t:1526667360901};\\\", \\\"{x:1287,y:639,t:1526667360918};\\\", \\\"{x:1286,y:644,t:1526667360933};\\\", \\\"{x:1286,y:648,t:1526667360951};\\\", \\\"{x:1286,y:658,t:1526667360968};\\\", \\\"{x:1286,y:669,t:1526667360983};\\\", \\\"{x:1286,y:684,t:1526667361001};\\\", \\\"{x:1286,y:698,t:1526667361018};\\\", \\\"{x:1286,y:709,t:1526667361033};\\\", \\\"{x:1286,y:720,t:1526667361051};\\\", \\\"{x:1286,y:726,t:1526667361068};\\\", \\\"{x:1286,y:736,t:1526667361083};\\\", \\\"{x:1286,y:744,t:1526667361101};\\\", \\\"{x:1286,y:756,t:1526667361118};\\\", \\\"{x:1288,y:770,t:1526667361133};\\\", \\\"{x:1289,y:784,t:1526667361150};\\\", \\\"{x:1291,y:794,t:1526667361168};\\\", \\\"{x:1291,y:800,t:1526667361183};\\\", \\\"{x:1293,y:807,t:1526667361200};\\\", \\\"{x:1294,y:816,t:1526667361218};\\\", \\\"{x:1295,y:826,t:1526667361234};\\\", \\\"{x:1295,y:836,t:1526667361251};\\\", \\\"{x:1295,y:843,t:1526667361268};\\\", \\\"{x:1295,y:848,t:1526667361285};\\\", \\\"{x:1295,y:856,t:1526667361301};\\\", \\\"{x:1295,y:863,t:1526667361318};\\\", \\\"{x:1295,y:871,t:1526667361335};\\\", \\\"{x:1294,y:880,t:1526667361351};\\\", \\\"{x:1293,y:890,t:1526667361368};\\\", \\\"{x:1292,y:899,t:1526667361385};\\\", \\\"{x:1292,y:913,t:1526667361401};\\\", \\\"{x:1292,y:922,t:1526667361417};\\\", \\\"{x:1292,y:934,t:1526667361435};\\\", \\\"{x:1292,y:938,t:1526667361451};\\\", \\\"{x:1292,y:942,t:1526667361468};\\\", \\\"{x:1292,y:948,t:1526667361485};\\\", \\\"{x:1292,y:953,t:1526667361501};\\\", \\\"{x:1292,y:959,t:1526667361517};\\\", \\\"{x:1292,y:961,t:1526667361535};\\\", \\\"{x:1292,y:963,t:1526667361551};\\\", \\\"{x:1292,y:965,t:1526667361568};\\\", \\\"{x:1292,y:966,t:1526667361603};\\\", \\\"{x:1291,y:966,t:1526667361618};\\\", \\\"{x:1290,y:967,t:1526667361634};\\\", \\\"{x:1287,y:967,t:1526667361651};\\\", \\\"{x:1286,y:967,t:1526667361668};\\\", \\\"{x:1285,y:967,t:1526667361684};\\\", \\\"{x:1282,y:968,t:1526667361702};\\\", \\\"{x:1280,y:970,t:1526667361718};\\\", \\\"{x:1279,y:970,t:1526667362043};\\\", \\\"{x:1279,y:972,t:1526667362052};\\\", \\\"{x:1278,y:975,t:1526667362068};\\\", \\\"{x:1278,y:977,t:1526667362084};\\\", \\\"{x:1278,y:978,t:1526667362443};\\\", \\\"{x:1280,y:979,t:1526667362452};\\\", \\\"{x:1288,y:981,t:1526667362469};\\\", \\\"{x:1296,y:983,t:1526667362484};\\\", \\\"{x:1301,y:984,t:1526667362502};\\\", \\\"{x:1308,y:985,t:1526667362519};\\\", \\\"{x:1311,y:985,t:1526667362534};\\\", \\\"{x:1314,y:986,t:1526667362552};\\\", \\\"{x:1317,y:986,t:1526667362568};\\\", \\\"{x:1323,y:988,t:1526667362585};\\\", \\\"{x:1329,y:989,t:1526667362602};\\\", \\\"{x:1337,y:990,t:1526667362619};\\\", \\\"{x:1340,y:991,t:1526667362635};\\\", \\\"{x:1341,y:991,t:1526667362762};\\\", \\\"{x:1342,y:991,t:1526667362778};\\\", \\\"{x:1343,y:991,t:1526667362786};\\\", \\\"{x:1344,y:991,t:1526667362803};\\\", \\\"{x:1349,y:991,t:1526667362819};\\\", \\\"{x:1355,y:991,t:1526667362836};\\\", \\\"{x:1362,y:991,t:1526667362851};\\\", \\\"{x:1368,y:991,t:1526667362869};\\\", \\\"{x:1375,y:991,t:1526667362886};\\\", \\\"{x:1377,y:991,t:1526667362902};\\\", \\\"{x:1379,y:991,t:1526667362919};\\\", \\\"{x:1384,y:991,t:1526667362936};\\\", \\\"{x:1389,y:991,t:1526667362952};\\\", \\\"{x:1392,y:991,t:1526667362969};\\\", \\\"{x:1393,y:991,t:1526667362986};\\\", \\\"{x:1394,y:991,t:1526667363001};\\\", \\\"{x:1398,y:991,t:1526667363019};\\\", \\\"{x:1401,y:991,t:1526667363036};\\\", \\\"{x:1406,y:989,t:1526667363052};\\\", \\\"{x:1409,y:989,t:1526667363069};\\\", \\\"{x:1412,y:989,t:1526667363085};\\\", \\\"{x:1414,y:988,t:1526667363107};\\\", \\\"{x:1415,y:988,t:1526667363139};\\\", \\\"{x:1416,y:988,t:1526667363153};\\\", \\\"{x:1419,y:986,t:1526667363169};\\\", \\\"{x:1421,y:985,t:1526667363185};\\\", \\\"{x:1423,y:984,t:1526667363202};\\\", \\\"{x:1426,y:983,t:1526667363219};\\\", \\\"{x:1429,y:983,t:1526667363291};\\\", \\\"{x:1430,y:983,t:1526667363315};\\\", \\\"{x:1431,y:983,t:1526667363322};\\\", \\\"{x:1433,y:983,t:1526667363336};\\\", \\\"{x:1437,y:984,t:1526667363353};\\\", \\\"{x:1442,y:986,t:1526667363369};\\\", \\\"{x:1448,y:988,t:1526667363386};\\\", \\\"{x:1459,y:991,t:1526667363403};\\\", \\\"{x:1463,y:992,t:1526667363419};\\\", \\\"{x:1466,y:993,t:1526667363436};\\\", \\\"{x:1468,y:993,t:1526667363531};\\\", \\\"{x:1472,y:992,t:1526667363539};\\\", \\\"{x:1473,y:990,t:1526667363553};\\\", \\\"{x:1477,y:989,t:1526667363568};\\\", \\\"{x:1480,y:989,t:1526667363586};\\\", \\\"{x:1482,y:987,t:1526667363603};\\\", \\\"{x:1483,y:987,t:1526667363620};\\\", \\\"{x:1486,y:987,t:1526667363715};\\\", \\\"{x:1489,y:987,t:1526667363722};\\\", \\\"{x:1493,y:988,t:1526667363736};\\\", \\\"{x:1501,y:990,t:1526667363753};\\\", \\\"{x:1514,y:992,t:1526667363770};\\\", \\\"{x:1530,y:993,t:1526667363786};\\\", \\\"{x:1543,y:993,t:1526667363802};\\\", \\\"{x:1546,y:993,t:1526667363820};\\\", \\\"{x:1548,y:993,t:1526667363867};\\\", \\\"{x:1550,y:992,t:1526667363874};\\\", \\\"{x:1550,y:991,t:1526667363886};\\\", \\\"{x:1552,y:990,t:1526667363903};\\\", \\\"{x:1554,y:988,t:1526667363920};\\\", \\\"{x:1556,y:987,t:1526667363936};\\\", \\\"{x:1557,y:986,t:1526667363955};\\\", \\\"{x:1558,y:984,t:1526667363995};\\\", \\\"{x:1560,y:984,t:1526667364098};\\\", \\\"{x:1562,y:984,t:1526667364107};\\\", \\\"{x:1563,y:984,t:1526667364120};\\\", \\\"{x:1569,y:984,t:1526667364137};\\\", \\\"{x:1572,y:985,t:1526667364153};\\\", \\\"{x:1581,y:988,t:1526667364169};\\\", \\\"{x:1589,y:989,t:1526667364187};\\\", \\\"{x:1590,y:989,t:1526667364203};\\\", \\\"{x:1593,y:989,t:1526667364220};\\\", \\\"{x:1597,y:989,t:1526667364237};\\\", \\\"{x:1599,y:989,t:1526667364253};\\\", \\\"{x:1600,y:988,t:1526667364270};\\\", \\\"{x:1602,y:987,t:1526667364287};\\\", \\\"{x:1604,y:986,t:1526667364303};\\\", \\\"{x:1604,y:985,t:1526667364323};\\\", \\\"{x:1605,y:985,t:1526667364336};\\\", \\\"{x:1606,y:984,t:1526667364353};\\\", \\\"{x:1607,y:984,t:1526667364370};\\\", \\\"{x:1609,y:982,t:1526667364387};\\\", \\\"{x:1610,y:982,t:1526667364403};\\\", \\\"{x:1614,y:981,t:1526667364420};\\\", \\\"{x:1616,y:980,t:1526667364437};\\\", \\\"{x:1617,y:980,t:1526667364453};\\\", \\\"{x:1625,y:983,t:1526667364470};\\\", \\\"{x:1633,y:988,t:1526667364487};\\\", \\\"{x:1645,y:993,t:1526667364503};\\\", \\\"{x:1655,y:998,t:1526667364520};\\\", \\\"{x:1669,y:1001,t:1526667364536};\\\", \\\"{x:1676,y:1002,t:1526667364553};\\\", \\\"{x:1684,y:1002,t:1526667364570};\\\", \\\"{x:1692,y:1002,t:1526667364587};\\\", \\\"{x:1695,y:1002,t:1526667364604};\\\", \\\"{x:1699,y:1002,t:1526667364620};\\\", \\\"{x:1704,y:1002,t:1526667364637};\\\", \\\"{x:1707,y:1002,t:1526667364654};\\\", \\\"{x:1708,y:1002,t:1526667364669};\\\", \\\"{x:1711,y:1002,t:1526667364739};\\\", \\\"{x:1710,y:1002,t:1526667364770};\\\", \\\"{x:1705,y:1001,t:1526667364787};\\\", \\\"{x:1700,y:998,t:1526667364803};\\\", \\\"{x:1699,y:998,t:1526667364827};\\\", \\\"{x:1698,y:997,t:1526667364837};\\\", \\\"{x:1697,y:997,t:1526667364891};\\\", \\\"{x:1697,y:995,t:1526667365019};\\\", \\\"{x:1695,y:993,t:1526667365026};\\\", \\\"{x:1693,y:991,t:1526667365037};\\\", \\\"{x:1691,y:989,t:1526667365054};\\\", \\\"{x:1690,y:988,t:1526667365070};\\\", \\\"{x:1689,y:987,t:1526667365087};\\\", \\\"{x:1688,y:986,t:1526667365106};\\\", \\\"{x:1688,y:984,t:1526667366883};\\\", \\\"{x:1687,y:984,t:1526667366915};\\\", \\\"{x:1683,y:984,t:1526667372521};\\\", \\\"{x:1671,y:980,t:1526667372528};\\\", \\\"{x:1650,y:973,t:1526667372541};\\\", \\\"{x:1608,y:965,t:1526667372557};\\\", \\\"{x:1598,y:964,t:1526667372574};\\\", \\\"{x:1605,y:967,t:1526667373688};\\\", \\\"{x:1611,y:970,t:1526667373696};\\\", \\\"{x:1615,y:971,t:1526667373708};\\\", \\\"{x:1627,y:974,t:1526667373725};\\\", \\\"{x:1640,y:977,t:1526667373741};\\\", \\\"{x:1653,y:981,t:1526667373758};\\\", \\\"{x:1664,y:985,t:1526667373775};\\\", \\\"{x:1669,y:985,t:1526667373791};\\\", \\\"{x:1670,y:985,t:1526667373841};\\\", \\\"{x:1670,y:983,t:1526667373857};\\\", \\\"{x:1669,y:982,t:1526667373865};\\\", \\\"{x:1664,y:978,t:1526667373875};\\\", \\\"{x:1641,y:960,t:1526667373891};\\\", \\\"{x:1592,y:929,t:1526667373908};\\\", \\\"{x:1531,y:891,t:1526667373925};\\\", \\\"{x:1468,y:852,t:1526667373941};\\\", \\\"{x:1451,y:836,t:1526667373958};\\\", \\\"{x:1431,y:823,t:1526667373975};\\\", \\\"{x:1415,y:814,t:1526667373991};\\\", \\\"{x:1403,y:808,t:1526667374009};\\\", \\\"{x:1391,y:804,t:1526667374025};\\\", \\\"{x:1391,y:803,t:1526667374041};\\\", \\\"{x:1389,y:801,t:1526667374065};\\\", \\\"{x:1389,y:800,t:1526667374081};\\\", \\\"{x:1389,y:799,t:1526667374092};\\\", \\\"{x:1389,y:797,t:1526667374108};\\\", \\\"{x:1388,y:796,t:1526667374125};\\\", \\\"{x:1388,y:795,t:1526667374143};\\\", \\\"{x:1388,y:794,t:1526667374161};\\\", \\\"{x:1387,y:790,t:1526667374176};\\\", \\\"{x:1385,y:789,t:1526667374192};\\\", \\\"{x:1381,y:783,t:1526667374208};\\\", \\\"{x:1367,y:766,t:1526667374226};\\\", \\\"{x:1353,y:758,t:1526667374242};\\\", \\\"{x:1336,y:750,t:1526667374258};\\\", \\\"{x:1324,y:747,t:1526667374275};\\\", \\\"{x:1328,y:748,t:1526667374433};\\\", \\\"{x:1330,y:750,t:1526667374442};\\\", \\\"{x:1334,y:754,t:1526667374459};\\\", \\\"{x:1336,y:756,t:1526667374475};\\\", \\\"{x:1336,y:757,t:1526667374492};\\\", \\\"{x:1336,y:759,t:1526667374521};\\\", \\\"{x:1336,y:761,t:1526667374529};\\\", \\\"{x:1336,y:765,t:1526667374545};\\\", \\\"{x:1337,y:768,t:1526667374559};\\\", \\\"{x:1338,y:770,t:1526667374575};\\\", \\\"{x:1340,y:771,t:1526667374592};\\\", \\\"{x:1340,y:772,t:1526667374616};\\\", \\\"{x:1340,y:770,t:1526667375017};\\\", \\\"{x:1340,y:769,t:1526667375027};\\\", \\\"{x:1340,y:768,t:1526667375042};\\\", \\\"{x:1341,y:767,t:1526667375059};\\\", \\\"{x:1342,y:766,t:1526667375077};\\\", \\\"{x:1342,y:765,t:1526667375705};\\\", \\\"{x:1342,y:763,t:1526667375889};\\\", \\\"{x:1343,y:762,t:1526667375909};\\\", \\\"{x:1343,y:760,t:1526667375936};\\\", \\\"{x:1343,y:759,t:1526667375961};\\\", \\\"{x:1345,y:759,t:1526667376121};\\\", \\\"{x:1346,y:759,t:1526667376145};\\\", \\\"{x:1348,y:759,t:1526667376281};\\\", \\\"{x:1349,y:759,t:1526667376293};\\\", \\\"{x:1351,y:759,t:1526667376312};\\\", \\\"{x:1352,y:754,t:1526667377217};\\\", \\\"{x:1353,y:747,t:1526667377227};\\\", \\\"{x:1354,y:741,t:1526667377245};\\\", \\\"{x:1354,y:735,t:1526667377260};\\\", \\\"{x:1354,y:732,t:1526667377278};\\\", \\\"{x:1354,y:730,t:1526667377294};\\\", \\\"{x:1355,y:725,t:1526667377310};\\\", \\\"{x:1356,y:721,t:1526667377327};\\\", \\\"{x:1356,y:716,t:1526667377345};\\\", \\\"{x:1356,y:714,t:1526667377361};\\\", \\\"{x:1356,y:712,t:1526667377377};\\\", \\\"{x:1356,y:709,t:1526667377394};\\\", \\\"{x:1356,y:708,t:1526667377411};\\\", \\\"{x:1356,y:707,t:1526667377427};\\\", \\\"{x:1356,y:706,t:1526667377444};\\\", \\\"{x:1356,y:705,t:1526667377465};\\\", \\\"{x:1356,y:704,t:1526667377497};\\\", \\\"{x:1356,y:710,t:1526667379080};\\\", \\\"{x:1352,y:717,t:1526667379095};\\\", \\\"{x:1333,y:739,t:1526667379112};\\\", \\\"{x:1321,y:750,t:1526667379128};\\\", \\\"{x:1312,y:757,t:1526667379145};\\\", \\\"{x:1304,y:760,t:1526667379163};\\\", \\\"{x:1296,y:765,t:1526667379178};\\\", \\\"{x:1285,y:768,t:1526667379196};\\\", \\\"{x:1271,y:769,t:1526667379213};\\\", \\\"{x:1252,y:769,t:1526667379228};\\\", \\\"{x:1241,y:771,t:1526667379245};\\\", \\\"{x:1226,y:771,t:1526667379262};\\\", \\\"{x:1220,y:771,t:1526667379279};\\\", \\\"{x:1218,y:771,t:1526667379295};\\\", \\\"{x:1217,y:771,t:1526667379328};\\\", \\\"{x:1217,y:770,t:1526667379361};\\\", \\\"{x:1217,y:769,t:1526667379377};\\\", \\\"{x:1216,y:769,t:1526667379384};\\\", \\\"{x:1215,y:769,t:1526667379395};\\\", \\\"{x:1213,y:768,t:1526667379416};\\\", \\\"{x:1212,y:768,t:1526667379429};\\\", \\\"{x:1210,y:766,t:1526667379445};\\\", \\\"{x:1200,y:766,t:1526667379463};\\\", \\\"{x:1192,y:766,t:1526667379479};\\\", \\\"{x:1185,y:766,t:1526667379495};\\\", \\\"{x:1176,y:766,t:1526667379513};\\\", \\\"{x:1173,y:766,t:1526667379529};\\\", \\\"{x:1172,y:766,t:1526667379545};\\\", \\\"{x:1171,y:766,t:1526667379649};\\\", \\\"{x:1170,y:766,t:1526667379681};\\\", \\\"{x:1170,y:765,t:1526667379696};\\\", \\\"{x:1170,y:764,t:1526667379712};\\\", \\\"{x:1170,y:762,t:1526667379729};\\\", \\\"{x:1171,y:759,t:1526667379745};\\\", \\\"{x:1173,y:756,t:1526667379762};\\\", \\\"{x:1174,y:755,t:1526667379779};\\\", \\\"{x:1175,y:754,t:1526667379796};\\\", \\\"{x:1176,y:754,t:1526667379985};\\\", \\\"{x:1176,y:757,t:1526667379997};\\\", \\\"{x:1176,y:765,t:1526667380012};\\\", \\\"{x:1177,y:770,t:1526667380030};\\\", \\\"{x:1179,y:775,t:1526667380047};\\\", \\\"{x:1180,y:776,t:1526667380062};\\\", \\\"{x:1180,y:778,t:1526667380079};\\\", \\\"{x:1180,y:782,t:1526667380096};\\\", \\\"{x:1180,y:786,t:1526667380112};\\\", \\\"{x:1180,y:791,t:1526667380129};\\\", \\\"{x:1176,y:796,t:1526667380147};\\\", \\\"{x:1176,y:803,t:1526667380162};\\\", \\\"{x:1176,y:809,t:1526667380179};\\\", \\\"{x:1174,y:820,t:1526667380197};\\\", \\\"{x:1170,y:828,t:1526667380212};\\\", \\\"{x:1165,y:840,t:1526667380229};\\\", \\\"{x:1164,y:846,t:1526667380246};\\\", \\\"{x:1163,y:850,t:1526667380263};\\\", \\\"{x:1162,y:854,t:1526667380280};\\\", \\\"{x:1160,y:858,t:1526667380296};\\\", \\\"{x:1159,y:865,t:1526667380313};\\\", \\\"{x:1158,y:873,t:1526667380330};\\\", \\\"{x:1156,y:878,t:1526667380347};\\\", \\\"{x:1155,y:880,t:1526667380364};\\\", \\\"{x:1154,y:882,t:1526667380379};\\\", \\\"{x:1154,y:884,t:1526667380396};\\\", \\\"{x:1155,y:889,t:1526667380413};\\\", \\\"{x:1160,y:897,t:1526667380429};\\\", \\\"{x:1163,y:901,t:1526667380447};\\\", \\\"{x:1164,y:902,t:1526667380463};\\\", \\\"{x:1166,y:904,t:1526667380479};\\\", \\\"{x:1169,y:906,t:1526667380496};\\\", \\\"{x:1173,y:908,t:1526667380514};\\\", \\\"{x:1174,y:908,t:1526667380529};\\\", \\\"{x:1175,y:908,t:1526667380546};\\\", \\\"{x:1177,y:908,t:1526667380569};\\\", \\\"{x:1181,y:907,t:1526667380580};\\\", \\\"{x:1182,y:886,t:1526667380596};\\\", \\\"{x:1183,y:864,t:1526667380614};\\\", \\\"{x:1184,y:844,t:1526667380629};\\\", \\\"{x:1184,y:834,t:1526667380646};\\\", \\\"{x:1184,y:820,t:1526667380663};\\\", \\\"{x:1184,y:812,t:1526667380679};\\\", \\\"{x:1184,y:805,t:1526667380696};\\\", \\\"{x:1181,y:798,t:1526667380713};\\\", \\\"{x:1180,y:795,t:1526667380731};\\\", \\\"{x:1178,y:787,t:1526667380747};\\\", \\\"{x:1177,y:783,t:1526667380763};\\\", \\\"{x:1176,y:779,t:1526667380781};\\\", \\\"{x:1176,y:765,t:1526667380797};\\\", \\\"{x:1173,y:757,t:1526667380814};\\\", \\\"{x:1172,y:753,t:1526667380831};\\\", \\\"{x:1171,y:751,t:1526667380846};\\\", \\\"{x:1171,y:752,t:1526667381008};\\\", \\\"{x:1171,y:761,t:1526667381017};\\\", \\\"{x:1171,y:770,t:1526667381031};\\\", \\\"{x:1168,y:790,t:1526667381047};\\\", \\\"{x:1168,y:826,t:1526667381064};\\\", \\\"{x:1168,y:858,t:1526667381080};\\\", \\\"{x:1168,y:862,t:1526667381096};\\\", \\\"{x:1168,y:863,t:1526667381114};\\\", \\\"{x:1168,y:867,t:1526667381130};\\\", \\\"{x:1168,y:870,t:1526667381146};\\\", \\\"{x:1168,y:877,t:1526667381163};\\\", \\\"{x:1168,y:887,t:1526667381180};\\\", \\\"{x:1168,y:895,t:1526667381197};\\\", \\\"{x:1168,y:905,t:1526667381213};\\\", \\\"{x:1169,y:913,t:1526667381231};\\\", \\\"{x:1171,y:925,t:1526667381247};\\\", \\\"{x:1172,y:937,t:1526667381263};\\\", \\\"{x:1181,y:962,t:1526667381280};\\\", \\\"{x:1184,y:975,t:1526667381297};\\\", \\\"{x:1185,y:981,t:1526667381314};\\\", \\\"{x:1190,y:988,t:1526667381330};\\\", \\\"{x:1190,y:992,t:1526667381348};\\\", \\\"{x:1191,y:996,t:1526667381363};\\\", \\\"{x:1191,y:1003,t:1526667381380};\\\", \\\"{x:1191,y:1008,t:1526667381397};\\\", \\\"{x:1193,y:1010,t:1526667381414};\\\", \\\"{x:1193,y:1008,t:1526667381545};\\\", \\\"{x:1193,y:1007,t:1526667381552};\\\", \\\"{x:1192,y:1004,t:1526667381564};\\\", \\\"{x:1190,y:1000,t:1526667381580};\\\", \\\"{x:1187,y:996,t:1526667381597};\\\", \\\"{x:1185,y:993,t:1526667381613};\\\", \\\"{x:1185,y:991,t:1526667381630};\\\", \\\"{x:1184,y:989,t:1526667381648};\\\", \\\"{x:1182,y:986,t:1526667381663};\\\", \\\"{x:1181,y:980,t:1526667381680};\\\", \\\"{x:1179,y:975,t:1526667381697};\\\", \\\"{x:1177,y:974,t:1526667381715};\\\", \\\"{x:1177,y:975,t:1526667382849};\\\", \\\"{x:1178,y:976,t:1526667382865};\\\", \\\"{x:1180,y:976,t:1526667382882};\\\", \\\"{x:1182,y:976,t:1526667382899};\\\", \\\"{x:1185,y:976,t:1526667382914};\\\", \\\"{x:1193,y:976,t:1526667382932};\\\", \\\"{x:1196,y:976,t:1526667382948};\\\", \\\"{x:1200,y:976,t:1526667382965};\\\", \\\"{x:1206,y:976,t:1526667382981};\\\", \\\"{x:1208,y:976,t:1526667382998};\\\", \\\"{x:1213,y:976,t:1526667383015};\\\", \\\"{x:1215,y:976,t:1526667383032};\\\", \\\"{x:1221,y:976,t:1526667383048};\\\", \\\"{x:1224,y:976,t:1526667383065};\\\", \\\"{x:1226,y:976,t:1526667383082};\\\", \\\"{x:1230,y:976,t:1526667383099};\\\", \\\"{x:1231,y:976,t:1526667383152};\\\", \\\"{x:1233,y:976,t:1526667383165};\\\", \\\"{x:1237,y:976,t:1526667383181};\\\", \\\"{x:1240,y:976,t:1526667383199};\\\", \\\"{x:1244,y:976,t:1526667383215};\\\", \\\"{x:1246,y:975,t:1526667383231};\\\", \\\"{x:1247,y:975,t:1526667383425};\\\", \\\"{x:1250,y:975,t:1526667383433};\\\", \\\"{x:1264,y:975,t:1526667383448};\\\", \\\"{x:1273,y:976,t:1526667383466};\\\", \\\"{x:1278,y:977,t:1526667383481};\\\", \\\"{x:1284,y:977,t:1526667383498};\\\", \\\"{x:1285,y:977,t:1526667383515};\\\", \\\"{x:1287,y:977,t:1526667383531};\\\", \\\"{x:1295,y:977,t:1526667383549};\\\", \\\"{x:1298,y:977,t:1526667383566};\\\", \\\"{x:1304,y:980,t:1526667383582};\\\", \\\"{x:1310,y:981,t:1526667383599};\\\", \\\"{x:1314,y:981,t:1526667383616};\\\", \\\"{x:1315,y:981,t:1526667384104};\\\", \\\"{x:1316,y:981,t:1526667384128};\\\", \\\"{x:1317,y:980,t:1526667384152};\\\", \\\"{x:1317,y:979,t:1526667384168};\\\", \\\"{x:1318,y:979,t:1526667384184};\\\", \\\"{x:1318,y:978,t:1526667384200};\\\", \\\"{x:1319,y:978,t:1526667384577};\\\", \\\"{x:1321,y:978,t:1526667384584};\\\", \\\"{x:1325,y:978,t:1526667384599};\\\", \\\"{x:1343,y:978,t:1526667384616};\\\", \\\"{x:1353,y:978,t:1526667384632};\\\", \\\"{x:1357,y:978,t:1526667384649};\\\", \\\"{x:1359,y:977,t:1526667384667};\\\", \\\"{x:1361,y:977,t:1526667384832};\\\", \\\"{x:1364,y:977,t:1526667384850};\\\", \\\"{x:1370,y:977,t:1526667384867};\\\", \\\"{x:1372,y:977,t:1526667384882};\\\", \\\"{x:1374,y:977,t:1526667384900};\\\", \\\"{x:1376,y:976,t:1526667384929};\\\", \\\"{x:1377,y:976,t:1526667384952};\\\", \\\"{x:1378,y:976,t:1526667384966};\\\", \\\"{x:1381,y:974,t:1526667384983};\\\", \\\"{x:1382,y:974,t:1526667385017};\\\", \\\"{x:1383,y:973,t:1526667386425};\\\", \\\"{x:1383,y:970,t:1526667386434};\\\", \\\"{x:1383,y:961,t:1526667386450};\\\", \\\"{x:1383,y:958,t:1526667386468};\\\", \\\"{x:1384,y:954,t:1526667386485};\\\", \\\"{x:1384,y:950,t:1526667386501};\\\", \\\"{x:1385,y:947,t:1526667386518};\\\", \\\"{x:1385,y:942,t:1526667386534};\\\", \\\"{x:1385,y:941,t:1526667386552};\\\", \\\"{x:1385,y:940,t:1526667386567};\\\", \\\"{x:1385,y:934,t:1526667386584};\\\", \\\"{x:1385,y:933,t:1526667386601};\\\", \\\"{x:1385,y:931,t:1526667386618};\\\", \\\"{x:1385,y:929,t:1526667386634};\\\", \\\"{x:1385,y:927,t:1526667386651};\\\", \\\"{x:1385,y:921,t:1526667386668};\\\", \\\"{x:1385,y:919,t:1526667386684};\\\", \\\"{x:1385,y:913,t:1526667386701};\\\", \\\"{x:1385,y:894,t:1526667386717};\\\", \\\"{x:1385,y:877,t:1526667386735};\\\", \\\"{x:1385,y:875,t:1526667386751};\\\", \\\"{x:1385,y:873,t:1526667386768};\\\", \\\"{x:1385,y:872,t:1526667386785};\\\", \\\"{x:1384,y:872,t:1526667386849};\\\", \\\"{x:1384,y:874,t:1526667387008};\\\", \\\"{x:1383,y:879,t:1526667387018};\\\", \\\"{x:1383,y:885,t:1526667387034};\\\", \\\"{x:1383,y:889,t:1526667387052};\\\", \\\"{x:1383,y:891,t:1526667387068};\\\", \\\"{x:1383,y:892,t:1526667387085};\\\", \\\"{x:1383,y:893,t:1526667387117};\\\", \\\"{x:1383,y:894,t:1526667387134};\\\", \\\"{x:1383,y:895,t:1526667387151};\\\", \\\"{x:1383,y:896,t:1526667387167};\\\", \\\"{x:1383,y:899,t:1526667387185};\\\", \\\"{x:1383,y:902,t:1526667387202};\\\", \\\"{x:1383,y:903,t:1526667387249};\\\", \\\"{x:1383,y:904,t:1526667387265};\\\", \\\"{x:1383,y:905,t:1526667387520};\\\", \\\"{x:1379,y:904,t:1526667387536};\\\", \\\"{x:1375,y:901,t:1526667387552};\\\", \\\"{x:1370,y:898,t:1526667387568};\\\", \\\"{x:1370,y:897,t:1526667387793};\\\", \\\"{x:1371,y:897,t:1526667388921};\\\", \\\"{x:1373,y:897,t:1526667389009};\\\", \\\"{x:1374,y:897,t:1526667389024};\\\", \\\"{x:1376,y:897,t:1526667389040};\\\", \\\"{x:1377,y:897,t:1526667389070};\\\", \\\"{x:1382,y:897,t:1526667389552};\\\", \\\"{x:1384,y:897,t:1526667389569};\\\", \\\"{x:1387,y:897,t:1526667389587};\\\", \\\"{x:1388,y:896,t:1526667389603};\\\", \\\"{x:1387,y:896,t:1526667392913};\\\", \\\"{x:1385,y:896,t:1526667393417};\\\", \\\"{x:1351,y:883,t:1526667393440};\\\", \\\"{x:1273,y:847,t:1526667393456};\\\", \\\"{x:1122,y:790,t:1526667393472};\\\", \\\"{x:1052,y:759,t:1526667393489};\\\", \\\"{x:996,y:741,t:1526667393507};\\\", \\\"{x:968,y:726,t:1526667393523};\\\", \\\"{x:949,y:716,t:1526667393539};\\\", \\\"{x:938,y:712,t:1526667393556};\\\", \\\"{x:935,y:711,t:1526667393573};\\\", \\\"{x:935,y:710,t:1526667393590};\\\", \\\"{x:933,y:709,t:1526667393606};\\\", \\\"{x:928,y:703,t:1526667393622};\\\", \\\"{x:918,y:696,t:1526667393640};\\\", \\\"{x:893,y:680,t:1526667393656};\\\", \\\"{x:867,y:667,t:1526667393673};\\\", \\\"{x:823,y:642,t:1526667393690};\\\", \\\"{x:779,y:612,t:1526667393707};\\\", \\\"{x:711,y:577,t:1526667393724};\\\", \\\"{x:662,y:557,t:1526667393741};\\\", \\\"{x:594,y:529,t:1526667393762};\\\", \\\"{x:567,y:511,t:1526667393779};\\\", \\\"{x:533,y:503,t:1526667393794};\\\", \\\"{x:509,y:493,t:1526667393811};\\\", \\\"{x:487,y:491,t:1526667393828};\\\", \\\"{x:475,y:487,t:1526667393844};\\\", \\\"{x:473,y:487,t:1526667393861};\\\", \\\"{x:472,y:487,t:1526667393878};\\\", \\\"{x:469,y:490,t:1526667393895};\\\", \\\"{x:466,y:499,t:1526667393911};\\\", \\\"{x:448,y:516,t:1526667393928};\\\", \\\"{x:438,y:526,t:1526667393946};\\\", \\\"{x:432,y:532,t:1526667393961};\\\", \\\"{x:429,y:540,t:1526667393978};\\\", \\\"{x:428,y:544,t:1526667393994};\\\", \\\"{x:426,y:544,t:1526667394097};\\\", \\\"{x:424,y:540,t:1526667394111};\\\", \\\"{x:405,y:527,t:1526667394128};\\\", \\\"{x:390,y:517,t:1526667394146};\\\", \\\"{x:377,y:508,t:1526667394162};\\\", \\\"{x:374,y:504,t:1526667394178};\\\", \\\"{x:372,y:502,t:1526667394195};\\\", \\\"{x:371,y:500,t:1526667394211};\\\", \\\"{x:370,y:500,t:1526667394321};\\\", \\\"{x:370,y:503,t:1526667394328};\\\", \\\"{x:365,y:513,t:1526667394344};\\\", \\\"{x:358,y:526,t:1526667394361};\\\", \\\"{x:355,y:542,t:1526667394378};\\\", \\\"{x:350,y:555,t:1526667394395};\\\", \\\"{x:350,y:558,t:1526667394412};\\\", \\\"{x:350,y:555,t:1526667394457};\\\", \\\"{x:351,y:554,t:1526667394465};\\\", \\\"{x:352,y:551,t:1526667394478};\\\", \\\"{x:354,y:549,t:1526667394495};\\\", \\\"{x:356,y:547,t:1526667394528};\\\", \\\"{x:361,y:546,t:1526667394545};\\\", \\\"{x:364,y:544,t:1526667394562};\\\", \\\"{x:365,y:544,t:1526667394578};\\\", \\\"{x:366,y:543,t:1526667394608};\\\", \\\"{x:367,y:543,t:1526667394616};\\\", \\\"{x:367,y:543,t:1526667394785};\\\", \\\"{x:363,y:541,t:1526667394929};\\\", \\\"{x:361,y:540,t:1526667394945};\\\", \\\"{x:360,y:540,t:1526667394962};\\\", \\\"{x:340,y:537,t:1526667394979};\\\", \\\"{x:322,y:535,t:1526667394994};\\\", \\\"{x:308,y:533,t:1526667395011};\\\", \\\"{x:301,y:531,t:1526667395029};\\\", \\\"{x:300,y:531,t:1526667395045};\\\", \\\"{x:300,y:530,t:1526667395216};\\\", \\\"{x:310,y:530,t:1526667395229};\\\", \\\"{x:333,y:530,t:1526667395246};\\\", \\\"{x:350,y:531,t:1526667395262};\\\", \\\"{x:361,y:533,t:1526667395279};\\\", \\\"{x:365,y:535,t:1526667395296};\\\", \\\"{x:366,y:536,t:1526667395320};\\\", \\\"{x:369,y:539,t:1526667395401};\\\", \\\"{x:369,y:540,t:1526667395416};\\\", \\\"{x:370,y:540,t:1526667395429};\\\", \\\"{x:371,y:540,t:1526667395449};\\\", \\\"{x:372,y:540,t:1526667395561};\\\", \\\"{x:373,y:540,t:1526667395569};\\\", \\\"{x:374,y:540,t:1526667395592};\\\", \\\"{x:373,y:540,t:1526667395753};\\\", \\\"{x:368,y:540,t:1526667395763};\\\", \\\"{x:349,y:536,t:1526667395779};\\\", \\\"{x:328,y:530,t:1526667395796};\\\", \\\"{x:300,y:523,t:1526667395813};\\\", \\\"{x:254,y:516,t:1526667395830};\\\", \\\"{x:232,y:513,t:1526667395846};\\\", \\\"{x:217,y:511,t:1526667395863};\\\", \\\"{x:210,y:509,t:1526667395879};\\\", \\\"{x:205,y:509,t:1526667395896};\\\", \\\"{x:200,y:509,t:1526667395913};\\\", \\\"{x:195,y:509,t:1526667395929};\\\", \\\"{x:192,y:509,t:1526667395946};\\\", \\\"{x:187,y:509,t:1526667395963};\\\", \\\"{x:181,y:509,t:1526667395979};\\\", \\\"{x:174,y:509,t:1526667395996};\\\", \\\"{x:166,y:508,t:1526667396013};\\\", \\\"{x:163,y:508,t:1526667396029};\\\", \\\"{x:162,y:508,t:1526667396089};\\\", \\\"{x:163,y:508,t:1526667396368};\\\", \\\"{x:166,y:508,t:1526667396380};\\\", \\\"{x:181,y:510,t:1526667396397};\\\", \\\"{x:197,y:519,t:1526667396414};\\\", \\\"{x:231,y:534,t:1526667396431};\\\", \\\"{x:290,y:553,t:1526667396448};\\\", \\\"{x:330,y:571,t:1526667396464};\\\", \\\"{x:385,y:605,t:1526667396481};\\\", \\\"{x:413,y:628,t:1526667396496};\\\", \\\"{x:432,y:644,t:1526667396514};\\\", \\\"{x:445,y:658,t:1526667396530};\\\", \\\"{x:449,y:673,t:1526667396547};\\\", \\\"{x:452,y:688,t:1526667396563};\\\", \\\"{x:455,y:698,t:1526667396580};\\\", \\\"{x:457,y:707,t:1526667396596};\\\", \\\"{x:460,y:713,t:1526667396614};\\\", \\\"{x:460,y:728,t:1526667396631};\\\", \\\"{x:460,y:737,t:1526667396646};\\\", \\\"{x:460,y:740,t:1526667396663};\\\", \\\"{x:460,y:744,t:1526667396680};\\\", \\\"{x:463,y:743,t:1526667396768};\\\", \\\"{x:465,y:739,t:1526667396780};\\\", \\\"{x:467,y:736,t:1526667396797};\\\", \\\"{x:468,y:734,t:1526667396814};\\\", \\\"{x:472,y:733,t:1526667396831};\\\", \\\"{x:474,y:733,t:1526667396847};\\\", \\\"{x:475,y:733,t:1526667396880};\\\", \\\"{x:479,y:735,t:1526667397456};\\\", \\\"{x:487,y:737,t:1526667397464};\\\", \\\"{x:505,y:740,t:1526667397480};\\\", \\\"{x:534,y:741,t:1526667397497};\\\", \\\"{x:598,y:741,t:1526667397514};\\\", \\\"{x:670,y:741,t:1526667397531};\\\", \\\"{x:745,y:741,t:1526667397547};\\\", \\\"{x:807,y:741,t:1526667397564};\\\", \\\"{x:854,y:741,t:1526667397582};\\\", \\\"{x:881,y:741,t:1526667397597};\\\", \\\"{x:896,y:741,t:1526667397614};\\\", \\\"{x:906,y:742,t:1526667397631};\\\", \\\"{x:909,y:741,t:1526667397647};\\\", \\\"{x:908,y:735,t:1526667397896};\\\", \\\"{x:908,y:734,t:1526667397904};\\\", \\\"{x:905,y:731,t:1526667397914};\\\", \\\"{x:897,y:728,t:1526667397931};\\\", \\\"{x:896,y:728,t:1526667397948};\\\", \\\"{x:894,y:726,t:1526667398008};\\\", \\\"{x:892,y:725,t:1526667398016};\\\", \\\"{x:890,y:723,t:1526667398033};\\\", \\\"{x:887,y:720,t:1526667398049};\\\", \\\"{x:882,y:719,t:1526667398064};\\\", \\\"{x:880,y:718,t:1526667398084};\\\", \\\"{x:877,y:716,t:1526667398109};\\\", \\\"{x:876,y:716,t:1526667398115};\\\", \\\"{x:874,y:715,t:1526667398131};\\\", \\\"{x:873,y:714,t:1526667398148};\\\", \\\"{x:872,y:714,t:1526667398164};\\\", \\\"{x:870,y:714,t:1526667398181};\\\", \\\"{x:868,y:713,t:1526667398208};\\\", \\\"{x:866,y:712,t:1526667398216};\\\", \\\"{x:865,y:711,t:1526667398232};\\\", \\\"{x:861,y:710,t:1526667398248};\\\", \\\"{x:859,y:709,t:1526667398265};\\\", \\\"{x:858,y:709,t:1526667398328};\\\", \\\"{x:857,y:709,t:1526667398352};\\\", \\\"{x:856,y:709,t:1526667398365};\\\", \\\"{x:853,y:709,t:1526667398381};\\\", \\\"{x:852,y:709,t:1526667398397};\\\" ] }, { \\\"rt\\\": 11739, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 520357, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"HWJDK\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"men\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"diagonal\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -B -B -12 PM-01 PM-02 PM-03 PM-03 PM-04 PM-Z \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:851,y:708,t:1526667398559};\\\", \\\"{x:850,y:708,t:1526667400145};\\\", \\\"{x:877,y:709,t:1526667400163};\\\", \\\"{x:898,y:710,t:1526667400169};\\\", \\\"{x:919,y:714,t:1526667400183};\\\", \\\"{x:998,y:727,t:1526667400199};\\\", \\\"{x:1147,y:751,t:1526667400216};\\\", \\\"{x:1230,y:762,t:1526667400233};\\\", \\\"{x:1305,y:772,t:1526667400250};\\\", \\\"{x:1365,y:777,t:1526667400266};\\\", \\\"{x:1416,y:777,t:1526667400283};\\\", \\\"{x:1440,y:778,t:1526667400299};\\\", \\\"{x:1450,y:778,t:1526667400316};\\\", \\\"{x:1455,y:778,t:1526667400334};\\\", \\\"{x:1457,y:778,t:1526667400349};\\\", \\\"{x:1461,y:779,t:1526667400367};\\\", \\\"{x:1463,y:779,t:1526667400384};\\\", \\\"{x:1463,y:780,t:1526667400400};\\\", \\\"{x:1463,y:779,t:1526667400481};\\\", \\\"{x:1462,y:772,t:1526667400488};\\\", \\\"{x:1458,y:767,t:1526667400501};\\\", \\\"{x:1447,y:755,t:1526667400516};\\\", \\\"{x:1430,y:739,t:1526667400534};\\\", \\\"{x:1407,y:723,t:1526667400551};\\\", \\\"{x:1367,y:703,t:1526667400567};\\\", \\\"{x:1336,y:694,t:1526667400584};\\\", \\\"{x:1323,y:688,t:1526667400601};\\\", \\\"{x:1323,y:687,t:1526667400616};\\\", \\\"{x:1324,y:686,t:1526667400745};\\\", \\\"{x:1329,y:687,t:1526667400752};\\\", \\\"{x:1335,y:689,t:1526667400767};\\\", \\\"{x:1343,y:692,t:1526667400783};\\\", \\\"{x:1351,y:694,t:1526667400801};\\\", \\\"{x:1351,y:696,t:1526667401952};\\\", \\\"{x:1349,y:698,t:1526667401967};\\\", \\\"{x:1348,y:699,t:1526667401984};\\\", \\\"{x:1348,y:700,t:1526667402001};\\\", \\\"{x:1347,y:701,t:1526667402017};\\\", \\\"{x:1347,y:702,t:1526667402040};\\\", \\\"{x:1345,y:700,t:1526667402408};\\\", \\\"{x:1345,y:698,t:1526667402448};\\\", \\\"{x:1345,y:699,t:1526667402552};\\\", \\\"{x:1345,y:709,t:1526667402569};\\\", \\\"{x:1345,y:722,t:1526667402586};\\\", \\\"{x:1345,y:737,t:1526667402601};\\\", \\\"{x:1345,y:747,t:1526667402618};\\\", \\\"{x:1346,y:756,t:1526667402636};\\\", \\\"{x:1348,y:768,t:1526667402651};\\\", \\\"{x:1348,y:773,t:1526667402669};\\\", \\\"{x:1349,y:781,t:1526667402686};\\\", \\\"{x:1351,y:793,t:1526667402701};\\\", \\\"{x:1351,y:805,t:1526667402718};\\\", \\\"{x:1351,y:814,t:1526667402735};\\\", \\\"{x:1353,y:826,t:1526667402751};\\\", \\\"{x:1351,y:851,t:1526667402768};\\\", \\\"{x:1349,y:867,t:1526667402785};\\\", \\\"{x:1347,y:881,t:1526667402801};\\\", \\\"{x:1347,y:892,t:1526667402818};\\\", \\\"{x:1347,y:903,t:1526667402836};\\\", \\\"{x:1347,y:908,t:1526667402852};\\\", \\\"{x:1347,y:910,t:1526667402868};\\\", \\\"{x:1346,y:915,t:1526667402886};\\\", \\\"{x:1345,y:924,t:1526667402901};\\\", \\\"{x:1343,y:932,t:1526667402918};\\\", \\\"{x:1342,y:942,t:1526667402936};\\\", \\\"{x:1340,y:948,t:1526667402951};\\\", \\\"{x:1340,y:951,t:1526667402969};\\\", \\\"{x:1340,y:952,t:1526667402986};\\\", \\\"{x:1340,y:955,t:1526667403002};\\\", \\\"{x:1340,y:956,t:1526667403019};\\\", \\\"{x:1340,y:957,t:1526667403035};\\\", \\\"{x:1341,y:958,t:1526667403064};\\\", \\\"{x:1341,y:959,t:1526667403072};\\\", \\\"{x:1343,y:964,t:1526667403086};\\\", \\\"{x:1343,y:976,t:1526667403102};\\\", \\\"{x:1344,y:986,t:1526667403119};\\\", \\\"{x:1344,y:989,t:1526667403135};\\\", \\\"{x:1344,y:992,t:1526667403153};\\\", \\\"{x:1346,y:992,t:1526667403320};\\\", \\\"{x:1351,y:992,t:1526667403335};\\\", \\\"{x:1377,y:992,t:1526667403352};\\\", \\\"{x:1395,y:992,t:1526667403369};\\\", \\\"{x:1414,y:992,t:1526667403386};\\\", \\\"{x:1422,y:992,t:1526667403403};\\\", \\\"{x:1423,y:992,t:1526667403418};\\\", \\\"{x:1425,y:992,t:1526667403435};\\\", \\\"{x:1426,y:992,t:1526667403520};\\\", \\\"{x:1428,y:991,t:1526667403560};\\\", \\\"{x:1429,y:990,t:1526667403569};\\\", \\\"{x:1430,y:989,t:1526667403585};\\\", \\\"{x:1431,y:989,t:1526667403697};\\\", \\\"{x:1432,y:989,t:1526667403704};\\\", \\\"{x:1434,y:989,t:1526667403719};\\\", \\\"{x:1443,y:990,t:1526667403735};\\\", \\\"{x:1460,y:990,t:1526667403752};\\\", \\\"{x:1468,y:990,t:1526667403769};\\\", \\\"{x:1475,y:990,t:1526667403786};\\\", \\\"{x:1480,y:990,t:1526667403802};\\\", \\\"{x:1482,y:990,t:1526667403819};\\\", \\\"{x:1484,y:990,t:1526667403835};\\\", \\\"{x:1485,y:990,t:1526667403853};\\\", \\\"{x:1489,y:990,t:1526667404049};\\\", \\\"{x:1492,y:990,t:1526667404056};\\\", \\\"{x:1500,y:989,t:1526667404070};\\\", \\\"{x:1517,y:989,t:1526667404086};\\\", \\\"{x:1541,y:988,t:1526667404103};\\\", \\\"{x:1561,y:988,t:1526667404120};\\\", \\\"{x:1580,y:988,t:1526667404136};\\\", \\\"{x:1585,y:988,t:1526667404152};\\\", \\\"{x:1585,y:987,t:1526667404384};\\\", \\\"{x:1584,y:987,t:1526667404392};\\\", \\\"{x:1580,y:984,t:1526667404404};\\\", \\\"{x:1577,y:983,t:1526667404419};\\\", \\\"{x:1576,y:983,t:1526667404436};\\\", \\\"{x:1573,y:981,t:1526667404454};\\\", \\\"{x:1568,y:980,t:1526667404469};\\\", \\\"{x:1560,y:980,t:1526667404487};\\\", \\\"{x:1555,y:980,t:1526667404504};\\\", \\\"{x:1552,y:980,t:1526667404520};\\\", \\\"{x:1548,y:980,t:1526667404537};\\\", \\\"{x:1549,y:980,t:1526667404641};\\\", \\\"{x:1551,y:980,t:1526667404654};\\\", \\\"{x:1554,y:980,t:1526667404669};\\\", \\\"{x:1557,y:980,t:1526667404687};\\\", \\\"{x:1560,y:980,t:1526667404703};\\\", \\\"{x:1562,y:980,t:1526667404825};\\\", \\\"{x:1564,y:981,t:1526667404837};\\\", \\\"{x:1569,y:984,t:1526667404854};\\\", \\\"{x:1574,y:986,t:1526667404870};\\\", \\\"{x:1575,y:986,t:1526667404944};\\\", \\\"{x:1576,y:986,t:1526667404954};\\\", \\\"{x:1578,y:986,t:1526667404971};\\\", \\\"{x:1579,y:986,t:1526667405033};\\\", \\\"{x:1582,y:986,t:1526667405040};\\\", \\\"{x:1587,y:985,t:1526667405053};\\\", \\\"{x:1593,y:985,t:1526667405071};\\\", \\\"{x:1603,y:984,t:1526667405087};\\\", \\\"{x:1617,y:983,t:1526667405104};\\\", \\\"{x:1622,y:983,t:1526667405121};\\\", \\\"{x:1624,y:983,t:1526667405138};\\\", \\\"{x:1624,y:981,t:1526667405592};\\\", \\\"{x:1624,y:979,t:1526667405605};\\\", \\\"{x:1623,y:971,t:1526667405621};\\\", \\\"{x:1623,y:964,t:1526667405638};\\\", \\\"{x:1623,y:959,t:1526667405654};\\\", \\\"{x:1623,y:953,t:1526667405670};\\\", \\\"{x:1621,y:948,t:1526667405688};\\\", \\\"{x:1621,y:937,t:1526667405704};\\\", \\\"{x:1620,y:916,t:1526667405720};\\\", \\\"{x:1620,y:900,t:1526667405737};\\\", \\\"{x:1620,y:883,t:1526667405754};\\\", \\\"{x:1620,y:868,t:1526667405771};\\\", \\\"{x:1620,y:856,t:1526667405787};\\\", \\\"{x:1620,y:842,t:1526667405804};\\\", \\\"{x:1621,y:825,t:1526667405820};\\\", \\\"{x:1622,y:809,t:1526667405838};\\\", \\\"{x:1624,y:789,t:1526667405855};\\\", \\\"{x:1624,y:771,t:1526667405871};\\\", \\\"{x:1624,y:756,t:1526667405887};\\\", \\\"{x:1626,y:733,t:1526667405904};\\\", \\\"{x:1629,y:716,t:1526667405920};\\\", \\\"{x:1629,y:712,t:1526667405938};\\\", \\\"{x:1629,y:703,t:1526667405955};\\\", \\\"{x:1629,y:702,t:1526667405971};\\\", \\\"{x:1630,y:699,t:1526667405988};\\\", \\\"{x:1630,y:696,t:1526667406005};\\\", \\\"{x:1630,y:695,t:1526667406022};\\\", \\\"{x:1630,y:693,t:1526667406039};\\\", \\\"{x:1630,y:692,t:1526667406055};\\\", \\\"{x:1628,y:689,t:1526667406169};\\\", \\\"{x:1623,y:688,t:1526667406176};\\\", \\\"{x:1612,y:687,t:1526667406188};\\\", \\\"{x:1572,y:683,t:1526667406205};\\\", \\\"{x:1488,y:681,t:1526667406222};\\\", \\\"{x:1369,y:665,t:1526667406237};\\\", \\\"{x:1242,y:648,t:1526667406255};\\\", \\\"{x:1087,y:629,t:1526667406272};\\\", \\\"{x:934,y:598,t:1526667406287};\\\", \\\"{x:729,y:564,t:1526667406305};\\\", \\\"{x:641,y:553,t:1526667406322};\\\", \\\"{x:599,y:535,t:1526667406337};\\\", \\\"{x:587,y:532,t:1526667406349};\\\", \\\"{x:575,y:528,t:1526667406367};\\\", \\\"{x:567,y:524,t:1526667406384};\\\", \\\"{x:562,y:522,t:1526667406400};\\\", \\\"{x:554,y:519,t:1526667406422};\\\", \\\"{x:538,y:517,t:1526667406439};\\\", \\\"{x:523,y:517,t:1526667406454};\\\", \\\"{x:504,y:517,t:1526667406472};\\\", \\\"{x:489,y:517,t:1526667406489};\\\", \\\"{x:490,y:519,t:1526667406536};\\\", \\\"{x:508,y:535,t:1526667406555};\\\", \\\"{x:523,y:542,t:1526667406572};\\\", \\\"{x:533,y:546,t:1526667406589};\\\", \\\"{x:551,y:552,t:1526667406605};\\\", \\\"{x:568,y:554,t:1526667406621};\\\", \\\"{x:578,y:555,t:1526667406639};\\\", \\\"{x:581,y:555,t:1526667406655};\\\", \\\"{x:582,y:555,t:1526667406671};\\\", \\\"{x:585,y:555,t:1526667406688};\\\", \\\"{x:588,y:555,t:1526667406705};\\\", \\\"{x:590,y:555,t:1526667406727};\\\", \\\"{x:589,y:555,t:1526667406800};\\\", \\\"{x:582,y:555,t:1526667406808};\\\", \\\"{x:573,y:554,t:1526667406823};\\\", \\\"{x:553,y:546,t:1526667406839};\\\", \\\"{x:524,y:539,t:1526667406856};\\\", \\\"{x:422,y:525,t:1526667406873};\\\", \\\"{x:370,y:520,t:1526667406889};\\\", \\\"{x:342,y:520,t:1526667406905};\\\", \\\"{x:333,y:521,t:1526667406921};\\\", \\\"{x:331,y:524,t:1526667406939};\\\", \\\"{x:329,y:533,t:1526667406956};\\\", \\\"{x:331,y:547,t:1526667406973};\\\", \\\"{x:336,y:565,t:1526667406989};\\\", \\\"{x:344,y:583,t:1526667407005};\\\", \\\"{x:347,y:599,t:1526667407022};\\\", \\\"{x:351,y:612,t:1526667407039};\\\", \\\"{x:351,y:617,t:1526667407056};\\\", \\\"{x:352,y:623,t:1526667407072};\\\", \\\"{x:354,y:628,t:1526667407088};\\\", \\\"{x:358,y:640,t:1526667407106};\\\", \\\"{x:361,y:646,t:1526667407122};\\\", \\\"{x:363,y:651,t:1526667407138};\\\", \\\"{x:363,y:652,t:1526667407156};\\\", \\\"{x:364,y:653,t:1526667407172};\\\", \\\"{x:368,y:659,t:1526667407188};\\\", \\\"{x:377,y:671,t:1526667407206};\\\", \\\"{x:388,y:678,t:1526667407222};\\\", \\\"{x:408,y:681,t:1526667407239};\\\", \\\"{x:429,y:682,t:1526667407256};\\\", \\\"{x:477,y:669,t:1526667407273};\\\", \\\"{x:504,y:654,t:1526667407289};\\\", \\\"{x:523,y:642,t:1526667407305};\\\", \\\"{x:553,y:630,t:1526667407323};\\\", \\\"{x:595,y:619,t:1526667407338};\\\", \\\"{x:613,y:616,t:1526667407356};\\\", \\\"{x:639,y:621,t:1526667407372};\\\", \\\"{x:661,y:624,t:1526667407389};\\\", \\\"{x:678,y:627,t:1526667407405};\\\", \\\"{x:686,y:630,t:1526667407423};\\\", \\\"{x:695,y:630,t:1526667407439};\\\", \\\"{x:695,y:631,t:1526667407456};\\\", \\\"{x:698,y:632,t:1526667407473};\\\", \\\"{x:705,y:633,t:1526667407489};\\\", \\\"{x:716,y:635,t:1526667407506};\\\", \\\"{x:731,y:635,t:1526667407522};\\\", \\\"{x:746,y:635,t:1526667407538};\\\", \\\"{x:757,y:633,t:1526667407555};\\\", \\\"{x:760,y:630,t:1526667407573};\\\", \\\"{x:760,y:628,t:1526667407590};\\\", \\\"{x:762,y:627,t:1526667407664};\\\", \\\"{x:763,y:627,t:1526667407672};\\\", \\\"{x:764,y:627,t:1526667407690};\\\", \\\"{x:766,y:627,t:1526667407705};\\\", \\\"{x:767,y:627,t:1526667407728};\\\", \\\"{x:771,y:630,t:1526667407740};\\\", \\\"{x:779,y:635,t:1526667407756};\\\", \\\"{x:785,y:639,t:1526667407773};\\\", \\\"{x:792,y:644,t:1526667407790};\\\", \\\"{x:793,y:644,t:1526667407805};\\\", \\\"{x:794,y:644,t:1526667407849};\\\", \\\"{x:796,y:644,t:1526667407864};\\\", \\\"{x:798,y:644,t:1526667407872};\\\", \\\"{x:799,y:643,t:1526667407890};\\\", \\\"{x:802,y:639,t:1526667407906};\\\", \\\"{x:806,y:636,t:1526667407923};\\\", \\\"{x:811,y:632,t:1526667407939};\\\", \\\"{x:816,y:627,t:1526667407957};\\\", \\\"{x:819,y:623,t:1526667407973};\\\", \\\"{x:824,y:621,t:1526667407989};\\\", \\\"{x:829,y:619,t:1526667408006};\\\", \\\"{x:829,y:618,t:1526667408096};\\\", \\\"{x:823,y:618,t:1526667409552};\\\", \\\"{x:811,y:620,t:1526667409560};\\\", \\\"{x:800,y:622,t:1526667409575};\\\", \\\"{x:774,y:628,t:1526667409591};\\\", \\\"{x:738,y:636,t:1526667409607};\\\", \\\"{x:714,y:647,t:1526667409623};\\\", \\\"{x:669,y:665,t:1526667409640};\\\", \\\"{x:645,y:677,t:1526667409656};\\\", \\\"{x:628,y:688,t:1526667409674};\\\", \\\"{x:618,y:694,t:1526667409690};\\\", \\\"{x:608,y:705,t:1526667409707};\\\", \\\"{x:599,y:718,t:1526667409724};\\\", \\\"{x:593,y:729,t:1526667409740};\\\", \\\"{x:586,y:744,t:1526667409757};\\\", \\\"{x:581,y:752,t:1526667409774};\\\", \\\"{x:580,y:754,t:1526667409790};\\\", \\\"{x:577,y:756,t:1526667409807};\\\", \\\"{x:575,y:758,t:1526667409823};\\\", \\\"{x:567,y:762,t:1526667409840};\\\", \\\"{x:564,y:763,t:1526667409858};\\\", \\\"{x:562,y:764,t:1526667409874};\\\", \\\"{x:561,y:764,t:1526667409928};\\\", \\\"{x:561,y:756,t:1526667409940};\\\", \\\"{x:561,y:740,t:1526667409958};\\\", \\\"{x:560,y:735,t:1526667409973};\\\", \\\"{x:560,y:733,t:1526667409990};\\\", \\\"{x:560,y:732,t:1526667410007};\\\", \\\"{x:555,y:731,t:1526667410024};\\\", \\\"{x:546,y:727,t:1526667410041};\\\", \\\"{x:534,y:724,t:1526667410058};\\\", \\\"{x:528,y:719,t:1526667410075};\\\", \\\"{x:515,y:717,t:1526667410090};\\\", \\\"{x:509,y:717,t:1526667410108};\\\", \\\"{x:508,y:717,t:1526667410125};\\\", \\\"{x:507,y:717,t:1526667410141};\\\", \\\"{x:507,y:719,t:1526667410158};\\\", \\\"{x:508,y:725,t:1526667410175};\\\", \\\"{x:509,y:726,t:1526667410191};\\\", \\\"{x:511,y:728,t:1526667410208};\\\", \\\"{x:511,y:729,t:1526667410327};\\\", \\\"{x:512,y:729,t:1526667410352};\\\", \\\"{x:513,y:729,t:1526667410367};\\\" ] }, { \\\"rt\\\": 9816, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 531357, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"HWJDK\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"men\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"diagonal\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM-12 PM-12 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:517,y:729,t:1526667412584};\\\", \\\"{x:526,y:728,t:1526667412593};\\\", \\\"{x:549,y:728,t:1526667412611};\\\", \\\"{x:585,y:726,t:1526667412626};\\\", \\\"{x:660,y:726,t:1526667412642};\\\", \\\"{x:749,y:726,t:1526667412660};\\\", \\\"{x:815,y:731,t:1526667412676};\\\", \\\"{x:901,y:740,t:1526667412693};\\\", \\\"{x:983,y:746,t:1526667412710};\\\", \\\"{x:1048,y:751,t:1526667412726};\\\", \\\"{x:1102,y:759,t:1526667412743};\\\", \\\"{x:1158,y:767,t:1526667412760};\\\", \\\"{x:1175,y:771,t:1526667412776};\\\", \\\"{x:1191,y:771,t:1526667412792};\\\", \\\"{x:1208,y:771,t:1526667412810};\\\", \\\"{x:1219,y:771,t:1526667412826};\\\", \\\"{x:1239,y:770,t:1526667412842};\\\", \\\"{x:1256,y:768,t:1526667412860};\\\", \\\"{x:1272,y:766,t:1526667412875};\\\", \\\"{x:1280,y:766,t:1526667412892};\\\", \\\"{x:1288,y:766,t:1526667412910};\\\", \\\"{x:1294,y:765,t:1526667412926};\\\", \\\"{x:1299,y:765,t:1526667412943};\\\", \\\"{x:1301,y:765,t:1526667412960};\\\", \\\"{x:1300,y:765,t:1526667413128};\\\", \\\"{x:1298,y:769,t:1526667413143};\\\", \\\"{x:1287,y:786,t:1526667413160};\\\", \\\"{x:1280,y:800,t:1526667413176};\\\", \\\"{x:1276,y:812,t:1526667413193};\\\", \\\"{x:1273,y:824,t:1526667413210};\\\", \\\"{x:1273,y:832,t:1526667413226};\\\", \\\"{x:1273,y:838,t:1526667413243};\\\", \\\"{x:1274,y:848,t:1526667413260};\\\", \\\"{x:1279,y:859,t:1526667413277};\\\", \\\"{x:1289,y:873,t:1526667413293};\\\", \\\"{x:1299,y:889,t:1526667413310};\\\", \\\"{x:1306,y:905,t:1526667413327};\\\", \\\"{x:1316,y:916,t:1526667413343};\\\", \\\"{x:1330,y:941,t:1526667413360};\\\", \\\"{x:1345,y:964,t:1526667413376};\\\", \\\"{x:1361,y:988,t:1526667413393};\\\", \\\"{x:1374,y:1005,t:1526667413410};\\\", \\\"{x:1383,y:1019,t:1526667413427};\\\", \\\"{x:1387,y:1026,t:1526667413442};\\\", \\\"{x:1389,y:1030,t:1526667413460};\\\", \\\"{x:1388,y:1028,t:1526667413608};\\\", \\\"{x:1386,y:1024,t:1526667413616};\\\", \\\"{x:1384,y:1021,t:1526667413627};\\\", \\\"{x:1383,y:1019,t:1526667413643};\\\", \\\"{x:1381,y:1015,t:1526667413660};\\\", \\\"{x:1379,y:1011,t:1526667413677};\\\", \\\"{x:1379,y:1009,t:1526667413737};\\\", \\\"{x:1379,y:1008,t:1526667413743};\\\", \\\"{x:1378,y:1005,t:1526667413760};\\\", \\\"{x:1378,y:1002,t:1526667413777};\\\", \\\"{x:1368,y:990,t:1526667413793};\\\", \\\"{x:1361,y:981,t:1526667413810};\\\", \\\"{x:1360,y:981,t:1526667413826};\\\", \\\"{x:1358,y:979,t:1526667413843};\\\", \\\"{x:1357,y:979,t:1526667413859};\\\", \\\"{x:1356,y:979,t:1526667413888};\\\", \\\"{x:1355,y:979,t:1526667413904};\\\", \\\"{x:1354,y:979,t:1526667413912};\\\", \\\"{x:1351,y:979,t:1526667413944};\\\", \\\"{x:1349,y:979,t:1526667413960};\\\", \\\"{x:1348,y:980,t:1526667413976};\\\", \\\"{x:1348,y:979,t:1526667414281};\\\", \\\"{x:1347,y:976,t:1526667414294};\\\", \\\"{x:1346,y:971,t:1526667414310};\\\", \\\"{x:1346,y:958,t:1526667414326};\\\", \\\"{x:1349,y:942,t:1526667414344};\\\", \\\"{x:1350,y:937,t:1526667414360};\\\", \\\"{x:1350,y:934,t:1526667414377};\\\", \\\"{x:1351,y:929,t:1526667414394};\\\", \\\"{x:1353,y:924,t:1526667414410};\\\", \\\"{x:1354,y:919,t:1526667414427};\\\", \\\"{x:1355,y:910,t:1526667414444};\\\", \\\"{x:1357,y:898,t:1526667414460};\\\", \\\"{x:1357,y:887,t:1526667414477};\\\", \\\"{x:1357,y:874,t:1526667414494};\\\", \\\"{x:1358,y:866,t:1526667414509};\\\", \\\"{x:1358,y:860,t:1526667414527};\\\", \\\"{x:1359,y:843,t:1526667414544};\\\", \\\"{x:1361,y:835,t:1526667414560};\\\", \\\"{x:1361,y:829,t:1526667414577};\\\", \\\"{x:1361,y:822,t:1526667414594};\\\", \\\"{x:1361,y:813,t:1526667414609};\\\", \\\"{x:1361,y:804,t:1526667414627};\\\", \\\"{x:1361,y:793,t:1526667414644};\\\", \\\"{x:1361,y:785,t:1526667414660};\\\", \\\"{x:1361,y:774,t:1526667414676};\\\", \\\"{x:1361,y:764,t:1526667414694};\\\", \\\"{x:1360,y:752,t:1526667414710};\\\", \\\"{x:1358,y:748,t:1526667414727};\\\", \\\"{x:1357,y:744,t:1526667414745};\\\", \\\"{x:1356,y:744,t:1526667414760};\\\", \\\"{x:1355,y:744,t:1526667414778};\\\", \\\"{x:1355,y:743,t:1526667414794};\\\", \\\"{x:1351,y:741,t:1526667414810};\\\", \\\"{x:1344,y:739,t:1526667414827};\\\", \\\"{x:1340,y:736,t:1526667414844};\\\", \\\"{x:1338,y:736,t:1526667414860};\\\", \\\"{x:1337,y:735,t:1526667414877};\\\", \\\"{x:1336,y:733,t:1526667414953};\\\", \\\"{x:1336,y:730,t:1526667414960};\\\", \\\"{x:1336,y:724,t:1526667414977};\\\", \\\"{x:1336,y:716,t:1526667414994};\\\", \\\"{x:1336,y:712,t:1526667415010};\\\", \\\"{x:1336,y:710,t:1526667415027};\\\", \\\"{x:1336,y:708,t:1526667415044};\\\", \\\"{x:1336,y:707,t:1526667415060};\\\", \\\"{x:1336,y:706,t:1526667415096};\\\", \\\"{x:1336,y:704,t:1526667415110};\\\", \\\"{x:1336,y:702,t:1526667415127};\\\", \\\"{x:1336,y:701,t:1526667415144};\\\", \\\"{x:1336,y:698,t:1526667415160};\\\", \\\"{x:1336,y:695,t:1526667415177};\\\", \\\"{x:1336,y:693,t:1526667415194};\\\", \\\"{x:1336,y:687,t:1526667415210};\\\", \\\"{x:1336,y:681,t:1526667415227};\\\", \\\"{x:1332,y:670,t:1526667415244};\\\", \\\"{x:1315,y:658,t:1526667415261};\\\", \\\"{x:1286,y:643,t:1526667415277};\\\", \\\"{x:1246,y:624,t:1526667415294};\\\", \\\"{x:1206,y:610,t:1526667415311};\\\", \\\"{x:1151,y:599,t:1526667415327};\\\", \\\"{x:1010,y:576,t:1526667415344};\\\", \\\"{x:897,y:564,t:1526667415361};\\\", \\\"{x:803,y:550,t:1526667415377};\\\", \\\"{x:714,y:537,t:1526667415395};\\\", \\\"{x:655,y:536,t:1526667415411};\\\", \\\"{x:621,y:530,t:1526667415429};\\\", \\\"{x:603,y:523,t:1526667415447};\\\", \\\"{x:597,y:522,t:1526667415462};\\\", \\\"{x:593,y:522,t:1526667415479};\\\", \\\"{x:589,y:520,t:1526667415496};\\\", \\\"{x:585,y:520,t:1526667415512};\\\", \\\"{x:578,y:520,t:1526667415529};\\\", \\\"{x:570,y:520,t:1526667415545};\\\", \\\"{x:559,y:520,t:1526667415561};\\\", \\\"{x:543,y:523,t:1526667415578};\\\", \\\"{x:522,y:528,t:1526667415595};\\\", \\\"{x:514,y:532,t:1526667415612};\\\", \\\"{x:510,y:535,t:1526667415629};\\\", \\\"{x:509,y:537,t:1526667415648};\\\", \\\"{x:509,y:538,t:1526667415672};\\\", \\\"{x:508,y:538,t:1526667415679};\\\", \\\"{x:507,y:542,t:1526667415695};\\\", \\\"{x:506,y:545,t:1526667415711};\\\", \\\"{x:503,y:549,t:1526667415729};\\\", \\\"{x:502,y:553,t:1526667415745};\\\", \\\"{x:498,y:560,t:1526667415763};\\\", \\\"{x:493,y:564,t:1526667415780};\\\", \\\"{x:486,y:566,t:1526667415796};\\\", \\\"{x:476,y:571,t:1526667415813};\\\", \\\"{x:468,y:574,t:1526667415829};\\\", \\\"{x:458,y:576,t:1526667415846};\\\", \\\"{x:444,y:579,t:1526667415863};\\\", \\\"{x:434,y:580,t:1526667415879};\\\", \\\"{x:409,y:584,t:1526667415896};\\\", \\\"{x:400,y:584,t:1526667415913};\\\", \\\"{x:393,y:584,t:1526667415929};\\\", \\\"{x:388,y:584,t:1526667415946};\\\", \\\"{x:384,y:584,t:1526667415963};\\\", \\\"{x:380,y:584,t:1526667415980};\\\", \\\"{x:377,y:583,t:1526667415996};\\\", \\\"{x:374,y:583,t:1526667416013};\\\", \\\"{x:372,y:582,t:1526667416129};\\\", \\\"{x:372,y:581,t:1526667416200};\\\", \\\"{x:372,y:580,t:1526667416216};\\\", \\\"{x:372,y:578,t:1526667416232};\\\", \\\"{x:372,y:577,t:1526667416245};\\\", \\\"{x:372,y:574,t:1526667416263};\\\", \\\"{x:372,y:572,t:1526667416279};\\\", \\\"{x:373,y:570,t:1526667416296};\\\", \\\"{x:375,y:568,t:1526667416313};\\\", \\\"{x:381,y:566,t:1526667416330};\\\", \\\"{x:388,y:562,t:1526667416346};\\\", \\\"{x:395,y:561,t:1526667416363};\\\", \\\"{x:403,y:559,t:1526667416379};\\\", \\\"{x:414,y:559,t:1526667416396};\\\", \\\"{x:425,y:559,t:1526667416413};\\\", \\\"{x:430,y:559,t:1526667416430};\\\", \\\"{x:436,y:559,t:1526667416445};\\\", \\\"{x:437,y:559,t:1526667416463};\\\", \\\"{x:439,y:559,t:1526667416480};\\\", \\\"{x:440,y:558,t:1526667416496};\\\", \\\"{x:441,y:558,t:1526667416512};\\\", \\\"{x:443,y:558,t:1526667416530};\\\", \\\"{x:444,y:558,t:1526667416616};\\\", \\\"{x:444,y:556,t:1526667416632};\\\", \\\"{x:442,y:555,t:1526667416646};\\\", \\\"{x:436,y:551,t:1526667416663};\\\", \\\"{x:430,y:550,t:1526667416680};\\\", \\\"{x:427,y:550,t:1526667416697};\\\", \\\"{x:424,y:552,t:1526667416713};\\\", \\\"{x:423,y:557,t:1526667416730};\\\", \\\"{x:421,y:565,t:1526667416747};\\\", \\\"{x:421,y:571,t:1526667416763};\\\", \\\"{x:418,y:581,t:1526667416780};\\\", \\\"{x:416,y:589,t:1526667416797};\\\", \\\"{x:415,y:594,t:1526667416813};\\\", \\\"{x:415,y:597,t:1526667416830};\\\", \\\"{x:415,y:599,t:1526667416847};\\\", \\\"{x:415,y:600,t:1526667416862};\\\", \\\"{x:414,y:601,t:1526667416880};\\\", \\\"{x:411,y:601,t:1526667416897};\\\", \\\"{x:408,y:602,t:1526667416913};\\\", \\\"{x:402,y:604,t:1526667416930};\\\", \\\"{x:395,y:606,t:1526667416946};\\\", \\\"{x:389,y:609,t:1526667416963};\\\", \\\"{x:385,y:612,t:1526667416980};\\\", \\\"{x:385,y:614,t:1526667417024};\\\", \\\"{x:385,y:615,t:1526667417032};\\\", \\\"{x:385,y:618,t:1526667417046};\\\", \\\"{x:385,y:626,t:1526667417065};\\\", \\\"{x:385,y:628,t:1526667417080};\\\", \\\"{x:385,y:629,t:1526667417103};\\\", \\\"{x:384,y:629,t:1526667417192};\\\", \\\"{x:380,y:626,t:1526667417200};\\\", \\\"{x:370,y:620,t:1526667417214};\\\", \\\"{x:352,y:604,t:1526667417230};\\\", \\\"{x:313,y:591,t:1526667417248};\\\", \\\"{x:276,y:586,t:1526667417263};\\\", \\\"{x:252,y:582,t:1526667417280};\\\", \\\"{x:241,y:582,t:1526667417297};\\\", \\\"{x:235,y:582,t:1526667417313};\\\", \\\"{x:230,y:583,t:1526667417330};\\\", \\\"{x:228,y:586,t:1526667417347};\\\", \\\"{x:228,y:588,t:1526667417364};\\\", \\\"{x:228,y:593,t:1526667417380};\\\", \\\"{x:229,y:598,t:1526667417397};\\\", \\\"{x:241,y:603,t:1526667417414};\\\", \\\"{x:250,y:605,t:1526667417430};\\\", \\\"{x:254,y:605,t:1526667417447};\\\", \\\"{x:256,y:605,t:1526667417463};\\\", \\\"{x:256,y:603,t:1526667417480};\\\", \\\"{x:256,y:600,t:1526667417504};\\\", \\\"{x:252,y:597,t:1526667417513};\\\", \\\"{x:242,y:590,t:1526667417531};\\\", \\\"{x:223,y:577,t:1526667417547};\\\", \\\"{x:194,y:559,t:1526667417565};\\\", \\\"{x:176,y:547,t:1526667417581};\\\", \\\"{x:155,y:537,t:1526667417597};\\\", \\\"{x:149,y:534,t:1526667417614};\\\", \\\"{x:146,y:532,t:1526667417632};\\\", \\\"{x:145,y:532,t:1526667417672};\\\", \\\"{x:145,y:531,t:1526667417681};\\\", \\\"{x:145,y:530,t:1526667417697};\\\", \\\"{x:146,y:530,t:1526667417816};\\\", \\\"{x:148,y:531,t:1526667417840};\\\", \\\"{x:150,y:531,t:1526667417976};\\\", \\\"{x:151,y:531,t:1526667417984};\\\", \\\"{x:152,y:531,t:1526667417998};\\\", \\\"{x:156,y:533,t:1526667418014};\\\", \\\"{x:157,y:533,t:1526667418031};\\\", \\\"{x:159,y:536,t:1526667418272};\\\", \\\"{x:174,y:537,t:1526667418281};\\\", \\\"{x:233,y:546,t:1526667418299};\\\", \\\"{x:312,y:560,t:1526667418314};\\\", \\\"{x:404,y:572,t:1526667418331};\\\", \\\"{x:509,y:585,t:1526667418348};\\\", \\\"{x:590,y:598,t:1526667418365};\\\", \\\"{x:657,y:600,t:1526667418381};\\\", \\\"{x:675,y:603,t:1526667418399};\\\", \\\"{x:701,y:602,t:1526667418415};\\\", \\\"{x:707,y:602,t:1526667418430};\\\", \\\"{x:709,y:601,t:1526667418448};\\\", \\\"{x:709,y:600,t:1526667418512};\\\", \\\"{x:709,y:597,t:1526667418531};\\\", \\\"{x:707,y:588,t:1526667418548};\\\", \\\"{x:703,y:581,t:1526667418565};\\\", \\\"{x:692,y:575,t:1526667418581};\\\", \\\"{x:686,y:570,t:1526667418597};\\\", \\\"{x:681,y:569,t:1526667418614};\\\", \\\"{x:679,y:569,t:1526667418631};\\\", \\\"{x:678,y:568,t:1526667418648};\\\", \\\"{x:680,y:568,t:1526667418687};\\\", \\\"{x:688,y:569,t:1526667418698};\\\", \\\"{x:707,y:578,t:1526667418715};\\\", \\\"{x:733,y:583,t:1526667418732};\\\", \\\"{x:760,y:583,t:1526667418748};\\\", \\\"{x:789,y:584,t:1526667418765};\\\", \\\"{x:812,y:584,t:1526667418781};\\\", \\\"{x:826,y:583,t:1526667418798};\\\", \\\"{x:831,y:581,t:1526667418815};\\\", \\\"{x:835,y:579,t:1526667418831};\\\", \\\"{x:835,y:577,t:1526667418848};\\\", \\\"{x:835,y:574,t:1526667418865};\\\", \\\"{x:828,y:560,t:1526667418883};\\\", \\\"{x:820,y:548,t:1526667418898};\\\", \\\"{x:815,y:540,t:1526667418916};\\\", \\\"{x:812,y:534,t:1526667418932};\\\", \\\"{x:811,y:531,t:1526667418948};\\\", \\\"{x:810,y:527,t:1526667418964};\\\", \\\"{x:808,y:522,t:1526667418983};\\\", \\\"{x:807,y:521,t:1526667418998};\\\", \\\"{x:807,y:520,t:1526667419024};\\\", \\\"{x:807,y:519,t:1526667419056};\\\", \\\"{x:808,y:518,t:1526667419065};\\\", \\\"{x:812,y:516,t:1526667419082};\\\", \\\"{x:816,y:513,t:1526667419098};\\\", \\\"{x:818,y:509,t:1526667419115};\\\", \\\"{x:818,y:508,t:1526667419132};\\\", \\\"{x:819,y:508,t:1526667419148};\\\", \\\"{x:819,y:507,t:1526667419232};\\\", \\\"{x:822,y:504,t:1526667419249};\\\", \\\"{x:823,y:504,t:1526667419264};\\\", \\\"{x:823,y:503,t:1526667419287};\\\", \\\"{x:824,y:502,t:1526667419303};\\\", \\\"{x:824,y:501,t:1526667419488};\\\", \\\"{x:820,y:502,t:1526667419499};\\\", \\\"{x:773,y:530,t:1526667419516};\\\", \\\"{x:694,y:572,t:1526667419533};\\\", \\\"{x:615,y:618,t:1526667419550};\\\", \\\"{x:558,y:651,t:1526667419565};\\\", \\\"{x:521,y:676,t:1526667419582};\\\", \\\"{x:505,y:694,t:1526667419599};\\\", \\\"{x:491,y:716,t:1526667419615};\\\", \\\"{x:486,y:730,t:1526667419632};\\\", \\\"{x:483,y:740,t:1526667419649};\\\", \\\"{x:483,y:748,t:1526667419665};\\\", \\\"{x:480,y:755,t:1526667419682};\\\", \\\"{x:478,y:763,t:1526667419700};\\\", \\\"{x:478,y:773,t:1526667419716};\\\", \\\"{x:478,y:776,t:1526667419732};\\\", \\\"{x:478,y:777,t:1526667419749};\\\", \\\"{x:479,y:776,t:1526667419824};\\\", \\\"{x:491,y:765,t:1526667419831};\\\", \\\"{x:511,y:747,t:1526667419849};\\\", \\\"{x:572,y:712,t:1526667419867};\\\", \\\"{x:643,y:680,t:1526667419882};\\\", \\\"{x:723,y:648,t:1526667419899};\\\", \\\"{x:779,y:621,t:1526667419917};\\\", \\\"{x:817,y:603,t:1526667419932};\\\", \\\"{x:825,y:596,t:1526667419949};\\\", \\\"{x:830,y:592,t:1526667419966};\\\", \\\"{x:833,y:587,t:1526667419983};\\\", \\\"{x:833,y:577,t:1526667419999};\\\", \\\"{x:834,y:563,t:1526667420016};\\\", \\\"{x:836,y:554,t:1526667420033};\\\", \\\"{x:839,y:547,t:1526667420049};\\\", \\\"{x:845,y:541,t:1526667420066};\\\", \\\"{x:852,y:536,t:1526667420083};\\\", \\\"{x:865,y:523,t:1526667420099};\\\", \\\"{x:865,y:522,t:1526667420116};\\\", \\\"{x:865,y:520,t:1526667420133};\\\", \\\"{x:865,y:518,t:1526667420149};\\\", \\\"{x:865,y:516,t:1526667420166};\\\", \\\"{x:865,y:513,t:1526667420183};\\\", \\\"{x:864,y:512,t:1526667420199};\\\", \\\"{x:858,y:510,t:1526667420216};\\\", \\\"{x:856,y:509,t:1526667420232};\\\", \\\"{x:853,y:506,t:1526667420249};\\\", \\\"{x:850,y:505,t:1526667420266};\\\", \\\"{x:848,y:504,t:1526667420283};\\\", \\\"{x:847,y:503,t:1526667420336};\\\", \\\"{x:846,y:502,t:1526667420349};\\\", \\\"{x:845,y:502,t:1526667420366};\\\", \\\"{x:844,y:502,t:1526667420391};\\\", \\\"{x:842,y:504,t:1526667420623};\\\", \\\"{x:831,y:516,t:1526667420634};\\\", \\\"{x:796,y:549,t:1526667420650};\\\", \\\"{x:754,y:590,t:1526667420666};\\\", \\\"{x:711,y:642,t:1526667420684};\\\", \\\"{x:671,y:689,t:1526667420700};\\\", \\\"{x:632,y:727,t:1526667420716};\\\", \\\"{x:613,y:748,t:1526667420733};\\\", \\\"{x:602,y:760,t:1526667420750};\\\", \\\"{x:595,y:768,t:1526667420766};\\\", \\\"{x:590,y:770,t:1526667420783};\\\", \\\"{x:576,y:775,t:1526667420800};\\\", \\\"{x:567,y:779,t:1526667420817};\\\", \\\"{x:551,y:783,t:1526667420833};\\\", \\\"{x:534,y:787,t:1526667420850};\\\", \\\"{x:525,y:792,t:1526667420867};\\\", \\\"{x:513,y:794,t:1526667420883};\\\", \\\"{x:510,y:794,t:1526667420900};\\\", \\\"{x:509,y:794,t:1526667420917};\\\", \\\"{x:509,y:793,t:1526667420976};\\\", \\\"{x:507,y:789,t:1526667420984};\\\", \\\"{x:504,y:778,t:1526667421000};\\\", \\\"{x:503,y:761,t:1526667421016};\\\", \\\"{x:500,y:742,t:1526667421034};\\\", \\\"{x:500,y:737,t:1526667421050};\\\", \\\"{x:500,y:735,t:1526667421066};\\\", \\\"{x:500,y:733,t:1526667421083};\\\" ] }, { \\\"rt\\\": 14430, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 547011, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"HWJDK\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"men\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"diagonal\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:501,y:732,t:1526667426384};\\\", \\\"{x:524,y:732,t:1526667426399};\\\", \\\"{x:575,y:732,t:1526667426417};\\\", \\\"{x:661,y:732,t:1526667426433};\\\", \\\"{x:778,y:735,t:1526667426454};\\\", \\\"{x:891,y:735,t:1526667426471};\\\", \\\"{x:1069,y:735,t:1526667426488};\\\", \\\"{x:1169,y:735,t:1526667426504};\\\", \\\"{x:1249,y:735,t:1526667426521};\\\", \\\"{x:1294,y:735,t:1526667426538};\\\", \\\"{x:1312,y:735,t:1526667426554};\\\", \\\"{x:1331,y:735,t:1526667426572};\\\", \\\"{x:1336,y:735,t:1526667426589};\\\", \\\"{x:1343,y:735,t:1526667426604};\\\", \\\"{x:1347,y:735,t:1526667426621};\\\", \\\"{x:1356,y:735,t:1526667426638};\\\", \\\"{x:1361,y:734,t:1526667426654};\\\", \\\"{x:1365,y:732,t:1526667426671};\\\", \\\"{x:1366,y:732,t:1526667426688};\\\", \\\"{x:1367,y:731,t:1526667426704};\\\", \\\"{x:1369,y:730,t:1526667426728};\\\", \\\"{x:1373,y:730,t:1526667426738};\\\", \\\"{x:1385,y:729,t:1526667426754};\\\", \\\"{x:1393,y:725,t:1526667426771};\\\", \\\"{x:1397,y:724,t:1526667426788};\\\", \\\"{x:1399,y:723,t:1526667426877};\\\", \\\"{x:1399,y:719,t:1526667426889};\\\", \\\"{x:1391,y:715,t:1526667426905};\\\", \\\"{x:1382,y:710,t:1526667426921};\\\", \\\"{x:1377,y:708,t:1526667426938};\\\", \\\"{x:1376,y:707,t:1526667426955};\\\", \\\"{x:1376,y:706,t:1526667427136};\\\", \\\"{x:1375,y:705,t:1526667427144};\\\", \\\"{x:1372,y:705,t:1526667427155};\\\", \\\"{x:1371,y:704,t:1526667427171};\\\", \\\"{x:1369,y:701,t:1526667427188};\\\", \\\"{x:1367,y:699,t:1526667427456};\\\", \\\"{x:1361,y:697,t:1526667427472};\\\", \\\"{x:1357,y:695,t:1526667427489};\\\", \\\"{x:1356,y:695,t:1526667427506};\\\", \\\"{x:1355,y:695,t:1526667427551};\\\", \\\"{x:1354,y:695,t:1526667427576};\\\", \\\"{x:1351,y:697,t:1526667430774};\\\", \\\"{x:1345,y:702,t:1526667430790};\\\", \\\"{x:1341,y:706,t:1526667430805};\\\", \\\"{x:1339,y:707,t:1526667430822};\\\", \\\"{x:1338,y:707,t:1526667431046};\\\", \\\"{x:1338,y:705,t:1526667431069};\\\", \\\"{x:1338,y:704,t:1526667431102};\\\", \\\"{x:1339,y:703,t:1526667431246};\\\", \\\"{x:1339,y:702,t:1526667431256};\\\", \\\"{x:1340,y:701,t:1526667431273};\\\", \\\"{x:1341,y:701,t:1526667431289};\\\", \\\"{x:1342,y:700,t:1526667431310};\\\", \\\"{x:1344,y:700,t:1526667431982};\\\", \\\"{x:1344,y:701,t:1526667431989};\\\", \\\"{x:1344,y:716,t:1526667432006};\\\", \\\"{x:1341,y:733,t:1526667432023};\\\", \\\"{x:1338,y:749,t:1526667432040};\\\", \\\"{x:1337,y:761,t:1526667432056};\\\", \\\"{x:1337,y:766,t:1526667432073};\\\", \\\"{x:1335,y:768,t:1526667432090};\\\", \\\"{x:1335,y:770,t:1526667432107};\\\", \\\"{x:1335,y:773,t:1526667432123};\\\", \\\"{x:1335,y:777,t:1526667432140};\\\", \\\"{x:1334,y:784,t:1526667432157};\\\", \\\"{x:1334,y:786,t:1526667432174};\\\", \\\"{x:1333,y:787,t:1526667432213};\\\", \\\"{x:1331,y:788,t:1526667432229};\\\", \\\"{x:1328,y:788,t:1526667432240};\\\", \\\"{x:1306,y:788,t:1526667432257};\\\", \\\"{x:1247,y:769,t:1526667432273};\\\", \\\"{x:1138,y:732,t:1526667432291};\\\", \\\"{x:987,y:679,t:1526667432307};\\\", \\\"{x:833,y:635,t:1526667432323};\\\", \\\"{x:680,y:584,t:1526667432341};\\\", \\\"{x:491,y:520,t:1526667432357};\\\", \\\"{x:405,y:497,t:1526667432373};\\\", \\\"{x:384,y:487,t:1526667432391};\\\", \\\"{x:378,y:485,t:1526667432408};\\\", \\\"{x:377,y:485,t:1526667432424};\\\", \\\"{x:376,y:484,t:1526667432453};\\\", \\\"{x:377,y:483,t:1526667432461};\\\", \\\"{x:380,y:485,t:1526667432605};\\\", \\\"{x:390,y:489,t:1526667432614};\\\", \\\"{x:399,y:495,t:1526667432624};\\\", \\\"{x:414,y:506,t:1526667432640};\\\", \\\"{x:433,y:513,t:1526667432657};\\\", \\\"{x:440,y:522,t:1526667432674};\\\", \\\"{x:455,y:526,t:1526667432690};\\\", \\\"{x:459,y:529,t:1526667432708};\\\", \\\"{x:461,y:529,t:1526667432742};\\\", \\\"{x:461,y:533,t:1526667432757};\\\", \\\"{x:456,y:539,t:1526667432774};\\\", \\\"{x:450,y:549,t:1526667432791};\\\", \\\"{x:446,y:561,t:1526667432807};\\\", \\\"{x:440,y:571,t:1526667432825};\\\", \\\"{x:436,y:576,t:1526667432841};\\\", \\\"{x:432,y:581,t:1526667432857};\\\", \\\"{x:426,y:584,t:1526667432875};\\\", \\\"{x:420,y:585,t:1526667432891};\\\", \\\"{x:416,y:585,t:1526667432908};\\\", \\\"{x:414,y:585,t:1526667432924};\\\", \\\"{x:413,y:586,t:1526667432941};\\\", \\\"{x:418,y:589,t:1526667433006};\\\", \\\"{x:438,y:594,t:1526667433025};\\\", \\\"{x:506,y:603,t:1526667433041};\\\", \\\"{x:601,y:603,t:1526667433058};\\\", \\\"{x:713,y:598,t:1526667433075};\\\", \\\"{x:818,y:582,t:1526667433092};\\\", \\\"{x:916,y:564,t:1526667433107};\\\", \\\"{x:977,y:556,t:1526667433124};\\\", \\\"{x:1004,y:547,t:1526667433142};\\\", \\\"{x:1005,y:547,t:1526667433158};\\\", \\\"{x:1005,y:546,t:1526667433189};\\\", \\\"{x:1005,y:544,t:1526667433205};\\\", \\\"{x:1005,y:543,t:1526667433222};\\\", \\\"{x:1003,y:541,t:1526667433230};\\\", \\\"{x:1000,y:539,t:1526667433241};\\\", \\\"{x:989,y:535,t:1526667433258};\\\", \\\"{x:973,y:528,t:1526667433274};\\\", \\\"{x:952,y:519,t:1526667433291};\\\", \\\"{x:928,y:508,t:1526667433307};\\\", \\\"{x:912,y:500,t:1526667433324};\\\", \\\"{x:904,y:499,t:1526667433341};\\\", \\\"{x:894,y:501,t:1526667433357};\\\", \\\"{x:885,y:502,t:1526667433374};\\\", \\\"{x:874,y:506,t:1526667433391};\\\", \\\"{x:865,y:512,t:1526667433409};\\\", \\\"{x:859,y:521,t:1526667433425};\\\", \\\"{x:850,y:534,t:1526667433442};\\\", \\\"{x:840,y:545,t:1526667433459};\\\", \\\"{x:831,y:557,t:1526667433474};\\\", \\\"{x:815,y:564,t:1526667433491};\\\", \\\"{x:784,y:574,t:1526667433508};\\\", \\\"{x:758,y:578,t:1526667433525};\\\", \\\"{x:672,y:572,t:1526667433542};\\\", \\\"{x:583,y:558,t:1526667433558};\\\", \\\"{x:500,y:549,t:1526667433575};\\\", \\\"{x:464,y:545,t:1526667433592};\\\", \\\"{x:446,y:543,t:1526667433609};\\\", \\\"{x:442,y:543,t:1526667433624};\\\", \\\"{x:439,y:543,t:1526667433641};\\\", \\\"{x:438,y:543,t:1526667433717};\\\", \\\"{x:436,y:548,t:1526667433725};\\\", \\\"{x:434,y:558,t:1526667433741};\\\", \\\"{x:433,y:566,t:1526667433759};\\\", \\\"{x:431,y:572,t:1526667433775};\\\", \\\"{x:426,y:578,t:1526667433791};\\\", \\\"{x:421,y:581,t:1526667433808};\\\", \\\"{x:411,y:585,t:1526667433825};\\\", \\\"{x:392,y:591,t:1526667433841};\\\", \\\"{x:365,y:593,t:1526667433858};\\\", \\\"{x:331,y:593,t:1526667433875};\\\", \\\"{x:301,y:593,t:1526667433891};\\\", \\\"{x:281,y:595,t:1526667433909};\\\", \\\"{x:267,y:596,t:1526667433924};\\\", \\\"{x:240,y:596,t:1526667433941};\\\", \\\"{x:221,y:596,t:1526667433958};\\\", \\\"{x:208,y:594,t:1526667433975};\\\", \\\"{x:204,y:594,t:1526667433992};\\\", \\\"{x:203,y:594,t:1526667434008};\\\", \\\"{x:203,y:596,t:1526667434053};\\\", \\\"{x:203,y:595,t:1526667434157};\\\", \\\"{x:202,y:591,t:1526667434165};\\\", \\\"{x:200,y:584,t:1526667434175};\\\", \\\"{x:189,y:572,t:1526667434192};\\\", \\\"{x:179,y:561,t:1526667434208};\\\", \\\"{x:170,y:556,t:1526667434226};\\\", \\\"{x:167,y:554,t:1526667434243};\\\", \\\"{x:167,y:552,t:1526667434258};\\\", \\\"{x:167,y:551,t:1526667434285};\\\", \\\"{x:166,y:551,t:1526667434293};\\\", \\\"{x:166,y:550,t:1526667434438};\\\", \\\"{x:166,y:549,t:1526667434444};\\\", \\\"{x:166,y:547,t:1526667434459};\\\", \\\"{x:166,y:545,t:1526667434476};\\\", \\\"{x:166,y:543,t:1526667434492};\\\", \\\"{x:166,y:542,t:1526667434510};\\\", \\\"{x:168,y:541,t:1526667434741};\\\", \\\"{x:179,y:544,t:1526667434750};\\\", \\\"{x:186,y:549,t:1526667434759};\\\", \\\"{x:238,y:569,t:1526667434776};\\\", \\\"{x:319,y:598,t:1526667434793};\\\", \\\"{x:415,y:638,t:1526667434809};\\\", \\\"{x:494,y:664,t:1526667434826};\\\", \\\"{x:561,y:687,t:1526667434843};\\\", \\\"{x:594,y:701,t:1526667434860};\\\", \\\"{x:611,y:706,t:1526667434875};\\\", \\\"{x:617,y:709,t:1526667434892};\\\", \\\"{x:618,y:711,t:1526667434973};\\\", \\\"{x:618,y:715,t:1526667434981};\\\", \\\"{x:618,y:716,t:1526667434992};\\\", \\\"{x:615,y:721,t:1526667435009};\\\", \\\"{x:612,y:724,t:1526667435025};\\\", \\\"{x:607,y:728,t:1526667435042};\\\", \\\"{x:601,y:731,t:1526667435059};\\\", \\\"{x:594,y:734,t:1526667435076};\\\", \\\"{x:590,y:734,t:1526667435092};\\\", \\\"{x:564,y:734,t:1526667435109};\\\", \\\"{x:550,y:733,t:1526667435125};\\\", \\\"{x:540,y:733,t:1526667435142};\\\", \\\"{x:535,y:733,t:1526667435159};\\\" ] }, { \\\"rt\\\": 46983, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 595249, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"HWJDK\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"men\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"diagonal\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -Z -Z -Z -Z -C \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:539,y:734,t:1526667442469};\\\", \\\"{x:641,y:745,t:1526667442490};\\\", \\\"{x:724,y:747,t:1526667442501};\\\", \\\"{x:888,y:754,t:1526667442517};\\\", \\\"{x:1053,y:769,t:1526667442531};\\\", \\\"{x:1197,y:789,t:1526667442547};\\\", \\\"{x:1319,y:788,t:1526667442564};\\\", \\\"{x:1448,y:792,t:1526667442581};\\\", \\\"{x:1514,y:797,t:1526667442598};\\\", \\\"{x:1541,y:805,t:1526667442614};\\\", \\\"{x:1553,y:812,t:1526667442632};\\\", \\\"{x:1557,y:814,t:1526667442649};\\\", \\\"{x:1561,y:817,t:1526667442664};\\\", \\\"{x:1565,y:824,t:1526667442681};\\\", \\\"{x:1568,y:836,t:1526667442698};\\\", \\\"{x:1571,y:845,t:1526667442715};\\\", \\\"{x:1574,y:847,t:1526667442732};\\\", \\\"{x:1577,y:849,t:1526667442748};\\\", \\\"{x:1589,y:851,t:1526667442765};\\\", \\\"{x:1607,y:844,t:1526667442782};\\\", \\\"{x:1630,y:828,t:1526667442798};\\\", \\\"{x:1645,y:813,t:1526667442814};\\\", \\\"{x:1654,y:795,t:1526667442832};\\\", \\\"{x:1661,y:775,t:1526667442848};\\\", \\\"{x:1664,y:764,t:1526667442865};\\\", \\\"{x:1665,y:750,t:1526667442882};\\\", \\\"{x:1665,y:737,t:1526667442898};\\\", \\\"{x:1657,y:725,t:1526667442914};\\\", \\\"{x:1646,y:713,t:1526667442932};\\\", \\\"{x:1638,y:706,t:1526667442948};\\\", \\\"{x:1628,y:699,t:1526667442964};\\\", \\\"{x:1621,y:693,t:1526667442982};\\\", \\\"{x:1614,y:683,t:1526667442999};\\\", \\\"{x:1604,y:672,t:1526667443014};\\\", \\\"{x:1600,y:669,t:1526667443031};\\\", \\\"{x:1597,y:667,t:1526667443049};\\\", \\\"{x:1597,y:670,t:1526667443126};\\\", \\\"{x:1597,y:674,t:1526667443133};\\\", \\\"{x:1597,y:675,t:1526667443149};\\\", \\\"{x:1598,y:676,t:1526667443165};\\\", \\\"{x:1598,y:677,t:1526667443182};\\\", \\\"{x:1598,y:678,t:1526667443205};\\\", \\\"{x:1599,y:678,t:1526667443214};\\\", \\\"{x:1600,y:679,t:1526667443245};\\\", \\\"{x:1601,y:679,t:1526667443325};\\\", \\\"{x:1602,y:680,t:1526667443333};\\\", \\\"{x:1604,y:681,t:1526667443349};\\\", \\\"{x:1611,y:683,t:1526667443364};\\\", \\\"{x:1614,y:685,t:1526667443382};\\\", \\\"{x:1615,y:685,t:1526667443398};\\\", \\\"{x:1615,y:687,t:1526667443493};\\\", \\\"{x:1615,y:689,t:1526667443500};\\\", \\\"{x:1615,y:691,t:1526667443516};\\\", \\\"{x:1615,y:692,t:1526667443532};\\\", \\\"{x:1615,y:694,t:1526667443548};\\\", \\\"{x:1615,y:695,t:1526667443597};\\\", \\\"{x:1615,y:696,t:1526667444725};\\\", \\\"{x:1611,y:696,t:1526667471221};\\\", \\\"{x:1577,y:689,t:1526667471233};\\\", \\\"{x:1450,y:658,t:1526667471249};\\\", \\\"{x:1291,y:622,t:1526667471266};\\\", \\\"{x:1115,y:582,t:1526667471282};\\\", \\\"{x:934,y:534,t:1526667471299};\\\", \\\"{x:741,y:486,t:1526667471316};\\\", \\\"{x:507,y:424,t:1526667471332};\\\", \\\"{x:395,y:401,t:1526667471355};\\\", \\\"{x:340,y:389,t:1526667471372};\\\", \\\"{x:316,y:385,t:1526667471389};\\\", \\\"{x:320,y:388,t:1526667471429};\\\", \\\"{x:330,y:392,t:1526667471439};\\\", \\\"{x:347,y:395,t:1526667471456};\\\", \\\"{x:369,y:397,t:1526667471473};\\\", \\\"{x:397,y:402,t:1526667471489};\\\", \\\"{x:436,y:426,t:1526667471506};\\\", \\\"{x:487,y:464,t:1526667471523};\\\", \\\"{x:550,y:509,t:1526667471540};\\\", \\\"{x:638,y:547,t:1526667471556};\\\", \\\"{x:685,y:568,t:1526667471573};\\\", \\\"{x:789,y:583,t:1526667471589};\\\", \\\"{x:868,y:587,t:1526667471606};\\\", \\\"{x:911,y:588,t:1526667471623};\\\", \\\"{x:926,y:588,t:1526667471639};\\\", \\\"{x:928,y:588,t:1526667471656};\\\", \\\"{x:926,y:587,t:1526667471741};\\\", \\\"{x:926,y:584,t:1526667471755};\\\", \\\"{x:918,y:572,t:1526667471772};\\\", \\\"{x:905,y:560,t:1526667471789};\\\", \\\"{x:887,y:549,t:1526667471806};\\\", \\\"{x:866,y:532,t:1526667471822};\\\", \\\"{x:848,y:519,t:1526667471839};\\\", \\\"{x:843,y:514,t:1526667471857};\\\", \\\"{x:839,y:511,t:1526667471873};\\\", \\\"{x:839,y:510,t:1526667471889};\\\", \\\"{x:838,y:510,t:1526667471940};\\\", \\\"{x:837,y:509,t:1526667472021};\\\", \\\"{x:836,y:509,t:1526667472277};\\\", \\\"{x:836,y:513,t:1526667472289};\\\", \\\"{x:831,y:522,t:1526667472307};\\\", \\\"{x:825,y:532,t:1526667472323};\\\", \\\"{x:815,y:546,t:1526667472340};\\\", \\\"{x:792,y:563,t:1526667472357};\\\", \\\"{x:778,y:572,t:1526667472372};\\\", \\\"{x:769,y:577,t:1526667472390};\\\", \\\"{x:750,y:578,t:1526667472406};\\\", \\\"{x:711,y:578,t:1526667472423};\\\", \\\"{x:669,y:575,t:1526667472440};\\\", \\\"{x:596,y:567,t:1526667472456};\\\", \\\"{x:544,y:561,t:1526667472474};\\\", \\\"{x:515,y:561,t:1526667472490};\\\", \\\"{x:494,y:561,t:1526667472507};\\\", \\\"{x:478,y:561,t:1526667472523};\\\", \\\"{x:470,y:567,t:1526667472541};\\\", \\\"{x:465,y:578,t:1526667472556};\\\", \\\"{x:464,y:588,t:1526667472573};\\\", \\\"{x:464,y:595,t:1526667472590};\\\", \\\"{x:464,y:599,t:1526667472607};\\\", \\\"{x:464,y:602,t:1526667472624};\\\", \\\"{x:465,y:605,t:1526667472640};\\\", \\\"{x:465,y:609,t:1526667472657};\\\", \\\"{x:465,y:614,t:1526667472673};\\\", \\\"{x:465,y:617,t:1526667472689};\\\", \\\"{x:464,y:620,t:1526667472706};\\\", \\\"{x:456,y:624,t:1526667472723};\\\", \\\"{x:447,y:627,t:1526667472740};\\\", \\\"{x:416,y:627,t:1526667472756};\\\", \\\"{x:393,y:624,t:1526667472774};\\\", \\\"{x:363,y:622,t:1526667472789};\\\", \\\"{x:337,y:620,t:1526667472807};\\\", \\\"{x:321,y:620,t:1526667472824};\\\", \\\"{x:316,y:620,t:1526667472840};\\\", \\\"{x:315,y:621,t:1526667472856};\\\", \\\"{x:317,y:623,t:1526667472873};\\\", \\\"{x:330,y:630,t:1526667472890};\\\", \\\"{x:376,y:633,t:1526667472907};\\\", \\\"{x:455,y:638,t:1526667472924};\\\", \\\"{x:545,y:642,t:1526667472940};\\\", \\\"{x:661,y:651,t:1526667472957};\\\", \\\"{x:709,y:652,t:1526667472974};\\\", \\\"{x:732,y:652,t:1526667472991};\\\", \\\"{x:739,y:652,t:1526667473007};\\\", \\\"{x:741,y:652,t:1526667473023};\\\", \\\"{x:742,y:651,t:1526667473041};\\\", \\\"{x:742,y:650,t:1526667473057};\\\", \\\"{x:742,y:646,t:1526667473074};\\\", \\\"{x:742,y:645,t:1526667473091};\\\", \\\"{x:742,y:643,t:1526667473107};\\\", \\\"{x:740,y:636,t:1526667473124};\\\", \\\"{x:723,y:625,t:1526667473141};\\\", \\\"{x:698,y:610,t:1526667473157};\\\", \\\"{x:683,y:601,t:1526667473174};\\\", \\\"{x:675,y:598,t:1526667473190};\\\", \\\"{x:661,y:592,t:1526667473207};\\\", \\\"{x:651,y:591,t:1526667473224};\\\", \\\"{x:645,y:588,t:1526667473240};\\\", \\\"{x:626,y:587,t:1526667473257};\\\", \\\"{x:609,y:584,t:1526667473273};\\\", \\\"{x:596,y:583,t:1526667473291};\\\", \\\"{x:594,y:583,t:1526667473306};\\\", \\\"{x:592,y:582,t:1526667473323};\\\", \\\"{x:592,y:581,t:1526667473532};\\\", \\\"{x:593,y:581,t:1526667473541};\\\", \\\"{x:596,y:581,t:1526667473557};\\\", \\\"{x:597,y:581,t:1526667473573};\\\", \\\"{x:598,y:581,t:1526667473669};\\\", \\\"{x:599,y:581,t:1526667473677};\\\", \\\"{x:601,y:581,t:1526667473690};\\\", \\\"{x:605,y:581,t:1526667473707};\\\", \\\"{x:606,y:581,t:1526667473724};\\\", \\\"{x:609,y:581,t:1526667473893};\\\", \\\"{x:614,y:581,t:1526667473908};\\\", \\\"{x:628,y:581,t:1526667473924};\\\", \\\"{x:667,y:581,t:1526667473941};\\\", \\\"{x:719,y:586,t:1526667473958};\\\", \\\"{x:857,y:603,t:1526667473976};\\\", \\\"{x:1015,y:630,t:1526667473991};\\\", \\\"{x:1208,y:655,t:1526667474008};\\\", \\\"{x:1402,y:691,t:1526667474025};\\\", \\\"{x:1565,y:709,t:1526667474041};\\\", \\\"{x:1698,y:726,t:1526667474057};\\\", \\\"{x:1776,y:739,t:1526667474075};\\\", \\\"{x:1800,y:742,t:1526667474091};\\\", \\\"{x:1806,y:744,t:1526667474107};\\\", \\\"{x:1805,y:744,t:1526667474156};\\\", \\\"{x:1804,y:744,t:1526667474164};\\\", \\\"{x:1803,y:744,t:1526667474174};\\\", \\\"{x:1798,y:744,t:1526667474191};\\\", \\\"{x:1792,y:744,t:1526667474207};\\\", \\\"{x:1778,y:743,t:1526667474225};\\\", \\\"{x:1756,y:741,t:1526667474241};\\\", \\\"{x:1733,y:741,t:1526667474258};\\\", \\\"{x:1704,y:739,t:1526667474275};\\\", \\\"{x:1683,y:732,t:1526667474292};\\\", \\\"{x:1662,y:727,t:1526667474308};\\\", \\\"{x:1631,y:718,t:1526667474324};\\\", \\\"{x:1618,y:714,t:1526667474341};\\\", \\\"{x:1610,y:709,t:1526667474358};\\\", \\\"{x:1599,y:704,t:1526667474375};\\\", \\\"{x:1593,y:703,t:1526667474392};\\\", \\\"{x:1589,y:699,t:1526667474407};\\\", \\\"{x:1596,y:699,t:1526667474468};\\\", \\\"{x:1600,y:699,t:1526667474477};\\\", \\\"{x:1603,y:699,t:1526667474491};\\\", \\\"{x:1607,y:699,t:1526667474508};\\\", \\\"{x:1613,y:698,t:1526667474525};\\\", \\\"{x:1613,y:697,t:1526667474572};\\\", \\\"{x:1613,y:696,t:1526667474892};\\\", \\\"{x:1613,y:693,t:1526667474909};\\\", \\\"{x:1613,y:692,t:1526667474932};\\\", \\\"{x:1613,y:690,t:1526667484358};\\\", \\\"{x:1610,y:689,t:1526667484369};\\\", \\\"{x:1588,y:677,t:1526667484384};\\\", \\\"{x:1535,y:657,t:1526667484401};\\\", \\\"{x:1451,y:630,t:1526667484418};\\\", \\\"{x:1367,y:615,t:1526667484434};\\\", \\\"{x:1329,y:612,t:1526667484451};\\\", \\\"{x:1283,y:614,t:1526667484468};\\\", \\\"{x:1259,y:626,t:1526667484484};\\\", \\\"{x:1230,y:642,t:1526667484501};\\\", \\\"{x:1203,y:661,t:1526667484518};\\\", \\\"{x:1182,y:678,t:1526667484534};\\\", \\\"{x:1153,y:707,t:1526667484551};\\\", \\\"{x:1121,y:730,t:1526667484569};\\\", \\\"{x:1082,y:756,t:1526667484585};\\\", \\\"{x:1015,y:777,t:1526667484601};\\\", \\\"{x:930,y:798,t:1526667484618};\\\", \\\"{x:869,y:804,t:1526667484635};\\\", \\\"{x:805,y:797,t:1526667484652};\\\", \\\"{x:729,y:781,t:1526667484669};\\\", \\\"{x:671,y:775,t:1526667484684};\\\", \\\"{x:641,y:771,t:1526667484701};\\\", \\\"{x:622,y:768,t:1526667484718};\\\", \\\"{x:615,y:764,t:1526667484735};\\\", \\\"{x:598,y:760,t:1526667484751};\\\", \\\"{x:587,y:756,t:1526667484769};\\\", \\\"{x:586,y:755,t:1526667484786};\\\", \\\"{x:584,y:755,t:1526667484802};\\\", \\\"{x:584,y:753,t:1526667484818};\\\", \\\"{x:583,y:751,t:1526667484844};\\\", \\\"{x:579,y:748,t:1526667484852};\\\", \\\"{x:574,y:746,t:1526667484868};\\\", \\\"{x:565,y:741,t:1526667484885};\\\", \\\"{x:561,y:740,t:1526667484901};\\\", \\\"{x:557,y:738,t:1526667484918};\\\", \\\"{x:553,y:738,t:1526667484936};\\\", \\\"{x:552,y:737,t:1526667484950};\\\" ] }, { \\\"rt\\\": 31829, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 628271, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"HWJDK\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"men\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"diagonal\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04:30-04:30-03 PM-X -03 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:555,y:737,t:1526667487029};\\\", \\\"{x:559,y:741,t:1526667487037};\\\", \\\"{x:581,y:746,t:1526667487054};\\\", \\\"{x:642,y:755,t:1526667487070};\\\", \\\"{x:719,y:760,t:1526667487086};\\\", \\\"{x:796,y:769,t:1526667487101};\\\", \\\"{x:824,y:773,t:1526667487119};\\\", \\\"{x:840,y:774,t:1526667487136};\\\", \\\"{x:853,y:774,t:1526667487152};\\\", \\\"{x:857,y:774,t:1526667487168};\\\", \\\"{x:859,y:774,t:1526667487186};\\\", \\\"{x:866,y:777,t:1526667488229};\\\", \\\"{x:879,y:782,t:1526667488236};\\\", \\\"{x:931,y:799,t:1526667488253};\\\", \\\"{x:1035,y:821,t:1526667488269};\\\", \\\"{x:1142,y:847,t:1526667488287};\\\", \\\"{x:1275,y:884,t:1526667488303};\\\", \\\"{x:1413,y:923,t:1526667488320};\\\", \\\"{x:1539,y:950,t:1526667488337};\\\", \\\"{x:1649,y:976,t:1526667488352};\\\", \\\"{x:1725,y:993,t:1526667488370};\\\", \\\"{x:1752,y:1000,t:1526667488387};\\\", \\\"{x:1775,y:1005,t:1526667488403};\\\", \\\"{x:1782,y:1009,t:1526667488420};\\\", \\\"{x:1786,y:1010,t:1526667488436};\\\", \\\"{x:1788,y:1012,t:1526667488453};\\\", \\\"{x:1791,y:1014,t:1526667488470};\\\", \\\"{x:1791,y:1015,t:1526667488486};\\\", \\\"{x:1790,y:1016,t:1526667488549};\\\", \\\"{x:1785,y:1016,t:1526667488557};\\\", \\\"{x:1776,y:1011,t:1526667488569};\\\", \\\"{x:1749,y:1000,t:1526667488586};\\\", \\\"{x:1721,y:986,t:1526667488603};\\\", \\\"{x:1694,y:979,t:1526667488620};\\\", \\\"{x:1663,y:972,t:1526667488636};\\\", \\\"{x:1649,y:969,t:1526667488653};\\\", \\\"{x:1641,y:968,t:1526667488670};\\\", \\\"{x:1640,y:968,t:1526667488764};\\\", \\\"{x:1639,y:968,t:1526667488772};\\\", \\\"{x:1636,y:968,t:1526667488787};\\\", \\\"{x:1630,y:969,t:1526667488804};\\\", \\\"{x:1625,y:971,t:1526667488820};\\\", \\\"{x:1610,y:973,t:1526667488837};\\\", \\\"{x:1596,y:973,t:1526667488853};\\\", \\\"{x:1580,y:973,t:1526667488869};\\\", \\\"{x:1556,y:972,t:1526667488886};\\\", \\\"{x:1548,y:972,t:1526667488903};\\\", \\\"{x:1546,y:972,t:1526667488920};\\\", \\\"{x:1545,y:972,t:1526667488937};\\\", \\\"{x:1544,y:971,t:1526667489021};\\\", \\\"{x:1544,y:970,t:1526667489036};\\\", \\\"{x:1544,y:969,t:1526667489101};\\\", \\\"{x:1544,y:966,t:1526667489116};\\\", \\\"{x:1545,y:965,t:1526667489133};\\\", \\\"{x:1546,y:965,t:1526667489141};\\\", \\\"{x:1547,y:964,t:1526667489156};\\\", \\\"{x:1544,y:953,t:1526667502442};\\\", \\\"{x:1506,y:924,t:1526667502450};\\\", \\\"{x:1445,y:883,t:1526667502462};\\\", \\\"{x:1313,y:797,t:1526667502479};\\\", \\\"{x:1162,y:716,t:1526667502495};\\\", \\\"{x:1004,y:637,t:1526667502512};\\\", \\\"{x:845,y:572,t:1526667502529};\\\", \\\"{x:609,y:494,t:1526667502546};\\\", \\\"{x:473,y:453,t:1526667502562};\\\", \\\"{x:424,y:442,t:1526667502577};\\\", \\\"{x:350,y:432,t:1526667502594};\\\", \\\"{x:334,y:441,t:1526667502610};\\\", \\\"{x:318,y:452,t:1526667502626};\\\", \\\"{x:300,y:463,t:1526667502644};\\\", \\\"{x:289,y:474,t:1526667502660};\\\", \\\"{x:270,y:497,t:1526667502677};\\\", \\\"{x:256,y:528,t:1526667502695};\\\", \\\"{x:249,y:576,t:1526667502712};\\\", \\\"{x:249,y:611,t:1526667502729};\\\", \\\"{x:264,y:636,t:1526667502746};\\\", \\\"{x:280,y:646,t:1526667502763};\\\", \\\"{x:303,y:656,t:1526667502779};\\\", \\\"{x:355,y:662,t:1526667502796};\\\", \\\"{x:401,y:663,t:1526667502812};\\\", \\\"{x:430,y:663,t:1526667502829};\\\", \\\"{x:443,y:660,t:1526667502846};\\\", \\\"{x:450,y:657,t:1526667502863};\\\", \\\"{x:453,y:653,t:1526667502878};\\\", \\\"{x:455,y:646,t:1526667502896};\\\", \\\"{x:457,y:632,t:1526667502913};\\\", \\\"{x:458,y:615,t:1526667502930};\\\", \\\"{x:453,y:601,t:1526667502945};\\\", \\\"{x:436,y:584,t:1526667502963};\\\", \\\"{x:410,y:571,t:1526667502980};\\\", \\\"{x:384,y:564,t:1526667502996};\\\", \\\"{x:361,y:561,t:1526667503013};\\\", \\\"{x:352,y:562,t:1526667503030};\\\", \\\"{x:334,y:572,t:1526667503046};\\\", \\\"{x:318,y:585,t:1526667503063};\\\", \\\"{x:299,y:598,t:1526667503078};\\\", \\\"{x:289,y:606,t:1526667503096};\\\", \\\"{x:280,y:609,t:1526667503112};\\\", \\\"{x:262,y:609,t:1526667503130};\\\", \\\"{x:247,y:609,t:1526667503146};\\\", \\\"{x:225,y:601,t:1526667503163};\\\", \\\"{x:207,y:588,t:1526667503179};\\\", \\\"{x:192,y:580,t:1526667503196};\\\", \\\"{x:181,y:573,t:1526667503212};\\\", \\\"{x:177,y:569,t:1526667503229};\\\", \\\"{x:177,y:566,t:1526667503246};\\\", \\\"{x:178,y:561,t:1526667503264};\\\", \\\"{x:179,y:558,t:1526667503279};\\\", \\\"{x:179,y:557,t:1526667503295};\\\", \\\"{x:180,y:554,t:1526667503313};\\\", \\\"{x:181,y:553,t:1526667503330};\\\", \\\"{x:181,y:551,t:1526667503354};\\\", \\\"{x:181,y:550,t:1526667503363};\\\", \\\"{x:180,y:546,t:1526667503380};\\\", \\\"{x:178,y:543,t:1526667503395};\\\", \\\"{x:174,y:536,t:1526667503413};\\\", \\\"{x:172,y:534,t:1526667503429};\\\", \\\"{x:170,y:532,t:1526667503446};\\\", \\\"{x:167,y:530,t:1526667503462};\\\", \\\"{x:164,y:528,t:1526667503480};\\\", \\\"{x:160,y:527,t:1526667503497};\\\", \\\"{x:155,y:524,t:1526667503513};\\\", \\\"{x:148,y:524,t:1526667503529};\\\", \\\"{x:147,y:524,t:1526667503546};\\\", \\\"{x:146,y:524,t:1526667503626};\\\", \\\"{x:146,y:525,t:1526667503635};\\\", \\\"{x:148,y:528,t:1526667503647};\\\", \\\"{x:151,y:532,t:1526667503663};\\\", \\\"{x:153,y:533,t:1526667503679};\\\", \\\"{x:153,y:534,t:1526667503930};\\\", \\\"{x:153,y:534,t:1526667503974};\\\", \\\"{x:155,y:536,t:1526667504082};\\\", \\\"{x:160,y:538,t:1526667504096};\\\", \\\"{x:201,y:548,t:1526667504114};\\\", \\\"{x:293,y:575,t:1526667504130};\\\", \\\"{x:426,y:614,t:1526667504147};\\\", \\\"{x:579,y:647,t:1526667504164};\\\", \\\"{x:760,y:683,t:1526667504179};\\\", \\\"{x:941,y:721,t:1526667504196};\\\", \\\"{x:1122,y:760,t:1526667504213};\\\", \\\"{x:1284,y:793,t:1526667504230};\\\", \\\"{x:1401,y:814,t:1526667504247};\\\", \\\"{x:1450,y:818,t:1526667504264};\\\", \\\"{x:1467,y:829,t:1526667504279};\\\", \\\"{x:1480,y:833,t:1526667504297};\\\", \\\"{x:1481,y:834,t:1526667504313};\\\", \\\"{x:1482,y:835,t:1526667504370};\\\", \\\"{x:1482,y:839,t:1526667504381};\\\", \\\"{x:1482,y:846,t:1526667504396};\\\", \\\"{x:1486,y:857,t:1526667504414};\\\", \\\"{x:1489,y:862,t:1526667504431};\\\", \\\"{x:1490,y:865,t:1526667504447};\\\", \\\"{x:1491,y:865,t:1526667505770};\\\", \\\"{x:1493,y:862,t:1526667505781};\\\", \\\"{x:1496,y:856,t:1526667505798};\\\", \\\"{x:1500,y:849,t:1526667505815};\\\", \\\"{x:1502,y:848,t:1526667505832};\\\", \\\"{x:1502,y:846,t:1526667505848};\\\", \\\"{x:1503,y:846,t:1526667505864};\\\", \\\"{x:1504,y:845,t:1526667505882};\\\", \\\"{x:1508,y:845,t:1526667505898};\\\", \\\"{x:1516,y:848,t:1526667505914};\\\", \\\"{x:1523,y:850,t:1526667505932};\\\", \\\"{x:1529,y:853,t:1526667505949};\\\", \\\"{x:1537,y:858,t:1526667505965};\\\", \\\"{x:1540,y:859,t:1526667505982};\\\", \\\"{x:1543,y:861,t:1526667505999};\\\", \\\"{x:1543,y:862,t:1526667506015};\\\", \\\"{x:1543,y:864,t:1526667506034};\\\", \\\"{x:1543,y:866,t:1526667506049};\\\", \\\"{x:1543,y:879,t:1526667506065};\\\", \\\"{x:1543,y:904,t:1526667506081};\\\", \\\"{x:1542,y:917,t:1526667506099};\\\", \\\"{x:1541,y:927,t:1526667506115};\\\", \\\"{x:1540,y:933,t:1526667506131};\\\", \\\"{x:1540,y:940,t:1526667506149};\\\", \\\"{x:1543,y:951,t:1526667506165};\\\", \\\"{x:1545,y:958,t:1526667506182};\\\", \\\"{x:1548,y:963,t:1526667506199};\\\", \\\"{x:1548,y:966,t:1526667506215};\\\", \\\"{x:1549,y:967,t:1526667506232};\\\", \\\"{x:1549,y:968,t:1526667506248};\\\", \\\"{x:1548,y:965,t:1526667506314};\\\", \\\"{x:1547,y:964,t:1526667506321};\\\", \\\"{x:1547,y:963,t:1526667506332};\\\", \\\"{x:1547,y:958,t:1526667506349};\\\", \\\"{x:1544,y:949,t:1526667506365};\\\", \\\"{x:1544,y:945,t:1526667506382};\\\", \\\"{x:1544,y:936,t:1526667506399};\\\", \\\"{x:1544,y:932,t:1526667506415};\\\", \\\"{x:1548,y:918,t:1526667506432};\\\", \\\"{x:1553,y:895,t:1526667506449};\\\", \\\"{x:1560,y:871,t:1526667506466};\\\", \\\"{x:1561,y:848,t:1526667506482};\\\", \\\"{x:1562,y:826,t:1526667506499};\\\", \\\"{x:1562,y:816,t:1526667506515};\\\", \\\"{x:1562,y:813,t:1526667506532};\\\", \\\"{x:1562,y:809,t:1526667506549};\\\", \\\"{x:1562,y:807,t:1526667506566};\\\", \\\"{x:1562,y:806,t:1526667506582};\\\", \\\"{x:1562,y:804,t:1526667506602};\\\", \\\"{x:1562,y:803,t:1526667506615};\\\", \\\"{x:1560,y:801,t:1526667506632};\\\", \\\"{x:1560,y:800,t:1526667506650};\\\", \\\"{x:1560,y:799,t:1526667506690};\\\", \\\"{x:1560,y:798,t:1526667506698};\\\", \\\"{x:1557,y:796,t:1526667506716};\\\", \\\"{x:1556,y:795,t:1526667506733};\\\", \\\"{x:1554,y:795,t:1526667506754};\\\", \\\"{x:1553,y:795,t:1526667506766};\\\", \\\"{x:1549,y:812,t:1526667506782};\\\", \\\"{x:1540,y:857,t:1526667506799};\\\", \\\"{x:1536,y:894,t:1526667506816};\\\", \\\"{x:1536,y:917,t:1526667506832};\\\", \\\"{x:1538,y:927,t:1526667506848};\\\", \\\"{x:1545,y:938,t:1526667506865};\\\", \\\"{x:1546,y:940,t:1526667506883};\\\", \\\"{x:1546,y:943,t:1526667506899};\\\", \\\"{x:1546,y:947,t:1526667506916};\\\", \\\"{x:1546,y:950,t:1526667506933};\\\", \\\"{x:1546,y:952,t:1526667506949};\\\", \\\"{x:1547,y:954,t:1526667507098};\\\", \\\"{x:1548,y:956,t:1526667507105};\\\", \\\"{x:1548,y:957,t:1526667507116};\\\", \\\"{x:1549,y:958,t:1526667507154};\\\", \\\"{x:1549,y:956,t:1526667507218};\\\", \\\"{x:1550,y:953,t:1526667507233};\\\", \\\"{x:1553,y:940,t:1526667507249};\\\", \\\"{x:1553,y:929,t:1526667507265};\\\", \\\"{x:1553,y:916,t:1526667507283};\\\", \\\"{x:1553,y:898,t:1526667507299};\\\", \\\"{x:1553,y:887,t:1526667507316};\\\", \\\"{x:1553,y:876,t:1526667507332};\\\", \\\"{x:1553,y:869,t:1526667507350};\\\", \\\"{x:1554,y:857,t:1526667507366};\\\", \\\"{x:1559,y:849,t:1526667507383};\\\", \\\"{x:1562,y:839,t:1526667507400};\\\", \\\"{x:1563,y:830,t:1526667507416};\\\", \\\"{x:1564,y:822,t:1526667507433};\\\", \\\"{x:1564,y:815,t:1526667507450};\\\", \\\"{x:1564,y:812,t:1526667507466};\\\", \\\"{x:1564,y:809,t:1526667507483};\\\", \\\"{x:1564,y:808,t:1526667507500};\\\", \\\"{x:1564,y:807,t:1526667507516};\\\", \\\"{x:1564,y:806,t:1526667507537};\\\", \\\"{x:1564,y:805,t:1526667507569};\\\", \\\"{x:1562,y:805,t:1526667507594};\\\", \\\"{x:1559,y:807,t:1526667507602};\\\", \\\"{x:1558,y:808,t:1526667507616};\\\", \\\"{x:1555,y:814,t:1526667507633};\\\", \\\"{x:1550,y:827,t:1526667507650};\\\", \\\"{x:1550,y:832,t:1526667507666};\\\", \\\"{x:1550,y:833,t:1526667507683};\\\", \\\"{x:1550,y:834,t:1526667507700};\\\", \\\"{x:1549,y:834,t:1526667507946};\\\", \\\"{x:1549,y:833,t:1526667507962};\\\", \\\"{x:1549,y:832,t:1526667507977};\\\", \\\"{x:1549,y:831,t:1526667508002};\\\", \\\"{x:1549,y:830,t:1526667508017};\\\", \\\"{x:1549,y:828,t:1526667508034};\\\", \\\"{x:1549,y:824,t:1526667508050};\\\", \\\"{x:1549,y:822,t:1526667508067};\\\", \\\"{x:1549,y:816,t:1526667508084};\\\", \\\"{x:1548,y:814,t:1526667508100};\\\", \\\"{x:1547,y:810,t:1526667508117};\\\", \\\"{x:1546,y:807,t:1526667508133};\\\", \\\"{x:1546,y:804,t:1526667508149};\\\", \\\"{x:1546,y:801,t:1526667508166};\\\", \\\"{x:1546,y:800,t:1526667508184};\\\", \\\"{x:1546,y:797,t:1526667508200};\\\", \\\"{x:1546,y:796,t:1526667508217};\\\", \\\"{x:1546,y:794,t:1526667508234};\\\", \\\"{x:1545,y:793,t:1526667508314};\\\", \\\"{x:1544,y:791,t:1526667508321};\\\", \\\"{x:1544,y:788,t:1526667508334};\\\", \\\"{x:1544,y:782,t:1526667508351};\\\", \\\"{x:1544,y:775,t:1526667508367};\\\", \\\"{x:1544,y:772,t:1526667508384};\\\", \\\"{x:1544,y:771,t:1526667508400};\\\", \\\"{x:1545,y:767,t:1526667508417};\\\", \\\"{x:1545,y:765,t:1526667508434};\\\", \\\"{x:1545,y:764,t:1526667508650};\\\", \\\"{x:1545,y:763,t:1526667508657};\\\", \\\"{x:1545,y:762,t:1526667508681};\\\", \\\"{x:1545,y:759,t:1526667509114};\\\", \\\"{x:1545,y:758,t:1526667509130};\\\", \\\"{x:1545,y:756,t:1526667509137};\\\", \\\"{x:1545,y:755,t:1526667509154};\\\", \\\"{x:1535,y:746,t:1526667517425};\\\", \\\"{x:1463,y:722,t:1526667517441};\\\", \\\"{x:1208,y:643,t:1526667517458};\\\", \\\"{x:1059,y:603,t:1526667517475};\\\", \\\"{x:923,y:578,t:1526667517492};\\\", \\\"{x:770,y:554,t:1526667517509};\\\", \\\"{x:631,y:547,t:1526667517525};\\\", \\\"{x:522,y:546,t:1526667517539};\\\", \\\"{x:470,y:549,t:1526667517555};\\\", \\\"{x:442,y:561,t:1526667517575};\\\", \\\"{x:417,y:577,t:1526667517591};\\\", \\\"{x:401,y:592,t:1526667517608};\\\", \\\"{x:394,y:598,t:1526667517624};\\\", \\\"{x:391,y:602,t:1526667517641};\\\", \\\"{x:391,y:609,t:1526667517658};\\\", \\\"{x:391,y:620,t:1526667517674};\\\", \\\"{x:397,y:643,t:1526667517692};\\\", \\\"{x:406,y:672,t:1526667517708};\\\", \\\"{x:424,y:706,t:1526667517724};\\\", \\\"{x:437,y:720,t:1526667517741};\\\", \\\"{x:452,y:737,t:1526667517758};\\\", \\\"{x:468,y:746,t:1526667517774};\\\", \\\"{x:472,y:750,t:1526667517791};\\\", \\\"{x:473,y:751,t:1526667517808};\\\", \\\"{x:474,y:751,t:1526667517874};\\\", \\\"{x:476,y:744,t:1526667517891};\\\", \\\"{x:478,y:735,t:1526667517908};\\\", \\\"{x:481,y:731,t:1526667517924};\\\", \\\"{x:481,y:730,t:1526667517942};\\\", \\\"{x:481,y:729,t:1526667517958};\\\" ] }, { \\\"rt\\\": 44180, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 673668, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"HWJDK\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"men\\\", \\\"condition\\\": \\\"113\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"diagonal\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-M -02 PM-01 PM-02 PM-02 PM-03 PM-02 PM-03 PM-02:30\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:483,y:729,t:1526667520386};\\\", \\\"{x:488,y:729,t:1526667520393};\\\", \\\"{x:506,y:729,t:1526667520410};\\\", \\\"{x:519,y:729,t:1526667520426};\\\", \\\"{x:533,y:731,t:1526667520443};\\\", \\\"{x:555,y:731,t:1526667520461};\\\", \\\"{x:574,y:731,t:1526667520476};\\\", \\\"{x:586,y:731,t:1526667520494};\\\", \\\"{x:597,y:731,t:1526667520510};\\\", \\\"{x:606,y:731,t:1526667520526};\\\", \\\"{x:610,y:731,t:1526667520543};\\\", \\\"{x:616,y:731,t:1526667520560};\\\", \\\"{x:623,y:731,t:1526667520577};\\\", \\\"{x:628,y:731,t:1526667520594};\\\", \\\"{x:632,y:731,t:1526667520610};\\\", \\\"{x:636,y:731,t:1526667520627};\\\", \\\"{x:642,y:731,t:1526667520643};\\\", \\\"{x:643,y:732,t:1526667520660};\\\", \\\"{x:647,y:733,t:1526667520678};\\\", \\\"{x:649,y:735,t:1526667520697};\\\", \\\"{x:652,y:735,t:1526667520710};\\\", \\\"{x:658,y:735,t:1526667520727};\\\", \\\"{x:660,y:735,t:1526667520743};\\\", \\\"{x:662,y:735,t:1526667520761};\\\", \\\"{x:663,y:735,t:1526667520777};\\\", \\\"{x:664,y:735,t:1526667520793};\\\", \\\"{x:669,y:735,t:1526667525410};\\\", \\\"{x:686,y:735,t:1526667525417};\\\", \\\"{x:701,y:736,t:1526667525431};\\\", \\\"{x:765,y:747,t:1526667525447};\\\", \\\"{x:854,y:761,t:1526667525465};\\\", \\\"{x:973,y:781,t:1526667525480};\\\", \\\"{x:1127,y:803,t:1526667525498};\\\", \\\"{x:1241,y:836,t:1526667525515};\\\", \\\"{x:1331,y:867,t:1526667525531};\\\", \\\"{x:1378,y:889,t:1526667525547};\\\", \\\"{x:1405,y:909,t:1526667525565};\\\", \\\"{x:1424,y:931,t:1526667525581};\\\", \\\"{x:1443,y:951,t:1526667525598};\\\", \\\"{x:1451,y:959,t:1526667525614};\\\", \\\"{x:1458,y:966,t:1526667525630};\\\", \\\"{x:1466,y:972,t:1526667525648};\\\", \\\"{x:1471,y:977,t:1526667525665};\\\", \\\"{x:1472,y:978,t:1526667525680};\\\", \\\"{x:1472,y:979,t:1526667525697};\\\", \\\"{x:1470,y:979,t:1526667525737};\\\", \\\"{x:1469,y:979,t:1526667525747};\\\", \\\"{x:1467,y:979,t:1526667525764};\\\", \\\"{x:1467,y:981,t:1526667525781};\\\", \\\"{x:1467,y:982,t:1526667525797};\\\", \\\"{x:1465,y:982,t:1526667525818};\\\", \\\"{x:1463,y:982,t:1526667525834};\\\", \\\"{x:1460,y:982,t:1526667525848};\\\", \\\"{x:1457,y:981,t:1526667525864};\\\", \\\"{x:1445,y:977,t:1526667525881};\\\", \\\"{x:1438,y:978,t:1526667525897};\\\", \\\"{x:1436,y:979,t:1526667525914};\\\", \\\"{x:1435,y:980,t:1526667526002};\\\", \\\"{x:1435,y:982,t:1526667526014};\\\", \\\"{x:1435,y:984,t:1526667526031};\\\", \\\"{x:1436,y:987,t:1526667526048};\\\", \\\"{x:1442,y:991,t:1526667526064};\\\", \\\"{x:1450,y:995,t:1526667526081};\\\", \\\"{x:1459,y:996,t:1526667526097};\\\", \\\"{x:1468,y:996,t:1526667526114};\\\", \\\"{x:1477,y:991,t:1526667526132};\\\", \\\"{x:1483,y:989,t:1526667526147};\\\", \\\"{x:1487,y:986,t:1526667526164};\\\", \\\"{x:1489,y:985,t:1526667526181};\\\", \\\"{x:1490,y:984,t:1526667526198};\\\", \\\"{x:1491,y:984,t:1526667526214};\\\", \\\"{x:1492,y:983,t:1526667526231};\\\", \\\"{x:1493,y:981,t:1526667526248};\\\", \\\"{x:1495,y:979,t:1526667526265};\\\", \\\"{x:1496,y:979,t:1526667526282};\\\", \\\"{x:1496,y:977,t:1526667526321};\\\", \\\"{x:1496,y:976,t:1526667526331};\\\", \\\"{x:1493,y:974,t:1526667526348};\\\", \\\"{x:1490,y:973,t:1526667526364};\\\", \\\"{x:1486,y:970,t:1526667526381};\\\", \\\"{x:1485,y:970,t:1526667526398};\\\", \\\"{x:1484,y:970,t:1526667526514};\\\", \\\"{x:1483,y:969,t:1526667526770};\\\", \\\"{x:1481,y:967,t:1526667526994};\\\", \\\"{x:1469,y:966,t:1526667537673};\\\", \\\"{x:1371,y:960,t:1526667537690};\\\", \\\"{x:1179,y:946,t:1526667537707};\\\", \\\"{x:952,y:941,t:1526667537724};\\\", \\\"{x:712,y:921,t:1526667537741};\\\", \\\"{x:512,y:879,t:1526667537757};\\\", \\\"{x:362,y:853,t:1526667537774};\\\", \\\"{x:248,y:835,t:1526667537791};\\\", \\\"{x:200,y:825,t:1526667537807};\\\", \\\"{x:187,y:820,t:1526667537824};\\\", \\\"{x:183,y:815,t:1526667537841};\\\", \\\"{x:183,y:814,t:1526667537857};\\\", \\\"{x:184,y:809,t:1526667537874};\\\", \\\"{x:184,y:807,t:1526667537891};\\\", \\\"{x:184,y:804,t:1526667537907};\\\", \\\"{x:184,y:797,t:1526667537924};\\\", \\\"{x:190,y:780,t:1526667537941};\\\", \\\"{x:210,y:757,t:1526667537957};\\\", \\\"{x:246,y:720,t:1526667537974};\\\", \\\"{x:301,y:661,t:1526667537991};\\\", \\\"{x:382,y:604,t:1526667538008};\\\", \\\"{x:479,y:557,t:1526667538024};\\\", \\\"{x:640,y:487,t:1526667538041};\\\", \\\"{x:714,y:445,t:1526667538058};\\\", \\\"{x:757,y:429,t:1526667538074};\\\", \\\"{x:774,y:425,t:1526667538091};\\\", \\\"{x:780,y:424,t:1526667538108};\\\", \\\"{x:782,y:424,t:1526667538124};\\\", \\\"{x:784,y:424,t:1526667538141};\\\", \\\"{x:786,y:422,t:1526667538158};\\\", \\\"{x:790,y:416,t:1526667538174};\\\", \\\"{x:793,y:412,t:1526667538191};\\\", \\\"{x:793,y:410,t:1526667538208};\\\", \\\"{x:786,y:406,t:1526667538225};\\\", \\\"{x:772,y:405,t:1526667538241};\\\", \\\"{x:757,y:409,t:1526667538258};\\\", \\\"{x:740,y:417,t:1526667538275};\\\", \\\"{x:718,y:429,t:1526667538291};\\\", \\\"{x:702,y:446,t:1526667538308};\\\", \\\"{x:685,y:465,t:1526667538324};\\\", \\\"{x:670,y:484,t:1526667538341};\\\", \\\"{x:656,y:500,t:1526667538358};\\\", \\\"{x:647,y:511,t:1526667538375};\\\", \\\"{x:644,y:514,t:1526667538391};\\\", \\\"{x:643,y:514,t:1526667538408};\\\", \\\"{x:642,y:516,t:1526667538466};\\\", \\\"{x:641,y:517,t:1526667538481};\\\", \\\"{x:640,y:517,t:1526667538491};\\\", \\\"{x:639,y:517,t:1526667538508};\\\", \\\"{x:638,y:517,t:1526667538537};\\\", \\\"{x:637,y:517,t:1526667538561};\\\", \\\"{x:636,y:517,t:1526667538577};\\\", \\\"{x:635,y:517,t:1526667538689};\\\", \\\"{x:633,y:517,t:1526667538697};\\\", \\\"{x:630,y:517,t:1526667538708};\\\", \\\"{x:627,y:517,t:1526667538725};\\\", \\\"{x:626,y:517,t:1526667538742};\\\", \\\"{x:624,y:517,t:1526667538817};\\\", \\\"{x:622,y:517,t:1526667538825};\\\", \\\"{x:619,y:517,t:1526667538842};\\\", \\\"{x:614,y:517,t:1526667538858};\\\", \\\"{x:612,y:516,t:1526667538875};\\\", \\\"{x:614,y:516,t:1526667539042};\\\", \\\"{x:633,y:529,t:1526667539058};\\\", \\\"{x:683,y:551,t:1526667539075};\\\", \\\"{x:807,y:583,t:1526667539092};\\\", \\\"{x:986,y:630,t:1526667539110};\\\", \\\"{x:1171,y:685,t:1526667539125};\\\", \\\"{x:1361,y:764,t:1526667539142};\\\", \\\"{x:1522,y:813,t:1526667539159};\\\", \\\"{x:1653,y:860,t:1526667539175};\\\", \\\"{x:1757,y:884,t:1526667539192};\\\", \\\"{x:1803,y:905,t:1526667539209};\\\", \\\"{x:1807,y:911,t:1526667539225};\\\", \\\"{x:1807,y:915,t:1526667539242};\\\", \\\"{x:1806,y:928,t:1526667539258};\\\", \\\"{x:1795,y:938,t:1526667539275};\\\", \\\"{x:1784,y:946,t:1526667539292};\\\", \\\"{x:1777,y:951,t:1526667539308};\\\", \\\"{x:1772,y:951,t:1526667539325};\\\", \\\"{x:1761,y:955,t:1526667539342};\\\", \\\"{x:1748,y:960,t:1526667539359};\\\", \\\"{x:1722,y:965,t:1526667539375};\\\", \\\"{x:1657,y:966,t:1526667539392};\\\", \\\"{x:1593,y:968,t:1526667539409};\\\", \\\"{x:1540,y:967,t:1526667539425};\\\", \\\"{x:1520,y:965,t:1526667539441};\\\", \\\"{x:1503,y:965,t:1526667539458};\\\", \\\"{x:1499,y:966,t:1526667539475};\\\", \\\"{x:1497,y:966,t:1526667539492};\\\", \\\"{x:1497,y:967,t:1526667539569};\\\", \\\"{x:1502,y:967,t:1526667539577};\\\", \\\"{x:1511,y:969,t:1526667539592};\\\", \\\"{x:1541,y:969,t:1526667539608};\\\", \\\"{x:1580,y:970,t:1526667539625};\\\", \\\"{x:1599,y:971,t:1526667539641};\\\", \\\"{x:1608,y:971,t:1526667539659};\\\", \\\"{x:1607,y:971,t:1526667539809};\\\", \\\"{x:1599,y:972,t:1526667539825};\\\", \\\"{x:1584,y:972,t:1526667539841};\\\", \\\"{x:1572,y:975,t:1526667539857};\\\", \\\"{x:1565,y:975,t:1526667539875};\\\", \\\"{x:1558,y:975,t:1526667539891};\\\", \\\"{x:1555,y:975,t:1526667539908};\\\", \\\"{x:1554,y:975,t:1526667539925};\\\", \\\"{x:1553,y:975,t:1526667540017};\\\", \\\"{x:1552,y:975,t:1526667540025};\\\", \\\"{x:1551,y:975,t:1526667540041};\\\", \\\"{x:1548,y:975,t:1526667540058};\\\", \\\"{x:1545,y:974,t:1526667540074};\\\", \\\"{x:1542,y:974,t:1526667540091};\\\", \\\"{x:1535,y:971,t:1526667540108};\\\", \\\"{x:1532,y:970,t:1526667540124};\\\", \\\"{x:1526,y:970,t:1526667540141};\\\", \\\"{x:1517,y:971,t:1526667540158};\\\", \\\"{x:1511,y:973,t:1526667540174};\\\", \\\"{x:1504,y:978,t:1526667540191};\\\", \\\"{x:1497,y:980,t:1526667540208};\\\", \\\"{x:1493,y:981,t:1526667540225};\\\", \\\"{x:1490,y:981,t:1526667540241};\\\", \\\"{x:1486,y:984,t:1526667540258};\\\", \\\"{x:1483,y:984,t:1526667540274};\\\", \\\"{x:1480,y:985,t:1526667540291};\\\", \\\"{x:1479,y:985,t:1526667540308};\\\", \\\"{x:1480,y:986,t:1526667540385};\\\", \\\"{x:1483,y:986,t:1526667540392};\\\", \\\"{x:1488,y:986,t:1526667540407};\\\", \\\"{x:1504,y:986,t:1526667540424};\\\", \\\"{x:1521,y:986,t:1526667540441};\\\", \\\"{x:1532,y:987,t:1526667540457};\\\", \\\"{x:1547,y:988,t:1526667540474};\\\", \\\"{x:1549,y:991,t:1526667540491};\\\", \\\"{x:1553,y:991,t:1526667540507};\\\", \\\"{x:1554,y:991,t:1526667540524};\\\", \\\"{x:1556,y:991,t:1526667540729};\\\", \\\"{x:1559,y:991,t:1526667540745};\\\", \\\"{x:1561,y:991,t:1526667540756};\\\", \\\"{x:1564,y:991,t:1526667540774};\\\", \\\"{x:1566,y:991,t:1526667540791};\\\", \\\"{x:1568,y:991,t:1526667540807};\\\", \\\"{x:1570,y:991,t:1526667540824};\\\", \\\"{x:1573,y:990,t:1526667540841};\\\", \\\"{x:1575,y:990,t:1526667540857};\\\", \\\"{x:1577,y:989,t:1526667540874};\\\", \\\"{x:1580,y:987,t:1526667540890};\\\", \\\"{x:1580,y:986,t:1526667540907};\\\", \\\"{x:1583,y:986,t:1526667540924};\\\", \\\"{x:1584,y:985,t:1526667540941};\\\", \\\"{x:1585,y:984,t:1526667540957};\\\", \\\"{x:1587,y:983,t:1526667540974};\\\", \\\"{x:1590,y:981,t:1526667540991};\\\", \\\"{x:1592,y:979,t:1526667541007};\\\", \\\"{x:1595,y:975,t:1526667541024};\\\", \\\"{x:1597,y:972,t:1526667541040};\\\", \\\"{x:1598,y:970,t:1526667541057};\\\", \\\"{x:1598,y:968,t:1526667541122};\\\", \\\"{x:1598,y:967,t:1526667541145};\\\", \\\"{x:1598,y:966,t:1526667541161};\\\", \\\"{x:1591,y:963,t:1526667541174};\\\", \\\"{x:1573,y:963,t:1526667541190};\\\", \\\"{x:1558,y:964,t:1526667541207};\\\", \\\"{x:1546,y:965,t:1526667541223};\\\", \\\"{x:1535,y:969,t:1526667541240};\\\", \\\"{x:1525,y:970,t:1526667541257};\\\", \\\"{x:1524,y:970,t:1526667541353};\\\", \\\"{x:1521,y:970,t:1526667541361};\\\", \\\"{x:1516,y:969,t:1526667541466};\\\", \\\"{x:1515,y:968,t:1526667541472};\\\", \\\"{x:1510,y:968,t:1526667541490};\\\", \\\"{x:1506,y:968,t:1526667541507};\\\", \\\"{x:1501,y:968,t:1526667541523};\\\", \\\"{x:1499,y:968,t:1526667541540};\\\", \\\"{x:1498,y:967,t:1526667541617};\\\", \\\"{x:1496,y:967,t:1526667541625};\\\", \\\"{x:1494,y:967,t:1526667541857};\\\", \\\"{x:1492,y:965,t:1526667541873};\\\", \\\"{x:1489,y:965,t:1526667541889};\\\", \\\"{x:1487,y:964,t:1526667541906};\\\", \\\"{x:1485,y:963,t:1526667542049};\\\", \\\"{x:1484,y:963,t:1526667542065};\\\", \\\"{x:1481,y:963,t:1526667542082};\\\", \\\"{x:1479,y:962,t:1526667542090};\\\", \\\"{x:1478,y:962,t:1526667542249};\\\", \\\"{x:1474,y:961,t:1526667542474};\\\", \\\"{x:1470,y:959,t:1526667542489};\\\", \\\"{x:1438,y:933,t:1526667550545};\\\", \\\"{x:1344,y:870,t:1526667550552};\\\", \\\"{x:1282,y:821,t:1526667550565};\\\", \\\"{x:1158,y:738,t:1526667550581};\\\", \\\"{x:1076,y:689,t:1526667550598};\\\", \\\"{x:992,y:632,t:1526667550615};\\\", \\\"{x:929,y:590,t:1526667550632};\\\", \\\"{x:893,y:557,t:1526667550648};\\\", \\\"{x:886,y:543,t:1526667550664};\\\", \\\"{x:883,y:537,t:1526667550679};\\\", \\\"{x:880,y:528,t:1526667550696};\\\", \\\"{x:876,y:521,t:1526667550712};\\\", \\\"{x:872,y:516,t:1526667550733};\\\", \\\"{x:861,y:509,t:1526667550750};\\\", \\\"{x:847,y:498,t:1526667550767};\\\", \\\"{x:828,y:495,t:1526667550783};\\\", \\\"{x:812,y:497,t:1526667550799};\\\", \\\"{x:800,y:513,t:1526667550816};\\\", \\\"{x:791,y:534,t:1526667550833};\\\", \\\"{x:787,y:551,t:1526667550850};\\\", \\\"{x:787,y:560,t:1526667550867};\\\", \\\"{x:794,y:566,t:1526667550883};\\\", \\\"{x:801,y:570,t:1526667550900};\\\", \\\"{x:815,y:572,t:1526667550917};\\\", \\\"{x:825,y:574,t:1526667550933};\\\", \\\"{x:829,y:574,t:1526667550950};\\\", \\\"{x:830,y:574,t:1526667550967};\\\", \\\"{x:832,y:573,t:1526667550991};\\\", \\\"{x:834,y:571,t:1526667550999};\\\", \\\"{x:838,y:565,t:1526667551016};\\\", \\\"{x:840,y:560,t:1526667551034};\\\", \\\"{x:843,y:557,t:1526667551049};\\\", \\\"{x:843,y:554,t:1526667551067};\\\", \\\"{x:844,y:551,t:1526667551083};\\\", \\\"{x:844,y:550,t:1526667551099};\\\", \\\"{x:844,y:547,t:1526667551117};\\\", \\\"{x:846,y:544,t:1526667551134};\\\", \\\"{x:846,y:541,t:1526667551151};\\\", \\\"{x:848,y:535,t:1526667551167};\\\", \\\"{x:848,y:531,t:1526667551184};\\\", \\\"{x:848,y:530,t:1526667551200};\\\", \\\"{x:848,y:528,t:1526667551216};\\\", \\\"{x:848,y:527,t:1526667551295};\\\", \\\"{x:848,y:526,t:1526667551302};\\\", \\\"{x:848,y:525,t:1526667551319};\\\", \\\"{x:847,y:524,t:1526667551334};\\\", \\\"{x:846,y:523,t:1526667551349};\\\", \\\"{x:847,y:523,t:1526667551543};\\\", \\\"{x:854,y:528,t:1526667551551};\\\", \\\"{x:864,y:536,t:1526667551567};\\\", \\\"{x:950,y:593,t:1526667551583};\\\", \\\"{x:1025,y:645,t:1526667551600};\\\", \\\"{x:1153,y:714,t:1526667551616};\\\", \\\"{x:1287,y:789,t:1526667551634};\\\", \\\"{x:1406,y:846,t:1526667551651};\\\", \\\"{x:1491,y:893,t:1526667551667};\\\", \\\"{x:1543,y:927,t:1526667551684};\\\", \\\"{x:1567,y:947,t:1526667551700};\\\", \\\"{x:1577,y:956,t:1526667551716};\\\", \\\"{x:1583,y:967,t:1526667551733};\\\", \\\"{x:1584,y:970,t:1526667551750};\\\", \\\"{x:1586,y:973,t:1526667551767};\\\", \\\"{x:1583,y:973,t:1526667551840};\\\", \\\"{x:1579,y:974,t:1526667551851};\\\", \\\"{x:1561,y:977,t:1526667551867};\\\", \\\"{x:1533,y:977,t:1526667551884};\\\", \\\"{x:1522,y:977,t:1526667551901};\\\", \\\"{x:1511,y:977,t:1526667551918};\\\", \\\"{x:1502,y:975,t:1526667551934};\\\", \\\"{x:1501,y:974,t:1526667552023};\\\", \\\"{x:1501,y:972,t:1526667552063};\\\", \\\"{x:1501,y:971,t:1526667552071};\\\", \\\"{x:1501,y:970,t:1526667552083};\\\", \\\"{x:1501,y:969,t:1526667552100};\\\", \\\"{x:1501,y:966,t:1526667552118};\\\", \\\"{x:1502,y:965,t:1526667552133};\\\", \\\"{x:1502,y:963,t:1526667552150};\\\", \\\"{x:1499,y:961,t:1526667552167};\\\", \\\"{x:1497,y:961,t:1526667552184};\\\", \\\"{x:1495,y:961,t:1526667552201};\\\", \\\"{x:1494,y:961,t:1526667552218};\\\", \\\"{x:1493,y:961,t:1526667552319};\\\", \\\"{x:1492,y:961,t:1526667552335};\\\", \\\"{x:1491,y:961,t:1526667552350};\\\", \\\"{x:1488,y:961,t:1526667552367};\\\", \\\"{x:1487,y:961,t:1526667552385};\\\", \\\"{x:1486,y:961,t:1526667552535};\\\", \\\"{x:1485,y:961,t:1526667552550};\\\", \\\"{x:1483,y:961,t:1526667552567};\\\", \\\"{x:1481,y:961,t:1526667552584};\\\", \\\"{x:1480,y:961,t:1526667552600};\\\", \\\"{x:1479,y:961,t:1526667552618};\\\", \\\"{x:1477,y:961,t:1526667552679};\\\", \\\"{x:1475,y:961,t:1526667562103};\\\", \\\"{x:1452,y:956,t:1526667562111};\\\", \\\"{x:1391,y:919,t:1526667562124};\\\", \\\"{x:1188,y:832,t:1526667562142};\\\", \\\"{x:807,y:685,t:1526667562159};\\\", \\\"{x:625,y:633,t:1526667562176};\\\", \\\"{x:515,y:619,t:1526667562192};\\\", \\\"{x:467,y:605,t:1526667562209};\\\", \\\"{x:447,y:594,t:1526667562226};\\\", \\\"{x:435,y:590,t:1526667562242};\\\", \\\"{x:428,y:589,t:1526667562259};\\\", \\\"{x:419,y:596,t:1526667562276};\\\", \\\"{x:410,y:612,t:1526667562293};\\\", \\\"{x:400,y:645,t:1526667562309};\\\", \\\"{x:395,y:669,t:1526667562326};\\\", \\\"{x:394,y:676,t:1526667562342};\\\", \\\"{x:394,y:680,t:1526667562375};\\\", \\\"{x:402,y:702,t:1526667562393};\\\", \\\"{x:421,y:729,t:1526667562409};\\\", \\\"{x:440,y:757,t:1526667562426};\\\", \\\"{x:452,y:771,t:1526667562442};\\\", \\\"{x:461,y:780,t:1526667562458};\\\", \\\"{x:473,y:791,t:1526667562476};\\\", \\\"{x:494,y:809,t:1526667562493};\\\", \\\"{x:542,y:840,t:1526667562509};\\\", \\\"{x:579,y:858,t:1526667562526};\\\", \\\"{x:589,y:860,t:1526667562543};\\\", \\\"{x:591,y:855,t:1526667562590};\\\", \\\"{x:591,y:849,t:1526667562598};\\\", \\\"{x:591,y:835,t:1526667562609};\\\", \\\"{x:591,y:811,t:1526667562626};\\\", \\\"{x:589,y:787,t:1526667562643};\\\", \\\"{x:583,y:766,t:1526667562659};\\\", \\\"{x:578,y:750,t:1526667562676};\\\", \\\"{x:564,y:731,t:1526667562693};\\\", \\\"{x:556,y:720,t:1526667562709};\\\", \\\"{x:548,y:715,t:1526667562726};\\\", \\\"{x:546,y:713,t:1526667562743};\\\", \\\"{x:545,y:713,t:1526667562823};\\\", \\\"{x:545,y:717,t:1526667562831};\\\", \\\"{x:545,y:723,t:1526667562842};\\\", \\\"{x:543,y:737,t:1526667562860};\\\", \\\"{x:539,y:752,t:1526667562876};\\\", \\\"{x:534,y:764,t:1526667562893};\\\", \\\"{x:532,y:768,t:1526667562908};\\\", \\\"{x:531,y:769,t:1526667562926};\\\", \\\"{x:531,y:768,t:1526667563312};\\\", \\\"{x:531,y:764,t:1526667563327};\\\", \\\"{x:531,y:762,t:1526667563343};\\\", \\\"{x:531,y:761,t:1526667563361};\\\", \\\"{x:531,y:758,t:1526667563376};\\\", \\\"{x:532,y:757,t:1526667563393};\\\", \\\"{x:533,y:753,t:1526667563410};\\\", \\\"{x:535,y:748,t:1526667563427};\\\", \\\"{x:536,y:743,t:1526667563443};\\\", \\\"{x:537,y:742,t:1526667563463};\\\", \\\"{x:539,y:742,t:1526667565151};\\\", \\\"{x:543,y:742,t:1526667565160};\\\", \\\"{x:562,y:735,t:1526667565178};\\\", \\\"{x:590,y:730,t:1526667565195};\\\", \\\"{x:616,y:721,t:1526667565211};\\\", \\\"{x:670,y:702,t:1526667565227};\\\", \\\"{x:742,y:684,t:1526667565244};\\\", \\\"{x:798,y:666,t:1526667565261};\\\", \\\"{x:841,y:646,t:1526667565277};\\\", \\\"{x:858,y:635,t:1526667565294};\\\", \\\"{x:878,y:625,t:1526667565311};\\\", \\\"{x:879,y:624,t:1526667565327};\\\", \\\"{x:880,y:623,t:1526667565439};\\\", \\\"{x:881,y:622,t:1526667565463};\\\", \\\"{x:882,y:619,t:1526667565477};\\\", \\\"{x:886,y:611,t:1526667565494};\\\", \\\"{x:890,y:601,t:1526667565511};\\\", \\\"{x:893,y:596,t:1526667565527};\\\", \\\"{x:895,y:592,t:1526667565543};\\\", \\\"{x:896,y:589,t:1526667565561};\\\", \\\"{x:898,y:585,t:1526667565576};\\\", \\\"{x:899,y:579,t:1526667565594};\\\", \\\"{x:900,y:576,t:1526667565611};\\\", \\\"{x:902,y:573,t:1526667565627};\\\", \\\"{x:902,y:572,t:1526667565719};\\\", \\\"{x:903,y:571,t:1526667565727};\\\", \\\"{x:905,y:565,t:1526667565745};\\\", \\\"{x:907,y:562,t:1526667565762};\\\", \\\"{x:908,y:560,t:1526667565778};\\\", \\\"{x:910,y:560,t:1526667565991};\\\", \\\"{x:912,y:560,t:1526667565999};\\\", \\\"{x:913,y:560,t:1526667566014};\\\", \\\"{x:914,y:560,t:1526667566029};\\\", \\\"{x:916,y:568,t:1526667567327};\\\", \\\"{x:916,y:574,t:1526667567335};\\\", \\\"{x:918,y:582,t:1526667567346};\\\", \\\"{x:920,y:600,t:1526667567363};\\\", \\\"{x:922,y:612,t:1526667567380};\\\", \\\"{x:922,y:623,t:1526667567396};\\\", \\\"{x:922,y:630,t:1526667567413};\\\", \\\"{x:922,y:635,t:1526667567430};\\\", \\\"{x:920,y:646,t:1526667567446};\\\", \\\"{x:916,y:674,t:1526667567463};\\\", \\\"{x:911,y:693,t:1526667567480};\\\", \\\"{x:907,y:698,t:1526667567497};\\\", \\\"{x:907,y:699,t:1526667567599};\\\", \\\"{x:908,y:699,t:1526667567613};\\\", \\\"{x:909,y:694,t:1526667567630};\\\", \\\"{x:910,y:684,t:1526667567646};\\\", \\\"{x:912,y:669,t:1526667567663};\\\", \\\"{x:913,y:667,t:1526667567680};\\\", \\\"{x:913,y:665,t:1526667567697};\\\", \\\"{x:914,y:663,t:1526667567735};\\\", \\\"{x:915,y:662,t:1526667567747};\\\", \\\"{x:915,y:659,t:1526667567763};\\\", \\\"{x:915,y:658,t:1526667567780};\\\", \\\"{x:916,y:655,t:1526667567797};\\\", \\\"{x:916,y:654,t:1526667567813};\\\", \\\"{x:916,y:653,t:1526667567830};\\\", \\\"{x:919,y:660,t:1526667582767};\\\", \\\"{x:936,y:688,t:1526667582777};\\\", \\\"{x:955,y:716,t:1526667582793};\\\", \\\"{x:966,y:731,t:1526667582809};\\\", \\\"{x:975,y:738,t:1526667582826};\\\", \\\"{x:977,y:738,t:1526667582846};\\\", \\\"{x:978,y:738,t:1526667582858};\\\", \\\"{x:979,y:738,t:1526667582876};\\\", \\\"{x:979,y:736,t:1526667582919};\\\", \\\"{x:979,y:733,t:1526667582926};\\\", \\\"{x:979,y:725,t:1526667582942};\\\", \\\"{x:979,y:712,t:1526667582959};\\\", \\\"{x:979,y:700,t:1526667582976};\\\", \\\"{x:977,y:684,t:1526667582993};\\\", \\\"{x:974,y:675,t:1526667583010};\\\", \\\"{x:974,y:674,t:1526667583026};\\\", \\\"{x:973,y:672,t:1526667583043};\\\", \\\"{x:972,y:672,t:1526667583184};\\\", \\\"{x:972,y:676,t:1526667583194};\\\", \\\"{x:970,y:682,t:1526667583209};\\\", \\\"{x:970,y:685,t:1526667583225};\\\", \\\"{x:970,y:687,t:1526667583246};\\\", \\\"{x:969,y:687,t:1526667583262};\\\", \\\"{x:969,y:688,t:1526667585839};\\\", \\\"{x:979,y:677,t:1526667585847};\\\", \\\"{x:994,y:648,t:1526667585863};\\\", \\\"{x:1027,y:590,t:1526667585878};\\\", \\\"{x:1067,y:527,t:1526667585895};\\\", \\\"{x:1080,y:512,t:1526667585913};\\\", \\\"{x:1097,y:483,t:1526667585928};\\\", \\\"{x:1108,y:458,t:1526667585945};\\\", \\\"{x:1115,y:437,t:1526667585963};\\\", \\\"{x:1115,y:414,t:1526667585979};\\\", \\\"{x:1112,y:391,t:1526667585995};\\\", \\\"{x:1100,y:365,t:1526667586012};\\\", \\\"{x:1088,y:345,t:1526667586029};\\\", \\\"{x:1072,y:329,t:1526667586046};\\\", \\\"{x:1055,y:313,t:1526667586062};\\\", \\\"{x:1040,y:300,t:1526667586079};\\\", \\\"{x:1025,y:284,t:1526667586095};\\\", \\\"{x:1012,y:273,t:1526667586112};\\\", \\\"{x:998,y:264,t:1526667586129};\\\", \\\"{x:977,y:254,t:1526667586145};\\\", \\\"{x:961,y:247,t:1526667586163};\\\", \\\"{x:941,y:243,t:1526667586179};\\\", \\\"{x:927,y:236,t:1526667586195};\\\", \\\"{x:918,y:234,t:1526667586212};\\\", \\\"{x:908,y:233,t:1526667586229};\\\", \\\"{x:903,y:232,t:1526667586245};\\\", \\\"{x:901,y:232,t:1526667586320};\\\", \\\"{x:900,y:232,t:1526667586329};\\\", \\\"{x:895,y:233,t:1526667586344};\\\", \\\"{x:894,y:233,t:1526667586367};\\\", \\\"{x:889,y:234,t:1526667586377};\\\", \\\"{x:879,y:235,t:1526667586394};\\\", \\\"{x:869,y:236,t:1526667586411};\\\", \\\"{x:861,y:236,t:1526667586427};\\\", \\\"{x:855,y:237,t:1526667586444};\\\", \\\"{x:850,y:237,t:1526667586462};\\\", \\\"{x:846,y:237,t:1526667586478};\\\", \\\"{x:844,y:237,t:1526667586494};\\\", \\\"{x:842,y:237,t:1526667586696};\\\", \\\"{x:840,y:237,t:1526667586711};\\\", \\\"{x:838,y:237,t:1526667586777};\\\", \\\"{x:837,y:237,t:1526667586799};\\\", \\\"{x:836,y:237,t:1526667586823};\\\", \\\"{x:835,y:237,t:1526667586839};\\\", \\\"{x:833,y:238,t:1526667587592};\\\", \\\"{x:833,y:239,t:1526667587599};\\\", \\\"{x:833,y:241,t:1526667587613};\\\", \\\"{x:833,y:246,t:1526667587631};\\\", \\\"{x:833,y:249,t:1526667587647};\\\", \\\"{x:833,y:251,t:1526667587663};\\\", \\\"{x:833,y:252,t:1526667587695};\\\", \\\"{x:834,y:252,t:1526667587736};\\\", \\\"{x:835,y:253,t:1526667587747};\\\", \\\"{x:836,y:254,t:1526667587764};\\\", \\\"{x:841,y:260,t:1526667587781};\\\", \\\"{x:845,y:266,t:1526667587796};\\\", \\\"{x:849,y:274,t:1526667587813};\\\", \\\"{x:859,y:288,t:1526667587830};\\\", \\\"{x:871,y:302,t:1526667587847};\\\", \\\"{x:879,y:307,t:1526667587863};\\\", \\\"{x:888,y:315,t:1526667587880};\\\", \\\"{x:893,y:321,t:1526667587897};\\\", \\\"{x:897,y:325,t:1526667587913};\\\", \\\"{x:900,y:326,t:1526667587930};\\\", \\\"{x:901,y:329,t:1526667587947};\\\", \\\"{x:901,y:331,t:1526667587963};\\\", \\\"{x:905,y:340,t:1526667587980};\\\", \\\"{x:909,y:354,t:1526667587997};\\\", \\\"{x:910,y:368,t:1526667588013};\\\", \\\"{x:913,y:381,t:1526667588030};\\\", \\\"{x:913,y:385,t:1526667588047};\\\", \\\"{x:913,y:386,t:1526667588063};\\\", \\\"{x:913,y:387,t:1526667588080};\\\", \\\"{x:913,y:388,t:1526667588098};\\\", \\\"{x:913,y:389,t:1526667588114};\\\", \\\"{x:911,y:390,t:1526667588130};\\\", \\\"{x:903,y:391,t:1526667588147};\\\", \\\"{x:891,y:395,t:1526667588163};\\\", \\\"{x:876,y:400,t:1526667588180};\\\", \\\"{x:858,y:406,t:1526667588198};\\\", \\\"{x:842,y:412,t:1526667588214};\\\", \\\"{x:830,y:417,t:1526667588230};\\\", \\\"{x:816,y:427,t:1526667588248};\\\", \\\"{x:810,y:434,t:1526667588264};\\\", \\\"{x:808,y:438,t:1526667588281};\\\", \\\"{x:806,y:442,t:1526667588297};\\\", \\\"{x:806,y:446,t:1526667588314};\\\", \\\"{x:806,y:449,t:1526667588330};\\\", \\\"{x:806,y:453,t:1526667588347};\\\", \\\"{x:806,y:456,t:1526667588364};\\\", \\\"{x:806,y:460,t:1526667588380};\\\", \\\"{x:807,y:463,t:1526667588398};\\\", \\\"{x:807,y:466,t:1526667588415};\\\", \\\"{x:809,y:467,t:1526667588431};\\\", \\\"{x:809,y:468,t:1526667588447};\\\", \\\"{x:810,y:469,t:1526667588465};\\\", \\\"{x:816,y:470,t:1526667588481};\\\", \\\"{x:824,y:470,t:1526667588498};\\\", \\\"{x:833,y:470,t:1526667588517};\\\", \\\"{x:837,y:469,t:1526667588530};\\\", \\\"{x:839,y:468,t:1526667588547};\\\", \\\"{x:840,y:467,t:1526667588565};\\\", \\\"{x:841,y:466,t:1526667588583};\\\", \\\"{x:841,y:463,t:1526667588615};\\\", \\\"{x:841,y:462,t:1526667588631};\\\", \\\"{x:841,y:460,t:1526667588647};\\\", \\\"{x:844,y:455,t:1526667588665};\\\", \\\"{x:844,y:453,t:1526667588680};\\\", \\\"{x:844,y:452,t:1526667588698};\\\", \\\"{x:844,y:450,t:1526667588719};\\\", \\\"{x:844,y:449,t:1526667588735};\\\", \\\"{x:844,y:447,t:1526667588815};\\\", \\\"{x:844,y:446,t:1526667588904};\\\", \\\"{x:844,y:444,t:1526667588943};\\\", \\\"{x:844,y:443,t:1526667588992};\\\", \\\"{x:844,y:442,t:1526667589024};\\\", \\\"{x:842,y:442,t:1526667589031};\\\", \\\"{x:840,y:441,t:1526667589048};\\\", \\\"{x:838,y:439,t:1526667589065};\\\", \\\"{x:830,y:439,t:1526667589081};\\\", \\\"{x:826,y:437,t:1526667589098};\\\", \\\"{x:824,y:436,t:1526667589116};\\\", \\\"{x:825,y:436,t:1526667589248};\\\", \\\"{x:827,y:436,t:1526667589265};\\\", \\\"{x:828,y:437,t:1526667589281};\\\", \\\"{x:831,y:437,t:1526667589299};\\\", \\\"{x:831,y:437,t:1526667589555};\\\", \\\"{x:832,y:439,t:1526667589879};\\\", \\\"{x:832,y:448,t:1526667589887};\\\", \\\"{x:834,y:456,t:1526667589900};\\\", \\\"{x:839,y:486,t:1526667589916};\\\", \\\"{x:845,y:523,t:1526667589932};\\\", \\\"{x:863,y:557,t:1526667589949};\\\", \\\"{x:886,y:587,t:1526667589965};\\\", \\\"{x:908,y:604,t:1526667589982};\\\", \\\"{x:929,y:623,t:1526667589998};\\\", \\\"{x:946,y:648,t:1526667590015};\\\", \\\"{x:949,y:654,t:1526667590032};\\\", \\\"{x:949,y:659,t:1526667590048};\\\", \\\"{x:949,y:662,t:1526667590065};\\\", \\\"{x:949,y:667,t:1526667590081};\\\", \\\"{x:939,y:671,t:1526667590098};\\\", \\\"{x:926,y:676,t:1526667590115};\\\", \\\"{x:912,y:683,t:1526667590132};\\\", \\\"{x:892,y:690,t:1526667590148};\\\", \\\"{x:883,y:693,t:1526667590166};\\\", \\\"{x:867,y:694,t:1526667590182};\\\", \\\"{x:849,y:697,t:1526667590198};\\\", \\\"{x:845,y:702,t:1526667590216};\\\", \\\"{x:840,y:709,t:1526667590232};\\\", \\\"{x:839,y:714,t:1526667590249};\\\", \\\"{x:839,y:718,t:1526667590266};\\\", \\\"{x:839,y:722,t:1526667590283};\\\", \\\"{x:839,y:725,t:1526667590299};\\\", \\\"{x:839,y:731,t:1526667590315};\\\", \\\"{x:839,y:736,t:1526667590332};\\\", \\\"{x:838,y:742,t:1526667590349};\\\", \\\"{x:838,y:747,t:1526667590366};\\\", \\\"{x:838,y:750,t:1526667590383};\\\", \\\"{x:838,y:759,t:1526667590400};\\\", \\\"{x:838,y:765,t:1526667590416};\\\", \\\"{x:838,y:769,t:1526667590432};\\\", \\\"{x:838,y:777,t:1526667590449};\\\", \\\"{x:838,y:781,t:1526667590466};\\\", \\\"{x:838,y:784,t:1526667590482};\\\", \\\"{x:838,y:786,t:1526667590502};\\\", \\\"{x:838,y:788,t:1526667590515};\\\", \\\"{x:838,y:790,t:1526667590532};\\\", \\\"{x:838,y:792,t:1526667590549};\\\", \\\"{x:838,y:797,t:1526667590565};\\\", \\\"{x:836,y:803,t:1526667590582};\\\", \\\"{x:836,y:804,t:1526667590606};\\\", \\\"{x:836,y:805,t:1526667590616};\\\", \\\"{x:835,y:810,t:1526667590634};\\\", \\\"{x:833,y:815,t:1526667590650};\\\", \\\"{x:831,y:819,t:1526667590665};\\\", \\\"{x:830,y:822,t:1526667590683};\\\", \\\"{x:830,y:826,t:1526667590699};\\\", \\\"{x:829,y:828,t:1526667590716};\\\", \\\"{x:828,y:830,t:1526667590733};\\\", \\\"{x:828,y:831,t:1526667590871};\\\", \\\"{x:830,y:831,t:1526667590882};\\\", \\\"{x:836,y:828,t:1526667590900};\\\", \\\"{x:840,y:824,t:1526667590917};\\\", \\\"{x:843,y:821,t:1526667590932};\\\", \\\"{x:846,y:818,t:1526667590949};\\\", \\\"{x:852,y:814,t:1526667590966};\\\", \\\"{x:860,y:809,t:1526667590984};\\\", \\\"{x:864,y:806,t:1526667590999};\\\", \\\"{x:871,y:802,t:1526667591017};\\\", \\\"{x:884,y:798,t:1526667591034};\\\", \\\"{x:902,y:793,t:1526667591050};\\\", \\\"{x:922,y:789,t:1526667591066};\\\", \\\"{x:943,y:785,t:1526667591083};\\\", \\\"{x:966,y:782,t:1526667591100};\\\", \\\"{x:988,y:774,t:1526667591116};\\\", \\\"{x:1007,y:771,t:1526667591134};\\\", \\\"{x:1021,y:767,t:1526667591149};\\\", \\\"{x:1027,y:766,t:1526667591166};\\\", \\\"{x:1032,y:763,t:1526667591183};\\\", \\\"{x:1034,y:763,t:1526667591200};\\\", \\\"{x:1034,y:761,t:1526667591223};\\\", \\\"{x:1035,y:759,t:1526667591234};\\\", \\\"{x:1036,y:750,t:1526667591250};\\\", \\\"{x:1034,y:741,t:1526667591266};\\\", \\\"{x:1027,y:728,t:1526667591284};\\\", \\\"{x:1020,y:720,t:1526667591300};\\\", \\\"{x:1016,y:716,t:1526667591317};\\\", \\\"{x:1014,y:714,t:1526667591333};\\\", \\\"{x:1012,y:713,t:1526667591423};\\\", \\\"{x:1009,y:712,t:1526667591434};\\\", \\\"{x:1005,y:711,t:1526667591449};\\\", \\\"{x:996,y:709,t:1526667591466};\\\", \\\"{x:981,y:707,t:1526667591482};\\\", \\\"{x:966,y:702,t:1526667591499};\\\", \\\"{x:957,y:698,t:1526667591516};\\\", \\\"{x:948,y:694,t:1526667591533};\\\", \\\"{x:943,y:690,t:1526667591549};\\\", \\\"{x:942,y:689,t:1526667591566};\\\", \\\"{x:942,y:686,t:1526667591583};\\\", \\\"{x:942,y:684,t:1526667591607};\\\", \\\"{x:942,y:683,t:1526667591616};\\\", \\\"{x:943,y:679,t:1526667591633};\\\", \\\"{x:948,y:672,t:1526667591650};\\\", \\\"{x:953,y:665,t:1526667591666};\\\", \\\"{x:957,y:659,t:1526667591683};\\\", \\\"{x:965,y:654,t:1526667591700};\\\", \\\"{x:967,y:652,t:1526667591716};\\\", \\\"{x:972,y:650,t:1526667591733};\\\", \\\"{x:980,y:649,t:1526667591750};\\\", \\\"{x:981,y:649,t:1526667591767};\\\", \\\"{x:992,y:648,t:1526667591783};\\\", \\\"{x:999,y:647,t:1526667591801};\\\", \\\"{x:1003,y:646,t:1526667591817};\\\", \\\"{x:1006,y:645,t:1526667591833};\\\", \\\"{x:1008,y:644,t:1526667591850};\\\", \\\"{x:1009,y:644,t:1526667591871};\\\", \\\"{x:1011,y:644,t:1526667591883};\\\", \\\"{x:1013,y:644,t:1526667591900};\\\", \\\"{x:1016,y:643,t:1526667591917};\\\", \\\"{x:1020,y:642,t:1526667591934};\\\", \\\"{x:1030,y:642,t:1526667591951};\\\", \\\"{x:1033,y:642,t:1526667591966};\\\", \\\"{x:1042,y:640,t:1526667591983};\\\", \\\"{x:1053,y:639,t:1526667592001};\\\", \\\"{x:1060,y:639,t:1526667592017};\\\", \\\"{x:1070,y:638,t:1526667592033};\\\", \\\"{x:1073,y:636,t:1526667592050};\\\", \\\"{x:1075,y:635,t:1526667592067};\\\", \\\"{x:1075,y:638,t:1526667592311};\\\", \\\"{x:1075,y:640,t:1526667592319};\\\", \\\"{x:1076,y:648,t:1526667592334};\\\", \\\"{x:1079,y:656,t:1526667592351};\\\", \\\"{x:1080,y:663,t:1526667592367};\\\", \\\"{x:1080,y:668,t:1526667592384};\\\", \\\"{x:1082,y:673,t:1526667592401};\\\", \\\"{x:1084,y:678,t:1526667592417};\\\", \\\"{x:1087,y:684,t:1526667592435};\\\", \\\"{x:1091,y:692,t:1526667592452};\\\", \\\"{x:1092,y:699,t:1526667592467};\\\", \\\"{x:1095,y:706,t:1526667592484};\\\", \\\"{x:1095,y:709,t:1526667592502};\\\", \\\"{x:1095,y:710,t:1526667592518};\\\", \\\"{x:1096,y:711,t:1526667592534};\\\", \\\"{x:1096,y:713,t:1526667592552};\\\", \\\"{x:1096,y:715,t:1526667592567};\\\", \\\"{x:1095,y:716,t:1526667592585};\\\", \\\"{x:1093,y:718,t:1526667592601};\\\", \\\"{x:1089,y:719,t:1526667592618};\\\", \\\"{x:1084,y:719,t:1526667592635};\\\", \\\"{x:1079,y:719,t:1526667592651};\\\", \\\"{x:1074,y:721,t:1526667592669};\\\", \\\"{x:1073,y:721,t:1526667592684};\\\", \\\"{x:1067,y:721,t:1526667592701};\\\", \\\"{x:1059,y:721,t:1526667592718};\\\", \\\"{x:1042,y:720,t:1526667592735};\\\", \\\"{x:1035,y:720,t:1526667592751};\\\", \\\"{x:1027,y:718,t:1526667592767};\\\", \\\"{x:1025,y:718,t:1526667592784};\\\", \\\"{x:1020,y:717,t:1526667592801};\\\", \\\"{x:1016,y:717,t:1526667592817};\\\", \\\"{x:1010,y:717,t:1526667592835};\\\", \\\"{x:1004,y:716,t:1526667592851};\\\", \\\"{x:997,y:716,t:1526667592868};\\\", \\\"{x:992,y:716,t:1526667592885};\\\", \\\"{x:988,y:716,t:1526667592902};\\\", \\\"{x:983,y:716,t:1526667592917};\\\", \\\"{x:979,y:714,t:1526667592934};\\\", \\\"{x:976,y:714,t:1526667592950};\\\", \\\"{x:975,y:714,t:1526667592967};\\\", \\\"{x:971,y:715,t:1526667592984};\\\", \\\"{x:964,y:715,t:1526667593001};\\\", \\\"{x:959,y:715,t:1526667593017};\\\", \\\"{x:953,y:718,t:1526667593034};\\\", \\\"{x:950,y:719,t:1526667593052};\\\", \\\"{x:948,y:719,t:1526667593067};\\\", \\\"{x:947,y:719,t:1526667593084};\\\", \\\"{x:945,y:720,t:1526667593102};\\\", \\\"{x:944,y:720,t:1526667593117};\\\", \\\"{x:943,y:721,t:1526667593135};\\\", \\\"{x:942,y:722,t:1526667593159};\\\", \\\"{x:943,y:723,t:1526667593191};\\\", \\\"{x:945,y:723,t:1526667593201};\\\", \\\"{x:964,y:724,t:1526667593218};\\\", \\\"{x:989,y:724,t:1526667593235};\\\", \\\"{x:1009,y:725,t:1526667593250};\\\", \\\"{x:1032,y:725,t:1526667593268};\\\", \\\"{x:1050,y:725,t:1526667593285};\\\", \\\"{x:1064,y:726,t:1526667593301};\\\", \\\"{x:1069,y:729,t:1526667593317};\\\", \\\"{x:1070,y:729,t:1526667593334};\\\", \\\"{x:1071,y:730,t:1526667593391};\\\", \\\"{x:1069,y:732,t:1526667593407};\\\", \\\"{x:1068,y:733,t:1526667593417};\\\", \\\"{x:1059,y:737,t:1526667593434};\\\", \\\"{x:1047,y:741,t:1526667593451};\\\", \\\"{x:1037,y:742,t:1526667593467};\\\", \\\"{x:1022,y:743,t:1526667593485};\\\", \\\"{x:1005,y:746,t:1526667593502};\\\", \\\"{x:983,y:746,t:1526667593519};\\\", \\\"{x:973,y:746,t:1526667593534};\\\", \\\"{x:953,y:746,t:1526667593552};\\\", \\\"{x:943,y:746,t:1526667593569};\\\", \\\"{x:933,y:746,t:1526667593585};\\\", \\\"{x:923,y:746,t:1526667593602};\\\", \\\"{x:915,y:746,t:1526667593619};\\\", \\\"{x:911,y:746,t:1526667593635};\\\", \\\"{x:907,y:746,t:1526667593651};\\\", \\\"{x:899,y:746,t:1526667593668};\\\", \\\"{x:898,y:746,t:1526667593685};\\\", \\\"{x:888,y:746,t:1526667593701};\\\", \\\"{x:874,y:746,t:1526667593718};\\\", \\\"{x:867,y:746,t:1526667593734};\\\", \\\"{x:863,y:746,t:1526667593752};\\\", \\\"{x:862,y:747,t:1526667593768};\\\", \\\"{x:860,y:748,t:1526667593815};\\\", \\\"{x:859,y:749,t:1526667593822};\\\", \\\"{x:858,y:750,t:1526667593835};\\\", \\\"{x:855,y:753,t:1526667593851};\\\", \\\"{x:853,y:756,t:1526667593869};\\\", \\\"{x:851,y:759,t:1526667593886};\\\", \\\"{x:849,y:760,t:1526667593903};\\\", \\\"{x:849,y:761,t:1526667593919};\\\", \\\"{x:847,y:763,t:1526667593952};\\\", \\\"{x:847,y:766,t:1526667593969};\\\", \\\"{x:847,y:769,t:1526667593992};\\\", \\\"{x:847,y:770,t:1526667594001};\\\", \\\"{x:845,y:775,t:1526667594018};\\\", \\\"{x:844,y:777,t:1526667594055};\\\", \\\"{x:847,y:779,t:1526667594151};\\\", \\\"{x:855,y:780,t:1526667594158};\\\", \\\"{x:856,y:780,t:1526667594168};\\\", \\\"{x:860,y:780,t:1526667594185};\\\", \\\"{x:874,y:782,t:1526667594202};\\\", \\\"{x:883,y:783,t:1526667594219};\\\", \\\"{x:886,y:783,t:1526667594235};\\\", \\\"{x:888,y:784,t:1526667594253};\\\", \\\"{x:889,y:784,t:1526667594295};\\\", \\\"{x:890,y:784,t:1526667594303};\\\", \\\"{x:896,y:782,t:1526667594319};\\\", \\\"{x:902,y:782,t:1526667594335};\\\", \\\"{x:911,y:778,t:1526667594352};\\\", \\\"{x:919,y:777,t:1526667594368};\\\", \\\"{x:921,y:777,t:1526667594386};\\\", \\\"{x:922,y:777,t:1526667594403};\\\", \\\"{x:923,y:777,t:1526667594418};\\\", \\\"{x:925,y:776,t:1526667594439};\\\", \\\"{x:929,y:776,t:1526667594453};\\\", \\\"{x:934,y:774,t:1526667594469};\\\", \\\"{x:942,y:773,t:1526667594485};\\\", \\\"{x:948,y:772,t:1526667594502};\\\", \\\"{x:949,y:772,t:1526667594534};\\\", \\\"{x:948,y:772,t:1526667594631};\\\", \\\"{x:945,y:772,t:1526667594638};\\\", \\\"{x:942,y:772,t:1526667594655};\\\", \\\"{x:939,y:773,t:1526667594670};\\\", \\\"{x:934,y:775,t:1526667594686};\\\", \\\"{x:926,y:776,t:1526667594702};\\\", \\\"{x:920,y:778,t:1526667594719};\\\", \\\"{x:913,y:780,t:1526667594736};\\\", \\\"{x:905,y:783,t:1526667594752};\\\", \\\"{x:898,y:786,t:1526667594769};\\\", \\\"{x:893,y:787,t:1526667594786};\\\", \\\"{x:890,y:787,t:1526667594803};\\\", \\\"{x:888,y:788,t:1526667594819};\\\", \\\"{x:886,y:788,t:1526667594835};\\\", \\\"{x:884,y:790,t:1526667594852};\\\", \\\"{x:882,y:791,t:1526667594869};\\\", \\\"{x:878,y:792,t:1526667594886};\\\", \\\"{x:868,y:798,t:1526667594904};\\\", \\\"{x:862,y:802,t:1526667594919};\\\", \\\"{x:854,y:802,t:1526667594936};\\\", \\\"{x:848,y:803,t:1526667594952};\\\", \\\"{x:844,y:803,t:1526667594969};\\\", \\\"{x:842,y:805,t:1526667594987};\\\", \\\"{x:840,y:806,t:1526667595002};\\\", \\\"{x:837,y:806,t:1526667595019};\\\", \\\"{x:836,y:806,t:1526667595038};\\\", \\\"{x:835,y:806,t:1526667595052};\\\", \\\"{x:831,y:806,t:1526667595069};\\\", \\\"{x:826,y:806,t:1526667595086};\\\", \\\"{x:824,y:806,t:1526667595103};\\\", \\\"{x:823,y:807,t:1526667595119};\\\", \\\"{x:822,y:808,t:1526667595137};\\\", \\\"{x:819,y:809,t:1526667595152};\\\", \\\"{x:819,y:810,t:1526667595199};\\\", \\\"{x:819,y:811,t:1526667595207};\\\", \\\"{x:819,y:812,t:1526667595231};\\\", \\\"{x:819,y:814,t:1526667595239};\\\", \\\"{x:820,y:815,t:1526667595252};\\\", \\\"{x:823,y:816,t:1526667595270};\\\", \\\"{x:830,y:818,t:1526667595287};\\\", \\\"{x:835,y:820,t:1526667595303};\\\", \\\"{x:839,y:821,t:1526667595320};\\\", \\\"{x:843,y:822,t:1526667595336};\\\", \\\"{x:846,y:823,t:1526667595352};\\\", \\\"{x:847,y:824,t:1526667595370};\\\", \\\"{x:848,y:825,t:1526667595511};\\\", \\\"{x:848,y:826,t:1526667595519};\\\", \\\"{x:848,y:832,t:1526667595536};\\\", \\\"{x:848,y:834,t:1526667595553};\\\", \\\"{x:848,y:836,t:1526667595570};\\\", \\\"{x:848,y:837,t:1526667595663};\\\", \\\"{x:848,y:839,t:1526667595678};\\\", \\\"{x:848,y:840,t:1526667595687};\\\", \\\"{x:848,y:843,t:1526667595703};\\\", \\\"{x:848,y:845,t:1526667595719};\\\", \\\"{x:848,y:846,t:1526667595736};\\\", \\\"{x:848,y:847,t:1526667595753};\\\", \\\"{x:848,y:849,t:1526667595770};\\\", \\\"{x:847,y:850,t:1526667595798};\\\", \\\"{x:846,y:850,t:1526667595822};\\\", \\\"{x:844,y:850,t:1526667595838};\\\", \\\"{x:843,y:850,t:1526667595853};\\\", \\\"{x:840,y:850,t:1526667595878};\\\", \\\"{x:839,y:850,t:1526667595927};\\\", \\\"{x:838,y:850,t:1526667595990};\\\", \\\"{x:837,y:850,t:1526667596135};\\\", \\\"{x:837,y:849,t:1526667596295};\\\", \\\"{x:837,y:848,t:1526667596306};\\\", \\\"{x:837,y:847,t:1526667596321};\\\", \\\"{x:837,y:846,t:1526667596343};\\\", \\\"{x:837,y:845,t:1526667596455};\\\", \\\"{x:837,y:844,t:1526667596471};\\\", \\\"{x:837,y:843,t:1526667596487};\\\", \\\"{x:837,y:841,t:1526667596503};\\\", \\\"{x:837,y:840,t:1526667596521};\\\", \\\"{x:837,y:839,t:1526667596639};\\\", \\\"{x:837,y:838,t:1526667596654};\\\", \\\"{x:836,y:837,t:1526667596671};\\\", \\\"{x:836,y:834,t:1526667596896};\\\", \\\"{x:836,y:833,t:1526667596904};\\\", \\\"{x:837,y:829,t:1526667596920};\\\", \\\"{x:838,y:827,t:1526667596938};\\\", \\\"{x:838,y:826,t:1526667596955};\\\", \\\"{x:838,y:825,t:1526667597080};\\\", \\\"{x:838,y:824,t:1526667597095};\\\", \\\"{x:838,y:823,t:1526667597119};\\\", \\\"{x:837,y:821,t:1526667597127};\\\", \\\"{x:837,y:820,t:1526667597159};\\\", \\\"{x:836,y:819,t:1526667597328};\\\", \\\"{x:835,y:819,t:1526667597337};\\\", \\\"{x:834,y:817,t:1526667597354};\\\", \\\"{x:833,y:816,t:1526667597663};\\\", \\\"{x:832,y:816,t:1526667597695};\\\", \\\"{x:831,y:815,t:1526667597735};\\\", \\\"{x:831,y:815,t:1526667597924};\\\", \\\"{x:839,y:814,t:1526667598295};\\\", \\\"{x:851,y:815,t:1526667598307};\\\", \\\"{x:874,y:815,t:1526667598322};\\\", \\\"{x:892,y:817,t:1526667598338};\\\", \\\"{x:906,y:820,t:1526667598355};\\\", \\\"{x:927,y:827,t:1526667598372};\\\", \\\"{x:938,y:831,t:1526667598389};\\\", \\\"{x:945,y:836,t:1526667598405};\\\", \\\"{x:947,y:839,t:1526667598423};\\\", \\\"{x:948,y:840,t:1526667598438};\\\", \\\"{x:948,y:844,t:1526667598455};\\\", \\\"{x:948,y:849,t:1526667598472};\\\", \\\"{x:948,y:859,t:1526667598489};\\\", \\\"{x:946,y:866,t:1526667598505};\\\", \\\"{x:936,y:877,t:1526667598523};\\\", \\\"{x:926,y:889,t:1526667598538};\\\", \\\"{x:914,y:904,t:1526667598556};\\\", \\\"{x:903,y:914,t:1526667598573};\\\", \\\"{x:894,y:922,t:1526667598589};\\\", \\\"{x:889,y:927,t:1526667598605};\\\", \\\"{x:884,y:931,t:1526667598623};\\\", \\\"{x:881,y:931,t:1526667598639};\\\", \\\"{x:877,y:931,t:1526667598655};\\\", \\\"{x:875,y:932,t:1526667598673};\\\", \\\"{x:870,y:933,t:1526667598688};\\\", \\\"{x:866,y:934,t:1526667598706};\\\", \\\"{x:862,y:935,t:1526667598723};\\\", \\\"{x:859,y:937,t:1526667598740};\\\", \\\"{x:855,y:938,t:1526667598756};\\\", \\\"{x:846,y:941,t:1526667598773};\\\", \\\"{x:838,y:942,t:1526667598790};\\\", \\\"{x:831,y:943,t:1526667598806};\\\", \\\"{x:822,y:943,t:1526667598823};\\\", \\\"{x:820,y:943,t:1526667598871};\\\", \\\"{x:819,y:944,t:1526667598934};\\\", \\\"{x:818,y:945,t:1526667598942};\\\", \\\"{x:818,y:946,t:1526667598955};\\\", \\\"{x:816,y:953,t:1526667598972};\\\", \\\"{x:814,y:958,t:1526667598989};\\\", \\\"{x:812,y:963,t:1526667599005};\\\", \\\"{x:812,y:969,t:1526667599022};\\\", \\\"{x:812,y:971,t:1526667599039};\\\", \\\"{x:812,y:972,t:1526667599055};\\\", \\\"{x:812,y:973,t:1526667599086};\\\", \\\"{x:814,y:973,t:1526667599143};\\\", \\\"{x:815,y:971,t:1526667599156};\\\", \\\"{x:819,y:968,t:1526667599172};\\\", \\\"{x:823,y:966,t:1526667599190};\\\", \\\"{x:829,y:962,t:1526667599206};\\\", \\\"{x:832,y:961,t:1526667599222};\\\", \\\"{x:833,y:961,t:1526667599303};\\\", \\\"{x:834,y:961,t:1526667599311};\\\", \\\"{x:836,y:960,t:1526667599323};\\\", \\\"{x:837,y:959,t:1526667599360};\\\", \\\"{x:841,y:961,t:1526667599711};\\\", \\\"{x:842,y:964,t:1526667599724};\\\", \\\"{x:846,y:969,t:1526667599740};\\\", \\\"{x:855,y:982,t:1526667599756};\\\", \\\"{x:857,y:990,t:1526667599774};\\\", \\\"{x:860,y:995,t:1526667599790};\\\", \\\"{x:864,y:1004,t:1526667599806};\\\", \\\"{x:866,y:1007,t:1526667599824};\\\", \\\"{x:866,y:1010,t:1526667599839};\\\", \\\"{x:866,y:1012,t:1526667599856};\\\", \\\"{x:867,y:1014,t:1526667599873};\\\", \\\"{x:867,y:1017,t:1526667599889};\\\", \\\"{x:868,y:1018,t:1526667599906};\\\", \\\"{x:868,y:1019,t:1526667599942};\\\", \\\"{x:869,y:1019,t:1526667599956};\\\", \\\"{x:870,y:1021,t:1526667599973};\\\", \\\"{x:870,y:1023,t:1526667599990};\\\", \\\"{x:872,y:1026,t:1526667600007};\\\", \\\"{x:873,y:1026,t:1526667600024};\\\", \\\"{x:873,y:1027,t:1526667600040};\\\", \\\"{x:873,y:1028,t:1526667600095};\\\", \\\"{x:873,y:1028,t:1526667600139};\\\", \\\"{x:875,y:1028,t:1526667600855};\\\", \\\"{x:876,y:1028,t:1526667600895};\\\", \\\"{x:877,y:1027,t:1526667600911};\\\", \\\"{x:879,y:1026,t:1526667600935};\\\", \\\"{x:879,y:1024,t:1526667600943};\\\", \\\"{x:879,y:1023,t:1526667600975};\\\", \\\"{x:879,y:1021,t:1526667600990};\\\", \\\"{x:880,y:1019,t:1526667601007};\\\", \\\"{x:880,y:1018,t:1526667601024};\\\", \\\"{x:882,y:1016,t:1526667601041};\\\", \\\"{x:883,y:1014,t:1526667601058};\\\", \\\"{x:883,y:1013,t:1526667601075};\\\", \\\"{x:884,y:1009,t:1526667601091};\\\", \\\"{x:884,y:1006,t:1526667601108};\\\", \\\"{x:886,y:1000,t:1526667601125};\\\", \\\"{x:886,y:992,t:1526667601140};\\\", \\\"{x:888,y:986,t:1526667601157};\\\", \\\"{x:890,y:979,t:1526667601175};\\\", \\\"{x:893,y:975,t:1526667601191};\\\", \\\"{x:895,y:967,t:1526667601208};\\\", \\\"{x:899,y:957,t:1526667601225};\\\", \\\"{x:900,y:946,t:1526667601255};\\\", \\\"{x:904,y:934,t:1526667601258};\\\", \\\"{x:909,y:919,t:1526667601275};\\\", \\\"{x:915,y:903,t:1526667601291};\\\", \\\"{x:926,y:883,t:1526667601308};\\\", \\\"{x:936,y:863,t:1526667601325};\\\", \\\"{x:947,y:839,t:1526667601341};\\\", \\\"{x:971,y:805,t:1526667601358};\\\", \\\"{x:997,y:757,t:1526667601375};\\\", \\\"{x:1023,y:723,t:1526667601391};\\\", \\\"{x:1056,y:682,t:1526667601407};\\\", \\\"{x:1088,y:644,t:1526667601425};\\\", \\\"{x:1131,y:596,t:1526667601440};\\\", \\\"{x:1177,y:544,t:1526667601457};\\\", \\\"{x:1229,y:489,t:1526667601474};\\\", \\\"{x:1281,y:433,t:1526667601490};\\\", \\\"{x:1319,y:400,t:1526667601507};\\\", \\\"{x:1358,y:364,t:1526667601525};\\\", \\\"{x:1381,y:348,t:1526667601541};\\\", \\\"{x:1394,y:337,t:1526667601567};\\\", \\\"{x:1385,y:339,t:1526667602230};\\\", \\\"{x:1371,y:351,t:1526667602239};\\\", \\\"{x:1283,y:405,t:1526667602257};\\\", \\\"{x:1188,y:473,t:1526667602274};\\\", \\\"{x:1088,y:526,t:1526667602290};\\\", \\\"{x:1003,y:575,t:1526667602306};\\\", \\\"{x:945,y:610,t:1526667602324};\\\", \\\"{x:909,y:630,t:1526667602339};\\\", \\\"{x:893,y:642,t:1526667602356};\\\", \\\"{x:884,y:651,t:1526667602373};\\\", \\\"{x:880,y:659,t:1526667602390};\\\", \\\"{x:877,y:676,t:1526667602407};\\\", \\\"{x:873,y:695,t:1526667602424};\\\", \\\"{x:873,y:709,t:1526667602440};\\\", \\\"{x:872,y:725,t:1526667602457};\\\", \\\"{x:870,y:739,t:1526667602474};\\\", \\\"{x:870,y:767,t:1526667602490};\\\", \\\"{x:875,y:801,t:1526667602507};\\\", \\\"{x:881,y:824,t:1526667602524};\\\", \\\"{x:886,y:842,t:1526667602540};\\\", \\\"{x:893,y:862,t:1526667602558};\\\", \\\"{x:898,y:879,t:1526667602574};\\\", \\\"{x:908,y:894,t:1526667602590};\\\", \\\"{x:928,y:911,t:1526667602606};\\\", \\\"{x:951,y:922,t:1526667602624};\\\", \\\"{x:975,y:929,t:1526667602640};\\\", \\\"{x:994,y:933,t:1526667602657};\\\", \\\"{x:1013,y:940,t:1526667602674};\\\", \\\"{x:1027,y:945,t:1526667602690};\\\", \\\"{x:1044,y:950,t:1526667602707};\\\", \\\"{x:1053,y:953,t:1526667602724};\\\", \\\"{x:1056,y:954,t:1526667602740};\\\", \\\"{x:1057,y:954,t:1526667602757};\\\", \\\"{x:1055,y:954,t:1526667611012};\\\", \\\"{x:1050,y:954,t:1526667611021};\\\", \\\"{x:1046,y:954,t:1526667611038};\\\", \\\"{x:1044,y:954,t:1526667611054};\\\", \\\"{x:1042,y:954,t:1526667611071};\\\", \\\"{x:1040,y:954,t:1526667611088};\\\", \\\"{x:1039,y:954,t:1526667611104};\\\", \\\"{x:1037,y:955,t:1526667611189};\\\", \\\"{x:1033,y:956,t:1526667611204};\\\", \\\"{x:1024,y:957,t:1526667611221};\\\", \\\"{x:1014,y:959,t:1526667611238};\\\", \\\"{x:999,y:961,t:1526667611254};\\\", \\\"{x:987,y:968,t:1526667611271};\\\", \\\"{x:974,y:971,t:1526667611288};\\\", \\\"{x:962,y:973,t:1526667611304};\\\", \\\"{x:951,y:975,t:1526667611321};\\\", \\\"{x:941,y:980,t:1526667611338};\\\", \\\"{x:936,y:982,t:1526667611354};\\\", \\\"{x:932,y:984,t:1526667611371};\\\", \\\"{x:929,y:985,t:1526667611389};\\\", \\\"{x:927,y:987,t:1526667611412};\\\", \\\"{x:925,y:989,t:1526667611428};\\\", \\\"{x:925,y:993,t:1526667611437};\\\", \\\"{x:920,y:999,t:1526667611454};\\\", \\\"{x:916,y:1004,t:1526667611471};\\\", \\\"{x:911,y:1015,t:1526667611488};\\\", \\\"{x:908,y:1021,t:1526667611504};\\\", \\\"{x:906,y:1026,t:1526667611521};\\\", \\\"{x:904,y:1031,t:1526667611538};\\\", \\\"{x:904,y:1038,t:1526667611554};\\\", \\\"{x:903,y:1045,t:1526667611571};\\\", \\\"{x:902,y:1051,t:1526667611589};\\\", \\\"{x:903,y:1055,t:1526667611605};\\\", \\\"{x:907,y:1059,t:1526667611621};\\\", \\\"{x:909,y:1062,t:1526667611638};\\\", \\\"{x:916,y:1066,t:1526667611654};\\\", \\\"{x:922,y:1069,t:1526667611671};\\\", \\\"{x:927,y:1070,t:1526667611688};\\\", \\\"{x:933,y:1071,t:1526667611704};\\\", \\\"{x:940,y:1072,t:1526667611722};\\\", \\\"{x:949,y:1073,t:1526667611738};\\\", \\\"{x:961,y:1076,t:1526667611753};\\\", \\\"{x:971,y:1082,t:1526667611764};\\\", \\\"{x:984,y:1085,t:1526667611781};\\\", \\\"{x:994,y:1089,t:1526667611798};\\\", \\\"{x:1000,y:1095,t:1526667611814};\\\", \\\"{x:1004,y:1097,t:1526667611831};\\\", \\\"{x:1005,y:1098,t:1526667611847};\\\", \\\"{x:1006,y:1100,t:1526667611863};\\\", \\\"{x:1006,y:1102,t:1526667611981};\\\", \\\"{x:1006,y:1105,t:1526667611997};\\\", \\\"{x:1006,y:1107,t:1526667612014};\\\", \\\"{x:1006,y:1108,t:1526667612030};\\\", \\\"{x:1004,y:1108,t:1526667612047};\\\", \\\"{x:1003,y:1108,t:1526667612084};\\\", \\\"{x:1000,y:1108,t:1526667612156};\\\", \\\"{x:997,y:1108,t:1526667612220};\\\", \\\"{x:995,y:1105,t:1526667612237};\\\", \\\"{x:993,y:1103,t:1526667612248};\\\", \\\"{x:989,y:1099,t:1526667612265};\\\", \\\"{x:988,y:1098,t:1526667612281};\\\", \\\"{x:987,y:1096,t:1526667612332};\\\", \\\"{x:986,y:1096,t:1526667612380};\\\", \\\"{x:986,y:1095,t:1526667612404};\\\", \\\"{x:985,y:1094,t:1526667612420};\\\", \\\"{x:985,y:1093,t:1526667612431};\\\", \\\"{x:984,y:1092,t:1526667612448};\\\", \\\"{x:983,y:1091,t:1526667612465};\\\", \\\"{x:983,y:1090,t:1526667612481};\\\", \\\"{x:982,y:1089,t:1526667612498};\\\", \\\"{x:982,y:1088,t:1526667612515};\\\" ] }, { \\\"rt\\\": 19508, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"19\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"US\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 694182, \\\"internal_node_id\\\": \\\"0.0-7.0\\\", \\\"subject\\\": \\\"HWJDK\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"men\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 15062, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Second\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Humanities\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 710261, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"HWJDK\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"men\\\", \\\"condition\\\": \\\"113\\\" }, { \\\"rt\\\": 15130, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 726736, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"HWJDK\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"men\\\", \\\"condition\\\": \\\"113\\\" } ]\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"HWJDK\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2273,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2274},{\"nodeType\":3,\"id\":2275,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2276},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2280,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"start\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2281,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2282,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2284,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2285},{\"nodeType\":3,\"id\":2286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2287,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2288,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2289,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2290,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2291,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2292,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2293,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2294,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2295,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2296,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2297,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2298,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2300,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2301,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2303,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2304,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2305,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2306,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2307,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2308,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2309,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2310,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2311,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2312,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2313,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2314,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2315,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2316,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2317,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2318,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2319,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2320,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2321,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2322,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2323,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2324,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2325,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2326,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2327,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2328,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2329,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2330,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2331,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2332,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2333,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2334,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2335,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2336,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2337,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2338,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2339,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2340,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2341,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2342,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2343,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2344,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2345,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2346,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2347,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2348,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2349,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2350,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2351,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2352,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2353,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2354,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2355,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2356,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2357,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2358,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2359,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2360,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2361,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2362,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2363,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2364,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2365,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2366,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2367,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2368,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2369,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2370,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2371,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2372,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2373,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2374,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2375,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2376,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2377,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2378,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2379,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2380,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2381,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2382,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2383,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2384,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2385,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2386,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2387,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2388,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2389,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2390,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2391,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"15\"}},{\"nodeType\":1,\"id\":2392,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"20\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2393,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2394,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2400,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2401,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2404,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2405,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2406,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2407,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2408,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2409,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2413,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2414,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2417,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2418,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2421,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"x1\":\"400\",\"x2\":\"0\",\"y1\":\"0\",\"y2\":\"800\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2425,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-65) translate(-200,280)\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2426,\"textContent\":\"DURATION (in hours)\"}]}]},{\"nodeType\":1,\"id\":2427,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"x\":\"-1.6666666666666714\",\"y\":\"738.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"33.33333333333333\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2432,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2433,\"tagName\":\"text\",\"attributes\":{\"x\":\"31.666666666666657\",\"y\":\"671.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2434,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2435,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2436,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"66.66666666666666\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2437,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2438,\"tagName\":\"text\",\"attributes\":{\"x\":\"65\",\"y\":\"605\"},\"childNodes\":[{\"nodeType\":3,\"id\":2439,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2440,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2441,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"100\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"text\",\"attributes\":{\"x\":\"98.33333333333331\",\"y\":\"538.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2444,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2445,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2446,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"133.33333333333331\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2447,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"x\":\"131.66666666666669\",\"y\":\"471.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"166.66666666666669\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2452,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2453,\"tagName\":\"text\",\"attributes\":{\"x\":\"165\",\"y\":\"405\"},\"childNodes\":[{\"nodeType\":3,\"id\":2454,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2455,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2456,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"200\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2457,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2458,\"tagName\":\"text\",\"attributes\":{\"x\":\"198.33333333333334\",\"y\":\"338.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2459,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2460,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2461,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"233.33333333333334\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"x\":\"231.66666666666663\",\"y\":\"271.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"266.66666666666663\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2467,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2468,\"tagName\":\"text\",\"attributes\":{\"x\":\"265\",\"y\":\"205\"},\"childNodes\":[{\"nodeType\":3,\"id\":2469,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"300\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"text\",\"attributes\":{\"x\":\"298.33333333333337\",\"y\":\"138.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2474,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2475,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2476,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"333.33333333333337\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2477,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2478,\"tagName\":\"text\",\"attributes\":{\"x\":\"331.66666666666663\",\"y\":\"71.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2479,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"366.66666666666663\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"text\",\"attributes\":{\"x\":\"365\",\"y\":\"5\"},\"childNodes\":[{\"nodeType\":3,\"id\":2484,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2485,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\"},\"childNodes\":[{\"nodeType\":1,\"id\":2486,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2487,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"766.6666666666667\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"733.3333333333333\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2492,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"700\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2494,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"666.6666666666667\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2496,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"633.3333333333333\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2498,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"600\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2500,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"566.6666666666667\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2502,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"533.3333333333333\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2504,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"500\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2506,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"466.6666666666667\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2508,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"433.3333333333333\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2510,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2512,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2513,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2514,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2515,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2516,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2517,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2518,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2519,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2520,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2521,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2522,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2523,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2524,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2525,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2526,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2527,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2528,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2529,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2530,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2531,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2532,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2533,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2534,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2535,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2536,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2537,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2538,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2539,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2540,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2541,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2542,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2543,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2544,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2545,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2546,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2547,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2548,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2549,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2550,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2551,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2552,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2553,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2554,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2555,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2556,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2557,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2558,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2559,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2560,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2561,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2562,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2563,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2564,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2565,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2566,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2567,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2568,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2569,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2570,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2571,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2572,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2573,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2574,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2575,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2576,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2577,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2578,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2579,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2580,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2581,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2582,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2583,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2584,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2585,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2586,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2587},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2589,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2590,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2591,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2592,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 108, dom: 1064, initialDom: 1459",
  "javascriptErrors": []
}