var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "1e4a3048fa4f2ccc42ee5ad115ffd862",
  "created": "2018-05-22T14:11:58.9404916-07:00",
  "lastActivity": "2018-05-22T14:12:12.3314916-07:00",
  "pageViews": [
    {
      "id": "05225936aa2e3ec041d1f2350781fc8f6484a786",
      "startTime": "2018-05-22T14:11:58.9404916-07:00",
      "endTime": "2018-05-22T14:12:12.3314916-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/14",
      "visitTime": 13391,
      "engagementTime": 13391,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 13391,
  "engagementTime": 13391,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.22",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=D3LUH",
    "CONDITION=121",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "42823f2a1b32b2370220db2176a3375f",
  "gdpr": false
}