var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "2326a7b7c4635ebc38ca60e996e203fc",
  "created": "2018-05-25T11:11:07.5972766-07:00",
  "lastActivity": "2018-05-25T11:11:31.9799424-07:00",
  "pageViews": [
    {
      "id": "05250720a8343b9b717fec2c1e90af64136630a9",
      "startTime": "2018-05-25T11:11:07.6459424-07:00",
      "endTime": "2018-05-25T11:11:31.9799424-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/2",
      "visitTime": 24334,
      "engagementTime": 24283,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 24334,
  "engagementTime": 24283,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.44",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=UV5LD",
    "CONDITION=114",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "915221f66c9f53fad67e906cd4d719a0",
  "gdpr": false
}