var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["0522069668fefe861fec80d1fabaee3461f20c11"] = {
  "startTime": "2018-05-22T23:01:06.224613Z",
  "websitePageUrl": "/",
  "visitTime": 14458,
  "engagementTime": 18916,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1094,
  "tags": [],
  "session": {
    "id": "ecf60c199296fb4cba35238047c258d2",
    "created": "2018-05-22T23:01:06.224613+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/",
    "tags": [],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "e6d113199349fd707ccb90e010556277",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/ecf60c199296fb4cba35238047c258d2/play"
  },
  "events": [
    {
      "t": 102,
      "e": 102,
      "ty": 0,
      "x": 1920,
      "y": 1094
    },
    {
      "t": 345,
      "e": 345,
      "ty": 14,
      "x": 0,
      "y": 1093
    },
    {
      "t": 1753,
      "e": 1753,
      "ty": 41,
      "x": 63744,
      "y": 0,
      "ta": "html > body"
    },
    {
      "t": 1801,
      "e": 1801,
      "ty": 2,
      "x": 1919,
      "y": 196
    },
    {
      "t": 1900,
      "e": 1900,
      "ty": 2,
      "x": 1902,
      "y": 302
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 2,
      "x": 1569,
      "y": 299
    },
    {
      "t": 2001,
      "e": 2001,
      "ty": 41,
      "x": 53757,
      "y": 17707,
      "ta": "html > body"
    },
    {
      "t": 2101,
      "e": 2101,
      "ty": 2,
      "x": 1245,
      "y": 401
    },
    {
      "t": 2201,
      "e": 2201,
      "ty": 2,
      "x": 1122,
      "y": 431
    },
    {
      "t": 2253,
      "e": 2253,
      "ty": 41,
      "x": 41642,
      "y": 23469,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 2301,
      "e": 2301,
      "ty": 2,
      "x": 1151,
      "y": 472
    },
    {
      "t": 2401,
      "e": 2401,
      "ty": 2,
      "x": 1234,
      "y": 538
    },
    {
      "t": 2789,
      "e": 2789,
      "ty": 2,
      "x": 1220,
      "y": 624
    },
    {
      "t": 2789,
      "e": 2789,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 2789,
      "e": 2789,
      "ty": 41,
      "x": 46994,
      "y": 39116,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 2801,
      "e": 2801,
      "ty": 2,
      "x": 1220,
      "y": 625
    },
    {
      "t": 2905,
      "e": 2905,
      "ty": 2,
      "x": 1217,
      "y": 630
    },
    {
      "t": 3004,
      "e": 3004,
      "ty": 2,
      "x": 1216,
      "y": 630
    },
    {
      "t": 3004,
      "e": 3004,
      "ty": 41,
      "x": 46775,
      "y": 39607,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 3101,
      "e": 3101,
      "ty": 2,
      "x": 1207,
      "y": 637
    },
    {
      "t": 3200,
      "e": 3200,
      "ty": 2,
      "x": 1185,
      "y": 652
    },
    {
      "t": 3250,
      "e": 3250,
      "ty": 41,
      "x": 45028,
      "y": 41491,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 3311,
      "e": 3311,
      "ty": 2,
      "x": 1184,
      "y": 653
    },
    {
      "t": 3501,
      "e": 3501,
      "ty": 2,
      "x": 1131,
      "y": 656
    },
    {
      "t": 3501,
      "e": 3501,
      "ty": 41,
      "x": 42133,
      "y": 41737,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 3601,
      "e": 3601,
      "ty": 2,
      "x": 991,
      "y": 581
    },
    {
      "t": 3701,
      "e": 3701,
      "ty": 2,
      "x": 960,
      "y": 610
    },
    {
      "t": 3752,
      "e": 3752,
      "ty": 41,
      "x": 32904,
      "y": 42802,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 3862,
      "e": 3862,
      "ty": 2,
      "x": 944,
      "y": 777
    },
    {
      "t": 3900,
      "e": 3900,
      "ty": 2,
      "x": 943,
      "y": 776
    },
    {
      "t": 4000,
      "e": 4000,
      "ty": 2,
      "x": 842,
      "y": 591
    },
    {
      "t": 4001,
      "e": 4001,
      "ty": 41,
      "x": 26350,
      "y": 36412,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 4101,
      "e": 4101,
      "ty": 2,
      "x": 837,
      "y": 564
    },
    {
      "t": 4258,
      "e": 4258,
      "ty": 41,
      "x": 26077,
      "y": 34201,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 4301,
      "e": 4301,
      "ty": 2,
      "x": 840,
      "y": 573
    },
    {
      "t": 4401,
      "e": 4401,
      "ty": 2,
      "x": 986,
      "y": 846
    },
    {
      "t": 4502,
      "e": 4502,
      "ty": 2,
      "x": 983,
      "y": 1094
    },
    {
      "t": 4605,
      "e": 4605,
      "ty": 2,
      "x": 983,
      "y": 1098
    },
    {
      "t": 4701,
      "e": 4701,
      "ty": 2,
      "x": 987,
      "y": 1040
    },
    {
      "t": 4752,
      "e": 4752,
      "ty": 41,
      "x": 33748,
      "y": 61458,
      "ta": "html > body"
    },
    {
      "t": 4801,
      "e": 4801,
      "ty": 2,
      "x": 988,
      "y": 1005
    },
    {
      "t": 4901,
      "e": 4901,
      "ty": 2,
      "x": 973,
      "y": 901
    },
    {
      "t": 5000,
      "e": 5000,
      "ty": 2,
      "x": 964,
      "y": 822
    },
    {
      "t": 5001,
      "e": 5001,
      "ty": 41,
      "x": 33013,
      "y": 55336,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 5102,
      "e": 5102,
      "ty": 2,
      "x": 963,
      "y": 817
    },
    {
      "t": 5253,
      "e": 5253,
      "ty": 41,
      "x": 32958,
      "y": 54926,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 5604,
      "e": 5604,
      "ty": 2,
      "x": 959,
      "y": 816
    },
    {
      "t": 5709,
      "e": 5709,
      "ty": 2,
      "x": 958,
      "y": 815
    },
    {
      "t": 5759,
      "e": 5759,
      "ty": 41,
      "x": 32685,
      "y": 54762,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 7869,
      "e": 7869,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 7901,
      "e": 7901,
      "ty": 2,
      "x": 1112,
      "y": 80
    },
    {
      "t": 8001,
      "e": 8001,
      "ty": 41,
      "x": 38019,
      "y": 4381,
      "ta": "html > body"
    },
    {
      "t": 8198,
      "e": 8198,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 8201,
      "e": 8201,
      "ty": 2,
      "x": 1632,
      "y": 1041
    },
    {
      "t": 8258,
      "e": 8258,
      "ty": 41,
      "x": 55926,
      "y": 62857,
      "ta": "html > body"
    },
    {
      "t": 8404,
      "e": 8404,
      "ty": 2,
      "x": 1919,
      "y": 1107
    },
    {
      "t": 8500,
      "e": 8500,
      "ty": 2,
      "x": 1907,
      "y": 1040
    },
    {
      "t": 8601,
      "e": 8601,
      "ty": 2,
      "x": 1879,
      "y": 966
    },
    {
      "t": 8700,
      "e": 8700,
      "ty": 2,
      "x": 1838,
      "y": 918
    },
    {
      "t": 8751,
      "e": 8751,
      "ty": 41,
      "x": 61815,
      "y": 55616,
      "ta": "html > body"
    },
    {
      "t": 8801,
      "e": 8801,
      "ty": 2,
      "x": 1733,
      "y": 949
    },
    {
      "t": 8905,
      "e": 8905,
      "ty": 2,
      "x": 1699,
      "y": 967
    },
    {
      "t": 9005,
      "e": 9005,
      "ty": 41,
      "x": 58234,
      "y": 58354,
      "ta": "html > body"
    },
    {
      "t": 9401,
      "e": 9401,
      "ty": 2,
      "x": 1690,
      "y": 984
    },
    {
      "t": 9500,
      "e": 9500,
      "ty": 2,
      "x": 1697,
      "y": 994
    },
    {
      "t": 9501,
      "e": 9501,
      "ty": 41,
      "x": 58165,
      "y": 59997,
      "ta": "html > body"
    },
    {
      "t": 9601,
      "e": 9601,
      "ty": 2,
      "x": 1739,
      "y": 972
    },
    {
      "t": 9700,
      "e": 9700,
      "ty": 2,
      "x": 1742,
      "y": 970
    },
    {
      "t": 9751,
      "e": 9751,
      "ty": 41,
      "x": 59852,
      "y": 58233,
      "ta": "html > body"
    },
    {
      "t": 9800,
      "e": 9800,
      "ty": 2,
      "x": 1746,
      "y": 956
    },
    {
      "t": 9900,
      "e": 9900,
      "ty": 2,
      "x": 1735,
      "y": 840
    },
    {
      "t": 10000,
      "e": 10000,
      "ty": 2,
      "x": 1768,
      "y": 498
    },
    {
      "t": 10000,
      "e": 10000,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10004,
      "e": 14462,
      "ty": 41,
      "x": 60610,
      "y": 29816,
      "ta": "html > body"
    },
    {
      "t": 10100,
      "e": 14558,
      "ty": 2,
      "x": 1794,
      "y": 420
    },
    {
      "t": 10100,
      "e": 14558,
      "ty": 1,
      "x": 0,
      "y": 8
    },
    {
      "t": 10201,
      "e": 14659,
      "ty": 2,
      "x": 1606,
      "y": 555
    },
    {
      "t": 10201,
      "e": 14659,
      "ty": 1,
      "x": 0,
      "y": 0
    },
    {
      "t": 10251,
      "e": 14709,
      "ty": 41,
      "x": 64797,
      "y": 35921,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 10300,
      "e": 14758,
      "ty": 2,
      "x": 1507,
      "y": 579
    },
    {
      "t": 10400,
      "e": 14858,
      "ty": 2,
      "x": 1357,
      "y": 612
    },
    {
      "t": 10438,
      "e": 14896,
      "ty": 3,
      "x": 1357,
      "y": 611,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 10501,
      "e": 14959,
      "ty": 2,
      "x": 1361,
      "y": 609
    },
    {
      "t": 10501,
      "e": 14959,
      "ty": 41,
      "x": 54694,
      "y": 37887,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 10700,
      "e": 15158,
      "ty": 2,
      "x": 1319,
      "y": 619
    },
    {
      "t": 10750,
      "e": 15208,
      "ty": 41,
      "x": 43444,
      "y": 54107,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 10800,
      "e": 15258,
      "ty": 2,
      "x": 1015,
      "y": 975
    },
    {
      "t": 10836,
      "e": 15294,
      "ty": 3,
      "x": 1007,
      "y": 986,
      "ta": "html > body"
    },
    {
      "t": 10900,
      "e": 15358,
      "ty": 2,
      "x": 1015,
      "y": 982
    },
    {
      "t": 10990,
      "e": 15448,
      "ty": 4,
      "x": 40058,
      "y": 60578,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 10991,
      "e": 15449,
      "ty": 5,
      "x": 1093,
      "y": 886,
      "ta": "html > body"
    },
    {
      "t": 11000,
      "e": 15458,
      "ty": 2,
      "x": 1093,
      "y": 886
    },
    {
      "t": 11000,
      "e": 15458,
      "ty": 41,
      "x": 40058,
      "y": 60578,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 11101,
      "e": 15559,
      "ty": 2,
      "x": 1899,
      "y": 300
    },
    {
      "t": 11205,
      "e": 15663,
      "ty": 2,
      "x": 1919,
      "y": 224
    },
    {
      "t": 11306,
      "e": 15764,
      "ty": 2,
      "x": 1919,
      "y": 215
    },
    {
      "t": 11401,
      "e": 15859,
      "ty": 2,
      "x": 1888,
      "y": 240
    },
    {
      "t": 11507,
      "e": 15965,
      "ty": 2,
      "x": 1887,
      "y": 240
    },
    {
      "t": 11508,
      "e": 15966,
      "ty": 41,
      "x": 64708,
      "y": 14117,
      "ta": "html > body"
    },
    {
      "t": 11600,
      "e": 16058,
      "ty": 2,
      "x": 1893,
      "y": 234
    },
    {
      "t": 11701,
      "e": 16159,
      "ty": 2,
      "x": 1912,
      "y": 232
    },
    {
      "t": 11808,
      "e": 16266,
      "ty": 2,
      "x": 1919,
      "y": 232
    },
    {
      "t": 11909,
      "e": 16367,
      "ty": 3,
      "x": 1919,
      "y": 232,
      "ta": "html"
    },
    {
      "t": 12200,
      "e": 16658,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 12566,
      "e": 17024,
      "ty": 4,
      "x": 63606,
      "y": 23853,
      "ta": "html"
    },
    {
      "t": 12600,
      "e": 17058,
      "ty": 2,
      "x": 1694,
      "y": 348
    },
    {
      "t": 12700,
      "e": 17158,
      "ty": 2,
      "x": 790,
      "y": 194
    },
    {
      "t": 12751,
      "e": 17209,
      "ty": 41,
      "x": 3194,
      "y": 3727,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 12801,
      "e": 17259,
      "ty": 2,
      "x": 432,
      "y": 196
    },
    {
      "t": 12906,
      "e": 17364,
      "ty": 2,
      "x": 436,
      "y": 196
    },
    {
      "t": 13007,
      "e": 17465,
      "ty": 41,
      "x": 4177,
      "y": 4054,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 13200,
      "e": 17658,
      "ty": 2,
      "x": 385,
      "y": 130
    },
    {
      "t": 13250,
      "e": 17708,
      "ty": 41,
      "x": 11812,
      "y": 4320,
      "ta": "html > body"
    },
    {
      "t": 13301,
      "e": 17759,
      "ty": 2,
      "x": 337,
      "y": 56
    },
    {
      "t": 13401,
      "e": 17859,
      "ty": 2,
      "x": 264,
      "y": 24
    },
    {
      "t": 13437,
      "e": 17895,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 13505,
      "e": 17963,
      "ty": 2,
      "x": 241,
      "y": 16
    },
    {
      "t": 13506,
      "e": 17964,
      "ty": 41,
      "x": 8023,
      "y": 486,
      "ta": "html > body"
    },
    {
      "t": 14458,
      "e": 18916,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 233, dom: 233, initialDom: 242",
  "javascriptErrors": []
}