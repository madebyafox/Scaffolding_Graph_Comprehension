var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "a26273badcb97a9f121ed733019dd1c7",
  "created": "2018-05-21T12:18:33.1966321-07:00",
  "lastActivity": "2018-05-21T12:19:21.8308689-07:00",
  "pageViews": [
    {
      "id": "05213323c0c6289c1e015fe1aeffdb32f59ccce3",
      "startTime": "2018-05-21T12:18:33.3178689-07:00",
      "endTime": "2018-05-21T12:19:21.8308689-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/15",
      "visitTime": 48513,
      "engagementTime": 45664,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 48513,
  "engagementTime": 45664,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.41",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=9BBMD",
    "CONDITION=111",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "2c8403bf2d0c52224c77923fa0669b8a",
  "gdpr": false
}