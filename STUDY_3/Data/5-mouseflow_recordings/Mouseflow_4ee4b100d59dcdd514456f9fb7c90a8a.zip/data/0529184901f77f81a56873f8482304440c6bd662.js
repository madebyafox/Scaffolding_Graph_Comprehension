var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["0529184901f77f81a56873f8482304440c6bd662"] = {
  "startTime": "2018-05-29T17:16:18.844909Z",
  "websitePageUrl": "/16",
  "visitTime": 92383,
  "engagementTime": 74440,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1156,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "4ee4b100d59dcdd514456f9fb7c90a8a",
    "created": "2018-05-29T17:16:18.844909+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=K7JVY",
      "CONDITION=114"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "04dc058b95ab6fcdb71514e9b4855b47",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/4ee4b100d59dcdd514456f9fb7c90a8a/play"
  },
  "events": [
    {
      "t": 0,
      "e": 0,
      "ty": 14,
      "x": 0,
      "y": 1155
    },
    {
      "t": 171,
      "e": 171,
      "ty": 0,
      "x": 1920,
      "y": 1156
    },
    {
      "t": 171,
      "e": 171,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 400,
      "e": 400,
      "ty": 2,
      "x": 566,
      "y": 645
    },
    {
      "t": 501,
      "e": 501,
      "ty": 2,
      "x": 566,
      "y": 644
    },
    {
      "t": 501,
      "e": 501,
      "ty": 41,
      "x": 52709,
      "y": 36593,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 600,
      "e": 600,
      "ty": 2,
      "x": 565,
      "y": 640
    },
    {
      "t": 755,
      "e": 755,
      "ty": 2,
      "x": 556,
      "y": 591
    },
    {
      "t": 755,
      "e": 755,
      "ty": 41,
      "x": 51585,
      "y": 61573,
      "ta": "> div.stimulus > div > div:[2]"
    },
    {
      "t": 779,
      "e": 779,
      "ty": 6,
      "x": 556,
      "y": 565,
      "ta": "#strategyAnswer"
    },
    {
      "t": 801,
      "e": 801,
      "ty": 2,
      "x": 556,
      "y": 552
    },
    {
      "t": 901,
      "e": 901,
      "ty": 2,
      "x": 557,
      "y": 528
    },
    {
      "t": 1000,
      "e": 1000,
      "ty": 2,
      "x": 556,
      "y": 527
    },
    {
      "t": 1000,
      "e": 1000,
      "ty": 41,
      "x": 51585,
      "y": 21250,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1401,
      "e": 1401,
      "ty": 2,
      "x": 552,
      "y": 526
    },
    {
      "t": 1500,
      "e": 1500,
      "ty": 2,
      "x": 552,
      "y": 527
    },
    {
      "t": 1500,
      "e": 1500,
      "ty": 41,
      "x": 51135,
      "y": 21250,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1725,
      "e": 1725,
      "ty": 3,
      "x": 552,
      "y": 527,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1726,
      "e": 1726,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1885,
      "e": 1885,
      "ty": 4,
      "x": 51135,
      "y": 21250,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1885,
      "e": 1885,
      "ty": 5,
      "x": 552,
      "y": 527,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3200,
      "e": 3200,
      "ty": 2,
      "x": 520,
      "y": 544
    },
    {
      "t": 3250,
      "e": 3250,
      "ty": 41,
      "x": 47314,
      "y": 35814,
      "ta": "#strategyAnswer"
    },
    {
      "t": 3301,
      "e": 3301,
      "ty": 2,
      "x": 517,
      "y": 545
    },
    {
      "t": 3400,
      "e": 3400,
      "ty": 2,
      "x": 500,
      "y": 545
    },
    {
      "t": 3500,
      "e": 3500,
      "ty": 2,
      "x": 495,
      "y": 545
    },
    {
      "t": 3500,
      "e": 3500,
      "ty": 41,
      "x": 44728,
      "y": 35814,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10000,
      "e": 8500,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 12993,
      "e": 8500,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "16"
    },
    {
      "t": 13329,
      "e": 8836,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 13329,
      "e": 8836,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13409,
      "e": 8916,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "L"
    },
    {
      "t": 13416,
      "e": 8923,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "L"
    },
    {
      "t": 13512,
      "e": 9019,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 13513,
      "e": 9020,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13568,
      "e": 9075,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Lo"
    },
    {
      "t": 13665,
      "e": 9172,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 13665,
      "e": 9172,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13768,
      "e": 9275,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "75"
    },
    {
      "t": 13768,
      "e": 9275,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13825,
      "e": 9332,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look"
    },
    {
      "t": 13881,
      "e": 9388,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13985,
      "e": 9492,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13985,
      "e": 9492,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14073,
      "e": 9580,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 14073,
      "e": 9580,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14080,
      "e": 9587,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| a"
    },
    {
      "t": 14160,
      "e": 9667,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14233,
      "e": 9740,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 14233,
      "e": 9740,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14272,
      "e": 9779,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 14273,
      "e": 9780,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14345,
      "e": 9852,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t "
    },
    {
      "t": 14352,
      "e": 9859,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 14536,
      "e": 10043,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 14536,
      "e": 10043,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14632,
      "e": 10139,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||d"
    },
    {
      "t": 14713,
      "e": 10220,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 14713,
      "e": 10220,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 14801,
      "e": 10308,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 14945,
      "e": 10452,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 14945,
      "e": 10452,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15025,
      "e": 10532,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 15176,
      "e": 10683,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 15177,
      "e": 10684,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15225,
      "e": 10732,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 15225,
      "e": 10732,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15256,
      "e": 10763,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||s "
    },
    {
      "t": 15304,
      "e": 10811,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 15537,
      "e": 11044,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 15537,
      "e": 11044,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15624,
      "e": 11131,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "66"
    },
    {
      "t": 15625,
      "e": 11132,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15633,
      "e": 11140,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ab"
    },
    {
      "t": 15744,
      "e": 11251,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 15760,
      "e": 11267,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 15760,
      "e": 11267,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15872,
      "e": 11379,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||o"
    },
    {
      "t": 15912,
      "e": 11419,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "86"
    },
    {
      "t": 15912,
      "e": 11419,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 15985,
      "e": 11492,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||v"
    },
    {
      "t": 16304,
      "e": 11811,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 16304,
      "e": 11811,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16376,
      "e": 11883,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 16552,
      "e": 12059,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 16553,
      "e": 12060,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 16665,
      "e": 12172,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 17120,
      "e": 12627,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "49"
    },
    {
      "t": 17121,
      "e": 12628,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17240,
      "e": 12747,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "50"
    },
    {
      "t": 17241,
      "e": 12748,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17257,
      "e": 12764,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||12"
    },
    {
      "t": 17337,
      "e": 12844,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 17497,
      "e": 13004,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 17497,
      "e": 13004,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17585,
      "e": 13092,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 17585,
      "e": 13092,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 17641,
      "e": 13148,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||pm"
    },
    {
      "t": 17753,
      "e": 13260,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 18496,
      "e": 14003,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "13"
    },
    {
      "t": 18497,
      "e": 14004,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 18545,
      "e": 14052,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||\n"
    },
    {
      "t": 19278,
      "e": 14785,
      "ty": 7,
      "x": 419,
      "y": 597,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19300,
      "e": 14807,
      "ty": 2,
      "x": 386,
      "y": 624
    },
    {
      "t": 19310,
      "e": 14817,
      "ty": 6,
      "x": 376,
      "y": 646,
      "ta": "#strategyButton"
    },
    {
      "t": 19400,
      "e": 14907,
      "ty": 2,
      "x": 371,
      "y": 658
    },
    {
      "t": 19444,
      "e": 14951,
      "ty": 7,
      "x": 361,
      "y": 669,
      "ta": "#strategyButton"
    },
    {
      "t": 19500,
      "e": 15007,
      "ty": 2,
      "x": 343,
      "y": 677
    },
    {
      "t": 19500,
      "e": 15007,
      "ty": 41,
      "x": 11424,
      "y": 50636,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 19700,
      "e": 15207,
      "ty": 2,
      "x": 330,
      "y": 679
    },
    {
      "t": 19750,
      "e": 15257,
      "ty": 41,
      "x": 658,
      "y": 54568,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 19800,
      "e": 15307,
      "ty": 2,
      "x": 301,
      "y": 686
    },
    {
      "t": 19900,
      "e": 15407,
      "ty": 2,
      "x": 265,
      "y": 687
    },
    {
      "t": 20000,
      "e": 15507,
      "ty": 2,
      "x": 252,
      "y": 683
    },
    {
      "t": 20000,
      "e": 15507,
      "ty": 41,
      "x": 17413,
      "y": 38837,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 20000,
      "e": 15507,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20100,
      "e": 15607,
      "ty": 2,
      "x": 167,
      "y": 586
    },
    {
      "t": 20250,
      "e": 15757,
      "ty": 41,
      "x": 7858,
      "y": 63443,
      "ta": "#.strategy"
    },
    {
      "t": 20300,
      "e": 15807,
      "ty": 2,
      "x": 178,
      "y": 585
    },
    {
      "t": 20401,
      "e": 15908,
      "ty": 2,
      "x": 253,
      "y": 620
    },
    {
      "t": 20500,
      "e": 16007,
      "ty": 2,
      "x": 262,
      "y": 630
    },
    {
      "t": 20501,
      "e": 16008,
      "ty": 41,
      "x": 18537,
      "y": 35788,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 20600,
      "e": 16107,
      "ty": 2,
      "x": 260,
      "y": 659
    },
    {
      "t": 20700,
      "e": 16207,
      "ty": 2,
      "x": 250,
      "y": 673
    },
    {
      "t": 20750,
      "e": 16257,
      "ty": 41,
      "x": 16401,
      "y": 38550,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 20801,
      "e": 16308,
      "ty": 2,
      "x": 236,
      "y": 685
    },
    {
      "t": 20900,
      "e": 16407,
      "ty": 2,
      "x": 235,
      "y": 690
    },
    {
      "t": 21000,
      "e": 16507,
      "ty": 41,
      "x": 15502,
      "y": 39240,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 21100,
      "e": 16607,
      "ty": 2,
      "x": 233,
      "y": 692
    },
    {
      "t": 21251,
      "e": 16758,
      "ty": 41,
      "x": 15277,
      "y": 39355,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 21400,
      "e": 16907,
      "ty": 2,
      "x": 233,
      "y": 693
    },
    {
      "t": 21501,
      "e": 17008,
      "ty": 41,
      "x": 15277,
      "y": 39413,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 22750,
      "e": 18257,
      "ty": 41,
      "x": 15839,
      "y": 39125,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 22801,
      "e": 18308,
      "ty": 2,
      "x": 248,
      "y": 681
    },
    {
      "t": 22900,
      "e": 18407,
      "ty": 2,
      "x": 279,
      "y": 667
    },
    {
      "t": 23001,
      "e": 18508,
      "ty": 2,
      "x": 337,
      "y": 651
    },
    {
      "t": 23001,
      "e": 18508,
      "ty": 41,
      "x": 8616,
      "y": 33596,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 23014,
      "e": 18521,
      "ty": 6,
      "x": 346,
      "y": 648,
      "ta": "#strategyButton"
    },
    {
      "t": 23100,
      "e": 18607,
      "ty": 2,
      "x": 369,
      "y": 645
    },
    {
      "t": 23200,
      "e": 18707,
      "ty": 2,
      "x": 382,
      "y": 644
    },
    {
      "t": 23250,
      "e": 18757,
      "ty": 41,
      "x": 23705,
      "y": 19786,
      "ta": "#strategyButton"
    },
    {
      "t": 23301,
      "e": 18808,
      "ty": 2,
      "x": 386,
      "y": 641
    },
    {
      "t": 23400,
      "e": 18907,
      "ty": 2,
      "x": 389,
      "y": 640
    },
    {
      "t": 23500,
      "e": 19007,
      "ty": 41,
      "x": 27528,
      "y": 14004,
      "ta": "#strategyButton"
    },
    {
      "t": 24485,
      "e": 19992,
      "ty": 3,
      "x": 389,
      "y": 640,
      "ta": "#strategyButton"
    },
    {
      "t": 24485,
      "e": 19992,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "Look at dots above 12pm\n"
    },
    {
      "t": 24485,
      "e": 19992,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 24486,
      "e": 19993,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 24573,
      "e": 20080,
      "ty": 4,
      "x": 27528,
      "y": 14004,
      "ta": "#strategyButton"
    },
    {
      "t": 24581,
      "e": 20088,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 24583,
      "e": 20090,
      "ty": 5,
      "x": 389,
      "y": 640,
      "ta": "#strategyButton"
    },
    {
      "t": 24587,
      "e": 20094,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 25586,
      "e": 21093,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 26100,
      "e": 21607,
      "ty": 2,
      "x": 397,
      "y": 636
    },
    {
      "t": 26200,
      "e": 21707,
      "ty": 6,
      "x": 839,
      "y": 552,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 26200,
      "e": 21707,
      "ty": 2,
      "x": 839,
      "y": 552
    },
    {
      "t": 26249,
      "e": 21756,
      "ty": 41,
      "x": 37850,
      "y": 3120,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 26300,
      "e": 21807,
      "ty": 2,
      "x": 1021,
      "y": 532
    },
    {
      "t": 26333,
      "e": 21840,
      "ty": 7,
      "x": 1029,
      "y": 531,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 26400,
      "e": 21907,
      "ty": 2,
      "x": 1029,
      "y": 531
    },
    {
      "t": 26500,
      "e": 22007,
      "ty": 41,
      "x": 47799,
      "y": 44394,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 26508,
      "e": 22015,
      "ty": 3,
      "x": 1029,
      "y": 531,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 26612,
      "e": 22119,
      "ty": 4,
      "x": 47799,
      "y": 44394,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 26613,
      "e": 22120,
      "ty": 5,
      "x": 1029,
      "y": 531,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 26734,
      "e": 22241,
      "ty": 6,
      "x": 1021,
      "y": 532,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 26750,
      "e": 22257,
      "ty": 41,
      "x": 45420,
      "y": 6241,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 26800,
      "e": 22307,
      "ty": 2,
      "x": 1017,
      "y": 535
    },
    {
      "t": 26908,
      "e": 22415,
      "ty": 3,
      "x": 1017,
      "y": 535,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 26909,
      "e": 22416,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 26972,
      "e": 22479,
      "ty": 4,
      "x": 45204,
      "y": 9362,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 26973,
      "e": 22480,
      "ty": 5,
      "x": 1017,
      "y": 535,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 27001,
      "e": 22508,
      "ty": 41,
      "x": 45204,
      "y": 9362,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 27544,
      "e": 23051,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "98"
    },
    {
      "t": 27544,
      "e": 23051,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 27608,
      "e": 23115,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 27688,
      "e": 23195,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "98"
    },
    {
      "t": 27688,
      "e": 23195,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 27744,
      "e": 23251,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "22"
    },
    {
      "t": 28385,
      "e": 23892,
      "ty": 7,
      "x": 997,
      "y": 567,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 28400,
      "e": 23907,
      "ty": 2,
      "x": 997,
      "y": 567
    },
    {
      "t": 28418,
      "e": 23925,
      "ty": 6,
      "x": 970,
      "y": 625,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 28435,
      "e": 23942,
      "ty": 7,
      "x": 964,
      "y": 649,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 28452,
      "e": 23959,
      "ty": 6,
      "x": 961,
      "y": 659,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 28500,
      "e": 24007,
      "ty": 2,
      "x": 956,
      "y": 670
    },
    {
      "t": 28500,
      "e": 24007,
      "ty": 41,
      "x": 30963,
      "y": 31774,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 28600,
      "e": 24107,
      "ty": 2,
      "x": 957,
      "y": 671
    },
    {
      "t": 28701,
      "e": 24208,
      "ty": 2,
      "x": 964,
      "y": 656
    },
    {
      "t": 28701,
      "e": 24208,
      "ty": 7,
      "x": 964,
      "y": 650,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 28719,
      "e": 24226,
      "ty": 6,
      "x": 964,
      "y": 644,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 28750,
      "e": 24257,
      "ty": 41,
      "x": 33740,
      "y": 46810,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 28801,
      "e": 24308,
      "ty": 2,
      "x": 964,
      "y": 635
    },
    {
      "t": 28900,
      "e": 24407,
      "ty": 2,
      "x": 964,
      "y": 633
    },
    {
      "t": 29001,
      "e": 24508,
      "ty": 2,
      "x": 965,
      "y": 630
    },
    {
      "t": 29001,
      "e": 24508,
      "ty": 41,
      "x": 33957,
      "y": 15603,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 29060,
      "e": 24567,
      "ty": 3,
      "x": 965,
      "y": 630,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 29061,
      "e": 24568,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "22"
    },
    {
      "t": 29061,
      "e": 24568,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 29061,
      "e": 24568,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 29127,
      "e": 24634,
      "ty": 4,
      "x": 33957,
      "y": 12482,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 29127,
      "e": 24634,
      "ty": 5,
      "x": 965,
      "y": 629,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 29204,
      "e": 24711,
      "ty": 2,
      "x": 965,
      "y": 629
    },
    {
      "t": 29254,
      "e": 24761,
      "ty": 41,
      "x": 33957,
      "y": 12482,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 29619,
      "e": 25126,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 29931,
      "e": 25438,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 29931,
      "e": 25438,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 30003,
      "e": 25510,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 30027,
      "e": 25534,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "S"
    },
    {
      "t": 30035,
      "e": 25542,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "S"
    },
    {
      "t": 30099,
      "e": 25606,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "79"
    },
    {
      "t": 30099,
      "e": 25606,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 30171,
      "e": 25678,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 30171,
      "e": 25678,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 30228,
      "e": 25735,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Sou"
    },
    {
      "t": 30284,
      "e": 25791,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "84"
    },
    {
      "t": 30284,
      "e": 25791,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 30291,
      "e": 25798,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Sout"
    },
    {
      "t": 30363,
      "e": 25870,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 30411,
      "e": 25918,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "72"
    },
    {
      "t": 30411,
      "e": 25918,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 30467,
      "e": 25974,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||h"
    },
    {
      "t": 30604,
      "e": 26111,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "South"
    },
    {
      "t": 30611,
      "e": 26118,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "32"
    },
    {
      "t": 30611,
      "e": 26118,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 30619,
      "e": 26126,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 30667,
      "e": 26174,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+|| "
    },
    {
      "t": 30804,
      "e": 26311,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "75"
    },
    {
      "t": 30804,
      "e": 26311,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 30812,
      "e": 26319,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||K"
    },
    {
      "t": 30939,
      "e": 26446,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "79"
    },
    {
      "t": 30940,
      "e": 26447,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 30971,
      "e": 26478,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||o"
    },
    {
      "t": 31028,
      "e": 26535,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "82"
    },
    {
      "t": 31028,
      "e": 26535,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 31043,
      "e": 26550,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||r"
    },
    {
      "t": 31075,
      "e": 26582,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "69"
    },
    {
      "t": 31076,
      "e": 26583,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 31123,
      "e": 26630,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||e"
    },
    {
      "t": 31187,
      "e": 26694,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||"
    },
    {
      "t": 31259,
      "e": 26766,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 31259,
      "e": 26766,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 31331,
      "e": 26838,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "+||a"
    },
    {
      "t": 31874,
      "e": 27381,
      "ty": 7,
      "x": 967,
      "y": 650,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 31892,
      "e": 27399,
      "ty": 6,
      "x": 966,
      "y": 658,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 31903,
      "e": 27410,
      "ty": 2,
      "x": 966,
      "y": 658
    },
    {
      "t": 32004,
      "e": 27511,
      "ty": 2,
      "x": 965,
      "y": 663
    },
    {
      "t": 32004,
      "e": 27511,
      "ty": 41,
      "x": 35602,
      "y": 17873,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 32103,
      "e": 27610,
      "ty": 3,
      "x": 965,
      "y": 663,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 32104,
      "e": 27611,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "South Korea"
    },
    {
      "t": 32104,
      "e": 27611,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 32104,
      "e": 27611,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 32168,
      "e": 27675,
      "ty": 4,
      "x": 35602,
      "y": 17873,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 32168,
      "e": 27675,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 32168,
      "e": 27675,
      "ty": 5,
      "x": 965,
      "y": 663,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 32169,
      "e": 27676,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 32603,
      "e": 28110,
      "ty": 2,
      "x": 932,
      "y": 690
    },
    {
      "t": 32704,
      "e": 28211,
      "ty": 2,
      "x": 898,
      "y": 718
    },
    {
      "t": 32754,
      "e": 28261,
      "ty": 41,
      "x": 30305,
      "y": 41599,
      "ta": "html > body"
    },
    {
      "t": 32803,
      "e": 28310,
      "ty": 2,
      "x": 872,
      "y": 754
    },
    {
      "t": 32903,
      "e": 28410,
      "ty": 2,
      "x": 869,
      "y": 757
    },
    {
      "t": 33003,
      "e": 28510,
      "ty": 41,
      "x": 29650,
      "y": 43095,
      "ta": "html > body"
    },
    {
      "t": 33179,
      "e": 28686,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 33895,
      "e": 29402,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 33903,
      "e": 29410,
      "ty": 2,
      "x": 1009,
      "y": 51
    },
    {
      "t": 34003,
      "e": 29510,
      "ty": 41,
      "x": 34472,
      "y": 2474,
      "ta": "html > body"
    },
    {
      "t": 34103,
      "e": 29610,
      "ty": 2,
      "x": 1042,
      "y": 96
    },
    {
      "t": 34203,
      "e": 29710,
      "ty": 2,
      "x": 990,
      "y": 190
    },
    {
      "t": 34253,
      "e": 29760,
      "ty": 41,
      "x": 36210,
      "y": 18250,
      "ta": "#jspsych-survey-multi-choice-0"
    },
    {
      "t": 34303,
      "e": 29810,
      "ty": 2,
      "x": 923,
      "y": 210
    },
    {
      "t": 34402,
      "e": 29909,
      "ty": 2,
      "x": 840,
      "y": 216
    },
    {
      "t": 34455,
      "e": 29962,
      "ty": 6,
      "x": 838,
      "y": 216,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 34503,
      "e": 30010,
      "ty": 2,
      "x": 830,
      "y": 213
    },
    {
      "t": 34503,
      "e": 30010,
      "ty": 41,
      "x": 18037,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 34526,
      "e": 30033,
      "ty": 7,
      "x": 825,
      "y": 212,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 34602,
      "e": 30109,
      "ty": 2,
      "x": 824,
      "y": 211
    },
    {
      "t": 34753,
      "e": 30260,
      "ty": 41,
      "x": 2111,
      "y": 13107,
      "ta": "#jspsych-survey-multi-choice-option-0-0 > label"
    },
    {
      "t": 34824,
      "e": 30331,
      "ty": 6,
      "x": 827,
      "y": 212,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 34903,
      "e": 30410,
      "ty": 2,
      "x": 832,
      "y": 216
    },
    {
      "t": 34960,
      "e": 30467,
      "ty": 7,
      "x": 837,
      "y": 224,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 35003,
      "e": 30510,
      "ty": 2,
      "x": 838,
      "y": 228
    },
    {
      "t": 35003,
      "e": 30510,
      "ty": 41,
      "x": 3934,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 35060,
      "e": 30567,
      "ty": 6,
      "x": 839,
      "y": 238,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 35103,
      "e": 30610,
      "ty": 2,
      "x": 839,
      "y": 244
    },
    {
      "t": 35160,
      "e": 30667,
      "ty": 7,
      "x": 839,
      "y": 252,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 35203,
      "e": 30710,
      "ty": 2,
      "x": 839,
      "y": 255
    },
    {
      "t": 35253,
      "e": 30760,
      "ty": 41,
      "x": 4171,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-0-2"
    },
    {
      "t": 35303,
      "e": 30810,
      "ty": 2,
      "x": 840,
      "y": 266
    },
    {
      "t": 35403,
      "e": 30910,
      "ty": 2,
      "x": 841,
      "y": 282
    },
    {
      "t": 35502,
      "e": 31009,
      "ty": 2,
      "x": 839,
      "y": 290
    },
    {
      "t": 35503,
      "e": 31010,
      "ty": 41,
      "x": 4171,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-0-3"
    },
    {
      "t": 35603,
      "e": 31110,
      "ty": 2,
      "x": 836,
      "y": 292
    },
    {
      "t": 35703,
      "e": 31110,
      "ty": 2,
      "x": 832,
      "y": 292
    },
    {
      "t": 35753,
      "e": 31160,
      "ty": 41,
      "x": 8515,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 35803,
      "e": 31210,
      "ty": 2,
      "x": 830,
      "y": 292
    },
    {
      "t": 35903,
      "e": 31310,
      "ty": 2,
      "x": 825,
      "y": 300
    },
    {
      "t": 36000,
      "e": 31407,
      "ty": 3,
      "x": 825,
      "y": 305,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 36002,
      "e": 31409,
      "ty": 2,
      "x": 825,
      "y": 305
    },
    {
      "t": 36002,
      "e": 31409,
      "ty": 41,
      "x": 3552,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 36080,
      "e": 31487,
      "ty": 4,
      "x": 3552,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 36080,
      "e": 31487,
      "ty": 5,
      "x": 825,
      "y": 306,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 36080,
      "e": 31487,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 36080,
      "e": 31487,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf",
      "v": "Other"
    },
    {
      "t": 36103,
      "e": 31510,
      "ty": 2,
      "x": 825,
      "y": 306
    },
    {
      "t": 36253,
      "e": 31660,
      "ty": 41,
      "x": 3552,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-0-3 > label"
    },
    {
      "t": 36502,
      "e": 31909,
      "ty": 2,
      "x": 825,
      "y": 399
    },
    {
      "t": 36503,
      "e": 31910,
      "ty": 41,
      "x": 4188,
      "y": 52428,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 36603,
      "e": 32010,
      "ty": 2,
      "x": 825,
      "y": 432
    },
    {
      "t": 36753,
      "e": 32160,
      "ty": 41,
      "x": 849,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 37078,
      "e": 32485,
      "ty": 6,
      "x": 829,
      "y": 426,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 37103,
      "e": 32510,
      "ty": 2,
      "x": 829,
      "y": 422
    },
    {
      "t": 37129,
      "e": 32536,
      "ty": 7,
      "x": 829,
      "y": 412,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 37178,
      "e": 32585,
      "ty": 6,
      "x": 826,
      "y": 397,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 37195,
      "e": 32602,
      "ty": 7,
      "x": 825,
      "y": 393,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 37203,
      "e": 32610,
      "ty": 2,
      "x": 825,
      "y": 393
    },
    {
      "t": 37252,
      "e": 32659,
      "ty": 41,
      "x": 0,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 37303,
      "e": 32710,
      "ty": 2,
      "x": 821,
      "y": 381
    },
    {
      "t": 37403,
      "e": 32810,
      "ty": 2,
      "x": 821,
      "y": 376
    },
    {
      "t": 37503,
      "e": 32910,
      "ty": 2,
      "x": 823,
      "y": 375
    },
    {
      "t": 37503,
      "e": 32910,
      "ty": 41,
      "x": 374,
      "y": 11373,
      "ta": "#jspsych-survey-multi-choice-1"
    },
    {
      "t": 37753,
      "e": 33160,
      "ty": 41,
      "x": 4188,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 37762,
      "e": 33169,
      "ty": 6,
      "x": 827,
      "y": 391,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 37796,
      "e": 33203,
      "ty": 7,
      "x": 830,
      "y": 401,
      "ta": "jspsych-survey-multi-choice-response-1[0]_mf"
    },
    {
      "t": 37803,
      "e": 33210,
      "ty": 2,
      "x": 830,
      "y": 401
    },
    {
      "t": 37845,
      "e": 33252,
      "ty": 6,
      "x": 833,
      "y": 415,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 37903,
      "e": 33310,
      "ty": 2,
      "x": 834,
      "y": 426
    },
    {
      "t": 37913,
      "e": 33320,
      "ty": 7,
      "x": 834,
      "y": 427,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 38003,
      "e": 33410,
      "ty": 2,
      "x": 833,
      "y": 428
    },
    {
      "t": 38003,
      "e": 33410,
      "ty": 41,
      "x": 9248,
      "y": 55704,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 38203,
      "e": 33610,
      "ty": 2,
      "x": 828,
      "y": 427
    },
    {
      "t": 38213,
      "e": 33620,
      "ty": 6,
      "x": 828,
      "y": 425,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 38253,
      "e": 33660,
      "ty": 41,
      "x": 7955,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 38303,
      "e": 33710,
      "ty": 2,
      "x": 827,
      "y": 418
    },
    {
      "t": 38336,
      "e": 33743,
      "ty": 7,
      "x": 827,
      "y": 413,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 38403,
      "e": 33810,
      "ty": 2,
      "x": 829,
      "y": 408
    },
    {
      "t": 38503,
      "e": 33910,
      "ty": 41,
      "x": 1798,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-1-1"
    },
    {
      "t": 38603,
      "e": 34010,
      "ty": 2,
      "x": 834,
      "y": 413
    },
    {
      "t": 38613,
      "e": 34020,
      "ty": 6,
      "x": 836,
      "y": 417,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 38629,
      "e": 34036,
      "ty": 7,
      "x": 837,
      "y": 427,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 38663,
      "e": 34070,
      "ty": 6,
      "x": 837,
      "y": 454,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 38680,
      "e": 34087,
      "ty": 7,
      "x": 838,
      "y": 464,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 38697,
      "e": 34088,
      "ty": 6,
      "x": 838,
      "y": 475,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 38703,
      "e": 34094,
      "ty": 2,
      "x": 838,
      "y": 475
    },
    {
      "t": 38713,
      "e": 34104,
      "ty": 7,
      "x": 838,
      "y": 483,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 38753,
      "e": 34144,
      "ty": 41,
      "x": 3934,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-1-4"
    },
    {
      "t": 38803,
      "e": 34194,
      "ty": 2,
      "x": 838,
      "y": 495
    },
    {
      "t": 38840,
      "e": 34231,
      "ty": 6,
      "x": 839,
      "y": 498,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 38903,
      "e": 34294,
      "ty": 2,
      "x": 839,
      "y": 505
    },
    {
      "t": 38946,
      "e": 34337,
      "ty": 7,
      "x": 840,
      "y": 510,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 39003,
      "e": 34394,
      "ty": 2,
      "x": 840,
      "y": 510
    },
    {
      "t": 39003,
      "e": 34394,
      "ty": 41,
      "x": 21741,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-option-1-4 > label"
    },
    {
      "t": 39103,
      "e": 34494,
      "ty": 2,
      "x": 840,
      "y": 501
    },
    {
      "t": 39203,
      "e": 34594,
      "ty": 2,
      "x": 840,
      "y": 490
    },
    {
      "t": 39253,
      "e": 34644,
      "ty": 41,
      "x": 17572,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 39303,
      "e": 34694,
      "ty": 2,
      "x": 841,
      "y": 476
    },
    {
      "t": 39403,
      "e": 34794,
      "ty": 2,
      "x": 841,
      "y": 474
    },
    {
      "t": 39503,
      "e": 34894,
      "ty": 2,
      "x": 840,
      "y": 473
    },
    {
      "t": 39503,
      "e": 34894,
      "ty": 41,
      "x": 16674,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 39504,
      "e": 34895,
      "ty": 6,
      "x": 838,
      "y": 473,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 39581,
      "e": 34972,
      "ty": 7,
      "x": 825,
      "y": 473,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 39603,
      "e": 34994,
      "ty": 2,
      "x": 819,
      "y": 475
    },
    {
      "t": 39703,
      "e": 35094,
      "ty": 2,
      "x": 815,
      "y": 476
    },
    {
      "t": 39711,
      "e": 35102,
      "ty": 3,
      "x": 816,
      "y": 475,
      "ta": "html > body"
    },
    {
      "t": 39712,
      "e": 35103,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[3]_mf"
    },
    {
      "t": 39753,
      "e": 35144,
      "ty": 41,
      "x": 27825,
      "y": 26869,
      "ta": "html > body"
    },
    {
      "t": 39759,
      "e": 35150,
      "ty": 4,
      "x": 27825,
      "y": 26869,
      "ta": "html > body"
    },
    {
      "t": 39759,
      "e": 35150,
      "ty": 5,
      "x": 816,
      "y": 475,
      "ta": "html > body"
    },
    {
      "t": 39803,
      "e": 35194,
      "ty": 2,
      "x": 818,
      "y": 475
    },
    {
      "t": 39903,
      "e": 35294,
      "ty": 2,
      "x": 822,
      "y": 475
    },
    {
      "t": 39964,
      "e": 35355,
      "ty": 6,
      "x": 826,
      "y": 475,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 40003,
      "e": 35394,
      "ty": 2,
      "x": 828,
      "y": 475
    },
    {
      "t": 40003,
      "e": 35394,
      "ty": 41,
      "x": 7955,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 40103,
      "e": 35494,
      "ty": 2,
      "x": 830,
      "y": 474
    },
    {
      "t": 40144,
      "e": 35535,
      "ty": 3,
      "x": 830,
      "y": 474,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 40144,
      "e": 35535,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 40224,
      "e": 35615,
      "ty": 4,
      "x": 18037,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 40224,
      "e": 35615,
      "ty": 5,
      "x": 830,
      "y": 474,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 40224,
      "e": 35615,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf",
      "v": "Fourth"
    },
    {
      "t": 40253,
      "e": 35644,
      "ty": 41,
      "x": 18037,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 40383,
      "e": 35774,
      "ty": 7,
      "x": 833,
      "y": 493,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 40398,
      "e": 35789,
      "ty": 6,
      "x": 837,
      "y": 506,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 40403,
      "e": 35794,
      "ty": 2,
      "x": 837,
      "y": 506
    },
    {
      "t": 40414,
      "e": 35805,
      "ty": 7,
      "x": 847,
      "y": 542,
      "ta": "jspsych-survey-multi-choice-response-1[4]_mf"
    },
    {
      "t": 40503,
      "e": 35894,
      "ty": 2,
      "x": 871,
      "y": 683
    },
    {
      "t": 40503,
      "e": 35894,
      "ty": 41,
      "x": 12492,
      "y": 39321,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 40581,
      "e": 35972,
      "ty": 6,
      "x": 830,
      "y": 704,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 40598,
      "e": 35989,
      "ty": 7,
      "x": 824,
      "y": 707,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 40603,
      "e": 35994,
      "ty": 2,
      "x": 824,
      "y": 707
    },
    {
      "t": 40688,
      "e": 36079,
      "ty": 6,
      "x": 829,
      "y": 705,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 40703,
      "e": 36094,
      "ty": 2,
      "x": 830,
      "y": 703
    },
    {
      "t": 40715,
      "e": 36106,
      "ty": 7,
      "x": 837,
      "y": 698,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 40753,
      "e": 36144,
      "ty": 41,
      "x": 5121,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 40803,
      "e": 36194,
      "ty": 2,
      "x": 850,
      "y": 690
    },
    {
      "t": 40903,
      "e": 36294,
      "ty": 2,
      "x": 873,
      "y": 674
    },
    {
      "t": 41003,
      "e": 36394,
      "ty": 2,
      "x": 875,
      "y": 672
    },
    {
      "t": 41003,
      "e": 36394,
      "ty": 41,
      "x": 13500,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 41254,
      "e": 36645,
      "ty": 41,
      "x": 13248,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 41303,
      "e": 36694,
      "ty": 2,
      "x": 873,
      "y": 672
    },
    {
      "t": 41403,
      "e": 36794,
      "ty": 2,
      "x": 867,
      "y": 673
    },
    {
      "t": 41503,
      "e": 36894,
      "ty": 2,
      "x": 860,
      "y": 676
    },
    {
      "t": 41503,
      "e": 36894,
      "ty": 41,
      "x": 9720,
      "y": 16383,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 42003,
      "e": 37394,
      "ty": 2,
      "x": 840,
      "y": 666
    },
    {
      "t": 42004,
      "e": 37394,
      "ty": 41,
      "x": 4409,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 42103,
      "e": 37493,
      "ty": 2,
      "x": 839,
      "y": 665
    },
    {
      "t": 42253,
      "e": 37643,
      "ty": 41,
      "x": 3934,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 42303,
      "e": 37693,
      "ty": 2,
      "x": 838,
      "y": 665
    },
    {
      "t": 42404,
      "e": 37794,
      "ty": 2,
      "x": 837,
      "y": 665
    },
    {
      "t": 42450,
      "e": 37840,
      "ty": 6,
      "x": 835,
      "y": 658,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 42503,
      "e": 37893,
      "ty": 2,
      "x": 834,
      "y": 653
    },
    {
      "t": 42503,
      "e": 37893,
      "ty": 41,
      "x": 38202,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 42604,
      "e": 37994,
      "ty": 2,
      "x": 834,
      "y": 652
    },
    {
      "t": 42753,
      "e": 38143,
      "ty": 41,
      "x": 23079,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 42766,
      "e": 38156,
      "ty": 7,
      "x": 829,
      "y": 659,
      "ta": "jspsych-survey-multi-choice-response-2[0]_mf"
    },
    {
      "t": 42803,
      "e": 38193,
      "ty": 2,
      "x": 826,
      "y": 666
    },
    {
      "t": 42903,
      "e": 38293,
      "ty": 2,
      "x": 823,
      "y": 675
    },
    {
      "t": 43003,
      "e": 38393,
      "ty": 2,
      "x": 823,
      "y": 680
    },
    {
      "t": 43003,
      "e": 38393,
      "ty": 41,
      "x": 397,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 43103,
      "e": 38493,
      "ty": 2,
      "x": 825,
      "y": 683
    },
    {
      "t": 43203,
      "e": 38593,
      "ty": 2,
      "x": 832,
      "y": 699
    },
    {
      "t": 43234,
      "e": 38624,
      "ty": 6,
      "x": 834,
      "y": 705,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 43253,
      "e": 38643,
      "ty": 41,
      "x": 38202,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 43303,
      "e": 38693,
      "ty": 2,
      "x": 836,
      "y": 711
    },
    {
      "t": 43316,
      "e": 38706,
      "ty": 7,
      "x": 837,
      "y": 715,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 43403,
      "e": 38793,
      "ty": 2,
      "x": 837,
      "y": 721
    },
    {
      "t": 43503,
      "e": 38893,
      "ty": 2,
      "x": 837,
      "y": 722
    },
    {
      "t": 43504,
      "e": 38894,
      "ty": 41,
      "x": 3697,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 43603,
      "e": 38993,
      "ty": 2,
      "x": 830,
      "y": 722
    },
    {
      "t": 43753,
      "e": 39143,
      "ty": 41,
      "x": 1798,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 43803,
      "e": 39193,
      "ty": 2,
      "x": 829,
      "y": 715
    },
    {
      "t": 43817,
      "e": 39207,
      "ty": 6,
      "x": 829,
      "y": 712,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 43903,
      "e": 39293,
      "ty": 2,
      "x": 829,
      "y": 712
    },
    {
      "t": 44004,
      "e": 39394,
      "ty": 41,
      "x": 12996,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 44167,
      "e": 39557,
      "ty": 7,
      "x": 830,
      "y": 698,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 44203,
      "e": 39593,
      "ty": 2,
      "x": 832,
      "y": 695
    },
    {
      "t": 44254,
      "e": 39644,
      "ty": 41,
      "x": 2510,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 44303,
      "e": 39693,
      "ty": 2,
      "x": 832,
      "y": 693
    },
    {
      "t": 44503,
      "e": 39893,
      "ty": 2,
      "x": 833,
      "y": 694
    },
    {
      "t": 44503,
      "e": 39893,
      "ty": 41,
      "x": 2747,
      "y": 63194,
      "ta": "#jspsych-survey-multi-choice-option-2-1"
    },
    {
      "t": 44704,
      "e": 40094,
      "ty": 2,
      "x": 833,
      "y": 697
    },
    {
      "t": 44754,
      "e": 40144,
      "ty": 41,
      "x": 2747,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 44803,
      "e": 40193,
      "ty": 2,
      "x": 833,
      "y": 700
    },
    {
      "t": 45004,
      "e": 40394,
      "ty": 41,
      "x": 2905,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-2-2 > label"
    },
    {
      "t": 47039,
      "e": 42429,
      "ty": 6,
      "x": 832,
      "y": 702,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 47103,
      "e": 42493,
      "ty": 2,
      "x": 831,
      "y": 703
    },
    {
      "t": 47203,
      "e": 42593,
      "ty": 2,
      "x": 830,
      "y": 706
    },
    {
      "t": 47253,
      "e": 42643,
      "ty": 41,
      "x": 18037,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 47503,
      "e": 42893,
      "ty": 3,
      "x": 830,
      "y": 706,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 47504,
      "e": 42894,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[3]_mf"
    },
    {
      "t": 47504,
      "e": 42894,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 47616,
      "e": 43006,
      "ty": 4,
      "x": 18037,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 47616,
      "e": 43006,
      "ty": 5,
      "x": 830,
      "y": 706,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 47616,
      "e": 43006,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf",
      "v": "Biomedical & Health Sciences"
    },
    {
      "t": 48803,
      "e": 44193,
      "ty": 2,
      "x": 830,
      "y": 708
    },
    {
      "t": 48903,
      "e": 44293,
      "ty": 2,
      "x": 829,
      "y": 711
    },
    {
      "t": 49003,
      "e": 44393,
      "ty": 2,
      "x": 829,
      "y": 713
    },
    {
      "t": 49004,
      "e": 44394,
      "ty": 41,
      "x": 12996,
      "y": 55452,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 49023,
      "e": 44413,
      "ty": 7,
      "x": 829,
      "y": 715,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 49103,
      "e": 44493,
      "ty": 2,
      "x": 829,
      "y": 718
    },
    {
      "t": 49203,
      "e": 44593,
      "ty": 2,
      "x": 829,
      "y": 727
    },
    {
      "t": 49239,
      "e": 44629,
      "ty": 6,
      "x": 829,
      "y": 730,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 49253,
      "e": 44643,
      "ty": 41,
      "x": 12996,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 49303,
      "e": 44693,
      "ty": 2,
      "x": 829,
      "y": 732
    },
    {
      "t": 49403,
      "e": 44793,
      "ty": 2,
      "x": 829,
      "y": 735
    },
    {
      "t": 49455,
      "e": 44845,
      "ty": 7,
      "x": 829,
      "y": 743,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 49503,
      "e": 44893,
      "ty": 2,
      "x": 829,
      "y": 751
    },
    {
      "t": 49504,
      "e": 44894,
      "ty": 41,
      "x": 1798,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 49555,
      "e": 44945,
      "ty": 6,
      "x": 829,
      "y": 758,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 49603,
      "e": 44993,
      "ty": 2,
      "x": 829,
      "y": 759
    },
    {
      "t": 49704,
      "e": 45094,
      "ty": 2,
      "x": 830,
      "y": 761
    },
    {
      "t": 49754,
      "e": 45144,
      "ty": 41,
      "x": 18037,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 49803,
      "e": 45193,
      "ty": 2,
      "x": 830,
      "y": 765
    },
    {
      "t": 49895,
      "e": 45285,
      "ty": 7,
      "x": 832,
      "y": 771,
      "ta": "jspsych-survey-multi-choice-response-2[4]_mf"
    },
    {
      "t": 49903,
      "e": 45293,
      "ty": 2,
      "x": 832,
      "y": 771
    },
    {
      "t": 50003,
      "e": 45393,
      "ty": 2,
      "x": 832,
      "y": 777
    },
    {
      "t": 50003,
      "e": 45393,
      "ty": 41,
      "x": 2510,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-4"
    },
    {
      "t": 50003,
      "e": 45393,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 50103,
      "e": 45493,
      "ty": 2,
      "x": 833,
      "y": 783
    },
    {
      "t": 50123,
      "e": 45513,
      "ty": 6,
      "x": 834,
      "y": 787,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 50204,
      "e": 45594,
      "ty": 2,
      "x": 835,
      "y": 791
    },
    {
      "t": 50254,
      "e": 45644,
      "ty": 41,
      "x": 43243,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 50303,
      "e": 45693,
      "ty": 2,
      "x": 835,
      "y": 794
    },
    {
      "t": 50403,
      "e": 45793,
      "ty": 2,
      "x": 836,
      "y": 797
    },
    {
      "t": 50455,
      "e": 45845,
      "ty": 7,
      "x": 836,
      "y": 799,
      "ta": "jspsych-survey-multi-choice-response-2[5]_mf"
    },
    {
      "t": 50504,
      "e": 45894,
      "ty": 2,
      "x": 837,
      "y": 801
    },
    {
      "t": 50504,
      "e": 45894,
      "ty": 41,
      "x": 9194,
      "y": 58981,
      "ta": "#jspsych-survey-multi-choice-option-2-5 > label"
    },
    {
      "t": 50603,
      "e": 45993,
      "ty": 2,
      "x": 837,
      "y": 803
    },
    {
      "t": 50703,
      "e": 46093,
      "ty": 2,
      "x": 837,
      "y": 806
    },
    {
      "t": 50754,
      "e": 46144,
      "ty": 41,
      "x": 10975,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-2-6 > label"
    },
    {
      "t": 50757,
      "e": 46147,
      "ty": 6,
      "x": 837,
      "y": 815,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 50804,
      "e": 46194,
      "ty": 2,
      "x": 837,
      "y": 819
    },
    {
      "t": 50822,
      "e": 46212,
      "ty": 7,
      "x": 837,
      "y": 829,
      "ta": "jspsych-survey-multi-choice-response-2[6]_mf"
    },
    {
      "t": 50904,
      "e": 46294,
      "ty": 2,
      "x": 845,
      "y": 869
    },
    {
      "t": 51003,
      "e": 46393,
      "ty": 41,
      "x": 5595,
      "y": 37448,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 51404,
      "e": 46794,
      "ty": 2,
      "x": 846,
      "y": 869
    },
    {
      "t": 51503,
      "e": 46893,
      "ty": 41,
      "x": 5832,
      "y": 37448,
      "ta": "#jspsych-survey-multi-choice-3 > p"
    },
    {
      "t": 51703,
      "e": 47093,
      "ty": 2,
      "x": 846,
      "y": 866
    },
    {
      "t": 51754,
      "e": 47144,
      "ty": 41,
      "x": 7256,
      "y": 53130,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 51804,
      "e": 47194,
      "ty": 2,
      "x": 858,
      "y": 822
    },
    {
      "t": 51904,
      "e": 47294,
      "ty": 2,
      "x": 859,
      "y": 798
    },
    {
      "t": 52004,
      "e": 47394,
      "ty": 2,
      "x": 859,
      "y": 774
    },
    {
      "t": 52004,
      "e": 47394,
      "ty": 41,
      "x": 21037,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-4 > label"
    },
    {
      "t": 52103,
      "e": 47493,
      "ty": 2,
      "x": 854,
      "y": 752
    },
    {
      "t": 52203,
      "e": 47593,
      "ty": 2,
      "x": 852,
      "y": 743
    },
    {
      "t": 52254,
      "e": 47644,
      "ty": 41,
      "x": 12341,
      "y": 42597,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 52303,
      "e": 47693,
      "ty": 2,
      "x": 849,
      "y": 737
    },
    {
      "t": 52403,
      "e": 47793,
      "ty": 2,
      "x": 847,
      "y": 736
    },
    {
      "t": 52504,
      "e": 47894,
      "ty": 41,
      "x": 10672,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 52603,
      "e": 47993,
      "ty": 2,
      "x": 846,
      "y": 736
    },
    {
      "t": 52704,
      "e": 48094,
      "ty": 2,
      "x": 844,
      "y": 736
    },
    {
      "t": 52754,
      "e": 48144,
      "ty": 41,
      "x": 9420,
      "y": 29490,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 52904,
      "e": 48294,
      "ty": 2,
      "x": 840,
      "y": 737
    },
    {
      "t": 53004,
      "e": 48394,
      "ty": 41,
      "x": 7751,
      "y": 32767,
      "ta": "#jspsych-survey-multi-choice-option-2-3 > label"
    },
    {
      "t": 53751,
      "e": 49141,
      "ty": 6,
      "x": 838,
      "y": 737,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 53753,
      "e": 49143,
      "ty": 41,
      "x": 58367,
      "y": 35288,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 53804,
      "e": 49194,
      "ty": 2,
      "x": 837,
      "y": 737
    },
    {
      "t": 53904,
      "e": 49294,
      "ty": 2,
      "x": 834,
      "y": 737
    },
    {
      "t": 54004,
      "e": 49394,
      "ty": 2,
      "x": 832,
      "y": 736
    },
    {
      "t": 54004,
      "e": 49394,
      "ty": 41,
      "x": 28120,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 54104,
      "e": 49494,
      "ty": 2,
      "x": 829,
      "y": 736
    },
    {
      "t": 54203,
      "e": 49593,
      "ty": 2,
      "x": 828,
      "y": 736
    },
    {
      "t": 54254,
      "e": 49644,
      "ty": 41,
      "x": 7955,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 60003,
      "e": 54644,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 60287,
      "e": 54644,
      "ty": 3,
      "x": 828,
      "y": 736,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 60288,
      "e": 54645,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 60288,
      "e": 54645,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 60439,
      "e": 54796,
      "ty": 4,
      "x": 7955,
      "y": 30246,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 60439,
      "e": 54796,
      "ty": 5,
      "x": 828,
      "y": 736,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 60439,
      "e": 54796,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf",
      "v": "Natural Sciences"
    },
    {
      "t": 60882,
      "e": 55239,
      "ty": 7,
      "x": 825,
      "y": 737,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 60903,
      "e": 55260,
      "ty": 2,
      "x": 822,
      "y": 764
    },
    {
      "t": 61003,
      "e": 55360,
      "ty": 2,
      "x": 854,
      "y": 909
    },
    {
      "t": 61003,
      "e": 55360,
      "ty": 41,
      "x": 35583,
      "y": 19660,
      "ta": "#jspsych-survey-multi-choice-option-3-0 > label"
    },
    {
      "t": 61103,
      "e": 55460,
      "ty": 2,
      "x": 859,
      "y": 925
    },
    {
      "t": 61253,
      "e": 55610,
      "ty": 41,
      "x": 8918,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 61403,
      "e": 55760,
      "ty": 2,
      "x": 861,
      "y": 920
    },
    {
      "t": 61503,
      "e": 55860,
      "ty": 2,
      "x": 871,
      "y": 902
    },
    {
      "t": 61503,
      "e": 55860,
      "ty": 41,
      "x": 11766,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 61603,
      "e": 55960,
      "ty": 2,
      "x": 873,
      "y": 897
    },
    {
      "t": 61753,
      "e": 56110,
      "ty": 41,
      "x": 10816,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-3-0"
    },
    {
      "t": 61803,
      "e": 56160,
      "ty": 2,
      "x": 860,
      "y": 903
    },
    {
      "t": 61902,
      "e": 56259,
      "ty": 2,
      "x": 848,
      "y": 915
    },
    {
      "t": 62003,
      "e": 56360,
      "ty": 41,
      "x": 5358,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 62003,
      "e": 56360,
      "ty": 2,
      "x": 844,
      "y": 930
    },
    {
      "t": 62199,
      "e": 56556,
      "ty": 3,
      "x": 844,
      "y": 930,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 62199,
      "e": 56556,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 62287,
      "e": 56644,
      "ty": 4,
      "x": 5358,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 62287,
      "e": 56644,
      "ty": 5,
      "x": 844,
      "y": 930,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 62405,
      "e": 56762,
      "ty": 2,
      "x": 844,
      "y": 931
    },
    {
      "t": 62472,
      "e": 56829,
      "ty": 6,
      "x": 839,
      "y": 935,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 62503,
      "e": 56860,
      "ty": 2,
      "x": 838,
      "y": 937
    },
    {
      "t": 62503,
      "e": 56860,
      "ty": 41,
      "x": 58367,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 62702,
      "e": 57059,
      "ty": 2,
      "x": 835,
      "y": 937
    },
    {
      "t": 62753,
      "e": 57110,
      "ty": 41,
      "x": 28120,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 62803,
      "e": 57160,
      "ty": 2,
      "x": 832,
      "y": 939
    },
    {
      "t": 62839,
      "e": 57196,
      "ty": 3,
      "x": 832,
      "y": 939,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 62839,
      "e": 57196,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 62903,
      "e": 57260,
      "ty": 2,
      "x": 831,
      "y": 939
    },
    {
      "t": 62927,
      "e": 57284,
      "ty": 4,
      "x": 23079,
      "y": 25205,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 62927,
      "e": 57284,
      "ty": 5,
      "x": 831,
      "y": 939,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 62927,
      "e": 57284,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 63003,
      "e": 57360,
      "ty": 2,
      "x": 830,
      "y": 944
    },
    {
      "t": 63003,
      "e": 57360,
      "ty": 41,
      "x": 18037,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 63017,
      "e": 57374,
      "ty": 7,
      "x": 830,
      "y": 947,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 63083,
      "e": 57440,
      "ty": 6,
      "x": 859,
      "y": 985,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 63103,
      "e": 57460,
      "ty": 2,
      "x": 863,
      "y": 990
    },
    {
      "t": 63203,
      "e": 57560,
      "ty": 2,
      "x": 866,
      "y": 1000
    },
    {
      "t": 63253,
      "e": 57610,
      "ty": 41,
      "x": 18851,
      "y": 33760,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 63424,
      "e": 57781,
      "ty": 3,
      "x": 866,
      "y": 1000,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 63424,
      "e": 57781,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 63424,
      "e": 57781,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 63495,
      "e": 57852,
      "ty": 4,
      "x": 18851,
      "y": 33760,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 63495,
      "e": 57852,
      "ty": 5,
      "x": 866,
      "y": 1000,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 63497,
      "e": 57854,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 63497,
      "e": 57854,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 63498,
      "e": 57855,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 63903,
      "e": 58260,
      "ty": 2,
      "x": 866,
      "y": 945
    },
    {
      "t": 64003,
      "e": 58360,
      "ty": 2,
      "x": 835,
      "y": 727
    },
    {
      "t": 64003,
      "e": 58360,
      "ty": 41,
      "x": 28480,
      "y": 41369,
      "ta": "html > body"
    },
    {
      "t": 64103,
      "e": 58460,
      "ty": 2,
      "x": 794,
      "y": 547
    },
    {
      "t": 64203,
      "e": 58560,
      "ty": 2,
      "x": 777,
      "y": 505
    },
    {
      "t": 64253,
      "e": 58610,
      "ty": 41,
      "x": 26344,
      "y": 28193,
      "ta": "html > body"
    },
    {
      "t": 64303,
      "e": 58660,
      "ty": 2,
      "x": 769,
      "y": 490
    },
    {
      "t": 64403,
      "e": 58760,
      "ty": 2,
      "x": 755,
      "y": 469
    },
    {
      "t": 64504,
      "e": 58861,
      "ty": 41,
      "x": 25724,
      "y": 26524,
      "ta": "html > body"
    },
    {
      "t": 64703,
      "e": 59060,
      "ty": 2,
      "x": 759,
      "y": 474
    },
    {
      "t": 64753,
      "e": 59110,
      "ty": 41,
      "x": 25862,
      "y": 26812,
      "ta": "html > body"
    },
    {
      "t": 64820,
      "e": 59177,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 65503,
      "e": 59860,
      "ty": 2,
      "x": 790,
      "y": 510
    },
    {
      "t": 65503,
      "e": 59860,
      "ty": 41,
      "x": 24428,
      "y": 19309,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 65603,
      "e": 59960,
      "ty": 2,
      "x": 856,
      "y": 658
    },
    {
      "t": 65703,
      "e": 60060,
      "ty": 2,
      "x": 886,
      "y": 756
    },
    {
      "t": 65752,
      "e": 60109,
      "ty": 41,
      "x": 29840,
      "y": 47395,
      "ta": "> div.masterdiv > div:[2] > div > p:[5]"
    },
    {
      "t": 65803,
      "e": 60160,
      "ty": 2,
      "x": 901,
      "y": 839
    },
    {
      "t": 65903,
      "e": 60260,
      "ty": 2,
      "x": 910,
      "y": 860
    },
    {
      "t": 66003,
      "e": 60360,
      "ty": 2,
      "x": 1027,
      "y": 974
    },
    {
      "t": 66003,
      "e": 60360,
      "ty": 41,
      "x": 36088,
      "y": 61284,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 66102,
      "e": 60459,
      "ty": 2,
      "x": 1060,
      "y": 1058
    },
    {
      "t": 66204,
      "e": 60561,
      "ty": 2,
      "x": 1053,
      "y": 1062
    },
    {
      "t": 66253,
      "e": 60610,
      "ty": 41,
      "x": 35367,
      "y": 60529,
      "ta": "> div.masterdiv"
    },
    {
      "t": 66270,
      "e": 60627,
      "ty": 6,
      "x": 1029,
      "y": 1059,
      "ta": "#start"
    },
    {
      "t": 66303,
      "e": 60660,
      "ty": 2,
      "x": 1024,
      "y": 1056
    },
    {
      "t": 66403,
      "e": 60760,
      "ty": 2,
      "x": 1022,
      "y": 1056
    },
    {
      "t": 66504,
      "e": 60861,
      "ty": 2,
      "x": 1022,
      "y": 1055
    },
    {
      "t": 66504,
      "e": 60861,
      "ty": 41,
      "x": 61439,
      "y": 42224,
      "ta": "#start"
    },
    {
      "t": 66603,
      "e": 60960,
      "ty": 2,
      "x": 1017,
      "y": 1050
    },
    {
      "t": 66703,
      "e": 61060,
      "ty": 2,
      "x": 1016,
      "y": 1050
    },
    {
      "t": 66753,
      "e": 61110,
      "ty": 41,
      "x": 58162,
      "y": 32586,
      "ta": "#start"
    },
    {
      "t": 67403,
      "e": 61760,
      "ty": 2,
      "x": 1015,
      "y": 1049
    },
    {
      "t": 67503,
      "e": 61860,
      "ty": 2,
      "x": 1015,
      "y": 1048
    },
    {
      "t": 67503,
      "e": 61860,
      "ty": 41,
      "x": 57616,
      "y": 28731,
      "ta": "#start"
    },
    {
      "t": 68003,
      "e": 62360,
      "ty": 2,
      "x": 1015,
      "y": 1047
    },
    {
      "t": 68003,
      "e": 62360,
      "ty": 41,
      "x": 57616,
      "y": 26804,
      "ta": "#start"
    },
    {
      "t": 68103,
      "e": 62460,
      "ty": 2,
      "x": 1015,
      "y": 1045
    },
    {
      "t": 68253,
      "e": 62610,
      "ty": 41,
      "x": 57616,
      "y": 22949,
      "ta": "#start"
    },
    {
      "t": 68603,
      "e": 62960,
      "ty": 2,
      "x": 1016,
      "y": 1041
    },
    {
      "t": 68754,
      "e": 63111,
      "ty": 41,
      "x": 58162,
      "y": 15239,
      "ta": "#start"
    },
    {
      "t": 68803,
      "e": 63160,
      "ty": 2,
      "x": 1016,
      "y": 1040
    },
    {
      "t": 68903,
      "e": 63260,
      "ty": 2,
      "x": 1016,
      "y": 1035
    },
    {
      "t": 69003,
      "e": 63360,
      "ty": 2,
      "x": 1016,
      "y": 1033
    },
    {
      "t": 69003,
      "e": 63360,
      "ty": 41,
      "x": 58162,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 69015,
      "e": 63372,
      "ty": 7,
      "x": 1016,
      "y": 1032,
      "ta": "#start"
    },
    {
      "t": 69103,
      "e": 63460,
      "ty": 2,
      "x": 1017,
      "y": 1030
    },
    {
      "t": 69203,
      "e": 63560,
      "ty": 2,
      "x": 1017,
      "y": 1029
    },
    {
      "t": 69253,
      "e": 63610,
      "ty": 41,
      "x": 35596,
      "y": 65240,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 69403,
      "e": 63760,
      "ty": 2,
      "x": 1017,
      "y": 1027
    },
    {
      "t": 69504,
      "e": 63861,
      "ty": 2,
      "x": 1017,
      "y": 1026
    },
    {
      "t": 69504,
      "e": 63861,
      "ty": 41,
      "x": 35596,
      "y": 65024,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 70004,
      "e": 64361,
      "ty": 2,
      "x": 1023,
      "y": 1011
    },
    {
      "t": 70004,
      "e": 64361,
      "ty": 41,
      "x": 35891,
      "y": 63945,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 70104,
      "e": 64461,
      "ty": 2,
      "x": 1026,
      "y": 1006
    },
    {
      "t": 70203,
      "e": 64560,
      "ty": 2,
      "x": 1029,
      "y": 1009
    },
    {
      "t": 70253,
      "e": 64610,
      "ty": 41,
      "x": 36186,
      "y": 64377,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 70289,
      "e": 64646,
      "ty": 6,
      "x": 1022,
      "y": 1033,
      "ta": "#start"
    },
    {
      "t": 70303,
      "e": 64660,
      "ty": 2,
      "x": 1022,
      "y": 1033
    },
    {
      "t": 70403,
      "e": 64760,
      "ty": 2,
      "x": 1014,
      "y": 1049
    },
    {
      "t": 70503,
      "e": 64860,
      "ty": 2,
      "x": 1008,
      "y": 1054
    },
    {
      "t": 70503,
      "e": 64860,
      "ty": 41,
      "x": 53793,
      "y": 40296,
      "ta": "#start"
    },
    {
      "t": 80003,
      "e": 69860,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 87803,
      "e": 69860,
      "ty": 2,
      "x": 1007,
      "y": 1054
    },
    {
      "t": 87903,
      "e": 69960,
      "ty": 2,
      "x": 1004,
      "y": 1054
    },
    {
      "t": 88003,
      "e": 70060,
      "ty": 2,
      "x": 1002,
      "y": 1054
    },
    {
      "t": 88003,
      "e": 70060,
      "ty": 41,
      "x": 50516,
      "y": 40296,
      "ta": "#start"
    },
    {
      "t": 88103,
      "e": 70160,
      "ty": 2,
      "x": 999,
      "y": 1054
    },
    {
      "t": 88253,
      "e": 70310,
      "ty": 41,
      "x": 48332,
      "y": 42224,
      "ta": "#start"
    },
    {
      "t": 88303,
      "e": 70360,
      "ty": 2,
      "x": 997,
      "y": 1055
    },
    {
      "t": 88403,
      "e": 70460,
      "ty": 2,
      "x": 996,
      "y": 1055
    },
    {
      "t": 88503,
      "e": 70560,
      "ty": 41,
      "x": 47239,
      "y": 42224,
      "ta": "#start"
    },
    {
      "t": 88604,
      "e": 70661,
      "ty": 2,
      "x": 995,
      "y": 1056
    },
    {
      "t": 88703,
      "e": 70760,
      "ty": 2,
      "x": 992,
      "y": 1058
    },
    {
      "t": 88753,
      "e": 70810,
      "ty": 41,
      "x": 44509,
      "y": 49934,
      "ta": "#start"
    },
    {
      "t": 88803,
      "e": 70860,
      "ty": 2,
      "x": 991,
      "y": 1059
    },
    {
      "t": 88903,
      "e": 70960,
      "ty": 2,
      "x": 990,
      "y": 1059
    },
    {
      "t": 89003,
      "e": 71060,
      "ty": 41,
      "x": 43963,
      "y": 49934,
      "ta": "#start"
    },
    {
      "t": 90252,
      "e": 72309,
      "ty": 3,
      "x": 990,
      "y": 1059,
      "ta": "#start"
    },
    {
      "t": 90252,
      "e": 72309,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 90355,
      "e": 72412,
      "ty": 4,
      "x": 43963,
      "y": 49934,
      "ta": "#start"
    },
    {
      "t": 90355,
      "e": 72412,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 90356,
      "e": 72413,
      "ty": 5,
      "x": 990,
      "y": 1059,
      "ta": "#start"
    },
    {
      "t": 90356,
      "e": 72413,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 91379,
      "e": 73436,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 92383,
      "e": 74440,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 5434, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 32, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 5438, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"K7JVY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 2146, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 8675, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"K7JVY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 10420, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"OSCAR\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"114\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 20098, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"K7JVY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 1806, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 22993, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"K7JVY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 1115, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 32, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 25110, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"K7JVY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 19668, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 46043, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"K7JVY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-Z -A -A \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:868,y:687,t:1527613634649};\\\", \\\"{x:902,y:676,t:1527613634656};\\\", \\\"{x:964,y:652,t:1527613634667};\\\", \\\"{x:1068,y:614,t:1527613634685};\\\", \\\"{x:1183,y:567,t:1527613634703};\\\", \\\"{x:1290,y:520,t:1527613634717};\\\", \\\"{x:1342,y:493,t:1527613634734};\\\", \\\"{x:1348,y:490,t:1527613634751};\\\", \\\"{x:1342,y:483,t:1527613643209};\\\", \\\"{x:1329,y:472,t:1527613643224};\\\", \\\"{x:1328,y:469,t:1527613643242};\\\", \\\"{x:1327,y:468,t:1527613643264};\\\", \\\"{x:1324,y:466,t:1527613643280};\\\", \\\"{x:1316,y:466,t:1527613643292};\\\", \\\"{x:1302,y:465,t:1527613643308};\\\", \\\"{x:1289,y:464,t:1527613643325};\\\", \\\"{x:1244,y:458,t:1527613643342};\\\", \\\"{x:1088,y:429,t:1527613643357};\\\", \\\"{x:903,y:402,t:1527613643374};\\\", \\\"{x:697,y:381,t:1527613643392};\\\", \\\"{x:477,y:370,t:1527613643407};\\\", \\\"{x:247,y:371,t:1527613643424};\\\", \\\"{x:151,y:390,t:1527613643442};\\\", \\\"{x:94,y:412,t:1527613643457};\\\", \\\"{x:81,y:427,t:1527613643474};\\\", \\\"{x:67,y:438,t:1527613643491};\\\", \\\"{x:54,y:445,t:1527613643506};\\\", \\\"{x:39,y:456,t:1527613643523};\\\", \\\"{x:27,y:466,t:1527613643541};\\\", \\\"{x:19,y:477,t:1527613643557};\\\", \\\"{x:19,y:483,t:1527613643574};\\\", \\\"{x:19,y:489,t:1527613643590};\\\", \\\"{x:53,y:490,t:1527613643608};\\\", \\\"{x:122,y:490,t:1527613643623};\\\", \\\"{x:217,y:490,t:1527613643640};\\\", \\\"{x:295,y:490,t:1527613643658};\\\", \\\"{x:338,y:490,t:1527613643675};\\\", \\\"{x:350,y:490,t:1527613643691};\\\", \\\"{x:352,y:490,t:1527613643708};\\\", \\\"{x:356,y:489,t:1527613643776};\\\", \\\"{x:360,y:489,t:1527613643791};\\\", \\\"{x:369,y:486,t:1527613643808};\\\", \\\"{x:371,y:487,t:1527613644273};\\\", \\\"{x:372,y:489,t:1527613644280};\\\", \\\"{x:372,y:491,t:1527613644304};\\\", \\\"{x:373,y:492,t:1527613644320};\\\", \\\"{x:374,y:493,t:1527613644336};\\\", \\\"{x:377,y:497,t:1527613644344};\\\", \\\"{x:382,y:503,t:1527613644358};\\\", \\\"{x:390,y:518,t:1527613644375};\\\", \\\"{x:406,y:535,t:1527613644392};\\\", \\\"{x:414,y:544,t:1527613644407};\\\", \\\"{x:423,y:551,t:1527613644425};\\\", \\\"{x:429,y:555,t:1527613644443};\\\", \\\"{x:430,y:556,t:1527613644458};\\\", \\\"{x:431,y:560,t:1527613644475};\\\", \\\"{x:437,y:570,t:1527613644492};\\\", \\\"{x:441,y:577,t:1527613644508};\\\", \\\"{x:443,y:579,t:1527613644525};\\\", \\\"{x:444,y:579,t:1527613644575};\\\", \\\"{x:438,y:563,t:1527613644591};\\\", \\\"{x:429,y:544,t:1527613644609};\\\", \\\"{x:425,y:535,t:1527613644625};\\\", \\\"{x:422,y:528,t:1527613644641};\\\", \\\"{x:420,y:524,t:1527613644659};\\\", \\\"{x:416,y:519,t:1527613644675};\\\", \\\"{x:413,y:514,t:1527613644692};\\\", \\\"{x:411,y:511,t:1527613644708};\\\", \\\"{x:408,y:508,t:1527613644725};\\\", \\\"{x:406,y:506,t:1527613644742};\\\", \\\"{x:406,y:505,t:1527613644758};\\\", \\\"{x:403,y:505,t:1527613644775};\\\", \\\"{x:397,y:504,t:1527613644792};\\\", \\\"{x:390,y:504,t:1527613644809};\\\", \\\"{x:383,y:506,t:1527613644826};\\\", \\\"{x:375,y:506,t:1527613644841};\\\", \\\"{x:370,y:506,t:1527613644859};\\\", \\\"{x:369,y:506,t:1527613644876};\\\", \\\"{x:369,y:507,t:1527613645409};\\\", \\\"{x:371,y:508,t:1527613645432};\\\", \\\"{x:372,y:508,t:1527613645448};\\\", \\\"{x:373,y:508,t:1527613645464};\\\", \\\"{x:374,y:508,t:1527613645477};\\\", \\\"{x:375,y:508,t:1527613645492};\\\", \\\"{x:376,y:508,t:1527613645508};\\\", \\\"{x:378,y:508,t:1527613645525};\\\", \\\"{x:379,y:508,t:1527613645576};\\\", \\\"{x:380,y:508,t:1527613645607};\\\", \\\"{x:418,y:511,t:1527613645952};\\\", \\\"{x:501,y:538,t:1527613645961};\\\", \\\"{x:643,y:588,t:1527613645976};\\\", \\\"{x:802,y:626,t:1527613645993};\\\", \\\"{x:1006,y:670,t:1527613646010};\\\", \\\"{x:1183,y:701,t:1527613646026};\\\", \\\"{x:1235,y:712,t:1527613646042};\\\", \\\"{x:1243,y:712,t:1527613646060};\\\", \\\"{x:1242,y:712,t:1527613646077};\\\", \\\"{x:1235,y:713,t:1527613646092};\\\", \\\"{x:1224,y:717,t:1527613646110};\\\", \\\"{x:1213,y:719,t:1527613646127};\\\", \\\"{x:1190,y:719,t:1527613646143};\\\", \\\"{x:1185,y:721,t:1527613646160};\\\", \\\"{x:1183,y:721,t:1527613646199};\\\", \\\"{x:1182,y:721,t:1527613646211};\\\", \\\"{x:1177,y:723,t:1527613646227};\\\", \\\"{x:1168,y:730,t:1527613646245};\\\", \\\"{x:1148,y:739,t:1527613646260};\\\", \\\"{x:1113,y:749,t:1527613646277};\\\", \\\"{x:1050,y:755,t:1527613646294};\\\", \\\"{x:966,y:755,t:1527613646311};\\\", \\\"{x:908,y:755,t:1527613646327};\\\", \\\"{x:862,y:755,t:1527613646344};\\\", \\\"{x:829,y:755,t:1527613646361};\\\", \\\"{x:812,y:755,t:1527613646377};\\\", \\\"{x:803,y:755,t:1527613646395};\\\", \\\"{x:798,y:755,t:1527613646411};\\\", \\\"{x:795,y:755,t:1527613646427};\\\", \\\"{x:792,y:754,t:1527613646528};\\\", \\\"{x:778,y:767,t:1527613646544};\\\", \\\"{x:746,y:785,t:1527613646561};\\\", \\\"{x:714,y:799,t:1527613646579};\\\", \\\"{x:685,y:814,t:1527613646595};\\\", \\\"{x:661,y:826,t:1527613646612};\\\", \\\"{x:644,y:836,t:1527613646629};\\\", \\\"{x:639,y:840,t:1527613646645};\\\", \\\"{x:638,y:840,t:1527613646672};\\\", \\\"{x:636,y:840,t:1527613646688};\\\", \\\"{x:636,y:836,t:1527613646694};\\\", \\\"{x:637,y:828,t:1527613646711};\\\", \\\"{x:640,y:821,t:1527613646728};\\\", \\\"{x:647,y:808,t:1527613646745};\\\", \\\"{x:651,y:801,t:1527613646761};\\\", \\\"{x:653,y:799,t:1527613646778};\\\", \\\"{x:656,y:794,t:1527613646794};\\\", \\\"{x:657,y:790,t:1527613646812};\\\", \\\"{x:659,y:783,t:1527613646828};\\\", \\\"{x:659,y:774,t:1527613646845};\\\", \\\"{x:653,y:755,t:1527613646862};\\\", \\\"{x:640,y:732,t:1527613646879};\\\", \\\"{x:623,y:714,t:1527613646895};\\\", \\\"{x:604,y:697,t:1527613646912};\\\", \\\"{x:598,y:692,t:1527613646930};\\\", \\\"{x:596,y:691,t:1527613646945};\\\", \\\"{x:595,y:691,t:1527613646968};\\\", \\\"{x:595,y:690,t:1527613647017};\\\", \\\"{x:593,y:690,t:1527613647030};\\\", \\\"{x:591,y:690,t:1527613647046};\\\", \\\"{x:584,y:690,t:1527613647062};\\\", \\\"{x:576,y:690,t:1527613647079};\\\", \\\"{x:558,y:690,t:1527613647098};\\\", \\\"{x:548,y:692,t:1527613647112};\\\", \\\"{x:540,y:693,t:1527613647126};\\\", \\\"{x:536,y:694,t:1527613647144};\\\", \\\"{x:533,y:694,t:1527613647161};\\\", \\\"{x:539,y:696,t:1527613650185};\\\", \\\"{x:601,y:705,t:1527613650203};\\\", \\\"{x:663,y:710,t:1527613650218};\\\", \\\"{x:755,y:721,t:1527613650235};\\\", \\\"{x:804,y:731,t:1527613650246};\\\", \\\"{x:905,y:743,t:1527613650263};\\\", \\\"{x:949,y:753,t:1527613650279};\\\", \\\"{x:987,y:763,t:1527613650296};\\\", \\\"{x:1009,y:773,t:1527613650313};\\\", \\\"{x:1034,y:784,t:1527613650330};\\\", \\\"{x:1053,y:794,t:1527613650346};\\\", \\\"{x:1072,y:803,t:1527613650363};\\\", \\\"{x:1104,y:814,t:1527613650380};\\\", \\\"{x:1136,y:822,t:1527613650396};\\\", \\\"{x:1169,y:828,t:1527613650413};\\\", \\\"{x:1192,y:833,t:1527613650430};\\\", \\\"{x:1207,y:837,t:1527613650446};\\\", \\\"{x:1238,y:845,t:1527613650463};\\\", \\\"{x:1257,y:850,t:1527613650479};\\\", \\\"{x:1282,y:859,t:1527613650497};\\\", \\\"{x:1329,y:869,t:1527613650513};\\\", \\\"{x:1363,y:880,t:1527613650530};\\\", \\\"{x:1386,y:882,t:1527613650546};\\\", \\\"{x:1397,y:884,t:1527613650563};\\\", \\\"{x:1398,y:885,t:1527613650581};\\\", \\\"{x:1397,y:884,t:1527613650712};\\\", \\\"{x:1388,y:882,t:1527613650720};\\\", \\\"{x:1375,y:882,t:1527613650731};\\\", \\\"{x:1349,y:880,t:1527613650748};\\\", \\\"{x:1326,y:880,t:1527613650763};\\\", \\\"{x:1311,y:881,t:1527613650780};\\\", \\\"{x:1301,y:887,t:1527613650797};\\\", \\\"{x:1298,y:891,t:1527613650813};\\\", \\\"{x:1298,y:896,t:1527613650830};\\\", \\\"{x:1295,y:904,t:1527613650847};\\\", \\\"{x:1295,y:909,t:1527613650863};\\\", \\\"{x:1294,y:913,t:1527613650880};\\\", \\\"{x:1294,y:916,t:1527613650897};\\\", \\\"{x:1294,y:918,t:1527613650919};\\\", \\\"{x:1295,y:919,t:1527613650959};\\\", \\\"{x:1296,y:919,t:1527613650992};\\\", \\\"{x:1296,y:921,t:1527613651000};\\\", \\\"{x:1297,y:922,t:1527613651013};\\\", \\\"{x:1298,y:926,t:1527613651030};\\\", \\\"{x:1298,y:929,t:1527613651048};\\\", \\\"{x:1299,y:930,t:1527613651088};\\\", \\\"{x:1299,y:932,t:1527613651112};\\\", \\\"{x:1300,y:932,t:1527613651120};\\\", \\\"{x:1300,y:933,t:1527613651136};\\\", \\\"{x:1300,y:934,t:1527613651193};\\\", \\\"{x:1300,y:935,t:1527613651200};\\\", \\\"{x:1300,y:936,t:1527613651216};\\\", \\\"{x:1300,y:938,t:1527613651230};\\\", \\\"{x:1300,y:940,t:1527613651248};\\\", \\\"{x:1300,y:941,t:1527613651265};\\\", \\\"{x:1300,y:944,t:1527613651281};\\\", \\\"{x:1300,y:945,t:1527613651304};\\\", \\\"{x:1299,y:945,t:1527613651409};\\\", \\\"{x:1297,y:945,t:1527613651416};\\\", \\\"{x:1295,y:945,t:1527613651431};\\\", \\\"{x:1294,y:945,t:1527613651456};\\\", \\\"{x:1293,y:945,t:1527613651473};\\\", \\\"{x:1291,y:945,t:1527613651488};\\\", \\\"{x:1288,y:945,t:1527613651504};\\\", \\\"{x:1285,y:945,t:1527613651520};\\\", \\\"{x:1284,y:945,t:1527613651532};\\\", \\\"{x:1282,y:945,t:1527613651548};\\\", \\\"{x:1281,y:945,t:1527613651564};\\\", \\\"{x:1281,y:946,t:1527613651581};\\\", \\\"{x:1280,y:946,t:1527613651703};\\\", \\\"{x:1280,y:945,t:1527613651715};\\\", \\\"{x:1280,y:941,t:1527613651731};\\\", \\\"{x:1280,y:937,t:1527613651747};\\\", \\\"{x:1280,y:930,t:1527613651764};\\\", \\\"{x:1280,y:924,t:1527613651781};\\\", \\\"{x:1280,y:919,t:1527613651797};\\\", \\\"{x:1280,y:911,t:1527613651814};\\\", \\\"{x:1280,y:897,t:1527613651831};\\\", \\\"{x:1280,y:886,t:1527613651847};\\\", \\\"{x:1280,y:873,t:1527613651864};\\\", \\\"{x:1280,y:865,t:1527613651881};\\\", \\\"{x:1280,y:854,t:1527613651898};\\\", \\\"{x:1278,y:845,t:1527613651914};\\\", \\\"{x:1278,y:836,t:1527613651931};\\\", \\\"{x:1278,y:827,t:1527613651948};\\\", \\\"{x:1278,y:821,t:1527613651964};\\\", \\\"{x:1280,y:816,t:1527613651981};\\\", \\\"{x:1281,y:808,t:1527613651998};\\\", \\\"{x:1283,y:802,t:1527613652015};\\\", \\\"{x:1284,y:794,t:1527613652031};\\\", \\\"{x:1285,y:789,t:1527613652048};\\\", \\\"{x:1286,y:785,t:1527613652064};\\\", \\\"{x:1286,y:782,t:1527613652081};\\\", \\\"{x:1286,y:781,t:1527613652103};\\\", \\\"{x:1286,y:779,t:1527613652115};\\\", \\\"{x:1286,y:778,t:1527613652136};\\\", \\\"{x:1286,y:777,t:1527613652149};\\\", \\\"{x:1286,y:776,t:1527613652164};\\\", \\\"{x:1283,y:773,t:1527613652182};\\\", \\\"{x:1283,y:770,t:1527613652199};\\\", \\\"{x:1282,y:765,t:1527613652215};\\\", \\\"{x:1279,y:750,t:1527613652232};\\\", \\\"{x:1278,y:737,t:1527613652248};\\\", \\\"{x:1276,y:726,t:1527613652265};\\\", \\\"{x:1272,y:710,t:1527613652282};\\\", \\\"{x:1266,y:691,t:1527613652299};\\\", \\\"{x:1262,y:670,t:1527613652314};\\\", \\\"{x:1261,y:658,t:1527613652332};\\\", \\\"{x:1258,y:647,t:1527613652349};\\\", \\\"{x:1257,y:637,t:1527613652365};\\\", \\\"{x:1256,y:628,t:1527613652382};\\\", \\\"{x:1255,y:622,t:1527613652398};\\\", \\\"{x:1254,y:612,t:1527613652416};\\\", \\\"{x:1254,y:607,t:1527613652432};\\\", \\\"{x:1254,y:601,t:1527613652448};\\\", \\\"{x:1254,y:596,t:1527613652466};\\\", \\\"{x:1254,y:592,t:1527613652482};\\\", \\\"{x:1254,y:586,t:1527613652500};\\\", \\\"{x:1257,y:575,t:1527613652515};\\\", \\\"{x:1258,y:570,t:1527613652531};\\\", \\\"{x:1259,y:564,t:1527613652548};\\\", \\\"{x:1259,y:563,t:1527613652565};\\\", \\\"{x:1259,y:561,t:1527613652581};\\\", \\\"{x:1249,y:571,t:1527613652752};\\\", \\\"{x:1238,y:584,t:1527613652766};\\\", \\\"{x:1190,y:630,t:1527613652782};\\\", \\\"{x:1122,y:685,t:1527613652798};\\\", \\\"{x:990,y:760,t:1527613652815};\\\", \\\"{x:912,y:803,t:1527613652833};\\\", \\\"{x:830,y:847,t:1527613652848};\\\", \\\"{x:777,y:883,t:1527613652865};\\\", \\\"{x:726,y:909,t:1527613652882};\\\", \\\"{x:684,y:931,t:1527613652898};\\\", \\\"{x:652,y:940,t:1527613652915};\\\", \\\"{x:624,y:943,t:1527613652932};\\\", \\\"{x:603,y:942,t:1527613652948};\\\", \\\"{x:590,y:927,t:1527613652965};\\\", \\\"{x:576,y:895,t:1527613652983};\\\", \\\"{x:563,y:858,t:1527613652998};\\\", \\\"{x:543,y:804,t:1527613653015};\\\", \\\"{x:535,y:781,t:1527613653033};\\\", \\\"{x:530,y:765,t:1527613653049};\\\", \\\"{x:524,y:749,t:1527613653065};\\\", \\\"{x:519,y:736,t:1527613653083};\\\", \\\"{x:517,y:728,t:1527613653098};\\\", \\\"{x:515,y:723,t:1527613653115};\\\", \\\"{x:513,y:719,t:1527613653132};\\\", \\\"{x:512,y:714,t:1527613653148};\\\", \\\"{x:509,y:704,t:1527613653166};\\\", \\\"{x:506,y:690,t:1527613653182};\\\", \\\"{x:504,y:687,t:1527613653198};\\\", \\\"{x:503,y:685,t:1527613653215};\\\", \\\"{x:504,y:686,t:1527613653760};\\\", \\\"{x:510,y:695,t:1527613653767};\\\", \\\"{x:516,y:704,t:1527613653783};\\\", \\\"{x:530,y:725,t:1527613653799};\\\", \\\"{x:538,y:733,t:1527613653816};\\\", \\\"{x:538,y:734,t:1527613653832};\\\", \\\"{x:539,y:734,t:1527613653870};\\\", \\\"{x:534,y:731,t:1527613653911};\\\", \\\"{x:529,y:727,t:1527613653919};\\\", \\\"{x:520,y:721,t:1527613653932};\\\", \\\"{x:507,y:712,t:1527613653949};\\\", \\\"{x:500,y:708,t:1527613653966};\\\", \\\"{x:499,y:707,t:1527613653983};\\\" ] }, { \\\"rt\\\": 7511, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 54802, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"K7JVY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -E \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:505,y:704,t:1527613656673};\\\", \\\"{x:533,y:700,t:1527613656688};\\\", \\\"{x:552,y:699,t:1527613656705};\\\", \\\"{x:585,y:699,t:1527613656723};\\\", \\\"{x:641,y:699,t:1527613656739};\\\", \\\"{x:733,y:699,t:1527613656755};\\\", \\\"{x:833,y:699,t:1527613656768};\\\", \\\"{x:952,y:699,t:1527613656785};\\\", \\\"{x:1074,y:699,t:1527613656801};\\\", \\\"{x:1195,y:699,t:1527613656819};\\\", \\\"{x:1292,y:699,t:1527613656835};\\\", \\\"{x:1373,y:699,t:1527613656851};\\\", \\\"{x:1435,y:696,t:1527613656868};\\\", \\\"{x:1471,y:692,t:1527613656885};\\\", \\\"{x:1499,y:685,t:1527613656901};\\\", \\\"{x:1526,y:677,t:1527613656918};\\\", \\\"{x:1554,y:667,t:1527613656935};\\\", \\\"{x:1564,y:662,t:1527613656951};\\\", \\\"{x:1576,y:658,t:1527613656968};\\\", \\\"{x:1589,y:653,t:1527613656985};\\\", \\\"{x:1599,y:647,t:1527613657001};\\\", \\\"{x:1604,y:645,t:1527613657018};\\\", \\\"{x:1605,y:644,t:1527613657035};\\\", \\\"{x:1606,y:644,t:1527613657080};\\\", \\\"{x:1606,y:643,t:1527613657087};\\\", \\\"{x:1606,y:642,t:1527613657102};\\\", \\\"{x:1605,y:639,t:1527613657118};\\\", \\\"{x:1598,y:637,t:1527613657135};\\\", \\\"{x:1587,y:632,t:1527613657152};\\\", \\\"{x:1573,y:628,t:1527613657168};\\\", \\\"{x:1558,y:623,t:1527613657186};\\\", \\\"{x:1548,y:619,t:1527613657203};\\\", \\\"{x:1540,y:617,t:1527613657219};\\\", \\\"{x:1531,y:615,t:1527613657236};\\\", \\\"{x:1521,y:613,t:1527613657253};\\\", \\\"{x:1507,y:610,t:1527613657269};\\\", \\\"{x:1489,y:608,t:1527613657286};\\\", \\\"{x:1467,y:607,t:1527613657303};\\\", \\\"{x:1445,y:604,t:1527613657319};\\\", \\\"{x:1415,y:599,t:1527613657336};\\\", \\\"{x:1397,y:599,t:1527613657353};\\\", \\\"{x:1382,y:598,t:1527613657369};\\\", \\\"{x:1372,y:598,t:1527613657386};\\\", \\\"{x:1360,y:598,t:1527613657403};\\\", \\\"{x:1349,y:598,t:1527613657419};\\\", \\\"{x:1339,y:598,t:1527613657436};\\\", \\\"{x:1333,y:598,t:1527613657453};\\\", \\\"{x:1328,y:598,t:1527613657469};\\\", \\\"{x:1326,y:598,t:1527613657486};\\\", \\\"{x:1325,y:598,t:1527613657584};\\\", \\\"{x:1325,y:595,t:1527613657592};\\\", \\\"{x:1325,y:591,t:1527613657603};\\\", \\\"{x:1328,y:576,t:1527613657620};\\\", \\\"{x:1332,y:565,t:1527613657636};\\\", \\\"{x:1338,y:547,t:1527613657653};\\\", \\\"{x:1348,y:525,t:1527613657670};\\\", \\\"{x:1355,y:510,t:1527613657686};\\\", \\\"{x:1366,y:494,t:1527613657702};\\\", \\\"{x:1372,y:482,t:1527613657720};\\\", \\\"{x:1377,y:473,t:1527613657736};\\\", \\\"{x:1381,y:465,t:1527613657753};\\\", \\\"{x:1385,y:459,t:1527613657770};\\\", \\\"{x:1394,y:448,t:1527613657786};\\\", \\\"{x:1404,y:439,t:1527613657803};\\\", \\\"{x:1418,y:428,t:1527613657820};\\\", \\\"{x:1430,y:417,t:1527613657835};\\\", \\\"{x:1443,y:407,t:1527613657853};\\\", \\\"{x:1450,y:401,t:1527613657870};\\\", \\\"{x:1463,y:393,t:1527613657886};\\\", \\\"{x:1477,y:386,t:1527613657903};\\\", \\\"{x:1508,y:375,t:1527613657919};\\\", \\\"{x:1529,y:371,t:1527613657935};\\\", \\\"{x:1550,y:369,t:1527613657953};\\\", \\\"{x:1573,y:369,t:1527613657969};\\\", \\\"{x:1603,y:369,t:1527613657986};\\\", \\\"{x:1624,y:369,t:1527613658002};\\\", \\\"{x:1648,y:369,t:1527613658019};\\\", \\\"{x:1669,y:373,t:1527613658036};\\\", \\\"{x:1679,y:376,t:1527613658052};\\\", \\\"{x:1683,y:377,t:1527613658069};\\\", \\\"{x:1686,y:378,t:1527613658086};\\\", \\\"{x:1686,y:379,t:1527613658103};\\\", \\\"{x:1687,y:380,t:1527613658127};\\\", \\\"{x:1688,y:380,t:1527613658136};\\\", \\\"{x:1688,y:383,t:1527613658152};\\\", \\\"{x:1688,y:387,t:1527613658170};\\\", \\\"{x:1688,y:394,t:1527613658187};\\\", \\\"{x:1688,y:402,t:1527613658203};\\\", \\\"{x:1684,y:410,t:1527613658219};\\\", \\\"{x:1678,y:417,t:1527613658236};\\\", \\\"{x:1668,y:428,t:1527613658253};\\\", \\\"{x:1658,y:438,t:1527613658269};\\\", \\\"{x:1645,y:447,t:1527613658286};\\\", \\\"{x:1640,y:447,t:1527613658302};\\\", \\\"{x:1640,y:449,t:1527613658519};\\\", \\\"{x:1640,y:450,t:1527613658536};\\\", \\\"{x:1639,y:453,t:1527613658553};\\\", \\\"{x:1638,y:453,t:1527613658569};\\\", \\\"{x:1637,y:455,t:1527613658587};\\\", \\\"{x:1636,y:456,t:1527613658603};\\\", \\\"{x:1636,y:458,t:1527613658619};\\\", \\\"{x:1634,y:460,t:1527613658637};\\\", \\\"{x:1633,y:462,t:1527613658653};\\\", \\\"{x:1632,y:465,t:1527613658670};\\\", \\\"{x:1630,y:467,t:1527613658686};\\\", \\\"{x:1629,y:469,t:1527613658704};\\\", \\\"{x:1628,y:470,t:1527613658720};\\\", \\\"{x:1628,y:472,t:1527613658737};\\\", \\\"{x:1627,y:475,t:1527613658754};\\\", \\\"{x:1626,y:479,t:1527613658770};\\\", \\\"{x:1625,y:481,t:1527613658787};\\\", \\\"{x:1625,y:484,t:1527613658804};\\\", \\\"{x:1623,y:488,t:1527613658820};\\\", \\\"{x:1623,y:490,t:1527613658837};\\\", \\\"{x:1622,y:493,t:1527613658854};\\\", \\\"{x:1622,y:495,t:1527613658870};\\\", \\\"{x:1622,y:497,t:1527613658887};\\\", \\\"{x:1622,y:498,t:1527613658919};\\\", \\\"{x:1622,y:501,t:1527613658936};\\\", \\\"{x:1622,y:504,t:1527613658953};\\\", \\\"{x:1622,y:507,t:1527613658969};\\\", \\\"{x:1621,y:509,t:1527613658987};\\\", \\\"{x:1620,y:511,t:1527613659004};\\\", \\\"{x:1620,y:513,t:1527613659020};\\\", \\\"{x:1620,y:516,t:1527613659037};\\\", \\\"{x:1619,y:517,t:1527613659053};\\\", \\\"{x:1619,y:519,t:1527613659070};\\\", \\\"{x:1618,y:521,t:1527613659087};\\\", \\\"{x:1617,y:524,t:1527613659103};\\\", \\\"{x:1617,y:526,t:1527613659121};\\\", \\\"{x:1616,y:529,t:1527613659136};\\\", \\\"{x:1616,y:531,t:1527613659153};\\\", \\\"{x:1616,y:536,t:1527613659173};\\\", \\\"{x:1616,y:540,t:1527613659186};\\\", \\\"{x:1616,y:544,t:1527613659203};\\\", \\\"{x:1616,y:545,t:1527613659221};\\\", \\\"{x:1616,y:546,t:1527613659236};\\\", \\\"{x:1616,y:547,t:1527613659254};\\\", \\\"{x:1615,y:548,t:1527613659432};\\\", \\\"{x:1613,y:549,t:1527613659448};\\\", \\\"{x:1610,y:549,t:1527613659455};\\\", \\\"{x:1605,y:551,t:1527613659471};\\\", \\\"{x:1578,y:552,t:1527613659487};\\\", \\\"{x:1547,y:552,t:1527613659504};\\\", \\\"{x:1511,y:552,t:1527613659521};\\\", \\\"{x:1469,y:552,t:1527613659538};\\\", \\\"{x:1416,y:552,t:1527613659554};\\\", \\\"{x:1354,y:553,t:1527613659571};\\\", \\\"{x:1275,y:559,t:1527613659588};\\\", \\\"{x:1198,y:564,t:1527613659603};\\\", \\\"{x:1126,y:573,t:1527613659621};\\\", \\\"{x:1045,y:586,t:1527613659638};\\\", \\\"{x:951,y:597,t:1527613659654};\\\", \\\"{x:849,y:607,t:1527613659671};\\\", \\\"{x:682,y:615,t:1527613659689};\\\", \\\"{x:574,y:629,t:1527613659704};\\\", \\\"{x:473,y:645,t:1527613659720};\\\", \\\"{x:374,y:657,t:1527613659738};\\\", \\\"{x:298,y:660,t:1527613659754};\\\", \\\"{x:263,y:660,t:1527613659770};\\\", \\\"{x:240,y:660,t:1527613659788};\\\", \\\"{x:229,y:660,t:1527613659804};\\\", \\\"{x:225,y:660,t:1527613659821};\\\", \\\"{x:224,y:660,t:1527613659838};\\\", \\\"{x:222,y:659,t:1527613659854};\\\", \\\"{x:219,y:654,t:1527613659870};\\\", \\\"{x:216,y:645,t:1527613659887};\\\", \\\"{x:216,y:639,t:1527613659905};\\\", \\\"{x:216,y:634,t:1527613659920};\\\", \\\"{x:218,y:628,t:1527613659938};\\\", \\\"{x:220,y:623,t:1527613659954};\\\", \\\"{x:224,y:618,t:1527613659971};\\\", \\\"{x:239,y:607,t:1527613659987};\\\", \\\"{x:266,y:597,t:1527613660005};\\\", \\\"{x:304,y:581,t:1527613660022};\\\", \\\"{x:359,y:558,t:1527613660037};\\\", \\\"{x:407,y:542,t:1527613660055};\\\", \\\"{x:483,y:518,t:1527613660071};\\\", \\\"{x:533,y:504,t:1527613660088};\\\", \\\"{x:561,y:501,t:1527613660104};\\\", \\\"{x:572,y:497,t:1527613660121};\\\", \\\"{x:570,y:497,t:1527613660247};\\\", \\\"{x:566,y:497,t:1527613660255};\\\", \\\"{x:555,y:499,t:1527613660271};\\\", \\\"{x:525,y:504,t:1527613660287};\\\", \\\"{x:488,y:506,t:1527613660306};\\\", \\\"{x:441,y:512,t:1527613660321};\\\", \\\"{x:395,y:514,t:1527613660337};\\\", \\\"{x:363,y:517,t:1527613660355};\\\", \\\"{x:340,y:518,t:1527613660371};\\\", \\\"{x:325,y:520,t:1527613660388};\\\", \\\"{x:318,y:523,t:1527613660406};\\\", \\\"{x:316,y:524,t:1527613660421};\\\", \\\"{x:315,y:525,t:1527613660438};\\\", \\\"{x:314,y:526,t:1527613660495};\\\", \\\"{x:314,y:528,t:1527613660504};\\\", \\\"{x:313,y:530,t:1527613660521};\\\", \\\"{x:312,y:532,t:1527613660538};\\\", \\\"{x:312,y:535,t:1527613660555};\\\", \\\"{x:310,y:537,t:1527613660571};\\\", \\\"{x:309,y:543,t:1527613660589};\\\", \\\"{x:301,y:550,t:1527613660605};\\\", \\\"{x:296,y:557,t:1527613660622};\\\", \\\"{x:282,y:567,t:1527613660639};\\\", \\\"{x:270,y:572,t:1527613660655};\\\", \\\"{x:259,y:577,t:1527613660671};\\\", \\\"{x:257,y:578,t:1527613660688};\\\", \\\"{x:246,y:580,t:1527613660704};\\\", \\\"{x:242,y:581,t:1527613660722};\\\", \\\"{x:231,y:585,t:1527613660739};\\\", \\\"{x:224,y:587,t:1527613660755};\\\", \\\"{x:218,y:589,t:1527613660772};\\\", \\\"{x:214,y:590,t:1527613660789};\\\", \\\"{x:213,y:591,t:1527613660806};\\\", \\\"{x:212,y:591,t:1527613660821};\\\", \\\"{x:211,y:592,t:1527613660838};\\\", \\\"{x:207,y:594,t:1527613660855};\\\", \\\"{x:202,y:597,t:1527613660871};\\\", \\\"{x:197,y:600,t:1527613660889};\\\", \\\"{x:191,y:603,t:1527613660905};\\\", \\\"{x:188,y:605,t:1527613660921};\\\", \\\"{x:185,y:608,t:1527613660938};\\\", \\\"{x:179,y:611,t:1527613660956};\\\", \\\"{x:173,y:614,t:1527613660971};\\\", \\\"{x:170,y:616,t:1527613660989};\\\", \\\"{x:169,y:616,t:1527613661005};\\\", \\\"{x:168,y:616,t:1527613661021};\\\", \\\"{x:173,y:616,t:1527613661327};\\\", \\\"{x:198,y:619,t:1527613661339};\\\", \\\"{x:261,y:624,t:1527613661356};\\\", \\\"{x:329,y:627,t:1527613661373};\\\", \\\"{x:382,y:635,t:1527613661389};\\\", \\\"{x:430,y:643,t:1527613661405};\\\", \\\"{x:453,y:647,t:1527613661422};\\\", \\\"{x:473,y:654,t:1527613661438};\\\", \\\"{x:500,y:663,t:1527613661455};\\\", \\\"{x:514,y:665,t:1527613661472};\\\", \\\"{x:522,y:668,t:1527613661489};\\\", \\\"{x:526,y:671,t:1527613661505};\\\", \\\"{x:529,y:672,t:1527613661522};\\\", \\\"{x:530,y:672,t:1527613661538};\\\", \\\"{x:532,y:674,t:1527613661624};\\\", \\\"{x:533,y:675,t:1527613661639};\\\", \\\"{x:534,y:679,t:1527613661656};\\\", \\\"{x:535,y:682,t:1527613661673};\\\", \\\"{x:535,y:685,t:1527613661689};\\\", \\\"{x:535,y:688,t:1527613661705};\\\", \\\"{x:535,y:689,t:1527613661722};\\\", \\\"{x:534,y:691,t:1527613661738};\\\", \\\"{x:534,y:692,t:1527613661755};\\\", \\\"{x:533,y:694,t:1527613661771};\\\", \\\"{x:532,y:695,t:1527613661788};\\\" ] }, { \\\"rt\\\": 24784, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 80887, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"K7JVY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"Z\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-4-C -C -C \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:531,y:695,t:1527613663623};\\\", \\\"{x:531,y:694,t:1527613663695};\\\", \\\"{x:535,y:694,t:1527613665167};\\\", \\\"{x:539,y:692,t:1527613665179};\\\", \\\"{x:546,y:689,t:1527613665195};\\\", \\\"{x:547,y:688,t:1527613665213};\\\", \\\"{x:548,y:688,t:1527613665229};\\\", \\\"{x:546,y:691,t:1527613665246};\\\", \\\"{x:546,y:694,t:1527613665263};\\\", \\\"{x:547,y:693,t:1527613666568};\\\", \\\"{x:549,y:689,t:1527613666584};\\\", \\\"{x:550,y:686,t:1527613666600};\\\", \\\"{x:552,y:683,t:1527613666617};\\\", \\\"{x:554,y:680,t:1527613666634};\\\", \\\"{x:555,y:677,t:1527613666652};\\\", \\\"{x:556,y:675,t:1527613666667};\\\", \\\"{x:560,y:672,t:1527613666684};\\\", \\\"{x:561,y:669,t:1527613666700};\\\", \\\"{x:563,y:668,t:1527613666724};\\\", \\\"{x:566,y:664,t:1527613666741};\\\", \\\"{x:567,y:662,t:1527613666759};\\\", \\\"{x:568,y:662,t:1527613666775};\\\", \\\"{x:568,y:661,t:1527613666792};\\\", \\\"{x:568,y:660,t:1527613667146};\\\", \\\"{x:569,y:660,t:1527613667162};\\\", \\\"{x:576,y:660,t:1527613667178};\\\", \\\"{x:582,y:660,t:1527613667194};\\\", \\\"{x:591,y:660,t:1527613667212};\\\", \\\"{x:603,y:660,t:1527613667228};\\\", \\\"{x:625,y:661,t:1527613667245};\\\", \\\"{x:657,y:661,t:1527613667262};\\\", \\\"{x:710,y:663,t:1527613667278};\\\", \\\"{x:786,y:666,t:1527613667295};\\\", \\\"{x:887,y:670,t:1527613667312};\\\", \\\"{x:981,y:670,t:1527613667328};\\\", \\\"{x:1059,y:670,t:1527613667345};\\\", \\\"{x:1119,y:671,t:1527613667364};\\\", \\\"{x:1142,y:675,t:1527613667378};\\\", \\\"{x:1155,y:675,t:1527613667396};\\\", \\\"{x:1157,y:675,t:1527613667412};\\\", \\\"{x:1158,y:675,t:1527613667428};\\\", \\\"{x:1160,y:675,t:1527613667451};\\\", \\\"{x:1162,y:675,t:1527613667463};\\\", \\\"{x:1168,y:675,t:1527613667478};\\\", \\\"{x:1188,y:675,t:1527613667495};\\\", \\\"{x:1212,y:675,t:1527613667512};\\\", \\\"{x:1240,y:675,t:1527613667528};\\\", \\\"{x:1267,y:675,t:1527613667546};\\\", \\\"{x:1299,y:675,t:1527613667562};\\\", \\\"{x:1315,y:675,t:1527613667579};\\\", \\\"{x:1328,y:675,t:1527613667596};\\\", \\\"{x:1335,y:675,t:1527613667612};\\\", \\\"{x:1341,y:675,t:1527613667628};\\\", \\\"{x:1346,y:675,t:1527613667646};\\\", \\\"{x:1354,y:675,t:1527613667662};\\\", \\\"{x:1361,y:676,t:1527613667678};\\\", \\\"{x:1366,y:676,t:1527613667696};\\\", \\\"{x:1369,y:676,t:1527613667712};\\\", \\\"{x:1371,y:678,t:1527613667728};\\\", \\\"{x:1372,y:678,t:1527613667891};\\\", \\\"{x:1372,y:680,t:1527613667899};\\\", \\\"{x:1370,y:682,t:1527613667913};\\\", \\\"{x:1364,y:690,t:1527613667929};\\\", \\\"{x:1359,y:702,t:1527613667945};\\\", \\\"{x:1347,y:722,t:1527613667963};\\\", \\\"{x:1341,y:735,t:1527613667979};\\\", \\\"{x:1336,y:746,t:1527613667996};\\\", \\\"{x:1328,y:756,t:1527613668013};\\\", \\\"{x:1323,y:764,t:1527613668030};\\\", \\\"{x:1316,y:772,t:1527613668045};\\\", \\\"{x:1310,y:780,t:1527613668062};\\\", \\\"{x:1305,y:784,t:1527613668079};\\\", \\\"{x:1301,y:787,t:1527613668095};\\\", \\\"{x:1297,y:791,t:1527613668112};\\\", \\\"{x:1291,y:795,t:1527613668129};\\\", \\\"{x:1285,y:799,t:1527613668145};\\\", \\\"{x:1273,y:804,t:1527613668162};\\\", \\\"{x:1265,y:806,t:1527613668178};\\\", \\\"{x:1256,y:810,t:1527613668196};\\\", \\\"{x:1249,y:812,t:1527613668212};\\\", \\\"{x:1246,y:814,t:1527613668229};\\\", \\\"{x:1242,y:815,t:1527613668245};\\\", \\\"{x:1241,y:815,t:1527613668262};\\\", \\\"{x:1240,y:816,t:1527613668290};\\\", \\\"{x:1239,y:817,t:1527613668298};\\\", \\\"{x:1237,y:817,t:1527613668312};\\\", \\\"{x:1231,y:821,t:1527613668329};\\\", \\\"{x:1227,y:821,t:1527613668345};\\\", \\\"{x:1225,y:822,t:1527613668362};\\\", \\\"{x:1224,y:822,t:1527613668644};\\\", \\\"{x:1222,y:822,t:1527613668651};\\\", \\\"{x:1221,y:822,t:1527613668662};\\\", \\\"{x:1217,y:822,t:1527613668680};\\\", \\\"{x:1215,y:822,t:1527613668695};\\\", \\\"{x:1214,y:823,t:1527613668712};\\\", \\\"{x:1211,y:824,t:1527613668730};\\\", \\\"{x:1210,y:825,t:1527613668764};\\\", \\\"{x:1209,y:825,t:1527613669251};\\\", \\\"{x:1209,y:824,t:1527613669516};\\\", \\\"{x:1208,y:823,t:1527613669531};\\\", \\\"{x:1208,y:822,t:1527613670419};\\\", \\\"{x:1208,y:821,t:1527613670430};\\\", \\\"{x:1208,y:819,t:1527613670447};\\\", \\\"{x:1208,y:817,t:1527613670463};\\\", \\\"{x:1208,y:815,t:1527613670480};\\\", \\\"{x:1208,y:813,t:1527613670496};\\\", \\\"{x:1208,y:812,t:1527613670513};\\\", \\\"{x:1208,y:811,t:1527613670531};\\\", \\\"{x:1208,y:810,t:1527613670547};\\\", \\\"{x:1208,y:809,t:1527613670563};\\\", \\\"{x:1209,y:805,t:1527613670582};\\\", \\\"{x:1209,y:803,t:1527613670597};\\\", \\\"{x:1210,y:800,t:1527613670613};\\\", \\\"{x:1210,y:799,t:1527613670634};\\\", \\\"{x:1210,y:798,t:1527613670658};\\\", \\\"{x:1211,y:797,t:1527613670698};\\\", \\\"{x:1212,y:796,t:1527613671011};\\\", \\\"{x:1213,y:796,t:1527613671218};\\\", \\\"{x:1213,y:798,t:1527613671651};\\\", \\\"{x:1213,y:799,t:1527613671755};\\\", \\\"{x:1213,y:801,t:1527613672027};\\\", \\\"{x:1213,y:803,t:1527613672138};\\\", \\\"{x:1214,y:803,t:1527613672202};\\\", \\\"{x:1215,y:804,t:1527613672298};\\\", \\\"{x:1215,y:805,t:1527613672323};\\\", \\\"{x:1216,y:806,t:1527613672354};\\\", \\\"{x:1217,y:806,t:1527613672378};\\\", \\\"{x:1217,y:807,t:1527613672747};\\\", \\\"{x:1216,y:808,t:1527613672915};\\\", \\\"{x:1216,y:809,t:1527613672938};\\\", \\\"{x:1215,y:809,t:1527613672979};\\\", \\\"{x:1214,y:809,t:1527613674154};\\\", \\\"{x:1215,y:810,t:1527613677027};\\\", \\\"{x:1218,y:811,t:1527613677035};\\\", \\\"{x:1219,y:811,t:1527613677049};\\\", \\\"{x:1224,y:813,t:1527613677066};\\\", \\\"{x:1228,y:813,t:1527613677082};\\\", \\\"{x:1229,y:813,t:1527613677099};\\\", \\\"{x:1230,y:813,t:1527613677139};\\\", \\\"{x:1231,y:813,t:1527613677148};\\\", \\\"{x:1235,y:813,t:1527613677165};\\\", \\\"{x:1239,y:813,t:1527613677182};\\\", \\\"{x:1247,y:813,t:1527613677198};\\\", \\\"{x:1255,y:813,t:1527613677214};\\\", \\\"{x:1266,y:813,t:1527613677231};\\\", \\\"{x:1270,y:813,t:1527613677248};\\\", \\\"{x:1272,y:813,t:1527613677264};\\\", \\\"{x:1274,y:813,t:1527613678003};\\\", \\\"{x:1277,y:813,t:1527613678019};\\\", \\\"{x:1282,y:814,t:1527613678032};\\\", \\\"{x:1291,y:815,t:1527613678049};\\\", \\\"{x:1297,y:815,t:1527613678066};\\\", \\\"{x:1308,y:815,t:1527613678082};\\\", \\\"{x:1314,y:815,t:1527613678100};\\\", \\\"{x:1319,y:815,t:1527613678116};\\\", \\\"{x:1322,y:815,t:1527613678132};\\\", \\\"{x:1323,y:815,t:1527613678149};\\\", \\\"{x:1326,y:815,t:1527613678166};\\\", \\\"{x:1331,y:814,t:1527613678182};\\\", \\\"{x:1335,y:813,t:1527613678198};\\\", \\\"{x:1341,y:812,t:1527613678215};\\\", \\\"{x:1343,y:812,t:1527613678231};\\\", \\\"{x:1344,y:812,t:1527613678248};\\\", \\\"{x:1346,y:812,t:1527613678298};\\\", \\\"{x:1340,y:807,t:1527613680227};\\\", \\\"{x:1327,y:801,t:1527613680233};\\\", \\\"{x:1317,y:795,t:1527613680250};\\\", \\\"{x:1280,y:783,t:1527613680266};\\\", \\\"{x:1210,y:764,t:1527613680282};\\\", \\\"{x:1160,y:749,t:1527613680299};\\\", \\\"{x:1115,y:738,t:1527613680316};\\\", \\\"{x:1081,y:728,t:1527613680332};\\\", \\\"{x:1053,y:719,t:1527613680350};\\\", \\\"{x:1017,y:708,t:1527613680366};\\\", \\\"{x:972,y:696,t:1527613680383};\\\", \\\"{x:922,y:689,t:1527613680399};\\\", \\\"{x:858,y:680,t:1527613680416};\\\", \\\"{x:791,y:670,t:1527613680432};\\\", \\\"{x:724,y:661,t:1527613680449};\\\", \\\"{x:684,y:654,t:1527613680466};\\\", \\\"{x:635,y:647,t:1527613680482};\\\", \\\"{x:610,y:642,t:1527613680500};\\\", \\\"{x:592,y:639,t:1527613680516};\\\", \\\"{x:590,y:638,t:1527613680533};\\\", \\\"{x:589,y:638,t:1527613680550};\\\", \\\"{x:587,y:638,t:1527613680565};\\\", \\\"{x:585,y:637,t:1527613680635};\\\", \\\"{x:579,y:635,t:1527613680649};\\\", \\\"{x:561,y:632,t:1527613680666};\\\", \\\"{x:555,y:624,t:1527613680684};\\\", \\\"{x:551,y:624,t:1527613681131};\\\", \\\"{x:548,y:624,t:1527613681142};\\\", \\\"{x:542,y:621,t:1527613681159};\\\", \\\"{x:539,y:620,t:1527613681175};\\\", \\\"{x:537,y:620,t:1527613681195};\\\", \\\"{x:535,y:618,t:1527613681227};\\\", \\\"{x:535,y:616,t:1527613681242};\\\", \\\"{x:532,y:610,t:1527613681259};\\\", \\\"{x:532,y:609,t:1527613681274};\\\", \\\"{x:531,y:609,t:1527613681291};\\\", \\\"{x:529,y:609,t:1527613681308};\\\", \\\"{x:523,y:609,t:1527613681324};\\\", \\\"{x:517,y:607,t:1527613681342};\\\", \\\"{x:514,y:606,t:1527613681359};\\\", \\\"{x:511,y:605,t:1527613681374};\\\", \\\"{x:510,y:604,t:1527613681402};\\\", \\\"{x:508,y:603,t:1527613681417};\\\", \\\"{x:504,y:598,t:1527613681426};\\\", \\\"{x:496,y:594,t:1527613681442};\\\", \\\"{x:479,y:584,t:1527613681459};\\\", \\\"{x:470,y:582,t:1527613681476};\\\", \\\"{x:466,y:580,t:1527613681492};\\\", \\\"{x:465,y:580,t:1527613681509};\\\", \\\"{x:465,y:579,t:1527613681620};\\\", \\\"{x:468,y:579,t:1527613681627};\\\", \\\"{x:469,y:578,t:1527613681731};\\\", \\\"{x:470,y:578,t:1527613682931};\\\", \\\"{x:470,y:580,t:1527613682943};\\\", \\\"{x:470,y:584,t:1527613682960};\\\", \\\"{x:471,y:590,t:1527613682977};\\\", \\\"{x:471,y:594,t:1527613682994};\\\", \\\"{x:473,y:600,t:1527613683010};\\\", \\\"{x:476,y:607,t:1527613683026};\\\", \\\"{x:479,y:615,t:1527613683043};\\\", \\\"{x:482,y:619,t:1527613683059};\\\", \\\"{x:485,y:624,t:1527613683076};\\\", \\\"{x:485,y:626,t:1527613683094};\\\", \\\"{x:488,y:630,t:1527613683111};\\\", \\\"{x:489,y:631,t:1527613683127};\\\", \\\"{x:491,y:634,t:1527613683144};\\\", \\\"{x:495,y:637,t:1527613683161};\\\", \\\"{x:498,y:639,t:1527613683176};\\\", \\\"{x:502,y:643,t:1527613683193};\\\", \\\"{x:503,y:643,t:1527613683234};\\\", \\\"{x:504,y:643,t:1527613683275};\\\", \\\"{x:505,y:643,t:1527613683282};\\\", \\\"{x:506,y:643,t:1527613683294};\\\", \\\"{x:508,y:639,t:1527613683310};\\\", \\\"{x:509,y:637,t:1527613683328};\\\", \\\"{x:509,y:634,t:1527613683344};\\\", \\\"{x:509,y:631,t:1527613683361};\\\", \\\"{x:509,y:628,t:1527613683378};\\\", \\\"{x:509,y:626,t:1527613683394};\\\", \\\"{x:509,y:625,t:1527613683411};\\\", \\\"{x:509,y:622,t:1527613683427};\\\", \\\"{x:507,y:620,t:1527613683443};\\\", \\\"{x:502,y:618,t:1527613683459};\\\", \\\"{x:500,y:617,t:1527613683476};\\\", \\\"{x:500,y:616,t:1527613683494};\\\", \\\"{x:499,y:616,t:1527613683510};\\\", \\\"{x:495,y:616,t:1527613683527};\\\", \\\"{x:487,y:616,t:1527613683543};\\\", \\\"{x:469,y:620,t:1527613683560};\\\", \\\"{x:448,y:620,t:1527613683577};\\\", \\\"{x:417,y:620,t:1527613683594};\\\", \\\"{x:399,y:620,t:1527613683609};\\\", \\\"{x:391,y:620,t:1527613683626};\\\", \\\"{x:388,y:620,t:1527613683643};\\\", \\\"{x:387,y:620,t:1527613683699};\\\", \\\"{x:385,y:618,t:1527613683711};\\\", \\\"{x:382,y:616,t:1527613683726};\\\", \\\"{x:378,y:613,t:1527613683743};\\\", \\\"{x:377,y:612,t:1527613683762};\\\", \\\"{x:376,y:610,t:1527613683778};\\\", \\\"{x:376,y:608,t:1527613683794};\\\", \\\"{x:374,y:606,t:1527613683810};\\\", \\\"{x:374,y:605,t:1527613683826};\\\", \\\"{x:374,y:603,t:1527613683844};\\\", \\\"{x:374,y:599,t:1527613683861};\\\", \\\"{x:374,y:597,t:1527613683877};\\\", \\\"{x:374,y:593,t:1527613683894};\\\", \\\"{x:378,y:587,t:1527613683911};\\\", \\\"{x:383,y:583,t:1527613683929};\\\", \\\"{x:389,y:580,t:1527613683944};\\\", \\\"{x:392,y:577,t:1527613683961};\\\", \\\"{x:406,y:572,t:1527613683978};\\\", \\\"{x:424,y:568,t:1527613683995};\\\", \\\"{x:436,y:567,t:1527613684011};\\\", \\\"{x:462,y:567,t:1527613684027};\\\", \\\"{x:496,y:567,t:1527613684044};\\\", \\\"{x:523,y:567,t:1527613684063};\\\", \\\"{x:554,y:567,t:1527613684078};\\\", \\\"{x:583,y:567,t:1527613684093};\\\", \\\"{x:607,y:567,t:1527613684111};\\\", \\\"{x:629,y:567,t:1527613684128};\\\", \\\"{x:639,y:569,t:1527613684143};\\\", \\\"{x:645,y:569,t:1527613684161};\\\", \\\"{x:654,y:569,t:1527613684177};\\\", \\\"{x:656,y:569,t:1527613684193};\\\", \\\"{x:657,y:569,t:1527613684210};\\\", \\\"{x:657,y:570,t:1527613684228};\\\", \\\"{x:658,y:570,t:1527613684250};\\\", \\\"{x:658,y:572,t:1527613684261};\\\", \\\"{x:655,y:574,t:1527613684278};\\\", \\\"{x:649,y:576,t:1527613684294};\\\", \\\"{x:639,y:578,t:1527613684311};\\\", \\\"{x:621,y:582,t:1527613684328};\\\", \\\"{x:599,y:583,t:1527613684344};\\\", \\\"{x:576,y:583,t:1527613684360};\\\", \\\"{x:539,y:584,t:1527613684377};\\\", \\\"{x:515,y:584,t:1527613684394};\\\", \\\"{x:502,y:582,t:1527613684411};\\\", \\\"{x:494,y:580,t:1527613684428};\\\", \\\"{x:487,y:578,t:1527613684445};\\\", \\\"{x:482,y:577,t:1527613684461};\\\", \\\"{x:477,y:576,t:1527613684478};\\\", \\\"{x:471,y:575,t:1527613684494};\\\", \\\"{x:464,y:575,t:1527613684510};\\\", \\\"{x:455,y:573,t:1527613684527};\\\", \\\"{x:450,y:573,t:1527613684544};\\\", \\\"{x:437,y:573,t:1527613684561};\\\", \\\"{x:414,y:573,t:1527613684578};\\\", \\\"{x:400,y:573,t:1527613684594};\\\", \\\"{x:388,y:573,t:1527613684611};\\\", \\\"{x:380,y:573,t:1527613684628};\\\", \\\"{x:374,y:573,t:1527613684644};\\\", \\\"{x:369,y:573,t:1527613684662};\\\", \\\"{x:365,y:574,t:1527613684678};\\\", \\\"{x:361,y:575,t:1527613684695};\\\", \\\"{x:357,y:577,t:1527613684711};\\\", \\\"{x:347,y:580,t:1527613684728};\\\", \\\"{x:334,y:582,t:1527613684745};\\\", \\\"{x:313,y:586,t:1527613684761};\\\", \\\"{x:282,y:588,t:1527613684778};\\\", \\\"{x:264,y:588,t:1527613684796};\\\", \\\"{x:250,y:588,t:1527613684812};\\\", \\\"{x:244,y:588,t:1527613684828};\\\", \\\"{x:233,y:588,t:1527613684845};\\\", \\\"{x:226,y:588,t:1527613684862};\\\", \\\"{x:219,y:588,t:1527613684878};\\\", \\\"{x:214,y:587,t:1527613684894};\\\", \\\"{x:210,y:587,t:1527613684912};\\\", \\\"{x:206,y:587,t:1527613684927};\\\", \\\"{x:203,y:588,t:1527613684944};\\\", \\\"{x:194,y:588,t:1527613684962};\\\", \\\"{x:188,y:589,t:1527613684978};\\\", \\\"{x:176,y:592,t:1527613684997};\\\", \\\"{x:168,y:595,t:1527613685011};\\\", \\\"{x:159,y:597,t:1527613685028};\\\", \\\"{x:157,y:597,t:1527613685044};\\\", \\\"{x:157,y:598,t:1527613685066};\\\", \\\"{x:157,y:599,t:1527613685178};\\\", \\\"{x:157,y:598,t:1527613685194};\\\", \\\"{x:174,y:593,t:1527613685213};\\\", \\\"{x:192,y:588,t:1527613685230};\\\", \\\"{x:214,y:583,t:1527613685245};\\\", \\\"{x:247,y:579,t:1527613685261};\\\", \\\"{x:297,y:573,t:1527613685280};\\\", \\\"{x:341,y:568,t:1527613685295};\\\", \\\"{x:403,y:568,t:1527613685312};\\\", \\\"{x:448,y:568,t:1527613685329};\\\", \\\"{x:498,y:568,t:1527613685345};\\\", \\\"{x:558,y:567,t:1527613685363};\\\", \\\"{x:585,y:567,t:1527613685378};\\\", \\\"{x:602,y:567,t:1527613685395};\\\", \\\"{x:607,y:565,t:1527613685412};\\\", \\\"{x:606,y:565,t:1527613685458};\\\", \\\"{x:597,y:565,t:1527613685467};\\\", \\\"{x:586,y:565,t:1527613685478};\\\", \\\"{x:559,y:564,t:1527613685495};\\\", \\\"{x:516,y:563,t:1527613685512};\\\", \\\"{x:463,y:563,t:1527613685530};\\\", \\\"{x:391,y:563,t:1527613685546};\\\", \\\"{x:323,y:563,t:1527613685563};\\\", \\\"{x:298,y:563,t:1527613685579};\\\", \\\"{x:282,y:562,t:1527613685595};\\\", \\\"{x:272,y:560,t:1527613685614};\\\", \\\"{x:261,y:560,t:1527613685629};\\\", \\\"{x:250,y:560,t:1527613685646};\\\", \\\"{x:239,y:560,t:1527613685662};\\\", \\\"{x:224,y:560,t:1527613685679};\\\", \\\"{x:209,y:560,t:1527613685696};\\\", \\\"{x:187,y:560,t:1527613685713};\\\", \\\"{x:170,y:560,t:1527613685729};\\\", \\\"{x:155,y:560,t:1527613685747};\\\", \\\"{x:153,y:560,t:1527613685763};\\\", \\\"{x:152,y:559,t:1527613685812};\\\", \\\"{x:151,y:559,t:1527613685830};\\\", \\\"{x:150,y:557,t:1527613685845};\\\", \\\"{x:147,y:553,t:1527613685861};\\\", \\\"{x:146,y:550,t:1527613685879};\\\", \\\"{x:145,y:549,t:1527613685896};\\\", \\\"{x:145,y:547,t:1527613685911};\\\", \\\"{x:145,y:546,t:1527613685954};\\\", \\\"{x:157,y:547,t:1527613686228};\\\", \\\"{x:202,y:569,t:1527613686246};\\\", \\\"{x:281,y:597,t:1527613686263};\\\", \\\"{x:365,y:626,t:1527613686279};\\\", \\\"{x:448,y:651,t:1527613686296};\\\", \\\"{x:497,y:668,t:1527613686313};\\\", \\\"{x:524,y:677,t:1527613686329};\\\", \\\"{x:547,y:687,t:1527613686346};\\\", \\\"{x:558,y:692,t:1527613686363};\\\", \\\"{x:567,y:694,t:1527613686379};\\\", \\\"{x:578,y:697,t:1527613686395};\\\", \\\"{x:583,y:698,t:1527613686412};\\\", \\\"{x:584,y:698,t:1527613686466};\\\", \\\"{x:578,y:698,t:1527613686523};\\\", \\\"{x:550,y:693,t:1527613686531};\\\", \\\"{x:469,y:682,t:1527613686546};\\\", \\\"{x:365,y:656,t:1527613686564};\\\", \\\"{x:309,y:639,t:1527613686580};\\\", \\\"{x:240,y:621,t:1527613686596};\\\", \\\"{x:194,y:604,t:1527613686613};\\\", \\\"{x:174,y:594,t:1527613686630};\\\", \\\"{x:167,y:589,t:1527613686646};\\\", \\\"{x:164,y:587,t:1527613686663};\\\", \\\"{x:163,y:585,t:1527613686680};\\\", \\\"{x:163,y:582,t:1527613686696};\\\", \\\"{x:162,y:580,t:1527613686712};\\\", \\\"{x:160,y:576,t:1527613686730};\\\", \\\"{x:160,y:573,t:1527613686745};\\\", \\\"{x:160,y:569,t:1527613686762};\\\", \\\"{x:160,y:565,t:1527613686780};\\\", \\\"{x:160,y:561,t:1527613686796};\\\", \\\"{x:160,y:559,t:1527613686814};\\\", \\\"{x:160,y:556,t:1527613686829};\\\", \\\"{x:160,y:555,t:1527613686847};\\\", \\\"{x:160,y:553,t:1527613686863};\\\", \\\"{x:160,y:552,t:1527613686908};\\\", \\\"{x:160,y:550,t:1527613686921};\\\", \\\"{x:160,y:549,t:1527613686937};\\\", \\\"{x:160,y:548,t:1527613686947};\\\", \\\"{x:159,y:546,t:1527613686962};\\\", \\\"{x:159,y:544,t:1527613686980};\\\", \\\"{x:159,y:542,t:1527613686996};\\\", \\\"{x:159,y:540,t:1527613687013};\\\", \\\"{x:159,y:539,t:1527613687029};\\\", \\\"{x:159,y:538,t:1527613687045};\\\", \\\"{x:161,y:536,t:1527613687442};\\\", \\\"{x:166,y:536,t:1527613687450};\\\", \\\"{x:177,y:537,t:1527613687464};\\\", \\\"{x:210,y:556,t:1527613687480};\\\", \\\"{x:272,y:588,t:1527613687497};\\\", \\\"{x:374,y:641,t:1527613687514};\\\", \\\"{x:424,y:664,t:1527613687529};\\\", \\\"{x:464,y:685,t:1527613687547};\\\", \\\"{x:495,y:700,t:1527613687563};\\\", \\\"{x:516,y:710,t:1527613687579};\\\", \\\"{x:532,y:720,t:1527613687597};\\\", \\\"{x:546,y:726,t:1527613687613};\\\", \\\"{x:556,y:731,t:1527613687629};\\\", \\\"{x:562,y:733,t:1527613687646};\\\", \\\"{x:567,y:736,t:1527613687664};\\\", \\\"{x:570,y:737,t:1527613687679};\\\", \\\"{x:575,y:738,t:1527613687697};\\\", \\\"{x:579,y:738,t:1527613687714};\\\", \\\"{x:580,y:738,t:1527613687755};\\\", \\\"{x:581,y:737,t:1527613687764};\\\", \\\"{x:581,y:736,t:1527613687780};\\\", \\\"{x:581,y:735,t:1527613687796};\\\", \\\"{x:581,y:731,t:1527613687814};\\\", \\\"{x:581,y:727,t:1527613687831};\\\", \\\"{x:576,y:721,t:1527613687847};\\\", \\\"{x:572,y:716,t:1527613687864};\\\", \\\"{x:568,y:711,t:1527613687881};\\\", \\\"{x:565,y:709,t:1527613687897};\\\", \\\"{x:562,y:707,t:1527613687915};\\\", \\\"{x:562,y:706,t:1527613687931};\\\", \\\"{x:561,y:705,t:1527613687947};\\\", \\\"{x:563,y:705,t:1527613689227};\\\", \\\"{x:572,y:705,t:1527613689234};\\\", \\\"{x:577,y:703,t:1527613689248};\\\", \\\"{x:586,y:701,t:1527613689265};\\\", \\\"{x:616,y:701,t:1527613689291};\\\", \\\"{x:622,y:701,t:1527613689297};\\\", \\\"{x:639,y:701,t:1527613689315};\\\", \\\"{x:654,y:701,t:1527613689331};\\\", \\\"{x:671,y:701,t:1527613689348};\\\", \\\"{x:702,y:701,t:1527613689365};\\\" ] }, { \\\"rt\\\": 47635, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 129819, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"K7JVY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-04 PM-04 PM-U -A -12 PM-06 PM-05 PM-02 PM-01 PM-F \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1078,y:619,t:1527613689556};\\\", \\\"{x:1089,y:614,t:1527613689566};\\\", \\\"{x:1113,y:611,t:1527613689582};\\\", \\\"{x:1139,y:603,t:1527613689599};\\\", \\\"{x:1170,y:595,t:1527613689614};\\\", \\\"{x:1201,y:585,t:1527613689644};\\\", \\\"{x:1206,y:583,t:1527613689655};\\\", \\\"{x:1209,y:583,t:1527613689665};\\\", \\\"{x:1213,y:580,t:1527613689682};\\\", \\\"{x:1214,y:580,t:1527613689802};\\\", \\\"{x:1214,y:586,t:1527613689815};\\\", \\\"{x:1214,y:593,t:1527613689832};\\\", \\\"{x:1211,y:591,t:1527613690283};\\\", \\\"{x:1194,y:579,t:1527613690299};\\\", \\\"{x:1171,y:569,t:1527613690316};\\\", \\\"{x:1141,y:563,t:1527613690332};\\\", \\\"{x:1106,y:556,t:1527613690350};\\\", \\\"{x:1076,y:553,t:1527613690366};\\\", \\\"{x:1048,y:548,t:1527613690382};\\\", \\\"{x:1037,y:545,t:1527613690399};\\\", \\\"{x:1015,y:545,t:1527613690416};\\\", \\\"{x:1001,y:545,t:1527613690432};\\\", \\\"{x:985,y:545,t:1527613690449};\\\", \\\"{x:957,y:545,t:1527613690466};\\\", \\\"{x:937,y:545,t:1527613690484};\\\", \\\"{x:907,y:545,t:1527613690499};\\\", \\\"{x:862,y:545,t:1527613690516};\\\", \\\"{x:825,y:545,t:1527613690533};\\\", \\\"{x:784,y:545,t:1527613690549};\\\", \\\"{x:736,y:545,t:1527613690566};\\\", \\\"{x:691,y:545,t:1527613690584};\\\", \\\"{x:652,y:545,t:1527613690599};\\\", \\\"{x:624,y:545,t:1527613690616};\\\", \\\"{x:602,y:545,t:1527613690633};\\\", \\\"{x:581,y:545,t:1527613690649};\\\", \\\"{x:562,y:545,t:1527613690666};\\\", \\\"{x:559,y:545,t:1527613690683};\\\", \\\"{x:558,y:545,t:1527613690705};\\\", \\\"{x:562,y:544,t:1527613690716};\\\", \\\"{x:578,y:539,t:1527613690732};\\\", \\\"{x:623,y:534,t:1527613690749};\\\", \\\"{x:718,y:529,t:1527613690766};\\\", \\\"{x:854,y:529,t:1527613690784};\\\", \\\"{x:1031,y:529,t:1527613690800};\\\", \\\"{x:1199,y:529,t:1527613690816};\\\", \\\"{x:1351,y:529,t:1527613690833};\\\", \\\"{x:1487,y:529,t:1527613690850};\\\", \\\"{x:1638,y:545,t:1527613690867};\\\", \\\"{x:1719,y:569,t:1527613690883};\\\", \\\"{x:1779,y:593,t:1527613690899};\\\", \\\"{x:1821,y:613,t:1527613690916};\\\", \\\"{x:1858,y:631,t:1527613690933};\\\", \\\"{x:1878,y:644,t:1527613690949};\\\", \\\"{x:1893,y:656,t:1527613690966};\\\", \\\"{x:1907,y:671,t:1527613690983};\\\", \\\"{x:1919,y:687,t:1527613690999};\\\", \\\"{x:1919,y:710,t:1527613691015};\\\", \\\"{x:1919,y:732,t:1527613691033};\\\", \\\"{x:1919,y:762,t:1527613691050};\\\", \\\"{x:1919,y:777,t:1527613691066};\\\", \\\"{x:1916,y:789,t:1527613691083};\\\", \\\"{x:1909,y:803,t:1527613691100};\\\", \\\"{x:1900,y:813,t:1527613691117};\\\", \\\"{x:1884,y:826,t:1527613691133};\\\", \\\"{x:1870,y:837,t:1527613691150};\\\", \\\"{x:1859,y:850,t:1527613691166};\\\", \\\"{x:1845,y:861,t:1527613691183};\\\", \\\"{x:1830,y:872,t:1527613691201};\\\", \\\"{x:1812,y:881,t:1527613691218};\\\", \\\"{x:1796,y:891,t:1527613691233};\\\", \\\"{x:1774,y:904,t:1527613691250};\\\", \\\"{x:1758,y:910,t:1527613691267};\\\", \\\"{x:1738,y:918,t:1527613691283};\\\", \\\"{x:1710,y:928,t:1527613691300};\\\", \\\"{x:1693,y:933,t:1527613691317};\\\", \\\"{x:1683,y:935,t:1527613691333};\\\", \\\"{x:1675,y:937,t:1527613691351};\\\", \\\"{x:1670,y:938,t:1527613691368};\\\", \\\"{x:1665,y:939,t:1527613691383};\\\", \\\"{x:1660,y:941,t:1527613691400};\\\", \\\"{x:1656,y:943,t:1527613691417};\\\", \\\"{x:1648,y:945,t:1527613691433};\\\", \\\"{x:1640,y:949,t:1527613691450};\\\", \\\"{x:1636,y:949,t:1527613691467};\\\", \\\"{x:1630,y:949,t:1527613691483};\\\", \\\"{x:1625,y:949,t:1527613691500};\\\", \\\"{x:1618,y:951,t:1527613691517};\\\", \\\"{x:1607,y:956,t:1527613691533};\\\", \\\"{x:1597,y:960,t:1527613691550};\\\", \\\"{x:1589,y:961,t:1527613691567};\\\", \\\"{x:1585,y:962,t:1527613691583};\\\", \\\"{x:1581,y:964,t:1527613691600};\\\", \\\"{x:1577,y:964,t:1527613691617};\\\", \\\"{x:1574,y:966,t:1527613691634};\\\", \\\"{x:1572,y:967,t:1527613691650};\\\", \\\"{x:1571,y:967,t:1527613691747};\\\", \\\"{x:1570,y:967,t:1527613691867};\\\", \\\"{x:1569,y:968,t:1527613691955};\\\", \\\"{x:1569,y:969,t:1527613692123};\\\", \\\"{x:1571,y:969,t:1527613692467};\\\", \\\"{x:1572,y:969,t:1527613692507};\\\", \\\"{x:1574,y:969,t:1527613692518};\\\", \\\"{x:1588,y:969,t:1527613692534};\\\", \\\"{x:1599,y:967,t:1527613692551};\\\", \\\"{x:1615,y:963,t:1527613692568};\\\", \\\"{x:1633,y:961,t:1527613692584};\\\", \\\"{x:1643,y:959,t:1527613692601};\\\", \\\"{x:1648,y:959,t:1527613692619};\\\", \\\"{x:1648,y:958,t:1527613692635};\\\", \\\"{x:1646,y:958,t:1527613692859};\\\", \\\"{x:1641,y:958,t:1527613692869};\\\", \\\"{x:1633,y:958,t:1527613692885};\\\", \\\"{x:1622,y:958,t:1527613692901};\\\", \\\"{x:1612,y:958,t:1527613692918};\\\", \\\"{x:1610,y:958,t:1527613692935};\\\", \\\"{x:1609,y:958,t:1527613692952};\\\", \\\"{x:1608,y:957,t:1527613693323};\\\", \\\"{x:1608,y:956,t:1527613693355};\\\", \\\"{x:1608,y:955,t:1527613693409};\\\", \\\"{x:1608,y:954,t:1527613693441};\\\", \\\"{x:1608,y:953,t:1527613693452};\\\", \\\"{x:1608,y:952,t:1527613693522};\\\", \\\"{x:1608,y:951,t:1527613693554};\\\", \\\"{x:1608,y:950,t:1527613693568};\\\", \\\"{x:1609,y:949,t:1527613693602};\\\", \\\"{x:1610,y:948,t:1527613693626};\\\", \\\"{x:1610,y:947,t:1527613693643};\\\", \\\"{x:1610,y:946,t:1527613693667};\\\", \\\"{x:1610,y:944,t:1527613693692};\\\", \\\"{x:1611,y:944,t:1527613693723};\\\", \\\"{x:1611,y:943,t:1527613693735};\\\", \\\"{x:1611,y:942,t:1527613693755};\\\", \\\"{x:1612,y:941,t:1527613693769};\\\", \\\"{x:1611,y:935,t:1527613700195};\\\", \\\"{x:1599,y:926,t:1527613700208};\\\", \\\"{x:1575,y:905,t:1527613700224};\\\", \\\"{x:1542,y:886,t:1527613700241};\\\", \\\"{x:1526,y:874,t:1527613700258};\\\", \\\"{x:1512,y:866,t:1527613700275};\\\", \\\"{x:1507,y:861,t:1527613700290};\\\", \\\"{x:1507,y:859,t:1527613700308};\\\", \\\"{x:1505,y:858,t:1527613700386};\\\", \\\"{x:1504,y:857,t:1527613700394};\\\", \\\"{x:1503,y:856,t:1527613700407};\\\", \\\"{x:1499,y:852,t:1527613700423};\\\", \\\"{x:1493,y:850,t:1527613700441};\\\", \\\"{x:1490,y:848,t:1527613700457};\\\", \\\"{x:1489,y:847,t:1527613700475};\\\", \\\"{x:1488,y:845,t:1527613700492};\\\", \\\"{x:1487,y:845,t:1527613700546};\\\", \\\"{x:1486,y:844,t:1527613700561};\\\", \\\"{x:1485,y:843,t:1527613700574};\\\", \\\"{x:1484,y:840,t:1527613700590};\\\", \\\"{x:1483,y:838,t:1527613700607};\\\", \\\"{x:1483,y:836,t:1527613700624};\\\", \\\"{x:1483,y:833,t:1527613700640};\\\", \\\"{x:1483,y:830,t:1527613700658};\\\", \\\"{x:1482,y:828,t:1527613700673};\\\", \\\"{x:1482,y:825,t:1527613700692};\\\", \\\"{x:1481,y:823,t:1527613700707};\\\", \\\"{x:1481,y:821,t:1527613700729};\\\", \\\"{x:1481,y:819,t:1527613700745};\\\", \\\"{x:1481,y:818,t:1527613700757};\\\", \\\"{x:1481,y:816,t:1527613700774};\\\", \\\"{x:1481,y:815,t:1527613700791};\\\", \\\"{x:1481,y:813,t:1527613700809};\\\", \\\"{x:1481,y:812,t:1527613700824};\\\", \\\"{x:1481,y:808,t:1527613700841};\\\", \\\"{x:1481,y:806,t:1527613700858};\\\", \\\"{x:1481,y:805,t:1527613700898};\\\", \\\"{x:1481,y:804,t:1527613700930};\\\", \\\"{x:1480,y:804,t:1527613701859};\\\", \\\"{x:1480,y:806,t:1527613701875};\\\", \\\"{x:1479,y:807,t:1527613701893};\\\", \\\"{x:1478,y:809,t:1527613701909};\\\", \\\"{x:1477,y:809,t:1527613705634};\\\", \\\"{x:1465,y:823,t:1527613705645};\\\", \\\"{x:1435,y:861,t:1527613705662};\\\", \\\"{x:1409,y:887,t:1527613705677};\\\", \\\"{x:1389,y:904,t:1527613705694};\\\", \\\"{x:1380,y:912,t:1527613705711};\\\", \\\"{x:1378,y:914,t:1527613705728};\\\", \\\"{x:1377,y:915,t:1527613705834};\\\", \\\"{x:1377,y:916,t:1527613705883};\\\", \\\"{x:1377,y:917,t:1527613705896};\\\", \\\"{x:1377,y:919,t:1527613705912};\\\", \\\"{x:1377,y:921,t:1527613705929};\\\", \\\"{x:1377,y:922,t:1527613705947};\\\", \\\"{x:1377,y:923,t:1527613705962};\\\", \\\"{x:1379,y:926,t:1527613705979};\\\", \\\"{x:1380,y:928,t:1527613705995};\\\", \\\"{x:1381,y:928,t:1527613706013};\\\", \\\"{x:1382,y:930,t:1527613706029};\\\", \\\"{x:1384,y:931,t:1527613706046};\\\", \\\"{x:1385,y:933,t:1527613706062};\\\", \\\"{x:1386,y:935,t:1527613706080};\\\", \\\"{x:1386,y:936,t:1527613706095};\\\", \\\"{x:1387,y:937,t:1527613706113};\\\", \\\"{x:1388,y:937,t:1527613706179};\\\", \\\"{x:1389,y:937,t:1527613706211};\\\", \\\"{x:1390,y:938,t:1527613706235};\\\", \\\"{x:1391,y:938,t:1527613706250};\\\", \\\"{x:1393,y:939,t:1527613706263};\\\", \\\"{x:1394,y:940,t:1527613706292};\\\", \\\"{x:1395,y:940,t:1527613706298};\\\", \\\"{x:1396,y:940,t:1527613706339};\\\", \\\"{x:1396,y:942,t:1527613706355};\\\", \\\"{x:1396,y:943,t:1527613706371};\\\", \\\"{x:1396,y:944,t:1527613706379};\\\", \\\"{x:1395,y:944,t:1527613707331};\\\", \\\"{x:1396,y:942,t:1527613707347};\\\", \\\"{x:1397,y:938,t:1527613707364};\\\", \\\"{x:1398,y:936,t:1527613707380};\\\", \\\"{x:1399,y:934,t:1527613707396};\\\", \\\"{x:1400,y:933,t:1527613707418};\\\", \\\"{x:1400,y:932,t:1527613707450};\\\", \\\"{x:1400,y:931,t:1527613707482};\\\", \\\"{x:1400,y:930,t:1527613707563};\\\", \\\"{x:1400,y:929,t:1527613707603};\\\", \\\"{x:1400,y:928,t:1527613707627};\\\", \\\"{x:1400,y:926,t:1527613707635};\\\", \\\"{x:1400,y:923,t:1527613707651};\\\", \\\"{x:1400,y:920,t:1527613707663};\\\", \\\"{x:1400,y:916,t:1527613707679};\\\", \\\"{x:1400,y:907,t:1527613707697};\\\", \\\"{x:1400,y:896,t:1527613707713};\\\", \\\"{x:1399,y:884,t:1527613707729};\\\", \\\"{x:1399,y:878,t:1527613707747};\\\", \\\"{x:1398,y:873,t:1527613707763};\\\", \\\"{x:1398,y:869,t:1527613707780};\\\", \\\"{x:1398,y:867,t:1527613707810};\\\", \\\"{x:1398,y:866,t:1527613707833};\\\", \\\"{x:1398,y:864,t:1527613707850};\\\", \\\"{x:1398,y:863,t:1527613707882};\\\", \\\"{x:1398,y:861,t:1527613707898};\\\", \\\"{x:1397,y:866,t:1527613708092};\\\", \\\"{x:1395,y:871,t:1527613708099};\\\", \\\"{x:1394,y:877,t:1527613708114};\\\", \\\"{x:1393,y:885,t:1527613708130};\\\", \\\"{x:1391,y:892,t:1527613708147};\\\", \\\"{x:1391,y:897,t:1527613708165};\\\", \\\"{x:1391,y:900,t:1527613708180};\\\", \\\"{x:1391,y:903,t:1527613708197};\\\", \\\"{x:1391,y:905,t:1527613708214};\\\", \\\"{x:1391,y:906,t:1527613708231};\\\", \\\"{x:1392,y:907,t:1527613708248};\\\", \\\"{x:1393,y:910,t:1527613708264};\\\", \\\"{x:1394,y:911,t:1527613708283};\\\", \\\"{x:1395,y:911,t:1527613708346};\\\", \\\"{x:1397,y:913,t:1527613708364};\\\", \\\"{x:1402,y:913,t:1527613708381};\\\", \\\"{x:1408,y:915,t:1527613708397};\\\", \\\"{x:1415,y:917,t:1527613708414};\\\", \\\"{x:1419,y:917,t:1527613708431};\\\", \\\"{x:1422,y:919,t:1527613708447};\\\", \\\"{x:1424,y:921,t:1527613708464};\\\", \\\"{x:1427,y:922,t:1527613708481};\\\", \\\"{x:1428,y:923,t:1527613708498};\\\", \\\"{x:1429,y:925,t:1527613708531};\\\", \\\"{x:1430,y:925,t:1527613708547};\\\", \\\"{x:1430,y:927,t:1527613708565};\\\", \\\"{x:1431,y:928,t:1527613708582};\\\", \\\"{x:1433,y:928,t:1527613708597};\\\", \\\"{x:1433,y:929,t:1527613708615};\\\", \\\"{x:1433,y:933,t:1527613708631};\\\", \\\"{x:1434,y:936,t:1527613708648};\\\", \\\"{x:1434,y:938,t:1527613708664};\\\", \\\"{x:1435,y:940,t:1527613708681};\\\", \\\"{x:1436,y:942,t:1527613708738};\\\", \\\"{x:1436,y:941,t:1527613710315};\\\", \\\"{x:1436,y:940,t:1527613710333};\\\", \\\"{x:1437,y:938,t:1527613710349};\\\", \\\"{x:1437,y:936,t:1527613710365};\\\", \\\"{x:1437,y:935,t:1527613710386};\\\", \\\"{x:1437,y:934,t:1527613711475};\\\", \\\"{x:1430,y:934,t:1527613711484};\\\", \\\"{x:1398,y:934,t:1527613711499};\\\", \\\"{x:1348,y:934,t:1527613711517};\\\", \\\"{x:1316,y:934,t:1527613711534};\\\", \\\"{x:1289,y:932,t:1527613711550};\\\", \\\"{x:1268,y:929,t:1527613711567};\\\", \\\"{x:1253,y:926,t:1527613711584};\\\", \\\"{x:1240,y:922,t:1527613711601};\\\", \\\"{x:1228,y:918,t:1527613711617};\\\", \\\"{x:1219,y:917,t:1527613711634};\\\", \\\"{x:1208,y:915,t:1527613711650};\\\", \\\"{x:1197,y:914,t:1527613711667};\\\", \\\"{x:1188,y:912,t:1527613711683};\\\", \\\"{x:1183,y:910,t:1527613711700};\\\", \\\"{x:1182,y:910,t:1527613711716};\\\", \\\"{x:1180,y:909,t:1527613711733};\\\", \\\"{x:1179,y:908,t:1527613711749};\\\", \\\"{x:1179,y:905,t:1527613711766};\\\", \\\"{x:1178,y:901,t:1527613711783};\\\", \\\"{x:1178,y:896,t:1527613711800};\\\", \\\"{x:1178,y:892,t:1527613711816};\\\", \\\"{x:1178,y:889,t:1527613711833};\\\", \\\"{x:1179,y:881,t:1527613711849};\\\", \\\"{x:1186,y:875,t:1527613711866};\\\", \\\"{x:1191,y:871,t:1527613711883};\\\", \\\"{x:1197,y:865,t:1527613711900};\\\", \\\"{x:1200,y:862,t:1527613711917};\\\", \\\"{x:1204,y:858,t:1527613711933};\\\", \\\"{x:1206,y:856,t:1527613711950};\\\", \\\"{x:1208,y:854,t:1527613711967};\\\", \\\"{x:1209,y:853,t:1527613711983};\\\", \\\"{x:1209,y:851,t:1527613712009};\\\", \\\"{x:1210,y:851,t:1527613712018};\\\", \\\"{x:1211,y:850,t:1527613712034};\\\", \\\"{x:1212,y:849,t:1527613712074};\\\", \\\"{x:1212,y:848,t:1527613712090};\\\", \\\"{x:1212,y:847,t:1527613712106};\\\", \\\"{x:1214,y:846,t:1527613712121};\\\", \\\"{x:1214,y:845,t:1527613712133};\\\", \\\"{x:1214,y:843,t:1527613712150};\\\", \\\"{x:1215,y:842,t:1527613712167};\\\", \\\"{x:1216,y:840,t:1527613712183};\\\", \\\"{x:1216,y:837,t:1527613712200};\\\", \\\"{x:1217,y:836,t:1527613712218};\\\", \\\"{x:1218,y:835,t:1527613712234};\\\", \\\"{x:1219,y:832,t:1527613712251};\\\", \\\"{x:1219,y:830,t:1527613712274};\\\", \\\"{x:1220,y:830,t:1527613712283};\\\", \\\"{x:1220,y:829,t:1527613712306};\\\", \\\"{x:1221,y:828,t:1527613712322};\\\", \\\"{x:1222,y:827,t:1527613712334};\\\", \\\"{x:1222,y:826,t:1527613712351};\\\", \\\"{x:1223,y:824,t:1527613712368};\\\", \\\"{x:1224,y:823,t:1527613712403};\\\", \\\"{x:1224,y:822,t:1527613712418};\\\", \\\"{x:1224,y:821,t:1527613712434};\\\", \\\"{x:1225,y:820,t:1527613712458};\\\", \\\"{x:1225,y:819,t:1527613712468};\\\", \\\"{x:1226,y:816,t:1527613712485};\\\", \\\"{x:1228,y:813,t:1527613712500};\\\", \\\"{x:1230,y:810,t:1527613712518};\\\", \\\"{x:1234,y:806,t:1527613712534};\\\", \\\"{x:1234,y:805,t:1527613712550};\\\", \\\"{x:1238,y:803,t:1527613712567};\\\", \\\"{x:1239,y:802,t:1527613712584};\\\", \\\"{x:1250,y:801,t:1527613712601};\\\", \\\"{x:1259,y:801,t:1527613712617};\\\", \\\"{x:1264,y:801,t:1527613712634};\\\", \\\"{x:1267,y:801,t:1527613712651};\\\", \\\"{x:1269,y:801,t:1527613712667};\\\", \\\"{x:1271,y:802,t:1527613712685};\\\", \\\"{x:1271,y:804,t:1527613712737};\\\", \\\"{x:1271,y:805,t:1527613712750};\\\", \\\"{x:1270,y:805,t:1527613712767};\\\", \\\"{x:1270,y:807,t:1527613712783};\\\", \\\"{x:1271,y:807,t:1527613713026};\\\", \\\"{x:1272,y:807,t:1527613713035};\\\", \\\"{x:1273,y:807,t:1527613713138};\\\", \\\"{x:1274,y:807,t:1527613713275};\\\", \\\"{x:1275,y:807,t:1527613713285};\\\", \\\"{x:1276,y:807,t:1527613713302};\\\", \\\"{x:1278,y:805,t:1527613713318};\\\", \\\"{x:1280,y:804,t:1527613713334};\\\", \\\"{x:1283,y:803,t:1527613713351};\\\", \\\"{x:1286,y:803,t:1527613713369};\\\", \\\"{x:1296,y:803,t:1527613713384};\\\", \\\"{x:1307,y:803,t:1527613713401};\\\", \\\"{x:1332,y:814,t:1527613713418};\\\", \\\"{x:1354,y:824,t:1527613713434};\\\", \\\"{x:1374,y:831,t:1527613713451};\\\", \\\"{x:1392,y:841,t:1527613713468};\\\", \\\"{x:1403,y:850,t:1527613713484};\\\", \\\"{x:1407,y:855,t:1527613713501};\\\", \\\"{x:1409,y:859,t:1527613713518};\\\", \\\"{x:1409,y:861,t:1527613713534};\\\", \\\"{x:1410,y:863,t:1527613713551};\\\", \\\"{x:1410,y:865,t:1527613713568};\\\", \\\"{x:1410,y:867,t:1527613713584};\\\", \\\"{x:1405,y:873,t:1527613713601};\\\", \\\"{x:1402,y:881,t:1527613713618};\\\", \\\"{x:1399,y:887,t:1527613713634};\\\", \\\"{x:1394,y:893,t:1527613713651};\\\", \\\"{x:1389,y:900,t:1527613713668};\\\", \\\"{x:1385,y:907,t:1527613713684};\\\", \\\"{x:1382,y:911,t:1527613713701};\\\", \\\"{x:1379,y:917,t:1527613713718};\\\", \\\"{x:1376,y:920,t:1527613713734};\\\", \\\"{x:1373,y:924,t:1527613713751};\\\", \\\"{x:1371,y:928,t:1527613713768};\\\", \\\"{x:1368,y:933,t:1527613713785};\\\", \\\"{x:1367,y:936,t:1527613713801};\\\", \\\"{x:1365,y:938,t:1527613713818};\\\", \\\"{x:1364,y:940,t:1527613713834};\\\", \\\"{x:1363,y:942,t:1527613713851};\\\", \\\"{x:1361,y:943,t:1527613713868};\\\", \\\"{x:1359,y:945,t:1527613713885};\\\", \\\"{x:1358,y:947,t:1527613713901};\\\", \\\"{x:1357,y:947,t:1527613713962};\\\", \\\"{x:1356,y:947,t:1527613713994};\\\", \\\"{x:1355,y:947,t:1527613714002};\\\", \\\"{x:1354,y:947,t:1527613714026};\\\", \\\"{x:1353,y:947,t:1527613714123};\\\", \\\"{x:1352,y:947,t:1527613714135};\\\", \\\"{x:1351,y:947,t:1527613714171};\\\", \\\"{x:1350,y:947,t:1527613714194};\\\", \\\"{x:1350,y:946,t:1527613714203};\\\", \\\"{x:1349,y:942,t:1527613714219};\\\", \\\"{x:1349,y:938,t:1527613714236};\\\", \\\"{x:1347,y:930,t:1527613714252};\\\", \\\"{x:1346,y:926,t:1527613714269};\\\", \\\"{x:1345,y:921,t:1527613714286};\\\", \\\"{x:1345,y:916,t:1527613714302};\\\", \\\"{x:1344,y:915,t:1527613714318};\\\", \\\"{x:1344,y:913,t:1527613714335};\\\", \\\"{x:1344,y:912,t:1527613714352};\\\", \\\"{x:1343,y:912,t:1527613714368};\\\", \\\"{x:1343,y:911,t:1527613714385};\\\", \\\"{x:1343,y:909,t:1527613714491};\\\", \\\"{x:1342,y:907,t:1527613714505};\\\", \\\"{x:1342,y:906,t:1527613714518};\\\", \\\"{x:1342,y:903,t:1527613714535};\\\", \\\"{x:1341,y:896,t:1527613714552};\\\", \\\"{x:1341,y:889,t:1527613714569};\\\", \\\"{x:1341,y:883,t:1527613714585};\\\", \\\"{x:1341,y:880,t:1527613714602};\\\", \\\"{x:1341,y:879,t:1527613714619};\\\", \\\"{x:1341,y:878,t:1527613714746};\\\", \\\"{x:1340,y:876,t:1527613715092};\\\", \\\"{x:1339,y:873,t:1527613715102};\\\", \\\"{x:1339,y:869,t:1527613715119};\\\", \\\"{x:1339,y:863,t:1527613715137};\\\", \\\"{x:1339,y:857,t:1527613715153};\\\", \\\"{x:1339,y:850,t:1527613715170};\\\", \\\"{x:1339,y:844,t:1527613715186};\\\", \\\"{x:1339,y:839,t:1527613715203};\\\", \\\"{x:1339,y:835,t:1527613715220};\\\", \\\"{x:1340,y:831,t:1527613715237};\\\", \\\"{x:1341,y:829,t:1527613715253};\\\", \\\"{x:1341,y:825,t:1527613715269};\\\", \\\"{x:1341,y:823,t:1527613715287};\\\", \\\"{x:1343,y:819,t:1527613715303};\\\", \\\"{x:1344,y:817,t:1527613715320};\\\", \\\"{x:1346,y:813,t:1527613715336};\\\", \\\"{x:1347,y:812,t:1527613715353};\\\", \\\"{x:1347,y:808,t:1527613715370};\\\", \\\"{x:1347,y:807,t:1527613715475};\\\", \\\"{x:1347,y:806,t:1527613715486};\\\", \\\"{x:1347,y:805,t:1527613715504};\\\", \\\"{x:1347,y:804,t:1527613715520};\\\", \\\"{x:1347,y:802,t:1527613715536};\\\", \\\"{x:1347,y:799,t:1527613715554};\\\", \\\"{x:1347,y:797,t:1527613715570};\\\", \\\"{x:1347,y:793,t:1527613715587};\\\", \\\"{x:1347,y:790,t:1527613715603};\\\", \\\"{x:1346,y:785,t:1527613715620};\\\", \\\"{x:1345,y:776,t:1527613715637};\\\", \\\"{x:1344,y:768,t:1527613715653};\\\", \\\"{x:1342,y:755,t:1527613715670};\\\", \\\"{x:1340,y:744,t:1527613715687};\\\", \\\"{x:1339,y:722,t:1527613715704};\\\", \\\"{x:1337,y:693,t:1527613715720};\\\", \\\"{x:1337,y:682,t:1527613715736};\\\", \\\"{x:1337,y:670,t:1527613715753};\\\", \\\"{x:1337,y:661,t:1527613715769};\\\", \\\"{x:1337,y:654,t:1527613715786};\\\", \\\"{x:1337,y:651,t:1527613715803};\\\", \\\"{x:1337,y:649,t:1527613715819};\\\", \\\"{x:1337,y:648,t:1527613715836};\\\", \\\"{x:1337,y:647,t:1527613715853};\\\", \\\"{x:1337,y:646,t:1527613716251};\\\", \\\"{x:1336,y:646,t:1527613718315};\\\", \\\"{x:1331,y:647,t:1527613718323};\\\", \\\"{x:1327,y:648,t:1527613718338};\\\", \\\"{x:1326,y:648,t:1527613718356};\\\", \\\"{x:1325,y:648,t:1527613718394};\\\", \\\"{x:1322,y:648,t:1527613718406};\\\", \\\"{x:1314,y:649,t:1527613718421};\\\", \\\"{x:1300,y:649,t:1527613718438};\\\", \\\"{x:1277,y:649,t:1527613718455};\\\", \\\"{x:1257,y:649,t:1527613718472};\\\", \\\"{x:1242,y:649,t:1527613718489};\\\", \\\"{x:1230,y:649,t:1527613718506};\\\", \\\"{x:1223,y:648,t:1527613718522};\\\", \\\"{x:1221,y:648,t:1527613718539};\\\", \\\"{x:1220,y:648,t:1527613718555};\\\", \\\"{x:1218,y:648,t:1527613718572};\\\", \\\"{x:1213,y:648,t:1527613718588};\\\", \\\"{x:1196,y:648,t:1527613718605};\\\", \\\"{x:1168,y:648,t:1527613718622};\\\", \\\"{x:1121,y:648,t:1527613718638};\\\", \\\"{x:1073,y:646,t:1527613718655};\\\", \\\"{x:996,y:639,t:1527613718672};\\\", \\\"{x:903,y:629,t:1527613718688};\\\", \\\"{x:715,y:615,t:1527613718706};\\\", \\\"{x:568,y:613,t:1527613718721};\\\", \\\"{x:436,y:604,t:1527613718738};\\\", \\\"{x:305,y:596,t:1527613718757};\\\", \\\"{x:186,y:596,t:1527613718773};\\\", \\\"{x:103,y:596,t:1527613718789};\\\", \\\"{x:50,y:596,t:1527613718806};\\\", \\\"{x:18,y:596,t:1527613718822};\\\", \\\"{x:6,y:596,t:1527613718839};\\\", \\\"{x:5,y:596,t:1527613718856};\\\", \\\"{x:10,y:596,t:1527613719003};\\\", \\\"{x:16,y:594,t:1527613719010};\\\", \\\"{x:22,y:591,t:1527613719022};\\\", \\\"{x:33,y:589,t:1527613719040};\\\", \\\"{x:48,y:587,t:1527613719058};\\\", \\\"{x:80,y:587,t:1527613719073};\\\", \\\"{x:107,y:589,t:1527613719089};\\\", \\\"{x:148,y:595,t:1527613719106};\\\", \\\"{x:193,y:602,t:1527613719123};\\\", \\\"{x:257,y:611,t:1527613719139};\\\", \\\"{x:343,y:622,t:1527613719157};\\\", \\\"{x:465,y:641,t:1527613719173};\\\", \\\"{x:611,y:653,t:1527613719189};\\\", \\\"{x:730,y:670,t:1527613719206};\\\", \\\"{x:834,y:678,t:1527613719223};\\\", \\\"{x:918,y:681,t:1527613719239};\\\", \\\"{x:961,y:688,t:1527613719256};\\\", \\\"{x:990,y:693,t:1527613719274};\\\", \\\"{x:995,y:694,t:1527613719291};\\\", \\\"{x:996,y:694,t:1527613719329};\\\", \\\"{x:998,y:694,t:1527613719339};\\\", \\\"{x:1008,y:697,t:1527613719357};\\\", \\\"{x:1026,y:699,t:1527613719373};\\\", \\\"{x:1045,y:702,t:1527613719389};\\\", \\\"{x:1062,y:704,t:1527613719407};\\\", \\\"{x:1086,y:709,t:1527613719423};\\\", \\\"{x:1110,y:713,t:1527613719440};\\\", \\\"{x:1130,y:716,t:1527613719457};\\\", \\\"{x:1138,y:718,t:1527613719473};\\\", \\\"{x:1139,y:718,t:1527613719489};\\\", \\\"{x:1138,y:719,t:1527613719546};\\\", \\\"{x:1136,y:719,t:1527613719557};\\\", \\\"{x:1124,y:721,t:1527613719573};\\\", \\\"{x:1101,y:721,t:1527613719590};\\\", \\\"{x:1074,y:721,t:1527613719607};\\\", \\\"{x:1046,y:721,t:1527613719623};\\\", \\\"{x:1017,y:721,t:1527613719641};\\\", \\\"{x:985,y:721,t:1527613719657};\\\", \\\"{x:940,y:721,t:1527613719674};\\\", \\\"{x:912,y:721,t:1527613719690};\\\", \\\"{x:890,y:721,t:1527613719706};\\\", \\\"{x:873,y:719,t:1527613719724};\\\", \\\"{x:866,y:719,t:1527613719740};\\\", \\\"{x:861,y:717,t:1527613719757};\\\", \\\"{x:859,y:717,t:1527613719774};\\\", \\\"{x:858,y:717,t:1527613719793};\\\", \\\"{x:857,y:717,t:1527613719826};\\\", \\\"{x:856,y:717,t:1527613719841};\\\", \\\"{x:854,y:716,t:1527613719865};\\\", \\\"{x:853,y:716,t:1527613719881};\\\", \\\"{x:850,y:716,t:1527613719891};\\\", \\\"{x:845,y:715,t:1527613719906};\\\", \\\"{x:836,y:714,t:1527613719923};\\\", \\\"{x:833,y:713,t:1527613719940};\\\", \\\"{x:829,y:713,t:1527613719958};\\\", \\\"{x:825,y:712,t:1527613719973};\\\", \\\"{x:819,y:711,t:1527613719990};\\\", \\\"{x:809,y:709,t:1527613720007};\\\", \\\"{x:800,y:709,t:1527613720023};\\\", \\\"{x:794,y:709,t:1527613720041};\\\", \\\"{x:792,y:708,t:1527613720057};\\\", \\\"{x:790,y:708,t:1527613720323};\\\", \\\"{x:789,y:708,t:1527613720338};\\\", \\\"{x:788,y:708,t:1527613720354};\\\", \\\"{x:787,y:708,t:1527613720370};\\\", \\\"{x:787,y:707,t:1527613720386};\\\", \\\"{x:786,y:706,t:1527613721314};\\\", \\\"{x:785,y:703,t:1527613721324};\\\", \\\"{x:778,y:687,t:1527613721342};\\\", \\\"{x:769,y:663,t:1527613721358};\\\", \\\"{x:755,y:635,t:1527613721375};\\\", \\\"{x:744,y:613,t:1527613721392};\\\", \\\"{x:737,y:606,t:1527613721409};\\\", \\\"{x:734,y:601,t:1527613721425};\\\", \\\"{x:732,y:598,t:1527613721442};\\\", \\\"{x:730,y:596,t:1527613721458};\\\", \\\"{x:726,y:591,t:1527613721475};\\\", \\\"{x:722,y:587,t:1527613721494};\\\", \\\"{x:717,y:583,t:1527613721508};\\\", \\\"{x:706,y:577,t:1527613721525};\\\", \\\"{x:689,y:572,t:1527613721541};\\\", \\\"{x:671,y:562,t:1527613721558};\\\", \\\"{x:659,y:556,t:1527613721574};\\\", \\\"{x:638,y:551,t:1527613721592};\\\", \\\"{x:617,y:550,t:1527613721608};\\\", \\\"{x:594,y:549,t:1527613721625};\\\", \\\"{x:589,y:549,t:1527613721641};\\\", \\\"{x:587,y:549,t:1527613721658};\\\", \\\"{x:586,y:549,t:1527613721738};\\\", \\\"{x:581,y:550,t:1527613721746};\\\", \\\"{x:580,y:552,t:1527613721758};\\\", \\\"{x:575,y:558,t:1527613721777};\\\", \\\"{x:572,y:564,t:1527613721792};\\\", \\\"{x:572,y:569,t:1527613721808};\\\", \\\"{x:572,y:571,t:1527613721824};\\\", \\\"{x:572,y:573,t:1527613721841};\\\", \\\"{x:572,y:574,t:1527613721857};\\\", \\\"{x:572,y:575,t:1527613721922};\\\", \\\"{x:572,y:576,t:1527613721937};\\\", \\\"{x:573,y:576,t:1527613721945};\\\", \\\"{x:574,y:577,t:1527613721969};\\\", \\\"{x:575,y:577,t:1527613722002};\\\", \\\"{x:576,y:577,t:1527613722034};\\\", \\\"{x:577,y:577,t:1527613722083};\\\", \\\"{x:578,y:577,t:1527613722092};\\\", \\\"{x:579,y:577,t:1527613722114};\\\", \\\"{x:580,y:577,t:1527613722138};\\\", \\\"{x:581,y:578,t:1527613722154};\\\", \\\"{x:583,y:579,t:1527613722219};\\\", \\\"{x:585,y:579,t:1527613722242};\\\", \\\"{x:585,y:580,t:1527613722266};\\\", \\\"{x:587,y:580,t:1527613722282};\\\", \\\"{x:588,y:580,t:1527613722347};\\\", \\\"{x:590,y:580,t:1527613722570};\\\", \\\"{x:591,y:580,t:1527613722683};\\\", \\\"{x:593,y:580,t:1527613722994};\\\", \\\"{x:594,y:580,t:1527613723945};\\\", \\\"{x:597,y:580,t:1527613723954};\\\", \\\"{x:602,y:579,t:1527613723971};\\\", \\\"{x:606,y:577,t:1527613723989};\\\", \\\"{x:607,y:576,t:1527613724004};\\\", \\\"{x:608,y:576,t:1527613724882};\\\", \\\"{x:609,y:576,t:1527613725595};\\\", \\\"{x:623,y:577,t:1527613725613};\\\", \\\"{x:651,y:585,t:1527613725630};\\\", \\\"{x:695,y:603,t:1527613725644};\\\", \\\"{x:773,y:625,t:1527613725662};\\\", \\\"{x:889,y:656,t:1527613725678};\\\", \\\"{x:1041,y:698,t:1527613725694};\\\", \\\"{x:1219,y:734,t:1527613725712};\\\", \\\"{x:1419,y:778,t:1527613725728};\\\", \\\"{x:1629,y:813,t:1527613725745};\\\", \\\"{x:1919,y:851,t:1527613725762};\\\", \\\"{x:1919,y:871,t:1527613725778};\\\", \\\"{x:1919,y:883,t:1527613725795};\\\", \\\"{x:1919,y:893,t:1527613725811};\\\", \\\"{x:1918,y:893,t:1527613725881};\\\", \\\"{x:1917,y:894,t:1527613725896};\\\", \\\"{x:1916,y:894,t:1527613725929};\\\", \\\"{x:1906,y:900,t:1527613725945};\\\", \\\"{x:1889,y:907,t:1527613725961};\\\", \\\"{x:1865,y:914,t:1527613725979};\\\", \\\"{x:1842,y:930,t:1527613725996};\\\", \\\"{x:1790,y:941,t:1527613726012};\\\", \\\"{x:1729,y:950,t:1527613726029};\\\", \\\"{x:1662,y:960,t:1527613726046};\\\", \\\"{x:1606,y:966,t:1527613726061};\\\", \\\"{x:1566,y:968,t:1527613726079};\\\", \\\"{x:1542,y:968,t:1527613726096};\\\", \\\"{x:1525,y:968,t:1527613726112};\\\", \\\"{x:1517,y:968,t:1527613726129};\\\", \\\"{x:1510,y:966,t:1527613726146};\\\", \\\"{x:1504,y:966,t:1527613726162};\\\", \\\"{x:1491,y:965,t:1527613726179};\\\", \\\"{x:1477,y:962,t:1527613726196};\\\", \\\"{x:1466,y:961,t:1527613726212};\\\", \\\"{x:1455,y:959,t:1527613726229};\\\", \\\"{x:1448,y:957,t:1527613726245};\\\", \\\"{x:1442,y:956,t:1527613726263};\\\", \\\"{x:1437,y:952,t:1527613726279};\\\", \\\"{x:1430,y:948,t:1527613726296};\\\", \\\"{x:1420,y:942,t:1527613726312};\\\", \\\"{x:1413,y:937,t:1527613726330};\\\", \\\"{x:1408,y:932,t:1527613726346};\\\", \\\"{x:1406,y:930,t:1527613726362};\\\", \\\"{x:1405,y:928,t:1527613726379};\\\", \\\"{x:1405,y:927,t:1527613726418};\\\", \\\"{x:1405,y:926,t:1527613726442};\\\", \\\"{x:1405,y:925,t:1527613726458};\\\", \\\"{x:1405,y:924,t:1527613726466};\\\", \\\"{x:1405,y:923,t:1527613726498};\\\", \\\"{x:1405,y:922,t:1527613726514};\\\", \\\"{x:1405,y:921,t:1527613726529};\\\", \\\"{x:1405,y:920,t:1527613726546};\\\", \\\"{x:1405,y:918,t:1527613726562};\\\", \\\"{x:1405,y:915,t:1527613726579};\\\", \\\"{x:1405,y:912,t:1527613726596};\\\", \\\"{x:1407,y:909,t:1527613726613};\\\", \\\"{x:1408,y:904,t:1527613726629};\\\", \\\"{x:1411,y:900,t:1527613726646};\\\", \\\"{x:1411,y:898,t:1527613726663};\\\", \\\"{x:1413,y:896,t:1527613726679};\\\", \\\"{x:1413,y:894,t:1527613726696};\\\", \\\"{x:1415,y:891,t:1527613726713};\\\", \\\"{x:1418,y:885,t:1527613726730};\\\", \\\"{x:1423,y:873,t:1527613726746};\\\", \\\"{x:1425,y:869,t:1527613726763};\\\", \\\"{x:1426,y:866,t:1527613726780};\\\", \\\"{x:1427,y:862,t:1527613726796};\\\", \\\"{x:1430,y:855,t:1527613726813};\\\", \\\"{x:1433,y:846,t:1527613726830};\\\", \\\"{x:1435,y:841,t:1527613726845};\\\", \\\"{x:1436,y:836,t:1527613726863};\\\", \\\"{x:1437,y:828,t:1527613726879};\\\", \\\"{x:1438,y:820,t:1527613726895};\\\", \\\"{x:1438,y:816,t:1527613726912};\\\", \\\"{x:1438,y:809,t:1527613726929};\\\", \\\"{x:1438,y:802,t:1527613726945};\\\", \\\"{x:1438,y:797,t:1527613726962};\\\", \\\"{x:1436,y:792,t:1527613726980};\\\", \\\"{x:1433,y:787,t:1527613726997};\\\", \\\"{x:1431,y:783,t:1527613727012};\\\", \\\"{x:1429,y:780,t:1527613727030};\\\", \\\"{x:1426,y:776,t:1527613727046};\\\", \\\"{x:1425,y:774,t:1527613727063};\\\", \\\"{x:1425,y:772,t:1527613727079};\\\", \\\"{x:1424,y:772,t:1527613727097};\\\", \\\"{x:1423,y:771,t:1527613727112};\\\", \\\"{x:1422,y:770,t:1527613727129};\\\", \\\"{x:1419,y:769,t:1527613727150};\\\", \\\"{x:1416,y:769,t:1527613727166};\\\", \\\"{x:1414,y:767,t:1527613727183};\\\", \\\"{x:1413,y:767,t:1527613727201};\\\", \\\"{x:1411,y:767,t:1527613727216};\\\", \\\"{x:1410,y:767,t:1527613727246};\\\", \\\"{x:1409,y:767,t:1527613727269};\\\", \\\"{x:1407,y:766,t:1527613727310};\\\", \\\"{x:1406,y:766,t:1527613727399};\\\", \\\"{x:1405,y:766,t:1527613727422};\\\", \\\"{x:1404,y:766,t:1527613727434};\\\", \\\"{x:1402,y:766,t:1527613727451};\\\", \\\"{x:1401,y:766,t:1527613727467};\\\", \\\"{x:1399,y:766,t:1527613727774};\\\", \\\"{x:1398,y:765,t:1527613727806};\\\", \\\"{x:1397,y:764,t:1527613727818};\\\", \\\"{x:1395,y:762,t:1527613727834};\\\", \\\"{x:1394,y:758,t:1527613727851};\\\", \\\"{x:1392,y:757,t:1527613727870};\\\", \\\"{x:1392,y:756,t:1527613727917};\\\", \\\"{x:1391,y:755,t:1527613728463};\\\", \\\"{x:1391,y:754,t:1527613728478};\\\", \\\"{x:1390,y:753,t:1527613728486};\\\", \\\"{x:1390,y:752,t:1527613728510};\\\", \\\"{x:1388,y:750,t:1527613728518};\\\", \\\"{x:1388,y:749,t:1527613728565};\\\", \\\"{x:1387,y:747,t:1527613728613};\\\", \\\"{x:1386,y:745,t:1527613728638};\\\", \\\"{x:1386,y:744,t:1527613728653};\\\", \\\"{x:1385,y:744,t:1527613728668};\\\", \\\"{x:1385,y:743,t:1527613728684};\\\", \\\"{x:1384,y:742,t:1527613728709};\\\", \\\"{x:1383,y:741,t:1527613728750};\\\", \\\"{x:1382,y:743,t:1527613729701};\\\", \\\"{x:1382,y:749,t:1527613729709};\\\", \\\"{x:1381,y:753,t:1527613729718};\\\", \\\"{x:1380,y:766,t:1527613729735};\\\", \\\"{x:1380,y:774,t:1527613729752};\\\", \\\"{x:1380,y:780,t:1527613729768};\\\", \\\"{x:1379,y:787,t:1527613729785};\\\", \\\"{x:1378,y:790,t:1527613729802};\\\", \\\"{x:1377,y:793,t:1527613729818};\\\", \\\"{x:1377,y:795,t:1527613729835};\\\", \\\"{x:1377,y:797,t:1527613729852};\\\", \\\"{x:1377,y:800,t:1527613729869};\\\", \\\"{x:1377,y:803,t:1527613729886};\\\", \\\"{x:1377,y:804,t:1527613729902};\\\", \\\"{x:1377,y:805,t:1527613729920};\\\", \\\"{x:1377,y:806,t:1527613729936};\\\", \\\"{x:1377,y:807,t:1527613729952};\\\", \\\"{x:1377,y:808,t:1527613729989};\\\", \\\"{x:1377,y:809,t:1527613730013};\\\", \\\"{x:1377,y:810,t:1527613730021};\\\", \\\"{x:1377,y:812,t:1527613730045};\\\", \\\"{x:1377,y:813,t:1527613730053};\\\", \\\"{x:1377,y:815,t:1527613730069};\\\", \\\"{x:1377,y:819,t:1527613730086};\\\", \\\"{x:1377,y:823,t:1527613730103};\\\", \\\"{x:1377,y:829,t:1527613730120};\\\", \\\"{x:1377,y:835,t:1527613730136};\\\", \\\"{x:1377,y:843,t:1527613730153};\\\", \\\"{x:1377,y:849,t:1527613730169};\\\", \\\"{x:1377,y:855,t:1527613730186};\\\", \\\"{x:1377,y:860,t:1527613730203};\\\", \\\"{x:1377,y:865,t:1527613730219};\\\", \\\"{x:1377,y:870,t:1527613730235};\\\", \\\"{x:1377,y:876,t:1527613730253};\\\", \\\"{x:1377,y:885,t:1527613730269};\\\", \\\"{x:1377,y:891,t:1527613730285};\\\", \\\"{x:1377,y:897,t:1527613730303};\\\", \\\"{x:1377,y:900,t:1527613730320};\\\", \\\"{x:1377,y:904,t:1527613730337};\\\", \\\"{x:1377,y:906,t:1527613730352};\\\", \\\"{x:1377,y:910,t:1527613730370};\\\", \\\"{x:1377,y:912,t:1527613730386};\\\", \\\"{x:1377,y:917,t:1527613730403};\\\", \\\"{x:1377,y:920,t:1527613730420};\\\", \\\"{x:1377,y:924,t:1527613730437};\\\", \\\"{x:1378,y:928,t:1527613730453};\\\", \\\"{x:1379,y:931,t:1527613730470};\\\", \\\"{x:1379,y:932,t:1527613730487};\\\", \\\"{x:1379,y:934,t:1527613730503};\\\", \\\"{x:1379,y:936,t:1527613730559};\\\", \\\"{x:1379,y:937,t:1527613730622};\\\", \\\"{x:1380,y:937,t:1527613736142};\\\", \\\"{x:1367,y:935,t:1527613736382};\\\", \\\"{x:1318,y:928,t:1527613736391};\\\", \\\"{x:1216,y:914,t:1527613736408};\\\", \\\"{x:1096,y:893,t:1527613736426};\\\", \\\"{x:983,y:862,t:1527613736441};\\\", \\\"{x:873,y:836,t:1527613736458};\\\", \\\"{x:779,y:810,t:1527613736475};\\\", \\\"{x:700,y:782,t:1527613736492};\\\", \\\"{x:649,y:762,t:1527613736508};\\\", \\\"{x:629,y:754,t:1527613736525};\\\", \\\"{x:620,y:748,t:1527613736542};\\\", \\\"{x:617,y:746,t:1527613736559};\\\", \\\"{x:612,y:741,t:1527613736575};\\\", \\\"{x:609,y:739,t:1527613736592};\\\", \\\"{x:600,y:734,t:1527613736609};\\\", \\\"{x:590,y:729,t:1527613736625};\\\", \\\"{x:580,y:724,t:1527613736642};\\\", \\\"{x:576,y:720,t:1527613736658};\\\", \\\"{x:571,y:716,t:1527613736675};\\\", \\\"{x:564,y:712,t:1527613736693};\\\", \\\"{x:561,y:709,t:1527613736710};\\\", \\\"{x:555,y:702,t:1527613736725};\\\", \\\"{x:553,y:698,t:1527613736742};\\\", \\\"{x:552,y:697,t:1527613736756};\\\", \\\"{x:551,y:694,t:1527613736773};\\\", \\\"{x:549,y:692,t:1527613736789};\\\", \\\"{x:548,y:691,t:1527613736806};\\\", \\\"{x:548,y:689,t:1527613736828};\\\", \\\"{x:546,y:688,t:1527613736845};\\\", \\\"{x:546,y:687,t:1527613736893};\\\" ] }, { \\\"rt\\\": 118834, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 249872, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"K7JVY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"U\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-I -12 PM-03 PM-H -01 PM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:547,y:685,t:1527613740646};\\\", \\\"{x:564,y:685,t:1527613740661};\\\", \\\"{x:611,y:695,t:1527613740678};\\\", \\\"{x:666,y:702,t:1527613740694};\\\", \\\"{x:742,y:718,t:1527613740711};\\\", \\\"{x:833,y:728,t:1527613740727};\\\", \\\"{x:907,y:733,t:1527613740744};\\\", \\\"{x:964,y:744,t:1527613740762};\\\", \\\"{x:1004,y:744,t:1527613740778};\\\", \\\"{x:1026,y:744,t:1527613740794};\\\", \\\"{x:1054,y:744,t:1527613740811};\\\", \\\"{x:1075,y:744,t:1527613740828};\\\", \\\"{x:1084,y:744,t:1527613740844};\\\", \\\"{x:1098,y:744,t:1527613740862};\\\", \\\"{x:1103,y:744,t:1527613740878};\\\", \\\"{x:1108,y:744,t:1527613740894};\\\", \\\"{x:1111,y:743,t:1527613740911};\\\", \\\"{x:1114,y:743,t:1527613740928};\\\", \\\"{x:1115,y:742,t:1527613740944};\\\", \\\"{x:1115,y:743,t:1527613741029};\\\", \\\"{x:1115,y:746,t:1527613741044};\\\", \\\"{x:1116,y:753,t:1527613741061};\\\", \\\"{x:1118,y:754,t:1527613741750};\\\", \\\"{x:1120,y:754,t:1527613741762};\\\", \\\"{x:1136,y:756,t:1527613741778};\\\", \\\"{x:1166,y:757,t:1527613741795};\\\", \\\"{x:1253,y:761,t:1527613741813};\\\", \\\"{x:1346,y:769,t:1527613741828};\\\", \\\"{x:1488,y:766,t:1527613741845};\\\", \\\"{x:1599,y:766,t:1527613741862};\\\", \\\"{x:1699,y:766,t:1527613741878};\\\", \\\"{x:1751,y:770,t:1527613741895};\\\", \\\"{x:1801,y:776,t:1527613741912};\\\", \\\"{x:1830,y:780,t:1527613741929};\\\", \\\"{x:1842,y:782,t:1527613741946};\\\", \\\"{x:1854,y:784,t:1527613741962};\\\", \\\"{x:1858,y:785,t:1527613741978};\\\", \\\"{x:1861,y:785,t:1527613741995};\\\", \\\"{x:1861,y:786,t:1527613742238};\\\", \\\"{x:1861,y:788,t:1527613742245};\\\", \\\"{x:1861,y:793,t:1527613742262};\\\", \\\"{x:1860,y:798,t:1527613742280};\\\", \\\"{x:1858,y:800,t:1527613742296};\\\", \\\"{x:1857,y:803,t:1527613742313};\\\", \\\"{x:1856,y:804,t:1527613742329};\\\", \\\"{x:1855,y:805,t:1527613742366};\\\", \\\"{x:1855,y:806,t:1527613742381};\\\", \\\"{x:1854,y:807,t:1527613742398};\\\", \\\"{x:1854,y:809,t:1527613742413};\\\", \\\"{x:1854,y:810,t:1527613742470};\\\", \\\"{x:1852,y:811,t:1527613742501};\\\", \\\"{x:1852,y:813,t:1527613742558};\\\", \\\"{x:1849,y:813,t:1527613744206};\\\", \\\"{x:1847,y:814,t:1527613744214};\\\", \\\"{x:1845,y:814,t:1527613744230};\\\", \\\"{x:1840,y:816,t:1527613744248};\\\", \\\"{x:1838,y:816,t:1527613744264};\\\", \\\"{x:1834,y:816,t:1527613744281};\\\", \\\"{x:1832,y:816,t:1527613744297};\\\", \\\"{x:1829,y:817,t:1527613744314};\\\", \\\"{x:1828,y:817,t:1527613744331};\\\", \\\"{x:1827,y:817,t:1527613744347};\\\", \\\"{x:1824,y:818,t:1527613744364};\\\", \\\"{x:1820,y:818,t:1527613744381};\\\", \\\"{x:1815,y:819,t:1527613744398};\\\", \\\"{x:1805,y:820,t:1527613744414};\\\", \\\"{x:1788,y:824,t:1527613744431};\\\", \\\"{x:1765,y:827,t:1527613744448};\\\", \\\"{x:1739,y:831,t:1527613744463};\\\", \\\"{x:1699,y:833,t:1527613744481};\\\", \\\"{x:1663,y:833,t:1527613744497};\\\", \\\"{x:1626,y:839,t:1527613744513};\\\", \\\"{x:1610,y:842,t:1527613744531};\\\", \\\"{x:1610,y:841,t:1527613744550};\\\", \\\"{x:1610,y:840,t:1527613745447};\\\", \\\"{x:1609,y:839,t:1527613745477};\\\", \\\"{x:1607,y:839,t:1527613745486};\\\", \\\"{x:1605,y:838,t:1527613745502};\\\", \\\"{x:1604,y:838,t:1527613745518};\\\", \\\"{x:1602,y:838,t:1527613745567};\\\", \\\"{x:1601,y:838,t:1527613745590};\\\", \\\"{x:1600,y:838,t:1527613745598};\\\", \\\"{x:1595,y:838,t:1527613745615};\\\", \\\"{x:1590,y:838,t:1527613745631};\\\", \\\"{x:1582,y:838,t:1527613745648};\\\", \\\"{x:1573,y:838,t:1527613745664};\\\", \\\"{x:1558,y:838,t:1527613745682};\\\", \\\"{x:1545,y:838,t:1527613745698};\\\", \\\"{x:1537,y:836,t:1527613745715};\\\", \\\"{x:1525,y:835,t:1527613745732};\\\", \\\"{x:1515,y:834,t:1527613745749};\\\", \\\"{x:1506,y:830,t:1527613745765};\\\", \\\"{x:1490,y:825,t:1527613745782};\\\", \\\"{x:1479,y:822,t:1527613745798};\\\", \\\"{x:1474,y:819,t:1527613745815};\\\", \\\"{x:1468,y:813,t:1527613745832};\\\", \\\"{x:1462,y:806,t:1527613745849};\\\", \\\"{x:1459,y:798,t:1527613745865};\\\", \\\"{x:1455,y:786,t:1527613745882};\\\", \\\"{x:1450,y:769,t:1527613745898};\\\", \\\"{x:1440,y:746,t:1527613745915};\\\", \\\"{x:1433,y:723,t:1527613745932};\\\", \\\"{x:1425,y:699,t:1527613745948};\\\", \\\"{x:1417,y:680,t:1527613745965};\\\", \\\"{x:1405,y:653,t:1527613745982};\\\", \\\"{x:1393,y:625,t:1527613745999};\\\", \\\"{x:1382,y:605,t:1527613746016};\\\", \\\"{x:1370,y:584,t:1527613746032};\\\", \\\"{x:1351,y:563,t:1527613746049};\\\", \\\"{x:1332,y:545,t:1527613746065};\\\", \\\"{x:1310,y:528,t:1527613746082};\\\", \\\"{x:1297,y:515,t:1527613746099};\\\", \\\"{x:1290,y:505,t:1527613746116};\\\", \\\"{x:1286,y:500,t:1527613746132};\\\", \\\"{x:1282,y:492,t:1527613746149};\\\", \\\"{x:1275,y:484,t:1527613746166};\\\", \\\"{x:1272,y:480,t:1527613746182};\\\", \\\"{x:1272,y:478,t:1527613746198};\\\", \\\"{x:1272,y:476,t:1527613746216};\\\", \\\"{x:1271,y:474,t:1527613746232};\\\", \\\"{x:1270,y:473,t:1527613746249};\\\", \\\"{x:1270,y:472,t:1527613746350};\\\", \\\"{x:1273,y:470,t:1527613746365};\\\", \\\"{x:1275,y:470,t:1527613746381};\\\", \\\"{x:1277,y:470,t:1527613746399};\\\", \\\"{x:1279,y:470,t:1527613746416};\\\", \\\"{x:1280,y:470,t:1527613746486};\\\", \\\"{x:1281,y:470,t:1527613746502};\\\", \\\"{x:1282,y:470,t:1527613746518};\\\", \\\"{x:1283,y:470,t:1527613746533};\\\", \\\"{x:1285,y:470,t:1527613746549};\\\", \\\"{x:1286,y:471,t:1527613746565};\\\", \\\"{x:1287,y:471,t:1527613746590};\\\", \\\"{x:1288,y:471,t:1527613746598};\\\", \\\"{x:1289,y:471,t:1527613746616};\\\", \\\"{x:1290,y:471,t:1527613746637};\\\", \\\"{x:1291,y:471,t:1527613746649};\\\", \\\"{x:1292,y:472,t:1527613746666};\\\", \\\"{x:1292,y:473,t:1527613746682};\\\", \\\"{x:1293,y:473,t:1527613746709};\\\", \\\"{x:1294,y:473,t:1527613746726};\\\", \\\"{x:1295,y:473,t:1527613746798};\\\", \\\"{x:1296,y:474,t:1527613746815};\\\", \\\"{x:1297,y:474,t:1527613746832};\\\", \\\"{x:1299,y:474,t:1527613746848};\\\", \\\"{x:1300,y:474,t:1527613746865};\\\", \\\"{x:1301,y:476,t:1527613746893};\\\", \\\"{x:1302,y:476,t:1527613746917};\\\", \\\"{x:1303,y:476,t:1527613746933};\\\", \\\"{x:1304,y:476,t:1527613746948};\\\", \\\"{x:1305,y:476,t:1527613747005};\\\", \\\"{x:1306,y:477,t:1527613747021};\\\", \\\"{x:1307,y:477,t:1527613747174};\\\", \\\"{x:1308,y:477,t:1527613747214};\\\", \\\"{x:1309,y:477,t:1527613747241};\\\", \\\"{x:1310,y:477,t:1527613747265};\\\", \\\"{x:1311,y:478,t:1527613747325};\\\", \\\"{x:1312,y:478,t:1527613747341};\\\", \\\"{x:1313,y:478,t:1527613747357};\\\", \\\"{x:1314,y:478,t:1527613750446};\\\", \\\"{x:1314,y:479,t:1527613750510};\\\", \\\"{x:1314,y:482,t:1527613750520};\\\", \\\"{x:1314,y:490,t:1527613750535};\\\", \\\"{x:1314,y:496,t:1527613750552};\\\", \\\"{x:1314,y:503,t:1527613750569};\\\", \\\"{x:1314,y:506,t:1527613750585};\\\", \\\"{x:1314,y:507,t:1527613750602};\\\", \\\"{x:1314,y:509,t:1527613750619};\\\", \\\"{x:1314,y:510,t:1527613750635};\\\", \\\"{x:1314,y:511,t:1527613750654};\\\", \\\"{x:1314,y:512,t:1527613750670};\\\", \\\"{x:1314,y:513,t:1527613750694};\\\", \\\"{x:1314,y:515,t:1527613750724};\\\", \\\"{x:1314,y:516,t:1527613750741};\\\", \\\"{x:1314,y:518,t:1527613750756};\\\", \\\"{x:1314,y:519,t:1527613750772};\\\", \\\"{x:1314,y:521,t:1527613750789};\\\", \\\"{x:1314,y:522,t:1527613750801};\\\", \\\"{x:1314,y:524,t:1527613750818};\\\", \\\"{x:1314,y:527,t:1527613750835};\\\", \\\"{x:1316,y:530,t:1527613750851};\\\", \\\"{x:1316,y:533,t:1527613750868};\\\", \\\"{x:1317,y:542,t:1527613750885};\\\", \\\"{x:1317,y:547,t:1527613750901};\\\", \\\"{x:1317,y:551,t:1527613750918};\\\", \\\"{x:1317,y:557,t:1527613750935};\\\", \\\"{x:1318,y:560,t:1527613750951};\\\", \\\"{x:1318,y:564,t:1527613750968};\\\", \\\"{x:1318,y:565,t:1527613750986};\\\", \\\"{x:1319,y:567,t:1527613751002};\\\", \\\"{x:1319,y:569,t:1527613751019};\\\", \\\"{x:1320,y:572,t:1527613751036};\\\", \\\"{x:1320,y:574,t:1527613751051};\\\", \\\"{x:1321,y:577,t:1527613751069};\\\", \\\"{x:1321,y:578,t:1527613751086};\\\", \\\"{x:1321,y:580,t:1527613751118};\\\", \\\"{x:1321,y:581,t:1527613751136};\\\", \\\"{x:1322,y:583,t:1527613751153};\\\", \\\"{x:1322,y:584,t:1527613751174};\\\", \\\"{x:1322,y:585,t:1527613751186};\\\", \\\"{x:1322,y:586,t:1527613751202};\\\", \\\"{x:1322,y:590,t:1527613751219};\\\", \\\"{x:1322,y:592,t:1527613751235};\\\", \\\"{x:1322,y:596,t:1527613751252};\\\", \\\"{x:1322,y:597,t:1527613751269};\\\", \\\"{x:1323,y:600,t:1527613751285};\\\", \\\"{x:1324,y:603,t:1527613751302};\\\", \\\"{x:1324,y:606,t:1527613751318};\\\", \\\"{x:1324,y:610,t:1527613751335};\\\", \\\"{x:1324,y:616,t:1527613751353};\\\", \\\"{x:1324,y:626,t:1527613751369};\\\", \\\"{x:1324,y:643,t:1527613751386};\\\", \\\"{x:1321,y:662,t:1527613751402};\\\", \\\"{x:1320,y:681,t:1527613751419};\\\", \\\"{x:1317,y:699,t:1527613751435};\\\", \\\"{x:1316,y:713,t:1527613751452};\\\", \\\"{x:1315,y:723,t:1527613751469};\\\", \\\"{x:1315,y:738,t:1527613751485};\\\", \\\"{x:1315,y:747,t:1527613751502};\\\", \\\"{x:1315,y:750,t:1527613751519};\\\", \\\"{x:1315,y:753,t:1527613751535};\\\", \\\"{x:1315,y:756,t:1527613751553};\\\", \\\"{x:1315,y:761,t:1527613751569};\\\", \\\"{x:1315,y:767,t:1527613751585};\\\", \\\"{x:1317,y:774,t:1527613751602};\\\", \\\"{x:1317,y:781,t:1527613751618};\\\", \\\"{x:1317,y:788,t:1527613751636};\\\", \\\"{x:1317,y:800,t:1527613751653};\\\", \\\"{x:1317,y:807,t:1527613751669};\\\", \\\"{x:1318,y:836,t:1527613751685};\\\", \\\"{x:1318,y:860,t:1527613751703};\\\", \\\"{x:1318,y:881,t:1527613751719};\\\", \\\"{x:1316,y:899,t:1527613751736};\\\", \\\"{x:1316,y:926,t:1527613751753};\\\", \\\"{x:1316,y:945,t:1527613751769};\\\", \\\"{x:1316,y:951,t:1527613751786};\\\", \\\"{x:1316,y:957,t:1527613751803};\\\", \\\"{x:1316,y:961,t:1527613751820};\\\", \\\"{x:1316,y:966,t:1527613751836};\\\", \\\"{x:1316,y:969,t:1527613751853};\\\", \\\"{x:1315,y:971,t:1527613751870};\\\", \\\"{x:1315,y:972,t:1527613751886};\\\", \\\"{x:1315,y:973,t:1527613751950};\\\", \\\"{x:1315,y:971,t:1527613752358};\\\", \\\"{x:1315,y:968,t:1527613752370};\\\", \\\"{x:1315,y:965,t:1527613752387};\\\", \\\"{x:1315,y:962,t:1527613752403};\\\", \\\"{x:1315,y:961,t:1527613752420};\\\", \\\"{x:1315,y:958,t:1527613752437};\\\", \\\"{x:1315,y:956,t:1527613752454};\\\", \\\"{x:1316,y:955,t:1527613752470};\\\", \\\"{x:1316,y:954,t:1527613752509};\\\", \\\"{x:1316,y:953,t:1527613752542};\\\", \\\"{x:1316,y:952,t:1527613753262};\\\", \\\"{x:1316,y:951,t:1527613755607};\\\", \\\"{x:1317,y:951,t:1527613783870};\\\", \\\"{x:1319,y:951,t:1527613783885};\\\", \\\"{x:1320,y:951,t:1527613783893};\\\", \\\"{x:1323,y:951,t:1527613783910};\\\", \\\"{x:1325,y:951,t:1527613783927};\\\", \\\"{x:1326,y:951,t:1527613783944};\\\", \\\"{x:1327,y:951,t:1527613783960};\\\", \\\"{x:1330,y:951,t:1527613783977};\\\", \\\"{x:1336,y:949,t:1527613783993};\\\", \\\"{x:1345,y:946,t:1527613784011};\\\", \\\"{x:1350,y:946,t:1527613784026};\\\", \\\"{x:1357,y:944,t:1527613784044};\\\", \\\"{x:1365,y:944,t:1527613784060};\\\", \\\"{x:1372,y:942,t:1527613784076};\\\", \\\"{x:1381,y:941,t:1527613784093};\\\", \\\"{x:1384,y:940,t:1527613784111};\\\", \\\"{x:1386,y:939,t:1527613784127};\\\", \\\"{x:1387,y:939,t:1527613784143};\\\", \\\"{x:1389,y:939,t:1527613784160};\\\", \\\"{x:1390,y:939,t:1527613784176};\\\", \\\"{x:1393,y:937,t:1527613784193};\\\", \\\"{x:1396,y:936,t:1527613784210};\\\", \\\"{x:1400,y:936,t:1527613784226};\\\", \\\"{x:1404,y:935,t:1527613784244};\\\", \\\"{x:1411,y:935,t:1527613784261};\\\", \\\"{x:1417,y:935,t:1527613784277};\\\", \\\"{x:1428,y:935,t:1527613784294};\\\", \\\"{x:1434,y:935,t:1527613784310};\\\", \\\"{x:1441,y:935,t:1527613784326};\\\", \\\"{x:1445,y:935,t:1527613784343};\\\", \\\"{x:1449,y:933,t:1527613784360};\\\", \\\"{x:1450,y:933,t:1527613784377};\\\", \\\"{x:1452,y:933,t:1527613784393};\\\", \\\"{x:1456,y:933,t:1527613784413};\\\", \\\"{x:1456,y:932,t:1527613784427};\\\", \\\"{x:1465,y:928,t:1527613784443};\\\", \\\"{x:1477,y:923,t:1527613784460};\\\", \\\"{x:1497,y:912,t:1527613784477};\\\", \\\"{x:1505,y:907,t:1527613784493};\\\", \\\"{x:1510,y:904,t:1527613784510};\\\", \\\"{x:1514,y:903,t:1527613784526};\\\", \\\"{x:1516,y:903,t:1527613784543};\\\", \\\"{x:1519,y:901,t:1527613784560};\\\", \\\"{x:1520,y:901,t:1527613784597};\\\", \\\"{x:1521,y:901,t:1527613784610};\\\", \\\"{x:1523,y:901,t:1527613784627};\\\", \\\"{x:1524,y:901,t:1527613784644};\\\", \\\"{x:1525,y:901,t:1527613784660};\\\", \\\"{x:1527,y:901,t:1527613784678};\\\", \\\"{x:1529,y:902,t:1527613784694};\\\", \\\"{x:1531,y:904,t:1527613784711};\\\", \\\"{x:1534,y:908,t:1527613784727};\\\", \\\"{x:1535,y:912,t:1527613784743};\\\", \\\"{x:1537,y:914,t:1527613784760};\\\", \\\"{x:1537,y:918,t:1527613784777};\\\", \\\"{x:1538,y:922,t:1527613784794};\\\", \\\"{x:1539,y:925,t:1527613784811};\\\", \\\"{x:1540,y:928,t:1527613784828};\\\", \\\"{x:1541,y:930,t:1527613784844};\\\", \\\"{x:1541,y:932,t:1527613784860};\\\", \\\"{x:1541,y:935,t:1527613784877};\\\", \\\"{x:1541,y:936,t:1527613784894};\\\", \\\"{x:1543,y:939,t:1527613784910};\\\", \\\"{x:1544,y:942,t:1527613784928};\\\", \\\"{x:1544,y:944,t:1527613784944};\\\", \\\"{x:1544,y:946,t:1527613784960};\\\", \\\"{x:1544,y:947,t:1527613784977};\\\", \\\"{x:1513,y:934,t:1527613802282};\\\", \\\"{x:1452,y:917,t:1527613802294};\\\", \\\"{x:1268,y:878,t:1527613802311};\\\", \\\"{x:1033,y:836,t:1527613802326};\\\", \\\"{x:773,y:798,t:1527613802344};\\\", \\\"{x:420,y:734,t:1527613802361};\\\", \\\"{x:225,y:688,t:1527613802377};\\\", \\\"{x:67,y:644,t:1527613802394};\\\", \\\"{x:0,y:610,t:1527613802411};\\\", \\\"{x:0,y:581,t:1527613802428};\\\", \\\"{x:0,y:569,t:1527613802443};\\\", \\\"{x:0,y:567,t:1527613802461};\\\", \\\"{x:0,y:564,t:1527613802513};\\\", \\\"{x:0,y:563,t:1527613802527};\\\", \\\"{x:1,y:559,t:1527613802544};\\\", \\\"{x:8,y:545,t:1527613802561};\\\", \\\"{x:18,y:534,t:1527613802577};\\\", \\\"{x:28,y:526,t:1527613802594};\\\", \\\"{x:36,y:520,t:1527613802611};\\\", \\\"{x:48,y:514,t:1527613802629};\\\", \\\"{x:63,y:510,t:1527613802643};\\\", \\\"{x:88,y:503,t:1527613802660};\\\", \\\"{x:150,y:495,t:1527613802683};\\\", \\\"{x:203,y:489,t:1527613802699};\\\", \\\"{x:251,y:489,t:1527613802716};\\\", \\\"{x:305,y:484,t:1527613802733};\\\", \\\"{x:356,y:484,t:1527613802749};\\\", \\\"{x:398,y:487,t:1527613802765};\\\", \\\"{x:431,y:491,t:1527613802782};\\\", \\\"{x:462,y:496,t:1527613802799};\\\", \\\"{x:484,y:499,t:1527613802816};\\\", \\\"{x:509,y:510,t:1527613802832};\\\", \\\"{x:523,y:515,t:1527613802849};\\\", \\\"{x:542,y:525,t:1527613802866};\\\", \\\"{x:558,y:533,t:1527613802883};\\\", \\\"{x:573,y:540,t:1527613802900};\\\", \\\"{x:588,y:549,t:1527613802917};\\\", \\\"{x:604,y:559,t:1527613802932};\\\", \\\"{x:619,y:570,t:1527613802950};\\\", \\\"{x:633,y:578,t:1527613802967};\\\", \\\"{x:638,y:583,t:1527613802982};\\\", \\\"{x:639,y:584,t:1527613802999};\\\", \\\"{x:640,y:585,t:1527613803016};\\\", \\\"{x:641,y:586,t:1527613803032};\\\", \\\"{x:642,y:587,t:1527613803056};\\\", \\\"{x:642,y:588,t:1527613803065};\\\", \\\"{x:642,y:589,t:1527613803201};\\\", \\\"{x:641,y:589,t:1527613803217};\\\", \\\"{x:636,y:591,t:1527613803233};\\\", \\\"{x:629,y:592,t:1527613803250};\\\", \\\"{x:622,y:592,t:1527613803267};\\\", \\\"{x:610,y:592,t:1527613803283};\\\", \\\"{x:599,y:592,t:1527613803300};\\\", \\\"{x:592,y:592,t:1527613803317};\\\", \\\"{x:583,y:592,t:1527613803332};\\\", \\\"{x:578,y:591,t:1527613803349};\\\", \\\"{x:579,y:591,t:1527613803641};\\\", \\\"{x:581,y:591,t:1527613803672};\\\", \\\"{x:583,y:592,t:1527613803684};\\\", \\\"{x:585,y:592,t:1527613803701};\\\", \\\"{x:587,y:592,t:1527613803717};\\\", \\\"{x:589,y:592,t:1527613803734};\\\", \\\"{x:591,y:592,t:1527613803751};\\\", \\\"{x:591,y:593,t:1527613803767};\\\", \\\"{x:592,y:593,t:1527613803784};\\\", \\\"{x:595,y:594,t:1527613803801};\\\", \\\"{x:596,y:594,t:1527613803937};\\\", \\\"{x:597,y:594,t:1527613803951};\\\", \\\"{x:599,y:594,t:1527613803968};\\\", \\\"{x:601,y:594,t:1527613803991};\\\", \\\"{x:602,y:594,t:1527613804016};\\\", \\\"{x:604,y:594,t:1527613804032};\\\", \\\"{x:605,y:594,t:1527613804039};\\\", \\\"{x:606,y:594,t:1527613804051};\\\", \\\"{x:607,y:594,t:1527613804066};\\\", \\\"{x:609,y:593,t:1527613804083};\\\", \\\"{x:596,y:556,t:1527613832163};\\\", \\\"{x:553,y:477,t:1527613832176};\\\", \\\"{x:503,y:384,t:1527613832191};\\\", \\\"{x:499,y:352,t:1527613832207};\\\", \\\"{x:524,y:305,t:1527613832223};\\\", \\\"{x:540,y:291,t:1527613832239};\\\", \\\"{x:552,y:286,t:1527613832257};\\\", \\\"{x:564,y:281,t:1527613832273};\\\", \\\"{x:576,y:274,t:1527613832290};\\\", \\\"{x:590,y:269,t:1527613832306};\\\", \\\"{x:603,y:263,t:1527613832324};\\\", \\\"{x:618,y:256,t:1527613832340};\\\", \\\"{x:628,y:251,t:1527613832357};\\\", \\\"{x:638,y:248,t:1527613832374};\\\", \\\"{x:666,y:252,t:1527613832390};\\\", \\\"{x:730,y:269,t:1527613832407};\\\", \\\"{x:893,y:329,t:1527613832424};\\\", \\\"{x:1019,y:383,t:1527613832440};\\\", \\\"{x:1162,y:440,t:1527613832457};\\\", \\\"{x:1308,y:504,t:1527613832473};\\\", \\\"{x:1451,y:561,t:1527613832490};\\\", \\\"{x:1568,y:601,t:1527613832507};\\\", \\\"{x:1656,y:634,t:1527613832524};\\\", \\\"{x:1694,y:647,t:1527613832541};\\\", \\\"{x:1720,y:655,t:1527613832557};\\\", \\\"{x:1728,y:659,t:1527613832574};\\\", \\\"{x:1728,y:660,t:1527613832608};\\\", \\\"{x:1723,y:657,t:1527613832721};\\\", \\\"{x:1709,y:651,t:1527613832728};\\\", \\\"{x:1688,y:642,t:1527613832741};\\\", \\\"{x:1640,y:629,t:1527613832757};\\\", \\\"{x:1616,y:626,t:1527613832773};\\\", \\\"{x:1597,y:621,t:1527613832791};\\\", \\\"{x:1570,y:615,t:1527613832807};\\\", \\\"{x:1549,y:609,t:1527613832824};\\\", \\\"{x:1544,y:606,t:1527613832840};\\\", \\\"{x:1542,y:606,t:1527613832857};\\\", \\\"{x:1541,y:606,t:1527613832937};\\\", \\\"{x:1538,y:605,t:1527613832944};\\\", \\\"{x:1537,y:604,t:1527613832957};\\\", \\\"{x:1529,y:598,t:1527613832974};\\\", \\\"{x:1511,y:587,t:1527613832991};\\\", \\\"{x:1494,y:581,t:1527613833007};\\\", \\\"{x:1469,y:572,t:1527613833024};\\\", \\\"{x:1453,y:569,t:1527613833041};\\\", \\\"{x:1437,y:565,t:1527613833057};\\\", \\\"{x:1424,y:561,t:1527613833075};\\\", \\\"{x:1414,y:558,t:1527613833091};\\\", \\\"{x:1402,y:554,t:1527613833108};\\\", \\\"{x:1390,y:550,t:1527613833124};\\\", \\\"{x:1385,y:549,t:1527613833141};\\\", \\\"{x:1380,y:547,t:1527613833158};\\\", \\\"{x:1377,y:546,t:1527613833174};\\\", \\\"{x:1375,y:545,t:1527613833191};\\\", \\\"{x:1376,y:545,t:1527613833321};\\\", \\\"{x:1378,y:543,t:1527613833328};\\\", \\\"{x:1380,y:543,t:1527613833342};\\\", \\\"{x:1382,y:543,t:1527613833358};\\\", \\\"{x:1385,y:542,t:1527613833374};\\\", \\\"{x:1388,y:540,t:1527613833391};\\\", \\\"{x:1389,y:540,t:1527613833408};\\\", \\\"{x:1391,y:540,t:1527613833424};\\\", \\\"{x:1392,y:540,t:1527613833441};\\\", \\\"{x:1393,y:541,t:1527613833458};\\\", \\\"{x:1394,y:541,t:1527613833475};\\\", \\\"{x:1395,y:541,t:1527613833505};\\\", \\\"{x:1396,y:541,t:1527613833513};\\\", \\\"{x:1397,y:541,t:1527613833529};\\\", \\\"{x:1398,y:541,t:1527613833553};\\\", \\\"{x:1399,y:541,t:1527613833560};\\\", \\\"{x:1400,y:541,t:1527613833574};\\\", \\\"{x:1401,y:541,t:1527613833600};\\\", \\\"{x:1403,y:541,t:1527613833608};\\\", \\\"{x:1405,y:541,t:1527613833632};\\\", \\\"{x:1407,y:541,t:1527613833663};\\\", \\\"{x:1410,y:542,t:1527613833680};\\\", \\\"{x:1410,y:543,t:1527613833691};\\\", \\\"{x:1412,y:545,t:1527613833712};\\\", \\\"{x:1412,y:546,t:1527613834209};\\\", \\\"{x:1412,y:561,t:1527613834225};\\\", \\\"{x:1412,y:576,t:1527613834241};\\\", \\\"{x:1412,y:587,t:1527613834258};\\\", \\\"{x:1412,y:597,t:1527613834275};\\\", \\\"{x:1412,y:602,t:1527613834291};\\\", \\\"{x:1414,y:609,t:1527613834308};\\\", \\\"{x:1415,y:617,t:1527613834325};\\\", \\\"{x:1416,y:623,t:1527613834341};\\\", \\\"{x:1418,y:632,t:1527613834358};\\\", \\\"{x:1418,y:643,t:1527613834375};\\\", \\\"{x:1418,y:651,t:1527613834391};\\\", \\\"{x:1418,y:664,t:1527613834408};\\\", \\\"{x:1418,y:670,t:1527613834425};\\\", \\\"{x:1418,y:677,t:1527613834441};\\\", \\\"{x:1418,y:685,t:1527613834458};\\\", \\\"{x:1418,y:692,t:1527613834475};\\\", \\\"{x:1418,y:700,t:1527613834491};\\\", \\\"{x:1418,y:706,t:1527613834508};\\\", \\\"{x:1418,y:714,t:1527613834524};\\\", \\\"{x:1418,y:721,t:1527613834541};\\\", \\\"{x:1418,y:728,t:1527613834558};\\\", \\\"{x:1419,y:738,t:1527613834575};\\\", \\\"{x:1420,y:748,t:1527613834591};\\\", \\\"{x:1423,y:759,t:1527613834608};\\\", \\\"{x:1423,y:768,t:1527613834625};\\\", \\\"{x:1423,y:778,t:1527613834641};\\\", \\\"{x:1423,y:790,t:1527613834658};\\\", \\\"{x:1423,y:800,t:1527613834675};\\\", \\\"{x:1424,y:810,t:1527613834692};\\\", \\\"{x:1424,y:820,t:1527613834708};\\\", \\\"{x:1424,y:831,t:1527613834726};\\\", \\\"{x:1424,y:840,t:1527613834742};\\\", \\\"{x:1424,y:849,t:1527613834758};\\\", \\\"{x:1424,y:857,t:1527613834776};\\\", \\\"{x:1425,y:867,t:1527613834792};\\\", \\\"{x:1425,y:870,t:1527613834808};\\\", \\\"{x:1425,y:877,t:1527613834826};\\\", \\\"{x:1425,y:885,t:1527613834842};\\\", \\\"{x:1425,y:892,t:1527613834858};\\\", \\\"{x:1425,y:900,t:1527613834876};\\\", \\\"{x:1425,y:905,t:1527613834892};\\\", \\\"{x:1425,y:910,t:1527613834908};\\\", \\\"{x:1425,y:916,t:1527613834925};\\\", \\\"{x:1425,y:924,t:1527613834942};\\\", \\\"{x:1425,y:931,t:1527613834959};\\\", \\\"{x:1425,y:937,t:1527613834976};\\\", \\\"{x:1425,y:943,t:1527613834992};\\\", \\\"{x:1425,y:945,t:1527613835008};\\\", \\\"{x:1425,y:947,t:1527613835026};\\\", \\\"{x:1425,y:948,t:1527613835345};\\\", \\\"{x:1424,y:948,t:1527613835393};\\\", \\\"{x:1423,y:948,t:1527613835416};\\\", \\\"{x:1422,y:948,t:1527613835465};\\\", \\\"{x:1421,y:948,t:1527613835601};\\\", \\\"{x:1420,y:948,t:1527613835608};\\\", \\\"{x:1419,y:948,t:1527613835632};\\\", \\\"{x:1417,y:949,t:1527613835649};\\\", \\\"{x:1417,y:950,t:1527613835665};\\\", \\\"{x:1416,y:950,t:1527613835713};\\\", \\\"{x:1416,y:949,t:1527613849284};\\\", \\\"{x:1418,y:946,t:1527613849303};\\\", \\\"{x:1419,y:944,t:1527613849320};\\\", \\\"{x:1419,y:942,t:1527613849336};\\\", \\\"{x:1419,y:941,t:1527613849353};\\\", \\\"{x:1421,y:940,t:1527613849370};\\\", \\\"{x:1422,y:938,t:1527613849385};\\\", \\\"{x:1423,y:937,t:1527613849402};\\\", \\\"{x:1425,y:932,t:1527613849420};\\\", \\\"{x:1425,y:930,t:1527613849436};\\\", \\\"{x:1426,y:926,t:1527613849452};\\\", \\\"{x:1426,y:921,t:1527613849469};\\\", \\\"{x:1426,y:914,t:1527613849486};\\\", \\\"{x:1426,y:907,t:1527613849502};\\\", \\\"{x:1426,y:900,t:1527613849519};\\\", \\\"{x:1426,y:893,t:1527613849536};\\\", \\\"{x:1424,y:884,t:1527613849553};\\\", \\\"{x:1422,y:875,t:1527613849569};\\\", \\\"{x:1418,y:863,t:1527613849586};\\\", \\\"{x:1413,y:852,t:1527613849602};\\\", \\\"{x:1398,y:823,t:1527613849620};\\\", \\\"{x:1389,y:805,t:1527613849635};\\\", \\\"{x:1372,y:777,t:1527613849653};\\\", \\\"{x:1340,y:735,t:1527613849669};\\\", \\\"{x:1297,y:694,t:1527613849687};\\\", \\\"{x:1244,y:654,t:1527613849703};\\\", \\\"{x:1172,y:623,t:1527613849719};\\\", \\\"{x:1089,y:600,t:1527613849737};\\\", \\\"{x:1003,y:577,t:1527613849753};\\\", \\\"{x:923,y:555,t:1527613849771};\\\", \\\"{x:846,y:536,t:1527613849786};\\\", \\\"{x:754,y:523,t:1527613849802};\\\", \\\"{x:617,y:504,t:1527613849825};\\\", \\\"{x:522,y:488,t:1527613849841};\\\", \\\"{x:429,y:483,t:1527613849857};\\\", \\\"{x:297,y:477,t:1527613849875};\\\", \\\"{x:238,y:473,t:1527613849892};\\\", \\\"{x:198,y:473,t:1527613849907};\\\", \\\"{x:171,y:473,t:1527613849925};\\\", \\\"{x:151,y:471,t:1527613849941};\\\", \\\"{x:134,y:470,t:1527613849957};\\\", \\\"{x:128,y:469,t:1527613849975};\\\", \\\"{x:126,y:466,t:1527613849991};\\\", \\\"{x:126,y:467,t:1527613851028};\\\", \\\"{x:126,y:468,t:1527613851042};\\\", \\\"{x:129,y:471,t:1527613851059};\\\", \\\"{x:131,y:473,t:1527613851076};\\\", \\\"{x:132,y:475,t:1527613851116};\\\", \\\"{x:133,y:475,t:1527613851131};\\\", \\\"{x:134,y:476,t:1527613851143};\\\", \\\"{x:137,y:477,t:1527613851160};\\\", \\\"{x:138,y:478,t:1527613851177};\\\", \\\"{x:141,y:480,t:1527613851192};\\\", \\\"{x:142,y:481,t:1527613851210};\\\", \\\"{x:147,y:485,t:1527613851226};\\\", \\\"{x:151,y:488,t:1527613851242};\\\", \\\"{x:161,y:494,t:1527613851259};\\\", \\\"{x:169,y:498,t:1527613851276};\\\", \\\"{x:171,y:501,t:1527613851293};\\\", \\\"{x:180,y:504,t:1527613851308};\\\", \\\"{x:188,y:509,t:1527613851326};\\\", \\\"{x:199,y:514,t:1527613851343};\\\", \\\"{x:213,y:522,t:1527613851359};\\\", \\\"{x:228,y:529,t:1527613851376};\\\", \\\"{x:245,y:535,t:1527613851392};\\\", \\\"{x:263,y:544,t:1527613851409};\\\", \\\"{x:282,y:551,t:1527613851426};\\\", \\\"{x:308,y:558,t:1527613851443};\\\", \\\"{x:315,y:561,t:1527613851458};\\\", \\\"{x:326,y:566,t:1527613851476};\\\", \\\"{x:335,y:569,t:1527613851493};\\\", \\\"{x:344,y:571,t:1527613851509};\\\", \\\"{x:350,y:574,t:1527613851527};\\\", \\\"{x:351,y:574,t:1527613851796};\\\", \\\"{x:351,y:575,t:1527613851811};\\\", \\\"{x:356,y:580,t:1527613851827};\\\", \\\"{x:360,y:583,t:1527613851843};\\\", \\\"{x:361,y:584,t:1527613851860};\\\", \\\"{x:362,y:585,t:1527613851916};\\\", \\\"{x:366,y:589,t:1527613851928};\\\", \\\"{x:372,y:594,t:1527613851943};\\\", \\\"{x:377,y:598,t:1527613851961};\\\", \\\"{x:381,y:600,t:1527613851977};\\\", \\\"{x:382,y:601,t:1527613851993};\\\", \\\"{x:383,y:601,t:1527613852010};\\\", \\\"{x:384,y:602,t:1527613852042};\\\", \\\"{x:385,y:604,t:1527613852059};\\\", \\\"{x:387,y:605,t:1527613852076};\\\", \\\"{x:388,y:607,t:1527613852093};\\\", \\\"{x:390,y:611,t:1527613852110};\\\", \\\"{x:392,y:613,t:1527613852126};\\\", \\\"{x:396,y:619,t:1527613852143};\\\", \\\"{x:400,y:628,t:1527613852160};\\\", \\\"{x:405,y:637,t:1527613852176};\\\", \\\"{x:412,y:648,t:1527613852193};\\\", \\\"{x:417,y:656,t:1527613852210};\\\", \\\"{x:418,y:660,t:1527613852226};\\\", \\\"{x:421,y:666,t:1527613852242};\\\", \\\"{x:422,y:669,t:1527613852260};\\\", \\\"{x:423,y:670,t:1527613852276};\\\", \\\"{x:423,y:671,t:1527613852315};\\\", \\\"{x:424,y:672,t:1527613852327};\\\", \\\"{x:425,y:674,t:1527613852348};\\\", \\\"{x:425,y:676,t:1527613852363};\\\", \\\"{x:426,y:676,t:1527613852376};\\\", \\\"{x:427,y:679,t:1527613852393};\\\", \\\"{x:428,y:680,t:1527613852409};\\\", \\\"{x:428,y:681,t:1527613852426};\\\", \\\"{x:429,y:682,t:1527613852442};\\\", \\\"{x:430,y:683,t:1527613852459};\\\", \\\"{x:430,y:684,t:1527613852477};\\\", \\\"{x:431,y:685,t:1527613852492};\\\", \\\"{x:431,y:686,t:1527613852523};\\\", \\\"{x:433,y:686,t:1527613853028};\\\", \\\"{x:434,y:686,t:1527613853041};\\\", \\\"{x:435,y:685,t:1527613853058};\\\", \\\"{x:440,y:682,t:1527613853075};\\\", \\\"{x:458,y:673,t:1527613853091};\\\", \\\"{x:504,y:651,t:1527613853108};\\\", \\\"{x:672,y:607,t:1527613853125};\\\", \\\"{x:957,y:556,t:1527613853142};\\\", \\\"{x:1250,y:510,t:1527613853158};\\\", \\\"{x:1579,y:461,t:1527613853174};\\\", \\\"{x:1881,y:434,t:1527613853191};\\\", \\\"{x:1919,y:425,t:1527613853208};\\\", \\\"{x:1919,y:426,t:1527613853224};\\\", \\\"{x:1919,y:430,t:1527613853244};\\\", \\\"{x:1919,y:432,t:1527613853261};\\\", \\\"{x:1919,y:433,t:1527613853278};\\\", \\\"{x:1919,y:434,t:1527613853315};\\\", \\\"{x:1919,y:435,t:1527613853328};\\\", \\\"{x:1916,y:440,t:1527613853344};\\\", \\\"{x:1908,y:449,t:1527613853361};\\\", \\\"{x:1889,y:460,t:1527613853378};\\\", \\\"{x:1866,y:467,t:1527613853394};\\\", \\\"{x:1820,y:489,t:1527613853411};\\\", \\\"{x:1785,y:505,t:1527613853429};\\\", \\\"{x:1751,y:519,t:1527613853444};\\\", \\\"{x:1730,y:528,t:1527613853461};\\\", \\\"{x:1708,y:535,t:1527613853478};\\\", \\\"{x:1691,y:539,t:1527613853494};\\\", \\\"{x:1678,y:541,t:1527613853511};\\\", \\\"{x:1670,y:544,t:1527613853528};\\\", \\\"{x:1668,y:545,t:1527613853544};\\\", \\\"{x:1667,y:545,t:1527613853561};\\\", \\\"{x:1664,y:546,t:1527613853578};\\\", \\\"{x:1661,y:548,t:1527613853595};\\\", \\\"{x:1652,y:553,t:1527613853611};\\\", \\\"{x:1644,y:557,t:1527613853628};\\\", \\\"{x:1637,y:559,t:1527613853644};\\\", \\\"{x:1631,y:560,t:1527613853662};\\\", \\\"{x:1624,y:560,t:1527613853678};\\\", \\\"{x:1618,y:561,t:1527613853694};\\\", \\\"{x:1612,y:561,t:1527613853710};\\\", \\\"{x:1607,y:561,t:1527613853728};\\\", \\\"{x:1603,y:561,t:1527613853744};\\\", \\\"{x:1599,y:561,t:1527613853761};\\\", \\\"{x:1589,y:558,t:1527613853778};\\\", \\\"{x:1585,y:556,t:1527613853794};\\\", \\\"{x:1585,y:554,t:1527613853811};\\\", \\\"{x:1585,y:553,t:1527613853828};\\\", \\\"{x:1587,y:549,t:1527613853844};\\\", \\\"{x:1588,y:548,t:1527613853861};\\\", \\\"{x:1590,y:547,t:1527613853878};\\\", \\\"{x:1592,y:546,t:1527613853894};\\\", \\\"{x:1593,y:546,t:1527613853912};\\\", \\\"{x:1594,y:546,t:1527613853929};\\\", \\\"{x:1595,y:546,t:1527613853945};\\\", \\\"{x:1596,y:546,t:1527613853980};\\\", \\\"{x:1598,y:546,t:1527613853995};\\\", \\\"{x:1599,y:546,t:1527613854036};\\\", \\\"{x:1601,y:547,t:1527613854045};\\\", \\\"{x:1604,y:547,t:1527613854061};\\\", \\\"{x:1605,y:547,t:1527613854078};\\\", \\\"{x:1606,y:548,t:1527613855108};\\\", \\\"{x:1601,y:553,t:1527613855115};\\\", \\\"{x:1594,y:555,t:1527613855130};\\\", \\\"{x:1574,y:564,t:1527613855146};\\\", \\\"{x:1548,y:574,t:1527613855163};\\\", \\\"{x:1514,y:580,t:1527613855180};\\\", \\\"{x:1501,y:585,t:1527613855196};\\\", \\\"{x:1490,y:587,t:1527613855212};\\\", \\\"{x:1482,y:587,t:1527613855230};\\\", \\\"{x:1472,y:588,t:1527613855246};\\\", \\\"{x:1467,y:591,t:1527613855263};\\\", \\\"{x:1457,y:592,t:1527613855279};\\\", \\\"{x:1448,y:593,t:1527613855296};\\\", \\\"{x:1436,y:597,t:1527613855313};\\\", \\\"{x:1412,y:604,t:1527613855330};\\\", \\\"{x:1390,y:613,t:1527613855346};\\\", \\\"{x:1344,y:627,t:1527613855363};\\\", \\\"{x:1223,y:656,t:1527613855379};\\\", \\\"{x:1130,y:677,t:1527613855397};\\\", \\\"{x:1011,y:709,t:1527613855413};\\\", \\\"{x:913,y:728,t:1527613855430};\\\", \\\"{x:826,y:743,t:1527613855446};\\\", \\\"{x:738,y:755,t:1527613855462};\\\", \\\"{x:657,y:757,t:1527613855480};\\\", \\\"{x:597,y:758,t:1527613855496};\\\", \\\"{x:559,y:760,t:1527613855513};\\\", \\\"{x:537,y:760,t:1527613855530};\\\", \\\"{x:528,y:761,t:1527613855547};\\\", \\\"{x:518,y:761,t:1527613855563};\\\", \\\"{x:513,y:761,t:1527613855579};\\\", \\\"{x:512,y:761,t:1527613855676};\\\", \\\"{x:510,y:761,t:1527613855691};\\\", \\\"{x:508,y:760,t:1527613855699};\\\", \\\"{x:504,y:754,t:1527613855713};\\\", \\\"{x:496,y:742,t:1527613855730};\\\", \\\"{x:487,y:733,t:1527613855746};\\\", \\\"{x:485,y:728,t:1527613855763};\\\", \\\"{x:485,y:727,t:1527613855781};\\\", \\\"{x:485,y:726,t:1527613855802};\\\", \\\"{x:485,y:725,t:1527613856748};\\\", \\\"{x:485,y:724,t:1527613856763};\\\", \\\"{x:485,y:722,t:1527613856779};\\\", \\\"{x:485,y:721,t:1527613856796};\\\", \\\"{x:486,y:718,t:1527613856813};\\\", \\\"{x:486,y:716,t:1527613856843};\\\", \\\"{x:486,y:715,t:1527613856875};\\\", \\\"{x:487,y:715,t:1527613856890};\\\", \\\"{x:487,y:714,t:1527613856898};\\\", \\\"{x:488,y:713,t:1527613856914};\\\", \\\"{x:489,y:713,t:1527613856930};\\\", \\\"{x:489,y:712,t:1527613856946};\\\", \\\"{x:491,y:711,t:1527613856963};\\\", \\\"{x:491,y:710,t:1527613856980};\\\", \\\"{x:492,y:709,t:1527613856997};\\\", \\\"{x:493,y:708,t:1527613857076};\\\" ] }, { \\\"rt\\\": 10974, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 262370, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"K7JVY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:494,y:708,t:1527613859187};\\\", \\\"{x:500,y:703,t:1527613859199};\\\", \\\"{x:507,y:697,t:1527613859217};\\\", \\\"{x:513,y:696,t:1527613860228};\\\", \\\"{x:515,y:696,t:1527613860243};\\\", \\\"{x:516,y:695,t:1527613860251};\\\", \\\"{x:517,y:695,t:1527613860266};\\\", \\\"{x:519,y:694,t:1527613860282};\\\", \\\"{x:521,y:692,t:1527613860299};\\\", \\\"{x:525,y:691,t:1527613860315};\\\", \\\"{x:530,y:688,t:1527613860333};\\\", \\\"{x:537,y:688,t:1527613860349};\\\", \\\"{x:558,y:681,t:1527613860366};\\\", \\\"{x:577,y:678,t:1527613860383};\\\", \\\"{x:609,y:673,t:1527613860399};\\\", \\\"{x:654,y:665,t:1527613860416};\\\", \\\"{x:722,y:662,t:1527613860432};\\\", \\\"{x:817,y:656,t:1527613860448};\\\", \\\"{x:936,y:656,t:1527613860466};\\\", \\\"{x:1116,y:656,t:1527613860484};\\\", \\\"{x:1245,y:650,t:1527613860500};\\\", \\\"{x:1389,y:644,t:1527613860516};\\\", \\\"{x:1517,y:641,t:1527613860533};\\\", \\\"{x:1622,y:641,t:1527613860549};\\\", \\\"{x:1700,y:634,t:1527613860566};\\\", \\\"{x:1737,y:632,t:1527613860582};\\\", \\\"{x:1752,y:627,t:1527613860598};\\\", \\\"{x:1756,y:627,t:1527613860616};\\\", \\\"{x:1757,y:627,t:1527613860633};\\\", \\\"{x:1751,y:623,t:1527613860828};\\\", \\\"{x:1743,y:620,t:1527613860835};\\\", \\\"{x:1728,y:616,t:1527613860849};\\\", \\\"{x:1684,y:606,t:1527613860866};\\\", \\\"{x:1625,y:598,t:1527613860882};\\\", \\\"{x:1522,y:588,t:1527613860899};\\\", \\\"{x:1465,y:585,t:1527613860915};\\\", \\\"{x:1411,y:577,t:1527613860932};\\\", \\\"{x:1361,y:561,t:1527613860948};\\\", \\\"{x:1316,y:548,t:1527613860966};\\\", \\\"{x:1276,y:535,t:1527613860983};\\\", \\\"{x:1228,y:519,t:1527613860999};\\\", \\\"{x:1203,y:509,t:1527613861015};\\\", \\\"{x:1188,y:501,t:1527613861033};\\\", \\\"{x:1180,y:495,t:1527613861049};\\\", \\\"{x:1175,y:488,t:1527613861066};\\\", \\\"{x:1173,y:481,t:1527613861082};\\\", \\\"{x:1173,y:473,t:1527613861098};\\\", \\\"{x:1171,y:467,t:1527613861115};\\\", \\\"{x:1170,y:460,t:1527613861132};\\\", \\\"{x:1165,y:452,t:1527613861149};\\\", \\\"{x:1162,y:446,t:1527613861166};\\\", \\\"{x:1162,y:444,t:1527613861183};\\\", \\\"{x:1161,y:442,t:1527613861199};\\\", \\\"{x:1160,y:440,t:1527613861216};\\\", \\\"{x:1159,y:440,t:1527613861233};\\\", \\\"{x:1155,y:438,t:1527613861249};\\\", \\\"{x:1150,y:438,t:1527613861265};\\\", \\\"{x:1135,y:438,t:1527613861283};\\\", \\\"{x:1121,y:442,t:1527613861300};\\\", \\\"{x:1106,y:449,t:1527613861316};\\\", \\\"{x:1086,y:455,t:1527613861333};\\\", \\\"{x:1065,y:464,t:1527613861349};\\\", \\\"{x:1049,y:471,t:1527613861366};\\\", \\\"{x:1038,y:474,t:1527613861383};\\\", \\\"{x:1036,y:476,t:1527613861398};\\\", \\\"{x:1035,y:476,t:1527613861416};\\\", \\\"{x:1035,y:477,t:1527613861443};\\\", \\\"{x:1035,y:479,t:1527613861523};\\\", \\\"{x:1037,y:481,t:1527613861533};\\\", \\\"{x:1043,y:483,t:1527613861549};\\\", \\\"{x:1051,y:487,t:1527613861565};\\\", \\\"{x:1065,y:490,t:1527613861583};\\\", \\\"{x:1085,y:494,t:1527613861599};\\\", \\\"{x:1100,y:499,t:1527613861616};\\\", \\\"{x:1115,y:506,t:1527613861633};\\\", \\\"{x:1126,y:514,t:1527613861650};\\\", \\\"{x:1131,y:522,t:1527613861666};\\\", \\\"{x:1134,y:529,t:1527613861683};\\\", \\\"{x:1135,y:531,t:1527613861699};\\\", \\\"{x:1136,y:532,t:1527613861715};\\\", \\\"{x:1136,y:533,t:1527613861796};\\\", \\\"{x:1136,y:534,t:1527613861803};\\\", \\\"{x:1136,y:536,t:1527613861816};\\\", \\\"{x:1136,y:538,t:1527613861833};\\\", \\\"{x:1139,y:540,t:1527613861850};\\\", \\\"{x:1155,y:545,t:1527613861866};\\\", \\\"{x:1178,y:548,t:1527613861883};\\\", \\\"{x:1194,y:550,t:1527613861899};\\\", \\\"{x:1211,y:555,t:1527613861916};\\\", \\\"{x:1225,y:559,t:1527613861933};\\\", \\\"{x:1242,y:566,t:1527613861949};\\\", \\\"{x:1258,y:570,t:1527613861966};\\\", \\\"{x:1271,y:575,t:1527613861983};\\\", \\\"{x:1281,y:576,t:1527613862000};\\\", \\\"{x:1283,y:576,t:1527613862016};\\\", \\\"{x:1284,y:576,t:1527613862033};\\\", \\\"{x:1285,y:576,t:1527613862050};\\\", \\\"{x:1286,y:576,t:1527613862066};\\\", \\\"{x:1289,y:576,t:1527613862083};\\\", \\\"{x:1293,y:575,t:1527613862100};\\\", \\\"{x:1295,y:575,t:1527613862116};\\\", \\\"{x:1299,y:574,t:1527613862133};\\\", \\\"{x:1299,y:573,t:1527613862340};\\\", \\\"{x:1299,y:572,t:1527613862363};\\\", \\\"{x:1299,y:571,t:1527613862500};\\\", \\\"{x:1299,y:570,t:1527613862548};\\\", \\\"{x:1299,y:569,t:1527613862556};\\\", \\\"{x:1297,y:569,t:1527613862587};\\\", \\\"{x:1296,y:569,t:1527613862600};\\\", \\\"{x:1295,y:569,t:1527613862616};\\\", \\\"{x:1293,y:568,t:1527613862633};\\\", \\\"{x:1290,y:567,t:1527613862650};\\\", \\\"{x:1288,y:567,t:1527613862666};\\\", \\\"{x:1282,y:566,t:1527613862684};\\\", \\\"{x:1275,y:566,t:1527613862699};\\\", \\\"{x:1270,y:566,t:1527613862716};\\\", \\\"{x:1266,y:566,t:1527613862733};\\\", \\\"{x:1264,y:566,t:1527613862750};\\\", \\\"{x:1263,y:565,t:1527613862766};\\\", \\\"{x:1261,y:565,t:1527613862783};\\\", \\\"{x:1260,y:565,t:1527613862860};\\\", \\\"{x:1253,y:565,t:1527613864140};\\\", \\\"{x:1241,y:565,t:1527613864151};\\\", \\\"{x:1193,y:565,t:1527613864166};\\\", \\\"{x:1126,y:565,t:1527613864183};\\\", \\\"{x:1057,y:565,t:1527613864201};\\\", \\\"{x:1015,y:565,t:1527613864216};\\\", \\\"{x:983,y:565,t:1527613864233};\\\", \\\"{x:960,y:565,t:1527613864250};\\\", \\\"{x:947,y:565,t:1527613864268};\\\", \\\"{x:937,y:565,t:1527613864282};\\\", \\\"{x:931,y:565,t:1527613864300};\\\", \\\"{x:918,y:567,t:1527613864319};\\\", \\\"{x:909,y:568,t:1527613864336};\\\", \\\"{x:894,y:571,t:1527613864353};\\\", \\\"{x:878,y:573,t:1527613864370};\\\", \\\"{x:857,y:579,t:1527613864387};\\\", \\\"{x:833,y:584,t:1527613864404};\\\", \\\"{x:811,y:584,t:1527613864419};\\\", \\\"{x:788,y:587,t:1527613864436};\\\", \\\"{x:770,y:589,t:1527613864453};\\\", \\\"{x:756,y:589,t:1527613864470};\\\", \\\"{x:746,y:591,t:1527613864487};\\\", \\\"{x:734,y:591,t:1527613864504};\\\", \\\"{x:714,y:592,t:1527613864521};\\\", \\\"{x:695,y:596,t:1527613864536};\\\", \\\"{x:670,y:600,t:1527613864554};\\\", \\\"{x:631,y:606,t:1527613864571};\\\", \\\"{x:605,y:608,t:1527613864587};\\\", \\\"{x:582,y:609,t:1527613864604};\\\", \\\"{x:564,y:610,t:1527613864622};\\\", \\\"{x:543,y:611,t:1527613864637};\\\", \\\"{x:521,y:611,t:1527613864653};\\\", \\\"{x:506,y:611,t:1527613864670};\\\", \\\"{x:482,y:611,t:1527613864687};\\\", \\\"{x:450,y:611,t:1527613864703};\\\", \\\"{x:424,y:603,t:1527613864721};\\\", \\\"{x:384,y:599,t:1527613864737};\\\", \\\"{x:338,y:592,t:1527613864754};\\\", \\\"{x:292,y:580,t:1527613864770};\\\", \\\"{x:270,y:576,t:1527613864787};\\\", \\\"{x:243,y:570,t:1527613864804};\\\", \\\"{x:213,y:563,t:1527613864821};\\\", \\\"{x:196,y:557,t:1527613864836};\\\", \\\"{x:186,y:555,t:1527613864854};\\\", \\\"{x:181,y:553,t:1527613864870};\\\", \\\"{x:180,y:553,t:1527613864887};\\\", \\\"{x:179,y:552,t:1527613865204};\\\", \\\"{x:181,y:549,t:1527613865221};\\\", \\\"{x:182,y:547,t:1527613865237};\\\", \\\"{x:182,y:546,t:1527613865254};\\\", \\\"{x:184,y:544,t:1527613865271};\\\", \\\"{x:185,y:543,t:1527613865288};\\\", \\\"{x:187,y:541,t:1527613865304};\\\", \\\"{x:190,y:537,t:1527613865321};\\\", \\\"{x:193,y:534,t:1527613865338};\\\", \\\"{x:197,y:530,t:1527613865354};\\\", \\\"{x:202,y:526,t:1527613865371};\\\", \\\"{x:204,y:525,t:1527613865387};\\\", \\\"{x:207,y:522,t:1527613865404};\\\", \\\"{x:208,y:521,t:1527613865421};\\\", \\\"{x:209,y:520,t:1527613865438};\\\", \\\"{x:206,y:520,t:1527613865556};\\\", \\\"{x:201,y:523,t:1527613865572};\\\", \\\"{x:192,y:528,t:1527613865587};\\\", \\\"{x:188,y:529,t:1527613865605};\\\", \\\"{x:180,y:533,t:1527613865621};\\\", \\\"{x:178,y:534,t:1527613865639};\\\", \\\"{x:175,y:535,t:1527613865654};\\\", \\\"{x:174,y:535,t:1527613865706};\\\", \\\"{x:173,y:536,t:1527613865722};\\\", \\\"{x:172,y:537,t:1527613865738};\\\", \\\"{x:171,y:538,t:1527613865753};\\\", \\\"{x:170,y:539,t:1527613865771};\\\", \\\"{x:169,y:540,t:1527613865787};\\\", \\\"{x:167,y:543,t:1527613865804};\\\", \\\"{x:165,y:549,t:1527613865821};\\\", \\\"{x:165,y:555,t:1527613865837};\\\", \\\"{x:164,y:562,t:1527613865855};\\\", \\\"{x:164,y:566,t:1527613865872};\\\", \\\"{x:164,y:569,t:1527613865888};\\\", \\\"{x:164,y:572,t:1527613865906};\\\", \\\"{x:164,y:576,t:1527613865922};\\\", \\\"{x:164,y:577,t:1527613865938};\\\", \\\"{x:164,y:579,t:1527613865956};\\\", \\\"{x:164,y:580,t:1527613865971};\\\", \\\"{x:164,y:582,t:1527613865988};\\\", \\\"{x:164,y:584,t:1527613866004};\\\", \\\"{x:164,y:585,t:1527613866022};\\\", \\\"{x:164,y:589,t:1527613866037};\\\", \\\"{x:164,y:591,t:1527613866054};\\\", \\\"{x:164,y:594,t:1527613866071};\\\", \\\"{x:164,y:595,t:1527613866106};\\\", \\\"{x:165,y:596,t:1527613866122};\\\", \\\"{x:167,y:595,t:1527613866146};\\\", \\\"{x:169,y:594,t:1527613866155};\\\", \\\"{x:175,y:589,t:1527613866172};\\\", \\\"{x:187,y:581,t:1527613866189};\\\", \\\"{x:204,y:570,t:1527613866205};\\\", \\\"{x:226,y:562,t:1527613866221};\\\", \\\"{x:242,y:553,t:1527613866237};\\\", \\\"{x:254,y:548,t:1527613866254};\\\", \\\"{x:260,y:547,t:1527613866271};\\\", \\\"{x:263,y:545,t:1527613866287};\\\", \\\"{x:267,y:543,t:1527613866304};\\\", \\\"{x:274,y:541,t:1527613866323};\\\", \\\"{x:283,y:536,t:1527613866338};\\\", \\\"{x:294,y:532,t:1527613866355};\\\", \\\"{x:302,y:528,t:1527613866371};\\\", \\\"{x:306,y:527,t:1527613866389};\\\", \\\"{x:318,y:523,t:1527613866404};\\\", \\\"{x:332,y:519,t:1527613866421};\\\", \\\"{x:352,y:514,t:1527613866438};\\\", \\\"{x:373,y:511,t:1527613866454};\\\", \\\"{x:395,y:507,t:1527613866473};\\\", \\\"{x:413,y:505,t:1527613866488};\\\", \\\"{x:428,y:502,t:1527613866505};\\\", \\\"{x:441,y:501,t:1527613866521};\\\", \\\"{x:448,y:500,t:1527613866539};\\\", \\\"{x:452,y:498,t:1527613866555};\\\", \\\"{x:453,y:497,t:1527613866572};\\\", \\\"{x:462,y:497,t:1527613866589};\\\", \\\"{x:476,y:496,t:1527613866604};\\\", \\\"{x:499,y:493,t:1527613866622};\\\", \\\"{x:528,y:490,t:1527613866638};\\\", \\\"{x:554,y:485,t:1527613866656};\\\", \\\"{x:571,y:485,t:1527613866673};\\\", \\\"{x:583,y:484,t:1527613866689};\\\", \\\"{x:589,y:484,t:1527613866706};\\\", \\\"{x:592,y:483,t:1527613866723};\\\", \\\"{x:593,y:482,t:1527613866739};\\\", \\\"{x:595,y:482,t:1527613866763};\\\", \\\"{x:596,y:482,t:1527613866787};\\\", \\\"{x:598,y:482,t:1527613866803};\\\", \\\"{x:600,y:481,t:1527613866812};\\\", \\\"{x:601,y:481,t:1527613866823};\\\", \\\"{x:603,y:479,t:1527613866838};\\\", \\\"{x:605,y:479,t:1527613866855};\\\", \\\"{x:609,y:479,t:1527613867419};\\\", \\\"{x:620,y:480,t:1527613867427};\\\", \\\"{x:627,y:481,t:1527613867439};\\\", \\\"{x:677,y:489,t:1527613867457};\\\", \\\"{x:751,y:496,t:1527613867473};\\\", \\\"{x:830,y:502,t:1527613867489};\\\", \\\"{x:904,y:505,t:1527613867506};\\\", \\\"{x:935,y:505,t:1527613867522};\\\", \\\"{x:941,y:505,t:1527613867540};\\\", \\\"{x:942,y:505,t:1527613867555};\\\", \\\"{x:942,y:506,t:1527613867683};\\\", \\\"{x:940,y:507,t:1527613867695};\\\", \\\"{x:912,y:513,t:1527613867715};\\\", \\\"{x:899,y:515,t:1527613867722};\\\", \\\"{x:873,y:518,t:1527613867739};\\\", \\\"{x:848,y:522,t:1527613867755};\\\", \\\"{x:833,y:525,t:1527613867773};\\\", \\\"{x:827,y:527,t:1527613867788};\\\", \\\"{x:826,y:527,t:1527613867805};\\\", \\\"{x:826,y:528,t:1527613867867};\\\", \\\"{x:827,y:528,t:1527613867996};\\\", \\\"{x:820,y:528,t:1527613868387};\\\", \\\"{x:814,y:534,t:1527613868395};\\\", \\\"{x:808,y:540,t:1527613868406};\\\", \\\"{x:793,y:551,t:1527613868423};\\\", \\\"{x:776,y:565,t:1527613868439};\\\", \\\"{x:758,y:577,t:1527613868457};\\\", \\\"{x:751,y:582,t:1527613868474};\\\", \\\"{x:745,y:586,t:1527613868489};\\\", \\\"{x:738,y:593,t:1527613868507};\\\", \\\"{x:727,y:599,t:1527613868523};\\\", \\\"{x:718,y:612,t:1527613868540};\\\", \\\"{x:701,y:627,t:1527613868556};\\\", \\\"{x:681,y:642,t:1527613868573};\\\", \\\"{x:663,y:654,t:1527613868590};\\\", \\\"{x:650,y:665,t:1527613868607};\\\", \\\"{x:642,y:673,t:1527613868623};\\\", \\\"{x:637,y:678,t:1527613868639};\\\", \\\"{x:632,y:681,t:1527613868657};\\\", \\\"{x:629,y:683,t:1527613868673};\\\", \\\"{x:628,y:683,t:1527613868690};\\\", \\\"{x:627,y:685,t:1527613868706};\\\", \\\"{x:624,y:685,t:1527613868723};\\\", \\\"{x:615,y:687,t:1527613868740};\\\", \\\"{x:603,y:689,t:1527613868757};\\\", \\\"{x:589,y:691,t:1527613868774};\\\", \\\"{x:579,y:692,t:1527613868790};\\\", \\\"{x:568,y:694,t:1527613868807};\\\", \\\"{x:560,y:696,t:1527613868824};\\\", \\\"{x:552,y:699,t:1527613868840};\\\", \\\"{x:537,y:704,t:1527613868857};\\\", \\\"{x:522,y:707,t:1527613868874};\\\", \\\"{x:489,y:717,t:1527613868891};\\\", \\\"{x:474,y:721,t:1527613868907};\\\", \\\"{x:464,y:727,t:1527613868924};\\\", \\\"{x:459,y:730,t:1527613868941};\\\", \\\"{x:458,y:731,t:1527613868957};\\\", \\\"{x:458,y:730,t:1527613869267};\\\", \\\"{x:458,y:728,t:1527613869283};\\\", \\\"{x:458,y:727,t:1527613869300};\\\", \\\"{x:458,y:725,t:1527613869315};\\\", \\\"{x:459,y:723,t:1527613869331};\\\", \\\"{x:460,y:722,t:1527613869347};\\\", \\\"{x:460,y:721,t:1527613869358};\\\", \\\"{x:461,y:720,t:1527613869492};\\\" ] }, { \\\"rt\\\": 22527, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 286152, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"K7JVY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:462,y:720,t:1527613875372};\\\", \\\"{x:463,y:720,t:1527613875418};\\\", \\\"{x:466,y:718,t:1527613875442};\\\", \\\"{x:467,y:717,t:1527613875450};\\\", \\\"{x:468,y:717,t:1527613875461};\\\", \\\"{x:469,y:717,t:1527613875477};\\\", \\\"{x:471,y:717,t:1527613875494};\\\", \\\"{x:472,y:717,t:1527613875511};\\\", \\\"{x:473,y:717,t:1527613875539};\\\", \\\"{x:475,y:716,t:1527613875546};\\\", \\\"{x:477,y:716,t:1527613875571};\\\", \\\"{x:478,y:716,t:1527613875579};\\\", \\\"{x:481,y:716,t:1527613875610};\\\", \\\"{x:482,y:716,t:1527613875627};\\\", \\\"{x:486,y:716,t:1527613875644};\\\", \\\"{x:489,y:716,t:1527613875661};\\\", \\\"{x:492,y:716,t:1527613875677};\\\", \\\"{x:496,y:716,t:1527613875695};\\\", \\\"{x:500,y:716,t:1527613875711};\\\", \\\"{x:504,y:716,t:1527613875727};\\\", \\\"{x:506,y:716,t:1527613875744};\\\", \\\"{x:508,y:716,t:1527613875762};\\\", \\\"{x:509,y:716,t:1527613875779};\\\", \\\"{x:510,y:716,t:1527613875827};\\\", \\\"{x:511,y:716,t:1527613875844};\\\", \\\"{x:512,y:716,t:1527613875861};\\\", \\\"{x:513,y:716,t:1527613875877};\\\", \\\"{x:516,y:715,t:1527613875895};\\\", \\\"{x:520,y:715,t:1527613875911};\\\", \\\"{x:523,y:715,t:1527613875928};\\\", \\\"{x:527,y:715,t:1527613875945};\\\", \\\"{x:533,y:715,t:1527613875962};\\\", \\\"{x:536,y:715,t:1527613875978};\\\", \\\"{x:540,y:715,t:1527613875995};\\\", \\\"{x:544,y:714,t:1527613876011};\\\", \\\"{x:547,y:714,t:1527613876027};\\\", \\\"{x:550,y:713,t:1527613876045};\\\", \\\"{x:553,y:713,t:1527613876061};\\\", \\\"{x:554,y:713,t:1527613876078};\\\", \\\"{x:556,y:713,t:1527613876095};\\\", \\\"{x:557,y:713,t:1527613876111};\\\", \\\"{x:559,y:711,t:1527613876128};\\\", \\\"{x:560,y:711,t:1527613876145};\\\", \\\"{x:562,y:711,t:1527613876162};\\\", \\\"{x:563,y:710,t:1527613876178};\\\", \\\"{x:564,y:710,t:1527613876194};\\\", \\\"{x:567,y:708,t:1527613876213};\\\", \\\"{x:569,y:708,t:1527613876228};\\\", \\\"{x:572,y:706,t:1527613876244};\\\", \\\"{x:578,y:704,t:1527613876263};\\\", \\\"{x:583,y:702,t:1527613876280};\\\", \\\"{x:591,y:699,t:1527613876296};\\\", \\\"{x:600,y:698,t:1527613876313};\\\", \\\"{x:611,y:694,t:1527613876330};\\\", \\\"{x:620,y:691,t:1527613876346};\\\", \\\"{x:624,y:690,t:1527613876363};\\\", \\\"{x:627,y:689,t:1527613876380};\\\", \\\"{x:628,y:689,t:1527613876402};\\\", \\\"{x:629,y:688,t:1527613876413};\\\", \\\"{x:631,y:688,t:1527613876430};\\\", \\\"{x:635,y:688,t:1527613876447};\\\", \\\"{x:642,y:686,t:1527613876463};\\\", \\\"{x:648,y:686,t:1527613876480};\\\", \\\"{x:656,y:686,t:1527613876497};\\\", \\\"{x:665,y:686,t:1527613876513};\\\", \\\"{x:673,y:686,t:1527613876531};\\\", \\\"{x:682,y:686,t:1527613876547};\\\", \\\"{x:689,y:686,t:1527613876563};\\\", \\\"{x:697,y:686,t:1527613876580};\\\", \\\"{x:706,y:686,t:1527613876598};\\\", \\\"{x:723,y:686,t:1527613876613};\\\", \\\"{x:745,y:686,t:1527613876630};\\\", \\\"{x:772,y:686,t:1527613876647};\\\", \\\"{x:798,y:687,t:1527613876663};\\\", \\\"{x:824,y:689,t:1527613876680};\\\", \\\"{x:853,y:691,t:1527613876697};\\\", \\\"{x:886,y:696,t:1527613876714};\\\", \\\"{x:919,y:697,t:1527613876731};\\\", \\\"{x:951,y:698,t:1527613876747};\\\", \\\"{x:960,y:698,t:1527613876764};\\\", \\\"{x:974,y:701,t:1527613876780};\\\", \\\"{x:989,y:702,t:1527613876798};\\\", \\\"{x:1011,y:706,t:1527613876814};\\\", \\\"{x:1031,y:707,t:1527613876830};\\\", \\\"{x:1047,y:709,t:1527613876847};\\\", \\\"{x:1064,y:711,t:1527613876864};\\\", \\\"{x:1086,y:713,t:1527613876880};\\\", \\\"{x:1104,y:714,t:1527613876897};\\\", \\\"{x:1126,y:716,t:1527613876914};\\\", \\\"{x:1152,y:716,t:1527613876930};\\\", \\\"{x:1187,y:716,t:1527613876947};\\\", \\\"{x:1218,y:718,t:1527613876964};\\\", \\\"{x:1254,y:718,t:1527613876981};\\\", \\\"{x:1290,y:718,t:1527613876997};\\\", \\\"{x:1330,y:718,t:1527613877015};\\\", \\\"{x:1369,y:718,t:1527613877031};\\\", \\\"{x:1397,y:718,t:1527613877047};\\\", \\\"{x:1429,y:718,t:1527613877064};\\\", \\\"{x:1462,y:718,t:1527613877081};\\\", \\\"{x:1484,y:718,t:1527613877098};\\\", \\\"{x:1507,y:719,t:1527613877114};\\\", \\\"{x:1542,y:723,t:1527613877131};\\\", \\\"{x:1562,y:728,t:1527613877148};\\\", \\\"{x:1582,y:730,t:1527613877164};\\\", \\\"{x:1594,y:731,t:1527613877181};\\\", \\\"{x:1598,y:732,t:1527613877198};\\\", \\\"{x:1600,y:733,t:1527613877214};\\\", \\\"{x:1600,y:735,t:1527613877292};\\\", \\\"{x:1600,y:737,t:1527613877299};\\\", \\\"{x:1600,y:739,t:1527613877315};\\\", \\\"{x:1600,y:740,t:1527613877363};\\\", \\\"{x:1599,y:740,t:1527613877932};\\\", \\\"{x:1597,y:741,t:1527613877964};\\\", \\\"{x:1595,y:741,t:1527613877979};\\\", \\\"{x:1595,y:742,t:1527613877987};\\\", \\\"{x:1594,y:743,t:1527613877999};\\\", \\\"{x:1593,y:744,t:1527613878020};\\\", \\\"{x:1591,y:745,t:1527613878033};\\\", \\\"{x:1588,y:747,t:1527613878049};\\\", \\\"{x:1586,y:748,t:1527613878066};\\\", \\\"{x:1586,y:749,t:1527613878083};\\\", \\\"{x:1585,y:749,t:1527613878148};\\\", \\\"{x:1585,y:750,t:1527613878323};\\\", \\\"{x:1584,y:750,t:1527613878333};\\\", \\\"{x:1581,y:750,t:1527613878350};\\\", \\\"{x:1573,y:750,t:1527613878366};\\\", \\\"{x:1570,y:751,t:1527613878383};\\\", \\\"{x:1568,y:753,t:1527613878399};\\\", \\\"{x:1566,y:753,t:1527613878416};\\\", \\\"{x:1565,y:754,t:1527613878435};\\\", \\\"{x:1563,y:755,t:1527613878450};\\\", \\\"{x:1560,y:756,t:1527613878466};\\\", \\\"{x:1556,y:758,t:1527613878483};\\\", \\\"{x:1552,y:759,t:1527613878499};\\\", \\\"{x:1551,y:760,t:1527613878516};\\\", \\\"{x:1546,y:763,t:1527613878532};\\\", \\\"{x:1542,y:764,t:1527613878549};\\\", \\\"{x:1536,y:764,t:1527613878566};\\\", \\\"{x:1528,y:766,t:1527613878583};\\\", \\\"{x:1524,y:768,t:1527613878599};\\\", \\\"{x:1519,y:768,t:1527613878616};\\\", \\\"{x:1509,y:770,t:1527613878632};\\\", \\\"{x:1503,y:771,t:1527613878650};\\\", \\\"{x:1492,y:773,t:1527613878666};\\\", \\\"{x:1476,y:777,t:1527613878683};\\\", \\\"{x:1461,y:779,t:1527613878699};\\\", \\\"{x:1451,y:779,t:1527613878717};\\\", \\\"{x:1433,y:783,t:1527613878733};\\\", \\\"{x:1408,y:790,t:1527613878749};\\\", \\\"{x:1383,y:800,t:1527613878767};\\\", \\\"{x:1350,y:810,t:1527613878783};\\\", \\\"{x:1316,y:819,t:1527613878800};\\\", \\\"{x:1290,y:826,t:1527613878816};\\\", \\\"{x:1267,y:832,t:1527613878834};\\\", \\\"{x:1255,y:836,t:1527613878849};\\\", \\\"{x:1244,y:838,t:1527613878866};\\\", \\\"{x:1229,y:840,t:1527613878883};\\\", \\\"{x:1228,y:840,t:1527613878899};\\\", \\\"{x:1226,y:841,t:1527613878917};\\\", \\\"{x:1223,y:841,t:1527613878933};\\\", \\\"{x:1219,y:840,t:1527613878949};\\\", \\\"{x:1210,y:835,t:1527613878967};\\\", \\\"{x:1194,y:828,t:1527613878983};\\\", \\\"{x:1184,y:819,t:1527613879000};\\\", \\\"{x:1175,y:807,t:1527613879016};\\\", \\\"{x:1168,y:792,t:1527613879034};\\\", \\\"{x:1162,y:777,t:1527613879050};\\\", \\\"{x:1158,y:768,t:1527613879067};\\\", \\\"{x:1156,y:761,t:1527613879084};\\\", \\\"{x:1156,y:760,t:1527613879101};\\\", \\\"{x:1155,y:755,t:1527613879117};\\\", \\\"{x:1154,y:749,t:1527613879134};\\\", \\\"{x:1154,y:743,t:1527613879150};\\\", \\\"{x:1151,y:737,t:1527613879167};\\\", \\\"{x:1150,y:731,t:1527613879184};\\\", \\\"{x:1150,y:726,t:1527613879201};\\\", \\\"{x:1148,y:722,t:1527613879216};\\\", \\\"{x:1148,y:716,t:1527613879234};\\\", \\\"{x:1148,y:702,t:1527613879251};\\\", \\\"{x:1148,y:696,t:1527613879267};\\\", \\\"{x:1148,y:692,t:1527613879283};\\\", \\\"{x:1148,y:687,t:1527613879301};\\\", \\\"{x:1148,y:683,t:1527613879317};\\\", \\\"{x:1149,y:679,t:1527613879333};\\\", \\\"{x:1151,y:674,t:1527613879351};\\\", \\\"{x:1152,y:669,t:1527613879367};\\\", \\\"{x:1153,y:665,t:1527613879384};\\\", \\\"{x:1156,y:661,t:1527613879401};\\\", \\\"{x:1161,y:655,t:1527613879418};\\\", \\\"{x:1165,y:648,t:1527613879434};\\\", \\\"{x:1172,y:641,t:1527613879452};\\\", \\\"{x:1177,y:636,t:1527613879467};\\\", \\\"{x:1180,y:633,t:1527613879484};\\\", \\\"{x:1184,y:631,t:1527613879501};\\\", \\\"{x:1188,y:629,t:1527613879518};\\\", \\\"{x:1191,y:628,t:1527613879534};\\\", \\\"{x:1194,y:627,t:1527613879551};\\\", \\\"{x:1197,y:626,t:1527613879568};\\\", \\\"{x:1198,y:625,t:1527613879584};\\\", \\\"{x:1200,y:624,t:1527613879600};\\\", \\\"{x:1205,y:624,t:1527613879618};\\\", \\\"{x:1211,y:621,t:1527613879633};\\\", \\\"{x:1222,y:620,t:1527613879650};\\\", \\\"{x:1230,y:619,t:1527613879667};\\\", \\\"{x:1237,y:619,t:1527613879684};\\\", \\\"{x:1240,y:618,t:1527613879700};\\\", \\\"{x:1245,y:617,t:1527613879717};\\\", \\\"{x:1248,y:617,t:1527613879735};\\\", \\\"{x:1251,y:616,t:1527613879751};\\\", \\\"{x:1254,y:616,t:1527613879767};\\\", \\\"{x:1258,y:615,t:1527613879784};\\\", \\\"{x:1261,y:615,t:1527613879800};\\\", \\\"{x:1262,y:614,t:1527613879818};\\\", \\\"{x:1263,y:614,t:1527613879835};\\\", \\\"{x:1265,y:614,t:1527613879883};\\\", \\\"{x:1266,y:613,t:1527613879915};\\\", \\\"{x:1267,y:613,t:1527613879939};\\\", \\\"{x:1268,y:613,t:1527613879964};\\\", \\\"{x:1269,y:612,t:1527613880004};\\\", \\\"{x:1271,y:612,t:1527613880020};\\\", \\\"{x:1272,y:612,t:1527613880051};\\\", \\\"{x:1276,y:611,t:1527613880068};\\\", \\\"{x:1279,y:611,t:1527613880092};\\\", \\\"{x:1280,y:611,t:1527613880107};\\\", \\\"{x:1282,y:610,t:1527613880118};\\\", \\\"{x:1284,y:610,t:1527613880135};\\\", \\\"{x:1286,y:610,t:1527613880151};\\\", \\\"{x:1289,y:609,t:1527613880168};\\\", \\\"{x:1290,y:609,t:1527613880188};\\\", \\\"{x:1293,y:609,t:1527613880202};\\\", \\\"{x:1295,y:609,t:1527613880218};\\\", \\\"{x:1304,y:609,t:1527613880235};\\\", \\\"{x:1310,y:609,t:1527613880251};\\\", \\\"{x:1316,y:609,t:1527613880268};\\\", \\\"{x:1322,y:609,t:1527613880285};\\\", \\\"{x:1330,y:609,t:1527613880301};\\\", \\\"{x:1339,y:609,t:1527613880318};\\\", \\\"{x:1347,y:609,t:1527613880335};\\\", \\\"{x:1352,y:609,t:1527613880351};\\\", \\\"{x:1355,y:609,t:1527613880368};\\\", \\\"{x:1356,y:609,t:1527613880386};\\\", \\\"{x:1357,y:609,t:1527613880676};\\\", \\\"{x:1358,y:609,t:1527613881460};\\\", \\\"{x:1359,y:609,t:1527613888268};\\\", \\\"{x:1359,y:613,t:1527613888277};\\\", \\\"{x:1359,y:618,t:1527613888294};\\\", \\\"{x:1359,y:625,t:1527613888311};\\\", \\\"{x:1358,y:631,t:1527613888327};\\\", \\\"{x:1358,y:633,t:1527613888344};\\\", \\\"{x:1358,y:634,t:1527613888361};\\\", \\\"{x:1358,y:636,t:1527613888377};\\\", \\\"{x:1358,y:638,t:1527613888394};\\\", \\\"{x:1358,y:640,t:1527613888412};\\\", \\\"{x:1358,y:643,t:1527613888428};\\\", \\\"{x:1358,y:645,t:1527613888444};\\\", \\\"{x:1358,y:646,t:1527613888461};\\\", \\\"{x:1357,y:649,t:1527613888478};\\\", \\\"{x:1356,y:652,t:1527613888494};\\\", \\\"{x:1353,y:656,t:1527613888511};\\\", \\\"{x:1350,y:661,t:1527613888529};\\\", \\\"{x:1345,y:667,t:1527613888545};\\\", \\\"{x:1336,y:673,t:1527613888562};\\\", \\\"{x:1324,y:679,t:1527613888578};\\\", \\\"{x:1314,y:685,t:1527613888594};\\\", \\\"{x:1292,y:696,t:1527613888612};\\\", \\\"{x:1280,y:703,t:1527613888628};\\\", \\\"{x:1262,y:706,t:1527613888643};\\\", \\\"{x:1244,y:710,t:1527613888661};\\\", \\\"{x:1221,y:711,t:1527613888678};\\\", \\\"{x:1201,y:714,t:1527613888695};\\\", \\\"{x:1178,y:714,t:1527613888711};\\\", \\\"{x:1160,y:714,t:1527613888728};\\\", \\\"{x:1133,y:714,t:1527613888744};\\\", \\\"{x:1103,y:714,t:1527613888761};\\\", \\\"{x:1049,y:713,t:1527613888777};\\\", \\\"{x:954,y:694,t:1527613888795};\\\", \\\"{x:877,y:685,t:1527613888811};\\\", \\\"{x:797,y:665,t:1527613888828};\\\", \\\"{x:728,y:649,t:1527613888844};\\\", \\\"{x:663,y:626,t:1527613888861};\\\", \\\"{x:626,y:612,t:1527613888878};\\\", \\\"{x:603,y:603,t:1527613888896};\\\", \\\"{x:585,y:593,t:1527613888911};\\\", \\\"{x:573,y:585,t:1527613888927};\\\", \\\"{x:567,y:583,t:1527613888940};\\\", \\\"{x:558,y:576,t:1527613888957};\\\", \\\"{x:545,y:569,t:1527613888974};\\\", \\\"{x:535,y:563,t:1527613888991};\\\", \\\"{x:519,y:554,t:1527613889007};\\\", \\\"{x:502,y:546,t:1527613889023};\\\", \\\"{x:491,y:540,t:1527613889042};\\\", \\\"{x:482,y:534,t:1527613889057};\\\", \\\"{x:478,y:532,t:1527613889075};\\\", \\\"{x:475,y:529,t:1527613889090};\\\", \\\"{x:473,y:529,t:1527613889107};\\\", \\\"{x:473,y:528,t:1527613889124};\\\", \\\"{x:473,y:527,t:1527613889140};\\\", \\\"{x:474,y:524,t:1527613889156};\\\", \\\"{x:476,y:520,t:1527613889173};\\\", \\\"{x:481,y:513,t:1527613889190};\\\", \\\"{x:485,y:510,t:1527613889206};\\\", \\\"{x:487,y:508,t:1527613889223};\\\", \\\"{x:488,y:507,t:1527613889241};\\\", \\\"{x:487,y:507,t:1527613889307};\\\", \\\"{x:480,y:507,t:1527613889324};\\\", \\\"{x:460,y:511,t:1527613889341};\\\", \\\"{x:441,y:513,t:1527613889357};\\\", \\\"{x:416,y:517,t:1527613889375};\\\", \\\"{x:393,y:522,t:1527613889391};\\\", \\\"{x:376,y:523,t:1527613889406};\\\", \\\"{x:367,y:524,t:1527613889423};\\\", \\\"{x:362,y:526,t:1527613889439};\\\", \\\"{x:360,y:526,t:1527613889457};\\\", \\\"{x:359,y:527,t:1527613889473};\\\", \\\"{x:350,y:530,t:1527613889490};\\\", \\\"{x:337,y:534,t:1527613889508};\\\", \\\"{x:319,y:537,t:1527613889523};\\\", \\\"{x:302,y:540,t:1527613889541};\\\", \\\"{x:281,y:542,t:1527613889558};\\\", \\\"{x:260,y:546,t:1527613889574};\\\", \\\"{x:242,y:546,t:1527613889590};\\\", \\\"{x:234,y:546,t:1527613889607};\\\", \\\"{x:228,y:546,t:1527613889623};\\\", \\\"{x:223,y:546,t:1527613889640};\\\", \\\"{x:219,y:546,t:1527613889657};\\\", \\\"{x:208,y:550,t:1527613889674};\\\", \\\"{x:197,y:554,t:1527613889690};\\\", \\\"{x:186,y:556,t:1527613889707};\\\", \\\"{x:176,y:560,t:1527613889725};\\\", \\\"{x:166,y:561,t:1527613889740};\\\", \\\"{x:159,y:563,t:1527613889758};\\\", \\\"{x:157,y:565,t:1527613889774};\\\", \\\"{x:156,y:566,t:1527613889827};\\\", \\\"{x:155,y:567,t:1527613889851};\\\", \\\"{x:154,y:568,t:1527613889859};\\\", \\\"{x:154,y:569,t:1527613889874};\\\", \\\"{x:154,y:570,t:1527613889890};\\\", \\\"{x:154,y:573,t:1527613889908};\\\", \\\"{x:154,y:574,t:1527613889925};\\\", \\\"{x:154,y:576,t:1527613889940};\\\", \\\"{x:154,y:578,t:1527613889958};\\\", \\\"{x:154,y:579,t:1527613889976};\\\", \\\"{x:154,y:580,t:1527613889990};\\\", \\\"{x:154,y:583,t:1527613890008};\\\", \\\"{x:158,y:583,t:1527613890024};\\\", \\\"{x:180,y:583,t:1527613890041};\\\", \\\"{x:225,y:583,t:1527613890058};\\\", \\\"{x:354,y:569,t:1527613890074};\\\", \\\"{x:437,y:558,t:1527613890090};\\\", \\\"{x:477,y:544,t:1527613890108};\\\", \\\"{x:500,y:537,t:1527613890125};\\\", \\\"{x:510,y:532,t:1527613890143};\\\", \\\"{x:513,y:530,t:1527613890157};\\\", \\\"{x:514,y:529,t:1527613890175};\\\", \\\"{x:516,y:527,t:1527613890192};\\\", \\\"{x:521,y:526,t:1527613890208};\\\", \\\"{x:532,y:521,t:1527613890225};\\\", \\\"{x:549,y:515,t:1527613890242};\\\", \\\"{x:570,y:507,t:1527613890258};\\\", \\\"{x:591,y:499,t:1527613890276};\\\", \\\"{x:595,y:496,t:1527613890292};\\\", \\\"{x:596,y:496,t:1527613890443};\\\", \\\"{x:597,y:496,t:1527613890507};\\\", \\\"{x:598,y:495,t:1527613890573};\\\", \\\"{x:602,y:492,t:1527613890591};\\\", \\\"{x:613,y:488,t:1527613890608};\\\", \\\"{x:630,y:482,t:1527613890625};\\\", \\\"{x:647,y:476,t:1527613890642};\\\", \\\"{x:679,y:467,t:1527613890657};\\\", \\\"{x:701,y:462,t:1527613890675};\\\", \\\"{x:729,y:461,t:1527613890692};\\\", \\\"{x:755,y:459,t:1527613890707};\\\", \\\"{x:790,y:459,t:1527613890724};\\\", \\\"{x:817,y:459,t:1527613890742};\\\", \\\"{x:835,y:462,t:1527613890757};\\\", \\\"{x:843,y:464,t:1527613890774};\\\", \\\"{x:844,y:464,t:1527613890792};\\\", \\\"{x:845,y:466,t:1527613890877};\\\", \\\"{x:846,y:467,t:1527613890892};\\\", \\\"{x:847,y:467,t:1527613890914};\\\", \\\"{x:847,y:468,t:1527613890925};\\\", \\\"{x:847,y:471,t:1527613890942};\\\", \\\"{x:847,y:473,t:1527613890958};\\\", \\\"{x:847,y:476,t:1527613890974};\\\", \\\"{x:847,y:479,t:1527613890992};\\\", \\\"{x:847,y:480,t:1527613891008};\\\", \\\"{x:842,y:480,t:1527613891354};\\\", \\\"{x:831,y:480,t:1527613891362};\\\", \\\"{x:806,y:483,t:1527613891376};\\\", \\\"{x:729,y:489,t:1527613891393};\\\", \\\"{x:663,y:495,t:1527613891409};\\\", \\\"{x:589,y:501,t:1527613891426};\\\", \\\"{x:513,y:503,t:1527613891443};\\\", \\\"{x:477,y:503,t:1527613891459};\\\", \\\"{x:456,y:505,t:1527613891476};\\\", \\\"{x:438,y:508,t:1527613891492};\\\", \\\"{x:424,y:510,t:1527613891509};\\\", \\\"{x:414,y:512,t:1527613891527};\\\", \\\"{x:406,y:512,t:1527613891542};\\\", \\\"{x:399,y:512,t:1527613891559};\\\", \\\"{x:391,y:513,t:1527613891576};\\\", \\\"{x:380,y:513,t:1527613891591};\\\", \\\"{x:361,y:513,t:1527613891609};\\\", \\\"{x:345,y:513,t:1527613891626};\\\", \\\"{x:327,y:513,t:1527613891642};\\\", \\\"{x:321,y:513,t:1527613891659};\\\", \\\"{x:315,y:513,t:1527613891676};\\\", \\\"{x:307,y:513,t:1527613891693};\\\", \\\"{x:296,y:513,t:1527613891709};\\\", \\\"{x:287,y:513,t:1527613891725};\\\", \\\"{x:279,y:513,t:1527613891743};\\\", \\\"{x:270,y:513,t:1527613891761};\\\", \\\"{x:264,y:514,t:1527613891776};\\\", \\\"{x:261,y:514,t:1527613891793};\\\", \\\"{x:258,y:515,t:1527613891809};\\\", \\\"{x:253,y:517,t:1527613891826};\\\", \\\"{x:240,y:519,t:1527613891842};\\\", \\\"{x:230,y:520,t:1527613891859};\\\", \\\"{x:215,y:522,t:1527613891876};\\\", \\\"{x:201,y:524,t:1527613891893};\\\", \\\"{x:190,y:524,t:1527613891910};\\\", \\\"{x:177,y:524,t:1527613891925};\\\", \\\"{x:169,y:524,t:1527613891943};\\\", \\\"{x:165,y:524,t:1527613891959};\\\", \\\"{x:162,y:524,t:1527613891975};\\\", \\\"{x:161,y:524,t:1527613891993};\\\", \\\"{x:160,y:524,t:1527613892066};\\\", \\\"{x:169,y:531,t:1527613892660};\\\", \\\"{x:224,y:562,t:1527613892677};\\\", \\\"{x:284,y:597,t:1527613892693};\\\", \\\"{x:350,y:635,t:1527613892711};\\\", \\\"{x:397,y:664,t:1527613892727};\\\", \\\"{x:410,y:682,t:1527613892743};\\\", \\\"{x:413,y:689,t:1527613892759};\\\", \\\"{x:416,y:692,t:1527613892777};\\\", \\\"{x:418,y:698,t:1527613892793};\\\", \\\"{x:420,y:699,t:1527613892810};\\\", \\\"{x:421,y:700,t:1527613892827};\\\", \\\"{x:423,y:702,t:1527613893012};\\\", \\\"{x:425,y:703,t:1527613893028};\\\", \\\"{x:426,y:704,t:1527613893044};\\\", \\\"{x:427,y:704,t:1527613893156};\\\", \\\"{x:428,y:705,t:1527613893163};\\\", \\\"{x:430,y:706,t:1527613893178};\\\", \\\"{x:431,y:706,t:1527613893194};\\\", \\\"{x:442,y:711,t:1527613893212};\\\", \\\"{x:451,y:713,t:1527613893229};\\\", \\\"{x:454,y:714,t:1527613893243};\\\", \\\"{x:455,y:714,t:1527613893260};\\\", \\\"{x:456,y:714,t:1527613893276};\\\", \\\"{x:459,y:715,t:1527613893293};\\\", \\\"{x:465,y:717,t:1527613893310};\\\", \\\"{x:470,y:718,t:1527613893327};\\\", \\\"{x:475,y:720,t:1527613893343};\\\", \\\"{x:476,y:720,t:1527613893359};\\\", \\\"{x:477,y:720,t:1527613893386};\\\" ] }, { \\\"rt\\\": 56702, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 344130, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"K7JVY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-X -E -11 AM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:481,y:722,t:1527613900748};\\\", \\\"{x:507,y:729,t:1527613900755};\\\", \\\"{x:616,y:745,t:1527613900772};\\\", \\\"{x:618,y:747,t:1527613900789};\\\", \\\"{x:623,y:749,t:1527613900805};\\\", \\\"{x:671,y:752,t:1527613900816};\\\", \\\"{x:794,y:758,t:1527613900833};\\\", \\\"{x:960,y:760,t:1527613900850};\\\", \\\"{x:1033,y:760,t:1527613900866};\\\", \\\"{x:1060,y:759,t:1527613900883};\\\", \\\"{x:1082,y:758,t:1527613900900};\\\", \\\"{x:1107,y:758,t:1527613900917};\\\", \\\"{x:1128,y:758,t:1527613900933};\\\", \\\"{x:1161,y:758,t:1527613900950};\\\", \\\"{x:1201,y:762,t:1527613900966};\\\", \\\"{x:1259,y:769,t:1527613900983};\\\", \\\"{x:1320,y:777,t:1527613901001};\\\", \\\"{x:1365,y:777,t:1527613901017};\\\", \\\"{x:1410,y:782,t:1527613901033};\\\", \\\"{x:1464,y:785,t:1527613901050};\\\", \\\"{x:1494,y:786,t:1527613901067};\\\", \\\"{x:1516,y:788,t:1527613901083};\\\", \\\"{x:1537,y:788,t:1527613901100};\\\", \\\"{x:1552,y:788,t:1527613901118};\\\", \\\"{x:1560,y:788,t:1527613901133};\\\", \\\"{x:1565,y:788,t:1527613901150};\\\", \\\"{x:1566,y:789,t:1527613901307};\\\", \\\"{x:1566,y:791,t:1527613901322};\\\", \\\"{x:1566,y:792,t:1527613901333};\\\", \\\"{x:1563,y:796,t:1527613901350};\\\", \\\"{x:1563,y:797,t:1527613901368};\\\", \\\"{x:1559,y:802,t:1527613901383};\\\", \\\"{x:1557,y:806,t:1527613901401};\\\", \\\"{x:1552,y:812,t:1527613901417};\\\", \\\"{x:1548,y:815,t:1527613901434};\\\", \\\"{x:1534,y:822,t:1527613901450};\\\", \\\"{x:1526,y:825,t:1527613901467};\\\", \\\"{x:1522,y:827,t:1527613901484};\\\", \\\"{x:1516,y:828,t:1527613901500};\\\", \\\"{x:1514,y:828,t:1527613901539};\\\", \\\"{x:1513,y:828,t:1527613901555};\\\", \\\"{x:1511,y:828,t:1527613901571};\\\", \\\"{x:1510,y:828,t:1527613901589};\\\", \\\"{x:1509,y:828,t:1527613901600};\\\", \\\"{x:1508,y:828,t:1527613901617};\\\", \\\"{x:1507,y:827,t:1527613901634};\\\", \\\"{x:1506,y:827,t:1527613901650};\\\", \\\"{x:1505,y:827,t:1527613901675};\\\", \\\"{x:1504,y:825,t:1527613901684};\\\", \\\"{x:1502,y:824,t:1527613901700};\\\", \\\"{x:1499,y:823,t:1527613901717};\\\", \\\"{x:1496,y:820,t:1527613901734};\\\", \\\"{x:1493,y:818,t:1527613901751};\\\", \\\"{x:1492,y:817,t:1527613901767};\\\", \\\"{x:1491,y:816,t:1527613901785};\\\", \\\"{x:1491,y:815,t:1527613901800};\\\", \\\"{x:1490,y:814,t:1527613901868};\\\", \\\"{x:1489,y:814,t:1527613901915};\\\", \\\"{x:1488,y:813,t:1527613901956};\\\", \\\"{x:1488,y:812,t:1527613901979};\\\", \\\"{x:1487,y:812,t:1527613902068};\\\", \\\"{x:1486,y:812,t:1527613902091};\\\", \\\"{x:1484,y:812,t:1527613902118};\\\", \\\"{x:1483,y:812,t:1527613902134};\\\", \\\"{x:1481,y:812,t:1527613902152};\\\", \\\"{x:1480,y:812,t:1527613902167};\\\", \\\"{x:1482,y:814,t:1527613903925};\\\", \\\"{x:1486,y:817,t:1527613903936};\\\", \\\"{x:1498,y:827,t:1527613903953};\\\", \\\"{x:1513,y:841,t:1527613903970};\\\", \\\"{x:1527,y:854,t:1527613903985};\\\", \\\"{x:1551,y:869,t:1527613904003};\\\", \\\"{x:1563,y:875,t:1527613904019};\\\", \\\"{x:1579,y:885,t:1527613904036};\\\", \\\"{x:1593,y:895,t:1527613904053};\\\", \\\"{x:1609,y:904,t:1527613904070};\\\", \\\"{x:1628,y:918,t:1527613904086};\\\", \\\"{x:1639,y:924,t:1527613904103};\\\", \\\"{x:1648,y:931,t:1527613904120};\\\", \\\"{x:1655,y:933,t:1527613904136};\\\", \\\"{x:1657,y:934,t:1527613904153};\\\", \\\"{x:1658,y:935,t:1527613904170};\\\", \\\"{x:1659,y:936,t:1527613904187};\\\", \\\"{x:1661,y:936,t:1527613904211};\\\", \\\"{x:1662,y:936,t:1527613904219};\\\", \\\"{x:1667,y:936,t:1527613904237};\\\", \\\"{x:1672,y:936,t:1527613904253};\\\", \\\"{x:1676,y:936,t:1527613904270};\\\", \\\"{x:1678,y:936,t:1527613904287};\\\", \\\"{x:1680,y:936,t:1527613904459};\\\", \\\"{x:1681,y:938,t:1527613904470};\\\", \\\"{x:1683,y:940,t:1527613904487};\\\", \\\"{x:1684,y:941,t:1527613904503};\\\", \\\"{x:1684,y:942,t:1527613904519};\\\", \\\"{x:1685,y:943,t:1527613904540};\\\", \\\"{x:1686,y:943,t:1527613913454};\\\", \\\"{x:1684,y:927,t:1527613930750};\\\", \\\"{x:1652,y:838,t:1527613930761};\\\", \\\"{x:1568,y:700,t:1527613930777};\\\", \\\"{x:1478,y:581,t:1527613930794};\\\", \\\"{x:1369,y:476,t:1527613930811};\\\", \\\"{x:1247,y:384,t:1527613930826};\\\", \\\"{x:1140,y:321,t:1527613930844};\\\", \\\"{x:1047,y:285,t:1527613930860};\\\", \\\"{x:1005,y:281,t:1527613930877};\\\", \\\"{x:983,y:291,t:1527613930893};\\\", \\\"{x:979,y:300,t:1527613930910};\\\", \\\"{x:979,y:308,t:1527613930926};\\\", \\\"{x:979,y:320,t:1527613930943};\\\", \\\"{x:979,y:329,t:1527613930960};\\\", \\\"{x:979,y:343,t:1527613930977};\\\", \\\"{x:981,y:367,t:1527613930994};\\\", \\\"{x:993,y:395,t:1527613931011};\\\", \\\"{x:1034,y:444,t:1527613931027};\\\", \\\"{x:1099,y:490,t:1527613931044};\\\", \\\"{x:1157,y:518,t:1527613931060};\\\", \\\"{x:1215,y:533,t:1527613931077};\\\", \\\"{x:1240,y:535,t:1527613931094};\\\", \\\"{x:1258,y:537,t:1527613931111};\\\", \\\"{x:1277,y:540,t:1527613931128};\\\", \\\"{x:1287,y:541,t:1527613931143};\\\", \\\"{x:1290,y:541,t:1527613931162};\\\", \\\"{x:1291,y:541,t:1527613931205};\\\", \\\"{x:1293,y:541,t:1527613931213};\\\", \\\"{x:1294,y:541,t:1527613931228};\\\", \\\"{x:1300,y:541,t:1527613931244};\\\", \\\"{x:1306,y:541,t:1527613931260};\\\", \\\"{x:1307,y:542,t:1527613931414};\\\", \\\"{x:1307,y:543,t:1527613931427};\\\", \\\"{x:1304,y:551,t:1527613931444};\\\", \\\"{x:1303,y:558,t:1527613931460};\\\", \\\"{x:1296,y:572,t:1527613931477};\\\", \\\"{x:1295,y:580,t:1527613931495};\\\", \\\"{x:1294,y:585,t:1527613931511};\\\", \\\"{x:1292,y:591,t:1527613931528};\\\", \\\"{x:1292,y:598,t:1527613931545};\\\", \\\"{x:1291,y:606,t:1527613931561};\\\", \\\"{x:1291,y:620,t:1527613931577};\\\", \\\"{x:1291,y:629,t:1527613931594};\\\", \\\"{x:1291,y:642,t:1527613931610};\\\", \\\"{x:1295,y:660,t:1527613931627};\\\", \\\"{x:1295,y:677,t:1527613931644};\\\", \\\"{x:1297,y:706,t:1527613931660};\\\", \\\"{x:1297,y:728,t:1527613931677};\\\", \\\"{x:1297,y:749,t:1527613931694};\\\", \\\"{x:1296,y:767,t:1527613931710};\\\", \\\"{x:1292,y:787,t:1527613931728};\\\", \\\"{x:1290,y:804,t:1527613931744};\\\", \\\"{x:1290,y:819,t:1527613931761};\\\", \\\"{x:1290,y:834,t:1527613931777};\\\", \\\"{x:1290,y:842,t:1527613931794};\\\", \\\"{x:1290,y:846,t:1527613931810};\\\", \\\"{x:1290,y:848,t:1527613931828};\\\", \\\"{x:1291,y:853,t:1527613931844};\\\", \\\"{x:1291,y:857,t:1527613931860};\\\", \\\"{x:1292,y:865,t:1527613931877};\\\", \\\"{x:1294,y:879,t:1527613931895};\\\", \\\"{x:1296,y:900,t:1527613931910};\\\", \\\"{x:1296,y:922,t:1527613931927};\\\", \\\"{x:1297,y:946,t:1527613931945};\\\", \\\"{x:1297,y:972,t:1527613931961};\\\", \\\"{x:1297,y:988,t:1527613931977};\\\", \\\"{x:1298,y:1002,t:1527613931994};\\\", \\\"{x:1298,y:1007,t:1527613932010};\\\", \\\"{x:1299,y:1011,t:1527613932028};\\\", \\\"{x:1299,y:1014,t:1527613932044};\\\", \\\"{x:1299,y:1015,t:1527613932245};\\\", \\\"{x:1298,y:1012,t:1527613932261};\\\", \\\"{x:1298,y:1009,t:1527613932278};\\\", \\\"{x:1295,y:1001,t:1527613932295};\\\", \\\"{x:1292,y:993,t:1527613932312};\\\", \\\"{x:1292,y:986,t:1527613932328};\\\", \\\"{x:1291,y:979,t:1527613932344};\\\", \\\"{x:1289,y:974,t:1527613932362};\\\", \\\"{x:1287,y:970,t:1527613932377};\\\", \\\"{x:1287,y:969,t:1527613932394};\\\", \\\"{x:1287,y:968,t:1527613932412};\\\", \\\"{x:1287,y:967,t:1527613932437};\\\", \\\"{x:1287,y:966,t:1527613932557};\\\", \\\"{x:1286,y:966,t:1527613932565};\\\", \\\"{x:1285,y:965,t:1527613932581};\\\", \\\"{x:1284,y:964,t:1527613932595};\\\", \\\"{x:1284,y:963,t:1527613932611};\\\", \\\"{x:1284,y:960,t:1527613932628};\\\", \\\"{x:1283,y:959,t:1527613932717};\\\", \\\"{x:1283,y:958,t:1527613940797};\\\", \\\"{x:1284,y:951,t:1527613940805};\\\", \\\"{x:1286,y:947,t:1527613940818};\\\", \\\"{x:1286,y:942,t:1527613940836};\\\", \\\"{x:1287,y:937,t:1527613940852};\\\", \\\"{x:1287,y:936,t:1527613940868};\\\", \\\"{x:1287,y:935,t:1527613940958};\\\", \\\"{x:1287,y:933,t:1527613940973};\\\", \\\"{x:1288,y:932,t:1527613940985};\\\", \\\"{x:1288,y:930,t:1527613941003};\\\", \\\"{x:1288,y:926,t:1527613941018};\\\", \\\"{x:1288,y:922,t:1527613941035};\\\", \\\"{x:1288,y:915,t:1527613941053};\\\", \\\"{x:1291,y:909,t:1527613941069};\\\", \\\"{x:1292,y:906,t:1527613941085};\\\", \\\"{x:1292,y:902,t:1527613941102};\\\", \\\"{x:1292,y:901,t:1527613941118};\\\", \\\"{x:1293,y:900,t:1527613941135};\\\", \\\"{x:1294,y:900,t:1527613941152};\\\", \\\"{x:1290,y:902,t:1527613947222};\\\", \\\"{x:1282,y:906,t:1527613947229};\\\", \\\"{x:1276,y:909,t:1527613947241};\\\", \\\"{x:1271,y:911,t:1527613947257};\\\", \\\"{x:1268,y:911,t:1527613947273};\\\", \\\"{x:1265,y:911,t:1527613947291};\\\", \\\"{x:1264,y:911,t:1527613947306};\\\", \\\"{x:1263,y:911,t:1527613947323};\\\", \\\"{x:1262,y:911,t:1527613947340};\\\", \\\"{x:1261,y:911,t:1527613947356};\\\", \\\"{x:1260,y:911,t:1527613947374};\\\", \\\"{x:1259,y:911,t:1527613947397};\\\", \\\"{x:1258,y:911,t:1527613947421};\\\", \\\"{x:1256,y:911,t:1527613947462};\\\", \\\"{x:1255,y:911,t:1527613947473};\\\", \\\"{x:1252,y:911,t:1527613947491};\\\", \\\"{x:1251,y:912,t:1527613947507};\\\", \\\"{x:1248,y:912,t:1527613947525};\\\", \\\"{x:1248,y:913,t:1527613947541};\\\", \\\"{x:1247,y:913,t:1527613947557};\\\", \\\"{x:1244,y:915,t:1527613947573};\\\", \\\"{x:1241,y:916,t:1527613947592};\\\", \\\"{x:1237,y:918,t:1527613947607};\\\", \\\"{x:1232,y:920,t:1527613947623};\\\", \\\"{x:1225,y:923,t:1527613947640};\\\", \\\"{x:1223,y:924,t:1527613947658};\\\", \\\"{x:1221,y:925,t:1527613947674};\\\", \\\"{x:1219,y:925,t:1527613947691};\\\", \\\"{x:1218,y:926,t:1527613947709};\\\", \\\"{x:1201,y:912,t:1527613949477};\\\", \\\"{x:1187,y:896,t:1527613949492};\\\", \\\"{x:1172,y:884,t:1527613949508};\\\", \\\"{x:1170,y:884,t:1527613949781};\\\", \\\"{x:1170,y:883,t:1527613949792};\\\", \\\"{x:1170,y:876,t:1527613949813};\\\", \\\"{x:1171,y:869,t:1527613949826};\\\", \\\"{x:1171,y:849,t:1527613949843};\\\", \\\"{x:1162,y:829,t:1527613949858};\\\", \\\"{x:1143,y:800,t:1527613949875};\\\", \\\"{x:1086,y:735,t:1527613949892};\\\", \\\"{x:1013,y:679,t:1527613949908};\\\", \\\"{x:915,y:626,t:1527613949925};\\\", \\\"{x:788,y:572,t:1527613949942};\\\", \\\"{x:659,y:521,t:1527613949959};\\\", \\\"{x:534,y:476,t:1527613949975};\\\", \\\"{x:433,y:440,t:1527613949992};\\\", \\\"{x:348,y:407,t:1527613950010};\\\", \\\"{x:320,y:388,t:1527613950026};\\\", \\\"{x:315,y:381,t:1527613950042};\\\", \\\"{x:315,y:374,t:1527613950060};\\\", \\\"{x:315,y:371,t:1527613950076};\\\", \\\"{x:315,y:369,t:1527613950093};\\\", \\\"{x:317,y:365,t:1527613950110};\\\", \\\"{x:318,y:363,t:1527613950126};\\\", \\\"{x:319,y:362,t:1527613950143};\\\", \\\"{x:321,y:361,t:1527613950160};\\\", \\\"{x:325,y:360,t:1527613950176};\\\", \\\"{x:344,y:360,t:1527613950193};\\\", \\\"{x:381,y:370,t:1527613950210};\\\", \\\"{x:453,y:399,t:1527613950226};\\\", \\\"{x:518,y:422,t:1527613950243};\\\", \\\"{x:563,y:440,t:1527613950260};\\\", \\\"{x:571,y:445,t:1527613950277};\\\", \\\"{x:574,y:447,t:1527613950293};\\\", \\\"{x:575,y:450,t:1527613950310};\\\", \\\"{x:577,y:454,t:1527613950327};\\\", \\\"{x:581,y:459,t:1527613950343};\\\", \\\"{x:583,y:461,t:1527613950360};\\\", \\\"{x:588,y:465,t:1527613950379};\\\", \\\"{x:595,y:469,t:1527613950393};\\\", \\\"{x:599,y:472,t:1527613950410};\\\", \\\"{x:600,y:472,t:1527613950426};\\\", \\\"{x:601,y:472,t:1527613950452};\\\", \\\"{x:602,y:472,t:1527613950467};\\\", \\\"{x:604,y:475,t:1527613950476};\\\", \\\"{x:608,y:478,t:1527613950493};\\\", \\\"{x:613,y:482,t:1527613950509};\\\", \\\"{x:615,y:484,t:1527613950526};\\\", \\\"{x:617,y:485,t:1527613950544};\\\", \\\"{x:617,y:492,t:1527613950876};\\\", \\\"{x:611,y:529,t:1527613950894};\\\", \\\"{x:608,y:565,t:1527613950910};\\\", \\\"{x:604,y:607,t:1527613950928};\\\", \\\"{x:604,y:640,t:1527613950944};\\\", \\\"{x:598,y:667,t:1527613950960};\\\", \\\"{x:591,y:688,t:1527613950977};\\\", \\\"{x:580,y:707,t:1527613950994};\\\", \\\"{x:572,y:719,t:1527613951011};\\\", \\\"{x:568,y:725,t:1527613951027};\\\", \\\"{x:566,y:729,t:1527613951044};\\\", \\\"{x:565,y:730,t:1527613951061};\\\", \\\"{x:565,y:731,t:1527613951077};\\\", \\\"{x:563,y:728,t:1527613951181};\\\", \\\"{x:562,y:724,t:1527613951194};\\\", \\\"{x:560,y:717,t:1527613951211};\\\", \\\"{x:554,y:709,t:1527613951228};\\\", \\\"{x:553,y:708,t:1527613951244};\\\", \\\"{x:552,y:707,t:1527613951260};\\\", \\\"{x:550,y:707,t:1527613951278};\\\", \\\"{x:549,y:707,t:1527613951293};\\\", \\\"{x:547,y:707,t:1527613951310};\\\", \\\"{x:546,y:707,t:1527613951340};\\\", \\\"{x:546,y:705,t:1527613951757};\\\", \\\"{x:557,y:704,t:1527613951764};\\\", \\\"{x:590,y:703,t:1527613951778};\\\", \\\"{x:684,y:695,t:1527613951795};\\\", \\\"{x:787,y:693,t:1527613951811};\\\", \\\"{x:918,y:681,t:1527613951828};\\\", \\\"{x:1007,y:677,t:1527613951844};\\\", \\\"{x:1088,y:677,t:1527613951861};\\\", \\\"{x:1133,y:677,t:1527613951878};\\\", \\\"{x:1163,y:677,t:1527613951895};\\\", \\\"{x:1180,y:674,t:1527613951910};\\\", \\\"{x:1184,y:674,t:1527613951928};\\\", \\\"{x:1185,y:674,t:1527613951945};\\\", \\\"{x:1186,y:674,t:1527613951961};\\\", \\\"{x:1187,y:673,t:1527613951996};\\\", \\\"{x:1187,y:672,t:1527613952357};\\\", \\\"{x:1187,y:671,t:1527613952373};\\\", \\\"{x:1188,y:671,t:1527613952421};\\\" ] }, { \\\"rt\\\": 55278, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 400675, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"K7JVY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"I\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -J -I \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:1189,y:670,t:1527613958364};\\\", \\\"{x:1200,y:672,t:1527613958372};\\\", \\\"{x:1211,y:676,t:1527613958382};\\\", \\\"{x:1248,y:689,t:1527613958399};\\\", \\\"{x:1313,y:699,t:1527613958416};\\\", \\\"{x:1375,y:709,t:1527613958433};\\\", \\\"{x:1416,y:714,t:1527613958449};\\\", \\\"{x:1445,y:715,t:1527613958466};\\\", \\\"{x:1465,y:715,t:1527613958482};\\\", \\\"{x:1475,y:714,t:1527613958499};\\\", \\\"{x:1484,y:709,t:1527613958516};\\\", \\\"{x:1492,y:704,t:1527613958533};\\\", \\\"{x:1503,y:697,t:1527613958549};\\\", \\\"{x:1513,y:690,t:1527613958566};\\\", \\\"{x:1516,y:688,t:1527613958583};\\\", \\\"{x:1517,y:687,t:1527613958600};\\\", \\\"{x:1518,y:687,t:1527613958616};\\\", \\\"{x:1518,y:686,t:1527613958836};\\\", \\\"{x:1517,y:686,t:1527613958876};\\\", \\\"{x:1515,y:686,t:1527613958884};\\\", \\\"{x:1514,y:686,t:1527613958899};\\\", \\\"{x:1511,y:689,t:1527613958916};\\\", \\\"{x:1509,y:691,t:1527613958934};\\\", \\\"{x:1506,y:688,t:1527613959061};\\\", \\\"{x:1506,y:687,t:1527613959069};\\\", \\\"{x:1506,y:685,t:1527613959084};\\\", \\\"{x:1503,y:675,t:1527613959101};\\\", \\\"{x:1503,y:667,t:1527613959116};\\\", \\\"{x:1502,y:665,t:1527613959134};\\\", \\\"{x:1502,y:664,t:1527613959151};\\\", \\\"{x:1501,y:664,t:1527613959758};\\\", \\\"{x:1501,y:663,t:1527613959789};\\\", \\\"{x:1500,y:662,t:1527613959933};\\\", \\\"{x:1498,y:662,t:1527613959941};\\\", \\\"{x:1497,y:662,t:1527613959951};\\\", \\\"{x:1494,y:663,t:1527613959968};\\\", \\\"{x:1492,y:664,t:1527613959985};\\\", \\\"{x:1488,y:666,t:1527613960001};\\\", \\\"{x:1486,y:667,t:1527613960018};\\\", \\\"{x:1484,y:668,t:1527613960035};\\\", \\\"{x:1481,y:672,t:1527613960052};\\\", \\\"{x:1476,y:675,t:1527613960068};\\\", \\\"{x:1468,y:680,t:1527613960084};\\\", \\\"{x:1463,y:683,t:1527613960100};\\\", \\\"{x:1461,y:685,t:1527613960117};\\\", \\\"{x:1458,y:687,t:1527613960134};\\\", \\\"{x:1456,y:689,t:1527613960150};\\\", \\\"{x:1455,y:690,t:1527613960167};\\\", \\\"{x:1453,y:692,t:1527613960185};\\\", \\\"{x:1450,y:696,t:1527613960201};\\\", \\\"{x:1447,y:700,t:1527613960218};\\\", \\\"{x:1446,y:703,t:1527613960235};\\\", \\\"{x:1444,y:708,t:1527613960251};\\\", \\\"{x:1442,y:711,t:1527613960268};\\\", \\\"{x:1439,y:715,t:1527613960285};\\\", \\\"{x:1437,y:718,t:1527613960301};\\\", \\\"{x:1436,y:719,t:1527613960318};\\\", \\\"{x:1435,y:722,t:1527613960335};\\\", \\\"{x:1434,y:723,t:1527613960351};\\\", \\\"{x:1432,y:725,t:1527613960368};\\\", \\\"{x:1432,y:727,t:1527613960385};\\\", \\\"{x:1430,y:730,t:1527613960402};\\\", \\\"{x:1427,y:734,t:1527613960418};\\\", \\\"{x:1425,y:737,t:1527613960434};\\\", \\\"{x:1421,y:741,t:1527613960452};\\\", \\\"{x:1417,y:746,t:1527613960468};\\\", \\\"{x:1408,y:753,t:1527613960485};\\\", \\\"{x:1402,y:757,t:1527613960501};\\\", \\\"{x:1397,y:760,t:1527613960518};\\\", \\\"{x:1385,y:765,t:1527613960535};\\\", \\\"{x:1379,y:768,t:1527613960552};\\\", \\\"{x:1365,y:773,t:1527613960568};\\\", \\\"{x:1353,y:778,t:1527613960585};\\\", \\\"{x:1339,y:786,t:1527613960601};\\\", \\\"{x:1324,y:790,t:1527613960618};\\\", \\\"{x:1311,y:794,t:1527613960635};\\\", \\\"{x:1305,y:795,t:1527613960652};\\\", \\\"{x:1297,y:797,t:1527613960668};\\\", \\\"{x:1281,y:802,t:1527613960685};\\\", \\\"{x:1261,y:808,t:1527613960702};\\\", \\\"{x:1235,y:811,t:1527613960718};\\\", \\\"{x:1228,y:815,t:1527613960735};\\\", \\\"{x:1228,y:817,t:1527613960752};\\\", \\\"{x:1223,y:819,t:1527613960768};\\\", \\\"{x:1218,y:819,t:1527613960785};\\\", \\\"{x:1214,y:819,t:1527613960802};\\\", \\\"{x:1213,y:819,t:1527613960818};\\\", \\\"{x:1213,y:818,t:1527613960933};\\\", \\\"{x:1213,y:817,t:1527613960941};\\\", \\\"{x:1213,y:816,t:1527613960952};\\\", \\\"{x:1214,y:815,t:1527613960969};\\\", \\\"{x:1214,y:814,t:1527613960989};\\\", \\\"{x:1214,y:807,t:1527613981000};\\\", \\\"{x:1214,y:792,t:1527613981020};\\\", \\\"{x:1213,y:783,t:1527613981037};\\\", \\\"{x:1213,y:777,t:1527613981053};\\\", \\\"{x:1211,y:769,t:1527613981070};\\\", \\\"{x:1208,y:764,t:1527613981087};\\\", \\\"{x:1208,y:761,t:1527613981103};\\\", \\\"{x:1208,y:759,t:1527613981120};\\\", \\\"{x:1207,y:757,t:1527613981265};\\\", \\\"{x:1206,y:757,t:1527613981288};\\\", \\\"{x:1205,y:756,t:1527613981312};\\\", \\\"{x:1204,y:756,t:1527613981336};\\\", \\\"{x:1204,y:755,t:1527613981344};\\\", \\\"{x:1203,y:754,t:1527613981360};\\\", \\\"{x:1203,y:753,t:1527613981376};\\\", \\\"{x:1202,y:753,t:1527613981392};\\\", \\\"{x:1201,y:753,t:1527613981416};\\\", \\\"{x:1199,y:752,t:1527613981425};\\\", \\\"{x:1199,y:751,t:1527613981456};\\\", \\\"{x:1197,y:751,t:1527613981470};\\\", \\\"{x:1196,y:750,t:1527613981487};\\\", \\\"{x:1194,y:750,t:1527613981560};\\\", \\\"{x:1194,y:749,t:1527613981576};\\\", \\\"{x:1193,y:749,t:1527613981588};\\\", \\\"{x:1191,y:749,t:1527613981604};\\\", \\\"{x:1191,y:748,t:1527613981623};\\\", \\\"{x:1190,y:748,t:1527613981637};\\\", \\\"{x:1188,y:748,t:1527613981656};\\\", \\\"{x:1187,y:747,t:1527613981672};\\\", \\\"{x:1179,y:745,t:1527614004033};\\\", \\\"{x:1124,y:730,t:1527614004055};\\\", \\\"{x:1049,y:710,t:1527614004071};\\\", \\\"{x:963,y:684,t:1527614004088};\\\", \\\"{x:901,y:664,t:1527614004104};\\\", \\\"{x:851,y:648,t:1527614004120};\\\", \\\"{x:807,y:630,t:1527614004138};\\\", \\\"{x:771,y:614,t:1527614004154};\\\", \\\"{x:741,y:603,t:1527614004171};\\\", \\\"{x:714,y:596,t:1527614004187};\\\", \\\"{x:697,y:592,t:1527614004203};\\\", \\\"{x:683,y:589,t:1527614004221};\\\", \\\"{x:673,y:589,t:1527614004238};\\\", \\\"{x:668,y:589,t:1527614004254};\\\", \\\"{x:664,y:589,t:1527614004271};\\\", \\\"{x:662,y:589,t:1527614004288};\\\", \\\"{x:660,y:589,t:1527614004304};\\\", \\\"{x:659,y:589,t:1527614004320};\\\", \\\"{x:655,y:589,t:1527614004338};\\\", \\\"{x:644,y:589,t:1527614004354};\\\", \\\"{x:634,y:588,t:1527614004372};\\\", \\\"{x:620,y:586,t:1527614004388};\\\", \\\"{x:601,y:583,t:1527614004408};\\\", \\\"{x:597,y:581,t:1527614004426};\\\", \\\"{x:592,y:580,t:1527614004442};\\\", \\\"{x:590,y:579,t:1527614004535};\\\", \\\"{x:590,y:577,t:1527614004583};\\\", \\\"{x:590,y:576,t:1527614004599};\\\", \\\"{x:590,y:575,t:1527614004608};\\\", \\\"{x:590,y:574,t:1527614004625};\\\", \\\"{x:591,y:571,t:1527614004641};\\\", \\\"{x:592,y:569,t:1527614004658};\\\", \\\"{x:593,y:567,t:1527614004675};\\\", \\\"{x:593,y:565,t:1527614004691};\\\", \\\"{x:594,y:563,t:1527614004708};\\\", \\\"{x:595,y:559,t:1527614004725};\\\", \\\"{x:597,y:556,t:1527614004742};\\\", \\\"{x:598,y:551,t:1527614004758};\\\", \\\"{x:599,y:549,t:1527614004775};\\\", \\\"{x:600,y:546,t:1527614004792};\\\", \\\"{x:601,y:544,t:1527614004809};\\\", \\\"{x:601,y:543,t:1527614004825};\\\", \\\"{x:601,y:541,t:1527614004842};\\\", \\\"{x:602,y:541,t:1527614004859};\\\", \\\"{x:602,y:540,t:1527614004875};\\\", \\\"{x:603,y:538,t:1527614004892};\\\", \\\"{x:603,y:537,t:1527614004911};\\\", \\\"{x:603,y:535,t:1527614004925};\\\", \\\"{x:603,y:534,t:1527614004942};\\\", \\\"{x:604,y:531,t:1527614004959};\\\", \\\"{x:605,y:527,t:1527614004976};\\\", \\\"{x:606,y:523,t:1527614004992};\\\", \\\"{x:606,y:521,t:1527614005009};\\\", \\\"{x:606,y:518,t:1527614005025};\\\", \\\"{x:607,y:516,t:1527614005042};\\\", \\\"{x:607,y:514,t:1527614005059};\\\", \\\"{x:607,y:513,t:1527614005075};\\\", \\\"{x:608,y:510,t:1527614005092};\\\", \\\"{x:608,y:509,t:1527614005109};\\\", \\\"{x:608,y:507,t:1527614005126};\\\", \\\"{x:608,y:506,t:1527614005144};\\\", \\\"{x:608,y:505,t:1527614005160};\\\", \\\"{x:608,y:504,t:1527614005175};\\\", \\\"{x:608,y:502,t:1527614005193};\\\", \\\"{x:608,y:501,t:1527614005209};\\\", \\\"{x:608,y:498,t:1527614005225};\\\", \\\"{x:608,y:494,t:1527614005242};\\\", \\\"{x:608,y:490,t:1527614005259};\\\", \\\"{x:608,y:485,t:1527614005276};\\\", \\\"{x:608,y:481,t:1527614005292};\\\", \\\"{x:607,y:476,t:1527614005309};\\\", \\\"{x:606,y:472,t:1527614005325};\\\", \\\"{x:606,y:468,t:1527614005342};\\\", \\\"{x:605,y:466,t:1527614005359};\\\", \\\"{x:605,y:465,t:1527614005376};\\\", \\\"{x:604,y:464,t:1527614005522};\\\", \\\"{x:600,y:464,t:1527614005542};\\\", \\\"{x:588,y:464,t:1527614005559};\\\", \\\"{x:576,y:464,t:1527614005576};\\\", \\\"{x:570,y:464,t:1527614005592};\\\", \\\"{x:564,y:464,t:1527614005609};\\\", \\\"{x:563,y:464,t:1527614005626};\\\", \\\"{x:561,y:464,t:1527614005642};\\\", \\\"{x:560,y:464,t:1527614005680};\\\", \\\"{x:558,y:464,t:1527614005695};\\\", \\\"{x:556,y:464,t:1527614005712};\\\", \\\"{x:554,y:464,t:1527614005726};\\\", \\\"{x:546,y:464,t:1527614005742};\\\", \\\"{x:530,y:468,t:1527614005760};\\\", \\\"{x:517,y:472,t:1527614005775};\\\", \\\"{x:508,y:473,t:1527614005793};\\\", \\\"{x:504,y:473,t:1527614005809};\\\", \\\"{x:499,y:475,t:1527614005826};\\\", \\\"{x:494,y:476,t:1527614005844};\\\", \\\"{x:488,y:478,t:1527614005859};\\\", \\\"{x:482,y:479,t:1527614005876};\\\", \\\"{x:472,y:481,t:1527614005893};\\\", \\\"{x:460,y:484,t:1527614005908};\\\", \\\"{x:442,y:489,t:1527614005926};\\\", \\\"{x:426,y:490,t:1527614005943};\\\", \\\"{x:415,y:492,t:1527614005959};\\\", \\\"{x:404,y:494,t:1527614005976};\\\", \\\"{x:397,y:495,t:1527614005993};\\\", \\\"{x:390,y:496,t:1527614006009};\\\", \\\"{x:381,y:499,t:1527614006026};\\\", \\\"{x:372,y:500,t:1527614006042};\\\", \\\"{x:364,y:501,t:1527614006060};\\\", \\\"{x:356,y:503,t:1527614006077};\\\", \\\"{x:347,y:505,t:1527614006093};\\\", \\\"{x:340,y:506,t:1527614006110};\\\", \\\"{x:330,y:507,t:1527614006126};\\\", \\\"{x:305,y:511,t:1527614006143};\\\", \\\"{x:289,y:514,t:1527614006159};\\\", \\\"{x:278,y:514,t:1527614006176};\\\", \\\"{x:263,y:515,t:1527614006194};\\\", \\\"{x:248,y:515,t:1527614006210};\\\", \\\"{x:235,y:518,t:1527614006226};\\\", \\\"{x:225,y:519,t:1527614006243};\\\", \\\"{x:217,y:520,t:1527614006260};\\\", \\\"{x:212,y:522,t:1527614006276};\\\", \\\"{x:210,y:523,t:1527614006293};\\\", \\\"{x:209,y:523,t:1527614006310};\\\", \\\"{x:207,y:524,t:1527614006345};\\\", \\\"{x:206,y:524,t:1527614006360};\\\", \\\"{x:205,y:525,t:1527614006376};\\\", \\\"{x:202,y:526,t:1527614006394};\\\", \\\"{x:200,y:526,t:1527614006410};\\\", \\\"{x:199,y:526,t:1527614006426};\\\", \\\"{x:197,y:526,t:1527614006443};\\\", \\\"{x:196,y:526,t:1527614006461};\\\", \\\"{x:193,y:522,t:1527614006477};\\\", \\\"{x:189,y:517,t:1527614006495};\\\", \\\"{x:186,y:513,t:1527614006510};\\\", \\\"{x:183,y:507,t:1527614006527};\\\", \\\"{x:180,y:502,t:1527614006543};\\\", \\\"{x:179,y:500,t:1527614006560};\\\", \\\"{x:178,y:497,t:1527614006576};\\\", \\\"{x:177,y:496,t:1527614006593};\\\", \\\"{x:177,y:493,t:1527614006611};\\\", \\\"{x:177,y:491,t:1527614006631};\\\", \\\"{x:177,y:490,t:1527614006643};\\\", \\\"{x:176,y:488,t:1527614006660};\\\", \\\"{x:176,y:487,t:1527614006677};\\\", \\\"{x:176,y:485,t:1527614006692};\\\", \\\"{x:176,y:484,t:1527614006710};\\\", \\\"{x:176,y:483,t:1527614007168};\\\", \\\"{x:180,y:484,t:1527614007177};\\\", \\\"{x:197,y:496,t:1527614007194};\\\", \\\"{x:221,y:513,t:1527614007211};\\\", \\\"{x:251,y:538,t:1527614007227};\\\", \\\"{x:297,y:574,t:1527614007244};\\\", \\\"{x:347,y:608,t:1527614007261};\\\", \\\"{x:377,y:630,t:1527614007278};\\\", \\\"{x:401,y:648,t:1527614007295};\\\", \\\"{x:428,y:669,t:1527614007310};\\\", \\\"{x:452,y:690,t:1527614007327};\\\", \\\"{x:463,y:700,t:1527614007346};\\\", \\\"{x:465,y:702,t:1527614007360};\\\", \\\"{x:465,y:703,t:1527614007391};\\\" ] }, { \\\"rt\\\": 44602, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 446525, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"K7JVY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-12 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:468,y:701,t:1527614017576};\\\", \\\"{x:504,y:695,t:1527614017588};\\\", \\\"{x:643,y:695,t:1527614017608};\\\", \\\"{x:734,y:692,t:1527614017620};\\\", \\\"{x:884,y:688,t:1527614017635};\\\", \\\"{x:1067,y:688,t:1527614017652};\\\", \\\"{x:1237,y:694,t:1527614017669};\\\", \\\"{x:1491,y:699,t:1527614017686};\\\", \\\"{x:1583,y:695,t:1527614017702};\\\", \\\"{x:1593,y:696,t:1527614017719};\\\", \\\"{x:1604,y:700,t:1527614017736};\\\", \\\"{x:1614,y:709,t:1527614017753};\\\", \\\"{x:1616,y:708,t:1527614017769};\\\", \\\"{x:1614,y:709,t:1527614017785};\\\", \\\"{x:1613,y:709,t:1527614017802};\\\", \\\"{x:1549,y:709,t:1527614017819};\\\", \\\"{x:1466,y:704,t:1527614017836};\\\", \\\"{x:1309,y:704,t:1527614017853};\\\", \\\"{x:1135,y:686,t:1527614017870};\\\", \\\"{x:994,y:663,t:1527614017886};\\\", \\\"{x:847,y:643,t:1527614017903};\\\", \\\"{x:696,y:622,t:1527614017919};\\\", \\\"{x:658,y:610,t:1527614017936};\\\", \\\"{x:656,y:609,t:1527614017954};\\\", \\\"{x:656,y:608,t:1527614017975};\\\", \\\"{x:658,y:606,t:1527614017985};\\\", \\\"{x:670,y:604,t:1527614018003};\\\", \\\"{x:680,y:601,t:1527614018020};\\\", \\\"{x:700,y:596,t:1527614018036};\\\", \\\"{x:724,y:589,t:1527614018053};\\\", \\\"{x:752,y:584,t:1527614018070};\\\", \\\"{x:779,y:578,t:1527614018087};\\\", \\\"{x:804,y:573,t:1527614018103};\\\", \\\"{x:859,y:572,t:1527614018119};\\\", \\\"{x:912,y:572,t:1527614018136};\\\", \\\"{x:969,y:574,t:1527614018152};\\\", \\\"{x:1027,y:580,t:1527614018169};\\\", \\\"{x:1108,y:591,t:1527614018186};\\\", \\\"{x:1169,y:601,t:1527614018203};\\\", \\\"{x:1207,y:614,t:1527614018220};\\\", \\\"{x:1239,y:627,t:1527614018237};\\\", \\\"{x:1284,y:640,t:1527614018253};\\\", \\\"{x:1319,y:652,t:1527614018270};\\\", \\\"{x:1353,y:667,t:1527614018287};\\\", \\\"{x:1385,y:683,t:1527614018302};\\\", \\\"{x:1434,y:704,t:1527614018319};\\\", \\\"{x:1455,y:713,t:1527614018337};\\\", \\\"{x:1469,y:717,t:1527614018353};\\\", \\\"{x:1474,y:719,t:1527614018370};\\\", \\\"{x:1477,y:722,t:1527614018387};\\\", \\\"{x:1479,y:725,t:1527614018403};\\\", \\\"{x:1480,y:729,t:1527614018420};\\\", \\\"{x:1481,y:732,t:1527614018437};\\\", \\\"{x:1481,y:736,t:1527614018453};\\\", \\\"{x:1482,y:744,t:1527614018470};\\\", \\\"{x:1482,y:753,t:1527614018487};\\\", \\\"{x:1482,y:773,t:1527614018504};\\\", \\\"{x:1480,y:788,t:1527614018520};\\\", \\\"{x:1477,y:803,t:1527614018537};\\\", \\\"{x:1471,y:818,t:1527614018554};\\\", \\\"{x:1467,y:838,t:1527614018570};\\\", \\\"{x:1463,y:855,t:1527614018588};\\\", \\\"{x:1456,y:873,t:1527614018604};\\\", \\\"{x:1446,y:897,t:1527614018620};\\\", \\\"{x:1433,y:936,t:1527614018638};\\\", \\\"{x:1420,y:979,t:1527614018654};\\\", \\\"{x:1410,y:1009,t:1527614018670};\\\", \\\"{x:1403,y:1031,t:1527614018687};\\\", \\\"{x:1398,y:1049,t:1527614018704};\\\", \\\"{x:1395,y:1055,t:1527614018719};\\\", \\\"{x:1394,y:1056,t:1527614018737};\\\", \\\"{x:1394,y:1057,t:1527614018767};\\\", \\\"{x:1393,y:1057,t:1527614018775};\\\", \\\"{x:1389,y:1057,t:1527614018787};\\\", \\\"{x:1383,y:1050,t:1527614018804};\\\", \\\"{x:1376,y:1038,t:1527614018821};\\\", \\\"{x:1373,y:1024,t:1527614018838};\\\", \\\"{x:1368,y:1005,t:1527614018854};\\\", \\\"{x:1363,y:988,t:1527614018871};\\\", \\\"{x:1359,y:975,t:1527614018887};\\\", \\\"{x:1358,y:955,t:1527614018904};\\\", \\\"{x:1358,y:947,t:1527614018920};\\\", \\\"{x:1358,y:943,t:1527614018937};\\\", \\\"{x:1357,y:941,t:1527614018954};\\\", \\\"{x:1357,y:940,t:1527614019048};\\\", \\\"{x:1356,y:940,t:1527614019352};\\\", \\\"{x:1355,y:940,t:1527614019392};\\\", \\\"{x:1354,y:940,t:1527614019408};\\\", \\\"{x:1353,y:940,t:1527614019422};\\\", \\\"{x:1350,y:936,t:1527614019438};\\\", \\\"{x:1348,y:930,t:1527614019454};\\\", \\\"{x:1348,y:917,t:1527614019472};\\\", \\\"{x:1348,y:905,t:1527614019488};\\\", \\\"{x:1348,y:893,t:1527614019505};\\\", \\\"{x:1348,y:878,t:1527614019521};\\\", \\\"{x:1350,y:861,t:1527614019538};\\\", \\\"{x:1353,y:846,t:1527614019554};\\\", \\\"{x:1353,y:833,t:1527614019571};\\\", \\\"{x:1354,y:823,t:1527614019588};\\\", \\\"{x:1355,y:816,t:1527614019605};\\\", \\\"{x:1355,y:808,t:1527614019621};\\\", \\\"{x:1355,y:802,t:1527614019638};\\\", \\\"{x:1355,y:794,t:1527614019654};\\\", \\\"{x:1356,y:790,t:1527614019670};\\\", \\\"{x:1356,y:781,t:1527614019688};\\\", \\\"{x:1358,y:769,t:1527614019705};\\\", \\\"{x:1358,y:757,t:1527614019720};\\\", \\\"{x:1358,y:750,t:1527614019737};\\\", \\\"{x:1358,y:744,t:1527614019754};\\\", \\\"{x:1358,y:738,t:1527614019771};\\\", \\\"{x:1358,y:730,t:1527614019787};\\\", \\\"{x:1358,y:720,t:1527614019805};\\\", \\\"{x:1358,y:713,t:1527614019821};\\\", \\\"{x:1358,y:706,t:1527614019837};\\\", \\\"{x:1358,y:697,t:1527614019855};\\\", \\\"{x:1358,y:688,t:1527614019871};\\\", \\\"{x:1358,y:682,t:1527614019888};\\\", \\\"{x:1358,y:677,t:1527614019905};\\\", \\\"{x:1358,y:674,t:1527614019922};\\\", \\\"{x:1358,y:671,t:1527614019938};\\\", \\\"{x:1358,y:669,t:1527614019954};\\\", \\\"{x:1357,y:667,t:1527614019972};\\\", \\\"{x:1357,y:665,t:1527614019987};\\\", \\\"{x:1356,y:664,t:1527614020005};\\\", \\\"{x:1355,y:664,t:1527614020022};\\\", \\\"{x:1355,y:663,t:1527614020088};\\\", \\\"{x:1354,y:663,t:1527614020112};\\\", \\\"{x:1354,y:662,t:1527614020128};\\\", \\\"{x:1353,y:661,t:1527614022272};\\\", \\\"{x:1351,y:661,t:1527614025624};\\\", \\\"{x:1342,y:666,t:1527614025631};\\\", \\\"{x:1323,y:675,t:1527614025644};\\\", \\\"{x:1301,y:685,t:1527614025660};\\\", \\\"{x:1280,y:698,t:1527614025677};\\\", \\\"{x:1256,y:708,t:1527614025695};\\\", \\\"{x:1230,y:715,t:1527614025711};\\\", \\\"{x:1191,y:729,t:1527614025728};\\\", \\\"{x:1145,y:738,t:1527614025743};\\\", \\\"{x:1087,y:746,t:1527614025761};\\\", \\\"{x:1000,y:759,t:1527614025777};\\\", \\\"{x:905,y:763,t:1527614025795};\\\", \\\"{x:805,y:763,t:1527614025810};\\\", \\\"{x:706,y:763,t:1527614025827};\\\", \\\"{x:628,y:763,t:1527614025844};\\\", \\\"{x:575,y:763,t:1527614025860};\\\", \\\"{x:546,y:763,t:1527614025877};\\\", \\\"{x:514,y:762,t:1527614025894};\\\", \\\"{x:487,y:761,t:1527614025910};\\\", \\\"{x:439,y:757,t:1527614025927};\\\", \\\"{x:417,y:757,t:1527614025944};\\\", \\\"{x:392,y:756,t:1527614025960};\\\", \\\"{x:368,y:755,t:1527614025977};\\\", \\\"{x:345,y:753,t:1527614025994};\\\", \\\"{x:325,y:753,t:1527614026011};\\\", \\\"{x:312,y:751,t:1527614026027};\\\", \\\"{x:307,y:750,t:1527614026044};\\\", \\\"{x:306,y:749,t:1527614026061};\\\", \\\"{x:305,y:747,t:1527614026077};\\\", \\\"{x:304,y:744,t:1527614026095};\\\", \\\"{x:304,y:731,t:1527614026111};\\\", \\\"{x:304,y:717,t:1527614026127};\\\", \\\"{x:305,y:701,t:1527614026145};\\\", \\\"{x:308,y:685,t:1527614026161};\\\", \\\"{x:311,y:666,t:1527614026178};\\\", \\\"{x:317,y:647,t:1527614026195};\\\", \\\"{x:320,y:633,t:1527614026211};\\\", \\\"{x:324,y:622,t:1527614026226};\\\", \\\"{x:327,y:607,t:1527614026243};\\\", \\\"{x:331,y:589,t:1527614026259};\\\", \\\"{x:335,y:577,t:1527614026277};\\\", \\\"{x:339,y:568,t:1527614026293};\\\", \\\"{x:341,y:562,t:1527614026310};\\\", \\\"{x:343,y:557,t:1527614026326};\\\", \\\"{x:347,y:549,t:1527614026342};\\\", \\\"{x:348,y:544,t:1527614026359};\\\", \\\"{x:350,y:541,t:1527614026376};\\\", \\\"{x:353,y:536,t:1527614026393};\\\", \\\"{x:355,y:532,t:1527614026410};\\\", \\\"{x:359,y:529,t:1527614026425};\\\", \\\"{x:365,y:524,t:1527614026442};\\\", \\\"{x:375,y:519,t:1527614026460};\\\", \\\"{x:391,y:510,t:1527614026477};\\\", \\\"{x:404,y:504,t:1527614026493};\\\", \\\"{x:422,y:495,t:1527614026511};\\\", \\\"{x:442,y:489,t:1527614026526};\\\", \\\"{x:470,y:488,t:1527614026543};\\\", \\\"{x:488,y:487,t:1527614026560};\\\", \\\"{x:505,y:484,t:1527614026577};\\\", \\\"{x:523,y:484,t:1527614026592};\\\", \\\"{x:542,y:483,t:1527614026610};\\\", \\\"{x:547,y:483,t:1527614026626};\\\", \\\"{x:549,y:483,t:1527614026643};\\\", \\\"{x:550,y:483,t:1527614026660};\\\", \\\"{x:551,y:483,t:1527614026687};\\\", \\\"{x:550,y:483,t:1527614026767};\\\", \\\"{x:545,y:483,t:1527614026777};\\\", \\\"{x:533,y:489,t:1527614026793};\\\", \\\"{x:528,y:493,t:1527614026811};\\\", \\\"{x:521,y:497,t:1527614026828};\\\", \\\"{x:519,y:498,t:1527614026842};\\\", \\\"{x:514,y:502,t:1527614026859};\\\", \\\"{x:512,y:503,t:1527614026877};\\\", \\\"{x:506,y:507,t:1527614026892};\\\", \\\"{x:500,y:510,t:1527614026910};\\\", \\\"{x:491,y:515,t:1527614026927};\\\", \\\"{x:484,y:517,t:1527614026943};\\\", \\\"{x:472,y:522,t:1527614026960};\\\", \\\"{x:464,y:524,t:1527614026977};\\\", \\\"{x:451,y:527,t:1527614026993};\\\", \\\"{x:433,y:530,t:1527614027010};\\\", \\\"{x:412,y:534,t:1527614027027};\\\", \\\"{x:386,y:538,t:1527614027043};\\\", \\\"{x:364,y:540,t:1527614027060};\\\", \\\"{x:342,y:544,t:1527614027077};\\\", \\\"{x:324,y:546,t:1527614027093};\\\", \\\"{x:310,y:549,t:1527614027109};\\\", \\\"{x:293,y:555,t:1527614027127};\\\", \\\"{x:288,y:556,t:1527614027143};\\\", \\\"{x:281,y:560,t:1527614027159};\\\", \\\"{x:275,y:562,t:1527614027176};\\\", \\\"{x:271,y:563,t:1527614027193};\\\", \\\"{x:264,y:566,t:1527614027210};\\\", \\\"{x:259,y:568,t:1527614027227};\\\", \\\"{x:251,y:571,t:1527614027243};\\\", \\\"{x:245,y:573,t:1527614027260};\\\", \\\"{x:234,y:575,t:1527614027277};\\\", \\\"{x:222,y:577,t:1527614027294};\\\", \\\"{x:210,y:578,t:1527614027310};\\\", \\\"{x:196,y:580,t:1527614027327};\\\", \\\"{x:189,y:581,t:1527614027344};\\\", \\\"{x:183,y:581,t:1527614027360};\\\", \\\"{x:179,y:581,t:1527614027377};\\\", \\\"{x:176,y:581,t:1527614027394};\\\", \\\"{x:172,y:581,t:1527614027410};\\\", \\\"{x:171,y:581,t:1527614027427};\\\", \\\"{x:170,y:581,t:1527614027444};\\\", \\\"{x:169,y:581,t:1527614027487};\\\", \\\"{x:172,y:581,t:1527614027552};\\\", \\\"{x:176,y:581,t:1527614027560};\\\", \\\"{x:186,y:581,t:1527614027577};\\\", \\\"{x:188,y:581,t:1527614027594};\\\", \\\"{x:196,y:581,t:1527614027610};\\\", \\\"{x:209,y:586,t:1527614027628};\\\", \\\"{x:228,y:590,t:1527614027645};\\\", \\\"{x:257,y:593,t:1527614027660};\\\", \\\"{x:275,y:593,t:1527614027679};\\\", \\\"{x:306,y:593,t:1527614027693};\\\", \\\"{x:360,y:580,t:1527614027710};\\\", \\\"{x:384,y:568,t:1527614027727};\\\", \\\"{x:418,y:552,t:1527614027748};\\\", \\\"{x:445,y:537,t:1527614027764};\\\", \\\"{x:462,y:526,t:1527614027781};\\\", \\\"{x:473,y:517,t:1527614027797};\\\", \\\"{x:482,y:510,t:1527614027815};\\\", \\\"{x:490,y:504,t:1527614027830};\\\", \\\"{x:498,y:499,t:1527614027848};\\\", \\\"{x:510,y:494,t:1527614027865};\\\", \\\"{x:526,y:488,t:1527614027881};\\\", \\\"{x:552,y:482,t:1527614027897};\\\", \\\"{x:623,y:466,t:1527614027914};\\\", \\\"{x:704,y:456,t:1527614027931};\\\", \\\"{x:783,y:448,t:1527614027948};\\\", \\\"{x:842,y:440,t:1527614027965};\\\", \\\"{x:879,y:440,t:1527614027980};\\\", \\\"{x:897,y:440,t:1527614027998};\\\", \\\"{x:908,y:440,t:1527614028014};\\\", \\\"{x:912,y:440,t:1527614028032};\\\", \\\"{x:918,y:440,t:1527614028048};\\\", \\\"{x:921,y:441,t:1527614028065};\\\", \\\"{x:921,y:442,t:1527614028081};\\\", \\\"{x:924,y:445,t:1527614028098};\\\", \\\"{x:924,y:456,t:1527614028115};\\\", \\\"{x:918,y:466,t:1527614028132};\\\", \\\"{x:907,y:477,t:1527614028148};\\\", \\\"{x:890,y:485,t:1527614028164};\\\", \\\"{x:872,y:493,t:1527614028181};\\\", \\\"{x:849,y:504,t:1527614028198};\\\", \\\"{x:822,y:507,t:1527614028214};\\\", \\\"{x:795,y:511,t:1527614028231};\\\", \\\"{x:773,y:512,t:1527614028248};\\\", \\\"{x:759,y:512,t:1527614028264};\\\", \\\"{x:749,y:512,t:1527614028282};\\\", \\\"{x:743,y:512,t:1527614028297};\\\", \\\"{x:738,y:512,t:1527614028315};\\\", \\\"{x:732,y:512,t:1527614028331};\\\", \\\"{x:723,y:512,t:1527614028348};\\\", \\\"{x:706,y:512,t:1527614028364};\\\", \\\"{x:686,y:512,t:1527614028381};\\\", \\\"{x:670,y:512,t:1527614028398};\\\", \\\"{x:648,y:512,t:1527614028415};\\\", \\\"{x:633,y:512,t:1527614028432};\\\", \\\"{x:619,y:515,t:1527614028449};\\\", \\\"{x:610,y:516,t:1527614028464};\\\", \\\"{x:600,y:517,t:1527614028481};\\\", \\\"{x:586,y:520,t:1527614028498};\\\", \\\"{x:577,y:522,t:1527614028514};\\\", \\\"{x:569,y:524,t:1527614028532};\\\", \\\"{x:557,y:526,t:1527614028548};\\\", \\\"{x:548,y:527,t:1527614028564};\\\", \\\"{x:543,y:529,t:1527614028581};\\\", \\\"{x:535,y:531,t:1527614028599};\\\", \\\"{x:531,y:533,t:1527614028614};\\\", \\\"{x:530,y:534,t:1527614028632};\\\", \\\"{x:529,y:536,t:1527614028648};\\\", \\\"{x:529,y:538,t:1527614028682};\\\", \\\"{x:529,y:542,t:1527614028700};\\\", \\\"{x:531,y:545,t:1527614028715};\\\", \\\"{x:532,y:546,t:1527614028738};\\\", \\\"{x:532,y:547,t:1527614028748};\\\", \\\"{x:533,y:547,t:1527614028765};\\\", \\\"{x:534,y:547,t:1527614028786};\\\", \\\"{x:535,y:547,t:1527614028799};\\\", \\\"{x:538,y:547,t:1527614028814};\\\", \\\"{x:543,y:547,t:1527614028831};\\\", \\\"{x:546,y:548,t:1527614028849};\\\", \\\"{x:547,y:549,t:1527614028864};\\\", \\\"{x:548,y:551,t:1527614028881};\\\", \\\"{x:552,y:552,t:1527614028898};\\\", \\\"{x:554,y:553,t:1527614028916};\\\", \\\"{x:555,y:554,t:1527614028932};\\\", \\\"{x:556,y:554,t:1527614028954};\\\", \\\"{x:557,y:554,t:1527614028979};\\\", \\\"{x:559,y:555,t:1527614028987};\\\", \\\"{x:561,y:556,t:1527614028998};\\\", \\\"{x:566,y:559,t:1527614029016};\\\", \\\"{x:569,y:561,t:1527614029031};\\\", \\\"{x:573,y:562,t:1527614029048};\\\", \\\"{x:577,y:563,t:1527614029065};\\\", \\\"{x:580,y:563,t:1527614029081};\\\", \\\"{x:585,y:563,t:1527614029099};\\\", \\\"{x:586,y:563,t:1527614029171};\\\", \\\"{x:587,y:563,t:1527614029211};\\\", \\\"{x:588,y:563,t:1527614029243};\\\", \\\"{x:591,y:563,t:1527614029571};\\\", \\\"{x:592,y:563,t:1527614029610};\\\", \\\"{x:593,y:563,t:1527614029627};\\\", \\\"{x:594,y:563,t:1527614029683};\\\", \\\"{x:595,y:563,t:1527614029699};\\\", \\\"{x:596,y:563,t:1527614029747};\\\", \\\"{x:597,y:563,t:1527614029868};\\\", \\\"{x:598,y:563,t:1527614029891};\\\", \\\"{x:597,y:563,t:1527614050811};\\\", \\\"{x:588,y:566,t:1527614050819};\\\", \\\"{x:565,y:566,t:1527614050834};\\\", \\\"{x:432,y:566,t:1527614050852};\\\", \\\"{x:324,y:566,t:1527614050867};\\\", \\\"{x:196,y:563,t:1527614050885};\\\", \\\"{x:75,y:555,t:1527614050900};\\\", \\\"{x:24,y:551,t:1527614050913};\\\", \\\"{x:0,y:540,t:1527614050929};\\\", \\\"{x:0,y:531,t:1527614050945};\\\", \\\"{x:0,y:525,t:1527614050963};\\\", \\\"{x:0,y:522,t:1527614050980};\\\", \\\"{x:1,y:522,t:1527614051115};\\\", \\\"{x:5,y:525,t:1527614051129};\\\", \\\"{x:29,y:541,t:1527614051146};\\\", \\\"{x:78,y:568,t:1527614051163};\\\", \\\"{x:163,y:602,t:1527614051180};\\\", \\\"{x:285,y:638,t:1527614051201};\\\", \\\"{x:401,y:669,t:1527614051217};\\\", \\\"{x:508,y:693,t:1527614051233};\\\", \\\"{x:577,y:711,t:1527614051250};\\\", \\\"{x:585,y:711,t:1527614051266};\\\", \\\"{x:583,y:711,t:1527614051451};\\\", \\\"{x:580,y:711,t:1527614051468};\\\", \\\"{x:574,y:708,t:1527614051485};\\\", \\\"{x:567,y:704,t:1527614051502};\\\", \\\"{x:561,y:702,t:1527614051520};\\\", \\\"{x:555,y:700,t:1527614051535};\\\", \\\"{x:551,y:699,t:1527614051549};\\\", \\\"{x:550,y:699,t:1527614051566};\\\", \\\"{x:547,y:699,t:1527614051583};\\\", \\\"{x:545,y:699,t:1527614051642};\\\", \\\"{x:544,y:699,t:1527614051658};\\\", \\\"{x:543,y:699,t:1527614051674};\\\", \\\"{x:541,y:700,t:1527614051690};\\\", \\\"{x:539,y:701,t:1527614051714};\\\", \\\"{x:537,y:703,t:1527614051722};\\\", \\\"{x:535,y:703,t:1527614051734};\\\", \\\"{x:533,y:705,t:1527614051750};\\\", \\\"{x:532,y:705,t:1527614051771};\\\", \\\"{x:532,y:704,t:1527614051851};\\\", \\\"{x:532,y:693,t:1527614051868};\\\", \\\"{x:537,y:671,t:1527614051883};\\\", \\\"{x:543,y:650,t:1527614051900};\\\", \\\"{x:553,y:629,t:1527614051918};\\\", \\\"{x:561,y:611,t:1527614051933};\\\", \\\"{x:569,y:594,t:1527614051951};\\\", \\\"{x:577,y:581,t:1527614051967};\\\", \\\"{x:585,y:567,t:1527614051984};\\\", \\\"{x:591,y:557,t:1527614052001};\\\", \\\"{x:594,y:548,t:1527614052017};\\\", \\\"{x:597,y:541,t:1527614052034};\\\", \\\"{x:598,y:539,t:1527614052051};\\\", \\\"{x:600,y:536,t:1527614052067};\\\", \\\"{x:600,y:535,t:1527614052084};\\\", \\\"{x:600,y:534,t:1527614052100};\\\", \\\"{x:601,y:532,t:1527614052118};\\\", \\\"{x:602,y:531,t:1527614052134};\\\", \\\"{x:603,y:529,t:1527614052150};\\\", \\\"{x:603,y:525,t:1527614052170};\\\", \\\"{x:604,y:525,t:1527614052185};\\\", \\\"{x:604,y:524,t:1527614052201};\\\", \\\"{x:605,y:522,t:1527614052218};\\\", \\\"{x:606,y:519,t:1527614052234};\\\", \\\"{x:608,y:516,t:1527614052250};\\\", \\\"{x:609,y:513,t:1527614052267};\\\", \\\"{x:610,y:513,t:1527614052306};\\\", \\\"{x:610,y:512,t:1527614052378};\\\", \\\"{x:608,y:512,t:1527614052385};\\\", \\\"{x:604,y:513,t:1527614052401};\\\", \\\"{x:599,y:514,t:1527614052417};\\\", \\\"{x:593,y:518,t:1527614052435};\\\", \\\"{x:591,y:520,t:1527614052452};\\\", \\\"{x:590,y:522,t:1527614052468};\\\", \\\"{x:589,y:523,t:1527614052485};\\\", \\\"{x:587,y:524,t:1527614052529};\\\", \\\"{x:586,y:526,t:1527614052546};\\\", \\\"{x:585,y:529,t:1527614052554};\\\", \\\"{x:585,y:530,t:1527614052568};\\\", \\\"{x:585,y:535,t:1527614052585};\\\", \\\"{x:585,y:538,t:1527614052601};\\\", \\\"{x:585,y:541,t:1527614052618};\\\", \\\"{x:586,y:542,t:1527614052635};\\\", \\\"{x:587,y:544,t:1527614052690};\\\", \\\"{x:588,y:544,t:1527614052701};\\\", \\\"{x:590,y:545,t:1527614052718};\\\", \\\"{x:592,y:546,t:1527614052734};\\\", \\\"{x:596,y:548,t:1527614052752};\\\", \\\"{x:600,y:549,t:1527614052768};\\\", \\\"{x:603,y:552,t:1527614052784};\\\", \\\"{x:609,y:554,t:1527614052802};\\\", \\\"{x:612,y:555,t:1527614052817};\\\", \\\"{x:616,y:557,t:1527614052834};\\\", \\\"{x:618,y:559,t:1527614052852};\\\", \\\"{x:619,y:563,t:1527614053307};\\\", \\\"{x:619,y:574,t:1527614053320};\\\", \\\"{x:616,y:597,t:1527614053336};\\\", \\\"{x:612,y:623,t:1527614053352};\\\", \\\"{x:610,y:652,t:1527614053369};\\\", \\\"{x:604,y:670,t:1527614053386};\\\", \\\"{x:600,y:682,t:1527614053401};\\\", \\\"{x:599,y:691,t:1527614053418};\\\", \\\"{x:599,y:694,t:1527614053435};\\\", \\\"{x:598,y:695,t:1527614053451};\\\", \\\"{x:597,y:696,t:1527614053546};\\\", \\\"{x:596,y:696,t:1527614053562};\\\", \\\"{x:593,y:696,t:1527614053570};\\\", \\\"{x:591,y:696,t:1527614053586};\\\", \\\"{x:582,y:699,t:1527614053602};\\\", \\\"{x:565,y:703,t:1527614053618};\\\", \\\"{x:547,y:705,t:1527614053637};\\\", \\\"{x:532,y:707,t:1527614053652};\\\", \\\"{x:523,y:709,t:1527614053668};\\\", \\\"{x:517,y:710,t:1527614053685};\\\", \\\"{x:516,y:710,t:1527614053702};\\\", \\\"{x:514,y:712,t:1527614053718};\\\" ] }, { \\\"rt\\\": 11126, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 458909, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"K7JVY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2.5, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"F\\\", \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:514,y:711,t:1527614059275};\\\", \\\"{x:517,y:702,t:1527614059304};\\\", \\\"{x:518,y:700,t:1527614059312};\\\", \\\"{x:526,y:693,t:1527614059330};\\\", \\\"{x:532,y:686,t:1527614059345};\\\", \\\"{x:534,y:680,t:1527614059357};\\\", \\\"{x:537,y:676,t:1527614059374};\\\", \\\"{x:537,y:674,t:1527614059390};\\\", \\\"{x:540,y:669,t:1527614059407};\\\", \\\"{x:541,y:667,t:1527614059423};\\\", \\\"{x:542,y:664,t:1527614059439};\\\", \\\"{x:544,y:661,t:1527614059456};\\\", \\\"{x:545,y:657,t:1527614059473};\\\", \\\"{x:548,y:653,t:1527614059490};\\\", \\\"{x:554,y:644,t:1527614059507};\\\", \\\"{x:557,y:641,t:1527614059524};\\\", \\\"{x:560,y:636,t:1527614059540};\\\", \\\"{x:563,y:631,t:1527614059557};\\\", \\\"{x:567,y:627,t:1527614059574};\\\", \\\"{x:572,y:621,t:1527614059591};\\\", \\\"{x:575,y:617,t:1527614059607};\\\", \\\"{x:578,y:613,t:1527614059624};\\\", \\\"{x:583,y:611,t:1527614059641};\\\", \\\"{x:588,y:606,t:1527614059659};\\\", \\\"{x:594,y:602,t:1527614059674};\\\", \\\"{x:598,y:598,t:1527614059689};\\\", \\\"{x:602,y:595,t:1527614059707};\\\", \\\"{x:606,y:591,t:1527614059723};\\\", \\\"{x:611,y:587,t:1527614059741};\\\", \\\"{x:617,y:583,t:1527614059757};\\\", \\\"{x:620,y:580,t:1527614059774};\\\", \\\"{x:627,y:575,t:1527614059791};\\\", \\\"{x:630,y:573,t:1527614059807};\\\", \\\"{x:634,y:570,t:1527614059825};\\\", \\\"{x:635,y:569,t:1527614059840};\\\", \\\"{x:637,y:567,t:1527614059857};\\\", \\\"{x:639,y:566,t:1527614059874};\\\", \\\"{x:640,y:565,t:1527614059890};\\\", \\\"{x:642,y:564,t:1527614060963};\\\", \\\"{x:646,y:562,t:1527614060976};\\\", \\\"{x:659,y:557,t:1527614060992};\\\", \\\"{x:666,y:554,t:1527614061008};\\\", \\\"{x:667,y:553,t:1527614061025};\\\", \\\"{x:668,y:553,t:1527614061042};\\\", \\\"{x:668,y:552,t:1527614061139};\\\", \\\"{x:669,y:552,t:1527614061163};\\\", \\\"{x:670,y:552,t:1527614061175};\\\", \\\"{x:671,y:551,t:1527614061192};\\\", \\\"{x:673,y:550,t:1527614061210};\\\", \\\"{x:674,y:550,t:1527614061234};\\\", \\\"{x:674,y:549,t:1527614061259};\\\", \\\"{x:674,y:550,t:1527614061370};\\\", \\\"{x:670,y:552,t:1527614061378};\\\", \\\"{x:669,y:552,t:1527614061395};\\\", \\\"{x:669,y:553,t:1527614061409};\\\", \\\"{x:668,y:553,t:1527614061426};\\\", \\\"{x:667,y:553,t:1527614061443};\\\", \\\"{x:666,y:553,t:1527614061547};\\\", \\\"{x:664,y:553,t:1527614061559};\\\", \\\"{x:660,y:549,t:1527614061575};\\\", \\\"{x:656,y:543,t:1527614061593};\\\", \\\"{x:654,y:539,t:1527614061611};\\\", \\\"{x:651,y:536,t:1527614061625};\\\", \\\"{x:644,y:531,t:1527614061643};\\\", \\\"{x:641,y:528,t:1527614061659};\\\", \\\"{x:640,y:527,t:1527614061674};\\\", \\\"{x:638,y:525,t:1527614061692};\\\", \\\"{x:637,y:524,t:1527614061709};\\\", \\\"{x:636,y:521,t:1527614061725};\\\", \\\"{x:635,y:518,t:1527614061741};\\\", \\\"{x:634,y:513,t:1527614061759};\\\", \\\"{x:633,y:507,t:1527614061774};\\\", \\\"{x:632,y:504,t:1527614061792};\\\", \\\"{x:632,y:498,t:1527614061810};\\\", \\\"{x:632,y:491,t:1527614061826};\\\", \\\"{x:632,y:487,t:1527614061842};\\\", \\\"{x:632,y:484,t:1527614061858};\\\", \\\"{x:632,y:482,t:1527614061875};\\\", \\\"{x:632,y:480,t:1527614061892};\\\", \\\"{x:631,y:477,t:1527614061909};\\\", \\\"{x:630,y:475,t:1527614061925};\\\", \\\"{x:629,y:474,t:1527614061942};\\\", \\\"{x:628,y:473,t:1527614061958};\\\", \\\"{x:628,y:472,t:1527614061975};\\\", \\\"{x:628,y:471,t:1527614062010};\\\", \\\"{x:628,y:470,t:1527614062025};\\\", \\\"{x:641,y:468,t:1527614062042};\\\", \\\"{x:656,y:468,t:1527614062059};\\\", \\\"{x:679,y:468,t:1527614062075};\\\", \\\"{x:714,y:468,t:1527614062091};\\\", \\\"{x:748,y:468,t:1527614062109};\\\", \\\"{x:775,y:468,t:1527614062125};\\\", \\\"{x:797,y:468,t:1527614062142};\\\", \\\"{x:812,y:468,t:1527614062159};\\\", \\\"{x:814,y:468,t:1527614062176};\\\", \\\"{x:814,y:470,t:1527614062274};\\\", \\\"{x:814,y:471,t:1527614062281};\\\", \\\"{x:814,y:473,t:1527614062293};\\\", \\\"{x:815,y:475,t:1527614062309};\\\", \\\"{x:815,y:477,t:1527614063026};\\\", \\\"{x:816,y:477,t:1527614063131};\\\", \\\"{x:820,y:477,t:1527614063299};\\\", \\\"{x:821,y:477,t:1527614063310};\\\", \\\"{x:823,y:477,t:1527614063327};\\\", \\\"{x:826,y:477,t:1527614063346};\\\", \\\"{x:827,y:477,t:1527614063360};\\\", \\\"{x:828,y:477,t:1527614063376};\\\", \\\"{x:829,y:477,t:1527614063392};\\\", \\\"{x:830,y:477,t:1527614063407};\\\", \\\"{x:831,y:477,t:1527614063425};\\\", \\\"{x:832,y:477,t:1527614063442};\\\", \\\"{x:834,y:477,t:1527614063458};\\\", \\\"{x:835,y:477,t:1527614063475};\\\", \\\"{x:817,y:481,t:1527614064012};\\\", \\\"{x:744,y:495,t:1527614064027};\\\", \\\"{x:663,y:506,t:1527614064045};\\\", \\\"{x:581,y:511,t:1527614064060};\\\", \\\"{x:501,y:511,t:1527614064077};\\\", \\\"{x:415,y:511,t:1527614064095};\\\", \\\"{x:337,y:511,t:1527614064111};\\\", \\\"{x:281,y:511,t:1527614064127};\\\", \\\"{x:245,y:511,t:1527614064144};\\\", \\\"{x:226,y:511,t:1527614064160};\\\", \\\"{x:218,y:511,t:1527614064176};\\\", \\\"{x:217,y:511,t:1527614064194};\\\", \\\"{x:219,y:511,t:1527614064266};\\\", \\\"{x:221,y:509,t:1527614064277};\\\", \\\"{x:232,y:506,t:1527614064294};\\\", \\\"{x:245,y:504,t:1527614064311};\\\", \\\"{x:254,y:502,t:1527614064328};\\\", \\\"{x:256,y:502,t:1527614064344};\\\", \\\"{x:255,y:502,t:1527614064403};\\\", \\\"{x:253,y:503,t:1527614064412};\\\", \\\"{x:248,y:508,t:1527614064428};\\\", \\\"{x:244,y:511,t:1527614064444};\\\", \\\"{x:239,y:514,t:1527614064461};\\\", \\\"{x:237,y:516,t:1527614064478};\\\", \\\"{x:236,y:516,t:1527614064494};\\\", \\\"{x:235,y:516,t:1527614064511};\\\", \\\"{x:234,y:516,t:1527614064528};\\\", \\\"{x:229,y:518,t:1527614064544};\\\", \\\"{x:222,y:518,t:1527614064561};\\\", \\\"{x:208,y:518,t:1527614064578};\\\", \\\"{x:201,y:518,t:1527614064594};\\\", \\\"{x:190,y:518,t:1527614064613};\\\", \\\"{x:180,y:518,t:1527614064628};\\\", \\\"{x:177,y:518,t:1527614064644};\\\", \\\"{x:176,y:518,t:1527614064661};\\\", \\\"{x:174,y:518,t:1527614064689};\\\", \\\"{x:172,y:518,t:1527614064714};\\\", \\\"{x:170,y:518,t:1527614064931};\\\", \\\"{x:169,y:518,t:1527614064946};\\\", \\\"{x:166,y:519,t:1527614064961};\\\", \\\"{x:163,y:520,t:1527614064979};\\\", \\\"{x:161,y:521,t:1527614064995};\\\", \\\"{x:159,y:522,t:1527614065012};\\\", \\\"{x:157,y:523,t:1527614065028};\\\", \\\"{x:156,y:523,t:1527614065045};\\\", \\\"{x:156,y:525,t:1527614065587};\\\", \\\"{x:171,y:540,t:1527614065597};\\\", \\\"{x:210,y:566,t:1527614065613};\\\", \\\"{x:257,y:597,t:1527614065629};\\\", \\\"{x:301,y:625,t:1527614065645};\\\", \\\"{x:353,y:653,t:1527614065663};\\\", \\\"{x:396,y:676,t:1527614065678};\\\", \\\"{x:425,y:693,t:1527614065695};\\\", \\\"{x:443,y:707,t:1527614065712};\\\", \\\"{x:458,y:717,t:1527614065729};\\\", \\\"{x:469,y:728,t:1527614065745};\\\", \\\"{x:487,y:741,t:1527614065762};\\\", \\\"{x:493,y:747,t:1527614065778};\\\", \\\"{x:494,y:748,t:1527614065795};\\\", \\\"{x:496,y:749,t:1527614065812};\\\", \\\"{x:497,y:749,t:1527614065913};\\\", \\\"{x:498,y:749,t:1527614065928};\\\", \\\"{x:501,y:744,t:1527614065945};\\\", \\\"{x:504,y:739,t:1527614065962};\\\", \\\"{x:504,y:737,t:1527614065978};\\\", \\\"{x:505,y:734,t:1527614065995};\\\", \\\"{x:505,y:733,t:1527614066012};\\\", \\\"{x:505,y:729,t:1527614066029};\\\", \\\"{x:505,y:727,t:1527614066045};\\\", \\\"{x:506,y:724,t:1527614066062};\\\", \\\"{x:506,y:721,t:1527614066079};\\\", \\\"{x:506,y:718,t:1527614066096};\\\", \\\"{x:506,y:714,t:1527614066112};\\\", \\\"{x:506,y:712,t:1527614066129};\\\", \\\"{x:506,y:708,t:1527614066819};\\\", \\\"{x:506,y:697,t:1527614066829};\\\", \\\"{x:508,y:678,t:1527614066846};\\\", \\\"{x:508,y:656,t:1527614066863};\\\", \\\"{x:507,y:636,t:1527614066880};\\\", \\\"{x:500,y:620,t:1527614066896};\\\", \\\"{x:495,y:609,t:1527614066913};\\\", \\\"{x:494,y:605,t:1527614066929};\\\", \\\"{x:492,y:600,t:1527614066946};\\\", \\\"{x:492,y:599,t:1527614066970};\\\" ] }, { \\\"rt\\\": 8805, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 468972, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"K7JVY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:493,y:598,t:1527614069361};\\\", \\\"{x:493,y:597,t:1527614069397};\\\", \\\"{x:494,y:597,t:1527614069403};\\\", \\\"{x:494,y:596,t:1527614072938};\\\", \\\"{x:494,y:588,t:1527614073043};\\\", \\\"{x:496,y:582,t:1527614073051};\\\", \\\"{x:497,y:576,t:1527614073070};\\\", \\\"{x:498,y:567,t:1527614073085};\\\", \\\"{x:498,y:562,t:1527614073101};\\\", \\\"{x:501,y:555,t:1527614073118};\\\", \\\"{x:501,y:551,t:1527614073134};\\\", \\\"{x:502,y:547,t:1527614073151};\\\", \\\"{x:503,y:542,t:1527614073168};\\\", \\\"{x:504,y:539,t:1527614073184};\\\", \\\"{x:506,y:534,t:1527614073202};\\\", \\\"{x:510,y:529,t:1527614073219};\\\", \\\"{x:514,y:524,t:1527614073235};\\\", \\\"{x:519,y:519,t:1527614073251};\\\", \\\"{x:521,y:516,t:1527614073269};\\\", \\\"{x:525,y:511,t:1527614073284};\\\", \\\"{x:526,y:509,t:1527614073301};\\\", \\\"{x:527,y:507,t:1527614073318};\\\", \\\"{x:529,y:505,t:1527614073334};\\\", \\\"{x:534,y:503,t:1527614073351};\\\", \\\"{x:537,y:500,t:1527614073368};\\\", \\\"{x:541,y:496,t:1527614073384};\\\", \\\"{x:546,y:492,t:1527614073402};\\\", \\\"{x:550,y:490,t:1527614073418};\\\", \\\"{x:554,y:486,t:1527614073434};\\\", \\\"{x:555,y:485,t:1527614073451};\\\", \\\"{x:553,y:485,t:1527614073554};\\\", \\\"{x:550,y:485,t:1527614073568};\\\", \\\"{x:539,y:489,t:1527614073585};\\\", \\\"{x:528,y:490,t:1527614073601};\\\", \\\"{x:513,y:493,t:1527614073618};\\\", \\\"{x:499,y:494,t:1527614073635};\\\", \\\"{x:486,y:494,t:1527614073652};\\\", \\\"{x:473,y:495,t:1527614073668};\\\", \\\"{x:459,y:498,t:1527614073685};\\\", \\\"{x:447,y:500,t:1527614073702};\\\", \\\"{x:435,y:501,t:1527614073719};\\\", \\\"{x:420,y:504,t:1527614073735};\\\", \\\"{x:404,y:505,t:1527614073752};\\\", \\\"{x:386,y:506,t:1527614073768};\\\", \\\"{x:365,y:508,t:1527614073786};\\\", \\\"{x:357,y:508,t:1527614073802};\\\", \\\"{x:350,y:508,t:1527614073818};\\\", \\\"{x:348,y:508,t:1527614073836};\\\", \\\"{x:347,y:508,t:1527614073852};\\\", \\\"{x:346,y:509,t:1527614073897};\\\", \\\"{x:345,y:509,t:1527614073922};\\\", \\\"{x:344,y:509,t:1527614073935};\\\", \\\"{x:341,y:510,t:1527614073951};\\\", \\\"{x:337,y:510,t:1527614073969};\\\", \\\"{x:330,y:510,t:1527614073985};\\\", \\\"{x:325,y:512,t:1527614074001};\\\", \\\"{x:321,y:513,t:1527614074019};\\\", \\\"{x:316,y:513,t:1527614074036};\\\", \\\"{x:312,y:514,t:1527614074052};\\\", \\\"{x:310,y:514,t:1527614074068};\\\", \\\"{x:307,y:514,t:1527614074085};\\\", \\\"{x:304,y:514,t:1527614074101};\\\", \\\"{x:301,y:514,t:1527614074118};\\\", \\\"{x:298,y:514,t:1527614074136};\\\", \\\"{x:295,y:514,t:1527614074152};\\\", \\\"{x:294,y:514,t:1527614074178};\\\", \\\"{x:292,y:514,t:1527614074202};\\\", \\\"{x:291,y:514,t:1527614074219};\\\", \\\"{x:287,y:516,t:1527614074236};\\\", \\\"{x:285,y:516,t:1527614074251};\\\", \\\"{x:281,y:516,t:1527614074268};\\\", \\\"{x:278,y:516,t:1527614074285};\\\", \\\"{x:276,y:516,t:1527614074306};\\\", \\\"{x:274,y:516,t:1527614074318};\\\", \\\"{x:272,y:516,t:1527614074337};\\\", \\\"{x:269,y:516,t:1527614074351};\\\", \\\"{x:268,y:516,t:1527614074369};\\\", \\\"{x:267,y:516,t:1527614074386};\\\", \\\"{x:266,y:516,t:1527614074410};\\\", \\\"{x:265,y:517,t:1527614074426};\\\", \\\"{x:264,y:517,t:1527614074437};\\\", \\\"{x:261,y:518,t:1527614074453};\\\", \\\"{x:255,y:520,t:1527614074469};\\\", \\\"{x:251,y:520,t:1527614074486};\\\", \\\"{x:249,y:521,t:1527614074502};\\\", \\\"{x:246,y:521,t:1527614074519};\\\", \\\"{x:243,y:522,t:1527614074537};\\\", \\\"{x:238,y:522,t:1527614074554};\\\", \\\"{x:233,y:522,t:1527614074570};\\\", \\\"{x:227,y:522,t:1527614074586};\\\", \\\"{x:218,y:522,t:1527614074603};\\\", \\\"{x:212,y:522,t:1527614074619};\\\", \\\"{x:203,y:522,t:1527614074636};\\\", \\\"{x:197,y:522,t:1527614074654};\\\", \\\"{x:194,y:522,t:1527614074669};\\\", \\\"{x:190,y:522,t:1527614074687};\\\", \\\"{x:187,y:521,t:1527614074703};\\\", \\\"{x:183,y:521,t:1527614074719};\\\", \\\"{x:178,y:521,t:1527614074736};\\\", \\\"{x:172,y:521,t:1527614074752};\\\", \\\"{x:171,y:521,t:1527614074769};\\\", \\\"{x:167,y:521,t:1527614074842};\\\", \\\"{x:166,y:521,t:1527614074858};\\\", \\\"{x:165,y:521,t:1527614074870};\\\", \\\"{x:164,y:521,t:1527614074887};\\\", \\\"{x:162,y:521,t:1527614074902};\\\", \\\"{x:161,y:521,t:1527614074920};\\\", \\\"{x:161,y:521,t:1527614075006};\\\", \\\"{x:167,y:522,t:1527614075346};\\\", \\\"{x:188,y:531,t:1527614075355};\\\", \\\"{x:230,y:551,t:1527614075370};\\\", \\\"{x:304,y:585,t:1527614075386};\\\", \\\"{x:384,y:617,t:1527614075404};\\\", \\\"{x:437,y:642,t:1527614075419};\\\", \\\"{x:465,y:659,t:1527614075437};\\\", \\\"{x:482,y:670,t:1527614075454};\\\", \\\"{x:492,y:677,t:1527614075470};\\\", \\\"{x:493,y:679,t:1527614075487};\\\", \\\"{x:494,y:680,t:1527614075503};\\\", \\\"{x:495,y:682,t:1527614075520};\\\", \\\"{x:496,y:682,t:1527614075537};\\\", \\\"{x:496,y:683,t:1527614075554};\\\", \\\"{x:497,y:684,t:1527614075571};\\\", \\\"{x:497,y:685,t:1527614075818};\\\", \\\"{x:497,y:687,t:1527614075826};\\\", \\\"{x:496,y:692,t:1527614075838};\\\", \\\"{x:496,y:699,t:1527614075855};\\\", \\\"{x:496,y:704,t:1527614075872};\\\", \\\"{x:496,y:709,t:1527614075887};\\\", \\\"{x:496,y:712,t:1527614075903};\\\", \\\"{x:496,y:713,t:1527614075921};\\\", \\\"{x:496,y:713,t:1527614076228};\\\" ] }, { \\\"rt\\\": 25214, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 495383, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"K7JVY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-05 PM-04 PM-04 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:492,y:719,t:1527614078131};\\\", \\\"{x:492,y:720,t:1527614078273};\\\", \\\"{x:493,y:720,t:1527614078306};\\\", \\\"{x:494,y:721,t:1527614078362};\\\", \\\"{x:494,y:725,t:1527614078372};\\\", \\\"{x:491,y:734,t:1527614078390};\\\", \\\"{x:483,y:743,t:1527614078407};\\\", \\\"{x:480,y:752,t:1527614078422};\\\", \\\"{x:480,y:757,t:1527614078438};\\\", \\\"{x:480,y:760,t:1527614078529};\\\", \\\"{x:480,y:766,t:1527614078539};\\\", \\\"{x:480,y:815,t:1527614078555};\\\", \\\"{x:485,y:870,t:1527614078572};\\\", \\\"{x:498,y:908,t:1527614078588};\\\", \\\"{x:509,y:932,t:1527614078605};\\\", \\\"{x:517,y:941,t:1527614078622};\\\", \\\"{x:520,y:943,t:1527614078638};\\\", \\\"{x:522,y:943,t:1527614078658};\\\", \\\"{x:526,y:943,t:1527614078672};\\\", \\\"{x:536,y:950,t:1527614078689};\\\", \\\"{x:541,y:954,t:1527614078705};\\\", \\\"{x:542,y:954,t:1527614079585};\\\", \\\"{x:543,y:954,t:1527614079593};\\\", \\\"{x:544,y:954,t:1527614079606};\\\", \\\"{x:554,y:949,t:1527614079623};\\\", \\\"{x:568,y:940,t:1527614079639};\\\", \\\"{x:586,y:926,t:1527614079656};\\\", \\\"{x:611,y:907,t:1527614079672};\\\", \\\"{x:683,y:854,t:1527614079689};\\\", \\\"{x:727,y:815,t:1527614079706};\\\", \\\"{x:763,y:781,t:1527614079722};\\\", \\\"{x:790,y:753,t:1527614079740};\\\", \\\"{x:812,y:722,t:1527614079757};\\\", \\\"{x:835,y:692,t:1527614079772};\\\", \\\"{x:869,y:649,t:1527614079790};\\\", \\\"{x:907,y:610,t:1527614079807};\\\", \\\"{x:950,y:574,t:1527614079822};\\\", \\\"{x:968,y:553,t:1527614079840};\\\", \\\"{x:991,y:531,t:1527614079856};\\\", \\\"{x:999,y:526,t:1527614079872};\\\", \\\"{x:1000,y:525,t:1527614079889};\\\", \\\"{x:1001,y:525,t:1527614079937};\\\", \\\"{x:1002,y:525,t:1527614079962};\\\", \\\"{x:1001,y:525,t:1527614080001};\\\", \\\"{x:1001,y:524,t:1527614080290};\\\", \\\"{x:1001,y:523,t:1527614080306};\\\", \\\"{x:1003,y:522,t:1527614080353};\\\", \\\"{x:1006,y:521,t:1527614080361};\\\", \\\"{x:1013,y:521,t:1527614080373};\\\", \\\"{x:1025,y:521,t:1527614080390};\\\", \\\"{x:1041,y:521,t:1527614080407};\\\", \\\"{x:1077,y:532,t:1527614080424};\\\", \\\"{x:1137,y:558,t:1527614080441};\\\", \\\"{x:1232,y:590,t:1527614080457};\\\", \\\"{x:1383,y:638,t:1527614080474};\\\", \\\"{x:1472,y:669,t:1527614080491};\\\", \\\"{x:1553,y:710,t:1527614080507};\\\", \\\"{x:1629,y:747,t:1527614080524};\\\", \\\"{x:1682,y:781,t:1527614080540};\\\", \\\"{x:1726,y:812,t:1527614080557};\\\", \\\"{x:1761,y:839,t:1527614080573};\\\", \\\"{x:1795,y:862,t:1527614080591};\\\", \\\"{x:1833,y:884,t:1527614080606};\\\", \\\"{x:1868,y:903,t:1527614080623};\\\", \\\"{x:1893,y:915,t:1527614080640};\\\", \\\"{x:1909,y:923,t:1527614080657};\\\", \\\"{x:1919,y:935,t:1527614080673};\\\", \\\"{x:1919,y:942,t:1527614080690};\\\", \\\"{x:1919,y:950,t:1527614080708};\\\", \\\"{x:1919,y:958,t:1527614080723};\\\", \\\"{x:1916,y:965,t:1527614080741};\\\", \\\"{x:1908,y:974,t:1527614080757};\\\", \\\"{x:1891,y:983,t:1527614080773};\\\", \\\"{x:1869,y:991,t:1527614080791};\\\", \\\"{x:1841,y:997,t:1527614080808};\\\", \\\"{x:1812,y:1001,t:1527614080824};\\\", \\\"{x:1793,y:1001,t:1527614080840};\\\", \\\"{x:1765,y:1004,t:1527614080857};\\\", \\\"{x:1747,y:1005,t:1527614080874};\\\", \\\"{x:1731,y:1007,t:1527614080890};\\\", \\\"{x:1728,y:1011,t:1527614080907};\\\", \\\"{x:1727,y:1011,t:1527614080925};\\\", \\\"{x:1723,y:1012,t:1527614081033};\\\", \\\"{x:1717,y:1016,t:1527614081041};\\\", \\\"{x:1700,y:1029,t:1527614081057};\\\", \\\"{x:1696,y:1034,t:1527614081074};\\\", \\\"{x:1696,y:1035,t:1527614081091};\\\", \\\"{x:1696,y:1036,t:1527614081113};\\\", \\\"{x:1690,y:1036,t:1527614081124};\\\", \\\"{x:1684,y:1033,t:1527614081142};\\\", \\\"{x:1682,y:1031,t:1527614081157};\\\", \\\"{x:1679,y:1031,t:1527614081174};\\\", \\\"{x:1676,y:1028,t:1527614081192};\\\", \\\"{x:1674,y:1026,t:1527614081207};\\\", \\\"{x:1670,y:1020,t:1527614081224};\\\", \\\"{x:1666,y:1005,t:1527614081241};\\\", \\\"{x:1665,y:998,t:1527614081257};\\\", \\\"{x:1665,y:991,t:1527614081275};\\\", \\\"{x:1665,y:982,t:1527614081292};\\\", \\\"{x:1670,y:966,t:1527614081308};\\\", \\\"{x:1678,y:947,t:1527614081325};\\\", \\\"{x:1686,y:927,t:1527614081342};\\\", \\\"{x:1694,y:915,t:1527614081358};\\\", \\\"{x:1700,y:904,t:1527614081375};\\\", \\\"{x:1706,y:892,t:1527614081392};\\\", \\\"{x:1709,y:885,t:1527614081408};\\\", \\\"{x:1711,y:882,t:1527614081425};\\\", \\\"{x:1714,y:875,t:1527614081442};\\\", \\\"{x:1715,y:870,t:1527614081457};\\\", \\\"{x:1717,y:862,t:1527614081474};\\\", \\\"{x:1719,y:857,t:1527614081491};\\\", \\\"{x:1720,y:848,t:1527614081507};\\\", \\\"{x:1724,y:838,t:1527614081525};\\\", \\\"{x:1725,y:829,t:1527614081541};\\\", \\\"{x:1728,y:818,t:1527614081557};\\\", \\\"{x:1730,y:812,t:1527614081574};\\\", \\\"{x:1731,y:808,t:1527614081591};\\\", \\\"{x:1732,y:807,t:1527614081609};\\\", \\\"{x:1734,y:802,t:1527614081625};\\\", \\\"{x:1735,y:800,t:1527614081642};\\\", \\\"{x:1735,y:798,t:1527614081659};\\\", \\\"{x:1735,y:797,t:1527614081674};\\\", \\\"{x:1735,y:795,t:1527614081692};\\\", \\\"{x:1735,y:791,t:1527614081709};\\\", \\\"{x:1736,y:786,t:1527614081724};\\\", \\\"{x:1735,y:779,t:1527614081741};\\\", \\\"{x:1734,y:774,t:1527614081759};\\\", \\\"{x:1731,y:768,t:1527614081775};\\\", \\\"{x:1730,y:765,t:1527614081791};\\\", \\\"{x:1728,y:760,t:1527614081808};\\\", \\\"{x:1726,y:756,t:1527614081824};\\\", \\\"{x:1723,y:749,t:1527614081841};\\\", \\\"{x:1720,y:744,t:1527614081859};\\\", \\\"{x:1718,y:737,t:1527614081874};\\\", \\\"{x:1715,y:732,t:1527614081892};\\\", \\\"{x:1711,y:724,t:1527614081909};\\\", \\\"{x:1706,y:714,t:1527614081925};\\\", \\\"{x:1701,y:704,t:1527614081942};\\\", \\\"{x:1697,y:698,t:1527614081959};\\\", \\\"{x:1692,y:689,t:1527614081975};\\\", \\\"{x:1687,y:680,t:1527614081992};\\\", \\\"{x:1683,y:672,t:1527614082009};\\\", \\\"{x:1677,y:662,t:1527614082024};\\\", \\\"{x:1670,y:648,t:1527614082041};\\\", \\\"{x:1666,y:638,t:1527614082059};\\\", \\\"{x:1664,y:632,t:1527614082076};\\\", \\\"{x:1663,y:627,t:1527614082091};\\\", \\\"{x:1662,y:626,t:1527614082108};\\\", \\\"{x:1657,y:628,t:1527614082193};\\\", \\\"{x:1652,y:634,t:1527614082209};\\\", \\\"{x:1645,y:653,t:1527614082225};\\\", \\\"{x:1641,y:667,t:1527614082241};\\\", \\\"{x:1640,y:676,t:1527614082259};\\\", \\\"{x:1637,y:685,t:1527614082276};\\\", \\\"{x:1636,y:690,t:1527614082291};\\\", \\\"{x:1633,y:696,t:1527614082308};\\\", \\\"{x:1633,y:697,t:1527614082326};\\\", \\\"{x:1633,y:699,t:1527614082342};\\\", \\\"{x:1633,y:701,t:1527614082362};\\\", \\\"{x:1633,y:703,t:1527614082377};\\\", \\\"{x:1632,y:703,t:1527614082441};\\\", \\\"{x:1631,y:703,t:1527614082449};\\\", \\\"{x:1630,y:703,t:1527614082459};\\\", \\\"{x:1627,y:703,t:1527614082476};\\\", \\\"{x:1624,y:703,t:1527614082492};\\\", \\\"{x:1622,y:699,t:1527614082508};\\\", \\\"{x:1619,y:693,t:1527614082525};\\\", \\\"{x:1617,y:688,t:1527614082542};\\\", \\\"{x:1615,y:686,t:1527614082558};\\\", \\\"{x:1613,y:683,t:1527614082576};\\\", \\\"{x:1612,y:683,t:1527614082593};\\\", \\\"{x:1612,y:682,t:1527614082609};\\\", \\\"{x:1611,y:684,t:1527614083585};\\\", \\\"{x:1610,y:687,t:1527614083593};\\\", \\\"{x:1610,y:693,t:1527614083609};\\\", \\\"{x:1609,y:700,t:1527614083627};\\\", \\\"{x:1609,y:705,t:1527614083643};\\\", \\\"{x:1609,y:712,t:1527614083660};\\\", \\\"{x:1608,y:717,t:1527614083677};\\\", \\\"{x:1607,y:724,t:1527614083693};\\\", \\\"{x:1607,y:730,t:1527614083710};\\\", \\\"{x:1607,y:736,t:1527614083727};\\\", \\\"{x:1606,y:748,t:1527614083743};\\\", \\\"{x:1603,y:762,t:1527614083760};\\\", \\\"{x:1602,y:776,t:1527614083776};\\\", \\\"{x:1601,y:798,t:1527614083793};\\\", \\\"{x:1601,y:813,t:1527614083810};\\\", \\\"{x:1601,y:830,t:1527614083827};\\\", \\\"{x:1601,y:847,t:1527614083843};\\\", \\\"{x:1601,y:865,t:1527614083859};\\\", \\\"{x:1601,y:876,t:1527614083877};\\\", \\\"{x:1601,y:885,t:1527614083893};\\\", \\\"{x:1601,y:889,t:1527614083909};\\\", \\\"{x:1601,y:895,t:1527614083927};\\\", \\\"{x:1601,y:899,t:1527614083944};\\\", \\\"{x:1601,y:904,t:1527614083959};\\\", \\\"{x:1603,y:910,t:1527614083976};\\\", \\\"{x:1604,y:912,t:1527614083993};\\\", \\\"{x:1606,y:914,t:1527614084010};\\\", \\\"{x:1608,y:917,t:1527614084027};\\\", \\\"{x:1613,y:922,t:1527614084044};\\\", \\\"{x:1616,y:925,t:1527614084060};\\\", \\\"{x:1619,y:926,t:1527614084076};\\\", \\\"{x:1620,y:926,t:1527614084113};\\\", \\\"{x:1621,y:928,t:1527614084129};\\\", \\\"{x:1621,y:929,t:1527614084146};\\\", \\\"{x:1622,y:931,t:1527614084160};\\\", \\\"{x:1622,y:932,t:1527614084177};\\\", \\\"{x:1622,y:934,t:1527614084193};\\\", \\\"{x:1622,y:935,t:1527614084210};\\\", \\\"{x:1622,y:936,t:1527614084233};\\\", \\\"{x:1622,y:938,t:1527614084249};\\\", \\\"{x:1622,y:939,t:1527614084273};\\\", \\\"{x:1622,y:940,t:1527614084281};\\\", \\\"{x:1622,y:941,t:1527614084294};\\\", \\\"{x:1622,y:942,t:1527614084311};\\\", \\\"{x:1622,y:943,t:1527614084327};\\\", \\\"{x:1622,y:944,t:1527614084344};\\\", \\\"{x:1622,y:947,t:1527614084361};\\\", \\\"{x:1622,y:948,t:1527614084376};\\\", \\\"{x:1622,y:950,t:1527614084393};\\\", \\\"{x:1622,y:951,t:1527614084411};\\\", \\\"{x:1622,y:953,t:1527614084427};\\\", \\\"{x:1622,y:955,t:1527614084443};\\\", \\\"{x:1622,y:957,t:1527614084460};\\\", \\\"{x:1622,y:958,t:1527614084477};\\\", \\\"{x:1622,y:959,t:1527614084493};\\\", \\\"{x:1621,y:961,t:1527614084510};\\\", \\\"{x:1621,y:962,t:1527614084527};\\\", \\\"{x:1620,y:963,t:1527614084544};\\\", \\\"{x:1620,y:964,t:1527614084561};\\\", \\\"{x:1619,y:964,t:1527614084809};\\\", \\\"{x:1618,y:964,t:1527614084825};\\\", \\\"{x:1617,y:964,t:1527614084833};\\\", \\\"{x:1615,y:964,t:1527614084843};\\\", \\\"{x:1614,y:964,t:1527614084861};\\\", \\\"{x:1613,y:964,t:1527614084877};\\\", \\\"{x:1612,y:964,t:1527614084893};\\\", \\\"{x:1611,y:964,t:1527614084910};\\\", \\\"{x:1610,y:964,t:1527614084928};\\\", \\\"{x:1609,y:963,t:1527614084945};\\\", \\\"{x:1608,y:963,t:1527614085033};\\\", \\\"{x:1607,y:962,t:1527614085044};\\\", \\\"{x:1606,y:962,t:1527614085106};\\\", \\\"{x:1605,y:962,t:1527614085129};\\\", \\\"{x:1604,y:962,t:1527614085145};\\\", \\\"{x:1603,y:961,t:1527614085160};\\\", \\\"{x:1602,y:960,t:1527614085194};\\\", \\\"{x:1601,y:960,t:1527614085209};\\\", \\\"{x:1600,y:959,t:1527614085217};\\\", \\\"{x:1599,y:959,t:1527614085233};\\\", \\\"{x:1597,y:959,t:1527614085244};\\\", \\\"{x:1594,y:956,t:1527614085261};\\\", \\\"{x:1575,y:945,t:1527614085277};\\\", \\\"{x:1544,y:933,t:1527614085295};\\\", \\\"{x:1492,y:911,t:1527614085311};\\\", \\\"{x:1430,y:893,t:1527614085327};\\\", \\\"{x:1358,y:873,t:1527614085345};\\\", \\\"{x:1296,y:850,t:1527614085361};\\\", \\\"{x:1204,y:816,t:1527614085378};\\\", \\\"{x:1160,y:796,t:1527614085394};\\\", \\\"{x:1095,y:773,t:1527614085410};\\\", \\\"{x:1034,y:756,t:1527614085428};\\\", \\\"{x:1001,y:747,t:1527614085445};\\\", \\\"{x:979,y:738,t:1527614085461};\\\", \\\"{x:968,y:732,t:1527614085477};\\\", \\\"{x:959,y:724,t:1527614085495};\\\", \\\"{x:952,y:713,t:1527614085511};\\\", \\\"{x:945,y:704,t:1527614085528};\\\", \\\"{x:939,y:698,t:1527614085544};\\\", \\\"{x:920,y:685,t:1527614085561};\\\", \\\"{x:900,y:677,t:1527614085578};\\\", \\\"{x:881,y:667,t:1527614085595};\\\", \\\"{x:852,y:654,t:1527614085612};\\\", \\\"{x:811,y:632,t:1527614085628};\\\", \\\"{x:763,y:606,t:1527614085646};\\\", \\\"{x:720,y:581,t:1527614085663};\\\", \\\"{x:692,y:565,t:1527614085679};\\\", \\\"{x:676,y:555,t:1527614085694};\\\", \\\"{x:663,y:547,t:1527614085711};\\\", \\\"{x:655,y:539,t:1527614085728};\\\", \\\"{x:644,y:531,t:1527614085746};\\\", \\\"{x:626,y:522,t:1527614085762};\\\", \\\"{x:610,y:512,t:1527614085778};\\\", \\\"{x:600,y:506,t:1527614085794};\\\", \\\"{x:597,y:504,t:1527614085812};\\\", \\\"{x:594,y:501,t:1527614085828};\\\", \\\"{x:593,y:500,t:1527614085844};\\\", \\\"{x:593,y:499,t:1527614085862};\\\", \\\"{x:592,y:498,t:1527614085878};\\\", \\\"{x:592,y:497,t:1527614085895};\\\", \\\"{x:592,y:496,t:1527614085913};\\\", \\\"{x:592,y:495,t:1527614085930};\\\", \\\"{x:592,y:494,t:1527614085945};\\\", \\\"{x:592,y:490,t:1527614085961};\\\", \\\"{x:592,y:487,t:1527614085978};\\\", \\\"{x:592,y:486,t:1527614086025};\\\", \\\"{x:597,y:486,t:1527614086353};\\\", \\\"{x:609,y:486,t:1527614086363};\\\", \\\"{x:638,y:486,t:1527614086379};\\\", \\\"{x:680,y:485,t:1527614086397};\\\", \\\"{x:723,y:479,t:1527614086412};\\\", \\\"{x:744,y:476,t:1527614086429};\\\", \\\"{x:756,y:473,t:1527614086446};\\\", \\\"{x:757,y:472,t:1527614086462};\\\", \\\"{x:758,y:472,t:1527614086478};\\\", \\\"{x:760,y:472,t:1527614086633};\\\", \\\"{x:766,y:473,t:1527614086646};\\\", \\\"{x:777,y:477,t:1527614086662};\\\", \\\"{x:783,y:479,t:1527614086679};\\\", \\\"{x:788,y:480,t:1527614086695};\\\", \\\"{x:790,y:481,t:1527614086712};\\\", \\\"{x:791,y:481,t:1527614086849};\\\", \\\"{x:792,y:481,t:1527614086861};\\\", \\\"{x:793,y:481,t:1527614086878};\\\", \\\"{x:795,y:481,t:1527614086896};\\\", \\\"{x:807,y:481,t:1527614086913};\\\", \\\"{x:822,y:481,t:1527614086929};\\\", \\\"{x:840,y:481,t:1527614086946};\\\", \\\"{x:843,y:483,t:1527614086963};\\\", \\\"{x:844,y:483,t:1527614100588};\\\", \\\"{x:808,y:503,t:1527614100606};\\\", \\\"{x:724,y:532,t:1527614100622};\\\", \\\"{x:647,y:550,t:1527614100639};\\\", \\\"{x:555,y:558,t:1527614100660};\\\", \\\"{x:515,y:561,t:1527614100676};\\\", \\\"{x:486,y:561,t:1527614100694};\\\", \\\"{x:462,y:561,t:1527614100711};\\\", \\\"{x:442,y:553,t:1527614100726};\\\", \\\"{x:417,y:547,t:1527614100744};\\\", \\\"{x:389,y:541,t:1527614100761};\\\", \\\"{x:366,y:540,t:1527614100778};\\\", \\\"{x:340,y:539,t:1527614100793};\\\", \\\"{x:325,y:535,t:1527614100811};\\\", \\\"{x:316,y:534,t:1527614100827};\\\", \\\"{x:310,y:531,t:1527614100844};\\\", \\\"{x:304,y:527,t:1527614100860};\\\", \\\"{x:303,y:526,t:1527614100892};\\\", \\\"{x:302,y:524,t:1527614100900};\\\", \\\"{x:300,y:521,t:1527614100916};\\\", \\\"{x:300,y:518,t:1527614100927};\\\", \\\"{x:300,y:512,t:1527614100943};\\\", \\\"{x:301,y:506,t:1527614100961};\\\", \\\"{x:320,y:498,t:1527614100978};\\\", \\\"{x:359,y:488,t:1527614100994};\\\", \\\"{x:423,y:479,t:1527614101010};\\\", \\\"{x:494,y:474,t:1527614101027};\\\", \\\"{x:540,y:471,t:1527614101044};\\\", \\\"{x:559,y:469,t:1527614101060};\\\", \\\"{x:562,y:469,t:1527614101077};\\\", \\\"{x:564,y:469,t:1527614101108};\\\", \\\"{x:565,y:469,t:1527614101116};\\\", \\\"{x:566,y:469,t:1527614101128};\\\", \\\"{x:574,y:470,t:1527614101144};\\\", \\\"{x:589,y:470,t:1527614101161};\\\", \\\"{x:597,y:470,t:1527614101177};\\\", \\\"{x:610,y:470,t:1527614101193};\\\", \\\"{x:612,y:470,t:1527614101211};\\\", \\\"{x:613,y:471,t:1527614101252};\\\", \\\"{x:613,y:474,t:1527614101308};\\\", \\\"{x:613,y:475,t:1527614101316};\\\", \\\"{x:615,y:478,t:1527614101327};\\\", \\\"{x:617,y:482,t:1527614101344};\\\", \\\"{x:619,y:485,t:1527614101361};\\\", \\\"{x:621,y:487,t:1527614101377};\\\", \\\"{x:621,y:489,t:1527614101395};\\\", \\\"{x:621,y:492,t:1527614101410};\\\", \\\"{x:623,y:496,t:1527614101428};\\\", \\\"{x:623,y:501,t:1527614101444};\\\", \\\"{x:623,y:503,t:1527614101461};\\\", \\\"{x:624,y:505,t:1527614101478};\\\", \\\"{x:624,y:508,t:1527614101495};\\\", \\\"{x:624,y:509,t:1527614101511};\\\", \\\"{x:624,y:511,t:1527614101527};\\\", \\\"{x:624,y:513,t:1527614101545};\\\", \\\"{x:624,y:516,t:1527614101561};\\\", \\\"{x:621,y:524,t:1527614101578};\\\", \\\"{x:619,y:529,t:1527614101595};\\\", \\\"{x:615,y:534,t:1527614101611};\\\", \\\"{x:615,y:537,t:1527614101628};\\\", \\\"{x:612,y:542,t:1527614101644};\\\", \\\"{x:611,y:543,t:1527614101662};\\\", \\\"{x:610,y:546,t:1527614101677};\\\", \\\"{x:610,y:548,t:1527614101695};\\\", \\\"{x:608,y:553,t:1527614101712};\\\", \\\"{x:608,y:554,t:1527614101727};\\\", \\\"{x:608,y:556,t:1527614101745};\\\", \\\"{x:606,y:558,t:1527614101761};\\\", \\\"{x:606,y:560,t:1527614102172};\\\", \\\"{x:604,y:565,t:1527614102180};\\\", \\\"{x:601,y:571,t:1527614102195};\\\", \\\"{x:596,y:590,t:1527614102212};\\\", \\\"{x:582,y:617,t:1527614102229};\\\", \\\"{x:574,y:628,t:1527614102245};\\\", \\\"{x:570,y:635,t:1527614102262};\\\", \\\"{x:567,y:642,t:1527614102279};\\\", \\\"{x:565,y:645,t:1527614102294};\\\", \\\"{x:563,y:649,t:1527614102311};\\\", \\\"{x:562,y:651,t:1527614102328};\\\", \\\"{x:561,y:652,t:1527614102344};\\\", \\\"{x:559,y:655,t:1527614102361};\\\", \\\"{x:557,y:657,t:1527614102378};\\\", \\\"{x:555,y:660,t:1527614102394};\\\", \\\"{x:552,y:663,t:1527614102412};\\\", \\\"{x:543,y:672,t:1527614102428};\\\", \\\"{x:526,y:685,t:1527614102445};\\\", \\\"{x:511,y:699,t:1527614102462};\\\", \\\"{x:495,y:710,t:1527614102479};\\\", \\\"{x:482,y:719,t:1527614102494};\\\", \\\"{x:474,y:724,t:1527614102511};\\\", \\\"{x:471,y:725,t:1527614102529};\\\" ] }, { \\\"rt\\\": 35374, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 531960, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"K7JVY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"B\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-05 PM-04 PM-M \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:481,y:721,t:1527614115940};\\\", \\\"{x:565,y:708,t:1527614115959};\\\", \\\"{x:615,y:708,t:1527614115971};\\\", \\\"{x:754,y:709,t:1527614115988};\\\", \\\"{x:809,y:706,t:1527614116007};\\\", \\\"{x:833,y:696,t:1527614116024};\\\", \\\"{x:842,y:692,t:1527614116039};\\\", \\\"{x:858,y:685,t:1527614116057};\\\", \\\"{x:872,y:680,t:1527614116073};\\\", \\\"{x:886,y:674,t:1527614116090};\\\", \\\"{x:895,y:670,t:1527614116106};\\\", \\\"{x:899,y:669,t:1527614116123};\\\", \\\"{x:902,y:666,t:1527614116139};\\\", \\\"{x:899,y:668,t:1527614117093};\\\", \\\"{x:896,y:670,t:1527614117108};\\\", \\\"{x:896,y:671,t:1527614117124};\\\", \\\"{x:896,y:673,t:1527614117156};\\\", \\\"{x:897,y:673,t:1527614117252};\\\", \\\"{x:902,y:673,t:1527614117260};\\\", \\\"{x:904,y:675,t:1527614117274};\\\", \\\"{x:912,y:678,t:1527614117290};\\\", \\\"{x:913,y:679,t:1527614117307};\\\", \\\"{x:917,y:682,t:1527614117325};\\\", \\\"{x:917,y:684,t:1527614117341};\\\", \\\"{x:917,y:687,t:1527614117358};\\\", \\\"{x:918,y:687,t:1527614117644};\\\", \\\"{x:919,y:687,t:1527614117660};\\\", \\\"{x:922,y:687,t:1527614117716};\\\", \\\"{x:939,y:688,t:1527614117724};\\\", \\\"{x:1020,y:701,t:1527614117742};\\\", \\\"{x:1147,y:713,t:1527614117757};\\\", \\\"{x:1293,y:733,t:1527614117775};\\\", \\\"{x:1459,y:759,t:1527614117791};\\\", \\\"{x:1631,y:786,t:1527614117807};\\\", \\\"{x:1756,y:803,t:1527614117824};\\\", \\\"{x:1851,y:818,t:1527614117842};\\\", \\\"{x:1894,y:826,t:1527614117857};\\\", \\\"{x:1902,y:830,t:1527614117874};\\\", \\\"{x:1903,y:830,t:1527614117891};\\\", \\\"{x:1903,y:835,t:1527614117907};\\\", \\\"{x:1894,y:864,t:1527614117925};\\\", \\\"{x:1871,y:889,t:1527614117942};\\\", \\\"{x:1851,y:904,t:1527614117958};\\\", \\\"{x:1818,y:920,t:1527614117975};\\\", \\\"{x:1785,y:933,t:1527614117991};\\\", \\\"{x:1755,y:941,t:1527614118009};\\\", \\\"{x:1727,y:950,t:1527614118025};\\\", \\\"{x:1706,y:955,t:1527614118041};\\\", \\\"{x:1690,y:956,t:1527614118058};\\\", \\\"{x:1677,y:957,t:1527614118075};\\\", \\\"{x:1662,y:957,t:1527614118092};\\\", \\\"{x:1633,y:957,t:1527614118108};\\\", \\\"{x:1614,y:954,t:1527614118125};\\\", \\\"{x:1586,y:946,t:1527614118142};\\\", \\\"{x:1546,y:934,t:1527614118158};\\\", \\\"{x:1507,y:922,t:1527614118174};\\\", \\\"{x:1478,y:914,t:1527614118191};\\\", \\\"{x:1451,y:906,t:1527614118209};\\\", \\\"{x:1423,y:894,t:1527614118224};\\\", \\\"{x:1408,y:883,t:1527614118242};\\\", \\\"{x:1396,y:875,t:1527614118258};\\\", \\\"{x:1394,y:874,t:1527614118275};\\\", \\\"{x:1392,y:873,t:1527614118291};\\\", \\\"{x:1391,y:869,t:1527614118308};\\\", \\\"{x:1388,y:866,t:1527614118324};\\\", \\\"{x:1384,y:861,t:1527614118342};\\\", \\\"{x:1378,y:855,t:1527614118359};\\\", \\\"{x:1361,y:844,t:1527614118375};\\\", \\\"{x:1331,y:827,t:1527614118391};\\\", \\\"{x:1284,y:805,t:1527614118408};\\\", \\\"{x:1227,y:785,t:1527614118426};\\\", \\\"{x:1156,y:758,t:1527614118441};\\\", \\\"{x:1094,y:724,t:1527614118459};\\\", \\\"{x:1036,y:700,t:1527614118475};\\\", \\\"{x:975,y:683,t:1527614118491};\\\", \\\"{x:912,y:669,t:1527614118508};\\\", \\\"{x:887,y:663,t:1527614118525};\\\", \\\"{x:868,y:660,t:1527614118541};\\\", \\\"{x:855,y:658,t:1527614118558};\\\", \\\"{x:849,y:657,t:1527614118576};\\\", \\\"{x:844,y:657,t:1527614118592};\\\", \\\"{x:842,y:657,t:1527614118608};\\\", \\\"{x:837,y:657,t:1527614118625};\\\", \\\"{x:831,y:657,t:1527614118641};\\\", \\\"{x:818,y:657,t:1527614118659};\\\", \\\"{x:793,y:657,t:1527614118675};\\\", \\\"{x:768,y:657,t:1527614118691};\\\", \\\"{x:724,y:655,t:1527614118708};\\\", \\\"{x:698,y:653,t:1527614118726};\\\", \\\"{x:676,y:653,t:1527614118741};\\\", \\\"{x:659,y:653,t:1527614118758};\\\", \\\"{x:652,y:653,t:1527614118776};\\\", \\\"{x:644,y:653,t:1527614118793};\\\", \\\"{x:641,y:653,t:1527614118808};\\\", \\\"{x:637,y:653,t:1527614118826};\\\", \\\"{x:634,y:652,t:1527614118842};\\\", \\\"{x:628,y:649,t:1527614118858};\\\", \\\"{x:614,y:647,t:1527614118876};\\\", \\\"{x:583,y:639,t:1527614118891};\\\", \\\"{x:563,y:632,t:1527614118909};\\\", \\\"{x:535,y:625,t:1527614118925};\\\", \\\"{x:515,y:618,t:1527614118942};\\\", \\\"{x:492,y:610,t:1527614118958};\\\", \\\"{x:472,y:603,t:1527614118976};\\\", \\\"{x:449,y:589,t:1527614118993};\\\", \\\"{x:433,y:575,t:1527614119009};\\\", \\\"{x:419,y:565,t:1527614119026};\\\", \\\"{x:410,y:556,t:1527614119043};\\\", \\\"{x:406,y:552,t:1527614119058};\\\", \\\"{x:403,y:549,t:1527614119076};\\\", \\\"{x:401,y:547,t:1527614119092};\\\", \\\"{x:401,y:546,t:1527614119109};\\\", \\\"{x:400,y:545,t:1527614119125};\\\", \\\"{x:400,y:544,t:1527614119155};\\\", \\\"{x:399,y:543,t:1527614119180};\\\", \\\"{x:398,y:543,t:1527614119192};\\\", \\\"{x:398,y:542,t:1527614119210};\\\", \\\"{x:398,y:540,t:1527614119225};\\\", \\\"{x:397,y:536,t:1527614119242};\\\", \\\"{x:397,y:534,t:1527614119260};\\\", \\\"{x:395,y:523,t:1527614119276};\\\", \\\"{x:394,y:510,t:1527614119293};\\\", \\\"{x:394,y:504,t:1527614119310};\\\", \\\"{x:394,y:499,t:1527614119326};\\\", \\\"{x:396,y:495,t:1527614119344};\\\", \\\"{x:400,y:491,t:1527614119360};\\\", \\\"{x:405,y:487,t:1527614119375};\\\", \\\"{x:409,y:485,t:1527614119393};\\\", \\\"{x:414,y:481,t:1527614119409};\\\", \\\"{x:418,y:478,t:1527614119426};\\\", \\\"{x:424,y:475,t:1527614119443};\\\", \\\"{x:428,y:473,t:1527614119460};\\\", \\\"{x:430,y:472,t:1527614119475};\\\", \\\"{x:429,y:472,t:1527614119516};\\\", \\\"{x:425,y:475,t:1527614119526};\\\", \\\"{x:410,y:480,t:1527614119543};\\\", \\\"{x:387,y:482,t:1527614119560};\\\", \\\"{x:351,y:482,t:1527614119576};\\\", \\\"{x:309,y:482,t:1527614119593};\\\", \\\"{x:280,y:482,t:1527614119609};\\\", \\\"{x:257,y:482,t:1527614119627};\\\", \\\"{x:242,y:482,t:1527614119643};\\\", \\\"{x:236,y:483,t:1527614119659};\\\", \\\"{x:235,y:484,t:1527614119676};\\\", \\\"{x:234,y:484,t:1527614119693};\\\", \\\"{x:234,y:485,t:1527614119732};\\\", \\\"{x:233,y:486,t:1527614119742};\\\", \\\"{x:228,y:489,t:1527614119760};\\\", \\\"{x:218,y:493,t:1527614119777};\\\", \\\"{x:211,y:498,t:1527614119793};\\\", \\\"{x:205,y:500,t:1527614119810};\\\", \\\"{x:203,y:502,t:1527614119827};\\\", \\\"{x:200,y:503,t:1527614119843};\\\", \\\"{x:199,y:504,t:1527614119859};\\\", \\\"{x:195,y:506,t:1527614119876};\\\", \\\"{x:192,y:508,t:1527614119893};\\\", \\\"{x:190,y:509,t:1527614119910};\\\", \\\"{x:187,y:510,t:1527614119926};\\\", \\\"{x:185,y:511,t:1527614119942};\\\", \\\"{x:183,y:511,t:1527614119996};\\\", \\\"{x:182,y:511,t:1527614120020};\\\", \\\"{x:180,y:511,t:1527614120043};\\\", \\\"{x:179,y:512,t:1527614120059};\\\", \\\"{x:177,y:512,t:1527614120076};\\\", \\\"{x:176,y:512,t:1527614120093};\\\", \\\"{x:175,y:512,t:1527614120109};\\\", \\\"{x:174,y:512,t:1527614120126};\\\", \\\"{x:173,y:512,t:1527614120148};\\\", \\\"{x:172,y:512,t:1527614120160};\\\", \\\"{x:171,y:512,t:1527614120212};\\\", \\\"{x:170,y:513,t:1527614137292};\\\", \\\"{x:169,y:515,t:1527614137549};\\\", \\\"{x:168,y:515,t:1527614137557};\\\", \\\"{x:151,y:512,t:1527614137573};\\\", \\\"{x:126,y:504,t:1527614137590};\\\", \\\"{x:98,y:491,t:1527614137608};\\\", \\\"{x:77,y:480,t:1527614137625};\\\", \\\"{x:68,y:471,t:1527614137642};\\\", \\\"{x:66,y:461,t:1527614137658};\\\", \\\"{x:66,y:450,t:1527614137675};\\\", \\\"{x:76,y:434,t:1527614137691};\\\", \\\"{x:89,y:421,t:1527614137707};\\\", \\\"{x:121,y:400,t:1527614137724};\\\", \\\"{x:150,y:394,t:1527614137741};\\\", \\\"{x:179,y:391,t:1527614137757};\\\", \\\"{x:219,y:391,t:1527614137775};\\\", \\\"{x:253,y:397,t:1527614137790};\\\", \\\"{x:277,y:411,t:1527614137807};\\\", \\\"{x:302,y:433,t:1527614137825};\\\", \\\"{x:328,y:460,t:1527614137840};\\\", \\\"{x:356,y:499,t:1527614137857};\\\", \\\"{x:382,y:547,t:1527614137875};\\\", \\\"{x:405,y:586,t:1527614137891};\\\", \\\"{x:434,y:630,t:1527614137909};\\\", \\\"{x:439,y:657,t:1527614137925};\\\", \\\"{x:441,y:670,t:1527614137942};\\\", \\\"{x:443,y:684,t:1527614137958};\\\", \\\"{x:443,y:691,t:1527614137974};\\\", \\\"{x:443,y:694,t:1527614137992};\\\", \\\"{x:443,y:698,t:1527614138008};\\\", \\\"{x:443,y:706,t:1527614138025};\\\", \\\"{x:443,y:713,t:1527614138041};\\\", \\\"{x:443,y:717,t:1527614138058};\\\", \\\"{x:445,y:721,t:1527614138075};\\\", \\\"{x:452,y:733,t:1527614138091};\\\", \\\"{x:463,y:743,t:1527614138108};\\\", \\\"{x:475,y:750,t:1527614138125};\\\", \\\"{x:492,y:750,t:1527614138142};\\\", \\\"{x:507,y:750,t:1527614138157};\\\", \\\"{x:523,y:750,t:1527614138174};\\\", \\\"{x:540,y:750,t:1527614138192};\\\", \\\"{x:552,y:750,t:1527614138207};\\\", \\\"{x:556,y:750,t:1527614138224};\\\", \\\"{x:557,y:749,t:1527614138241};\\\", \\\"{x:558,y:749,t:1527614138340};\\\", \\\"{x:559,y:747,t:1527614138347};\\\", \\\"{x:559,y:744,t:1527614138364};\\\", \\\"{x:559,y:743,t:1527614138375};\\\", \\\"{x:556,y:737,t:1527614138392};\\\", \\\"{x:551,y:733,t:1527614138408};\\\", \\\"{x:548,y:731,t:1527614138424};\\\", \\\"{x:545,y:728,t:1527614138442};\\\", \\\"{x:543,y:727,t:1527614138459};\\\", \\\"{x:541,y:726,t:1527614138475};\\\", \\\"{x:540,y:725,t:1527614138491};\\\", \\\"{x:539,y:724,t:1527614138508};\\\", \\\"{x:538,y:724,t:1527614138524};\\\", \\\"{x:538,y:723,t:1527614138548};\\\", \\\"{x:536,y:723,t:1527614138572};\\\", \\\"{x:535,y:723,t:1527614138580};\\\", \\\"{x:534,y:722,t:1527614138592};\\\", \\\"{x:533,y:721,t:1527614138612};\\\", \\\"{x:532,y:720,t:1527614138636};\\\" ] }, { \\\"rt\\\": 37299, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 570458, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"K7JVY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2, \\\"explicit\\\": 1, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YInside\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-04 PM-03 PM-B \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:532,y:718,t:1527614144204};\\\", \\\"{x:529,y:694,t:1527614144215};\\\", \\\"{x:529,y:641,t:1527614144232};\\\", \\\"{x:529,y:563,t:1527614144249};\\\", \\\"{x:536,y:489,t:1527614144263};\\\", \\\"{x:555,y:401,t:1527614144280};\\\", \\\"{x:592,y:328,t:1527614144297};\\\", \\\"{x:629,y:268,t:1527614144313};\\\", \\\"{x:674,y:213,t:1527614144330};\\\", \\\"{x:712,y:167,t:1527614144347};\\\", \\\"{x:762,y:120,t:1527614144362};\\\", \\\"{x:836,y:21,t:1527614144380};\\\", \\\"{x:1226,y:17,t:1527614145188};\\\", \\\"{x:1236,y:26,t:1527614145197};\\\", \\\"{x:1259,y:50,t:1527614145214};\\\", \\\"{x:1281,y:77,t:1527614145229};\\\", \\\"{x:1306,y:123,t:1527614145247};\\\", \\\"{x:1351,y:192,t:1527614145264};\\\", \\\"{x:1405,y:265,t:1527614145280};\\\", \\\"{x:1457,y:341,t:1527614145297};\\\", \\\"{x:1500,y:390,t:1527614145314};\\\", \\\"{x:1571,y:452,t:1527614145330};\\\", \\\"{x:1634,y:504,t:1527614145347};\\\", \\\"{x:1700,y:569,t:1527614145364};\\\", \\\"{x:1727,y:602,t:1527614145380};\\\", \\\"{x:1740,y:613,t:1527614145397};\\\", \\\"{x:1754,y:626,t:1527614145414};\\\", \\\"{x:1760,y:635,t:1527614145431};\\\", \\\"{x:1768,y:647,t:1527614145447};\\\", \\\"{x:1774,y:667,t:1527614145464};\\\", \\\"{x:1777,y:689,t:1527614145480};\\\", \\\"{x:1780,y:719,t:1527614145497};\\\", \\\"{x:1778,y:749,t:1527614145514};\\\", \\\"{x:1767,y:772,t:1527614145531};\\\", \\\"{x:1760,y:788,t:1527614145547};\\\", \\\"{x:1734,y:837,t:1527614145564};\\\", \\\"{x:1709,y:865,t:1527614145581};\\\", \\\"{x:1688,y:885,t:1527614145596};\\\", \\\"{x:1668,y:900,t:1527614145614};\\\", \\\"{x:1647,y:920,t:1527614145631};\\\", \\\"{x:1634,y:934,t:1527614145647};\\\", \\\"{x:1620,y:942,t:1527614145664};\\\", \\\"{x:1604,y:950,t:1527614145680};\\\", \\\"{x:1590,y:956,t:1527614145697};\\\", \\\"{x:1578,y:958,t:1527614145714};\\\", \\\"{x:1572,y:958,t:1527614145731};\\\", \\\"{x:1568,y:958,t:1527614145747};\\\", \\\"{x:1565,y:958,t:1527614145764};\\\", \\\"{x:1557,y:960,t:1527614145781};\\\", \\\"{x:1556,y:960,t:1527614145797};\\\", \\\"{x:1555,y:956,t:1527614145835};\\\", \\\"{x:1554,y:953,t:1527614145846};\\\", \\\"{x:1547,y:939,t:1527614145864};\\\", \\\"{x:1539,y:931,t:1527614145881};\\\", \\\"{x:1536,y:929,t:1527614145897};\\\", \\\"{x:1533,y:927,t:1527614145914};\\\", \\\"{x:1532,y:927,t:1527614145931};\\\", \\\"{x:1531,y:927,t:1527614145948};\\\", \\\"{x:1528,y:927,t:1527614145964};\\\", \\\"{x:1524,y:927,t:1527614145981};\\\", \\\"{x:1510,y:931,t:1527614145997};\\\", \\\"{x:1493,y:936,t:1527614146014};\\\", \\\"{x:1477,y:941,t:1527614146031};\\\", \\\"{x:1467,y:944,t:1527614146048};\\\", \\\"{x:1461,y:946,t:1527614146063};\\\", \\\"{x:1460,y:946,t:1527614146080};\\\", \\\"{x:1461,y:946,t:1527614146316};\\\", \\\"{x:1462,y:946,t:1527614146340};\\\", \\\"{x:1463,y:945,t:1527614146348};\\\", \\\"{x:1465,y:945,t:1527614146380};\\\", \\\"{x:1466,y:945,t:1527614146388};\\\", \\\"{x:1467,y:943,t:1527614146404};\\\", \\\"{x:1467,y:938,t:1527614146414};\\\", \\\"{x:1467,y:930,t:1527614146431};\\\", \\\"{x:1469,y:917,t:1527614146448};\\\", \\\"{x:1471,y:899,t:1527614146463};\\\", \\\"{x:1473,y:886,t:1527614146481};\\\", \\\"{x:1476,y:879,t:1527614146498};\\\", \\\"{x:1476,y:876,t:1527614146513};\\\", \\\"{x:1476,y:875,t:1527614146531};\\\", \\\"{x:1477,y:874,t:1527614146612};\\\", \\\"{x:1478,y:873,t:1527614146627};\\\", \\\"{x:1478,y:871,t:1527614146644};\\\", \\\"{x:1479,y:869,t:1527614146652};\\\", \\\"{x:1479,y:868,t:1527614146664};\\\", \\\"{x:1480,y:864,t:1527614146681};\\\", \\\"{x:1480,y:861,t:1527614146698};\\\", \\\"{x:1481,y:859,t:1527614146714};\\\", \\\"{x:1481,y:858,t:1527614146732};\\\", \\\"{x:1481,y:855,t:1527614146748};\\\", \\\"{x:1481,y:854,t:1527614146764};\\\", \\\"{x:1481,y:852,t:1527614146781};\\\", \\\"{x:1481,y:851,t:1527614146829};\\\", \\\"{x:1481,y:849,t:1527614146861};\\\", \\\"{x:1481,y:848,t:1527614146885};\\\", \\\"{x:1481,y:847,t:1527614146909};\\\", \\\"{x:1481,y:845,t:1527614146917};\\\", \\\"{x:1481,y:844,t:1527614146940};\\\", \\\"{x:1481,y:843,t:1527614146947};\\\", \\\"{x:1481,y:840,t:1527614146965};\\\", \\\"{x:1481,y:839,t:1527614146988};\\\", \\\"{x:1481,y:837,t:1527614146998};\\\", \\\"{x:1481,y:836,t:1527614147020};\\\", \\\"{x:1481,y:835,t:1527614147035};\\\", \\\"{x:1481,y:834,t:1527614147188};\\\", \\\"{x:1481,y:832,t:1527614147244};\\\", \\\"{x:1481,y:830,t:1527614147251};\\\", \\\"{x:1481,y:829,t:1527614147268};\\\", \\\"{x:1481,y:828,t:1527614147281};\\\", \\\"{x:1481,y:826,t:1527614147298};\\\", \\\"{x:1481,y:824,t:1527614147315};\\\", \\\"{x:1481,y:822,t:1527614147331};\\\", \\\"{x:1480,y:821,t:1527614147348};\\\", \\\"{x:1480,y:820,t:1527614147365};\\\", \\\"{x:1480,y:817,t:1527614150055};\\\", \\\"{x:1473,y:809,t:1527614150069};\\\", \\\"{x:1459,y:797,t:1527614150086};\\\", \\\"{x:1441,y:784,t:1527614150103};\\\", \\\"{x:1412,y:766,t:1527614150119};\\\", \\\"{x:1399,y:758,t:1527614150136};\\\", \\\"{x:1385,y:747,t:1527614150152};\\\", \\\"{x:1376,y:741,t:1527614150170};\\\", \\\"{x:1371,y:736,t:1527614150186};\\\", \\\"{x:1367,y:733,t:1527614150202};\\\", \\\"{x:1364,y:731,t:1527614150219};\\\", \\\"{x:1362,y:729,t:1527614150236};\\\", \\\"{x:1356,y:729,t:1527614150252};\\\", \\\"{x:1344,y:729,t:1527614150269};\\\", \\\"{x:1331,y:725,t:1527614150286};\\\", \\\"{x:1318,y:721,t:1527614150302};\\\", \\\"{x:1309,y:720,t:1527614150319};\\\", \\\"{x:1304,y:719,t:1527614150336};\\\", \\\"{x:1301,y:718,t:1527614150352};\\\", \\\"{x:1291,y:717,t:1527614150369};\\\", \\\"{x:1285,y:715,t:1527614150387};\\\", \\\"{x:1279,y:715,t:1527614150403};\\\", \\\"{x:1268,y:711,t:1527614150419};\\\", \\\"{x:1258,y:707,t:1527614150437};\\\", \\\"{x:1246,y:703,t:1527614150453};\\\", \\\"{x:1232,y:698,t:1527614150469};\\\", \\\"{x:1222,y:698,t:1527614150487};\\\", \\\"{x:1213,y:698,t:1527614150503};\\\", \\\"{x:1209,y:698,t:1527614150519};\\\", \\\"{x:1206,y:699,t:1527614150536};\\\", \\\"{x:1202,y:703,t:1527614150553};\\\", \\\"{x:1197,y:706,t:1527614150569};\\\", \\\"{x:1193,y:710,t:1527614150586};\\\", \\\"{x:1187,y:714,t:1527614150603};\\\", \\\"{x:1183,y:717,t:1527614150619};\\\", \\\"{x:1178,y:720,t:1527614150636};\\\", \\\"{x:1175,y:723,t:1527614150653};\\\", \\\"{x:1171,y:725,t:1527614150669};\\\", \\\"{x:1171,y:727,t:1527614150686};\\\", \\\"{x:1168,y:729,t:1527614150703};\\\", \\\"{x:1167,y:729,t:1527614151000};\\\", \\\"{x:1166,y:729,t:1527614161431};\\\", \\\"{x:1165,y:729,t:1527614161441};\\\", \\\"{x:1150,y:729,t:1527614161459};\\\", \\\"{x:1134,y:724,t:1527614161474};\\\", \\\"{x:1119,y:720,t:1527614161491};\\\", \\\"{x:1108,y:717,t:1527614161508};\\\", \\\"{x:1102,y:716,t:1527614161525};\\\", \\\"{x:1098,y:716,t:1527614161541};\\\", \\\"{x:1090,y:715,t:1527614161559};\\\", \\\"{x:1081,y:712,t:1527614161575};\\\", \\\"{x:1069,y:710,t:1527614161592};\\\", \\\"{x:1058,y:707,t:1527614161609};\\\", \\\"{x:1045,y:703,t:1527614161625};\\\", \\\"{x:1024,y:698,t:1527614161641};\\\", \\\"{x:997,y:692,t:1527614161659};\\\", \\\"{x:968,y:686,t:1527614161674};\\\", \\\"{x:936,y:683,t:1527614161692};\\\", \\\"{x:890,y:675,t:1527614161709};\\\", \\\"{x:856,y:670,t:1527614161724};\\\", \\\"{x:825,y:665,t:1527614161741};\\\", \\\"{x:779,y:659,t:1527614161758};\\\", \\\"{x:748,y:654,t:1527614161775};\\\", \\\"{x:719,y:650,t:1527614161792};\\\", \\\"{x:692,y:646,t:1527614161808};\\\", \\\"{x:654,y:638,t:1527614161825};\\\", \\\"{x:628,y:630,t:1527614161842};\\\", \\\"{x:602,y:624,t:1527614161859};\\\", \\\"{x:580,y:617,t:1527614161875};\\\", \\\"{x:564,y:612,t:1527614161891};\\\", \\\"{x:548,y:608,t:1527614161907};\\\", \\\"{x:541,y:603,t:1527614161924};\\\", \\\"{x:536,y:599,t:1527614161941};\\\", \\\"{x:531,y:594,t:1527614161957};\\\", \\\"{x:520,y:578,t:1527614161975};\\\", \\\"{x:512,y:563,t:1527614161991};\\\", \\\"{x:508,y:551,t:1527614162016};\\\", \\\"{x:508,y:550,t:1527614162030};\\\", \\\"{x:506,y:547,t:1527614162048};\\\", \\\"{x:504,y:546,t:1527614162065};\\\", \\\"{x:503,y:545,t:1527614162081};\\\", \\\"{x:502,y:545,t:1527614162098};\\\", \\\"{x:502,y:544,t:1527614162318};\\\", \\\"{x:502,y:542,t:1527614162391};\\\", \\\"{x:502,y:540,t:1527614162406};\\\", \\\"{x:502,y:538,t:1527614162414};\\\", \\\"{x:502,y:534,t:1527614162447};\\\", \\\"{x:502,y:533,t:1527614162454};\\\", \\\"{x:502,y:532,t:1527614162470};\\\", \\\"{x:502,y:530,t:1527614162480};\\\", \\\"{x:502,y:528,t:1527614162497};\\\", \\\"{x:501,y:527,t:1527614162527};\\\", \\\"{x:501,y:526,t:1527614162535};\\\", \\\"{x:501,y:525,t:1527614162548};\\\", \\\"{x:501,y:522,t:1527614162565};\\\", \\\"{x:502,y:520,t:1527614162581};\\\", \\\"{x:506,y:520,t:1527614162598};\\\", \\\"{x:510,y:519,t:1527614162615};\\\", \\\"{x:513,y:518,t:1527614162630};\\\", \\\"{x:527,y:517,t:1527614162648};\\\", \\\"{x:532,y:516,t:1527614162665};\\\", \\\"{x:537,y:514,t:1527614162681};\\\", \\\"{x:539,y:513,t:1527614162698};\\\", \\\"{x:544,y:512,t:1527614162714};\\\", \\\"{x:550,y:512,t:1527614162731};\\\", \\\"{x:552,y:512,t:1527614162748};\\\", \\\"{x:553,y:512,t:1527614162765};\\\", \\\"{x:558,y:510,t:1527614162782};\\\", \\\"{x:564,y:508,t:1527614162799};\\\", \\\"{x:574,y:508,t:1527614162815};\\\", \\\"{x:581,y:505,t:1527614162832};\\\", \\\"{x:586,y:505,t:1527614162848};\\\", \\\"{x:592,y:504,t:1527614162865};\\\", \\\"{x:593,y:504,t:1527614162882};\\\", \\\"{x:596,y:504,t:1527614162899};\\\", \\\"{x:597,y:504,t:1527614162914};\\\", \\\"{x:598,y:504,t:1527614162931};\\\", \\\"{x:599,y:504,t:1527614162951};\\\", \\\"{x:597,y:504,t:1527614163184};\\\", \\\"{x:592,y:506,t:1527614163199};\\\", \\\"{x:582,y:510,t:1527614163215};\\\", \\\"{x:576,y:514,t:1527614163232};\\\", \\\"{x:565,y:516,t:1527614163249};\\\", \\\"{x:566,y:516,t:1527614163327};\\\", \\\"{x:577,y:516,t:1527614163334};\\\", \\\"{x:598,y:516,t:1527614163349};\\\", \\\"{x:679,y:516,t:1527614163366};\\\", \\\"{x:733,y:512,t:1527614163382};\\\", \\\"{x:806,y:512,t:1527614163399};\\\", \\\"{x:829,y:512,t:1527614163415};\\\", \\\"{x:849,y:512,t:1527614163432};\\\", \\\"{x:855,y:512,t:1527614163448};\\\", \\\"{x:860,y:511,t:1527614163465};\\\", \\\"{x:865,y:511,t:1527614163481};\\\", \\\"{x:875,y:510,t:1527614163499};\\\", \\\"{x:889,y:508,t:1527614163517};\\\", \\\"{x:905,y:508,t:1527614163532};\\\", \\\"{x:914,y:507,t:1527614163548};\\\", \\\"{x:917,y:507,t:1527614163566};\\\", \\\"{x:917,y:506,t:1527614163581};\\\", \\\"{x:917,y:507,t:1527614163670};\\\", \\\"{x:916,y:507,t:1527614163682};\\\", \\\"{x:907,y:507,t:1527614163699};\\\", \\\"{x:900,y:507,t:1527614163716};\\\", \\\"{x:890,y:506,t:1527614163733};\\\", \\\"{x:874,y:505,t:1527614163748};\\\", \\\"{x:866,y:503,t:1527614163766};\\\", \\\"{x:859,y:501,t:1527614163782};\\\", \\\"{x:857,y:501,t:1527614163799};\\\", \\\"{x:855,y:500,t:1527614163816};\\\", \\\"{x:855,y:499,t:1527614163838};\\\", \\\"{x:853,y:499,t:1527614163855};\\\", \\\"{x:852,y:499,t:1527614163871};\\\", \\\"{x:850,y:498,t:1527614163882};\\\", \\\"{x:847,y:498,t:1527614163898};\\\", \\\"{x:844,y:496,t:1527614163916};\\\", \\\"{x:838,y:496,t:1527614163933};\\\", \\\"{x:835,y:495,t:1527614163948};\\\", \\\"{x:833,y:495,t:1527614163967};\\\", \\\"{x:832,y:494,t:1527614163983};\\\", \\\"{x:831,y:493,t:1527614164015};\\\", \\\"{x:830,y:493,t:1527614164023};\\\", \\\"{x:829,y:493,t:1527614164055};\\\", \\\"{x:828,y:501,t:1527614175535};\\\", \\\"{x:824,y:513,t:1527614175544};\\\", \\\"{x:816,y:539,t:1527614175561};\\\", \\\"{x:808,y:560,t:1527614175577};\\\", \\\"{x:805,y:569,t:1527614175587};\\\", \\\"{x:795,y:587,t:1527614175605};\\\", \\\"{x:791,y:597,t:1527614175622};\\\", \\\"{x:785,y:611,t:1527614175642};\\\", \\\"{x:781,y:620,t:1527614175658};\\\", \\\"{x:776,y:632,t:1527614175675};\\\", \\\"{x:767,y:648,t:1527614175692};\\\", \\\"{x:759,y:664,t:1527614175708};\\\", \\\"{x:751,y:679,t:1527614175725};\\\", \\\"{x:741,y:695,t:1527614175742};\\\", \\\"{x:727,y:720,t:1527614175758};\\\", \\\"{x:710,y:744,t:1527614175775};\\\", \\\"{x:697,y:754,t:1527614175792};\\\", \\\"{x:689,y:760,t:1527614175809};\\\", \\\"{x:679,y:763,t:1527614175825};\\\", \\\"{x:667,y:765,t:1527614175843};\\\", \\\"{x:658,y:765,t:1527614175859};\\\", \\\"{x:649,y:765,t:1527614175875};\\\", \\\"{x:630,y:762,t:1527614175892};\\\", \\\"{x:608,y:751,t:1527614175909};\\\", \\\"{x:581,y:736,t:1527614175926};\\\", \\\"{x:554,y:721,t:1527614175943};\\\", \\\"{x:523,y:698,t:1527614175959};\\\", \\\"{x:492,y:666,t:1527614175976};\\\", \\\"{x:481,y:647,t:1527614175993};\\\", \\\"{x:473,y:631,t:1527614176010};\\\", \\\"{x:469,y:622,t:1527614176026};\\\", \\\"{x:466,y:615,t:1527614176042};\\\", \\\"{x:470,y:606,t:1527614176059};\\\", \\\"{x:472,y:597,t:1527614176076};\\\", \\\"{x:480,y:594,t:1527614176092};\\\", \\\"{x:496,y:585,t:1527614176110};\\\", \\\"{x:502,y:578,t:1527614176127};\\\", \\\"{x:511,y:569,t:1527614176142};\\\", \\\"{x:523,y:558,t:1527614176160};\\\", \\\"{x:533,y:549,t:1527614176177};\\\", \\\"{x:545,y:543,t:1527614176193};\\\", \\\"{x:553,y:538,t:1527614176210};\\\", \\\"{x:561,y:533,t:1527614176225};\\\", \\\"{x:564,y:531,t:1527614176242};\\\", \\\"{x:568,y:528,t:1527614176259};\\\", \\\"{x:571,y:526,t:1527614176275};\\\", \\\"{x:575,y:523,t:1527614176292};\\\", \\\"{x:579,y:520,t:1527614176309};\\\", \\\"{x:584,y:515,t:1527614176326};\\\", \\\"{x:589,y:510,t:1527614176342};\\\", \\\"{x:592,y:506,t:1527614176360};\\\", \\\"{x:593,y:504,t:1527614176407};\\\", \\\"{x:594,y:504,t:1527614176431};\\\", \\\"{x:594,y:502,t:1527614176443};\\\", \\\"{x:596,y:500,t:1527614176459};\\\", \\\"{x:597,y:498,t:1527614176476};\\\", \\\"{x:598,y:497,t:1527614176494};\\\", \\\"{x:599,y:494,t:1527614176509};\\\", \\\"{x:603,y:492,t:1527614176527};\\\", \\\"{x:608,y:488,t:1527614176543};\\\", \\\"{x:608,y:487,t:1527614176559};\\\", \\\"{x:609,y:487,t:1527614176576};\\\", \\\"{x:609,y:490,t:1527614176838};\\\", \\\"{x:602,y:504,t:1527614176847};\\\", \\\"{x:595,y:527,t:1527614176860};\\\", \\\"{x:584,y:566,t:1527614176877};\\\", \\\"{x:577,y:589,t:1527614176894};\\\", \\\"{x:574,y:605,t:1527614176910};\\\", \\\"{x:573,y:614,t:1527614176927};\\\", \\\"{x:572,y:624,t:1527614176943};\\\", \\\"{x:571,y:629,t:1527614176960};\\\", \\\"{x:571,y:634,t:1527614176977};\\\", \\\"{x:569,y:639,t:1527614176994};\\\", \\\"{x:567,y:644,t:1527614177010};\\\", \\\"{x:563,y:649,t:1527614177026};\\\", \\\"{x:559,y:653,t:1527614177043};\\\", \\\"{x:554,y:658,t:1527614177060};\\\", \\\"{x:552,y:661,t:1527614177076};\\\", \\\"{x:550,y:663,t:1527614177093};\\\", \\\"{x:549,y:664,t:1527614177111};\\\", \\\"{x:546,y:665,t:1527614177126};\\\", \\\"{x:544,y:667,t:1527614177143};\\\", \\\"{x:542,y:668,t:1527614177160};\\\", \\\"{x:539,y:671,t:1527614177176};\\\", \\\"{x:535,y:675,t:1527614177193};\\\", \\\"{x:532,y:679,t:1527614177210};\\\", \\\"{x:527,y:686,t:1527614177227};\\\", \\\"{x:523,y:691,t:1527614177243};\\\", \\\"{x:523,y:693,t:1527614177260};\\\", \\\"{x:520,y:698,t:1527614177277};\\\", \\\"{x:519,y:700,t:1527614177294};\\\", \\\"{x:519,y:703,t:1527614177310};\\\", \\\"{x:520,y:704,t:1527614177328};\\\", \\\"{x:520,y:705,t:1527614177344};\\\", \\\"{x:520,y:707,t:1527614177583};\\\", \\\"{x:520,y:712,t:1527614177593};\\\", \\\"{x:519,y:718,t:1527614177611};\\\", \\\"{x:519,y:727,t:1527614177628};\\\", \\\"{x:518,y:730,t:1527614177643};\\\", \\\"{x:518,y:732,t:1527614177660};\\\", \\\"{x:516,y:734,t:1527614178374};\\\", \\\"{x:516,y:733,t:1527614178383};\\\", \\\"{x:516,y:729,t:1527614178395};\\\", \\\"{x:517,y:722,t:1527614178412};\\\", \\\"{x:517,y:718,t:1527614178427};\\\", \\\"{x:518,y:716,t:1527614178444};\\\", \\\"{x:518,y:714,t:1527614178462};\\\", \\\"{x:520,y:710,t:1527614178477};\\\", \\\"{x:523,y:705,t:1527614178494};\\\", \\\"{x:524,y:700,t:1527614178511};\\\", \\\"{x:530,y:693,t:1527614178527};\\\", \\\"{x:534,y:687,t:1527614178544};\\\", \\\"{x:541,y:679,t:1527614178561};\\\", \\\"{x:549,y:672,t:1527614178578};\\\", \\\"{x:552,y:668,t:1527614178594};\\\", \\\"{x:555,y:665,t:1527614178611};\\\", \\\"{x:559,y:660,t:1527614178629};\\\", \\\"{x:561,y:658,t:1527614178645};\\\", \\\"{x:562,y:655,t:1527614178661};\\\", \\\"{x:562,y:653,t:1527614178678};\\\", \\\"{x:564,y:652,t:1527614178694};\\\", \\\"{x:564,y:651,t:1527614178791};\\\", \\\"{x:566,y:646,t:1527614178798};\\\" ] }, { \\\"rt\\\": 24404, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 596049, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"K7JVY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"Look at dots above 12pm\\\\n\\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 6584, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"22\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"South Korea\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 603635, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"K7JVY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 30320, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"Other\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Fourth\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Natural Sciences\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 634964, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"K7JVY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\" }, { \\\"rt\\\": 25538, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 661823, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"K7JVY\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"oscar\\\", \\\"condition\\\": \\\"114\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"K7JVY\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"13.333333333333329\",\"x2\":\"766.6666666666667\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"46.66666666666666\",\"x2\":\"733.3333333333333\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"80\",\"x2\":\"700\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"113.33333333333331\",\"x2\":\"666.6666666666667\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"146.66666666666669\",\"x2\":\"633.3333333333333\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"180\",\"x2\":\"600\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"213.33333333333334\",\"x2\":\"566.6666666666667\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"246.66666666666663\",\"x2\":\"533.3333333333333\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"280\",\"x2\":\"500\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"313.33333333333337\",\"x2\":\"466.6666666666667\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"346.66666666666663\",\"x2\":\"433.3333333333333\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"grid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"380\",\"x2\":\"400\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 194, dom: 879, initialDom: 964",
  "javascriptErrors": []
}