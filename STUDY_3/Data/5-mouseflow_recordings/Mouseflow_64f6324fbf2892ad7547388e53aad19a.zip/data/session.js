var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "64f6324fbf2892ad7547388e53aad19a",
  "created": "2018-05-21T09:08:34.6910222-07:00",
  "lastActivity": "2018-05-21T09:09:01.6384047-07:00",
  "pageViews": [
    {
      "id": "052134198f7eea330dbb05612ee68212dc333626",
      "startTime": "2018-05-21T09:08:34.6910222-07:00",
      "endTime": "2018-05-21T09:09:01.6384047-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/7",
      "visitTime": 27059,
      "engagementTime": 26537,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 27059,
  "engagementTime": 26537,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "69.196.34.183",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.139",
  "os": "macOS",
  "osVersion": "10.12 Sierra",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1440x900",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=G72GB",
    "CONDITION=121",
    "TRI_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "b75ea27fedfae66264e895e4ce8bafea",
  "gdpr": false
}