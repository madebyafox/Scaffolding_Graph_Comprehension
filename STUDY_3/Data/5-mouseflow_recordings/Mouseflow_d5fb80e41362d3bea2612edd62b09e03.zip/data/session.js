var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "d5fb80e41362d3bea2612edd62b09e03",
  "created": "2018-05-22T10:10:45.7219564-07:00",
  "lastActivity": "2018-05-22T10:10:57.0829564-07:00",
  "pageViews": [
    {
      "id": "05224502898fbdf202584501896fc6a87bd698f2",
      "startTime": "2018-05-22T10:10:45.7219564-07:00",
      "endTime": "2018-05-22T10:10:57.0829564-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/3",
      "visitTime": 11361,
      "engagementTime": 11361,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 11361,
  "engagementTime": 11361,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.36",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=R06S6",
    "CONDITION=121"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "a96c150aec00cd1473d20ccb98c32d95",
  "gdpr": false
}