var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "a3bfd85678d8938192e4e1dc466bdc9d",
  "created": "2018-05-29T15:15:28.193367-07:00",
  "lastActivity": "2018-05-29T15:16:07.6776511-07:00",
  "pageViews": [
    {
      "id": "05292850544817ecb97a3bc66a6f7a39a52b6edf",
      "startTime": "2018-05-29T15:15:28.193367-07:00",
      "endTime": "2018-05-29T15:16:07.6776511-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/10",
      "visitTime": 39532,
      "engagementTime": 39333,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 39532,
  "engagementTime": 39333,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.34",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "67.0.3396.62",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=9PKA7",
    "CONDITION=114",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "e316c9565b3999a39aa1ef4ef0e1641e",
  "gdpr": false
}