var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "f7beb9affb1512c8b65146c5744537b1",
  "created": "2018-05-29T14:08:48.3858855-07:00",
  "lastActivity": "2018-05-29T14:09:08.6518855-07:00",
  "pageViews": [
    {
      "id": "0529492154b8d52fc73ad9b17da7ae76c2daeda9",
      "startTime": "2018-05-29T14:08:48.3858855-07:00",
      "endTime": "2018-05-29T14:09:08.6518855-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/10",
      "visitTime": 20266,
      "engagementTime": 16167,
      "scroll": 100.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 20266,
  "engagementTime": 16167,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "128.54.68.26",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.181",
  "os": "Windows",
  "osVersion": "7",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1920x1200",
  "tags": [
    "form-interact"
  ],
  "variables": [
    "SID=F92ER",
    "CONDITION=115",
    "ORTH_CORRECT=1"
  ],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "a8bd3905ca8539060f5cf24a6f6dd899",
  "gdpr": false
}