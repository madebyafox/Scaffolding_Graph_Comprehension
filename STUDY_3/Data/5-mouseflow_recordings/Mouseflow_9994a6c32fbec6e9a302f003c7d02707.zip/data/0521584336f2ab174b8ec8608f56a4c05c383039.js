var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["0521584336f2ab174b8ec8608f56a4c05c383039"] = {
  "startTime": "2018-05-21T16:56:58.9544867Z",
  "websitePageUrl": "/",
  "visitTime": 1018194,
  "engagementTime": 35161,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1353,
  "viewportHeight": 780,
  "tags": [
    "form-interact"
  ],
  "session": {
    "id": "9994a6c32fbec6e9a302f003c7d02707",
    "created": "2018-05-21T16:56:58.92901+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.139",
    "os": "macOS",
    "osVersion": "10.12 Sierra",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1440x900",
    "entryPage": "/",
    "tags": [
      "form-interact"
    ],
    "variables": [],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "1d004384f1069d02125653a0b6b0564a",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/9994a6c32fbec6e9a302f003c7d02707/play"
  },
  "events": [
    {
      "t": 104,
      "e": 104,
      "ty": 0,
      "x": 1353,
      "y": 780
    },
    {
      "t": 258,
      "e": 258,
      "ty": 14,
      "x": 0,
      "y": 798
    },
    {
      "t": 900,
      "e": 900,
      "ty": 2,
      "x": 365,
      "y": 373
    },
    {
      "t": 1002,
      "e": 1002,
      "ty": 2,
      "x": 405,
      "y": 411
    },
    {
      "t": 1004,
      "e": 1004,
      "ty": 41,
      "x": 17503,
      "y": 33832,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 1105,
      "e": 1105,
      "ty": 2,
      "x": 402,
      "y": 408
    },
    {
      "t": 1255,
      "e": 1255,
      "ty": 41,
      "x": 17339,
      "y": 33586,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 1600,
      "e": 1600,
      "ty": 2,
      "x": 408,
      "y": 399
    },
    {
      "t": 1700,
      "e": 1700,
      "ty": 2,
      "x": 458,
      "y": 364
    },
    {
      "t": 1750,
      "e": 1750,
      "ty": 41,
      "x": 20616,
      "y": 30064,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 1801,
      "e": 1801,
      "ty": 2,
      "x": 462,
      "y": 368
    },
    {
      "t": 1900,
      "e": 1900,
      "ty": 2,
      "x": 457,
      "y": 372
    },
    {
      "t": 2003,
      "e": 2003,
      "ty": 2,
      "x": 454,
      "y": 373
    },
    {
      "t": 2003,
      "e": 2003,
      "ty": 41,
      "x": 20179,
      "y": 30719,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 2337,
      "e": 2337,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 2751,
      "e": 2751,
      "ty": 41,
      "x": 21699,
      "y": 30162,
      "ta": "html > body"
    },
    {
      "t": 2800,
      "e": 2800,
      "ty": 2,
      "x": 575,
      "y": 162
    },
    {
      "t": 2816,
      "e": 2816,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 2905,
      "e": 2905,
      "ty": 2,
      "x": 670,
      "y": 40
    },
    {
      "t": 3005,
      "e": 3005,
      "ty": 41,
      "x": 32065,
      "y": 2688,
      "ta": "html > body"
    },
    {
      "t": 3442,
      "e": 3442,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 4100,
      "e": 4100,
      "ty": 2,
      "x": 739,
      "y": 238
    },
    {
      "t": 4205,
      "e": 4205,
      "ty": 2,
      "x": 739,
      "y": 293
    },
    {
      "t": 4256,
      "e": 4256,
      "ty": 41,
      "x": 36538,
      "y": 29076,
      "ta": "> div.masterdiv > div:[2] > div > p:[2]"
    },
    {
      "t": 4300,
      "e": 4300,
      "ty": 2,
      "x": 737,
      "y": 353
    },
    {
      "t": 4400,
      "e": 4400,
      "ty": 2,
      "x": 600,
      "y": 779
    },
    {
      "t": 4506,
      "e": 4506,
      "ty": 41,
      "x": 28674,
      "y": 64778,
      "ta": "> div.masterdiv"
    },
    {
      "t": 4738,
      "e": 4738,
      "ty": 1,
      "x": 0,
      "y": 16
    },
    {
      "t": 4843,
      "e": 4843,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 4884,
      "e": 4884,
      "ty": 41,
      "x": 27608,
      "y": 60913,
      "ta": "> div.masterdiv"
    },
    {
      "t": 4884,
      "e": 4884,
      "ty": 2,
      "x": 578,
      "y": 733
    },
    {
      "t": 4900,
      "e": 4900,
      "ty": 2,
      "x": 569,
      "y": 685
    },
    {
      "t": 5001,
      "e": 5001,
      "ty": 2,
      "x": 550,
      "y": 611
    },
    {
      "t": 5001,
      "e": 5001,
      "ty": 41,
      "x": 23460,
      "y": 38033,
      "ta": "> div.masterdiv > div:[2] > div > p:[3]"
    },
    {
      "t": 5417,
      "e": 5417,
      "ty": 2,
      "x": 460,
      "y": 646
    },
    {
      "t": 5417,
      "e": 5417,
      "ty": 39,
      "x": 0,
      "y": 223,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 5417,
      "e": 5417,
      "ty": 41,
      "x": 17233,
      "y": 58813,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 5500,
      "e": 5500,
      "ty": 2,
      "x": 281,
      "y": 633
    },
    {
      "t": 5500,
      "e": 5500,
      "ty": 41,
      "x": 4846,
      "y": 57448,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 5600,
      "e": 5600,
      "ty": 2,
      "x": 215,
      "y": 603
    },
    {
      "t": 5700,
      "e": 5700,
      "ty": 2,
      "x": 442,
      "y": 616
    },
    {
      "t": 5750,
      "e": 5750,
      "ty": 41,
      "x": 18962,
      "y": 55977,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 5800,
      "e": 5800,
      "ty": 2,
      "x": 492,
      "y": 613
    },
    {
      "t": 5900,
      "e": 5900,
      "ty": 2,
      "x": 524,
      "y": 596
    },
    {
      "t": 6000,
      "e": 6000,
      "ty": 2,
      "x": 542,
      "y": 594
    },
    {
      "t": 6000,
      "e": 6000,
      "ty": 41,
      "x": 44440,
      "y": 31129,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 6064,
      "e": 6064,
      "ty": 3,
      "x": 543,
      "y": 594,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 6101,
      "e": 6101,
      "ty": 2,
      "x": 543,
      "y": 594
    },
    {
      "t": 6136,
      "e": 6136,
      "ty": 4,
      "x": 47717,
      "y": 31129,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 6137,
      "e": 6137,
      "ty": 5,
      "x": 543,
      "y": 594,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 6137,
      "e": 6137,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 6148,
      "e": 6148,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox",
      "v": "on"
    },
    {
      "t": 6251,
      "e": 6251,
      "ty": 41,
      "x": 47717,
      "y": 31129,
      "ta": "> div.masterdiv > div:[2] > div > div > label > div"
    },
    {
      "t": 6400,
      "e": 6400,
      "ty": 2,
      "x": 628,
      "y": 694
    },
    {
      "t": 6410,
      "e": 6410,
      "ty": 6,
      "x": 656,
      "y": 715,
      "ta": "#start"
    },
    {
      "t": 6444,
      "e": 6444,
      "ty": 7,
      "x": 725,
      "y": 759,
      "ta": "#start"
    },
    {
      "t": 6500,
      "e": 6500,
      "ty": 2,
      "x": 757,
      "y": 780
    },
    {
      "t": 6501,
      "e": 6501,
      "ty": 41,
      "x": 36279,
      "y": 64862,
      "ta": "> div.masterdiv"
    },
    {
      "t": 6601,
      "e": 6601,
      "ty": 2,
      "x": 747,
      "y": 771
    },
    {
      "t": 6678,
      "e": 6678,
      "ty": 6,
      "x": 711,
      "y": 743,
      "ta": "#start"
    },
    {
      "t": 6700,
      "e": 6700,
      "ty": 2,
      "x": 709,
      "y": 742
    },
    {
      "t": 6750,
      "e": 6750,
      "ty": 41,
      "x": 39047,
      "y": 55897,
      "ta": "#start"
    },
    {
      "t": 6763,
      "e": 6763,
      "ty": 3,
      "x": 705,
      "y": 738,
      "ta": "#start"
    },
    {
      "t": 6763,
      "e": 6763,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#consent_checkbox"
    },
    {
      "t": 6764,
      "e": 6764,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 6800,
      "e": 6800,
      "ty": 2,
      "x": 705,
      "y": 738
    },
    {
      "t": 6843,
      "e": 6843,
      "ty": 4,
      "x": 38501,
      "y": 53970,
      "ta": "#start"
    },
    {
      "t": 6844,
      "e": 6844,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 6846,
      "e": 6846,
      "ty": 5,
      "x": 705,
      "y": 738,
      "ta": "#start"
    },
    {
      "t": 6847,
      "e": 6847,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 7004,
      "e": 7004,
      "ty": 41,
      "x": 33760,
      "y": 61334,
      "ta": "html > body"
    },
    {
      "t": 7856,
      "e": 7856,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 8401,
      "e": 8401,
      "ty": 2,
      "x": 691,
      "y": 704
    },
    {
      "t": 8461,
      "e": 8461,
      "ty": 6,
      "x": 647,
      "y": 519,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 8477,
      "e": 8477,
      "ty": 7,
      "x": 643,
      "y": 491,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 8478,
      "e": 8478,
      "ty": 6,
      "x": 643,
      "y": 491,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 8494,
      "e": 8494,
      "ty": 7,
      "x": 641,
      "y": 468,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 8501,
      "e": 8501,
      "ty": 2,
      "x": 641,
      "y": 468
    },
    {
      "t": 8501,
      "e": 8501,
      "ty": 41,
      "x": 21886,
      "y": 38822,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 8601,
      "e": 8601,
      "ty": 2,
      "x": 632,
      "y": 448
    },
    {
      "t": 8678,
      "e": 8678,
      "ty": 6,
      "x": 618,
      "y": 403,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 8700,
      "e": 8700,
      "ty": 2,
      "x": 617,
      "y": 398
    },
    {
      "t": 8750,
      "e": 8750,
      "ty": 41,
      "x": 15383,
      "y": 36216,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 8801,
      "e": 8801,
      "ty": 2,
      "x": 613,
      "y": 394
    },
    {
      "t": 8880,
      "e": 8880,
      "ty": 3,
      "x": 612,
      "y": 394,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 8881,
      "e": 8881,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 8903,
      "e": 8903,
      "ty": 2,
      "x": 612,
      "y": 394
    },
    {
      "t": 8958,
      "e": 8958,
      "ty": 4,
      "x": 14632,
      "y": 25869,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 8959,
      "e": 8959,
      "ty": 5,
      "x": 612,
      "y": 394,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 9003,
      "e": 9003,
      "ty": 41,
      "x": 14632,
      "y": 25869,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 10005,
      "e": 10005,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10212,
      "e": 10212,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "91"
    },
    {
      "t": 12481,
      "e": 12481,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": ""
    },
    {
      "t": 12787,
      "e": 12787,
      "ty": 7,
      "x": 671,
      "y": 271,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 12800,
      "e": 12800,
      "ty": 2,
      "x": 690,
      "y": 237
    },
    {
      "t": 12850,
      "e": 12850,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 12901,
      "e": 12901,
      "ty": 2,
      "x": 800,
      "y": 43
    },
    {
      "t": 13006,
      "e": 13006,
      "ty": 41,
      "x": 38361,
      "y": 2940,
      "ta": "html > body"
    },
    {
      "t": 14139,
      "e": 14139,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 16340,
      "e": 16340,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 16602,
      "e": 16602,
      "ty": 2,
      "x": 999,
      "y": 136
    },
    {
      "t": 16700,
      "e": 16700,
      "ty": 2,
      "x": 520,
      "y": 409
    },
    {
      "t": 16750,
      "e": 16750,
      "ty": 41,
      "x": 23588,
      "y": 34447,
      "ta": "html > body"
    },
    {
      "t": 16806,
      "e": 16806,
      "ty": 2,
      "x": 494,
      "y": 418
    },
    {
      "t": 17006,
      "e": 17006,
      "ty": 41,
      "x": 23540,
      "y": 34447,
      "ta": "html > body"
    },
    {
      "t": 17110,
      "e": 17110,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "91"
    },
    {
      "t": 17165,
      "e": 17165,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "86"
    },
    {
      "t": 17228,
      "e": 17228,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "STRATEGY-CONNECTING"
    },
    {
      "t": 17739,
      "e": 17739,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "9"
    },
    {
      "t": 17748,
      "e": 17748,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "STRATEGY-CONNECTING"
    },
    {
      "t": 17748,
      "e": 17748,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 17749,
      "e": 17749,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 17800,
      "e": 17800,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 18259,
      "e": 18259,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 18261,
      "e": 18261,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 18315,
      "e": 18315,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "50"
    },
    {
      "t": 18316,
      "e": 18316,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 18336,
      "e": 18336,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "12"
    },
    {
      "t": 18431,
      "e": 18431,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "49"
    },
    {
      "t": 18431,
      "e": 18431,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 18450,
      "e": 18450,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "12*"
    },
    {
      "t": 18500,
      "e": 18500,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "12*"
    },
    {
      "t": 18612,
      "e": 18612,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "12*"
    },
    {
      "t": 18901,
      "e": 18901,
      "ty": 2,
      "x": 574,
      "y": 552
    },
    {
      "t": 19000,
      "e": 19000,
      "ty": 2,
      "x": 580,
      "y": 588
    },
    {
      "t": 19001,
      "e": 19001,
      "ty": 41,
      "x": 27705,
      "y": 48731,
      "ta": "html > body"
    },
    {
      "t": 19101,
      "e": 19101,
      "ty": 2,
      "x": 582,
      "y": 582
    },
    {
      "t": 19179,
      "e": 19179,
      "ty": 6,
      "x": 621,
      "y": 532,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 19201,
      "e": 19201,
      "ty": 2,
      "x": 634,
      "y": 527
    },
    {
      "t": 19251,
      "e": 19251,
      "ty": 41,
      "x": 24778,
      "y": 22837,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 19301,
      "e": 19301,
      "ty": 2,
      "x": 677,
      "y": 515
    },
    {
      "t": 19309,
      "e": 19309,
      "ty": 3,
      "x": 677,
      "y": 515,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 19309,
      "e": 19309,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "12*"
    },
    {
      "t": 19310,
      "e": 19310,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 19310,
      "e": 19310,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 19372,
      "e": 19372,
      "ty": 4,
      "x": 28902,
      "y": 18866,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 19374,
      "e": 19374,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 19375,
      "e": 19375,
      "ty": 5,
      "x": 677,
      "y": 515,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 19376,
      "e": 19376,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 19506,
      "e": 19506,
      "ty": 41,
      "x": 32404,
      "y": 42597,
      "ta": "html > body"
    },
    {
      "t": 20005,
      "e": 20005,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 20477,
      "e": 20477,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 20488,
      "e": 20488,
      "ty": 6,
      "x": 677,
      "y": 515,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 20512,
      "e": 20512,
      "ty": 7,
      "x": 696,
      "y": 445,
      "ta": "> div.masterdiv > div:[2] > div > ul > li:[2]"
    },
    {
      "t": 20601,
      "e": 20601,
      "ty": 2,
      "x": 780,
      "y": 70
    },
    {
      "t": 20623,
      "e": 20623,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 20700,
      "e": 20700,
      "ty": 2,
      "x": 796,
      "y": 16
    },
    {
      "t": 20756,
      "e": 20756,
      "ty": 41,
      "x": 38168,
      "y": 672,
      "ta": "> div.masterdiv"
    },
    {
      "t": 21001,
      "e": 21001,
      "ty": 2,
      "x": 881,
      "y": 32
    },
    {
      "t": 21001,
      "e": 21001,
      "ty": 41,
      "x": 42285,
      "y": 2016,
      "ta": "> div.masterdiv"
    },
    {
      "t": 21100,
      "e": 21100,
      "ty": 2,
      "x": 860,
      "y": 39
    },
    {
      "t": 21160,
      "e": 21160,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 21205,
      "e": 21205,
      "ty": 2,
      "x": 863,
      "y": 22
    },
    {
      "t": 21253,
      "e": 21253,
      "ty": 41,
      "x": 41413,
      "y": 1176,
      "ta": "> div.masterdiv"
    },
    {
      "t": 30762,
      "e": 26253,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 963338,
      "e": 26253,
      "ty": 2,
      "x": 703,
      "y": 205
    },
    {
      "t": 963392,
      "e": 26307,
      "ty": 6,
      "x": 455,
      "y": 333,
      "ta": "#da1"
    },
    {
      "t": 963439,
      "e": 26354,
      "ty": 2,
      "x": 433,
      "y": 343
    },
    {
      "t": 963539,
      "e": 26454,
      "ty": 41,
      "x": 19872,
      "y": 60619,
      "ta": "#da1"
    },
    {
      "t": 963573,
      "e": 26488,
      "ty": 7,
      "x": 469,
      "y": 359,
      "ta": "#da1"
    },
    {
      "t": 963608,
      "e": 26523,
      "ty": 6,
      "x": 622,
      "y": 502,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 963622,
      "e": 26537,
      "ty": 7,
      "x": 741,
      "y": 628,
      "ta": "> div.masterdiv > div:[2] > div > ul > li"
    },
    {
      "t": 963635,
      "e": 26550,
      "ty": 2,
      "x": 741,
      "y": 628
    },
    {
      "t": 963735,
      "e": 26650,
      "ty": 2,
      "x": 796,
      "y": 734
    },
    {
      "t": 963786,
      "e": 26701,
      "ty": 41,
      "x": 37877,
      "y": 61081,
      "ta": "> div.masterdiv"
    },
    {
      "t": 963836,
      "e": 26751,
      "ty": 2,
      "x": 770,
      "y": 740
    },
    {
      "t": 963925,
      "e": 26840,
      "ty": 6,
      "x": 707,
      "y": 742,
      "ta": "#start"
    },
    {
      "t": 963935,
      "e": 26850,
      "ty": 2,
      "x": 707,
      "y": 742
    },
    {
      "t": 963983,
      "e": 26898,
      "ty": 3,
      "x": 697,
      "y": 736,
      "ta": "#start"
    },
    {
      "t": 963986,
      "e": 26901,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 964015,
      "e": 26930,
      "ty": 4,
      "x": 34132,
      "y": 50115,
      "ta": "#start"
    },
    {
      "t": 964017,
      "e": 26932,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 964019,
      "e": 26934,
      "ty": 5,
      "x": 697,
      "y": 736,
      "ta": "#start"
    },
    {
      "t": 964020,
      "e": 26935,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 964037,
      "e": 26952,
      "ty": 2,
      "x": 697,
      "y": 736
    },
    {
      "t": 964038,
      "e": 26953,
      "ty": 41,
      "x": 33372,
      "y": 61166,
      "ta": "html > body"
    },
    {
      "t": 964537,
      "e": 27452,
      "ty": 41,
      "x": 32937,
      "y": 58393,
      "ta": "html > body"
    },
    {
      "t": 964537,
      "e": 27452,
      "ty": 2,
      "x": 688,
      "y": 703
    },
    {
      "t": 964635,
      "e": 27550,
      "ty": 2,
      "x": 614,
      "y": 479
    },
    {
      "t": 964740,
      "e": 27655,
      "ty": 2,
      "x": 612,
      "y": 474
    },
    {
      "t": 964790,
      "e": 27705,
      "ty": 41,
      "x": 29255,
      "y": 39152,
      "ta": "html > body"
    },
    {
      "t": 965027,
      "e": 27942,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 965636,
      "e": 28551,
      "ty": 2,
      "x": 620,
      "y": 225
    },
    {
      "t": 965646,
      "e": 28561,
      "ty": 40,
      "x": 0,
      "y": 0
    },
    {
      "t": 965736,
      "e": 28651,
      "ty": 2,
      "x": 649,
      "y": 49
    },
    {
      "t": 965789,
      "e": 28704,
      "ty": 41,
      "x": 31044,
      "y": 8153,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 970774,
      "e": 33689,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 1016737,
      "e": 33704,
      "ty": 2,
      "x": 890,
      "y": 271
    },
    {
      "t": 1016790,
      "e": 33757,
      "ty": 41,
      "x": 42015,
      "y": 26555,
      "ta": "#jspsych-single-stim-stimulus"
    },
    {
      "t": 1016839,
      "e": 33806,
      "ty": 2,
      "x": 875,
      "y": 286
    },
    {
      "t": 1017178,
      "e": 34145,
      "ty": 38,
      "x": 9,
      "y": 0
    },
    {
      "t": 1018194,
      "e": 35161,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":66,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":67,\"previousSibling\":{\"id\":66},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":68,\"textContent\":\" \",\"previousSibling\":{\"id\":67},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":69,\"textContent\":\" \",\"parentNode\":{\"id\":66}},{\"nodeType\":1,\"id\":70,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":69},\"parentNode\":{\"id\":66}},{\"nodeType\":3,\"id\":71,\"textContent\":\" \",\"previousSibling\":{\"id\":70},\"parentNode\":{\"id\":66}},{\"nodeType\":8,\"id\":72,\"previousSibling\":{\"id\":71},\"parentNode\":{\"id\":66}},{\"nodeType\":3,\"id\":73,\"textContent\":\" \",\"previousSibling\":{\"id\":72},\"parentNode\":{\"id\":66}},{\"nodeType\":1,\"id\":74,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":73},\"parentNode\":{\"id\":66}},{\"nodeType\":8,\"id\":75,\"previousSibling\":{\"id\":74},\"parentNode\":{\"id\":66}},{\"nodeType\":3,\"id\":76,\"textContent\":\" \",\"previousSibling\":{\"id\":75},\"parentNode\":{\"id\":66}},{\"nodeType\":1,\"id\":77,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":76},\"parentNode\":{\"id\":66}},{\"nodeType\":8,\"id\":78,\"previousSibling\":{\"id\":77},\"parentNode\":{\"id\":66}},{\"nodeType\":3,\"id\":79,\"textContent\":\" \",\"previousSibling\":{\"id\":78},\"parentNode\":{\"id\":66}},{\"nodeType\":3,\"id\":80,\"textContent\":\" \",\"parentNode\":{\"id\":70}},{\"nodeType\":1,\"id\":81,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":80},\"parentNode\":{\"id\":70}},{\"nodeType\":3,\"id\":82,\"textContent\":\" \",\"previousSibling\":{\"id\":81},\"parentNode\":{\"id\":70}},{\"nodeType\":3,\"id\":83,\"textContent\":\" \",\"parentNode\":{\"id\":81}},{\"nodeType\":1,\"id\":84,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":83},\"parentNode\":{\"id\":81}},{\"nodeType\":3,\"id\":85,\"textContent\":\" \",\"previousSibling\":{\"id\":84},\"parentNode\":{\"id\":81}},{\"nodeType\":3,\"id\":86,\"textContent\":\"UNIVERSITY OF CALIFORNIA, SAN DIEGO CONSENT TO ACT AS A RESEARCH SUBJECT\",\"parentNode\":{\"id\":84}},{\"nodeType\":3,\"id\":87,\"textContent\":\" \",\"parentNode\":{\"id\":74}},{\"nodeType\":1,\"id\":88,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":87},\"parentNode\":{\"id\":74}},{\"nodeType\":3,\"id\":89,\"textContent\":\" \",\"previousSibling\":{\"id\":88},\"parentNode\":{\"id\":74}},{\"nodeType\":3,\"id\":90,\"textContent\":\" \",\"parentNode\":{\"id\":88}},{\"nodeType\":1,\"id\":91,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":90},\"parentNode\":{\"id\":88}},{\"nodeType\":3,\"id\":92,\"textContent\":\" \",\"previousSibling\":{\"id\":91},\"parentNode\":{\"id\":88}},{\"nodeType\":1,\"id\":93,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":92},\"parentNode\":{\"id\":88}},{\"nodeType\":3,\"id\":94,\"textContent\":\" \",\"previousSibling\":{\"id\":93},\"parentNode\":{\"id\":88}},{\"nodeType\":1,\"id\":95,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":94},\"parentNode\":{\"id\":88}},{\"nodeType\":3,\"id\":96,\"textContent\":\" \",\"previousSibling\":{\"id\":95},\"parentNode\":{\"id\":88}},{\"nodeType\":1,\"id\":97,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":96},\"parentNode\":{\"id\":88}},{\"nodeType\":3,\"id\":98,\"textContent\":\" \",\"previousSibling\":{\"id\":97},\"parentNode\":{\"id\":88}},{\"nodeType\":8,\"id\":99,\"previousSibling\":{\"id\":98},\"parentNode\":{\"id\":88}},{\"nodeType\":3,\"id\":100,\"textContent\":\" \",\"previousSibling\":{\"id\":99},\"parentNode\":{\"id\":88}},{\"nodeType\":1,\"id\":101,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control-group centered\"},\"previousSibling\":{\"id\":100},\"parentNode\":{\"id\":88}},{\"nodeType\":3,\"id\":102,\"textContent\":\" \",\"previousSibling\":{\"id\":101},\"parentNode\":{\"id\":88}},{\"nodeType\":3,\"id\":103,\"textContent\":\" You are being invited to participate in a research study titled Learning Diagrams: Evaluating Learning With External Representations. This study is being done by Amy Fox and Dr. Jim Hollan from the University of California - San Diego (UCSD). You were selected to participate in this study because we think you might use graphs and diagrams in your work and educational activities.\",\"parentNode\":{\"id\":91}},{\"nodeType\":3,\"id\":104,\"textContent\":\" The purpose of this research study is to understand how humans try to make sense of charts, diagrams and graphs that are unconventional and that we may not have seen before. If you agree to take part in this study, you will be asked to read a series of instructions and answer a series of questions. The entire study should take no more than 60 minutes to complete. The researchers expect there will be no direct benefit to you from this research, other than any enjoyment you might have in contributing to research. We hope that you will find the questions interesting, though at times you may feel bored. The investigator(s), however, may learn more about how different types of instructions trigger different levels of understanding when using graphs. There are minimal risks associated with this research study, including a loss of confidentiality of your participation. The researchers are taking all required steps to protect your confidentiality, including storing all of your responses to questions in a secure, encrypted database separate from any information that can personally identify you. The only records containing your name and other personally identifying information are those stored in the system through which you signed up to participate in the study. These records will never be connected with the data we collect from you today. Research records will be kept confidential to the extent allowed by law and may be reviewed by the UCSD Institutional Review Board.\",\"parentNode\":{\"id\":93}},{\"nodeType\":3,\"id\":105,\"textContent\":\" Your participation in this study is completely voluntary and you can withdraw at any time by notifying the researcher that you wish to end your participation. Choosing not to participate or withdrawing will result in no penalty or loss of benefits to which you are entitled. You are free to skip any questions that you choose. If you have questions about this project or if you have a research-related problem, you may contact the researcher(s), Amy Fox: 919 886 4455: a2fox@ucsd.edu, and Jim Hollan: hollan@ucsd.edu. If you have any questions concerning your rights as a research subject, you may contact the UCSD Human Research Protections Program Office at 858-246-HRPP (858-246-4777). \",\"parentNode\":{\"id\":95}},{\"nodeType\":3,\"id\":106,\"textContent\":\" By clicking “I agree” below you are indicating that: you are at least 18 years old, have read this consent form, and agree to participate in this research study. If you do not wish to participate in the study, please notify the researcher now.\",\"parentNode\":{\"id\":97}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \",\"parentNode\":{\"id\":101}},{\"nodeType\":1,\"id\":108,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"centered control control-checkbox\"},\"previousSibling\":{\"id\":107},\"parentNode\":{\"id\":101}},{\"nodeType\":3,\"id\":109,\"textContent\":\" \",\"previousSibling\":{\"id\":108},\"parentNode\":{\"id\":101}},{\"nodeType\":3,\"id\":110,\"textContent\":\" I agree to take part in this study. \",\"parentNode\":{\"id\":108}},{\"nodeType\":1,\"id\":111,\"tagName\":\"INPUT\",\"attributes\":{\"id\":\"consent_checkbox\",\"type\":\"checkbox\"},\"previousSibling\":{\"id\":110},\"parentNode\":{\"id\":108}},{\"nodeType\":3,\"id\":112,\"textContent\":\" \",\"previousSibling\":{\"id\":111},\"parentNode\":{\"id\":108}},{\"nodeType\":1,\"id\":113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"},\"previousSibling\":{\"id\":112},\"parentNode\":{\"id\":108}},{\"nodeType\":3,\"id\":114,\"textContent\":\" \",\"previousSibling\":{\"id\":113},\"parentNode\":{\"id\":108}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \",\"parentNode\":{\"id\":77}},{\"nodeType\":1,\"id\":116,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":115},\"parentNode\":{\"id\":77}},{\"nodeType\":3,\"id\":117,\"textContent\":\" \",\"previousSibling\":{\"id\":116},\"parentNode\":{\"id\":77}},{\"nodeType\":3,\"id\":118,\"textContent\":\"START\",\"parentNode\":{\"id\":116}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":66},{\"id\":69},{\"id\":70},{\"id\":80},{\"id\":81},{\"id\":83},{\"id\":84},{\"id\":86},{\"id\":85},{\"id\":82},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":87},{\"id\":88},{\"id\":90},{\"id\":91},{\"id\":103},{\"id\":92},{\"id\":93},{\"id\":104},{\"id\":94},{\"id\":95},{\"id\":105},{\"id\":96},{\"id\":97},{\"id\":106},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":107},{\"id\":108},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":109},{\"id\":102},{\"id\":89},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":115},{\"id\":116},{\"id\":118},{\"id\":117},{\"id\":78},{\"id\":79},{\"id\":67},{\"id\":68}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":119,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":120,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":119},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":121,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":120},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":122,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":121},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":123,\"tagName\":\"P\",\"attributes\":{},\"parentNode\":{\"id\":119}},{\"nodeType\":3,\"id\":124,\"textContent\":\"Please enter the following information from your participant card\",\"parentNode\":{\"id\":123}},{\"nodeType\":1,\"id\":125,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":120}},{\"nodeType\":1,\"id\":126,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":125},\"parentNode\":{\"id\":120}},{\"nodeType\":3,\"id\":127,\"textContent\":\"Session code: \",\"parentNode\":{\"id\":125}},{\"nodeType\":1,\"id\":128,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":121}},{\"nodeType\":1,\"id\":129,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":128},\"parentNode\":{\"id\":121}},{\"nodeType\":3,\"id\":130,\"textContent\":\"Condition code: \",\"parentNode\":{\"id\":128}},{\"nodeType\":3,\"id\":131,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":122}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":119},{\"id\":123},{\"id\":124},{\"id\":120},{\"id\":125},{\"id\":127},{\"id\":126},{\"id\":121},{\"id\":128},{\"id\":130},{\"id\":129},{\"id\":122},{\"id\":131}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":132,\"tagName\":\"SCRIPT\",\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":133,\"textContent\":\" \",\"previousSibling\":{\"id\":132},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":134,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"previousSibling\":{\"id\":133},\"parentNode\":{\"id\":55}},{\"nodeType\":8,\"id\":135,\"previousSibling\":{\"id\":134},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":136,\"textContent\":\" \",\"previousSibling\":{\"id\":135},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":137,\"textContent\":\" \\t//set text of scenario descriptions based on scenario randomization order in main switch(scenarios[0]) { case \\\"acme\\\": $('#da1').text(\\\"Answer 15 questions to help a manager coordinate a factory shift schedule.\\\"); break; } \",\"parentNode\":{\"id\":132}},{\"nodeType\":3,\"id\":138,\"textContent\":\" \",\"parentNode\":{\"id\":134}},{\"nodeType\":1,\"id\":139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":138},\"parentNode\":{\"id\":134}},{\"nodeType\":8,\"id\":140,\"previousSibling\":{\"id\":139},\"parentNode\":{\"id\":134}},{\"nodeType\":3,\"id\":141,\"textContent\":\" \",\"previousSibling\":{\"id\":140},\"parentNode\":{\"id\":134}},{\"nodeType\":1,\"id\":142,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":141},\"parentNode\":{\"id\":134}},{\"nodeType\":3,\"id\":143,\"textContent\":\" \",\"previousSibling\":{\"id\":142},\"parentNode\":{\"id\":134}},{\"nodeType\":8,\"id\":144,\"previousSibling\":{\"id\":143},\"parentNode\":{\"id\":134}},{\"nodeType\":3,\"id\":145,\"textContent\":\" \",\"previousSibling\":{\"id\":144},\"parentNode\":{\"id\":134}},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":145},\"parentNode\":{\"id\":134}},{\"nodeType\":8,\"id\":147,\"previousSibling\":{\"id\":146},\"parentNode\":{\"id\":134}},{\"nodeType\":3,\"id\":148,\"textContent\":\" \",\"previousSibling\":{\"id\":147},\"parentNode\":{\"id\":134}},{\"nodeType\":3,\"id\":149,\"textContent\":\" \",\"parentNode\":{\"id\":139}},{\"nodeType\":1,\"id\":150,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":149},\"parentNode\":{\"id\":139}},{\"nodeType\":3,\"id\":151,\"textContent\":\" \",\"previousSibling\":{\"id\":150},\"parentNode\":{\"id\":139}},{\"nodeType\":3,\"id\":152,\"textContent\":\" \",\"parentNode\":{\"id\":150}},{\"nodeType\":1,\"id\":153,\"tagName\":\"H1\",\"attributes\":{},\"previousSibling\":{\"id\":152},\"parentNode\":{\"id\":150}},{\"nodeType\":3,\"id\":154,\"textContent\":\" \",\"previousSibling\":{\"id\":153},\"parentNode\":{\"id\":150}},{\"nodeType\":3,\"id\":155,\"textContent\":\"Instructions\",\"parentNode\":{\"id\":153}},{\"nodeType\":3,\"id\":156,\"textContent\":\" \",\"parentNode\":{\"id\":142}},{\"nodeType\":1,\"id\":157,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":156},\"parentNode\":{\"id\":142}},{\"nodeType\":3,\"id\":158,\"textContent\":\" \",\"previousSibling\":{\"id\":157},\"parentNode\":{\"id\":142}},{\"nodeType\":8,\"id\":159,\"previousSibling\":{\"id\":158},\"parentNode\":{\"id\":142}},{\"nodeType\":3,\"id\":160,\"textContent\":\" \",\"previousSibling\":{\"id\":159},\"parentNode\":{\"id\":142}},{\"nodeType\":3,\"id\":161,\"textContent\":\" \",\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":162,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":161},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":163,\"tagName\":\"TABLE\",\"attributes\":{\"cellspacing\":\"0\",\"cellpadding\":\"0\",\"border\":\"0\",\"style\":\"display:block;\"},\"previousSibling\":{\"id\":162},\"parentNode\":{\"id\":157}},{\"nodeType\":3,\"id\":164,\"textContent\":\" \",\"previousSibling\":{\"id\":163},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":165,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":164},\"parentNode\":{\"id\":157}},{\"nodeType\":3,\"id\":166,\"textContent\":\" \",\"previousSibling\":{\"id\":165},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":167,\"tagName\":\"UL\",\"attributes\":{\"class\":\"fa-ul\"},\"previousSibling\":{\"id\":166},\"parentNode\":{\"id\":157}},{\"nodeType\":3,\"id\":168,\"textContent\":\" \",\"previousSibling\":{\"id\":167},\"parentNode\":{\"id\":157}},{\"nodeType\":1,\"id\":169,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":168},\"parentNode\":{\"id\":157}},{\"nodeType\":3,\"id\":170,\"textContent\":\" \",\"previousSibling\":{\"id\":169},\"parentNode\":{\"id\":157}},{\"nodeType\":3,\"id\":171,\"textContent\":\"We are interested in learning about how people make decisions about time. In this study, you are going to solve a series of problems about scheduling events. To help you solve the problems, we are going to give you a variety of graphs and diagrams. You are going to complete \",\"parentNode\":{\"id\":162}},{\"nodeType\":1,\"id\":172,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":171},\"parentNode\":{\"id\":162}},{\"nodeType\":3,\"id\":173,\"textContent\":\" of the activities on this computer. \",\"previousSibling\":{\"id\":172},\"parentNode\":{\"id\":162}},{\"nodeType\":3,\"id\":174,\"textContent\":\"all\",\"parentNode\":{\"id\":172}},{\"nodeType\":3,\"id\":175,\"textContent\":\" \",\"parentNode\":{\"id\":163}},{\"nodeType\":1,\"id\":176,\"tagName\":\"TBODY\",\"attributes\":{},\"previousSibling\":{\"id\":175},\"parentNode\":{\"id\":163}},{\"nodeType\":1,\"id\":177,\"tagName\":\"TR\",\"attributes\":{},\"parentNode\":{\"id\":176}},{\"nodeType\":3,\"id\":178,\"textContent\":\" \",\"previousSibling\":{\"id\":177},\"parentNode\":{\"id\":176}},{\"nodeType\":1,\"id\":179,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":178},\"parentNode\":{\"id\":176}},{\"nodeType\":3,\"id\":180,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":179},\"parentNode\":{\"id\":176}},{\"nodeType\":1,\"id\":181,\"tagName\":\"TR\",\"attributes\":{\"height\":\"15\"},\"previousSibling\":{\"id\":180},\"parentNode\":{\"id\":176}},{\"nodeType\":3,\"id\":182,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":181},\"parentNode\":{\"id\":176}},{\"nodeType\":1,\"id\":183,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":182},\"parentNode\":{\"id\":176}},{\"nodeType\":3,\"id\":184,\"textContent\":\" \",\"previousSibling\":{\"id\":183},\"parentNode\":{\"id\":176}},{\"nodeType\":1,\"id\":185,\"tagName\":\"TR\",\"attributes\":{},\"previousSibling\":{\"id\":184},\"parentNode\":{\"id\":176}},{\"nodeType\":3,\"id\":186,\"textContent\":\" \",\"previousSibling\":{\"id\":185},\"parentNode\":{\"id\":176}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \",\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":188,\"tagName\":\"TD\",\"attributes\":{\"width\":\"40\",\"rowspan\":\"2\"},\"previousSibling\":{\"id\":187},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":189,\"textContent\":\" \",\"previousSibling\":{\"id\":188},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":190,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":189},\"parentNode\":{\"id\":177}},{\"nodeType\":3,\"id\":191,\"textContent\":\" \",\"previousSibling\":{\"id\":190},\"parentNode\":{\"id\":177}},{\"nodeType\":1,\"id\":192,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":188}},{\"nodeType\":3,\"id\":193,\"textContent\":\"Acme Factory [20 minutes]\",\"parentNode\":{\"id\":190}},{\"nodeType\":3,\"id\":194,\"textContent\":\" \",\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":195,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":194},\"parentNode\":{\"id\":179}},{\"nodeType\":3,\"id\":196,\"textContent\":\" \",\"previousSibling\":{\"id\":195},\"parentNode\":{\"id\":179}},{\"nodeType\":1,\"id\":197,\"tagName\":\"A\",\"attributes\":{\"id\":\"da1\",\"class\":\"subheading\"},\"parentNode\":{\"id\":195}},{\"nodeType\":3,\"id\":198,\"textContent\":\"Answer 15 questions to help a manager coordinate a factory shift schedule.\",\"parentNode\":{\"id\":197}},{\"nodeType\":3,\"id\":199,\"textContent\":\" \",\"parentNode\":{\"id\":183}},{\"nodeType\":1,\"id\":200,\"tagName\":\"TD\",\"attributes\":{\"rowspan\":\"2\"},\"previousSibling\":{\"id\":199},\"parentNode\":{\"id\":183}},{\"nodeType\":3,\"id\":201,\"textContent\":\" \",\"previousSibling\":{\"id\":200},\"parentNode\":{\"id\":183}},{\"nodeType\":1,\"id\":202,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":201},\"parentNode\":{\"id\":183}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \",\"previousSibling\":{\"id\":202},\"parentNode\":{\"id\":183}},{\"nodeType\":1,\"id\":204,\"tagName\":\"A\",\"attributes\":{\"class\":\"fa fa-desktop fa-lg\"},\"parentNode\":{\"id\":200}},{\"nodeType\":3,\"id\":205,\"textContent\":\"Final Survey [5 minutes]\",\"parentNode\":{\"id\":202}},{\"nodeType\":3,\"id\":206,\"textContent\":\" \",\"parentNode\":{\"id\":185}},{\"nodeType\":1,\"id\":207,\"tagName\":\"TD\",\"attributes\":{},\"previousSibling\":{\"id\":206},\"parentNode\":{\"id\":185}},{\"nodeType\":3,\"id\":208,\"textContent\":\" \",\"previousSibling\":{\"id\":207},\"parentNode\":{\"id\":185}},{\"nodeType\":1,\"id\":209,\"tagName\":\"I\",\"attributes\":{},\"parentNode\":{\"id\":207}},{\"nodeType\":3,\"id\":210,\"textContent\":\"Complete a demographic survey and feedback on your experience.\",\"parentNode\":{\"id\":209}},{\"nodeType\":1,\"id\":211,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":165}},{\"nodeType\":3,\"id\":212,\"textContent\":\" \",\"previousSibling\":{\"id\":211},\"parentNode\":{\"id\":165}},{\"nodeType\":3,\"id\":213,\"textContent\":\"To ensure accurate results, please:\",\"parentNode\":{\"id\":211}},{\"nodeType\":3,\"id\":214,\"textContent\":\" \\t\",\"parentNode\":{\"id\":167}},{\"nodeType\":1,\"id\":215,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":214},\"parentNode\":{\"id\":167}},{\"nodeType\":3,\"id\":216,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":215},\"parentNode\":{\"id\":167}},{\"nodeType\":1,\"id\":217,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":216},\"parentNode\":{\"id\":167}},{\"nodeType\":3,\"id\":218,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":217},\"parentNode\":{\"id\":167}},{\"nodeType\":1,\"id\":219,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":218},\"parentNode\":{\"id\":167}},{\"nodeType\":3,\"id\":220,\"textContent\":\" \\t\",\"previousSibling\":{\"id\":219},\"parentNode\":{\"id\":167}},{\"nodeType\":1,\"id\":221,\"tagName\":\"LI\",\"attributes\":{},\"previousSibling\":{\"id\":220},\"parentNode\":{\"id\":167}},{\"nodeType\":3,\"id\":222,\"textContent\":\" \",\"previousSibling\":{\"id\":221},\"parentNode\":{\"id\":167}},{\"nodeType\":1,\"id\":223,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-check\",\"style\":\"color:green\"},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":224,\"textContent\":\"DO read all instructions \",\"previousSibling\":{\"id\":223},\"parentNode\":{\"id\":215}},{\"nodeType\":1,\"id\":225,\"tagName\":\"I\",\"attributes\":{},\"previousSibling\":{\"id\":224},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":226,\"textContent\":\" \",\"previousSibling\":{\"id\":225},\"parentNode\":{\"id\":215}},{\"nodeType\":3,\"id\":227,\"textContent\":\"carefully\",\"parentNode\":{\"id\":225}},{\"nodeType\":1,\"id\":228,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":217}},{\"nodeType\":3,\"id\":229,\"textContent\":\"DO NOT close this browser window\",\"previousSibling\":{\"id\":228},\"parentNode\":{\"id\":217}},{\"nodeType\":1,\"id\":230,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":219}},{\"nodeType\":3,\"id\":231,\"textContent\":\"DO NOT try to return to a previous page \",\"previousSibling\":{\"id\":230},\"parentNode\":{\"id\":219}},{\"nodeType\":1,\"id\":232,\"tagName\":\"I\",\"attributes\":{\"class\":\"fa-li fa fa-close\",\"style\":\"color:#EA4335\"},\"parentNode\":{\"id\":221}},{\"nodeType\":3,\"id\":233,\"textContent\":\"DO NOT use the back button on the mouse or web browser\",\"previousSibling\":{\"id\":232},\"parentNode\":{\"id\":221}},{\"nodeType\":3,\"id\":234,\"textContent\":\"If you have questions at any time, please raise your hand and the experimenter will assist you. \",\"parentNode\":{\"id\":169}},{\"nodeType\":3,\"id\":235,\"textContent\":\" \\t\",\"parentNode\":{\"id\":146}},{\"nodeType\":1,\"id\":236,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":235},\"parentNode\":{\"id\":146}},{\"nodeType\":3,\"id\":237,\"textContent\":\" \",\"previousSibling\":{\"id\":236},\"parentNode\":{\"id\":146}},{\"nodeType\":3,\"id\":238,\"textContent\":\"BEGIN\",\"parentNode\":{\"id\":236}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":132},{\"id\":137},{\"id\":133},{\"id\":134},{\"id\":138},{\"id\":139},{\"id\":149},{\"id\":150},{\"id\":152},{\"id\":153},{\"id\":155},{\"id\":154},{\"id\":151},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":156},{\"id\":157},{\"id\":161},{\"id\":162},{\"id\":171},{\"id\":172},{\"id\":174},{\"id\":173},{\"id\":163},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":187},{\"id\":188},{\"id\":192},{\"id\":189},{\"id\":190},{\"id\":193},{\"id\":191},{\"id\":178},{\"id\":179},{\"id\":194},{\"id\":195},{\"id\":197},{\"id\":198},{\"id\":196},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":199},{\"id\":200},{\"id\":204},{\"id\":201},{\"id\":202},{\"id\":205},{\"id\":203},{\"id\":184},{\"id\":185},{\"id\":206},{\"id\":207},{\"id\":209},{\"id\":210},{\"id\":208},{\"id\":186},{\"id\":164},{\"id\":165},{\"id\":211},{\"id\":213},{\"id\":212},{\"id\":166},{\"id\":167},{\"id\":214},{\"id\":215},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":227},{\"id\":226},{\"id\":216},{\"id\":217},{\"id\":228},{\"id\":229},{\"id\":218},{\"id\":219},{\"id\":230},{\"id\":231},{\"id\":220},{\"id\":221},{\"id\":232},{\"id\":233},{\"id\":222},{\"id\":168},{\"id\":169},{\"id\":234},{\"id\":170},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":235},{\"id\":236},{\"id\":238},{\"id\":237},{\"id\":147},{\"id\":148},{\"id\":135},{\"id\":136}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":239,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/acme.png\",\"id\":\"jspsych-single-stim-stimulus\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":240,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":239},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":241,\"textContent\":\"Press enter to continue\",\"parentNode\":{\"id\":240}}],[],[]]}"
    },
    {
      "sequence": 9,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":239},{\"id\":240},{\"id\":241}],[],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":1,\"id\":59,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"ambiance-notification\"}},{\"nodeType\":1,\"id\":60,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"blue_light_filter\",\"style\":\"width: 100%; height: 100%; z-index: 2147483646; transition: -webkit-transform 10s ease-in-out; position: fixed !important; left: 0px !important; bottom: 0px !important; overflow: hidden !important; pointer-events: none !important; background: rgb(214, 107, 0); opacity: 0;\"}},{\"nodeType\":1,\"id\":61,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"blf_status\",\"style\":\"position: fixed !important; width: 105px; height: 27px;\\tcolor: white; text-shadow: 1px 2px 4px #000; font-size: 20px;\\tfont-weight: bold; background-color: blue; z-index: 2147483647;\\tright: 0px; top: 0px; display:none; font-family: arial,sans-serif; text-align: center;\"}},{\"nodeType\":1,\"id\":62,\"tagName\":\"SPAN\",\"attributes\":{\"style\":\"border-radius: 3px; text-indent: 20px; width: auto; padding: 0px 4px 0px 0px; text-align: center; font-style: normal; font-variant: normal; font-weight: bold; font-stretch: normal; font-size: 11px; line-height: 20px; font-family: \\\"Helvetica Neue\\\", Helvetica, sans-serif; color: rgb(255, 255, 255); background: url(\\\"data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIGhlaWdodD0iMzBweCIgd2lkdGg9IjMwcHgiIHZpZXdCb3g9Ii0xIC0xIDMxIDMxIj48Zz48cGF0aCBkPSJNMjkuNDQ5LDE0LjY2MiBDMjkuNDQ5LDIyLjcyMiAyMi44NjgsMjkuMjU2IDE0Ljc1LDI5LjI1NiBDNi42MzIsMjkuMjU2IDAuMDUxLDIyLjcyMiAwLjA1MSwxNC42NjIgQzAuMDUxLDYuNjAxIDYuNjMyLDAuMDY3IDE0Ljc1LDAuMDY3IEMyMi44NjgsMC4wNjcgMjkuNDQ5LDYuNjAxIDI5LjQ0OSwxNC42NjIiIGZpbGw9IiNmZmYiIHN0cm9rZT0iI2ZmZiIgc3Ryb2tlLXdpZHRoPSIxIj48L3BhdGg+PHBhdGggZD0iTTE0LjczMywxLjY4NiBDNy41MTYsMS42ODYgMS42NjUsNy40OTUgMS42NjUsMTQuNjYyIEMxLjY2NSwyMC4xNTkgNS4xMDksMjQuODU0IDkuOTcsMjYuNzQ0IEM5Ljg1NiwyNS43MTggOS43NTMsMjQuMTQzIDEwLjAxNiwyMy4wMjIgQzEwLjI1MywyMi4wMSAxMS41NDgsMTYuNTcyIDExLjU0OCwxNi41NzIgQzExLjU0OCwxNi41NzIgMTEuMTU3LDE1Ljc5NSAxMS4xNTcsMTQuNjQ2IEMxMS4xNTcsMTIuODQyIDEyLjIxMSwxMS40OTUgMTMuNTIyLDExLjQ5NSBDMTQuNjM3LDExLjQ5NSAxNS4xNzUsMTIuMzI2IDE1LjE3NSwxMy4zMjMgQzE1LjE3NSwxNC40MzYgMTQuNDYyLDE2LjEgMTQuMDkzLDE3LjY0MyBDMTMuNzg1LDE4LjkzNSAxNC43NDUsMTkuOTg4IDE2LjAyOCwxOS45ODggQzE4LjM1MSwxOS45ODggMjAuMTM2LDE3LjU1NiAyMC4xMzYsMTQuMDQ2IEMyMC4xMzYsMTAuOTM5IDE3Ljg4OCw4Ljc2NyAxNC42NzgsOC43NjcgQzEwLjk1OSw4Ljc2NyA4Ljc3NywxMS41MzYgOC43NzcsMTQuMzk4IEM4Ljc3NywxNS41MTMgOS4yMSwxNi43MDkgOS43NDksMTcuMzU5IEM5Ljg1NiwxNy40ODggOS44NzIsMTcuNiA5Ljg0LDE3LjczMSBDOS43NDEsMTguMTQxIDkuNTIsMTkuMDIzIDkuNDc3LDE5LjIwMyBDOS40MiwxOS40NCA5LjI4OCwxOS40OTEgOS4wNCwxOS4zNzYgQzcuNDA4LDE4LjYyMiA2LjM4NywxNi4yNTIgNi4zODcsMTQuMzQ5IEM2LjM4NywxMC4yNTYgOS4zODMsNi40OTcgMTUuMDIyLDYuNDk3IEMxOS41NTUsNi40OTcgMjMuMDc4LDkuNzA1IDIzLjA3OCwxMy45OTEgQzIzLjA3OCwxOC40NjMgMjAuMjM5LDIyLjA2MiAxNi4yOTcsMjIuMDYyIEMxNC45NzMsMjIuMDYyIDEzLjcyOCwyMS4zNzkgMTMuMzAyLDIwLjU3MiBDMTMuMzAyLDIwLjU3MiAxMi42NDcsMjMuMDUgMTIuNDg4LDIzLjY1NyBDMTIuMTkzLDI0Ljc4NCAxMS4zOTYsMjYuMTk2IDEwLjg2MywyNy4wNTggQzEyLjA4NiwyNy40MzQgMTMuMzg2LDI3LjYzNyAxNC43MzMsMjcuNjM3IEMyMS45NSwyNy42MzcgMjcuODAxLDIxLjgyOCAyNy44MDEsMTQuNjYyIEMyNy44MDEsNy40OTUgMjEuOTUsMS42ODYgMTQuNzMzLDEuNjg2IiBmaWxsPSIjYmQwODFjIj48L3BhdGg+PC9nPjwvc3ZnPg==\\\") 3px 50% / 14px 14px no-repeat rgb(189, 8, 28); position: absolute; opacity: 1; z-index: 8675309; display: block; cursor: pointer; border: none; -webkit-font-smoothing: antialiased; top: 8px; left: 95px;\"},\"childNodes\":[{\"nodeType\":3,\"id\":63,\"textContent\":\"Save\"}]},{\"nodeType\":1,\"id\":64,\"tagName\":\"SPAN\",\"attributes\":{\"style\":\"width: 24px; height: 24px; background: url(\\\"data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiA/Pjxzdmcgd2lkdGg9IjI0cHgiIGhlaWdodD0iMjRweCIgdmlld0JveD0iMCAwIDI0IDI0IiB2ZXJzaW9uPSIxLjEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiPjxkZWZzPjxtYXNrIGlkPSJtIj48cmVjdCBmaWxsPSIjZmZmIiB4PSIwIiB5PSIwIiB3aWR0aD0iMjQiIGhlaWdodD0iMjQiIHJ4PSI2IiByeT0iNiIvPjxyZWN0IGZpbGw9IiMwMDAiIHg9IjUiIHk9IjUiIHdpZHRoPSIxNCIgaGVpZ2h0PSIxNCIgcng9IjEiIHJ5PSIxIi8+PHJlY3QgZmlsbD0iIzAwMCIgeD0iMTAiIHk9IjAiIHdpZHRoPSI0IiBoZWlnaHQ9IjI0Ii8+PHJlY3QgZmlsbD0iIzAwMCIgeD0iMCIgeT0iMTAiIHdpZHRoPSIyNCIgaGVpZ2h0PSI0Ii8+PC9tYXNrPjwvZGVmcz48cmVjdCB4PSIwIiB5PSIwIiB3aWR0aD0iMjQiIGhlaWdodD0iMjQiIGZpbGw9IiNmZmYiIG1hc2s9InVybCgjbSkiLz48L3N2Zz4=\\\") 50% 50% / 14px 14px no-repeat rgba(0, 0, 0, 0.4); position: absolute; opacity: 1; z-index: 8675309; display: block; cursor: pointer; border: none; border-radius: 12px; top: 6px; left: 1253px;\"}},{\"nodeType\":1,\"id\":65,\"tagName\":\"IMG\",\"attributes\":{\"src\":\"img/phone.png\",\"id\":\"jspsych-single-stim-stimulus\"}}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 96, dom: 835, initialDom: 955",
  "javascriptErrors": []
}