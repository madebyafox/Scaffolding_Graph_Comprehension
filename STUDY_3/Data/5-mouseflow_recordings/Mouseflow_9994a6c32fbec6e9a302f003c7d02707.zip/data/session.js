var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["session"] = {
  "id": "9994a6c32fbec6e9a302f003c7d02707",
  "created": "2018-05-21T09:56:58.92901-07:00",
  "lastActivity": "2018-05-21T10:13:56.9769428-07:00",
  "pageViews": [
    {
      "id": "0521584336f2ab174b8ec8608f56a4c05c383039",
      "startTime": "2018-05-21T09:56:58.9544867-07:00",
      "endTime": "2018-05-21T10:13:56.9769428-07:00",
      "title": "FOX2YP",
      "uri": "https://warm-citadel-75324.herokuapp.com/",
      "websitePage": "/",
      "visitTime": 1018194,
      "engagementTime": 35161,
      "scroll": 99.0,
      "tags": [
        "form-interact"
      ],
      "friction": 0,
      "annotations": []
    }
  ],
  "duration": 1018194,
  "engagementTime": 35161,
  "totalFriction": 0,
  "country": "us",
  "region": "CA",
  "city": "La Jolla",
  "isp": "University of California, San Diego",
  "ip": "69.196.34.183",
  "lang": "en-US",
  "userAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.139 Safari/537.36",
  "browser": "Chrome",
  "browserVersion": "66.0.3359.139",
  "os": "macOS",
  "osVersion": "10.12 Sierra",
  "device": "Desktop",
  "referrer": "",
  "referrerType": "",
  "screenRes": "1440x900",
  "tags": [
    "form-interact"
  ],
  "variables": [],
  "watched": false,
  "starred": false,
  "lng": -117.2359,
  "lat": 32.8807,
  "visitorId": "1d004384f1069d02125653a0b6b0564a",
  "gdpr": false
}