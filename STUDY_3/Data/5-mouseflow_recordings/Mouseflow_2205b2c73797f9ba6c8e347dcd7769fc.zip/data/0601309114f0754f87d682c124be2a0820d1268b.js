var MF = MF || {};MF.RecordingData = MF.RecordingData || {};MF.RecordingData["0601309114f0754f87d682c124be2a0820d1268b"] = {
  "startTime": "2018-06-01T18:16:30.4822761Z",
  "websitePageUrl": "/16",
  "visitTime": 59314,
  "engagementTime": 55337,
  "pageTitle": "FOX2YP",
  "url": "https://warm-citadel-75324.herokuapp.com/",
  "viewportWidth": 1920,
  "viewportHeight": 1200,
  "tags": [
    "form-interact",
    "submit"
  ],
  "session": {
    "id": "2205b2c73797f9ba6c8e347dcd7769fc",
    "created": "2018-06-01T18:16:30.4822761+00:00",
    "lastActivity": "0001-01-01T00:00:00+00:00",
    "pages": 1,
    "duration": 0,
    "engagementTime": 0,
    "totalFriction": 0,
    "country": "us",
    "region": "CA",
    "city": "La Jolla",
    "isp": "University of California, San Diego",
    "ip": "###.###.###.###",
    "lang": "en-US",
    "userAgent": "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.181 Safari/537.36",
    "browser": "Chrome",
    "browserVersion": "66.0.3359.181",
    "os": "Windows",
    "osVersion": "7",
    "device": "Desktop",
    "referrer": "",
    "referrerType": "",
    "screenRes": "1920x1200",
    "entryPage": "/16",
    "tags": [
      "form-interact",
      "submit"
    ],
    "variables": [
      "SID=EER58",
      "CONDITION=311"
    ],
    "watched": false,
    "starred": false,
    "lng": 32.8807,
    "lat": 32.8807,
    "visitorId": "474a8318c531f77c9109e6a4de1ac5ed",
    "gdpr": false,
    "visitorName": null,
    "playbackUrl": "https://us.mouseflow.com/websites/e0c9ff05-6fcb-4c4a-8173-e5a0724987b1/recordings/2205b2c73797f9ba6c8e347dcd7769fc/play"
  },
  "events": [
    {
      "t": 1,
      "e": 1,
      "ty": 14,
      "x": 0,
      "y": 1199
    },
    {
      "t": 180,
      "e": 180,
      "ty": 0,
      "x": 1920,
      "y": 1200
    },
    {
      "t": 658,
      "e": 658,
      "ty": 2,
      "x": 510,
      "y": 743
    },
    {
      "t": 751,
      "e": 751,
      "ty": 41,
      "x": 46414,
      "y": 40717,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 900,
      "e": 900,
      "ty": 2,
      "x": 509,
      "y": 734
    },
    {
      "t": 1000,
      "e": 1000,
      "ty": 2,
      "x": 501,
      "y": 696
    },
    {
      "t": 1001,
      "e": 1001,
      "ty": 41,
      "x": 45403,
      "y": 38113,
      "ta": "> div.stimulus > div"
    },
    {
      "t": 1101,
      "e": 1101,
      "ty": 2,
      "x": 489,
      "y": 670
    },
    {
      "t": 1200,
      "e": 1200,
      "ty": 2,
      "x": 469,
      "y": 607
    },
    {
      "t": 1203,
      "e": 1203,
      "ty": 6,
      "x": 469,
      "y": 603,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1251,
      "e": 1251,
      "ty": 41,
      "x": 41468,
      "y": 56850,
      "ta": "#strategyAnswer"
    },
    {
      "t": 1300,
      "e": 1300,
      "ty": 2,
      "x": 466,
      "y": 585
    },
    {
      "t": 1401,
      "e": 1401,
      "ty": 2,
      "x": 466,
      "y": 584
    },
    {
      "t": 1501,
      "e": 1501,
      "ty": 41,
      "x": 41468,
      "y": 49568,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2701,
      "e": 2701,
      "ty": 2,
      "x": 465,
      "y": 583
    },
    {
      "t": 2751,
      "e": 2751,
      "ty": 41,
      "x": 41356,
      "y": 48759,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2810,
      "e": 2810,
      "ty": 3,
      "x": 465,
      "y": 583,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2813,
      "e": 2813,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2921,
      "e": 2921,
      "ty": 4,
      "x": 41356,
      "y": 48759,
      "ta": "#strategyAnswer"
    },
    {
      "t": 2921,
      "e": 2921,
      "ty": 5,
      "x": 465,
      "y": 583,
      "ta": "#strategyAnswer"
    },
    {
      "t": 9951,
      "e": 7921,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 9951,
      "e": 7921,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10000,
      "e": 7970,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 10060,
      "e": 8030,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 10061,
      "e": 8031,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10093,
      "e": 8063,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "th"
    },
    {
      "t": 10157,
      "e": 8127,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 10157,
      "e": 8127,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10220,
      "e": 8190,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "the"
    },
    {
      "t": 10245,
      "e": 8215,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 10246,
      "e": 8216,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10280,
      "e": 8250,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "the "
    },
    {
      "t": 10373,
      "e": 8343,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 10373,
      "e": 8343,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 10373,
      "e": 8343,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10460,
      "e": 8430,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 10460,
      "e": 8430,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10508,
      "e": 8478,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||di"
    },
    {
      "t": 10533,
      "e": 8503,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 10533,
      "e": 8503,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10573,
      "e": 8543,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 10652,
      "e": 8622,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 10653,
      "e": 8623,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 10669,
      "e": 8639,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||g"
    },
    {
      "t": 10803,
      "e": 8773,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "the diag"
    },
    {
      "t": 10822,
      "e": 8792,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 11389,
      "e": 9359,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 11390,
      "e": 9360,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11572,
      "e": 9542,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 11573,
      "e": 9543,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11605,
      "e": 9575,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||on"
    },
    {
      "t": 11757,
      "e": 9727,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "65"
    },
    {
      "t": 11758,
      "e": 9728,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 11812,
      "e": 9782,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||a"
    },
    {
      "t": 11924,
      "e": 9894,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 11965,
      "e": 9935,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 11966,
      "e": 9936,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12093,
      "e": 10063,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 12094,
      "e": 10064,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12109,
      "e": 10079,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||l "
    },
    {
      "t": 12229,
      "e": 10199,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12301,
      "e": 10271,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "76"
    },
    {
      "t": 12302,
      "e": 10272,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12510,
      "e": 10480,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 12510,
      "e": 10480,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12540,
      "e": 10510,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||li"
    },
    {
      "t": 12645,
      "e": 10615,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 12685,
      "e": 10655,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 12686,
      "e": 10656,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12802,
      "e": 10772,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "the diagonal lin"
    },
    {
      "t": 12822,
      "e": 10792,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 12822,
      "e": 10792,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 12932,
      "e": 10902,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||ne"
    },
    {
      "t": 12980,
      "e": 10950,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 13005,
      "e": 10975,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 13006,
      "e": 10976,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 13125,
      "e": 11095,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 18956,
      "e": 16095,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 18956,
      "e": 16095,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19045,
      "e": 16184,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 19045,
      "e": 16184,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19101,
      "e": 16240,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||to"
    },
    {
      "t": 19149,
      "e": 16288,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19150,
      "e": 16289,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19197,
      "e": 16336,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 19281,
      "e": 16420,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 19289,
      "e": 16428,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 19290,
      "e": 16429,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19400,
      "e": 16539,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 19401,
      "e": 16540,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19416,
      "e": 16555,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||th"
    },
    {
      "t": 19521,
      "e": 16660,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 19523,
      "e": 16662,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19569,
      "e": 16708,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||e"
    },
    {
      "t": 19585,
      "e": 16724,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 19585,
      "e": 16724,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 19648,
      "e": 16787,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 19704,
      "e": 16843,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 20004,
      "e": 17143,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 25689,
      "e": 21843,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "82"
    },
    {
      "t": 25691,
      "e": 21845,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25785,
      "e": 21939,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||r"
    },
    {
      "t": 25793,
      "e": 21947,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "73"
    },
    {
      "t": 25794,
      "e": 21948,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 25912,
      "e": 22066,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||i"
    },
    {
      "t": 25945,
      "e": 22099,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "71"
    },
    {
      "t": 25945,
      "e": 22099,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26057,
      "e": 22211,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 26058,
      "e": 22212,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26072,
      "e": 22226,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||gh"
    },
    {
      "t": 26206,
      "e": 22360,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "the diagonal line to the righ"
    },
    {
      "t": 26217,
      "e": 22371,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 26217,
      "e": 22371,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26248,
      "e": 22402,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||t"
    },
    {
      "t": 26249,
      "e": 22403,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 26250,
      "e": 22404,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 26353,
      "e": 22507,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+|| "
    },
    {
      "t": 26433,
      "e": 22587,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 27505,
      "e": 23659,
      "ty": 2,
      "x": 420,
      "y": 526
    },
    {
      "t": 27505,
      "e": 23659,
      "ty": 41,
      "x": 36297,
      "y": 2642,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27512,
      "e": 23666,
      "ty": 7,
      "x": 400,
      "y": 502,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27604,
      "e": 23758,
      "ty": 2,
      "x": 327,
      "y": 495
    },
    {
      "t": 27704,
      "e": 23858,
      "ty": 2,
      "x": 281,
      "y": 516
    },
    {
      "t": 27754,
      "e": 23908,
      "ty": 41,
      "x": 17188,
      "y": 61475,
      "ta": "#.strategy > p"
    },
    {
      "t": 27762,
      "e": 23916,
      "ty": 6,
      "x": 232,
      "y": 523,
      "ta": "#strategyAnswer"
    },
    {
      "t": 27805,
      "e": 23959,
      "ty": 2,
      "x": 188,
      "y": 524
    },
    {
      "t": 27905,
      "e": 24059,
      "ty": 2,
      "x": 129,
      "y": 527
    },
    {
      "t": 28004,
      "e": 24158,
      "ty": 2,
      "x": 127,
      "y": 530
    },
    {
      "t": 28004,
      "e": 24158,
      "ty": 41,
      "x": 3361,
      "y": 5878,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28104,
      "e": 24258,
      "ty": 2,
      "x": 121,
      "y": 544
    },
    {
      "t": 28254,
      "e": 24408,
      "ty": 41,
      "x": 2687,
      "y": 17205,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28293,
      "e": 24447,
      "ty": 3,
      "x": 121,
      "y": 544,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28420,
      "e": 24574,
      "ty": 4,
      "x": 2687,
      "y": 17205,
      "ta": "#strategyAnswer"
    },
    {
      "t": 28420,
      "e": 24574,
      "ty": 5,
      "x": 121,
      "y": 544,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29033,
      "e": 25187,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 29034,
      "e": 25188,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29136,
      "e": 25290,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "the  diagonal line to the right "
    },
    {
      "t": 29161,
      "e": 25315,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "68"
    },
    {
      "t": 29161,
      "e": 25315,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29265,
      "e": 25419,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 29266,
      "e": 25420,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29280,
      "e": 25434,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "the do diagonal line to the right "
    },
    {
      "t": 29406,
      "e": 25560,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "the do diagonal line to the right "
    },
    {
      "t": 29416,
      "e": 25570,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 29417,
      "e": 25571,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29440,
      "e": 25594,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "the don diagonal line to the right "
    },
    {
      "t": 29529,
      "e": 25683,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 29713,
      "e": 25867,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 29793,
      "e": 25947,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "the do diagonal line to the right "
    },
    {
      "t": 29881,
      "e": 26035,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 29882,
      "e": 26036,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 29952,
      "e": 26106,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "83"
    },
    {
      "t": 29952,
      "e": 26106,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30032,
      "e": 26186,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "the dots diagonal line to the right "
    },
    {
      "t": 30065,
      "e": 26219,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 30065,
      "e": 26219,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30088,
      "e": 26242,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "the dots  diagonal line to the right "
    },
    {
      "t": 30168,
      "e": 26322,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "80"
    },
    {
      "t": 30168,
      "e": 26322,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30184,
      "e": 26338,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "the dots p diagonal line to the right "
    },
    {
      "t": 30312,
      "e": 26466,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30377,
      "e": 26531,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "77"
    },
    {
      "t": 30377,
      "e": 26531,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30392,
      "e": 26546,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 30392,
      "e": 26546,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 30432,
      "e": 26586,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "the dots pmn diagonal line to the right "
    },
    {
      "t": 30480,
      "e": 26634,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 30752,
      "e": 26906,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30841,
      "e": 26995,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "the dots pm diagonal line to the right "
    },
    {
      "t": 30904,
      "e": 27058,
      "ty": 2,
      "x": 121,
      "y": 545
    },
    {
      "t": 30904,
      "e": 27058,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 30968,
      "e": 27122,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "the dots p diagonal line to the right "
    },
    {
      "t": 31004,
      "e": 27158,
      "ty": 41,
      "x": 2687,
      "y": 18014,
      "ta": "#strategyAnswer"
    },
    {
      "t": 31048,
      "e": 27202,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "8"
    },
    {
      "t": 31112,
      "e": 27266,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "the dots  diagonal line to the right "
    },
    {
      "t": 32097,
      "e": 28251,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "79"
    },
    {
      "t": 32098,
      "e": 28252,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32179,
      "e": 28254,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "the dots o diagonal line to the right "
    },
    {
      "t": 32264,
      "e": 28339,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "78"
    },
    {
      "t": 32265,
      "e": 28340,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 32344,
      "e": 28419,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "the dots on diagonal line to the right "
    },
    {
      "t": 33457,
      "e": 29532,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "32"
    },
    {
      "t": 33458,
      "e": 29533,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33536,
      "e": 29611,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "84"
    },
    {
      "t": 33536,
      "e": 29611,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33560,
      "e": 29635,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "the dots on t diagonal line to the right "
    },
    {
      "t": 33640,
      "e": 29715,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "72"
    },
    {
      "t": 33640,
      "e": 29715,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33673,
      "e": 29748,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "the dots on th diagonal line to the right "
    },
    {
      "t": 33753,
      "e": 29828,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "+||"
    },
    {
      "t": 33761,
      "e": 29836,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "69"
    },
    {
      "t": 33762,
      "e": 29837,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 33864,
      "e": 29939,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "the dots on the diagonal line to the right "
    },
    {
      "t": 34304,
      "e": 30379,
      "ty": 2,
      "x": 126,
      "y": 551
    },
    {
      "t": 34404,
      "e": 30479,
      "ty": 2,
      "x": 133,
      "y": 559
    },
    {
      "t": 34450,
      "e": 30525,
      "ty": 7,
      "x": 185,
      "y": 605,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34504,
      "e": 30579,
      "ty": 2,
      "x": 334,
      "y": 687
    },
    {
      "t": 34504,
      "e": 30579,
      "ty": 41,
      "x": 7211,
      "y": 42771,
      "ta": "> div.stimulus > div > div:[3]"
    },
    {
      "t": 34517,
      "e": 30592,
      "ty": 6,
      "x": 351,
      "y": 688,
      "ta": "#strategyButton"
    },
    {
      "t": 34604,
      "e": 30679,
      "ty": 2,
      "x": 361,
      "y": 686
    },
    {
      "t": 34704,
      "e": 30779,
      "ty": 2,
      "x": 380,
      "y": 668
    },
    {
      "t": 34754,
      "e": 30829,
      "ty": 41,
      "x": 24251,
      "y": 23641,
      "ta": "#strategyButton"
    },
    {
      "t": 34804,
      "e": 30879,
      "ty": 2,
      "x": 383,
      "y": 667
    },
    {
      "t": 34861,
      "e": 30936,
      "ty": 3,
      "x": 383,
      "y": 667,
      "ta": "#strategyButton"
    },
    {
      "t": 34863,
      "e": 30938,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer",
      "v": "the dots on the diagonal line to the right "
    },
    {
      "t": 34864,
      "e": 30939,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyAnswer"
    },
    {
      "t": 34865,
      "e": 30940,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 34980,
      "e": 31055,
      "ty": 4,
      "x": 24251,
      "y": 23641,
      "ta": "#strategyButton"
    },
    {
      "t": 34991,
      "e": 31066,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#strategyButton"
    },
    {
      "t": 34994,
      "e": 31069,
      "ty": 5,
      "x": 383,
      "y": 667,
      "ta": "#strategyButton"
    },
    {
      "t": 34999,
      "e": 31074,
      "ty": 38,
      "x": 1,
      "y": 0
    },
    {
      "t": 35704,
      "e": 31779,
      "ty": 2,
      "x": 385,
      "y": 660
    },
    {
      "t": 35755,
      "e": 31830,
      "ty": 41,
      "x": 12983,
      "y": 36119,
      "ta": "html > body"
    },
    {
      "t": 36001,
      "e": 32076,
      "ty": 38,
      "x": 2,
      "y": 0
    },
    {
      "t": 36512,
      "e": 32587,
      "ty": 2,
      "x": 668,
      "y": 588
    },
    {
      "t": 36512,
      "e": 32587,
      "ty": 41,
      "x": 22728,
      "y": 32130,
      "ta": "html > body"
    },
    {
      "t": 36605,
      "e": 32680,
      "ty": 2,
      "x": 856,
      "y": 542
    },
    {
      "t": 36704,
      "e": 32779,
      "ty": 2,
      "x": 856,
      "y": 543
    },
    {
      "t": 36736,
      "e": 32811,
      "ty": 6,
      "x": 856,
      "y": 556,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 36755,
      "e": 32830,
      "ty": 41,
      "x": 10381,
      "y": 24965,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 36802,
      "e": 32877,
      "ty": 7,
      "x": 859,
      "y": 575,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 36804,
      "e": 32879,
      "ty": 2,
      "x": 859,
      "y": 575
    },
    {
      "t": 36905,
      "e": 32980,
      "ty": 2,
      "x": 859,
      "y": 576
    },
    {
      "t": 37004,
      "e": 33079,
      "ty": 2,
      "x": 860,
      "y": 576
    },
    {
      "t": 37004,
      "e": 33079,
      "ty": 41,
      "x": 11246,
      "y": 60602,
      "ta": "#jspsych-survey-text-0"
    },
    {
      "t": 37035,
      "e": 33110,
      "ty": 6,
      "x": 866,
      "y": 574,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 37104,
      "e": 33179,
      "ty": 2,
      "x": 869,
      "y": 572
    },
    {
      "t": 37204,
      "e": 33279,
      "ty": 2,
      "x": 875,
      "y": 561
    },
    {
      "t": 37255,
      "e": 33330,
      "ty": 41,
      "x": 14491,
      "y": 21845,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 37294,
      "e": 33369,
      "ty": 3,
      "x": 875,
      "y": 561,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 37295,
      "e": 33370,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 37429,
      "e": 33504,
      "ty": 4,
      "x": 14491,
      "y": 21845,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 37429,
      "e": 33504,
      "ty": 5,
      "x": 875,
      "y": 561,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 38521,
      "e": 34596,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "50"
    },
    {
      "t": 38521,
      "e": 34596,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 38665,
      "e": 34740,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "2"
    },
    {
      "t": 38977,
      "e": 35052,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "48"
    },
    {
      "t": 38978,
      "e": 35053,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 39096,
      "e": 35171,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 39173,
      "e": 35248,
      "ty": 7,
      "x": 875,
      "y": 577,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 39205,
      "e": 35280,
      "ty": 2,
      "x": 875,
      "y": 607
    },
    {
      "t": 39255,
      "e": 35330,
      "ty": 41,
      "x": 14274,
      "y": 38052,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 39304,
      "e": 35379,
      "ty": 6,
      "x": 869,
      "y": 652,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 39306,
      "e": 35381,
      "ty": 2,
      "x": 869,
      "y": 652
    },
    {
      "t": 39354,
      "e": 35429,
      "ty": 7,
      "x": 863,
      "y": 669,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 39404,
      "e": 35479,
      "ty": 2,
      "x": 862,
      "y": 671
    },
    {
      "t": 39504,
      "e": 35579,
      "ty": 2,
      "x": 860,
      "y": 671
    },
    {
      "t": 39505,
      "e": 35580,
      "ty": 41,
      "x": 11246,
      "y": 62011,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 39537,
      "e": 35612,
      "ty": 6,
      "x": 859,
      "y": 667,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 39605,
      "e": 35680,
      "ty": 2,
      "x": 856,
      "y": 658
    },
    {
      "t": 39704,
      "e": 35779,
      "ty": 2,
      "x": 856,
      "y": 653
    },
    {
      "t": 39755,
      "e": 35830,
      "ty": 41,
      "x": 10381,
      "y": 18724,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 39789,
      "e": 35864,
      "ty": 3,
      "x": 856,
      "y": 653,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 39791,
      "e": 35866,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea",
      "v": "20"
    },
    {
      "t": 39791,
      "e": 35866,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-0 > textarea"
    },
    {
      "t": 39791,
      "e": 35866,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 39893,
      "e": 35968,
      "ty": 4,
      "x": 10381,
      "y": 18724,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 39893,
      "e": 35968,
      "ty": 5,
      "x": 856,
      "y": 653,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40005,
      "e": 36080,
      "ty": 19,
      "x": 0,
      "y": 0
    },
    {
      "t": 40521,
      "e": 36596,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 40529,
      "e": 36604,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "90"
    },
    {
      "t": 40529,
      "e": 36604,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 40568,
      "e": 36643,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Z"
    },
    {
      "t": 40624,
      "e": 36699,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Z"
    },
    {
      "t": 40672,
      "e": 36747,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 40768,
      "e": 36843,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "Z"
    },
    {
      "t": 41481,
      "e": 37556,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "8"
    },
    {
      "t": 41606,
      "e": 37681,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 41616,
      "e": 37691,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": ""
    },
    {
      "t": 41752,
      "e": 37827,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "16"
    },
    {
      "t": 42024,
      "e": 38099,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "85"
    },
    {
      "t": 42024,
      "e": 38099,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 42089,
      "e": 38164,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 42205,
      "e": 38280,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "U"
    },
    {
      "t": 42217,
      "e": 38292,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "83"
    },
    {
      "t": 42217,
      "e": 38292,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 42377,
      "e": 38452,
      "ty": 33,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "65"
    },
    {
      "t": 42377,
      "e": 38452,
      "ty": 8,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 42424,
      "e": 38499,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 42544,
      "e": 38619,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 42640,
      "e": 38715,
      "ty": 9,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 42991,
      "e": 39066,
      "ty": 7,
      "x": 881,
      "y": 672,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 43005,
      "e": 39080,
      "ty": 2,
      "x": 881,
      "y": 672
    },
    {
      "t": 43006,
      "e": 39081,
      "ty": 41,
      "x": 15788,
      "y": 62716,
      "ta": "#jspsych-survey-text-1"
    },
    {
      "t": 43105,
      "e": 39180,
      "ty": 2,
      "x": 888,
      "y": 673
    },
    {
      "t": 43124,
      "e": 39199,
      "ty": 6,
      "x": 898,
      "y": 677,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 43204,
      "e": 39279,
      "ty": 2,
      "x": 900,
      "y": 679
    },
    {
      "t": 43254,
      "e": 39329,
      "ty": 41,
      "x": 8801,
      "y": 17873,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 43305,
      "e": 39380,
      "ty": 2,
      "x": 920,
      "y": 687
    },
    {
      "t": 43373,
      "e": 39448,
      "ty": 3,
      "x": 920,
      "y": 687,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 43375,
      "e": 39450,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea",
      "v": "USA"
    },
    {
      "t": 43375,
      "e": 39450,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-1 > textarea"
    },
    {
      "t": 43375,
      "e": 39450,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 43501,
      "e": 39576,
      "ty": 4,
      "x": 12409,
      "y": 21845,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 43501,
      "e": 39576,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 43502,
      "e": 39577,
      "ty": 5,
      "x": 920,
      "y": 687,
      "ta": "#jspsych-survey-text-next"
    },
    {
      "t": 43502,
      "e": 39577,
      "ty": 38,
      "x": 3,
      "y": 0
    },
    {
      "t": 43505,
      "e": 39580,
      "ty": 41,
      "x": 31407,
      "y": 37614,
      "ta": "html > body"
    },
    {
      "t": 44524,
      "e": 40599,
      "ty": 38,
      "x": 4,
      "y": 0
    },
    {
      "t": 45404,
      "e": 41479,
      "ty": 2,
      "x": 925,
      "y": 592
    },
    {
      "t": 45505,
      "e": 41580,
      "ty": 2,
      "x": 857,
      "y": 408
    },
    {
      "t": 45505,
      "e": 41580,
      "ty": 41,
      "x": 41647,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-1-0 > label"
    },
    {
      "t": 45604,
      "e": 41679,
      "ty": 2,
      "x": 793,
      "y": 282
    },
    {
      "t": 45705,
      "e": 41780,
      "ty": 2,
      "x": 789,
      "y": 248
    },
    {
      "t": 45755,
      "e": 41830,
      "ty": 41,
      "x": 27240,
      "y": 12907,
      "ta": "html > body"
    },
    {
      "t": 45805,
      "e": 41880,
      "ty": 2,
      "x": 814,
      "y": 233
    },
    {
      "t": 45905,
      "e": 41980,
      "ty": 2,
      "x": 826,
      "y": 226
    },
    {
      "t": 46005,
      "e": 42080,
      "ty": 2,
      "x": 827,
      "y": 228
    },
    {
      "t": 46005,
      "e": 42080,
      "ty": 41,
      "x": 1323,
      "y": 7021,
      "ta": "#jspsych-survey-multi-choice-option-0-0"
    },
    {
      "t": 46028,
      "e": 42103,
      "ty": 6,
      "x": 827,
      "y": 232,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 46105,
      "e": 42180,
      "ty": 2,
      "x": 827,
      "y": 233
    },
    {
      "t": 46213,
      "e": 42288,
      "ty": 3,
      "x": 827,
      "y": 233,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 46214,
      "e": 42289,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 46255,
      "e": 42330,
      "ty": 41,
      "x": 2914,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 46301,
      "e": 42376,
      "ty": 4,
      "x": 2914,
      "y": 5041,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 46301,
      "e": 42376,
      "ty": 5,
      "x": 827,
      "y": 233,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 46302,
      "e": 42377,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf",
      "v": "English"
    },
    {
      "t": 46804,
      "e": 42879,
      "ty": 2,
      "x": 827,
      "y": 239
    },
    {
      "t": 46811,
      "e": 42886,
      "ty": 7,
      "x": 829,
      "y": 248,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 46845,
      "e": 42920,
      "ty": 6,
      "x": 837,
      "y": 263,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 46904,
      "e": 42979,
      "ty": 2,
      "x": 837,
      "y": 268
    },
    {
      "t": 46910,
      "e": 42985,
      "ty": 7,
      "x": 840,
      "y": 274,
      "ta": "jspsych-survey-multi-choice-response-0[1]_mf"
    },
    {
      "t": 47004,
      "e": 43079,
      "ty": 2,
      "x": 863,
      "y": 376
    },
    {
      "t": 47004,
      "e": 43079,
      "ty": 41,
      "x": 9867,
      "y": 49151,
      "ta": "#jspsych-survey-multi-choice-1 > p"
    },
    {
      "t": 47104,
      "e": 43179,
      "ty": 2,
      "x": 862,
      "y": 451
    },
    {
      "t": 47205,
      "e": 43280,
      "ty": 2,
      "x": 859,
      "y": 458
    },
    {
      "t": 47255,
      "e": 43330,
      "ty": 41,
      "x": 6782,
      "y": 2340,
      "ta": "#jspsych-survey-multi-choice-option-1-2"
    },
    {
      "t": 47305,
      "e": 43380,
      "ty": 2,
      "x": 827,
      "y": 454
    },
    {
      "t": 47404,
      "e": 43479,
      "ty": 2,
      "x": 805,
      "y": 436
    },
    {
      "t": 47505,
      "e": 43580,
      "ty": 2,
      "x": 806,
      "y": 434
    },
    {
      "t": 47505,
      "e": 43580,
      "ty": 41,
      "x": 27481,
      "y": 23599,
      "ta": "html > body"
    },
    {
      "t": 47604,
      "e": 43679,
      "ty": 2,
      "x": 832,
      "y": 434
    },
    {
      "t": 47705,
      "e": 43780,
      "ty": 2,
      "x": 833,
      "y": 434
    },
    {
      "t": 47755,
      "e": 43830,
      "ty": 41,
      "x": 9248,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 47758,
      "e": 43833,
      "ty": 3,
      "x": 833,
      "y": 434,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 47759,
      "e": 43834,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-0[0]_mf"
    },
    {
      "t": 47892,
      "e": 43967,
      "ty": 4,
      "x": 9248,
      "y": 3276,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 47893,
      "e": 43968,
      "ty": 5,
      "x": 833,
      "y": 434,
      "ta": "#jspsych-survey-multi-choice-option-1-1 > label"
    },
    {
      "t": 47895,
      "e": 43970,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 47898,
      "e": 43973,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf",
      "v": "Second"
    },
    {
      "t": 48379,
      "e": 44454,
      "ty": 6,
      "x": 835,
      "y": 439,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 48405,
      "e": 44480,
      "ty": 2,
      "x": 835,
      "y": 444
    },
    {
      "t": 48413,
      "e": 44488,
      "ty": 7,
      "x": 837,
      "y": 456,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 48444,
      "e": 44519,
      "ty": 6,
      "x": 839,
      "y": 469,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 48462,
      "e": 44537,
      "ty": 7,
      "x": 841,
      "y": 477,
      "ta": "jspsych-survey-multi-choice-response-1[2]_mf"
    },
    {
      "t": 48504,
      "e": 44579,
      "ty": 2,
      "x": 850,
      "y": 503
    },
    {
      "t": 48505,
      "e": 44580,
      "ty": 41,
      "x": 25650,
      "y": 45874,
      "ta": "#jspsych-survey-multi-choice-option-1-3 > label"
    },
    {
      "t": 48605,
      "e": 44680,
      "ty": 2,
      "x": 879,
      "y": 604
    },
    {
      "t": 48705,
      "e": 44780,
      "ty": 2,
      "x": 893,
      "y": 647
    },
    {
      "t": 48755,
      "e": 44830,
      "ty": 41,
      "x": 16987,
      "y": 8665,
      "ta": "#jspsych-survey-multi-choice-2"
    },
    {
      "t": 48805,
      "e": 44880,
      "ty": 2,
      "x": 893,
      "y": 649
    },
    {
      "t": 48905,
      "e": 44980,
      "ty": 2,
      "x": 893,
      "y": 654
    },
    {
      "t": 49005,
      "e": 45080,
      "ty": 2,
      "x": 889,
      "y": 668
    },
    {
      "t": 49005,
      "e": 45080,
      "ty": 41,
      "x": 18144,
      "y": 9830,
      "ta": "#jspsych-survey-multi-choice-option-2-0 > label"
    },
    {
      "t": 49105,
      "e": 45180,
      "ty": 2,
      "x": 881,
      "y": 684
    },
    {
      "t": 49204,
      "e": 45279,
      "ty": 2,
      "x": 878,
      "y": 685
    },
    {
      "t": 49256,
      "e": 45331,
      "ty": 41,
      "x": 11766,
      "y": 60853,
      "ta": "#jspsych-survey-multi-choice-option-2-0"
    },
    {
      "t": 49305,
      "e": 45380,
      "ty": 2,
      "x": 860,
      "y": 691
    },
    {
      "t": 49404,
      "e": 45479,
      "ty": 2,
      "x": 840,
      "y": 706
    },
    {
      "t": 49413,
      "e": 45488,
      "ty": 6,
      "x": 839,
      "y": 708,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 49430,
      "e": 45505,
      "ty": 7,
      "x": 834,
      "y": 718,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 49446,
      "e": 45521,
      "ty": 6,
      "x": 829,
      "y": 727,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 49462,
      "e": 45537,
      "ty": 7,
      "x": 822,
      "y": 738,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 49504,
      "e": 45579,
      "ty": 2,
      "x": 819,
      "y": 747
    },
    {
      "t": 49505,
      "e": 45580,
      "ty": 41,
      "x": 27928,
      "y": 40938,
      "ta": "html > body"
    },
    {
      "t": 49604,
      "e": 45679,
      "ty": 2,
      "x": 817,
      "y": 756
    },
    {
      "t": 49705,
      "e": 45780,
      "ty": 2,
      "x": 817,
      "y": 771
    },
    {
      "t": 49755,
      "e": 45830,
      "ty": 41,
      "x": 27860,
      "y": 42489,
      "ta": "html > body"
    },
    {
      "t": 49805,
      "e": 45880,
      "ty": 2,
      "x": 817,
      "y": 777
    },
    {
      "t": 49905,
      "e": 45980,
      "ty": 2,
      "x": 817,
      "y": 780
    },
    {
      "t": 49979,
      "e": 46054,
      "ty": 6,
      "x": 832,
      "y": 762,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 50004,
      "e": 46079,
      "ty": 2,
      "x": 836,
      "y": 755
    },
    {
      "t": 50005,
      "e": 46080,
      "ty": 41,
      "x": 48284,
      "y": 15123,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 50030,
      "e": 46105,
      "ty": 7,
      "x": 837,
      "y": 751,
      "ta": "jspsych-survey-multi-choice-response-2[3]_mf"
    },
    {
      "t": 50105,
      "e": 46180,
      "ty": 2,
      "x": 838,
      "y": 747
    },
    {
      "t": 50163,
      "e": 46238,
      "ty": 6,
      "x": 838,
      "y": 733,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 50196,
      "e": 46271,
      "ty": 7,
      "x": 836,
      "y": 720,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 50204,
      "e": 46279,
      "ty": 2,
      "x": 836,
      "y": 720
    },
    {
      "t": 50256,
      "e": 46280,
      "ty": 41,
      "x": 2917,
      "y": 62258,
      "ta": "#jspsych-survey-multi-choice-option-2-1 > label"
    },
    {
      "t": 50296,
      "e": 46320,
      "ty": 6,
      "x": 832,
      "y": 708,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 50304,
      "e": 46328,
      "ty": 2,
      "x": 832,
      "y": 708
    },
    {
      "t": 50405,
      "e": 46429,
      "ty": 2,
      "x": 831,
      "y": 703
    },
    {
      "t": 50504,
      "e": 46528,
      "ty": 2,
      "x": 830,
      "y": 696
    },
    {
      "t": 50506,
      "e": 46530,
      "ty": 41,
      "x": 18037,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 50997,
      "e": 47021,
      "ty": 3,
      "x": 830,
      "y": 696,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 51001,
      "e": 47025,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-1[1]_mf"
    },
    {
      "t": 51001,
      "e": 47025,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 51108,
      "e": 47132,
      "ty": 4,
      "x": 18037,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 51108,
      "e": 47132,
      "ty": 5,
      "x": 830,
      "y": 696,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 51108,
      "e": 47132,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf",
      "v": "Social Sciences (incl. CogSci)"
    },
    {
      "t": 51754,
      "e": 47778,
      "ty": 41,
      "x": 18037,
      "y": 45370,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 51804,
      "e": 47828,
      "ty": 2,
      "x": 830,
      "y": 706
    },
    {
      "t": 51917,
      "e": 47941,
      "ty": 3,
      "x": 830,
      "y": 706,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 52004,
      "e": 48028,
      "ty": 41,
      "x": 18037,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 52044,
      "e": 48068,
      "ty": 4,
      "x": 18037,
      "y": 50411,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 52044,
      "e": 48068,
      "ty": 5,
      "x": 830,
      "y": 706,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 52478,
      "e": 48502,
      "ty": 7,
      "x": 830,
      "y": 709,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 52504,
      "e": 48528,
      "ty": 2,
      "x": 830,
      "y": 719
    },
    {
      "t": 52504,
      "e": 48528,
      "ty": 41,
      "x": 2035,
      "y": 4681,
      "ta": "#jspsych-survey-multi-choice-option-2-2"
    },
    {
      "t": 52515,
      "e": 48539,
      "ty": 6,
      "x": 837,
      "y": 735,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 52532,
      "e": 48556,
      "ty": 7,
      "x": 849,
      "y": 763,
      "ta": "jspsych-survey-multi-choice-response-2[2]_mf"
    },
    {
      "t": 52604,
      "e": 48628,
      "ty": 2,
      "x": 862,
      "y": 823
    },
    {
      "t": 52704,
      "e": 48728,
      "ty": 2,
      "x": 789,
      "y": 946
    },
    {
      "t": 52754,
      "e": 48778,
      "ty": 41,
      "x": 25173,
      "y": 56228,
      "ta": "html > body"
    },
    {
      "t": 52804,
      "e": 48828,
      "ty": 2,
      "x": 739,
      "y": 1027
    },
    {
      "t": 52904,
      "e": 48928,
      "ty": 2,
      "x": 816,
      "y": 992
    },
    {
      "t": 52916,
      "e": 48940,
      "ty": 6,
      "x": 827,
      "y": 985,
      "ta": "jspsych-survey-multi-choice-response-3[2]_mf"
    },
    {
      "t": 52932,
      "e": 48956,
      "ty": 7,
      "x": 832,
      "y": 980,
      "ta": "jspsych-survey-multi-choice-response-3[2]_mf"
    },
    {
      "t": 53004,
      "e": 49028,
      "ty": 2,
      "x": 834,
      "y": 977
    },
    {
      "t": 53005,
      "e": 49029,
      "ty": 41,
      "x": 2985,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-option-3-2"
    },
    {
      "t": 53085,
      "e": 49109,
      "ty": 6,
      "x": 833,
      "y": 968,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 53104,
      "e": 49128,
      "ty": 2,
      "x": 833,
      "y": 966
    },
    {
      "t": 53204,
      "e": 49228,
      "ty": 2,
      "x": 830,
      "y": 961
    },
    {
      "t": 53254,
      "e": 49278,
      "ty": 41,
      "x": 18037,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 53304,
      "e": 49328,
      "ty": 2,
      "x": 830,
      "y": 960
    },
    {
      "t": 53317,
      "e": 49341,
      "ty": 3,
      "x": 830,
      "y": 960,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 53318,
      "e": 49342,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-2[1]_mf"
    },
    {
      "t": 53319,
      "e": 49343,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 53412,
      "e": 49436,
      "ty": 4,
      "x": 18037,
      "y": 20164,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 53412,
      "e": 49436,
      "ty": 5,
      "x": 830,
      "y": 960,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 53412,
      "e": 49436,
      "ty": 10,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf",
      "v": "Female"
    },
    {
      "t": 53499,
      "e": 49523,
      "ty": 7,
      "x": 838,
      "y": 974,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 53504,
      "e": 49528,
      "ty": 2,
      "x": 838,
      "y": 974
    },
    {
      "t": 53504,
      "e": 49528,
      "ty": 41,
      "x": 3934,
      "y": 58513,
      "ta": "#jspsych-survey-multi-choice-option-3-1"
    },
    {
      "t": 53532,
      "e": 49556,
      "ty": 6,
      "x": 871,
      "y": 1018,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 53604,
      "e": 49628,
      "ty": 2,
      "x": 872,
      "y": 1019
    },
    {
      "t": 53704,
      "e": 49728,
      "ty": 2,
      "x": 875,
      "y": 1022
    },
    {
      "t": 53754,
      "e": 49778,
      "ty": 41,
      "x": 23490,
      "y": 33760,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 54229,
      "e": 50253,
      "ty": 3,
      "x": 875,
      "y": 1022,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 54230,
      "e": 50254,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "jspsych-survey-multi-choice-response-3[1]_mf"
    },
    {
      "t": 54231,
      "e": 50255,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 54340,
      "e": 50364,
      "ty": 4,
      "x": 23490,
      "y": 33760,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 54340,
      "e": 50364,
      "ty": 5,
      "x": 875,
      "y": 1022,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 54343,
      "e": 50367,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-next"
    },
    {
      "t": 54344,
      "e": 50368,
      "ty": 13,
      "x": 0,
      "y": 0,
      "ta": "#jspsych-survey-multi-choice-form"
    },
    {
      "t": 54345,
      "e": 50369,
      "ty": 38,
      "x": 5,
      "y": 0
    },
    {
      "t": 55204,
      "e": 51228,
      "ty": 2,
      "x": 877,
      "y": 1022
    },
    {
      "t": 55254,
      "e": 51278,
      "ty": 41,
      "x": 29926,
      "y": 56172,
      "ta": "html > body"
    },
    {
      "t": 55440,
      "e": 51464,
      "ty": 38,
      "x": 6,
      "y": 0
    },
    {
      "t": 56254,
      "e": 52278,
      "ty": 41,
      "x": 29053,
      "y": 62025,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 56304,
      "e": 52328,
      "ty": 2,
      "x": 902,
      "y": 1024
    },
    {
      "t": 56404,
      "e": 52428,
      "ty": 2,
      "x": 958,
      "y": 1048
    },
    {
      "t": 56504,
      "e": 52528,
      "ty": 2,
      "x": 976,
      "y": 1054
    },
    {
      "t": 56505,
      "e": 52529,
      "ty": 41,
      "x": 33579,
      "y": 64240,
      "ta": "> div.masterdiv > div:[2]"
    },
    {
      "t": 56603,
      "e": 52627,
      "ty": 6,
      "x": 967,
      "y": 1076,
      "ta": "#start"
    },
    {
      "t": 56604,
      "e": 52628,
      "ty": 2,
      "x": 967,
      "y": 1076
    },
    {
      "t": 56704,
      "e": 52728,
      "ty": 2,
      "x": 959,
      "y": 1092
    },
    {
      "t": 56754,
      "e": 52778,
      "ty": 41,
      "x": 27033,
      "y": 37224,
      "ta": "#start"
    },
    {
      "t": 56788,
      "e": 52812,
      "ty": 3,
      "x": 959,
      "y": 1092,
      "ta": "#start"
    },
    {
      "t": 56790,
      "e": 52814,
      "ty": 11,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 56900,
      "e": 52924,
      "ty": 4,
      "x": 27033,
      "y": 37224,
      "ta": "#start"
    },
    {
      "t": 56902,
      "e": 52926,
      "ty": 12,
      "x": 0,
      "y": 0,
      "ta": "#start"
    },
    {
      "t": 56904,
      "e": 52927,
      "ty": 5,
      "x": 959,
      "y": 1092,
      "ta": "#start"
    },
    {
      "t": 56906,
      "e": 52929,
      "ty": 38,
      "x": 7,
      "y": 0
    },
    {
      "t": 57936,
      "e": 53959,
      "ty": 38,
      "x": 8,
      "y": 0
    },
    {
      "t": 58758,
      "e": 54781,
      "ty": 2,
      "x": 874,
      "y": 997
    },
    {
      "t": 58758,
      "e": 54781,
      "ty": 41,
      "x": 28664,
      "y": 32854,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 58818,
      "e": 54841,
      "ty": 2,
      "x": 755,
      "y": 837
    },
    {
      "t": 58905,
      "e": 54928,
      "ty": 2,
      "x": 512,
      "y": 569
    },
    {
      "t": 59004,
      "e": 55027,
      "ty": 2,
      "x": 452,
      "y": 524
    },
    {
      "t": 59004,
      "e": 55027,
      "ty": 41,
      "x": 8414,
      "y": 32751,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 59104,
      "e": 55127,
      "ty": 2,
      "x": 451,
      "y": 524
    },
    {
      "t": 59255,
      "e": 55278,
      "ty": 41,
      "x": 8366,
      "y": 32751,
      "ta": "#jspsych-data-display"
    },
    {
      "t": 59314,
      "e": 55337,
      "ty": 20,
      "x": 0,
      "y": 0
    }
  ],
  "domMutations": [
    {
      "sequence": 1,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":56},{\"id\":57},{\"id\":58},{\"id\":59},{\"id\":60},{\"id\":61},{\"id\":62},{\"id\":63},{\"id\":64},{\"id\":65},{\"id\":66},{\"id\":67},{\"id\":68},{\"id\":69},{\"id\":70},{\"id\":71},{\"id\":72},{\"id\":73},{\"id\":74},{\"id\":75},{\"id\":76},{\"id\":77},{\"id\":78},{\"id\":79},{\"id\":80},{\"id\":81},{\"id\":82},{\"id\":83},{\"id\":84},{\"id\":85},{\"id\":86},{\"id\":87},{\"id\":88},{\"id\":89},{\"id\":90},{\"id\":91},{\"id\":92},{\"id\":93},{\"id\":94},{\"id\":95},{\"id\":96},{\"id\":97},{\"id\":98},{\"id\":99},{\"id\":100},{\"id\":101},{\"id\":102},{\"id\":103},{\"id\":104},{\"id\":105},{\"id\":106},{\"id\":107},{\"id\":108},{\"id\":109},{\"id\":110},{\"id\":111},{\"id\":112},{\"id\":113},{\"id\":114},{\"id\":115},{\"id\":116},{\"id\":117},{\"id\":118},{\"id\":119},{\"id\":120},{\"id\":121},{\"id\":122},{\"id\":123},{\"id\":124},{\"id\":125},{\"id\":126},{\"id\":127},{\"id\":128},{\"id\":129},{\"id\":130},{\"id\":131},{\"id\":132},{\"id\":133},{\"id\":134},{\"id\":135},{\"id\":136},{\"id\":137},{\"id\":138},{\"id\":139},{\"id\":140},{\"id\":141},{\"id\":142},{\"id\":143},{\"id\":144},{\"id\":145},{\"id\":146},{\"id\":147},{\"id\":148},{\"id\":149},{\"id\":150},{\"id\":151},{\"id\":152},{\"id\":153},{\"id\":154},{\"id\":155},{\"id\":156},{\"id\":157},{\"id\":158},{\"id\":159},{\"id\":160},{\"id\":161},{\"id\":162},{\"id\":163},{\"id\":164},{\"id\":165},{\"id\":166},{\"id\":167},{\"id\":168},{\"id\":169},{\"id\":170},{\"id\":171},{\"id\":172},{\"id\":173},{\"id\":174},{\"id\":175},{\"id\":176},{\"id\":177},{\"id\":178},{\"id\":179},{\"id\":180},{\"id\":181},{\"id\":182},{\"id\":183},{\"id\":184},{\"id\":185},{\"id\":186},{\"id\":187},{\"id\":188},{\"id\":189},{\"id\":190},{\"id\":191},{\"id\":192},{\"id\":193},{\"id\":194},{\"id\":195},{\"id\":196},{\"id\":197},{\"id\":198},{\"id\":199},{\"id\":200},{\"id\":201},{\"id\":202},{\"id\":203},{\"id\":204},{\"id\":205},{\"id\":206},{\"id\":207},{\"id\":208},{\"id\":209},{\"id\":210},{\"id\":211},{\"id\":212},{\"id\":213},{\"id\":214},{\"id\":215},{\"id\":216},{\"id\":217},{\"id\":218},{\"id\":219},{\"id\":220},{\"id\":221},{\"id\":222},{\"id\":223},{\"id\":224},{\"id\":225},{\"id\":226},{\"id\":227},{\"id\":228},{\"id\":229},{\"id\":230},{\"id\":231},{\"id\":232},{\"id\":233},{\"id\":234},{\"id\":235},{\"id\":236},{\"id\":237},{\"id\":238},{\"id\":239},{\"id\":240},{\"id\":241},{\"id\":242},{\"id\":243},{\"id\":244},{\"id\":245},{\"id\":246},{\"id\":247},{\"id\":248},{\"id\":249},{\"id\":250},{\"id\":251},{\"id\":252},{\"id\":253},{\"id\":254},{\"id\":255},{\"id\":256},{\"id\":257},{\"id\":258},{\"id\":259},{\"id\":260},{\"id\":261},{\"id\":262},{\"id\":263},{\"id\":264},{\"id\":265},{\"id\":266},{\"id\":267},{\"id\":268},{\"id\":269},{\"id\":270},{\"id\":271},{\"id\":272},{\"id\":273},{\"id\":274},{\"id\":275},{\"id\":276},{\"id\":277},{\"id\":278},{\"id\":279},{\"id\":280},{\"id\":281},{\"id\":282},{\"id\":283},{\"id\":284},{\"id\":285},{\"id\":286},{\"id\":287},{\"id\":288},{\"id\":289},{\"id\":290},{\"id\":291},{\"id\":292},{\"id\":293},{\"id\":294},{\"id\":295},{\"id\":296},{\"id\":297},{\"id\":298},{\"id\":299},{\"id\":300},{\"id\":301},{\"id\":302},{\"id\":303},{\"id\":304},{\"id\":305},{\"id\":306},{\"id\":307},{\"id\":308},{\"id\":309},{\"id\":310},{\"id\":311},{\"id\":312},{\"id\":313},{\"id\":314},{\"id\":315},{\"id\":316},{\"id\":317},{\"id\":318},{\"id\":319},{\"id\":320},{\"id\":321},{\"id\":322},{\"id\":323},{\"id\":324},{\"id\":325},{\"id\":326},{\"id\":327},{\"id\":328},{\"id\":329},{\"id\":330},{\"id\":331},{\"id\":332},{\"id\":333},{\"id\":334},{\"id\":335},{\"id\":336},{\"id\":337},{\"id\":338},{\"id\":339},{\"id\":340},{\"id\":341},{\"id\":342},{\"id\":343},{\"id\":344},{\"id\":345},{\"id\":346},{\"id\":347},{\"id\":348},{\"id\":349},{\"id\":350},{\"id\":351},{\"id\":352},{\"id\":353},{\"id\":354},{\"id\":355},{\"id\":356},{\"id\":357},{\"id\":358},{\"id\":359},{\"id\":360},{\"id\":361},{\"id\":362},{\"id\":363},{\"id\":364},{\"id\":365},{\"id\":366},{\"id\":367},{\"id\":368},{\"id\":369},{\"id\":370},{\"id\":371},{\"id\":372},{\"id\":373},{\"id\":374},{\"id\":375},{\"id\":376},{\"id\":377},{\"id\":378},{\"id\":379},{\"id\":380},{\"id\":381},{\"id\":382},{\"id\":383},{\"id\":384},{\"id\":385},{\"id\":386},{\"id\":387},{\"id\":388},{\"id\":389},{\"id\":390},{\"id\":391},{\"id\":392},{\"id\":393},{\"id\":394},{\"id\":395},{\"id\":396},{\"id\":397},{\"id\":398},{\"id\":399},{\"id\":400},{\"id\":401},{\"id\":402},{\"id\":403},{\"id\":404},{\"id\":405},{\"id\":406},{\"id\":407},{\"id\":408},{\"id\":409},{\"id\":410},{\"id\":411},{\"id\":412},{\"id\":413},{\"id\":414},{\"id\":415},{\"id\":416},{\"id\":417},{\"id\":418},{\"id\":419},{\"id\":420},{\"id\":421},{\"id\":422},{\"id\":423},{\"id\":424},{\"id\":425},{\"id\":426},{\"id\":427},{\"id\":428},{\"id\":429},{\"id\":430},{\"id\":431},{\"id\":432},{\"id\":433},{\"id\":434},{\"id\":435},{\"id\":436},{\"id\":437},{\"id\":438},{\"id\":439},{\"id\":440},{\"id\":441},{\"id\":442},{\"id\":443},{\"id\":444},{\"id\":445},{\"id\":446},{\"id\":447},{\"id\":448},{\"id\":449},{\"id\":450},{\"id\":451},{\"id\":452},{\"id\":453},{\"id\":454},{\"id\":455},{\"id\":456},{\"id\":457},{\"id\":458},{\"id\":459},{\"id\":460},{\"id\":461},{\"id\":462},{\"id\":463},{\"id\":464},{\"id\":465},{\"id\":466},{\"id\":467},{\"id\":468},{\"id\":469},{\"id\":470},{\"id\":471},{\"id\":472},{\"id\":473},{\"id\":474},{\"id\":475},{\"id\":476},{\"id\":477},{\"id\":478},{\"id\":479},{\"id\":480},{\"id\":481},{\"id\":482},{\"id\":483},{\"id\":484},{\"id\":485},{\"id\":486},{\"id\":487},{\"id\":488},{\"id\":489},{\"id\":490},{\"id\":491},{\"id\":492},{\"id\":493},{\"id\":494},{\"id\":495},{\"id\":496},{\"id\":497},{\"id\":498},{\"id\":499},{\"id\":500},{\"id\":501},{\"id\":502},{\"id\":503},{\"id\":504},{\"id\":505},{\"id\":506},{\"id\":507},{\"id\":508},{\"id\":509},{\"id\":510},{\"id\":511},{\"id\":512},{\"id\":513},{\"id\":514},{\"id\":515},{\"id\":516},{\"id\":517},{\"id\":518},{\"id\":519},{\"id\":520},{\"id\":521},{\"id\":522},{\"id\":523},{\"id\":524},{\"id\":525},{\"id\":526},{\"id\":527},{\"id\":528},{\"id\":529},{\"id\":530},{\"id\":531},{\"id\":532},{\"id\":533},{\"id\":534},{\"id\":535},{\"id\":536},{\"id\":537},{\"id\":538},{\"id\":539},{\"id\":540},{\"id\":541},{\"id\":542},{\"id\":543},{\"id\":544},{\"id\":545},{\"id\":546},{\"id\":547},{\"id\":548},{\"id\":549},{\"id\":550},{\"id\":551},{\"id\":552},{\"id\":553},{\"id\":554},{\"id\":555},{\"id\":556},{\"id\":557},{\"id\":558},{\"id\":559},{\"id\":560},{\"id\":561},{\"id\":562},{\"id\":563},{\"id\":564},{\"id\":565},{\"id\":566},{\"id\":567},{\"id\":568},{\"id\":569},{\"id\":570},{\"id\":571},{\"id\":572},{\"id\":573},{\"id\":574},{\"id\":575},{\"id\":576},{\"id\":577},{\"id\":578},{\"id\":579},{\"id\":580},{\"id\":581},{\"id\":582},{\"id\":583},{\"id\":584},{\"id\":585},{\"id\":586},{\"id\":587},{\"id\":588},{\"id\":589},{\"id\":590},{\"id\":591},{\"id\":592},{\"id\":593},{\"id\":594},{\"id\":595},{\"id\":596},{\"id\":597},{\"id\":598},{\"id\":599},{\"id\":600},{\"id\":601},{\"id\":602},{\"id\":603},{\"id\":604},{\"id\":605},{\"id\":606},{\"id\":607},{\"id\":608},{\"id\":609},{\"id\":610},{\"id\":611},{\"id\":612},{\"id\":613},{\"id\":614},{\"id\":615},{\"id\":616},{\"id\":617},{\"id\":618},{\"id\":619},{\"id\":620},{\"id\":621},{\"id\":622},{\"id\":623},{\"id\":624},{\"id\":625},{\"id\":626},{\"id\":627},{\"id\":628},{\"id\":629},{\"id\":630},{\"id\":631},{\"id\":632},{\"id\":633},{\"id\":634},{\"id\":635},{\"id\":636},{\"id\":637},{\"id\":638},{\"id\":639},{\"id\":640},{\"id\":641},{\"id\":642},{\"id\":643},{\"id\":644},{\"id\":645},{\"id\":646},{\"id\":647},{\"id\":648},{\"id\":649},{\"id\":650},{\"id\":651},{\"id\":652},{\"id\":653},{\"id\":654},{\"id\":655},{\"id\":656},{\"id\":657},{\"id\":658},{\"id\":659},{\"id\":660},{\"id\":661},{\"id\":662},{\"id\":663},{\"id\":664},{\"id\":665},{\"id\":666},{\"id\":667},{\"id\":668},{\"id\":669},{\"id\":670},{\"id\":671},{\"id\":672},{\"id\":673},{\"id\":674},{\"id\":675},{\"id\":676},{\"id\":677},{\"id\":678},{\"id\":679},{\"id\":680},{\"id\":681},{\"id\":682},{\"id\":683},{\"id\":684},{\"id\":685},{\"id\":686},{\"id\":687},{\"id\":688},{\"id\":689},{\"id\":690},{\"id\":691},{\"id\":692},{\"id\":693},{\"id\":694},{\"id\":695},{\"id\":696},{\"id\":697},{\"id\":698},{\"id\":699},{\"id\":700},{\"id\":701},{\"id\":702},{\"id\":703},{\"id\":704},{\"id\":705},{\"id\":706},{\"id\":707},{\"id\":708},{\"id\":709},{\"id\":710},{\"id\":711},{\"id\":712},{\"id\":713},{\"id\":714},{\"id\":715},{\"id\":716},{\"id\":717},{\"id\":718},{\"id\":719},{\"id\":720},{\"id\":721},{\"id\":722},{\"id\":723},{\"id\":724},{\"id\":725},{\"id\":726},{\"id\":727},{\"id\":728},{\"id\":729},{\"id\":730},{\"id\":731},{\"id\":732},{\"id\":733},{\"id\":734},{\"id\":735},{\"id\":736},{\"id\":737},{\"id\":738},{\"id\":739},{\"id\":740},{\"id\":741},{\"id\":742},{\"id\":743},{\"id\":744},{\"id\":745},{\"id\":746},{\"id\":747},{\"id\":748},{\"id\":749},{\"id\":750},{\"id\":751},{\"id\":752},{\"id\":753},{\"id\":754},{\"id\":755},{\"id\":756},{\"id\":757},{\"id\":758},{\"id\":759},{\"id\":760},{\"id\":761},{\"id\":762},{\"id\":763},{\"id\":764},{\"id\":765},{\"id\":766},{\"id\":767},{\"id\":768},{\"id\":769},{\"id\":770},{\"id\":771},{\"id\":772},{\"id\":773},{\"id\":774},{\"id\":775},{\"id\":776},{\"id\":777},{\"id\":778},{\"id\":779},{\"id\":780},{\"id\":781},{\"id\":782},{\"id\":783},{\"id\":784},{\"id\":785},{\"id\":786},{\"id\":787},{\"id\":788},{\"id\":789},{\"id\":790},{\"id\":791},{\"id\":792},{\"id\":793},{\"id\":794},{\"id\":795},{\"id\":796},{\"id\":797},{\"id\":798},{\"id\":799},{\"id\":800},{\"id\":801},{\"id\":802},{\"id\":803},{\"id\":804},{\"id\":805},{\"id\":806},{\"id\":807},{\"id\":808},{\"id\":809},{\"id\":810},{\"id\":811},{\"id\":812},{\"id\":813},{\"id\":814},{\"id\":815},{\"id\":816},{\"id\":817},{\"id\":818},{\"id\":819},{\"id\":820},{\"id\":821},{\"id\":822},{\"id\":823},{\"id\":824},{\"id\":825},{\"id\":826},{\"id\":827},{\"id\":828},{\"id\":829},{\"id\":830},{\"id\":831},{\"id\":832},{\"id\":833},{\"id\":834},{\"id\":835},{\"id\":836},{\"id\":837},{\"id\":838},{\"id\":839},{\"id\":840},{\"id\":841},{\"id\":842},{\"id\":843},{\"id\":844},{\"id\":845},{\"id\":846},{\"id\":847},{\"id\":848},{\"id\":849},{\"id\":850},{\"id\":851},{\"id\":852},{\"id\":853},{\"id\":854},{\"id\":855},{\"id\":856},{\"id\":857},{\"id\":858},{\"id\":859},{\"id\":860},{\"id\":861},{\"id\":862},{\"id\":863},{\"id\":864},{\"id\":865},{\"id\":866},{\"id\":867},{\"id\":868},{\"id\":869},{\"id\":870},{\"id\":871},{\"id\":872},{\"id\":873},{\"id\":874},{\"id\":875},{\"id\":876},{\"id\":877},{\"id\":878},{\"id\":879},{\"id\":880},{\"id\":881},{\"id\":882},{\"id\":883},{\"id\":884},{\"id\":885},{\"id\":886},{\"id\":887},{\"id\":888},{\"id\":889},{\"id\":890},{\"id\":891},{\"id\":892},{\"id\":893},{\"id\":894},{\"id\":895},{\"id\":896},{\"id\":897},{\"id\":898},{\"id\":899},{\"id\":900},{\"id\":901},{\"id\":902},{\"id\":903},{\"id\":904},{\"id\":905},{\"id\":906},{\"id\":907},{\"id\":908},{\"id\":909},{\"id\":910},{\"id\":911},{\"id\":912},{\"id\":913},{\"id\":914},{\"id\":915},{\"id\":916},{\"id\":917},{\"id\":918},{\"id\":919},{\"id\":920},{\"id\":921},{\"id\":922},{\"id\":923},{\"id\":924},{\"id\":925},{\"id\":926},{\"id\":927},{\"id\":928},{\"id\":929},{\"id\":930},{\"id\":931},{\"id\":932},{\"id\":933},{\"id\":934},{\"id\":935},{\"id\":936},{\"id\":937},{\"id\":938},{\"id\":939},{\"id\":940},{\"id\":941},{\"id\":942},{\"id\":943},{\"id\":944},{\"id\":945},{\"id\":946},{\"id\":947},{\"id\":948},{\"id\":949},{\"id\":950},{\"id\":951},{\"id\":952},{\"id\":953},{\"id\":954},{\"id\":955},{\"id\":956},{\"id\":957},{\"id\":958},{\"id\":959},{\"id\":960},{\"id\":961},{\"id\":962},{\"id\":963},{\"id\":964},{\"id\":965},{\"id\":966},{\"id\":967},{\"id\":968},{\"id\":969},{\"id\":970},{\"id\":971},{\"id\":972},{\"id\":973},{\"id\":974},{\"id\":975},{\"id\":976},{\"id\":977},{\"id\":978},{\"id\":979},{\"id\":980},{\"id\":981},{\"id\":982},{\"id\":983},{\"id\":984},{\"id\":985},{\"id\":986},{\"id\":987},{\"id\":988},{\"id\":989},{\"id\":990},{\"id\":991},{\"id\":992},{\"id\":993},{\"id\":994},{\"id\":995},{\"id\":996},{\"id\":997},{\"id\":998},{\"id\":999},{\"id\":1000},{\"id\":1001},{\"id\":1002},{\"id\":1003},{\"id\":1004},{\"id\":1005},{\"id\":1006},{\"id\":1007},{\"id\":1008},{\"id\":1009},{\"id\":1010},{\"id\":1011},{\"id\":1012},{\"id\":1013},{\"id\":1014},{\"id\":1015},{\"id\":1016},{\"id\":1017},{\"id\":1018},{\"id\":1019},{\"id\":1020},{\"id\":1021},{\"id\":1022},{\"id\":1023},{\"id\":1024},{\"id\":1025},{\"id\":1026},{\"id\":1027},{\"id\":1028},{\"id\":1029},{\"id\":1030},{\"id\":1031},{\"id\":1032},{\"id\":1033},{\"id\":1034},{\"id\":1035},{\"id\":1036},{\"id\":1037},{\"id\":1038},{\"id\":1039},{\"id\":1040},{\"id\":1041},{\"id\":1042},{\"id\":1043},{\"id\":1044},{\"id\":1045},{\"id\":1046},{\"id\":1047},{\"id\":1048},{\"id\":1049},{\"id\":1050},{\"id\":1051},{\"id\":1052},{\"id\":1053},{\"id\":1054},{\"id\":1055},{\"id\":1056},{\"id\":1057},{\"id\":1058},{\"id\":1059},{\"id\":1060},{\"id\":1061},{\"id\":1062},{\"id\":1063},{\"id\":1064},{\"id\":1065},{\"id\":1066},{\"id\":1067},{\"id\":1068},{\"id\":1069},{\"id\":1070},{\"id\":1071},{\"id\":1072},{\"id\":1073},{\"id\":1074},{\"id\":1075},{\"id\":1076},{\"id\":1077},{\"id\":1078},{\"id\":1079},{\"id\":1080},{\"id\":1081},{\"id\":1082},{\"id\":1083},{\"id\":1084},{\"id\":1085},{\"id\":1086},{\"id\":1087},{\"id\":1088},{\"id\":1089},{\"id\":1090},{\"id\":1091},{\"id\":1092},{\"id\":1093},{\"id\":1094},{\"id\":1095},{\"id\":1096},{\"id\":1097},{\"id\":1098},{\"id\":1099},{\"id\":1100},{\"id\":1101},{\"id\":1102},{\"id\":1103},{\"id\":1104},{\"id\":1105},{\"id\":1106},{\"id\":1107},{\"id\":1108},{\"id\":1109},{\"id\":1110},{\"id\":1111},{\"id\":1112},{\"id\":1113},{\"id\":1114},{\"id\":1115},{\"id\":1116},{\"id\":1117},{\"id\":1118},{\"id\":1119},{\"id\":1120},{\"id\":1121},{\"id\":1122},{\"id\":1123},{\"id\":1124},{\"id\":1125},{\"id\":1126},{\"id\":1127},{\"id\":1128},{\"id\":1129},{\"id\":1130},{\"id\":1131},{\"id\":1132},{\"id\":1133},{\"id\":1134},{\"id\":1135},{\"id\":1136},{\"id\":1137},{\"id\":1138},{\"id\":1139},{\"id\":1140},{\"id\":1141},{\"id\":1142},{\"id\":1143},{\"id\":1144},{\"id\":1145},{\"id\":1146},{\"id\":1147},{\"id\":1148},{\"id\":1149},{\"id\":1150},{\"id\":1151},{\"id\":1152},{\"id\":1153},{\"id\":1154},{\"id\":1155},{\"id\":1156},{\"id\":1157},{\"id\":1158},{\"id\":1159},{\"id\":1160},{\"id\":1161},{\"id\":1162},{\"id\":1163},{\"id\":1164},{\"id\":1165},{\"id\":1166},{\"id\":1167},{\"id\":1168},{\"id\":1169},{\"id\":1170},{\"id\":1171},{\"id\":1172},{\"id\":1173},{\"id\":1174},{\"id\":1175},{\"id\":1176},{\"id\":1177},{\"id\":1178},{\"id\":1179},{\"id\":1180},{\"id\":1181},{\"id\":1182},{\"id\":1183},{\"id\":1184},{\"id\":1185},{\"id\":1186},{\"id\":1187},{\"id\":1188},{\"id\":1189},{\"id\":1190},{\"id\":1191},{\"id\":1192},{\"id\":1193},{\"id\":1194},{\"id\":1195},{\"id\":1196},{\"id\":1197},{\"id\":1198},{\"id\":1199},{\"id\":1200},{\"id\":1201},{\"id\":1202},{\"id\":1203},{\"id\":1204},{\"id\":1205},{\"id\":1206},{\"id\":1207},{\"id\":1208},{\"id\":1209},{\"id\":1210},{\"id\":1211},{\"id\":1212},{\"id\":1213},{\"id\":1214},{\"id\":1215},{\"id\":1216},{\"id\":1217},{\"id\":1218},{\"id\":1219},{\"id\":1220},{\"id\":1221},{\"id\":1222},{\"id\":1223},{\"id\":1224},{\"id\":1225},{\"id\":1226},{\"id\":1227},{\"id\":1228},{\"id\":1229},{\"id\":1230},{\"id\":1231},{\"id\":1232},{\"id\":1233},{\"id\":1234},{\"id\":1235},{\"id\":1236},{\"id\":1237},{\"id\":1238},{\"id\":1239},{\"id\":1240},{\"id\":1241},{\"id\":1242},{\"id\":1243},{\"id\":1244},{\"id\":1245},{\"id\":1246},{\"id\":1247},{\"id\":1248},{\"id\":1249},{\"id\":1250},{\"id\":1251},{\"id\":1252},{\"id\":1253},{\"id\":1254},{\"id\":1255},{\"id\":1256},{\"id\":1257},{\"id\":1258},{\"id\":1259},{\"id\":1260},{\"id\":1261},{\"id\":1262},{\"id\":1263},{\"id\":1264},{\"id\":1265},{\"id\":1266},{\"id\":1267},{\"id\":1268},{\"id\":1269},{\"id\":1270},{\"id\":1271},{\"id\":1272},{\"id\":1273},{\"id\":1274},{\"id\":1275},{\"id\":1276},{\"id\":1277},{\"id\":1278},{\"id\":1279},{\"id\":1280},{\"id\":1281},{\"id\":1282},{\"id\":1283},{\"id\":1284},{\"id\":1285},{\"id\":1286},{\"id\":1287},{\"id\":1288},{\"id\":1289},{\"id\":1290},{\"id\":1291},{\"id\":1292},{\"id\":1293},{\"id\":1294},{\"id\":1295},{\"id\":1296},{\"id\":1297},{\"id\":1298},{\"id\":1299},{\"id\":1300},{\"id\":1301},{\"id\":1302},{\"id\":1303},{\"id\":1304},{\"id\":1305},{\"id\":1306},{\"id\":1307},{\"id\":1308},{\"id\":1309},{\"id\":1310},{\"id\":1311},{\"id\":1312},{\"id\":1313},{\"id\":1314},{\"id\":1315},{\"id\":1316},{\"id\":1317},{\"id\":1318},{\"id\":1319},{\"id\":1320},{\"id\":1321},{\"id\":1322},{\"id\":1323},{\"id\":1324},{\"id\":1325},{\"id\":1326},{\"id\":1327},{\"id\":1328},{\"id\":1329},{\"id\":1330},{\"id\":1331},{\"id\":1332},{\"id\":1333},{\"id\":1334},{\"id\":1335},{\"id\":1336},{\"id\":1337},{\"id\":1338},{\"id\":1339},{\"id\":1340},{\"id\":1341},{\"id\":1342},{\"id\":1343},{\"id\":1344},{\"id\":1345},{\"id\":1346},{\"id\":1347},{\"id\":1348},{\"id\":1349},{\"id\":1350},{\"id\":1351},{\"id\":1352},{\"id\":1353},{\"id\":1354},{\"id\":1355},{\"id\":1356},{\"id\":1357},{\"id\":1358},{\"id\":1359},{\"id\":1360},{\"id\":1361},{\"id\":1362},{\"id\":1363},{\"id\":1364},{\"id\":1365},{\"id\":1366},{\"id\":1367},{\"id\":1368},{\"id\":1369},{\"id\":1370},{\"id\":1371},{\"id\":1372},{\"id\":1373},{\"id\":1374},{\"id\":1375},{\"id\":1376},{\"id\":1377},{\"id\":1378},{\"id\":1379},{\"id\":1380},{\"id\":1381},{\"id\":1382},{\"id\":1383},{\"id\":1384},{\"id\":1385},{\"id\":1386},{\"id\":1387},{\"id\":1388},{\"id\":1389},{\"id\":1390},{\"id\":1391},{\"id\":1392},{\"id\":1393},{\"id\":1394},{\"id\":1395},{\"id\":1396},{\"id\":1397},{\"id\":1398},{\"id\":1399},{\"id\":1400},{\"id\":1401},{\"id\":1402},{\"id\":1403},{\"id\":1404},{\"id\":1405},{\"id\":1406},{\"id\":1407},{\"id\":1408},{\"id\":1409},{\"id\":1410},{\"id\":1411},{\"id\":1412},{\"id\":1413},{\"id\":1414},{\"id\":1415},{\"id\":1416},{\"id\":1417},{\"id\":1418},{\"id\":1419},{\"id\":1420},{\"id\":1421},{\"id\":1422},{\"id\":1423},{\"id\":1424},{\"id\":1425},{\"id\":1426},{\"id\":1427},{\"id\":1428},{\"id\":1429},{\"id\":1430},{\"id\":1431},{\"id\":1432},{\"id\":1433},{\"id\":1434},{\"id\":1435},{\"id\":1436},{\"id\":1437},{\"id\":1438},{\"id\":1439},{\"id\":1440},{\"id\":1441},{\"id\":1442},{\"id\":1443},{\"id\":1444},{\"id\":1445},{\"id\":1446},{\"id\":1447},{\"id\":1448},{\"id\":1449},{\"id\":1450},{\"id\":1451},{\"id\":1452},{\"id\":1453},{\"id\":1454},{\"id\":1455},{\"id\":1456},{\"id\":1457},{\"id\":1458},{\"id\":1459},{\"id\":1460},{\"id\":1461},{\"id\":1462},{\"id\":1463},{\"id\":1464},{\"id\":1465},{\"id\":1466},{\"id\":1467},{\"id\":1468},{\"id\":1469},{\"id\":1470},{\"id\":1471},{\"id\":1472},{\"id\":1473},{\"id\":1474},{\"id\":1475},{\"id\":1476},{\"id\":1477},{\"id\":1478},{\"id\":1479},{\"id\":1480},{\"id\":1481},{\"id\":1482},{\"id\":1483},{\"id\":1484},{\"id\":1485},{\"id\":1486},{\"id\":1487},{\"id\":1488},{\"id\":1489},{\"id\":1490},{\"id\":1491},{\"id\":1492},{\"id\":1493},{\"id\":1494},{\"id\":1495},{\"id\":1496},{\"id\":1497},{\"id\":1498},{\"id\":1499},{\"id\":1500},{\"id\":1501},{\"id\":1502},{\"id\":1503},{\"id\":1504},{\"id\":1505},{\"id\":1506},{\"id\":1507},{\"id\":1508},{\"id\":1509},{\"id\":1510},{\"id\":1511},{\"id\":1512},{\"id\":1513},{\"id\":1514},{\"id\":1515},{\"id\":1516},{\"id\":1517},{\"id\":1518},{\"id\":1519},{\"id\":1520},{\"id\":1521},{\"id\":1522},{\"id\":1523},{\"id\":1524},{\"id\":1525},{\"id\":1526},{\"id\":1527},{\"id\":1528},{\"id\":1529},{\"id\":1530},{\"id\":1531},{\"id\":1532},{\"id\":1533},{\"id\":1534},{\"id\":1535},{\"id\":1536},{\"id\":1537},{\"id\":1538},{\"id\":1539},{\"id\":1540},{\"id\":1541},{\"id\":1542},{\"id\":1543},{\"id\":1544},{\"id\":1545},{\"id\":1546},{\"id\":1547},{\"id\":1548},{\"id\":1549},{\"id\":1550},{\"id\":1551},{\"id\":1552},{\"id\":1553},{\"id\":1554},{\"id\":1555},{\"id\":1556},{\"id\":1557},{\"id\":1558},{\"id\":1559},{\"id\":1560},{\"id\":1561},{\"id\":1562},{\"id\":1563},{\"id\":1564},{\"id\":1565},{\"id\":1566},{\"id\":1567},{\"id\":1568},{\"id\":1569},{\"id\":1570},{\"id\":1571},{\"id\":1572},{\"id\":1573},{\"id\":1574},{\"id\":1575},{\"id\":1576},{\"id\":1577},{\"id\":1578},{\"id\":1579},{\"id\":1580},{\"id\":1581},{\"id\":1582},{\"id\":1583},{\"id\":1584},{\"id\":1585},{\"id\":1586},{\"id\":1587},{\"id\":1588},{\"id\":1589},{\"id\":1590},{\"id\":1591},{\"id\":1592},{\"id\":1593},{\"id\":1594},{\"id\":1595},{\"id\":1596},{\"id\":1597},{\"id\":1598},{\"id\":1599},{\"id\":1600},{\"id\":1601},{\"id\":1602},{\"id\":1603},{\"id\":1604},{\"id\":1605},{\"id\":1606},{\"id\":1607},{\"id\":1608},{\"id\":1609},{\"id\":1610},{\"id\":1611},{\"id\":1612},{\"id\":1613},{\"id\":1614},{\"id\":1615},{\"id\":1616},{\"id\":1617},{\"id\":1618},{\"id\":1619},{\"id\":1620},{\"id\":1621},{\"id\":1622},{\"id\":1623},{\"id\":1624},{\"id\":1625},{\"id\":1626},{\"id\":1627},{\"id\":1628},{\"id\":1629},{\"id\":1630},{\"id\":1631},{\"id\":1632},{\"id\":1633},{\"id\":1634},{\"id\":1635},{\"id\":1636},{\"id\":1637},{\"id\":1638},{\"id\":1639},{\"id\":1640},{\"id\":1641},{\"id\":1642},{\"id\":1643},{\"id\":1644},{\"id\":1645},{\"id\":1646},{\"id\":1647},{\"id\":1648},{\"id\":1649},{\"id\":1650},{\"id\":1651},{\"id\":1652},{\"id\":1653},{\"id\":1654},{\"id\":1655},{\"id\":1656},{\"id\":1657},{\"id\":1658},{\"id\":1659},{\"id\":1660},{\"id\":1661},{\"id\":1662},{\"id\":1663},{\"id\":1664},{\"id\":1665},{\"id\":1666},{\"id\":1667},{\"id\":1668},{\"id\":1669},{\"id\":1670},{\"id\":1671},{\"id\":1672},{\"id\":1673},{\"id\":1674},{\"id\":1675},{\"id\":1676},{\"id\":1677},{\"id\":1678},{\"id\":1679},{\"id\":1680},{\"id\":1681},{\"id\":1682},{\"id\":1683},{\"id\":1684},{\"id\":1685},{\"id\":1686},{\"id\":1687},{\"id\":1688},{\"id\":1689},{\"id\":1690},{\"id\":1691},{\"id\":1692},{\"id\":1693},{\"id\":1694},{\"id\":1695},{\"id\":1696},{\"id\":1697},{\"id\":1698},{\"id\":1699},{\"id\":1700},{\"id\":1701},{\"id\":1702},{\"id\":1703},{\"id\":1704},{\"id\":1705},{\"id\":1706},{\"id\":1707},{\"id\":1708},{\"id\":1709},{\"id\":1710},{\"id\":1711},{\"id\":1712},{\"id\":1713},{\"id\":1714},{\"id\":1715},{\"id\":1716},{\"id\":1717},{\"id\":1718},{\"id\":1719},{\"id\":1720},{\"id\":1721},{\"id\":1722},{\"id\":1723},{\"id\":1724},{\"id\":1725},{\"id\":1726},{\"id\":1727},{\"id\":1728},{\"id\":1729},{\"id\":1730},{\"id\":1731},{\"id\":1732},{\"id\":1733},{\"id\":1734},{\"id\":1735},{\"id\":1736},{\"id\":1737},{\"id\":1738},{\"id\":1739},{\"id\":1740},{\"id\":1741},{\"id\":1742},{\"id\":1743},{\"id\":1744},{\"id\":1745},{\"id\":1746},{\"id\":1747},{\"id\":1748},{\"id\":1749},{\"id\":1750},{\"id\":1751},{\"id\":1752},{\"id\":1753},{\"id\":1754},{\"id\":1755},{\"id\":1756},{\"id\":1757},{\"id\":1758},{\"id\":1759},{\"id\":1760},{\"id\":1761},{\"id\":1762},{\"id\":1763},{\"id\":1764},{\"id\":1765},{\"id\":1766},{\"id\":1767},{\"id\":1768},{\"id\":1769},{\"id\":1770},{\"id\":1771},{\"id\":1772},{\"id\":1773},{\"id\":1774},{\"id\":1775},{\"id\":1776},{\"id\":1777},{\"id\":1778},{\"id\":1779},{\"id\":1780},{\"id\":1781},{\"id\":1782},{\"id\":1783},{\"id\":1784},{\"id\":1785},{\"id\":1786},{\"id\":1787},{\"id\":1788},{\"id\":1789},{\"id\":1790},{\"id\":1791},{\"id\":1792},{\"id\":1793},{\"id\":1794},{\"id\":1795},{\"id\":1796},{\"id\":1797},{\"id\":1798},{\"id\":1799},{\"id\":1800},{\"id\":1801},{\"id\":1802},{\"id\":1803},{\"id\":1804},{\"id\":1805},{\"id\":1806},{\"id\":1807},{\"id\":1808},{\"id\":1809},{\"id\":1810},{\"id\":1811},{\"id\":1812},{\"id\":1813},{\"id\":1814},{\"id\":1815},{\"id\":1816},{\"id\":1817},{\"id\":1818},{\"id\":1819},{\"id\":1820},{\"id\":1821},{\"id\":1822},{\"id\":1823},{\"id\":1824},{\"id\":1825},{\"id\":1826},{\"id\":1827},{\"id\":1828},{\"id\":1829},{\"id\":1830},{\"id\":1831},{\"id\":1832},{\"id\":1833},{\"id\":1834},{\"id\":1835},{\"id\":1836},{\"id\":1837},{\"id\":1838},{\"id\":1839},{\"id\":1840},{\"id\":1841},{\"id\":1842},{\"id\":1843},{\"id\":1844},{\"id\":1845},{\"id\":1846},{\"id\":1847},{\"id\":1848},{\"id\":1849},{\"id\":1850},{\"id\":1851},{\"id\":1852},{\"id\":1853},{\"id\":1854},{\"id\":1855},{\"id\":1856},{\"id\":1857},{\"id\":1858},{\"id\":1859},{\"id\":1860},{\"id\":1861},{\"id\":1862},{\"id\":1863},{\"id\":1864},{\"id\":1865},{\"id\":1866},{\"id\":1867},{\"id\":1868},{\"id\":1869},{\"id\":1870},{\"id\":1871},{\"id\":1872},{\"id\":1873},{\"id\":1874},{\"id\":1875},{\"id\":1876},{\"id\":1877},{\"id\":1878},{\"id\":1879},{\"id\":1880},{\"id\":1881},{\"id\":1882},{\"id\":1883},{\"id\":1884},{\"id\":1885},{\"id\":1886},{\"id\":1887},{\"id\":1888},{\"id\":1889},{\"id\":1890},{\"id\":1891},{\"id\":1892},{\"id\":1893},{\"id\":1894},{\"id\":1895},{\"id\":1896},{\"id\":1897},{\"id\":1898},{\"id\":1899},{\"id\":1900},{\"id\":1901},{\"id\":1902},{\"id\":1903},{\"id\":1904},{\"id\":1905},{\"id\":1906},{\"id\":1907},{\"id\":1908},{\"id\":1909},{\"id\":1910},{\"id\":1911},{\"id\":1912},{\"id\":1913},{\"id\":1914},{\"id\":1915},{\"id\":1916},{\"id\":1917},{\"id\":1918},{\"id\":1919},{\"id\":1920},{\"id\":1921},{\"id\":1922},{\"id\":1923},{\"id\":1924},{\"id\":1925},{\"id\":1926},{\"id\":1927},{\"id\":1928},{\"id\":1929},{\"id\":1930},{\"id\":1931},{\"id\":1932},{\"id\":1933},{\"id\":1934},{\"id\":1935},{\"id\":1936},{\"id\":1937},{\"id\":1938},{\"id\":1939},{\"id\":1940},{\"id\":1941},{\"id\":1942},{\"id\":1943},{\"id\":1944},{\"id\":1945},{\"id\":1946},{\"id\":1947},{\"id\":1948},{\"id\":1949},{\"id\":1950},{\"id\":1951},{\"id\":1952},{\"id\":1953},{\"id\":1954},{\"id\":1955},{\"id\":1956},{\"id\":1957},{\"id\":1958},{\"id\":1959},{\"id\":1960},{\"id\":1961},{\"id\":1962},{\"id\":1963},{\"id\":1964},{\"id\":1965},{\"id\":1966},{\"id\":1967},{\"id\":1968},{\"id\":1969},{\"id\":1970},{\"id\":1971},{\"id\":1972},{\"id\":1973},{\"id\":1974},{\"id\":1975},{\"id\":1976},{\"id\":1977},{\"id\":1978},{\"id\":1979},{\"id\":1980},{\"id\":1981},{\"id\":1982},{\"id\":1983},{\"id\":1984},{\"id\":1985},{\"id\":1986},{\"id\":1987},{\"id\":1988},{\"id\":1989},{\"id\":1990},{\"id\":1991},{\"id\":1992},{\"id\":1993},{\"id\":1994},{\"id\":1995},{\"id\":1996},{\"id\":1997},{\"id\":1998},{\"id\":1999},{\"id\":2000},{\"id\":2001},{\"id\":2002},{\"id\":2003},{\"id\":2004},{\"id\":2005},{\"id\":2006},{\"id\":2007},{\"id\":2008},{\"id\":2009},{\"id\":2010},{\"id\":2011},{\"id\":2012},{\"id\":2013},{\"id\":2014},{\"id\":2015},{\"id\":2016},{\"id\":2017},{\"id\":2018},{\"id\":2019},{\"id\":2020},{\"id\":2021},{\"id\":2022},{\"id\":2023},{\"id\":2024},{\"id\":2025},{\"id\":2026},{\"id\":2027},{\"id\":2028},{\"id\":2029},{\"id\":2030},{\"id\":2031},{\"id\":2032},{\"id\":2033},{\"id\":2034},{\"id\":2035},{\"id\":2036},{\"id\":2037},{\"id\":2038},{\"id\":2039},{\"id\":2040},{\"id\":2041},{\"id\":2042},{\"id\":2043},{\"id\":2044},{\"id\":2045},{\"id\":2046},{\"id\":2047},{\"id\":2048},{\"id\":2049},{\"id\":2050},{\"id\":2051},{\"id\":2052},{\"id\":2053},{\"id\":2054},{\"id\":2055},{\"id\":2056},{\"id\":2057},{\"id\":2058},{\"id\":2059},{\"id\":2060},{\"id\":2061},{\"id\":2062},{\"id\":2063},{\"id\":2064},{\"id\":2065},{\"id\":2066},{\"id\":2067},{\"id\":2068},{\"id\":2069},{\"id\":2070},{\"id\":2071},{\"id\":2072},{\"id\":2073},{\"id\":2074},{\"id\":2075},{\"id\":2076},{\"id\":2077},{\"id\":2078},{\"id\":2079},{\"id\":2080},{\"id\":2081},{\"id\":2082},{\"id\":2083},{\"id\":2084},{\"id\":2085},{\"id\":2086},{\"id\":2087},{\"id\":2088},{\"id\":2089},{\"id\":2090},{\"id\":2091},{\"id\":2092},{\"id\":2093},{\"id\":2094},{\"id\":2095},{\"id\":2096},{\"id\":2097},{\"id\":2098},{\"id\":2099},{\"id\":2100},{\"id\":2101},{\"id\":2102},{\"id\":2103},{\"id\":2104},{\"id\":2105},{\"id\":2106},{\"id\":2107},{\"id\":2108},{\"id\":2109},{\"id\":2110},{\"id\":2111},{\"id\":2112},{\"id\":2113},{\"id\":2114},{\"id\":2115},{\"id\":2116},{\"id\":2117},{\"id\":2118},{\"id\":2119},{\"id\":2120},{\"id\":2121},{\"id\":2122},{\"id\":2123},{\"id\":2124},{\"id\":2125},{\"id\":2126},{\"id\":2127},{\"id\":2128},{\"id\":2129},{\"id\":2130},{\"id\":2131},{\"id\":2132},{\"id\":2133},{\"id\":2134},{\"id\":2135},{\"id\":2136},{\"id\":2137},{\"id\":2138},{\"id\":2139},{\"id\":2140},{\"id\":2141},{\"id\":2142},{\"id\":2143},{\"id\":2144},{\"id\":2145},{\"id\":2146},{\"id\":2147},{\"id\":2148},{\"id\":2149},{\"id\":2150},{\"id\":2151},{\"id\":2152},{\"id\":2153},{\"id\":2154},{\"id\":2155},{\"id\":2156},{\"id\":2157},{\"id\":2158},{\"id\":2159},{\"id\":2160},{\"id\":2161},{\"id\":2162},{\"id\":2163},{\"id\":2164},{\"id\":2165},{\"id\":2166},{\"id\":2167},{\"id\":2168},{\"id\":2169},{\"id\":2170},{\"id\":2171},{\"id\":2172},{\"id\":2173},{\"id\":2174},{\"id\":2175},{\"id\":2176},{\"id\":2177},{\"id\":2178},{\"id\":2179},{\"id\":2180},{\"id\":2181},{\"id\":2182},{\"id\":2183},{\"id\":2184},{\"id\":2185},{\"id\":2186},{\"id\":2187},{\"id\":2188},{\"id\":2189},{\"id\":2190},{\"id\":2191},{\"id\":2192},{\"id\":2193},{\"id\":2194},{\"id\":2195},{\"id\":2196},{\"id\":2197},{\"id\":2198},{\"id\":2199},{\"id\":2200},{\"id\":2201},{\"id\":2202},{\"id\":2203},{\"id\":2204},{\"id\":2205},{\"id\":2206},{\"id\":2207},{\"id\":2208},{\"id\":2209},{\"id\":2210},{\"id\":2211},{\"id\":2212},{\"id\":2213},{\"id\":2214},{\"id\":2215},{\"id\":2216},{\"id\":2217},{\"id\":2218},{\"id\":2219},{\"id\":2220},{\"id\":2221},{\"id\":2222},{\"id\":2223},{\"id\":2224},{\"id\":2225},{\"id\":2226},{\"id\":2227},{\"id\":2228},{\"id\":2229},{\"id\":2230},{\"id\":2231},{\"id\":2232},{\"id\":2233},{\"id\":2234},{\"id\":2235},{\"id\":2236},{\"id\":2237},{\"id\":2238},{\"id\":2239},{\"id\":2240},{\"id\":2241},{\"id\":2242},{\"id\":2243},{\"id\":2244},{\"id\":2245},{\"id\":2246},{\"id\":2247},{\"id\":2248},{\"id\":2249},{\"id\":2250},{\"id\":2251},{\"id\":2252},{\"id\":2253},{\"id\":2254},{\"id\":2255},{\"id\":2256},{\"id\":2257},{\"id\":2258},{\"id\":2259},{\"id\":2260},{\"id\":2261},{\"id\":2262},{\"id\":2263},{\"id\":2264},{\"id\":2265},{\"id\":2266},{\"id\":2267},{\"id\":2268},{\"id\":2269},{\"id\":2270},{\"id\":2271},{\"id\":2272},{\"id\":2273},{\"id\":2274},{\"id\":2275},{\"id\":2276},{\"id\":2277},{\"id\":2278},{\"id\":2279},{\"id\":2280},{\"id\":2281},{\"id\":2282},{\"id\":2283},{\"id\":2284},{\"id\":2285},{\"id\":2286},{\"id\":2287},{\"id\":2288},{\"id\":2289},{\"id\":2290},{\"id\":2291},{\"id\":2292},{\"id\":2293},{\"id\":2294},{\"id\":2295},{\"id\":2296},{\"id\":2297},{\"id\":2298},{\"id\":2299},{\"id\":2300},{\"id\":2301},{\"id\":2302},{\"id\":2303},{\"id\":2304},{\"id\":2305},{\"id\":2306},{\"id\":2307},{\"id\":2308},{\"id\":2309},{\"id\":2310},{\"id\":2311},{\"id\":2312},{\"id\":2313},{\"id\":2314},{\"id\":2315},{\"id\":2316},{\"id\":2317},{\"id\":2318},{\"id\":2319},{\"id\":2320},{\"id\":2321},{\"id\":2322},{\"id\":2323},{\"id\":2324},{\"id\":2325},{\"id\":2326},{\"id\":2327},{\"id\":2328},{\"id\":2329},{\"id\":2330},{\"id\":2331},{\"id\":2332},{\"id\":2333},{\"id\":2334},{\"id\":2335},{\"id\":2336},{\"id\":2337},{\"id\":2338},{\"id\":2339},{\"id\":2340},{\"id\":2341},{\"id\":2342},{\"id\":2343},{\"id\":2344},{\"id\":2345},{\"id\":2346},{\"id\":2347},{\"id\":2348},{\"id\":2349},{\"id\":2350},{\"id\":2351},{\"id\":2352},{\"id\":2353},{\"id\":2354},{\"id\":2355},{\"id\":2356},{\"id\":2357},{\"id\":2358},{\"id\":2359},{\"id\":2360},{\"id\":2361},{\"id\":2362},{\"id\":2363},{\"id\":2364},{\"id\":2365},{\"id\":2366},{\"id\":2367},{\"id\":2368},{\"id\":2369},{\"id\":2370},{\"id\":2371},{\"id\":2372},{\"id\":2373},{\"id\":2374},{\"id\":2375},{\"id\":2376},{\"id\":2377},{\"id\":2378},{\"id\":2379},{\"id\":2380},{\"id\":2381},{\"id\":2382},{\"id\":2383},{\"id\":2384},{\"id\":2385},{\"id\":2386},{\"id\":2387},{\"id\":2388},{\"id\":2389},{\"id\":2390},{\"id\":2391},{\"id\":2392},{\"id\":2393},{\"id\":2394},{\"id\":2395},{\"id\":2396},{\"id\":2397},{\"id\":2398},{\"id\":2399},{\"id\":2400},{\"id\":2401},{\"id\":2402},{\"id\":2403},{\"id\":2404},{\"id\":2405},{\"id\":2406},{\"id\":2407},{\"id\":2408},{\"id\":2409},{\"id\":2410},{\"id\":2411},{\"id\":2412},{\"id\":2413},{\"id\":2414},{\"id\":2415},{\"id\":2416},{\"id\":2417},{\"id\":2418},{\"id\":2419},{\"id\":2420},{\"id\":2421},{\"id\":2422},{\"id\":2423},{\"id\":2424},{\"id\":2425},{\"id\":2426},{\"id\":2427},{\"id\":2428},{\"id\":2429},{\"id\":2430},{\"id\":2431},{\"id\":2432},{\"id\":2433},{\"id\":2434},{\"id\":2435},{\"id\":2436},{\"id\":2437},{\"id\":2438},{\"id\":2439},{\"id\":2440},{\"id\":2441},{\"id\":2442},{\"id\":2443},{\"id\":2444},{\"id\":2445},{\"id\":2446},{\"id\":2447},{\"id\":2448},{\"id\":2449},{\"id\":2450},{\"id\":2451},{\"id\":2452},{\"id\":2453},{\"id\":2454},{\"id\":2455},{\"id\":2456},{\"id\":2457},{\"id\":2458},{\"id\":2459},{\"id\":2460},{\"id\":2461},{\"id\":2462},{\"id\":2463},{\"id\":2464},{\"id\":2465},{\"id\":2466},{\"id\":2467},{\"id\":2468},{\"id\":2469},{\"id\":2470},{\"id\":2471},{\"id\":2472},{\"id\":2473},{\"id\":2474},{\"id\":2475},{\"id\":2476},{\"id\":2477},{\"id\":2478},{\"id\":2479},{\"id\":2480},{\"id\":2481},{\"id\":2482},{\"id\":2483},{\"id\":2484},{\"id\":2485},{\"id\":2486},{\"id\":2487},{\"id\":2488},{\"id\":2489},{\"id\":2490},{\"id\":2491},{\"id\":2492},{\"id\":2493},{\"id\":2494},{\"id\":2495},{\"id\":2496},{\"id\":2497},{\"id\":2498},{\"id\":2499},{\"id\":2500},{\"id\":2501},{\"id\":2502},{\"id\":2503},{\"id\":2504},{\"id\":2505},{\"id\":2506},{\"id\":2507},{\"id\":2508},{\"id\":2509},{\"id\":2510},{\"id\":2511},{\"id\":2512},{\"id\":2513},{\"id\":2514},{\"id\":2515},{\"id\":2516},{\"id\":2517},{\"id\":2518},{\"id\":2519},{\"id\":2520},{\"id\":2521},{\"id\":2522},{\"id\":2523},{\"id\":2524},{\"id\":2525},{\"id\":2526},{\"id\":2527},{\"id\":2528},{\"id\":2529},{\"id\":2530},{\"id\":2531},{\"id\":2532},{\"id\":2533},{\"id\":2534},{\"id\":2535},{\"id\":2536},{\"id\":2537},{\"id\":2538},{\"id\":2539},{\"id\":2540},{\"id\":2541},{\"id\":2542},{\"id\":2543},{\"id\":2544},{\"id\":2545},{\"id\":2546},{\"id\":2547},{\"id\":2548},{\"id\":2549},{\"id\":2550},{\"id\":2551},{\"id\":2552},{\"id\":2553},{\"id\":2554},{\"id\":2555},{\"id\":2556},{\"id\":2557},{\"id\":2558},{\"id\":2559},{\"id\":2560},{\"id\":2561},{\"id\":2562},{\"id\":2563},{\"id\":2564},{\"id\":2565},{\"id\":2566},{\"id\":2567},{\"id\":2568},{\"id\":2569},{\"id\":2570},{\"id\":2571},{\"id\":2572},{\"id\":2573},{\"id\":2574},{\"id\":2575},{\"id\":2576},{\"id\":2577},{\"id\":2578},{\"id\":2579},{\"id\":2580},{\"id\":2581},{\"id\":2582},{\"id\":2583},{\"id\":2584},{\"id\":2585},{\"id\":2586},{\"id\":2587},{\"id\":2588},{\"id\":2589},{\"id\":2590},{\"id\":2591},{\"id\":2592},{\"nodeType\":3,\"id\":2596,\"textContent\":\" // Track clicks on page $(document).ready(function() { $(\\\".control\\\").click(function(e) { e.stopImmediatePropagation(); clicks = clicks + 1; console.log(clicks); }); }); $('.userid').html(sid); // console.log(\\\"start of clicked array: \\\"+clicked); // console.log(\\\"start of hovered string: \\\"+hovered); //set correct answers for each question var triangular_answers = { \\\"acme.starttime.1\\\" : [\\\"F\\\"], \\\"acme.starts.1\\\" : [\\\"K\\\"], \\\"acme.meets.1\\\" : [\\\"F\\\"], \\\"acme.endtime.1\\\" : [\\\"H\\\"], \\\"acme.midpoint.1\\\" : [\\\"O\\\"], \\\"acme.starttime.2\\\" : [\\\"F\\\"], \\\"acme.starts.2\\\" : [\\\"K\\\"], \\\"acme.meets.2\\\" : [\\\"F\\\"], \\\"acme.endtime.2\\\" : [\\\"H\\\"], \\\"acme.midpoint.2\\\" : [\\\"A\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"E\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"X\\\",\\\"O\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"G\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"E\\\"], \\\"bigset.starttime.1\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.1\\\" : [\\\"G\\\"], \\\"bigset.meets.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.1\\\" : [\\\"X\\\"], \\\"bigset.midpoint.1\\\" : [\\\"K\\\",\\\"X\\\"], \\\"bigset.starttime.2\\\" : [\\\"M\\\",\\\"L\\\"], \\\"bigset.starts.2\\\" : [\\\"G\\\"], \\\"bigset.meets.2\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.endtime.2\\\" : [\\\"X\\\"], \\\"bigset.midpoint.2\\\" : [\\\"K\\\",\\\"X\\\"] } var orthogonal_answers = { \\\"acme.starttime.1\\\" : [\\\"A\\\"], \\\"acme.starts.1\\\" : [\\\"E\\\"], \\\"acme.meets.1\\\" : [\\\"Z\\\"], \\\"acme.endtime.1\\\" : [\\\"U\\\"], \\\"acme.midpoint.1\\\" : [\\\"U\\\"], \\\"acme.starttime.2\\\" : [\\\"0\\\"], \\\"acme.starts.2\\\" : [\\\"0\\\"], \\\"acme.meets.2\\\" : [\\\"0\\\"], \\\"acme.endtime.2\\\" : [\\\"0\\\"], \\\"acme.midpoint.2\\\" : [\\\"0\\\"], \\\"bigset.duration.1\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.1\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.1\\\": [\\\"I\\\"], \\\"bigset.ends.1\\\" : [\\\"X\\\"], \\\"bigset.duration.2\\\" : [\\\"E\\\",\\\"G\\\"], \\\"bigset.duration+starts.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.duration+contained.2\\\" : [\\\"E\\\"], \\\"bigset.starttime+before+endtime+during.2\\\":[\\\"I\\\"], \\\"bigset.ends.2\\\" : [\\\"X\\\"], \\\"bigset.starttime.1\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.1\\\" : [\\\"B\\\"], \\\"bigset.meets.1\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.1\\\" : [\\\"B\\\"], \\\"bigset.midpoint.1\\\" : [\\\"E\\\",\\\"F\\\"], \\\"bigset.starttime.2\\\" : [\\\"F\\\",\\\"B\\\"], \\\"bigset.starts.2\\\" : [\\\"B\\\"], \\\"bigset.meets.2\\\" : [\\\"F\\\",\\\"X\\\"], \\\"bigset.endtime.2\\\" : [\\\"B\\\"], \\\"bigset.midpoint.2\\\" : [\\\"E\\\",\\\"F\\\"] } //display the question and answer buttons based on input values from jsPsych document.getElementById(scenario+\\\".\\\"+question).style.display = \\\"block\\\"; if (question == \\\"strategy\\\") {document.getElementById(\\\"strategyButton\\\").style.display = \\\"block\\\";} else {document.getElementById(\\\"testingButton\\\").style.display = \\\"block\\\";} //---------SET PROPERTIES OF THE GRAPH -------------// // set the dimensions and margins of the graph var margin = {top: 25, right: 30, bottom: 90, left: 100}, width = 800, height = 800; var intersects = false; //default value for intersects scaffold var xAxisTitle, yAxisTitle; var datafile =\\\"\\\"; // SET AXIS VALUES if (axis == 1){ axis = \\\"Orthogonal-XInside-YFull\\\"; } else if (axis == 2){ axis = \\\"Orthogonal-XInside-YPartial\\\"; } else if (axis ==3){ axis = \\\"Triangular-XInside-YInside\\\"; } else if (axis ==4){ axis = \\\"Orthogonal-XInside-YInside\\\"; } else if (axis ==5){ axis = \\\"Orthogonal-XFull-YFull\\\"; } // SET EXPLICIT SCAFFOLD FEATURES if (explicit ==2 && axis != \\\"diagonal\\\"){ scaffold = 2; intersects = false; } else if (explicit == 2 && axis == \\\"diagonal\\\"){ scaffold = 2; intersects = false; } //TODO: not sure if above two lines are still valid since leaders are now generated on the fly else if (explicit == 3){ $('#hint-interactive').css(\\\"display\\\",\\\"block\\\"); //display textimage scaffold intersects = true; } //SET DATA FILE FOR IMPLICIT SCAFFOLD if (impasse == 1){ datafile = \\\"../views/src/data/acme_nonimpasse.csv\\\"; } else if (impasse == 2){ datafile = \\\"../views/src/data/acme_impasse.csv\\\"; } //OVERRIDE DATA FILE FOR NON-SCAFFOLD QUESTIONS if (q > 5) { //override data file if q# is greater than 5 datafile = \\\"../views/src/data/bigset.csv\\\"; console.log(\\\"override data file\\\"); $('#orthogonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#diagonal-image').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold $('#hint-interactive').css(\\\"display\\\",\\\"none\\\"); //display textimage scaffold intersects = false; } // //---------CREATE THE SVG ------------------------// var svg = d3.select(\\\".d3container\\\").append(\\\"svg\\\") .attr(\\\"width\\\", width + margin.left + margin.right) .attr(\\\"height\\\", height + margin.top + margin.bottom) .append(\\\"g\\\") .attr(\\\"transform\\\", \\\"translate(\\\" + margin.left + \\\",\\\" + margin.top + \\\")\\\"); //---------DRAW THE GRAPH ------------------------// xAxisTitle = \\\"START & END TIME (time of day)\\\"; yAxisTitle = \\\"DURATION (in hours)\\\"; drawTriangleModel(datafile,intersects,axis,scaffold,q); \"},{\"id\":2593},{\"id\":2594},{\"nodeType\":3,\"id\":2597,\"textContent\":\" //MOUSE LOGGING SCRIPT var mouseLog = [] var xwidth = $(document).width(); var xheight = $(document).width(); mouseLog.push(\\\"{x:\\\"+xwidth+\\\",y:\\\"+xheight+\\\",t:\\\"+\\\"0};\\\") document.onmousemove = function(e){ var pageCoords = \\\"{x:\\\" + e.pageX + \\\",y:\\\"+ e.pageY +\\\",t:\\\"+ Date.now()+ \\\"};\\\" ; mouseLog.push(pageCoords); // console.log(pageCoords); }; \"},{\"id\":2595}],[],[],[]]}"
    },
    {
      "sequence": 2,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2598,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-preamble\",\"class\":\"jspsych-survey-text-preamble\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2599,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-0\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2598},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2600,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-text-1\",\"class\":\"jspsych-survey-text-question\"},\"previousSibling\":{\"id\":2599},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2601,\"tagName\":\"BUTTON\",\"attributes\":{\"id\":\"jspsych-survey-text-next\",\"class\":\"jspsych-btn jspsych-survey-text\"},\"previousSibling\":{\"id\":2600},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2602,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2599}},{\"nodeType\":1,\"id\":2603,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-0\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2602},\"parentNode\":{\"id\":2599}},{\"nodeType\":3,\"id\":2604,\"textContent\":\"What is your age?\",\"parentNode\":{\"id\":2602}},{\"nodeType\":1,\"id\":2605,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-text\"},\"parentNode\":{\"id\":2600}},{\"nodeType\":1,\"id\":2606,\"tagName\":\"TEXTAREA\",\"attributes\":{\"name\":\"#jspsych-survey-text-response-1\",\"cols\":\"40\",\"rows\":\"1\"},\"previousSibling\":{\"id\":2605},\"parentNode\":{\"id\":2600}},{\"nodeType\":3,\"id\":2607,\"textContent\":\"In what country were you born?\",\"parentNode\":{\"id\":2605}},{\"nodeType\":3,\"id\":2608,\"textContent\":\"Submit Answers\",\"parentNode\":{\"id\":2601}}],[],[]]}"
    },
    {
      "sequence": 3,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2598},{\"id\":2599},{\"id\":2602},{\"id\":2604},{\"id\":2603},{\"id\":2600},{\"id\":2605},{\"id\":2607},{\"id\":2606},{\"id\":2601},{\"id\":2608}],[],[],[]]}"
    },
    {
      "sequence": 4,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2609,\"tagName\":\"FORM\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-form\"},\"parentNode\":{\"id\":55}},{\"nodeType\":1,\"id\":2610,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-preamble\",\"class\":\"jspsych-survey-multi-choice-preamble\"},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2611,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-0\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2610},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2612,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-1\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2611},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2613,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-2\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2612},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2614,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-3\",\"class\":\"jspsych-survey-multi-choice-question jspsych-survey-multi-choice-horizontal\"},\"previousSibling\":{\"id\":2613},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2615,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"submit\",\"id\":\"jspsych-survey-multi-choice-next\",\"class\":\"jspsych-survey-multi-choice jspsych-btn\",\"value\":\"Submit Answers\"},\"previousSibling\":{\"id\":2614},\"parentNode\":{\"id\":2609}},{\"nodeType\":1,\"id\":2616,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2617,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2616},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2618,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2617},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2619,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2618},\"parentNode\":{\"id\":2611}},{\"nodeType\":1,\"id\":2620,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-0-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2619},\"parentNode\":{\"id\":2611}},{\"nodeType\":3,\"id\":2621,\"textContent\":\"What is your first language?\",\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2622,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2621},\"parentNode\":{\"id\":2616}},{\"nodeType\":1,\"id\":2623,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2617}},{\"nodeType\":1,\"id\":2624,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2623}},{\"nodeType\":3,\"id\":2625,\"textContent\":\"English\",\"previousSibling\":{\"id\":2624},\"parentNode\":{\"id\":2623}},{\"nodeType\":1,\"id\":2626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2618}},{\"nodeType\":1,\"id\":2627,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2626}},{\"nodeType\":3,\"id\":2628,\"textContent\":\"Spanish\",\"previousSibling\":{\"id\":2627},\"parentNode\":{\"id\":2626}},{\"nodeType\":1,\"id\":2629,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2619}},{\"nodeType\":1,\"id\":2630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2629}},{\"nodeType\":3,\"id\":2631,\"textContent\":\"Mandarin or Cantonese\",\"previousSibling\":{\"id\":2630},\"parentNode\":{\"id\":2629}},{\"nodeType\":1,\"id\":2632,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2620}},{\"nodeType\":1,\"id\":2633,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-0\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2634,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2633},\"parentNode\":{\"id\":2632}},{\"nodeType\":3,\"id\":2635,\"textContent\":\"*\",\"parentNode\":{\"id\":2622}},{\"nodeType\":1,\"id\":2636,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2637,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2636},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2638,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2637},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2639,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2638},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2640,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2639},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2641,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2640},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2642,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2641},\"parentNode\":{\"id\":2612}},{\"nodeType\":1,\"id\":2643,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-1-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2642},\"parentNode\":{\"id\":2612}},{\"nodeType\":3,\"id\":2644,\"textContent\":\"What is your year in school?\",\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2645,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2644},\"parentNode\":{\"id\":2636}},{\"nodeType\":1,\"id\":2646,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2637}},{\"nodeType\":1,\"id\":2647,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2646}},{\"nodeType\":3,\"id\":2648,\"textContent\":\"First\",\"previousSibling\":{\"id\":2647},\"parentNode\":{\"id\":2646}},{\"nodeType\":1,\"id\":2649,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2638}},{\"nodeType\":1,\"id\":2650,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2649}},{\"nodeType\":3,\"id\":2651,\"textContent\":\"Second\",\"previousSibling\":{\"id\":2650},\"parentNode\":{\"id\":2649}},{\"nodeType\":1,\"id\":2652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2639}},{\"nodeType\":1,\"id\":2653,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2652}},{\"nodeType\":3,\"id\":2654,\"textContent\":\"Third\",\"previousSibling\":{\"id\":2653},\"parentNode\":{\"id\":2652}},{\"nodeType\":1,\"id\":2655,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2640}},{\"nodeType\":1,\"id\":2656,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2655}},{\"nodeType\":3,\"id\":2657,\"textContent\":\"Fourth\",\"previousSibling\":{\"id\":2656},\"parentNode\":{\"id\":2655}},{\"nodeType\":1,\"id\":2658,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2641}},{\"nodeType\":1,\"id\":2659,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2658}},{\"nodeType\":3,\"id\":2660,\"textContent\":\"Fifth\",\"previousSibling\":{\"id\":2659},\"parentNode\":{\"id\":2658}},{\"nodeType\":1,\"id\":2661,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2642}},{\"nodeType\":1,\"id\":2662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2661}},{\"nodeType\":3,\"id\":2663,\"textContent\":\"Graduate\",\"previousSibling\":{\"id\":2662},\"parentNode\":{\"id\":2661}},{\"nodeType\":1,\"id\":2664,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2643}},{\"nodeType\":1,\"id\":2665,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-1\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2666,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2665},\"parentNode\":{\"id\":2664}},{\"nodeType\":3,\"id\":2667,\"textContent\":\"*\",\"parentNode\":{\"id\":2645}},{\"nodeType\":1,\"id\":2668,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2669,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2668},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2670,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2669},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2671,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2670},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2672,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-3\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2671},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2673,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-4\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2672},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2674,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-5\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2673},\"parentNode\":{\"id\":2613}},{\"nodeType\":1,\"id\":2675,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-2-6\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2674},\"parentNode\":{\"id\":2613}},{\"nodeType\":3,\"id\":2676,\"textContent\":\"What is your major area of study?\",\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2677,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2676},\"parentNode\":{\"id\":2668}},{\"nodeType\":1,\"id\":2678,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2669}},{\"nodeType\":1,\"id\":2679,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2678}},{\"nodeType\":3,\"id\":2680,\"textContent\":\"Math or Computer Sciences\",\"previousSibling\":{\"id\":2679},\"parentNode\":{\"id\":2678}},{\"nodeType\":1,\"id\":2681,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2670}},{\"nodeType\":1,\"id\":2682,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2681}},{\"nodeType\":3,\"id\":2683,\"textContent\":\"Social Sciences (incl. CogSci)\",\"previousSibling\":{\"id\":2682},\"parentNode\":{\"id\":2681}},{\"nodeType\":1,\"id\":2684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2671}},{\"nodeType\":1,\"id\":2685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2684}},{\"nodeType\":3,\"id\":2686,\"textContent\":\"Biomedical & Health Sciences\",\"previousSibling\":{\"id\":2685},\"parentNode\":{\"id\":2684}},{\"nodeType\":1,\"id\":2687,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2672}},{\"nodeType\":1,\"id\":2688,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2687}},{\"nodeType\":3,\"id\":2689,\"textContent\":\"Natural Sciences\",\"previousSibling\":{\"id\":2688},\"parentNode\":{\"id\":2687}},{\"nodeType\":1,\"id\":2690,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2673}},{\"nodeType\":1,\"id\":2691,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2690}},{\"nodeType\":3,\"id\":2692,\"textContent\":\"Engineering\",\"previousSibling\":{\"id\":2691},\"parentNode\":{\"id\":2690}},{\"nodeType\":1,\"id\":2693,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2674}},{\"nodeType\":1,\"id\":2694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2693}},{\"nodeType\":3,\"id\":2695,\"textContent\":\"Humanities\",\"previousSibling\":{\"id\":2694},\"parentNode\":{\"id\":2693}},{\"nodeType\":1,\"id\":2696,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2675}},{\"nodeType\":1,\"id\":2697,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-2\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2698,\"textContent\":\"Fine Arts\",\"previousSibling\":{\"id\":2697},\"parentNode\":{\"id\":2696}},{\"nodeType\":3,\"id\":2699,\"textContent\":\"*\",\"parentNode\":{\"id\":2677}},{\"nodeType\":1,\"id\":2700,\"tagName\":\"P\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text survey-multi-choice\"},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2701,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-0\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2700},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2702,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-1\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2701},\"parentNode\":{\"id\":2614}},{\"nodeType\":1,\"id\":2703,\"tagName\":\"DIV\",\"attributes\":{\"id\":\"jspsych-survey-multi-choice-option-3-2\",\"class\":\"jspsych-survey-multi-choice-option\"},\"previousSibling\":{\"id\":2702},\"parentNode\":{\"id\":2614}},{\"nodeType\":3,\"id\":2704,\"textContent\":\"What is your gender?\",\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2705,\"tagName\":\"SPAN\",\"attributes\":{\"class\":\"required\"},\"previousSibling\":{\"id\":2704},\"parentNode\":{\"id\":2700}},{\"nodeType\":1,\"id\":2706,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2701}},{\"nodeType\":1,\"id\":2707,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2706}},{\"nodeType\":3,\"id\":2708,\"textContent\":\"Male\",\"previousSibling\":{\"id\":2707},\"parentNode\":{\"id\":2706}},{\"nodeType\":1,\"id\":2709,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2702}},{\"nodeType\":1,\"id\":2710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2709}},{\"nodeType\":3,\"id\":2711,\"textContent\":\"Female\",\"previousSibling\":{\"id\":2710},\"parentNode\":{\"id\":2709}},{\"nodeType\":1,\"id\":2712,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"jspsych-survey-multi-choice-text\"},\"parentNode\":{\"id\":2703}},{\"nodeType\":1,\"id\":2713,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"radio\",\"name\":\"jspsych-survey-multi-choice-response-3\",\"value\":\"\",\"required\":\"\"},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2714,\"textContent\":\"Other\",\"previousSibling\":{\"id\":2713},\"parentNode\":{\"id\":2712}},{\"nodeType\":3,\"id\":2715,\"textContent\":\"*\",\"parentNode\":{\"id\":2705}}],[],[]]}"
    },
    {
      "sequence": 5,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2609},{\"id\":2610},{\"id\":2611},{\"id\":2616},{\"id\":2621},{\"id\":2622},{\"id\":2635},{\"id\":2617},{\"id\":2623},{\"id\":2624},{\"id\":2625},{\"id\":2618},{\"id\":2626},{\"id\":2627},{\"id\":2628},{\"id\":2619},{\"id\":2629},{\"id\":2630},{\"id\":2631},{\"id\":2620},{\"id\":2632},{\"id\":2633},{\"id\":2634},{\"id\":2612},{\"id\":2636},{\"id\":2644},{\"id\":2645},{\"id\":2667},{\"id\":2637},{\"id\":2646},{\"id\":2647},{\"id\":2648},{\"id\":2638},{\"id\":2649},{\"id\":2650},{\"id\":2651},{\"id\":2639},{\"id\":2652},{\"id\":2653},{\"id\":2654},{\"id\":2640},{\"id\":2655},{\"id\":2656},{\"id\":2657},{\"id\":2641},{\"id\":2658},{\"id\":2659},{\"id\":2660},{\"id\":2642},{\"id\":2661},{\"id\":2662},{\"id\":2663},{\"id\":2643},{\"id\":2664},{\"id\":2665},{\"id\":2666},{\"id\":2613},{\"id\":2668},{\"id\":2676},{\"id\":2677},{\"id\":2699},{\"id\":2669},{\"id\":2678},{\"id\":2679},{\"id\":2680},{\"id\":2670},{\"id\":2681},{\"id\":2682},{\"id\":2683},{\"id\":2671},{\"id\":2684},{\"id\":2685},{\"id\":2686},{\"id\":2672},{\"id\":2687},{\"id\":2688},{\"id\":2689},{\"id\":2673},{\"id\":2690},{\"id\":2691},{\"id\":2692},{\"id\":2674},{\"id\":2693},{\"id\":2694},{\"id\":2695},{\"id\":2675},{\"id\":2696},{\"id\":2697},{\"id\":2698},{\"id\":2614},{\"id\":2700},{\"id\":2704},{\"id\":2705},{\"id\":2715},{\"id\":2701},{\"id\":2706},{\"id\":2707},{\"id\":2708},{\"id\":2702},{\"id\":2709},{\"id\":2710},{\"id\":2711},{\"id\":2703},{\"id\":2712},{\"id\":2713},{\"id\":2714},{\"id\":2615}],[],[],[]]}"
    },
    {
      "sequence": 6,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2716,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"masterdiv\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2717,\"textContent\":\" \",\"previousSibling\":{\"id\":2716},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2718,\"textContent\":\" \",\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"top\"},\"previousSibling\":{\"id\":2718},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2720,\"textContent\":\" \",\"previousSibling\":{\"id\":2719},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2721,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"instructions\"},\"previousSibling\":{\"id\":2720},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2722,\"textContent\":\" \",\"previousSibling\":{\"id\":2721},\"parentNode\":{\"id\":2716}},{\"nodeType\":1,\"id\":2723,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bottom\"},\"previousSibling\":{\"id\":2722},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2724,\"textContent\":\" \",\"previousSibling\":{\"id\":2723},\"parentNode\":{\"id\":2716}},{\"nodeType\":3,\"id\":2725,\"textContent\":\" \",\"parentNode\":{\"id\":2719}},{\"nodeType\":1,\"id\":2726,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bcent\"},\"previousSibling\":{\"id\":2725},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2727,\"textContent\":\" \",\"previousSibling\":{\"id\":2726},\"parentNode\":{\"id\":2719}},{\"nodeType\":3,\"id\":2728,\"textContent\":\" \",\"parentNode\":{\"id\":2726}},{\"nodeType\":1,\"id\":2729,\"tagName\":\"H3\",\"attributes\":{},\"previousSibling\":{\"id\":2728},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2730,\"textContent\":\" \",\"previousSibling\":{\"id\":2729},\"parentNode\":{\"id\":2726}},{\"nodeType\":3,\"id\":2731,\"textContent\":\"DEBRIEFING\",\"parentNode\":{\"id\":2729}},{\"nodeType\":3,\"id\":2732,\"textContent\":\" \",\"parentNode\":{\"id\":2721}},{\"nodeType\":1,\"id\":2733,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"vcent\"},\"previousSibling\":{\"id\":2732},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2734,\"textContent\":\" \",\"previousSibling\":{\"id\":2733},\"parentNode\":{\"id\":2721}},{\"nodeType\":3,\"id\":2735,\"textContent\":\" \",\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2736,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic\"},\"previousSibling\":{\"id\":2735},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2737,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2736},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2738,\"textContent\":\" \",\"previousSibling\":{\"id\":2737},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2739,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2738},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2740,\"textContent\":\" \",\"previousSibling\":{\"id\":2739},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2741,\"tagName\":\"P\",\"attributes\":{},\"previousSibling\":{\"id\":2740},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2742,\"textContent\":\" \",\"previousSibling\":{\"id\":2741},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2743,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:bold;\"},\"previousSibling\":{\"id\":2742},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2744,\"textContent\":\" \",\"previousSibling\":{\"id\":2743},\"parentNode\":{\"id\":2733}},{\"nodeType\":1,\"id\":2745,\"tagName\":\"P\",\"attributes\":{\"style\":\"font-style:italic;\"},\"previousSibling\":{\"id\":2744},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2746,\"textContent\":\" \",\"previousSibling\":{\"id\":2745},\"parentNode\":{\"id\":2733}},{\"nodeType\":3,\"id\":2747,\"textContent\":\"Thank you very much for your participation! This debriefing will tell you more about the study, what you did, and why. \",\"parentNode\":{\"id\":2736}},{\"nodeType\":3,\"id\":2748,\"textContent\":\" \",\"parentNode\":{\"id\":2737}},{\"nodeType\":1,\"id\":2749,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2748},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2750,\"textContent\":\" You have just used a series of pictures (charts, graphs and diagrams) accompanied by different types of instructions to answer a series of problem solving questions. While you were using the pictures, we measured where you clicked, scrolled and pointed with the computer mouse. We also measured the accuracy of your responses and the time it took to complete each question.\",\"previousSibling\":{\"id\":2749},\"parentNode\":{\"id\":2737}},{\"nodeType\":3,\"id\":2751,\"textContent\":\"What did you just do?\",\"parentNode\":{\"id\":2749}},{\"nodeType\":3,\"id\":2752,\"textContent\":\" \",\"parentNode\":{\"id\":2739}},{\"nodeType\":1,\"id\":2753,\"tagName\":\"B\",\"attributes\":{},\"previousSibling\":{\"id\":2752},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2754,\"textContent\":\" Researchers of learning and cognition have long been interested in how graphic displays of information can be used to communicate, solve problems, and generate insights. As powerful as graphics may be in their communicative efficiency, they're not always immediately intuitive to understand. In short, we know a great deal more about learning with representations than we do about the learning of representations. In this project we are building upon previous research on reading and graph comprehension to explore how readers make sense of unfamiliar representations. The instructions you saw for each type of graph are known as “scaffolding techniques”, and we will compare your performance with the scaffolding techniques you saw with the performance of other participants to determine which types of instructions are most effective in helping humans to make sense of unfamiliar graphs. \",\"previousSibling\":{\"id\":2753},\"parentNode\":{\"id\":2739}},{\"nodeType\":3,\"id\":2755,\"textContent\":\"Why did we have you do it?\",\"parentNode\":{\"id\":2753}},{\"nodeType\":1,\"id\":2756,\"tagName\":\"B\",\"attributes\":{},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2757,\"textContent\":\" We expect that you will have found some of the graphics more difficult to use than others. We also expect that with the assistance of the instructions, after solving several problems you will learn to use the difficult graphics so that you can answer the questions even more quickly than without. If you would like to receive a copy of the results of the study, or have any further questions, please contact the researchers Primary Researcher: Amy Fox : a2fox@ucsd.edu Faculty Advisor : Dr. Jim Hollan : hollan@ucsd.edu \",\"previousSibling\":{\"id\":2756},\"parentNode\":{\"id\":2741}},{\"nodeType\":3,\"id\":2758,\"textContent\":\"What do we expect to find?\",\"parentNode\":{\"id\":2756}},{\"nodeType\":3,\"id\":2759,\"textContent\":\"It is important that you do not discuss this experiment with other students who might participate after you. They must participate in the same way as you did, without any knowledge of what the experiment entails, or the reasoning behind it.\",\"parentNode\":{\"id\":2743}},{\"nodeType\":3,\"id\":2760,\"textContent\":\"Thank you for your time! We hope you enjoyed participating in this study as much as we enjoyed designing it.\",\"parentNode\":{\"id\":2745}},{\"nodeType\":3,\"id\":2761,\"textContent\":\" \",\"parentNode\":{\"id\":2723}},{\"nodeType\":1,\"id\":2762,\"tagName\":\"BUTTON\",\"attributes\":{\"class\":\"btn\",\"type\":\"button\",\"id\":\"start\"},\"previousSibling\":{\"id\":2761},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2763,\"textContent\":\" \",\"previousSibling\":{\"id\":2762},\"parentNode\":{\"id\":2723}},{\"nodeType\":3,\"id\":2764,\"textContent\":\"FINISH\",\"parentNode\":{\"id\":2762}}],[],[]]}"
    },
    {
      "sequence": 7,
      "data": "{\"f\":\"applyChanged\",\"args\":[[{\"id\":2716},{\"id\":2718},{\"id\":2719},{\"id\":2725},{\"id\":2726},{\"id\":2728},{\"id\":2729},{\"id\":2731},{\"id\":2730},{\"id\":2727},{\"id\":2720},{\"id\":2721},{\"id\":2732},{\"id\":2733},{\"id\":2735},{\"id\":2736},{\"id\":2747},{\"id\":2737},{\"id\":2748},{\"id\":2749},{\"id\":2751},{\"id\":2750},{\"id\":2738},{\"id\":2739},{\"id\":2752},{\"id\":2753},{\"id\":2755},{\"id\":2754},{\"id\":2740},{\"id\":2741},{\"id\":2756},{\"id\":2758},{\"id\":2757},{\"id\":2742},{\"id\":2743},{\"id\":2759},{\"id\":2744},{\"id\":2745},{\"id\":2760},{\"id\":2746},{\"id\":2734},{\"id\":2722},{\"id\":2723},{\"id\":2761},{\"id\":2762},{\"id\":2764},{\"id\":2763},{\"id\":2724},{\"id\":2717}],[],[],[]]}"
    },
    {
      "sequence": 8,
      "data": "{\"f\":\"applyChanged\",\"args\":[[],[{\"nodeType\":1,\"id\":2765,\"tagName\":\"PRE\",\"attributes\":{\"id\":\"jspsych-data-display\"},\"parentNode\":{\"id\":55}},{\"nodeType\":3,\"id\":2766,\"textContent\":\"[ { \\\"rt\\\": 103873, \\\"stimulus\\\": \\\"img/phone.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"phone\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 0, \\\"time_elapsed\\\": 103877, \\\"internal_node_id\\\": \\\"0.0-0.0\\\", \\\"subject\\\": \\\"EER58\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 4776, \\\"url\\\": \\\"../views/src/external/consent.html\\\", \\\"block\\\": \\\"consent\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 1, \\\"time_elapsed\\\": 109985, \\\"internal_node_id\\\": \\\"0.0-1.0\\\", \\\"subject\\\": \\\"EER58\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 12550, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"XRAY\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"311\\\\\\\"}\\\", \\\"block\\\": \\\"codes\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 2, \\\"time_elapsed\\\": 123544, \\\"internal_node_id\\\": \\\"0.0-2.0\\\", \\\"subject\\\": \\\"EER58\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 17554, \\\"url\\\": \\\"../views/src/external/instructions_lab.html\\\", \\\"block\\\": \\\"instructions_lab\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 3, \\\"time_elapsed\\\": 142188, \\\"internal_node_id\\\": \\\"0.0-3.0\\\", \\\"subject\\\": \\\"EER58\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 15497, \\\"stimulus\\\": \\\"img/acme.png\\\", \\\"key_press\\\": 13, \\\"block\\\": \\\"scenario\\\", \\\"trial_type\\\": \\\"single-stim\\\", \\\"trial_index\\\": 4, \\\"time_elapsed\\\": 158688, \\\"internal_node_id\\\": \\\"0.0-4.0\\\", \\\"subject\\\": \\\"EER58\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 30166, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 5, \\\"time_elapsed\\\": 190216, \\\"internal_node_id\\\": \\\"0.0-5.0-0.0\\\", \\\"subject\\\": \\\"EER58\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 1, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"A\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-01 PM-11 AM-A -A -11 AM-12 PM-11 AM-A -11 AM-12 PM-11 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:955,y:1082,t:1527876574064};\\\", \\\"{x:975,y:1060,t:1527876574080};\\\", \\\"{x:1008,y:1033,t:1527876574096};\\\", \\\"{x:1038,y:1015,t:1527876574113};\\\", \\\"{x:1075,y:996,t:1527876574130};\\\", \\\"{x:1118,y:980,t:1527876574147};\\\", \\\"{x:1181,y:965,t:1527876574163};\\\", \\\"{x:1238,y:953,t:1527876574179};\\\", \\\"{x:1289,y:944,t:1527876574197};\\\", \\\"{x:1319,y:939,t:1527876574212};\\\", \\\"{x:1350,y:935,t:1527876574230};\\\", \\\"{x:1375,y:935,t:1527876574247};\\\", \\\"{x:1408,y:935,t:1527876574263};\\\", \\\"{x:1423,y:935,t:1527876574279};\\\", \\\"{x:1427,y:935,t:1527876574297};\\\", \\\"{x:1428,y:935,t:1527876574368};\\\", \\\"{x:1429,y:935,t:1527876574380};\\\", \\\"{x:1431,y:939,t:1527876574397};\\\", \\\"{x:1433,y:944,t:1527876574414};\\\", \\\"{x:1434,y:947,t:1527876574430};\\\", \\\"{x:1434,y:952,t:1527876574448};\\\", \\\"{x:1434,y:960,t:1527876574464};\\\", \\\"{x:1434,y:963,t:1527876574480};\\\", \\\"{x:1434,y:967,t:1527876574497};\\\", \\\"{x:1434,y:969,t:1527876574514};\\\", \\\"{x:1434,y:971,t:1527876574532};\\\", \\\"{x:1434,y:973,t:1527876574547};\\\", \\\"{x:1434,y:974,t:1527876574568};\\\", \\\"{x:1433,y:975,t:1527876574584};\\\", \\\"{x:1430,y:978,t:1527876574597};\\\", \\\"{x:1423,y:981,t:1527876574615};\\\", \\\"{x:1411,y:985,t:1527876574631};\\\", \\\"{x:1400,y:989,t:1527876574647};\\\", \\\"{x:1368,y:998,t:1527876574664};\\\", \\\"{x:1346,y:1000,t:1527876574680};\\\", \\\"{x:1327,y:1003,t:1527876574697};\\\", \\\"{x:1312,y:1003,t:1527876574714};\\\", \\\"{x:1306,y:1003,t:1527876574731};\\\", \\\"{x:1304,y:1003,t:1527876574747};\\\", \\\"{x:1303,y:1003,t:1527876574776};\\\", \\\"{x:1303,y:1002,t:1527876574824};\\\", \\\"{x:1303,y:1001,t:1527876574832};\\\", \\\"{x:1303,y:999,t:1527876574848};\\\", \\\"{x:1303,y:996,t:1527876574864};\\\", \\\"{x:1303,y:992,t:1527876574881};\\\", \\\"{x:1300,y:987,t:1527876574898};\\\", \\\"{x:1294,y:976,t:1527876574915};\\\", \\\"{x:1286,y:966,t:1527876574936};\\\", \\\"{x:1285,y:963,t:1527876574947};\\\", \\\"{x:1284,y:961,t:1527876574964};\\\", \\\"{x:1284,y:960,t:1527876574980};\\\", \\\"{x:1284,y:958,t:1527876574997};\\\", \\\"{x:1284,y:957,t:1527876575015};\\\", \\\"{x:1283,y:956,t:1527876575039};\\\", \\\"{x:1282,y:955,t:1527876575055};\\\", \\\"{x:1282,y:953,t:1527876575489};\\\", \\\"{x:1282,y:943,t:1527876575498};\\\", \\\"{x:1284,y:921,t:1527876575515};\\\", \\\"{x:1288,y:899,t:1527876575532};\\\", \\\"{x:1290,y:886,t:1527876575548};\\\", \\\"{x:1291,y:881,t:1527876575564};\\\", \\\"{x:1293,y:874,t:1527876575581};\\\", \\\"{x:1294,y:870,t:1527876575599};\\\", \\\"{x:1295,y:866,t:1527876575615};\\\", \\\"{x:1296,y:862,t:1527876575632};\\\", \\\"{x:1297,y:856,t:1527876575648};\\\", \\\"{x:1297,y:854,t:1527876575665};\\\", \\\"{x:1297,y:853,t:1527876575736};\\\", \\\"{x:1297,y:851,t:1527876575748};\\\", \\\"{x:1295,y:848,t:1527876575764};\\\", \\\"{x:1294,y:841,t:1527876575780};\\\", \\\"{x:1293,y:838,t:1527876575798};\\\", \\\"{x:1292,y:837,t:1527876575831};\\\", \\\"{x:1291,y:836,t:1527876575847};\\\", \\\"{x:1289,y:833,t:1527876575864};\\\", \\\"{x:1288,y:831,t:1527876575881};\\\", \\\"{x:1287,y:830,t:1527876576113};\\\", \\\"{x:1286,y:830,t:1527876576128};\\\", \\\"{x:1283,y:829,t:1527876576165};\\\", \\\"{x:1282,y:829,t:1527876576295};\\\", \\\"{x:1282,y:830,t:1527876580928};\\\", \\\"{x:1282,y:831,t:1527876582488};\\\", \\\"{x:1281,y:831,t:1527876582503};\\\", \\\"{x:1279,y:831,t:1527876582520};\\\", \\\"{x:1278,y:831,t:1527876582537};\\\", \\\"{x:1276,y:833,t:1527876582557};\\\", \\\"{x:1275,y:834,t:1527876582575};\\\", \\\"{x:1274,y:834,t:1527876582719};\\\", \\\"{x:1273,y:834,t:1527876582737};\\\", \\\"{x:1271,y:834,t:1527876582754};\\\", \\\"{x:1267,y:834,t:1527876582770};\\\", \\\"{x:1265,y:834,t:1527876582788};\\\", \\\"{x:1262,y:833,t:1527876582804};\\\", \\\"{x:1261,y:833,t:1527876582820};\\\", \\\"{x:1261,y:832,t:1527876582944};\\\", \\\"{x:1261,y:831,t:1527876582955};\\\", \\\"{x:1261,y:830,t:1527876582970};\\\", \\\"{x:1264,y:829,t:1527876582987};\\\", \\\"{x:1267,y:828,t:1527876583004};\\\", \\\"{x:1270,y:826,t:1527876583020};\\\", \\\"{x:1273,y:826,t:1527876583038};\\\", \\\"{x:1278,y:826,t:1527876583059};\\\", \\\"{x:1286,y:824,t:1527876583071};\\\", \\\"{x:1297,y:823,t:1527876583087};\\\", \\\"{x:1303,y:822,t:1527876583104};\\\", \\\"{x:1309,y:821,t:1527876583120};\\\", \\\"{x:1314,y:821,t:1527876583137};\\\", \\\"{x:1312,y:821,t:1527876583359};\\\", \\\"{x:1310,y:822,t:1527876583375};\\\", \\\"{x:1308,y:823,t:1527876583391};\\\", \\\"{x:1307,y:824,t:1527876583488};\\\", \\\"{x:1304,y:828,t:1527876583504};\\\", \\\"{x:1303,y:836,t:1527876583522};\\\", \\\"{x:1300,y:851,t:1527876583538};\\\", \\\"{x:1300,y:867,t:1527876583555};\\\", \\\"{x:1300,y:884,t:1527876583572};\\\", \\\"{x:1300,y:897,t:1527876583588};\\\", \\\"{x:1302,y:910,t:1527876583605};\\\", \\\"{x:1303,y:917,t:1527876583622};\\\", \\\"{x:1303,y:926,t:1527876583639};\\\", \\\"{x:1303,y:935,t:1527876583654};\\\", \\\"{x:1303,y:943,t:1527876583671};\\\", \\\"{x:1303,y:946,t:1527876583688};\\\", \\\"{x:1303,y:947,t:1527876583712};\\\", \\\"{x:1303,y:949,t:1527876583722};\\\", \\\"{x:1302,y:952,t:1527876583739};\\\", \\\"{x:1301,y:955,t:1527876583755};\\\", \\\"{x:1300,y:957,t:1527876583772};\\\", \\\"{x:1299,y:958,t:1527876583788};\\\", \\\"{x:1296,y:961,t:1527876583805};\\\", \\\"{x:1293,y:963,t:1527876583822};\\\", \\\"{x:1291,y:965,t:1527876583839};\\\", \\\"{x:1289,y:967,t:1527876583855};\\\", \\\"{x:1285,y:971,t:1527876583872};\\\", \\\"{x:1279,y:972,t:1527876583888};\\\", \\\"{x:1272,y:976,t:1527876583904};\\\", \\\"{x:1269,y:977,t:1527876583922};\\\", \\\"{x:1268,y:978,t:1527876583939};\\\", \\\"{x:1267,y:978,t:1527876583961};\\\", \\\"{x:1265,y:978,t:1527876584024};\\\", \\\"{x:1265,y:976,t:1527876584079};\\\", \\\"{x:1265,y:975,t:1527876584095};\\\", \\\"{x:1265,y:974,t:1527876584119};\\\", \\\"{x:1266,y:973,t:1527876584135};\\\", \\\"{x:1267,y:972,t:1527876584159};\\\", \\\"{x:1268,y:971,t:1527876584171};\\\", \\\"{x:1269,y:969,t:1527876584189};\\\", \\\"{x:1270,y:968,t:1527876584205};\\\", \\\"{x:1271,y:967,t:1527876584221};\\\", \\\"{x:1272,y:966,t:1527876584238};\\\", \\\"{x:1275,y:962,t:1527876584255};\\\", \\\"{x:1276,y:962,t:1527876584271};\\\", \\\"{x:1279,y:960,t:1527876584289};\\\", \\\"{x:1280,y:960,t:1527876584306};\\\", \\\"{x:1283,y:959,t:1527876584322};\\\", \\\"{x:1285,y:958,t:1527876584339};\\\", \\\"{x:1286,y:958,t:1527876584355};\\\", \\\"{x:1287,y:958,t:1527876585496};\\\", \\\"{x:1290,y:959,t:1527876585507};\\\", \\\"{x:1311,y:968,t:1527876585523};\\\", \\\"{x:1330,y:976,t:1527876585540};\\\", \\\"{x:1347,y:983,t:1527876585557};\\\", \\\"{x:1369,y:991,t:1527876585573};\\\", \\\"{x:1382,y:997,t:1527876585590};\\\", \\\"{x:1389,y:1000,t:1527876585607};\\\", \\\"{x:1393,y:1002,t:1527876585623};\\\", \\\"{x:1393,y:1003,t:1527876585672};\\\", \\\"{x:1395,y:1004,t:1527876585690};\\\", \\\"{x:1395,y:1005,t:1527876585744};\\\", \\\"{x:1396,y:1006,t:1527876585757};\\\", \\\"{x:1399,y:1010,t:1527876585773};\\\", \\\"{x:1401,y:1013,t:1527876585790};\\\", \\\"{x:1404,y:1016,t:1527876585807};\\\", \\\"{x:1405,y:1018,t:1527876585824};\\\", \\\"{x:1406,y:1021,t:1527876585840};\\\", \\\"{x:1406,y:1022,t:1527876585857};\\\", \\\"{x:1407,y:1024,t:1527876585888};\\\", \\\"{x:1407,y:1025,t:1527876585896};\\\", \\\"{x:1407,y:1026,t:1527876585907};\\\", \\\"{x:1407,y:1029,t:1527876585924};\\\", \\\"{x:1409,y:1034,t:1527876585940};\\\", \\\"{x:1409,y:1035,t:1527876585957};\\\", \\\"{x:1409,y:1036,t:1527876585974};\\\", \\\"{x:1408,y:1035,t:1527876586320};\\\", \\\"{x:1407,y:1033,t:1527876586327};\\\", \\\"{x:1404,y:1031,t:1527876586340};\\\", \\\"{x:1399,y:1027,t:1527876586356};\\\", \\\"{x:1390,y:1023,t:1527876586373};\\\", \\\"{x:1379,y:1019,t:1527876586390};\\\", \\\"{x:1365,y:1017,t:1527876586406};\\\", \\\"{x:1338,y:1011,t:1527876586422};\\\", \\\"{x:1317,y:1004,t:1527876586440};\\\", \\\"{x:1305,y:1001,t:1527876586456};\\\", \\\"{x:1300,y:1000,t:1527876586474};\\\", \\\"{x:1299,y:1000,t:1527876586490};\\\", \\\"{x:1299,y:999,t:1527876586544};\\\", \\\"{x:1298,y:999,t:1527876586560};\\\", \\\"{x:1297,y:997,t:1527876586578};\\\", \\\"{x:1297,y:996,t:1527876586590};\\\", \\\"{x:1297,y:993,t:1527876586606};\\\", \\\"{x:1294,y:985,t:1527876586623};\\\", \\\"{x:1293,y:977,t:1527876586640};\\\", \\\"{x:1289,y:966,t:1527876586658};\\\", \\\"{x:1287,y:957,t:1527876586673};\\\", \\\"{x:1285,y:951,t:1527876586690};\\\", \\\"{x:1284,y:940,t:1527876586708};\\\", \\\"{x:1280,y:925,t:1527876586723};\\\", \\\"{x:1275,y:906,t:1527876586740};\\\", \\\"{x:1269,y:884,t:1527876586758};\\\", \\\"{x:1268,y:872,t:1527876586774};\\\", \\\"{x:1268,y:866,t:1527876586791};\\\", \\\"{x:1268,y:863,t:1527876586807};\\\", \\\"{x:1268,y:860,t:1527876586823};\\\", \\\"{x:1269,y:858,t:1527876586847};\\\", \\\"{x:1270,y:857,t:1527876586857};\\\", \\\"{x:1273,y:856,t:1527876586873};\\\", \\\"{x:1275,y:854,t:1527876586891};\\\", \\\"{x:1277,y:853,t:1527876586908};\\\", \\\"{x:1278,y:851,t:1527876586923};\\\", \\\"{x:1280,y:846,t:1527876586941};\\\", \\\"{x:1282,y:842,t:1527876586958};\\\", \\\"{x:1283,y:841,t:1527876586974};\\\", \\\"{x:1285,y:838,t:1527876586991};\\\", \\\"{x:1286,y:836,t:1527876587007};\\\", \\\"{x:1286,y:833,t:1527876587024};\\\", \\\"{x:1286,y:829,t:1527876587043};\\\", \\\"{x:1286,y:828,t:1527876587057};\\\", \\\"{x:1286,y:827,t:1527876587126};\\\", \\\"{x:1287,y:826,t:1527876587759};\\\", \\\"{x:1289,y:828,t:1527876589217};\\\", \\\"{x:1290,y:831,t:1527876589226};\\\", \\\"{x:1297,y:838,t:1527876589243};\\\", \\\"{x:1303,y:846,t:1527876589263};\\\", \\\"{x:1306,y:850,t:1527876589280};\\\", \\\"{x:1308,y:853,t:1527876589296};\\\", \\\"{x:1310,y:857,t:1527876589539};\\\", \\\"{x:1310,y:861,t:1527876589548};\\\", \\\"{x:1310,y:870,t:1527876589563};\\\", \\\"{x:1310,y:882,t:1527876589579};\\\", \\\"{x:1309,y:899,t:1527876589597};\\\", \\\"{x:1305,y:925,t:1527876589613};\\\", \\\"{x:1304,y:951,t:1527876589629};\\\", \\\"{x:1303,y:972,t:1527876589646};\\\", \\\"{x:1303,y:986,t:1527876589664};\\\", \\\"{x:1302,y:991,t:1527876589680};\\\", \\\"{x:1301,y:991,t:1527876590106};\\\", \\\"{x:1300,y:991,t:1527876590113};\\\", \\\"{x:1297,y:991,t:1527876590130};\\\", \\\"{x:1293,y:988,t:1527876590146};\\\", \\\"{x:1289,y:986,t:1527876590163};\\\", \\\"{x:1287,y:985,t:1527876590179};\\\", \\\"{x:1285,y:983,t:1527876590197};\\\", \\\"{x:1282,y:982,t:1527876590212};\\\", \\\"{x:1280,y:981,t:1527876590229};\\\", \\\"{x:1280,y:980,t:1527876590247};\\\", \\\"{x:1279,y:979,t:1527876590262};\\\", \\\"{x:1279,y:978,t:1527876590279};\\\", \\\"{x:1279,y:977,t:1527876590369};\\\", \\\"{x:1279,y:975,t:1527876590401};\\\", \\\"{x:1279,y:973,t:1527876590434};\\\", \\\"{x:1279,y:972,t:1527876590457};\\\", \\\"{x:1280,y:972,t:1527876590466};\\\", \\\"{x:1281,y:971,t:1527876590497};\\\", \\\"{x:1282,y:971,t:1527876590514};\\\", \\\"{x:1286,y:971,t:1527876590530};\\\", \\\"{x:1307,y:975,t:1527876590547};\\\", \\\"{x:1331,y:983,t:1527876590563};\\\", \\\"{x:1355,y:990,t:1527876590579};\\\", \\\"{x:1374,y:998,t:1527876590597};\\\", \\\"{x:1382,y:1003,t:1527876590614};\\\", \\\"{x:1386,y:1004,t:1527876590630};\\\", \\\"{x:1387,y:1004,t:1527876590647};\\\", \\\"{x:1388,y:1004,t:1527876590780};\\\", \\\"{x:1388,y:1005,t:1527876590827};\\\", \\\"{x:1389,y:1006,t:1527876590835};\\\", \\\"{x:1391,y:1007,t:1527876590847};\\\", \\\"{x:1400,y:1011,t:1527876590864};\\\", \\\"{x:1417,y:1015,t:1527876590880};\\\", \\\"{x:1433,y:1019,t:1527876590897};\\\", \\\"{x:1449,y:1022,t:1527876590915};\\\", \\\"{x:1465,y:1024,t:1527876590930};\\\", \\\"{x:1489,y:1028,t:1527876590947};\\\", \\\"{x:1506,y:1031,t:1527876590964};\\\", \\\"{x:1521,y:1032,t:1527876590981};\\\", \\\"{x:1535,y:1032,t:1527876590997};\\\", \\\"{x:1541,y:1032,t:1527876591015};\\\", \\\"{x:1542,y:1032,t:1527876591032};\\\", \\\"{x:1537,y:1032,t:1527876591140};\\\", \\\"{x:1527,y:1031,t:1527876591147};\\\", \\\"{x:1485,y:1029,t:1527876591165};\\\", \\\"{x:1405,y:1023,t:1527876591181};\\\", \\\"{x:1299,y:1019,t:1527876591197};\\\", \\\"{x:1171,y:1015,t:1527876591214};\\\", \\\"{x:1041,y:1013,t:1527876591232};\\\", \\\"{x:901,y:1002,t:1527876591248};\\\", \\\"{x:759,y:976,t:1527876591264};\\\", \\\"{x:629,y:913,t:1527876591281};\\\", \\\"{x:496,y:825,t:1527876591297};\\\", \\\"{x:402,y:742,t:1527876591314};\\\", \\\"{x:341,y:656,t:1527876591333};\\\", \\\"{x:331,y:594,t:1527876591348};\\\", \\\"{x:331,y:532,t:1527876591364};\\\", \\\"{x:331,y:496,t:1527876591381};\\\", \\\"{x:331,y:475,t:1527876591397};\\\", \\\"{x:335,y:462,t:1527876591414};\\\", \\\"{x:341,y:441,t:1527876591431};\\\", \\\"{x:344,y:422,t:1527876591447};\\\", \\\"{x:344,y:399,t:1527876591464};\\\", \\\"{x:335,y:376,t:1527876591481};\\\", \\\"{x:331,y:368,t:1527876591496};\\\", \\\"{x:331,y:367,t:1527876591513};\\\", \\\"{x:335,y:369,t:1527876591538};\\\", \\\"{x:342,y:374,t:1527876591547};\\\", \\\"{x:380,y:403,t:1527876591564};\\\", \\\"{x:433,y:437,t:1527876591581};\\\", \\\"{x:478,y:468,t:1527876591597};\\\", \\\"{x:509,y:489,t:1527876591614};\\\", \\\"{x:537,y:509,t:1527876591631};\\\", \\\"{x:557,y:525,t:1527876591648};\\\", \\\"{x:570,y:535,t:1527876591664};\\\", \\\"{x:573,y:539,t:1527876591681};\\\", \\\"{x:573,y:540,t:1527876591698};\\\", \\\"{x:573,y:541,t:1527876591771};\\\", \\\"{x:572,y:541,t:1527876591795};\\\", \\\"{x:570,y:541,t:1527876591803};\\\", \\\"{x:568,y:540,t:1527876591814};\\\", \\\"{x:561,y:535,t:1527876591831};\\\", \\\"{x:556,y:531,t:1527876591847};\\\", \\\"{x:552,y:527,t:1527876591864};\\\", \\\"{x:550,y:525,t:1527876591882};\\\", \\\"{x:548,y:524,t:1527876591899};\\\", \\\"{x:546,y:522,t:1527876591914};\\\", \\\"{x:546,y:521,t:1527876591931};\\\", \\\"{x:543,y:521,t:1527876591949};\\\", \\\"{x:541,y:521,t:1527876591964};\\\", \\\"{x:540,y:521,t:1527876591982};\\\", \\\"{x:539,y:521,t:1527876592036};\\\", \\\"{x:538,y:521,t:1527876592172};\\\", \\\"{x:536,y:521,t:1527876592187};\\\", \\\"{x:533,y:521,t:1527876592198};\\\", \\\"{x:524,y:525,t:1527876592214};\\\", \\\"{x:508,y:529,t:1527876592232};\\\", \\\"{x:485,y:538,t:1527876592248};\\\", \\\"{x:454,y:549,t:1527876592267};\\\", \\\"{x:422,y:555,t:1527876592281};\\\", \\\"{x:373,y:564,t:1527876592297};\\\", \\\"{x:351,y:567,t:1527876592315};\\\", \\\"{x:337,y:570,t:1527876592332};\\\", \\\"{x:334,y:570,t:1527876592348};\\\", \\\"{x:337,y:569,t:1527876592507};\\\", \\\"{x:342,y:568,t:1527876592516};\\\", \\\"{x:355,y:564,t:1527876592536};\\\", \\\"{x:359,y:563,t:1527876592549};\\\", \\\"{x:362,y:563,t:1527876592567};\\\", \\\"{x:363,y:563,t:1527876592668};\\\", \\\"{x:365,y:563,t:1527876592683};\\\", \\\"{x:366,y:563,t:1527876592795};\\\", \\\"{x:367,y:563,t:1527876592803};\\\", \\\"{x:368,y:563,t:1527876592817};\\\", \\\"{x:369,y:563,t:1527876592834};\\\", \\\"{x:371,y:562,t:1527876592851};\\\", \\\"{x:373,y:562,t:1527876592868};\\\", \\\"{x:374,y:562,t:1527876592885};\\\", \\\"{x:375,y:561,t:1527876592900};\\\", \\\"{x:376,y:561,t:1527876593828};\\\", \\\"{x:379,y:562,t:1527876593835};\\\", \\\"{x:388,y:568,t:1527876593849};\\\", \\\"{x:424,y:587,t:1527876593867};\\\", \\\"{x:535,y:618,t:1527876593884};\\\", \\\"{x:652,y:656,t:1527876593901};\\\", \\\"{x:790,y:697,t:1527876593916};\\\", \\\"{x:914,y:722,t:1527876593933};\\\", \\\"{x:1014,y:737,t:1527876593949};\\\", \\\"{x:1076,y:747,t:1527876593965};\\\", \\\"{x:1102,y:752,t:1527876593983};\\\", \\\"{x:1112,y:754,t:1527876594000};\\\", \\\"{x:1113,y:754,t:1527876594016};\\\", \\\"{x:1112,y:754,t:1527876594434};\\\", \\\"{x:1111,y:755,t:1527876594564};\\\", \\\"{x:1115,y:761,t:1527876594571};\\\", \\\"{x:1122,y:766,t:1527876594584};\\\", \\\"{x:1135,y:777,t:1527876594600};\\\", \\\"{x:1150,y:787,t:1527876594617};\\\", \\\"{x:1163,y:796,t:1527876594632};\\\", \\\"{x:1172,y:804,t:1527876594649};\\\", \\\"{x:1176,y:807,t:1527876594666};\\\", \\\"{x:1178,y:810,t:1527876594683};\\\", \\\"{x:1179,y:811,t:1527876594699};\\\", \\\"{x:1180,y:813,t:1527876594716};\\\", \\\"{x:1181,y:814,t:1527876594732};\\\", \\\"{x:1183,y:818,t:1527876594750};\\\", \\\"{x:1188,y:824,t:1527876594767};\\\", \\\"{x:1192,y:834,t:1527876594784};\\\", \\\"{x:1201,y:851,t:1527876594800};\\\", \\\"{x:1209,y:867,t:1527876594818};\\\", \\\"{x:1217,y:887,t:1527876594833};\\\", \\\"{x:1231,y:907,t:1527876594850};\\\", \\\"{x:1251,y:936,t:1527876594867};\\\", \\\"{x:1262,y:951,t:1527876594883};\\\", \\\"{x:1271,y:961,t:1527876594900};\\\", \\\"{x:1277,y:968,t:1527876594917};\\\", \\\"{x:1279,y:973,t:1527876594934};\\\", \\\"{x:1279,y:974,t:1527876594951};\\\", \\\"{x:1280,y:974,t:1527876594967};\\\", \\\"{x:1281,y:976,t:1527876594995};\\\", \\\"{x:1281,y:974,t:1527876595627};\\\", \\\"{x:1282,y:973,t:1527876595651};\\\", \\\"{x:1282,y:971,t:1527876595708};\\\", \\\"{x:1282,y:970,t:1527876595739};\\\", \\\"{x:1283,y:970,t:1527876595750};\\\", \\\"{x:1283,y:968,t:1527876595771};\\\", \\\"{x:1284,y:967,t:1527876595795};\\\", \\\"{x:1284,y:965,t:1527876595852};\\\", \\\"{x:1284,y:964,t:1527876595908};\\\", \\\"{x:1284,y:963,t:1527876595917};\\\", \\\"{x:1284,y:961,t:1527876595935};\\\", \\\"{x:1284,y:960,t:1527876595955};\\\", \\\"{x:1284,y:959,t:1527876595971};\\\", \\\"{x:1284,y:958,t:1527876595987};\\\", \\\"{x:1285,y:957,t:1527876596003};\\\", \\\"{x:1285,y:955,t:1527876596018};\\\", \\\"{x:1285,y:950,t:1527876596035};\\\", \\\"{x:1285,y:934,t:1527876596051};\\\", \\\"{x:1285,y:925,t:1527876596067};\\\", \\\"{x:1285,y:918,t:1527876596085};\\\", \\\"{x:1285,y:914,t:1527876596101};\\\", \\\"{x:1286,y:912,t:1527876596118};\\\", \\\"{x:1287,y:909,t:1527876596135};\\\", \\\"{x:1287,y:907,t:1527876596152};\\\", \\\"{x:1287,y:903,t:1527876596168};\\\", \\\"{x:1287,y:898,t:1527876596184};\\\", \\\"{x:1287,y:891,t:1527876596201};\\\", \\\"{x:1288,y:887,t:1527876596218};\\\", \\\"{x:1288,y:884,t:1527876596234};\\\", \\\"{x:1288,y:880,t:1527876596251};\\\", \\\"{x:1288,y:874,t:1527876596268};\\\", \\\"{x:1288,y:866,t:1527876596285};\\\", \\\"{x:1288,y:860,t:1527876596302};\\\", \\\"{x:1288,y:857,t:1527876596317};\\\", \\\"{x:1288,y:855,t:1527876596335};\\\", \\\"{x:1287,y:855,t:1527876596787};\\\", \\\"{x:1287,y:858,t:1527876596801};\\\", \\\"{x:1287,y:866,t:1527876596818};\\\", \\\"{x:1285,y:881,t:1527876596835};\\\", \\\"{x:1282,y:894,t:1527876596851};\\\", \\\"{x:1281,y:905,t:1527876596868};\\\", \\\"{x:1278,y:918,t:1527876596885};\\\", \\\"{x:1275,y:929,t:1527876596902};\\\", \\\"{x:1271,y:938,t:1527876596919};\\\", \\\"{x:1268,y:946,t:1527876596935};\\\", \\\"{x:1266,y:951,t:1527876596952};\\\", \\\"{x:1263,y:955,t:1527876596969};\\\", \\\"{x:1262,y:956,t:1527876596984};\\\", \\\"{x:1261,y:957,t:1527876597002};\\\", \\\"{x:1259,y:958,t:1527876597019};\\\", \\\"{x:1258,y:958,t:1527876597035};\\\", \\\"{x:1258,y:959,t:1527876597052};\\\", \\\"{x:1256,y:960,t:1527876597075};\\\", \\\"{x:1254,y:961,t:1527876597091};\\\", \\\"{x:1251,y:961,t:1527876597101};\\\", \\\"{x:1245,y:964,t:1527876597119};\\\", \\\"{x:1242,y:965,t:1527876597136};\\\", \\\"{x:1239,y:965,t:1527876597152};\\\", \\\"{x:1235,y:965,t:1527876597169};\\\", \\\"{x:1229,y:966,t:1527876597185};\\\", \\\"{x:1223,y:968,t:1527876597202};\\\", \\\"{x:1221,y:968,t:1527876597219};\\\", \\\"{x:1220,y:968,t:1527876597243};\\\", \\\"{x:1219,y:968,t:1527876597283};\\\", \\\"{x:1218,y:968,t:1527876597291};\\\", \\\"{x:1218,y:964,t:1527876597302};\\\", \\\"{x:1217,y:947,t:1527876597319};\\\", \\\"{x:1217,y:923,t:1527876597335};\\\", \\\"{x:1216,y:902,t:1527876597352};\\\", \\\"{x:1216,y:886,t:1527876597369};\\\", \\\"{x:1216,y:883,t:1527876597385};\\\", \\\"{x:1216,y:882,t:1527876597402};\\\", \\\"{x:1216,y:884,t:1527876597562};\\\", \\\"{x:1216,y:889,t:1527876597570};\\\", \\\"{x:1216,y:896,t:1527876597585};\\\", \\\"{x:1218,y:913,t:1527876597601};\\\", \\\"{x:1223,y:936,t:1527876597618};\\\", \\\"{x:1228,y:948,t:1527876597634};\\\", \\\"{x:1230,y:953,t:1527876597651};\\\", \\\"{x:1233,y:955,t:1527876597669};\\\", \\\"{x:1236,y:957,t:1527876597685};\\\", \\\"{x:1239,y:959,t:1527876597701};\\\", \\\"{x:1250,y:962,t:1527876597718};\\\", \\\"{x:1262,y:962,t:1527876597736};\\\", \\\"{x:1278,y:962,t:1527876597752};\\\", \\\"{x:1298,y:962,t:1527876597769};\\\", \\\"{x:1315,y:962,t:1527876597786};\\\", \\\"{x:1329,y:962,t:1527876597802};\\\", \\\"{x:1338,y:962,t:1527876597818};\\\", \\\"{x:1341,y:962,t:1527876597836};\\\", \\\"{x:1342,y:961,t:1527876597852};\\\", \\\"{x:1345,y:960,t:1527876597869};\\\", \\\"{x:1349,y:959,t:1527876597886};\\\", \\\"{x:1356,y:956,t:1527876597901};\\\", \\\"{x:1361,y:954,t:1527876597918};\\\", \\\"{x:1365,y:953,t:1527876597935};\\\", \\\"{x:1368,y:953,t:1527876597953};\\\", \\\"{x:1370,y:953,t:1527876598027};\\\", \\\"{x:1370,y:952,t:1527876598043};\\\", \\\"{x:1370,y:951,t:1527876598059};\\\", \\\"{x:1370,y:950,t:1527876598068};\\\", \\\"{x:1370,y:945,t:1527876598086};\\\", \\\"{x:1370,y:940,t:1527876598102};\\\", \\\"{x:1368,y:936,t:1527876598119};\\\", \\\"{x:1367,y:934,t:1527876598135};\\\", \\\"{x:1366,y:932,t:1527876598152};\\\", \\\"{x:1366,y:931,t:1527876598169};\\\", \\\"{x:1365,y:931,t:1527876598331};\\\", \\\"{x:1365,y:932,t:1527876598363};\\\", \\\"{x:1365,y:933,t:1527876598371};\\\", \\\"{x:1365,y:934,t:1527876598387};\\\", \\\"{x:1365,y:935,t:1527876598402};\\\", \\\"{x:1365,y:936,t:1527876598419};\\\", \\\"{x:1365,y:938,t:1527876598436};\\\", \\\"{x:1365,y:939,t:1527876598452};\\\", \\\"{x:1365,y:940,t:1527876598468};\\\", \\\"{x:1365,y:942,t:1527876598486};\\\", \\\"{x:1365,y:944,t:1527876598503};\\\", \\\"{x:1365,y:946,t:1527876598519};\\\", \\\"{x:1365,y:947,t:1527876598535};\\\", \\\"{x:1365,y:948,t:1527876598553};\\\", \\\"{x:1365,y:950,t:1527876598568};\\\", \\\"{x:1365,y:952,t:1527876598586};\\\", \\\"{x:1361,y:955,t:1527876598603};\\\", \\\"{x:1360,y:956,t:1527876598619};\\\", \\\"{x:1358,y:958,t:1527876598636};\\\", \\\"{x:1357,y:959,t:1527876598653};\\\", \\\"{x:1353,y:961,t:1527876598668};\\\", \\\"{x:1352,y:962,t:1527876598686};\\\", \\\"{x:1348,y:963,t:1527876598703};\\\", \\\"{x:1344,y:964,t:1527876598720};\\\", \\\"{x:1338,y:965,t:1527876598735};\\\", \\\"{x:1332,y:965,t:1527876598752};\\\", \\\"{x:1325,y:965,t:1527876598768};\\\", \\\"{x:1315,y:965,t:1527876598785};\\\", \\\"{x:1292,y:965,t:1527876598802};\\\", \\\"{x:1271,y:965,t:1527876598818};\\\", \\\"{x:1243,y:965,t:1527876598836};\\\", \\\"{x:1208,y:963,t:1527876598852};\\\", \\\"{x:1163,y:958,t:1527876598868};\\\", \\\"{x:1118,y:950,t:1527876598885};\\\", \\\"{x:1059,y:942,t:1527876598902};\\\", \\\"{x:1001,y:934,t:1527876598919};\\\", \\\"{x:939,y:924,t:1527876598936};\\\", \\\"{x:878,y:916,t:1527876598952};\\\", \\\"{x:811,y:907,t:1527876598969};\\\", \\\"{x:746,y:897,t:1527876598985};\\\", \\\"{x:639,y:883,t:1527876599002};\\\", \\\"{x:551,y:872,t:1527876599019};\\\", \\\"{x:459,y:858,t:1527876599035};\\\", \\\"{x:364,y:843,t:1527876599052};\\\", \\\"{x:273,y:815,t:1527876599069};\\\", \\\"{x:204,y:789,t:1527876599085};\\\", \\\"{x:158,y:764,t:1527876599102};\\\", \\\"{x:126,y:746,t:1527876599119};\\\", \\\"{x:99,y:730,t:1527876599135};\\\", \\\"{x:85,y:722,t:1527876599152};\\\", \\\"{x:82,y:721,t:1527876599170};\\\", \\\"{x:82,y:720,t:1527876599186};\\\", \\\"{x:86,y:720,t:1527876599259};\\\", \\\"{x:93,y:720,t:1527876599269};\\\", \\\"{x:115,y:720,t:1527876599286};\\\", \\\"{x:153,y:725,t:1527876599303};\\\", \\\"{x:223,y:734,t:1527876599320};\\\", \\\"{x:314,y:745,t:1527876599336};\\\", \\\"{x:406,y:761,t:1527876599353};\\\", \\\"{x:478,y:771,t:1527876599372};\\\", \\\"{x:522,y:782,t:1527876599385};\\\", \\\"{x:555,y:787,t:1527876599402};\\\", \\\"{x:558,y:787,t:1527876599420};\\\", \\\"{x:556,y:786,t:1527876599547};\\\", \\\"{x:555,y:785,t:1527876599554};\\\", \\\"{x:552,y:785,t:1527876599570};\\\", \\\"{x:551,y:784,t:1527876599603};\\\", \\\"{x:550,y:784,t:1527876599611};\\\", \\\"{x:548,y:783,t:1527876599620};\\\", \\\"{x:546,y:781,t:1527876599638};\\\", \\\"{x:538,y:778,t:1527876599653};\\\", \\\"{x:534,y:776,t:1527876599670};\\\", \\\"{x:526,y:773,t:1527876599688};\\\", \\\"{x:522,y:772,t:1527876599704};\\\", \\\"{x:521,y:771,t:1527876599722};\\\", \\\"{x:520,y:770,t:1527876599850};\\\", \\\"{x:520,y:769,t:1527876599858};\\\", \\\"{x:518,y:766,t:1527876599871};\\\", \\\"{x:517,y:763,t:1527876599890};\\\", \\\"{x:517,y:761,t:1527876599907};\\\", \\\"{x:516,y:759,t:1527876599922};\\\", \\\"{x:516,y:758,t:1527876599938};\\\", \\\"{x:516,y:752,t:1527876599955};\\\", \\\"{x:516,y:751,t:1527876599972};\\\" ] }, { \\\"rt\\\": 65641, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 6, \\\"time_elapsed\\\": 257107, \\\"internal_node_id\\\": \\\"0.0-5.0-1.0\\\", \\\"subject\\\": \\\"EER58\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 2, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-05 PM-05 PM-D -D -D -D -Z -Z -A -A -Z -Z -C -C -F -F -D -D -Z -U -U -F -F -K -K -K -D -K -D -D -X -X -E -E -E \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:516,y:750,t:1527876604027};\\\", \\\"{x:516,y:749,t:1527876604042};\\\", \\\"{x:525,y:749,t:1527876604058};\\\", \\\"{x:533,y:749,t:1527876604074};\\\", \\\"{x:551,y:751,t:1527876604091};\\\", \\\"{x:573,y:755,t:1527876604108};\\\", \\\"{x:594,y:760,t:1527876604124};\\\", \\\"{x:624,y:763,t:1527876604141};\\\", \\\"{x:663,y:769,t:1527876604157};\\\", \\\"{x:708,y:776,t:1527876604174};\\\", \\\"{x:759,y:786,t:1527876604191};\\\", \\\"{x:815,y:794,t:1527876604207};\\\", \\\"{x:879,y:802,t:1527876604225};\\\", \\\"{x:955,y:815,t:1527876604241};\\\", \\\"{x:1029,y:824,t:1527876604257};\\\", \\\"{x:1176,y:849,t:1527876604274};\\\", \\\"{x:1263,y:864,t:1527876604291};\\\", \\\"{x:1341,y:875,t:1527876604308};\\\", \\\"{x:1396,y:883,t:1527876604324};\\\", \\\"{x:1450,y:893,t:1527876604341};\\\", \\\"{x:1500,y:905,t:1527876604358};\\\", \\\"{x:1545,y:919,t:1527876604375};\\\", \\\"{x:1576,y:927,t:1527876604391};\\\", \\\"{x:1601,y:934,t:1527876604407};\\\", \\\"{x:1619,y:942,t:1527876604424};\\\", \\\"{x:1640,y:950,t:1527876604441};\\\", \\\"{x:1670,y:962,t:1527876604458};\\\", \\\"{x:1690,y:971,t:1527876604475};\\\", \\\"{x:1708,y:981,t:1527876604493};\\\", \\\"{x:1721,y:984,t:1527876604508};\\\", \\\"{x:1723,y:986,t:1527876604525};\\\", \\\"{x:1724,y:986,t:1527876604611};\\\", \\\"{x:1725,y:987,t:1527876604747};\\\", \\\"{x:1723,y:987,t:1527876604811};\\\", \\\"{x:1722,y:987,t:1527876604824};\\\", \\\"{x:1720,y:987,t:1527876604842};\\\", \\\"{x:1716,y:987,t:1527876604859};\\\", \\\"{x:1713,y:987,t:1527876604875};\\\", \\\"{x:1710,y:987,t:1527876604891};\\\", \\\"{x:1706,y:987,t:1527876604909};\\\", \\\"{x:1702,y:987,t:1527876604925};\\\", \\\"{x:1697,y:987,t:1527876604942};\\\", \\\"{x:1693,y:986,t:1527876604958};\\\", \\\"{x:1689,y:985,t:1527876604976};\\\", \\\"{x:1687,y:985,t:1527876604992};\\\", \\\"{x:1686,y:985,t:1527876605018};\\\", \\\"{x:1684,y:985,t:1527876605042};\\\", \\\"{x:1682,y:985,t:1527876605083};\\\", \\\"{x:1682,y:984,t:1527876605093};\\\", \\\"{x:1678,y:982,t:1527876605108};\\\", \\\"{x:1676,y:981,t:1527876605125};\\\", \\\"{x:1674,y:980,t:1527876605141};\\\", \\\"{x:1671,y:978,t:1527876605158};\\\", \\\"{x:1670,y:978,t:1527876605175};\\\", \\\"{x:1669,y:977,t:1527876605191};\\\", \\\"{x:1667,y:976,t:1527876605210};\\\", \\\"{x:1667,y:975,t:1527876605226};\\\", \\\"{x:1666,y:975,t:1527876605323};\\\", \\\"{x:1666,y:974,t:1527876605339};\\\", \\\"{x:1665,y:973,t:1527876605370};\\\", \\\"{x:1665,y:972,t:1527876605386};\\\", \\\"{x:1664,y:971,t:1527876605403};\\\", \\\"{x:1664,y:970,t:1527876605418};\\\", \\\"{x:1664,y:969,t:1527876605435};\\\", \\\"{x:1664,y:968,t:1527876605500};\\\", \\\"{x:1664,y:967,t:1527876605509};\\\", \\\"{x:1664,y:966,t:1527876605526};\\\", \\\"{x:1664,y:963,t:1527876605543};\\\", \\\"{x:1662,y:960,t:1527876605559};\\\", \\\"{x:1661,y:959,t:1527876605579};\\\", \\\"{x:1660,y:958,t:1527876605595};\\\", \\\"{x:1660,y:957,t:1527876605609};\\\", \\\"{x:1659,y:956,t:1527876605626};\\\", \\\"{x:1658,y:953,t:1527876605643};\\\", \\\"{x:1656,y:951,t:1527876605659};\\\", \\\"{x:1654,y:947,t:1527876605676};\\\", \\\"{x:1651,y:942,t:1527876605693};\\\", \\\"{x:1651,y:940,t:1527876605709};\\\", \\\"{x:1649,y:935,t:1527876605726};\\\", \\\"{x:1648,y:933,t:1527876605743};\\\", \\\"{x:1646,y:931,t:1527876605759};\\\", \\\"{x:1646,y:930,t:1527876605776};\\\", \\\"{x:1645,y:929,t:1527876605792};\\\", \\\"{x:1645,y:928,t:1527876605811};\\\", \\\"{x:1645,y:927,t:1527876605843};\\\", \\\"{x:1642,y:921,t:1527876606299};\\\", \\\"{x:1638,y:910,t:1527876606310};\\\", \\\"{x:1628,y:881,t:1527876606326};\\\", \\\"{x:1621,y:836,t:1527876606342};\\\", \\\"{x:1620,y:791,t:1527876606360};\\\", \\\"{x:1620,y:746,t:1527876606377};\\\", \\\"{x:1625,y:696,t:1527876606393};\\\", \\\"{x:1632,y:643,t:1527876606410};\\\", \\\"{x:1643,y:560,t:1527876606426};\\\", \\\"{x:1648,y:514,t:1527876606443};\\\", \\\"{x:1655,y:476,t:1527876606460};\\\", \\\"{x:1657,y:454,t:1527876606477};\\\", \\\"{x:1657,y:436,t:1527876606493};\\\", \\\"{x:1653,y:422,t:1527876606510};\\\", \\\"{x:1644,y:406,t:1527876606527};\\\", \\\"{x:1630,y:386,t:1527876606543};\\\", \\\"{x:1620,y:373,t:1527876606560};\\\", \\\"{x:1614,y:367,t:1527876606577};\\\", \\\"{x:1613,y:366,t:1527876606593};\\\", \\\"{x:1612,y:366,t:1527876606635};\\\", \\\"{x:1610,y:366,t:1527876606651};\\\", \\\"{x:1607,y:369,t:1527876606660};\\\", \\\"{x:1602,y:383,t:1527876606677};\\\", \\\"{x:1601,y:404,t:1527876606694};\\\", \\\"{x:1599,y:425,t:1527876606710};\\\", \\\"{x:1601,y:443,t:1527876606727};\\\", \\\"{x:1603,y:457,t:1527876606743};\\\", \\\"{x:1606,y:464,t:1527876606760};\\\", \\\"{x:1606,y:466,t:1527876606777};\\\", \\\"{x:1607,y:466,t:1527876606883};\\\", \\\"{x:1609,y:466,t:1527876606894};\\\", \\\"{x:1613,y:460,t:1527876606910};\\\", \\\"{x:1617,y:454,t:1527876606927};\\\", \\\"{x:1620,y:448,t:1527876606943};\\\", \\\"{x:1621,y:444,t:1527876606960};\\\", \\\"{x:1621,y:441,t:1527876606977};\\\", \\\"{x:1621,y:437,t:1527876606994};\\\", \\\"{x:1621,y:435,t:1527876607011};\\\", \\\"{x:1622,y:434,t:1527876607027};\\\", \\\"{x:1623,y:433,t:1527876607243};\\\", \\\"{x:1622,y:432,t:1527876607283};\\\", \\\"{x:1621,y:432,t:1527876607314};\\\", \\\"{x:1620,y:432,t:1527876607339};\\\", \\\"{x:1619,y:432,t:1527876607410};\\\", \\\"{x:1618,y:432,t:1527876607426};\\\", \\\"{x:1617,y:432,t:1527876607458};\\\", \\\"{x:1615,y:432,t:1527876607489};\\\", \\\"{x:1614,y:432,t:1527876607546};\\\", \\\"{x:1612,y:432,t:1527876607610};\\\", \\\"{x:1612,y:434,t:1527876610475};\\\", \\\"{x:1612,y:435,t:1527876610507};\\\", \\\"{x:1612,y:437,t:1527876616795};\\\", \\\"{x:1612,y:438,t:1527876616802};\\\", \\\"{x:1612,y:441,t:1527876616817};\\\", \\\"{x:1611,y:443,t:1527876616834};\\\", \\\"{x:1610,y:445,t:1527876616852};\\\", \\\"{x:1610,y:446,t:1527876616867};\\\", \\\"{x:1609,y:452,t:1527876616884};\\\", \\\"{x:1607,y:460,t:1527876616901};\\\", \\\"{x:1607,y:468,t:1527876616917};\\\", \\\"{x:1606,y:476,t:1527876616934};\\\", \\\"{x:1603,y:485,t:1527876616952};\\\", \\\"{x:1598,y:497,t:1527876616967};\\\", \\\"{x:1595,y:511,t:1527876616985};\\\", \\\"{x:1586,y:536,t:1527876617001};\\\", \\\"{x:1579,y:555,t:1527876617018};\\\", \\\"{x:1571,y:571,t:1527876617035};\\\", \\\"{x:1565,y:584,t:1527876617052};\\\", \\\"{x:1558,y:597,t:1527876617068};\\\", \\\"{x:1552,y:611,t:1527876617084};\\\", \\\"{x:1545,y:626,t:1527876617102};\\\", \\\"{x:1539,y:638,t:1527876617118};\\\", \\\"{x:1532,y:651,t:1527876617134};\\\", \\\"{x:1525,y:665,t:1527876617152};\\\", \\\"{x:1520,y:672,t:1527876617167};\\\", \\\"{x:1519,y:677,t:1527876617185};\\\", \\\"{x:1519,y:674,t:1527876617250};\\\", \\\"{x:1521,y:666,t:1527876617257};\\\", \\\"{x:1529,y:647,t:1527876617268};\\\", \\\"{x:1564,y:589,t:1527876617285};\\\", \\\"{x:1593,y:543,t:1527876617302};\\\", \\\"{x:1622,y:503,t:1527876617319};\\\", \\\"{x:1640,y:475,t:1527876617334};\\\", \\\"{x:1647,y:459,t:1527876617352};\\\", \\\"{x:1650,y:452,t:1527876617369};\\\", \\\"{x:1650,y:448,t:1527876617385};\\\", \\\"{x:1650,y:447,t:1527876617402};\\\", \\\"{x:1650,y:445,t:1527876617458};\\\", \\\"{x:1650,y:444,t:1527876617469};\\\", \\\"{x:1650,y:443,t:1527876617633};\\\", \\\"{x:1648,y:440,t:1527876617641};\\\", \\\"{x:1645,y:438,t:1527876617652};\\\", \\\"{x:1640,y:435,t:1527876617669};\\\", \\\"{x:1633,y:433,t:1527876617685};\\\", \\\"{x:1632,y:432,t:1527876617702};\\\", \\\"{x:1631,y:432,t:1527876617719};\\\", \\\"{x:1630,y:432,t:1527876617962};\\\", \\\"{x:1628,y:432,t:1527876618123};\\\", \\\"{x:1624,y:432,t:1527876618137};\\\", \\\"{x:1613,y:433,t:1527876618156};\\\", \\\"{x:1603,y:434,t:1527876618170};\\\", \\\"{x:1598,y:434,t:1527876618185};\\\", \\\"{x:1595,y:435,t:1527876618203};\\\", \\\"{x:1595,y:433,t:1527876618451};\\\", \\\"{x:1596,y:432,t:1527876618459};\\\", \\\"{x:1596,y:429,t:1527876618470};\\\", \\\"{x:1599,y:425,t:1527876618488};\\\", \\\"{x:1600,y:424,t:1527876618506};\\\", \\\"{x:1600,y:423,t:1527876618546};\\\", \\\"{x:1601,y:423,t:1527876619027};\\\", \\\"{x:1602,y:423,t:1527876619038};\\\", \\\"{x:1604,y:423,t:1527876619053};\\\", \\\"{x:1607,y:423,t:1527876619071};\\\", \\\"{x:1608,y:424,t:1527876619088};\\\", \\\"{x:1609,y:425,t:1527876619226};\\\", \\\"{x:1611,y:426,t:1527876619239};\\\", \\\"{x:1613,y:427,t:1527876619253};\\\", \\\"{x:1615,y:428,t:1527876619269};\\\", \\\"{x:1614,y:430,t:1527876621091};\\\", \\\"{x:1608,y:437,t:1527876621112};\\\", \\\"{x:1606,y:441,t:1527876621125};\\\", \\\"{x:1602,y:447,t:1527876621141};\\\", \\\"{x:1599,y:452,t:1527876621155};\\\", \\\"{x:1595,y:460,t:1527876621172};\\\", \\\"{x:1593,y:468,t:1527876621188};\\\", \\\"{x:1591,y:474,t:1527876621205};\\\", \\\"{x:1588,y:483,t:1527876621222};\\\", \\\"{x:1585,y:490,t:1527876621238};\\\", \\\"{x:1583,y:498,t:1527876621255};\\\", \\\"{x:1581,y:507,t:1527876621272};\\\", \\\"{x:1577,y:516,t:1527876621288};\\\", \\\"{x:1572,y:528,t:1527876621305};\\\", \\\"{x:1567,y:540,t:1527876621322};\\\", \\\"{x:1563,y:550,t:1527876621338};\\\", \\\"{x:1557,y:558,t:1527876621355};\\\", \\\"{x:1550,y:569,t:1527876621372};\\\", \\\"{x:1544,y:577,t:1527876621389};\\\", \\\"{x:1534,y:590,t:1527876621405};\\\", \\\"{x:1526,y:601,t:1527876621422};\\\", \\\"{x:1522,y:606,t:1527876621438};\\\", \\\"{x:1523,y:601,t:1527876621507};\\\", \\\"{x:1536,y:580,t:1527876621522};\\\", \\\"{x:1551,y:552,t:1527876621539};\\\", \\\"{x:1568,y:520,t:1527876621555};\\\", \\\"{x:1581,y:496,t:1527876621572};\\\", \\\"{x:1591,y:480,t:1527876621589};\\\", \\\"{x:1592,y:474,t:1527876621605};\\\", \\\"{x:1594,y:471,t:1527876621623};\\\", \\\"{x:1594,y:469,t:1527876621642};\\\", \\\"{x:1594,y:468,t:1527876621691};\\\", \\\"{x:1595,y:466,t:1527876621706};\\\", \\\"{x:1597,y:463,t:1527876621722};\\\", \\\"{x:1597,y:462,t:1527876621739};\\\", \\\"{x:1598,y:461,t:1527876621755};\\\", \\\"{x:1598,y:458,t:1527876621773};\\\", \\\"{x:1602,y:453,t:1527876621790};\\\", \\\"{x:1607,y:447,t:1527876621805};\\\", \\\"{x:1611,y:441,t:1527876621823};\\\", \\\"{x:1615,y:434,t:1527876621843};\\\", \\\"{x:1617,y:432,t:1527876621856};\\\", \\\"{x:1617,y:430,t:1527876621872};\\\", \\\"{x:1619,y:427,t:1527876621888};\\\", \\\"{x:1619,y:426,t:1527876621904};\\\", \\\"{x:1618,y:426,t:1527876628474};\\\", \\\"{x:1617,y:426,t:1527876628610};\\\", \\\"{x:1616,y:427,t:1527876629451};\\\", \\\"{x:1613,y:428,t:1527876629461};\\\", \\\"{x:1611,y:432,t:1527876629479};\\\", \\\"{x:1606,y:440,t:1527876629498};\\\", \\\"{x:1598,y:455,t:1527876629511};\\\", \\\"{x:1582,y:482,t:1527876629528};\\\", \\\"{x:1546,y:542,t:1527876629546};\\\", \\\"{x:1516,y:594,t:1527876629561};\\\", \\\"{x:1483,y:651,t:1527876629578};\\\", \\\"{x:1449,y:716,t:1527876629596};\\\", \\\"{x:1420,y:782,t:1527876629612};\\\", \\\"{x:1384,y:842,t:1527876629628};\\\", \\\"{x:1364,y:887,t:1527876629645};\\\", \\\"{x:1355,y:904,t:1527876629663};\\\", \\\"{x:1352,y:908,t:1527876629679};\\\", \\\"{x:1350,y:907,t:1527876629738};\\\", \\\"{x:1350,y:903,t:1527876629747};\\\", \\\"{x:1349,y:892,t:1527876629765};\\\", \\\"{x:1346,y:885,t:1527876629779};\\\", \\\"{x:1344,y:883,t:1527876629795};\\\", \\\"{x:1343,y:882,t:1527876629833};\\\", \\\"{x:1343,y:881,t:1527876629850};\\\", \\\"{x:1341,y:879,t:1527876629863};\\\", \\\"{x:1333,y:870,t:1527876629878};\\\", \\\"{x:1322,y:856,t:1527876629896};\\\", \\\"{x:1308,y:844,t:1527876629913};\\\", \\\"{x:1299,y:837,t:1527876629928};\\\", \\\"{x:1293,y:833,t:1527876629945};\\\", \\\"{x:1292,y:832,t:1527876629963};\\\", \\\"{x:1292,y:830,t:1527876629979};\\\", \\\"{x:1292,y:826,t:1527876629996};\\\", \\\"{x:1292,y:818,t:1527876630012};\\\", \\\"{x:1290,y:812,t:1527876630029};\\\", \\\"{x:1290,y:810,t:1527876630046};\\\", \\\"{x:1289,y:810,t:1527876630154};\\\", \\\"{x:1286,y:810,t:1527876630171};\\\", \\\"{x:1285,y:810,t:1527876630179};\\\", \\\"{x:1283,y:815,t:1527876630196};\\\", \\\"{x:1279,y:821,t:1527876630212};\\\", \\\"{x:1277,y:824,t:1527876630229};\\\", \\\"{x:1276,y:825,t:1527876630492};\\\", \\\"{x:1277,y:826,t:1527876630558};\\\", \\\"{x:1279,y:828,t:1527876630579};\\\", \\\"{x:1281,y:828,t:1527876630596};\\\", \\\"{x:1282,y:829,t:1527876630612};\\\", \\\"{x:1284,y:830,t:1527876631323};\\\", \\\"{x:1284,y:831,t:1527876631332};\\\", \\\"{x:1285,y:831,t:1527876631348};\\\", \\\"{x:1288,y:832,t:1527876631367};\\\", \\\"{x:1291,y:833,t:1527876631381};\\\", \\\"{x:1292,y:833,t:1527876631401};\\\", \\\"{x:1292,y:834,t:1527876631546};\\\", \\\"{x:1296,y:836,t:1527876631564};\\\", \\\"{x:1300,y:841,t:1527876631581};\\\", \\\"{x:1311,y:851,t:1527876631597};\\\", \\\"{x:1325,y:868,t:1527876631614};\\\", \\\"{x:1340,y:884,t:1527876631631};\\\", \\\"{x:1357,y:899,t:1527876631647};\\\", \\\"{x:1365,y:904,t:1527876631664};\\\", \\\"{x:1369,y:908,t:1527876631681};\\\", \\\"{x:1370,y:909,t:1527876631696};\\\", \\\"{x:1370,y:908,t:1527876631858};\\\", \\\"{x:1370,y:907,t:1527876631866};\\\", \\\"{x:1370,y:906,t:1527876631883};\\\", \\\"{x:1370,y:905,t:1527876631963};\\\", \\\"{x:1368,y:904,t:1527876631970};\\\", \\\"{x:1367,y:904,t:1527876631980};\\\", \\\"{x:1364,y:904,t:1527876631997};\\\", \\\"{x:1362,y:904,t:1527876632013};\\\", \\\"{x:1361,y:904,t:1527876632031};\\\", \\\"{x:1359,y:904,t:1527876632048};\\\", \\\"{x:1357,y:904,t:1527876632064};\\\", \\\"{x:1353,y:904,t:1527876632080};\\\", \\\"{x:1348,y:902,t:1527876632100};\\\", \\\"{x:1346,y:902,t:1527876632113};\\\", \\\"{x:1344,y:901,t:1527876632179};\\\", \\\"{x:1343,y:900,t:1527876632523};\\\", \\\"{x:1344,y:900,t:1527876632562};\\\", \\\"{x:1345,y:899,t:1527876632578};\\\", \\\"{x:1344,y:899,t:1527876633001};\\\", \\\"{x:1330,y:894,t:1527876633031};\\\", \\\"{x:1313,y:889,t:1527876633048};\\\", \\\"{x:1292,y:884,t:1527876633065};\\\", \\\"{x:1262,y:875,t:1527876633081};\\\", \\\"{x:1252,y:873,t:1527876633097};\\\", \\\"{x:1246,y:869,t:1527876633114};\\\", \\\"{x:1242,y:866,t:1527876633131};\\\", \\\"{x:1242,y:863,t:1527876633147};\\\", \\\"{x:1239,y:859,t:1527876633165};\\\", \\\"{x:1238,y:856,t:1527876633181};\\\", \\\"{x:1237,y:854,t:1527876633198};\\\", \\\"{x:1236,y:851,t:1527876633215};\\\", \\\"{x:1234,y:848,t:1527876633232};\\\", \\\"{x:1234,y:844,t:1527876633248};\\\", \\\"{x:1233,y:841,t:1527876633265};\\\", \\\"{x:1231,y:837,t:1527876633283};\\\", \\\"{x:1231,y:836,t:1527876633298};\\\", \\\"{x:1230,y:834,t:1527876633315};\\\", \\\"{x:1230,y:833,t:1527876633332};\\\", \\\"{x:1227,y:830,t:1527876633348};\\\", \\\"{x:1224,y:826,t:1527876633366};\\\", \\\"{x:1220,y:821,t:1527876633382};\\\", \\\"{x:1215,y:815,t:1527876633398};\\\", \\\"{x:1214,y:814,t:1527876633415};\\\", \\\"{x:1211,y:813,t:1527876633432};\\\", \\\"{x:1210,y:813,t:1527876633450};\\\", \\\"{x:1209,y:813,t:1527876633691};\\\", \\\"{x:1207,y:813,t:1527876633699};\\\", \\\"{x:1207,y:815,t:1527876633716};\\\", \\\"{x:1205,y:818,t:1527876633733};\\\", \\\"{x:1204,y:820,t:1527876633748};\\\", \\\"{x:1204,y:821,t:1527876633765};\\\", \\\"{x:1203,y:823,t:1527876633782};\\\", \\\"{x:1205,y:824,t:1527876633931};\\\", \\\"{x:1213,y:822,t:1527876633938};\\\", \\\"{x:1229,y:817,t:1527876633949};\\\", \\\"{x:1288,y:800,t:1527876633965};\\\", \\\"{x:1357,y:783,t:1527876633982};\\\", \\\"{x:1434,y:764,t:1527876633999};\\\", \\\"{x:1479,y:751,t:1527876634015};\\\", \\\"{x:1492,y:747,t:1527876634032};\\\", \\\"{x:1492,y:748,t:1527876634115};\\\", \\\"{x:1491,y:748,t:1527876634132};\\\", \\\"{x:1489,y:750,t:1527876634149};\\\", \\\"{x:1483,y:751,t:1527876634165};\\\", \\\"{x:1476,y:754,t:1527876634182};\\\", \\\"{x:1468,y:757,t:1527876634199};\\\", \\\"{x:1455,y:761,t:1527876634215};\\\", \\\"{x:1442,y:765,t:1527876634232};\\\", \\\"{x:1427,y:768,t:1527876634250};\\\", \\\"{x:1420,y:768,t:1527876634265};\\\", \\\"{x:1418,y:768,t:1527876634282};\\\", \\\"{x:1417,y:768,t:1527876634338};\\\", \\\"{x:1416,y:769,t:1527876634349};\\\", \\\"{x:1415,y:770,t:1527876634365};\\\", \\\"{x:1410,y:770,t:1527876634381};\\\", \\\"{x:1402,y:772,t:1527876634399};\\\", \\\"{x:1398,y:772,t:1527876634414};\\\", \\\"{x:1395,y:773,t:1527876634432};\\\", \\\"{x:1392,y:773,t:1527876634448};\\\", \\\"{x:1391,y:773,t:1527876634465};\\\", \\\"{x:1388,y:774,t:1527876634482};\\\", \\\"{x:1386,y:774,t:1527876634498};\\\", \\\"{x:1385,y:774,t:1527876634587};\\\", \\\"{x:1385,y:773,t:1527876634602};\\\", \\\"{x:1385,y:772,t:1527876634615};\\\", \\\"{x:1385,y:770,t:1527876634634};\\\", \\\"{x:1385,y:769,t:1527876634691};\\\", \\\"{x:1384,y:766,t:1527876635238};\\\", \\\"{x:1383,y:763,t:1527876635266};\\\", \\\"{x:1381,y:760,t:1527876635282};\\\", \\\"{x:1381,y:759,t:1527876635300};\\\", \\\"{x:1380,y:759,t:1527876635338};\\\", \\\"{x:1379,y:758,t:1527876636203};\\\", \\\"{x:1382,y:755,t:1527876636220};\\\", \\\"{x:1387,y:751,t:1527876636233};\\\", \\\"{x:1396,y:746,t:1527876636251};\\\", \\\"{x:1426,y:735,t:1527876636268};\\\", \\\"{x:1472,y:725,t:1527876636284};\\\", \\\"{x:1547,y:703,t:1527876636301};\\\", \\\"{x:1630,y:680,t:1527876636317};\\\", \\\"{x:1716,y:660,t:1527876636334};\\\", \\\"{x:1791,y:634,t:1527876636350};\\\", \\\"{x:1841,y:613,t:1527876636367};\\\", \\\"{x:1863,y:600,t:1527876636383};\\\", \\\"{x:1866,y:597,t:1527876636401};\\\", \\\"{x:1864,y:597,t:1527876636442};\\\", \\\"{x:1863,y:597,t:1527876636451};\\\", \\\"{x:1861,y:597,t:1527876636469};\\\", \\\"{x:1860,y:597,t:1527876636484};\\\", \\\"{x:1857,y:597,t:1527876636501};\\\", \\\"{x:1855,y:598,t:1527876636519};\\\", \\\"{x:1854,y:598,t:1527876636534};\\\", \\\"{x:1852,y:598,t:1527876636551};\\\", \\\"{x:1851,y:599,t:1527876636568};\\\", \\\"{x:1849,y:600,t:1527876636585};\\\", \\\"{x:1847,y:600,t:1527876636601};\\\", \\\"{x:1845,y:601,t:1527876636618};\\\", \\\"{x:1844,y:601,t:1527876636634};\\\", \\\"{x:1842,y:601,t:1527876636652};\\\", \\\"{x:1838,y:603,t:1527876636668};\\\", \\\"{x:1834,y:603,t:1527876636685};\\\", \\\"{x:1826,y:603,t:1527876636701};\\\", \\\"{x:1810,y:602,t:1527876636718};\\\", \\\"{x:1795,y:598,t:1527876636736};\\\", \\\"{x:1776,y:595,t:1527876636751};\\\", \\\"{x:1748,y:591,t:1527876636768};\\\", \\\"{x:1725,y:591,t:1527876636785};\\\", \\\"{x:1703,y:590,t:1527876636801};\\\", \\\"{x:1688,y:584,t:1527876636818};\\\", \\\"{x:1685,y:581,t:1527876636835};\\\", \\\"{x:1685,y:579,t:1527876636851};\\\", \\\"{x:1683,y:572,t:1527876636867};\\\", \\\"{x:1683,y:568,t:1527876636885};\\\", \\\"{x:1683,y:564,t:1527876636900};\\\", \\\"{x:1683,y:561,t:1527876636918};\\\", \\\"{x:1682,y:559,t:1527876636935};\\\", \\\"{x:1682,y:558,t:1527876636951};\\\", \\\"{x:1682,y:557,t:1527876636968};\\\", \\\"{x:1682,y:553,t:1527876636985};\\\", \\\"{x:1684,y:546,t:1527876637002};\\\", \\\"{x:1687,y:533,t:1527876637018};\\\", \\\"{x:1688,y:523,t:1527876637035};\\\", \\\"{x:1688,y:509,t:1527876637052};\\\", \\\"{x:1688,y:496,t:1527876637068};\\\", \\\"{x:1688,y:482,t:1527876637085};\\\", \\\"{x:1686,y:476,t:1527876637102};\\\", \\\"{x:1685,y:474,t:1527876637118};\\\", \\\"{x:1685,y:473,t:1527876637136};\\\", \\\"{x:1684,y:473,t:1527876637170};\\\", \\\"{x:1683,y:473,t:1527876637186};\\\", \\\"{x:1664,y:464,t:1527876637202};\\\", \\\"{x:1652,y:461,t:1527876637218};\\\", \\\"{x:1644,y:458,t:1527876637235};\\\", \\\"{x:1642,y:458,t:1527876637253};\\\", \\\"{x:1641,y:458,t:1527876637268};\\\", \\\"{x:1640,y:458,t:1527876637306};\\\", \\\"{x:1638,y:457,t:1527876637318};\\\", \\\"{x:1636,y:449,t:1527876637335};\\\", \\\"{x:1633,y:444,t:1527876637352};\\\", \\\"{x:1631,y:441,t:1527876637368};\\\", \\\"{x:1630,y:439,t:1527876637385};\\\", \\\"{x:1629,y:435,t:1527876637402};\\\", \\\"{x:1629,y:429,t:1527876637418};\\\", \\\"{x:1625,y:421,t:1527876637435};\\\", \\\"{x:1621,y:414,t:1527876637452};\\\", \\\"{x:1618,y:409,t:1527876637469};\\\", \\\"{x:1616,y:408,t:1527876637486};\\\", \\\"{x:1615,y:410,t:1527876637635};\\\", \\\"{x:1615,y:418,t:1527876637652};\\\", \\\"{x:1614,y:423,t:1527876637669};\\\", \\\"{x:1613,y:429,t:1527876637689};\\\", \\\"{x:1613,y:431,t:1527876637701};\\\", \\\"{x:1613,y:433,t:1527876637719};\\\", \\\"{x:1613,y:434,t:1527876637735};\\\", \\\"{x:1594,y:471,t:1527876645091};\\\", \\\"{x:1581,y:498,t:1527876645108};\\\", \\\"{x:1567,y:528,t:1527876645124};\\\", \\\"{x:1560,y:556,t:1527876645141};\\\", \\\"{x:1552,y:580,t:1527876645158};\\\", \\\"{x:1545,y:600,t:1527876645174};\\\", \\\"{x:1536,y:625,t:1527876645191};\\\", \\\"{x:1526,y:647,t:1527876645208};\\\", \\\"{x:1519,y:672,t:1527876645224};\\\", \\\"{x:1515,y:698,t:1527876645241};\\\", \\\"{x:1507,y:732,t:1527876645258};\\\", \\\"{x:1504,y:748,t:1527876645276};\\\", \\\"{x:1500,y:754,t:1527876645292};\\\", \\\"{x:1498,y:757,t:1527876645308};\\\", \\\"{x:1493,y:762,t:1527876645325};\\\", \\\"{x:1486,y:769,t:1527876645342};\\\", \\\"{x:1472,y:778,t:1527876645358};\\\", \\\"{x:1454,y:790,t:1527876645375};\\\", \\\"{x:1435,y:802,t:1527876645391};\\\", \\\"{x:1418,y:812,t:1527876645408};\\\", \\\"{x:1405,y:817,t:1527876645425};\\\", \\\"{x:1394,y:822,t:1527876645441};\\\", \\\"{x:1385,y:829,t:1527876645458};\\\", \\\"{x:1382,y:834,t:1527876645476};\\\", \\\"{x:1380,y:836,t:1527876645491};\\\", \\\"{x:1379,y:837,t:1527876645513};\\\", \\\"{x:1378,y:837,t:1527876645546};\\\", \\\"{x:1376,y:838,t:1527876645558};\\\", \\\"{x:1375,y:841,t:1527876645575};\\\", \\\"{x:1374,y:844,t:1527876645592};\\\", \\\"{x:1373,y:848,t:1527876645609};\\\", \\\"{x:1371,y:852,t:1527876645625};\\\", \\\"{x:1370,y:855,t:1527876645642};\\\", \\\"{x:1367,y:863,t:1527876645659};\\\", \\\"{x:1367,y:869,t:1527876645676};\\\", \\\"{x:1366,y:873,t:1527876645692};\\\", \\\"{x:1364,y:878,t:1527876645708};\\\", \\\"{x:1363,y:883,t:1527876645726};\\\", \\\"{x:1361,y:887,t:1527876645742};\\\", \\\"{x:1361,y:889,t:1527876645759};\\\", \\\"{x:1359,y:892,t:1527876645776};\\\", \\\"{x:1359,y:893,t:1527876645793};\\\", \\\"{x:1358,y:895,t:1527876645809};\\\", \\\"{x:1357,y:896,t:1527876645915};\\\", \\\"{x:1356,y:896,t:1527876645930};\\\", \\\"{x:1355,y:896,t:1527876646010};\\\", \\\"{x:1354,y:896,t:1527876646025};\\\", \\\"{x:1352,y:896,t:1527876646045};\\\", \\\"{x:1350,y:896,t:1527876646058};\\\", \\\"{x:1349,y:897,t:1527876646075};\\\", \\\"{x:1347,y:897,t:1527876646092};\\\", \\\"{x:1346,y:897,t:1527876646113};\\\", \\\"{x:1346,y:898,t:1527876646125};\\\", \\\"{x:1345,y:898,t:1527876646142};\\\", \\\"{x:1344,y:898,t:1527876646161};\\\", \\\"{x:1343,y:898,t:1527876646175};\\\", \\\"{x:1342,y:898,t:1527876646192};\\\", \\\"{x:1343,y:898,t:1527876646338};\\\", \\\"{x:1346,y:898,t:1527876646346};\\\", \\\"{x:1348,y:897,t:1527876646359};\\\", \\\"{x:1353,y:896,t:1527876646376};\\\", \\\"{x:1359,y:895,t:1527876646394};\\\", \\\"{x:1363,y:895,t:1527876646409};\\\", \\\"{x:1372,y:894,t:1527876646426};\\\", \\\"{x:1379,y:893,t:1527876646443};\\\", \\\"{x:1386,y:893,t:1527876646459};\\\", \\\"{x:1391,y:891,t:1527876646475};\\\", \\\"{x:1392,y:891,t:1527876646492};\\\", \\\"{x:1395,y:890,t:1527876646509};\\\", \\\"{x:1396,y:890,t:1527876646530};\\\", \\\"{x:1399,y:889,t:1527876646542};\\\", \\\"{x:1402,y:887,t:1527876646560};\\\", \\\"{x:1410,y:882,t:1527876646576};\\\", \\\"{x:1417,y:878,t:1527876646592};\\\", \\\"{x:1426,y:872,t:1527876646609};\\\", \\\"{x:1434,y:868,t:1527876646625};\\\", \\\"{x:1437,y:864,t:1527876646642};\\\", \\\"{x:1439,y:862,t:1527876646659};\\\", \\\"{x:1442,y:860,t:1527876646676};\\\", \\\"{x:1444,y:858,t:1527876646692};\\\", \\\"{x:1448,y:855,t:1527876646709};\\\", \\\"{x:1452,y:852,t:1527876646726};\\\", \\\"{x:1458,y:845,t:1527876646742};\\\", \\\"{x:1465,y:840,t:1527876646759};\\\", \\\"{x:1471,y:834,t:1527876646777};\\\", \\\"{x:1474,y:831,t:1527876646792};\\\", \\\"{x:1476,y:829,t:1527876646811};\\\", \\\"{x:1476,y:828,t:1527876647338};\\\", \\\"{x:1477,y:828,t:1527876647346};\\\", \\\"{x:1477,y:826,t:1527876647362};\\\", \\\"{x:1477,y:824,t:1527876647378};\\\", \\\"{x:1475,y:814,t:1527876647393};\\\", \\\"{x:1467,y:794,t:1527876647410};\\\", \\\"{x:1462,y:780,t:1527876647426};\\\", \\\"{x:1457,y:772,t:1527876647443};\\\", \\\"{x:1450,y:764,t:1527876647460};\\\", \\\"{x:1445,y:759,t:1527876647476};\\\", \\\"{x:1443,y:756,t:1527876647493};\\\", \\\"{x:1438,y:753,t:1527876647510};\\\", \\\"{x:1435,y:751,t:1527876647526};\\\", \\\"{x:1430,y:748,t:1527876647543};\\\", \\\"{x:1420,y:744,t:1527876647560};\\\", \\\"{x:1408,y:741,t:1527876647577};\\\", \\\"{x:1404,y:741,t:1527876647594};\\\", \\\"{x:1402,y:741,t:1527876647610};\\\", \\\"{x:1399,y:741,t:1527876647628};\\\", \\\"{x:1395,y:743,t:1527876647643};\\\", \\\"{x:1391,y:745,t:1527876647660};\\\", \\\"{x:1387,y:748,t:1527876647677};\\\", \\\"{x:1384,y:751,t:1527876647693};\\\", \\\"{x:1382,y:754,t:1527876647711};\\\", \\\"{x:1381,y:755,t:1527876647727};\\\", \\\"{x:1380,y:757,t:1527876647922};\\\", \\\"{x:1380,y:758,t:1527876647949};\\\", \\\"{x:1380,y:759,t:1527876647961};\\\", \\\"{x:1380,y:761,t:1527876647977};\\\", \\\"{x:1380,y:762,t:1527876647993};\\\", \\\"{x:1380,y:763,t:1527876648010};\\\", \\\"{x:1380,y:764,t:1527876648027};\\\", \\\"{x:1380,y:766,t:1527876648043};\\\", \\\"{x:1380,y:765,t:1527876648259};\\\", \\\"{x:1382,y:763,t:1527876648266};\\\", \\\"{x:1386,y:759,t:1527876648280};\\\", \\\"{x:1395,y:750,t:1527876648293};\\\", \\\"{x:1401,y:742,t:1527876648310};\\\", \\\"{x:1413,y:730,t:1527876648327};\\\", \\\"{x:1419,y:723,t:1527876648344};\\\", \\\"{x:1424,y:715,t:1527876648360};\\\", \\\"{x:1426,y:709,t:1527876648377};\\\", \\\"{x:1427,y:704,t:1527876648395};\\\", \\\"{x:1428,y:700,t:1527876648410};\\\", \\\"{x:1431,y:696,t:1527876648427};\\\", \\\"{x:1435,y:689,t:1527876648445};\\\", \\\"{x:1439,y:684,t:1527876648461};\\\", \\\"{x:1442,y:681,t:1527876648478};\\\", \\\"{x:1446,y:675,t:1527876648495};\\\", \\\"{x:1451,y:669,t:1527876648510};\\\", \\\"{x:1461,y:661,t:1527876648527};\\\", \\\"{x:1470,y:655,t:1527876648544};\\\", \\\"{x:1478,y:650,t:1527876648561};\\\", \\\"{x:1485,y:647,t:1527876648577};\\\", \\\"{x:1487,y:645,t:1527876648594};\\\", \\\"{x:1488,y:644,t:1527876648611};\\\", \\\"{x:1489,y:644,t:1527876648628};\\\", \\\"{x:1489,y:643,t:1527876648645};\\\", \\\"{x:1490,y:642,t:1527876648662};\\\", \\\"{x:1492,y:641,t:1527876648677};\\\", \\\"{x:1494,y:639,t:1527876648695};\\\", \\\"{x:1495,y:638,t:1527876648711};\\\", \\\"{x:1497,y:636,t:1527876648728};\\\", \\\"{x:1498,y:636,t:1527876648744};\\\", \\\"{x:1500,y:634,t:1527876648762};\\\", \\\"{x:1501,y:634,t:1527876648778};\\\", \\\"{x:1506,y:632,t:1527876648795};\\\", \\\"{x:1508,y:631,t:1527876648812};\\\", \\\"{x:1509,y:631,t:1527876648838};\\\", \\\"{x:1510,y:630,t:1527876648865};\\\", \\\"{x:1511,y:630,t:1527876648882};\\\", \\\"{x:1512,y:630,t:1527876648894};\\\", \\\"{x:1514,y:629,t:1527876648912};\\\", \\\"{x:1518,y:628,t:1527876648927};\\\", \\\"{x:1521,y:626,t:1527876648945};\\\", \\\"{x:1522,y:626,t:1527876648969};\\\", \\\"{x:1524,y:626,t:1527876648993};\\\", \\\"{x:1523,y:626,t:1527876649501};\\\", \\\"{x:1522,y:627,t:1527876649514};\\\", \\\"{x:1521,y:627,t:1527876649542};\\\", \\\"{x:1520,y:627,t:1527876649574};\\\", \\\"{x:1519,y:628,t:1527876649585};\\\", \\\"{x:1518,y:628,t:1527876649614};\\\", \\\"{x:1518,y:629,t:1527876649668};\\\", \\\"{x:1517,y:629,t:1527876649708};\\\", \\\"{x:1516,y:630,t:1527876649717};\\\", \\\"{x:1516,y:629,t:1527876650845};\\\", \\\"{x:1517,y:624,t:1527876650853};\\\", \\\"{x:1520,y:618,t:1527876650866};\\\", \\\"{x:1533,y:603,t:1527876650882};\\\", \\\"{x:1551,y:582,t:1527876650899};\\\", \\\"{x:1565,y:561,t:1527876650915};\\\", \\\"{x:1581,y:535,t:1527876650932};\\\", \\\"{x:1589,y:519,t:1527876650948};\\\", \\\"{x:1595,y:503,t:1527876650965};\\\", \\\"{x:1600,y:491,t:1527876650982};\\\", \\\"{x:1605,y:480,t:1527876651000};\\\", \\\"{x:1607,y:474,t:1527876651016};\\\", \\\"{x:1609,y:469,t:1527876651032};\\\", \\\"{x:1611,y:463,t:1527876651049};\\\", \\\"{x:1612,y:457,t:1527876651065};\\\", \\\"{x:1613,y:452,t:1527876651082};\\\", \\\"{x:1613,y:448,t:1527876651099};\\\", \\\"{x:1614,y:442,t:1527876651115};\\\", \\\"{x:1615,y:439,t:1527876651132};\\\", \\\"{x:1615,y:438,t:1527876651149};\\\", \\\"{x:1615,y:435,t:1527876651166};\\\", \\\"{x:1615,y:432,t:1527876651181};\\\", \\\"{x:1615,y:431,t:1527876651199};\\\", \\\"{x:1615,y:429,t:1527876651215};\\\", \\\"{x:1615,y:428,t:1527876651236};\\\", \\\"{x:1616,y:428,t:1527876651837};\\\", \\\"{x:1615,y:431,t:1527876651893};\\\", \\\"{x:1614,y:433,t:1527876651901};\\\", \\\"{x:1613,y:440,t:1527876651919};\\\", \\\"{x:1610,y:449,t:1527876651934};\\\", \\\"{x:1606,y:461,t:1527876651949};\\\", \\\"{x:1604,y:471,t:1527876651966};\\\", \\\"{x:1600,y:483,t:1527876651983};\\\", \\\"{x:1596,y:492,t:1527876651999};\\\", \\\"{x:1594,y:505,t:1527876652016};\\\", \\\"{x:1590,y:514,t:1527876652034};\\\", \\\"{x:1589,y:523,t:1527876652049};\\\", \\\"{x:1585,y:535,t:1527876652066};\\\", \\\"{x:1581,y:549,t:1527876652083};\\\", \\\"{x:1577,y:565,t:1527876652100};\\\", \\\"{x:1573,y:585,t:1527876652116};\\\", \\\"{x:1570,y:597,t:1527876652133};\\\", \\\"{x:1564,y:612,t:1527876652150};\\\", \\\"{x:1559,y:624,t:1527876652166};\\\", \\\"{x:1551,y:637,t:1527876652183};\\\", \\\"{x:1545,y:646,t:1527876652200};\\\", \\\"{x:1541,y:651,t:1527876652216};\\\", \\\"{x:1540,y:654,t:1527876652234};\\\", \\\"{x:1538,y:654,t:1527876652251};\\\", \\\"{x:1537,y:654,t:1527876652349};\\\", \\\"{x:1536,y:654,t:1527876652363};\\\", \\\"{x:1534,y:653,t:1527876652366};\\\", \\\"{x:1533,y:651,t:1527876652383};\\\", \\\"{x:1532,y:649,t:1527876652400};\\\", \\\"{x:1530,y:646,t:1527876652416};\\\", \\\"{x:1527,y:643,t:1527876652433};\\\", \\\"{x:1526,y:642,t:1527876652450};\\\", \\\"{x:1525,y:641,t:1527876652466};\\\", \\\"{x:1524,y:640,t:1527876652484};\\\", \\\"{x:1524,y:639,t:1527876652532};\\\", \\\"{x:1523,y:639,t:1527876652541};\\\", \\\"{x:1522,y:637,t:1527876652550};\\\", \\\"{x:1521,y:637,t:1527876652567};\\\", \\\"{x:1521,y:636,t:1527876652584};\\\", \\\"{x:1519,y:636,t:1527876652601};\\\", \\\"{x:1518,y:634,t:1527876652620};\\\", \\\"{x:1517,y:634,t:1527876652650};\\\", \\\"{x:1516,y:633,t:1527876652667};\\\", \\\"{x:1516,y:632,t:1527876652683};\\\", \\\"{x:1515,y:631,t:1527876652700};\\\", \\\"{x:1513,y:630,t:1527876652717};\\\", \\\"{x:1512,y:629,t:1527876652733};\\\", \\\"{x:1511,y:628,t:1527876652751};\\\", \\\"{x:1506,y:635,t:1527876655512};\\\", \\\"{x:1496,y:645,t:1527876655519};\\\", \\\"{x:1434,y:676,t:1527876655536};\\\", \\\"{x:1323,y:709,t:1527876655553};\\\", \\\"{x:1180,y:746,t:1527876655569};\\\", \\\"{x:1003,y:771,t:1527876655585};\\\", \\\"{x:785,y:791,t:1527876655602};\\\", \\\"{x:560,y:808,t:1527876655619};\\\", \\\"{x:356,y:810,t:1527876655636};\\\", \\\"{x:145,y:810,t:1527876655652};\\\", \\\"{x:58,y:804,t:1527876655669};\\\", \\\"{x:9,y:794,t:1527876655686};\\\", \\\"{x:0,y:787,t:1527876655703};\\\", \\\"{x:0,y:782,t:1527876655719};\\\", \\\"{x:0,y:776,t:1527876655736};\\\", \\\"{x:0,y:769,t:1527876655753};\\\", \\\"{x:0,y:761,t:1527876655769};\\\", \\\"{x:0,y:755,t:1527876655787};\\\", \\\"{x:0,y:743,t:1527876655803};\\\", \\\"{x:7,y:726,t:1527876655820};\\\", \\\"{x:49,y:673,t:1527876655838};\\\", \\\"{x:110,y:622,t:1527876655853};\\\", \\\"{x:187,y:572,t:1527876655869};\\\", \\\"{x:261,y:528,t:1527876655887};\\\", \\\"{x:302,y:512,t:1527876655904};\\\", \\\"{x:328,y:502,t:1527876655920};\\\", \\\"{x:341,y:500,t:1527876655937};\\\", \\\"{x:342,y:501,t:1527876656068};\\\", \\\"{x:342,y:506,t:1527876656076};\\\", \\\"{x:342,y:513,t:1527876656086};\\\", \\\"{x:346,y:534,t:1527876656104};\\\", \\\"{x:353,y:552,t:1527876656120};\\\", \\\"{x:357,y:562,t:1527876656136};\\\", \\\"{x:359,y:567,t:1527876656153};\\\", \\\"{x:361,y:572,t:1527876656170};\\\", \\\"{x:362,y:579,t:1527876656187};\\\", \\\"{x:366,y:590,t:1527876656204};\\\", \\\"{x:371,y:608,t:1527876656220};\\\", \\\"{x:375,y:628,t:1527876656237};\\\", \\\"{x:380,y:636,t:1527876656253};\\\", \\\"{x:382,y:641,t:1527876656269};\\\", \\\"{x:385,y:644,t:1527876656286};\\\", \\\"{x:388,y:647,t:1527876656304};\\\", \\\"{x:395,y:651,t:1527876656320};\\\", \\\"{x:407,y:656,t:1527876656337};\\\", \\\"{x:436,y:662,t:1527876656353};\\\", \\\"{x:479,y:662,t:1527876656370};\\\", \\\"{x:534,y:662,t:1527876656387};\\\", \\\"{x:582,y:662,t:1527876656403};\\\", \\\"{x:609,y:662,t:1527876656420};\\\", \\\"{x:621,y:662,t:1527876656436};\\\", \\\"{x:614,y:662,t:1527876656549};\\\", \\\"{x:602,y:662,t:1527876656556};\\\", \\\"{x:582,y:662,t:1527876656571};\\\", \\\"{x:537,y:662,t:1527876656586};\\\", \\\"{x:492,y:662,t:1527876656604};\\\", \\\"{x:429,y:657,t:1527876656620};\\\", \\\"{x:403,y:652,t:1527876656637};\\\", \\\"{x:393,y:651,t:1527876656653};\\\", \\\"{x:392,y:650,t:1527876656709};\\\", \\\"{x:392,y:649,t:1527876656733};\\\", \\\"{x:391,y:649,t:1527876656741};\\\", \\\"{x:390,y:649,t:1527876656757};\\\", \\\"{x:390,y:648,t:1527876656772};\\\", \\\"{x:389,y:648,t:1527876656787};\\\", \\\"{x:388,y:646,t:1527876656804};\\\", \\\"{x:387,y:646,t:1527876656852};\\\", \\\"{x:387,y:643,t:1527876656868};\\\", \\\"{x:388,y:639,t:1527876656887};\\\", \\\"{x:388,y:637,t:1527876656903};\\\", \\\"{x:388,y:635,t:1527876656920};\\\", \\\"{x:388,y:634,t:1527876656956};\\\", \\\"{x:394,y:633,t:1527876657925};\\\", \\\"{x:401,y:633,t:1527876657938};\\\", \\\"{x:424,y:634,t:1527876657955};\\\", \\\"{x:451,y:638,t:1527876657971};\\\", \\\"{x:505,y:640,t:1527876657988};\\\", \\\"{x:660,y:640,t:1527876658004};\\\", \\\"{x:807,y:640,t:1527876658022};\\\", \\\"{x:984,y:642,t:1527876658038};\\\", \\\"{x:1149,y:625,t:1527876658054};\\\", \\\"{x:1301,y:604,t:1527876658071};\\\", \\\"{x:1412,y:587,t:1527876658088};\\\", \\\"{x:1470,y:575,t:1527876658104};\\\", \\\"{x:1491,y:569,t:1527876658121};\\\", \\\"{x:1496,y:568,t:1527876658139};\\\", \\\"{x:1497,y:568,t:1527876658181};\\\", \\\"{x:1499,y:566,t:1527876658189};\\\", \\\"{x:1507,y:566,t:1527876658205};\\\", \\\"{x:1521,y:564,t:1527876658222};\\\", \\\"{x:1535,y:561,t:1527876658239};\\\", \\\"{x:1548,y:560,t:1527876658255};\\\", \\\"{x:1557,y:558,t:1527876658272};\\\", \\\"{x:1565,y:555,t:1527876658290};\\\", \\\"{x:1574,y:549,t:1527876658305};\\\", \\\"{x:1587,y:542,t:1527876658322};\\\", \\\"{x:1611,y:524,t:1527876658339};\\\", \\\"{x:1631,y:509,t:1527876658355};\\\", \\\"{x:1644,y:496,t:1527876658372};\\\", \\\"{x:1647,y:486,t:1527876658389};\\\", \\\"{x:1647,y:479,t:1527876658405};\\\", \\\"{x:1644,y:473,t:1527876658422};\\\", \\\"{x:1641,y:468,t:1527876658439};\\\", \\\"{x:1639,y:463,t:1527876658456};\\\", \\\"{x:1639,y:459,t:1527876658472};\\\", \\\"{x:1638,y:450,t:1527876658491};\\\", \\\"{x:1637,y:439,t:1527876658505};\\\", \\\"{x:1634,y:427,t:1527876658522};\\\", \\\"{x:1632,y:417,t:1527876658540};\\\", \\\"{x:1628,y:408,t:1527876658555};\\\", \\\"{x:1625,y:400,t:1527876658572};\\\", \\\"{x:1622,y:394,t:1527876658588};\\\", \\\"{x:1621,y:392,t:1527876658606};\\\", \\\"{x:1619,y:392,t:1527876658686};\\\", \\\"{x:1617,y:393,t:1527876658693};\\\", \\\"{x:1614,y:395,t:1527876658706};\\\", \\\"{x:1607,y:403,t:1527876658722};\\\", \\\"{x:1603,y:411,t:1527876658739};\\\", \\\"{x:1602,y:419,t:1527876658755};\\\", \\\"{x:1600,y:424,t:1527876658772};\\\", \\\"{x:1600,y:427,t:1527876658788};\\\", \\\"{x:1600,y:428,t:1527876658805};\\\", \\\"{x:1602,y:429,t:1527876659461};\\\", \\\"{x:1603,y:429,t:1527876659473};\\\", \\\"{x:1607,y:430,t:1527876659490};\\\", \\\"{x:1616,y:430,t:1527876659509};\\\", \\\"{x:1637,y:430,t:1527876659541};\\\", \\\"{x:1642,y:430,t:1527876659556};\\\", \\\"{x:1644,y:429,t:1527876659572};\\\", \\\"{x:1642,y:429,t:1527876659708};\\\", \\\"{x:1640,y:429,t:1527876659723};\\\", \\\"{x:1634,y:430,t:1527876659740};\\\", \\\"{x:1632,y:432,t:1527876659756};\\\", \\\"{x:1631,y:433,t:1527876659773};\\\", \\\"{x:1630,y:433,t:1527876659821};\\\", \\\"{x:1629,y:433,t:1527876659908};\\\", \\\"{x:1628,y:433,t:1527876659922};\\\", \\\"{x:1627,y:433,t:1527876659940};\\\", \\\"{x:1623,y:433,t:1527876659957};\\\", \\\"{x:1620,y:433,t:1527876659972};\\\", \\\"{x:1619,y:433,t:1527876660054};\\\", \\\"{x:1617,y:434,t:1527876660072};\\\", \\\"{x:1613,y:432,t:1527876662493};\\\", \\\"{x:1605,y:427,t:1527876662503};\\\", \\\"{x:1588,y:416,t:1527876662517};\\\", \\\"{x:1570,y:399,t:1527876662534};\\\", \\\"{x:1545,y:367,t:1527876662559};\\\", \\\"{x:1524,y:332,t:1527876662575};\\\", \\\"{x:1492,y:279,t:1527876662592};\\\", \\\"{x:1473,y:215,t:1527876662608};\\\", \\\"{x:1460,y:163,t:1527876662625};\\\", \\\"{x:1458,y:135,t:1527876662642};\\\", \\\"{x:1453,y:117,t:1527876662658};\\\", \\\"{x:1452,y:108,t:1527876662675};\\\", \\\"{x:1449,y:102,t:1527876662691};\\\", \\\"{x:1448,y:100,t:1527876662709};\\\", \\\"{x:1449,y:101,t:1527876662821};\\\", \\\"{x:1453,y:106,t:1527876662828};\\\", \\\"{x:1457,y:111,t:1527876662842};\\\", \\\"{x:1467,y:126,t:1527876662859};\\\", \\\"{x:1475,y:138,t:1527876662876};\\\", \\\"{x:1482,y:147,t:1527876662893};\\\", \\\"{x:1485,y:154,t:1527876662909};\\\", \\\"{x:1485,y:155,t:1527876662933};\\\", \\\"{x:1485,y:156,t:1527876662989};\\\", \\\"{x:1485,y:157,t:1527876662997};\\\", \\\"{x:1485,y:158,t:1527876663110};\\\", \\\"{x:1484,y:159,t:1527876663136};\\\", \\\"{x:1483,y:159,t:1527876663172};\\\", \\\"{x:1483,y:160,t:1527876663180};\\\", \\\"{x:1482,y:160,t:1527876663196};\\\", \\\"{x:1481,y:161,t:1527876663212};\\\", \\\"{x:1480,y:162,t:1527876663228};\\\", \\\"{x:1479,y:163,t:1527876663260};\\\", \\\"{x:1478,y:164,t:1527876663284};\\\", \\\"{x:1478,y:165,t:1527876663316};\\\", \\\"{x:1478,y:166,t:1527876663326};\\\", \\\"{x:1477,y:166,t:1527876663405};\\\", \\\"{x:1477,y:168,t:1527876664256};\\\", \\\"{x:1477,y:173,t:1527876664275};\\\", \\\"{x:1480,y:180,t:1527876664293};\\\", \\\"{x:1484,y:187,t:1527876664309};\\\", \\\"{x:1487,y:194,t:1527876664327};\\\", \\\"{x:1492,y:205,t:1527876664342};\\\", \\\"{x:1499,y:216,t:1527876664360};\\\", \\\"{x:1504,y:228,t:1527876664377};\\\", \\\"{x:1510,y:242,t:1527876664392};\\\", \\\"{x:1519,y:261,t:1527876664410};\\\", \\\"{x:1534,y:284,t:1527876664427};\\\", \\\"{x:1553,y:305,t:1527876664442};\\\", \\\"{x:1573,y:330,t:1527876664461};\\\", \\\"{x:1582,y:345,t:1527876664476};\\\", \\\"{x:1592,y:360,t:1527876664493};\\\", \\\"{x:1602,y:379,t:1527876664510};\\\", \\\"{x:1609,y:395,t:1527876664527};\\\", \\\"{x:1619,y:411,t:1527876664543};\\\", \\\"{x:1624,y:425,t:1527876664560};\\\", \\\"{x:1628,y:435,t:1527876664577};\\\", \\\"{x:1629,y:441,t:1527876664593};\\\", \\\"{x:1629,y:447,t:1527876664610};\\\", \\\"{x:1629,y:453,t:1527876664627};\\\", \\\"{x:1629,y:457,t:1527876664643};\\\", \\\"{x:1629,y:463,t:1527876664660};\\\", \\\"{x:1628,y:477,t:1527876664677};\\\", \\\"{x:1627,y:487,t:1527876664694};\\\", \\\"{x:1627,y:495,t:1527876664711};\\\", \\\"{x:1626,y:500,t:1527876664727};\\\", \\\"{x:1626,y:504,t:1527876664744};\\\", \\\"{x:1624,y:513,t:1527876664760};\\\", \\\"{x:1623,y:526,t:1527876664778};\\\", \\\"{x:1620,y:537,t:1527876664794};\\\", \\\"{x:1620,y:544,t:1527876664810};\\\", \\\"{x:1619,y:548,t:1527876664827};\\\", \\\"{x:1619,y:552,t:1527876664844};\\\", \\\"{x:1619,y:555,t:1527876664861};\\\", \\\"{x:1618,y:559,t:1527876664880};\\\", \\\"{x:1618,y:563,t:1527876664894};\\\", \\\"{x:1616,y:567,t:1527876664910};\\\", \\\"{x:1615,y:570,t:1527876664927};\\\", \\\"{x:1614,y:570,t:1527876665150};\\\", \\\"{x:1613,y:569,t:1527876665162};\\\", \\\"{x:1612,y:566,t:1527876665178};\\\", \\\"{x:1612,y:564,t:1527876665194};\\\", \\\"{x:1612,y:563,t:1527876665211};\\\", \\\"{x:1612,y:562,t:1527876665226};\\\", \\\"{x:1612,y:561,t:1527876665244};\\\", \\\"{x:1612,y:560,t:1527876665589};\\\", \\\"{x:1612,y:558,t:1527876665613};\\\", \\\"{x:1612,y:557,t:1527876665631};\\\", \\\"{x:1612,y:556,t:1527876665740};\\\", \\\"{x:1612,y:555,t:1527876665772};\\\", \\\"{x:1611,y:554,t:1527876665957};\\\", \\\"{x:1606,y:555,t:1527876665966};\\\", \\\"{x:1587,y:560,t:1527876665978};\\\", \\\"{x:1468,y:579,t:1527876665995};\\\", \\\"{x:1261,y:606,t:1527876666011};\\\", \\\"{x:833,y:645,t:1527876666029};\\\", \\\"{x:526,y:667,t:1527876666045};\\\", \\\"{x:251,y:686,t:1527876666062};\\\", \\\"{x:44,y:711,t:1527876666078};\\\", \\\"{x:0,y:730,t:1527876666095};\\\", \\\"{x:0,y:741,t:1527876666111};\\\", \\\"{x:0,y:744,t:1527876666128};\\\", \\\"{x:2,y:748,t:1527876666145};\\\", \\\"{x:19,y:761,t:1527876666161};\\\", \\\"{x:64,y:792,t:1527876666177};\\\", \\\"{x:133,y:835,t:1527876666195};\\\", \\\"{x:222,y:878,t:1527876666210};\\\", \\\"{x:335,y:921,t:1527876666228};\\\", \\\"{x:379,y:931,t:1527876666245};\\\", \\\"{x:418,y:933,t:1527876666261};\\\", \\\"{x:444,y:933,t:1527876666278};\\\", \\\"{x:454,y:926,t:1527876666295};\\\", \\\"{x:458,y:921,t:1527876666311};\\\", \\\"{x:459,y:915,t:1527876666328};\\\", \\\"{x:464,y:908,t:1527876666345};\\\", \\\"{x:473,y:895,t:1527876666362};\\\", \\\"{x:485,y:880,t:1527876666378};\\\", \\\"{x:491,y:861,t:1527876666396};\\\", \\\"{x:495,y:852,t:1527876666413};\\\", \\\"{x:495,y:850,t:1527876666428};\\\", \\\"{x:493,y:841,t:1527876666445};\\\", \\\"{x:489,y:829,t:1527876666462};\\\", \\\"{x:489,y:816,t:1527876666479};\\\", \\\"{x:488,y:808,t:1527876666495};\\\", \\\"{x:488,y:804,t:1527876666511};\\\", \\\"{x:487,y:801,t:1527876666528};\\\", \\\"{x:487,y:796,t:1527876666545};\\\", \\\"{x:487,y:788,t:1527876666562};\\\", \\\"{x:490,y:772,t:1527876666577};\\\", \\\"{x:496,y:754,t:1527876666595};\\\", \\\"{x:502,y:738,t:1527876666612};\\\", \\\"{x:504,y:735,t:1527876666628};\\\", \\\"{x:505,y:734,t:1527876666652};\\\", \\\"{x:504,y:735,t:1527876666837};\\\", \\\"{x:504,y:736,t:1527876666845};\\\", \\\"{x:499,y:739,t:1527876666863};\\\", \\\"{x:497,y:741,t:1527876666879};\\\", \\\"{x:497,y:740,t:1527876667908};\\\", \\\"{x:497,y:739,t:1527876667917};\\\", \\\"{x:497,y:738,t:1527876667940};\\\", \\\"{x:497,y:737,t:1527876668220};\\\", \\\"{x:497,y:736,t:1527876668230};\\\", \\\"{x:497,y:735,t:1527876668246};\\\", \\\"{x:497,y:734,t:1527876668275};\\\", \\\"{x:498,y:731,t:1527876668284};\\\", \\\"{x:498,y:730,t:1527876668308};\\\", \\\"{x:498,y:729,t:1527876668316};\\\", \\\"{x:498,y:728,t:1527876668330};\\\", \\\"{x:498,y:727,t:1527876668348};\\\" ] }, { \\\"rt\\\": 36297, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 7, \\\"time_elapsed\\\": 295004, \\\"internal_node_id\\\": \\\"0.0-5.0-2.0\\\", \\\"subject\\\": \\\"EER58\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 3, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-7-C -C -C -C -C -F -A -C -C -U -F -F -11 AM-11 AM-Z -F -F -C -C -11 AM\\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:498,y:725,t:1527876672357};\\\", \\\"{x:500,y:721,t:1527876672366};\\\", \\\"{x:502,y:708,t:1527876672382};\\\", \\\"{x:507,y:683,t:1527876672399};\\\", \\\"{x:508,y:616,t:1527876672416};\\\", \\\"{x:508,y:571,t:1527876672434};\\\", \\\"{x:510,y:541,t:1527876672450};\\\", \\\"{x:510,y:519,t:1527876672466};\\\", \\\"{x:510,y:506,t:1527876672483};\\\", \\\"{x:510,y:493,t:1527876672499};\\\", \\\"{x:510,y:488,t:1527876672516};\\\", \\\"{x:510,y:489,t:1527876672709};\\\", \\\"{x:512,y:492,t:1527876672716};\\\", \\\"{x:513,y:495,t:1527876672734};\\\", \\\"{x:514,y:498,t:1527876672751};\\\", \\\"{x:516,y:502,t:1527876672767};\\\", \\\"{x:518,y:505,t:1527876672783};\\\", \\\"{x:519,y:507,t:1527876672801};\\\", \\\"{x:520,y:508,t:1527876672818};\\\", \\\"{x:520,y:509,t:1527876672833};\\\", \\\"{x:521,y:512,t:1527876672851};\\\", \\\"{x:523,y:514,t:1527876672867};\\\", \\\"{x:524,y:515,t:1527876672883};\\\", \\\"{x:526,y:518,t:1527876672900};\\\", \\\"{x:528,y:519,t:1527876672918};\\\", \\\"{x:531,y:521,t:1527876672934};\\\", \\\"{x:537,y:522,t:1527876672950};\\\", \\\"{x:551,y:523,t:1527876672968};\\\", \\\"{x:575,y:523,t:1527876672983};\\\", \\\"{x:620,y:523,t:1527876673001};\\\", \\\"{x:684,y:523,t:1527876673017};\\\", \\\"{x:778,y:523,t:1527876673033};\\\", \\\"{x:868,y:520,t:1527876673051};\\\", \\\"{x:965,y:507,t:1527876673067};\\\", \\\"{x:1059,y:495,t:1527876673084};\\\", \\\"{x:1171,y:470,t:1527876673102};\\\", \\\"{x:1229,y:457,t:1527876673118};\\\", \\\"{x:1274,y:451,t:1527876673134};\\\", \\\"{x:1313,y:446,t:1527876673150};\\\", \\\"{x:1353,y:437,t:1527876673168};\\\", \\\"{x:1398,y:425,t:1527876673184};\\\", \\\"{x:1442,y:413,t:1527876673201};\\\", \\\"{x:1486,y:409,t:1527876673218};\\\", \\\"{x:1528,y:404,t:1527876673234};\\\", \\\"{x:1563,y:404,t:1527876673251};\\\", \\\"{x:1595,y:404,t:1527876673267};\\\", \\\"{x:1637,y:404,t:1527876673284};\\\", \\\"{x:1660,y:406,t:1527876673301};\\\", \\\"{x:1669,y:410,t:1527876673318};\\\", \\\"{x:1671,y:410,t:1527876673335};\\\", \\\"{x:1671,y:414,t:1527876673621};\\\", \\\"{x:1672,y:419,t:1527876673635};\\\", \\\"{x:1675,y:439,t:1527876673653};\\\", \\\"{x:1678,y:446,t:1527876673668};\\\", \\\"{x:1682,y:471,t:1527876673685};\\\", \\\"{x:1686,y:491,t:1527876673701};\\\", \\\"{x:1691,y:511,t:1527876673718};\\\", \\\"{x:1694,y:533,t:1527876673734};\\\", \\\"{x:1697,y:553,t:1527876673752};\\\", \\\"{x:1697,y:571,t:1527876673768};\\\", \\\"{x:1698,y:585,t:1527876673785};\\\", \\\"{x:1698,y:598,t:1527876673802};\\\", \\\"{x:1698,y:607,t:1527876673818};\\\", \\\"{x:1699,y:615,t:1527876673835};\\\", \\\"{x:1699,y:619,t:1527876673852};\\\", \\\"{x:1701,y:622,t:1527876673867};\\\", \\\"{x:1701,y:627,t:1527876673885};\\\", \\\"{x:1701,y:628,t:1527876673901};\\\", \\\"{x:1701,y:629,t:1527876673918};\\\", \\\"{x:1702,y:630,t:1527876673935};\\\", \\\"{x:1703,y:630,t:1527876673951};\\\", \\\"{x:1705,y:632,t:1527876673968};\\\", \\\"{x:1713,y:634,t:1527876673985};\\\", \\\"{x:1733,y:638,t:1527876674002};\\\", \\\"{x:1762,y:642,t:1527876674019};\\\", \\\"{x:1800,y:642,t:1527876674035};\\\", \\\"{x:1834,y:642,t:1527876674052};\\\", \\\"{x:1862,y:643,t:1527876674068};\\\", \\\"{x:1884,y:647,t:1527876674085};\\\", \\\"{x:1887,y:648,t:1527876674102};\\\", \\\"{x:1888,y:651,t:1527876674119};\\\", \\\"{x:1888,y:658,t:1527876674134};\\\", \\\"{x:1884,y:668,t:1527876674153};\\\", \\\"{x:1867,y:684,t:1527876674168};\\\", \\\"{x:1849,y:697,t:1527876674184};\\\", \\\"{x:1819,y:718,t:1527876674201};\\\", \\\"{x:1782,y:745,t:1527876674218};\\\", \\\"{x:1737,y:767,t:1527876674235};\\\", \\\"{x:1683,y:784,t:1527876674251};\\\", \\\"{x:1578,y:802,t:1527876674267};\\\", \\\"{x:1503,y:802,t:1527876674284};\\\", \\\"{x:1433,y:802,t:1527876674302};\\\", \\\"{x:1380,y:802,t:1527876674318};\\\", \\\"{x:1332,y:802,t:1527876674334};\\\", \\\"{x:1298,y:802,t:1527876674352};\\\", \\\"{x:1272,y:802,t:1527876674369};\\\", \\\"{x:1257,y:802,t:1527876674384};\\\", \\\"{x:1247,y:803,t:1527876674402};\\\", \\\"{x:1243,y:803,t:1527876674419};\\\", \\\"{x:1239,y:803,t:1527876674435};\\\", \\\"{x:1236,y:803,t:1527876674452};\\\", \\\"{x:1229,y:806,t:1527876674468};\\\", \\\"{x:1228,y:806,t:1527876674485};\\\", \\\"{x:1228,y:808,t:1527876674502};\\\", \\\"{x:1228,y:809,t:1527876674519};\\\", \\\"{x:1227,y:809,t:1527876674535};\\\", \\\"{x:1227,y:810,t:1527876674552};\\\", \\\"{x:1227,y:812,t:1527876674568};\\\", \\\"{x:1227,y:815,t:1527876674586};\\\", \\\"{x:1227,y:820,t:1527876674602};\\\", \\\"{x:1227,y:822,t:1527876674619};\\\", \\\"{x:1227,y:823,t:1527876674636};\\\", \\\"{x:1227,y:824,t:1527876674652};\\\", \\\"{x:1227,y:825,t:1527876674676};\\\", \\\"{x:1227,y:827,t:1527876674693};\\\", \\\"{x:1226,y:828,t:1527876674702};\\\", \\\"{x:1225,y:830,t:1527876674719};\\\", \\\"{x:1223,y:832,t:1527876674736};\\\", \\\"{x:1221,y:832,t:1527876674752};\\\", \\\"{x:1220,y:832,t:1527876674769};\\\", \\\"{x:1218,y:832,t:1527876674791};\\\", \\\"{x:1217,y:832,t:1527876674801};\\\", \\\"{x:1215,y:832,t:1527876674859};\\\", \\\"{x:1214,y:832,t:1527876674876};\\\", \\\"{x:1213,y:832,t:1527876674886};\\\", \\\"{x:1209,y:831,t:1527876674902};\\\", \\\"{x:1206,y:828,t:1527876674919};\\\", \\\"{x:1206,y:827,t:1527876674940};\\\", \\\"{x:1206,y:826,t:1527876675134};\\\", \\\"{x:1208,y:826,t:1527876675164};\\\", \\\"{x:1209,y:826,t:1527876675180};\\\", \\\"{x:1211,y:827,t:1527876675376};\\\", \\\"{x:1212,y:828,t:1527876675385};\\\", \\\"{x:1214,y:829,t:1527876675402};\\\", \\\"{x:1215,y:829,t:1527876675418};\\\", \\\"{x:1216,y:829,t:1527876675435};\\\", \\\"{x:1215,y:829,t:1527876676836};\\\", \\\"{x:1213,y:829,t:1527876676964};\\\", \\\"{x:1211,y:831,t:1527876677076};\\\", \\\"{x:1211,y:834,t:1527876677091};\\\", \\\"{x:1210,y:837,t:1527876677148};\\\", \\\"{x:1210,y:838,t:1527876677340};\\\", \\\"{x:1210,y:840,t:1527876677353};\\\", \\\"{x:1211,y:842,t:1527876677370};\\\", \\\"{x:1213,y:844,t:1527876677388};\\\", \\\"{x:1214,y:844,t:1527876677565};\\\", \\\"{x:1214,y:842,t:1527876677605};\\\", \\\"{x:1214,y:840,t:1527876677621};\\\", \\\"{x:1214,y:837,t:1527876677638};\\\", \\\"{x:1212,y:831,t:1527876677656};\\\", \\\"{x:1211,y:828,t:1527876677670};\\\", \\\"{x:1211,y:826,t:1527876677687};\\\", \\\"{x:1211,y:823,t:1527876677705};\\\", \\\"{x:1211,y:821,t:1527876677720};\\\", \\\"{x:1211,y:818,t:1527876677737};\\\", \\\"{x:1211,y:817,t:1527876677754};\\\", \\\"{x:1211,y:816,t:1527876677770};\\\", \\\"{x:1213,y:819,t:1527876677965};\\\", \\\"{x:1214,y:822,t:1527876677972};\\\", \\\"{x:1217,y:826,t:1527876677992};\\\", \\\"{x:1218,y:829,t:1527876678004};\\\", \\\"{x:1219,y:830,t:1527876678021};\\\", \\\"{x:1220,y:831,t:1527876678052};\\\", \\\"{x:1219,y:831,t:1527876678364};\\\", \\\"{x:1219,y:832,t:1527876678500};\\\", \\\"{x:1219,y:838,t:1527876678521};\\\", \\\"{x:1226,y:849,t:1527876678538};\\\", \\\"{x:1232,y:861,t:1527876678554};\\\", \\\"{x:1242,y:875,t:1527876678571};\\\", \\\"{x:1257,y:898,t:1527876678587};\\\", \\\"{x:1266,y:911,t:1527876678604};\\\", \\\"{x:1274,y:922,t:1527876678621};\\\", \\\"{x:1280,y:930,t:1527876678638};\\\", \\\"{x:1286,y:938,t:1527876678654};\\\", \\\"{x:1291,y:945,t:1527876678671};\\\", \\\"{x:1294,y:950,t:1527876678689};\\\", \\\"{x:1296,y:955,t:1527876678704};\\\", \\\"{x:1299,y:959,t:1527876678721};\\\", \\\"{x:1300,y:961,t:1527876678738};\\\", \\\"{x:1300,y:962,t:1527876678901};\\\", \\\"{x:1299,y:962,t:1527876678925};\\\", \\\"{x:1298,y:962,t:1527876678981};\\\", \\\"{x:1297,y:962,t:1527876678997};\\\", \\\"{x:1297,y:963,t:1527876679007};\\\", \\\"{x:1296,y:963,t:1527876679022};\\\", \\\"{x:1295,y:964,t:1527876679039};\\\", \\\"{x:1293,y:965,t:1527876679056};\\\", \\\"{x:1292,y:965,t:1527876679072};\\\", \\\"{x:1290,y:965,t:1527876679089};\\\", \\\"{x:1287,y:967,t:1527876679106};\\\", \\\"{x:1283,y:967,t:1527876679122};\\\", \\\"{x:1280,y:967,t:1527876679139};\\\", \\\"{x:1279,y:967,t:1527876679157};\\\", \\\"{x:1278,y:967,t:1527876679205};\\\", \\\"{x:1277,y:967,t:1527876679236};\\\", \\\"{x:1276,y:967,t:1527876679252};\\\", \\\"{x:1276,y:964,t:1527876679733};\\\", \\\"{x:1277,y:958,t:1527876679741};\\\", \\\"{x:1279,y:949,t:1527876679756};\\\", \\\"{x:1299,y:912,t:1527876679772};\\\", \\\"{x:1313,y:883,t:1527876679789};\\\", \\\"{x:1324,y:862,t:1527876679806};\\\", \\\"{x:1332,y:843,t:1527876679823};\\\", \\\"{x:1336,y:831,t:1527876679839};\\\", \\\"{x:1339,y:822,t:1527876679856};\\\", \\\"{x:1340,y:818,t:1527876679873};\\\", \\\"{x:1340,y:816,t:1527876679889};\\\", \\\"{x:1340,y:814,t:1527876679907};\\\", \\\"{x:1340,y:813,t:1527876679925};\\\", \\\"{x:1340,y:812,t:1527876680005};\\\", \\\"{x:1344,y:807,t:1527876680023};\\\", \\\"{x:1347,y:804,t:1527876680040};\\\", \\\"{x:1351,y:798,t:1527876680056};\\\", \\\"{x:1354,y:793,t:1527876680073};\\\", \\\"{x:1357,y:789,t:1527876680090};\\\", \\\"{x:1361,y:783,t:1527876680106};\\\", \\\"{x:1365,y:778,t:1527876680123};\\\", \\\"{x:1368,y:774,t:1527876680140};\\\", \\\"{x:1372,y:769,t:1527876680157};\\\", \\\"{x:1375,y:766,t:1527876680173};\\\", \\\"{x:1375,y:765,t:1527876680309};\\\", \\\"{x:1375,y:764,t:1527876680501};\\\", \\\"{x:1377,y:764,t:1527876680531};\\\", \\\"{x:1378,y:764,t:1527876680604};\\\", \\\"{x:1378,y:763,t:1527876680612};\\\", \\\"{x:1379,y:763,t:1527876680643};\\\", \\\"{x:1380,y:763,t:1527876680676};\\\", \\\"{x:1381,y:763,t:1527876680700};\\\", \\\"{x:1382,y:763,t:1527876680740};\\\", \\\"{x:1383,y:762,t:1527876680756};\\\", \\\"{x:1383,y:765,t:1527876682581};\\\", \\\"{x:1367,y:789,t:1527876682609};\\\", \\\"{x:1357,y:804,t:1527876682624};\\\", \\\"{x:1353,y:812,t:1527876682642};\\\", \\\"{x:1351,y:814,t:1527876682657};\\\", \\\"{x:1350,y:815,t:1527876682675};\\\", \\\"{x:1348,y:816,t:1527876682691};\\\", \\\"{x:1345,y:818,t:1527876682707};\\\", \\\"{x:1339,y:820,t:1527876682725};\\\", \\\"{x:1322,y:824,t:1527876682742};\\\", \\\"{x:1302,y:827,t:1527876682759};\\\", \\\"{x:1279,y:828,t:1527876682776};\\\", \\\"{x:1259,y:829,t:1527876682792};\\\", \\\"{x:1241,y:829,t:1527876682808};\\\", \\\"{x:1227,y:829,t:1527876682824};\\\", \\\"{x:1217,y:827,t:1527876682843};\\\", \\\"{x:1209,y:824,t:1527876682859};\\\", \\\"{x:1200,y:821,t:1527876682875};\\\", \\\"{x:1177,y:817,t:1527876682892};\\\", \\\"{x:1165,y:817,t:1527876682908};\\\", \\\"{x:1157,y:817,t:1527876682925};\\\", \\\"{x:1156,y:817,t:1527876682948};\\\", \\\"{x:1157,y:817,t:1527876683060};\\\", \\\"{x:1159,y:818,t:1527876683076};\\\", \\\"{x:1167,y:820,t:1527876683092};\\\", \\\"{x:1170,y:820,t:1527876683108};\\\", \\\"{x:1172,y:820,t:1527876683125};\\\", \\\"{x:1173,y:820,t:1527876683142};\\\", \\\"{x:1174,y:820,t:1527876683160};\\\", \\\"{x:1175,y:820,t:1527876683189};\\\", \\\"{x:1176,y:820,t:1527876683197};\\\", \\\"{x:1177,y:820,t:1527876683209};\\\", \\\"{x:1179,y:820,t:1527876683225};\\\", \\\"{x:1180,y:820,t:1527876683242};\\\", \\\"{x:1182,y:820,t:1527876683259};\\\", \\\"{x:1187,y:820,t:1527876683276};\\\", \\\"{x:1191,y:822,t:1527876683292};\\\", \\\"{x:1198,y:825,t:1527876683309};\\\", \\\"{x:1201,y:826,t:1527876683325};\\\", \\\"{x:1202,y:826,t:1527876683348};\\\", \\\"{x:1203,y:826,t:1527876683421};\\\", \\\"{x:1205,y:827,t:1527876683645};\\\", \\\"{x:1206,y:827,t:1527876683669};\\\", \\\"{x:1207,y:829,t:1527876683685};\\\", \\\"{x:1207,y:830,t:1527876683701};\\\", \\\"{x:1209,y:832,t:1527876683712};\\\", \\\"{x:1212,y:833,t:1527876683724};\\\", \\\"{x:1213,y:833,t:1527876683742};\\\", \\\"{x:1223,y:832,t:1527876687496};\\\", \\\"{x:1254,y:826,t:1527876687513};\\\", \\\"{x:1321,y:825,t:1527876687529};\\\", \\\"{x:1410,y:825,t:1527876687545};\\\", \\\"{x:1482,y:825,t:1527876687563};\\\", \\\"{x:1541,y:825,t:1527876687579};\\\", \\\"{x:1571,y:823,t:1527876687595};\\\", \\\"{x:1572,y:821,t:1527876687692};\\\", \\\"{x:1569,y:819,t:1527876687700};\\\", \\\"{x:1563,y:817,t:1527876687712};\\\", \\\"{x:1549,y:812,t:1527876687729};\\\", \\\"{x:1525,y:805,t:1527876687746};\\\", \\\"{x:1484,y:799,t:1527876687762};\\\", \\\"{x:1448,y:795,t:1527876687779};\\\", \\\"{x:1381,y:784,t:1527876687795};\\\", \\\"{x:1344,y:779,t:1527876687812};\\\", \\\"{x:1324,y:773,t:1527876687829};\\\", \\\"{x:1318,y:772,t:1527876687846};\\\", \\\"{x:1315,y:771,t:1527876687863};\\\", \\\"{x:1315,y:770,t:1527876687989};\\\", \\\"{x:1316,y:770,t:1527876687996};\\\", \\\"{x:1318,y:770,t:1527876688013};\\\", \\\"{x:1323,y:769,t:1527876688029};\\\", \\\"{x:1329,y:768,t:1527876688046};\\\", \\\"{x:1332,y:765,t:1527876688063};\\\", \\\"{x:1334,y:765,t:1527876688080};\\\", \\\"{x:1336,y:765,t:1527876688096};\\\", \\\"{x:1337,y:765,t:1527876688117};\\\", \\\"{x:1339,y:765,t:1527876688129};\\\", \\\"{x:1344,y:765,t:1527876688146};\\\", \\\"{x:1350,y:765,t:1527876688163};\\\", \\\"{x:1354,y:765,t:1527876688179};\\\", \\\"{x:1358,y:765,t:1527876688196};\\\", \\\"{x:1362,y:764,t:1527876688213};\\\", \\\"{x:1364,y:764,t:1527876688229};\\\", \\\"{x:1366,y:763,t:1527876688246};\\\", \\\"{x:1367,y:763,t:1527876688263};\\\", \\\"{x:1370,y:762,t:1527876688280};\\\", \\\"{x:1371,y:762,t:1527876688295};\\\", \\\"{x:1373,y:762,t:1527876688312};\\\", \\\"{x:1374,y:762,t:1527876688381};\\\", \\\"{x:1376,y:762,t:1527876688407};\\\", \\\"{x:1377,y:762,t:1527876688430};\\\", \\\"{x:1379,y:762,t:1527876688446};\\\", \\\"{x:1380,y:761,t:1527876688463};\\\", \\\"{x:1382,y:759,t:1527876688480};\\\", \\\"{x:1384,y:758,t:1527876688496};\\\", \\\"{x:1385,y:756,t:1527876688517};\\\", \\\"{x:1386,y:756,t:1527876688548};\\\", \\\"{x:1387,y:756,t:1527876688580};\\\", \\\"{x:1388,y:755,t:1527876688596};\\\", \\\"{x:1386,y:755,t:1527876688749};\\\", \\\"{x:1384,y:756,t:1527876688763};\\\", \\\"{x:1381,y:761,t:1527876688784};\\\", \\\"{x:1378,y:763,t:1527876688797};\\\", \\\"{x:1377,y:764,t:1527876688813};\\\", \\\"{x:1377,y:765,t:1527876688830};\\\", \\\"{x:1376,y:765,t:1527876689365};\\\", \\\"{x:1369,y:787,t:1527876689397};\\\", \\\"{x:1364,y:797,t:1527876689413};\\\", \\\"{x:1360,y:808,t:1527876689430};\\\", \\\"{x:1358,y:818,t:1527876689447};\\\", \\\"{x:1354,y:832,t:1527876689464};\\\", \\\"{x:1348,y:849,t:1527876689480};\\\", \\\"{x:1343,y:868,t:1527876689497};\\\", \\\"{x:1334,y:885,t:1527876689514};\\\", \\\"{x:1332,y:893,t:1527876689530};\\\", \\\"{x:1330,y:897,t:1527876689547};\\\", \\\"{x:1330,y:899,t:1527876689564};\\\", \\\"{x:1329,y:899,t:1527876689581};\\\", \\\"{x:1329,y:900,t:1527876689597};\\\", \\\"{x:1329,y:901,t:1527876689615};\\\", \\\"{x:1328,y:902,t:1527876689632};\\\", \\\"{x:1328,y:903,t:1527876689733};\\\", \\\"{x:1327,y:904,t:1527876689748};\\\", \\\"{x:1324,y:907,t:1527876689765};\\\", \\\"{x:1323,y:909,t:1527876689781};\\\", \\\"{x:1319,y:916,t:1527876689797};\\\", \\\"{x:1315,y:921,t:1527876689814};\\\", \\\"{x:1311,y:928,t:1527876689832};\\\", \\\"{x:1308,y:932,t:1527876689847};\\\", \\\"{x:1307,y:933,t:1527876689865};\\\", \\\"{x:1306,y:936,t:1527876689882};\\\", \\\"{x:1304,y:938,t:1527876689898};\\\", \\\"{x:1303,y:939,t:1527876689915};\\\", \\\"{x:1301,y:943,t:1527876689932};\\\", \\\"{x:1298,y:947,t:1527876689947};\\\", \\\"{x:1295,y:955,t:1527876689965};\\\", \\\"{x:1293,y:963,t:1527876689982};\\\", \\\"{x:1288,y:970,t:1527876689998};\\\", \\\"{x:1284,y:976,t:1527876690015};\\\", \\\"{x:1278,y:984,t:1527876690031};\\\", \\\"{x:1276,y:986,t:1527876690048};\\\", \\\"{x:1276,y:985,t:1527876690757};\\\", \\\"{x:1276,y:984,t:1527876690765};\\\", \\\"{x:1276,y:983,t:1527876690803};\\\", \\\"{x:1276,y:982,t:1527876690852};\\\", \\\"{x:1277,y:982,t:1527876690865};\\\", \\\"{x:1278,y:981,t:1527876690881};\\\", \\\"{x:1280,y:978,t:1527876690898};\\\", \\\"{x:1281,y:976,t:1527876690915};\\\", \\\"{x:1283,y:973,t:1527876690931};\\\", \\\"{x:1288,y:965,t:1527876690948};\\\", \\\"{x:1293,y:955,t:1527876690965};\\\", \\\"{x:1305,y:939,t:1527876690981};\\\", \\\"{x:1318,y:925,t:1527876690998};\\\", \\\"{x:1333,y:913,t:1527876691016};\\\", \\\"{x:1342,y:903,t:1527876691032};\\\", \\\"{x:1351,y:895,t:1527876691050};\\\", \\\"{x:1353,y:893,t:1527876691066};\\\", \\\"{x:1355,y:891,t:1527876691081};\\\", \\\"{x:1355,y:890,t:1527876691098};\\\", \\\"{x:1356,y:887,t:1527876691115};\\\", \\\"{x:1358,y:884,t:1527876691131};\\\", \\\"{x:1359,y:881,t:1527876691148};\\\", \\\"{x:1360,y:879,t:1527876691165};\\\", \\\"{x:1360,y:877,t:1527876691182};\\\", \\\"{x:1360,y:875,t:1527876691198};\\\", \\\"{x:1360,y:874,t:1527876691214};\\\", \\\"{x:1360,y:872,t:1527876691232};\\\", \\\"{x:1362,y:869,t:1527876691248};\\\", \\\"{x:1362,y:864,t:1527876691265};\\\", \\\"{x:1363,y:858,t:1527876691282};\\\", \\\"{x:1364,y:853,t:1527876691299};\\\", \\\"{x:1366,y:846,t:1527876691315};\\\", \\\"{x:1369,y:840,t:1527876691332};\\\", \\\"{x:1369,y:835,t:1527876691349};\\\", \\\"{x:1374,y:826,t:1527876691365};\\\", \\\"{x:1378,y:817,t:1527876691382};\\\", \\\"{x:1383,y:810,t:1527876691399};\\\", \\\"{x:1387,y:803,t:1527876691415};\\\", \\\"{x:1390,y:799,t:1527876691432};\\\", \\\"{x:1391,y:795,t:1527876691449};\\\", \\\"{x:1395,y:785,t:1527876691465};\\\", \\\"{x:1398,y:772,t:1527876691482};\\\", \\\"{x:1400,y:758,t:1527876691499};\\\", \\\"{x:1401,y:750,t:1527876691515};\\\", \\\"{x:1401,y:745,t:1527876691532};\\\", \\\"{x:1401,y:744,t:1527876691550};\\\", \\\"{x:1401,y:743,t:1527876691653};\\\", \\\"{x:1399,y:743,t:1527876691666};\\\", \\\"{x:1394,y:745,t:1527876691682};\\\", \\\"{x:1389,y:751,t:1527876691700};\\\", \\\"{x:1384,y:755,t:1527876691715};\\\", \\\"{x:1380,y:761,t:1527876691734};\\\", \\\"{x:1387,y:758,t:1527876693015};\\\", \\\"{x:1398,y:738,t:1527876693033};\\\", \\\"{x:1409,y:719,t:1527876693050};\\\", \\\"{x:1420,y:697,t:1527876693066};\\\", \\\"{x:1430,y:674,t:1527876693083};\\\", \\\"{x:1438,y:628,t:1527876693100};\\\", \\\"{x:1442,y:598,t:1527876693116};\\\", \\\"{x:1446,y:570,t:1527876693133};\\\", \\\"{x:1448,y:547,t:1527876693150};\\\", \\\"{x:1452,y:528,t:1527876693167};\\\", \\\"{x:1457,y:513,t:1527876693183};\\\", \\\"{x:1458,y:505,t:1527876693200};\\\", \\\"{x:1462,y:496,t:1527876693217};\\\", \\\"{x:1464,y:487,t:1527876693235};\\\", \\\"{x:1468,y:475,t:1527876693251};\\\", \\\"{x:1474,y:461,t:1527876693268};\\\", \\\"{x:1486,y:444,t:1527876693283};\\\", \\\"{x:1504,y:425,t:1527876693300};\\\", \\\"{x:1514,y:418,t:1527876693318};\\\", \\\"{x:1525,y:407,t:1527876693334};\\\", \\\"{x:1535,y:401,t:1527876693351};\\\", \\\"{x:1542,y:395,t:1527876693367};\\\", \\\"{x:1548,y:391,t:1527876693384};\\\", \\\"{x:1556,y:385,t:1527876693400};\\\", \\\"{x:1563,y:382,t:1527876693418};\\\", \\\"{x:1570,y:377,t:1527876693434};\\\", \\\"{x:1576,y:374,t:1527876693451};\\\", \\\"{x:1577,y:373,t:1527876693468};\\\", \\\"{x:1579,y:372,t:1527876693484};\\\", \\\"{x:1580,y:370,t:1527876693500};\\\", \\\"{x:1582,y:364,t:1527876693518};\\\", \\\"{x:1584,y:362,t:1527876693534};\\\", \\\"{x:1584,y:360,t:1527876693550};\\\", \\\"{x:1585,y:360,t:1527876693568};\\\", \\\"{x:1583,y:361,t:1527876693605};\\\", \\\"{x:1579,y:365,t:1527876693618};\\\", \\\"{x:1573,y:373,t:1527876693634};\\\", \\\"{x:1562,y:391,t:1527876693651};\\\", \\\"{x:1547,y:416,t:1527876693667};\\\", \\\"{x:1535,y:446,t:1527876693683};\\\", \\\"{x:1521,y:501,t:1527876693701};\\\", \\\"{x:1518,y:532,t:1527876693717};\\\", \\\"{x:1514,y:557,t:1527876693734};\\\", \\\"{x:1508,y:578,t:1527876693751};\\\", \\\"{x:1506,y:598,t:1527876693768};\\\", \\\"{x:1501,y:617,t:1527876693785};\\\", \\\"{x:1495,y:632,t:1527876693800};\\\", \\\"{x:1492,y:644,t:1527876693818};\\\", \\\"{x:1487,y:659,t:1527876693835};\\\", \\\"{x:1486,y:674,t:1527876693851};\\\", \\\"{x:1485,y:684,t:1527876693868};\\\", \\\"{x:1482,y:693,t:1527876693885};\\\", \\\"{x:1482,y:695,t:1527876693901};\\\", \\\"{x:1479,y:699,t:1527876693918};\\\", \\\"{x:1477,y:701,t:1527876693934};\\\", \\\"{x:1471,y:705,t:1527876693950};\\\", \\\"{x:1458,y:713,t:1527876693968};\\\", \\\"{x:1446,y:720,t:1527876693984};\\\", \\\"{x:1435,y:727,t:1527876694001};\\\", \\\"{x:1426,y:730,t:1527876694018};\\\", \\\"{x:1420,y:733,t:1527876694035};\\\", \\\"{x:1413,y:738,t:1527876694051};\\\", \\\"{x:1407,y:741,t:1527876694067};\\\", \\\"{x:1398,y:747,t:1527876694084};\\\", \\\"{x:1393,y:752,t:1527876694100};\\\", \\\"{x:1390,y:755,t:1527876694118};\\\", \\\"{x:1389,y:756,t:1527876694135};\\\", \\\"{x:1387,y:757,t:1527876694151};\\\", \\\"{x:1386,y:758,t:1527876694172};\\\", \\\"{x:1384,y:760,t:1527876694192};\\\", \\\"{x:1383,y:760,t:1527876694217};\\\", \\\"{x:1382,y:761,t:1527876694252};\\\", \\\"{x:1381,y:761,t:1527876694588};\\\", \\\"{x:1380,y:761,t:1527876694601};\\\", \\\"{x:1373,y:761,t:1527876694621};\\\", \\\"{x:1351,y:762,t:1527876694635};\\\", \\\"{x:1323,y:764,t:1527876694652};\\\", \\\"{x:1216,y:760,t:1527876694668};\\\", \\\"{x:1105,y:741,t:1527876694684};\\\", \\\"{x:981,y:727,t:1527876694701};\\\", \\\"{x:858,y:708,t:1527876694719};\\\", \\\"{x:736,y:690,t:1527876694735};\\\", \\\"{x:626,y:675,t:1527876694752};\\\", \\\"{x:525,y:656,t:1527876694768};\\\", \\\"{x:436,y:631,t:1527876694785};\\\", \\\"{x:364,y:609,t:1527876694802};\\\", \\\"{x:304,y:588,t:1527876694817};\\\", \\\"{x:245,y:570,t:1527876694836};\\\", \\\"{x:187,y:553,t:1527876694851};\\\", \\\"{x:109,y:531,t:1527876694867};\\\", \\\"{x:69,y:524,t:1527876694885};\\\", \\\"{x:38,y:520,t:1527876694900};\\\", \\\"{x:23,y:517,t:1527876694918};\\\", \\\"{x:22,y:517,t:1527876694935};\\\", \\\"{x:21,y:517,t:1527876694951};\\\", \\\"{x:27,y:520,t:1527876695061};\\\", \\\"{x:38,y:525,t:1527876695068};\\\", \\\"{x:66,y:536,t:1527876695085};\\\", \\\"{x:105,y:549,t:1527876695103};\\\", \\\"{x:144,y:559,t:1527876695118};\\\", \\\"{x:186,y:572,t:1527876695135};\\\", \\\"{x:216,y:582,t:1527876695153};\\\", \\\"{x:242,y:587,t:1527876695168};\\\", \\\"{x:260,y:589,t:1527876695185};\\\", \\\"{x:273,y:590,t:1527876695202};\\\", \\\"{x:281,y:592,t:1527876695218};\\\", \\\"{x:291,y:592,t:1527876695235};\\\", \\\"{x:303,y:592,t:1527876695251};\\\", \\\"{x:305,y:591,t:1527876695268};\\\", \\\"{x:307,y:591,t:1527876695285};\\\", \\\"{x:307,y:590,t:1527876695316};\\\", \\\"{x:309,y:590,t:1527876695324};\\\", \\\"{x:310,y:590,t:1527876695335};\\\", \\\"{x:318,y:589,t:1527876695353};\\\", \\\"{x:326,y:588,t:1527876695368};\\\", \\\"{x:330,y:588,t:1527876695386};\\\", \\\"{x:333,y:588,t:1527876695402};\\\", \\\"{x:334,y:588,t:1527876695420};\\\", \\\"{x:335,y:588,t:1527876695435};\\\", \\\"{x:345,y:590,t:1527876695453};\\\", \\\"{x:354,y:590,t:1527876695468};\\\", \\\"{x:357,y:590,t:1527876695485};\\\", \\\"{x:359,y:591,t:1527876695524};\\\", \\\"{x:361,y:591,t:1527876695539};\\\", \\\"{x:363,y:591,t:1527876695553};\\\", \\\"{x:365,y:593,t:1527876695568};\\\", \\\"{x:368,y:594,t:1527876695585};\\\", \\\"{x:369,y:595,t:1527876695602};\\\", \\\"{x:369,y:596,t:1527876695619};\\\", \\\"{x:373,y:596,t:1527876695940};\\\", \\\"{x:379,y:598,t:1527876695955};\\\", \\\"{x:398,y:609,t:1527876695970};\\\", \\\"{x:439,y:637,t:1527876695987};\\\", \\\"{x:486,y:670,t:1527876696002};\\\", \\\"{x:555,y:711,t:1527876696019};\\\", \\\"{x:622,y:757,t:1527876696036};\\\", \\\"{x:648,y:777,t:1527876696052};\\\", \\\"{x:665,y:792,t:1527876696069};\\\", \\\"{x:672,y:800,t:1527876696086};\\\", \\\"{x:674,y:803,t:1527876696102};\\\", \\\"{x:675,y:804,t:1527876696119};\\\", \\\"{x:671,y:804,t:1527876696220};\\\", \\\"{x:651,y:804,t:1527876696236};\\\", \\\"{x:618,y:796,t:1527876696252};\\\", \\\"{x:574,y:767,t:1527876696269};\\\", \\\"{x:527,y:738,t:1527876696289};\\\", \\\"{x:483,y:712,t:1527876696302};\\\", \\\"{x:458,y:691,t:1527876696319};\\\", \\\"{x:443,y:675,t:1527876696337};\\\", \\\"{x:435,y:660,t:1527876696353};\\\", \\\"{x:431,y:650,t:1527876696369};\\\", \\\"{x:431,y:645,t:1527876696387};\\\", \\\"{x:429,y:642,t:1527876696402};\\\", \\\"{x:428,y:641,t:1527876696419};\\\", \\\"{x:428,y:640,t:1527876696468};\\\", \\\"{x:428,y:639,t:1527876696475};\\\", \\\"{x:428,y:638,t:1527876696508};\\\", \\\"{x:428,y:636,t:1527876696519};\\\", \\\"{x:425,y:632,t:1527876696536};\\\", \\\"{x:417,y:622,t:1527876696553};\\\", \\\"{x:407,y:609,t:1527876696569};\\\", \\\"{x:396,y:597,t:1527876696586};\\\", \\\"{x:389,y:590,t:1527876696604};\\\", \\\"{x:384,y:585,t:1527876696620};\\\", \\\"{x:380,y:582,t:1527876696636};\\\", \\\"{x:379,y:582,t:1527876696676};\\\", \\\"{x:378,y:582,t:1527876696788};\\\", \\\"{x:378,y:584,t:1527876697285};\\\", \\\"{x:382,y:589,t:1527876697304};\\\", \\\"{x:386,y:593,t:1527876697320};\\\", \\\"{x:389,y:599,t:1527876697337};\\\", \\\"{x:391,y:600,t:1527876697354};\\\", \\\"{x:395,y:603,t:1527876698069};\\\", \\\"{x:400,y:605,t:1527876698077};\\\", \\\"{x:407,y:609,t:1527876698087};\\\", \\\"{x:425,y:621,t:1527876698105};\\\", \\\"{x:455,y:643,t:1527876698120};\\\", \\\"{x:491,y:668,t:1527876698137};\\\", \\\"{x:537,y:694,t:1527876698155};\\\", \\\"{x:585,y:725,t:1527876698171};\\\", \\\"{x:594,y:732,t:1527876698187};\\\", \\\"{x:607,y:745,t:1527876698204};\\\", \\\"{x:610,y:750,t:1527876698221};\\\", \\\"{x:611,y:754,t:1527876698237};\\\", \\\"{x:611,y:756,t:1527876698254};\\\", \\\"{x:611,y:757,t:1527876698308};\\\", \\\"{x:611,y:758,t:1527876698321};\\\", \\\"{x:604,y:762,t:1527876698337};\\\", \\\"{x:591,y:765,t:1527876698354};\\\", \\\"{x:575,y:769,t:1527876698372};\\\", \\\"{x:559,y:770,t:1527876698388};\\\", \\\"{x:544,y:772,t:1527876698405};\\\", \\\"{x:539,y:773,t:1527876698422};\\\", \\\"{x:537,y:773,t:1527876698438};\\\", \\\"{x:536,y:773,t:1527876698500};\\\", \\\"{x:535,y:773,t:1527876698507};\\\", \\\"{x:534,y:773,t:1527876698521};\\\", \\\"{x:531,y:773,t:1527876698538};\\\", \\\"{x:530,y:773,t:1527876698701};\\\", \\\"{x:529,y:772,t:1527876698709};\\\", \\\"{x:529,y:771,t:1527876698724};\\\", \\\"{x:527,y:768,t:1527876698739};\\\", \\\"{x:526,y:766,t:1527876698755};\\\", \\\"{x:526,y:763,t:1527876698771};\\\", \\\"{x:525,y:760,t:1527876698788};\\\", \\\"{x:529,y:760,t:1527876699876};\\\", \\\"{x:543,y:760,t:1527876699890};\\\", \\\"{x:603,y:762,t:1527876699908};\\\", \\\"{x:700,y:776,t:1527876699922};\\\", \\\"{x:821,y:792,t:1527876699939};\\\", \\\"{x:1012,y:822,t:1527876699955};\\\", \\\"{x:1127,y:834,t:1527876699972};\\\", \\\"{x:1200,y:835,t:1527876699989};\\\", \\\"{x:1235,y:835,t:1527876700005};\\\", \\\"{x:1245,y:835,t:1527876700022};\\\", \\\"{x:1246,y:835,t:1527876700060};\\\", \\\"{x:1245,y:835,t:1527876700333};\\\", \\\"{x:1244,y:835,t:1527876700365};\\\", \\\"{x:1242,y:835,t:1527876700373};\\\", \\\"{x:1239,y:835,t:1527876700390};\\\", \\\"{x:1238,y:835,t:1527876700407};\\\", \\\"{x:1235,y:835,t:1527876700423};\\\", \\\"{x:1232,y:835,t:1527876700440};\\\", \\\"{x:1230,y:834,t:1527876700457};\\\", \\\"{x:1225,y:834,t:1527876700473};\\\", \\\"{x:1220,y:833,t:1527876700490};\\\", \\\"{x:1214,y:831,t:1527876700511};\\\", \\\"{x:1210,y:831,t:1527876700522};\\\", \\\"{x:1207,y:830,t:1527876700540};\\\", \\\"{x:1209,y:831,t:1527876700809};\\\", \\\"{x:1210,y:831,t:1527876700823};\\\", \\\"{x:1212,y:831,t:1527876700839};\\\", \\\"{x:1213,y:831,t:1527876700924};\\\", \\\"{x:1215,y:831,t:1527876701068};\\\", \\\"{x:1216,y:832,t:1527876702685};\\\", \\\"{x:1226,y:845,t:1527876702708};\\\", \\\"{x:1235,y:857,t:1527876702724};\\\", \\\"{x:1240,y:865,t:1527876702742};\\\", \\\"{x:1243,y:873,t:1527876702758};\\\", \\\"{x:1249,y:884,t:1527876702775};\\\", \\\"{x:1255,y:894,t:1527876702791};\\\", \\\"{x:1263,y:907,t:1527876702807};\\\", \\\"{x:1270,y:917,t:1527876702824};\\\", \\\"{x:1277,y:929,t:1527876702842};\\\", \\\"{x:1283,y:941,t:1527876702857};\\\", \\\"{x:1290,y:949,t:1527876702875};\\\", \\\"{x:1296,y:961,t:1527876702892};\\\", \\\"{x:1297,y:963,t:1527876702908};\\\", \\\"{x:1298,y:964,t:1527876702940};\\\", \\\"{x:1298,y:965,t:1527876702948};\\\", \\\"{x:1300,y:966,t:1527876702964};\\\", \\\"{x:1300,y:967,t:1527876702980};\\\", \\\"{x:1300,y:968,t:1527876702992};\\\", \\\"{x:1300,y:969,t:1527876703213};\\\", \\\"{x:1299,y:969,t:1527876703228};\\\", \\\"{x:1297,y:969,t:1527876703242};\\\", \\\"{x:1295,y:969,t:1527876703259};\\\", \\\"{x:1292,y:971,t:1527876703275};\\\", \\\"{x:1290,y:971,t:1527876703292};\\\", \\\"{x:1283,y:971,t:1527876703309};\\\", \\\"{x:1280,y:972,t:1527876703325};\\\", \\\"{x:1277,y:972,t:1527876703342};\\\", \\\"{x:1276,y:972,t:1527876703404};\\\", \\\"{x:1276,y:973,t:1527876703412};\\\", \\\"{x:1276,y:974,t:1527876703468};\\\", \\\"{x:1277,y:972,t:1527876703588};\\\", \\\"{x:1281,y:968,t:1527876703597};\\\", \\\"{x:1284,y:963,t:1527876703609};\\\", \\\"{x:1296,y:946,t:1527876703626};\\\", \\\"{x:1308,y:923,t:1527876703642};\\\", \\\"{x:1323,y:902,t:1527876703659};\\\", \\\"{x:1350,y:869,t:1527876703676};\\\", \\\"{x:1373,y:842,t:1527876703692};\\\", \\\"{x:1389,y:816,t:1527876703709};\\\", \\\"{x:1399,y:796,t:1527876703726};\\\", \\\"{x:1402,y:781,t:1527876703742};\\\", \\\"{x:1402,y:768,t:1527876703759};\\\", \\\"{x:1403,y:761,t:1527876703777};\\\", \\\"{x:1403,y:757,t:1527876703792};\\\", \\\"{x:1404,y:754,t:1527876703809};\\\", \\\"{x:1398,y:760,t:1527876703901};\\\", \\\"{x:1384,y:772,t:1527876703909};\\\", \\\"{x:1301,y:808,t:1527876703926};\\\", \\\"{x:1174,y:839,t:1527876703943};\\\", \\\"{x:1017,y:859,t:1527876703959};\\\", \\\"{x:849,y:877,t:1527876703976};\\\", \\\"{x:674,y:881,t:1527876703993};\\\", \\\"{x:511,y:880,t:1527876704009};\\\", \\\"{x:391,y:876,t:1527876704026};\\\", \\\"{x:338,y:870,t:1527876704043};\\\", \\\"{x:323,y:867,t:1527876704058};\\\", \\\"{x:322,y:866,t:1527876704076};\\\", \\\"{x:321,y:866,t:1527876704116};\\\", \\\"{x:322,y:866,t:1527876704125};\\\", \\\"{x:326,y:861,t:1527876704143};\\\", \\\"{x:326,y:857,t:1527876704159};\\\", \\\"{x:326,y:853,t:1527876704176};\\\", \\\"{x:326,y:852,t:1527876704193};\\\", \\\"{x:328,y:848,t:1527876704209};\\\", \\\"{x:337,y:835,t:1527876704226};\\\", \\\"{x:348,y:823,t:1527876704243};\\\", \\\"{x:358,y:812,t:1527876704259};\\\", \\\"{x:378,y:798,t:1527876704276};\\\", \\\"{x:389,y:791,t:1527876704293};\\\", \\\"{x:399,y:783,t:1527876704310};\\\", \\\"{x:402,y:781,t:1527876704326};\\\", \\\"{x:405,y:778,t:1527876704343};\\\", \\\"{x:406,y:777,t:1527876704360};\\\", \\\"{x:407,y:775,t:1527876704388};\\\", \\\"{x:408,y:774,t:1527876704396};\\\", \\\"{x:410,y:771,t:1527876704410};\\\", \\\"{x:415,y:765,t:1527876704426};\\\", \\\"{x:422,y:757,t:1527876704443};\\\", \\\"{x:425,y:754,t:1527876704461};\\\", \\\"{x:427,y:751,t:1527876704476};\\\", \\\"{x:430,y:748,t:1527876704492};\\\", \\\"{x:433,y:746,t:1527876704510};\\\", \\\"{x:436,y:745,t:1527876704526};\\\", \\\"{x:438,y:745,t:1527876704669};\\\", \\\"{x:442,y:745,t:1527876704676};\\\", \\\"{x:454,y:750,t:1527876704694};\\\", \\\"{x:465,y:757,t:1527876704710};\\\", \\\"{x:472,y:762,t:1527876704726};\\\", \\\"{x:476,y:765,t:1527876704742};\\\" ] }, { \\\"rt\\\": 22603, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 8, \\\"time_elapsed\\\": 318813, \\\"internal_node_id\\\": \\\"0.0-5.0-3.0\\\", \\\"subject\\\": \\\"EER58\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 4, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"H\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-06 PM-04 PM-B -B -H -H -H -H -H -H -H -H -04 PM-H -H \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:476,y:767,t:1527876707245};\\\", \\\"{x:475,y:771,t:1527876707255};\\\", \\\"{x:472,y:774,t:1527876707264};\\\", \\\"{x:470,y:778,t:1527876707281};\\\", \\\"{x:467,y:782,t:1527876707295};\\\", \\\"{x:465,y:785,t:1527876707311};\\\", \\\"{x:464,y:790,t:1527876707327};\\\", \\\"{x:463,y:793,t:1527876707344};\\\", \\\"{x:460,y:798,t:1527876707362};\\\", \\\"{x:458,y:805,t:1527876707378};\\\", \\\"{x:455,y:812,t:1527876707395};\\\", \\\"{x:451,y:821,t:1527876707412};\\\", \\\"{x:450,y:824,t:1527876707428};\\\", \\\"{x:448,y:828,t:1527876707444};\\\", \\\"{x:447,y:831,t:1527876707461};\\\", \\\"{x:446,y:832,t:1527876707478};\\\", \\\"{x:446,y:834,t:1527876707495};\\\", \\\"{x:445,y:834,t:1527876710232};\\\", \\\"{x:448,y:834,t:1527876710250};\\\", \\\"{x:464,y:835,t:1527876710267};\\\", \\\"{x:495,y:838,t:1527876710282};\\\", \\\"{x:550,y:839,t:1527876710300};\\\", \\\"{x:611,y:841,t:1527876710316};\\\", \\\"{x:686,y:841,t:1527876710333};\\\", \\\"{x:759,y:841,t:1527876710350};\\\", \\\"{x:815,y:841,t:1527876710367};\\\", \\\"{x:852,y:841,t:1527876710383};\\\", \\\"{x:877,y:836,t:1527876710400};\\\", \\\"{x:882,y:833,t:1527876710416};\\\", \\\"{x:883,y:833,t:1527876710432};\\\", \\\"{x:885,y:831,t:1527876710449};\\\", \\\"{x:889,y:829,t:1527876710466};\\\", \\\"{x:895,y:827,t:1527876710482};\\\", \\\"{x:902,y:823,t:1527876710499};\\\", \\\"{x:907,y:821,t:1527876710517};\\\", \\\"{x:913,y:817,t:1527876710533};\\\", \\\"{x:917,y:815,t:1527876710549};\\\", \\\"{x:918,y:814,t:1527876710566};\\\", \\\"{x:922,y:813,t:1527876710583};\\\", \\\"{x:935,y:811,t:1527876710600};\\\", \\\"{x:955,y:811,t:1527876710617};\\\", \\\"{x:986,y:813,t:1527876710633};\\\", \\\"{x:1031,y:818,t:1527876710650};\\\", \\\"{x:1075,y:823,t:1527876710666};\\\", \\\"{x:1123,y:823,t:1527876710683};\\\", \\\"{x:1176,y:823,t:1527876710700};\\\", \\\"{x:1232,y:822,t:1527876710716};\\\", \\\"{x:1266,y:812,t:1527876710733};\\\", \\\"{x:1300,y:803,t:1527876710749};\\\", \\\"{x:1322,y:796,t:1527876710768};\\\", \\\"{x:1351,y:791,t:1527876710783};\\\", \\\"{x:1425,y:781,t:1527876710799};\\\", \\\"{x:1503,y:770,t:1527876710817};\\\", \\\"{x:1599,y:762,t:1527876710833};\\\", \\\"{x:1701,y:750,t:1527876710850};\\\", \\\"{x:1810,y:732,t:1527876710867};\\\", \\\"{x:1899,y:721,t:1527876710883};\\\", \\\"{x:1919,y:717,t:1527876710900};\\\", \\\"{x:1919,y:722,t:1527876710975};\\\", \\\"{x:1919,y:726,t:1527876710985};\\\", \\\"{x:1919,y:735,t:1527876711001};\\\", \\\"{x:1919,y:744,t:1527876711018};\\\", \\\"{x:1919,y:753,t:1527876711034};\\\", \\\"{x:1919,y:761,t:1527876711051};\\\", \\\"{x:1919,y:772,t:1527876711068};\\\", \\\"{x:1919,y:789,t:1527876711086};\\\", \\\"{x:1919,y:804,t:1527876711101};\\\", \\\"{x:1919,y:815,t:1527876711119};\\\", \\\"{x:1919,y:826,t:1527876711135};\\\", \\\"{x:1919,y:828,t:1527876711151};\\\", \\\"{x:1918,y:830,t:1527876711208};\\\", \\\"{x:1917,y:830,t:1527876711223};\\\", \\\"{x:1916,y:830,t:1527876711236};\\\", \\\"{x:1915,y:832,t:1527876711251};\\\", \\\"{x:1912,y:834,t:1527876711268};\\\", \\\"{x:1910,y:836,t:1527876711285};\\\", \\\"{x:1905,y:841,t:1527876711301};\\\", \\\"{x:1895,y:848,t:1527876711319};\\\", \\\"{x:1866,y:862,t:1527876711335};\\\", \\\"{x:1846,y:869,t:1527876711352};\\\", \\\"{x:1821,y:874,t:1527876711368};\\\", \\\"{x:1798,y:878,t:1527876711386};\\\", \\\"{x:1779,y:880,t:1527876711402};\\\", \\\"{x:1762,y:883,t:1527876711419};\\\", \\\"{x:1750,y:885,t:1527876711436};\\\", \\\"{x:1744,y:888,t:1527876711452};\\\", \\\"{x:1741,y:889,t:1527876711469};\\\", \\\"{x:1740,y:890,t:1527876711486};\\\", \\\"{x:1738,y:893,t:1527876711502};\\\", \\\"{x:1737,y:895,t:1527876711519};\\\", \\\"{x:1736,y:906,t:1527876711536};\\\", \\\"{x:1736,y:916,t:1527876711552};\\\", \\\"{x:1740,y:930,t:1527876711569};\\\", \\\"{x:1745,y:947,t:1527876711586};\\\", \\\"{x:1749,y:960,t:1527876711603};\\\", \\\"{x:1751,y:967,t:1527876711619};\\\", \\\"{x:1752,y:972,t:1527876711636};\\\", \\\"{x:1753,y:976,t:1527876711653};\\\", \\\"{x:1754,y:978,t:1527876711669};\\\", \\\"{x:1754,y:980,t:1527876711685};\\\", \\\"{x:1754,y:984,t:1527876711703};\\\", \\\"{x:1749,y:987,t:1527876711720};\\\", \\\"{x:1738,y:989,t:1527876711735};\\\", \\\"{x:1722,y:992,t:1527876711753};\\\", \\\"{x:1697,y:993,t:1527876711769};\\\", \\\"{x:1669,y:993,t:1527876711785};\\\", \\\"{x:1645,y:994,t:1527876711803};\\\", \\\"{x:1625,y:994,t:1527876711819};\\\", \\\"{x:1610,y:994,t:1527876711835};\\\", \\\"{x:1600,y:994,t:1527876711852};\\\", \\\"{x:1594,y:994,t:1527876711869};\\\", \\\"{x:1591,y:994,t:1527876711886};\\\", \\\"{x:1590,y:994,t:1527876711920};\\\", \\\"{x:1589,y:994,t:1527876711976};\\\", \\\"{x:1589,y:993,t:1527876712015};\\\", \\\"{x:1590,y:992,t:1527876712024};\\\", \\\"{x:1591,y:991,t:1527876712036};\\\", \\\"{x:1595,y:987,t:1527876712053};\\\", \\\"{x:1597,y:984,t:1527876712070};\\\", \\\"{x:1597,y:982,t:1527876712086};\\\", \\\"{x:1598,y:979,t:1527876712103};\\\", \\\"{x:1598,y:974,t:1527876712119};\\\", \\\"{x:1598,y:969,t:1527876712135};\\\", \\\"{x:1598,y:968,t:1527876712153};\\\", \\\"{x:1598,y:966,t:1527876712170};\\\", \\\"{x:1599,y:966,t:1527876712186};\\\", \\\"{x:1599,y:964,t:1527876712204};\\\", \\\"{x:1599,y:963,t:1527876712239};\\\", \\\"{x:1601,y:962,t:1527876712252};\\\", \\\"{x:1601,y:961,t:1527876712269};\\\", \\\"{x:1602,y:960,t:1527876712286};\\\", \\\"{x:1604,y:958,t:1527876712448};\\\", \\\"{x:1605,y:958,t:1527876712464};\\\", \\\"{x:1606,y:956,t:1527876712472};\\\", \\\"{x:1607,y:956,t:1527876712488};\\\", \\\"{x:1607,y:955,t:1527876712503};\\\", \\\"{x:1609,y:953,t:1527876712519};\\\", \\\"{x:1610,y:951,t:1527876712537};\\\", \\\"{x:1610,y:949,t:1527876712553};\\\", \\\"{x:1610,y:942,t:1527876712570};\\\", \\\"{x:1610,y:934,t:1527876712587};\\\", \\\"{x:1610,y:927,t:1527876712602};\\\", \\\"{x:1610,y:921,t:1527876712620};\\\", \\\"{x:1610,y:916,t:1527876712637};\\\", \\\"{x:1610,y:912,t:1527876712653};\\\", \\\"{x:1610,y:908,t:1527876712670};\\\", \\\"{x:1610,y:906,t:1527876712687};\\\", \\\"{x:1609,y:904,t:1527876712703};\\\", \\\"{x:1607,y:902,t:1527876712719};\\\", \\\"{x:1605,y:900,t:1527876712737};\\\", \\\"{x:1600,y:896,t:1527876712753};\\\", \\\"{x:1595,y:895,t:1527876712771};\\\", \\\"{x:1593,y:895,t:1527876712787};\\\", \\\"{x:1590,y:893,t:1527876712803};\\\", \\\"{x:1584,y:890,t:1527876712820};\\\", \\\"{x:1572,y:884,t:1527876712838};\\\", \\\"{x:1564,y:881,t:1527876712854};\\\", \\\"{x:1549,y:873,t:1527876712870};\\\", \\\"{x:1534,y:866,t:1527876712887};\\\", \\\"{x:1515,y:858,t:1527876712904};\\\", \\\"{x:1512,y:856,t:1527876712919};\\\", \\\"{x:1510,y:854,t:1527876712937};\\\", \\\"{x:1509,y:851,t:1527876712954};\\\", \\\"{x:1508,y:847,t:1527876712970};\\\", \\\"{x:1508,y:846,t:1527876713008};\\\", \\\"{x:1513,y:849,t:1527876713024};\\\", \\\"{x:1523,y:857,t:1527876713037};\\\", \\\"{x:1548,y:881,t:1527876713054};\\\", \\\"{x:1572,y:905,t:1527876713070};\\\", \\\"{x:1587,y:919,t:1527876713087};\\\", \\\"{x:1598,y:933,t:1527876713103};\\\", \\\"{x:1599,y:934,t:1527876713119};\\\", \\\"{x:1599,y:935,t:1527876713264};\\\", \\\"{x:1600,y:937,t:1527876713272};\\\", \\\"{x:1602,y:941,t:1527876713287};\\\", \\\"{x:1611,y:952,t:1527876713304};\\\", \\\"{x:1616,y:956,t:1527876713321};\\\", \\\"{x:1618,y:957,t:1527876713337};\\\", \\\"{x:1618,y:958,t:1527876713424};\\\", \\\"{x:1618,y:959,t:1527876713440};\\\", \\\"{x:1619,y:960,t:1527876713454};\\\", \\\"{x:1619,y:961,t:1527876713510};\\\", \\\"{x:1619,y:962,t:1527876713960};\\\", \\\"{x:1620,y:962,t:1527876713971};\\\", \\\"{x:1628,y:949,t:1527876713988};\\\", \\\"{x:1640,y:934,t:1527876714004};\\\", \\\"{x:1650,y:921,t:1527876714021};\\\", \\\"{x:1659,y:908,t:1527876714038};\\\", \\\"{x:1661,y:900,t:1527876714054};\\\", \\\"{x:1664,y:893,t:1527876714071};\\\", \\\"{x:1665,y:884,t:1527876714087};\\\", \\\"{x:1668,y:880,t:1527876714103};\\\", \\\"{x:1668,y:878,t:1527876714121};\\\", \\\"{x:1668,y:877,t:1527876714138};\\\", \\\"{x:1668,y:874,t:1527876714154};\\\", \\\"{x:1668,y:873,t:1527876714170};\\\", \\\"{x:1668,y:870,t:1527876714187};\\\", \\\"{x:1668,y:868,t:1527876714205};\\\", \\\"{x:1668,y:865,t:1527876714220};\\\", \\\"{x:1668,y:862,t:1527876714238};\\\", \\\"{x:1668,y:857,t:1527876714255};\\\", \\\"{x:1668,y:855,t:1527876714271};\\\", \\\"{x:1668,y:854,t:1527876714288};\\\", \\\"{x:1668,y:851,t:1527876714305};\\\", \\\"{x:1669,y:848,t:1527876714321};\\\", \\\"{x:1672,y:842,t:1527876714337};\\\", \\\"{x:1675,y:836,t:1527876714354};\\\", \\\"{x:1676,y:832,t:1527876714373};\\\", \\\"{x:1677,y:829,t:1527876714387};\\\", \\\"{x:1677,y:828,t:1527876714407};\\\", \\\"{x:1677,y:826,t:1527876714422};\\\", \\\"{x:1677,y:825,t:1527876714440};\\\", \\\"{x:1677,y:824,t:1527876714455};\\\", \\\"{x:1677,y:822,t:1527876714471};\\\", \\\"{x:1677,y:824,t:1527876714792};\\\", \\\"{x:1675,y:827,t:1527876714805};\\\", \\\"{x:1671,y:836,t:1527876714822};\\\", \\\"{x:1669,y:843,t:1527876714838};\\\", \\\"{x:1666,y:859,t:1527876714856};\\\", \\\"{x:1663,y:879,t:1527876714872};\\\", \\\"{x:1658,y:895,t:1527876714889};\\\", \\\"{x:1655,y:911,t:1527876714905};\\\", \\\"{x:1649,y:926,t:1527876714923};\\\", \\\"{x:1644,y:935,t:1527876714939};\\\", \\\"{x:1639,y:944,t:1527876714955};\\\", \\\"{x:1634,y:952,t:1527876714972};\\\", \\\"{x:1631,y:959,t:1527876714988};\\\", \\\"{x:1631,y:962,t:1527876715005};\\\", \\\"{x:1630,y:964,t:1527876715022};\\\", \\\"{x:1630,y:966,t:1527876715039};\\\", \\\"{x:1628,y:966,t:1527876715248};\\\", \\\"{x:1623,y:966,t:1527876715256};\\\", \\\"{x:1615,y:966,t:1527876715272};\\\", \\\"{x:1611,y:966,t:1527876715289};\\\", \\\"{x:1607,y:966,t:1527876715305};\\\", \\\"{x:1606,y:966,t:1527876715322};\\\", \\\"{x:1605,y:966,t:1527876715360};\\\", \\\"{x:1604,y:966,t:1527876715372};\\\", \\\"{x:1602,y:966,t:1527876715390};\\\", \\\"{x:1599,y:964,t:1527876715405};\\\", \\\"{x:1597,y:958,t:1527876715422};\\\", \\\"{x:1593,y:950,t:1527876715439};\\\", \\\"{x:1588,y:939,t:1527876715456};\\\", \\\"{x:1583,y:928,t:1527876715472};\\\", \\\"{x:1580,y:921,t:1527876715489};\\\", \\\"{x:1577,y:915,t:1527876715506};\\\", \\\"{x:1575,y:908,t:1527876715523};\\\", \\\"{x:1570,y:899,t:1527876715539};\\\", \\\"{x:1568,y:893,t:1527876715556};\\\", \\\"{x:1566,y:889,t:1527876715573};\\\", \\\"{x:1566,y:885,t:1527876715590};\\\", \\\"{x:1566,y:882,t:1527876715606};\\\", \\\"{x:1564,y:878,t:1527876715622};\\\", \\\"{x:1564,y:876,t:1527876715639};\\\", \\\"{x:1564,y:870,t:1527876715655};\\\", \\\"{x:1564,y:865,t:1527876715672};\\\", \\\"{x:1564,y:859,t:1527876715689};\\\", \\\"{x:1562,y:851,t:1527876715706};\\\", \\\"{x:1561,y:845,t:1527876715722};\\\", \\\"{x:1560,y:840,t:1527876715739};\\\", \\\"{x:1559,y:835,t:1527876715757};\\\", \\\"{x:1558,y:832,t:1527876715773};\\\", \\\"{x:1555,y:824,t:1527876715789};\\\", \\\"{x:1551,y:818,t:1527876715806};\\\", \\\"{x:1549,y:810,t:1527876715823};\\\", \\\"{x:1543,y:802,t:1527876715839};\\\", \\\"{x:1537,y:789,t:1527876715855};\\\", \\\"{x:1533,y:782,t:1527876715873};\\\", \\\"{x:1525,y:772,t:1527876715888};\\\", \\\"{x:1518,y:762,t:1527876715906};\\\", \\\"{x:1514,y:756,t:1527876715923};\\\", \\\"{x:1508,y:747,t:1527876715939};\\\", \\\"{x:1501,y:737,t:1527876715956};\\\", \\\"{x:1491,y:726,t:1527876715973};\\\", \\\"{x:1486,y:720,t:1527876715988};\\\", \\\"{x:1482,y:715,t:1527876716006};\\\", \\\"{x:1479,y:713,t:1527876716022};\\\", \\\"{x:1479,y:712,t:1527876716038};\\\", \\\"{x:1476,y:708,t:1527876716056};\\\", \\\"{x:1475,y:706,t:1527876716073};\\\", \\\"{x:1474,y:704,t:1527876716089};\\\", \\\"{x:1473,y:703,t:1527876716135};\\\", \\\"{x:1472,y:702,t:1527876716192};\\\", \\\"{x:1471,y:701,t:1527876716206};\\\", \\\"{x:1468,y:689,t:1527876716223};\\\", \\\"{x:1463,y:677,t:1527876716240};\\\", \\\"{x:1457,y:656,t:1527876716256};\\\", \\\"{x:1448,y:636,t:1527876716273};\\\", \\\"{x:1441,y:623,t:1527876716290};\\\", \\\"{x:1434,y:612,t:1527876716306};\\\", \\\"{x:1430,y:603,t:1527876716323};\\\", \\\"{x:1426,y:597,t:1527876716340};\\\", \\\"{x:1424,y:595,t:1527876716356};\\\", \\\"{x:1424,y:594,t:1527876716373};\\\", \\\"{x:1423,y:594,t:1527876716390};\\\", \\\"{x:1422,y:592,t:1527876716416};\\\", \\\"{x:1421,y:588,t:1527876716431};\\\", \\\"{x:1420,y:586,t:1527876716439};\\\", \\\"{x:1417,y:580,t:1527876716456};\\\", \\\"{x:1412,y:573,t:1527876716473};\\\", \\\"{x:1411,y:569,t:1527876716490};\\\", \\\"{x:1407,y:563,t:1527876716506};\\\", \\\"{x:1404,y:557,t:1527876716523};\\\", \\\"{x:1403,y:554,t:1527876716540};\\\", \\\"{x:1403,y:552,t:1527876716556};\\\", \\\"{x:1403,y:551,t:1527876716736};\\\", \\\"{x:1405,y:551,t:1527876716751};\\\", \\\"{x:1407,y:552,t:1527876716760};\\\", \\\"{x:1408,y:552,t:1527876716773};\\\", \\\"{x:1408,y:554,t:1527876716790};\\\", \\\"{x:1411,y:555,t:1527876716888};\\\", \\\"{x:1411,y:556,t:1527876716895};\\\", \\\"{x:1411,y:557,t:1527876716907};\\\", \\\"{x:1412,y:558,t:1527876716927};\\\", \\\"{x:1413,y:560,t:1527876716939};\\\", \\\"{x:1414,y:561,t:1527876716956};\\\", \\\"{x:1414,y:563,t:1527876716972};\\\", \\\"{x:1415,y:567,t:1527876716988};\\\", \\\"{x:1415,y:568,t:1527876717006};\\\", \\\"{x:1414,y:568,t:1527876717484};\\\", \\\"{x:1413,y:568,t:1527876717489};\\\", \\\"{x:1410,y:567,t:1527876717524};\\\", \\\"{x:1410,y:566,t:1527876717540};\\\", \\\"{x:1409,y:566,t:1527876717558};\\\", \\\"{x:1408,y:566,t:1527876717575};\\\", \\\"{x:1408,y:565,t:1527876718096};\\\", \\\"{x:1409,y:565,t:1527876718147};\\\", \\\"{x:1410,y:565,t:1527876718223};\\\", \\\"{x:1412,y:564,t:1527876718239};\\\", \\\"{x:1414,y:563,t:1527876718256};\\\", \\\"{x:1415,y:563,t:1527876718273};\\\", \\\"{x:1418,y:562,t:1527876718290};\\\", \\\"{x:1418,y:560,t:1527876718784};\\\", \\\"{x:1418,y:556,t:1527876718793};\\\", \\\"{x:1412,y:549,t:1527876718807};\\\", \\\"{x:1406,y:542,t:1527876718825};\\\", \\\"{x:1398,y:532,t:1527876718841};\\\", \\\"{x:1394,y:529,t:1527876718858};\\\", \\\"{x:1394,y:528,t:1527876718874};\\\", \\\"{x:1393,y:528,t:1527876718892};\\\", \\\"{x:1392,y:527,t:1527876718927};\\\", \\\"{x:1390,y:527,t:1527876718942};\\\", \\\"{x:1389,y:525,t:1527876718957};\\\", \\\"{x:1385,y:519,t:1527876718975};\\\", \\\"{x:1379,y:512,t:1527876718991};\\\", \\\"{x:1374,y:504,t:1527876719008};\\\", \\\"{x:1366,y:491,t:1527876719025};\\\", \\\"{x:1361,y:486,t:1527876719042};\\\", \\\"{x:1359,y:483,t:1527876719059};\\\", \\\"{x:1358,y:482,t:1527876719075};\\\", \\\"{x:1358,y:480,t:1527876719095};\\\", \\\"{x:1358,y:479,t:1527876719108};\\\", \\\"{x:1358,y:476,t:1527876719125};\\\", \\\"{x:1357,y:467,t:1527876719142};\\\", \\\"{x:1357,y:460,t:1527876719158};\\\", \\\"{x:1357,y:439,t:1527876719176};\\\", \\\"{x:1359,y:425,t:1527876719191};\\\", \\\"{x:1360,y:415,t:1527876719209};\\\", \\\"{x:1360,y:408,t:1527876719225};\\\", \\\"{x:1360,y:404,t:1527876719242};\\\", \\\"{x:1360,y:401,t:1527876719259};\\\", \\\"{x:1360,y:400,t:1527876719275};\\\", \\\"{x:1360,y:398,t:1527876719312};\\\", \\\"{x:1359,y:398,t:1527876719376};\\\", \\\"{x:1353,y:406,t:1527876719392};\\\", \\\"{x:1346,y:418,t:1527876719409};\\\", \\\"{x:1340,y:438,t:1527876719425};\\\", \\\"{x:1338,y:457,t:1527876719442};\\\", \\\"{x:1338,y:475,t:1527876719461};\\\", \\\"{x:1338,y:488,t:1527876719476};\\\", \\\"{x:1344,y:504,t:1527876719492};\\\", \\\"{x:1352,y:517,t:1527876719509};\\\", \\\"{x:1358,y:527,t:1527876719525};\\\", \\\"{x:1364,y:534,t:1527876719542};\\\", \\\"{x:1365,y:537,t:1527876719560};\\\", \\\"{x:1367,y:538,t:1527876719584};\\\", \\\"{x:1368,y:539,t:1527876719600};\\\", \\\"{x:1369,y:539,t:1527876719609};\\\", \\\"{x:1372,y:541,t:1527876719625};\\\", \\\"{x:1375,y:542,t:1527876719643};\\\", \\\"{x:1378,y:543,t:1527876719660};\\\", \\\"{x:1384,y:545,t:1527876719676};\\\", \\\"{x:1391,y:548,t:1527876719693};\\\", \\\"{x:1399,y:550,t:1527876719709};\\\", \\\"{x:1410,y:553,t:1527876719726};\\\", \\\"{x:1416,y:553,t:1527876719742};\\\", \\\"{x:1420,y:554,t:1527876719760};\\\", \\\"{x:1420,y:555,t:1527876719775};\\\", \\\"{x:1421,y:555,t:1527876719792};\\\", \\\"{x:1422,y:555,t:1527876719809};\\\", \\\"{x:1423,y:555,t:1527876719839};\\\", \\\"{x:1424,y:555,t:1527876719928};\\\", \\\"{x:1425,y:555,t:1527876719943};\\\", \\\"{x:1426,y:556,t:1527876719959};\\\", \\\"{x:1426,y:557,t:1527876719976};\\\", \\\"{x:1426,y:559,t:1527876719992};\\\", \\\"{x:1426,y:560,t:1527876720031};\\\", \\\"{x:1426,y:561,t:1527876720112};\\\", \\\"{x:1425,y:561,t:1527876720135};\\\", \\\"{x:1424,y:562,t:1527876720144};\\\", \\\"{x:1423,y:562,t:1527876720183};\\\", \\\"{x:1421,y:563,t:1527876720207};\\\", \\\"{x:1420,y:563,t:1527876720219};\\\", \\\"{x:1419,y:564,t:1527876720242};\\\", \\\"{x:1418,y:564,t:1527876720259};\\\", \\\"{x:1417,y:564,t:1527876720276};\\\", \\\"{x:1415,y:565,t:1527876720292};\\\", \\\"{x:1414,y:565,t:1527876720327};\\\", \\\"{x:1413,y:565,t:1527876720367};\\\", \\\"{x:1413,y:566,t:1527876720391};\\\", \\\"{x:1412,y:567,t:1527876720536};\\\", \\\"{x:1418,y:576,t:1527876720559};\\\", \\\"{x:1422,y:582,t:1527876720575};\\\", \\\"{x:1427,y:590,t:1527876720593};\\\", \\\"{x:1435,y:599,t:1527876720609};\\\", \\\"{x:1442,y:610,t:1527876720626};\\\", \\\"{x:1447,y:619,t:1527876720643};\\\", \\\"{x:1453,y:631,t:1527876720660};\\\", \\\"{x:1461,y:641,t:1527876720676};\\\", \\\"{x:1465,y:645,t:1527876720693};\\\", \\\"{x:1472,y:651,t:1527876720710};\\\", \\\"{x:1475,y:657,t:1527876720726};\\\", \\\"{x:1482,y:666,t:1527876720743};\\\", \\\"{x:1486,y:672,t:1527876720759};\\\", \\\"{x:1491,y:679,t:1527876720776};\\\", \\\"{x:1497,y:692,t:1527876720793};\\\", \\\"{x:1507,y:707,t:1527876720810};\\\", \\\"{x:1516,y:724,t:1527876720826};\\\", \\\"{x:1526,y:742,t:1527876720843};\\\", \\\"{x:1537,y:759,t:1527876720860};\\\", \\\"{x:1548,y:776,t:1527876720876};\\\", \\\"{x:1556,y:791,t:1527876720893};\\\", \\\"{x:1562,y:802,t:1527876720910};\\\", \\\"{x:1570,y:815,t:1527876720926};\\\", \\\"{x:1584,y:839,t:1527876720943};\\\", \\\"{x:1599,y:858,t:1527876720960};\\\", \\\"{x:1611,y:874,t:1527876720977};\\\", \\\"{x:1619,y:887,t:1527876720993};\\\", \\\"{x:1623,y:895,t:1527876721011};\\\", \\\"{x:1627,y:900,t:1527876721027};\\\", \\\"{x:1631,y:906,t:1527876721044};\\\", \\\"{x:1636,y:914,t:1527876721061};\\\", \\\"{x:1642,y:924,t:1527876721078};\\\", \\\"{x:1650,y:934,t:1527876721092};\\\", \\\"{x:1652,y:938,t:1527876721110};\\\", \\\"{x:1652,y:939,t:1527876721199};\\\", \\\"{x:1651,y:941,t:1527876721210};\\\", \\\"{x:1650,y:943,t:1527876721227};\\\", \\\"{x:1649,y:947,t:1527876721243};\\\", \\\"{x:1647,y:949,t:1527876721260};\\\", \\\"{x:1645,y:953,t:1527876721278};\\\", \\\"{x:1644,y:957,t:1527876721294};\\\", \\\"{x:1642,y:960,t:1527876721311};\\\", \\\"{x:1642,y:968,t:1527876721327};\\\", \\\"{x:1638,y:976,t:1527876721343};\\\", \\\"{x:1637,y:980,t:1527876721361};\\\", \\\"{x:1636,y:983,t:1527876721377};\\\", \\\"{x:1635,y:983,t:1527876721394};\\\", \\\"{x:1633,y:983,t:1527876721511};\\\", \\\"{x:1626,y:974,t:1527876721527};\\\", \\\"{x:1621,y:964,t:1527876721544};\\\", \\\"{x:1616,y:957,t:1527876721560};\\\", \\\"{x:1613,y:951,t:1527876721577};\\\", \\\"{x:1613,y:946,t:1527876721594};\\\", \\\"{x:1613,y:944,t:1527876721610};\\\", \\\"{x:1612,y:940,t:1527876721628};\\\", \\\"{x:1610,y:933,t:1527876721645};\\\", \\\"{x:1608,y:927,t:1527876721661};\\\", \\\"{x:1605,y:919,t:1527876721677};\\\", \\\"{x:1603,y:910,t:1527876721694};\\\", \\\"{x:1599,y:894,t:1527876721710};\\\", \\\"{x:1588,y:861,t:1527876721728};\\\", \\\"{x:1577,y:836,t:1527876721744};\\\", \\\"{x:1567,y:815,t:1527876721760};\\\", \\\"{x:1559,y:797,t:1527876721778};\\\", \\\"{x:1553,y:781,t:1527876721795};\\\", \\\"{x:1544,y:763,t:1527876721811};\\\", \\\"{x:1538,y:743,t:1527876721828};\\\", \\\"{x:1527,y:722,t:1527876721844};\\\", \\\"{x:1522,y:707,t:1527876721862};\\\", \\\"{x:1514,y:694,t:1527876721878};\\\", \\\"{x:1504,y:679,t:1527876721894};\\\", \\\"{x:1490,y:655,t:1527876721911};\\\", \\\"{x:1483,y:641,t:1527876721927};\\\", \\\"{x:1475,y:628,t:1527876721944};\\\", \\\"{x:1466,y:617,t:1527876721961};\\\", \\\"{x:1458,y:609,t:1527876721977};\\\", \\\"{x:1454,y:603,t:1527876721995};\\\", \\\"{x:1451,y:599,t:1527876722011};\\\", \\\"{x:1449,y:598,t:1527876722028};\\\", \\\"{x:1446,y:595,t:1527876722044};\\\", \\\"{x:1443,y:590,t:1527876722061};\\\", \\\"{x:1437,y:584,t:1527876722077};\\\", \\\"{x:1431,y:579,t:1527876722094};\\\", \\\"{x:1429,y:576,t:1527876722110};\\\", \\\"{x:1429,y:575,t:1527876722183};\\\", \\\"{x:1429,y:574,t:1527876722194};\\\", \\\"{x:1429,y:571,t:1527876722211};\\\", \\\"{x:1428,y:567,t:1527876722227};\\\", \\\"{x:1428,y:566,t:1527876722244};\\\", \\\"{x:1427,y:564,t:1527876722263};\\\", \\\"{x:1426,y:564,t:1527876722277};\\\", \\\"{x:1424,y:562,t:1527876722294};\\\", \\\"{x:1421,y:559,t:1527876722311};\\\", \\\"{x:1418,y:557,t:1527876722327};\\\", \\\"{x:1417,y:556,t:1527876722344};\\\", \\\"{x:1416,y:556,t:1527876722361};\\\", \\\"{x:1415,y:556,t:1527876722391};\\\", \\\"{x:1414,y:556,t:1527876722400};\\\", \\\"{x:1413,y:555,t:1527876722412};\\\", \\\"{x:1413,y:554,t:1527876722429};\\\", \\\"{x:1412,y:554,t:1527876722445};\\\", \\\"{x:1411,y:554,t:1527876722640};\\\", \\\"{x:1411,y:555,t:1527876722872};\\\", \\\"{x:1411,y:557,t:1527876722880};\\\", \\\"{x:1414,y:558,t:1527876722899};\\\", \\\"{x:1418,y:561,t:1527876722927};\\\", \\\"{x:1417,y:561,t:1527876725072};\\\", \\\"{x:1412,y:563,t:1527876725079};\\\", \\\"{x:1377,y:573,t:1527876725098};\\\", \\\"{x:1320,y:584,t:1527876725113};\\\", \\\"{x:1215,y:600,t:1527876725130};\\\", \\\"{x:1103,y:620,t:1527876725146};\\\", \\\"{x:975,y:641,t:1527876725163};\\\", \\\"{x:854,y:653,t:1527876725179};\\\", \\\"{x:769,y:659,t:1527876725196};\\\", \\\"{x:727,y:659,t:1527876725213};\\\", \\\"{x:699,y:659,t:1527876725231};\\\", \\\"{x:688,y:659,t:1527876725246};\\\", \\\"{x:685,y:659,t:1527876725263};\\\", \\\"{x:684,y:659,t:1527876725287};\\\", \\\"{x:683,y:659,t:1527876725296};\\\", \\\"{x:680,y:659,t:1527876725313};\\\", \\\"{x:672,y:659,t:1527876725330};\\\", \\\"{x:656,y:659,t:1527876725347};\\\", \\\"{x:638,y:660,t:1527876725364};\\\", \\\"{x:625,y:660,t:1527876725380};\\\", \\\"{x:620,y:658,t:1527876725397};\\\", \\\"{x:617,y:655,t:1527876725413};\\\", \\\"{x:612,y:648,t:1527876725431};\\\", \\\"{x:608,y:632,t:1527876725447};\\\", \\\"{x:600,y:615,t:1527876725464};\\\", \\\"{x:595,y:598,t:1527876725481};\\\", \\\"{x:592,y:585,t:1527876725497};\\\", \\\"{x:590,y:581,t:1527876725512};\\\", \\\"{x:590,y:579,t:1527876725530};\\\", \\\"{x:592,y:579,t:1527876725656};\\\", \\\"{x:594,y:579,t:1527876725664};\\\", \\\"{x:597,y:580,t:1527876725682};\\\", \\\"{x:601,y:581,t:1527876725697};\\\", \\\"{x:602,y:582,t:1527876725714};\\\", \\\"{x:603,y:582,t:1527876725759};\\\", \\\"{x:603,y:583,t:1527876725768};\\\", \\\"{x:604,y:584,t:1527876725780};\\\", \\\"{x:607,y:588,t:1527876725797};\\\", \\\"{x:608,y:589,t:1527876725814};\\\", \\\"{x:608,y:592,t:1527876726151};\\\", \\\"{x:608,y:593,t:1527876726164};\\\", \\\"{x:608,y:599,t:1527876726181};\\\", \\\"{x:608,y:604,t:1527876726197};\\\", \\\"{x:608,y:612,t:1527876726214};\\\", \\\"{x:608,y:617,t:1527876726231};\\\", \\\"{x:608,y:619,t:1527876726247};\\\", \\\"{x:608,y:622,t:1527876726264};\\\", \\\"{x:608,y:624,t:1527876726281};\\\", \\\"{x:606,y:626,t:1527876726512};\\\", \\\"{x:606,y:629,t:1527876726519};\\\", \\\"{x:603,y:634,t:1527876726531};\\\", \\\"{x:598,y:645,t:1527876726548};\\\", \\\"{x:591,y:660,t:1527876726564};\\\", \\\"{x:585,y:674,t:1527876726581};\\\", \\\"{x:579,y:685,t:1527876726597};\\\", \\\"{x:575,y:694,t:1527876726615};\\\", \\\"{x:568,y:706,t:1527876726631};\\\", \\\"{x:562,y:712,t:1527876726647};\\\", \\\"{x:557,y:718,t:1527876726664};\\\", \\\"{x:551,y:724,t:1527876726681};\\\", \\\"{x:547,y:728,t:1527876726697};\\\", \\\"{x:543,y:732,t:1527876726714};\\\", \\\"{x:540,y:736,t:1527876726731};\\\", \\\"{x:538,y:739,t:1527876726748};\\\", \\\"{x:535,y:741,t:1527876726764};\\\", \\\"{x:534,y:742,t:1527876726781};\\\", \\\"{x:533,y:743,t:1527876726798};\\\", \\\"{x:532,y:744,t:1527876726815};\\\", \\\"{x:531,y:746,t:1527876727191};\\\", \\\"{x:531,y:747,t:1527876727223};\\\", \\\"{x:531,y:746,t:1527876729504};\\\", \\\"{x:530,y:745,t:1527876729527};\\\" ] }, { \\\"rt\\\": 29206, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 9, \\\"time_elapsed\\\": 349257, \\\"internal_node_id\\\": \\\"0.0-5.0-4.0\\\", \\\"subject\\\": \\\"EER58\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"acme\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 5, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"X \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"U \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -01 PM-I -I -I -O -O -O -O -O -I -I -O -O -O -O -O \\\", \\\"block\\\": \\\"triangular_scaffolded\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:530,y:742,t:1527876733983};\\\", \\\"{x:531,y:737,t:1527876733992};\\\", \\\"{x:536,y:729,t:1527876734003};\\\", \\\"{x:545,y:708,t:1527876734021};\\\", \\\"{x:562,y:665,t:1527876734038};\\\", \\\"{x:575,y:633,t:1527876734055};\\\", \\\"{x:585,y:606,t:1527876734071};\\\", \\\"{x:587,y:580,t:1527876734087};\\\", \\\"{x:587,y:570,t:1527876734103};\\\", \\\"{x:585,y:563,t:1527876734120};\\\", \\\"{x:584,y:561,t:1527876734151};\\\", \\\"{x:581,y:559,t:1527876734167};\\\", \\\"{x:581,y:558,t:1527876734175};\\\", \\\"{x:580,y:557,t:1527876734188};\\\", \\\"{x:579,y:557,t:1527876734215};\\\", \\\"{x:579,y:556,t:1527876734231};\\\", \\\"{x:578,y:556,t:1527876734238};\\\", \\\"{x:578,y:555,t:1527876734253};\\\", \\\"{x:577,y:554,t:1527876734270};\\\", \\\"{x:573,y:554,t:1527876734287};\\\", \\\"{x:566,y:551,t:1527876734303};\\\", \\\"{x:553,y:545,t:1527876734321};\\\", \\\"{x:538,y:539,t:1527876734338};\\\", \\\"{x:522,y:532,t:1527876734354};\\\", \\\"{x:502,y:524,t:1527876734371};\\\", \\\"{x:476,y:517,t:1527876734387};\\\", \\\"{x:461,y:514,t:1527876734404};\\\", \\\"{x:457,y:513,t:1527876734421};\\\", \\\"{x:458,y:511,t:1527876734672};\\\", \\\"{x:468,y:509,t:1527876734688};\\\", \\\"{x:483,y:506,t:1527876734705};\\\", \\\"{x:507,y:503,t:1527876734721};\\\", \\\"{x:532,y:499,t:1527876734738};\\\", \\\"{x:561,y:499,t:1527876734755};\\\", \\\"{x:588,y:499,t:1527876734770};\\\", \\\"{x:616,y:499,t:1527876734788};\\\", \\\"{x:641,y:499,t:1527876734805};\\\", \\\"{x:657,y:499,t:1527876734822};\\\", \\\"{x:666,y:499,t:1527876734838};\\\", \\\"{x:669,y:499,t:1527876734855};\\\", \\\"{x:670,y:499,t:1527876734871};\\\", \\\"{x:671,y:499,t:1527876735344};\\\", \\\"{x:672,y:499,t:1527876735355};\\\", \\\"{x:673,y:501,t:1527876735383};\\\", \\\"{x:673,y:502,t:1527876735494};\\\", \\\"{x:673,y:503,t:1527876736343};\\\", \\\"{x:673,y:504,t:1527876736392};\\\", \\\"{x:672,y:505,t:1527876736456};\\\", \\\"{x:671,y:506,t:1527876736519};\\\", \\\"{x:669,y:506,t:1527876736535};\\\", \\\"{x:668,y:507,t:1527876736665};\\\", \\\"{x:667,y:507,t:1527876736743};\\\", \\\"{x:666,y:507,t:1527876736776};\\\", \\\"{x:665,y:507,t:1527876736789};\\\", \\\"{x:664,y:506,t:1527876736805};\\\", \\\"{x:663,y:505,t:1527876736822};\\\", \\\"{x:662,y:504,t:1527876736854};\\\", \\\"{x:662,y:503,t:1527876736879};\\\", \\\"{x:662,y:502,t:1527876736895};\\\", \\\"{x:661,y:501,t:1527876736905};\\\", \\\"{x:661,y:500,t:1527876736923};\\\", \\\"{x:661,y:499,t:1527876736940};\\\", \\\"{x:660,y:499,t:1527876737102};\\\", \\\"{x:659,y:499,t:1527876737110};\\\", \\\"{x:657,y:499,t:1527876737122};\\\", \\\"{x:656,y:500,t:1527876737140};\\\", \\\"{x:656,y:503,t:1527876737156};\\\", \\\"{x:655,y:505,t:1527876737173};\\\", \\\"{x:655,y:506,t:1527876737189};\\\", \\\"{x:655,y:510,t:1527876737207};\\\", \\\"{x:655,y:512,t:1527876737223};\\\", \\\"{x:658,y:517,t:1527876737240};\\\", \\\"{x:668,y:524,t:1527876737257};\\\", \\\"{x:689,y:529,t:1527876737272};\\\", \\\"{x:712,y:532,t:1527876737290};\\\", \\\"{x:761,y:540,t:1527876737307};\\\", \\\"{x:822,y:540,t:1527876737323};\\\", \\\"{x:900,y:540,t:1527876737340};\\\", \\\"{x:968,y:529,t:1527876737358};\\\", \\\"{x:1032,y:510,t:1527876737374};\\\", \\\"{x:1074,y:497,t:1527876737390};\\\", \\\"{x:1111,y:480,t:1527876737408};\\\", \\\"{x:1120,y:477,t:1527876737424};\\\", \\\"{x:1124,y:475,t:1527876737440};\\\", \\\"{x:1126,y:475,t:1527876737457};\\\", \\\"{x:1125,y:476,t:1527876737815};\\\", \\\"{x:1124,y:476,t:1527876737831};\\\", \\\"{x:1124,y:477,t:1527876737855};\\\", \\\"{x:1123,y:477,t:1527876737872};\\\", \\\"{x:1123,y:478,t:1527876737992};\\\", \\\"{x:1126,y:477,t:1527876738132};\\\", \\\"{x:1131,y:476,t:1527876738140};\\\", \\\"{x:1138,y:474,t:1527876738157};\\\", \\\"{x:1153,y:468,t:1527876738173};\\\", \\\"{x:1186,y:452,t:1527876738190};\\\", \\\"{x:1221,y:434,t:1527876738207};\\\", \\\"{x:1263,y:419,t:1527876738224};\\\", \\\"{x:1304,y:397,t:1527876738241};\\\", \\\"{x:1337,y:382,t:1527876738258};\\\", \\\"{x:1368,y:368,t:1527876738274};\\\", \\\"{x:1392,y:358,t:1527876738291};\\\", \\\"{x:1416,y:348,t:1527876738307};\\\", \\\"{x:1433,y:337,t:1527876738323};\\\", \\\"{x:1446,y:326,t:1527876738340};\\\", \\\"{x:1462,y:314,t:1527876738358};\\\", \\\"{x:1470,y:306,t:1527876738374};\\\", \\\"{x:1476,y:299,t:1527876738390};\\\", \\\"{x:1479,y:295,t:1527876738407};\\\", \\\"{x:1480,y:293,t:1527876738423};\\\", \\\"{x:1481,y:290,t:1527876738441};\\\", \\\"{x:1484,y:287,t:1527876738458};\\\", \\\"{x:1486,y:285,t:1527876738473};\\\", \\\"{x:1488,y:282,t:1527876738490};\\\", \\\"{x:1490,y:279,t:1527876738508};\\\", \\\"{x:1492,y:277,t:1527876738524};\\\", \\\"{x:1494,y:275,t:1527876738540};\\\", \\\"{x:1494,y:273,t:1527876738558};\\\", \\\"{x:1496,y:269,t:1527876738573};\\\", \\\"{x:1496,y:264,t:1527876738591};\\\", \\\"{x:1497,y:262,t:1527876738607};\\\", \\\"{x:1500,y:259,t:1527876738623};\\\", \\\"{x:1502,y:256,t:1527876738642};\\\", \\\"{x:1504,y:254,t:1527876738658};\\\", \\\"{x:1506,y:250,t:1527876738674};\\\", \\\"{x:1508,y:247,t:1527876738691};\\\", \\\"{x:1510,y:244,t:1527876738708};\\\", \\\"{x:1511,y:241,t:1527876738724};\\\", \\\"{x:1514,y:237,t:1527876738740};\\\", \\\"{x:1515,y:235,t:1527876738757};\\\", \\\"{x:1515,y:237,t:1527876738816};\\\", \\\"{x:1515,y:246,t:1527876738826};\\\", \\\"{x:1511,y:270,t:1527876738841};\\\", \\\"{x:1511,y:299,t:1527876738857};\\\", \\\"{x:1515,y:337,t:1527876738874};\\\", \\\"{x:1528,y:379,t:1527876738891};\\\", \\\"{x:1545,y:428,t:1527876738907};\\\", \\\"{x:1561,y:469,t:1527876738925};\\\", \\\"{x:1581,y:504,t:1527876738941};\\\", \\\"{x:1594,y:530,t:1527876738958};\\\", \\\"{x:1614,y:561,t:1527876738976};\\\", \\\"{x:1627,y:576,t:1527876738991};\\\", \\\"{x:1640,y:589,t:1527876739007};\\\", \\\"{x:1658,y:601,t:1527876739024};\\\", \\\"{x:1671,y:613,t:1527876739039};\\\", \\\"{x:1688,y:620,t:1527876739056};\\\", \\\"{x:1706,y:631,t:1527876739074};\\\", \\\"{x:1728,y:644,t:1527876739089};\\\", \\\"{x:1747,y:655,t:1527876739106};\\\", \\\"{x:1763,y:664,t:1527876739124};\\\", \\\"{x:1775,y:673,t:1527876739140};\\\", \\\"{x:1785,y:681,t:1527876739157};\\\", \\\"{x:1791,y:687,t:1527876739174};\\\", \\\"{x:1797,y:693,t:1527876739190};\\\", \\\"{x:1803,y:702,t:1527876739207};\\\", \\\"{x:1805,y:707,t:1527876739223};\\\", \\\"{x:1806,y:712,t:1527876739240};\\\", \\\"{x:1807,y:714,t:1527876739257};\\\", \\\"{x:1807,y:715,t:1527876739274};\\\", \\\"{x:1808,y:717,t:1527876739290};\\\", \\\"{x:1808,y:718,t:1527876739307};\\\", \\\"{x:1809,y:719,t:1527876739327};\\\", \\\"{x:1810,y:721,t:1527876739359};\\\", \\\"{x:1811,y:722,t:1527876739375};\\\", \\\"{x:1811,y:723,t:1527876739390};\\\", \\\"{x:1812,y:724,t:1527876739408};\\\", \\\"{x:1813,y:726,t:1527876739423};\\\", \\\"{x:1813,y:727,t:1527876739536};\\\", \\\"{x:1813,y:728,t:1527876739760};\\\", \\\"{x:1810,y:732,t:1527876739774};\\\", \\\"{x:1792,y:747,t:1527876739790};\\\", \\\"{x:1751,y:773,t:1527876739807};\\\", \\\"{x:1706,y:805,t:1527876739824};\\\", \\\"{x:1651,y:839,t:1527876739841};\\\", \\\"{x:1613,y:862,t:1527876739857};\\\", \\\"{x:1573,y:882,t:1527876739874};\\\", \\\"{x:1547,y:895,t:1527876739891};\\\", \\\"{x:1522,y:909,t:1527876739907};\\\", \\\"{x:1502,y:920,t:1527876739924};\\\", \\\"{x:1483,y:932,t:1527876739939};\\\", \\\"{x:1469,y:939,t:1527876739957};\\\", \\\"{x:1462,y:944,t:1527876739974};\\\", \\\"{x:1453,y:950,t:1527876739991};\\\", \\\"{x:1451,y:952,t:1527876740007};\\\", \\\"{x:1449,y:953,t:1527876740023};\\\", \\\"{x:1448,y:954,t:1527876740041};\\\", \\\"{x:1448,y:955,t:1527876740057};\\\", \\\"{x:1446,y:956,t:1527876740073};\\\", \\\"{x:1445,y:956,t:1527876740091};\\\", \\\"{x:1444,y:958,t:1527876740107};\\\", \\\"{x:1441,y:959,t:1527876740124};\\\", \\\"{x:1439,y:960,t:1527876740141};\\\", \\\"{x:1434,y:962,t:1527876740156};\\\", \\\"{x:1432,y:963,t:1527876740173};\\\", \\\"{x:1425,y:967,t:1527876740191};\\\", \\\"{x:1424,y:967,t:1527876740207};\\\", \\\"{x:1423,y:968,t:1527876740224};\\\", \\\"{x:1421,y:970,t:1527876740241};\\\", \\\"{x:1419,y:970,t:1527876740256};\\\", \\\"{x:1417,y:972,t:1527876740274};\\\", \\\"{x:1415,y:974,t:1527876740291};\\\", \\\"{x:1414,y:975,t:1527876740307};\\\", \\\"{x:1414,y:976,t:1527876740343};\\\", \\\"{x:1414,y:977,t:1527876740367};\\\", \\\"{x:1414,y:978,t:1527876740447};\\\", \\\"{x:1416,y:978,t:1527876740464};\\\", \\\"{x:1419,y:977,t:1527876740474};\\\", \\\"{x:1425,y:974,t:1527876740491};\\\", \\\"{x:1430,y:973,t:1527876740507};\\\", \\\"{x:1434,y:970,t:1527876740524};\\\", \\\"{x:1437,y:969,t:1527876740541};\\\", \\\"{x:1440,y:967,t:1527876740557};\\\", \\\"{x:1441,y:966,t:1527876740583};\\\", \\\"{x:1442,y:966,t:1527876740655};\\\", \\\"{x:1443,y:965,t:1527876740776};\\\", \\\"{x:1444,y:964,t:1527876740800};\\\", \\\"{x:1444,y:963,t:1527876740815};\\\", \\\"{x:1444,y:962,t:1527876740831};\\\", \\\"{x:1444,y:961,t:1527876740841};\\\", \\\"{x:1444,y:959,t:1527876740865};\\\", \\\"{x:1444,y:958,t:1527876740880};\\\", \\\"{x:1444,y:956,t:1527876740895};\\\", \\\"{x:1445,y:955,t:1527876740908};\\\", \\\"{x:1445,y:953,t:1527876740924};\\\", \\\"{x:1445,y:949,t:1527876740942};\\\", \\\"{x:1446,y:945,t:1527876740958};\\\", \\\"{x:1447,y:942,t:1527876740975};\\\", \\\"{x:1450,y:936,t:1527876740992};\\\", \\\"{x:1451,y:927,t:1527876741008};\\\", \\\"{x:1455,y:915,t:1527876741024};\\\", \\\"{x:1457,y:905,t:1527876741041};\\\", \\\"{x:1460,y:897,t:1527876741058};\\\", \\\"{x:1464,y:887,t:1527876741074};\\\", \\\"{x:1466,y:877,t:1527876741090};\\\", \\\"{x:1471,y:868,t:1527876741107};\\\", \\\"{x:1471,y:865,t:1527876741124};\\\", \\\"{x:1473,y:863,t:1527876741141};\\\", \\\"{x:1473,y:862,t:1527876741158};\\\", \\\"{x:1473,y:861,t:1527876741264};\\\", \\\"{x:1473,y:859,t:1527876741528};\\\", \\\"{x:1473,y:851,t:1527876741541};\\\", \\\"{x:1467,y:815,t:1527876741559};\\\", \\\"{x:1452,y:747,t:1527876741576};\\\", \\\"{x:1444,y:709,t:1527876741591};\\\", \\\"{x:1436,y:674,t:1527876741609};\\\", \\\"{x:1427,y:633,t:1527876741625};\\\", \\\"{x:1418,y:610,t:1527876741642};\\\", \\\"{x:1412,y:598,t:1527876741658};\\\", \\\"{x:1410,y:593,t:1527876741675};\\\", \\\"{x:1409,y:591,t:1527876741691};\\\", \\\"{x:1408,y:589,t:1527876741708};\\\", \\\"{x:1406,y:587,t:1527876741726};\\\", \\\"{x:1404,y:585,t:1527876741742};\\\", \\\"{x:1400,y:584,t:1527876741759};\\\", \\\"{x:1391,y:577,t:1527876741775};\\\", \\\"{x:1380,y:570,t:1527876741792};\\\", \\\"{x:1369,y:562,t:1527876741808};\\\", \\\"{x:1356,y:551,t:1527876741825};\\\", \\\"{x:1343,y:537,t:1527876741842};\\\", \\\"{x:1330,y:522,t:1527876741859};\\\", \\\"{x:1320,y:507,t:1527876741876};\\\", \\\"{x:1315,y:496,t:1527876741895};\\\", \\\"{x:1312,y:487,t:1527876741909};\\\", \\\"{x:1309,y:478,t:1527876741925};\\\", \\\"{x:1308,y:473,t:1527876741937};\\\", \\\"{x:1307,y:467,t:1527876741953};\\\", \\\"{x:1307,y:465,t:1527876741970};\\\", \\\"{x:1307,y:464,t:1527876741990};\\\", \\\"{x:1307,y:465,t:1527876742094};\\\", \\\"{x:1307,y:468,t:1527876742102};\\\", \\\"{x:1307,y:477,t:1527876742119};\\\", \\\"{x:1307,y:485,t:1527876742135};\\\", \\\"{x:1307,y:492,t:1527876742153};\\\", \\\"{x:1307,y:494,t:1527876742170};\\\", \\\"{x:1307,y:497,t:1527876742186};\\\", \\\"{x:1307,y:498,t:1527876742203};\\\", \\\"{x:1307,y:499,t:1527876742219};\\\", \\\"{x:1308,y:500,t:1527876742236};\\\", \\\"{x:1309,y:501,t:1527876742392};\\\", \\\"{x:1310,y:501,t:1527876742402};\\\", \\\"{x:1311,y:501,t:1527876742423};\\\", \\\"{x:1312,y:500,t:1527876742559};\\\", \\\"{x:1313,y:500,t:1527876742566};\\\", \\\"{x:1315,y:500,t:1527876742591};\\\", \\\"{x:1315,y:499,t:1527876742607};\\\", \\\"{x:1316,y:499,t:1527876742615};\\\", \\\"{x:1317,y:498,t:1527876744103};\\\", \\\"{x:1317,y:497,t:1527876746319};\\\", \\\"{x:1317,y:496,t:1527876746330};\\\", \\\"{x:1316,y:494,t:1527876746348};\\\", \\\"{x:1316,y:493,t:1527876746364};\\\", \\\"{x:1316,y:495,t:1527876746639};\\\", \\\"{x:1316,y:496,t:1527876746647};\\\", \\\"{x:1316,y:500,t:1527876746664};\\\", \\\"{x:1316,y:508,t:1527876746696};\\\", \\\"{x:1316,y:512,t:1527876746714};\\\", \\\"{x:1316,y:514,t:1527876746730};\\\", \\\"{x:1316,y:517,t:1527876746747};\\\", \\\"{x:1316,y:519,t:1527876746764};\\\", \\\"{x:1316,y:521,t:1527876746781};\\\", \\\"{x:1316,y:524,t:1527876746797};\\\", \\\"{x:1316,y:526,t:1527876746813};\\\", \\\"{x:1316,y:534,t:1527876746831};\\\", \\\"{x:1316,y:538,t:1527876746848};\\\", \\\"{x:1316,y:542,t:1527876746864};\\\", \\\"{x:1316,y:546,t:1527876746881};\\\", \\\"{x:1316,y:549,t:1527876746897};\\\", \\\"{x:1316,y:552,t:1527876746915};\\\", \\\"{x:1316,y:554,t:1527876746931};\\\", \\\"{x:1316,y:556,t:1527876746949};\\\", \\\"{x:1316,y:557,t:1527876746965};\\\", \\\"{x:1316,y:560,t:1527876746981};\\\", \\\"{x:1316,y:564,t:1527876746998};\\\", \\\"{x:1316,y:567,t:1527876747014};\\\", \\\"{x:1316,y:572,t:1527876747032};\\\", \\\"{x:1316,y:575,t:1527876747048};\\\", \\\"{x:1316,y:578,t:1527876747064};\\\", \\\"{x:1316,y:582,t:1527876747082};\\\", \\\"{x:1316,y:585,t:1527876747098};\\\", \\\"{x:1316,y:589,t:1527876747114};\\\", \\\"{x:1316,y:592,t:1527876747131};\\\", \\\"{x:1316,y:596,t:1527876747148};\\\", \\\"{x:1316,y:598,t:1527876747164};\\\", \\\"{x:1316,y:599,t:1527876747181};\\\", \\\"{x:1317,y:601,t:1527876747198};\\\", \\\"{x:1317,y:602,t:1527876747214};\\\", \\\"{x:1317,y:604,t:1527876747231};\\\", \\\"{x:1317,y:605,t:1527876747249};\\\", \\\"{x:1317,y:606,t:1527876747265};\\\", \\\"{x:1317,y:608,t:1527876747282};\\\", \\\"{x:1317,y:609,t:1527876747303};\\\", \\\"{x:1317,y:610,t:1527876747315};\\\", \\\"{x:1317,y:611,t:1527876747331};\\\", \\\"{x:1317,y:612,t:1527876747348};\\\", \\\"{x:1317,y:614,t:1527876747364};\\\", \\\"{x:1317,y:615,t:1527876747464};\\\", \\\"{x:1317,y:616,t:1527876747479};\\\", \\\"{x:1317,y:617,t:1527876747487};\\\", \\\"{x:1317,y:618,t:1527876747519};\\\", \\\"{x:1317,y:619,t:1527876747536};\\\", \\\"{x:1317,y:620,t:1527876747548};\\\", \\\"{x:1317,y:621,t:1527876747567};\\\", \\\"{x:1317,y:622,t:1527876747582};\\\", \\\"{x:1317,y:623,t:1527876747599};\\\", \\\"{x:1317,y:626,t:1527876747618};\\\", \\\"{x:1317,y:630,t:1527876747631};\\\", \\\"{x:1317,y:636,t:1527876747648};\\\", \\\"{x:1317,y:639,t:1527876747665};\\\", \\\"{x:1317,y:641,t:1527876747680};\\\", \\\"{x:1317,y:643,t:1527876747698};\\\", \\\"{x:1317,y:644,t:1527876747839};\\\", \\\"{x:1317,y:643,t:1527876747983};\\\", \\\"{x:1317,y:642,t:1527876748015};\\\", \\\"{x:1317,y:640,t:1527876748033};\\\", \\\"{x:1317,y:639,t:1527876748049};\\\", \\\"{x:1317,y:638,t:1527876748065};\\\", \\\"{x:1317,y:637,t:1527876748082};\\\", \\\"{x:1317,y:636,t:1527876748103};\\\", \\\"{x:1317,y:635,t:1527876748117};\\\", \\\"{x:1317,y:634,t:1527876748132};\\\", \\\"{x:1317,y:633,t:1527876748146};\\\", \\\"{x:1317,y:632,t:1527876748164};\\\", \\\"{x:1317,y:631,t:1527876748247};\\\", \\\"{x:1317,y:632,t:1527876749022};\\\", \\\"{x:1317,y:635,t:1527876749031};\\\", \\\"{x:1317,y:637,t:1527876749047};\\\", \\\"{x:1318,y:639,t:1527876749062};\\\", \\\"{x:1318,y:643,t:1527876749083};\\\", \\\"{x:1319,y:645,t:1527876749099};\\\", \\\"{x:1319,y:644,t:1527876749448};\\\", \\\"{x:1319,y:641,t:1527876749456};\\\", \\\"{x:1319,y:639,t:1527876749466};\\\", \\\"{x:1319,y:635,t:1527876749484};\\\", \\\"{x:1319,y:629,t:1527876749502};\\\", \\\"{x:1319,y:625,t:1527876749517};\\\", \\\"{x:1319,y:622,t:1527876749533};\\\", \\\"{x:1319,y:620,t:1527876749550};\\\", \\\"{x:1319,y:619,t:1527876749566};\\\", \\\"{x:1319,y:618,t:1527876749583};\\\", \\\"{x:1319,y:619,t:1527876749982};\\\", \\\"{x:1319,y:620,t:1527876749999};\\\", \\\"{x:1319,y:621,t:1527876750007};\\\", \\\"{x:1319,y:622,t:1527876750017};\\\", \\\"{x:1319,y:623,t:1527876750071};\\\", \\\"{x:1319,y:624,t:1527876750094};\\\", \\\"{x:1319,y:625,t:1527876750111};\\\", \\\"{x:1319,y:626,t:1527876750179};\\\", \\\"{x:1319,y:627,t:1527876750217};\\\", \\\"{x:1319,y:626,t:1527876751767};\\\", \\\"{x:1319,y:618,t:1527876751778};\\\", \\\"{x:1319,y:611,t:1527876751787};\\\", \\\"{x:1322,y:592,t:1527876751803};\\\", \\\"{x:1326,y:572,t:1527876751819};\\\", \\\"{x:1330,y:554,t:1527876751835};\\\", \\\"{x:1332,y:541,t:1527876751851};\\\", \\\"{x:1334,y:529,t:1527876751868};\\\", \\\"{x:1334,y:520,t:1527876751885};\\\", \\\"{x:1334,y:512,t:1527876751901};\\\", \\\"{x:1334,y:502,t:1527876751918};\\\", \\\"{x:1334,y:496,t:1527876751935};\\\", \\\"{x:1334,y:495,t:1527876752024};\\\", \\\"{x:1333,y:495,t:1527876752039};\\\", \\\"{x:1333,y:494,t:1527876752052};\\\", \\\"{x:1332,y:494,t:1527876752071};\\\", \\\"{x:1332,y:493,t:1527876752085};\\\", \\\"{x:1330,y:493,t:1527876752102};\\\", \\\"{x:1329,y:493,t:1527876752127};\\\", \\\"{x:1329,y:492,t:1527876752135};\\\", \\\"{x:1328,y:492,t:1527876752152};\\\", \\\"{x:1327,y:492,t:1527876752191};\\\", \\\"{x:1326,y:492,t:1527876752202};\\\", \\\"{x:1324,y:492,t:1527876752218};\\\", \\\"{x:1320,y:493,t:1527876752235};\\\", \\\"{x:1316,y:493,t:1527876752254};\\\", \\\"{x:1309,y:494,t:1527876752268};\\\", \\\"{x:1305,y:496,t:1527876752286};\\\", \\\"{x:1304,y:496,t:1527876752302};\\\", \\\"{x:1303,y:496,t:1527876752318};\\\", \\\"{x:1303,y:497,t:1527876752639};\\\", \\\"{x:1303,y:498,t:1527876752655};\\\", \\\"{x:1304,y:498,t:1527876752671};\\\", \\\"{x:1305,y:498,t:1527876752686};\\\", \\\"{x:1306,y:499,t:1527876752719};\\\", \\\"{x:1308,y:499,t:1527876752823};\\\", \\\"{x:1309,y:499,t:1527876752851};\\\", \\\"{x:1311,y:499,t:1527876752869};\\\", \\\"{x:1312,y:499,t:1527876752887};\\\", \\\"{x:1313,y:499,t:1527876752902};\\\", \\\"{x:1314,y:499,t:1527876752919};\\\", \\\"{x:1315,y:499,t:1527876753071};\\\", \\\"{x:1316,y:500,t:1527876753567};\\\", \\\"{x:1316,y:506,t:1527876753587};\\\", \\\"{x:1316,y:517,t:1527876753603};\\\", \\\"{x:1316,y:531,t:1527876753619};\\\", \\\"{x:1316,y:544,t:1527876753636};\\\", \\\"{x:1316,y:555,t:1527876753654};\\\", \\\"{x:1316,y:563,t:1527876753670};\\\", \\\"{x:1316,y:574,t:1527876753687};\\\", \\\"{x:1316,y:577,t:1527876753703};\\\", \\\"{x:1316,y:579,t:1527876753719};\\\", \\\"{x:1317,y:582,t:1527876753737};\\\", \\\"{x:1317,y:586,t:1527876753753};\\\", \\\"{x:1318,y:588,t:1527876753769};\\\", \\\"{x:1318,y:589,t:1527876753786};\\\", \\\"{x:1318,y:590,t:1527876753807};\\\", \\\"{x:1318,y:591,t:1527876753823};\\\", \\\"{x:1318,y:592,t:1527876753836};\\\", \\\"{x:1318,y:594,t:1527876753853};\\\", \\\"{x:1318,y:597,t:1527876753871};\\\", \\\"{x:1318,y:602,t:1527876753887};\\\", \\\"{x:1318,y:609,t:1527876753904};\\\", \\\"{x:1318,y:616,t:1527876753920};\\\", \\\"{x:1318,y:622,t:1527876753937};\\\", \\\"{x:1318,y:629,t:1527876753956};\\\", \\\"{x:1318,y:639,t:1527876753986};\\\", \\\"{x:1318,y:640,t:1527876754003};\\\", \\\"{x:1318,y:642,t:1527876754021};\\\", \\\"{x:1318,y:643,t:1527876754038};\\\", \\\"{x:1317,y:641,t:1527876754303};\\\", \\\"{x:1317,y:639,t:1527876754321};\\\", \\\"{x:1316,y:636,t:1527876754338};\\\", \\\"{x:1316,y:634,t:1527876754356};\\\", \\\"{x:1316,y:633,t:1527876754370};\\\", \\\"{x:1316,y:632,t:1527876754439};\\\", \\\"{x:1314,y:634,t:1527876755336};\\\", \\\"{x:1314,y:637,t:1527876755345};\\\", \\\"{x:1313,y:640,t:1527876755357};\\\", \\\"{x:1310,y:646,t:1527876755372};\\\", \\\"{x:1308,y:652,t:1527876755387};\\\", \\\"{x:1306,y:655,t:1527876755405};\\\", \\\"{x:1306,y:659,t:1527876755421};\\\", \\\"{x:1305,y:662,t:1527876755437};\\\", \\\"{x:1305,y:672,t:1527876755454};\\\", \\\"{x:1305,y:680,t:1527876755471};\\\", \\\"{x:1305,y:690,t:1527876755488};\\\", \\\"{x:1306,y:699,t:1527876755504};\\\", \\\"{x:1308,y:705,t:1527876755521};\\\", \\\"{x:1310,y:711,t:1527876755538};\\\", \\\"{x:1314,y:720,t:1527876755555};\\\", \\\"{x:1317,y:728,t:1527876755571};\\\", \\\"{x:1322,y:735,t:1527876755588};\\\", \\\"{x:1324,y:740,t:1527876755605};\\\", \\\"{x:1325,y:745,t:1527876755621};\\\", \\\"{x:1326,y:748,t:1527876755639};\\\", \\\"{x:1326,y:750,t:1527876755687};\\\", \\\"{x:1326,y:751,t:1527876755703};\\\", \\\"{x:1326,y:753,t:1527876755735};\\\", \\\"{x:1326,y:754,t:1527876755743};\\\", \\\"{x:1326,y:755,t:1527876755755};\\\", \\\"{x:1324,y:759,t:1527876755772};\\\", \\\"{x:1323,y:761,t:1527876755789};\\\", \\\"{x:1322,y:764,t:1527876755805};\\\", \\\"{x:1320,y:768,t:1527876755822};\\\", \\\"{x:1318,y:775,t:1527876755839};\\\", \\\"{x:1314,y:784,t:1527876755856};\\\", \\\"{x:1311,y:801,t:1527876755871};\\\", \\\"{x:1309,y:816,t:1527876755889};\\\", \\\"{x:1308,y:826,t:1527876755906};\\\", \\\"{x:1305,y:836,t:1527876755922};\\\", \\\"{x:1304,y:842,t:1527876755939};\\\", \\\"{x:1304,y:845,t:1527876755956};\\\", \\\"{x:1304,y:851,t:1527876755972};\\\", \\\"{x:1304,y:860,t:1527876755989};\\\", \\\"{x:1304,y:873,t:1527876756006};\\\", \\\"{x:1304,y:888,t:1527876756022};\\\", \\\"{x:1304,y:908,t:1527876756039};\\\", \\\"{x:1304,y:917,t:1527876756056};\\\", \\\"{x:1304,y:922,t:1527876756072};\\\", \\\"{x:1304,y:927,t:1527876756089};\\\", \\\"{x:1304,y:932,t:1527876756106};\\\", \\\"{x:1304,y:939,t:1527876756122};\\\", \\\"{x:1304,y:946,t:1527876756138};\\\", \\\"{x:1304,y:951,t:1527876756156};\\\", \\\"{x:1304,y:955,t:1527876756172};\\\", \\\"{x:1304,y:961,t:1527876756189};\\\", \\\"{x:1304,y:967,t:1527876756206};\\\", \\\"{x:1304,y:973,t:1527876756222};\\\", \\\"{x:1304,y:974,t:1527876756238};\\\", \\\"{x:1304,y:975,t:1527876756296};\\\", \\\"{x:1303,y:969,t:1527876756528};\\\", \\\"{x:1301,y:956,t:1527876756539};\\\", \\\"{x:1301,y:920,t:1527876756556};\\\", \\\"{x:1301,y:864,t:1527876756573};\\\", \\\"{x:1301,y:825,t:1527876756589};\\\", \\\"{x:1301,y:800,t:1527876756606};\\\", \\\"{x:1298,y:769,t:1527876756623};\\\", \\\"{x:1296,y:753,t:1527876756640};\\\", \\\"{x:1295,y:737,t:1527876756656};\\\", \\\"{x:1295,y:718,t:1527876756673};\\\", \\\"{x:1295,y:704,t:1527876756689};\\\", \\\"{x:1296,y:694,t:1527876756706};\\\", \\\"{x:1297,y:678,t:1527876756723};\\\", \\\"{x:1297,y:662,t:1527876756739};\\\", \\\"{x:1297,y:653,t:1527876756756};\\\", \\\"{x:1297,y:650,t:1527876756773};\\\", \\\"{x:1297,y:649,t:1527876756790};\\\", \\\"{x:1299,y:646,t:1527876756806};\\\", \\\"{x:1308,y:636,t:1527876756823};\\\", \\\"{x:1314,y:629,t:1527876756843};\\\", \\\"{x:1317,y:624,t:1527876756873};\\\", \\\"{x:1314,y:624,t:1527876756902};\\\", \\\"{x:1307,y:626,t:1527876756910};\\\", \\\"{x:1295,y:628,t:1527876756922};\\\", \\\"{x:1246,y:637,t:1527876756939};\\\", \\\"{x:1180,y:645,t:1527876756956};\\\", \\\"{x:1093,y:658,t:1527876756972};\\\", \\\"{x:1015,y:669,t:1527876756989};\\\", \\\"{x:921,y:683,t:1527876757005};\\\", \\\"{x:793,y:696,t:1527876757022};\\\", \\\"{x:711,y:700,t:1527876757041};\\\", \\\"{x:647,y:702,t:1527876757056};\\\", \\\"{x:586,y:702,t:1527876757072};\\\", \\\"{x:527,y:702,t:1527876757090};\\\", \\\"{x:469,y:698,t:1527876757106};\\\", \\\"{x:411,y:690,t:1527876757122};\\\", \\\"{x:376,y:686,t:1527876757139};\\\", \\\"{x:339,y:679,t:1527876757155};\\\", \\\"{x:302,y:672,t:1527876757172};\\\", \\\"{x:261,y:662,t:1527876757189};\\\", \\\"{x:223,y:652,t:1527876757205};\\\", \\\"{x:204,y:645,t:1527876757222};\\\", \\\"{x:203,y:644,t:1527876757239};\\\", \\\"{x:203,y:641,t:1527876757256};\\\", \\\"{x:211,y:630,t:1527876757272};\\\", \\\"{x:236,y:613,t:1527876757290};\\\", \\\"{x:285,y:587,t:1527876757305};\\\", \\\"{x:357,y:563,t:1527876757323};\\\", \\\"{x:449,y:550,t:1527876757340};\\\", \\\"{x:560,y:538,t:1527876757356};\\\", \\\"{x:679,y:520,t:1527876757372};\\\", \\\"{x:798,y:518,t:1527876757389};\\\", \\\"{x:925,y:514,t:1527876757406};\\\", \\\"{x:960,y:522,t:1527876757422};\\\", \\\"{x:970,y:527,t:1527876757439};\\\", \\\"{x:971,y:528,t:1527876757456};\\\", \\\"{x:971,y:530,t:1527876757473};\\\", \\\"{x:968,y:531,t:1527876757490};\\\", \\\"{x:961,y:536,t:1527876757506};\\\", \\\"{x:953,y:542,t:1527876757523};\\\", \\\"{x:945,y:549,t:1527876757539};\\\", \\\"{x:935,y:560,t:1527876757557};\\\", \\\"{x:925,y:568,t:1527876757573};\\\", \\\"{x:912,y:572,t:1527876757589};\\\", \\\"{x:892,y:577,t:1527876757606};\\\", \\\"{x:886,y:577,t:1527876757622};\\\", \\\"{x:882,y:577,t:1527876757639};\\\", \\\"{x:881,y:577,t:1527876757656};\\\", \\\"{x:880,y:577,t:1527876757674};\\\", \\\"{x:878,y:577,t:1527876757689};\\\", \\\"{x:876,y:578,t:1527876757707};\\\", \\\"{x:873,y:578,t:1527876757724};\\\", \\\"{x:870,y:578,t:1527876757739};\\\", \\\"{x:868,y:578,t:1527876757757};\\\", \\\"{x:866,y:578,t:1527876757773};\\\", \\\"{x:863,y:578,t:1527876757790};\\\", \\\"{x:860,y:577,t:1527876757806};\\\", \\\"{x:857,y:576,t:1527876757824};\\\", \\\"{x:853,y:575,t:1527876757839};\\\", \\\"{x:850,y:574,t:1527876757856};\\\", \\\"{x:849,y:574,t:1527876757873};\\\", \\\"{x:847,y:574,t:1527876758383};\\\", \\\"{x:843,y:574,t:1527876758391};\\\", \\\"{x:828,y:576,t:1527876758407};\\\", \\\"{x:804,y:584,t:1527876758424};\\\", \\\"{x:779,y:592,t:1527876758441};\\\", \\\"{x:751,y:605,t:1527876758457};\\\", \\\"{x:713,y:625,t:1527876758474};\\\", \\\"{x:669,y:654,t:1527876758490};\\\", \\\"{x:620,y:680,t:1527876758508};\\\", \\\"{x:577,y:698,t:1527876758524};\\\", \\\"{x:545,y:714,t:1527876758540};\\\", \\\"{x:518,y:724,t:1527876758558};\\\", \\\"{x:500,y:733,t:1527876758573};\\\", \\\"{x:493,y:738,t:1527876758591};\\\", \\\"{x:493,y:739,t:1527876758608};\\\", \\\"{x:492,y:740,t:1527876758623};\\\", \\\"{x:492,y:743,t:1527876758640};\\\", \\\"{x:490,y:747,t:1527876758658};\\\", \\\"{x:484,y:757,t:1527876758674};\\\", \\\"{x:483,y:764,t:1527876758691};\\\", \\\"{x:482,y:769,t:1527876758708};\\\", \\\"{x:482,y:771,t:1527876758725};\\\", \\\"{x:482,y:772,t:1527876758740};\\\", \\\"{x:482,y:774,t:1527876758757};\\\", \\\"{x:485,y:781,t:1527876758774};\\\", \\\"{x:487,y:785,t:1527876758790};\\\", \\\"{x:488,y:786,t:1527876758808};\\\", \\\"{x:488,y:784,t:1527876758985};\\\", \\\"{x:488,y:782,t:1527876758991};\\\", \\\"{x:488,y:775,t:1527876759007};\\\", \\\"{x:488,y:767,t:1527876759024};\\\", \\\"{x:489,y:765,t:1527876759041};\\\", \\\"{x:489,y:764,t:1527876759057};\\\", \\\"{x:489,y:763,t:1527876759074};\\\", \\\"{x:491,y:761,t:1527876759560};\\\", \\\"{x:491,y:760,t:1527876759639};\\\", \\\"{x:491,y:758,t:1527876759687};\\\", \\\"{x:491,y:757,t:1527876759720};\\\", \\\"{x:491,y:755,t:1527876759735};\\\", \\\"{x:491,y:754,t:1527876759751};\\\", \\\"{x:491,y:752,t:1527876760047};\\\", \\\"{x:492,y:752,t:1527876760143};\\\", \\\"{x:494,y:751,t:1527876760167};\\\", \\\"{x:495,y:750,t:1527876760199};\\\", \\\"{x:497,y:750,t:1527876760308};\\\", \\\"{x:498,y:749,t:1527876760325};\\\", \\\"{x:498,y:748,t:1527876760343};\\\" ] }, { \\\"rt\\\": 15272, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 10, \\\"time_elapsed\\\": 365740, \\\"internal_node_id\\\": \\\"0.0-6.0-0.0\\\", \\\"subject\\\": \\\"EER58\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration\\\", \\\"q\\\": 6, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 1, \\\"answer\\\": [ \\\"E\\\", \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-E -E -G -G -G -G -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:498,y:747,t:1527876760990};\\\", \\\"{x:500,y:747,t:1527876761002};\\\", \\\"{x:501,y:747,t:1527876761010};\\\", \\\"{x:503,y:748,t:1527876761025};\\\", \\\"{x:506,y:748,t:1527876761043};\\\", \\\"{x:507,y:749,t:1527876761060};\\\", \\\"{x:510,y:749,t:1527876761076};\\\", \\\"{x:512,y:751,t:1527876761092};\\\", \\\"{x:516,y:755,t:1527876761109};\\\", \\\"{x:519,y:759,t:1527876761126};\\\", \\\"{x:522,y:763,t:1527876761142};\\\", \\\"{x:525,y:765,t:1527876761159};\\\", \\\"{x:528,y:767,t:1527876761175};\\\", \\\"{x:530,y:767,t:1527876761192};\\\", \\\"{x:531,y:769,t:1527876761209};\\\", \\\"{x:534,y:770,t:1527876761225};\\\", \\\"{x:544,y:774,t:1527876761243};\\\", \\\"{x:564,y:776,t:1527876761260};\\\", \\\"{x:592,y:779,t:1527876761276};\\\", \\\"{x:632,y:781,t:1527876761293};\\\", \\\"{x:693,y:786,t:1527876761310};\\\", \\\"{x:766,y:789,t:1527876761326};\\\", \\\"{x:911,y:795,t:1527876761343};\\\", \\\"{x:1003,y:795,t:1527876761360};\\\", \\\"{x:1086,y:795,t:1527876761376};\\\", \\\"{x:1148,y:795,t:1527876761393};\\\", \\\"{x:1204,y:795,t:1527876761410};\\\", \\\"{x:1241,y:788,t:1527876761426};\\\", \\\"{x:1256,y:786,t:1527876761443};\\\", \\\"{x:1257,y:785,t:1527876761460};\\\", \\\"{x:1258,y:785,t:1527876761575};\\\", \\\"{x:1258,y:787,t:1527876761583};\\\", \\\"{x:1260,y:793,t:1527876761593};\\\", \\\"{x:1265,y:801,t:1527876761610};\\\", \\\"{x:1276,y:813,t:1527876761627};\\\", \\\"{x:1289,y:820,t:1527876761643};\\\", \\\"{x:1295,y:827,t:1527876761660};\\\", \\\"{x:1296,y:829,t:1527876761677};\\\", \\\"{x:1296,y:830,t:1527876762472};\\\", \\\"{x:1295,y:831,t:1527876762480};\\\", \\\"{x:1294,y:830,t:1527876762536};\\\", \\\"{x:1294,y:829,t:1527876762568};\\\", \\\"{x:1293,y:828,t:1527876762577};\\\", \\\"{x:1293,y:827,t:1527876762594};\\\", \\\"{x:1292,y:824,t:1527876762612};\\\", \\\"{x:1291,y:823,t:1527876762627};\\\", \\\"{x:1291,y:822,t:1527876762644};\\\", \\\"{x:1290,y:820,t:1527876762661};\\\", \\\"{x:1289,y:819,t:1527876762678};\\\", \\\"{x:1288,y:818,t:1527876762695};\\\", \\\"{x:1286,y:817,t:1527876762711};\\\", \\\"{x:1284,y:816,t:1527876762727};\\\", \\\"{x:1282,y:816,t:1527876762744};\\\", \\\"{x:1280,y:816,t:1527876762783};\\\", \\\"{x:1279,y:816,t:1527876762800};\\\", \\\"{x:1277,y:816,t:1527876762812};\\\", \\\"{x:1276,y:816,t:1527876762827};\\\", \\\"{x:1274,y:816,t:1527876762844};\\\", \\\"{x:1271,y:816,t:1527876762861};\\\", \\\"{x:1267,y:816,t:1527876762877};\\\", \\\"{x:1264,y:816,t:1527876762893};\\\", \\\"{x:1260,y:816,t:1527876762910};\\\", \\\"{x:1259,y:816,t:1527876762927};\\\", \\\"{x:1258,y:816,t:1527876762950};\\\", \\\"{x:1257,y:815,t:1527876762966};\\\", \\\"{x:1257,y:808,t:1527876762977};\\\", \\\"{x:1257,y:782,t:1527876762994};\\\", \\\"{x:1263,y:758,t:1527876763011};\\\", \\\"{x:1270,y:733,t:1527876763027};\\\", \\\"{x:1281,y:707,t:1527876763044};\\\", \\\"{x:1290,y:684,t:1527876763061};\\\", \\\"{x:1294,y:661,t:1527876763078};\\\", \\\"{x:1296,y:640,t:1527876763094};\\\", \\\"{x:1292,y:624,t:1527876763111};\\\", \\\"{x:1290,y:615,t:1527876763129};\\\", \\\"{x:1286,y:609,t:1527876763144};\\\", \\\"{x:1286,y:608,t:1527876763161};\\\", \\\"{x:1286,y:607,t:1527876763199};\\\", \\\"{x:1285,y:605,t:1527876763212};\\\", \\\"{x:1284,y:603,t:1527876763228};\\\", \\\"{x:1282,y:598,t:1527876763245};\\\", \\\"{x:1280,y:594,t:1527876763261};\\\", \\\"{x:1280,y:593,t:1527876763278};\\\", \\\"{x:1280,y:590,t:1527876763295};\\\", \\\"{x:1280,y:586,t:1527876763312};\\\", \\\"{x:1280,y:583,t:1527876763328};\\\", \\\"{x:1279,y:578,t:1527876763345};\\\", \\\"{x:1279,y:577,t:1527876763361};\\\", \\\"{x:1279,y:576,t:1527876763378};\\\", \\\"{x:1278,y:574,t:1527876763399};\\\", \\\"{x:1277,y:575,t:1527876763519};\\\", \\\"{x:1276,y:575,t:1527876763528};\\\", \\\"{x:1270,y:577,t:1527876763545};\\\", \\\"{x:1268,y:578,t:1527876763561};\\\", \\\"{x:1263,y:578,t:1527876763579};\\\", \\\"{x:1259,y:576,t:1527876763595};\\\", \\\"{x:1256,y:574,t:1527876763611};\\\", \\\"{x:1253,y:573,t:1527876763628};\\\", \\\"{x:1252,y:572,t:1527876763646};\\\", \\\"{x:1251,y:572,t:1527876763661};\\\", \\\"{x:1250,y:572,t:1527876763712};\\\", \\\"{x:1250,y:571,t:1527876763728};\\\", \\\"{x:1253,y:567,t:1527876763745};\\\", \\\"{x:1260,y:561,t:1527876763761};\\\", \\\"{x:1269,y:556,t:1527876763778};\\\", \\\"{x:1272,y:553,t:1527876763796};\\\", \\\"{x:1273,y:553,t:1527876763811};\\\", \\\"{x:1274,y:552,t:1527876763839};\\\", \\\"{x:1275,y:552,t:1527876763855};\\\", \\\"{x:1276,y:552,t:1527876763920};\\\", \\\"{x:1278,y:552,t:1527876763935};\\\", \\\"{x:1279,y:551,t:1527876763951};\\\", \\\"{x:1281,y:551,t:1527876763975};\\\", \\\"{x:1282,y:551,t:1527876763991};\\\", \\\"{x:1284,y:551,t:1527876764016};\\\", \\\"{x:1284,y:553,t:1527876764031};\\\", \\\"{x:1285,y:554,t:1527876764046};\\\", \\\"{x:1285,y:555,t:1527876764062};\\\", \\\"{x:1285,y:556,t:1527876764078};\\\", \\\"{x:1285,y:557,t:1527876764360};\\\", \\\"{x:1285,y:558,t:1527876764375};\\\", \\\"{x:1285,y:560,t:1527876764393};\\\", \\\"{x:1284,y:561,t:1527876764430};\\\", \\\"{x:1284,y:562,t:1527876764462};\\\", \\\"{x:1283,y:563,t:1527876764495};\\\", \\\"{x:1282,y:565,t:1527876764512};\\\", \\\"{x:1281,y:566,t:1527876764528};\\\", \\\"{x:1279,y:568,t:1527876764545};\\\", \\\"{x:1278,y:568,t:1527876764615};\\\", \\\"{x:1279,y:568,t:1527876764751};\\\", \\\"{x:1279,y:567,t:1527876764762};\\\", \\\"{x:1280,y:566,t:1527876764779};\\\", \\\"{x:1280,y:564,t:1527876764795};\\\", \\\"{x:1281,y:564,t:1527876764863};\\\", \\\"{x:1281,y:563,t:1527876765223};\\\", \\\"{x:1279,y:563,t:1527876765239};\\\", \\\"{x:1278,y:563,t:1527876765247};\\\", \\\"{x:1275,y:562,t:1527876765263};\\\", \\\"{x:1272,y:562,t:1527876765278};\\\", \\\"{x:1268,y:560,t:1527876765296};\\\", \\\"{x:1267,y:560,t:1527876765312};\\\", \\\"{x:1265,y:560,t:1527876765330};\\\", \\\"{x:1262,y:560,t:1527876765346};\\\", \\\"{x:1256,y:561,t:1527876765362};\\\", \\\"{x:1249,y:562,t:1527876765380};\\\", \\\"{x:1240,y:563,t:1527876765396};\\\", \\\"{x:1231,y:565,t:1527876765413};\\\", \\\"{x:1214,y:569,t:1527876765429};\\\", \\\"{x:1186,y:574,t:1527876765447};\\\", \\\"{x:1145,y:580,t:1527876765463};\\\", \\\"{x:1118,y:580,t:1527876765479};\\\", \\\"{x:1102,y:580,t:1527876765496};\\\", \\\"{x:1100,y:580,t:1527876765514};\\\", \\\"{x:1104,y:579,t:1527876765583};\\\", \\\"{x:1113,y:576,t:1527876765596};\\\", \\\"{x:1149,y:569,t:1527876765613};\\\", \\\"{x:1206,y:565,t:1527876765630};\\\", \\\"{x:1269,y:562,t:1527876765646};\\\", \\\"{x:1380,y:562,t:1527876765663};\\\", \\\"{x:1433,y:562,t:1527876765679};\\\", \\\"{x:1462,y:562,t:1527876765696};\\\", \\\"{x:1468,y:562,t:1527876765713};\\\", \\\"{x:1466,y:562,t:1527876766087};\\\", \\\"{x:1463,y:562,t:1527876766096};\\\", \\\"{x:1454,y:562,t:1527876766114};\\\", \\\"{x:1442,y:565,t:1527876766130};\\\", \\\"{x:1430,y:566,t:1527876766146};\\\", \\\"{x:1421,y:567,t:1527876766164};\\\", \\\"{x:1415,y:567,t:1527876766181};\\\", \\\"{x:1409,y:567,t:1527876766197};\\\", \\\"{x:1407,y:567,t:1527876766213};\\\", \\\"{x:1408,y:567,t:1527876766432};\\\", \\\"{x:1409,y:567,t:1527876766448};\\\", \\\"{x:1412,y:567,t:1527876766464};\\\", \\\"{x:1413,y:567,t:1527876766497};\\\", \\\"{x:1413,y:566,t:1527876766513};\\\", \\\"{x:1414,y:566,t:1527876766543};\\\", \\\"{x:1415,y:565,t:1527876766615};\\\", \\\"{x:1410,y:566,t:1527876767118};\\\", \\\"{x:1399,y:567,t:1527876767130};\\\", \\\"{x:1373,y:569,t:1527876767147};\\\", \\\"{x:1342,y:573,t:1527876767164};\\\", \\\"{x:1312,y:573,t:1527876767180};\\\", \\\"{x:1285,y:574,t:1527876767197};\\\", \\\"{x:1264,y:574,t:1527876767214};\\\", \\\"{x:1242,y:574,t:1527876767230};\\\", \\\"{x:1233,y:574,t:1527876767247};\\\", \\\"{x:1230,y:574,t:1527876767264};\\\", \\\"{x:1231,y:574,t:1527876767422};\\\", \\\"{x:1234,y:574,t:1527876767446};\\\", \\\"{x:1236,y:573,t:1527876767447};\\\", \\\"{x:1243,y:572,t:1527876767464};\\\", \\\"{x:1256,y:569,t:1527876767481};\\\", \\\"{x:1272,y:567,t:1527876767497};\\\", \\\"{x:1296,y:563,t:1527876767514};\\\", \\\"{x:1318,y:562,t:1527876767531};\\\", \\\"{x:1342,y:562,t:1527876767547};\\\", \\\"{x:1364,y:562,t:1527876767564};\\\", \\\"{x:1380,y:561,t:1527876767581};\\\", \\\"{x:1397,y:561,t:1527876767597};\\\", \\\"{x:1405,y:561,t:1527876767614};\\\", \\\"{x:1416,y:561,t:1527876767632};\\\", \\\"{x:1422,y:560,t:1527876767648};\\\", \\\"{x:1429,y:558,t:1527876767664};\\\", \\\"{x:1434,y:558,t:1527876767681};\\\", \\\"{x:1439,y:558,t:1527876767697};\\\", \\\"{x:1441,y:558,t:1527876767714};\\\", \\\"{x:1442,y:558,t:1527876767731};\\\", \\\"{x:1443,y:558,t:1527876767751};\\\", \\\"{x:1444,y:558,t:1527876767767};\\\", \\\"{x:1445,y:558,t:1527876767782};\\\", \\\"{x:1447,y:558,t:1527876767799};\\\", \\\"{x:1448,y:558,t:1527876767815};\\\", \\\"{x:1449,y:558,t:1527876767878};\\\", \\\"{x:1447,y:558,t:1527876767951};\\\", \\\"{x:1446,y:558,t:1527876767965};\\\", \\\"{x:1443,y:558,t:1527876767981};\\\", \\\"{x:1438,y:558,t:1527876767999};\\\", \\\"{x:1435,y:558,t:1527876768015};\\\", \\\"{x:1428,y:558,t:1527876768031};\\\", \\\"{x:1425,y:558,t:1527876768050};\\\", \\\"{x:1422,y:558,t:1527876768073};\\\", \\\"{x:1421,y:558,t:1527876768081};\\\", \\\"{x:1419,y:558,t:1527876768097};\\\", \\\"{x:1418,y:559,t:1527876768167};\\\", \\\"{x:1417,y:559,t:1527876768181};\\\", \\\"{x:1410,y:561,t:1527876768198};\\\", \\\"{x:1397,y:563,t:1527876768214};\\\", \\\"{x:1370,y:567,t:1527876768232};\\\", \\\"{x:1344,y:569,t:1527876768248};\\\", \\\"{x:1311,y:574,t:1527876768265};\\\", \\\"{x:1281,y:579,t:1527876768281};\\\", \\\"{x:1253,y:580,t:1527876768298};\\\", \\\"{x:1232,y:580,t:1527876768315};\\\", \\\"{x:1220,y:580,t:1527876768331};\\\", \\\"{x:1218,y:580,t:1527876768349};\\\", \\\"{x:1217,y:580,t:1527876768424};\\\", \\\"{x:1215,y:581,t:1527876768431};\\\", \\\"{x:1207,y:582,t:1527876768449};\\\", \\\"{x:1193,y:583,t:1527876768465};\\\", \\\"{x:1175,y:583,t:1527876768482};\\\", \\\"{x:1148,y:583,t:1527876768498};\\\", \\\"{x:1121,y:583,t:1527876768515};\\\", \\\"{x:1096,y:583,t:1527876768531};\\\", \\\"{x:1076,y:583,t:1527876768548};\\\", \\\"{x:1068,y:583,t:1527876768565};\\\", \\\"{x:1067,y:583,t:1527876768623};\\\", \\\"{x:1073,y:583,t:1527876768751};\\\", \\\"{x:1084,y:580,t:1527876768765};\\\", \\\"{x:1108,y:577,t:1527876768783};\\\", \\\"{x:1144,y:574,t:1527876768799};\\\", \\\"{x:1214,y:574,t:1527876768815};\\\", \\\"{x:1266,y:571,t:1527876768832};\\\", \\\"{x:1319,y:571,t:1527876768849};\\\", \\\"{x:1362,y:570,t:1527876768865};\\\", \\\"{x:1393,y:570,t:1527876768883};\\\", \\\"{x:1415,y:570,t:1527876768899};\\\", \\\"{x:1427,y:569,t:1527876768916};\\\", \\\"{x:1430,y:569,t:1527876768933};\\\", \\\"{x:1431,y:569,t:1527876768975};\\\", \\\"{x:1431,y:568,t:1527876768992};\\\", \\\"{x:1432,y:568,t:1527876768999};\\\", \\\"{x:1434,y:567,t:1527876769015};\\\", \\\"{x:1428,y:568,t:1527876769723};\\\", \\\"{x:1417,y:571,t:1527876769736};\\\", \\\"{x:1379,y:575,t:1527876769753};\\\", \\\"{x:1315,y:585,t:1527876769770};\\\", \\\"{x:1226,y:598,t:1527876769786};\\\", \\\"{x:1082,y:610,t:1527876769803};\\\", \\\"{x:973,y:612,t:1527876769820};\\\", \\\"{x:876,y:612,t:1527876769837};\\\", \\\"{x:793,y:612,t:1527876769853};\\\", \\\"{x:737,y:612,t:1527876769870};\\\", \\\"{x:703,y:608,t:1527876769885};\\\", \\\"{x:681,y:604,t:1527876769903};\\\", \\\"{x:670,y:599,t:1527876769919};\\\", \\\"{x:663,y:593,t:1527876769938};\\\", \\\"{x:660,y:587,t:1527876769953};\\\", \\\"{x:651,y:572,t:1527876769969};\\\", \\\"{x:646,y:562,t:1527876769986};\\\", \\\"{x:637,y:551,t:1527876770004};\\\", \\\"{x:628,y:544,t:1527876770021};\\\", \\\"{x:623,y:540,t:1527876770036};\\\", \\\"{x:622,y:539,t:1527876770053};\\\", \\\"{x:621,y:537,t:1527876770069};\\\", \\\"{x:620,y:534,t:1527876770086};\\\", \\\"{x:620,y:528,t:1527876770103};\\\", \\\"{x:617,y:519,t:1527876770120};\\\", \\\"{x:616,y:514,t:1527876770136};\\\", \\\"{x:612,y:505,t:1527876770153};\\\", \\\"{x:609,y:498,t:1527876770169};\\\", \\\"{x:606,y:492,t:1527876770186};\\\", \\\"{x:603,y:488,t:1527876770204};\\\", \\\"{x:601,y:485,t:1527876770226};\\\", \\\"{x:601,y:484,t:1527876770274};\\\", \\\"{x:600,y:484,t:1527876770287};\\\", \\\"{x:602,y:484,t:1527876770521};\\\", \\\"{x:606,y:487,t:1527876770529};\\\", \\\"{x:609,y:492,t:1527876770538};\\\", \\\"{x:613,y:499,t:1527876770556};\\\", \\\"{x:614,y:502,t:1527876770570};\\\", \\\"{x:616,y:503,t:1527876770587};\\\", \\\"{x:622,y:507,t:1527876771226};\\\", \\\"{x:635,y:509,t:1527876771238};\\\", \\\"{x:682,y:518,t:1527876771255};\\\", \\\"{x:743,y:526,t:1527876771273};\\\", \\\"{x:839,y:545,t:1527876771287};\\\", \\\"{x:929,y:565,t:1527876771305};\\\", \\\"{x:1018,y:579,t:1527876771322};\\\", \\\"{x:1037,y:584,t:1527876771338};\\\", \\\"{x:1040,y:584,t:1527876771354};\\\", \\\"{x:1035,y:584,t:1527876771474};\\\", \\\"{x:1027,y:583,t:1527876771488};\\\", \\\"{x:1009,y:583,t:1527876771505};\\\", \\\"{x:994,y:581,t:1527876771522};\\\", \\\"{x:977,y:578,t:1527876771538};\\\", \\\"{x:953,y:572,t:1527876771555};\\\", \\\"{x:932,y:569,t:1527876771573};\\\", \\\"{x:919,y:565,t:1527876771588};\\\", \\\"{x:915,y:563,t:1527876771605};\\\", \\\"{x:909,y:561,t:1527876771622};\\\", \\\"{x:905,y:559,t:1527876771638};\\\", \\\"{x:902,y:558,t:1527876771654};\\\", \\\"{x:900,y:558,t:1527876771672};\\\", \\\"{x:899,y:558,t:1527876771688};\\\", \\\"{x:896,y:557,t:1527876771704};\\\", \\\"{x:891,y:556,t:1527876771721};\\\", \\\"{x:882,y:555,t:1527876771738};\\\", \\\"{x:871,y:554,t:1527876771754};\\\", \\\"{x:860,y:553,t:1527876771771};\\\", \\\"{x:854,y:553,t:1527876771788};\\\", \\\"{x:851,y:553,t:1527876771805};\\\", \\\"{x:847,y:551,t:1527876771821};\\\", \\\"{x:843,y:551,t:1527876771839};\\\", \\\"{x:841,y:551,t:1527876771855};\\\", \\\"{x:837,y:549,t:1527876771871};\\\", \\\"{x:849,y:549,t:1527876772819};\\\", \\\"{x:871,y:549,t:1527876772827};\\\", \\\"{x:894,y:549,t:1527876772838};\\\", \\\"{x:958,y:549,t:1527876772856};\\\", \\\"{x:1036,y:549,t:1527876772873};\\\", \\\"{x:1105,y:549,t:1527876772888};\\\", \\\"{x:1183,y:549,t:1527876772905};\\\", \\\"{x:1228,y:549,t:1527876772921};\\\", \\\"{x:1255,y:549,t:1527876772939};\\\", \\\"{x:1270,y:549,t:1527876772956};\\\", \\\"{x:1277,y:549,t:1527876772973};\\\", \\\"{x:1279,y:549,t:1527876772988};\\\", \\\"{x:1280,y:549,t:1527876773010};\\\", \\\"{x:1282,y:549,t:1527876773022};\\\", \\\"{x:1285,y:549,t:1527876773038};\\\", \\\"{x:1291,y:551,t:1527876773055};\\\", \\\"{x:1296,y:552,t:1527876773073};\\\", \\\"{x:1301,y:554,t:1527876773088};\\\", \\\"{x:1302,y:554,t:1527876773106};\\\", \\\"{x:1302,y:556,t:1527876773275};\\\", \\\"{x:1291,y:560,t:1527876773291};\\\", \\\"{x:1268,y:566,t:1527876773306};\\\", \\\"{x:1215,y:578,t:1527876773323};\\\", \\\"{x:1132,y:589,t:1527876773340};\\\", \\\"{x:1018,y:603,t:1527876773356};\\\", \\\"{x:897,y:620,t:1527876773374};\\\", \\\"{x:769,y:639,t:1527876773390};\\\", \\\"{x:659,y:651,t:1527876773407};\\\", \\\"{x:551,y:663,t:1527876773422};\\\", \\\"{x:490,y:671,t:1527876773439};\\\", \\\"{x:461,y:677,t:1527876773456};\\\", \\\"{x:447,y:682,t:1527876773472};\\\", \\\"{x:436,y:697,t:1527876773490};\\\", \\\"{x:435,y:708,t:1527876773505};\\\", \\\"{x:432,y:717,t:1527876773522};\\\", \\\"{x:430,y:729,t:1527876773539};\\\", \\\"{x:426,y:739,t:1527876773556};\\\", \\\"{x:423,y:748,t:1527876773572};\\\", \\\"{x:422,y:754,t:1527876773590};\\\", \\\"{x:422,y:755,t:1527876773607};\\\", \\\"{x:422,y:756,t:1527876773623};\\\", \\\"{x:422,y:757,t:1527876773640};\\\", \\\"{x:422,y:758,t:1527876773657};\\\", \\\"{x:422,y:759,t:1527876773674};\\\", \\\"{x:422,y:760,t:1527876773690};\\\", \\\"{x:422,y:761,t:1527876773707};\\\", \\\"{x:423,y:762,t:1527876773826};\\\", \\\"{x:430,y:762,t:1527876773840};\\\", \\\"{x:443,y:762,t:1527876773857};\\\", \\\"{x:460,y:762,t:1527876773873};\\\", \\\"{x:482,y:761,t:1527876773890};\\\", \\\"{x:498,y:759,t:1527876773906};\\\", \\\"{x:504,y:758,t:1527876773923};\\\", \\\"{x:506,y:757,t:1527876773940};\\\", \\\"{x:507,y:753,t:1527876774436};\\\", \\\"{x:509,y:748,t:1527876774457};\\\", \\\"{x:509,y:744,t:1527876774472};\\\", \\\"{x:511,y:738,t:1527876774490};\\\", \\\"{x:513,y:736,t:1527876774505};\\\", \\\"{x:513,y:734,t:1527876776507};\\\" ] }, { \\\"rt\\\": 40815, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 11, \\\"time_elapsed\\\": 407869, \\\"internal_node_id\\\": \\\"0.0-6.0-1.0\\\", \\\"subject\\\": \\\"EER58\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+starts\\\", \\\"q\\\": 7, \\\"clicks\\\": 2.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\", \\\"O\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-2-F -09 AM-08 AM-I -09 AM-F -F -F -B -B -B -B -M -12 PM-M -M -X -X -H -H -O -X -X -X -O -X -O -O -O -01 PM-O -O -O -X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:515,y:734,t:1527876777181};\\\", \\\"{x:516,y:734,t:1527876777226};\\\", \\\"{x:518,y:732,t:1527876779346};\\\", \\\"{x:519,y:732,t:1527876779359};\\\", \\\"{x:519,y:731,t:1527876779376};\\\", \\\"{x:520,y:730,t:1527876779467};\\\", \\\"{x:521,y:729,t:1527876779482};\\\", \\\"{x:522,y:729,t:1527876779498};\\\", \\\"{x:524,y:728,t:1527876779730};\\\", \\\"{x:537,y:728,t:1527876779742};\\\", \\\"{x:578,y:728,t:1527876779760};\\\", \\\"{x:637,y:728,t:1527876779775};\\\", \\\"{x:687,y:728,t:1527876779792};\\\", \\\"{x:747,y:737,t:1527876779810};\\\", \\\"{x:768,y:743,t:1527876779827};\\\", \\\"{x:777,y:748,t:1527876779845};\\\", \\\"{x:780,y:751,t:1527876779861};\\\", \\\"{x:781,y:751,t:1527876779878};\\\", \\\"{x:783,y:754,t:1527876779894};\\\", \\\"{x:792,y:759,t:1527876779911};\\\", \\\"{x:816,y:765,t:1527876779928};\\\", \\\"{x:863,y:777,t:1527876779944};\\\", \\\"{x:964,y:798,t:1527876779961};\\\", \\\"{x:1022,y:811,t:1527876779978};\\\", \\\"{x:1059,y:823,t:1527876779995};\\\", \\\"{x:1085,y:831,t:1527876780012};\\\", \\\"{x:1095,y:836,t:1527876780028};\\\", \\\"{x:1095,y:837,t:1527876780045};\\\", \\\"{x:1096,y:838,t:1527876780062};\\\", \\\"{x:1096,y:841,t:1527876780078};\\\", \\\"{x:1097,y:846,t:1527876780094};\\\", \\\"{x:1097,y:853,t:1527876780112};\\\", \\\"{x:1097,y:860,t:1527876780127};\\\", \\\"{x:1097,y:866,t:1527876780144};\\\", \\\"{x:1100,y:873,t:1527876780161};\\\", \\\"{x:1100,y:875,t:1527876780179};\\\", \\\"{x:1100,y:876,t:1527876780194};\\\", \\\"{x:1100,y:877,t:1527876780233};\\\", \\\"{x:1100,y:874,t:1527876780362};\\\", \\\"{x:1099,y:860,t:1527876780379};\\\", \\\"{x:1096,y:847,t:1527876780394};\\\", \\\"{x:1093,y:836,t:1527876780413};\\\", \\\"{x:1087,y:821,t:1527876780429};\\\", \\\"{x:1085,y:814,t:1527876780445};\\\", \\\"{x:1084,y:810,t:1527876780462};\\\", \\\"{x:1082,y:804,t:1527876780479};\\\", \\\"{x:1082,y:796,t:1527876780495};\\\", \\\"{x:1082,y:785,t:1527876780512};\\\", \\\"{x:1081,y:778,t:1527876780529};\\\", \\\"{x:1081,y:771,t:1527876780546};\\\", \\\"{x:1081,y:765,t:1527876780563};\\\", \\\"{x:1082,y:760,t:1527876780579};\\\", \\\"{x:1084,y:752,t:1527876780597};\\\", \\\"{x:1087,y:746,t:1527876780612};\\\", \\\"{x:1091,y:736,t:1527876780629};\\\", \\\"{x:1096,y:725,t:1527876780647};\\\", \\\"{x:1097,y:717,t:1527876780662};\\\", \\\"{x:1100,y:706,t:1527876780680};\\\", \\\"{x:1100,y:699,t:1527876780697};\\\", \\\"{x:1100,y:689,t:1527876780712};\\\", \\\"{x:1100,y:682,t:1527876780729};\\\", \\\"{x:1100,y:675,t:1527876780747};\\\", \\\"{x:1100,y:670,t:1527876780762};\\\", \\\"{x:1100,y:667,t:1527876780780};\\\", \\\"{x:1100,y:663,t:1527876780796};\\\", \\\"{x:1100,y:660,t:1527876780812};\\\", \\\"{x:1100,y:655,t:1527876780829};\\\", \\\"{x:1099,y:649,t:1527876780846};\\\", \\\"{x:1098,y:643,t:1527876780863};\\\", \\\"{x:1097,y:636,t:1527876780878};\\\", \\\"{x:1096,y:631,t:1527876780896};\\\", \\\"{x:1094,y:625,t:1527876780911};\\\", \\\"{x:1094,y:624,t:1527876780929};\\\", \\\"{x:1092,y:622,t:1527876780946};\\\", \\\"{x:1092,y:621,t:1527876780970};\\\", \\\"{x:1091,y:620,t:1527876781019};\\\", \\\"{x:1090,y:619,t:1527876781051};\\\", \\\"{x:1089,y:618,t:1527876781064};\\\", \\\"{x:1088,y:617,t:1527876781079};\\\", \\\"{x:1086,y:616,t:1527876781096};\\\", \\\"{x:1085,y:615,t:1527876781113};\\\", \\\"{x:1084,y:615,t:1527876781130};\\\", \\\"{x:1083,y:615,t:1527876781147};\\\", \\\"{x:1083,y:614,t:1527876781178};\\\", \\\"{x:1082,y:614,t:1527876781507};\\\", \\\"{x:1082,y:615,t:1527876781547};\\\", \\\"{x:1082,y:616,t:1527876781570};\\\", \\\"{x:1082,y:618,t:1527876781580};\\\", \\\"{x:1082,y:619,t:1527876781598};\\\", \\\"{x:1081,y:622,t:1527876781613};\\\", \\\"{x:1080,y:623,t:1527876781631};\\\", \\\"{x:1080,y:624,t:1527876781648};\\\", \\\"{x:1079,y:625,t:1527876781664};\\\", \\\"{x:1079,y:626,t:1527876781680};\\\", \\\"{x:1079,y:629,t:1527876782050};\\\", \\\"{x:1079,y:633,t:1527876782064};\\\", \\\"{x:1079,y:641,t:1527876782081};\\\", \\\"{x:1080,y:647,t:1527876782097};\\\", \\\"{x:1082,y:652,t:1527876782114};\\\", \\\"{x:1082,y:657,t:1527876782130};\\\", \\\"{x:1082,y:659,t:1527876782147};\\\", \\\"{x:1083,y:661,t:1527876782164};\\\", \\\"{x:1083,y:663,t:1527876782180};\\\", \\\"{x:1083,y:664,t:1527876782198};\\\", \\\"{x:1083,y:668,t:1527876782214};\\\", \\\"{x:1083,y:672,t:1527876782230};\\\", \\\"{x:1083,y:676,t:1527876782248};\\\", \\\"{x:1083,y:678,t:1527876782264};\\\", \\\"{x:1083,y:680,t:1527876782282};\\\", \\\"{x:1083,y:683,t:1527876782298};\\\", \\\"{x:1083,y:685,t:1527876782314};\\\", \\\"{x:1083,y:687,t:1527876782331};\\\", \\\"{x:1083,y:688,t:1527876782348};\\\", \\\"{x:1082,y:688,t:1527876782370};\\\", \\\"{x:1082,y:689,t:1527876782410};\\\", \\\"{x:1081,y:690,t:1527876782418};\\\", \\\"{x:1080,y:690,t:1527876782432};\\\", \\\"{x:1079,y:693,t:1527876782447};\\\", \\\"{x:1078,y:694,t:1527876782465};\\\", \\\"{x:1077,y:696,t:1527876782481};\\\", \\\"{x:1076,y:698,t:1527876786811};\\\", \\\"{x:1076,y:699,t:1527876786819};\\\", \\\"{x:1076,y:703,t:1527876786835};\\\", \\\"{x:1076,y:705,t:1527876786852};\\\", \\\"{x:1076,y:707,t:1527876786868};\\\", \\\"{x:1076,y:709,t:1527876786884};\\\", \\\"{x:1076,y:710,t:1527876786902};\\\", \\\"{x:1076,y:714,t:1527876786918};\\\", \\\"{x:1076,y:720,t:1527876786935};\\\", \\\"{x:1076,y:723,t:1527876786952};\\\", \\\"{x:1076,y:728,t:1527876786969};\\\", \\\"{x:1076,y:731,t:1527876786985};\\\", \\\"{x:1076,y:738,t:1527876787002};\\\", \\\"{x:1076,y:742,t:1527876787019};\\\", \\\"{x:1076,y:748,t:1527876787036};\\\", \\\"{x:1076,y:750,t:1527876787052};\\\", \\\"{x:1074,y:754,t:1527876787070};\\\", \\\"{x:1074,y:756,t:1527876787086};\\\", \\\"{x:1074,y:757,t:1527876787103};\\\", \\\"{x:1074,y:759,t:1527876787122};\\\", \\\"{x:1073,y:759,t:1527876787136};\\\", \\\"{x:1072,y:761,t:1527876787154};\\\", \\\"{x:1072,y:762,t:1527876787170};\\\", \\\"{x:1072,y:763,t:1527876787475};\\\", \\\"{x:1072,y:764,t:1527876787486};\\\", \\\"{x:1078,y:766,t:1527876787503};\\\", \\\"{x:1083,y:767,t:1527876787520};\\\", \\\"{x:1086,y:767,t:1527876787536};\\\", \\\"{x:1088,y:767,t:1527876787553};\\\", \\\"{x:1086,y:767,t:1527876788186};\\\", \\\"{x:1085,y:767,t:1527876788250};\\\", \\\"{x:1084,y:767,t:1527876788282};\\\", \\\"{x:1082,y:766,t:1527876788803};\\\", \\\"{x:1081,y:765,t:1527876789081};\\\", \\\"{x:1080,y:763,t:1527876789097};\\\", \\\"{x:1080,y:762,t:1527876789113};\\\", \\\"{x:1079,y:761,t:1527876789129};\\\", \\\"{x:1079,y:760,t:1527876789145};\\\", \\\"{x:1079,y:759,t:1527876789154};\\\", \\\"{x:1079,y:758,t:1527876789171};\\\", \\\"{x:1079,y:756,t:1527876789188};\\\", \\\"{x:1079,y:751,t:1527876789205};\\\", \\\"{x:1079,y:746,t:1527876789221};\\\", \\\"{x:1079,y:741,t:1527876789237};\\\", \\\"{x:1079,y:738,t:1527876789254};\\\", \\\"{x:1079,y:733,t:1527876789272};\\\", \\\"{x:1079,y:727,t:1527876789288};\\\", \\\"{x:1079,y:720,t:1527876789304};\\\", \\\"{x:1079,y:714,t:1527876789322};\\\", \\\"{x:1081,y:707,t:1527876789338};\\\", \\\"{x:1083,y:703,t:1527876789354};\\\", \\\"{x:1084,y:699,t:1527876789371};\\\", \\\"{x:1087,y:697,t:1527876789388};\\\", \\\"{x:1087,y:696,t:1527876789405};\\\", \\\"{x:1088,y:695,t:1527876789442};\\\", \\\"{x:1088,y:694,t:1527876789458};\\\", \\\"{x:1088,y:693,t:1527876789482};\\\", \\\"{x:1095,y:693,t:1527876790771};\\\", \\\"{x:1107,y:693,t:1527876790778};\\\", \\\"{x:1117,y:693,t:1527876790790};\\\", \\\"{x:1142,y:693,t:1527876790807};\\\", \\\"{x:1174,y:693,t:1527876790824};\\\", \\\"{x:1217,y:693,t:1527876790839};\\\", \\\"{x:1253,y:689,t:1527876790857};\\\", \\\"{x:1276,y:686,t:1527876790873};\\\", \\\"{x:1298,y:682,t:1527876790890};\\\", \\\"{x:1303,y:680,t:1527876790906};\\\", \\\"{x:1304,y:680,t:1527876790923};\\\", \\\"{x:1305,y:679,t:1527876790939};\\\", \\\"{x:1307,y:678,t:1527876790957};\\\", \\\"{x:1307,y:677,t:1527876790974};\\\", \\\"{x:1308,y:677,t:1527876791018};\\\", \\\"{x:1310,y:677,t:1527876791026};\\\", \\\"{x:1314,y:677,t:1527876791039};\\\", \\\"{x:1318,y:678,t:1527876791056};\\\", \\\"{x:1323,y:681,t:1527876791073};\\\", \\\"{x:1327,y:683,t:1527876791089};\\\", \\\"{x:1329,y:686,t:1527876791106};\\\", \\\"{x:1330,y:687,t:1527876791123};\\\", \\\"{x:1332,y:688,t:1527876791139};\\\", \\\"{x:1334,y:690,t:1527876791156};\\\", \\\"{x:1336,y:692,t:1527876791174};\\\", \\\"{x:1339,y:694,t:1527876791190};\\\", \\\"{x:1342,y:696,t:1527876791208};\\\", \\\"{x:1343,y:696,t:1527876791530};\\\", \\\"{x:1345,y:696,t:1527876791540};\\\", \\\"{x:1346,y:696,t:1527876791561};\\\", \\\"{x:1347,y:696,t:1527876791577};\\\", \\\"{x:1348,y:696,t:1527876791609};\\\", \\\"{x:1349,y:696,t:1527876791650};\\\", \\\"{x:1350,y:696,t:1527876791690};\\\", \\\"{x:1350,y:695,t:1527876791922};\\\", \\\"{x:1350,y:694,t:1527876791979};\\\", \\\"{x:1349,y:694,t:1527876792002};\\\", \\\"{x:1347,y:694,t:1527876792042};\\\", \\\"{x:1341,y:699,t:1527876792060};\\\", \\\"{x:1330,y:706,t:1527876792074};\\\", \\\"{x:1322,y:714,t:1527876792091};\\\", \\\"{x:1317,y:719,t:1527876792108};\\\", \\\"{x:1309,y:728,t:1527876792124};\\\", \\\"{x:1303,y:737,t:1527876792140};\\\", \\\"{x:1293,y:748,t:1527876792157};\\\", \\\"{x:1280,y:759,t:1527876792174};\\\", \\\"{x:1266,y:770,t:1527876792190};\\\", \\\"{x:1257,y:778,t:1527876792208};\\\", \\\"{x:1248,y:784,t:1527876792224};\\\", \\\"{x:1236,y:789,t:1527876792240};\\\", \\\"{x:1212,y:795,t:1527876792257};\\\", \\\"{x:1190,y:797,t:1527876792275};\\\", \\\"{x:1167,y:797,t:1527876792290};\\\", \\\"{x:1147,y:797,t:1527876792307};\\\", \\\"{x:1132,y:795,t:1527876792325};\\\", \\\"{x:1119,y:787,t:1527876792341};\\\", \\\"{x:1109,y:777,t:1527876792358};\\\", \\\"{x:1101,y:767,t:1527876792374};\\\", \\\"{x:1096,y:758,t:1527876792392};\\\", \\\"{x:1094,y:754,t:1527876792407};\\\", \\\"{x:1092,y:751,t:1527876792424};\\\", \\\"{x:1092,y:748,t:1527876792441};\\\", \\\"{x:1091,y:744,t:1527876792458};\\\", \\\"{x:1091,y:741,t:1527876792475};\\\", \\\"{x:1091,y:737,t:1527876792492};\\\", \\\"{x:1091,y:734,t:1527876792508};\\\", \\\"{x:1091,y:731,t:1527876792525};\\\", \\\"{x:1091,y:729,t:1527876792542};\\\", \\\"{x:1091,y:727,t:1527876792558};\\\", \\\"{x:1092,y:725,t:1527876792575};\\\", \\\"{x:1094,y:720,t:1527876792592};\\\", \\\"{x:1094,y:713,t:1527876792607};\\\", \\\"{x:1095,y:708,t:1527876792624};\\\", \\\"{x:1096,y:701,t:1527876792642};\\\", \\\"{x:1096,y:699,t:1527876792658};\\\", \\\"{x:1096,y:695,t:1527876792674};\\\", \\\"{x:1096,y:689,t:1527876792692};\\\", \\\"{x:1095,y:685,t:1527876792709};\\\", \\\"{x:1094,y:681,t:1527876792725};\\\", \\\"{x:1093,y:678,t:1527876792742};\\\", \\\"{x:1092,y:675,t:1527876792759};\\\", \\\"{x:1092,y:677,t:1527876792843};\\\", \\\"{x:1091,y:682,t:1527876792858};\\\", \\\"{x:1091,y:692,t:1527876792875};\\\", \\\"{x:1093,y:701,t:1527876792892};\\\", \\\"{x:1100,y:714,t:1527876792909};\\\", \\\"{x:1115,y:731,t:1527876792925};\\\", \\\"{x:1127,y:741,t:1527876792942};\\\", \\\"{x:1138,y:749,t:1527876792959};\\\", \\\"{x:1149,y:754,t:1527876792976};\\\", \\\"{x:1161,y:758,t:1527876792991};\\\", \\\"{x:1172,y:761,t:1527876793008};\\\", \\\"{x:1188,y:763,t:1527876793025};\\\", \\\"{x:1209,y:769,t:1527876793042};\\\", \\\"{x:1220,y:774,t:1527876793058};\\\", \\\"{x:1228,y:779,t:1527876793076};\\\", \\\"{x:1232,y:783,t:1527876793092};\\\", \\\"{x:1234,y:787,t:1527876793109};\\\", \\\"{x:1237,y:797,t:1527876793126};\\\", \\\"{x:1238,y:811,t:1527876793142};\\\", \\\"{x:1238,y:826,t:1527876793159};\\\", \\\"{x:1238,y:845,t:1527876793176};\\\", \\\"{x:1238,y:867,t:1527876793192};\\\", \\\"{x:1234,y:888,t:1527876793209};\\\", \\\"{x:1225,y:916,t:1527876793226};\\\", \\\"{x:1219,y:928,t:1527876793242};\\\", \\\"{x:1213,y:938,t:1527876793259};\\\", \\\"{x:1204,y:949,t:1527876793276};\\\", \\\"{x:1198,y:956,t:1527876793292};\\\", \\\"{x:1193,y:961,t:1527876793309};\\\", \\\"{x:1186,y:969,t:1527876793326};\\\", \\\"{x:1180,y:974,t:1527876793343};\\\", \\\"{x:1175,y:978,t:1527876793358};\\\", \\\"{x:1166,y:983,t:1527876793376};\\\", \\\"{x:1161,y:986,t:1527876793394};\\\", \\\"{x:1151,y:991,t:1527876793409};\\\", \\\"{x:1142,y:994,t:1527876793426};\\\", \\\"{x:1138,y:995,t:1527876793442};\\\", \\\"{x:1134,y:996,t:1527876793459};\\\", \\\"{x:1133,y:996,t:1527876793476};\\\", \\\"{x:1131,y:996,t:1527876793493};\\\", \\\"{x:1129,y:996,t:1527876793509};\\\", \\\"{x:1127,y:996,t:1527876793526};\\\", \\\"{x:1123,y:995,t:1527876793543};\\\", \\\"{x:1118,y:993,t:1527876793559};\\\", \\\"{x:1110,y:990,t:1527876793576};\\\", \\\"{x:1107,y:988,t:1527876793593};\\\", \\\"{x:1106,y:987,t:1527876793609};\\\", \\\"{x:1104,y:986,t:1527876793626};\\\", \\\"{x:1102,y:984,t:1527876793642};\\\", \\\"{x:1101,y:980,t:1527876793660};\\\", \\\"{x:1100,y:977,t:1527876793676};\\\", \\\"{x:1099,y:972,t:1527876793693};\\\", \\\"{x:1097,y:967,t:1527876793710};\\\", \\\"{x:1097,y:962,t:1527876793726};\\\", \\\"{x:1096,y:960,t:1527876793743};\\\", \\\"{x:1096,y:958,t:1527876793760};\\\", \\\"{x:1096,y:956,t:1527876793776};\\\", \\\"{x:1096,y:955,t:1527876793793};\\\", \\\"{x:1096,y:953,t:1527876793810};\\\", \\\"{x:1096,y:952,t:1527876793826};\\\", \\\"{x:1096,y:951,t:1527876793939};\\\", \\\"{x:1096,y:950,t:1527876793954};\\\", \\\"{x:1095,y:949,t:1527876793970};\\\", \\\"{x:1094,y:948,t:1527876793994};\\\", \\\"{x:1094,y:947,t:1527876794179};\\\", \\\"{x:1094,y:946,t:1527876794193};\\\", \\\"{x:1096,y:936,t:1527876794210};\\\", \\\"{x:1100,y:930,t:1527876794227};\\\", \\\"{x:1108,y:921,t:1527876794242};\\\", \\\"{x:1114,y:914,t:1527876794259};\\\", \\\"{x:1122,y:904,t:1527876794277};\\\", \\\"{x:1130,y:890,t:1527876794293};\\\", \\\"{x:1138,y:879,t:1527876794309};\\\", \\\"{x:1145,y:870,t:1527876794326};\\\", \\\"{x:1151,y:862,t:1527876794345};\\\", \\\"{x:1155,y:855,t:1527876794360};\\\", \\\"{x:1159,y:849,t:1527876794377};\\\", \\\"{x:1165,y:841,t:1527876794395};\\\", \\\"{x:1167,y:833,t:1527876794410};\\\", \\\"{x:1172,y:826,t:1527876794427};\\\", \\\"{x:1176,y:817,t:1527876794444};\\\", \\\"{x:1183,y:808,t:1527876794460};\\\", \\\"{x:1187,y:803,t:1527876794476};\\\", \\\"{x:1189,y:798,t:1527876794494};\\\", \\\"{x:1191,y:795,t:1527876794510};\\\", \\\"{x:1193,y:792,t:1527876794527};\\\", \\\"{x:1194,y:789,t:1527876794544};\\\", \\\"{x:1195,y:784,t:1527876794560};\\\", \\\"{x:1199,y:778,t:1527876794577};\\\", \\\"{x:1202,y:771,t:1527876794594};\\\", \\\"{x:1203,y:766,t:1527876794610};\\\", \\\"{x:1205,y:761,t:1527876794627};\\\", \\\"{x:1205,y:759,t:1527876794644};\\\", \\\"{x:1205,y:757,t:1527876794661};\\\", \\\"{x:1205,y:756,t:1527876794698};\\\", \\\"{x:1205,y:755,t:1527876794714};\\\", \\\"{x:1205,y:754,t:1527876794738};\\\", \\\"{x:1204,y:753,t:1527876794746};\\\", \\\"{x:1204,y:752,t:1527876794770};\\\", \\\"{x:1203,y:752,t:1527876794811};\\\", \\\"{x:1202,y:752,t:1527876794827};\\\", \\\"{x:1199,y:753,t:1527876794844};\\\", \\\"{x:1195,y:754,t:1527876794861};\\\", \\\"{x:1194,y:754,t:1527876794877};\\\", \\\"{x:1192,y:755,t:1527876794893};\\\", \\\"{x:1191,y:756,t:1527876794911};\\\", \\\"{x:1190,y:756,t:1527876794927};\\\", \\\"{x:1189,y:757,t:1527876794944};\\\", \\\"{x:1190,y:752,t:1527876795283};\\\", \\\"{x:1198,y:743,t:1527876795294};\\\", \\\"{x:1213,y:728,t:1527876795311};\\\", \\\"{x:1224,y:713,t:1527876795328};\\\", \\\"{x:1231,y:701,t:1527876795345};\\\", \\\"{x:1233,y:698,t:1527876795361};\\\", \\\"{x:1235,y:695,t:1527876795378};\\\", \\\"{x:1236,y:694,t:1527876795459};\\\", \\\"{x:1233,y:694,t:1527876795562};\\\", \\\"{x:1225,y:696,t:1527876795579};\\\", \\\"{x:1215,y:702,t:1527876795595};\\\", \\\"{x:1210,y:705,t:1527876795612};\\\", \\\"{x:1207,y:707,t:1527876795628};\\\", \\\"{x:1206,y:709,t:1527876795645};\\\", \\\"{x:1205,y:709,t:1527876795662};\\\", \\\"{x:1205,y:710,t:1527876795678};\\\", \\\"{x:1204,y:711,t:1527876795698};\\\", \\\"{x:1204,y:713,t:1527876795712};\\\", \\\"{x:1202,y:715,t:1527876795728};\\\", \\\"{x:1201,y:719,t:1527876795745};\\\", \\\"{x:1199,y:723,t:1527876795762};\\\", \\\"{x:1197,y:728,t:1527876795778};\\\", \\\"{x:1195,y:735,t:1527876795796};\\\", \\\"{x:1192,y:742,t:1527876795811};\\\", \\\"{x:1189,y:749,t:1527876795828};\\\", \\\"{x:1187,y:755,t:1527876795844};\\\", \\\"{x:1185,y:763,t:1527876795862};\\\", \\\"{x:1182,y:771,t:1527876795877};\\\", \\\"{x:1180,y:780,t:1527876795894};\\\", \\\"{x:1177,y:788,t:1527876795911};\\\", \\\"{x:1171,y:800,t:1527876795927};\\\", \\\"{x:1166,y:812,t:1527876795945};\\\", \\\"{x:1158,y:828,t:1527876795962};\\\", \\\"{x:1152,y:840,t:1527876795978};\\\", \\\"{x:1144,y:859,t:1527876795995};\\\", \\\"{x:1132,y:882,t:1527876796012};\\\", \\\"{x:1125,y:907,t:1527876796029};\\\", \\\"{x:1123,y:935,t:1527876796045};\\\", \\\"{x:1118,y:958,t:1527876796062};\\\", \\\"{x:1117,y:971,t:1527876796078};\\\", \\\"{x:1117,y:980,t:1527876796095};\\\", \\\"{x:1117,y:987,t:1527876796112};\\\", \\\"{x:1121,y:993,t:1527876796129};\\\", \\\"{x:1124,y:994,t:1527876796145};\\\", \\\"{x:1131,y:994,t:1527876796162};\\\", \\\"{x:1136,y:993,t:1527876796179};\\\", \\\"{x:1144,y:986,t:1527876796195};\\\", \\\"{x:1154,y:972,t:1527876796212};\\\", \\\"{x:1165,y:957,t:1527876796230};\\\", \\\"{x:1170,y:945,t:1527876796244};\\\", \\\"{x:1173,y:935,t:1527876796262};\\\", \\\"{x:1174,y:929,t:1527876796279};\\\", \\\"{x:1175,y:927,t:1527876796295};\\\", \\\"{x:1176,y:925,t:1527876796311};\\\", \\\"{x:1177,y:921,t:1527876796328};\\\", \\\"{x:1179,y:911,t:1527876796345};\\\", \\\"{x:1181,y:905,t:1527876796361};\\\", \\\"{x:1186,y:897,t:1527876796378};\\\", \\\"{x:1190,y:886,t:1527876796396};\\\", \\\"{x:1201,y:872,t:1527876796411};\\\", \\\"{x:1213,y:858,t:1527876796429};\\\", \\\"{x:1224,y:844,t:1527876796446};\\\", \\\"{x:1235,y:828,t:1527876796462};\\\", \\\"{x:1241,y:817,t:1527876796479};\\\", \\\"{x:1246,y:808,t:1527876796496};\\\", \\\"{x:1249,y:799,t:1527876796512};\\\", \\\"{x:1254,y:791,t:1527876796529};\\\", \\\"{x:1263,y:775,t:1527876796546};\\\", \\\"{x:1268,y:766,t:1527876796562};\\\", \\\"{x:1274,y:756,t:1527876796579};\\\", \\\"{x:1282,y:742,t:1527876796597};\\\", \\\"{x:1290,y:729,t:1527876796612};\\\", \\\"{x:1298,y:715,t:1527876796628};\\\", \\\"{x:1304,y:703,t:1527876796645};\\\", \\\"{x:1308,y:695,t:1527876796662};\\\", \\\"{x:1310,y:690,t:1527876796678};\\\", \\\"{x:1311,y:688,t:1527876796695};\\\", \\\"{x:1312,y:687,t:1527876796745};\\\", \\\"{x:1312,y:688,t:1527876796786};\\\", \\\"{x:1311,y:693,t:1527876796796};\\\", \\\"{x:1310,y:713,t:1527876796813};\\\", \\\"{x:1310,y:730,t:1527876796829};\\\", \\\"{x:1311,y:750,t:1527876796845};\\\", \\\"{x:1314,y:761,t:1527876796863};\\\", \\\"{x:1318,y:776,t:1527876796879};\\\", \\\"{x:1319,y:784,t:1527876796896};\\\", \\\"{x:1319,y:797,t:1527876796912};\\\", \\\"{x:1316,y:810,t:1527876796929};\\\", \\\"{x:1311,y:829,t:1527876796945};\\\", \\\"{x:1306,y:839,t:1527876796962};\\\", \\\"{x:1300,y:850,t:1527876796979};\\\", \\\"{x:1295,y:857,t:1527876796995};\\\", \\\"{x:1286,y:869,t:1527876797012};\\\", \\\"{x:1278,y:878,t:1527876797029};\\\", \\\"{x:1268,y:888,t:1527876797045};\\\", \\\"{x:1256,y:899,t:1527876797063};\\\", \\\"{x:1246,y:909,t:1527876797079};\\\", \\\"{x:1231,y:921,t:1527876797095};\\\", \\\"{x:1217,y:932,t:1527876797113};\\\", \\\"{x:1201,y:945,t:1527876797130};\\\", \\\"{x:1196,y:949,t:1527876797145};\\\", \\\"{x:1194,y:951,t:1527876797163};\\\", \\\"{x:1192,y:953,t:1527876797180};\\\", \\\"{x:1192,y:955,t:1527876797210};\\\", \\\"{x:1191,y:956,t:1527876797218};\\\", \\\"{x:1191,y:958,t:1527876797230};\\\", \\\"{x:1191,y:962,t:1527876797246};\\\", \\\"{x:1191,y:965,t:1527876797263};\\\", \\\"{x:1192,y:965,t:1527876797347};\\\", \\\"{x:1199,y:956,t:1527876797364};\\\", \\\"{x:1211,y:940,t:1527876797380};\\\", \\\"{x:1229,y:909,t:1527876797397};\\\", \\\"{x:1257,y:867,t:1527876797413};\\\", \\\"{x:1276,y:838,t:1527876797430};\\\", \\\"{x:1289,y:815,t:1527876797447};\\\", \\\"{x:1299,y:799,t:1527876797463};\\\", \\\"{x:1305,y:786,t:1527876797480};\\\", \\\"{x:1312,y:768,t:1527876797497};\\\", \\\"{x:1317,y:751,t:1527876797513};\\\", \\\"{x:1323,y:728,t:1527876797529};\\\", \\\"{x:1328,y:719,t:1527876797546};\\\", \\\"{x:1332,y:711,t:1527876797563};\\\", \\\"{x:1336,y:703,t:1527876797580};\\\", \\\"{x:1339,y:699,t:1527876797597};\\\", \\\"{x:1340,y:697,t:1527876797612};\\\", \\\"{x:1342,y:696,t:1527876797630};\\\", \\\"{x:1345,y:691,t:1527876797647};\\\", \\\"{x:1349,y:687,t:1527876797663};\\\", \\\"{x:1353,y:681,t:1527876797681};\\\", \\\"{x:1355,y:679,t:1527876797697};\\\", \\\"{x:1355,y:678,t:1527876797714};\\\", \\\"{x:1354,y:681,t:1527876797817};\\\", \\\"{x:1353,y:684,t:1527876797829};\\\", \\\"{x:1350,y:692,t:1527876797847};\\\", \\\"{x:1349,y:701,t:1527876797864};\\\", \\\"{x:1345,y:711,t:1527876797880};\\\", \\\"{x:1344,y:720,t:1527876797897};\\\", \\\"{x:1344,y:729,t:1527876797913};\\\", \\\"{x:1344,y:731,t:1527876797930};\\\", \\\"{x:1343,y:734,t:1527876797946};\\\", \\\"{x:1343,y:738,t:1527876797963};\\\", \\\"{x:1343,y:744,t:1527876797980};\\\", \\\"{x:1343,y:749,t:1527876797997};\\\", \\\"{x:1343,y:752,t:1527876798014};\\\", \\\"{x:1341,y:755,t:1527876798031};\\\", \\\"{x:1341,y:758,t:1527876798047};\\\", \\\"{x:1341,y:761,t:1527876798064};\\\", \\\"{x:1341,y:762,t:1527876798081};\\\", \\\"{x:1341,y:766,t:1527876798096};\\\", \\\"{x:1341,y:768,t:1527876798113};\\\", \\\"{x:1342,y:768,t:1527876798298};\\\", \\\"{x:1350,y:764,t:1527876798314};\\\", \\\"{x:1356,y:758,t:1527876798332};\\\", \\\"{x:1366,y:748,t:1527876798347};\\\", \\\"{x:1369,y:744,t:1527876798364};\\\", \\\"{x:1370,y:742,t:1527876798381};\\\", \\\"{x:1368,y:743,t:1527876798505};\\\", \\\"{x:1365,y:744,t:1527876798513};\\\", \\\"{x:1360,y:748,t:1527876798530};\\\", \\\"{x:1356,y:751,t:1527876798548};\\\", \\\"{x:1355,y:753,t:1527876798564};\\\", \\\"{x:1352,y:756,t:1527876798581};\\\", \\\"{x:1350,y:759,t:1527876798598};\\\", \\\"{x:1347,y:761,t:1527876798614};\\\", \\\"{x:1345,y:763,t:1527876798630};\\\", \\\"{x:1344,y:764,t:1527876798648};\\\", \\\"{x:1344,y:766,t:1527876798664};\\\", \\\"{x:1344,y:767,t:1527876798680};\\\", \\\"{x:1343,y:769,t:1527876798699};\\\", \\\"{x:1345,y:769,t:1527876798770};\\\", \\\"{x:1351,y:764,t:1527876798781};\\\", \\\"{x:1367,y:751,t:1527876798799};\\\", \\\"{x:1381,y:738,t:1527876798815};\\\", \\\"{x:1392,y:726,t:1527876798832};\\\", \\\"{x:1398,y:717,t:1527876798848};\\\", \\\"{x:1399,y:715,t:1527876798865};\\\", \\\"{x:1399,y:716,t:1527876798969};\\\", \\\"{x:1398,y:723,t:1527876798981};\\\", \\\"{x:1394,y:740,t:1527876798998};\\\", \\\"{x:1393,y:760,t:1527876799015};\\\", \\\"{x:1392,y:779,t:1527876799031};\\\", \\\"{x:1391,y:799,t:1527876799048};\\\", \\\"{x:1391,y:820,t:1527876799065};\\\", \\\"{x:1391,y:839,t:1527876799081};\\\", \\\"{x:1391,y:849,t:1527876799097};\\\", \\\"{x:1391,y:857,t:1527876799115};\\\", \\\"{x:1391,y:865,t:1527876799131};\\\", \\\"{x:1391,y:871,t:1527876799148};\\\", \\\"{x:1388,y:881,t:1527876799164};\\\", \\\"{x:1384,y:896,t:1527876799181};\\\", \\\"{x:1380,y:910,t:1527876799198};\\\", \\\"{x:1377,y:920,t:1527876799214};\\\", \\\"{x:1375,y:926,t:1527876799232};\\\", \\\"{x:1373,y:930,t:1527876799248};\\\", \\\"{x:1370,y:935,t:1527876799264};\\\", \\\"{x:1367,y:943,t:1527876799282};\\\", \\\"{x:1363,y:950,t:1527876799297};\\\", \\\"{x:1358,y:956,t:1527876799314};\\\", \\\"{x:1353,y:961,t:1527876799331};\\\", \\\"{x:1349,y:965,t:1527876799348};\\\", \\\"{x:1345,y:970,t:1527876799365};\\\", \\\"{x:1346,y:968,t:1527876799507};\\\", \\\"{x:1350,y:962,t:1527876799516};\\\", \\\"{x:1355,y:951,t:1527876799532};\\\", \\\"{x:1359,y:944,t:1527876799549};\\\", \\\"{x:1363,y:934,t:1527876799565};\\\", \\\"{x:1366,y:926,t:1527876799583};\\\", \\\"{x:1371,y:914,t:1527876799599};\\\", \\\"{x:1374,y:907,t:1527876799616};\\\", \\\"{x:1377,y:902,t:1527876799631};\\\", \\\"{x:1379,y:897,t:1527876799648};\\\", \\\"{x:1384,y:891,t:1527876799665};\\\", \\\"{x:1386,y:887,t:1527876799682};\\\", \\\"{x:1389,y:882,t:1527876799699};\\\", \\\"{x:1393,y:876,t:1527876799715};\\\", \\\"{x:1396,y:871,t:1527876799731};\\\", \\\"{x:1398,y:868,t:1527876799749};\\\", \\\"{x:1400,y:866,t:1527876799766};\\\", \\\"{x:1402,y:863,t:1527876799782};\\\", \\\"{x:1404,y:860,t:1527876799799};\\\", \\\"{x:1407,y:856,t:1527876799816};\\\", \\\"{x:1411,y:851,t:1527876799831};\\\", \\\"{x:1415,y:846,t:1527876799849};\\\", \\\"{x:1417,y:843,t:1527876799865};\\\", \\\"{x:1417,y:842,t:1527876799882};\\\", \\\"{x:1418,y:840,t:1527876799899};\\\", \\\"{x:1419,y:839,t:1527876799917};\\\", \\\"{x:1420,y:838,t:1527876799933};\\\", \\\"{x:1421,y:834,t:1527876799949};\\\", \\\"{x:1423,y:832,t:1527876799967};\\\", \\\"{x:1425,y:831,t:1527876799982};\\\", \\\"{x:1426,y:828,t:1527876800000};\\\", \\\"{x:1428,y:826,t:1527876800016};\\\", \\\"{x:1429,y:824,t:1527876800033};\\\", \\\"{x:1432,y:819,t:1527876800049};\\\", \\\"{x:1437,y:811,t:1527876800066};\\\", \\\"{x:1441,y:806,t:1527876800084};\\\", \\\"{x:1445,y:796,t:1527876800100};\\\", \\\"{x:1451,y:787,t:1527876800116};\\\", \\\"{x:1456,y:780,t:1527876800134};\\\", \\\"{x:1460,y:774,t:1527876800149};\\\", \\\"{x:1462,y:769,t:1527876800166};\\\", \\\"{x:1463,y:767,t:1527876800183};\\\", \\\"{x:1464,y:765,t:1527876800200};\\\", \\\"{x:1465,y:763,t:1527876800216};\\\", \\\"{x:1466,y:760,t:1527876800234};\\\", \\\"{x:1469,y:757,t:1527876800249};\\\", \\\"{x:1471,y:750,t:1527876800266};\\\", \\\"{x:1473,y:744,t:1527876800283};\\\", \\\"{x:1475,y:740,t:1527876800299};\\\", \\\"{x:1477,y:737,t:1527876800316};\\\", \\\"{x:1477,y:734,t:1527876800333};\\\", \\\"{x:1478,y:731,t:1527876800350};\\\", \\\"{x:1480,y:728,t:1527876800366};\\\", \\\"{x:1480,y:723,t:1527876800383};\\\", \\\"{x:1482,y:716,t:1527876800400};\\\", \\\"{x:1484,y:709,t:1527876800416};\\\", \\\"{x:1484,y:707,t:1527876800433};\\\", \\\"{x:1484,y:703,t:1527876800451};\\\", \\\"{x:1485,y:700,t:1527876800467};\\\", \\\"{x:1486,y:697,t:1527876800484};\\\", \\\"{x:1487,y:692,t:1527876800500};\\\", \\\"{x:1489,y:689,t:1527876800516};\\\", \\\"{x:1489,y:686,t:1527876800533};\\\", \\\"{x:1493,y:681,t:1527876800550};\\\", \\\"{x:1496,y:675,t:1527876800566};\\\", \\\"{x:1500,y:666,t:1527876800583};\\\", \\\"{x:1502,y:661,t:1527876800600};\\\", \\\"{x:1505,y:653,t:1527876800616};\\\", \\\"{x:1508,y:648,t:1527876800633};\\\", \\\"{x:1508,y:643,t:1527876800650};\\\", \\\"{x:1509,y:641,t:1527876800666};\\\", \\\"{x:1510,y:638,t:1527876800683};\\\", \\\"{x:1511,y:636,t:1527876800700};\\\", \\\"{x:1512,y:633,t:1527876800718};\\\", \\\"{x:1512,y:631,t:1527876800733};\\\", \\\"{x:1512,y:629,t:1527876800750};\\\", \\\"{x:1511,y:634,t:1527876800890};\\\", \\\"{x:1509,y:644,t:1527876800901};\\\", \\\"{x:1501,y:667,t:1527876800917};\\\", \\\"{x:1498,y:695,t:1527876800934};\\\", \\\"{x:1494,y:724,t:1527876800950};\\\", \\\"{x:1492,y:750,t:1527876800968};\\\", \\\"{x:1490,y:770,t:1527876800983};\\\", \\\"{x:1487,y:789,t:1527876801001};\\\", \\\"{x:1486,y:803,t:1527876801017};\\\", \\\"{x:1484,y:821,t:1527876801034};\\\", \\\"{x:1483,y:831,t:1527876801051};\\\", \\\"{x:1482,y:840,t:1527876801068};\\\", \\\"{x:1479,y:846,t:1527876801083};\\\", \\\"{x:1479,y:850,t:1527876801100};\\\", \\\"{x:1477,y:856,t:1527876801117};\\\", \\\"{x:1476,y:861,t:1527876801134};\\\", \\\"{x:1474,y:866,t:1527876801150};\\\", \\\"{x:1471,y:869,t:1527876801167};\\\", \\\"{x:1465,y:878,t:1527876801183};\\\", \\\"{x:1459,y:884,t:1527876801200};\\\", \\\"{x:1454,y:892,t:1527876801216};\\\", \\\"{x:1445,y:906,t:1527876801233};\\\", \\\"{x:1438,y:914,t:1527876801250};\\\", \\\"{x:1430,y:925,t:1527876801267};\\\", \\\"{x:1420,y:937,t:1527876801284};\\\", \\\"{x:1416,y:944,t:1527876801300};\\\", \\\"{x:1414,y:949,t:1527876801317};\\\", \\\"{x:1412,y:950,t:1527876801334};\\\", \\\"{x:1414,y:951,t:1527876801546};\\\", \\\"{x:1419,y:949,t:1527876801554};\\\", \\\"{x:1426,y:944,t:1527876801568};\\\", \\\"{x:1451,y:923,t:1527876801584};\\\", \\\"{x:1484,y:894,t:1527876801601};\\\", \\\"{x:1521,y:859,t:1527876801617};\\\", \\\"{x:1557,y:814,t:1527876801634};\\\", \\\"{x:1564,y:801,t:1527876801651};\\\", \\\"{x:1567,y:795,t:1527876801667};\\\", \\\"{x:1567,y:792,t:1527876801684};\\\", \\\"{x:1567,y:791,t:1527876801714};\\\", \\\"{x:1567,y:789,t:1527876801722};\\\", \\\"{x:1567,y:788,t:1527876801734};\\\", \\\"{x:1567,y:783,t:1527876801751};\\\", \\\"{x:1567,y:774,t:1527876801769};\\\", \\\"{x:1566,y:766,t:1527876801784};\\\", \\\"{x:1562,y:754,t:1527876801802};\\\", \\\"{x:1559,y:737,t:1527876801818};\\\", \\\"{x:1557,y:724,t:1527876801834};\\\", \\\"{x:1555,y:709,t:1527876801851};\\\", \\\"{x:1553,y:696,t:1527876801869};\\\", \\\"{x:1552,y:682,t:1527876801884};\\\", \\\"{x:1550,y:674,t:1527876801901};\\\", \\\"{x:1550,y:666,t:1527876801918};\\\", \\\"{x:1552,y:659,t:1527876801933};\\\", \\\"{x:1555,y:652,t:1527876801951};\\\", \\\"{x:1558,y:646,t:1527876801968};\\\", \\\"{x:1560,y:639,t:1527876801984};\\\", \\\"{x:1564,y:633,t:1527876802001};\\\", \\\"{x:1565,y:631,t:1527876802018};\\\", \\\"{x:1567,y:629,t:1527876802035};\\\", \\\"{x:1568,y:627,t:1527876802050};\\\", \\\"{x:1569,y:626,t:1527876802067};\\\", \\\"{x:1569,y:625,t:1527876802084};\\\", \\\"{x:1571,y:622,t:1527876802100};\\\", \\\"{x:1575,y:618,t:1527876802118};\\\", \\\"{x:1579,y:615,t:1527876802135};\\\", \\\"{x:1580,y:614,t:1527876802151};\\\", \\\"{x:1581,y:614,t:1527876802202};\\\", \\\"{x:1582,y:615,t:1527876802218};\\\", \\\"{x:1583,y:621,t:1527876802235};\\\", \\\"{x:1583,y:629,t:1527876802252};\\\", \\\"{x:1583,y:638,t:1527876802269};\\\", \\\"{x:1582,y:646,t:1527876802285};\\\", \\\"{x:1580,y:655,t:1527876802302};\\\", \\\"{x:1578,y:659,t:1527876802319};\\\", \\\"{x:1578,y:661,t:1527876802336};\\\", \\\"{x:1577,y:662,t:1527876802351};\\\", \\\"{x:1577,y:664,t:1527876802368};\\\", \\\"{x:1577,y:668,t:1527876802385};\\\", \\\"{x:1575,y:672,t:1527876802402};\\\", \\\"{x:1574,y:673,t:1527876802426};\\\", \\\"{x:1571,y:676,t:1527876802595};\\\", \\\"{x:1570,y:676,t:1527876802602};\\\", \\\"{x:1564,y:681,t:1527876802618};\\\", \\\"{x:1559,y:686,t:1527876802636};\\\", \\\"{x:1552,y:693,t:1527876802652};\\\", \\\"{x:1544,y:701,t:1527876802669};\\\", \\\"{x:1538,y:711,t:1527876802685};\\\", \\\"{x:1533,y:721,t:1527876802703};\\\", \\\"{x:1529,y:727,t:1527876802719};\\\", \\\"{x:1526,y:736,t:1527876802735};\\\", \\\"{x:1524,y:742,t:1527876802752};\\\", \\\"{x:1522,y:747,t:1527876802770};\\\", \\\"{x:1521,y:751,t:1527876802785};\\\", \\\"{x:1520,y:753,t:1527876802803};\\\", \\\"{x:1520,y:754,t:1527876802819};\\\", \\\"{x:1520,y:756,t:1527876802835};\\\", \\\"{x:1519,y:757,t:1527876802852};\\\", \\\"{x:1524,y:755,t:1527876802963};\\\", \\\"{x:1530,y:750,t:1527876802969};\\\", \\\"{x:1538,y:745,t:1527876802986};\\\", \\\"{x:1554,y:727,t:1527876803002};\\\", \\\"{x:1562,y:716,t:1527876803019};\\\", \\\"{x:1565,y:712,t:1527876803037};\\\", \\\"{x:1567,y:709,t:1527876803053};\\\", \\\"{x:1565,y:712,t:1527876803282};\\\", \\\"{x:1557,y:718,t:1527876803290};\\\", \\\"{x:1550,y:726,t:1527876803302};\\\", \\\"{x:1532,y:747,t:1527876803319};\\\", \\\"{x:1517,y:763,t:1527876803337};\\\", \\\"{x:1507,y:775,t:1527876803354};\\\", \\\"{x:1503,y:780,t:1527876803370};\\\", \\\"{x:1502,y:780,t:1527876803386};\\\", \\\"{x:1502,y:782,t:1527876803594};\\\", \\\"{x:1500,y:785,t:1527876803604};\\\", \\\"{x:1496,y:795,t:1527876803619};\\\", \\\"{x:1493,y:802,t:1527876803637};\\\", \\\"{x:1490,y:808,t:1527876803653};\\\", \\\"{x:1489,y:814,t:1527876803670};\\\", \\\"{x:1486,y:817,t:1527876803687};\\\", \\\"{x:1486,y:818,t:1527876803703};\\\", \\\"{x:1486,y:819,t:1527876803721};\\\", \\\"{x:1486,y:821,t:1527876803931};\\\", \\\"{x:1485,y:822,t:1527876803938};\\\", \\\"{x:1484,y:824,t:1527876803954};\\\", \\\"{x:1483,y:827,t:1527876803970};\\\", \\\"{x:1482,y:828,t:1527876803986};\\\", \\\"{x:1482,y:823,t:1527876804067};\\\", \\\"{x:1489,y:813,t:1527876804075};\\\", \\\"{x:1495,y:807,t:1527876804088};\\\", \\\"{x:1508,y:789,t:1527876804103};\\\", \\\"{x:1514,y:780,t:1527876804120};\\\", \\\"{x:1516,y:777,t:1527876804137};\\\", \\\"{x:1516,y:775,t:1527876804218};\\\", \\\"{x:1517,y:774,t:1527876804226};\\\", \\\"{x:1517,y:773,t:1527876804241};\\\", \\\"{x:1518,y:771,t:1527876804345};\\\", \\\"{x:1518,y:769,t:1527876804354};\\\", \\\"{x:1520,y:765,t:1527876804370};\\\", \\\"{x:1521,y:763,t:1527876804387};\\\", \\\"{x:1521,y:761,t:1527876804418};\\\", \\\"{x:1521,y:762,t:1527876804593};\\\", \\\"{x:1519,y:765,t:1527876804603};\\\", \\\"{x:1515,y:773,t:1527876804620};\\\", \\\"{x:1509,y:783,t:1527876804637};\\\", \\\"{x:1504,y:794,t:1527876804654};\\\", \\\"{x:1499,y:805,t:1527876804670};\\\", \\\"{x:1494,y:815,t:1527876804687};\\\", \\\"{x:1486,y:826,t:1527876804704};\\\", \\\"{x:1480,y:834,t:1527876804721};\\\", \\\"{x:1471,y:844,t:1527876804738};\\\", \\\"{x:1468,y:849,t:1527876804754};\\\", \\\"{x:1467,y:846,t:1527876804955};\\\", \\\"{x:1464,y:839,t:1527876804972};\\\", \\\"{x:1454,y:824,t:1527876804988};\\\", \\\"{x:1424,y:804,t:1527876805004};\\\", \\\"{x:1373,y:788,t:1527876805021};\\\", \\\"{x:1312,y:778,t:1527876805038};\\\", \\\"{x:1224,y:761,t:1527876805054};\\\", \\\"{x:1110,y:743,t:1527876805072};\\\", \\\"{x:975,y:724,t:1527876805088};\\\", \\\"{x:847,y:703,t:1527876805104};\\\", \\\"{x:761,y:680,t:1527876805121};\\\", \\\"{x:715,y:655,t:1527876805137};\\\", \\\"{x:706,y:644,t:1527876805154};\\\", \\\"{x:705,y:631,t:1527876805173};\\\", \\\"{x:705,y:620,t:1527876805188};\\\", \\\"{x:705,y:608,t:1527876805204};\\\", \\\"{x:707,y:606,t:1527876805214};\\\", \\\"{x:707,y:598,t:1527876805232};\\\", \\\"{x:707,y:591,t:1527876805248};\\\", \\\"{x:704,y:584,t:1527876805265};\\\", \\\"{x:702,y:579,t:1527876805282};\\\", \\\"{x:702,y:577,t:1527876805298};\\\", \\\"{x:703,y:575,t:1527876805337};\\\", \\\"{x:705,y:575,t:1527876805349};\\\", \\\"{x:720,y:574,t:1527876805365};\\\", \\\"{x:736,y:574,t:1527876805383};\\\", \\\"{x:750,y:574,t:1527876805398};\\\", \\\"{x:759,y:574,t:1527876805415};\\\", \\\"{x:764,y:574,t:1527876805432};\\\", \\\"{x:767,y:574,t:1527876805448};\\\", \\\"{x:768,y:574,t:1527876805482};\\\", \\\"{x:769,y:574,t:1527876805499};\\\", \\\"{x:772,y:576,t:1527876805516};\\\", \\\"{x:775,y:579,t:1527876805532};\\\", \\\"{x:780,y:580,t:1527876805549};\\\", \\\"{x:781,y:580,t:1527876805566};\\\", \\\"{x:782,y:581,t:1527876805582};\\\", \\\"{x:783,y:581,t:1527876805617};\\\", \\\"{x:784,y:581,t:1527876805631};\\\", \\\"{x:789,y:581,t:1527876805648};\\\", \\\"{x:791,y:582,t:1527876805665};\\\", \\\"{x:793,y:582,t:1527876805682};\\\", \\\"{x:796,y:582,t:1527876805699};\\\", \\\"{x:797,y:582,t:1527876805716};\\\", \\\"{x:803,y:582,t:1527876805733};\\\", \\\"{x:809,y:582,t:1527876805749};\\\", \\\"{x:816,y:582,t:1527876805765};\\\", \\\"{x:819,y:582,t:1527876805782};\\\", \\\"{x:820,y:582,t:1527876806530};\\\", \\\"{x:822,y:582,t:1527876806545};\\\", \\\"{x:823,y:582,t:1527876806554};\\\", \\\"{x:825,y:582,t:1527876806567};\\\", \\\"{x:828,y:582,t:1527876806583};\\\", \\\"{x:829,y:582,t:1527876806599};\\\", \\\"{x:830,y:582,t:1527876806698};\\\", \\\"{x:831,y:582,t:1527876806850};\\\", \\\"{x:832,y:581,t:1527876806904};\\\", \\\"{x:832,y:581,t:1527876806982};\\\", \\\"{x:832,y:580,t:1527876807282};\\\", \\\"{x:821,y:580,t:1527876807291};\\\", \\\"{x:801,y:580,t:1527876807300};\\\", \\\"{x:738,y:584,t:1527876807317};\\\", \\\"{x:657,y:597,t:1527876807334};\\\", \\\"{x:608,y:600,t:1527876807351};\\\", \\\"{x:579,y:600,t:1527876807367};\\\", \\\"{x:566,y:600,t:1527876807384};\\\", \\\"{x:564,y:600,t:1527876807400};\\\", \\\"{x:565,y:599,t:1527876807538};\\\", \\\"{x:569,y:598,t:1527876807551};\\\", \\\"{x:573,y:596,t:1527876807568};\\\", \\\"{x:576,y:593,t:1527876807585};\\\", \\\"{x:581,y:591,t:1527876807601};\\\", \\\"{x:584,y:589,t:1527876807617};\\\", \\\"{x:587,y:588,t:1527876807633};\\\", \\\"{x:588,y:587,t:1527876807657};\\\", \\\"{x:591,y:586,t:1527876807667};\\\", \\\"{x:593,y:585,t:1527876807683};\\\", \\\"{x:595,y:584,t:1527876807700};\\\", \\\"{x:599,y:581,t:1527876807717};\\\", \\\"{x:602,y:581,t:1527876807734};\\\", \\\"{x:605,y:579,t:1527876807751};\\\", \\\"{x:607,y:578,t:1527876808290};\\\", \\\"{x:614,y:578,t:1527876808301};\\\", \\\"{x:648,y:578,t:1527876808319};\\\", \\\"{x:706,y:578,t:1527876808335};\\\", \\\"{x:790,y:578,t:1527876808351};\\\", \\\"{x:892,y:578,t:1527876808367};\\\", \\\"{x:992,y:578,t:1527876808384};\\\", \\\"{x:1175,y:578,t:1527876808400};\\\", \\\"{x:1316,y:578,t:1527876808418};\\\", \\\"{x:1440,y:578,t:1527876808434};\\\", \\\"{x:1555,y:581,t:1527876808451};\\\", \\\"{x:1649,y:594,t:1527876808468};\\\", \\\"{x:1727,y:603,t:1527876808485};\\\", \\\"{x:1789,y:617,t:1527876808501};\\\", \\\"{x:1853,y:634,t:1527876808518};\\\", \\\"{x:1893,y:647,t:1527876808535};\\\", \\\"{x:1919,y:659,t:1527876808552};\\\", \\\"{x:1919,y:668,t:1527876808568};\\\", \\\"{x:1919,y:678,t:1527876808585};\\\", \\\"{x:1919,y:681,t:1527876808601};\\\", \\\"{x:1919,y:683,t:1527876808618};\\\", \\\"{x:1917,y:686,t:1527876808635};\\\", \\\"{x:1910,y:693,t:1527876808652};\\\", \\\"{x:1895,y:709,t:1527876808669};\\\", \\\"{x:1872,y:727,t:1527876808685};\\\", \\\"{x:1843,y:750,t:1527876808702};\\\", \\\"{x:1809,y:774,t:1527876808718};\\\", \\\"{x:1782,y:790,t:1527876808735};\\\", \\\"{x:1760,y:800,t:1527876808751};\\\", \\\"{x:1747,y:805,t:1527876808768};\\\", \\\"{x:1736,y:810,t:1527876808786};\\\", \\\"{x:1724,y:815,t:1527876808802};\\\", \\\"{x:1711,y:818,t:1527876808818};\\\", \\\"{x:1689,y:821,t:1527876808835};\\\", \\\"{x:1673,y:823,t:1527876808853};\\\", \\\"{x:1661,y:824,t:1527876808869};\\\", \\\"{x:1653,y:824,t:1527876808886};\\\", \\\"{x:1652,y:824,t:1527876808902};\\\", \\\"{x:1650,y:824,t:1527876808918};\\\", \\\"{x:1648,y:824,t:1527876808946};\\\", \\\"{x:1646,y:824,t:1527876808954};\\\", \\\"{x:1643,y:824,t:1527876808969};\\\", \\\"{x:1614,y:826,t:1527876808985};\\\", \\\"{x:1587,y:831,t:1527876809002};\\\", \\\"{x:1564,y:832,t:1527876809018};\\\", \\\"{x:1538,y:832,t:1527876809036};\\\", \\\"{x:1512,y:832,t:1527876809053};\\\", \\\"{x:1495,y:832,t:1527876809068};\\\", \\\"{x:1489,y:832,t:1527876809085};\\\", \\\"{x:1488,y:832,t:1527876809102};\\\", \\\"{x:1488,y:831,t:1527876809185};\\\", \\\"{x:1488,y:826,t:1527876809202};\\\", \\\"{x:1488,y:818,t:1527876809219};\\\", \\\"{x:1492,y:802,t:1527876809235};\\\", \\\"{x:1498,y:789,t:1527876809252};\\\", \\\"{x:1508,y:778,t:1527876809269};\\\", \\\"{x:1515,y:768,t:1527876809285};\\\", \\\"{x:1518,y:763,t:1527876809302};\\\", \\\"{x:1520,y:758,t:1527876809320};\\\", \\\"{x:1521,y:753,t:1527876809335};\\\", \\\"{x:1523,y:748,t:1527876809353};\\\", \\\"{x:1523,y:745,t:1527876809370};\\\", \\\"{x:1523,y:743,t:1527876809386};\\\", \\\"{x:1523,y:742,t:1527876809434};\\\", \\\"{x:1523,y:741,t:1527876809547};\\\", \\\"{x:1522,y:741,t:1527876809561};\\\", \\\"{x:1520,y:742,t:1527876809578};\\\", \\\"{x:1518,y:742,t:1527876809610};\\\", \\\"{x:1517,y:743,t:1527876809634};\\\", \\\"{x:1517,y:744,t:1527876809675};\\\", \\\"{x:1517,y:745,t:1527876809687};\\\", \\\"{x:1516,y:746,t:1527876809714};\\\", \\\"{x:1516,y:747,t:1527876809738};\\\", \\\"{x:1515,y:749,t:1527876809752};\\\", \\\"{x:1514,y:751,t:1527876809778};\\\", \\\"{x:1514,y:752,t:1527876809794};\\\", \\\"{x:1514,y:753,t:1527876809802};\\\", \\\"{x:1514,y:754,t:1527876809820};\\\", \\\"{x:1513,y:755,t:1527876809836};\\\", \\\"{x:1513,y:756,t:1527876809865};\\\", \\\"{x:1513,y:757,t:1527876809905};\\\", \\\"{x:1513,y:758,t:1527876810083};\\\", \\\"{x:1511,y:760,t:1527876810104};\\\", \\\"{x:1511,y:762,t:1527876810119};\\\", \\\"{x:1511,y:763,t:1527876810137};\\\", \\\"{x:1511,y:764,t:1527876810154};\\\", \\\"{x:1510,y:766,t:1527876810346};\\\", \\\"{x:1509,y:766,t:1527876810371};\\\", \\\"{x:1507,y:768,t:1527876810387};\\\", \\\"{x:1507,y:769,t:1527876810404};\\\", \\\"{x:1506,y:770,t:1527876810421};\\\", \\\"{x:1505,y:771,t:1527876810437};\\\", \\\"{x:1505,y:774,t:1527876810713};\\\", \\\"{x:1505,y:775,t:1527876810721};\\\", \\\"{x:1504,y:780,t:1527876810737};\\\", \\\"{x:1504,y:788,t:1527876810752};\\\", \\\"{x:1504,y:794,t:1527876810770};\\\", \\\"{x:1504,y:799,t:1527876810787};\\\", \\\"{x:1504,y:804,t:1527876810803};\\\", \\\"{x:1504,y:811,t:1527876810820};\\\", \\\"{x:1504,y:812,t:1527876810837};\\\", \\\"{x:1504,y:814,t:1527876810853};\\\", \\\"{x:1504,y:816,t:1527876810870};\\\", \\\"{x:1504,y:817,t:1527876810887};\\\", \\\"{x:1504,y:818,t:1527876810903};\\\", \\\"{x:1503,y:818,t:1527876810920};\\\", \\\"{x:1502,y:819,t:1527876810937};\\\", \\\"{x:1500,y:820,t:1527876810954};\\\", \\\"{x:1500,y:821,t:1527876810970};\\\", \\\"{x:1499,y:821,t:1527876810987};\\\", \\\"{x:1498,y:823,t:1527876811004};\\\", \\\"{x:1496,y:825,t:1527876811020};\\\", \\\"{x:1494,y:828,t:1527876811037};\\\", \\\"{x:1492,y:831,t:1527876811054};\\\", \\\"{x:1492,y:833,t:1527876811185};\\\", \\\"{x:1492,y:834,t:1527876811201};\\\", \\\"{x:1491,y:836,t:1527876811225};\\\", \\\"{x:1491,y:837,t:1527876811237};\\\", \\\"{x:1490,y:840,t:1527876811254};\\\", \\\"{x:1488,y:842,t:1527876811270};\\\", \\\"{x:1487,y:844,t:1527876811287};\\\", \\\"{x:1484,y:847,t:1527876811304};\\\", \\\"{x:1483,y:849,t:1527876811321};\\\", \\\"{x:1480,y:851,t:1527876811337};\\\", \\\"{x:1478,y:853,t:1527876811355};\\\", \\\"{x:1476,y:857,t:1527876811370};\\\", \\\"{x:1474,y:858,t:1527876811387};\\\", \\\"{x:1473,y:861,t:1527876811404};\\\", \\\"{x:1472,y:862,t:1527876811421};\\\", \\\"{x:1471,y:863,t:1527876811437};\\\", \\\"{x:1471,y:864,t:1527876811454};\\\", \\\"{x:1469,y:867,t:1527876811471};\\\", \\\"{x:1468,y:868,t:1527876811498};\\\", \\\"{x:1467,y:869,t:1527876811505};\\\", \\\"{x:1464,y:872,t:1527876811521};\\\", \\\"{x:1462,y:875,t:1527876811537};\\\", \\\"{x:1456,y:881,t:1527876811554};\\\", \\\"{x:1454,y:888,t:1527876811573};\\\", \\\"{x:1450,y:894,t:1527876811587};\\\", \\\"{x:1449,y:900,t:1527876811604};\\\", \\\"{x:1444,y:905,t:1527876811621};\\\", \\\"{x:1441,y:907,t:1527876811637};\\\", \\\"{x:1439,y:910,t:1527876811777};\\\", \\\"{x:1438,y:911,t:1527876811788};\\\", \\\"{x:1437,y:911,t:1527876811804};\\\", \\\"{x:1437,y:912,t:1527876811825};\\\", \\\"{x:1437,y:913,t:1527876811839};\\\", \\\"{x:1436,y:914,t:1527876811854};\\\", \\\"{x:1435,y:915,t:1527876811871};\\\", \\\"{x:1434,y:917,t:1527876811888};\\\", \\\"{x:1430,y:921,t:1527876811904};\\\", \\\"{x:1427,y:925,t:1527876811921};\\\", \\\"{x:1425,y:927,t:1527876811938};\\\", \\\"{x:1424,y:928,t:1527876811954};\\\", \\\"{x:1423,y:930,t:1527876811985};\\\", \\\"{x:1422,y:931,t:1527876812001};\\\", \\\"{x:1421,y:933,t:1527876812009};\\\", \\\"{x:1420,y:935,t:1527876812025};\\\", \\\"{x:1419,y:937,t:1527876812038};\\\", \\\"{x:1416,y:940,t:1527876812054};\\\", \\\"{x:1415,y:944,t:1527876812071};\\\", \\\"{x:1411,y:954,t:1527876812088};\\\", \\\"{x:1408,y:962,t:1527876812104};\\\", \\\"{x:1404,y:972,t:1527876812121};\\\", \\\"{x:1402,y:974,t:1527876812139};\\\", \\\"{x:1403,y:974,t:1527876812241};\\\", \\\"{x:1403,y:973,t:1527876812255};\\\", \\\"{x:1407,y:964,t:1527876812271};\\\", \\\"{x:1412,y:953,t:1527876812288};\\\", \\\"{x:1423,y:924,t:1527876812305};\\\", \\\"{x:1429,y:905,t:1527876812321};\\\", \\\"{x:1435,y:887,t:1527876812338};\\\", \\\"{x:1440,y:872,t:1527876812355};\\\", \\\"{x:1447,y:858,t:1527876812371};\\\", \\\"{x:1453,y:844,t:1527876812388};\\\", \\\"{x:1459,y:832,t:1527876812405};\\\", \\\"{x:1464,y:823,t:1527876812421};\\\", \\\"{x:1467,y:816,t:1527876812438};\\\", \\\"{x:1467,y:814,t:1527876812455};\\\", \\\"{x:1468,y:812,t:1527876812471};\\\", \\\"{x:1469,y:811,t:1527876812488};\\\", \\\"{x:1470,y:808,t:1527876812505};\\\", \\\"{x:1472,y:805,t:1527876812522};\\\", \\\"{x:1474,y:800,t:1527876812538};\\\", \\\"{x:1475,y:798,t:1527876812555};\\\", \\\"{x:1478,y:794,t:1527876812572};\\\", \\\"{x:1481,y:789,t:1527876812588};\\\", \\\"{x:1482,y:787,t:1527876812605};\\\", \\\"{x:1487,y:782,t:1527876812622};\\\", \\\"{x:1491,y:775,t:1527876812638};\\\", \\\"{x:1496,y:767,t:1527876812655};\\\", \\\"{x:1504,y:758,t:1527876812673};\\\", \\\"{x:1509,y:752,t:1527876812688};\\\", \\\"{x:1512,y:748,t:1527876812705};\\\", \\\"{x:1513,y:747,t:1527876812722};\\\", \\\"{x:1513,y:746,t:1527876812738};\\\", \\\"{x:1515,y:745,t:1527876812755};\\\", \\\"{x:1516,y:743,t:1527876812772};\\\", \\\"{x:1516,y:742,t:1527876812788};\\\", \\\"{x:1518,y:740,t:1527876812806};\\\", \\\"{x:1519,y:739,t:1527876812823};\\\", \\\"{x:1518,y:739,t:1527876813025};\\\", \\\"{x:1518,y:740,t:1527876813073};\\\", \\\"{x:1518,y:741,t:1527876813089};\\\", \\\"{x:1518,y:742,t:1527876813137};\\\", \\\"{x:1517,y:742,t:1527876813145};\\\", \\\"{x:1517,y:744,t:1527876813169};\\\", \\\"{x:1517,y:745,t:1527876813193};\\\", \\\"{x:1517,y:746,t:1527876813225};\\\", \\\"{x:1516,y:747,t:1527876813239};\\\", \\\"{x:1515,y:748,t:1527876813255};\\\", \\\"{x:1515,y:750,t:1527876813281};\\\", \\\"{x:1514,y:750,t:1527876813297};\\\", \\\"{x:1514,y:751,t:1527876813329};\\\", \\\"{x:1512,y:753,t:1527876813360};\\\", \\\"{x:1512,y:754,t:1527876813416};\\\", \\\"{x:1511,y:755,t:1527876813641};\\\", \\\"{x:1510,y:755,t:1527876813656};\\\", \\\"{x:1510,y:756,t:1527876813672};\\\", \\\"{x:1509,y:757,t:1527876813689};\\\", \\\"{x:1509,y:758,t:1527876813706};\\\", \\\"{x:1508,y:761,t:1527876813723};\\\", \\\"{x:1508,y:762,t:1527876813739};\\\", \\\"{x:1508,y:763,t:1527876813756};\\\", \\\"{x:1508,y:764,t:1527876813773};\\\", \\\"{x:1507,y:766,t:1527876813789};\\\", \\\"{x:1507,y:767,t:1527876813809};\\\", \\\"{x:1507,y:768,t:1527876813825};\\\", \\\"{x:1506,y:770,t:1527876813841};\\\", \\\"{x:1505,y:770,t:1527876813865};\\\", \\\"{x:1505,y:772,t:1527876813873};\\\", \\\"{x:1505,y:773,t:1527876813905};\\\", \\\"{x:1505,y:775,t:1527876813929};\\\", \\\"{x:1505,y:776,t:1527876813960};\\\", \\\"{x:1506,y:776,t:1527876814145};\\\", \\\"{x:1507,y:776,t:1527876814156};\\\", \\\"{x:1509,y:775,t:1527876814173};\\\", \\\"{x:1509,y:774,t:1527876814241};\\\", \\\"{x:1510,y:774,t:1527876814273};\\\", \\\"{x:1510,y:772,t:1527876814290};\\\", \\\"{x:1511,y:772,t:1527876814313};\\\", \\\"{x:1512,y:771,t:1527876814353};\\\", \\\"{x:1512,y:769,t:1527876814370};\\\", \\\"{x:1513,y:768,t:1527876814378};\\\", \\\"{x:1513,y:767,t:1527876814390};\\\", \\\"{x:1513,y:766,t:1527876814406};\\\", \\\"{x:1514,y:765,t:1527876814424};\\\", \\\"{x:1511,y:766,t:1527876814625};\\\", \\\"{x:1509,y:768,t:1527876814641};\\\", \\\"{x:1502,y:778,t:1527876814657};\\\", \\\"{x:1500,y:784,t:1527876814673};\\\", \\\"{x:1497,y:789,t:1527876814690};\\\", \\\"{x:1494,y:796,t:1527876814708};\\\", \\\"{x:1493,y:800,t:1527876814723};\\\", \\\"{x:1491,y:806,t:1527876814740};\\\", \\\"{x:1489,y:810,t:1527876814757};\\\", \\\"{x:1487,y:815,t:1527876814773};\\\", \\\"{x:1486,y:819,t:1527876814791};\\\", \\\"{x:1486,y:822,t:1527876814807};\\\", \\\"{x:1484,y:826,t:1527876814824};\\\", \\\"{x:1483,y:829,t:1527876814840};\\\", \\\"{x:1483,y:832,t:1527876814857};\\\", \\\"{x:1482,y:833,t:1527876814874};\\\", \\\"{x:1482,y:835,t:1527876814890};\\\", \\\"{x:1482,y:836,t:1527876814908};\\\", \\\"{x:1480,y:837,t:1527876814924};\\\", \\\"{x:1481,y:837,t:1527876816034};\\\", \\\"{x:1485,y:834,t:1527876816041};\\\", \\\"{x:1494,y:825,t:1527876816059};\\\", \\\"{x:1500,y:820,t:1527876816075};\\\", \\\"{x:1507,y:816,t:1527876816091};\\\", \\\"{x:1517,y:811,t:1527876816108};\\\", \\\"{x:1532,y:806,t:1527876816125};\\\", \\\"{x:1549,y:800,t:1527876816142};\\\", \\\"{x:1572,y:792,t:1527876816158};\\\", \\\"{x:1596,y:783,t:1527876816175};\\\", \\\"{x:1622,y:772,t:1527876816191};\\\", \\\"{x:1643,y:761,t:1527876816208};\\\", \\\"{x:1661,y:746,t:1527876816225};\\\", \\\"{x:1664,y:743,t:1527876816241};\\\", \\\"{x:1664,y:741,t:1527876816258};\\\", \\\"{x:1667,y:738,t:1527876816275};\\\", \\\"{x:1669,y:736,t:1527876816292};\\\", \\\"{x:1671,y:733,t:1527876816309};\\\", \\\"{x:1672,y:731,t:1527876816325};\\\", \\\"{x:1673,y:731,t:1527876816345};\\\", \\\"{x:1675,y:732,t:1527876816393};\\\", \\\"{x:1681,y:738,t:1527876816408};\\\", \\\"{x:1698,y:765,t:1527876816425};\\\", \\\"{x:1712,y:782,t:1527876816442};\\\", \\\"{x:1724,y:804,t:1527876816458};\\\", \\\"{x:1729,y:820,t:1527876816476};\\\", \\\"{x:1734,y:830,t:1527876816492};\\\", \\\"{x:1735,y:837,t:1527876816508};\\\", \\\"{x:1737,y:839,t:1527876816525};\\\", \\\"{x:1737,y:841,t:1527876816542};\\\", \\\"{x:1737,y:842,t:1527876816577};\\\", \\\"{x:1737,y:843,t:1527876816592};\\\", \\\"{x:1736,y:846,t:1527876816608};\\\", \\\"{x:1728,y:850,t:1527876816625};\\\", \\\"{x:1720,y:854,t:1527876816642};\\\", \\\"{x:1717,y:856,t:1527876816658};\\\", \\\"{x:1713,y:857,t:1527876816675};\\\", \\\"{x:1709,y:857,t:1527876816692};\\\", \\\"{x:1707,y:858,t:1527876816709};\\\", \\\"{x:1702,y:860,t:1527876816725};\\\", \\\"{x:1695,y:860,t:1527876816743};\\\", \\\"{x:1691,y:860,t:1527876816759};\\\", \\\"{x:1684,y:861,t:1527876816776};\\\", \\\"{x:1672,y:862,t:1527876816792};\\\", \\\"{x:1642,y:866,t:1527876816809};\\\", \\\"{x:1609,y:870,t:1527876816825};\\\", \\\"{x:1545,y:870,t:1527876816843};\\\", \\\"{x:1474,y:871,t:1527876816860};\\\", \\\"{x:1397,y:871,t:1527876816875};\\\", \\\"{x:1311,y:871,t:1527876816893};\\\", \\\"{x:1224,y:871,t:1527876816909};\\\", \\\"{x:1140,y:858,t:1527876816926};\\\", \\\"{x:1052,y:846,t:1527876816943};\\\", \\\"{x:960,y:833,t:1527876816960};\\\", \\\"{x:876,y:820,t:1527876816976};\\\", \\\"{x:818,y:812,t:1527876816992};\\\", \\\"{x:742,y:796,t:1527876817009};\\\", \\\"{x:707,y:790,t:1527876817025};\\\", \\\"{x:658,y:773,t:1527876817043};\\\", \\\"{x:619,y:755,t:1527876817059};\\\", \\\"{x:584,y:748,t:1527876817076};\\\", \\\"{x:565,y:745,t:1527876817092};\\\", \\\"{x:549,y:741,t:1527876817110};\\\", \\\"{x:543,y:740,t:1527876817126};\\\", \\\"{x:537,y:738,t:1527876817142};\\\", \\\"{x:536,y:737,t:1527876817159};\\\", \\\"{x:534,y:737,t:1527876817193};\\\", \\\"{x:533,y:737,t:1527876817337};\\\", \\\"{x:531,y:737,t:1527876817345};\\\", \\\"{x:530,y:737,t:1527876817361};\\\", \\\"{x:529,y:737,t:1527876817375};\\\", \\\"{x:527,y:737,t:1527876817392};\\\", \\\"{x:524,y:737,t:1527876817408};\\\", \\\"{x:523,y:737,t:1527876817425};\\\", \\\"{x:521,y:737,t:1527876817442};\\\", \\\"{x:520,y:737,t:1527876817481};\\\", \\\"{x:517,y:739,t:1527876817492};\\\", \\\"{x:515,y:741,t:1527876817508};\\\", \\\"{x:513,y:742,t:1527876817525};\\\" ] }, { \\\"rt\\\": 39195, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 12, \\\"time_elapsed\\\": 448314, \\\"internal_node_id\\\": \\\"0.0-6.0-2.0\\\", \\\"subject\\\": \\\"EER58\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"duration+contained\\\", \\\"q\\\": 8, \\\"clicks\\\": 1.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -B -B -B -X -X -B -X -X -B -X -F -F -C -C -C -C -G -G -G -G -E -E -G -G -C -C -H -H \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:513,y:741,t:1527876819561};\\\", \\\"{x:513,y:740,t:1527876819857};\\\", \\\"{x:514,y:738,t:1527876819864};\\\", \\\"{x:515,y:738,t:1527876819881};\\\", \\\"{x:516,y:737,t:1527876819896};\\\", \\\"{x:518,y:737,t:1527876819911};\\\", \\\"{x:522,y:735,t:1527876819929};\\\", \\\"{x:528,y:732,t:1527876819944};\\\", \\\"{x:536,y:729,t:1527876819961};\\\", \\\"{x:555,y:725,t:1527876819978};\\\", \\\"{x:575,y:725,t:1527876819996};\\\", \\\"{x:594,y:722,t:1527876820012};\\\", \\\"{x:614,y:721,t:1527876820027};\\\", \\\"{x:635,y:721,t:1527876820044};\\\", \\\"{x:664,y:721,t:1527876820060};\\\", \\\"{x:703,y:721,t:1527876820077};\\\", \\\"{x:742,y:721,t:1527876820095};\\\", \\\"{x:776,y:721,t:1527876820111};\\\", \\\"{x:804,y:721,t:1527876820128};\\\", \\\"{x:829,y:721,t:1527876820144};\\\", \\\"{x:856,y:721,t:1527876820160};\\\", \\\"{x:914,y:721,t:1527876820177};\\\", \\\"{x:953,y:721,t:1527876820194};\\\", \\\"{x:982,y:721,t:1527876820210};\\\", \\\"{x:1005,y:721,t:1527876820228};\\\", \\\"{x:1020,y:721,t:1527876820245};\\\", \\\"{x:1023,y:721,t:1527876820260};\\\", \\\"{x:1027,y:720,t:1527876820673};\\\", \\\"{x:1030,y:720,t:1527876820680};\\\", \\\"{x:1038,y:715,t:1527876820694};\\\", \\\"{x:1059,y:705,t:1527876820711};\\\", \\\"{x:1086,y:690,t:1527876820727};\\\", \\\"{x:1128,y:663,t:1527876820745};\\\", \\\"{x:1170,y:624,t:1527876820761};\\\", \\\"{x:1181,y:606,t:1527876820778};\\\", \\\"{x:1183,y:595,t:1527876820794};\\\", \\\"{x:1184,y:587,t:1527876820812};\\\", \\\"{x:1184,y:582,t:1527876820828};\\\", \\\"{x:1184,y:577,t:1527876820844};\\\", \\\"{x:1184,y:570,t:1527876820862};\\\", \\\"{x:1179,y:563,t:1527876820878};\\\", \\\"{x:1170,y:551,t:1527876820894};\\\", \\\"{x:1163,y:541,t:1527876820912};\\\", \\\"{x:1154,y:529,t:1527876820928};\\\", \\\"{x:1146,y:521,t:1527876820944};\\\", \\\"{x:1131,y:512,t:1527876820961};\\\", \\\"{x:1115,y:504,t:1527876820979};\\\", \\\"{x:1099,y:499,t:1527876820995};\\\", \\\"{x:1084,y:495,t:1527876821012};\\\", \\\"{x:1076,y:492,t:1527876821029};\\\", \\\"{x:1075,y:491,t:1527876821065};\\\", \\\"{x:1076,y:491,t:1527876821281};\\\", \\\"{x:1076,y:494,t:1527876821296};\\\", \\\"{x:1077,y:494,t:1527876821311};\\\", \\\"{x:1078,y:495,t:1527876821329};\\\", \\\"{x:1078,y:497,t:1527876821345};\\\", \\\"{x:1078,y:499,t:1527876821361};\\\", \\\"{x:1078,y:500,t:1527876821378};\\\", \\\"{x:1078,y:503,t:1527876821395};\\\", \\\"{x:1078,y:504,t:1527876822105};\\\", \\\"{x:1078,y:500,t:1527876823434};\\\", \\\"{x:1078,y:498,t:1527876823446};\\\", \\\"{x:1078,y:492,t:1527876823464};\\\", \\\"{x:1078,y:488,t:1527876823479};\\\", \\\"{x:1078,y:485,t:1527876823496};\\\", \\\"{x:1078,y:484,t:1527876823521};\\\", \\\"{x:1077,y:485,t:1527876823617};\\\", \\\"{x:1077,y:489,t:1527876823631};\\\", \\\"{x:1075,y:503,t:1527876823647};\\\", \\\"{x:1074,y:519,t:1527876823663};\\\", \\\"{x:1074,y:533,t:1527876823681};\\\", \\\"{x:1074,y:537,t:1527876823696};\\\", \\\"{x:1073,y:545,t:1527876823714};\\\", \\\"{x:1073,y:548,t:1527876823731};\\\", \\\"{x:1073,y:551,t:1527876823747};\\\", \\\"{x:1074,y:554,t:1527876823764};\\\", \\\"{x:1074,y:555,t:1527876823780};\\\", \\\"{x:1074,y:557,t:1527876823797};\\\", \\\"{x:1075,y:559,t:1527876823814};\\\", \\\"{x:1075,y:563,t:1527876823831};\\\", \\\"{x:1077,y:567,t:1527876823847};\\\", \\\"{x:1077,y:570,t:1527876823863};\\\", \\\"{x:1077,y:569,t:1527876824209};\\\", \\\"{x:1078,y:567,t:1527876824217};\\\", \\\"{x:1079,y:565,t:1527876824230};\\\", \\\"{x:1080,y:560,t:1527876824248};\\\", \\\"{x:1080,y:559,t:1527876824265};\\\", \\\"{x:1081,y:558,t:1527876824281};\\\", \\\"{x:1081,y:557,t:1527876825186};\\\", \\\"{x:1081,y:555,t:1527876825198};\\\", \\\"{x:1081,y:552,t:1527876825215};\\\", \\\"{x:1080,y:548,t:1527876825232};\\\", \\\"{x:1079,y:547,t:1527876825248};\\\", \\\"{x:1078,y:545,t:1527876825265};\\\", \\\"{x:1078,y:547,t:1527876825977};\\\", \\\"{x:1078,y:551,t:1527876825985};\\\", \\\"{x:1078,y:555,t:1527876825998};\\\", \\\"{x:1080,y:569,t:1527876826015};\\\", \\\"{x:1088,y:585,t:1527876826032};\\\", \\\"{x:1104,y:610,t:1527876826048};\\\", \\\"{x:1120,y:631,t:1527876826066};\\\", \\\"{x:1138,y:645,t:1527876826082};\\\", \\\"{x:1161,y:661,t:1527876826099};\\\", \\\"{x:1179,y:673,t:1527876826115};\\\", \\\"{x:1198,y:684,t:1527876826132};\\\", \\\"{x:1210,y:687,t:1527876826149};\\\", \\\"{x:1220,y:687,t:1527876826166};\\\", \\\"{x:1228,y:687,t:1527876826183};\\\", \\\"{x:1229,y:687,t:1527876826199};\\\", \\\"{x:1239,y:689,t:1527876826216};\\\", \\\"{x:1255,y:691,t:1527876826233};\\\", \\\"{x:1263,y:692,t:1527876826249};\\\", \\\"{x:1266,y:692,t:1527876826266};\\\", \\\"{x:1270,y:692,t:1527876826282};\\\", \\\"{x:1272,y:692,t:1527876826313};\\\", \\\"{x:1273,y:692,t:1527876826321};\\\", \\\"{x:1274,y:693,t:1527876826333};\\\", \\\"{x:1280,y:695,t:1527876826349};\\\", \\\"{x:1294,y:697,t:1527876826366};\\\", \\\"{x:1306,y:697,t:1527876826382};\\\", \\\"{x:1327,y:697,t:1527876826399};\\\", \\\"{x:1351,y:697,t:1527876826416};\\\", \\\"{x:1392,y:697,t:1527876826433};\\\", \\\"{x:1407,y:697,t:1527876826449};\\\", \\\"{x:1409,y:697,t:1527876826465};\\\", \\\"{x:1409,y:698,t:1527876826496};\\\", \\\"{x:1409,y:699,t:1527876826504};\\\", \\\"{x:1409,y:702,t:1527876826515};\\\", \\\"{x:1409,y:707,t:1527876826532};\\\", \\\"{x:1409,y:713,t:1527876826549};\\\", \\\"{x:1409,y:719,t:1527876826565};\\\", \\\"{x:1402,y:732,t:1527876826583};\\\", \\\"{x:1395,y:745,t:1527876826600};\\\", \\\"{x:1387,y:759,t:1527876826615};\\\", \\\"{x:1379,y:770,t:1527876826633};\\\", \\\"{x:1376,y:774,t:1527876826649};\\\", \\\"{x:1375,y:774,t:1527876826666};\\\", \\\"{x:1374,y:774,t:1527876826754};\\\", \\\"{x:1373,y:774,t:1527876826766};\\\", \\\"{x:1371,y:774,t:1527876826783};\\\", \\\"{x:1370,y:774,t:1527876826801};\\\", \\\"{x:1369,y:774,t:1527876826815};\\\", \\\"{x:1364,y:772,t:1527876826833};\\\", \\\"{x:1359,y:768,t:1527876826850};\\\", \\\"{x:1355,y:765,t:1527876826866};\\\", \\\"{x:1352,y:764,t:1527876826884};\\\", \\\"{x:1350,y:763,t:1527876826901};\\\", \\\"{x:1349,y:763,t:1527876826946};\\\", \\\"{x:1349,y:761,t:1527876827515};\\\", \\\"{x:1349,y:760,t:1527876827545};\\\", \\\"{x:1349,y:759,t:1527876827610};\\\", \\\"{x:1349,y:758,t:1527876830124};\\\", \\\"{x:1349,y:757,t:1527876830139};\\\", \\\"{x:1349,y:756,t:1527876830156};\\\", \\\"{x:1349,y:755,t:1527876830319};\\\", \\\"{x:1349,y:754,t:1527876830558};\\\", \\\"{x:1351,y:757,t:1527876830573};\\\", \\\"{x:1353,y:762,t:1527876830590};\\\", \\\"{x:1355,y:766,t:1527876830607};\\\", \\\"{x:1357,y:768,t:1527876830623};\\\", \\\"{x:1357,y:770,t:1527876830640};\\\", \\\"{x:1357,y:773,t:1527876830657};\\\", \\\"{x:1359,y:774,t:1527876830673};\\\", \\\"{x:1365,y:779,t:1527876830690};\\\", \\\"{x:1376,y:789,t:1527876830707};\\\", \\\"{x:1391,y:795,t:1527876830723};\\\", \\\"{x:1409,y:804,t:1527876830740};\\\", \\\"{x:1431,y:809,t:1527876830757};\\\", \\\"{x:1441,y:809,t:1527876830773};\\\", \\\"{x:1448,y:809,t:1527876830790};\\\", \\\"{x:1452,y:809,t:1527876830807};\\\", \\\"{x:1455,y:809,t:1527876830823};\\\", \\\"{x:1458,y:809,t:1527876830885};\\\", \\\"{x:1459,y:809,t:1527876830893};\\\", \\\"{x:1461,y:810,t:1527876830907};\\\", \\\"{x:1467,y:813,t:1527876830923};\\\", \\\"{x:1473,y:814,t:1527876830940};\\\", \\\"{x:1479,y:816,t:1527876830957};\\\", \\\"{x:1483,y:819,t:1527876830973};\\\", \\\"{x:1488,y:823,t:1527876830991};\\\", \\\"{x:1491,y:827,t:1527876831007};\\\", \\\"{x:1494,y:828,t:1527876831024};\\\", \\\"{x:1494,y:829,t:1527876831040};\\\", \\\"{x:1495,y:830,t:1527876831057};\\\", \\\"{x:1492,y:830,t:1527876831285};\\\", \\\"{x:1492,y:828,t:1527876831566};\\\", \\\"{x:1492,y:827,t:1527876831613};\\\", \\\"{x:1491,y:827,t:1527876831624};\\\", \\\"{x:1490,y:827,t:1527876831642};\\\", \\\"{x:1489,y:826,t:1527876831657};\\\", \\\"{x:1487,y:825,t:1527876831674};\\\", \\\"{x:1484,y:824,t:1527876831692};\\\", \\\"{x:1482,y:823,t:1527876831707};\\\", \\\"{x:1480,y:823,t:1527876831723};\\\", \\\"{x:1479,y:822,t:1527876832685};\\\", \\\"{x:1479,y:821,t:1527876832700};\\\", \\\"{x:1477,y:820,t:1527876832709};\\\", \\\"{x:1472,y:815,t:1527876832726};\\\", \\\"{x:1467,y:811,t:1527876832741};\\\", \\\"{x:1458,y:805,t:1527876832758};\\\", \\\"{x:1452,y:801,t:1527876832775};\\\", \\\"{x:1440,y:794,t:1527876832791};\\\", \\\"{x:1426,y:785,t:1527876832808};\\\", \\\"{x:1413,y:780,t:1527876832824};\\\", \\\"{x:1400,y:774,t:1527876832841};\\\", \\\"{x:1384,y:766,t:1527876832857};\\\", \\\"{x:1367,y:759,t:1527876832874};\\\", \\\"{x:1348,y:756,t:1527876832892};\\\", \\\"{x:1334,y:753,t:1527876832909};\\\", \\\"{x:1321,y:749,t:1527876832926};\\\", \\\"{x:1315,y:747,t:1527876832941};\\\", \\\"{x:1313,y:746,t:1527876832958};\\\", \\\"{x:1317,y:750,t:1527876833093};\\\", \\\"{x:1325,y:755,t:1527876833108};\\\", \\\"{x:1359,y:770,t:1527876833125};\\\", \\\"{x:1382,y:779,t:1527876833142};\\\", \\\"{x:1402,y:784,t:1527876833158};\\\", \\\"{x:1418,y:789,t:1527876833175};\\\", \\\"{x:1426,y:791,t:1527876833192};\\\", \\\"{x:1427,y:792,t:1527876833208};\\\", \\\"{x:1428,y:792,t:1527876833269};\\\", \\\"{x:1429,y:793,t:1527876833277};\\\", \\\"{x:1432,y:794,t:1527876833292};\\\", \\\"{x:1436,y:799,t:1527876833309};\\\", \\\"{x:1442,y:803,t:1527876833325};\\\", \\\"{x:1447,y:807,t:1527876833342};\\\", \\\"{x:1454,y:809,t:1527876833359};\\\", \\\"{x:1463,y:816,t:1527876833375};\\\", \\\"{x:1472,y:822,t:1527876833393};\\\", \\\"{x:1480,y:826,t:1527876833409};\\\", \\\"{x:1484,y:828,t:1527876833425};\\\", \\\"{x:1487,y:830,t:1527876833443};\\\", \\\"{x:1488,y:830,t:1527876833459};\\\", \\\"{x:1486,y:829,t:1527876834350};\\\", \\\"{x:1481,y:825,t:1527876834359};\\\", \\\"{x:1468,y:818,t:1527876834377};\\\", \\\"{x:1457,y:811,t:1527876834393};\\\", \\\"{x:1438,y:801,t:1527876834409};\\\", \\\"{x:1422,y:796,t:1527876834426};\\\", \\\"{x:1412,y:791,t:1527876834443};\\\", \\\"{x:1405,y:787,t:1527876834459};\\\", \\\"{x:1402,y:786,t:1527876834476};\\\", \\\"{x:1397,y:784,t:1527876834493};\\\", \\\"{x:1394,y:782,t:1527876834509};\\\", \\\"{x:1392,y:782,t:1527876834526};\\\", \\\"{x:1390,y:780,t:1527876834543};\\\", \\\"{x:1389,y:780,t:1527876834560};\\\", \\\"{x:1388,y:780,t:1527876834576};\\\", \\\"{x:1387,y:779,t:1527876834593};\\\", \\\"{x:1385,y:778,t:1527876834613};\\\", \\\"{x:1385,y:777,t:1527876834629};\\\", \\\"{x:1383,y:777,t:1527876834643};\\\", \\\"{x:1379,y:774,t:1527876834661};\\\", \\\"{x:1373,y:772,t:1527876834676};\\\", \\\"{x:1359,y:765,t:1527876834693};\\\", \\\"{x:1349,y:762,t:1527876834711};\\\", \\\"{x:1337,y:757,t:1527876834727};\\\", \\\"{x:1324,y:753,t:1527876834743};\\\", \\\"{x:1315,y:750,t:1527876834760};\\\", \\\"{x:1310,y:749,t:1527876834777};\\\", \\\"{x:1310,y:748,t:1527876834793};\\\", \\\"{x:1311,y:748,t:1527876834965};\\\", \\\"{x:1314,y:751,t:1527876834977};\\\", \\\"{x:1319,y:755,t:1527876834993};\\\", \\\"{x:1327,y:761,t:1527876835010};\\\", \\\"{x:1331,y:765,t:1527876835027};\\\", \\\"{x:1335,y:767,t:1527876835043};\\\", \\\"{x:1339,y:768,t:1527876835060};\\\", \\\"{x:1341,y:769,t:1527876835078};\\\", \\\"{x:1343,y:770,t:1527876835093};\\\", \\\"{x:1345,y:772,t:1527876835110};\\\", \\\"{x:1349,y:774,t:1527876835127};\\\", \\\"{x:1357,y:779,t:1527876835143};\\\", \\\"{x:1369,y:785,t:1527876835160};\\\", \\\"{x:1381,y:790,t:1527876835177};\\\", \\\"{x:1391,y:795,t:1527876835193};\\\", \\\"{x:1400,y:799,t:1527876835210};\\\", \\\"{x:1408,y:804,t:1527876835227};\\\", \\\"{x:1416,y:808,t:1527876835243};\\\", \\\"{x:1423,y:812,t:1527876835261};\\\", \\\"{x:1429,y:814,t:1527876835277};\\\", \\\"{x:1433,y:815,t:1527876835293};\\\", \\\"{x:1435,y:816,t:1527876835310};\\\", \\\"{x:1441,y:819,t:1527876835327};\\\", \\\"{x:1447,y:820,t:1527876835344};\\\", \\\"{x:1458,y:824,t:1527876835360};\\\", \\\"{x:1468,y:828,t:1527876835378};\\\", \\\"{x:1474,y:829,t:1527876835394};\\\", \\\"{x:1476,y:829,t:1527876835411};\\\", \\\"{x:1477,y:831,t:1527876835427};\\\", \\\"{x:1477,y:830,t:1527876835486};\\\", \\\"{x:1475,y:826,t:1527876835494};\\\", \\\"{x:1469,y:816,t:1527876835510};\\\", \\\"{x:1458,y:800,t:1527876835527};\\\", \\\"{x:1447,y:785,t:1527876835545};\\\", \\\"{x:1435,y:770,t:1527876835561};\\\", \\\"{x:1424,y:753,t:1527876835577};\\\", \\\"{x:1411,y:736,t:1527876835594};\\\", \\\"{x:1403,y:724,t:1527876835610};\\\", \\\"{x:1393,y:711,t:1527876835627};\\\", \\\"{x:1384,y:700,t:1527876835644};\\\", \\\"{x:1379,y:691,t:1527876835660};\\\", \\\"{x:1377,y:689,t:1527876835678};\\\", \\\"{x:1376,y:689,t:1527876835782};\\\", \\\"{x:1374,y:689,t:1527876835794};\\\", \\\"{x:1370,y:689,t:1527876835810};\\\", \\\"{x:1361,y:692,t:1527876835827};\\\", \\\"{x:1348,y:694,t:1527876835845};\\\", \\\"{x:1338,y:696,t:1527876835861};\\\", \\\"{x:1330,y:696,t:1527876835877};\\\", \\\"{x:1329,y:696,t:1527876836061};\\\", \\\"{x:1329,y:695,t:1527876836125};\\\", \\\"{x:1329,y:693,t:1527876836157};\\\", \\\"{x:1330,y:693,t:1527876836254};\\\", \\\"{x:1331,y:693,t:1527876836319};\\\", \\\"{x:1332,y:693,t:1527876836328};\\\", \\\"{x:1333,y:693,t:1527876836366};\\\", \\\"{x:1334,y:693,t:1527876836378};\\\", \\\"{x:1335,y:693,t:1527876836395};\\\", \\\"{x:1337,y:693,t:1527876836411};\\\", \\\"{x:1338,y:693,t:1527876836429};\\\", \\\"{x:1339,y:693,t:1527876836445};\\\", \\\"{x:1340,y:693,t:1527876836519};\\\", \\\"{x:1341,y:692,t:1527876836528};\\\", \\\"{x:1344,y:690,t:1527876836544};\\\", \\\"{x:1352,y:687,t:1527876836562};\\\", \\\"{x:1364,y:682,t:1527876836579};\\\", \\\"{x:1379,y:674,t:1527876836594};\\\", \\\"{x:1393,y:668,t:1527876836611};\\\", \\\"{x:1406,y:661,t:1527876836628};\\\", \\\"{x:1409,y:658,t:1527876836644};\\\", \\\"{x:1414,y:655,t:1527876836661};\\\", \\\"{x:1415,y:653,t:1527876836678};\\\", \\\"{x:1420,y:651,t:1527876836694};\\\", \\\"{x:1424,y:647,t:1527876836712};\\\", \\\"{x:1427,y:645,t:1527876836728};\\\", \\\"{x:1428,y:644,t:1527876836745};\\\", \\\"{x:1430,y:641,t:1527876836762};\\\", \\\"{x:1430,y:639,t:1527876836779};\\\", \\\"{x:1431,y:637,t:1527876836795};\\\", \\\"{x:1432,y:636,t:1527876836811};\\\", \\\"{x:1433,y:634,t:1527876836901};\\\", \\\"{x:1434,y:634,t:1527876836912};\\\", \\\"{x:1435,y:633,t:1527876836928};\\\", \\\"{x:1435,y:632,t:1527876836989};\\\", \\\"{x:1436,y:631,t:1527876837013};\\\", \\\"{x:1438,y:631,t:1527876837028};\\\", \\\"{x:1439,y:629,t:1527876837045};\\\", \\\"{x:1444,y:625,t:1527876837062};\\\", \\\"{x:1447,y:622,t:1527876837079};\\\", \\\"{x:1451,y:621,t:1527876837095};\\\", \\\"{x:1452,y:620,t:1527876837112};\\\", \\\"{x:1453,y:620,t:1527876837140};\\\", \\\"{x:1453,y:619,t:1527876837148};\\\", \\\"{x:1455,y:619,t:1527876837180};\\\", \\\"{x:1454,y:619,t:1527876837301};\\\", \\\"{x:1449,y:619,t:1527876837312};\\\", \\\"{x:1443,y:623,t:1527876837328};\\\", \\\"{x:1436,y:628,t:1527876837346};\\\", \\\"{x:1432,y:631,t:1527876837362};\\\", \\\"{x:1431,y:631,t:1527876837378};\\\", \\\"{x:1431,y:632,t:1527876837396};\\\", \\\"{x:1431,y:631,t:1527876837533};\\\", \\\"{x:1431,y:630,t:1527876837546};\\\", \\\"{x:1437,y:629,t:1527876837562};\\\", \\\"{x:1441,y:626,t:1527876837579};\\\", \\\"{x:1444,y:624,t:1527876837595};\\\", \\\"{x:1445,y:624,t:1527876838669};\\\", \\\"{x:1451,y:624,t:1527876838940};\\\", \\\"{x:1456,y:624,t:1527876838948};\\\", \\\"{x:1459,y:624,t:1527876838962};\\\", \\\"{x:1461,y:624,t:1527876838979};\\\", \\\"{x:1464,y:624,t:1527876838996};\\\", \\\"{x:1460,y:624,t:1527876839222};\\\", \\\"{x:1459,y:624,t:1527876839230};\\\", \\\"{x:1458,y:621,t:1527876839246};\\\", \\\"{x:1457,y:621,t:1527876839263};\\\", \\\"{x:1457,y:619,t:1527876839281};\\\", \\\"{x:1457,y:614,t:1527876839297};\\\", \\\"{x:1455,y:601,t:1527876839313};\\\", \\\"{x:1450,y:588,t:1527876839331};\\\", \\\"{x:1440,y:567,t:1527876839347};\\\", \\\"{x:1425,y:548,t:1527876839364};\\\", \\\"{x:1411,y:531,t:1527876839380};\\\", \\\"{x:1402,y:523,t:1527876839396};\\\", \\\"{x:1402,y:522,t:1527876839413};\\\", \\\"{x:1402,y:524,t:1527876839509};\\\", \\\"{x:1402,y:531,t:1527876839519};\\\", \\\"{x:1402,y:537,t:1527876839530};\\\", \\\"{x:1410,y:553,t:1527876839547};\\\", \\\"{x:1415,y:558,t:1527876839564};\\\", \\\"{x:1423,y:564,t:1527876839580};\\\", \\\"{x:1426,y:567,t:1527876839597};\\\", \\\"{x:1426,y:569,t:1527876839613};\\\", \\\"{x:1425,y:570,t:1527876839757};\\\", \\\"{x:1424,y:570,t:1527876839765};\\\", \\\"{x:1423,y:570,t:1527876839789};\\\", \\\"{x:1422,y:570,t:1527876839805};\\\", \\\"{x:1421,y:570,t:1527876839821};\\\", \\\"{x:1420,y:569,t:1527876839949};\\\", \\\"{x:1420,y:568,t:1527876839965};\\\", \\\"{x:1420,y:567,t:1527876839981};\\\", \\\"{x:1419,y:565,t:1527876839997};\\\", \\\"{x:1419,y:563,t:1527876840015};\\\", \\\"{x:1418,y:563,t:1527876840805};\\\", \\\"{x:1418,y:562,t:1527876840813};\\\", \\\"{x:1417,y:561,t:1527876840845};\\\", \\\"{x:1416,y:561,t:1527876840869};\\\", \\\"{x:1416,y:560,t:1527876840881};\\\", \\\"{x:1415,y:560,t:1527876840898};\\\", \\\"{x:1415,y:559,t:1527876840914};\\\", \\\"{x:1414,y:559,t:1527876840931};\\\", \\\"{x:1414,y:558,t:1527876844894};\\\", \\\"{x:1414,y:557,t:1527876844926};\\\", \\\"{x:1413,y:557,t:1527876845173};\\\", \\\"{x:1412,y:557,t:1527876845184};\\\", \\\"{x:1410,y:557,t:1527876845213};\\\", \\\"{x:1409,y:557,t:1527876845261};\\\", \\\"{x:1409,y:558,t:1527876845277};\\\", \\\"{x:1408,y:558,t:1527876845309};\\\", \\\"{x:1408,y:559,t:1527876845318};\\\", \\\"{x:1407,y:561,t:1527876845334};\\\", \\\"{x:1403,y:564,t:1527876845351};\\\", \\\"{x:1398,y:568,t:1527876845368};\\\", \\\"{x:1396,y:568,t:1527876845384};\\\", \\\"{x:1394,y:569,t:1527876845401};\\\", \\\"{x:1391,y:569,t:1527876845549};\\\", \\\"{x:1384,y:569,t:1527876845557};\\\", \\\"{x:1374,y:569,t:1527876845569};\\\", \\\"{x:1358,y:569,t:1527876845585};\\\", \\\"{x:1344,y:569,t:1527876845602};\\\", \\\"{x:1333,y:569,t:1527876845619};\\\", \\\"{x:1324,y:567,t:1527876845634};\\\", \\\"{x:1319,y:567,t:1527876845651};\\\", \\\"{x:1314,y:567,t:1527876845669};\\\", \\\"{x:1314,y:566,t:1527876845709};\\\", \\\"{x:1313,y:566,t:1527876845814};\\\", \\\"{x:1311,y:566,t:1527876845869};\\\", \\\"{x:1309,y:565,t:1527876845885};\\\", \\\"{x:1302,y:563,t:1527876845902};\\\", \\\"{x:1297,y:561,t:1527876845919};\\\", \\\"{x:1293,y:561,t:1527876845935};\\\", \\\"{x:1291,y:560,t:1527876845952};\\\", \\\"{x:1290,y:560,t:1527876845968};\\\", \\\"{x:1287,y:560,t:1527876845985};\\\", \\\"{x:1284,y:559,t:1527876846002};\\\", \\\"{x:1283,y:559,t:1527876846019};\\\", \\\"{x:1281,y:558,t:1527876846036};\\\", \\\"{x:1280,y:558,t:1527876846051};\\\", \\\"{x:1278,y:558,t:1527876846069};\\\", \\\"{x:1277,y:557,t:1527876846087};\\\", \\\"{x:1276,y:556,t:1527876846597};\\\", \\\"{x:1276,y:557,t:1527876847341};\\\", \\\"{x:1278,y:557,t:1527876847353};\\\", \\\"{x:1285,y:558,t:1527876847370};\\\", \\\"{x:1290,y:559,t:1527876847387};\\\", \\\"{x:1304,y:559,t:1527876847402};\\\", \\\"{x:1319,y:559,t:1527876847420};\\\", \\\"{x:1351,y:559,t:1527876847437};\\\", \\\"{x:1377,y:559,t:1527876847453};\\\", \\\"{x:1420,y:559,t:1527876847470};\\\", \\\"{x:1450,y:557,t:1527876847486};\\\", \\\"{x:1469,y:557,t:1527876847503};\\\", \\\"{x:1477,y:556,t:1527876847520};\\\", \\\"{x:1478,y:556,t:1527876847536};\\\", \\\"{x:1475,y:556,t:1527876847726};\\\", \\\"{x:1470,y:558,t:1527876847737};\\\", \\\"{x:1467,y:559,t:1527876847754};\\\", \\\"{x:1463,y:559,t:1527876847769};\\\", \\\"{x:1462,y:559,t:1527876847787};\\\", \\\"{x:1461,y:559,t:1527876847803};\\\", \\\"{x:1460,y:559,t:1527876847861};\\\", \\\"{x:1459,y:559,t:1527876847871};\\\", \\\"{x:1457,y:559,t:1527876847887};\\\", \\\"{x:1453,y:559,t:1527876847904};\\\", \\\"{x:1451,y:559,t:1527876847920};\\\", \\\"{x:1450,y:559,t:1527876847937};\\\", \\\"{x:1448,y:559,t:1527876847954};\\\", \\\"{x:1445,y:559,t:1527876847971};\\\", \\\"{x:1442,y:559,t:1527876847987};\\\", \\\"{x:1437,y:559,t:1527876848004};\\\", \\\"{x:1431,y:559,t:1527876848021};\\\", \\\"{x:1429,y:559,t:1527876848037};\\\", \\\"{x:1427,y:559,t:1527876848054};\\\", \\\"{x:1426,y:559,t:1527876848110};\\\", \\\"{x:1425,y:560,t:1527876848133};\\\", \\\"{x:1424,y:560,t:1527876848141};\\\", \\\"{x:1423,y:560,t:1527876848157};\\\", \\\"{x:1422,y:560,t:1527876848171};\\\", \\\"{x:1421,y:561,t:1527876848186};\\\", \\\"{x:1420,y:562,t:1527876848205};\\\", \\\"{x:1418,y:562,t:1527876848221};\\\", \\\"{x:1417,y:563,t:1527876848245};\\\", \\\"{x:1416,y:563,t:1527876848726};\\\", \\\"{x:1416,y:564,t:1527876848737};\\\", \\\"{x:1414,y:565,t:1527876848754};\\\", \\\"{x:1412,y:565,t:1527876848770};\\\", \\\"{x:1412,y:566,t:1527876848787};\\\", \\\"{x:1407,y:569,t:1527876851214};\\\", \\\"{x:1400,y:571,t:1527876851222};\\\", \\\"{x:1371,y:581,t:1527876851239};\\\", \\\"{x:1329,y:592,t:1527876851256};\\\", \\\"{x:1280,y:597,t:1527876851273};\\\", \\\"{x:1233,y:603,t:1527876851289};\\\", \\\"{x:1191,y:603,t:1527876851306};\\\", \\\"{x:1157,y:603,t:1527876851323};\\\", \\\"{x:1117,y:603,t:1527876851340};\\\", \\\"{x:1075,y:603,t:1527876851356};\\\", \\\"{x:1012,y:601,t:1527876851373};\\\", \\\"{x:976,y:597,t:1527876851390};\\\", \\\"{x:934,y:590,t:1527876851408};\\\", \\\"{x:912,y:585,t:1527876851422};\\\", \\\"{x:893,y:581,t:1527876851439};\\\", \\\"{x:880,y:580,t:1527876851456};\\\", \\\"{x:864,y:578,t:1527876851472};\\\", \\\"{x:856,y:576,t:1527876851489};\\\", \\\"{x:853,y:576,t:1527876851506};\\\", \\\"{x:851,y:574,t:1527876851523};\\\", \\\"{x:847,y:572,t:1527876851539};\\\", \\\"{x:840,y:569,t:1527876851556};\\\", \\\"{x:837,y:568,t:1527876851573};\\\", \\\"{x:835,y:566,t:1527876851590};\\\", \\\"{x:834,y:565,t:1527876851613};\\\", \\\"{x:833,y:564,t:1527876851623};\\\", \\\"{x:831,y:562,t:1527876851641};\\\", \\\"{x:829,y:562,t:1527876851656};\\\", \\\"{x:828,y:561,t:1527876851673};\\\", \\\"{x:827,y:560,t:1527876851718};\\\", \\\"{x:827,y:559,t:1527876851733};\\\", \\\"{x:827,y:556,t:1527876851740};\\\", \\\"{x:826,y:551,t:1527876851758};\\\", \\\"{x:824,y:545,t:1527876851773};\\\", \\\"{x:823,y:539,t:1527876851791};\\\", \\\"{x:821,y:534,t:1527876851807};\\\", \\\"{x:821,y:532,t:1527876851823};\\\", \\\"{x:821,y:530,t:1527876851844};\\\", \\\"{x:822,y:530,t:1527876852484};\\\", \\\"{x:825,y:532,t:1527876852491};\\\", \\\"{x:830,y:535,t:1527876852507};\\\", \\\"{x:838,y:541,t:1527876852524};\\\", \\\"{x:840,y:543,t:1527876852540};\\\", \\\"{x:844,y:543,t:1527876853197};\\\", \\\"{x:851,y:543,t:1527876853208};\\\", \\\"{x:878,y:543,t:1527876853226};\\\", \\\"{x:933,y:548,t:1527876853241};\\\", \\\"{x:1025,y:552,t:1527876853259};\\\", \\\"{x:1126,y:558,t:1527876853274};\\\", \\\"{x:1229,y:558,t:1527876853292};\\\", \\\"{x:1346,y:560,t:1527876853308};\\\", \\\"{x:1386,y:560,t:1527876853325};\\\", \\\"{x:1409,y:561,t:1527876853341};\\\", \\\"{x:1416,y:562,t:1527876853358};\\\", \\\"{x:1419,y:562,t:1527876853428};\\\", \\\"{x:1420,y:562,t:1527876853444};\\\", \\\"{x:1423,y:562,t:1527876853460};\\\", \\\"{x:1424,y:561,t:1527876853475};\\\", \\\"{x:1428,y:560,t:1527876853492};\\\", \\\"{x:1431,y:559,t:1527876853509};\\\", \\\"{x:1433,y:559,t:1527876853525};\\\", \\\"{x:1433,y:558,t:1527876853542};\\\", \\\"{x:1431,y:558,t:1527876853845};\\\", \\\"{x:1430,y:558,t:1527876853859};\\\", \\\"{x:1428,y:558,t:1527876853876};\\\", \\\"{x:1427,y:558,t:1527876853892};\\\", \\\"{x:1426,y:558,t:1527876853909};\\\", \\\"{x:1425,y:558,t:1527876853926};\\\", \\\"{x:1423,y:559,t:1527876854101};\\\", \\\"{x:1423,y:566,t:1527876854108};\\\", \\\"{x:1423,y:584,t:1527876854126};\\\", \\\"{x:1426,y:594,t:1527876854143};\\\", \\\"{x:1430,y:603,t:1527876854159};\\\", \\\"{x:1433,y:609,t:1527876854176};\\\", \\\"{x:1437,y:615,t:1527876854193};\\\", \\\"{x:1442,y:625,t:1527876854209};\\\", \\\"{x:1447,y:633,t:1527876854226};\\\", \\\"{x:1452,y:639,t:1527876854244};\\\", \\\"{x:1454,y:641,t:1527876854260};\\\", \\\"{x:1454,y:642,t:1527876854276};\\\", \\\"{x:1454,y:641,t:1527876854861};\\\", \\\"{x:1454,y:639,t:1527876854876};\\\", \\\"{x:1453,y:638,t:1527876854893};\\\", \\\"{x:1453,y:636,t:1527876854910};\\\", \\\"{x:1453,y:635,t:1527876854927};\\\", \\\"{x:1452,y:633,t:1527876854942};\\\", \\\"{x:1451,y:632,t:1527876854976};\\\", \\\"{x:1450,y:631,t:1527876855012};\\\", \\\"{x:1450,y:630,t:1527876855093};\\\", \\\"{x:1455,y:630,t:1527876855454};\\\", \\\"{x:1465,y:630,t:1527876855461};\\\", \\\"{x:1488,y:630,t:1527876855477};\\\", \\\"{x:1515,y:630,t:1527876855495};\\\", \\\"{x:1536,y:632,t:1527876855511};\\\", \\\"{x:1544,y:634,t:1527876855527};\\\", \\\"{x:1545,y:634,t:1527876855544};\\\", \\\"{x:1546,y:634,t:1527876855725};\\\", \\\"{x:1548,y:634,t:1527876855732};\\\", \\\"{x:1551,y:634,t:1527876855744};\\\", \\\"{x:1558,y:633,t:1527876855761};\\\", \\\"{x:1568,y:631,t:1527876855777};\\\", \\\"{x:1580,y:629,t:1527876855794};\\\", \\\"{x:1585,y:628,t:1527876855811};\\\", \\\"{x:1590,y:628,t:1527876855828};\\\", \\\"{x:1593,y:626,t:1527876855844};\\\", \\\"{x:1596,y:626,t:1527876855861};\\\", \\\"{x:1596,y:625,t:1527876856398};\\\", \\\"{x:1595,y:625,t:1527876856411};\\\", \\\"{x:1593,y:625,t:1527876856428};\\\", \\\"{x:1590,y:625,t:1527876856445};\\\", \\\"{x:1588,y:625,t:1527876856461};\\\", \\\"{x:1586,y:625,t:1527876856478};\\\", \\\"{x:1584,y:625,t:1527876856496};\\\", \\\"{x:1581,y:625,t:1527876856511};\\\", \\\"{x:1580,y:625,t:1527876856528};\\\", \\\"{x:1576,y:625,t:1527876856546};\\\", \\\"{x:1574,y:625,t:1527876856561};\\\", \\\"{x:1571,y:625,t:1527876856578};\\\", \\\"{x:1570,y:625,t:1527876856595};\\\", \\\"{x:1568,y:625,t:1527876856611};\\\", \\\"{x:1568,y:620,t:1527876856693};\\\", \\\"{x:1568,y:613,t:1527876856701};\\\", \\\"{x:1568,y:606,t:1527876856711};\\\", \\\"{x:1572,y:588,t:1527876856728};\\\", \\\"{x:1577,y:567,t:1527876856745};\\\", \\\"{x:1579,y:554,t:1527876856761};\\\", \\\"{x:1579,y:542,t:1527876856778};\\\", \\\"{x:1579,y:532,t:1527876856795};\\\", \\\"{x:1579,y:526,t:1527876856812};\\\", \\\"{x:1578,y:521,t:1527876856828};\\\", \\\"{x:1578,y:515,t:1527876856845};\\\", \\\"{x:1577,y:511,t:1527876856862};\\\", \\\"{x:1577,y:508,t:1527876856878};\\\", \\\"{x:1577,y:504,t:1527876856895};\\\", \\\"{x:1575,y:501,t:1527876856913};\\\", \\\"{x:1574,y:499,t:1527876856928};\\\", \\\"{x:1574,y:496,t:1527876856945};\\\", \\\"{x:1573,y:494,t:1527876856962};\\\", \\\"{x:1573,y:493,t:1527876857005};\\\", \\\"{x:1570,y:492,t:1527876857228};\\\", \\\"{x:1547,y:503,t:1527876857245};\\\", \\\"{x:1500,y:525,t:1527876857262};\\\", \\\"{x:1426,y:541,t:1527876857278};\\\", \\\"{x:1332,y:555,t:1527876857295};\\\", \\\"{x:1218,y:571,t:1527876857312};\\\", \\\"{x:1074,y:593,t:1527876857329};\\\", \\\"{x:909,y:608,t:1527876857346};\\\", \\\"{x:735,y:628,t:1527876857362};\\\", \\\"{x:573,y:646,t:1527876857379};\\\", \\\"{x:453,y:650,t:1527876857395};\\\", \\\"{x:373,y:659,t:1527876857410};\\\", \\\"{x:337,y:666,t:1527876857428};\\\", \\\"{x:309,y:674,t:1527876857445};\\\", \\\"{x:301,y:679,t:1527876857461};\\\", \\\"{x:291,y:687,t:1527876857478};\\\", \\\"{x:281,y:697,t:1527876857495};\\\", \\\"{x:267,y:714,t:1527876857512};\\\", \\\"{x:255,y:730,t:1527876857529};\\\", \\\"{x:248,y:742,t:1527876857546};\\\", \\\"{x:248,y:746,t:1527876857562};\\\", \\\"{x:248,y:749,t:1527876857613};\\\", \\\"{x:248,y:753,t:1527876857629};\\\", \\\"{x:252,y:759,t:1527876857645};\\\", \\\"{x:256,y:761,t:1527876857663};\\\", \\\"{x:258,y:761,t:1527876857679};\\\", \\\"{x:265,y:761,t:1527876857696};\\\", \\\"{x:279,y:760,t:1527876857713};\\\", \\\"{x:313,y:760,t:1527876857729};\\\", \\\"{x:380,y:760,t:1527876857746};\\\", \\\"{x:466,y:760,t:1527876857763};\\\", \\\"{x:531,y:759,t:1527876857780};\\\", \\\"{x:599,y:752,t:1527876857797};\\\", \\\"{x:620,y:746,t:1527876857813};\\\", \\\"{x:623,y:744,t:1527876857830};\\\", \\\"{x:623,y:743,t:1527876857847};\\\", \\\"{x:620,y:743,t:1527876857965};\\\", \\\"{x:614,y:743,t:1527876857980};\\\", \\\"{x:577,y:739,t:1527876857997};\\\", \\\"{x:551,y:739,t:1527876858015};\\\", \\\"{x:535,y:739,t:1527876858030};\\\", \\\"{x:531,y:739,t:1527876858045};\\\", \\\"{x:530,y:737,t:1527876858925};\\\", \\\"{x:530,y:736,t:1527876858931};\\\", \\\"{x:530,y:735,t:1527876858948};\\\", \\\"{x:530,y:734,t:1527876858963};\\\" ] }, { \\\"rt\\\": 27172, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 13, \\\"time_elapsed\\\": 476695, \\\"internal_node_id\\\": \\\"0.0-6.0-3.0\\\", \\\"subject\\\": \\\"EER58\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime+before+endtime+during\\\", \\\"q\\\": 9, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 0, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-J -J -J -J -J -I -I -E -E -E -E -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:530,y:733,t:1527876860445};\\\", \\\"{x:531,y:732,t:1527876861276};\\\", \\\"{x:534,y:730,t:1527876861285};\\\", \\\"{x:555,y:719,t:1527876861303};\\\", \\\"{x:590,y:709,t:1527876861319};\\\", \\\"{x:607,y:703,t:1527876861330};\\\", \\\"{x:637,y:695,t:1527876861347};\\\", \\\"{x:699,y:678,t:1527876861364};\\\", \\\"{x:735,y:663,t:1527876861381};\\\", \\\"{x:778,y:647,t:1527876861396};\\\", \\\"{x:807,y:639,t:1527876861414};\\\", \\\"{x:828,y:632,t:1527876861431};\\\", \\\"{x:846,y:628,t:1527876861447};\\\", \\\"{x:868,y:622,t:1527876861464};\\\", \\\"{x:889,y:619,t:1527876861481};\\\", \\\"{x:911,y:614,t:1527876861498};\\\", \\\"{x:933,y:611,t:1527876861515};\\\", \\\"{x:965,y:608,t:1527876861533};\\\", \\\"{x:992,y:608,t:1527876861548};\\\", \\\"{x:1022,y:608,t:1527876861565};\\\", \\\"{x:1068,y:605,t:1527876861582};\\\", \\\"{x:1116,y:599,t:1527876861598};\\\", \\\"{x:1159,y:594,t:1527876861615};\\\", \\\"{x:1205,y:593,t:1527876861632};\\\", \\\"{x:1236,y:588,t:1527876861648};\\\", \\\"{x:1256,y:586,t:1527876861665};\\\", \\\"{x:1269,y:586,t:1527876861682};\\\", \\\"{x:1272,y:586,t:1527876861699};\\\", \\\"{x:1273,y:586,t:1527876861715};\\\", \\\"{x:1274,y:586,t:1527876861733};\\\", \\\"{x:1277,y:589,t:1527876861748};\\\", \\\"{x:1280,y:602,t:1527876861765};\\\", \\\"{x:1289,y:620,t:1527876861783};\\\", \\\"{x:1308,y:643,t:1527876861799};\\\", \\\"{x:1318,y:658,t:1527876861815};\\\", \\\"{x:1319,y:658,t:1527876862877};\\\", \\\"{x:1320,y:658,t:1527876863021};\\\", \\\"{x:1320,y:657,t:1527876863053};\\\", \\\"{x:1320,y:655,t:1527876863077};\\\", \\\"{x:1320,y:653,t:1527876863093};\\\", \\\"{x:1319,y:652,t:1527876863100};\\\", \\\"{x:1318,y:650,t:1527876863117};\\\", \\\"{x:1317,y:649,t:1527876863132};\\\", \\\"{x:1316,y:648,t:1527876863149};\\\", \\\"{x:1315,y:647,t:1527876863166};\\\", \\\"{x:1314,y:647,t:1527876863182};\\\", \\\"{x:1313,y:646,t:1527876863199};\\\", \\\"{x:1312,y:645,t:1527876863221};\\\", \\\"{x:1311,y:644,t:1527876863233};\\\", \\\"{x:1310,y:644,t:1527876863250};\\\", \\\"{x:1310,y:643,t:1527876863267};\\\", \\\"{x:1309,y:643,t:1527876863282};\\\", \\\"{x:1309,y:642,t:1527876863299};\\\", \\\"{x:1308,y:642,t:1527876863317};\\\", \\\"{x:1308,y:641,t:1527876863333};\\\", \\\"{x:1307,y:639,t:1527876864246};\\\", \\\"{x:1311,y:630,t:1527876864253};\\\", \\\"{x:1320,y:621,t:1527876864267};\\\", \\\"{x:1347,y:589,t:1527876864284};\\\", \\\"{x:1376,y:558,t:1527876864299};\\\", \\\"{x:1416,y:518,t:1527876864317};\\\", \\\"{x:1433,y:499,t:1527876864332};\\\", \\\"{x:1454,y:476,t:1527876864349};\\\", \\\"{x:1470,y:461,t:1527876864367};\\\", \\\"{x:1482,y:452,t:1527876864384};\\\", \\\"{x:1485,y:448,t:1527876864400};\\\", \\\"{x:1487,y:448,t:1527876864417};\\\", \\\"{x:1487,y:450,t:1527876864566};\\\", \\\"{x:1487,y:454,t:1527876864584};\\\", \\\"{x:1487,y:462,t:1527876864599};\\\", \\\"{x:1487,y:483,t:1527876864617};\\\", \\\"{x:1495,y:520,t:1527876864633};\\\", \\\"{x:1509,y:565,t:1527876864650};\\\", \\\"{x:1518,y:604,t:1527876864666};\\\", \\\"{x:1527,y:630,t:1527876864683};\\\", \\\"{x:1534,y:652,t:1527876864700};\\\", \\\"{x:1546,y:678,t:1527876864716};\\\", \\\"{x:1552,y:694,t:1527876864733};\\\", \\\"{x:1561,y:709,t:1527876864751};\\\", \\\"{x:1571,y:725,t:1527876864767};\\\", \\\"{x:1581,y:740,t:1527876864784};\\\", \\\"{x:1591,y:750,t:1527876864801};\\\", \\\"{x:1600,y:757,t:1527876864817};\\\", \\\"{x:1608,y:761,t:1527876864833};\\\", \\\"{x:1620,y:762,t:1527876864849};\\\", \\\"{x:1627,y:762,t:1527876864867};\\\", \\\"{x:1631,y:761,t:1527876864883};\\\", \\\"{x:1637,y:757,t:1527876864901};\\\", \\\"{x:1640,y:753,t:1527876864917};\\\", \\\"{x:1642,y:749,t:1527876864934};\\\", \\\"{x:1644,y:745,t:1527876864951};\\\", \\\"{x:1645,y:742,t:1527876864967};\\\", \\\"{x:1647,y:739,t:1527876864984};\\\", \\\"{x:1647,y:738,t:1527876865000};\\\", \\\"{x:1648,y:738,t:1527876865053};\\\", \\\"{x:1649,y:738,t:1527876865066};\\\", \\\"{x:1653,y:740,t:1527876865084};\\\", \\\"{x:1657,y:745,t:1527876865101};\\\", \\\"{x:1662,y:750,t:1527876865117};\\\", \\\"{x:1669,y:758,t:1527876865133};\\\", \\\"{x:1678,y:767,t:1527876865151};\\\", \\\"{x:1692,y:780,t:1527876865167};\\\", \\\"{x:1706,y:793,t:1527876865183};\\\", \\\"{x:1716,y:804,t:1527876865200};\\\", \\\"{x:1723,y:812,t:1527876865216};\\\", \\\"{x:1728,y:818,t:1527876865233};\\\", \\\"{x:1731,y:821,t:1527876865250};\\\", \\\"{x:1732,y:823,t:1527876865266};\\\", \\\"{x:1732,y:824,t:1527876865283};\\\", \\\"{x:1733,y:827,t:1527876865300};\\\", \\\"{x:1733,y:830,t:1527876865316};\\\", \\\"{x:1733,y:832,t:1527876865333};\\\", \\\"{x:1732,y:838,t:1527876865350};\\\", \\\"{x:1729,y:846,t:1527876865366};\\\", \\\"{x:1723,y:856,t:1527876865383};\\\", \\\"{x:1714,y:868,t:1527876865401};\\\", \\\"{x:1703,y:877,t:1527876865417};\\\", \\\"{x:1687,y:890,t:1527876865433};\\\", \\\"{x:1672,y:899,t:1527876865451};\\\", \\\"{x:1655,y:911,t:1527876865467};\\\", \\\"{x:1638,y:917,t:1527876865484};\\\", \\\"{x:1621,y:924,t:1527876865501};\\\", \\\"{x:1609,y:924,t:1527876865516};\\\", \\\"{x:1589,y:924,t:1527876865534};\\\", \\\"{x:1572,y:926,t:1527876865550};\\\", \\\"{x:1549,y:926,t:1527876865566};\\\", \\\"{x:1524,y:926,t:1527876865584};\\\", \\\"{x:1502,y:925,t:1527876865600};\\\", \\\"{x:1486,y:924,t:1527876865618};\\\", \\\"{x:1470,y:922,t:1527876865634};\\\", \\\"{x:1455,y:922,t:1527876865651};\\\", \\\"{x:1436,y:920,t:1527876865668};\\\", \\\"{x:1421,y:917,t:1527876865684};\\\", \\\"{x:1399,y:912,t:1527876865701};\\\", \\\"{x:1382,y:907,t:1527876865716};\\\", \\\"{x:1366,y:902,t:1527876865733};\\\", \\\"{x:1353,y:899,t:1527876865750};\\\", \\\"{x:1339,y:894,t:1527876865767};\\\", \\\"{x:1328,y:893,t:1527876865783};\\\", \\\"{x:1319,y:891,t:1527876865799};\\\", \\\"{x:1310,y:889,t:1527876865817};\\\", \\\"{x:1302,y:887,t:1527876865832};\\\", \\\"{x:1292,y:883,t:1527876865849};\\\", \\\"{x:1276,y:878,t:1527876865867};\\\", \\\"{x:1257,y:873,t:1527876865882};\\\", \\\"{x:1240,y:868,t:1527876865900};\\\", \\\"{x:1226,y:859,t:1527876865917};\\\", \\\"{x:1214,y:850,t:1527876865933};\\\", \\\"{x:1206,y:841,t:1527876865950};\\\", \\\"{x:1197,y:830,t:1527876865967};\\\", \\\"{x:1193,y:826,t:1527876865983};\\\", \\\"{x:1189,y:820,t:1527876866000};\\\", \\\"{x:1188,y:818,t:1527876866017};\\\", \\\"{x:1189,y:817,t:1527876866157};\\\", \\\"{x:1193,y:817,t:1527876866168};\\\", \\\"{x:1200,y:819,t:1527876866184};\\\", \\\"{x:1210,y:823,t:1527876866200};\\\", \\\"{x:1216,y:826,t:1527876866219};\\\", \\\"{x:1221,y:826,t:1527876866233};\\\", \\\"{x:1223,y:826,t:1527876866250};\\\", \\\"{x:1222,y:826,t:1527876866453};\\\", \\\"{x:1221,y:825,t:1527876866467};\\\", \\\"{x:1219,y:825,t:1527876866484};\\\", \\\"{x:1218,y:825,t:1527876866500};\\\", \\\"{x:1217,y:825,t:1527876866540};\\\", \\\"{x:1216,y:825,t:1527876866724};\\\", \\\"{x:1216,y:824,t:1527876867238};\\\", \\\"{x:1216,y:823,t:1527876867261};\\\", \\\"{x:1214,y:821,t:1527876867367};\\\", \\\"{x:1214,y:820,t:1527876868971};\\\", \\\"{x:1213,y:819,t:1527876869011};\\\", \\\"{x:1213,y:818,t:1527876869060};\\\", \\\"{x:1213,y:817,t:1527876869068};\\\", \\\"{x:1211,y:815,t:1527876869189};\\\", \\\"{x:1211,y:814,t:1527876869277};\\\", \\\"{x:1212,y:814,t:1527876869427};\\\", \\\"{x:1213,y:814,t:1527876869436};\\\", \\\"{x:1214,y:816,t:1527876869451};\\\", \\\"{x:1218,y:819,t:1527876869467};\\\", \\\"{x:1219,y:821,t:1527876869485};\\\", \\\"{x:1219,y:823,t:1527876869501};\\\", \\\"{x:1219,y:824,t:1527876869797};\\\", \\\"{x:1219,y:825,t:1527876869805};\\\", \\\"{x:1219,y:826,t:1527876869821};\\\", \\\"{x:1218,y:826,t:1527876869835};\\\", \\\"{x:1216,y:828,t:1527876869853};\\\", \\\"{x:1215,y:830,t:1527876869869};\\\", \\\"{x:1213,y:833,t:1527876869886};\\\", \\\"{x:1212,y:834,t:1527876869902};\\\", \\\"{x:1211,y:836,t:1527876869920};\\\", \\\"{x:1210,y:836,t:1527876869936};\\\", \\\"{x:1210,y:837,t:1527876869953};\\\", \\\"{x:1209,y:837,t:1527876870093};\\\", \\\"{x:1208,y:837,t:1527876870629};\\\", \\\"{x:1207,y:838,t:1527876870677};\\\", \\\"{x:1207,y:839,t:1527876870709};\\\", \\\"{x:1206,y:839,t:1527876870780};\\\", \\\"{x:1205,y:839,t:1527876871085};\\\", \\\"{x:1205,y:838,t:1527876871103};\\\", \\\"{x:1205,y:836,t:1527876871120};\\\", \\\"{x:1205,y:833,t:1527876871135};\\\", \\\"{x:1205,y:830,t:1527876871153};\\\", \\\"{x:1205,y:827,t:1527876871170};\\\", \\\"{x:1205,y:825,t:1527876871186};\\\", \\\"{x:1204,y:825,t:1527876871237};\\\", \\\"{x:1204,y:823,t:1527876871268};\\\", \\\"{x:1202,y:820,t:1527876871286};\\\", \\\"{x:1197,y:809,t:1527876871303};\\\", \\\"{x:1187,y:795,t:1527876871320};\\\", \\\"{x:1180,y:781,t:1527876871335};\\\", \\\"{x:1176,y:774,t:1527876871353};\\\", \\\"{x:1175,y:770,t:1527876871370};\\\", \\\"{x:1173,y:768,t:1527876871385};\\\", \\\"{x:1172,y:768,t:1527876871404};\\\", \\\"{x:1172,y:766,t:1527876871701};\\\", \\\"{x:1173,y:766,t:1527876871709};\\\", \\\"{x:1173,y:765,t:1527876871720};\\\", \\\"{x:1174,y:763,t:1527876871749};\\\", \\\"{x:1176,y:761,t:1527876872821};\\\", \\\"{x:1176,y:760,t:1527876872837};\\\", \\\"{x:1177,y:760,t:1527876872853};\\\", \\\"{x:1177,y:759,t:1527876872870};\\\", \\\"{x:1177,y:758,t:1527876872888};\\\", \\\"{x:1179,y:757,t:1527876872904};\\\", \\\"{x:1181,y:755,t:1527876872920};\\\", \\\"{x:1182,y:754,t:1527876872937};\\\", \\\"{x:1183,y:754,t:1527876872954};\\\", \\\"{x:1183,y:752,t:1527876872969};\\\", \\\"{x:1184,y:750,t:1527876873693};\\\", \\\"{x:1186,y:748,t:1527876873704};\\\", \\\"{x:1188,y:743,t:1527876873720};\\\", \\\"{x:1191,y:734,t:1527876873737};\\\", \\\"{x:1197,y:723,t:1527876873753};\\\", \\\"{x:1204,y:712,t:1527876873771};\\\", \\\"{x:1211,y:700,t:1527876873787};\\\", \\\"{x:1219,y:687,t:1527876873804};\\\", \\\"{x:1231,y:662,t:1527876873820};\\\", \\\"{x:1236,y:651,t:1527876873837};\\\", \\\"{x:1246,y:631,t:1527876873854};\\\", \\\"{x:1251,y:619,t:1527876873870};\\\", \\\"{x:1256,y:608,t:1527876873887};\\\", \\\"{x:1257,y:603,t:1527876873904};\\\", \\\"{x:1259,y:600,t:1527876873921};\\\", \\\"{x:1260,y:597,t:1527876873937};\\\", \\\"{x:1261,y:596,t:1527876873954};\\\", \\\"{x:1262,y:594,t:1527876873971};\\\", \\\"{x:1264,y:591,t:1527876873987};\\\", \\\"{x:1265,y:588,t:1527876874003};\\\", \\\"{x:1268,y:582,t:1527876874021};\\\", \\\"{x:1269,y:581,t:1527876874038};\\\", \\\"{x:1270,y:577,t:1527876874054};\\\", \\\"{x:1272,y:575,t:1527876874071};\\\", \\\"{x:1274,y:571,t:1527876874088};\\\", \\\"{x:1278,y:564,t:1527876874104};\\\", \\\"{x:1281,y:555,t:1527876874121};\\\", \\\"{x:1285,y:548,t:1527876874138};\\\", \\\"{x:1288,y:542,t:1527876874154};\\\", \\\"{x:1289,y:539,t:1527876874171};\\\", \\\"{x:1288,y:539,t:1527876874357};\\\", \\\"{x:1287,y:539,t:1527876874371};\\\", \\\"{x:1283,y:541,t:1527876874388};\\\", \\\"{x:1279,y:544,t:1527876874404};\\\", \\\"{x:1273,y:553,t:1527876874421};\\\", \\\"{x:1271,y:556,t:1527876874438};\\\", \\\"{x:1271,y:560,t:1527876874454};\\\", \\\"{x:1269,y:561,t:1527876874471};\\\", \\\"{x:1270,y:561,t:1527876874693};\\\", \\\"{x:1271,y:561,t:1527876874704};\\\", \\\"{x:1273,y:561,t:1527876874720};\\\", \\\"{x:1274,y:560,t:1527876874738};\\\", \\\"{x:1275,y:561,t:1527876876181};\\\", \\\"{x:1278,y:561,t:1527876876188};\\\", \\\"{x:1285,y:562,t:1527876876205};\\\", \\\"{x:1291,y:562,t:1527876876223};\\\", \\\"{x:1292,y:562,t:1527876876238};\\\", \\\"{x:1291,y:562,t:1527876877188};\\\", \\\"{x:1290,y:562,t:1527876877211};\\\", \\\"{x:1290,y:563,t:1527876877221};\\\", \\\"{x:1289,y:563,t:1527876877251};\\\", \\\"{x:1288,y:563,t:1527876877324};\\\", \\\"{x:1287,y:563,t:1527876878461};\\\", \\\"{x:1286,y:563,t:1527876883925};\\\", \\\"{x:1284,y:565,t:1527876884301};\\\", \\\"{x:1265,y:571,t:1527876884310};\\\", \\\"{x:1181,y:586,t:1527876884326};\\\", \\\"{x:1057,y:596,t:1527876884342};\\\", \\\"{x:921,y:600,t:1527876884359};\\\", \\\"{x:782,y:602,t:1527876884376};\\\", \\\"{x:638,y:602,t:1527876884392};\\\", \\\"{x:514,y:602,t:1527876884408};\\\", \\\"{x:456,y:602,t:1527876884417};\\\", \\\"{x:372,y:602,t:1527876884433};\\\", \\\"{x:322,y:602,t:1527876884449};\\\", \\\"{x:303,y:602,t:1527876884466};\\\", \\\"{x:299,y:602,t:1527876884484};\\\", \\\"{x:301,y:602,t:1527876884572};\\\", \\\"{x:306,y:602,t:1527876884584};\\\", \\\"{x:318,y:596,t:1527876884601};\\\", \\\"{x:332,y:590,t:1527876884618};\\\", \\\"{x:343,y:587,t:1527876884634};\\\", \\\"{x:364,y:580,t:1527876884650};\\\", \\\"{x:385,y:574,t:1527876884667};\\\", \\\"{x:424,y:563,t:1527876884684};\\\", \\\"{x:444,y:556,t:1527876884700};\\\", \\\"{x:459,y:551,t:1527876884717};\\\", \\\"{x:463,y:548,t:1527876884734};\\\", \\\"{x:464,y:548,t:1527876884751};\\\", \\\"{x:464,y:547,t:1527876884780};\\\", \\\"{x:466,y:546,t:1527876884788};\\\", \\\"{x:469,y:543,t:1527876884801};\\\", \\\"{x:479,y:538,t:1527876884817};\\\", \\\"{x:486,y:533,t:1527876884834};\\\", \\\"{x:492,y:529,t:1527876884851};\\\", \\\"{x:496,y:525,t:1527876884868};\\\", \\\"{x:499,y:523,t:1527876884885};\\\", \\\"{x:507,y:516,t:1527876884901};\\\", \\\"{x:514,y:512,t:1527876884917};\\\", \\\"{x:518,y:509,t:1527876884933};\\\", \\\"{x:519,y:509,t:1527876884989};\\\", \\\"{x:522,y:508,t:1527876885000};\\\", \\\"{x:524,y:508,t:1527876885017};\\\", \\\"{x:527,y:508,t:1527876885034};\\\", \\\"{x:537,y:508,t:1527876885051};\\\", \\\"{x:544,y:508,t:1527876885067};\\\", \\\"{x:546,y:508,t:1527876885084};\\\", \\\"{x:547,y:508,t:1527876885157};\\\", \\\"{x:548,y:508,t:1527876885172};\\\", \\\"{x:550,y:508,t:1527876885184};\\\", \\\"{x:551,y:508,t:1527876885201};\\\", \\\"{x:554,y:508,t:1527876885217};\\\", \\\"{x:559,y:508,t:1527876885234};\\\", \\\"{x:565,y:508,t:1527876885250};\\\", \\\"{x:573,y:508,t:1527876885267};\\\", \\\"{x:585,y:508,t:1527876885285};\\\", \\\"{x:591,y:508,t:1527876885300};\\\", \\\"{x:594,y:508,t:1527876885318};\\\", \\\"{x:595,y:508,t:1527876885405};\\\", \\\"{x:596,y:508,t:1527876885418};\\\", \\\"{x:598,y:508,t:1527876885477};\\\", \\\"{x:600,y:505,t:1527876885485};\\\", \\\"{x:607,y:502,t:1527876885500};\\\", \\\"{x:609,y:501,t:1527876885517};\\\", \\\"{x:610,y:501,t:1527876885588};\\\", \\\"{x:610,y:500,t:1527876885627};\\\", \\\"{x:610,y:500,t:1527876885699};\\\", \\\"{x:610,y:505,t:1527876885957};\\\", \\\"{x:608,y:515,t:1527876885968};\\\", \\\"{x:606,y:535,t:1527876885986};\\\", \\\"{x:606,y:552,t:1527876886001};\\\", \\\"{x:606,y:569,t:1527876886018};\\\", \\\"{x:606,y:584,t:1527876886035};\\\", \\\"{x:606,y:605,t:1527876886051};\\\", \\\"{x:603,y:619,t:1527876886068};\\\", \\\"{x:603,y:630,t:1527876886085};\\\", \\\"{x:602,y:640,t:1527876886102};\\\", \\\"{x:602,y:651,t:1527876886118};\\\", \\\"{x:601,y:664,t:1527876886135};\\\", \\\"{x:598,y:678,t:1527876886151};\\\", \\\"{x:596,y:696,t:1527876886168};\\\", \\\"{x:595,y:709,t:1527876886185};\\\", \\\"{x:593,y:718,t:1527876886201};\\\", \\\"{x:592,y:723,t:1527876886219};\\\", \\\"{x:591,y:724,t:1527876886235};\\\", \\\"{x:591,y:725,t:1527876886251};\\\", \\\"{x:590,y:725,t:1527876886283};\\\", \\\"{x:589,y:727,t:1527876886292};\\\", \\\"{x:588,y:727,t:1527876886302};\\\", \\\"{x:583,y:729,t:1527876886319};\\\", \\\"{x:578,y:731,t:1527876886335};\\\", \\\"{x:573,y:732,t:1527876886352};\\\", \\\"{x:568,y:733,t:1527876886369};\\\", \\\"{x:562,y:734,t:1527876886386};\\\", \\\"{x:552,y:735,t:1527876886402};\\\", \\\"{x:540,y:736,t:1527876886419};\\\", \\\"{x:530,y:739,t:1527876886435};\\\", \\\"{x:528,y:739,t:1527876886452};\\\", \\\"{x:527,y:739,t:1527876886469};\\\", \\\"{x:526,y:739,t:1527876886884};\\\", \\\"{x:526,y:737,t:1527876886908};\\\", \\\"{x:525,y:736,t:1527876886931};\\\", \\\"{x:525,y:735,t:1527876886940};\\\", \\\"{x:525,y:733,t:1527876886956};\\\", \\\"{x:524,y:733,t:1527876886980};\\\", \\\"{x:524,y:732,t:1527876887012};\\\", \\\"{x:524,y:731,t:1527876887076};\\\", \\\"{x:523,y:730,t:1527876887388};\\\", \\\"{x:523,y:729,t:1527876887403};\\\", \\\"{x:521,y:726,t:1527876887420};\\\", \\\"{x:520,y:725,t:1527876887436};\\\", \\\"{x:520,y:724,t:1527876887453};\\\", \\\"{x:520,y:723,t:1527876887492};\\\", \\\"{x:520,y:722,t:1527876887503};\\\", \\\"{x:519,y:721,t:1527876887524};\\\", \\\"{x:519,y:720,t:1527876887644};\\\", \\\"{x:518,y:719,t:1527876887653};\\\", \\\"{x:517,y:718,t:1527876887670};\\\", \\\"{x:517,y:716,t:1527876887687};\\\", \\\"{x:516,y:714,t:1527876887703};\\\", \\\"{x:515,y:712,t:1527876887720};\\\", \\\"{x:514,y:709,t:1527876887778};\\\" ] }, { \\\"rt\\\": 10241, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 14, \\\"time_elapsed\\\": 488231, \\\"internal_node_id\\\": \\\"0.0-6.0-4.0\\\", \\\"subject\\\": \\\"EER58\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"ends\\\", \\\"q\\\": 10, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-F -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:513,y:708,t:1527876888845};\\\", \\\"{x:513,y:709,t:1527876889420};\\\", \\\"{x:515,y:711,t:1527876889428};\\\", \\\"{x:517,y:714,t:1527876889438};\\\", \\\"{x:519,y:716,t:1527876889454};\\\", \\\"{x:523,y:719,t:1527876889472};\\\", \\\"{x:529,y:723,t:1527876889489};\\\", \\\"{x:530,y:723,t:1527876889503};\\\", \\\"{x:531,y:723,t:1527876889920};\\\", \\\"{x:535,y:722,t:1527876889928};\\\", \\\"{x:545,y:721,t:1527876889941};\\\", \\\"{x:579,y:721,t:1527876889960};\\\", \\\"{x:636,y:716,t:1527876889974};\\\", \\\"{x:779,y:699,t:1527876889992};\\\", \\\"{x:893,y:695,t:1527876890009};\\\", \\\"{x:1014,y:683,t:1527876890025};\\\", \\\"{x:1125,y:666,t:1527876890042};\\\", \\\"{x:1232,y:657,t:1527876890059};\\\", \\\"{x:1322,y:655,t:1527876890075};\\\", \\\"{x:1408,y:655,t:1527876890093};\\\", \\\"{x:1465,y:650,t:1527876890109};\\\", \\\"{x:1507,y:646,t:1527876890125};\\\", \\\"{x:1534,y:643,t:1527876890142};\\\", \\\"{x:1554,y:638,t:1527876890159};\\\", \\\"{x:1567,y:635,t:1527876890175};\\\", \\\"{x:1571,y:632,t:1527876890192};\\\", \\\"{x:1569,y:633,t:1527876890297};\\\", \\\"{x:1562,y:636,t:1527876890310};\\\", \\\"{x:1540,y:649,t:1527876890327};\\\", \\\"{x:1510,y:662,t:1527876890343};\\\", \\\"{x:1488,y:673,t:1527876890359};\\\", \\\"{x:1456,y:686,t:1527876890377};\\\", \\\"{x:1446,y:690,t:1527876890393};\\\", \\\"{x:1441,y:692,t:1527876890409};\\\", \\\"{x:1438,y:694,t:1527876890426};\\\", \\\"{x:1436,y:695,t:1527876890521};\\\", \\\"{x:1435,y:696,t:1527876890529};\\\", \\\"{x:1431,y:697,t:1527876890543};\\\", \\\"{x:1424,y:698,t:1527876890559};\\\", \\\"{x:1415,y:701,t:1527876890576};\\\", \\\"{x:1408,y:702,t:1527876890593};\\\", \\\"{x:1404,y:702,t:1527876890609};\\\", \\\"{x:1400,y:703,t:1527876890626};\\\", \\\"{x:1398,y:703,t:1527876890642};\\\", \\\"{x:1396,y:704,t:1527876890659};\\\", \\\"{x:1394,y:704,t:1527876890677};\\\", \\\"{x:1393,y:704,t:1527876890693};\\\", \\\"{x:1392,y:704,t:1527876890720};\\\", \\\"{x:1391,y:705,t:1527876890729};\\\", \\\"{x:1390,y:705,t:1527876890759};\\\", \\\"{x:1389,y:705,t:1527876890783};\\\", \\\"{x:1388,y:705,t:1527876890793};\\\", \\\"{x:1385,y:705,t:1527876890809};\\\", \\\"{x:1382,y:705,t:1527876890826};\\\", \\\"{x:1376,y:704,t:1527876890842};\\\", \\\"{x:1373,y:703,t:1527876890859};\\\", \\\"{x:1369,y:701,t:1527876890876};\\\", \\\"{x:1366,y:700,t:1527876890893};\\\", \\\"{x:1364,y:698,t:1527876890909};\\\", \\\"{x:1361,y:696,t:1527876890926};\\\", \\\"{x:1358,y:694,t:1527876890943};\\\", \\\"{x:1356,y:693,t:1527876890959};\\\", \\\"{x:1354,y:692,t:1527876890976};\\\", \\\"{x:1353,y:692,t:1527876891425};\\\", \\\"{x:1353,y:693,t:1527876891448};\\\", \\\"{x:1353,y:694,t:1527876891463};\\\", \\\"{x:1354,y:695,t:1527876891478};\\\", \\\"{x:1356,y:699,t:1527876891494};\\\", \\\"{x:1357,y:702,t:1527876891511};\\\", \\\"{x:1360,y:708,t:1527876891527};\\\", \\\"{x:1361,y:712,t:1527876891543};\\\", \\\"{x:1362,y:713,t:1527876891640};\\\", \\\"{x:1362,y:714,t:1527876891648};\\\", \\\"{x:1363,y:715,t:1527876891661};\\\", \\\"{x:1367,y:718,t:1527876891678};\\\", \\\"{x:1369,y:721,t:1527876891694};\\\", \\\"{x:1372,y:727,t:1527876891710};\\\", \\\"{x:1378,y:736,t:1527876891728};\\\", \\\"{x:1384,y:742,t:1527876891744};\\\", \\\"{x:1396,y:757,t:1527876891760};\\\", \\\"{x:1404,y:768,t:1527876891777};\\\", \\\"{x:1411,y:778,t:1527876891794};\\\", \\\"{x:1419,y:788,t:1527876891810};\\\", \\\"{x:1424,y:795,t:1527876891827};\\\", \\\"{x:1428,y:802,t:1527876891844};\\\", \\\"{x:1432,y:808,t:1527876891861};\\\", \\\"{x:1436,y:811,t:1527876891878};\\\", \\\"{x:1437,y:815,t:1527876891894};\\\", \\\"{x:1439,y:819,t:1527876891910};\\\", \\\"{x:1441,y:825,t:1527876891927};\\\", \\\"{x:1442,y:829,t:1527876891944};\\\", \\\"{x:1446,y:839,t:1527876891961};\\\", \\\"{x:1449,y:846,t:1527876891977};\\\", \\\"{x:1451,y:852,t:1527876891994};\\\", \\\"{x:1455,y:861,t:1527876892010};\\\", \\\"{x:1457,y:870,t:1527876892028};\\\", \\\"{x:1459,y:877,t:1527876892044};\\\", \\\"{x:1461,y:885,t:1527876892060};\\\", \\\"{x:1464,y:892,t:1527876892077};\\\", \\\"{x:1466,y:900,t:1527876892095};\\\", \\\"{x:1471,y:907,t:1527876892110};\\\", \\\"{x:1474,y:915,t:1527876892127};\\\", \\\"{x:1477,y:922,t:1527876892144};\\\", \\\"{x:1481,y:927,t:1527876892161};\\\", \\\"{x:1482,y:932,t:1527876892177};\\\", \\\"{x:1484,y:936,t:1527876892195};\\\", \\\"{x:1486,y:938,t:1527876892210};\\\", \\\"{x:1487,y:942,t:1527876892227};\\\", \\\"{x:1489,y:945,t:1527876892244};\\\", \\\"{x:1490,y:948,t:1527876892263};\\\", \\\"{x:1490,y:949,t:1527876892296};\\\", \\\"{x:1491,y:949,t:1527876892310};\\\", \\\"{x:1491,y:951,t:1527876892327};\\\", \\\"{x:1492,y:953,t:1527876892344};\\\", \\\"{x:1492,y:954,t:1527876892360};\\\", \\\"{x:1492,y:955,t:1527876892377};\\\", \\\"{x:1492,y:956,t:1527876892408};\\\", \\\"{x:1492,y:955,t:1527876892520};\\\", \\\"{x:1490,y:951,t:1527876892528};\\\", \\\"{x:1485,y:938,t:1527876892545};\\\", \\\"{x:1481,y:922,t:1527876892561};\\\", \\\"{x:1474,y:902,t:1527876892578};\\\", \\\"{x:1467,y:880,t:1527876892595};\\\", \\\"{x:1460,y:860,t:1527876892611};\\\", \\\"{x:1454,y:841,t:1527876892628};\\\", \\\"{x:1451,y:824,t:1527876892645};\\\", \\\"{x:1443,y:804,t:1527876892662};\\\", \\\"{x:1437,y:787,t:1527876892678};\\\", \\\"{x:1427,y:773,t:1527876892694};\\\", \\\"{x:1418,y:759,t:1527876892712};\\\", \\\"{x:1410,y:752,t:1527876892727};\\\", \\\"{x:1401,y:741,t:1527876892744};\\\", \\\"{x:1394,y:734,t:1527876892762};\\\", \\\"{x:1386,y:724,t:1527876892777};\\\", \\\"{x:1376,y:712,t:1527876892794};\\\", \\\"{x:1368,y:704,t:1527876892811};\\\", \\\"{x:1361,y:696,t:1527876892828};\\\", \\\"{x:1352,y:689,t:1527876892845};\\\", \\\"{x:1345,y:682,t:1527876892862};\\\", \\\"{x:1340,y:678,t:1527876892879};\\\", \\\"{x:1336,y:675,t:1527876892894};\\\", \\\"{x:1335,y:674,t:1527876892912};\\\", \\\"{x:1332,y:669,t:1527876892928};\\\", \\\"{x:1330,y:667,t:1527876892945};\\\", \\\"{x:1329,y:663,t:1527876892962};\\\", \\\"{x:1327,y:654,t:1527876892979};\\\", \\\"{x:1325,y:648,t:1527876892995};\\\", \\\"{x:1323,y:639,t:1527876893011};\\\", \\\"{x:1321,y:632,t:1527876893029};\\\", \\\"{x:1318,y:625,t:1527876893044};\\\", \\\"{x:1317,y:618,t:1527876893062};\\\", \\\"{x:1316,y:613,t:1527876893079};\\\", \\\"{x:1314,y:608,t:1527876893094};\\\", \\\"{x:1310,y:599,t:1527876893111};\\\", \\\"{x:1301,y:588,t:1527876893129};\\\", \\\"{x:1290,y:571,t:1527876893144};\\\", \\\"{x:1271,y:548,t:1527876893161};\\\", \\\"{x:1255,y:525,t:1527876893179};\\\", \\\"{x:1242,y:513,t:1527876893195};\\\", \\\"{x:1231,y:506,t:1527876893212};\\\", \\\"{x:1225,y:503,t:1527876893229};\\\", \\\"{x:1223,y:502,t:1527876893244};\\\", \\\"{x:1223,y:501,t:1527876893261};\\\", \\\"{x:1222,y:501,t:1527876893368};\\\", \\\"{x:1222,y:504,t:1527876893378};\\\", \\\"{x:1226,y:510,t:1527876893396};\\\", \\\"{x:1230,y:515,t:1527876893411};\\\", \\\"{x:1233,y:521,t:1527876893429};\\\", \\\"{x:1237,y:528,t:1527876893446};\\\", \\\"{x:1240,y:534,t:1527876893462};\\\", \\\"{x:1244,y:542,t:1527876893479};\\\", \\\"{x:1248,y:548,t:1527876893495};\\\", \\\"{x:1254,y:556,t:1527876893512};\\\", \\\"{x:1260,y:562,t:1527876893528};\\\", \\\"{x:1264,y:568,t:1527876893545};\\\", \\\"{x:1268,y:573,t:1527876893561};\\\", \\\"{x:1273,y:582,t:1527876893578};\\\", \\\"{x:1283,y:594,t:1527876893595};\\\", \\\"{x:1294,y:609,t:1527876893612};\\\", \\\"{x:1305,y:624,t:1527876893629};\\\", \\\"{x:1321,y:640,t:1527876893645};\\\", \\\"{x:1330,y:651,t:1527876893662};\\\", \\\"{x:1338,y:656,t:1527876893679};\\\", \\\"{x:1344,y:662,t:1527876893695};\\\", \\\"{x:1348,y:668,t:1527876893711};\\\", \\\"{x:1357,y:679,t:1527876893728};\\\", \\\"{x:1364,y:689,t:1527876893746};\\\", \\\"{x:1372,y:697,t:1527876893763};\\\", \\\"{x:1376,y:703,t:1527876893779};\\\", \\\"{x:1378,y:705,t:1527876893796};\\\", \\\"{x:1375,y:702,t:1527876893873};\\\", \\\"{x:1369,y:699,t:1527876893880};\\\", \\\"{x:1363,y:696,t:1527876893896};\\\", \\\"{x:1324,y:688,t:1527876893913};\\\", \\\"{x:1293,y:684,t:1527876893928};\\\", \\\"{x:1249,y:674,t:1527876893946};\\\", \\\"{x:1193,y:658,t:1527876893963};\\\", \\\"{x:1142,y:650,t:1527876893978};\\\", \\\"{x:1099,y:641,t:1527876893996};\\\", \\\"{x:1073,y:636,t:1527876894012};\\\", \\\"{x:1050,y:628,t:1527876894029};\\\", \\\"{x:1032,y:620,t:1527876894046};\\\", \\\"{x:1013,y:614,t:1527876894063};\\\", \\\"{x:996,y:606,t:1527876894079};\\\", \\\"{x:977,y:598,t:1527876894095};\\\", \\\"{x:942,y:584,t:1527876894113};\\\", \\\"{x:917,y:572,t:1527876894128};\\\", \\\"{x:883,y:559,t:1527876894145};\\\", \\\"{x:843,y:548,t:1527876894162};\\\", \\\"{x:810,y:539,t:1527876894179};\\\", \\\"{x:789,y:533,t:1527876894195};\\\", \\\"{x:780,y:529,t:1527876894212};\\\", \\\"{x:779,y:529,t:1527876894228};\\\", \\\"{x:778,y:528,t:1527876894244};\\\", \\\"{x:777,y:525,t:1527876894262};\\\", \\\"{x:777,y:522,t:1527876894278};\\\", \\\"{x:776,y:518,t:1527876894295};\\\", \\\"{x:772,y:514,t:1527876894312};\\\", \\\"{x:772,y:513,t:1527876894329};\\\", \\\"{x:771,y:512,t:1527876894345};\\\", \\\"{x:769,y:511,t:1527876894362};\\\", \\\"{x:762,y:509,t:1527876894379};\\\", \\\"{x:749,y:508,t:1527876894395};\\\", \\\"{x:733,y:505,t:1527876894412};\\\", \\\"{x:713,y:502,t:1527876894431};\\\", \\\"{x:695,y:502,t:1527876894445};\\\", \\\"{x:678,y:502,t:1527876894462};\\\", \\\"{x:664,y:502,t:1527876894479};\\\", \\\"{x:650,y:502,t:1527876894495};\\\", \\\"{x:646,y:501,t:1527876894513};\\\", \\\"{x:643,y:500,t:1527876894529};\\\", \\\"{x:641,y:500,t:1527876894547};\\\", \\\"{x:640,y:500,t:1527876894563};\\\", \\\"{x:638,y:500,t:1527876894664};\\\", \\\"{x:636,y:500,t:1527876894696};\\\", \\\"{x:635,y:500,t:1527876894713};\\\", \\\"{x:631,y:500,t:1527876894729};\\\", \\\"{x:628,y:500,t:1527876894747};\\\", \\\"{x:623,y:500,t:1527876894762};\\\", \\\"{x:622,y:500,t:1527876894792};\\\", \\\"{x:624,y:500,t:1527876895393};\\\", \\\"{x:632,y:501,t:1527876895400};\\\", \\\"{x:645,y:502,t:1527876895414};\\\", \\\"{x:676,y:508,t:1527876895429};\\\", \\\"{x:734,y:508,t:1527876895447};\\\", \\\"{x:862,y:510,t:1527876895464};\\\", \\\"{x:974,y:516,t:1527876895480};\\\", \\\"{x:1115,y:516,t:1527876895496};\\\", \\\"{x:1254,y:516,t:1527876895513};\\\", \\\"{x:1378,y:516,t:1527876895531};\\\", \\\"{x:1470,y:516,t:1527876895546};\\\", \\\"{x:1534,y:516,t:1527876895564};\\\", \\\"{x:1565,y:516,t:1527876895581};\\\", \\\"{x:1567,y:516,t:1527876895596};\\\", \\\"{x:1567,y:517,t:1527876895737};\\\", \\\"{x:1565,y:518,t:1527876895746};\\\", \\\"{x:1556,y:523,t:1527876895764};\\\", \\\"{x:1539,y:531,t:1527876895781};\\\", \\\"{x:1513,y:543,t:1527876895797};\\\", \\\"{x:1492,y:552,t:1527876895813};\\\", \\\"{x:1472,y:559,t:1527876895831};\\\", \\\"{x:1451,y:565,t:1527876895847};\\\", \\\"{x:1434,y:570,t:1527876895864};\\\", \\\"{x:1399,y:575,t:1527876895880};\\\", \\\"{x:1387,y:577,t:1527876895897};\\\", \\\"{x:1381,y:577,t:1527876895914};\\\", \\\"{x:1377,y:578,t:1527876895931};\\\", \\\"{x:1373,y:578,t:1527876895947};\\\", \\\"{x:1368,y:580,t:1527876895964};\\\", \\\"{x:1362,y:580,t:1527876895980};\\\", \\\"{x:1349,y:581,t:1527876895997};\\\", \\\"{x:1333,y:584,t:1527876896013};\\\", \\\"{x:1322,y:586,t:1527876896031};\\\", \\\"{x:1308,y:586,t:1527876896046};\\\", \\\"{x:1300,y:586,t:1527876896064};\\\", \\\"{x:1289,y:586,t:1527876896080};\\\", \\\"{x:1284,y:586,t:1527876896097};\\\", \\\"{x:1280,y:586,t:1527876896113};\\\", \\\"{x:1278,y:586,t:1527876896131};\\\", \\\"{x:1277,y:586,t:1527876896147};\\\", \\\"{x:1275,y:585,t:1527876896185};\\\", \\\"{x:1274,y:585,t:1527876896321};\\\", \\\"{x:1274,y:588,t:1527876896330};\\\", \\\"{x:1274,y:599,t:1527876896347};\\\", \\\"{x:1280,y:608,t:1527876896364};\\\", \\\"{x:1287,y:618,t:1527876896380};\\\", \\\"{x:1296,y:629,t:1527876896397};\\\", \\\"{x:1300,y:635,t:1527876896413};\\\", \\\"{x:1305,y:641,t:1527876896431};\\\", \\\"{x:1308,y:644,t:1527876896446};\\\", \\\"{x:1310,y:648,t:1527876896464};\\\", \\\"{x:1315,y:654,t:1527876896480};\\\", \\\"{x:1324,y:665,t:1527876896497};\\\", \\\"{x:1339,y:677,t:1527876896514};\\\", \\\"{x:1354,y:686,t:1527876896531};\\\", \\\"{x:1365,y:693,t:1527876896547};\\\", \\\"{x:1374,y:698,t:1527876896564};\\\", \\\"{x:1378,y:702,t:1527876896580};\\\", \\\"{x:1383,y:705,t:1527876896596};\\\", \\\"{x:1388,y:712,t:1527876896613};\\\", \\\"{x:1393,y:719,t:1527876896630};\\\", \\\"{x:1398,y:726,t:1527876896646};\\\", \\\"{x:1403,y:733,t:1527876896663};\\\", \\\"{x:1405,y:737,t:1527876896680};\\\", \\\"{x:1406,y:740,t:1527876896696};\\\", \\\"{x:1409,y:744,t:1527876896713};\\\", \\\"{x:1412,y:750,t:1527876896730};\\\", \\\"{x:1414,y:758,t:1527876896746};\\\", \\\"{x:1418,y:767,t:1527876896763};\\\", \\\"{x:1421,y:773,t:1527876896780};\\\", \\\"{x:1425,y:782,t:1527876896796};\\\", \\\"{x:1427,y:788,t:1527876896813};\\\", \\\"{x:1432,y:799,t:1527876896830};\\\", \\\"{x:1436,y:809,t:1527876896846};\\\", \\\"{x:1437,y:822,t:1527876896864};\\\", \\\"{x:1439,y:835,t:1527876896880};\\\", \\\"{x:1441,y:847,t:1527876896896};\\\", \\\"{x:1444,y:860,t:1527876896913};\\\", \\\"{x:1449,y:872,t:1527876896931};\\\", \\\"{x:1452,y:882,t:1527876896946};\\\", \\\"{x:1455,y:888,t:1527876896964};\\\", \\\"{x:1455,y:894,t:1527876896981};\\\", \\\"{x:1458,y:899,t:1527876896996};\\\", \\\"{x:1458,y:903,t:1527876897013};\\\", \\\"{x:1460,y:907,t:1527876897030};\\\", \\\"{x:1461,y:909,t:1527876897046};\\\", \\\"{x:1465,y:916,t:1527876897064};\\\", \\\"{x:1467,y:920,t:1527876897079};\\\", \\\"{x:1471,y:926,t:1527876897097};\\\", \\\"{x:1473,y:930,t:1527876897113};\\\", \\\"{x:1474,y:931,t:1527876897131};\\\", \\\"{x:1475,y:933,t:1527876897147};\\\", \\\"{x:1475,y:934,t:1527876897164};\\\", \\\"{x:1476,y:934,t:1527876897240};\\\", \\\"{x:1476,y:935,t:1527876897248};\\\", \\\"{x:1478,y:936,t:1527876897263};\\\", \\\"{x:1479,y:938,t:1527876897280};\\\", \\\"{x:1481,y:940,t:1527876897297};\\\", \\\"{x:1481,y:941,t:1527876897327};\\\", \\\"{x:1481,y:943,t:1527876897351};\\\", \\\"{x:1481,y:944,t:1527876897368};\\\", \\\"{x:1481,y:946,t:1527876897383};\\\", \\\"{x:1481,y:947,t:1527876897398};\\\", \\\"{x:1471,y:951,t:1527876897413};\\\", \\\"{x:1438,y:952,t:1527876897430};\\\", \\\"{x:1291,y:939,t:1527876897448};\\\", \\\"{x:1181,y:927,t:1527876897464};\\\", \\\"{x:1071,y:917,t:1527876897481};\\\", \\\"{x:965,y:897,t:1527876897498};\\\", \\\"{x:872,y:879,t:1527876897513};\\\", \\\"{x:790,y:861,t:1527876897531};\\\", \\\"{x:731,y:844,t:1527876897548};\\\", \\\"{x:683,y:828,t:1527876897563};\\\", \\\"{x:642,y:812,t:1527876897581};\\\", \\\"{x:614,y:794,t:1527876897597};\\\", \\\"{x:598,y:783,t:1527876897613};\\\", \\\"{x:584,y:769,t:1527876897630};\\\", \\\"{x:566,y:744,t:1527876897648};\\\", \\\"{x:551,y:722,t:1527876897664};\\\", \\\"{x:536,y:707,t:1527876897680};\\\", \\\"{x:525,y:698,t:1527876897697};\\\", \\\"{x:522,y:697,t:1527876897715};\\\", \\\"{x:521,y:696,t:1527876897732};\\\", \\\"{x:520,y:696,t:1527876897751};\\\", \\\"{x:519,y:696,t:1527876897824};\\\", \\\"{x:517,y:698,t:1527876897832};\\\", \\\"{x:515,y:706,t:1527876897848};\\\", \\\"{x:513,y:719,t:1527876897866};\\\", \\\"{x:511,y:727,t:1527876897883};\\\", \\\"{x:511,y:730,t:1527876897899};\\\", \\\"{x:511,y:732,t:1527876897916};\\\", \\\"{x:511,y:733,t:1527876897932};\\\", \\\"{x:510,y:733,t:1527876898880};\\\", \\\"{x:509,y:733,t:1527876898904};\\\", \\\"{x:509,y:732,t:1527876898928};\\\", \\\"{x:508,y:731,t:1527876898936};\\\", \\\"{x:508,y:729,t:1527876898959};\\\", \\\"{x:507,y:728,t:1527876898984};\\\", \\\"{x:506,y:726,t:1527876899000};\\\", \\\"{x:506,y:725,t:1527876899015};\\\", \\\"{x:505,y:724,t:1527876899039};\\\" ] }, { \\\"rt\\\": 23335, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 15, \\\"time_elapsed\\\": 512802, \\\"internal_node_id\\\": \\\"0.0-6.0-5.0\\\", \\\"subject\\\": \\\"EER58\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starttime\\\", \\\"q\\\": 11, \\\"clicks\\\": 2.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"M\\\", \\\"L\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-08 AM-02 PM-01 PM-12 PM-M -12 PM-M -L -L -04 PM-10 AM-11 AM-12 PM-L \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:505,y:723,t:1527876900136};\\\", \\\"{x:504,y:721,t:1527876900151};\\\", \\\"{x:503,y:718,t:1527876900168};\\\", \\\"{x:500,y:714,t:1527876900185};\\\", \\\"{x:498,y:709,t:1527876900200};\\\", \\\"{x:495,y:703,t:1527876900217};\\\", \\\"{x:492,y:693,t:1527876900233};\\\", \\\"{x:486,y:679,t:1527876900250};\\\", \\\"{x:479,y:658,t:1527876900269};\\\", \\\"{x:472,y:635,t:1527876900284};\\\", \\\"{x:467,y:617,t:1527876900300};\\\", \\\"{x:460,y:601,t:1527876900317};\\\", \\\"{x:452,y:584,t:1527876900334};\\\", \\\"{x:445,y:566,t:1527876900351};\\\", \\\"{x:436,y:546,t:1527876900368};\\\", \\\"{x:428,y:527,t:1527876900383};\\\", \\\"{x:419,y:507,t:1527876900401};\\\", \\\"{x:408,y:488,t:1527876900417};\\\", \\\"{x:403,y:479,t:1527876900434};\\\", \\\"{x:399,y:471,t:1527876900450};\\\", \\\"{x:398,y:466,t:1527876900468};\\\", \\\"{x:398,y:464,t:1527876900484};\\\", \\\"{x:398,y:461,t:1527876900500};\\\", \\\"{x:398,y:459,t:1527876900517};\\\", \\\"{x:398,y:457,t:1527876900534};\\\", \\\"{x:398,y:455,t:1527876900824};\\\", \\\"{x:399,y:453,t:1527876900835};\\\", \\\"{x:408,y:445,t:1527876900851};\\\", \\\"{x:423,y:434,t:1527876900868};\\\", \\\"{x:439,y:421,t:1527876900884};\\\", \\\"{x:453,y:408,t:1527876900901};\\\", \\\"{x:464,y:397,t:1527876900917};\\\", \\\"{x:473,y:389,t:1527876900934};\\\", \\\"{x:477,y:384,t:1527876900951};\\\", \\\"{x:477,y:383,t:1527876900975};\\\", \\\"{x:478,y:383,t:1527876901840};\\\", \\\"{x:481,y:383,t:1527876901852};\\\", \\\"{x:489,y:382,t:1527876901869};\\\", \\\"{x:504,y:382,t:1527876901886};\\\", \\\"{x:524,y:382,t:1527876901902};\\\", \\\"{x:548,y:382,t:1527876901919};\\\", \\\"{x:595,y:382,t:1527876901936};\\\", \\\"{x:653,y:382,t:1527876901952};\\\", \\\"{x:724,y:379,t:1527876901968};\\\", \\\"{x:793,y:379,t:1527876901986};\\\", \\\"{x:849,y:379,t:1527876902002};\\\", \\\"{x:897,y:379,t:1527876902019};\\\", \\\"{x:941,y:379,t:1527876902036};\\\", \\\"{x:984,y:379,t:1527876902053};\\\", \\\"{x:1026,y:379,t:1527876902069};\\\", \\\"{x:1065,y:379,t:1527876902086};\\\", \\\"{x:1099,y:377,t:1527876902103};\\\", \\\"{x:1144,y:377,t:1527876902118};\\\", \\\"{x:1220,y:377,t:1527876902136};\\\", \\\"{x:1278,y:377,t:1527876902153};\\\", \\\"{x:1345,y:377,t:1527876902168};\\\", \\\"{x:1406,y:377,t:1527876902186};\\\", \\\"{x:1462,y:377,t:1527876902203};\\\", \\\"{x:1515,y:377,t:1527876902219};\\\", \\\"{x:1568,y:377,t:1527876902235};\\\", \\\"{x:1620,y:381,t:1527876902252};\\\", \\\"{x:1674,y:391,t:1527876902268};\\\", \\\"{x:1721,y:403,t:1527876902285};\\\", \\\"{x:1769,y:419,t:1527876902303};\\\", \\\"{x:1828,y:443,t:1527876902319};\\\", \\\"{x:1863,y:461,t:1527876902335};\\\", \\\"{x:1894,y:475,t:1527876902352};\\\", \\\"{x:1919,y:498,t:1527876902369};\\\", \\\"{x:1919,y:524,t:1527876902386};\\\", \\\"{x:1919,y:547,t:1527876902402};\\\", \\\"{x:1919,y:573,t:1527876902418};\\\", \\\"{x:1919,y:596,t:1527876902436};\\\", \\\"{x:1919,y:616,t:1527876902452};\\\", \\\"{x:1919,y:632,t:1527876902469};\\\", \\\"{x:1919,y:648,t:1527876902486};\\\", \\\"{x:1919,y:670,t:1527876902501};\\\", \\\"{x:1919,y:695,t:1527876902518};\\\", \\\"{x:1903,y:727,t:1527876902536};\\\", \\\"{x:1889,y:744,t:1527876902552};\\\", \\\"{x:1869,y:760,t:1527876902569};\\\", \\\"{x:1854,y:772,t:1527876902586};\\\", \\\"{x:1838,y:778,t:1527876902603};\\\", \\\"{x:1824,y:782,t:1527876902619};\\\", \\\"{x:1803,y:783,t:1527876902636};\\\", \\\"{x:1778,y:783,t:1527876902653};\\\", \\\"{x:1745,y:780,t:1527876902669};\\\", \\\"{x:1715,y:774,t:1527876902686};\\\", \\\"{x:1672,y:764,t:1527876902703};\\\", \\\"{x:1630,y:753,t:1527876902719};\\\", \\\"{x:1579,y:738,t:1527876902736};\\\", \\\"{x:1559,y:728,t:1527876902753};\\\", \\\"{x:1544,y:718,t:1527876902769};\\\", \\\"{x:1533,y:711,t:1527876902786};\\\", \\\"{x:1520,y:700,t:1527876902803};\\\", \\\"{x:1503,y:685,t:1527876902820};\\\", \\\"{x:1477,y:666,t:1527876902836};\\\", \\\"{x:1434,y:645,t:1527876902853};\\\", \\\"{x:1400,y:628,t:1527876902870};\\\", \\\"{x:1365,y:613,t:1527876902886};\\\", \\\"{x:1332,y:600,t:1527876902903};\\\", \\\"{x:1280,y:569,t:1527876902920};\\\", \\\"{x:1250,y:543,t:1527876902935};\\\", \\\"{x:1224,y:513,t:1527876902953};\\\", \\\"{x:1198,y:480,t:1527876902970};\\\", \\\"{x:1178,y:454,t:1527876902986};\\\", \\\"{x:1163,y:429,t:1527876903003};\\\", \\\"{x:1156,y:407,t:1527876903020};\\\", \\\"{x:1151,y:381,t:1527876903036};\\\", \\\"{x:1150,y:356,t:1527876903053};\\\", \\\"{x:1150,y:330,t:1527876903070};\\\", \\\"{x:1148,y:314,t:1527876903086};\\\", \\\"{x:1148,y:299,t:1527876903103};\\\", \\\"{x:1148,y:287,t:1527876903120};\\\", \\\"{x:1147,y:286,t:1527876903136};\\\", \\\"{x:1147,y:282,t:1527876903153};\\\", \\\"{x:1147,y:278,t:1527876903170};\\\", \\\"{x:1146,y:274,t:1527876903186};\\\", \\\"{x:1143,y:269,t:1527876903203};\\\", \\\"{x:1140,y:264,t:1527876903220};\\\", \\\"{x:1135,y:258,t:1527876903237};\\\", \\\"{x:1132,y:254,t:1527876903253};\\\", \\\"{x:1125,y:249,t:1527876903270};\\\", \\\"{x:1120,y:245,t:1527876903287};\\\", \\\"{x:1108,y:237,t:1527876903303};\\\", \\\"{x:1073,y:217,t:1527876903320};\\\", \\\"{x:1041,y:199,t:1527876903337};\\\", \\\"{x:1018,y:189,t:1527876903353};\\\", \\\"{x:1003,y:182,t:1527876903370};\\\", \\\"{x:998,y:181,t:1527876903386};\\\", \\\"{x:997,y:180,t:1527876903403};\\\", \\\"{x:997,y:181,t:1527876903952};\\\", \\\"{x:997,y:188,t:1527876903960};\\\", \\\"{x:997,y:202,t:1527876903970};\\\", \\\"{x:1005,y:237,t:1527876903987};\\\", \\\"{x:1011,y:263,t:1527876904004};\\\", \\\"{x:1018,y:284,t:1527876904020};\\\", \\\"{x:1022,y:299,t:1527876904037};\\\", \\\"{x:1024,y:318,t:1527876904054};\\\", \\\"{x:1029,y:354,t:1527876904071};\\\", \\\"{x:1037,y:458,t:1527876904087};\\\", \\\"{x:1039,y:682,t:1527876904104};\\\", \\\"{x:1043,y:819,t:1527876904120};\\\", \\\"{x:1056,y:905,t:1527876904137};\\\", \\\"{x:1066,y:944,t:1527876904154};\\\", \\\"{x:1073,y:962,t:1527876904171};\\\", \\\"{x:1077,y:973,t:1527876904187};\\\", \\\"{x:1080,y:981,t:1527876904204};\\\", \\\"{x:1081,y:984,t:1527876904221};\\\", \\\"{x:1082,y:986,t:1527876904238};\\\", \\\"{x:1082,y:988,t:1527876904254};\\\", \\\"{x:1083,y:989,t:1527876904271};\\\", \\\"{x:1084,y:989,t:1527876904985};\\\", \\\"{x:1087,y:989,t:1527876904992};\\\", \\\"{x:1092,y:989,t:1527876905005};\\\", \\\"{x:1105,y:988,t:1527876905021};\\\", \\\"{x:1126,y:987,t:1527876905038};\\\", \\\"{x:1155,y:987,t:1527876905055};\\\", \\\"{x:1188,y:987,t:1527876905071};\\\", \\\"{x:1232,y:987,t:1527876905088};\\\", \\\"{x:1260,y:987,t:1527876905105};\\\", \\\"{x:1278,y:987,t:1527876905121};\\\", \\\"{x:1297,y:987,t:1527876905138};\\\", \\\"{x:1311,y:987,t:1527876905155};\\\", \\\"{x:1323,y:987,t:1527876905171};\\\", \\\"{x:1331,y:987,t:1527876905188};\\\", \\\"{x:1340,y:987,t:1527876905205};\\\", \\\"{x:1349,y:987,t:1527876905221};\\\", \\\"{x:1361,y:987,t:1527876905238};\\\", \\\"{x:1377,y:987,t:1527876905255};\\\", \\\"{x:1392,y:987,t:1527876905271};\\\", \\\"{x:1413,y:987,t:1527876905288};\\\", \\\"{x:1425,y:987,t:1527876905305};\\\", \\\"{x:1439,y:987,t:1527876905321};\\\", \\\"{x:1449,y:987,t:1527876905339};\\\", \\\"{x:1463,y:987,t:1527876905355};\\\", \\\"{x:1471,y:987,t:1527876905371};\\\", \\\"{x:1473,y:986,t:1527876905388};\\\", \\\"{x:1474,y:986,t:1527876905405};\\\", \\\"{x:1475,y:986,t:1527876905422};\\\", \\\"{x:1476,y:985,t:1527876905551};\\\", \\\"{x:1476,y:984,t:1527876905576};\\\", \\\"{x:1476,y:983,t:1527876905591};\\\", \\\"{x:1476,y:981,t:1527876905604};\\\", \\\"{x:1472,y:980,t:1527876905621};\\\", \\\"{x:1467,y:978,t:1527876905638};\\\", \\\"{x:1464,y:978,t:1527876905655};\\\", \\\"{x:1463,y:978,t:1527876905785};\\\", \\\"{x:1461,y:978,t:1527876905793};\\\", \\\"{x:1460,y:978,t:1527876905805};\\\", \\\"{x:1455,y:978,t:1527876905822};\\\", \\\"{x:1450,y:978,t:1527876905838};\\\", \\\"{x:1441,y:978,t:1527876905855};\\\", \\\"{x:1428,y:980,t:1527876905872};\\\", \\\"{x:1421,y:981,t:1527876905889};\\\", \\\"{x:1418,y:981,t:1527876905905};\\\", \\\"{x:1416,y:981,t:1527876905922};\\\", \\\"{x:1415,y:981,t:1527876905960};\\\", \\\"{x:1414,y:981,t:1527876906008};\\\", \\\"{x:1413,y:981,t:1527876906022};\\\", \\\"{x:1410,y:981,t:1527876906040};\\\", \\\"{x:1404,y:980,t:1527876906055};\\\", \\\"{x:1388,y:975,t:1527876906072};\\\", \\\"{x:1371,y:971,t:1527876906090};\\\", \\\"{x:1353,y:969,t:1527876906105};\\\", \\\"{x:1332,y:965,t:1527876906123};\\\", \\\"{x:1317,y:963,t:1527876906140};\\\", \\\"{x:1313,y:963,t:1527876906155};\\\", \\\"{x:1311,y:963,t:1527876906173};\\\", \\\"{x:1313,y:961,t:1527876906401};\\\", \\\"{x:1314,y:961,t:1527876906416};\\\", \\\"{x:1315,y:961,t:1527876906448};\\\", \\\"{x:1316,y:960,t:1527876906464};\\\", \\\"{x:1317,y:960,t:1527876906472};\\\", \\\"{x:1323,y:957,t:1527876906490};\\\", \\\"{x:1335,y:952,t:1527876906506};\\\", \\\"{x:1344,y:947,t:1527876906521};\\\", \\\"{x:1351,y:944,t:1527876906538};\\\", \\\"{x:1355,y:943,t:1527876906556};\\\", \\\"{x:1356,y:942,t:1527876906571};\\\", \\\"{x:1356,y:943,t:1527876906745};\\\", \\\"{x:1356,y:944,t:1527876906760};\\\", \\\"{x:1354,y:945,t:1527876906773};\\\", \\\"{x:1353,y:947,t:1527876906789};\\\", \\\"{x:1352,y:947,t:1527876906806};\\\", \\\"{x:1350,y:948,t:1527876906823};\\\", \\\"{x:1350,y:949,t:1527876906839};\\\", \\\"{x:1349,y:950,t:1527876906856};\\\", \\\"{x:1348,y:950,t:1527876906928};\\\", \\\"{x:1347,y:950,t:1527876907049};\\\", \\\"{x:1345,y:951,t:1527876907193};\\\", \\\"{x:1344,y:952,t:1527876907206};\\\", \\\"{x:1341,y:954,t:1527876907223};\\\", \\\"{x:1340,y:954,t:1527876907239};\\\", \\\"{x:1339,y:956,t:1527876907255};\\\", \\\"{x:1338,y:957,t:1527876907273};\\\", \\\"{x:1338,y:960,t:1527876907289};\\\", \\\"{x:1337,y:961,t:1527876907305};\\\", \\\"{x:1337,y:962,t:1527876907323};\\\", \\\"{x:1337,y:963,t:1527876907340};\\\", \\\"{x:1338,y:963,t:1527876907464};\\\", \\\"{x:1341,y:963,t:1527876907474};\\\", \\\"{x:1345,y:962,t:1527876907490};\\\", \\\"{x:1347,y:961,t:1527876907506};\\\", \\\"{x:1346,y:962,t:1527876907929};\\\", \\\"{x:1345,y:962,t:1527876907952};\\\", \\\"{x:1346,y:961,t:1527876908112};\\\", \\\"{x:1348,y:960,t:1527876908123};\\\", \\\"{x:1353,y:955,t:1527876908140};\\\", \\\"{x:1357,y:949,t:1527876908157};\\\", \\\"{x:1357,y:944,t:1527876908174};\\\", \\\"{x:1360,y:937,t:1527876908191};\\\", \\\"{x:1362,y:934,t:1527876908207};\\\", \\\"{x:1365,y:927,t:1527876908224};\\\", \\\"{x:1368,y:923,t:1527876908240};\\\", \\\"{x:1371,y:919,t:1527876908258};\\\", \\\"{x:1374,y:916,t:1527876908275};\\\", \\\"{x:1376,y:914,t:1527876908290};\\\", \\\"{x:1376,y:913,t:1527876908312};\\\", \\\"{x:1376,y:912,t:1527876908368};\\\", \\\"{x:1377,y:910,t:1527876908384};\\\", \\\"{x:1379,y:907,t:1527876908392};\\\", \\\"{x:1379,y:905,t:1527876908408};\\\", \\\"{x:1379,y:904,t:1527876908424};\\\", \\\"{x:1379,y:903,t:1527876908528};\\\", \\\"{x:1379,y:902,t:1527876908541};\\\", \\\"{x:1380,y:900,t:1527876908559};\\\", \\\"{x:1380,y:899,t:1527876908655};\\\", \\\"{x:1380,y:898,t:1527876908671};\\\", \\\"{x:1380,y:897,t:1527876908703};\\\", \\\"{x:1380,y:896,t:1527876908840};\\\", \\\"{x:1375,y:896,t:1527876908858};\\\", \\\"{x:1370,y:896,t:1527876908874};\\\", \\\"{x:1360,y:894,t:1527876908891};\\\", \\\"{x:1338,y:887,t:1527876908908};\\\", \\\"{x:1269,y:855,t:1527876908924};\\\", \\\"{x:1170,y:815,t:1527876908941};\\\", \\\"{x:1117,y:788,t:1527876908958};\\\", \\\"{x:1005,y:747,t:1527876908975};\\\", \\\"{x:875,y:686,t:1527876908991};\\\", \\\"{x:701,y:595,t:1527876909008};\\\", \\\"{x:645,y:557,t:1527876909024};\\\", \\\"{x:627,y:541,t:1527876909042};\\\", \\\"{x:620,y:530,t:1527876909058};\\\", \\\"{x:617,y:522,t:1527876909074};\\\", \\\"{x:616,y:518,t:1527876909090};\\\", \\\"{x:616,y:515,t:1527876909108};\\\", \\\"{x:614,y:514,t:1527876909123};\\\", \\\"{x:614,y:513,t:1527876909143};\\\", \\\"{x:613,y:513,t:1527876909157};\\\", \\\"{x:607,y:512,t:1527876909174};\\\", \\\"{x:596,y:510,t:1527876909191};\\\", \\\"{x:566,y:510,t:1527876909208};\\\", \\\"{x:537,y:510,t:1527876909225};\\\", \\\"{x:499,y:510,t:1527876909241};\\\", \\\"{x:443,y:510,t:1527876909258};\\\", \\\"{x:360,y:510,t:1527876909275};\\\", \\\"{x:299,y:510,t:1527876909291};\\\", \\\"{x:251,y:510,t:1527876909309};\\\", \\\"{x:230,y:512,t:1527876909325};\\\", \\\"{x:219,y:512,t:1527876909341};\\\", \\\"{x:218,y:512,t:1527876909391};\\\", \\\"{x:218,y:514,t:1527876909471};\\\", \\\"{x:223,y:515,t:1527876909479};\\\", \\\"{x:229,y:518,t:1527876909493};\\\", \\\"{x:239,y:520,t:1527876909507};\\\", \\\"{x:249,y:523,t:1527876909525};\\\", \\\"{x:262,y:525,t:1527876909541};\\\", \\\"{x:275,y:526,t:1527876909558};\\\", \\\"{x:283,y:526,t:1527876909574};\\\", \\\"{x:288,y:526,t:1527876909591};\\\", \\\"{x:292,y:527,t:1527876909607};\\\", \\\"{x:297,y:528,t:1527876909625};\\\", \\\"{x:301,y:529,t:1527876909640};\\\", \\\"{x:305,y:529,t:1527876909658};\\\", \\\"{x:309,y:529,t:1527876909674};\\\", \\\"{x:316,y:532,t:1527876909692};\\\", \\\"{x:327,y:534,t:1527876909707};\\\", \\\"{x:336,y:537,t:1527876909724};\\\", \\\"{x:345,y:539,t:1527876909742};\\\", \\\"{x:346,y:539,t:1527876909758};\\\", \\\"{x:347,y:539,t:1527876909775};\\\", \\\"{x:348,y:540,t:1527876909792};\\\", \\\"{x:352,y:541,t:1527876909808};\\\", \\\"{x:355,y:541,t:1527876909825};\\\", \\\"{x:357,y:542,t:1527876909842};\\\", \\\"{x:360,y:542,t:1527876910144};\\\", \\\"{x:363,y:541,t:1527876910159};\\\", \\\"{x:399,y:540,t:1527876910176};\\\", \\\"{x:460,y:540,t:1527876910192};\\\", \\\"{x:568,y:540,t:1527876910208};\\\", \\\"{x:702,y:543,t:1527876910224};\\\", \\\"{x:848,y:562,t:1527876910242};\\\", \\\"{x:1001,y:584,t:1527876910259};\\\", \\\"{x:1158,y:606,t:1527876910274};\\\", \\\"{x:1319,y:630,t:1527876910292};\\\", \\\"{x:1460,y:652,t:1527876910309};\\\", \\\"{x:1558,y:669,t:1527876910325};\\\", \\\"{x:1607,y:686,t:1527876910341};\\\", \\\"{x:1623,y:695,t:1527876910358};\\\", \\\"{x:1628,y:700,t:1527876910374};\\\", \\\"{x:1628,y:706,t:1527876910391};\\\", \\\"{x:1628,y:708,t:1527876910409};\\\", \\\"{x:1622,y:713,t:1527876910424};\\\", \\\"{x:1605,y:721,t:1527876910442};\\\", \\\"{x:1568,y:727,t:1527876910459};\\\", \\\"{x:1497,y:733,t:1527876910475};\\\", \\\"{x:1409,y:740,t:1527876910491};\\\", \\\"{x:1315,y:740,t:1527876910509};\\\", \\\"{x:1196,y:740,t:1527876910524};\\\", \\\"{x:1051,y:732,t:1527876910541};\\\", \\\"{x:883,y:715,t:1527876910559};\\\", \\\"{x:705,y:688,t:1527876910575};\\\", \\\"{x:482,y:653,t:1527876910592};\\\", \\\"{x:388,y:628,t:1527876910609};\\\", \\\"{x:330,y:603,t:1527876910626};\\\", \\\"{x:298,y:587,t:1527876910643};\\\", \\\"{x:282,y:576,t:1527876910659};\\\", \\\"{x:278,y:573,t:1527876910676};\\\", \\\"{x:277,y:572,t:1527876910692};\\\", \\\"{x:277,y:567,t:1527876910709};\\\", \\\"{x:277,y:566,t:1527876910726};\\\", \\\"{x:278,y:564,t:1527876910743};\\\", \\\"{x:281,y:559,t:1527876910761};\\\", \\\"{x:294,y:546,t:1527876910776};\\\", \\\"{x:310,y:538,t:1527876910792};\\\", \\\"{x:332,y:530,t:1527876910809};\\\", \\\"{x:353,y:525,t:1527876910826};\\\", \\\"{x:371,y:523,t:1527876910842};\\\", \\\"{x:381,y:522,t:1527876910858};\\\", \\\"{x:385,y:522,t:1527876910876};\\\", \\\"{x:390,y:522,t:1527876910891};\\\", \\\"{x:392,y:523,t:1527876910909};\\\", \\\"{x:394,y:524,t:1527876910926};\\\", \\\"{x:396,y:526,t:1527876910943};\\\", \\\"{x:397,y:527,t:1527876910959};\\\", \\\"{x:397,y:528,t:1527876911087};\\\", \\\"{x:395,y:529,t:1527876911095};\\\", \\\"{x:395,y:530,t:1527876911109};\\\", \\\"{x:394,y:530,t:1527876911126};\\\", \\\"{x:391,y:534,t:1527876911143};\\\", \\\"{x:386,y:539,t:1527876911158};\\\", \\\"{x:383,y:540,t:1527876911176};\\\", \\\"{x:383,y:541,t:1527876911193};\\\", \\\"{x:394,y:542,t:1527876911640};\\\", \\\"{x:420,y:548,t:1527876911648};\\\", \\\"{x:448,y:556,t:1527876911660};\\\", \\\"{x:549,y:574,t:1527876911676};\\\", \\\"{x:671,y:593,t:1527876911693};\\\", \\\"{x:826,y:615,t:1527876911711};\\\", \\\"{x:1005,y:639,t:1527876911727};\\\", \\\"{x:1316,y:683,t:1527876911743};\\\", \\\"{x:1492,y:721,t:1527876911759};\\\", \\\"{x:1632,y:760,t:1527876911776};\\\", \\\"{x:1720,y:793,t:1527876911793};\\\", \\\"{x:1758,y:813,t:1527876911810};\\\", \\\"{x:1776,y:828,t:1527876911827};\\\", \\\"{x:1780,y:838,t:1527876911843};\\\", \\\"{x:1780,y:846,t:1527876911860};\\\", \\\"{x:1771,y:861,t:1527876911877};\\\", \\\"{x:1761,y:880,t:1527876911893};\\\", \\\"{x:1745,y:907,t:1527876911910};\\\", \\\"{x:1725,y:929,t:1527876911927};\\\", \\\"{x:1701,y:949,t:1527876911943};\\\", \\\"{x:1658,y:973,t:1527876911960};\\\", \\\"{x:1617,y:988,t:1527876911977};\\\", \\\"{x:1564,y:1006,t:1527876911993};\\\", \\\"{x:1509,y:1017,t:1527876912010};\\\", \\\"{x:1453,y:1025,t:1527876912027};\\\", \\\"{x:1413,y:1028,t:1527876912044};\\\", \\\"{x:1383,y:1032,t:1527876912060};\\\", \\\"{x:1373,y:1032,t:1527876912078};\\\", \\\"{x:1369,y:1032,t:1527876912093};\\\", \\\"{x:1369,y:1031,t:1527876912127};\\\", \\\"{x:1368,y:1031,t:1527876912143};\\\", \\\"{x:1366,y:1028,t:1527876912159};\\\", \\\"{x:1365,y:1026,t:1527876912177};\\\", \\\"{x:1363,y:1021,t:1527876912193};\\\", \\\"{x:1363,y:1017,t:1527876912209};\\\", \\\"{x:1362,y:1011,t:1527876912227};\\\", \\\"{x:1362,y:1009,t:1527876912243};\\\", \\\"{x:1362,y:1002,t:1527876912260};\\\", \\\"{x:1362,y:995,t:1527876912277};\\\", \\\"{x:1362,y:983,t:1527876912294};\\\", \\\"{x:1362,y:978,t:1527876912310};\\\", \\\"{x:1362,y:974,t:1527876912327};\\\", \\\"{x:1362,y:969,t:1527876912343};\\\", \\\"{x:1362,y:966,t:1527876912360};\\\", \\\"{x:1361,y:962,t:1527876912377};\\\", \\\"{x:1361,y:958,t:1527876912394};\\\", \\\"{x:1359,y:954,t:1527876912410};\\\", \\\"{x:1359,y:952,t:1527876912428};\\\", \\\"{x:1359,y:951,t:1527876912444};\\\", \\\"{x:1358,y:950,t:1527876912460};\\\", \\\"{x:1358,y:949,t:1527876912512};\\\", \\\"{x:1357,y:948,t:1527876912528};\\\", \\\"{x:1356,y:948,t:1527876912545};\\\", \\\"{x:1354,y:948,t:1527876912617};\\\", \\\"{x:1353,y:948,t:1527876912627};\\\", \\\"{x:1352,y:948,t:1527876912644};\\\", \\\"{x:1348,y:949,t:1527876912661};\\\", \\\"{x:1344,y:950,t:1527876912678};\\\", \\\"{x:1341,y:953,t:1527876912694};\\\", \\\"{x:1339,y:954,t:1527876912710};\\\", \\\"{x:1340,y:953,t:1527876912792};\\\", \\\"{x:1341,y:951,t:1527876912799};\\\", \\\"{x:1344,y:949,t:1527876912811};\\\", \\\"{x:1349,y:938,t:1527876912827};\\\", \\\"{x:1360,y:923,t:1527876912844};\\\", \\\"{x:1371,y:908,t:1527876912860};\\\", \\\"{x:1379,y:897,t:1527876912878};\\\", \\\"{x:1387,y:884,t:1527876912895};\\\", \\\"{x:1393,y:876,t:1527876912912};\\\", \\\"{x:1395,y:869,t:1527876912928};\\\", \\\"{x:1398,y:861,t:1527876912944};\\\", \\\"{x:1398,y:859,t:1527876912961};\\\", \\\"{x:1399,y:855,t:1527876912977};\\\", \\\"{x:1402,y:848,t:1527876912995};\\\", \\\"{x:1403,y:840,t:1527876913012};\\\", \\\"{x:1407,y:828,t:1527876913028};\\\", \\\"{x:1408,y:820,t:1527876913044};\\\", \\\"{x:1416,y:806,t:1527876913061};\\\", \\\"{x:1423,y:788,t:1527876913078};\\\", \\\"{x:1432,y:771,t:1527876913094};\\\", \\\"{x:1443,y:753,t:1527876913111};\\\", \\\"{x:1462,y:727,t:1527876913127};\\\", \\\"{x:1470,y:711,t:1527876913145};\\\", \\\"{x:1478,y:698,t:1527876913162};\\\", \\\"{x:1486,y:679,t:1527876913177};\\\", \\\"{x:1494,y:659,t:1527876913194};\\\", \\\"{x:1501,y:639,t:1527876913212};\\\", \\\"{x:1505,y:624,t:1527876913227};\\\", \\\"{x:1509,y:612,t:1527876913245};\\\", \\\"{x:1510,y:603,t:1527876913262};\\\", \\\"{x:1514,y:591,t:1527876913277};\\\", \\\"{x:1519,y:577,t:1527876913294};\\\", \\\"{x:1533,y:552,t:1527876913311};\\\", \\\"{x:1544,y:537,t:1527876913326};\\\", \\\"{x:1552,y:525,t:1527876913344};\\\", \\\"{x:1555,y:518,t:1527876913360};\\\", \\\"{x:1557,y:510,t:1527876913378};\\\", \\\"{x:1563,y:498,t:1527876913394};\\\", \\\"{x:1570,y:490,t:1527876913410};\\\", \\\"{x:1579,y:478,t:1527876913429};\\\", \\\"{x:1588,y:472,t:1527876913444};\\\", \\\"{x:1592,y:467,t:1527876913461};\\\", \\\"{x:1593,y:466,t:1527876913478};\\\", \\\"{x:1594,y:464,t:1527876913495};\\\", \\\"{x:1595,y:462,t:1527876913511};\\\", \\\"{x:1595,y:464,t:1527876913696};\\\", \\\"{x:1593,y:466,t:1527876913712};\\\", \\\"{x:1591,y:470,t:1527876913728};\\\", \\\"{x:1589,y:473,t:1527876913745};\\\", \\\"{x:1589,y:476,t:1527876913761};\\\", \\\"{x:1588,y:479,t:1527876913778};\\\", \\\"{x:1587,y:483,t:1527876913794};\\\", \\\"{x:1585,y:487,t:1527876913811};\\\", \\\"{x:1584,y:491,t:1527876913829};\\\", \\\"{x:1582,y:498,t:1527876913845};\\\", \\\"{x:1581,y:502,t:1527876913862};\\\", \\\"{x:1581,y:504,t:1527876913879};\\\", \\\"{x:1580,y:509,t:1527876913896};\\\", \\\"{x:1578,y:514,t:1527876913912};\\\", \\\"{x:1577,y:521,t:1527876913928};\\\", \\\"{x:1576,y:528,t:1527876913945};\\\", \\\"{x:1572,y:539,t:1527876913962};\\\", \\\"{x:1567,y:551,t:1527876913978};\\\", \\\"{x:1557,y:566,t:1527876913996};\\\", \\\"{x:1545,y:582,t:1527876914011};\\\", \\\"{x:1527,y:600,t:1527876914029};\\\", \\\"{x:1505,y:617,t:1527876914046};\\\", \\\"{x:1482,y:629,t:1527876914061};\\\", \\\"{x:1453,y:640,t:1527876914079};\\\", \\\"{x:1360,y:648,t:1527876914096};\\\", \\\"{x:1272,y:648,t:1527876914111};\\\", \\\"{x:1175,y:648,t:1527876914128};\\\", \\\"{x:1091,y:648,t:1527876914145};\\\", \\\"{x:997,y:648,t:1527876914161};\\\", \\\"{x:914,y:648,t:1527876914179};\\\", \\\"{x:841,y:648,t:1527876914196};\\\", \\\"{x:793,y:650,t:1527876914212};\\\", \\\"{x:770,y:650,t:1527876914228};\\\", \\\"{x:763,y:650,t:1527876914245};\\\", \\\"{x:762,y:650,t:1527876914262};\\\", \\\"{x:761,y:650,t:1527876915056};\\\", \\\"{x:760,y:649,t:1527876915064};\\\", \\\"{x:753,y:646,t:1527876915079};\\\", \\\"{x:743,y:643,t:1527876915096};\\\", \\\"{x:726,y:638,t:1527876915112};\\\", \\\"{x:705,y:635,t:1527876915129};\\\", \\\"{x:685,y:633,t:1527876915145};\\\", \\\"{x:673,y:630,t:1527876915164};\\\", \\\"{x:662,y:628,t:1527876915179};\\\", \\\"{x:659,y:627,t:1527876915194};\\\", \\\"{x:657,y:625,t:1527876915212};\\\", \\\"{x:652,y:623,t:1527876915229};\\\", \\\"{x:649,y:621,t:1527876915245};\\\", \\\"{x:647,y:620,t:1527876915262};\\\", \\\"{x:645,y:616,t:1527876915279};\\\", \\\"{x:643,y:613,t:1527876915295};\\\", \\\"{x:642,y:606,t:1527876915311};\\\", \\\"{x:639,y:591,t:1527876915329};\\\", \\\"{x:635,y:571,t:1527876915345};\\\", \\\"{x:628,y:557,t:1527876915363};\\\", \\\"{x:621,y:546,t:1527876915380};\\\", \\\"{x:615,y:541,t:1527876915396};\\\", \\\"{x:613,y:539,t:1527876915413};\\\", \\\"{x:612,y:539,t:1527876915455};\\\", \\\"{x:611,y:539,t:1527876915463};\\\", \\\"{x:605,y:539,t:1527876915479};\\\", \\\"{x:598,y:542,t:1527876915497};\\\", \\\"{x:579,y:550,t:1527876915513};\\\", \\\"{x:557,y:555,t:1527876915529};\\\", \\\"{x:525,y:562,t:1527876915548};\\\", \\\"{x:479,y:573,t:1527876915564};\\\", \\\"{x:413,y:588,t:1527876915580};\\\", \\\"{x:336,y:597,t:1527876915597};\\\", \\\"{x:255,y:610,t:1527876915613};\\\", \\\"{x:203,y:621,t:1527876915630};\\\", \\\"{x:158,y:627,t:1527876915647};\\\", \\\"{x:133,y:631,t:1527876915664};\\\", \\\"{x:132,y:631,t:1527876915679};\\\", \\\"{x:135,y:631,t:1527876915792};\\\", \\\"{x:136,y:631,t:1527876915800};\\\", \\\"{x:138,y:630,t:1527876915813};\\\", \\\"{x:142,y:630,t:1527876915831};\\\", \\\"{x:165,y:630,t:1527876915847};\\\", \\\"{x:191,y:631,t:1527876915864};\\\", \\\"{x:217,y:635,t:1527876915881};\\\", \\\"{x:237,y:642,t:1527876915898};\\\", \\\"{x:247,y:646,t:1527876915913};\\\", \\\"{x:251,y:647,t:1527876915930};\\\", \\\"{x:253,y:648,t:1527876915946};\\\", \\\"{x:256,y:649,t:1527876915964};\\\", \\\"{x:262,y:650,t:1527876915980};\\\", \\\"{x:267,y:650,t:1527876915997};\\\", \\\"{x:272,y:650,t:1527876916013};\\\", \\\"{x:283,y:650,t:1527876916030};\\\", \\\"{x:303,y:650,t:1527876916047};\\\", \\\"{x:321,y:644,t:1527876916063};\\\", \\\"{x:335,y:638,t:1527876916080};\\\", \\\"{x:348,y:629,t:1527876916098};\\\", \\\"{x:351,y:626,t:1527876916113};\\\", \\\"{x:352,y:625,t:1527876916130};\\\", \\\"{x:352,y:624,t:1527876916264};\\\", \\\"{x:353,y:622,t:1527876916280};\\\", \\\"{x:353,y:621,t:1527876916297};\\\", \\\"{x:354,y:621,t:1527876916463};\\\", \\\"{x:356,y:621,t:1527876916480};\\\", \\\"{x:357,y:621,t:1527876916497};\\\", \\\"{x:363,y:621,t:1527876916514};\\\", \\\"{x:368,y:621,t:1527876916530};\\\", \\\"{x:370,y:621,t:1527876916547};\\\", \\\"{x:371,y:621,t:1527876916672};\\\", \\\"{x:372,y:621,t:1527876916791};\\\", \\\"{x:373,y:621,t:1527876916798};\\\", \\\"{x:375,y:621,t:1527876916815};\\\", \\\"{x:377,y:621,t:1527876916831};\\\", \\\"{x:377,y:621,t:1527876916863};\\\", \\\"{x:378,y:621,t:1527876917255};\\\", \\\"{x:380,y:621,t:1527876917264};\\\", \\\"{x:381,y:620,t:1527876917294};\\\", \\\"{x:382,y:619,t:1527876917303};\\\", \\\"{x:382,y:617,t:1527876917314};\\\", \\\"{x:382,y:616,t:1527876917331};\\\", \\\"{x:395,y:615,t:1527876917816};\\\", \\\"{x:461,y:615,t:1527876917832};\\\", \\\"{x:566,y:615,t:1527876917849};\\\", \\\"{x:721,y:615,t:1527876917864};\\\", \\\"{x:920,y:615,t:1527876917882};\\\", \\\"{x:1152,y:615,t:1527876917898};\\\", \\\"{x:1395,y:616,t:1527876917915};\\\", \\\"{x:1636,y:626,t:1527876917931};\\\", \\\"{x:1869,y:642,t:1527876917948};\\\", \\\"{x:1919,y:667,t:1527876917966};\\\", \\\"{x:1919,y:696,t:1527876917982};\\\", \\\"{x:1919,y:725,t:1527876917998};\\\", \\\"{x:1919,y:760,t:1527876918015};\\\", \\\"{x:1919,y:789,t:1527876918032};\\\", \\\"{x:1917,y:809,t:1527876918048};\\\", \\\"{x:1904,y:826,t:1527876918065};\\\", \\\"{x:1885,y:839,t:1527876918083};\\\", \\\"{x:1862,y:853,t:1527876918098};\\\", \\\"{x:1835,y:868,t:1527876918115};\\\", \\\"{x:1794,y:884,t:1527876918131};\\\", \\\"{x:1758,y:901,t:1527876918149};\\\", \\\"{x:1711,y:921,t:1527876918165};\\\", \\\"{x:1655,y:946,t:1527876918182};\\\", \\\"{x:1600,y:970,t:1527876918199};\\\", \\\"{x:1532,y:993,t:1527876918215};\\\", \\\"{x:1497,y:1005,t:1527876918231};\\\", \\\"{x:1472,y:1017,t:1527876918248};\\\", \\\"{x:1455,y:1024,t:1527876918266};\\\", \\\"{x:1437,y:1034,t:1527876918284};\\\", \\\"{x:1423,y:1042,t:1527876918298};\\\", \\\"{x:1410,y:1050,t:1527876918316};\\\", \\\"{x:1401,y:1055,t:1527876918333};\\\", \\\"{x:1394,y:1058,t:1527876918348};\\\", \\\"{x:1389,y:1059,t:1527876918365};\\\", \\\"{x:1385,y:1060,t:1527876918382};\\\", \\\"{x:1380,y:1060,t:1527876918398};\\\", \\\"{x:1372,y:1060,t:1527876918416};\\\", \\\"{x:1370,y:1060,t:1527876918432};\\\", \\\"{x:1369,y:1060,t:1527876918464};\\\", \\\"{x:1368,y:1059,t:1527876918487};\\\", \\\"{x:1368,y:1055,t:1527876918504};\\\", \\\"{x:1366,y:1051,t:1527876918516};\\\", \\\"{x:1362,y:1040,t:1527876918532};\\\", \\\"{x:1357,y:1029,t:1527876918548};\\\", \\\"{x:1353,y:1020,t:1527876918566};\\\", \\\"{x:1349,y:1013,t:1527876918583};\\\", \\\"{x:1344,y:1006,t:1527876918599};\\\", \\\"{x:1337,y:999,t:1527876918616};\\\", \\\"{x:1334,y:995,t:1527876918632};\\\", \\\"{x:1332,y:992,t:1527876918649};\\\", \\\"{x:1331,y:991,t:1527876918665};\\\", \\\"{x:1330,y:989,t:1527876918683};\\\", \\\"{x:1329,y:989,t:1527876918699};\\\", \\\"{x:1329,y:987,t:1527876918715};\\\", \\\"{x:1327,y:984,t:1527876918733};\\\", \\\"{x:1324,y:980,t:1527876918749};\\\", \\\"{x:1323,y:978,t:1527876918766};\\\", \\\"{x:1321,y:975,t:1527876918782};\\\", \\\"{x:1317,y:971,t:1527876918800};\\\", \\\"{x:1316,y:968,t:1527876918816};\\\", \\\"{x:1314,y:966,t:1527876918832};\\\", \\\"{x:1312,y:965,t:1527876918850};\\\", \\\"{x:1310,y:964,t:1527876918865};\\\", \\\"{x:1309,y:963,t:1527876918883};\\\", \\\"{x:1308,y:963,t:1527876919192};\\\", \\\"{x:1307,y:963,t:1527876919207};\\\", \\\"{x:1306,y:963,t:1527876919216};\\\", \\\"{x:1304,y:964,t:1527876919232};\\\", \\\"{x:1301,y:965,t:1527876919250};\\\", \\\"{x:1300,y:965,t:1527876919267};\\\", \\\"{x:1298,y:965,t:1527876919287};\\\", \\\"{x:1297,y:965,t:1527876919299};\\\", \\\"{x:1295,y:965,t:1527876919319};\\\", \\\"{x:1295,y:966,t:1527876919332};\\\", \\\"{x:1292,y:966,t:1527876919349};\\\", \\\"{x:1288,y:967,t:1527876919366};\\\", \\\"{x:1280,y:967,t:1527876919382};\\\", \\\"{x:1264,y:967,t:1527876919399};\\\", \\\"{x:1246,y:967,t:1527876919417};\\\", \\\"{x:1230,y:967,t:1527876919432};\\\", \\\"{x:1214,y:967,t:1527876919449};\\\", \\\"{x:1201,y:967,t:1527876919466};\\\", \\\"{x:1194,y:967,t:1527876919483};\\\", \\\"{x:1191,y:967,t:1527876919499};\\\", \\\"{x:1188,y:968,t:1527876919516};\\\", \\\"{x:1188,y:969,t:1527876919632};\\\", \\\"{x:1189,y:970,t:1527876919640};\\\", \\\"{x:1193,y:972,t:1527876919649};\\\", \\\"{x:1202,y:973,t:1527876919666};\\\", \\\"{x:1217,y:974,t:1527876919683};\\\", \\\"{x:1236,y:974,t:1527876919699};\\\", \\\"{x:1259,y:974,t:1527876919716};\\\", \\\"{x:1277,y:974,t:1527876919734};\\\", \\\"{x:1287,y:974,t:1527876919749};\\\", \\\"{x:1292,y:974,t:1527876919766};\\\", \\\"{x:1292,y:973,t:1527876919871};\\\", \\\"{x:1300,y:973,t:1527876919887};\\\", \\\"{x:1309,y:973,t:1527876919900};\\\", \\\"{x:1328,y:973,t:1527876919917};\\\", \\\"{x:1346,y:972,t:1527876919934};\\\", \\\"{x:1359,y:972,t:1527876919950};\\\", \\\"{x:1365,y:972,t:1527876919967};\\\", \\\"{x:1366,y:971,t:1527876920289};\\\", \\\"{x:1366,y:969,t:1527876920304};\\\", \\\"{x:1366,y:967,t:1527876920317};\\\", \\\"{x:1364,y:964,t:1527876920333};\\\", \\\"{x:1364,y:961,t:1527876920351};\\\", \\\"{x:1362,y:959,t:1527876920367};\\\", \\\"{x:1362,y:954,t:1527876920383};\\\", \\\"{x:1363,y:950,t:1527876920400};\\\", \\\"{x:1367,y:943,t:1527876920417};\\\", \\\"{x:1375,y:932,t:1527876920433};\\\", \\\"{x:1381,y:922,t:1527876920450};\\\", \\\"{x:1386,y:914,t:1527876920467};\\\", \\\"{x:1390,y:905,t:1527876920483};\\\", \\\"{x:1394,y:894,t:1527876920500};\\\", \\\"{x:1396,y:886,t:1527876920518};\\\", \\\"{x:1401,y:878,t:1527876920533};\\\", \\\"{x:1407,y:869,t:1527876920550};\\\", \\\"{x:1415,y:861,t:1527876920567};\\\", \\\"{x:1422,y:853,t:1527876920583};\\\", \\\"{x:1428,y:842,t:1527876920601};\\\", \\\"{x:1433,y:831,t:1527876920618};\\\", \\\"{x:1443,y:815,t:1527876920633};\\\", \\\"{x:1453,y:796,t:1527876920650};\\\", \\\"{x:1465,y:775,t:1527876920668};\\\", \\\"{x:1476,y:756,t:1527876920684};\\\", \\\"{x:1492,y:737,t:1527876920700};\\\", \\\"{x:1507,y:717,t:1527876920718};\\\", \\\"{x:1517,y:701,t:1527876920733};\\\", \\\"{x:1527,y:682,t:1527876920751};\\\", \\\"{x:1538,y:656,t:1527876920767};\\\", \\\"{x:1547,y:643,t:1527876920784};\\\", \\\"{x:1554,y:631,t:1527876920800};\\\", \\\"{x:1560,y:619,t:1527876920818};\\\", \\\"{x:1567,y:603,t:1527876920833};\\\", \\\"{x:1572,y:589,t:1527876920851};\\\", \\\"{x:1579,y:580,t:1527876920867};\\\", \\\"{x:1587,y:566,t:1527876920885};\\\", \\\"{x:1594,y:555,t:1527876920900};\\\", \\\"{x:1598,y:548,t:1527876920918};\\\", \\\"{x:1599,y:543,t:1527876920935};\\\", \\\"{x:1601,y:536,t:1527876920951};\\\", \\\"{x:1601,y:531,t:1527876920968};\\\", \\\"{x:1601,y:527,t:1527876920985};\\\", \\\"{x:1601,y:524,t:1527876921000};\\\", \\\"{x:1601,y:523,t:1527876921017};\\\", \\\"{x:1600,y:519,t:1527876921035};\\\", \\\"{x:1598,y:516,t:1527876921051};\\\", \\\"{x:1597,y:511,t:1527876921067};\\\", \\\"{x:1597,y:503,t:1527876921084};\\\", \\\"{x:1597,y:494,t:1527876921100};\\\", \\\"{x:1597,y:486,t:1527876921117};\\\", \\\"{x:1597,y:480,t:1527876921134};\\\", \\\"{x:1599,y:475,t:1527876921150};\\\", \\\"{x:1600,y:468,t:1527876921167};\\\", \\\"{x:1601,y:465,t:1527876921185};\\\", \\\"{x:1600,y:465,t:1527876921288};\\\", \\\"{x:1597,y:465,t:1527876921301};\\\", \\\"{x:1590,y:468,t:1527876921318};\\\", \\\"{x:1583,y:473,t:1527876921335};\\\", \\\"{x:1576,y:481,t:1527876921352};\\\", \\\"{x:1571,y:490,t:1527876921368};\\\", \\\"{x:1560,y:508,t:1527876921385};\\\", \\\"{x:1541,y:542,t:1527876921402};\\\", \\\"{x:1512,y:589,t:1527876921418};\\\", \\\"{x:1478,y:635,t:1527876921435};\\\", \\\"{x:1442,y:678,t:1527876921452};\\\", \\\"{x:1413,y:720,t:1527876921468};\\\", \\\"{x:1373,y:772,t:1527876921485};\\\", \\\"{x:1318,y:822,t:1527876921502};\\\", \\\"{x:1256,y:864,t:1527876921518};\\\", \\\"{x:1179,y:900,t:1527876921534};\\\", \\\"{x:1047,y:928,t:1527876921552};\\\", \\\"{x:979,y:933,t:1527876921568};\\\", \\\"{x:920,y:933,t:1527876921585};\\\", \\\"{x:872,y:925,t:1527876921601};\\\", \\\"{x:826,y:922,t:1527876921617};\\\", \\\"{x:769,y:919,t:1527876921635};\\\", \\\"{x:697,y:927,t:1527876921652};\\\", \\\"{x:624,y:929,t:1527876921668};\\\", \\\"{x:562,y:929,t:1527876921685};\\\", \\\"{x:517,y:929,t:1527876921701};\\\", \\\"{x:487,y:920,t:1527876921718};\\\", \\\"{x:467,y:914,t:1527876921734};\\\", \\\"{x:451,y:905,t:1527876921752};\\\", \\\"{x:443,y:897,t:1527876921768};\\\", \\\"{x:436,y:886,t:1527876921785};\\\", \\\"{x:428,y:875,t:1527876921802};\\\", \\\"{x:422,y:864,t:1527876921819};\\\", \\\"{x:421,y:845,t:1527876921835};\\\", \\\"{x:424,y:823,t:1527876921851};\\\", \\\"{x:434,y:803,t:1527876921868};\\\", \\\"{x:441,y:789,t:1527876921884};\\\", \\\"{x:447,y:782,t:1527876921902};\\\", \\\"{x:449,y:780,t:1527876921919};\\\", \\\"{x:450,y:778,t:1527876921935};\\\", \\\"{x:450,y:776,t:1527876922033};\\\", \\\"{x:452,y:774,t:1527876922039};\\\", \\\"{x:454,y:772,t:1527876922051};\\\", \\\"{x:460,y:766,t:1527876922069};\\\", \\\"{x:467,y:760,t:1527876922085};\\\", \\\"{x:474,y:756,t:1527876922101};\\\", \\\"{x:484,y:749,t:1527876922120};\\\", \\\"{x:504,y:736,t:1527876922135};\\\", \\\"{x:515,y:726,t:1527876922151};\\\", \\\"{x:526,y:718,t:1527876922169};\\\", \\\"{x:530,y:715,t:1527876922185};\\\", \\\"{x:530,y:714,t:1527876922201};\\\", \\\"{x:530,y:713,t:1527876922223};\\\", \\\"{x:530,y:717,t:1527876922424};\\\", \\\"{x:530,y:721,t:1527876922436};\\\", \\\"{x:528,y:726,t:1527876922451};\\\", \\\"{x:527,y:730,t:1527876922468};\\\", \\\"{x:527,y:731,t:1527876922485};\\\", \\\"{x:526,y:731,t:1527876922576};\\\", \\\"{x:526,y:732,t:1527876922648};\\\", \\\"{x:525,y:732,t:1527876922719};\\\", \\\"{x:524,y:733,t:1527876922743};\\\", \\\"{x:523,y:733,t:1527876922753};\\\", \\\"{x:523,y:733,t:1527876922838};\\\" ] }, { \\\"rt\\\": 12558, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 16, \\\"time_elapsed\\\": 526587, \\\"internal_node_id\\\": \\\"0.0-6.0-6.0\\\", \\\"subject\\\": \\\"EER58\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"starts\\\", \\\"q\\\": 12, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"G\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-O -F -F -G -G -G -G -E -G -G -F -G -F \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:528,y:733,t:1527876926392};\\\", \\\"{x:555,y:730,t:1527876926408};\\\", \\\"{x:590,y:726,t:1527876926429};\\\", \\\"{x:619,y:724,t:1527876926440};\\\", \\\"{x:643,y:721,t:1527876926457};\\\", \\\"{x:666,y:721,t:1527876926472};\\\", \\\"{x:684,y:720,t:1527876926488};\\\", \\\"{x:689,y:719,t:1527876926505};\\\", \\\"{x:690,y:718,t:1527876926567};\\\", \\\"{x:690,y:717,t:1527876926591};\\\", \\\"{x:691,y:716,t:1527876926605};\\\", \\\"{x:691,y:715,t:1527876926621};\\\", \\\"{x:691,y:714,t:1527876926638};\\\", \\\"{x:692,y:713,t:1527876926655};\\\", \\\"{x:692,y:711,t:1527876926671};\\\", \\\"{x:692,y:710,t:1527876926688};\\\", \\\"{x:692,y:709,t:1527876926706};\\\", \\\"{x:692,y:708,t:1527876926735};\\\", \\\"{x:697,y:707,t:1527876926743};\\\", \\\"{x:712,y:706,t:1527876926755};\\\", \\\"{x:768,y:706,t:1527876926771};\\\", \\\"{x:865,y:706,t:1527876926789};\\\", \\\"{x:973,y:706,t:1527876926806};\\\", \\\"{x:1101,y:706,t:1527876926822};\\\", \\\"{x:1231,y:706,t:1527876926839};\\\", \\\"{x:1446,y:706,t:1527876926856};\\\", \\\"{x:1590,y:706,t:1527876926872};\\\", \\\"{x:1704,y:706,t:1527876926889};\\\", \\\"{x:1812,y:706,t:1527876926906};\\\", \\\"{x:1899,y:720,t:1527876926923};\\\", \\\"{x:1919,y:738,t:1527876926939};\\\", \\\"{x:1919,y:743,t:1527876927143};\\\", \\\"{x:1917,y:743,t:1527876927231};\\\", \\\"{x:1912,y:741,t:1527876927239};\\\", \\\"{x:1896,y:740,t:1527876927255};\\\", \\\"{x:1871,y:740,t:1527876927272};\\\", \\\"{x:1840,y:740,t:1527876927289};\\\", \\\"{x:1794,y:741,t:1527876927305};\\\", \\\"{x:1748,y:745,t:1527876927322};\\\", \\\"{x:1680,y:748,t:1527876927339};\\\", \\\"{x:1612,y:752,t:1527876927355};\\\", \\\"{x:1564,y:752,t:1527876927373};\\\", \\\"{x:1537,y:752,t:1527876927390};\\\", \\\"{x:1515,y:751,t:1527876927405};\\\", \\\"{x:1503,y:751,t:1527876927423};\\\", \\\"{x:1500,y:750,t:1527876927439};\\\", \\\"{x:1498,y:750,t:1527876927656};\\\", \\\"{x:1497,y:750,t:1527876927673};\\\", \\\"{x:1496,y:750,t:1527876927690};\\\", \\\"{x:1495,y:750,t:1527876927706};\\\", \\\"{x:1492,y:749,t:1527876927723};\\\", \\\"{x:1488,y:746,t:1527876927740};\\\", \\\"{x:1475,y:738,t:1527876927757};\\\", \\\"{x:1462,y:731,t:1527876927773};\\\", \\\"{x:1441,y:720,t:1527876927790};\\\", \\\"{x:1419,y:710,t:1527876927807};\\\", \\\"{x:1403,y:704,t:1527876927823};\\\", \\\"{x:1388,y:698,t:1527876927839};\\\", \\\"{x:1386,y:697,t:1527876927857};\\\", \\\"{x:1385,y:697,t:1527876927873};\\\", \\\"{x:1384,y:697,t:1527876927936};\\\", \\\"{x:1383,y:697,t:1527876927944};\\\", \\\"{x:1382,y:697,t:1527876927968};\\\", \\\"{x:1381,y:697,t:1527876927999};\\\", \\\"{x:1380,y:697,t:1527876928007};\\\", \\\"{x:1379,y:697,t:1527876928024};\\\", \\\"{x:1378,y:698,t:1527876928040};\\\", \\\"{x:1376,y:699,t:1527876928057};\\\", \\\"{x:1373,y:700,t:1527876928073};\\\", \\\"{x:1372,y:700,t:1527876928090};\\\", \\\"{x:1369,y:700,t:1527876928107};\\\", \\\"{x:1365,y:700,t:1527876928123};\\\", \\\"{x:1359,y:700,t:1527876928140};\\\", \\\"{x:1355,y:700,t:1527876928157};\\\", \\\"{x:1354,y:700,t:1527876928174};\\\", \\\"{x:1354,y:701,t:1527876928190};\\\", \\\"{x:1352,y:701,t:1527876928207};\\\", \\\"{x:1349,y:701,t:1527876928226};\\\", \\\"{x:1347,y:702,t:1527876928239};\\\", \\\"{x:1345,y:703,t:1527876928258};\\\", \\\"{x:1345,y:702,t:1527876928608};\\\", \\\"{x:1345,y:700,t:1527876928624};\\\", \\\"{x:1346,y:697,t:1527876928641};\\\", \\\"{x:1348,y:694,t:1527876928657};\\\", \\\"{x:1349,y:692,t:1527876928674};\\\", \\\"{x:1352,y:687,t:1527876928692};\\\", \\\"{x:1354,y:680,t:1527876928707};\\\", \\\"{x:1364,y:663,t:1527876928724};\\\", \\\"{x:1370,y:645,t:1527876928741};\\\", \\\"{x:1378,y:629,t:1527876928757};\\\", \\\"{x:1385,y:613,t:1527876928774};\\\", \\\"{x:1392,y:603,t:1527876928791};\\\", \\\"{x:1395,y:595,t:1527876928808};\\\", \\\"{x:1403,y:583,t:1527876928824};\\\", \\\"{x:1409,y:572,t:1527876928841};\\\", \\\"{x:1415,y:564,t:1527876928857};\\\", \\\"{x:1418,y:556,t:1527876928875};\\\", \\\"{x:1420,y:554,t:1527876928892};\\\", \\\"{x:1420,y:553,t:1527876928907};\\\", \\\"{x:1420,y:552,t:1527876929376};\\\", \\\"{x:1417,y:553,t:1527876929391};\\\", \\\"{x:1412,y:560,t:1527876929409};\\\", \\\"{x:1410,y:563,t:1527876929424};\\\", \\\"{x:1409,y:566,t:1527876929442};\\\", \\\"{x:1409,y:568,t:1527876929458};\\\", \\\"{x:1408,y:570,t:1527876929474};\\\", \\\"{x:1407,y:571,t:1527876929491};\\\", \\\"{x:1406,y:572,t:1527876929519};\\\", \\\"{x:1406,y:575,t:1527876930088};\\\", \\\"{x:1401,y:578,t:1527876930096};\\\", \\\"{x:1391,y:580,t:1527876930108};\\\", \\\"{x:1336,y:595,t:1527876930125};\\\", \\\"{x:1239,y:623,t:1527876930142};\\\", \\\"{x:1110,y:654,t:1527876930158};\\\", \\\"{x:954,y:681,t:1527876930175};\\\", \\\"{x:705,y:705,t:1527876930192};\\\", \\\"{x:555,y:711,t:1527876930208};\\\", \\\"{x:439,y:711,t:1527876930225};\\\", \\\"{x:361,y:711,t:1527876930242};\\\", \\\"{x:331,y:709,t:1527876930258};\\\", \\\"{x:319,y:705,t:1527876930275};\\\", \\\"{x:317,y:703,t:1527876930292};\\\", \\\"{x:317,y:700,t:1527876930307};\\\", \\\"{x:317,y:698,t:1527876930325};\\\", \\\"{x:321,y:691,t:1527876930342};\\\", \\\"{x:337,y:680,t:1527876930359};\\\", \\\"{x:370,y:657,t:1527876930377};\\\", \\\"{x:402,y:640,t:1527876930391};\\\", \\\"{x:430,y:622,t:1527876930408};\\\", \\\"{x:458,y:610,t:1527876930424};\\\", \\\"{x:485,y:597,t:1527876930442};\\\", \\\"{x:512,y:582,t:1527876930458};\\\", \\\"{x:523,y:577,t:1527876930475};\\\", \\\"{x:524,y:576,t:1527876930492};\\\", \\\"{x:525,y:575,t:1527876930508};\\\", \\\"{x:526,y:575,t:1527876930524};\\\", \\\"{x:529,y:573,t:1527876930541};\\\", \\\"{x:538,y:567,t:1527876930559};\\\", \\\"{x:544,y:564,t:1527876930574};\\\", \\\"{x:560,y:554,t:1527876930592};\\\", \\\"{x:567,y:550,t:1527876930609};\\\", \\\"{x:578,y:546,t:1527876930625};\\\", \\\"{x:603,y:543,t:1527876930642};\\\", \\\"{x:656,y:537,t:1527876930659};\\\", \\\"{x:726,y:527,t:1527876930677};\\\", \\\"{x:810,y:514,t:1527876930692};\\\", \\\"{x:892,y:505,t:1527876930709};\\\", \\\"{x:968,y:501,t:1527876930726};\\\", \\\"{x:1013,y:497,t:1527876930742};\\\", \\\"{x:1038,y:496,t:1527876930758};\\\", \\\"{x:1050,y:495,t:1527876930776};\\\", \\\"{x:1051,y:495,t:1527876930792};\\\", \\\"{x:1050,y:495,t:1527876930871};\\\", \\\"{x:1047,y:496,t:1527876930880};\\\", \\\"{x:1042,y:499,t:1527876930892};\\\", \\\"{x:1029,y:508,t:1527876930909};\\\", \\\"{x:1014,y:516,t:1527876930926};\\\", \\\"{x:995,y:525,t:1527876930943};\\\", \\\"{x:965,y:538,t:1527876930960};\\\", \\\"{x:957,y:540,t:1527876930976};\\\", \\\"{x:946,y:544,t:1527876930993};\\\", \\\"{x:945,y:544,t:1527876931009};\\\", \\\"{x:944,y:544,t:1527876931030};\\\", \\\"{x:943,y:545,t:1527876931042};\\\", \\\"{x:940,y:546,t:1527876931059};\\\", \\\"{x:938,y:548,t:1527876931076};\\\", \\\"{x:930,y:551,t:1527876931093};\\\", \\\"{x:919,y:555,t:1527876931108};\\\", \\\"{x:905,y:558,t:1527876931127};\\\", \\\"{x:884,y:561,t:1527876931142};\\\", \\\"{x:868,y:563,t:1527876931159};\\\", \\\"{x:849,y:566,t:1527876931176};\\\", \\\"{x:839,y:567,t:1527876931192};\\\", \\\"{x:837,y:567,t:1527876931208};\\\", \\\"{x:835,y:567,t:1527876931271};\\\", \\\"{x:834,y:567,t:1527876931295};\\\", \\\"{x:833,y:567,t:1527876931320};\\\", \\\"{x:833,y:566,t:1527876931327};\\\", \\\"{x:833,y:563,t:1527876931343};\\\", \\\"{x:835,y:560,t:1527876931359};\\\", \\\"{x:839,y:555,t:1527876931376};\\\", \\\"{x:841,y:551,t:1527876931393};\\\", \\\"{x:842,y:548,t:1527876931408};\\\", \\\"{x:843,y:546,t:1527876931426};\\\", \\\"{x:844,y:546,t:1527876931443};\\\", \\\"{x:844,y:545,t:1527876932367};\\\", \\\"{x:853,y:545,t:1527876932377};\\\", \\\"{x:904,y:545,t:1527876932393};\\\", \\\"{x:985,y:545,t:1527876932411};\\\", \\\"{x:1076,y:545,t:1527876932427};\\\", \\\"{x:1182,y:545,t:1527876932444};\\\", \\\"{x:1276,y:545,t:1527876932460};\\\", \\\"{x:1351,y:545,t:1527876932477};\\\", \\\"{x:1390,y:545,t:1527876932494};\\\", \\\"{x:1411,y:545,t:1527876932510};\\\", \\\"{x:1417,y:546,t:1527876932527};\\\", \\\"{x:1417,y:549,t:1527876932616};\\\", \\\"{x:1417,y:552,t:1527876932627};\\\", \\\"{x:1417,y:560,t:1527876932645};\\\", \\\"{x:1419,y:578,t:1527876932662};\\\", \\\"{x:1424,y:605,t:1527876932678};\\\", \\\"{x:1428,y:631,t:1527876932694};\\\", \\\"{x:1431,y:664,t:1527876932712};\\\", \\\"{x:1431,y:676,t:1527876932728};\\\", \\\"{x:1429,y:686,t:1527876932744};\\\", \\\"{x:1423,y:697,t:1527876932762};\\\", \\\"{x:1421,y:704,t:1527876932778};\\\", \\\"{x:1419,y:708,t:1527876932794};\\\", \\\"{x:1419,y:712,t:1527876932811};\\\", \\\"{x:1416,y:713,t:1527876932827};\\\", \\\"{x:1416,y:714,t:1527876932848};\\\", \\\"{x:1416,y:715,t:1527876932864};\\\", \\\"{x:1415,y:715,t:1527876932960};\\\", \\\"{x:1409,y:713,t:1527876932978};\\\", \\\"{x:1405,y:711,t:1527876932994};\\\", \\\"{x:1399,y:709,t:1527876933011};\\\", \\\"{x:1395,y:707,t:1527876933028};\\\", \\\"{x:1391,y:706,t:1527876933044};\\\", \\\"{x:1387,y:706,t:1527876933061};\\\", \\\"{x:1384,y:706,t:1527876933078};\\\", \\\"{x:1382,y:706,t:1527876933095};\\\", \\\"{x:1374,y:706,t:1527876933112};\\\", \\\"{x:1368,y:706,t:1527876933128};\\\", \\\"{x:1362,y:707,t:1527876933144};\\\", \\\"{x:1356,y:707,t:1527876933161};\\\", \\\"{x:1347,y:711,t:1527876933178};\\\", \\\"{x:1338,y:712,t:1527876933195};\\\", \\\"{x:1333,y:713,t:1527876933211};\\\", \\\"{x:1332,y:713,t:1527876933229};\\\", \\\"{x:1331,y:713,t:1527876933244};\\\", \\\"{x:1330,y:713,t:1527876933261};\\\", \\\"{x:1329,y:714,t:1527876934280};\\\", \\\"{x:1322,y:715,t:1527876934296};\\\", \\\"{x:1313,y:716,t:1527876934312};\\\", \\\"{x:1305,y:717,t:1527876934329};\\\", \\\"{x:1303,y:717,t:1527876934347};\\\", \\\"{x:1302,y:717,t:1527876934363};\\\", \\\"{x:1303,y:717,t:1527876934479};\\\", \\\"{x:1309,y:713,t:1527876934495};\\\", \\\"{x:1316,y:710,t:1527876934512};\\\", \\\"{x:1324,y:705,t:1527876934529};\\\", \\\"{x:1330,y:701,t:1527876934547};\\\", \\\"{x:1335,y:698,t:1527876934563};\\\", \\\"{x:1339,y:695,t:1527876934579};\\\", \\\"{x:1341,y:692,t:1527876934596};\\\", \\\"{x:1342,y:691,t:1527876934612};\\\", \\\"{x:1344,y:689,t:1527876934630};\\\", \\\"{x:1346,y:686,t:1527876934646};\\\", \\\"{x:1354,y:675,t:1527876934664};\\\", \\\"{x:1364,y:660,t:1527876934680};\\\", \\\"{x:1376,y:638,t:1527876934696};\\\", \\\"{x:1390,y:617,t:1527876934714};\\\", \\\"{x:1402,y:596,t:1527876934729};\\\", \\\"{x:1414,y:580,t:1527876934747};\\\", \\\"{x:1422,y:565,t:1527876934763};\\\", \\\"{x:1430,y:554,t:1527876934779};\\\", \\\"{x:1435,y:543,t:1527876934797};\\\", \\\"{x:1438,y:538,t:1527876934814};\\\", \\\"{x:1439,y:533,t:1527876934829};\\\", \\\"{x:1442,y:530,t:1527876934846};\\\", \\\"{x:1442,y:528,t:1527876934863};\\\", \\\"{x:1440,y:530,t:1527876935040};\\\", \\\"{x:1438,y:532,t:1527876935048};\\\", \\\"{x:1431,y:539,t:1527876935064};\\\", \\\"{x:1427,y:546,t:1527876935080};\\\", \\\"{x:1421,y:555,t:1527876935096};\\\", \\\"{x:1418,y:561,t:1527876935114};\\\", \\\"{x:1414,y:569,t:1527876935132};\\\", \\\"{x:1414,y:572,t:1527876935146};\\\", \\\"{x:1411,y:575,t:1527876935164};\\\", \\\"{x:1410,y:577,t:1527876935180};\\\", \\\"{x:1407,y:580,t:1527876935197};\\\", \\\"{x:1403,y:586,t:1527876935214};\\\", \\\"{x:1399,y:593,t:1527876935230};\\\", \\\"{x:1394,y:603,t:1527876935246};\\\", \\\"{x:1387,y:621,t:1527876935264};\\\", \\\"{x:1382,y:632,t:1527876935280};\\\", \\\"{x:1379,y:641,t:1527876935296};\\\", \\\"{x:1376,y:648,t:1527876935314};\\\", \\\"{x:1373,y:653,t:1527876935331};\\\", \\\"{x:1370,y:658,t:1527876935347};\\\", \\\"{x:1367,y:665,t:1527876935364};\\\", \\\"{x:1361,y:675,t:1527876935380};\\\", \\\"{x:1357,y:682,t:1527876935397};\\\", \\\"{x:1351,y:690,t:1527876935414};\\\", \\\"{x:1347,y:696,t:1527876935431};\\\", \\\"{x:1340,y:707,t:1527876935448};\\\", \\\"{x:1332,y:721,t:1527876935463};\\\", \\\"{x:1323,y:732,t:1527876935480};\\\", \\\"{x:1312,y:747,t:1527876935498};\\\", \\\"{x:1303,y:757,t:1527876935514};\\\", \\\"{x:1291,y:772,t:1527876935530};\\\", \\\"{x:1276,y:789,t:1527876935547};\\\", \\\"{x:1257,y:810,t:1527876935563};\\\", \\\"{x:1236,y:829,t:1527876935580};\\\", \\\"{x:1217,y:850,t:1527876935597};\\\", \\\"{x:1195,y:876,t:1527876935613};\\\", \\\"{x:1173,y:903,t:1527876935631};\\\", \\\"{x:1124,y:954,t:1527876935647};\\\", \\\"{x:1071,y:1002,t:1527876935663};\\\", \\\"{x:1003,y:1054,t:1527876935680};\\\", \\\"{x:937,y:1092,t:1527876935698};\\\", \\\"{x:880,y:1117,t:1527876935715};\\\", \\\"{x:844,y:1119,t:1527876935730};\\\", \\\"{x:827,y:1117,t:1527876935747};\\\", \\\"{x:810,y:1107,t:1527876935765};\\\", \\\"{x:794,y:1093,t:1527876935780};\\\", \\\"{x:785,y:1078,t:1527876935797};\\\", \\\"{x:775,y:1053,t:1527876935815};\\\", \\\"{x:760,y:1026,t:1527876935830};\\\", \\\"{x:727,y:988,t:1527876935847};\\\", \\\"{x:701,y:969,t:1527876935864};\\\", \\\"{x:669,y:950,t:1527876935881};\\\", \\\"{x:634,y:931,t:1527876935897};\\\", \\\"{x:590,y:906,t:1527876935915};\\\", \\\"{x:555,y:886,t:1527876935930};\\\", \\\"{x:518,y:868,t:1527876935947};\\\", \\\"{x:479,y:855,t:1527876935964};\\\", \\\"{x:418,y:840,t:1527876935981};\\\", \\\"{x:363,y:834,t:1527876935997};\\\", \\\"{x:335,y:830,t:1527876936015};\\\", \\\"{x:314,y:809,t:1527876936031};\\\", \\\"{x:311,y:787,t:1527876936047};\\\", \\\"{x:312,y:763,t:1527876936064};\\\", \\\"{x:322,y:748,t:1527876936081};\\\", \\\"{x:329,y:738,t:1527876936098};\\\", \\\"{x:332,y:735,t:1527876936114};\\\", \\\"{x:335,y:734,t:1527876936131};\\\", \\\"{x:342,y:732,t:1527876936147};\\\", \\\"{x:352,y:732,t:1527876936164};\\\", \\\"{x:364,y:736,t:1527876936181};\\\", \\\"{x:376,y:739,t:1527876936198};\\\", \\\"{x:386,y:742,t:1527876936215};\\\", \\\"{x:406,y:748,t:1527876936231};\\\", \\\"{x:425,y:757,t:1527876936248};\\\", \\\"{x:438,y:759,t:1527876936265};\\\", \\\"{x:451,y:762,t:1527876936281};\\\", \\\"{x:463,y:762,t:1527876936297};\\\", \\\"{x:478,y:762,t:1527876936314};\\\", \\\"{x:491,y:760,t:1527876936331};\\\", \\\"{x:500,y:757,t:1527876936348};\\\", \\\"{x:502,y:756,t:1527876936364};\\\", \\\"{x:505,y:754,t:1527876936382};\\\", \\\"{x:506,y:753,t:1527876936399};\\\", \\\"{x:506,y:752,t:1527876936414};\\\", \\\"{x:507,y:752,t:1527876936431};\\\", \\\"{x:508,y:752,t:1527876936534};\\\", \\\"{x:508,y:751,t:1527876936621};\\\", \\\"{x:509,y:749,t:1527876936630};\\\", \\\"{x:511,y:749,t:1527876936646};\\\" ] }, { \\\"rt\\\": 26678, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 17, \\\"time_elapsed\\\": 554489, \\\"internal_node_id\\\": \\\"0.0-6.0-7.0\\\", \\\"subject\\\": \\\"EER58\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"meets\\\", \\\"q\\\": 13, \\\"clicks\\\": 2, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"E\\\", \\\"F\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-C -C -Z -Z -Z -Z -Z -Z -02 PM-02 PM-02 PM-02 PM-F -E \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:512,y:749,t:1527876938832};\\\", \\\"{x:518,y:745,t:1527876938848};\\\", \\\"{x:526,y:742,t:1527876938865};\\\", \\\"{x:533,y:739,t:1527876938882};\\\", \\\"{x:540,y:739,t:1527876938899};\\\", \\\"{x:550,y:737,t:1527876938915};\\\", \\\"{x:562,y:734,t:1527876938932};\\\", \\\"{x:577,y:732,t:1527876938949};\\\", \\\"{x:593,y:730,t:1527876938965};\\\", \\\"{x:615,y:726,t:1527876938982};\\\", \\\"{x:654,y:722,t:1527876938998};\\\", \\\"{x:692,y:715,t:1527876939015};\\\", \\\"{x:729,y:711,t:1527876939032};\\\", \\\"{x:764,y:709,t:1527876939049};\\\", \\\"{x:808,y:704,t:1527876939065};\\\", \\\"{x:849,y:700,t:1527876939082};\\\", \\\"{x:880,y:698,t:1527876939099};\\\", \\\"{x:905,y:694,t:1527876939115};\\\", \\\"{x:924,y:691,t:1527876939132};\\\", \\\"{x:938,y:690,t:1527876939149};\\\", \\\"{x:944,y:689,t:1527876939165};\\\", \\\"{x:945,y:689,t:1527876939182};\\\", \\\"{x:946,y:690,t:1527876939352};\\\", \\\"{x:949,y:697,t:1527876939365};\\\", \\\"{x:959,y:711,t:1527876939382};\\\", \\\"{x:962,y:717,t:1527876939399};\\\", \\\"{x:964,y:717,t:1527876940744};\\\", \\\"{x:969,y:715,t:1527876940751};\\\", \\\"{x:985,y:709,t:1527876940767};\\\", \\\"{x:1017,y:703,t:1527876940784};\\\", \\\"{x:1067,y:689,t:1527876940801};\\\", \\\"{x:1134,y:677,t:1527876940818};\\\", \\\"{x:1213,y:664,t:1527876940834};\\\", \\\"{x:1288,y:653,t:1527876940851};\\\", \\\"{x:1361,y:639,t:1527876940868};\\\", \\\"{x:1411,y:634,t:1527876940883};\\\", \\\"{x:1439,y:629,t:1527876940901};\\\", \\\"{x:1452,y:627,t:1527876940920};\\\", \\\"{x:1457,y:627,t:1527876940934};\\\", \\\"{x:1454,y:627,t:1527876941079};\\\", \\\"{x:1452,y:627,t:1527876941087};\\\", \\\"{x:1448,y:627,t:1527876941100};\\\", \\\"{x:1438,y:627,t:1527876941117};\\\", \\\"{x:1428,y:627,t:1527876941133};\\\", \\\"{x:1415,y:627,t:1527876941150};\\\", \\\"{x:1394,y:620,t:1527876941167};\\\", \\\"{x:1375,y:609,t:1527876941184};\\\", \\\"{x:1347,y:593,t:1527876941200};\\\", \\\"{x:1310,y:575,t:1527876941218};\\\", \\\"{x:1272,y:561,t:1527876941235};\\\", \\\"{x:1250,y:554,t:1527876941251};\\\", \\\"{x:1238,y:551,t:1527876941268};\\\", \\\"{x:1236,y:551,t:1527876941285};\\\", \\\"{x:1241,y:551,t:1527876941920};\\\", \\\"{x:1253,y:553,t:1527876941935};\\\", \\\"{x:1324,y:576,t:1527876941952};\\\", \\\"{x:1410,y:613,t:1527876941968};\\\", \\\"{x:1479,y:644,t:1527876941985};\\\", \\\"{x:1551,y:676,t:1527876942001};\\\", \\\"{x:1614,y:713,t:1527876942018};\\\", \\\"{x:1663,y:745,t:1527876942035};\\\", \\\"{x:1693,y:769,t:1527876942052};\\\", \\\"{x:1710,y:781,t:1527876942068};\\\", \\\"{x:1717,y:787,t:1527876942085};\\\", \\\"{x:1719,y:790,t:1527876942102};\\\", \\\"{x:1719,y:791,t:1527876942168};\\\", \\\"{x:1718,y:793,t:1527876942199};\\\", \\\"{x:1718,y:794,t:1527876942208};\\\", \\\"{x:1718,y:795,t:1527876942219};\\\", \\\"{x:1716,y:798,t:1527876942235};\\\", \\\"{x:1716,y:801,t:1527876942251};\\\", \\\"{x:1715,y:803,t:1527876942268};\\\", \\\"{x:1715,y:804,t:1527876942286};\\\", \\\"{x:1715,y:805,t:1527876942311};\\\", \\\"{x:1715,y:806,t:1527876942319};\\\", \\\"{x:1714,y:806,t:1527876942334};\\\", \\\"{x:1714,y:808,t:1527876942351};\\\", \\\"{x:1714,y:809,t:1527876942369};\\\", \\\"{x:1714,y:813,t:1527876942384};\\\", \\\"{x:1714,y:814,t:1527876942401};\\\", \\\"{x:1714,y:818,t:1527876942418};\\\", \\\"{x:1716,y:822,t:1527876942434};\\\", \\\"{x:1717,y:825,t:1527876942452};\\\", \\\"{x:1721,y:832,t:1527876942469};\\\", \\\"{x:1724,y:837,t:1527876942485};\\\", \\\"{x:1729,y:844,t:1527876942501};\\\", \\\"{x:1733,y:849,t:1527876942518};\\\", \\\"{x:1742,y:856,t:1527876942535};\\\", \\\"{x:1743,y:857,t:1527876942551};\\\", \\\"{x:1744,y:858,t:1527876942569};\\\", \\\"{x:1743,y:859,t:1527876942656};\\\", \\\"{x:1741,y:859,t:1527876942669};\\\", \\\"{x:1735,y:859,t:1527876942686};\\\", \\\"{x:1730,y:859,t:1527876942702};\\\", \\\"{x:1720,y:859,t:1527876942719};\\\", \\\"{x:1698,y:859,t:1527876942735};\\\", \\\"{x:1682,y:859,t:1527876942751};\\\", \\\"{x:1660,y:861,t:1527876942768};\\\", \\\"{x:1641,y:863,t:1527876942786};\\\", \\\"{x:1621,y:867,t:1527876942802};\\\", \\\"{x:1605,y:872,t:1527876942818};\\\", \\\"{x:1598,y:873,t:1527876942836};\\\", \\\"{x:1589,y:876,t:1527876942852};\\\", \\\"{x:1586,y:878,t:1527876942869};\\\", \\\"{x:1585,y:879,t:1527876942887};\\\", \\\"{x:1584,y:880,t:1527876942903};\\\", \\\"{x:1583,y:881,t:1527876942919};\\\", \\\"{x:1581,y:882,t:1527876942936};\\\", \\\"{x:1580,y:882,t:1527876942992};\\\", \\\"{x:1580,y:881,t:1527876943003};\\\", \\\"{x:1580,y:879,t:1527876943024};\\\", \\\"{x:1585,y:870,t:1527876943035};\\\", \\\"{x:1600,y:844,t:1527876943052};\\\", \\\"{x:1613,y:822,t:1527876943069};\\\", \\\"{x:1620,y:804,t:1527876943086};\\\", \\\"{x:1624,y:795,t:1527876943103};\\\", \\\"{x:1624,y:786,t:1527876943118};\\\", \\\"{x:1624,y:778,t:1527876943137};\\\", \\\"{x:1624,y:774,t:1527876943153};\\\", \\\"{x:1624,y:772,t:1527876943169};\\\", \\\"{x:1623,y:768,t:1527876943186};\\\", \\\"{x:1623,y:763,t:1527876943203};\\\", \\\"{x:1623,y:755,t:1527876943219};\\\", \\\"{x:1623,y:748,t:1527876943235};\\\", \\\"{x:1623,y:743,t:1527876943253};\\\", \\\"{x:1622,y:735,t:1527876943268};\\\", \\\"{x:1622,y:730,t:1527876943286};\\\", \\\"{x:1621,y:720,t:1527876943303};\\\", \\\"{x:1618,y:709,t:1527876943320};\\\", \\\"{x:1617,y:703,t:1527876943336};\\\", \\\"{x:1615,y:700,t:1527876943353};\\\", \\\"{x:1614,y:698,t:1527876943370};\\\", \\\"{x:1612,y:697,t:1527876944264};\\\", \\\"{x:1609,y:697,t:1527876944272};\\\", \\\"{x:1607,y:700,t:1527876944288};\\\", \\\"{x:1603,y:704,t:1527876944304};\\\", \\\"{x:1603,y:706,t:1527876944320};\\\", \\\"{x:1602,y:706,t:1527876944337};\\\", \\\"{x:1601,y:710,t:1527876944354};\\\", \\\"{x:1597,y:714,t:1527876944369};\\\", \\\"{x:1593,y:719,t:1527876944387};\\\", \\\"{x:1589,y:724,t:1527876944403};\\\", \\\"{x:1586,y:729,t:1527876944420};\\\", \\\"{x:1585,y:736,t:1527876944437};\\\", \\\"{x:1584,y:740,t:1527876944454};\\\", \\\"{x:1583,y:745,t:1527876944470};\\\", \\\"{x:1581,y:751,t:1527876944487};\\\", \\\"{x:1579,y:758,t:1527876944503};\\\", \\\"{x:1576,y:764,t:1527876944521};\\\", \\\"{x:1576,y:770,t:1527876944537};\\\", \\\"{x:1576,y:777,t:1527876944554};\\\", \\\"{x:1575,y:785,t:1527876944570};\\\", \\\"{x:1575,y:791,t:1527876944587};\\\", \\\"{x:1572,y:795,t:1527876944604};\\\", \\\"{x:1571,y:802,t:1527876944620};\\\", \\\"{x:1568,y:807,t:1527876944638};\\\", \\\"{x:1567,y:815,t:1527876944654};\\\", \\\"{x:1565,y:820,t:1527876944671};\\\", \\\"{x:1564,y:828,t:1527876944687};\\\", \\\"{x:1560,y:836,t:1527876944703};\\\", \\\"{x:1556,y:840,t:1527876944720};\\\", \\\"{x:1555,y:847,t:1527876944737};\\\", \\\"{x:1550,y:856,t:1527876944754};\\\", \\\"{x:1547,y:864,t:1527876944771};\\\", \\\"{x:1541,y:874,t:1527876944787};\\\", \\\"{x:1537,y:881,t:1527876944804};\\\", \\\"{x:1534,y:884,t:1527876944821};\\\", \\\"{x:1530,y:889,t:1527876944837};\\\", \\\"{x:1528,y:893,t:1527876944854};\\\", \\\"{x:1522,y:901,t:1527876944871};\\\", \\\"{x:1516,y:909,t:1527876944886};\\\", \\\"{x:1508,y:920,t:1527876944903};\\\", \\\"{x:1502,y:926,t:1527876944921};\\\", \\\"{x:1498,y:931,t:1527876944937};\\\", \\\"{x:1495,y:934,t:1527876944954};\\\", \\\"{x:1494,y:936,t:1527876944970};\\\", \\\"{x:1493,y:937,t:1527876944987};\\\", \\\"{x:1492,y:939,t:1527876945004};\\\", \\\"{x:1491,y:941,t:1527876945021};\\\", \\\"{x:1489,y:943,t:1527876945037};\\\", \\\"{x:1489,y:944,t:1527876945054};\\\", \\\"{x:1488,y:945,t:1527876945071};\\\", \\\"{x:1486,y:947,t:1527876945088};\\\", \\\"{x:1485,y:948,t:1527876945208};\\\", \\\"{x:1485,y:949,t:1527876945221};\\\", \\\"{x:1484,y:950,t:1527876945240};\\\", \\\"{x:1484,y:951,t:1527876945254};\\\", \\\"{x:1484,y:954,t:1527876945271};\\\", \\\"{x:1483,y:957,t:1527876945288};\\\", \\\"{x:1483,y:959,t:1527876945304};\\\", \\\"{x:1483,y:960,t:1527876945321};\\\", \\\"{x:1483,y:962,t:1527876945338};\\\", \\\"{x:1483,y:963,t:1527876945359};\\\", \\\"{x:1482,y:963,t:1527876945371};\\\", \\\"{x:1482,y:965,t:1527876945400};\\\", \\\"{x:1481,y:966,t:1527876945456};\\\", \\\"{x:1481,y:965,t:1527876945968};\\\", \\\"{x:1481,y:964,t:1527876945975};\\\", \\\"{x:1481,y:961,t:1527876945992};\\\", \\\"{x:1481,y:960,t:1527876946005};\\\", \\\"{x:1487,y:946,t:1527876946022};\\\", \\\"{x:1501,y:925,t:1527876946038};\\\", \\\"{x:1523,y:893,t:1527876946055};\\\", \\\"{x:1555,y:848,t:1527876946071};\\\", \\\"{x:1571,y:823,t:1527876946087};\\\", \\\"{x:1582,y:808,t:1527876946105};\\\", \\\"{x:1590,y:796,t:1527876946122};\\\", \\\"{x:1595,y:783,t:1527876946138};\\\", \\\"{x:1601,y:767,t:1527876946155};\\\", \\\"{x:1604,y:753,t:1527876946172};\\\", \\\"{x:1607,y:742,t:1527876946188};\\\", \\\"{x:1609,y:737,t:1527876946205};\\\", \\\"{x:1609,y:731,t:1527876946222};\\\", \\\"{x:1609,y:725,t:1527876946238};\\\", \\\"{x:1609,y:722,t:1527876946255};\\\", \\\"{x:1609,y:718,t:1527876946272};\\\", \\\"{x:1609,y:713,t:1527876946288};\\\", \\\"{x:1609,y:709,t:1527876946304};\\\", \\\"{x:1609,y:704,t:1527876946322};\\\", \\\"{x:1609,y:697,t:1527876946338};\\\", \\\"{x:1609,y:692,t:1527876946355};\\\", \\\"{x:1610,y:687,t:1527876946372};\\\", \\\"{x:1611,y:682,t:1527876946387};\\\", \\\"{x:1615,y:679,t:1527876946404};\\\", \\\"{x:1615,y:677,t:1527876946423};\\\", \\\"{x:1616,y:676,t:1527876946439};\\\", \\\"{x:1616,y:677,t:1527876946608};\\\", \\\"{x:1617,y:679,t:1527876946622};\\\", \\\"{x:1618,y:682,t:1527876946639};\\\", \\\"{x:1618,y:685,t:1527876946655};\\\", \\\"{x:1618,y:687,t:1527876946672};\\\", \\\"{x:1618,y:689,t:1527876946936};\\\", \\\"{x:1618,y:691,t:1527876946944};\\\", \\\"{x:1618,y:692,t:1527876946959};\\\", \\\"{x:1618,y:693,t:1527876946972};\\\", \\\"{x:1618,y:694,t:1527876946988};\\\", \\\"{x:1618,y:695,t:1527876947005};\\\", \\\"{x:1618,y:697,t:1527876952003};\\\", \\\"{x:1622,y:693,t:1527876952013};\\\", \\\"{x:1630,y:683,t:1527876952029};\\\", \\\"{x:1635,y:675,t:1527876952046};\\\", \\\"{x:1639,y:670,t:1527876952062};\\\", \\\"{x:1642,y:666,t:1527876952079};\\\", \\\"{x:1642,y:665,t:1527876952096};\\\", \\\"{x:1642,y:666,t:1527876952410};\\\", \\\"{x:1638,y:669,t:1527876952418};\\\", \\\"{x:1637,y:671,t:1527876952429};\\\", \\\"{x:1628,y:679,t:1527876952446};\\\", \\\"{x:1624,y:684,t:1527876952463};\\\", \\\"{x:1621,y:686,t:1527876952479};\\\", \\\"{x:1619,y:689,t:1527876952496};\\\", \\\"{x:1616,y:691,t:1527876952513};\\\", \\\"{x:1612,y:695,t:1527876952529};\\\", \\\"{x:1602,y:705,t:1527876952547};\\\", \\\"{x:1596,y:712,t:1527876952563};\\\", \\\"{x:1589,y:717,t:1527876952579};\\\", \\\"{x:1586,y:720,t:1527876952596};\\\", \\\"{x:1584,y:721,t:1527876952613};\\\", \\\"{x:1584,y:722,t:1527876952630};\\\", \\\"{x:1583,y:724,t:1527876952646};\\\", \\\"{x:1581,y:727,t:1527876952663};\\\", \\\"{x:1580,y:729,t:1527876952679};\\\", \\\"{x:1578,y:734,t:1527876952696};\\\", \\\"{x:1577,y:741,t:1527876952713};\\\", \\\"{x:1577,y:767,t:1527876952730};\\\", \\\"{x:1574,y:791,t:1527876952746};\\\", \\\"{x:1568,y:817,t:1527876952763};\\\", \\\"{x:1561,y:837,t:1527876952780};\\\", \\\"{x:1557,y:852,t:1527876952796};\\\", \\\"{x:1555,y:865,t:1527876952813};\\\", \\\"{x:1552,y:878,t:1527876952829};\\\", \\\"{x:1551,y:889,t:1527876952847};\\\", \\\"{x:1550,y:898,t:1527876952863};\\\", \\\"{x:1546,y:908,t:1527876952880};\\\", \\\"{x:1543,y:913,t:1527876952896};\\\", \\\"{x:1541,y:916,t:1527876952913};\\\", \\\"{x:1539,y:918,t:1527876952931};\\\", \\\"{x:1538,y:920,t:1527876952946};\\\", \\\"{x:1535,y:923,t:1527876952963};\\\", \\\"{x:1531,y:926,t:1527876952980};\\\", \\\"{x:1527,y:931,t:1527876952996};\\\", \\\"{x:1522,y:935,t:1527876953013};\\\", \\\"{x:1517,y:937,t:1527876953030};\\\", \\\"{x:1514,y:938,t:1527876953046};\\\", \\\"{x:1510,y:941,t:1527876953063};\\\", \\\"{x:1507,y:943,t:1527876953080};\\\", \\\"{x:1503,y:946,t:1527876953097};\\\", \\\"{x:1500,y:948,t:1527876953113};\\\", \\\"{x:1494,y:952,t:1527876953130};\\\", \\\"{x:1492,y:954,t:1527876953146};\\\", \\\"{x:1491,y:954,t:1527876953163};\\\", \\\"{x:1490,y:955,t:1527876953180};\\\", \\\"{x:1489,y:955,t:1527876953202};\\\", \\\"{x:1488,y:955,t:1527876953218};\\\", \\\"{x:1488,y:956,t:1527876953229};\\\", \\\"{x:1486,y:957,t:1527876953247};\\\", \\\"{x:1485,y:958,t:1527876953263};\\\", \\\"{x:1485,y:960,t:1527876953280};\\\", \\\"{x:1485,y:961,t:1527876953297};\\\", \\\"{x:1484,y:962,t:1527876953313};\\\", \\\"{x:1484,y:963,t:1527876953362};\\\", \\\"{x:1484,y:964,t:1527876953380};\\\", \\\"{x:1484,y:965,t:1527876953397};\\\", \\\"{x:1484,y:967,t:1527876953418};\\\", \\\"{x:1484,y:968,t:1527876953434};\\\", \\\"{x:1484,y:970,t:1527876953447};\\\", \\\"{x:1483,y:971,t:1527876953463};\\\", \\\"{x:1483,y:972,t:1527876953555};\\\", \\\"{x:1482,y:972,t:1527876953859};\\\", \\\"{x:1481,y:972,t:1527876953906};\\\", \\\"{x:1481,y:971,t:1527876953922};\\\", \\\"{x:1481,y:970,t:1527876953946};\\\", \\\"{x:1481,y:968,t:1527876953965};\\\", \\\"{x:1481,y:967,t:1527876953987};\\\", \\\"{x:1481,y:965,t:1527876954010};\\\", \\\"{x:1481,y:964,t:1527876954018};\\\", \\\"{x:1480,y:961,t:1527876954031};\\\", \\\"{x:1480,y:960,t:1527876954047};\\\", \\\"{x:1480,y:956,t:1527876954065};\\\", \\\"{x:1480,y:953,t:1527876954081};\\\", \\\"{x:1480,y:950,t:1527876954097};\\\", \\\"{x:1480,y:947,t:1527876954114};\\\", \\\"{x:1480,y:944,t:1527876954130};\\\", \\\"{x:1480,y:943,t:1527876954162};\\\", \\\"{x:1481,y:943,t:1527876954451};\\\", \\\"{x:1481,y:944,t:1527876954464};\\\", \\\"{x:1481,y:947,t:1527876954481};\\\", \\\"{x:1481,y:950,t:1527876954498};\\\", \\\"{x:1481,y:951,t:1527876954514};\\\", \\\"{x:1482,y:951,t:1527876954554};\\\", \\\"{x:1482,y:952,t:1527876954579};\\\", \\\"{x:1482,y:953,t:1527876954586};\\\", \\\"{x:1483,y:953,t:1527876954610};\\\", \\\"{x:1483,y:954,t:1527876954634};\\\", \\\"{x:1483,y:955,t:1527876954650};\\\", \\\"{x:1483,y:956,t:1527876954666};\\\", \\\"{x:1483,y:958,t:1527876954682};\\\", \\\"{x:1483,y:960,t:1527876954698};\\\", \\\"{x:1483,y:962,t:1527876954715};\\\", \\\"{x:1483,y:963,t:1527876954731};\\\", \\\"{x:1483,y:964,t:1527876954802};\\\", \\\"{x:1483,y:965,t:1527876955595};\\\", \\\"{x:1483,y:966,t:1527876955602};\\\", \\\"{x:1483,y:968,t:1527876955615};\\\", \\\"{x:1483,y:971,t:1527876955633};\\\", \\\"{x:1483,y:972,t:1527876955648};\\\", \\\"{x:1483,y:974,t:1527876955665};\\\", \\\"{x:1483,y:975,t:1527876955681};\\\", \\\"{x:1483,y:976,t:1527876955699};\\\", \\\"{x:1484,y:978,t:1527876955715};\\\", \\\"{x:1485,y:979,t:1527876955738};\\\", \\\"{x:1485,y:980,t:1527876955753};\\\", \\\"{x:1486,y:981,t:1527876955769};\\\", \\\"{x:1486,y:982,t:1527876955802};\\\", \\\"{x:1487,y:982,t:1527876955815};\\\", \\\"{x:1487,y:983,t:1527876955832};\\\", \\\"{x:1487,y:982,t:1527876956362};\\\", \\\"{x:1487,y:981,t:1527876956378};\\\", \\\"{x:1487,y:980,t:1527876956386};\\\", \\\"{x:1487,y:979,t:1527876956418};\\\", \\\"{x:1486,y:977,t:1527876956450};\\\", \\\"{x:1485,y:976,t:1527876956474};\\\", \\\"{x:1485,y:974,t:1527876956505};\\\", \\\"{x:1485,y:972,t:1527876956521};\\\", \\\"{x:1485,y:971,t:1527876956546};\\\", \\\"{x:1485,y:970,t:1527876956562};\\\", \\\"{x:1485,y:969,t:1527876956569};\\\", \\\"{x:1485,y:968,t:1527876956586};\\\", \\\"{x:1485,y:967,t:1527876956599};\\\", \\\"{x:1484,y:965,t:1527876956616};\\\", \\\"{x:1484,y:963,t:1527876956633};\\\", \\\"{x:1483,y:962,t:1527876956649};\\\", \\\"{x:1483,y:961,t:1527876956665};\\\", \\\"{x:1483,y:960,t:1527876956682};\\\", \\\"{x:1482,y:958,t:1527876956699};\\\", \\\"{x:1481,y:956,t:1527876956716};\\\", \\\"{x:1479,y:952,t:1527876956733};\\\", \\\"{x:1478,y:950,t:1527876956749};\\\", \\\"{x:1477,y:950,t:1527876956766};\\\", \\\"{x:1477,y:949,t:1527876956783};\\\", \\\"{x:1476,y:948,t:1527876956799};\\\", \\\"{x:1476,y:947,t:1527876956818};\\\", \\\"{x:1476,y:948,t:1527876957218};\\\", \\\"{x:1476,y:949,t:1527876957233};\\\", \\\"{x:1476,y:951,t:1527876957249};\\\", \\\"{x:1476,y:952,t:1527876957785};\\\", \\\"{x:1476,y:953,t:1527876957809};\\\", \\\"{x:1476,y:954,t:1527876957817};\\\", \\\"{x:1476,y:955,t:1527876957833};\\\", \\\"{x:1476,y:957,t:1527876957849};\\\", \\\"{x:1476,y:958,t:1527876957867};\\\", \\\"{x:1476,y:960,t:1527876957883};\\\", \\\"{x:1476,y:961,t:1527876957899};\\\", \\\"{x:1478,y:965,t:1527876957917};\\\", \\\"{x:1480,y:968,t:1527876957933};\\\", \\\"{x:1481,y:969,t:1527876957950};\\\", \\\"{x:1481,y:971,t:1527876957967};\\\", \\\"{x:1482,y:972,t:1527876957984};\\\", \\\"{x:1485,y:971,t:1527876958010};\\\", \\\"{x:1490,y:966,t:1527876958018};\\\", \\\"{x:1517,y:941,t:1527876958034};\\\", \\\"{x:1553,y:902,t:1527876958050};\\\", \\\"{x:1591,y:849,t:1527876958067};\\\", \\\"{x:1618,y:793,t:1527876958084};\\\", \\\"{x:1634,y:755,t:1527876958100};\\\", \\\"{x:1640,y:732,t:1527876958117};\\\", \\\"{x:1643,y:717,t:1527876958134};\\\", \\\"{x:1644,y:709,t:1527876958150};\\\", \\\"{x:1644,y:708,t:1527876958167};\\\", \\\"{x:1644,y:706,t:1527876958185};\\\", \\\"{x:1644,y:704,t:1527876958201};\\\", \\\"{x:1644,y:702,t:1527876958218};\\\", \\\"{x:1644,y:697,t:1527876958234};\\\", \\\"{x:1644,y:696,t:1527876958251};\\\", \\\"{x:1644,y:695,t:1527876958268};\\\", \\\"{x:1642,y:695,t:1527876958386};\\\", \\\"{x:1639,y:695,t:1527876958402};\\\", \\\"{x:1634,y:698,t:1527876958417};\\\", \\\"{x:1627,y:705,t:1527876958434};\\\", \\\"{x:1620,y:712,t:1527876958450};\\\", \\\"{x:1614,y:722,t:1527876958468};\\\", \\\"{x:1605,y:734,t:1527876958484};\\\", \\\"{x:1598,y:746,t:1527876958501};\\\", \\\"{x:1592,y:758,t:1527876958517};\\\", \\\"{x:1583,y:775,t:1527876958534};\\\", \\\"{x:1573,y:791,t:1527876958551};\\\", \\\"{x:1565,y:808,t:1527876958568};\\\", \\\"{x:1558,y:827,t:1527876958584};\\\", \\\"{x:1549,y:846,t:1527876958602};\\\", \\\"{x:1541,y:858,t:1527876958617};\\\", \\\"{x:1531,y:877,t:1527876958634};\\\", \\\"{x:1527,y:888,t:1527876958651};\\\", \\\"{x:1523,y:897,t:1527876958667};\\\", \\\"{x:1518,y:907,t:1527876958684};\\\", \\\"{x:1516,y:912,t:1527876958701};\\\", \\\"{x:1514,y:914,t:1527876958718};\\\", \\\"{x:1513,y:917,t:1527876958734};\\\", \\\"{x:1509,y:923,t:1527876958751};\\\", \\\"{x:1503,y:934,t:1527876958768};\\\", \\\"{x:1500,y:940,t:1527876958784};\\\", \\\"{x:1494,y:948,t:1527876958801};\\\", \\\"{x:1489,y:955,t:1527876958818};\\\", \\\"{x:1486,y:959,t:1527876958834};\\\", \\\"{x:1485,y:962,t:1527876958851};\\\", \\\"{x:1484,y:965,t:1527876958868};\\\", \\\"{x:1483,y:969,t:1527876958885};\\\", \\\"{x:1480,y:973,t:1527876958901};\\\", \\\"{x:1479,y:977,t:1527876958918};\\\", \\\"{x:1479,y:979,t:1527876958934};\\\", \\\"{x:1479,y:978,t:1527876959099};\\\", \\\"{x:1479,y:976,t:1527876959106};\\\", \\\"{x:1479,y:973,t:1527876959119};\\\", \\\"{x:1479,y:970,t:1527876959134};\\\", \\\"{x:1479,y:968,t:1527876959152};\\\", \\\"{x:1479,y:967,t:1527876959168};\\\", \\\"{x:1479,y:966,t:1527876959185};\\\", \\\"{x:1479,y:965,t:1527876959443};\\\", \\\"{x:1479,y:964,t:1527876959459};\\\", \\\"{x:1479,y:963,t:1527876959490};\\\", \\\"{x:1479,y:962,t:1527876959531};\\\", \\\"{x:1479,y:961,t:1527876959554};\\\", \\\"{x:1479,y:959,t:1527876959570};\\\", \\\"{x:1479,y:956,t:1527876959586};\\\", \\\"{x:1476,y:950,t:1527876959601};\\\", \\\"{x:1469,y:933,t:1527876959618};\\\", \\\"{x:1466,y:923,t:1527876959635};\\\", \\\"{x:1463,y:911,t:1527876959652};\\\", \\\"{x:1456,y:897,t:1527876959669};\\\", \\\"{x:1453,y:886,t:1527876959686};\\\", \\\"{x:1448,y:875,t:1527876959703};\\\", \\\"{x:1443,y:865,t:1527876959718};\\\", \\\"{x:1440,y:858,t:1527876959735};\\\", \\\"{x:1435,y:846,t:1527876959753};\\\", \\\"{x:1430,y:834,t:1527876959769};\\\", \\\"{x:1425,y:822,t:1527876959786};\\\", \\\"{x:1418,y:809,t:1527876959803};\\\", \\\"{x:1414,y:804,t:1527876959819};\\\", \\\"{x:1408,y:795,t:1527876959835};\\\", \\\"{x:1402,y:787,t:1527876959852};\\\", \\\"{x:1394,y:775,t:1527876959869};\\\", \\\"{x:1385,y:760,t:1527876959885};\\\", \\\"{x:1376,y:749,t:1527876959903};\\\", \\\"{x:1369,y:739,t:1527876959919};\\\", \\\"{x:1365,y:733,t:1527876959935};\\\", \\\"{x:1362,y:729,t:1527876959952};\\\", \\\"{x:1358,y:725,t:1527876959969};\\\", \\\"{x:1353,y:718,t:1527876959986};\\\", \\\"{x:1346,y:702,t:1527876960003};\\\", \\\"{x:1342,y:696,t:1527876960018};\\\", \\\"{x:1339,y:691,t:1527876960036};\\\", \\\"{x:1337,y:688,t:1527876960052};\\\", \\\"{x:1335,y:684,t:1527876960068};\\\", \\\"{x:1334,y:681,t:1527876960085};\\\", \\\"{x:1331,y:674,t:1527876960101};\\\", \\\"{x:1328,y:666,t:1527876960119};\\\", \\\"{x:1323,y:656,t:1527876960135};\\\", \\\"{x:1320,y:649,t:1527876960152};\\\", \\\"{x:1316,y:640,t:1527876960169};\\\", \\\"{x:1311,y:629,t:1527876960185};\\\", \\\"{x:1302,y:608,t:1527876960202};\\\", \\\"{x:1295,y:596,t:1527876960219};\\\", \\\"{x:1288,y:585,t:1527876960235};\\\", \\\"{x:1282,y:573,t:1527876960252};\\\", \\\"{x:1277,y:566,t:1527876960269};\\\", \\\"{x:1273,y:557,t:1527876960286};\\\", \\\"{x:1272,y:551,t:1527876960302};\\\", \\\"{x:1269,y:547,t:1527876960319};\\\", \\\"{x:1268,y:545,t:1527876960335};\\\", \\\"{x:1267,y:545,t:1527876960352};\\\", \\\"{x:1248,y:545,t:1527876960571};\\\", \\\"{x:1215,y:545,t:1527876960586};\\\", \\\"{x:1062,y:545,t:1527876960602};\\\", \\\"{x:947,y:539,t:1527876960621};\\\", \\\"{x:818,y:524,t:1527876960636};\\\", \\\"{x:716,y:498,t:1527876960652};\\\", \\\"{x:638,y:474,t:1527876960670};\\\", \\\"{x:582,y:449,t:1527876960686};\\\", \\\"{x:558,y:434,t:1527876960703};\\\", \\\"{x:546,y:424,t:1527876960718};\\\", \\\"{x:543,y:422,t:1527876960736};\\\", \\\"{x:541,y:418,t:1527876960753};\\\", \\\"{x:540,y:418,t:1527876960769};\\\", \\\"{x:537,y:418,t:1527876960785};\\\", \\\"{x:532,y:418,t:1527876960803};\\\", \\\"{x:528,y:419,t:1527876960819};\\\", \\\"{x:525,y:420,t:1527876960836};\\\", \\\"{x:522,y:420,t:1527876960853};\\\", \\\"{x:517,y:424,t:1527876960869};\\\", \\\"{x:513,y:429,t:1527876960885};\\\", \\\"{x:513,y:437,t:1527876960903};\\\", \\\"{x:515,y:446,t:1527876960919};\\\", \\\"{x:523,y:459,t:1527876960935};\\\", \\\"{x:535,y:472,t:1527876960953};\\\", \\\"{x:551,y:486,t:1527876960969};\\\", \\\"{x:558,y:493,t:1527876960986};\\\", \\\"{x:563,y:496,t:1527876961003};\\\", \\\"{x:569,y:501,t:1527876961020};\\\", \\\"{x:578,y:505,t:1527876961035};\\\", \\\"{x:593,y:511,t:1527876961052};\\\", \\\"{x:602,y:513,t:1527876961070};\\\", \\\"{x:608,y:514,t:1527876961088};\\\", \\\"{x:610,y:514,t:1527876961102};\\\", \\\"{x:611,y:514,t:1527876961145};\\\", \\\"{x:613,y:514,t:1527876961153};\\\", \\\"{x:615,y:512,t:1527876961169};\\\", \\\"{x:616,y:509,t:1527876961186};\\\", \\\"{x:617,y:507,t:1527876961203};\\\", \\\"{x:618,y:507,t:1527876961220};\\\", \\\"{x:620,y:506,t:1527876961473};\\\", \\\"{x:626,y:506,t:1527876961487};\\\", \\\"{x:651,y:501,t:1527876961503};\\\", \\\"{x:689,y:493,t:1527876961520};\\\", \\\"{x:741,y:482,t:1527876961538};\\\", \\\"{x:775,y:473,t:1527876961552};\\\", \\\"{x:796,y:470,t:1527876961569};\\\", \\\"{x:798,y:469,t:1527876961587};\\\", \\\"{x:799,y:469,t:1527876961722};\\\", \\\"{x:803,y:471,t:1527876961737};\\\", \\\"{x:808,y:479,t:1527876961753};\\\", \\\"{x:824,y:496,t:1527876961772};\\\", \\\"{x:836,y:507,t:1527876961787};\\\", \\\"{x:850,y:517,t:1527876961804};\\\", \\\"{x:859,y:522,t:1527876961820};\\\", \\\"{x:861,y:523,t:1527876961836};\\\", \\\"{x:862,y:523,t:1527876961881};\\\", \\\"{x:864,y:523,t:1527876961889};\\\", \\\"{x:865,y:521,t:1527876961904};\\\", \\\"{x:866,y:518,t:1527876961921};\\\", \\\"{x:868,y:515,t:1527876961938};\\\", \\\"{x:868,y:509,t:1527876961954};\\\", \\\"{x:868,y:506,t:1527876961970};\\\", \\\"{x:868,y:505,t:1527876961986};\\\", \\\"{x:868,y:502,t:1527876962003};\\\", \\\"{x:865,y:501,t:1527876962021};\\\", \\\"{x:864,y:501,t:1527876962037};\\\", \\\"{x:862,y:501,t:1527876962054};\\\", \\\"{x:861,y:501,t:1527876962114};\\\", \\\"{x:859,y:501,t:1527876962138};\\\", \\\"{x:857,y:501,t:1527876962153};\\\", \\\"{x:856,y:501,t:1527876962170};\\\", \\\"{x:855,y:501,t:1527876962202};\\\", \\\"{x:854,y:501,t:1527876962210};\\\", \\\"{x:853,y:502,t:1527876962221};\\\", \\\"{x:852,y:502,t:1527876962242};\\\", \\\"{x:851,y:502,t:1527876962257};\\\", \\\"{x:850,y:502,t:1527876962270};\\\", \\\"{x:849,y:502,t:1527876962287};\\\", \\\"{x:847,y:503,t:1527876963562};\\\", \\\"{x:843,y:505,t:1527876963573};\\\", \\\"{x:840,y:507,t:1527876963588};\\\", \\\"{x:839,y:507,t:1527876963606};\\\", \\\"{x:838,y:508,t:1527876963659};\\\", \\\"{x:836,y:509,t:1527876963673};\\\", \\\"{x:833,y:510,t:1527876963688};\\\", \\\"{x:828,y:512,t:1527876963706};\\\", \\\"{x:820,y:515,t:1527876963722};\\\", \\\"{x:812,y:522,t:1527876963739};\\\", \\\"{x:796,y:531,t:1527876963755};\\\", \\\"{x:774,y:545,t:1527876963771};\\\", \\\"{x:754,y:560,t:1527876963788};\\\", \\\"{x:733,y:578,t:1527876963805};\\\", \\\"{x:714,y:601,t:1527876963823};\\\", \\\"{x:696,y:623,t:1527876963839};\\\", \\\"{x:681,y:642,t:1527876963855};\\\", \\\"{x:668,y:666,t:1527876963872};\\\", \\\"{x:657,y:684,t:1527876963887};\\\", \\\"{x:650,y:698,t:1527876963905};\\\", \\\"{x:648,y:705,t:1527876963921};\\\", \\\"{x:648,y:709,t:1527876963938};\\\", \\\"{x:648,y:711,t:1527876963955};\\\", \\\"{x:648,y:712,t:1527876963972};\\\", \\\"{x:647,y:714,t:1527876963989};\\\", \\\"{x:647,y:715,t:1527876964010};\\\", \\\"{x:647,y:716,t:1527876964022};\\\", \\\"{x:646,y:718,t:1527876964040};\\\", \\\"{x:644,y:720,t:1527876964055};\\\", \\\"{x:644,y:721,t:1527876964072};\\\", \\\"{x:642,y:723,t:1527876964089};\\\", \\\"{x:637,y:725,t:1527876964105};\\\", \\\"{x:607,y:729,t:1527876964121};\\\", \\\"{x:579,y:732,t:1527876964139};\\\", \\\"{x:551,y:736,t:1527876964155};\\\", \\\"{x:528,y:736,t:1527876964172};\\\", \\\"{x:511,y:736,t:1527876964188};\\\", \\\"{x:505,y:736,t:1527876964205};\\\", \\\"{x:504,y:736,t:1527876964222};\\\", \\\"{x:503,y:736,t:1527876964241};\\\", \\\"{x:502,y:736,t:1527876965466};\\\" ] }, { \\\"rt\\\": 8260, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 18, \\\"time_elapsed\\\": 563956, \\\"internal_node_id\\\": \\\"0.0-6.0-8.0\\\", \\\"subject\\\": \\\"EER58\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"endtime\\\", \\\"q\\\": 14, \\\"clicks\\\": 1, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-06 PM-03 PM\\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:499,y:730,t:1527876965718};\\\", \\\"{x:498,y:729,t:1527876965740};\\\", \\\"{x:498,y:728,t:1527876966570};\\\", \\\"{x:498,y:726,t:1527876966585};\\\", \\\"{x:498,y:724,t:1527876966609};\\\", \\\"{x:498,y:722,t:1527876966624};\\\", \\\"{x:498,y:718,t:1527876966642};\\\", \\\"{x:498,y:716,t:1527876966657};\\\", \\\"{x:501,y:709,t:1527876966674};\\\", \\\"{x:507,y:700,t:1527876966691};\\\", \\\"{x:518,y:688,t:1527876966708};\\\", \\\"{x:528,y:675,t:1527876966724};\\\", \\\"{x:538,y:666,t:1527876966741};\\\", \\\"{x:547,y:657,t:1527876966758};\\\", \\\"{x:559,y:650,t:1527876966774};\\\", \\\"{x:573,y:642,t:1527876966791};\\\", \\\"{x:591,y:635,t:1527876966809};\\\", \\\"{x:609,y:630,t:1527876966826};\\\", \\\"{x:645,y:628,t:1527876966840};\\\", \\\"{x:681,y:629,t:1527876966857};\\\", \\\"{x:741,y:643,t:1527876966874};\\\", \\\"{x:843,y:666,t:1527876966891};\\\", \\\"{x:953,y:695,t:1527876966907};\\\", \\\"{x:1078,y:731,t:1527876966924};\\\", \\\"{x:1211,y:772,t:1527876966941};\\\", \\\"{x:1355,y:816,t:1527876966957};\\\", \\\"{x:1481,y:867,t:1527876966975};\\\", \\\"{x:1599,y:913,t:1527876966991};\\\", \\\"{x:1694,y:947,t:1527876967008};\\\", \\\"{x:1765,y:971,t:1527876967024};\\\", \\\"{x:1833,y:994,t:1527876967042};\\\", \\\"{x:1862,y:1003,t:1527876967058};\\\", \\\"{x:1872,y:1005,t:1527876967074};\\\", \\\"{x:1875,y:1007,t:1527876967091};\\\", \\\"{x:1878,y:1011,t:1527876967162};\\\", \\\"{x:1880,y:1018,t:1527876967174};\\\", \\\"{x:1890,y:1042,t:1527876967192};\\\", \\\"{x:1896,y:1069,t:1527876967208};\\\", \\\"{x:1898,y:1087,t:1527876967225};\\\", \\\"{x:1898,y:1099,t:1527876967242};\\\", \\\"{x:1898,y:1102,t:1527876967257};\\\", \\\"{x:1896,y:1105,t:1527876967275};\\\", \\\"{x:1894,y:1106,t:1527876967292};\\\", \\\"{x:1888,y:1109,t:1527876967309};\\\", \\\"{x:1878,y:1111,t:1527876967325};\\\", \\\"{x:1859,y:1114,t:1527876967342};\\\", \\\"{x:1834,y:1114,t:1527876967358};\\\", \\\"{x:1808,y:1114,t:1527876967375};\\\", \\\"{x:1784,y:1114,t:1527876967392};\\\", \\\"{x:1761,y:1114,t:1527876967409};\\\", \\\"{x:1742,y:1113,t:1527876967425};\\\", \\\"{x:1727,y:1110,t:1527876967442};\\\", \\\"{x:1707,y:1102,t:1527876967458};\\\", \\\"{x:1696,y:1095,t:1527876967475};\\\", \\\"{x:1686,y:1089,t:1527876967492};\\\", \\\"{x:1682,y:1086,t:1527876967508};\\\", \\\"{x:1679,y:1084,t:1527876967524};\\\", \\\"{x:1675,y:1080,t:1527876967541};\\\", \\\"{x:1670,y:1077,t:1527876967558};\\\", \\\"{x:1664,y:1073,t:1527876967575};\\\", \\\"{x:1658,y:1068,t:1527876967592};\\\", \\\"{x:1650,y:1062,t:1527876967609};\\\", \\\"{x:1642,y:1056,t:1527876967626};\\\", \\\"{x:1636,y:1050,t:1527876967642};\\\", \\\"{x:1628,y:1042,t:1527876967659};\\\", \\\"{x:1619,y:1034,t:1527876967675};\\\", \\\"{x:1614,y:1029,t:1527876967691};\\\", \\\"{x:1611,y:1027,t:1527876967709};\\\", \\\"{x:1608,y:1024,t:1527876967726};\\\", \\\"{x:1607,y:1022,t:1527876967741};\\\", \\\"{x:1605,y:1018,t:1527876967758};\\\", \\\"{x:1603,y:1017,t:1527876967775};\\\", \\\"{x:1603,y:1015,t:1527876967791};\\\", \\\"{x:1601,y:1012,t:1527876967809};\\\", \\\"{x:1599,y:1008,t:1527876967826};\\\", \\\"{x:1597,y:1006,t:1527876967842};\\\", \\\"{x:1596,y:1005,t:1527876967859};\\\", \\\"{x:1594,y:1002,t:1527876967875};\\\", \\\"{x:1592,y:998,t:1527876967892};\\\", \\\"{x:1589,y:994,t:1527876967908};\\\", \\\"{x:1584,y:988,t:1527876967926};\\\", \\\"{x:1578,y:981,t:1527876967941};\\\", \\\"{x:1573,y:976,t:1527876967958};\\\", \\\"{x:1570,y:973,t:1527876967976};\\\", \\\"{x:1567,y:970,t:1527876967992};\\\", \\\"{x:1566,y:970,t:1527876968008};\\\", \\\"{x:1564,y:970,t:1527876968099};\\\", \\\"{x:1562,y:969,t:1527876968418};\\\", \\\"{x:1561,y:967,t:1527876968426};\\\", \\\"{x:1559,y:967,t:1527876968442};\\\", \\\"{x:1552,y:967,t:1527876968458};\\\", \\\"{x:1545,y:965,t:1527876968475};\\\", \\\"{x:1536,y:961,t:1527876968492};\\\", \\\"{x:1529,y:959,t:1527876968509};\\\", \\\"{x:1522,y:957,t:1527876968526};\\\", \\\"{x:1517,y:956,t:1527876968543};\\\", \\\"{x:1516,y:956,t:1527876968559};\\\", \\\"{x:1517,y:956,t:1527876968826};\\\", \\\"{x:1521,y:956,t:1527876968842};\\\", \\\"{x:1526,y:956,t:1527876968860};\\\", \\\"{x:1530,y:958,t:1527876968876};\\\", \\\"{x:1531,y:958,t:1527876968893};\\\", \\\"{x:1532,y:958,t:1527876968910};\\\", \\\"{x:1533,y:958,t:1527876968926};\\\", \\\"{x:1536,y:959,t:1527876968942};\\\", \\\"{x:1538,y:960,t:1527876968960};\\\", \\\"{x:1540,y:961,t:1527876968976};\\\", \\\"{x:1542,y:962,t:1527876968992};\\\", \\\"{x:1543,y:962,t:1527876969074};\\\", \\\"{x:1544,y:962,t:1527876969098};\\\", \\\"{x:1545,y:962,t:1527876969109};\\\", \\\"{x:1546,y:963,t:1527876969130};\\\", \\\"{x:1547,y:963,t:1527876969146};\\\", \\\"{x:1548,y:963,t:1527876969411};\\\", \\\"{x:1548,y:952,t:1527876969426};\\\", \\\"{x:1548,y:942,t:1527876969443};\\\", \\\"{x:1544,y:930,t:1527876969460};\\\", \\\"{x:1538,y:921,t:1527876969477};\\\", \\\"{x:1534,y:914,t:1527876969493};\\\", \\\"{x:1532,y:908,t:1527876969510};\\\", \\\"{x:1528,y:903,t:1527876969527};\\\", \\\"{x:1524,y:896,t:1527876969543};\\\", \\\"{x:1520,y:890,t:1527876969560};\\\", \\\"{x:1518,y:888,t:1527876969576};\\\", \\\"{x:1517,y:887,t:1527876969593};\\\", \\\"{x:1514,y:885,t:1527876969610};\\\", \\\"{x:1514,y:884,t:1527876969626};\\\", \\\"{x:1509,y:877,t:1527876969643};\\\", \\\"{x:1500,y:866,t:1527876969660};\\\", \\\"{x:1488,y:853,t:1527876969677};\\\", \\\"{x:1480,y:844,t:1527876969693};\\\", \\\"{x:1477,y:838,t:1527876969710};\\\", \\\"{x:1476,y:836,t:1527876969727};\\\", \\\"{x:1476,y:835,t:1527876969818};\\\", \\\"{x:1464,y:834,t:1527876970682};\\\", \\\"{x:1438,y:822,t:1527876970693};\\\", \\\"{x:1341,y:795,t:1527876970710};\\\", \\\"{x:1215,y:750,t:1527876970726};\\\", \\\"{x:1080,y:713,t:1527876970743};\\\", \\\"{x:933,y:670,t:1527876970760};\\\", \\\"{x:803,y:629,t:1527876970776};\\\", \\\"{x:660,y:584,t:1527876970793};\\\", \\\"{x:613,y:563,t:1527876970810};\\\", \\\"{x:592,y:553,t:1527876970828};\\\", \\\"{x:587,y:550,t:1527876970844};\\\", \\\"{x:586,y:551,t:1527876971017};\\\", \\\"{x:586,y:558,t:1527876971027};\\\", \\\"{x:590,y:570,t:1527876971044};\\\", \\\"{x:595,y:581,t:1527876971060};\\\", \\\"{x:601,y:587,t:1527876971077};\\\", \\\"{x:606,y:594,t:1527876971093};\\\", \\\"{x:608,y:597,t:1527876971111};\\\", \\\"{x:610,y:599,t:1527876971127};\\\", \\\"{x:610,y:596,t:1527876971273};\\\", \\\"{x:610,y:592,t:1527876971281};\\\", \\\"{x:609,y:589,t:1527876971294};\\\", \\\"{x:608,y:586,t:1527876971311};\\\", \\\"{x:608,y:585,t:1527876971328};\\\", \\\"{x:608,y:583,t:1527876971345};\\\", \\\"{x:607,y:582,t:1527876971361};\\\", \\\"{x:606,y:581,t:1527876971378};\\\", \\\"{x:605,y:581,t:1527876972529};\\\", \\\"{x:605,y:582,t:1527876972553};\\\", \\\"{x:604,y:583,t:1527876972577};\\\", \\\"{x:603,y:583,t:1527876972625};\\\", \\\"{x:603,y:584,t:1527876972825};\\\", \\\"{x:603,y:585,t:1527876972833};\\\", \\\"{x:603,y:587,t:1527876972849};\\\", \\\"{x:603,y:588,t:1527876972863};\\\", \\\"{x:603,y:589,t:1527876972879};\\\", \\\"{x:602,y:591,t:1527876972895};\\\", \\\"{x:602,y:592,t:1527876972969};\\\", \\\"{x:602,y:593,t:1527876973001};\\\", \\\"{x:602,y:594,t:1527876973013};\\\", \\\"{x:602,y:595,t:1527876973040};\\\", \\\"{x:600,y:596,t:1527876973057};\\\", \\\"{x:600,y:597,t:1527876973073};\\\", \\\"{x:600,y:598,t:1527876973081};\\\", \\\"{x:600,y:599,t:1527876973096};\\\", \\\"{x:599,y:601,t:1527876973113};\\\", \\\"{x:598,y:606,t:1527876973128};\\\", \\\"{x:598,y:611,t:1527876973147};\\\", \\\"{x:597,y:615,t:1527876973162};\\\", \\\"{x:596,y:624,t:1527876973179};\\\", \\\"{x:594,y:634,t:1527876973196};\\\", \\\"{x:592,y:647,t:1527876973212};\\\", \\\"{x:588,y:667,t:1527876973229};\\\", \\\"{x:578,y:701,t:1527876973247};\\\", \\\"{x:571,y:729,t:1527876973262};\\\", \\\"{x:566,y:750,t:1527876973280};\\\", \\\"{x:563,y:775,t:1527876973336};\\\", \\\"{x:562,y:775,t:1527876973346};\\\", \\\"{x:561,y:771,t:1527876973561};\\\", \\\"{x:559,y:768,t:1527876973569};\\\", \\\"{x:556,y:763,t:1527876973579};\\\", \\\"{x:553,y:759,t:1527876973596};\\\", \\\"{x:549,y:753,t:1527876973613};\\\", \\\"{x:546,y:748,t:1527876973629};\\\", \\\"{x:542,y:743,t:1527876973647};\\\", \\\"{x:541,y:742,t:1527876973663};\\\" ] }, { \\\"rt\\\": 14083, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 19, \\\"time_elapsed\\\": 579344, \\\"internal_node_id\\\": \\\"0.0-6.0-9.0\\\", \\\"subject\\\": \\\"EER58\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"scenario\\\": \\\"bigset\\\", \\\"question\\\": \\\"midpoint\\\", \\\"q\\\": 15, \\\"clicks\\\": 2.5, \\\"explicit\\\": 3, \\\"impasse\\\": 1, \\\"axis\\\": \\\"Orthogonal-XInside-YFull\\\", \\\"correct\\\": 1, \\\"orth_correct\\\": 0, \\\"answer\\\": [ \\\"K\\\", \\\"X\\\" ], \\\"clicked\\\": [ [ \\\"answer\\\", \\\"clicked\\\" ], [ \\\"A \\\", \\\"false\\\" ], [ \\\"B \\\", \\\"false\\\" ], [ \\\"C \\\", \\\"false\\\" ], [ \\\"D \\\", \\\"false\\\" ], [ \\\"E \\\", \\\"false\\\" ], [ \\\"F \\\", \\\"false\\\" ], [ \\\"G \\\", \\\"false\\\" ], [ \\\"H \\\", \\\"false\\\" ], [ \\\"I \\\", \\\"false\\\" ], [ \\\"J \\\", \\\"false\\\" ], [ \\\"K \\\", \\\"false\\\" ], [ \\\"L \\\", \\\"false\\\" ], [ \\\"M \\\", \\\"false\\\" ], [ \\\"N \\\", \\\"false\\\" ], [ \\\"O \\\", \\\"false\\\" ], [ \\\"P \\\", \\\"false\\\" ], [ \\\"Z \\\", \\\"false\\\" ], [ \\\"X \\\", \\\"false\\\" ] ], \\\"hovered\\\": \\\"-02 PM-02 PM-X -X -X -X \\\", \\\"block\\\": \\\"triangular_testing\\\", \\\"mouseLog\\\": [ \\\"{x:1911,y:1911,t:0};\\\", \\\"{x:541,y:740,t:1527876975569};\\\", \\\"{x:540,y:738,t:1527876975581};\\\", \\\"{x:539,y:734,t:1527876975597};\\\", \\\"{x:539,y:729,t:1527876975614};\\\", \\\"{x:538,y:725,t:1527876975631};\\\", \\\"{x:537,y:722,t:1527876975647};\\\", \\\"{x:537,y:719,t:1527876975664};\\\", \\\"{x:535,y:714,t:1527876975681};\\\", \\\"{x:535,y:713,t:1527876975698};\\\", \\\"{x:535,y:710,t:1527876975714};\\\", \\\"{x:534,y:705,t:1527876975731};\\\", \\\"{x:534,y:703,t:1527876975748};\\\", \\\"{x:534,y:697,t:1527876975764};\\\", \\\"{x:529,y:659,t:1527876975879};\\\", \\\"{x:527,y:657,t:1527876975885};\\\", \\\"{x:526,y:651,t:1527876975898};\\\", \\\"{x:523,y:644,t:1527876975914};\\\", \\\"{x:522,y:640,t:1527876975931};\\\", \\\"{x:520,y:636,t:1527876975948};\\\", \\\"{x:514,y:626,t:1527876975964};\\\", \\\"{x:507,y:620,t:1527876975981};\\\", \\\"{x:504,y:619,t:1527876975999};\\\", \\\"{x:502,y:616,t:1527876976137};\\\", \\\"{x:502,y:613,t:1527876976149};\\\", \\\"{x:503,y:603,t:1527876976165};\\\", \\\"{x:510,y:594,t:1527876976181};\\\", \\\"{x:516,y:588,t:1527876976198};\\\", \\\"{x:526,y:577,t:1527876976215};\\\", \\\"{x:538,y:558,t:1527876976232};\\\", \\\"{x:553,y:539,t:1527876976248};\\\", \\\"{x:574,y:511,t:1527876976265};\\\", \\\"{x:591,y:495,t:1527876976282};\\\", \\\"{x:610,y:480,t:1527876976298};\\\", \\\"{x:625,y:469,t:1527876976315};\\\", \\\"{x:633,y:464,t:1527876976332};\\\", \\\"{x:639,y:461,t:1527876976348};\\\", \\\"{x:639,y:460,t:1527876976365};\\\", \\\"{x:641,y:459,t:1527876976969};\\\", \\\"{x:642,y:459,t:1527876976983};\\\", \\\"{x:653,y:457,t:1527876976999};\\\", \\\"{x:679,y:457,t:1527876977015};\\\", \\\"{x:715,y:457,t:1527876977032};\\\", \\\"{x:791,y:457,t:1527876977049};\\\", \\\"{x:860,y:457,t:1527876977065};\\\", \\\"{x:944,y:457,t:1527876977082};\\\", \\\"{x:1052,y:457,t:1527876977100};\\\", \\\"{x:1175,y:468,t:1527876977115};\\\", \\\"{x:1293,y:489,t:1527876977132};\\\", \\\"{x:1397,y:517,t:1527876977150};\\\", \\\"{x:1501,y:554,t:1527876977165};\\\", \\\"{x:1573,y:585,t:1527876977182};\\\", \\\"{x:1575,y:585,t:1527876977199};\\\", \\\"{x:1576,y:585,t:1527876978553};\\\", \\\"{x:1576,y:596,t:1527876978566};\\\", \\\"{x:1556,y:678,t:1527876978583};\\\", \\\"{x:1526,y:786,t:1527876978599};\\\", \\\"{x:1487,y:884,t:1527876978617};\\\", \\\"{x:1468,y:951,t:1527876978633};\\\", \\\"{x:1466,y:966,t:1527876978650};\\\", \\\"{x:1466,y:967,t:1527876978673};\\\", \\\"{x:1466,y:969,t:1527876978705};\\\", \\\"{x:1466,y:971,t:1527876978720};\\\", \\\"{x:1466,y:973,t:1527876978734};\\\", \\\"{x:1466,y:978,t:1527876978749};\\\", \\\"{x:1466,y:985,t:1527876978767};\\\", \\\"{x:1467,y:990,t:1527876978783};\\\", \\\"{x:1467,y:991,t:1527876978937};\\\", \\\"{x:1468,y:992,t:1527876979001};\\\", \\\"{x:1470,y:992,t:1527876979017};\\\", \\\"{x:1479,y:986,t:1527876979034};\\\", \\\"{x:1484,y:983,t:1527876979050};\\\", \\\"{x:1488,y:980,t:1527876979066};\\\", \\\"{x:1495,y:975,t:1527876979083};\\\", \\\"{x:1506,y:970,t:1527876979101};\\\", \\\"{x:1514,y:969,t:1527876979116};\\\", \\\"{x:1521,y:966,t:1527876979133};\\\", \\\"{x:1527,y:964,t:1527876979151};\\\", \\\"{x:1531,y:962,t:1527876979167};\\\", \\\"{x:1532,y:962,t:1527876979184};\\\", \\\"{x:1531,y:962,t:1527876979497};\\\", \\\"{x:1529,y:962,t:1527876979504};\\\", \\\"{x:1525,y:962,t:1527876979517};\\\", \\\"{x:1515,y:966,t:1527876979534};\\\", \\\"{x:1507,y:968,t:1527876979550};\\\", \\\"{x:1499,y:968,t:1527876979568};\\\", \\\"{x:1491,y:968,t:1527876979583};\\\", \\\"{x:1483,y:968,t:1527876979601};\\\", \\\"{x:1475,y:968,t:1527876979616};\\\", \\\"{x:1474,y:968,t:1527876979634};\\\", \\\"{x:1473,y:968,t:1527876979651};\\\", \\\"{x:1473,y:967,t:1527876979873};\\\", \\\"{x:1474,y:964,t:1527876979884};\\\", \\\"{x:1476,y:960,t:1527876979900};\\\", \\\"{x:1476,y:959,t:1527876979917};\\\", \\\"{x:1477,y:957,t:1527876979933};\\\", \\\"{x:1478,y:956,t:1527876979951};\\\", \\\"{x:1478,y:954,t:1527876980482};\\\", \\\"{x:1479,y:948,t:1527876980488};\\\", \\\"{x:1480,y:938,t:1527876980501};\\\", \\\"{x:1483,y:920,t:1527876980517};\\\", \\\"{x:1484,y:904,t:1527876980534};\\\", \\\"{x:1485,y:893,t:1527876980551};\\\", \\\"{x:1485,y:886,t:1527876980568};\\\", \\\"{x:1485,y:878,t:1527876980585};\\\", \\\"{x:1487,y:869,t:1527876980601};\\\", \\\"{x:1487,y:866,t:1527876980618};\\\", \\\"{x:1487,y:864,t:1527876980634};\\\", \\\"{x:1487,y:859,t:1527876980651};\\\", \\\"{x:1486,y:857,t:1527876980668};\\\", \\\"{x:1486,y:854,t:1527876980685};\\\", \\\"{x:1486,y:852,t:1527876980701};\\\", \\\"{x:1486,y:850,t:1527876980718};\\\", \\\"{x:1486,y:848,t:1527876980735};\\\", \\\"{x:1484,y:845,t:1527876980751};\\\", \\\"{x:1484,y:841,t:1527876980768};\\\", \\\"{x:1484,y:839,t:1527876980785};\\\", \\\"{x:1483,y:835,t:1527876980802};\\\", \\\"{x:1483,y:834,t:1527876980817};\\\", \\\"{x:1483,y:833,t:1527876980834};\\\", \\\"{x:1483,y:830,t:1527876980851};\\\", \\\"{x:1483,y:826,t:1527876980867};\\\", \\\"{x:1483,y:820,t:1527876980884};\\\", \\\"{x:1483,y:817,t:1527876980901};\\\", \\\"{x:1483,y:814,t:1527876980918};\\\", \\\"{x:1484,y:813,t:1527876980934};\\\", \\\"{x:1483,y:813,t:1527876981193};\\\", \\\"{x:1482,y:814,t:1527876981241};\\\", \\\"{x:1481,y:814,t:1527876981257};\\\", \\\"{x:1481,y:816,t:1527876981329};\\\", \\\"{x:1481,y:817,t:1527876981353};\\\", \\\"{x:1481,y:818,t:1527876981377};\\\", \\\"{x:1481,y:819,t:1527876981385};\\\", \\\"{x:1482,y:823,t:1527876981401};\\\", \\\"{x:1482,y:827,t:1527876981419};\\\", \\\"{x:1484,y:830,t:1527876981434};\\\", \\\"{x:1484,y:833,t:1527876981452};\\\", \\\"{x:1485,y:834,t:1527876981469};\\\", \\\"{x:1485,y:835,t:1527876981485};\\\", \\\"{x:1485,y:836,t:1527876981501};\\\", \\\"{x:1486,y:837,t:1527876981544};\\\", \\\"{x:1486,y:841,t:1527876982754};\\\", \\\"{x:1486,y:848,t:1527876982770};\\\", \\\"{x:1486,y:860,t:1527876982786};\\\", \\\"{x:1486,y:866,t:1527876982803};\\\", \\\"{x:1486,y:874,t:1527876982820};\\\", \\\"{x:1486,y:884,t:1527876982837};\\\", \\\"{x:1486,y:895,t:1527876982853};\\\", \\\"{x:1489,y:905,t:1527876982870};\\\", \\\"{x:1489,y:914,t:1527876982886};\\\", \\\"{x:1489,y:921,t:1527876982904};\\\", \\\"{x:1489,y:923,t:1527876982920};\\\", \\\"{x:1489,y:925,t:1527876982937};\\\", \\\"{x:1489,y:927,t:1527876982953};\\\", \\\"{x:1489,y:930,t:1527876982970};\\\", \\\"{x:1489,y:932,t:1527876982986};\\\", \\\"{x:1490,y:934,t:1527876983003};\\\", \\\"{x:1490,y:935,t:1527876983020};\\\", \\\"{x:1490,y:937,t:1527876983037};\\\", \\\"{x:1491,y:939,t:1527876983053};\\\", \\\"{x:1491,y:940,t:1527876983070};\\\", \\\"{x:1491,y:941,t:1527876983086};\\\", \\\"{x:1491,y:943,t:1527876983106};\\\", \\\"{x:1491,y:944,t:1527876983138};\\\", \\\"{x:1491,y:947,t:1527876983154};\\\", \\\"{x:1491,y:951,t:1527876983170};\\\", \\\"{x:1492,y:954,t:1527876983186};\\\", \\\"{x:1492,y:957,t:1527876983204};\\\", \\\"{x:1492,y:958,t:1527876983220};\\\", \\\"{x:1492,y:960,t:1527876983236};\\\", \\\"{x:1492,y:961,t:1527876983253};\\\", \\\"{x:1492,y:963,t:1527876983271};\\\", \\\"{x:1492,y:964,t:1527876983286};\\\", \\\"{x:1492,y:965,t:1527876983304};\\\", \\\"{x:1492,y:966,t:1527876983378};\\\", \\\"{x:1491,y:966,t:1527876983546};\\\", \\\"{x:1490,y:966,t:1527876983562};\\\", \\\"{x:1489,y:966,t:1527876983578};\\\", \\\"{x:1487,y:966,t:1527876983588};\\\", \\\"{x:1486,y:966,t:1527876983604};\\\", \\\"{x:1485,y:965,t:1527876983620};\\\", \\\"{x:1485,y:964,t:1527876983642};\\\", \\\"{x:1484,y:963,t:1527876983658};\\\", \\\"{x:1484,y:961,t:1527876983671};\\\", \\\"{x:1482,y:955,t:1527876983688};\\\", \\\"{x:1478,y:945,t:1527876983703};\\\", \\\"{x:1476,y:938,t:1527876983720};\\\", \\\"{x:1476,y:934,t:1527876983737};\\\", \\\"{x:1476,y:927,t:1527876983753};\\\", \\\"{x:1476,y:917,t:1527876983770};\\\", \\\"{x:1476,y:910,t:1527876983788};\\\", \\\"{x:1476,y:905,t:1527876983803};\\\", \\\"{x:1476,y:901,t:1527876983820};\\\", \\\"{x:1476,y:896,t:1527876983838};\\\", \\\"{x:1476,y:892,t:1527876983854};\\\", \\\"{x:1476,y:889,t:1527876983870};\\\", \\\"{x:1476,y:885,t:1527876983887};\\\", \\\"{x:1476,y:882,t:1527876983903};\\\", \\\"{x:1476,y:879,t:1527876983920};\\\", \\\"{x:1476,y:875,t:1527876983937};\\\", \\\"{x:1476,y:865,t:1527876983953};\\\", \\\"{x:1476,y:861,t:1527876983970};\\\", \\\"{x:1476,y:857,t:1527876983988};\\\", \\\"{x:1476,y:854,t:1527876984004};\\\", \\\"{x:1476,y:851,t:1527876984021};\\\", \\\"{x:1476,y:849,t:1527876984038};\\\", \\\"{x:1476,y:846,t:1527876984054};\\\", \\\"{x:1476,y:843,t:1527876984071};\\\", \\\"{x:1476,y:840,t:1527876984088};\\\", \\\"{x:1476,y:838,t:1527876984105};\\\", \\\"{x:1476,y:837,t:1527876984120};\\\", \\\"{x:1476,y:835,t:1527876984138};\\\", \\\"{x:1476,y:833,t:1527876984153};\\\", \\\"{x:1476,y:832,t:1527876984170};\\\", \\\"{x:1476,y:831,t:1527876984204};\\\", \\\"{x:1476,y:830,t:1527876984226};\\\", \\\"{x:1467,y:825,t:1527876985378};\\\", \\\"{x:1450,y:820,t:1527876985388};\\\", \\\"{x:1368,y:805,t:1527876985404};\\\", \\\"{x:1266,y:791,t:1527876985421};\\\", \\\"{x:1134,y:781,t:1527876985438};\\\", \\\"{x:995,y:761,t:1527876985454};\\\", \\\"{x:862,y:738,t:1527876985471};\\\", \\\"{x:753,y:718,t:1527876985488};\\\", \\\"{x:666,y:689,t:1527876985504};\\\", \\\"{x:575,y:646,t:1527876985521};\\\", \\\"{x:548,y:632,t:1527876985538};\\\", \\\"{x:537,y:623,t:1527876985553};\\\", \\\"{x:527,y:617,t:1527876985570};\\\", \\\"{x:518,y:609,t:1527876985590};\\\", \\\"{x:512,y:605,t:1527876985607};\\\", \\\"{x:510,y:604,t:1527876985622};\\\", \\\"{x:509,y:604,t:1527876985641};\\\", \\\"{x:508,y:603,t:1527876985656};\\\", \\\"{x:507,y:600,t:1527876985672};\\\", \\\"{x:508,y:597,t:1527876985689};\\\", \\\"{x:512,y:594,t:1527876985706};\\\", \\\"{x:516,y:591,t:1527876985723};\\\", \\\"{x:519,y:591,t:1527876985740};\\\", \\\"{x:521,y:591,t:1527876985769};\\\", \\\"{x:523,y:591,t:1527876985777};\\\", \\\"{x:525,y:591,t:1527876985790};\\\", \\\"{x:532,y:591,t:1527876985806};\\\", \\\"{x:538,y:592,t:1527876985823};\\\", \\\"{x:546,y:594,t:1527876985840};\\\", \\\"{x:548,y:596,t:1527876985857};\\\", \\\"{x:549,y:596,t:1527876985921};\\\", \\\"{x:550,y:596,t:1527876985929};\\\", \\\"{x:551,y:596,t:1527876985945};\\\", \\\"{x:552,y:596,t:1527876985957};\\\", \\\"{x:555,y:596,t:1527876985973};\\\", \\\"{x:559,y:596,t:1527876985990};\\\", \\\"{x:563,y:596,t:1527876986006};\\\", \\\"{x:568,y:595,t:1527876986023};\\\", \\\"{x:570,y:594,t:1527876986040};\\\", \\\"{x:571,y:594,t:1527876986120};\\\", \\\"{x:572,y:594,t:1527876986128};\\\", \\\"{x:574,y:594,t:1527876986140};\\\", \\\"{x:577,y:594,t:1527876986156};\\\", \\\"{x:581,y:594,t:1527876986172};\\\", \\\"{x:584,y:594,t:1527876986189};\\\", \\\"{x:586,y:594,t:1527876986207};\\\", \\\"{x:587,y:594,t:1527876986249};\\\", \\\"{x:588,y:594,t:1527876986273};\\\", \\\"{x:591,y:594,t:1527876986290};\\\", \\\"{x:595,y:594,t:1527876986307};\\\", \\\"{x:597,y:594,t:1527876986323};\\\", \\\"{x:601,y:594,t:1527876986340};\\\", \\\"{x:603,y:594,t:1527876986357};\\\", \\\"{x:606,y:594,t:1527876986370};\\\", \\\"{x:609,y:594,t:1527876986388};\\\", \\\"{x:611,y:594,t:1527876986403};\\\", \\\"{x:613,y:593,t:1527876986421};\\\", \\\"{x:616,y:592,t:1527876986438};\\\", \\\"{x:621,y:592,t:1527876986455};\\\", \\\"{x:626,y:591,t:1527876986471};\\\", \\\"{x:628,y:591,t:1527876986488};\\\", \\\"{x:619,y:591,t:1527876986818};\\\", \\\"{x:607,y:591,t:1527876986825};\\\", \\\"{x:580,y:591,t:1527876986841};\\\", \\\"{x:546,y:591,t:1527876986857};\\\", \\\"{x:517,y:591,t:1527876986874};\\\", \\\"{x:494,y:591,t:1527876986893};\\\", \\\"{x:473,y:591,t:1527876986907};\\\", \\\"{x:455,y:591,t:1527876986924};\\\", \\\"{x:442,y:591,t:1527876986941};\\\", \\\"{x:430,y:590,t:1527876986957};\\\", \\\"{x:428,y:589,t:1527876986974};\\\", \\\"{x:426,y:589,t:1527876987225};\\\", \\\"{x:425,y:589,t:1527876987249};\\\", \\\"{x:423,y:589,t:1527876987266};\\\", \\\"{x:421,y:589,t:1527876987274};\\\", \\\"{x:418,y:589,t:1527876987292};\\\", \\\"{x:414,y:588,t:1527876987308};\\\", \\\"{x:411,y:588,t:1527876987324};\\\", \\\"{x:407,y:587,t:1527876987341};\\\", \\\"{x:405,y:587,t:1527876987358};\\\", \\\"{x:404,y:587,t:1527876987374};\\\", \\\"{x:401,y:587,t:1527876987391};\\\", \\\"{x:399,y:587,t:1527876987408};\\\", \\\"{x:394,y:587,t:1527876987424};\\\", \\\"{x:378,y:587,t:1527876987441};\\\", \\\"{x:369,y:587,t:1527876987459};\\\", \\\"{x:364,y:587,t:1527876987475};\\\", \\\"{x:363,y:587,t:1527876987497};\\\", \\\"{x:364,y:588,t:1527876987817};\\\", \\\"{x:370,y:591,t:1527876987825};\\\", \\\"{x:375,y:594,t:1527876987842};\\\", \\\"{x:376,y:595,t:1527876987858};\\\", \\\"{x:378,y:596,t:1527876987875};\\\", \\\"{x:380,y:597,t:1527876987890};\\\", \\\"{x:381,y:597,t:1527876987908};\\\", \\\"{x:383,y:597,t:1527876987929};\\\", \\\"{x:384,y:597,t:1527876987969};\\\", \\\"{x:386,y:597,t:1527876987985};\\\", \\\"{x:387,y:597,t:1527876987993};\\\", \\\"{x:394,y:601,t:1527876988474};\\\", \\\"{x:404,y:605,t:1527876988483};\\\", \\\"{x:417,y:611,t:1527876988493};\\\", \\\"{x:439,y:620,t:1527876988508};\\\", \\\"{x:465,y:630,t:1527876988525};\\\", \\\"{x:487,y:641,t:1527876988541};\\\", \\\"{x:501,y:647,t:1527876988559};\\\", \\\"{x:504,y:648,t:1527876988575};\\\", \\\"{x:505,y:649,t:1527876988592};\\\", \\\"{x:509,y:652,t:1527876988609};\\\", \\\"{x:510,y:656,t:1527876988625};\\\", \\\"{x:511,y:661,t:1527876988642};\\\", \\\"{x:511,y:667,t:1527876988659};\\\", \\\"{x:511,y:677,t:1527876988676};\\\", \\\"{x:511,y:685,t:1527876988692};\\\", \\\"{x:513,y:694,t:1527876988709};\\\", \\\"{x:514,y:699,t:1527876988726};\\\", \\\"{x:516,y:705,t:1527876988742};\\\", \\\"{x:517,y:709,t:1527876988759};\\\", \\\"{x:518,y:712,t:1527876988776};\\\", \\\"{x:518,y:713,t:1527876988792};\\\", \\\"{x:519,y:714,t:1527876988825};\\\", \\\"{x:519,y:716,t:1527876988842};\\\", \\\"{x:518,y:722,t:1527876988859};\\\", \\\"{x:515,y:728,t:1527876988876};\\\", \\\"{x:514,y:734,t:1527876988894};\\\", \\\"{x:514,y:736,t:1527876988909};\\\", \\\"{x:512,y:737,t:1527876988926};\\\", \\\"{x:512,y:739,t:1527876988977};\\\", \\\"{x:511,y:740,t:1527876988992};\\\", \\\"{x:510,y:742,t:1527876989009};\\\" ] }, { \\\"rt\\\": 34803, \\\"url\\\": \\\"../views/src/external/stimulus.html\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 20, \\\"time_elapsed\\\": 615356, \\\"internal_node_id\\\": \\\"0.0-7.0-0.0\\\", \\\"subject\\\": \\\"EER58\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\", \\\"q\\\": 16, \\\"answer\\\": \\\"the dots on the diagonal line to the right \\\", \\\"block\\\": \\\"triangular_testing\\\" }, { \\\"rt\\\": 7502, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"20\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"USA\\\\\\\"}\\\", \\\"block\\\": \\\"demo-1\\\", \\\"trial_type\\\": \\\"survey-text\\\", \\\"trial_index\\\": 21, \\\"time_elapsed\\\": 623865, \\\"internal_node_id\\\": \\\"0.0-8.0\\\", \\\"subject\\\": \\\"EER58\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 9819, \\\"responses\\\": \\\"{\\\\\\\"Q0\\\\\\\":\\\\\\\"English\\\\\\\",\\\\\\\"Q1\\\\\\\":\\\\\\\"Second\\\\\\\",\\\\\\\"Q2\\\\\\\":\\\\\\\"Social Sciences (incl. CogSci)\\\\\\\",\\\\\\\"Q3\\\\\\\":\\\\\\\"Female\\\\\\\"}\\\", \\\"block\\\": \\\"demo-2\\\", \\\"trial_type\\\": \\\"survey-multi-choice\\\", \\\"trial_index\\\": 22, \\\"time_elapsed\\\": 634707, \\\"internal_node_id\\\": \\\"0.0-9.0\\\", \\\"subject\\\": \\\"EER58\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" }, { \\\"rt\\\": 1469, \\\"url\\\": \\\"../views/src/external/debrief.html\\\", \\\"block\\\": \\\"debrief\\\", \\\"trial_type\\\": \\\"html\\\", \\\"trial_index\\\": 23, \\\"time_elapsed\\\": 637266, \\\"internal_node_id\\\": \\\"0.0-10.0\\\", \\\"subject\\\": \\\"EER58\\\", \\\"experiment\\\": \\\"2YP3\\\", \\\"graph\\\": \\\"triangular\\\", \\\"session\\\": \\\"xray\\\", \\\"condition\\\": \\\"311\\\" } ]\",\"parentNode\":{\"id\":2765}}],[],[]]}"
    }
  ],
  "initialDom": "{\"f\":\"initialize\",\"args\":[1,[{\"nodeType\":10,\"id\":2,\"name\":\"html\",\"publicId\":\"\",\"systemId\":\"\"},{\"nodeType\":1,\"id\":3,\"tagName\":\"HTML\",\"attributes\":{\"class\":\"fa-events-icons-ready\"},\"childNodes\":[{\"nodeType\":1,\"id\":4,\"tagName\":\"HEAD\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":5,\"textContent\":\" \"},{\"nodeType\":1,\"id\":6,\"tagName\":\"TITLE\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":7,\"textContent\":\"FOX2YP\"}]},{\"nodeType\":3,\"id\":8,\"textContent\":\" \"},{\"nodeType\":8,\"id\":9},{\"nodeType\":3,\"id\":10,\"textContent\":\" \"},{\"nodeType\":1,\"id\":11,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":12,\"textContent\":\" \"},{\"nodeType\":1,\"id\":13,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":14,\"textContent\":\" \"},{\"nodeType\":1,\"id\":15,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":16,\"textContent\":\" \"},{\"nodeType\":1,\"id\":17,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":18,\"textContent\":\" \"},{\"nodeType\":1,\"id\":19,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":20,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"https://use.fontawesome.com/945539d961.css\",\"media\":\"all\",\"rel\":\"stylesheet\"}},{\"nodeType\":3,\"id\":21,\"textContent\":\" \"},{\"nodeType\":8,\"id\":22},{\"nodeType\":3,\"id\":23,\"textContent\":\" \"},{\"nodeType\":1,\"id\":24,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":25,\"textContent\":\" \"},{\"nodeType\":1,\"id\":26,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":27,\"textContent\":\" \"},{\"nodeType\":1,\"id\":28,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":29,\"textContent\":\" \"},{\"nodeType\":1,\"id\":30,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":31,\"textContent\":\" \"},{\"nodeType\":1,\"id\":32,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":33,\"textContent\":\" \"},{\"nodeType\":1,\"id\":34,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":35,\"textContent\":\" \"},{\"nodeType\":1,\"id\":36,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":37,\"textContent\":\" \"},{\"nodeType\":8,\"id\":38},{\"nodeType\":3,\"id\":39,\"textContent\":\" \"},{\"nodeType\":1,\"id\":40,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":41,\"textContent\":\" \"},{\"nodeType\":8,\"id\":42},{\"nodeType\":3,\"id\":43,\"textContent\":\" \"},{\"nodeType\":8,\"id\":44},{\"nodeType\":3,\"id\":45,\"textContent\":\" \"},{\"nodeType\":1,\"id\":46,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../views/jsPsych/css/jspsych.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":47,\"textContent\":\" \"},{\"nodeType\":1,\"id\":48,\"tagName\":\"LINK\",\"attributes\":{\"href\":\"../css/styles.css\",\"rel\":\"stylesheet\",\"type\":\"text/css\"}},{\"nodeType\":3,\"id\":49,\"textContent\":\" \"},{\"nodeType\":1,\"id\":50,\"tagName\":\"SCRIPT\"},{\"nodeType\":1,\"id\":51,\"tagName\":\"SCRIPT\"}]},{\"nodeType\":3,\"id\":52,\"textContent\":\" \"},{\"nodeType\":8,\"id\":53},{\"nodeType\":3,\"id\":54,\"textContent\":\" \"},{\"nodeType\":1,\"id\":55,\"tagName\":\"BODY\",\"attributes\":{\"class\":\"jspsych-display-element\"},\"childNodes\":[{\"nodeType\":3,\"id\":56,\"textContent\":\" \"},{\"nodeType\":1,\"id\":57,\"tagName\":\"META\",\"attributes\":{\"charset\":\"utf-8\"}},{\"nodeType\":3,\"id\":58,\"textContent\":\" \"},{\"nodeType\":8,\"id\":59},{\"nodeType\":3,\"id\":60,\"textContent\":\" \"},{\"nodeType\":1,\"id\":61,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":62,\"textContent\":\" \"},{\"nodeType\":1,\"id\":63,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":64,\"textContent\":\" \"},{\"nodeType\":1,\"id\":65,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":66,\"textContent\":\" \"},{\"nodeType\":1,\"id\":67,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":68,\"textContent\":\" \"},{\"nodeType\":1,\"id\":69,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":70,\"textContent\":\" \"},{\"nodeType\":1,\"id\":71,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":72,\"textContent\":\" \"},{\"nodeType\":1,\"id\":73,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"stimulus\"},\"childNodes\":[{\"nodeType\":3,\"id\":74,\"textContent\":\" \"},{\"nodeType\":1,\"id\":75,\"tagName\":\"P\",\"attributes\":{\"class\":\"userid\",\"id\":\"userid\"},\"childNodes\":[{\"nodeType\":3,\"id\":76,\"textContent\":\"EER58\"}]},{\"nodeType\":3,\"id\":77,\"textContent\":\" \"},{\"nodeType\":1,\"id\":78,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"userinput\"},\"childNodes\":[{\"nodeType\":3,\"id\":79,\"textContent\":\" \"},{\"nodeType\":8,\"id\":80},{\"nodeType\":3,\"id\":81,\"textContent\":\" \"},{\"nodeType\":1,\"id\":82,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"legend\",\"id\":\"hint-interactive\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":83,\"textContent\":\" \"},{\"nodeType\":1,\"id\":84,\"tagName\":\"P\",\"attributes\":{},\"childNodes\":[{\"nodeType\":3,\"id\":85,\"textContent\":\"Hint: Hover your mouse over the data points in the graph\"}]},{\"nodeType\":3,\"id\":86,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":87,\"textContent\":\" \"},{\"nodeType\":8,\"id\":88},{\"nodeType\":3,\"id\":89,\"textContent\":\" \"},{\"nodeType\":8,\"id\":90},{\"nodeType\":3,\"id\":91,\"textContent\":\" \"},{\"nodeType\":1,\"id\":92,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"test\"},\"childNodes\":[{\"nodeType\":3,\"id\":93,\"textContent\":\" \"},{\"nodeType\":1,\"id\":94,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":95,\"textContent\":\" \"},{\"nodeType\":1,\"id\":96,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":97,\"textContent\":\"Which shift(s) start at 11 am? \"}]},{\"nodeType\":3,\"id\":98,\"textContent\":\" \"},{\"nodeType\":1,\"id\":99,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":100,\"textContent\":\" \"},{\"nodeType\":1,\"id\":101,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":102,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":103,\"textContent\":\" \"},{\"nodeType\":1,\"id\":104,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":105,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":106,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":107,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":108,\"textContent\":\" \"},{\"nodeType\":1,\"id\":109,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":110,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":111,\"textContent\":\" \"},{\"nodeType\":1,\"id\":112,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":113,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":114,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":115,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":116,\"textContent\":\" \"},{\"nodeType\":1,\"id\":117,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":118,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":120,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":121,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":122,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":123,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":125,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":126,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":127,\"textContent\":\" \"},{\"nodeType\":1,\"id\":128,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":129,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":130,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":131,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":132,\"textContent\":\" \"},{\"nodeType\":1,\"id\":133,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":134,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":135,\"textContent\":\" \"},{\"nodeType\":1,\"id\":136,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":137,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":138,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":139,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":140,\"textContent\":\" \"},{\"nodeType\":1,\"id\":141,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":142,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":143,\"textContent\":\" \"},{\"nodeType\":1,\"id\":144,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":145,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":146,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":147,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":148,\"textContent\":\" \"},{\"nodeType\":1,\"id\":149,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":150,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":151,\"textContent\":\" \"},{\"nodeType\":1,\"id\":152,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":153,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":154,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":155,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":156,\"textContent\":\" \"},{\"nodeType\":1,\"id\":157,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":158,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":159,\"textContent\":\" \"},{\"nodeType\":1,\"id\":160,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":161,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":162,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":163,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":164,\"textContent\":\" \"},{\"nodeType\":1,\"id\":165,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":166,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":167,\"textContent\":\" \"},{\"nodeType\":1,\"id\":168,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":169,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":170,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":171,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":172,\"textContent\":\" \"},{\"nodeType\":1,\"id\":173,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":174,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":175,\"textContent\":\" \"},{\"nodeType\":1,\"id\":176,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":177,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":178,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":179,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":180,\"textContent\":\" \"},{\"nodeType\":1,\"id\":181,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":182,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":183,\"textContent\":\" \"},{\"nodeType\":1,\"id\":184,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":185,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":186,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":187,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":188,\"textContent\":\" \"},{\"nodeType\":1,\"id\":189,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":190,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":191,\"textContent\":\" \"},{\"nodeType\":1,\"id\":192,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":193,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":194,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":195,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":196,\"textContent\":\" \"},{\"nodeType\":1,\"id\":197,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":198,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":200,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":201,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":202,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":203,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":205,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":206,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":207,\"textContent\":\" \"},{\"nodeType\":1,\"id\":208,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":209,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":210,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":211,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":212,\"textContent\":\" \"},{\"nodeType\":1,\"id\":213,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":214,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":215,\"textContent\":\" \"},{\"nodeType\":1,\"id\":216,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":217,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":218,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":219,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":220,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":221,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":223,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":224,\"textContent\":\" \"},{\"nodeType\":1,\"id\":225,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":226,\"textContent\":\"Which shift(s) start at the same time as D?\"}]},{\"nodeType\":3,\"id\":227,\"textContent\":\" \"},{\"nodeType\":1,\"id\":228,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":229,\"textContent\":\" \"},{\"nodeType\":1,\"id\":230,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":231,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":232,\"textContent\":\" \"},{\"nodeType\":1,\"id\":233,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":234,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":235,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":236,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":237,\"textContent\":\" \"},{\"nodeType\":1,\"id\":238,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":239,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":240,\"textContent\":\" \"},{\"nodeType\":1,\"id\":241,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":242,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":243,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":244,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":245,\"textContent\":\" \"},{\"nodeType\":1,\"id\":246,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":247,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":248,\"textContent\":\" \"},{\"nodeType\":1,\"id\":249,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":250,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":251,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":252,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":253,\"textContent\":\" \"},{\"nodeType\":1,\"id\":254,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":255,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":256,\"textContent\":\" \"},{\"nodeType\":1,\"id\":257,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":258,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":259,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":260,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":261,\"textContent\":\" \"},{\"nodeType\":1,\"id\":262,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":263,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":264,\"textContent\":\" \"},{\"nodeType\":1,\"id\":265,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":266,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":267,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":268,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":269,\"textContent\":\" \"},{\"nodeType\":1,\"id\":270,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":271,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":273,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":274,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":275,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":276,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":278,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":279,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":280,\"textContent\":\" \"},{\"nodeType\":1,\"id\":281,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":282,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":283,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":284,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":286,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":287,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":288,\"textContent\":\" \"},{\"nodeType\":1,\"id\":289,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":290,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":291,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":292,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":293,\"textContent\":\" \"},{\"nodeType\":1,\"id\":294,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":295,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":296,\"textContent\":\" \"},{\"nodeType\":1,\"id\":297,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":298,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":299,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":300,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":301,\"textContent\":\" \"},{\"nodeType\":1,\"id\":302,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":303,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":304,\"textContent\":\" \"},{\"nodeType\":1,\"id\":305,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":306,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":307,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":308,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":309,\"textContent\":\" \"},{\"nodeType\":1,\"id\":310,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":311,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":312,\"textContent\":\" \"},{\"nodeType\":1,\"id\":313,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":314,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":315,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":316,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":317,\"textContent\":\" \"},{\"nodeType\":1,\"id\":318,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":319,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":320,\"textContent\":\" \"},{\"nodeType\":1,\"id\":321,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":322,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":323,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":324,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":325,\"textContent\":\" \"},{\"nodeType\":1,\"id\":326,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":327,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":328,\"textContent\":\" \"},{\"nodeType\":1,\"id\":329,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":330,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":331,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":332,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":333,\"textContent\":\" \"},{\"nodeType\":1,\"id\":334,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":335,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":336,\"textContent\":\" \"},{\"nodeType\":1,\"id\":337,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":338,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":339,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":340,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":341,\"textContent\":\" \"},{\"nodeType\":1,\"id\":342,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":343,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":344,\"textContent\":\" \"},{\"nodeType\":1,\"id\":345,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":346,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":347,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":348,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":349,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":351,\"textContent\":\" \"},{\"nodeType\":1,\"id\":352,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":353,\"textContent\":\" \"},{\"nodeType\":1,\"id\":354,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":355,\"textContent\":\"Which shift(s) begin when C ends?\"}]},{\"nodeType\":3,\"id\":356,\"textContent\":\" \"},{\"nodeType\":1,\"id\":357,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":358,\"textContent\":\" \"},{\"nodeType\":1,\"id\":359,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":360,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":361,\"textContent\":\" \"},{\"nodeType\":1,\"id\":362,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":363,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":364,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":365,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":366,\"textContent\":\" \"},{\"nodeType\":1,\"id\":367,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":368,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":369,\"textContent\":\" \"},{\"nodeType\":1,\"id\":370,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":371,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":372,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":373,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":374,\"textContent\":\" \"},{\"nodeType\":1,\"id\":375,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":376,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":377,\"textContent\":\" \"},{\"nodeType\":1,\"id\":378,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":379,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":380,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":381,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":382,\"textContent\":\" \"},{\"nodeType\":1,\"id\":383,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":384,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":385,\"textContent\":\" \"},{\"nodeType\":1,\"id\":386,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":387,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":388,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":389,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":390,\"textContent\":\" \"},{\"nodeType\":1,\"id\":391,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":392,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":393,\"textContent\":\" \"},{\"nodeType\":1,\"id\":394,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":395,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":396,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":397,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":398,\"textContent\":\" \"},{\"nodeType\":1,\"id\":399,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":400,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":401,\"textContent\":\" \"},{\"nodeType\":1,\"id\":402,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":403,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":404,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":405,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":406,\"textContent\":\" \"},{\"nodeType\":1,\"id\":407,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":408,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":409,\"textContent\":\" \"},{\"nodeType\":1,\"id\":410,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":411,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":412,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":413,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":414,\"textContent\":\" \"},{\"nodeType\":1,\"id\":415,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":416,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":417,\"textContent\":\" \"},{\"nodeType\":1,\"id\":418,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":419,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":420,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":421,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":422,\"textContent\":\" \"},{\"nodeType\":1,\"id\":423,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":424,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":425,\"textContent\":\" \"},{\"nodeType\":1,\"id\":426,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":427,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":428,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":429,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":430,\"textContent\":\" \"},{\"nodeType\":1,\"id\":431,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":432,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":433,\"textContent\":\" \"},{\"nodeType\":1,\"id\":434,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":435,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":436,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":437,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":438,\"textContent\":\" \"},{\"nodeType\":1,\"id\":439,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":440,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":441,\"textContent\":\" \"},{\"nodeType\":1,\"id\":442,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":443,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":444,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":445,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":446,\"textContent\":\" \"},{\"nodeType\":1,\"id\":447,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":448,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":449,\"textContent\":\" \"},{\"nodeType\":1,\"id\":450,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":451,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":452,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":453,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":454,\"textContent\":\" \"},{\"nodeType\":1,\"id\":455,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":456,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":457,\"textContent\":\" \"},{\"nodeType\":1,\"id\":458,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":459,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":460,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":461,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":462,\"textContent\":\" \"},{\"nodeType\":1,\"id\":463,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":464,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":465,\"textContent\":\" \"},{\"nodeType\":1,\"id\":466,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":467,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":468,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":469,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":470,\"textContent\":\" \"},{\"nodeType\":1,\"id\":471,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":472,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":473,\"textContent\":\" \"},{\"nodeType\":1,\"id\":474,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":475,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":476,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":477,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":478,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":479,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":480,\"textContent\":\" \"},{\"nodeType\":1,\"id\":481,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":483,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":484,\"textContent\":\" Which shift(s) end at 4 pm?\"}]},{\"nodeType\":3,\"id\":485,\"textContent\":\" \"},{\"nodeType\":1,\"id\":486,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":492,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":500,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":503,\"textContent\":\" \"},{\"nodeType\":1,\"id\":504,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":505,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":506,\"textContent\":\" \"},{\"nodeType\":1,\"id\":507,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":508,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":509,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":510,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":511,\"textContent\":\" \"},{\"nodeType\":1,\"id\":512,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":513,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":514,\"textContent\":\" \"},{\"nodeType\":1,\"id\":515,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":516,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":517,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":518,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":519,\"textContent\":\" \"},{\"nodeType\":1,\"id\":520,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":521,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":522,\"textContent\":\" \"},{\"nodeType\":1,\"id\":523,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":524,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":525,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":526,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":527,\"textContent\":\" \"},{\"nodeType\":1,\"id\":528,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":529,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":530,\"textContent\":\" \"},{\"nodeType\":1,\"id\":531,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":532,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":533,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":534,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":535,\"textContent\":\" \"},{\"nodeType\":1,\"id\":536,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":537,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":538,\"textContent\":\" \"},{\"nodeType\":1,\"id\":539,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":540,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":541,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":542,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":543,\"textContent\":\" \"},{\"nodeType\":1,\"id\":544,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":545,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":546,\"textContent\":\" \"},{\"nodeType\":1,\"id\":547,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":548,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":549,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":550,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":551,\"textContent\":\" \"},{\"nodeType\":1,\"id\":552,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":553,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":554,\"textContent\":\" \"},{\"nodeType\":1,\"id\":555,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":556,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":557,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":558,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":559,\"textContent\":\" \"},{\"nodeType\":1,\"id\":560,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":561,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":562,\"textContent\":\" \"},{\"nodeType\":1,\"id\":563,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":564,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":565,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":566,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":567,\"textContent\":\" \"},{\"nodeType\":1,\"id\":568,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":569,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":570,\"textContent\":\" \"},{\"nodeType\":1,\"id\":571,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":572,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":573,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":574,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":575,\"textContent\":\" \"},{\"nodeType\":1,\"id\":576,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":577,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":578,\"textContent\":\" \"},{\"nodeType\":1,\"id\":579,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":580,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":581,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":582,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":583,\"textContent\":\" \"},{\"nodeType\":1,\"id\":584,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":585,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":586,\"textContent\":\" \"},{\"nodeType\":1,\"id\":587,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":588,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":589,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":590,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":592,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":593,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":594,\"textContent\":\" \"},{\"nodeType\":1,\"id\":595,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":596,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":597,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":598,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":599,\"textContent\":\" \"},{\"nodeType\":1,\"id\":600,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":601,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":602,\"textContent\":\" \"},{\"nodeType\":1,\"id\":603,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":604,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":605,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":606,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":607,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":608,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":609,\"textContent\":\" \"},{\"nodeType\":1,\"id\":610,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"acme\",\"id\":\"acme.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":612,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":613,\"textContent\":\"Coffee breaks happen halfway through a shift.\"},{\"nodeType\":1,\"id\":614,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":615,\"textContent\":\" Which shift(s) share a break with I?\"}]},{\"nodeType\":3,\"id\":616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":617,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":618,\"textContent\":\" \"},{\"nodeType\":1,\"id\":619,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":620,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":621,\"textContent\":\" \"},{\"nodeType\":1,\"id\":622,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":623,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":624,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":625,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":626,\"textContent\":\" \"},{\"nodeType\":1,\"id\":627,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":628,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":629,\"textContent\":\" \"},{\"nodeType\":1,\"id\":630,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":631,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":632,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":633,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":634,\"textContent\":\" \"},{\"nodeType\":1,\"id\":635,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":636,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":637,\"textContent\":\" \"},{\"nodeType\":1,\"id\":638,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":639,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":640,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":641,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":642,\"textContent\":\" \"},{\"nodeType\":1,\"id\":643,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":644,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":645,\"textContent\":\" \"},{\"nodeType\":1,\"id\":646,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":647,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":648,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":649,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":650,\"textContent\":\" \"},{\"nodeType\":1,\"id\":651,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":652,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":653,\"textContent\":\" \"},{\"nodeType\":1,\"id\":654,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":655,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":656,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":657,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":659,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":660,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":661,\"textContent\":\" \"},{\"nodeType\":1,\"id\":662,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":663,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":664,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":665,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":666,\"textContent\":\" \"},{\"nodeType\":1,\"id\":667,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":668,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":669,\"textContent\":\" \"},{\"nodeType\":1,\"id\":670,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":671,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":672,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":673,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":674,\"textContent\":\" \"},{\"nodeType\":1,\"id\":675,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":676,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":677,\"textContent\":\" \"},{\"nodeType\":1,\"id\":678,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":679,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":680,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":681,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":682,\"textContent\":\" \"},{\"nodeType\":1,\"id\":683,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":684,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":685,\"textContent\":\" \"},{\"nodeType\":1,\"id\":686,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":687,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":688,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":689,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":690,\"textContent\":\" \"},{\"nodeType\":1,\"id\":691,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":692,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":693,\"textContent\":\" \"},{\"nodeType\":1,\"id\":694,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":695,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":696,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":697,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":698,\"textContent\":\" \"},{\"nodeType\":1,\"id\":699,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":700,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":701,\"textContent\":\" \"},{\"nodeType\":1,\"id\":702,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"U\",\"value\":\"\"}},{\"nodeType\":3,\"id\":703,\"textContent\":\"U \"},{\"nodeType\":1,\"id\":704,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":705,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":706,\"textContent\":\" \"},{\"nodeType\":1,\"id\":707,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":708,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":709,\"textContent\":\" \"},{\"nodeType\":1,\"id\":710,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":711,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":712,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":713,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":714,\"textContent\":\" \"},{\"nodeType\":1,\"id\":715,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":716,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":717,\"textContent\":\" \"},{\"nodeType\":1,\"id\":718,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":719,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":720,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":721,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":722,\"textContent\":\" \"},{\"nodeType\":1,\"id\":723,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":724,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":725,\"textContent\":\" \"},{\"nodeType\":1,\"id\":726,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":727,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":728,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":729,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":730,\"textContent\":\" \"},{\"nodeType\":1,\"id\":731,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":732,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":733,\"textContent\":\" \"},{\"nodeType\":1,\"id\":734,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":735,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":736,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":737,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":738,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":739,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":741,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":742,\"textContent\":\" \"},{\"nodeType\":1,\"id\":743,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":744,\"textContent\":\"Which shift(s) are six hours long?\"}]},{\"nodeType\":3,\"id\":745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":746,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":747,\"textContent\":\" \"},{\"nodeType\":1,\"id\":748,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":749,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":750,\"textContent\":\" \"},{\"nodeType\":1,\"id\":751,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":752,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":753,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":754,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":755,\"textContent\":\" \"},{\"nodeType\":1,\"id\":756,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":757,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":758,\"textContent\":\" \"},{\"nodeType\":1,\"id\":759,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":760,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":761,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":762,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":763,\"textContent\":\" \"},{\"nodeType\":1,\"id\":764,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":765,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":766,\"textContent\":\" \"},{\"nodeType\":1,\"id\":767,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":768,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":769,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":770,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":771,\"textContent\":\" \"},{\"nodeType\":1,\"id\":772,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":773,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":774,\"textContent\":\" \"},{\"nodeType\":1,\"id\":775,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":776,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":777,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":778,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":779,\"textContent\":\" \"},{\"nodeType\":1,\"id\":780,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":781,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":782,\"textContent\":\" \"},{\"nodeType\":1,\"id\":783,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":784,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":785,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":786,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":787,\"textContent\":\" \"},{\"nodeType\":1,\"id\":788,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":789,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":790,\"textContent\":\" \"},{\"nodeType\":1,\"id\":791,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":792,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":793,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":794,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":795,\"textContent\":\" \"},{\"nodeType\":1,\"id\":796,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":797,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":798,\"textContent\":\" \"},{\"nodeType\":1,\"id\":799,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":800,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":801,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":802,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":803,\"textContent\":\" \"},{\"nodeType\":1,\"id\":804,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":805,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":806,\"textContent\":\" \"},{\"nodeType\":1,\"id\":807,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":808,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":809,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":810,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":812,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":813,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":814,\"textContent\":\" \"},{\"nodeType\":1,\"id\":815,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":816,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":817,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":818,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":819,\"textContent\":\" \"},{\"nodeType\":1,\"id\":820,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":821,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":822,\"textContent\":\" \"},{\"nodeType\":1,\"id\":823,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":824,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":825,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":826,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":827,\"textContent\":\" \"},{\"nodeType\":1,\"id\":828,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":829,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":830,\"textContent\":\" \"},{\"nodeType\":1,\"id\":831,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":832,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":833,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":834,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":835,\"textContent\":\" \"},{\"nodeType\":1,\"id\":836,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":837,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":838,\"textContent\":\" \"},{\"nodeType\":1,\"id\":839,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":840,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":841,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":842,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":843,\"textContent\":\" \"},{\"nodeType\":1,\"id\":844,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":845,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":846,\"textContent\":\" \"},{\"nodeType\":1,\"id\":847,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":848,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":849,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":850,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":851,\"textContent\":\" \"},{\"nodeType\":1,\"id\":852,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":853,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":854,\"textContent\":\" \"},{\"nodeType\":1,\"id\":855,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":856,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":857,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":858,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":859,\"textContent\":\" \"},{\"nodeType\":1,\"id\":860,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":861,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":862,\"textContent\":\" \"},{\"nodeType\":1,\"id\":863,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":864,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":865,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":866,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":867,\"textContent\":\" \"},{\"nodeType\":1,\"id\":868,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":869,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":870,\"textContent\":\" \"},{\"nodeType\":1,\"id\":871,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":872,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":873,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":874,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":875,\"textContent\":\" \"},{\"nodeType\":1,\"id\":876,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":877,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":878,\"textContent\":\" \"},{\"nodeType\":1,\"id\":879,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":880,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":881,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":882,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":883,\"textContent\":\" \"},{\"nodeType\":1,\"id\":884,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":885,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":886,\"textContent\":\" \"},{\"nodeType\":1,\"id\":887,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":888,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":889,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":890,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":891,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":892,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":894,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":895,\"textContent\":\" \"},{\"nodeType\":1,\"id\":896,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":897,\"textContent\":\"Which 2 shifts less than 5 hours long start at the same time?\"}]},{\"nodeType\":3,\"id\":898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":899,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":900,\"textContent\":\" \"},{\"nodeType\":1,\"id\":901,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":902,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":903,\"textContent\":\" \"},{\"nodeType\":1,\"id\":904,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":905,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":906,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":907,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":908,\"textContent\":\" \"},{\"nodeType\":1,\"id\":909,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":910,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":911,\"textContent\":\" \"},{\"nodeType\":1,\"id\":912,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":913,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":914,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":915,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":916,\"textContent\":\" \"},{\"nodeType\":1,\"id\":917,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":918,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":919,\"textContent\":\" \"},{\"nodeType\":1,\"id\":920,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":921,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":922,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":923,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":924,\"textContent\":\" \"},{\"nodeType\":1,\"id\":925,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":926,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":927,\"textContent\":\" \"},{\"nodeType\":1,\"id\":928,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":929,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":930,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":931,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":932,\"textContent\":\" \"},{\"nodeType\":1,\"id\":933,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":934,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":935,\"textContent\":\" \"},{\"nodeType\":1,\"id\":936,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":937,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":938,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":939,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":940,\"textContent\":\" \"},{\"nodeType\":1,\"id\":941,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":942,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":943,\"textContent\":\" \"},{\"nodeType\":1,\"id\":944,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":945,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":946,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":947,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":948,\"textContent\":\" \"},{\"nodeType\":1,\"id\":949,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":950,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":951,\"textContent\":\" \"},{\"nodeType\":1,\"id\":952,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":953,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":954,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":955,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":956,\"textContent\":\" \"},{\"nodeType\":1,\"id\":957,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":958,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":959,\"textContent\":\" \"},{\"nodeType\":1,\"id\":960,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":961,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":962,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":963,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":965,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":966,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":967,\"textContent\":\" \"},{\"nodeType\":1,\"id\":968,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":969,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":970,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":971,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":972,\"textContent\":\" \"},{\"nodeType\":1,\"id\":973,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":974,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":975,\"textContent\":\" \"},{\"nodeType\":1,\"id\":976,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":977,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":978,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":979,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":980,\"textContent\":\" \"},{\"nodeType\":1,\"id\":981,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":982,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":983,\"textContent\":\" \"},{\"nodeType\":1,\"id\":984,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":985,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":986,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":987,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":988,\"textContent\":\" \"},{\"nodeType\":1,\"id\":989,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":990,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":991,\"textContent\":\" \"},{\"nodeType\":1,\"id\":992,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":993,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":994,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":995,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":996,\"textContent\":\" \"},{\"nodeType\":1,\"id\":997,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":998,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":999,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1000,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1001,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1002,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1003,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1004,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1005,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1006,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1007,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1008,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1009,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1010,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1011,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1012,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1013,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1014,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1015,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1016,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1017,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1018,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1019,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1020,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1021,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1022,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1023,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1024,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1025,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1026,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1027,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1028,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1029,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1030,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1031,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1032,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1033,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1034,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1035,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1036,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1037,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1038,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1039,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1040,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1041,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1042,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1043,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1044,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1045,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1047,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.duration+contained\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1048,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1049,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1050,\"textContent\":\"Which shift(s) under 7 hours long starts before B starts, and ends after X ends?\"}]},{\"nodeType\":3,\"id\":1051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1052,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1053,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1054,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1055,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1056,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1057,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1058,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1059,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1060,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1061,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1062,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1063,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1064,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1065,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1066,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1067,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1068,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1069,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1070,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1071,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1072,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1073,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1074,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1075,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1076,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1077,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1078,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1079,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1080,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1081,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1082,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1083,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1084,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1085,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1086,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1087,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1088,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1089,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1090,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1091,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1092,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1093,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1094,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1095,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1096,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1097,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1098,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1099,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1100,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1101,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1102,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1103,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1104,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1105,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1106,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1107,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1108,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1109,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1110,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1111,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1112,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1113,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1114,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1115,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1116,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1118,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1119,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1120,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1121,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1122,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1123,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1124,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1125,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1126,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1127,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1128,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1129,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1130,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1131,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1132,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1133,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1134,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1135,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1136,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1137,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1138,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1139,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1140,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1141,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1142,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1143,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1144,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1145,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1146,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1147,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1148,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1149,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1150,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1151,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1152,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1153,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1154,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1155,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1156,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1157,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1158,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1159,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1160,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1161,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1162,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1163,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1164,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1165,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1166,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1167,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1168,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1169,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1170,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1171,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1172,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1173,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1174,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1175,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1176,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1177,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1178,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1179,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1180,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1181,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1182,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1183,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1184,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1185,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1186,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1187,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1188,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1189,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1190,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1191,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1192,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1193,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1194,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1195,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1196,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1197,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1198,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1199,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1200,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime+before+endtime+during\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1202,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1203,\"textContent\":\"Which shift(s) begins before J begins and ends during B?\"}]},{\"nodeType\":3,\"id\":1204,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1205,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1211,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1219,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1227,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1235,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1243,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1251,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1259,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1267,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1270,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1271,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1272,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1273,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1274,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1275,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1276,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1277,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1278,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1279,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1280,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1281,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1282,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1283,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1284,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1285,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1286,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1287,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1288,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1289,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1290,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1291,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1292,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1293,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1294,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1295,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1296,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1298,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1299,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1300,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1301,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1302,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1303,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1304,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1305,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1306,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1307,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1308,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1309,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1310,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1311,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1312,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1313,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1314,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1315,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1316,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1317,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1318,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1319,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1320,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1321,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1322,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1323,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1324,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1325,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1326,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1327,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1328,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1329,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1330,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1331,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1332,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1333,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1334,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1335,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1336,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1337,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1338,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1339,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1340,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1341,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1342,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1343,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1344,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1345,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1346,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1347,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1348,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1349,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1350,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1351,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1352,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1353,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.ends\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1354,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1355,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1356,\"textContent\":\"Which shift(s) end at the same time as F?\"}]},{\"nodeType\":3,\"id\":1357,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1358,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1359,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1360,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1361,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1362,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1363,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1364,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1365,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1366,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1367,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1368,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1369,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1370,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1371,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1372,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1373,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1374,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1375,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1376,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1377,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1378,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1379,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1380,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1381,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1382,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1383,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1384,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1385,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1386,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1387,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1388,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1389,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1390,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1391,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1392,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1393,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1394,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1395,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1396,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1397,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1398,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1399,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1400,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1401,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1402,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1403,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1404,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1405,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1406,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1407,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1408,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1409,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1410,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1411,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1412,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1413,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1414,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1415,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1416,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1417,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1418,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1419,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1420,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1421,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1422,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1423,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1424,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1425,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1426,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1427,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1428,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1429,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1430,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1431,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1432,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1433,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1434,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1435,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1436,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1437,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1438,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1439,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1440,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1441,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1442,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1443,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1444,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1445,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1446,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1447,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1448,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1449,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1450,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1451,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1452,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1453,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1454,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1455,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1456,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1457,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1458,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1459,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1460,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1461,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1462,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1463,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1464,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1465,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1466,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1467,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1468,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1469,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1470,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1471,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1472,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1473,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1474,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1475,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1476,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1477,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1478,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1479,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1480,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1481,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1482,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1483,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1484,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1485,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1486,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1487,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1488,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1489,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1490,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1491,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1492,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1493,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1494,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1495,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1496,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1497,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1498,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1499,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1500,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1501,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1502,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1503,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1504,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1505,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1506,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starttime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1507,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1508,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1509,\"textContent\":\"Which shift(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":1510,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1511,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1512,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1513,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1514,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1515,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1516,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1517,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1518,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1519,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1520,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1521,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1522,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1523,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1524,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1525,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1526,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1527,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1528,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1529,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1530,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1531,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1532,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1533,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1534,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1535,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1536,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1537,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1538,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1539,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1540,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1541,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1542,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1543,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1544,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1545,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1546,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1547,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1548,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1549,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1550,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1551,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1552,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1553,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1554,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1555,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1556,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1557,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1558,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1559,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1560,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1561,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1562,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1563,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1564,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1565,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1566,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1567,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1568,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1569,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1570,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1571,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1572,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1573,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1574,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1575,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1576,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1577,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1578,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1579,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1580,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1581,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1582,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1583,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1584,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1585,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1586,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1587,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1588,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1589,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1590,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1591,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1592,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1593,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1594,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1595,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1596,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1597,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1598,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1599,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1600,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1601,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1602,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1603,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1604,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1605,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1606,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1607,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1608,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1609,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1610,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1611,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1612,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1613,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1614,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1615,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1616,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1617,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1618,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1619,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1620,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1621,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1622,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1623,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1624,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1625,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1626,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1627,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1628,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1629,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1630,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1631,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1632,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1633,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1634,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1635,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1636,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1637,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1638,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1639,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1640,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1641,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1642,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1643,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1644,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1645,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1646,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1647,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1648,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1649,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1650,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1651,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1652,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1653,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1654,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1655,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1656,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1657,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1658,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1659,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.starts\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1660,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1661,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1662,\"textContent\":\"Which shift(s) start at the same time as F?\"}]},{\"nodeType\":3,\"id\":1663,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1664,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1665,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1666,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1667,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1668,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1669,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1670,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1671,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1672,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1673,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1674,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1675,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1676,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1677,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1678,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1679,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1680,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1681,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1682,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1683,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1684,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1685,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1686,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1687,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1688,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1689,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1690,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1691,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1692,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1693,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1694,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1695,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1696,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1697,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1698,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1699,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1700,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1701,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1702,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1703,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1704,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1705,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1706,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1707,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1708,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1709,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1710,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1711,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1712,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1713,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1714,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1715,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1716,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1717,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1718,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1719,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1720,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1721,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1722,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1723,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1724,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1725,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1726,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1727,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1728,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1729,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1730,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1731,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1732,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1733,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1734,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1735,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1736,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1737,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1738,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1739,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1740,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1741,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1742,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1743,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1744,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1745,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1746,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1747,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1748,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1749,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1750,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1751,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1752,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1753,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1754,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1755,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1756,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1757,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1758,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1759,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1760,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1761,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1762,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1763,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1764,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1765,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1766,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1767,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1768,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1769,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1770,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1771,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1772,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1773,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1774,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1775,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1776,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1777,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1778,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1779,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1780,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1781,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1782,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1783,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1784,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1785,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1786,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1787,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1788,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1789,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1790,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1791,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1792,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1793,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1794,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1795,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1796,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1797,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1798,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1799,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1800,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1801,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1802,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1803,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1804,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1805,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1806,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1807,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1808,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1809,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1810,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1811,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1812,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.meets\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1813,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1814,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1815,\"textContent\":\"Which 2 shifts end when Z begins?\"}]},{\"nodeType\":3,\"id\":1816,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1817,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1818,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1819,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1820,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1821,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1822,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1823,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1824,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1825,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1826,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1827,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1828,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1829,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1830,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1831,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1832,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1833,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1834,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1835,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1836,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1837,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1838,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1839,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1840,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1841,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1842,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1843,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1844,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1845,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1846,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1847,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":1848,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1849,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1850,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1851,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1852,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1853,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1854,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1855,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":1856,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1857,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1858,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1859,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1860,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1861,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1862,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1863,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":1864,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1865,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1866,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1867,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1868,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1869,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1870,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1871,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":1872,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1873,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1874,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1875,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1876,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1877,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1878,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1879,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":1880,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1881,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1882,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1883,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1884,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1885,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1886,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1887,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":1888,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1889,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1890,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1891,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1892,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1893,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1894,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1895,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":1896,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1897,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1898,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1899,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1900,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1901,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1902,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1903,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":1904,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1905,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1906,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1907,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1908,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1909,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1910,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1911,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":1912,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1913,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1914,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1915,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1916,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1917,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1918,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1919,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":1920,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1921,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1922,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1923,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1924,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1925,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1926,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1927,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":1928,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1929,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1930,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1931,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1932,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1933,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1934,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1935,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":1936,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1937,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1938,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1939,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1940,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1941,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1942,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1943,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":1944,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1945,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1946,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1947,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1948,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1949,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1950,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1951,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":1952,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1953,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1954,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1955,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1956,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1957,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1958,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1959,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":1960,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1961,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1962,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1963,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":1964,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1965,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.endtime\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":1966,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1967,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":1968,\"textContent\":\"Which shift(s) end at 3pm?\"}]},{\"nodeType\":3,\"id\":1969,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1970,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":1971,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1972,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1973,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1974,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1975,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1976,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":1977,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1978,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1979,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1980,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1981,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1982,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1983,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1984,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":1985,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1986,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1987,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1988,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1989,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1990,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1991,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":1992,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":1993,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":1994,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":1995,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1996,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":1997,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":1998,\"textContent\":\" \"},{\"nodeType\":1,\"id\":1999,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2000,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2001,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2002,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2003,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2004,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2005,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2006,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2007,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2008,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2009,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2010,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2011,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2012,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2013,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2014,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2015,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2016,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2017,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2018,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2019,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2020,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2021,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2022,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2023,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2024,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2025,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2026,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2027,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2028,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2029,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2030,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2031,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2032,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2033,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2034,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2035,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2036,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2037,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2038,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2039,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2040,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2041,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2042,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2043,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2044,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2045,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2046,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2047,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2048,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2049,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2050,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2051,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2052,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2053,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2054,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2055,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2056,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2057,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2058,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2059,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2060,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2061,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2062,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2063,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2064,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2065,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2066,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2067,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2068,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2069,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2070,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2071,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2072,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2073,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2074,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2075,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2076,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2077,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2078,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2079,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2080,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2081,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2082,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2083,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2084,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2085,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2086,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2087,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2088,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2089,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2090,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2091,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2092,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2093,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2094,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2095,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2096,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2097,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2098,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2099,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2100,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2101,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2102,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2103,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2104,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2105,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2106,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2107,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2108,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2109,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2110,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2111,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2112,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2113,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2114,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2115,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2116,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2117,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2118,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\"bigset.midpoint\",\"style\":\"display:none\"},\"childNodes\":[{\"nodeType\":3,\"id\":2119,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2120,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2121,\"textContent\":\"Coffee breaks happen halfway through a shift. \"},{\"nodeType\":1,\"id\":2122,\"tagName\":\"BR\",\"attributes\":{}},{\"nodeType\":3,\"id\":2123,\"textContent\":\"Which shifts share a break at 2pm?\"}]},{\"nodeType\":3,\"id\":2124,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2125,\"tagName\":\"UL\",\"attributes\":{\"class\":\"checkbox-grid\"},\"childNodes\":[{\"nodeType\":3,\"id\":2126,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2127,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2128,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2129,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2130,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"I\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2131,\"textContent\":\"I \"},{\"nodeType\":1,\"id\":2132,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2133,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2134,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2135,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2136,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2137,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2138,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"J\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2139,\"textContent\":\"J \"},{\"nodeType\":1,\"id\":2140,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2141,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2142,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2143,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2144,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2145,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2146,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"E\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2147,\"textContent\":\"E \"},{\"nodeType\":1,\"id\":2148,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2149,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2150,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2151,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2152,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2153,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2154,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"F\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2155,\"textContent\":\"F \"},{\"nodeType\":1,\"id\":2156,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2157,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2158,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2159,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2160,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2161,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2162,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"B\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2163,\"textContent\":\"B \"},{\"nodeType\":1,\"id\":2164,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2165,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2166,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2167,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2168,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2169,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2170,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"M\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2171,\"textContent\":\"M \"},{\"nodeType\":1,\"id\":2172,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2173,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2174,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2175,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2176,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2177,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2178,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"A\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2179,\"textContent\":\"A \"},{\"nodeType\":1,\"id\":2180,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2181,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2182,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2183,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2184,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2185,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2186,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"G\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2187,\"textContent\":\"G \"},{\"nodeType\":1,\"id\":2188,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2189,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2190,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2191,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2192,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2193,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2194,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"C\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2195,\"textContent\":\"C \"},{\"nodeType\":1,\"id\":2196,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2197,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2198,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2199,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2200,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2201,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2202,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"K\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2203,\"textContent\":\"K \"},{\"nodeType\":1,\"id\":2204,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2205,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2206,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2207,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2208,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2209,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2210,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"X\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2211,\"textContent\":\"X \"},{\"nodeType\":1,\"id\":2212,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2213,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2214,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2215,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2216,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2217,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2218,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"O\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2219,\"textContent\":\"O \"},{\"nodeType\":1,\"id\":2220,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2221,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2222,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2223,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2224,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2225,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2226,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"P\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2227,\"textContent\":\"P \"},{\"nodeType\":1,\"id\":2228,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2229,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2230,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2231,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2232,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2233,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2234,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"L\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2235,\"textContent\":\"L \"},{\"nodeType\":1,\"id\":2236,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2237,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2238,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2239,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2240,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2241,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2242,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"H\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2243,\"textContent\":\"H \"},{\"nodeType\":1,\"id\":2244,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2245,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2246,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2247,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2248,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2249,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2250,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"Z\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2251,\"textContent\":\"Z \"},{\"nodeType\":1,\"id\":2252,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2253,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2254,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2255,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2256,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2257,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2258,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"N\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2259,\"textContent\":\"N \"},{\"nodeType\":1,\"id\":2260,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2261,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2262,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2263,\"tagName\":\"LI\",\"attributes\":{\"class\":\"control\"},\"childNodes\":[{\"nodeType\":1,\"id\":2264,\"tagName\":\"LABEL\",\"attributes\":{\"class\":\"control control-checkbox\"},\"childNodes\":[{\"nodeType\":3,\"id\":2265,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2266,\"tagName\":\"INPUT\",\"attributes\":{\"type\":\"checkbox\",\"name\":\"D\",\"value\":\"\"}},{\"nodeType\":3,\"id\":2267,\"textContent\":\"D \"},{\"nodeType\":1,\"id\":2268,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"control_indicator\"}},{\"nodeType\":3,\"id\":2269,\"textContent\":\" \"}]}]},{\"nodeType\":3,\"id\":2270,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2271,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2272,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2273,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"bigset\",\"id\":\".strategy\",\"style\":\"display: block;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2274,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2275,\"tagName\":\"P\",\"attributes\":{\"class\":\"question\"},\"childNodes\":[{\"nodeType\":3,\"id\":2276,\"textContent\":\"Please describe how to determine what event(s) start at 12pm?\"}]},{\"nodeType\":3,\"id\":2277,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2278,\"tagName\":\"TEXTAREA\",\"attributes\":{\"id\":\"strategyAnswer\",\"rows\":\"5\",\"cols\":\"80\"}},{\"nodeType\":3,\"id\":2279,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2280,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2281,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2282},{\"nodeType\":3,\"id\":2283,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2284},{\"nodeType\":3,\"id\":2285,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2286,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"fixbottom\"},\"childNodes\":[{\"nodeType\":3,\"id\":2287,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2288,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"testingButton\",\"style\":\"display:none;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2289,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2290,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2291,\"tagName\":\"BUTTON\",\"attributes\":{\"type\":\"button\",\"id\":\"strategyButton\",\"style\":\"display: block;\",\"class\":\"btn\"},\"childNodes\":[{\"nodeType\":3,\"id\":2292,\"textContent\":\"SUBMIT\"}]},{\"nodeType\":3,\"id\":2293,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2294,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2295,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2296},{\"nodeType\":3,\"id\":2297,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2298,\"tagName\":\"DIV\",\"attributes\":{\"class\":\"d3container\"},\"childNodes\":[{\"nodeType\":1,\"id\":2299,\"tagName\":\"svg\",\"attributes\":{\"width\":\"930\",\"height\":\"915\"},\"childNodes\":[{\"nodeType\":1,\"id\":2300,\"tagName\":\"g\",\"attributes\":{\"transform\":\"translate(100,25)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2301,\"tagName\":\"g\",\"attributes\":{\"class\":\"leaders\"}},{\"nodeType\":1,\"id\":2302,\"tagName\":\"g\",\"attributes\":{\"class\":\"static-scaffold\"}},{\"nodeType\":1,\"id\":2303,\"tagName\":\"g\",\"attributes\":{\"class\":\"xaxis\",\"transform\":\"translate(0,800)\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"middle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2304,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M0.5,6V0.5H800.5V6\"}},{\"nodeType\":1,\"id\":2305,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2306,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2307,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2308,\"textContent\":\"08 AM\"}]}]},{\"nodeType\":1,\"id\":2309,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(33.83333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2310,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2311,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2312,\"textContent\":\"08:30\"}]}]},{\"nodeType\":1,\"id\":2313,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(67.16666666666666,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2314,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2315,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2316,\"textContent\":\"09 AM\"}]}]},{\"nodeType\":1,\"id\":2317,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(100.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2318,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2319,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2320,\"textContent\":\"09:30\"}]}]},{\"nodeType\":1,\"id\":2321,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(133.83333333333331,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2322,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2323,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2324,\"textContent\":\"10 AM\"}]}]},{\"nodeType\":1,\"id\":2325,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(167.16666666666669,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2326,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2327,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2328,\"textContent\":\"10:30\"}]}]},{\"nodeType\":1,\"id\":2329,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(200.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2330,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2331,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2332,\"textContent\":\"11 AM\"}]}]},{\"nodeType\":1,\"id\":2333,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(233.83333333333334,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2334,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2335,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2336,\"textContent\":\"11:30\"}]}]},{\"nodeType\":1,\"id\":2337,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(267.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2338,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2339,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2340,\"textContent\":\"12 PM\"}]}]},{\"nodeType\":1,\"id\":2341,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(300.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2342,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2343,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2344,\"textContent\":\"12:30\"}]}]},{\"nodeType\":1,\"id\":2345,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(333.83333333333337,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2346,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2347,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2348,\"textContent\":\"01 PM\"}]}]},{\"nodeType\":1,\"id\":2349,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(367.16666666666663,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2350,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2351,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2352,\"textContent\":\"01:30\"}]}]},{\"nodeType\":1,\"id\":2353,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(400.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2354,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2355,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2356,\"textContent\":\"02 PM\"}]}]},{\"nodeType\":1,\"id\":2357,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(433.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2358,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2359,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2360,\"textContent\":\"02:30\"}]}]},{\"nodeType\":1,\"id\":2361,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(467.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2362,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2363,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2364,\"textContent\":\"03 PM\"}]}]},{\"nodeType\":1,\"id\":2365,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(500.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2366,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2367,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2368,\"textContent\":\"03:30\"}]}]},{\"nodeType\":1,\"id\":2369,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(533.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2370,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2371,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2372,\"textContent\":\"04 PM\"}]}]},{\"nodeType\":1,\"id\":2373,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(567.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2374,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2375,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2376,\"textContent\":\"04:30\"}]}]},{\"nodeType\":1,\"id\":2377,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(600.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2378,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2379,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2380,\"textContent\":\"05 PM\"}]}]},{\"nodeType\":1,\"id\":2381,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(633.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2382,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2383,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2384,\"textContent\":\"05:30\"}]}]},{\"nodeType\":1,\"id\":2385,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(667.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2386,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2387,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2388,\"textContent\":\"06 PM\"}]}]},{\"nodeType\":1,\"id\":2389,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(700.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2390,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2391,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2392,\"textContent\":\"06:30\"}]}]},{\"nodeType\":1,\"id\":2393,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(733.8333333333333,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2394,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2395,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2396,\"textContent\":\"07 PM\"}]}]},{\"nodeType\":1,\"id\":2397,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(767.1666666666667,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2398,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2399,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: none;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2400,\"textContent\":\"07:30\"}]}]},{\"nodeType\":1,\"id\":2401,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(800.5,0)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2402,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"y2\":\"6\"}},{\"nodeType\":1,\"id\":2403,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"y\":\"9\",\"dy\":\"0.71em\",\"style\":\"display: initial;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2404,\"textContent\":\"08 PM\"}]}]},{\"nodeType\":1,\"id\":2405,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2406,\"tagName\":\"text\",\"attributes\":{\"x\":\"533.3333333333334\",\"y\":\"80\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2407,\"textContent\":\"START & END TIME (time of day)\"}]}]}]},{\"nodeType\":1,\"id\":2408,\"tagName\":\"g\",\"attributes\":{\"class\":\"yaxis\",\"fill\":\"none\",\"font-size\":\"10\",\"font-family\":\"sans-serif\",\"text-anchor\":\"end\"},\"childNodes\":[{\"nodeType\":1,\"id\":2409,\"tagName\":\"path\",\"attributes\":{\"class\":\"domain\",\"stroke\":\"#000\",\"d\":\"M-15,800.5H0.5V0.5H-15\"}},{\"nodeType\":1,\"id\":2410,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,800.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2411,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2412,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2413,\"textContent\":\"0\"}]}]},{\"nodeType\":1,\"id\":2414,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,733.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2415,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2416,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2417,\"textContent\":\"1\"}]}]},{\"nodeType\":1,\"id\":2418,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,667.1666666666667)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2419,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2420,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2421,\"textContent\":\"2\"}]}]},{\"nodeType\":1,\"id\":2422,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,600.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2423,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2424,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2425,\"textContent\":\"3\"}]}]},{\"nodeType\":1,\"id\":2426,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,533.8333333333334)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2427,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2428,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2429,\"textContent\":\"4\"}]}]},{\"nodeType\":1,\"id\":2430,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,467.16666666666663)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2431,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2432,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2433,\"textContent\":\"5\"}]}]},{\"nodeType\":1,\"id\":2434,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,400.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2435,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2436,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2437,\"textContent\":\"6\"}]}]},{\"nodeType\":1,\"id\":2438,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,333.8333333333333)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2439,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2440,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2441,\"textContent\":\"7\"}]}]},{\"nodeType\":1,\"id\":2442,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,267.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2443,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2444,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2445,\"textContent\":\"8\"}]}]},{\"nodeType\":1,\"id\":2446,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,200.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2447,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2448,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2449,\"textContent\":\"9\"}]}]},{\"nodeType\":1,\"id\":2450,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,133.83333333333326)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2451,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2452,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2453,\"textContent\":\"10\"}]}]},{\"nodeType\":1,\"id\":2454,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,67.16666666666674)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2455,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2456,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2457,\"textContent\":\"11\"}]}]},{\"nodeType\":1,\"id\":2458,\"tagName\":\"g\",\"attributes\":{\"class\":\"tick\",\"opacity\":\"1\",\"transform\":\"translate(0,0.5)\"},\"childNodes\":[{\"nodeType\":1,\"id\":2459,\"tagName\":\"line\",\"attributes\":{\"stroke\":\"#000\",\"x2\":\"-15\"}},{\"nodeType\":1,\"id\":2460,\"tagName\":\"text\",\"attributes\":{\"fill\":\"#000\",\"x\":\"-18\",\"dy\":\"0.32em\"},\"childNodes\":[{\"nodeType\":3,\"id\":2461,\"textContent\":\"12\"}]}]},{\"nodeType\":1,\"id\":2462,\"tagName\":\"g\",\"attributes\":{\"class\":\"axisTitle\"},\"childNodes\":[{\"nodeType\":1,\"id\":2463,\"tagName\":\"text\",\"attributes\":{\"transform\":\"rotate(-90)\",\"x\":\"-350\",\"y\":\"-60\",\"style\":\"text-anchor: end;\"},\"childNodes\":[{\"nodeType\":3,\"id\":2464,\"textContent\":\"DURATION (in hours)\"}]}]}]},{\"nodeType\":1,\"id\":2465,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2466,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2467,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"733.3333333333334\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2468,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2469,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"666.6666666666667\",\"y2\":\"666.6666666666667\"}}]},{\"nodeType\":1,\"id\":2470,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2471,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"600\",\"y2\":\"600\"}}]},{\"nodeType\":1,\"id\":2472,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2473,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"533.3333333333334\",\"y2\":\"533.3333333333334\"}}]},{\"nodeType\":1,\"id\":2474,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2475,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"466.66666666666663\",\"y2\":\"466.66666666666663\"}}]},{\"nodeType\":1,\"id\":2476,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2477,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"400\",\"y2\":\"400\"}}]},{\"nodeType\":1,\"id\":2478,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2479,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"333.3333333333333\",\"y2\":\"333.3333333333333\"}}]},{\"nodeType\":1,\"id\":2480,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2481,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"266.66666666666674\",\"y2\":\"266.66666666666674\"}}]},{\"nodeType\":1,\"id\":2482,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2483,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"200\",\"y2\":\"200\"}}]},{\"nodeType\":1,\"id\":2484,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2485,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"133.33333333333326\",\"y2\":\"133.33333333333326\"}}]},{\"nodeType\":1,\"id\":2486,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2487,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"66.66666666666674\",\"y2\":\"66.66666666666674\"}}]},{\"nodeType\":1,\"id\":2488,\"tagName\":\"g\",\"attributes\":{\"class\":\"ygrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2489,\"tagName\":\"line\",\"attributes\":{\"x1\":\"0\",\"x2\":\"800\",\"y1\":\"0\",\"y2\":\"0\"}}]}]},{\"nodeType\":1,\"id\":2490,\"tagName\":\"g\",\"attributes\":{\"class\":\"xgrid\"},\"childNodes\":[{\"nodeType\":1,\"id\":2491,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"0\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2492,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"800\",\"y1\":\"800\",\"x2\":\"400\",\"y2\":\"0\"}},{\"nodeType\":1,\"id\":2493,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"433.3333333333333\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2494,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"366.66666666666663\",\"y2\":\"66.66666666666674\"}},{\"nodeType\":1,\"id\":2495,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"466.6666666666667\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2496,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"333.33333333333337\",\"y2\":\"133.33333333333326\"}},{\"nodeType\":1,\"id\":2497,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"500\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2498,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"300\",\"y2\":\"200\"}},{\"nodeType\":1,\"id\":2499,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"533.3333333333333\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2500,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"266.66666666666663\",\"y2\":\"266.66666666666674\"}},{\"nodeType\":1,\"id\":2501,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"566.6666666666667\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2502,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"233.33333333333334\",\"y2\":\"333.3333333333333\"}},{\"nodeType\":1,\"id\":2503,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"600\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2504,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"400\",\"y1\":\"800\",\"x2\":\"200\",\"y2\":\"400\"}},{\"nodeType\":1,\"id\":2505,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"466.6666666666667\",\"y1\":\"800\",\"x2\":\"633.3333333333333\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2506,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"333.33333333333337\",\"y1\":\"800\",\"x2\":\"166.66666666666669\",\"y2\":\"466.66666666666663\"}},{\"nodeType\":1,\"id\":2507,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"533.3333333333333\",\"y1\":\"800\",\"x2\":\"666.6666666666667\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2508,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"266.66666666666663\",\"y1\":\"800\",\"x2\":\"133.33333333333331\",\"y2\":\"533.3333333333334\"}},{\"nodeType\":1,\"id\":2509,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"600\",\"y1\":\"800\",\"x2\":\"700\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2510,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"200\",\"y1\":\"800\",\"x2\":\"100\",\"y2\":\"600\"}},{\"nodeType\":1,\"id\":2511,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"666.6666666666667\",\"y1\":\"800\",\"x2\":\"733.3333333333333\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2512,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"133.33333333333331\",\"y1\":\"800\",\"x2\":\"66.66666666666666\",\"y2\":\"666.6666666666667\"}},{\"nodeType\":1,\"id\":2513,\"tagName\":\"line\",\"attributes\":{\"class\":\"rgrid\",\"x1\":\"733.3333333333333\",\"y1\":\"800\",\"x2\":\"766.6666666666667\",\"y2\":\"733.3333333333334\"}},{\"nodeType\":1,\"id\":2514,\"tagName\":\"line\",\"attributes\":{\"class\":\"lgrid\",\"x1\":\"66.66666666666666\",\"y1\":\"800\",\"x2\":\"33.33333333333333\",\"y2\":\"733.3333333333334\"}}]},{\"nodeType\":1,\"id\":2515,\"tagName\":\"g\",\"attributes\":{\"class\":\"data\"},\"childNodes\":[{\"nodeType\":1,\"id\":2516,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2517,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"266.66666666666674\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2518,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"258.66666666666674\"},\"childNodes\":[{\"nodeType\":3,\"id\":2519,\"textContent\":\"A \"}]}]},{\"nodeType\":1,\"id\":2520,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2521,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2522,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2523,\"textContent\":\"B \"}]}]},{\"nodeType\":1,\"id\":2524,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2525,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"366.66666666666663\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2526,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"361.66666666666663\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2527,\"textContent\":\"C \"}]}]},{\"nodeType\":1,\"id\":2528,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2529,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"666.6666666666667\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2530,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"661.6666666666667\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2531,\"textContent\":\"D \"}]}]},{\"nodeType\":1,\"id\":2532,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2533,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"200\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2534,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"195\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2535,\"textContent\":\"E \"}]}]},{\"nodeType\":1,\"id\":2536,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2537,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"266.66666666666663\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2538,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"261.66666666666663\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2539,\"textContent\":\"F \"}]}]},{\"nodeType\":1,\"id\":2540,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2541,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"333.33333333333337\",\"cy\":\"400\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2542,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"328.33333333333337\",\"y\":\"392\"},\"childNodes\":[{\"nodeType\":3,\"id\":2543,\"textContent\":\"G \"}]}]},{\"nodeType\":1,\"id\":2544,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2545,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"466.66666666666663\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2546,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"458.66666666666663\"},\"childNodes\":[{\"nodeType\":3,\"id\":2547,\"textContent\":\"H \"}]}]},{\"nodeType\":1,\"id\":2548,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2549,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"100\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2550,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"95\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2551,\"textContent\":\"I \"}]}]},{\"nodeType\":1,\"id\":2552,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2553,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"133.33333333333331\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2554,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"128.33333333333331\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2555,\"textContent\":\"J \"}]}]},{\"nodeType\":1,\"id\":2556,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2557,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"133.33333333333326\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2558,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"125.33333333333326\"},\"childNodes\":[{\"nodeType\":3,\"id\":2559,\"textContent\":\"K \"}]}]},{\"nodeType\":1,\"id\":2560,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2561,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"333.3333333333333\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2562,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"325.3333333333333\"},\"childNodes\":[{\"nodeType\":3,\"id\":2563,\"textContent\":\"L \"}]}]},{\"nodeType\":1,\"id\":2564,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2565,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"300\",\"cy\":\"733.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2566,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"295\",\"y\":\"725.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2567,\"textContent\":\"M \"}]}]},{\"nodeType\":1,\"id\":2568,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2569,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"600\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2570,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"595\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2571,\"textContent\":\"N \"}]}]},{\"nodeType\":1,\"id\":2572,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2573,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"433.3333333333333\",\"cy\":\"600\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2574,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"428.3333333333333\",\"y\":\"592\"},\"childNodes\":[{\"nodeType\":3,\"id\":2575,\"textContent\":\"O \"}]}]},{\"nodeType\":1,\"id\":2576,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2577,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"500\",\"cy\":\"200\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2578,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"495\",\"y\":\"192\"},\"childNodes\":[{\"nodeType\":3,\"id\":2579,\"textContent\":\"P \"}]}]},{\"nodeType\":1,\"id\":2580,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2581,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"533.3333333333333\",\"cy\":\"533.3333333333334\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2582,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"528.3333333333333\",\"y\":\"525.3333333333334\"},\"childNodes\":[{\"nodeType\":3,\"id\":2583,\"textContent\":\"Z \"}]}]},{\"nodeType\":1,\"id\":2584,\"tagName\":\"g\",\"attributes\":{},\"childNodes\":[{\"nodeType\":1,\"id\":2585,\"tagName\":\"circle\",\"attributes\":{\"class\":\"dot\",\"cx\":\"400\",\"cy\":\"666.6666666666667\",\"r\":\"6\",\"selected\":\"false\"}},{\"nodeType\":1,\"id\":2586,\"tagName\":\"text\",\"attributes\":{\"class\":\"tmlabel\",\"x\":\"395\",\"y\":\"658.6666666666667\"},\"childNodes\":[{\"nodeType\":3,\"id\":2587,\"textContent\":\"X \"}]}]}]}]}]}]},{\"nodeType\":3,\"id\":2588,\"textContent\":\" \"}]},{\"nodeType\":3,\"id\":2589,\"textContent\":\" \"},{\"nodeType\":8,\"id\":2590},{\"nodeType\":3,\"id\":2591,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2592,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2593,\"textContent\":\" \"},{\"nodeType\":1,\"id\":2594,\"tagName\":\"SCRIPT\"},{\"nodeType\":3,\"id\":2595,\"textContent\":\" \"}]}]}]]}",
  "useCssProxy": true,
  "loadTimes": "es: 121, dom: 644, initialDom: 966",
  "javascriptErrors": []
}